import RamanujanPV.PackedHigh128.Data
import RamanujanPV.PackedHighBaseline.Data
namespace RamanujanPV.PackedHigh128
open RamanujanPV.QuotientDemandCheck
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
set_option Elab.async false
theorem every_original_page_word : allFrom (fun i=>decide (rawNodes.get i=RamanujanPV.PackedHighBaseline.rawNodes.get i)) 0 131072=true := by decide +kernel
#print axioms every_original_page_word
end RamanujanPV.PackedHigh128
