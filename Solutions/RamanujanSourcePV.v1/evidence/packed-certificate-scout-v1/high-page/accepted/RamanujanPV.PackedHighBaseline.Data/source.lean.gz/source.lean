import RamanujanPV.PackedHighBaseline.Data0000
import RamanujanPV.QuotientCertificateCode
namespace RamanujanPV.PackedHighBaseline
noncomputable def rawNodes : Lean.RArray Nat := raw_0000
noncomputable def nodes := RamanujanPV.QuotientPackedDemand.unpack rawNodes
end RamanujanPV.PackedHighBaseline
