import RamanujanPV.PackedHighBaseline.Data
import RamanujanPV.PackedHighBaseline.Gaps
namespace RamanujanPV.PackedHighBaseline
open RamanujanPV.QuotientDemandCheck
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
set_option Elab.async false
theorem original_first32768 : allFrom (checkEntry nodes RamanujanPV.PackedHighBaseline.gaps RamanujanPV.PackedHighBaseline.gapCount) 0 32768=true := by decide +kernel
#print axioms original_first32768
end RamanujanPV.PackedHighBaseline
