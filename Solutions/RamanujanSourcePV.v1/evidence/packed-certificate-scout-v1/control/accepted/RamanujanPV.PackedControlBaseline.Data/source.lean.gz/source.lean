/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import RamanujanPV.QuotientCertificateCode
import RamanujanPV.PackedControlBaseline.Gaps
import RamanujanPV.PackedControlBaseline.Data0000
import RamanujanPV.PackedControlBaseline.Data0001
namespace RamanujanPV.PackedControlBaseline
open QuotientDemandCheck QuotientPackedDemand
noncomputable def rawNodes : Lean.RArray Nat := (.branch 8192 raw_0000 raw_0001)
noncomputable def nodes : Lean.RArray Entry := unpack rawNodes
def entryCount : Nat := 11523
end RamanujanPV.PackedControlBaseline
