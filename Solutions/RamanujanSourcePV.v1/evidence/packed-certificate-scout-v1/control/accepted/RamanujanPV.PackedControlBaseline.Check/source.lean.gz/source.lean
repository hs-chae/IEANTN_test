import RamanujanPV.PackedControlBaseline.Data
namespace RamanujanPV.PackedControlBaseline
open RamanujanPV.QuotientDemandCheck
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
set_option Elab.async false
theorem all_numeric : allFrom (checkEntry nodes RamanujanPV.PackedControlBaseline.gaps RamanujanPV.PackedControlBaseline.gapCount) 0 11523=true := by decide +kernel
#print axioms all_numeric
end RamanujanPV.PackedControlBaseline
