import RamanujanPV.PackedControl128.Data
import RamanujanPV.PackedControlBaseline.Data
namespace RamanujanPV.PackedControl128
open RamanujanPV.QuotientDemandCheck
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
set_option Elab.async false
theorem every_original_word : allFrom (fun i=>decide (rawNodes.get i=RamanujanPV.PackedControlBaseline.rawNodes.get i)) 0 11523=true := by decide +kernel
#print axioms every_original_word
end RamanujanPV.PackedControl128
