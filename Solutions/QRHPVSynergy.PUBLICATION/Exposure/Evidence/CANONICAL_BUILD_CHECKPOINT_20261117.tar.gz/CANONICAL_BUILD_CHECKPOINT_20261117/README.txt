Canonical research-build checkpoint

The completed run compiled 3,908 fresh modules over a validated 10,970-module
source-built parent, then checked 20,541 selected typed roots. It exited0.
This is a chain with explicitly validated seeds, not a second empty-bank run.

These are existing receipts, source/environment locks and measurements.
They do not complete the later source-use audits, four context routes,
network10 or late3 append. No experimental scores or official status change.
The historical source-lock qualifier is retained; use the actual inventories
and final compiler receipt for current counts. The original actual compiled
objects and full run outputs remain preserved in the local study workspace.

Sources and clean regeneration scripts are separately available in the
44,182,004-byte QRH_SOURCE_FIRST_RESEARCH_REPRODUCTION_20261116.tar.xz.
This checkpoint avoids distributing huge regenerable application object banks.
Exact aggregate RAM peak and per-run disk peak are unavailable; sampled memory
is a lower bound. RESOURCE_SCOPE contains the actual full recorded samples.
