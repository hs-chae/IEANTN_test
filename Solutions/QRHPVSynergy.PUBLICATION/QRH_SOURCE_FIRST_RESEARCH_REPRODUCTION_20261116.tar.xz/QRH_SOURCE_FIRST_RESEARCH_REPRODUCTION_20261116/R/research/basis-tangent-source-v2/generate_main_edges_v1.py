"""Emit fixed actual C endpoint/buffer proofs; the Lean kernel checks every result."""
import argparse
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    if a.out.exists() or not a.out.resolve().is_relative_to(B):
        raise ValueError('fresh owned generation directory required')
    a.out.mkdir(parents=True)
    rows = []
    for kind, count in [('Prefix', 16), ('Shared', 256)]:
        for start in range(0, count, 32):
            block = start // 32
            name = f'SynergyTangentV2C.MainEdges.{kind}{block:02d}'
            s = ['/- Actual l and zero-buffer declarations from the fixed C main. -/',
                 'import SynergyTangentV2C.MainCellAPI', f'namespace {name}',
                 'open ScopedC ScopedNumerical', 'set_option autoImplicit false',
                 'set_option maxHeartbeats 0', 'set_option maxRecDepth 100000',
                 'set_option exponentiation.threshold 1024']
            roots = []
            for i in range(start, min(start+32, count)):
                logs = 'true' if kind == 'Shared' else 'false'
                numerator, denominator = (256+15*i, 256) if kind == 'Shared' else (80+i, 96)
                root = f'{name}.cell{i:03d}'
                roots.append(root)
                s += [f'theorem cell{i:03d} : MainCellAPI.ExactEdges {logs} {i}',
                      f'    (SynergyAnalytic.BoxModel.rat {numerator} {denominator}) := by',
                      '  intro totals arena', '  unfold MainCellAPI.edges',
                      '  run_tac do', '    let goal ← Lean.Elab.Tactic.getMainGoal',
                      '    let target ← goal.getType', '    let args := target.getAppArgs',
                      '    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do',
                      '      throwError "expected actual endpoint/buffer source equality"',
                      '    goal.assign (← Lean.Meta.mkEqRefl args[1]!)']
            s += [f'#print axioms {root}' for root in roots]
            s += [f'end {name}', '']
            p = B / 'lean' / Path(name.replace('.', '/') + '.lean')
            p.parent.mkdir(parents=True, exist_ok=True)
            text = '\n'.join(s)
            if p.exists() and p.read_text() != text:
                raise ValueError('refuse to overwrite different generated proof source')
            p.write_text(text)
            rows.append(dict(module=name, source=str(p.relative_to(B)),
                             source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(), roots=roots))
    result = dict(status='GENERATED_SOURCE_ONLY_PENDING_ORDINARY_KERNEL_COMPILATION',
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), rows=rows)
    (a.out / 'PLAN.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(modules=len(rows), requested_roots=sum(len(r['roots']) for r in rows))))


if __name__ == '__main__':
    main()
