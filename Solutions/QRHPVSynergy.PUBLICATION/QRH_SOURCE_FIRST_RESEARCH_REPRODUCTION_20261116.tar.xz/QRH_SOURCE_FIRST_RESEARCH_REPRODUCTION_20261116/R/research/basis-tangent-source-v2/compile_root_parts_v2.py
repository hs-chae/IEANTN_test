"""Compile the owned emitter/main modules with the existing strict consumer builder."""
import argparse
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

B = Path(__file__).resolve().parent
R = B.parents[1]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--only', action='append', default=[])
    a = ap.parse_args()
    out = a.out.resolve()
    need(not out.exists() and out.is_relative_to(B), 'fresh owned proof output')
    out.mkdir(parents=True)
    source_root = B / 'lean'
    directory = source_root / 'SynergyTangentV2C'
    candidates = sorted(directory.glob('EmitU*.lean')) + [directory / (name + '.lean') for name in
        ['MainInitialization', 'MainFrames', 'MainLn2', 'MainPrefix', 'MainCellAPI', 'WorldError']]
    if a.only:
        need(len(a.only) == len(set(a.only)), 'unique explicit selected modules')
        candidates = [p for p in candidates if p.stem in a.only]
        need({p.stem for p in candidates} == set(a.only), 'all explicit modules exist')
    modules = {'SynergyTangentV2C.' + p.stem: p for p in candidates}
    todo = dict(modules)
    order = []
    while todo:
        ready = [name for name, path in todo.items() if all(dep not in todo for dep in
            re.findall(r'^import\s+(\S+)', path.read_text(), re.M))]
        need(ready, 'acyclic selected source dependencies')
        for name in ready:
            order.append(name)
            del todo[name]
    order.sort(key=lambda name: name.startswith("SynergyTangentV2C.Main"))
    rows = []
    started = time.monotonic()
    for name in order:
        source = modules[name]
        text = source.read_text()
        namespace = re.search(r'^namespace\s+(\S+)', text, re.M)
        need(namespace is not None, 'explicit proof namespace')
        roots = [x if x.startswith('SynergyTangentV2C.') else namespace[1] + '.' + x for x in
                 re.findall(r'^#print axioms\s+(\S+)', text, re.M)]
        need(roots and len(roots) == len(set(roots)), 'nonempty unique actual printed root inventory')
        target = out / source.stem
        command = [sys.executable, '-I', '-B', str(R / 'research/main-weight-v1/compile_consumer.py'),
            '--source-root', str(source_root), '--bank',
            str(B / 'objects'), '--module', name,
            '--out', str(target), '--publish-object']
        for root in roots:
            command += ['--root', root]
        q = subprocess.run(command, capture_output=True, text=True)
        (out / (source.stem + '.stdout')).write_text(q.stdout)
        (out / (source.stem + '.stderr')).write_text(q.stderr)
        row = dict(module=name, source_sha256=sha(source), roots=roots, command=command,
                   exit_code=q.returncode,
                   receipt_sha256=sha(target / 'RECEIPT.json') if (target / 'RECEIPT.json').is_file() else None)
        rows.append(row)
        (out / 'PROGRESS.json').write_text(json.dumps(dict(rows=rows), indent=2) + '\n')
        print(json.dumps(dict(module=name, exit_code=q.returncode)), flush=True)
        if q.returncode:
            print(q.stdout[-2500:] + q.stderr[-1000:], flush=True)
            raise ValueError('actual compiler or typed Std3 source acceptance rejected ' + name)
    result = dict(status='PASS_SELECTED_ROOT_OWNED_SOURCE_MODULES_TYPED_STD3_HOST',
                  seconds=time.monotonic() - started, rows=rows,
                  script_sha256=sha(Path(__file__)),
                  qualification='Warm coherent research source context. Actual source statements and '
                  'all explicit roots compile; complete basis-program/math/isolated gates remain separate.')
    (out / 'RECEIPT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status=result['status'], modules=len(rows), seconds=result['seconds'])))


if __name__ == '__main__':
    main()
