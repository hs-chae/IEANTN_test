"""Generate complete finite-row elimination and the exact public basis interface."""
import argparse
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent


def emit(module, source, rows):
    p = B / 'lean' / (module.replace('.', '/')+'.lean')
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists() and p.read_text() != source:
        raise ValueError('refuse different previously generated source '+module)
    p.write_text(source)
    rows.append(dict(module=module, source=str(p.relative_to(B)),
                     source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    if a.out.exists() or not a.out.resolve().is_relative_to(B):
        raise ValueError('fresh owned generation output')
    a.out.mkdir(parents=True)
    rows = []
    s = ['/- Complete actual C shared-loop rows, no finite provider hypothesis. -/',
         'import SynergyTangentV2C.MainPureBody']
    s += [f'import SynergyTangentV2C.MainAccum.Shared{b:02d}' for b in range(8)]
    s += ['namespace SynergyTangentV2C.MainSharedRows', 'open ScopedC ScopedNumerical',
          'set_option autoImplicit false', 'set_option maxHeartbeats 0',
          'set_option maxRecDepth 100000',
          'theorem complete : MainPureBody.SharedRows := by', '  intro i hi',
          '  change i < 256 at hi', '  interval_cases i']
    s += [f'  · exact MainAccum.Shared{i//32:02d}.source{i:03d} MainPureBody.arena'
          for i in range(256)]
    s += ['#print axioms complete', 'end SynergyTangentV2C.MainSharedRows', '']
    emit('SynergyTangentV2C.MainSharedRows', '\n'.join(s), rows)
    s = '''/- Closed source-first basis program. All272 C cells, accumulations,
both loops and all model correspondences are discharged; no numerical premise. -/
import SynergyTangentV2C.MainSharedRows
import SynergyTangentV2C.MainPrefixRows
import SynergyTangentV2C.CellSharedTotals
import SynergyTangentV2C.ProgramConsumer
namespace SynergyTangentV2C.SourceProgramClosed
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem program_exists : ∃ value, ProgramConsumer.Payload value :=
  ProgramConsumer.exists_output MainPrefixRows.complete MainSharedRows.complete
    CellSharedTotals.complete
noncomputable def sourceOutput : MainFrames.Totals := Classical.choose program_exists
theorem source_output_valid : ProgramConsumer.Payload sourceOutput :=
  Classical.choose_spec program_exists
theorem basis_caps :
    SynergyAnalytic.UniversalBasisCaps (373/200) (1273/2000) (129/250) := by
  have provider := source_output_valid
  exact SynergyTangentC.RealConsumer.caps_from_model_total provider.model
    provider.zeroWord provider.oneWord provider.twoWord

#print axioms program_exists
#print axioms source_output_valid
#print axioms basis_caps
end SynergyTangentV2C.SourceProgramClosed
'''
    emit('SynergyTangentV2C.SourceProgramClosed', s, rows)
    s = '''/- Exact unchanged mathematical basis interface, now fed by the actual
source-first C producer rather than the standalone kernel-only basis provider. -/
import SynergyTangentV2C.SourceProgramClosed
namespace SynergyTangentC.ClosedCaps
theorem source_universal_basis_caps :
    SynergyAnalytic.UniversalBasisCaps (373/200) (1273/2000) (129/250) :=
  SynergyTangentV2C.SourceProgramClosed.basis_caps
#print axioms source_universal_basis_caps
end SynergyTangentC.ClosedCaps
'''
    emit('SynergyTangentC.ClosedCaps', s, rows)
    (a.out / 'PLAN.json').write_text(json.dumps(dict(
        status='GENERATED_SOURCES_PENDING_COMPLETE272_C_SOURCE_AND_MODEL_PROVIDERS',
        rows=rows, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),
        indent=2)+'\n')
    print(json.dumps(dict(modules=len(rows), qualification='NOT_PROOF_ACCEPTANCE')))


if __name__ == '__main__':
    main()
