#!/usr/bin/env python3
"""Untrusted fixed-cell proposals; every generated leaf requires kernel proof."""
from pathlib import Path
import argparse
import hashlib
import json
import re

B = Path(__file__).resolve().parent
R = B.parents[1]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "Duplicate proposal key")
        result[key] = value
    return result


def invalid_constant(value):
    raise ValueError("Nonfinite JSON constant: "+value)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--proposal", type=Path, required=True)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    raw = args.proposal.read_text()
    decoder = json.JSONDecoder(object_pairs_hook=unique, parse_constant=invalid_constant)
    data, position = decoder.raw_decode(raw)
    tail = raw[position:].strip()
    diagnostic = json.loads(tail, object_pairs_hook=unique, parse_constant=invalid_constant)
    need(set(diagnostic) == {"exit_code", "classification", "source_sha256"} and
         type(diagnostic["exit_code"]) is int and diagnostic["exit_code"] == 0 and
         diagnostic["classification"] == "UNTRUSTED_NATIVE_DIAGNOSTIC_NO_NUMERICAL_THEOREM",
         "Actual successful proposer diagnostic")
    need(diagnostic["source_sha256"] == sha(B / "lean/SynergyTangentV2C/FamilyProposal.lean"),
         "Actual current source proposer pin")
    need(set(data) == {"classification", "cells", "prefix", "fractional_bits", "word_bits", "rows"} and
         all(type(data[k]) is int for k in ["cells", "prefix", "fractional_bits", "word_bits"]) and
         data["classification"] == "UNTRUSTED_ALL272_PROPOSALS_NOT_PROOF" and
         [data[k] for k in ["cells", "prefix", "fractional_bits", "word_bits"]] ==
         [256, 16, 128, 512], "Locked original mathematical parameters")
    rows = data["rows"]
    identities = [("prefix", i) for i in range(16)] + [("shared", i) for i in range(256)]
    need(isinstance(rows, list) and all(isinstance(r, dict) and
         type(r.get("index")) is int for r in rows), "Strict row/index types")
    need([(r["kind"], r["index"]) for r in rows] == identities,
         "Every original fixed index exactly once, in fixed order")
    for row in rows:
        need(set(row) == {"kind", "index", "left_numerator", "left_denominator",
                         "width_numerator", "width_denominator", "logs",
                         "native_actual_ast_checked", "words"}, "Exact row schema")
        pre = row["kind"] == "prefix"
        index = row["index"]
        expected = ([80+index, 96, 1, 96] if pre else [256+15*index, 256, 15, 256])
        fields = [row[k] for k in ["left_numerator", "left_denominator",
                                   "width_numerator", "width_denominator"]]
        need(all(type(v) is int for v in fields) and fields == expected and
             row["logs"] is (not pre) and row["native_actual_ast_checked"] is True,
             "All exact source inputs validated before writing")
        need(isinstance(row["words"], list) and len(row["words"]) == 6 and
             all(isinstance(w, str) and re.fullmatch(r"0|[1-9][0-9]*", w)
                 for w in row["words"]), "All exact word syntax validated before writing")
        values = [int(w) for w in row["words"]]
        need(all(0 <= w < 2**512 for w in values) and
             all(values[k] <= values[k+1] for k in [0, 2, 4]),
             "All proposed word ranges validated before writing")
    if args.check_only:
        print(json.dumps({"status": "ALL272_FIXED_PROPOSAL_INPUTS_CHECKED_ONLY_NOT_PROOF",
                          "modules": 272, "source_sha256": diagnostic["source_sha256"]}))
        return
    need(args.out is not None, "Fresh output path required for generation")
    out = args.out.resolve()
    need(out.is_relative_to(B) and not out.exists(), "Fresh owned plan")
    root = B / "lean/SynergyTangentV2C/SourceCells"
    need(not root.exists(), "Fresh generated source family")
    out.mkdir(parents=True)
    root.mkdir()
    modules = []
    for row in rows:
        prefix = row["kind"] == "prefix"
        i = row["index"]
        inputs = ([80+i, 96, 1, 96] if prefix else [256+15*i, 256, 15, 256])
        need([row[k] for k in ["left_numerator", "left_denominator",
                               "width_numerator", "width_denominator"]] == inputs and
             row["logs"] is (not prefix) and row["native_actual_ast_checked"] is True,
             "Exact source parameters and untrusted actual AST precheck")
        need(len(row["words"]) == 6 and
             all(isinstance(w, str) and re.fullmatch(r"0|[1-9][0-9]*", w)
                 for w in row["words"]), "Exact decimal word proposals")
        words = [int(w) for w in row["words"]]
        need(all(0 <= w < 2**512 for w in words) and
             all(words[k] <= words[k+1] for k in [0, 2, 4]), "Proposed word ranges/order")
        name = ("Prefix"+f"{i:02}" if prefix else "Shared"+f"{i:03}")
        module = "SynergyTangentV2C.SourceCells."+name
        logs = "false" if prefix else "true"
        text = f'''/- Fixed original {row["kind"]} cell{i}. Numerical words are proposals;
all three proofs below must pass ordinary declaration kernel checking. -/
import SynergyTangentV2C.CellExecutionExact
import SynergyTangentV2C.MainFrames
import ScopedC.ArrayStages
'''
        if not prefix and i == 0:
            text += "import SynergyTangentV2C.CellKernelPilot\n"
        text += f'''open Lean Meta Elab Tactic
namespace {module}
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 300000
set_option exponentiation.threshold 1024
def left : ProofBox := SynergyAnalytic.BoxModel.rat {inputs[0]} {inputs[1]}
def width : ProofBox := SynergyAnalytic.BoxModel.rat {inputs[2]} {inputs[3]}
def output : MainFrames.Totals :=
  (⟨{words[0]},{words[1]}⟩,
   ⟨{words[2]},{words[3]}⟩,
   ⟨{words[4]},{words[5]}⟩)
def base (totals : MainFrames.Totals) (arena : NatArena.Arena) : Machine.State :=
  ArrayStages.withArena (MainFrames.base totals {i} left) arena
theorem model_eq : SynergyAnalytic.BoxModel.sourceCell left width {logs}=some output := by
'''
        text += ("  exact CellOutputPilot.model_eq\n" if not prefix and i == 0
                 else "  decide +kernel\n")
        text += f'''theorem execution (totals : MainFrames.Totals) (arena : NatArena.Arena) :
    CellExecute.run (base totals arena) left width {logs}=
      some (.unit,CellExecute.filled (base totals arena) output) := by
'''
        if not prefix and i == 0:
            text += "  exact CellKernelPilot.actual_execution totals arena\n"
        else:
            text += '''  unfold CellExecute.run
  run_tac do
    let goal ← getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual source execution equality"
    goal.assign (← mkEqRefl args[1]!)
'''
        text += f'''theorem actual_source (totals : MainFrames.Totals) (arena : NatArena.Arena) :
    ArraySourceCalls.SourceCall Header.layout Bundle.code 16 "tangentCell"
      (CellExecute.args (base totals arena) left width {logs})
      (CellExecute.buffers (base totals arena)) .unit
      (CellExecute.filled (base totals arena) output) :=
  CellExecutionExact.source_of_execution (execution totals arena)
#print axioms model_eq
#print axioms execution
#print axioms actual_source
end {module}
'''
        target = root / (name+".lean")
        target.write_text(text)
        modules.append({"module": module, "kind": row["kind"], "index": i,
                        "source": str(target.relative_to(R)), "source_sha256": sha(target),
                        "roots": [module+"."+n for n in ["model_eq", "execution", "actual_source"]]})
    need(len(modules) == 272, "Exact original family population")
    pins = {}
    for name in ["Header", "Generated", "Bundle", "ArithmeticLibrary", "CellExecute",
                 "CellExecutionExact", "MainFrames", "CellOutputPilot", "CellKernelPilot"]:
        p = B / "lean/SynergyTangentV2C" / (name+".lean")
        pins[str(p.relative_to(R))] = sha(p)
    for p in sorted((B / "bundle-source").iterdir()):
        need(p.is_file() and not p.is_symlink(), "Owned actual source-tree leaves")
        pins[str(p.relative_to(R))] = sha(p)
    plan = {"status": "FROZEN_UNTRUSTED_PROPOSALS_PENDING_ALL_KERNEL_PROOFS",
            "parameters": {"cells": 256, "prefix": 16, "fractional_bits": 128, "word_bits": 512},
            "module_count": 272, "root_count": 816, "modules": modules,
            "source_pins": pins, "proposal_sha256": sha(args.proposal),
            "generator_sha256": sha(Path(__file__)),
            "reuse": "Shared000 reuses actually accepted model/kernel source pilot; all other271 newly checked.",
            "qualification": "Native proposals/prechecks confer no proof authority. Each exact index requires separate model equality and actual-C execution plus source-call theorem; no skipKernelTC."}
    (out / "FAMILY_PLAN.json").write_text(json.dumps(plan, indent=2)+"\n")
    print(json.dumps({"status": plan["status"], "modules": 272, "roots": 816}))


if __name__ == "__main__":
    main()
