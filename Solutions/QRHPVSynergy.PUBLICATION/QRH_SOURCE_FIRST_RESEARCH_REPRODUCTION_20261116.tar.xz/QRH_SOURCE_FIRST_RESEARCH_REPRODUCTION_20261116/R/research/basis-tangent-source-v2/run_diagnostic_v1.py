#!/usr/bin/env python3
"""Untrusted #eval diagnostic: no proof acceptance or object publication."""
from pathlib import Path
import json
import os
import subprocess
import hashlib
import argparse

B = Path(__file__).resolve().parent
R = B.parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--module", default="CellDiagnostic")
args = parser.parse_args()
if not args.module.isidentifier():
    raise ValueError("One owned diagnostic module name")
plan = json.loads((R / "research/framed-points-v1/PLAN.json").read_text())
source = B / ("lean/SynergyTangentV2C/"+args.module+".lean")
environment = dict(os.environ, LEAN_NUM_THREADS="1",
                   LEAN_PATH=":".join([str(B / "objects"), *plan["generic_libraries"]]))
result = subprocess.run([plan["compiler"], "-j1", "-R", str(B / "lean"), str(source)],
                        env=environment, capture_output=True, timeout=120)
print(result.stdout.decode(), end="")
print(result.stderr.decode(), end="")
print(json.dumps({"classification": "UNTRUSTED_NATIVE_DIAGNOSTIC_NO_NUMERICAL_THEOREM",
                  "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                  "exit_code": result.returncode}))
raise SystemExit(result.returncode)
