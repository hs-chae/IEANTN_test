#!/usr/bin/env python3
"""Compile both actual programs and require the same complete 512-byte output."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import time

B = Path(__file__).resolve().parent
R = B.parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def need(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compiler", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    need(out.is_relative_to(B) and not out.exists(), "Fresh experiment-owned native directory")
    out.mkdir(parents=True)
    if args.compiler is None:
        environment = json.loads((R / "scoped/build/DEVELOPMENT_ENVIRONMENT.json").read_text())
        compiler = Path(environment["compiler"]).with_name("clang")
    else:
        compiler = args.compiler.resolve()
    need(compiler.is_file(), "Pinned toolchain C++ compiler exists")
    lock = json.loads((B / "NATIVE_COMPILER_LOCK_V1.json").read_text())
    need(sha(compiler) == lock["compiler_sha256"], "Exact pinned native compiler")
    sources = [B / "source/original/basis_fp128_tangent_newton2.cpp",
               B / "bundle-source/basis_bundle.cpp"]
    records = []
    for label, source in zip(["original", "adapted"], sources):
        executable = out / label
        command = [str(compiler), "-std=c++17", "-O2", "-DBASIS_TANGENT_CELLS=256",
                   "-isystem", "/usr/include/c++/11", "-isystem",
                   "/usr/include/x86_64-linux-gnu/c++/11", "-isystem",
                   "/usr/lib/gcc/x86_64-linux-gnu/11/include", str(source), "-o", str(executable)]
        started = time.monotonic()
        compile_result = subprocess.run(command, capture_output=True, timeout=120)
        (out / (label+".compile.stdout")).write_bytes(compile_result.stdout)
        (out / (label+".compile.stderr")).write_bytes(compile_result.stderr)
        need(compile_result.returncode == 0, "Actual C compilation: "+label)
        run_result = subprocess.run([str(executable)], capture_output=True, timeout=120)
        (out / (label+".bin")).write_bytes(run_result.stdout)
        (out / (label+".stderr")).write_bytes(run_result.stderr)
        need(run_result.returncode == 0 and len(run_result.stdout) == 512 and not run_result.stderr,
             "Complete native output and successful exit: "+label)
        records.append({"label": label, "source": str(source.relative_to(R)),
                        "source_sha256": sha(source), "command": command,
                        "compiler_sha256": sha(compiler), "executable_sha256": sha(executable),
                        "output_sha256": sha(out / (label+".bin")),
                        "elapsed_seconds": time.monotonic()-started})
    need((out / "original.bin").read_bytes() == (out / "adapted.bin").read_bytes(),
         "All 512 observed bytes agree")
    files = [{"path": str(p.relative_to(B)), "sha256": sha(p)}
             for p in sorted((B / "bundle-source").iterdir()) if p.is_file()]
    receipt = {"status": "ACTUAL_NATIVE_ORIGINAL_ADAPTED_512_BYTE_EQUALITY_PASS",
               "programs": records, "adapted_include_tree": files,
               "qualification": "Native observations and C compiler/runtime/hardware association; "
                                "not a Lean proof or standalone source-first verification claim."}
    (out / "RECEIPT.json").write_text(json.dumps(receipt, indent=2)+"\n")
    print(json.dumps({"status": receipt["status"], "bytes": 512}))


if __name__ == "__main__":
    main()
