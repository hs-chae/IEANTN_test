#!/usr/bin/env python3
"""Freeze minimal source/evidence inputs; exclude all application object bytes."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
B = HERE.parent
R = B.parents[1]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load(p):
    def unique(items):
        d = {}
        for k, v in items:
            if k in d:
                raise ValueError("Duplicate JSON key")
            d[k] = v
        return d
    return json.loads(p.read_text(), object_pairs_hook=unique)


def main():
    target = HERE / "MANIFEST.json"
    if target.exists():
        raise ValueError("Frozen fresh manifest only")
    main_index = load(B / "BASIS_PROGRAM_ACCEPTED_CATALOG_V1.json")
    numeric = load(B / "NUMERICS_ALL272_MODEL_ACCEPTANCE_V1.json")
    final = load(B / "final-closed-pipeline-v1/RECEIPT.json")
    if len(main_index["rows"]) != 351 or numeric["module_count"] != 295 or \
            numeric["root_count"] != 1193 or len(final["records"]) != 13 or \
            sum(len(r["roots"]) for r in final["records"]) != 550:
        raise ValueError("Exact distinct evidence populations")
    paths = {}

    def add(path, role):
        path = path.resolve()
        if not path.is_relative_to(R) or not path.is_file() or path.suffix in [".olean", ".ilean", ".o", ".so"]:
            raise ValueError("Source/evidence only, within project: " + str(path))
        key = str(path.relative_to(R))
        paths.setdefault(key, {"path": key, "sha256": sha(path), "roles": []})
        if role not in paths[key]["roles"]:
            paths[key]["roles"].append(role)

    modules = []
    for row in main_index["rows"]:
        source = Path(row["source"])
        if sha(source) != row["source_sha256"]:
            raise ValueError("Frozen current actual source")
        add(source, "actual_completed_source_module")
        imports = re.findall(r"^import\s+(\S+)", source.read_text(), re.M)
        include_files = []
        for rel in re.findall(r'include_str\s+"([^"]+)"', source.read_text()):
            include = (source.parent / rel).resolve()
            add(include, "actual_source_bound_physical_C_include")
            include_files.append(str(include.relative_to(R)))
        receipts = []
        for value in row["accepted_receipts"]:
            receipt = Path(value)
            d = load(receipt)
            if not str(d.get("status", "")).startswith("PASS") or d.get("exit_code") != 0 or \
                    d.get("source_sha256") != row["source_sha256"]:
                raise ValueError("Actual accepted current source receipt")
            add(receipt, "accepted_kernel_receipt_no_object_input")
            receipts.append(str(receipt.relative_to(R)))
        modules.append({"module": row["module"], "source": str(source.relative_to(R)),
                        "source_sha256": row["source_sha256"], "imports": imports,
                        "include_files": include_files, "accepted_receipts": receipts,
                        "historical_object_sha256_evidence_only": row["object_sha256"]})
    for name in ["BASIS_PROGRAM_ACCEPTED_CATALOG_V1.json", "NUMERICS_ALL272_MODEL_ACCEPTANCE_V1.json",
                 "BUNDLE_INPUT_MANIFEST_V1.json", "NATIVE_COMPILER_LOCK_V1.json",
                 "frontend-v1/SOURCE_ADAPTATIONS.json", "frontend-v1/STRUCTURED_AST.json",
                 "family-plan-v1/FAMILY_PLAN.json", "family-plan-v1/FAMILY_API_V1.json",
                 "family-proof-v1/RECEIPT.json", "totals-plan-v1/TOTALS_API_V1.json",
                 "final-closed-pipeline-v1/REQUEST.json", "final-closed-pipeline-v1/RECEIPT.json",
                 "native-portable-v1/RECEIPT.json", "native-portable-v1/original.bin",
                 "native-portable-v1/adapted.bin", "family-input-controls-v1/valid.jsonl"]:
        add(B / name, "minimal_evidence_or_regenerable_proposal")
    script_names = ["prepare_frontend_v2.py", "generate_bundle_v1.py", "prepare_family_v1.py",
                    "prepare_totals_v1.py", "generate_main_edges_v1.py", "generate_main_accum_v1.py",
                    "generate_closed_source_v1.py", "run_stage_v1.py", "run_family_v1.py",
                    "run_closed_pipeline_v1.py", "run_diagnostic_v1.py", "reproduce_native_v1.py",
                    "compile_root_parts_v2.py"]
    for name in script_names:
        add(B / name, "existing_generation_or_reproduction_script")
    for name in ["basis_fp128_tangent_newton2.cpp", "basis_fp128_height_v2.cpp"]:
        add(B / "source/original" / name, "preserved_actual_original_C")
        add(R / "research/analytic/c" / name, "actual_original_source_for_frontend_regeneration")
    for path in [R / "scoped/frontend/generate_ast.py", R / "research/basis-source/generate_bundle.py",
                 R / "research/main-weight-v1/compile_consumer.py",
                 R / "scripts/resource_scope_v3.py", HERE / "reproduce.py", HERE / "prepare_manifest.py",
                 HERE / "README.md"]:
        add(path, "reproduction_tool_source")
    for p in sorted((B / "bundle-source").iterdir()):
        if p.is_file():
            add(p, "actual_native_C_include_tree")
    # Auxiliary proposer is untrusted data generation, never a theorem input bank.
    add(B / "lean/SynergyTangentV2C/FamilyProposal.lean", "untrusted_optional_native_proposer")
    owned = {m["module"] for m in modules}
    frontier = sorted({i for m in modules for i in m["imports"] if i not in owned})
    final_receipt = B / "final-closed-pipeline-v1/RECEIPT.json"
    if sha(final_receipt) != "e3cebfadd8732c557a505762623cba62247ae338cf892fde5d6ed6c9d09c4075":
        raise ValueError("Frozen completed full source composition")
    native = load(B / "native-portable-v1/RECEIPT.json")
    if native["status"] != "ACTUAL_NATIVE_ORIGINAL_ADAPTED_512_BYTE_EQUALITY_PASS":
        raise ValueError("Actual full original/adapted native comparison")
    if (B / "native-portable-v1/original.bin").read_bytes() != (B / "native-portable-v1/adapted.bin").read_bytes() or \
            (B / "native-portable-v1/original.bin").stat().st_size != 512:
        raise ValueError("All512actual observed output bytes")
    result = {"schema": 1, "status": "COMPLETED_BASIS_SOURCE_COMPONENT_REPRODUCTION_INPUTS",
        "parameters": {"shared_cells": 256, "prefix_cells": 16, "fractional_bits": 128,
                       "word_bits": 512, "native_output_bytes": 512, "random_seed": None},
        "mathematical_caps": ["373/200", "1273/2000", "129/250"],
        "module_population": {"main_and_read_local_import_union": 351, "numerics_subset_modules": 295,
            "numerics_subset_unique_roots": 1193, "final_composition_modules": 13,
            "final_composition_unique_roots": 550,
            "qualification": "Overlapping source inventories. Do not add351+295 or printed root populations."},
        "final_composition_receipt_sha256": sha(final_receipt), "modules": modules,
        "external_import_frontier": frontier, "files": [paths[k] for k in sorted(paths)],
        "application_object_files_bundled_or_trusted_by_default": 0,
        "source_cold_whole_replay": {"status": "NOT_EXECUTED_BY_THIS_ADDON_PENDING_REPAIRED_RESEARCH_CAPSULE",
            "required": "Actual coherent source-only research closure or explicitly validated read-only source-built parent, matching these source hashes/compiler context, then all basis and final ANT audits."},
        "trust": ["Lean ordinary declaration kernel/Std3", "Precise pinned compiler/BitInt512/ABI/core-runtime contracts",
                  "C stdio/CRT/OS/hardware contracts; accepted modeled stream bytes are not unconditional host success",
                  "Existing analytic assumptions unchanged; native diagnostics are proposals only"]}
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "modules": len(modules), "files": len(paths),
                      "external_frontier": len(frontier), "manifest_sha256": sha(target)}))


if __name__ == "__main__":
    main()
