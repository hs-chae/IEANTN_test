#!/usr/bin/env python3
"""Check or regenerate actual basis sources/native output; never seed proof objects."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
B = HERE.parent
R = B.parents[1]


def need(ok, text):
    if not ok:
        raise ValueError(text)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load(p):
    def pairs(items):
        d = {}
        for k, v in items:
            need(k not in d, "Duplicate JSON key")
            d[k] = v
        return d
    return json.loads(p.read_text(), object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def verify(manifest):
    need(manifest["status"] == "COMPLETED_BASIS_SOURCE_COMPONENT_REPRODUCTION_INPUTS" and
         manifest["application_object_files_bundled_or_trusted_by_default"] == 0,
         "Exact source-only evidence classification")
    need(manifest["parameters"] == {"shared_cells": 256, "prefix_cells": 16,
         "fractional_bits": 128, "word_bits": 512, "native_output_bytes": 512, "random_seed": None},
         "Original fixed mathematical parameters")
    paths = []
    for row in manifest["files"]:
        p = R / row["path"]
        need(p.resolve().is_relative_to(R) and not p.is_symlink() and p.is_file(), "Exact owned input")
        need(p.suffix not in [".olean", ".ilean", ".o", ".so"], "No trusted application objects")
        need(sha(p) == row["sha256"], "Exact source/evidence hash: " + row["path"])
        paths.append(row["path"])
    need(len(paths) == len(set(paths)) and len(manifest["modules"]) == 351,
         "Unique complete source population")
    return {"files": len(paths), "local_source_modules": 351, "trusted_application_object_inputs": 0}


def materialize(manifest, project):
    for row in manifest["files"]:
        source = R / row["path"]
        target = project / row["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        need(sha(target) == row["sha256"], "Materialized exact bytes")
    target = project / HERE.relative_to(R) / "MANIFEST.json"
    shutil.copyfile(HERE / "MANIFEST.json", target)


def run_logged(command, out, label, cwd):
    with (out / (label + ".stdout")).open("xb") as so, (out / (label + ".stderr")).open("xb") as se:
        result = subprocess.run(command, cwd=cwd, stdout=so, stderr=se, timeout=180)
    need(result.returncode == 0, "Actual " + label + " failed; outputs retained")
    return {"label": label, "command": command, "exit_code": result.returncode,
            "stdout_sha256": sha(out / (label + ".stdout")),
            "stderr_sha256": sha(out / (label + ".stderr"))}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=["verify", "materialize", "regenerate", "native"])
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--compiler", type=Path)
    a = p.parse_args()
    manifest_path = HERE / "MANIFEST.json"
    manifest = load(manifest_path)
    checked = verify(manifest)
    out = a.out.resolve()
    need(out.is_relative_to(HERE) and not out.exists(), "Fresh add-on-owned output required")
    out.mkdir(parents=True)
    records = []
    if a.mode != "verify":
        project = out / "source-project"
        project.mkdir()
        materialize(manifest, project)
        local_b = project / B.relative_to(R)
        if a.mode in ["regenerate", "native"]:
            need(a.compiler is not None and a.compiler.is_file(), "Explicit pinned compiler path required")
            compiler = a.compiler.resolve()
            lock = load(B / "NATIVE_COMPILER_LOCK_V1.json")
            need(sha(compiler) == lock["compiler_sha256"], "Exact actual native compiler bytes")
        if a.mode == "regenerate":
            # Only this newly created owned copy is changed, never accepted sources.
            for name in ["Header.lean", "Generated.lean", "Bundle.lean", "CellTotalsData.lean"]:
                (local_b / "lean/SynergyTangentV2C" / name).unlink()
            for rel in ["frontend-v1", "bundle-source", "lean/SynergyTangentV2C/SourceCells",
                        "family-plan-v1", "totals-plan-v1"]:
                target = local_b / rel
                need(target.resolve().is_relative_to(project), "Regeneration cleanup inside fresh copy")
                if target.exists():
                    shutil.rmtree(target)
            environment = project / "scoped/build/DEVELOPMENT_ENVIRONMENT.json"
            environment.parent.mkdir(parents=True, exist_ok=True)
            environment.write_text(json.dumps({"compiler": str(compiler.with_name("lean"))}) + "\n")
            commands = [
                ("frontend", [sys.executable, "-I", "-B", str(local_b / "prepare_frontend_v2.py")]),
                ("family", [sys.executable, "-I", "-B", str(local_b / "prepare_family_v1.py"),
                    "--proposal", str(local_b / "family-input-controls-v1/valid.jsonl"),
                    "--out", str(local_b / "family-plan-v1")]),
                ("totals", [sys.executable, "-I", "-B", str(local_b / "prepare_totals_v1.py")]),
                ("main-edges", [sys.executable, "-I", "-B", str(local_b / "generate_main_edges_v1.py"),
                    "--out", str(local_b / "regenerated-main-edges")]),
                ("main-accum", [sys.executable, "-I", "-B", str(local_b / "generate_main_accum_v1.py"),
                    "--out", str(local_b / "regenerated-main-accum")]),
                ("main-closed", [sys.executable, "-I", "-B", str(local_b / "generate_closed_source_v1.py"),
                    "--out", str(local_b / "regenerated-main-closed")])]
            for label, command in commands:
                records.append(run_logged(command, out, label, project))
                if label == "family":
                    # This is a pinned API index of the same untrusted proposal
                    # values, not an extra computation or proof certificate.
                    shutil.copyfile(B / "family-plan-v1/FAMILY_API_V1.json",
                                    local_b / "family-plan-v1/FAMILY_API_V1.json")
            for row in manifest["modules"]:
                need(sha(project / row["source"]) == row["source_sha256"],
                     "Every regenerated source matches accepted bytes: " + row["module"])
            for row in manifest["files"]:
                if "actual_native_C_include_tree" in row["roles"]:
                    need(sha(project / row["path"]) == row["sha256"], "Regenerated actual C bytes")
        if a.mode == "native":
            records.append(run_logged([sys.executable, "-I", "-B", str(local_b / "reproduce_native_v1.py"),
                "--compiler", str(compiler), "--out", str(local_b / "native-reproduced")], out, "native", project))
            native = load(local_b / "native-reproduced/RECEIPT.json")
            need(native["status"] == "ACTUAL_NATIVE_ORIGINAL_ADAPTED_512_BYTE_EQUALITY_PASS",
                 "Actual full512byte original/adapted native replay")
    receipt = {"status": "BASIS_ADDON_" + a.mode.upper() + "_PASS_NOT_NEW_KERNEL_ACCEPTANCE",
        "manifest_sha256": sha(manifest_path), "script_sha256": sha(Path(__file__)),
        "source_inputs": checked, "records": records,
        "whole_clean_source_proof_execution": False,
        "qualification": "No application object input. This checks/materializes/regenerates exact source or actual native512-byte observations only. Whole source-only kernel replay and final ANT repair require the separately validated coherent research capsule or explicitly source-validated read-only parent. Untrusted proposals are not proof."}
    (out / "RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(receipt["status"])


if __name__ == "__main__":
    main()
