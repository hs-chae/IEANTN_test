#!/usr/bin/env python3
"""Untrusted literal cumulative proposals; kernel sum/fold proofs are separate."""
from pathlib import Path
import hashlib
import json

B = Path(__file__).resolve().parent
R = B.parents[1]
api_path = B / "family-plan-v1/FAMILY_API_V1.json"
api = json.loads(api_path.read_text())
rows = api["rows"]
if [(r["kind"], r["index"]) for r in rows] != \
        [("prefix", i) for i in range(16)]+[("shared", i) for i in range(256)]:
    raise ValueError("Exact fixed cell universe")


def append_total(previous, cell, prefix_only):
    result = [previous[k]+(cell[k] if k < 2 or not prefix_only else 0) for k in range(6)]
    if any(not 0 <= w < 2**512 for w in result):
        raise ValueError("Proposed cumulative word bounds")
    return result


pre = [[0]*6]
for row in rows[:16]:
    pre.append(append_total(pre[-1], list(map(int, row["words"])), True))
only = [[0]*6]
mixed = [pre[-1]]
for row in rows[16:]:
    words = list(map(int, row["words"]))
    only.append(append_total(only[-1], words, False))
    mixed.append(append_total(mixed[-1], words, False))


def literal(words):
    return "(⟨"+str(words[0])+","+str(words[1])+"⟩,⟨"+str(words[2])+","+str(words[3])+\
        "⟩,⟨"+str(words[4])+","+str(words[5])+"⟩)"


source = B / "lean/SynergyTangentV2C/CellTotalsData.lean"
if source.exists():
    raise ValueError("Fresh source proposals")
text = '''/- Literal proposals for the exact C-loop accumulators. Accepted identities
and successful source loop execution are separate mandatory proof layers. -/
import SynergyTangentV2C.MainFrames
namespace SynergyTangentV2C.CellTotalsData
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev Totals := MainFrames.Totals
def zero : Totals := (⟨0,0⟩,⟨0,0⟩,⟨0,0⟩)
'''
for name, table in [("prefixTable", pre), ("sharedOnlyTable", only), ("sharedTable", mixed)]:
    text += "def "+name+" : List Totals := [\n"+",\n".join(literal(row) for row in table)+"]\n"
text += '''def prefixTotals (index : Nat) : Totals := (prefixTable[index]?).getD zero
def sharedOnlyTotals (index : Nat) : Totals := (sharedOnlyTable[index]?).getD zero
def sharedTotals (index : Nat) : Totals := (sharedTable[index]?).getD zero
theorem prefix_length : prefixTable.length=17 := by rfl
theorem shared_only_length : sharedOnlyTable.length=257 := by rfl
theorem shared_length : sharedTable.length=257 := by rfl
theorem prefix_zero : prefixTotals 0=zero := by rfl
theorem shared_only_zero : sharedOnlyTotals 0=zero := by rfl
theorem shared_initial : sharedTotals 0=prefixTotals 16 := by rfl
#print axioms prefix_length
#print axioms shared_only_length
#print axioms shared_length
#print axioms prefix_zero
#print axioms shared_only_zero
#print axioms shared_initial
end SynergyTangentV2C.CellTotalsData
'''
source.write_text(text)
out = B / "totals-plan-v1"
if out.exists():
    raise ValueError("Fresh owned data plan")
out.mkdir()
record = {"status": "UNTRUSTED_CUMULATIVE_PROPOSALS_PENDING_KERNEL_SUM_AND_MODEL_PROOFS",
          "source_api_sha256": hashlib.sha256(api_path.read_bytes()).hexdigest(),
          "source": str(source.relative_to(R)),
          "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
          "prefix": [[str(w) for w in row] for row in pre],
          "shared_only": [[str(w) for w in row] for row in only],
          "shared_with_prefix": [[str(w) for w in row] for row in mixed],
          "api": "CellTotalsData.{prefixTotals,sharedOnlyTotals,sharedTotals}:Nat->MainFrames.Totals",
          "qualification": "Data and size/zero facts are not successful source loop execution or verified cumulative sums."}
(out / "TOTALS_API_V1.json").write_text(json.dumps(record, indent=2)+"\n")
print(json.dumps({"status": record["status"], "prefix_states": 17, "shared_states": 257}))
