# Copyright (c) 2026 IEANTN contributors. Apache-2.0.
# Untrusted preparation; actual includes and every syntax equality are checked.
from pathlib import Path
import json,hashlib,importlib.util,shutil
B=Path(__file__).resolve().parent;R=B.parents[1];spec=importlib.util.spec_from_file_location('renderer',R/'scoped/frontend/generate_ast.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);D=B/'bundle-source';g.need(not D.exists(),'fresh bundle required');D.mkdir();ast=json.loads((B/'frontend-v1/STRUCTURED_AST.json').read_text());lean=['/-\nCopyright (c) 2026 IEANTN contributors. All rights reserved.\nReleased under Apache 2.0 license as described in the file LICENSE.\nAuthors: OpenAI (Codex)\n-/','import ScopedC.SourceBundle.Tree','import SynergyTangentV2C.Header','import SynergyTangentV2C.Generated','namespace SynergyTangentV2C.Bundle','open ScopedC.Syntax ScopedC.SourceBundle','set_option maxHeartbeats 0','set_option maxRecDepth 100000', '''inductive Piece where
  | prelude
  | typeDecl (d : Header.TypeDecl)
  | global (d : Decl)
  | function (f : Function)
inductive Piece.Bound : Piece → File → Prop where
  | prelude {file} (h : file.text = Header.externalPrelude) : Bound .prelude file
  | typeDecl {d file} (h : file.text = Header.renderType d) : Bound (.typeDecl d) file
  | global {d file} (h : (do pure ("static "++(←renderDecl d)++";\\n")) = some file.text) : Bound (.global d) file
  | function {f file} (h : renderFunction f = some file.text) : Bound (.function f) file
'''];nodes=[];leafindex=0

def leaf(name,text,value,proof):
 global leafindex
 i=leafindex;leafindex+=1;(D/name).write_text(text);lean.append(f'def file{i} : File := ⟨{g.quote(name)},include_str "../../bundle-source/{name}"⟩');lean.append(f'def piece{i} : Piece := {value}');lean.append(f'theorem bound{i} : Piece.Bound piece{i} file{i} := {proof}');lean.append(f'def tree{i} : ScopedC.SourceBundle.Tree Piece := .leaf file{i} piece{i}');lean.append(f'theorem tree_bound{i} : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree{i} := .leaf bound{i}');nodes.append((f'tree{i}',f'tree_bound{i}',name))
leaf('prelude.inc','#include <stdint.h>\n#include <stdio.h>\n#include <stdlib.h>\n','.prelude','.prelude (by rfl)')
leaf('type_U.inc','typedef unsigned _BitInt(512) U;\n','.typeDecl (.unsignedAlias "U" 512)','.typeDecl (by rfl)')
leaf('type_I.inc','struct I{U lo;U hi;};\n','.typeDecl (.record "I" [("U","lo"),("U","hi")])','.typeDecl (by rfl)')
globals=[dict(type='const U',name='S',value=['binary','<<',['cast','U',['nat',1]],['nat',128]],arrayExtent=None),dict(type='const U',name='MAXU',value=['cast','U',['unary','-',['nat',1]]],arrayExtent=None),dict(type='I',name='ln2',value=None,arrayExtent=None)]
for i,d in enumerate(globals):leaf('global_'+d['name']+'.inc','static '+g.cd(d)+';\n','.global '+g.ld(d),'.global (by decide +kernel)')
for f in ast:
 name=f['name'];text=(B/'frontend-v1'/(name+'.cpp.inc')).read_text();leaf('function_'+name+'.inc',text,'.function Generated.f_'+name,'.function (by simpa only [file'+str(leafindex)+'] using Generated.render_'+name+')')
count=0

def join(xs):
 global count
 if len(xs)==1:return xs[0]
 a=join(xs[:len(xs)//2]);b=join(xs[len(xs)//2:]);i=count;count+=1;name=f'join_{i:03}.inc';(D/name).write_text(f'#include "{a[2]}"\n#include "{b[2]}"\n');lean.append(f'def join_file{i} : File := ⟨{g.quote(name)},include_str "../../bundle-source/{name}"⟩');lean.append(f'def join_tree{i} : ScopedC.SourceBundle.Tree Piece := .pair join_file{i} {a[0]} {b[0]}');lean.append(f'theorem join_bound{i} : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree{i} := .pair {a[1]} {b[1]} (by decide +kernel)');return f'join_tree{i}',f'join_bound{i}',name
root=join(nodes);(D/'basis_bundle.cpp').write_text(f'#include "{root[2]}"\n');lean+=['def tree : ScopedC.SourceBundle.Tree Piece := '+root[0],'theorem bound : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree := '+root[1],'''def code : List Function := tree.values.flatMap (fun p => match p with | .function f => [f] | _ => [])
theorem code_exact : code = Generated.functions := by rfl
def actualFiles : List File := tree.files ++ [⟨"basis_bundle.cpp",include_str "../../bundle-source/basis_bundle.cpp"⟩]
#print axioms bound
#print axioms code_exact
end SynergyTangentV2C.Bundle'''];(B/'lean/SynergyTangentV2C/Bundle.lean').write_text('\n'.join(lean)+'\n');manifest=[dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sorted(D.iterdir())];(B/'BUNDLE_INPUT_MANIFEST_V1.json').write_text(json.dumps(dict(files=manifest,source_binding='PENDING_KERNEL_COMPILE',full_sourcePV=False),indent=2)+'\n');print('Prepared',len(manifest),'physical files and19functions; kernel checks still pending.')
