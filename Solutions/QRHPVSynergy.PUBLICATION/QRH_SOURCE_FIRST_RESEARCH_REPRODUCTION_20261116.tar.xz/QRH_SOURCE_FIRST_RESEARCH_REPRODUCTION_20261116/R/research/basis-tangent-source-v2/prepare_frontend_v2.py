#!/usr/bin/env python3
"""Untrusted AST preparation. Kernel renderers bind the actual compiled include bundle."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import subprocess
import copy

B = Path(__file__).resolve().parent
R = B.parent.parent
NAMES = ["fail", "addU", "mulU", "ceilDiv", "rat", "unit", "zero", "add", "mul", "divI",
         "divN", "positiveSub", "expNeg", "atanh2", "logPos", "floorCube", "cubeRoot",
         "gaussianCell", "archived_basis_main", "powerI", "exponentialMoment", "tangentCell",
         "emitU", "main"]


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def adapt(functions):
    """Three disclosed C implementation changes; no numerical-output input."""
    changes = []

    def lower(statement, function, path):
        if not isinstance(statement, list) or not statement:
            return statement
        if statement[0] == "sequence":
            result = []
            for index, child in enumerate(statement[1]):
                here = path + [index]
                if child[0] == "declare":
                    eligible = [d for d in child[1] if d["type"] == "I" and
                                d["arrayExtent"] is not None and d["value"] is not None]
                    if eligible:
                        need(len(child[1]) == 1 and len(eligible) == 1,
                             "Only isolated I-array declarations are lowered")
                        declaration = eligible[0]
                        value = declaration["value"]
                        need(value[0] == "record" and
                             len(value[1]) == declaration["arrayExtent"],
                             "Every I-array element is explicit")
                        uninitialized = copy.deepcopy(declaration)
                        uninitialized["value"] = None
                        result.append(["declare", [uninitialized]])
                        for slot, expression in enumerate(value[1]):
                            result.append(["eval", ["binary", "=",
                                          ["index", ["var", declaration["name"]],
                                           ["nat", slot]], expression]])
                        changes.append(dict(kind="I_ARRAY_ORDERED_STORES", function=function,
                                            path=here, name=declaration["name"],
                                            count=len(value[1])))
                        continue
                result.append(lower(child, function, here))
            return ["sequence", result]
        return [statement[0], *[lower(v, function, path) if isinstance(v, list) else v
                                 for v in statement[1:]]]

    def rename(value):
        if isinstance(value, dict):
            return {k: ({"limbs": "words", "k": "i"}.get(v, v) if k == "name"
                        else rename(v)) for k, v in value.items()}
        if isinstance(value, list):
            if len(value) == 2 and value[0] == "var":
                return ["var", {"limbs": "words", "k": "i"}.get(value[1], value[1])]
            return [rename(v) for v in value]
        return value

    def casts(value):
        if isinstance(value, list):
            if len(value) == 3 and value[:2] == ["call", ["var", "emitU"]] and \
                    len(value[2]) == 1 and value[2][0] in [["var", "cells"], ["var", "prefix"]]:
                changes.append(dict(kind="EXPLICIT_U_ARGUMENT_CAST", function="main",
                                    name=value[2][0][1]))
                return ["call", ["var", "emitU"], [["cast", "U", value[2][0]]]]
            return [casts(v) for v in value]
        if isinstance(value, dict):
            return {k: casts(v) for k, v in value.items()}
        return value

    result = copy.deepcopy(functions)
    for function in result:
        function["body"] = lower(function["body"], function["name"], [])
        if function["name"] == "emitU":
            function["body"] = rename(function["body"])
            changes.append(dict(kind="LOCAL_ALPHA_RENAME", function="emitU",
                                mapping={"limbs": "words", "k": "i"}))
        if function["name"] == "main":
            function["body"] = casts(function["body"])
    need(sum(c["kind"] == "I_ARRAY_ORDERED_STORES" for c in changes) == 4,
         "Exactly four initialized I arrays")
    need(sum(c["kind"] == "EXPLICIT_U_ARGUMENT_CAST" for c in changes) == 2,
         "Exactly two source ABI casts")
    return result, changes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", default="frontend-v1")
    args = parser.parse_args()
    need(Path(args.attempt).name == args.attempt, "Owned frontend attempt name")
    out = B / args.attempt
    need(not out.exists(), "Fresh frontend")
    out.mkdir(parents=True)
    original = B / "source/original"
    original.mkdir(parents=True, exist_ok=True)
    pins = []
    for name in ["basis_fp128_tangent_newton2.cpp", "basis_fp128_height_v2.cpp"]:
        source = R / "research/analytic/c" / name
        target = original / name
        if target.exists():
            need(target.read_bytes() == source.read_bytes(), "Exact preserved original source copy")
        else:
            target.write_bytes(source.read_bytes())
        pins.append({"source": str(source.relative_to(R)), "sha256": sha(source),
                     "copy": str(target.relative_to(R))})
    spec = importlib.util.spec_from_file_location("actual_scoped_renderer",
                                                R / "scoped/frontend/generate_ast.py")
    g = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g)
    environment = json.loads((R / "scoped/build/DEVELOPMENT_ENVIRONMENT.json").read_text())
    clang = Path(environment["compiler"]).parent / "clang"
    command = [str(clang), "-std=c++17", "-DBASIS_TANGENT_CELLS=256", "-isystem",
               "/usr/include/c++/11", "-isystem", "/usr/include/x86_64-linux-gnu/c++/11",
               "-isystem", "/usr/lib/gcc/x86_64-linux-gnu/11/include", "-Xclang",
               "-ast-dump=json", "-fsyntax-only", str(original / "basis_fp128_tangent_newton2.cpp")]
    with (out / "clang.json").open("w") as stdout, (out / "clang.stderr").open("w") as stderr:
        process = subprocess.run(command, stdout=stdout, stderr=stderr)
    need(process.returncode == 0, "Actual original source accepted by pinned Clang")
    tree = json.loads((out / "clang.json").read_text())
    functions = {}
    for node in tree["inner"]:
        name = node.get("name")
        bodies = [child for child in node.get("inner", []) if child.get("kind") == "CompoundStmt"]
        if node.get("kind") != "FunctionDecl" or name not in NAMES or not bodies:
            continue
        need(name not in functions, "Unique owned function definition")
        params = [(g.typ(child["type"]["qualType"]), child["name"])
                  for child in node.get("inner", []) if child.get("kind") == "ParmVarDecl"]
        result = g.typ(node["type"]["qualType"].split("(", 1)[0].strip())
        result = ("static " if node.get("storageClass") == "static" else "") + result
        functions[name] = {"name": name, "returnType": result, "parameters": params,
                           "body": g.stmt(bodies[0])}
    need(set(functions) == set(NAMES), "All24 owned source definitions")
    original_ordered = [functions[name] for name in NAMES]
    ordered, changes = adapt(original_ordered)
    (out / "ORIGINAL_STRUCTURED_AST.json").write_text(json.dumps(original_ordered, indent=2) + "\n")
    (out / "SOURCE_ADAPTATIONS.json").write_text(json.dumps(changes, indent=2) + "\n")
    (out / "STRUCTURED_AST.json").write_text(json.dumps(ordered, indent=2) + "\n")
    lean_root = B / "lean/SynergyTangentV2C"
    lean_root.mkdir(parents=True, exist_ok=True)
    need(not (lean_root / "Header.lean").exists() and not (lean_root / "Generated.lean").exists(),
         "Do not overwrite owned or parallel Lean source")
    header = ('import SynergyC.Header\nnamespace SynergyTangentV2C\n'
              'abbrev layout := SynergyC.Header.layout\nnamespace Header\n'
              'abbrev TypeDecl := SynergyC.Header.TypeDecl\n'
              'abbrev types := SynergyC.Header.types\n'
              'abbrev globals := SynergyC.Header.globals\n'
              'abbrev renderType := SynergyC.Header.renderType\n'
              'abbrev externalPrelude := SynergyC.Header.externalPrelude\n'
              'abbrev layout := SynergyC.Header.layout\nend Header\n'
              'theorem layout_eq : layout = SynergyC.Header.layout := rfl\n'
              '#print axioms layout_eq\nend SynergyTangentV2C\n')
    (lean_root / "Header.lean").write_text(header)
    lean = ["import ScopedC.Grammar", "namespace SynergyTangentV2C.Generated", "open ScopedC.Syntax",
            "set_option maxHeartbeats 0", "set_option maxRecDepth 200000"]
    for function in ordered:
        name = function["name"]
        params = "[" + ",".join("(" + g.quote(t) + "," + g.quote(n) + ")"
                                  for t, n in function["parameters"]) + "]"
        lean.append("def f_" + name + " : Function := {returnType:=" +
                    g.quote(function["returnType"]) + ",name:=" + g.quote(name) +
                    ",parameters:=" + params + ",body:=" + g.ls(function["body"]) + "}")
        text = (function["returnType"] + " " + name + "(" +
                ",".join(t + " " + n for t, n in function["parameters"]) + ")" +
                g.cs(function["body"]) + "\n")
        (out / (name + ".cpp.inc")).write_text(text)
        lean.append("theorem render_" + name + " : renderFunction f_" + name + " = some " +
                    g.quote(text) + " := by decide +kernel")
        lean.append("#print axioms render_" + name)
    lean.append("def functions : List Function := [" +
                ",".join("f_" + name for name in NAMES) + "]")
    lean.append("end SynergyTangentV2C.Generated")
    (lean_root / "Generated.lean").write_text("\n".join(lean) + "\n")
    # The formal include tree is the actual new executable counterpart. The
    # original macro/include source remains byte-exact; no arithmetic is changed.
    old = (R / "research/basis-source/generate_bundle.py").read_text()
    old = old.replace("B=Path(__file__).resolve().parent;R=B.parents[1]", "B=Path(__file__).resolve().parent;R=B.parents[1]")
    old = old.replace("SynergyC", "SynergyTangentV2C").replace("frontend-v1", out.name)
    old = old.replace("physical files and19functions", "physical files and24functions")
    generator = B / "generate_bundle_v1.py"
    generator.write_text(old)
    subprocess.run(["python3", "-B", str(generator)], check=True, cwd=R)
    receipt = {"status": "PREPARED_ACTUAL_EXECUTABLE_SOURCE_AST_NOT_YET_KERNEL_VERIFIED",
               "original_sources": pins, "clang_command": command, "clang_sha256": sha(clang),
               "owned_functions": NAMES, "source_adaptations": changes,
               "cells": 256, "prefix": 16,
               "fractional_bits": 128, "word_bits": 512,
               "generated_source_sha256": sha(lean_root / "Generated.lean"),
               "bundle_source_sha256": sha(lean_root / "Bundle.lean"),
               "qualification": "Actual executable include-tree counterpart, same24owned bodies "
                                "after fixed macro specialization, ordinary type spelling, formatting, "
                                "four I-array initializers lowered to same-block ordered stores, "
                                "emitter-local alpha renaming, and two explicit U parameter casts. "
                                "Arithmetic order and numerical inputs are unchanged. AST extraction "
                                "is untrusted. Every renderer/whole "
                                "source-tree binding, actual C build/run association and application "
                                "execution/math proof remain required. No computed outputs embedded."}
    (out / "PREPARATION.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": receipt["status"], "functions": len(NAMES)}))


if __name__ == "__main__":
    main()
