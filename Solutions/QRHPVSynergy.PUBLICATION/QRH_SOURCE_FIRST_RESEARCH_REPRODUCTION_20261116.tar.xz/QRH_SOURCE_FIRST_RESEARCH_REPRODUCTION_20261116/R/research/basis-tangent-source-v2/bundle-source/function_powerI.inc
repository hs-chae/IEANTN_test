static I powerI(I x,unsigned int n){I y=unit();
unsigned int i=0;
while((i<n)){(y=mul(y,x));
(i=(i+1));}
return y;}
