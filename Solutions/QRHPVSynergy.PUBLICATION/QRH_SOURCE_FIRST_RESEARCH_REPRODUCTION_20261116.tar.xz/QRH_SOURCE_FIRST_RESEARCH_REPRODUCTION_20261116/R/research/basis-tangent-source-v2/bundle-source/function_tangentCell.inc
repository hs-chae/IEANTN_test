static void tangentCell(I left,I width,I* zeroBound,I* oneBound,I* twoBound,unsigned int logs){I q=rat(601,2500);
I a=divN(add(left,rat(2,1)),3);
unsigned int refinement=0;
while((refinement<2)){(a=divN(add(mul(rat(2,1),a),divI(left,mul(a,a))),3));
(refinement=(refinement+1));}
I A=divN(mul(rat(5,1),a),6);
I B=divI(unit(),mul(rat(6,1),powerI(a,5)));
I coefficients[5];
((coefficients[0])=add(A,mul(B,mul(left,left))));
((coefficients[1])=mul(rat(2,1),mul(B,left)));
((coefficients[2])=B);
((coefficients[3])=zero());
((coefficients[4])=zero());
I moments[5];
I lambda=mul(rat(2,1),mul(q,left));
unsigned int k=0;
while((k<5)){((moments[k])=exponentialMoment(lambda,width,k));
(k=(k+1));}
I gaussian=expNeg(mul(q,mul(left,left)));
I logLeft=(logs?logPos(left):zero());
I invLeft=divI(unit(),left);
unsigned int j=0;
while((j<=logs)){I total=zero();
(k=0);
while((k<5)){(total=add(total,mul((coefficients[k]),(moments[k]))));
(k=(k+1));}
I bound=mul(gaussian,total);
if((j==0))((*zeroBound)=bound);else if((j==1))((*oneBound)=bound);else ((*twoBound)=bound);
I next[5];
((next[0])=zero());
((next[1])=zero());
((next[2])=zero());
((next[3])=zero());
((next[4])=zero());
(k=0);
while((k<5)){((next[k])=add((next[k]),mul((coefficients[k]),logLeft)));
if((k<4))((next[(k+1)])=add((next[(k+1)]),mul((coefficients[k]),invLeft)));else ;
(k=(k+1));}
(k=0);
while((k<5)){((coefficients[k])=(next[k]));
(k=(k+1));}
(j=(j+1));}}
