int main(){(ln2=atanh2(rat(1,3)));
const unsigned int cells=256;
if(((cells<16)||(cells>65536)))fail();else ;
const unsigned int prefix=(cells/16);
I J[3];
((J[0])=zero());
((J[1])=zero());
((J[2])=zero());
unsigned int i=0;
while((i<prefix)){I l=rat(((5*prefix)+i),(6*prefix));
I b0=zero();
I b1=zero();
I b2=zero();
tangentCell(l,rat(1,(6*prefix)),(&b0),(&b1),(&b2),0);
((J[0])=add((J[0]),b0));
(i=(i+1));}
(i=0);
while((i<cells)){I l=rat((cells+(15*i)),cells);
I b0=zero();
I b1=zero();
I b2=zero();
tangentCell(l,rat(15,cells),(&b0),(&b1),(&b2),2);
((J[0])=add((J[0]),b0));
((J[1])=add((J[1]),b1));
((J[2])=add((J[2]),b2));
(i=(i+1));}
I q=rat(601,2500);
I M=expNeg(divN(add(unit(),logPos(mul(rat(6,1),q))),6));
I bq=mul(rat(256,1),q);
I tail=divI(mul(expNeg(bq),add(bq,unit())),mul(rat(2,1),mul(q,q)));
((J[0])=add(add((J[0]),mul(rat(5,6),M)),tail));
((J[1])=add((J[1]),tail));
((J[2])=add((J[2]),tail));
emitU(((U)cells));
emitU(((U)prefix));
(i=0);
while((i<3)){emitU(((J[i]).lo));
emitU(((J[i]).hi));
(i=(i+1));}
return (ferror(stdout)?2:0);}
