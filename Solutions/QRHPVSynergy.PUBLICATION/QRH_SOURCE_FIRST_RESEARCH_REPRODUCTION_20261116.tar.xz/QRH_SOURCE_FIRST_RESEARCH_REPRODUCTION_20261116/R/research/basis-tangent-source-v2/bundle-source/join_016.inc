#include "function_expNeg.inc"
#include "function_atanh2.inc"
