static I exponentialMoment(I lambda,I width,unsigned int j){if((j>4))fail();else ;
I z=mul(lambda,width);
I term=unit();
I sum=unit();
unsigned int k=1;
while((k<=j)){(term=divN(mul(term,z),k));
(sum=add(sum,term));
(k=(k+1));}
I residue=positiveSub(unit(),mul(expNeg(z),sum));
unsigned int factorial=1;
(k=1);
while((k<=j)){(factorial=(factorial*k));
(k=(k+1));}
return divI(mul(rat(factorial,1),residue),powerI(lambda,(j+1)));}
