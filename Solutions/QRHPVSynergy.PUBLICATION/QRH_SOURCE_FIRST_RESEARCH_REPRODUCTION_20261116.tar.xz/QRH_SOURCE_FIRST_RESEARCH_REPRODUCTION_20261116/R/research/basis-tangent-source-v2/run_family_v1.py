#!/usr/bin/env python3
"""All272 actual C cells, fixed source pins and bounded independent children."""
from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import time

B = Path(__file__).resolve().parent
R = B.parents[1]
STANDARD = {"propext", "Classical.choice", "Quot.sound"}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic(path, value):
    temporary = path.with_name(path.name+".tmp")
    temporary.write_text(json.dumps(value, indent=2)+"\n")
    os.replace(temporary, path)


def verify(row, out):
    source = R / row["source"]
    need(sha(source) == row["source_sha256"], "Frozen current source "+row["module"])
    path = out / row["module"].rsplit(".", 1)[-1] / "RECEIPT.json"
    receipt = json.loads(path.read_text())
    need(receipt["status"] == "PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES" and
         receipt["exit_code"] == 0 and receipt["source_unchanged"] is True and
         receipt["source_sha256"] == row["source_sha256"], "Complete accepted source receipt")
    need(set(receipt["audits"]) == set(row["roots"]) and
         all(isinstance(v, list) and set(v) <= STANDARD for v in receipt["audits"].values()),
         "All three exact standard-axiom roots")
    obj = B / "objects" / Path(row["module"].replace(".", "/")).with_suffix(".olean")
    need(obj.is_file() and sha(obj) == receipt["object_sha256"], "Published matching object")
    return {"module": row["module"], "source_sha256": row["source_sha256"],
            "receipt": str(path.relative_to(R)), "receipt_sha256": sha(path),
            "object_sha256": sha(obj), "seconds": receipt["seconds"],
            "roots": receipt["audits"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=3)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    rows = plan["modules"]
    need(args.jobs in [1, 2, 3] and len(rows) == 272 and plan["root_count"] == 816,
         "Measured bounded concurrency and complete fixed population")
    need([(r["kind"], r["index"]) for r in rows] ==
         [("prefix", i) for i in range(16)]+[("shared", i) for i in range(256)],
         "Original16+256 index universe")
    need(len({r["module"] for r in rows}) == 272, "Unique actual source modules")
    for path, digest in plan["source_pins"].items():
        need(sha(R / path) == digest, "Current pinned source helper")
    out = args.out.resolve()
    need(out.is_relative_to(B) and not out.exists(), "Fresh experiment-owned family output")
    out.mkdir(parents=True)
    accepted, failed = [], []
    started = time.monotonic()
    atomic(out / "REQUEST.json", {"plan_sha256": sha(args.plan), "jobs": args.jobs,
                                  "script_sha256": sha(Path(__file__)), "modules": 272,
                                  "roots": 816, "mathematical_parameters": plan["parameters"]})

    def compile_one(row):
        source = R / row["source"]
        need(sha(source) == row["source_sha256"], "Frozen leaf source")
        destination = out / row["module"].rsplit(".", 1)[-1]
        command = ["python3", "-B", str(R / "research/main-weight-v1/compile_consumer.py"),
                   "--module", row["module"], "--bank", str(B / "objects"),
                   "--source-root", str(B / "lean"), "--out", str(destination), "--publish-object"]
        for root in row["roots"]:
            command.extend(["--root", root])
        log = out / (row["module"].rsplit(".", 1)[-1]+".driver.log")
        with log.open("xb") as stream:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=660)
        if result.returncode:
            return {"module": row["module"], "exit_code": result.returncode,
                    "log": str(log.relative_to(R))}, None
        return None, verify(row, out)

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        pending = {pool.submit(compile_one, row): row for row in rows}
        for future in concurrent.futures.as_completed(pending):
            row = pending[future]
            try:
                failure, success = future.result()
            except Exception as error:
                failure, success = {"module": row["module"], "failure": str(error)}, None
            if success is not None:
                accepted.append(success)
            if failure is not None:
                failed.append(failure)
            atomic(out / "LIVE_FAMILY.json", {"accepted": accepted, "failed": failed,
                   "pending": 272-len(accepted)-len(failed), "seconds": time.monotonic()-started})
            print(json.dumps({"accepted": len(accepted), "failed": len(failed),
                              "module": row["module"]}), flush=True)
    need(not failed and len(accepted) == 272, "Every fixed cell must complete; partial evidence retained")
    for row in rows:
        verify(row, out)
    for path, digest in plan["source_pins"].items():
        need(sha(R / path) == digest, "Final source helper pin")
    atomic(out / "RECEIPT.json", {"status": "ALL272_MODEL_AND_ACTUAL_C_SOURCE_KERNEL_PROOFS_PASS",
        "plan_sha256": sha(args.plan), "module_count": 272, "root_count": 816,
        "seconds": time.monotonic()-started, "jobs": args.jobs, "records": accepted,
        "qualification": "Host development replay, not a source-cold/isolated proof run. Full main/read/caps composition remains separate."})


if __name__ == "__main__":
    main()
