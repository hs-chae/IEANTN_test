#!/usr/bin/env python3
"""Bounded host development stage; exact roots use the existing strict builder."""
from pathlib import Path
import argparse
import json
import re
import subprocess
import hashlib

B = Path(__file__).resolve().parent
R = B.parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True)
    parser.add_argument("modules", nargs="+")
    args = parser.parse_args()
    receipts = []
    for module in args.modules:
        source = B / "lean" / Path(module.replace(".", "/")).with_suffix(".lean")
        text = source.read_text()
        namespace = re.search(r"^namespace ([A-Za-z0-9_.]+)$", text, re.M)
        if namespace is None:
            raise ValueError("Explicit source namespace required")
        roots = [name if name.startswith(namespace[1]+".") else namespace[1]+"."+name
                 for name in re.findall(r"^#print axioms ([A-Za-z0-9_.]+)$", text, re.M)]
        if not roots or len(set(roots)) != len(roots):
            raise ValueError("Unique explicit audit roots required")
        output = B / "proof" / (args.stage + "-" + module.rsplit(".", 1)[-1])
        command = ["python3", "-B", str(R / "research/main-weight-v1/compile_consumer.py"),
                   "--module", module, "--bank", str(B / "objects"),
                   "--source-root", str(B / "lean"), "--out", str(output), "--publish-object"]
        for root in roots:
            command.extend(["--root", root])
        subprocess.run(command, cwd=R, check=True)
        receipt = output / "RECEIPT.json"
        receipts.append({"module": module, "roots": roots,
                         "receipt": str(receipt.relative_to(R)),
                         "sha256": hashlib.sha256(receipt.read_bytes()).hexdigest()})
    index = B / "proof" / (args.stage + "-INDEX.json")
    if index.exists():
        raise ValueError("Fresh index required")
    index.write_text(json.dumps({"status": "HOST_TYPED_STANDARD_AXIOMS_COMPONENT_PASS",
                                "modules": receipts,
                                "qualification": "Not a source-cold or isolated replay."}, indent=2)+"\n")


if __name__ == "__main__":
    main()
