"""Generate actual C sum updates and their composition with the proved cell calls."""
import argparse
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    if a.out.exists() or not a.out.resolve().is_relative_to(B):
        raise ValueError('fresh owned generation directory required')
    a.out.mkdir(parents=True)
    rows = []
    for kind, count in [('Prefix', 16), ('Shared', 256)]:
        for start in range(0, count, 32):
            block = start // 32
            name = f'SynergyTangentV2C.MainAccum.{kind}{block:02d}'
            edge = f'SynergyTangentV2C.MainEdges.{kind}{block:02d}'
            indices = range(start, min(start+32, count))
            cell = lambda i: f'SynergyTangentV2C.SourceCells.{kind}{i:02d}' if kind == 'Prefix' else f'SynergyTangentV2C.SourceCells.{kind}{i:03d}'
            s = ['/- Actual C J updates, then actual same-frame source row composition. -/',
                 'import SynergyTangentV2C.MainRowAPI',
                 'import SynergyTangentV2C.CellTotalsData', f'import {edge}']
            s += [f'import {cell(i)}' for i in indices]
            s += [f'namespace {name}', 'open ScopedC ScopedNumerical',
                  'set_option autoImplicit false', 'set_option maxHeartbeats 0',
                  'set_option maxRecDepth 100000', 'set_option exponentiation.threshold 1024']
            roots = []
            logs = 'true' if kind == 'Shared' else 'false'
            total = 'sharedTotals' if kind == 'Shared' else 'prefixTotals'
            for i in indices:
                c = cell(i)
                before = f'(CellTotalsData.{total} {i})'
                after = f'(CellTotalsData.{total} {i+1})'
                s += [f'theorem suffix{i:03d} : MainRowAPI.ExactSuffix {logs}',
                      f'    {before} {after} {c}.output {i} {c}.left := by',
                      '  intro arena', '  unfold MainRowAPI.suffix',
                      '  run_tac do', '    let goal ← Lean.Elab.Tactic.getMainGoal',
                      '    let target ← goal.getType', '    let args := target.getAppArgs',
                      '    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do',
                      '      throwError "expected actual C accumulator source equality"',
                      '    goal.assign (← Lean.Meta.mkEqRefl args[1]!)',
                      f'theorem source{i:03d} (arena : NatArena.Arena) :',
                      f'    ArraySourceCalls.Run Header.layout MainLn2.service',
                      f'      (.sequence (MainCellAPI.body {logs}))',
                      f'      (MainCellAPI.before {before} {i} arena)',
                      f'      (.continuing (MainCellAPI.before {after} {i+1} arena)) :=',
                      f'  MainRowAPI.actual_body {edge}.cell{i:03d}',
                      f'    {before} {after} {c}.output arena',
                      f'    ({c}.execution {before} arena) suffix{i:03d}']
                roots += [f'{name}.suffix{i:03d}', f'{name}.source{i:03d}']
            s += [f'#print axioms {root}' for root in roots]
            s += [f'end {name}', '']
            p = B / 'lean' / Path(name.replace('.', '/') + '.lean')
            p.parent.mkdir(parents=True, exist_ok=True)
            text = '\n'.join(s)
            if p.exists() and p.read_text() != text:
                raise ValueError('different previously generated source')
            p.write_text(text)
            rows.append(dict(module=name, source=str(p.relative_to(B)),
                             source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(), roots=roots))
    (a.out / 'PLAN.json').write_text(json.dumps(dict(
        status='SOURCE_GENERATED_PENDING_ACTUAL_KERNEL_ACCEPTANCE', rows=rows,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()), indent=2)+'\n')
    print(json.dumps(dict(modules=len(rows), requested_roots=sum(len(r['roots']) for r in rows))))


if __name__ == '__main__':
    main()
