# Reproduce the verified Gaussian/tangent basis program

This add-on preserves the completed **actual C source-first basis producer**.
The program uses256shared cells,16prefix cells,128fractional bits and unsigned
512-bit arithmetic, and proves the unchanged three caps373/200,1273/2000 and129/250.
The original and adapted actual executables produce the same complete512bytes.
The adaptation is limited to four initialized record arrays becoming ordered
stores in their original blocks, local alpha-renaming, and two explicit U casts.
`frontend-v1/SOURCE_ADAPTATIONS.json` identifies every change. The original source
and its native output are retained; its constant is not an unverified conjecture.

`MANIFEST.json` pins every local source, physical C include, generator and minimal
receipt. It includes **zero application-object files**. Recorded historical object
hashes identify accepted evidence and are never default proof inputs.

## Check or copy the exact evidence

From the research checkout root:

```sh
python3 research/basis-tangent-source-v2/reproduction-v2/reproduce.py verify \
  --out research/basis-tangent-source-v2/reproduction-v2/verify-fresh

python3 research/basis-tangent-source-v2/reproduction-v2/reproduce.py materialize \
  --out research/basis-tangent-source-v2/reproduction-v2/source-copy-fresh
```

Every output path must be fresh and inside this add-on. `materialize` writes the
exact351local proof-source modules and actual physical input tree under
`source-project/`, preserving relative `include_str` paths. It also copies the
minimal accepted receipts and this manifest. This is evidence/source preparation,
not a new kernel build or a claim that the26external import modules and their
transitive dependencies are bundled here.

## Regenerate source and numerical proposals

Use the exact Clang binary whose SHA256 is pinned in
`../NATIVE_COMPILER_LOCK_V1.json`, Linux x86-64, and the GCC11 development headers
at the include locations recorded in the actual native receipts. The executable
path may change; its bytes must match.

```sh
python3 scripts/resource_scope_v3.py --family root_generic \
  --memory-gib 2 --cpus 2 --wall 300 \
  --out resources/basis-source-regeneration-fresh -- \
  python3 research/basis-tangent-source-v2/reproduction-v2/reproduce.py regenerate \
    --compiler /path/to/pinned/clang \
    --out research/basis-tangent-source-v2/reproduction-v2/regeneration-fresh
```

The command changes only a newly materialized private copy. It reruns the existing
actual-Clang frontend, source-bundle generator,272leaf-source generator, literal
sum-table generator, endpoint/accumulator generators and closed-main generator.
Every regenerated Lean module and actual C include must match the accepted bytes.
The small104KBproposer transcript is retained as **untrusted generation data**;
its values confer no proof authority. `FamilyProposal.lean` can regenerate that
transcript after compiling its dependencies in the complete coherent environment.
The272ordinary-kernel actual-AST execution equalities, model equalities and source
call theorems are what validate the proposed values.

## Rerun both actual native executables

```sh
python3 scripts/resource_scope_v3.py --family root_generic \
  --memory-gib 2 --cpus 2 --wall 300 \
  --out resources/basis-native-reproduction-fresh -- \
  python3 research/basis-tangent-source-v2/reproduction-v2/reproduce.py native \
    --compiler /path/to/pinned/clang \
    --out research/basis-tangent-source-v2/reproduction-v2/native-fresh
```

This reuses `reproduce_native_v1.py`: compile both originals/adapted sources, run
both successfully, compare all512bytes and record source/compiler/executable/output
hashes. Native C execution uses no Lean memory-policy shim. Native observations
are distinct from the formal source execution and cannot replace it.

## Compile the proofs in a complete clean environment

The completed development evidence is:

| Evidence population | Exact scope |
|---|---|
| Numerical subset |295modules /1193unique typedStd3 roots, including272actual C cells /816roots |
| Main/read local source union |351modules, including the numerical subset |
| Final composition |13modules /550roots, receipt SHA e3cebfadd8732c557a505762623cba62247ae338cf892fde5d6ed6c9d09c4075 |

These populations overlap. Do not add351+295 or combine printed root counts into
an invented total. All statements, source hashes, compiler pins and actual
acceptance receipts are preserved in the manifest and the three original indices.
There are no random seeds.

The whole clean source-only route is **not executed by this add-on**. It requires
the repaired coherent research source capsule: the existing joint-cold-chainV4
engine, the actually audited original10338source-built parent, exact coherent
research source map, basis/current159extensions, and context-separated final283
repair/audit modules. Parent objects may be used only through explicit validation
of those actual read-only source-built parent receipts, compiler context and source
hashes. Ordinary host `objects/` directories are not clean parents.

Until that final capsule/parent adapter is supplied and actually executed, this
directory intentionally provides no fake Lake project or default warm-object
proof route. The existing `run_family_v1.py`, `run_stage_v1.py` and
`run_closed_pipeline_v1.py` are retained for their exact development commands and
must keep their host-development classification. A fresh full replay must compile
all needed source dependencies or explicitly chain the validated read-only parent,
then audit `SourceProgramRead` and `ClosedCaps` and the repaired ANT consumers.

## Trust, failures and storage

The source proof uses normal Lean declaration kernel checking and the usualStd3
axioms. Exact pinned compiler/BitInt512/ABI/core-runtime, stdio/CRT, OS and hardware
contracts remain. The formal main constructs a normal-write stream scenario;
accepted stream bytes are distinguished from delivered bytes after CRT flushing.
No universal host I/O success, new analytic premise, `sorry`, native execution
axiom or `skipKernelTC` is introduced.

The failed12GiB first cell,8GiB frontend and32GiB computed-cache attempts remain
historical resource failures; later accepted runs do not rewrite them. Actual
resource facts and measured boundaries are in
`reports/final-campaign-v1/evidence/NUMERICS_RESOURCE_FACTS_V1.json`.

Generated source copies and native executables can be regenerated by these scripts.
After a reproduction is checked, remove only its named fresh output directory.
Keep this manifest, source/generators, original sources, minimal proposer data,
accepted receipts and the two512byte native outputs. Never remove the original
accepted proof artifacts or unrelated workspaces as part of add-on cleanup.

Version2 adds strict finite floating-point JSON parsing to the active reproduction
validator and proposal parser. All351 accepted Lean modules and actual C inputs
remain unchanged. The original V1 evidence is preserved. The104KB proposal
transcript is still an explicitly untrusted seed in this component-only route;
the integrated clean master must regenerate it from FamilyProposal in a fresh
source-built frontend context before source generation and final verification.
