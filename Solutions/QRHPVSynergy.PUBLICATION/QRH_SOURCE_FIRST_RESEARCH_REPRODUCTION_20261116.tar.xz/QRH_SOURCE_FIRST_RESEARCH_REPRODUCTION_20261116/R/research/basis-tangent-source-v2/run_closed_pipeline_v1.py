"""Close the complete actual-source basis program after all272 source cells pass.

This is a warm development composition. The separate complete source-only
namespace replay and final research theorem audit remain mandatory.
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

B = Path(__file__).resolve().parent
R = B.parents[1]
STD3 = {'propext', 'Classical.choice', 'Quot.sound'}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load(p):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    return json.loads(p.read_text(), object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def atomic(p, value):
    tmp = p.with_name(p.name+'.tmp')
    tmp.write_text(json.dumps(value, indent=2)+'\n')
    os.replace(tmp, p)


def validate_family(family):
    receipt = load(family / 'RECEIPT.json')
    plan_path = B/'family-plan-v1/FAMILY_PLAN.json'
    plan = load(plan_path)
    need(receipt['status'] == 'ALL272_MODEL_AND_ACTUAL_C_SOURCE_KERNEL_PROOFS_PASS' and
         receipt['module_count'] == 272 and receipt['root_count'] == 816 and
         receipt['plan_sha256'] ==
         '3c720380a6c22fa24a9d1cbfe4cf22b6e041c438052b617150a79da907cd03d5',
         'complete fixed272 family, not a partial/pending receipt')
    need(sha(plan_path) == receipt['plan_sha256'], 'actual frozen complete family plan')
    for path, digest in plan['source_pins'].items():
        need(sha(R/path) == digest, 'current source/AST/include/helper pin '+path)
    records = receipt['records']
    expected = {f'SynergyTangentV2C.SourceCells.Prefix{i:02d}' for i in range(16)} | {
        f'SynergyTangentV2C.SourceCells.Shared{i:03d}' for i in range(256)}
    need(len(records) == 272 and {r['module'] for r in records} == expected,
         'exact original16+256 compiler identities')
    for row in records:
        module = row['module']
        source = B/'lean'/(module.replace('.', '/')+'.lean')
        obj = B/'objects'/(module.replace('.', '/')+'.olean')
        p = R / row['receipt']
        need(p.resolve().is_relative_to(family.resolve()) and sha(p) == row['receipt_sha256'],
             'actual accepted receipt association')
        proof = load(p)
        roots = {module+'.'+name for name in ['model_eq', 'execution', 'actual_source']}
        need(sha(source) == row['source_sha256'] == proof['source_sha256'] and
             sha(obj) == row['object_sha256'] == proof['object_sha256'],
             'current exact source and published object')
        need(proof['status'] == 'PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES' and
             proof['exit_code'] == 0 and proof['source_unchanged'] is True and
             set(proof['audits']) == roots and
             all(isinstance(v, list) and set(v) <= STD3 for v in proof['audits'].values()),
             'all three actual ordinary-kernel source/model roots')
    return dict(receipt_sha256=sha(family/'RECEIPT.json'), modules=272, roots=816)


def validate_owned_dependencies(modules, family):
    """Associate every reachable local import with a real accepted kernel object."""
    owned = {}
    todo = list(modules)
    while todo:
        module = todo.pop()
        if module in owned:
            continue
        p = B/'lean'/(module.replace('.', '/')+'.lean')
        if not p.is_file():
            continue
        owned[module] = p
        todo += re.findall(r'^import\s+(\S+)', p.read_text(), re.M)
    final = set(modules)
    accepted = {}
    for p in (B/'proof').rglob('RECEIPT.json'):
        d = load(p)
        if (d.get('status') == 'PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES' and
                d.get('exit_code') == 0 and d.get('source_unchanged') is True):
            accepted.setdefault((d['source_sha256'], d['object_sha256']), []).append(p)
    for p in family.glob('*/RECEIPT.json'):
        d = load(p)
        if (d.get('status') == 'PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES' and
                d.get('exit_code') == 0 and d.get('source_unchanged') is True):
            accepted.setdefault((d['source_sha256'], d['object_sha256']), []).append(p)
    pins = {}
    for module, source in owned.items():
        if module in final:
            continue
        obj = B/'objects'/(module.replace('.', '/')+'.olean')
        key = (sha(source), sha(obj))
        need(key in accepted, 'reachable owned source/object has no matching accepted receipt '+module)
        pins[module] = dict(source_sha256=key[0], object_sha256=key[1],
                            receipts=[str(p.relative_to(B)) for p in accepted[key]])
    return pins


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--family', type=Path, required=True)
    ap.add_argument('--out', type=Path)
    ap.add_argument('--check-inputs', action='store_true')
    a = ap.parse_args()
    family = a.family.resolve()
    need(family.is_relative_to(B), 'owned fixed family')
    checked = validate_family(family)
    modules = ['SynergyTangentV2C.MainAccum.Prefix00'] + [
        f'SynergyTangentV2C.MainAccum.Shared{i:02d}' for i in range(8)] + [
        'SynergyTangentV2C.MainSharedRows', 'SynergyTangentV2C.SourceProgramClosed',
        'SynergyTangentV2C.SourceProgramRead',
        'SynergyTangentC.ClosedCaps']
    sources = {m: B/'lean'/(m.replace('.', '/')+'.lean') for m in modules}
    need(all(p.is_file() for p in sources.values()), 'all concrete final source files')
    for module, source in sources.items():
        text = source.read_text()
        need(re.search(r'\b(?:sorry|admit|axiom)\b', text) is None,
             'no unproved/application-axiom source '+module)
    dependency_pins = validate_owned_dependencies(modules, family)
    if a.check_inputs:
        print(json.dumps(dict(status='INPUT_CHECK_ONLY_NOT_NEW_PROOF_ACCEPTANCE',
                              owned_dependencies=len(dependency_pins), **checked)))
        return
    need(a.out is not None, 'explicit fresh proof output')
    out = a.out.resolve()
    need(out.is_relative_to(B) and not out.exists(), 'fresh owned output')
    out.mkdir(parents=True)
    request = dict(family=checked, source_pins={m: sha(p) for m,p in sources.items()},
                   owned_dependencies=dependency_pins,
                   script_sha256=sha(Path(__file__)), modules=modules)
    atomic(out/'REQUEST.json', request)
    started = time.monotonic()
    records = []
    for module in modules:
        source = sources[module]
        need(sha(source) == request['source_pins'][module], 'frozen final source')
        namespace = re.search(r'^namespace\s+(\S+)', source.read_text(), re.M)[1]
        roots = [name if name.startswith(namespace+'.') else namespace+'.'+name
                 for name in re.findall(r'^#print axioms\s+(\S+)', source.read_text(), re.M)]
        need(roots and len(roots) == len(set(roots)), 'unique actual typed roots')
        dest = out/module
        command = [sys.executable, '-I', '-B', str(R/'research/main-weight-v1/compile_consumer.py'),
                   '--module', module, '--bank', str(B/'objects'), '--source-root', str(B/'lean'),
                   '--out', str(dest), '--publish-object']
        for root in roots:
            command += ['--root', root]
        with (out/(module+'.driver.log')).open('xb') as stream:
            child = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=660)
        need(child.returncode == 0, 'actual complete numerical/source consumer compiler '+module)
        proof = load(dest/'RECEIPT.json')
        need(proof['status'] == 'PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES' and
             proof['exit_code'] == 0 and set(proof['audits']) == set(roots) and
             all(set(v) <= STD3 for v in proof['audits'].values()), 'final complete typed Std3')
        records.append(dict(module=module, roots=roots, receipt_sha256=sha(dest/'RECEIPT.json'),
                            source_sha256=sha(source), object_sha256=proof['object_sha256']))
        atomic(out/'PROGRESS.json', dict(completed=records, pending=len(modules)-len(records)))
    need(validate_family(family) == checked, 'family unchanged through composition')
    need(validate_owned_dependencies(modules, family) == dependency_pins,
         'all reachable owned source/object dependencies unchanged')
    atomic(out/'RECEIPT.json', dict(status='COMPLETE_BASIS_SOURCE_FIRST_PROGRAM_WARM_COMPOSITION_PASS',
        request_sha256=sha(out/'REQUEST.json'), family=checked, records=records,
        seconds=time.monotonic()-started, native_execution_axioms=0,
        qualification='Actual source-first basis producer and real-cap consumer. Complete research '
                      'ANT closure and source-only isolated replay are separate acceptance gates.'))
    print(json.dumps(dict(status='COMPLETE_BASIS_SOURCE_FIRST_PROGRAM_WARM_COMPOSITION_PASS',
                          modules=len(records))))


if __name__ == '__main__':
    main()
