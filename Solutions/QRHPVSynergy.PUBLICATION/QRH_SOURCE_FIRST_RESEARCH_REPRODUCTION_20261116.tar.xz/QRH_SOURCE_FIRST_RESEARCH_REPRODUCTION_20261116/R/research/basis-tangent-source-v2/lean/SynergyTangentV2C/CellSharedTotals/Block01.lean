/- Exact cumulative sums, using the corresponding accepted fixed-cell model equations. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Shared032
import SynergyTangentV2C.SourceCells.Shared033
import SynergyTangentV2C.SourceCells.Shared034
import SynergyTangentV2C.SourceCells.Shared035
import SynergyTangentV2C.SourceCells.Shared036
import SynergyTangentV2C.SourceCells.Shared037
import SynergyTangentV2C.SourceCells.Shared038
import SynergyTangentV2C.SourceCells.Shared039
import SynergyTangentV2C.SourceCells.Shared040
import SynergyTangentV2C.SourceCells.Shared041
import SynergyTangentV2C.SourceCells.Shared042
import SynergyTangentV2C.SourceCells.Shared043
import SynergyTangentV2C.SourceCells.Shared044
import SynergyTangentV2C.SourceCells.Shared045
import SynergyTangentV2C.SourceCells.Shared046
import SynergyTangentV2C.SourceCells.Shared047
import SynergyTangentV2C.SourceCells.Shared048
import SynergyTangentV2C.SourceCells.Shared049
import SynergyTangentV2C.SourceCells.Shared050
import SynergyTangentV2C.SourceCells.Shared051
import SynergyTangentV2C.SourceCells.Shared052
import SynergyTangentV2C.SourceCells.Shared053
import SynergyTangentV2C.SourceCells.Shared054
import SynergyTangentV2C.SourceCells.Shared055
import SynergyTangentV2C.SourceCells.Shared056
import SynergyTangentV2C.SourceCells.Shared057
import SynergyTangentV2C.SourceCells.Shared058
import SynergyTangentV2C.SourceCells.Shared059
import SynergyTangentV2C.SourceCells.Shared060
import SynergyTangentV2C.SourceCells.Shared061
import SynergyTangentV2C.SourceCells.Shared062
import SynergyTangentV2C.SourceCells.Shared063
namespace SynergyTangentV2C.CellSharedTotals.Block01
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.sharedOnlyTotals
theorem sum032 :
    (ProofBox.add (totals 32).1 SourceCells.Shared032.output.1,
     ProofBox.add (totals 32).2.1 SourceCells.Shared032.output.2.1,
     ProofBox.add (totals 32).2.2 SourceCells.Shared032.output.2.2)=totals 33 := by
  decide +kernel
#print axioms sum032
theorem sum033 :
    (ProofBox.add (totals 33).1 SourceCells.Shared033.output.1,
     ProofBox.add (totals 33).2.1 SourceCells.Shared033.output.2.1,
     ProofBox.add (totals 33).2.2 SourceCells.Shared033.output.2.2)=totals 34 := by
  decide +kernel
#print axioms sum033
theorem sum034 :
    (ProofBox.add (totals 34).1 SourceCells.Shared034.output.1,
     ProofBox.add (totals 34).2.1 SourceCells.Shared034.output.2.1,
     ProofBox.add (totals 34).2.2 SourceCells.Shared034.output.2.2)=totals 35 := by
  decide +kernel
#print axioms sum034
theorem sum035 :
    (ProofBox.add (totals 35).1 SourceCells.Shared035.output.1,
     ProofBox.add (totals 35).2.1 SourceCells.Shared035.output.2.1,
     ProofBox.add (totals 35).2.2 SourceCells.Shared035.output.2.2)=totals 36 := by
  decide +kernel
#print axioms sum035
theorem sum036 :
    (ProofBox.add (totals 36).1 SourceCells.Shared036.output.1,
     ProofBox.add (totals 36).2.1 SourceCells.Shared036.output.2.1,
     ProofBox.add (totals 36).2.2 SourceCells.Shared036.output.2.2)=totals 37 := by
  decide +kernel
#print axioms sum036
theorem sum037 :
    (ProofBox.add (totals 37).1 SourceCells.Shared037.output.1,
     ProofBox.add (totals 37).2.1 SourceCells.Shared037.output.2.1,
     ProofBox.add (totals 37).2.2 SourceCells.Shared037.output.2.2)=totals 38 := by
  decide +kernel
#print axioms sum037
theorem sum038 :
    (ProofBox.add (totals 38).1 SourceCells.Shared038.output.1,
     ProofBox.add (totals 38).2.1 SourceCells.Shared038.output.2.1,
     ProofBox.add (totals 38).2.2 SourceCells.Shared038.output.2.2)=totals 39 := by
  decide +kernel
#print axioms sum038
theorem sum039 :
    (ProofBox.add (totals 39).1 SourceCells.Shared039.output.1,
     ProofBox.add (totals 39).2.1 SourceCells.Shared039.output.2.1,
     ProofBox.add (totals 39).2.2 SourceCells.Shared039.output.2.2)=totals 40 := by
  decide +kernel
#print axioms sum039
theorem sum040 :
    (ProofBox.add (totals 40).1 SourceCells.Shared040.output.1,
     ProofBox.add (totals 40).2.1 SourceCells.Shared040.output.2.1,
     ProofBox.add (totals 40).2.2 SourceCells.Shared040.output.2.2)=totals 41 := by
  decide +kernel
#print axioms sum040
theorem sum041 :
    (ProofBox.add (totals 41).1 SourceCells.Shared041.output.1,
     ProofBox.add (totals 41).2.1 SourceCells.Shared041.output.2.1,
     ProofBox.add (totals 41).2.2 SourceCells.Shared041.output.2.2)=totals 42 := by
  decide +kernel
#print axioms sum041
theorem sum042 :
    (ProofBox.add (totals 42).1 SourceCells.Shared042.output.1,
     ProofBox.add (totals 42).2.1 SourceCells.Shared042.output.2.1,
     ProofBox.add (totals 42).2.2 SourceCells.Shared042.output.2.2)=totals 43 := by
  decide +kernel
#print axioms sum042
theorem sum043 :
    (ProofBox.add (totals 43).1 SourceCells.Shared043.output.1,
     ProofBox.add (totals 43).2.1 SourceCells.Shared043.output.2.1,
     ProofBox.add (totals 43).2.2 SourceCells.Shared043.output.2.2)=totals 44 := by
  decide +kernel
#print axioms sum043
theorem sum044 :
    (ProofBox.add (totals 44).1 SourceCells.Shared044.output.1,
     ProofBox.add (totals 44).2.1 SourceCells.Shared044.output.2.1,
     ProofBox.add (totals 44).2.2 SourceCells.Shared044.output.2.2)=totals 45 := by
  decide +kernel
#print axioms sum044
theorem sum045 :
    (ProofBox.add (totals 45).1 SourceCells.Shared045.output.1,
     ProofBox.add (totals 45).2.1 SourceCells.Shared045.output.2.1,
     ProofBox.add (totals 45).2.2 SourceCells.Shared045.output.2.2)=totals 46 := by
  decide +kernel
#print axioms sum045
theorem sum046 :
    (ProofBox.add (totals 46).1 SourceCells.Shared046.output.1,
     ProofBox.add (totals 46).2.1 SourceCells.Shared046.output.2.1,
     ProofBox.add (totals 46).2.2 SourceCells.Shared046.output.2.2)=totals 47 := by
  decide +kernel
#print axioms sum046
theorem sum047 :
    (ProofBox.add (totals 47).1 SourceCells.Shared047.output.1,
     ProofBox.add (totals 47).2.1 SourceCells.Shared047.output.2.1,
     ProofBox.add (totals 47).2.2 SourceCells.Shared047.output.2.2)=totals 48 := by
  decide +kernel
#print axioms sum047
theorem sum048 :
    (ProofBox.add (totals 48).1 SourceCells.Shared048.output.1,
     ProofBox.add (totals 48).2.1 SourceCells.Shared048.output.2.1,
     ProofBox.add (totals 48).2.2 SourceCells.Shared048.output.2.2)=totals 49 := by
  decide +kernel
#print axioms sum048
theorem sum049 :
    (ProofBox.add (totals 49).1 SourceCells.Shared049.output.1,
     ProofBox.add (totals 49).2.1 SourceCells.Shared049.output.2.1,
     ProofBox.add (totals 49).2.2 SourceCells.Shared049.output.2.2)=totals 50 := by
  decide +kernel
#print axioms sum049
theorem sum050 :
    (ProofBox.add (totals 50).1 SourceCells.Shared050.output.1,
     ProofBox.add (totals 50).2.1 SourceCells.Shared050.output.2.1,
     ProofBox.add (totals 50).2.2 SourceCells.Shared050.output.2.2)=totals 51 := by
  decide +kernel
#print axioms sum050
theorem sum051 :
    (ProofBox.add (totals 51).1 SourceCells.Shared051.output.1,
     ProofBox.add (totals 51).2.1 SourceCells.Shared051.output.2.1,
     ProofBox.add (totals 51).2.2 SourceCells.Shared051.output.2.2)=totals 52 := by
  decide +kernel
#print axioms sum051
theorem sum052 :
    (ProofBox.add (totals 52).1 SourceCells.Shared052.output.1,
     ProofBox.add (totals 52).2.1 SourceCells.Shared052.output.2.1,
     ProofBox.add (totals 52).2.2 SourceCells.Shared052.output.2.2)=totals 53 := by
  decide +kernel
#print axioms sum052
theorem sum053 :
    (ProofBox.add (totals 53).1 SourceCells.Shared053.output.1,
     ProofBox.add (totals 53).2.1 SourceCells.Shared053.output.2.1,
     ProofBox.add (totals 53).2.2 SourceCells.Shared053.output.2.2)=totals 54 := by
  decide +kernel
#print axioms sum053
theorem sum054 :
    (ProofBox.add (totals 54).1 SourceCells.Shared054.output.1,
     ProofBox.add (totals 54).2.1 SourceCells.Shared054.output.2.1,
     ProofBox.add (totals 54).2.2 SourceCells.Shared054.output.2.2)=totals 55 := by
  decide +kernel
#print axioms sum054
theorem sum055 :
    (ProofBox.add (totals 55).1 SourceCells.Shared055.output.1,
     ProofBox.add (totals 55).2.1 SourceCells.Shared055.output.2.1,
     ProofBox.add (totals 55).2.2 SourceCells.Shared055.output.2.2)=totals 56 := by
  decide +kernel
#print axioms sum055
theorem sum056 :
    (ProofBox.add (totals 56).1 SourceCells.Shared056.output.1,
     ProofBox.add (totals 56).2.1 SourceCells.Shared056.output.2.1,
     ProofBox.add (totals 56).2.2 SourceCells.Shared056.output.2.2)=totals 57 := by
  decide +kernel
#print axioms sum056
theorem sum057 :
    (ProofBox.add (totals 57).1 SourceCells.Shared057.output.1,
     ProofBox.add (totals 57).2.1 SourceCells.Shared057.output.2.1,
     ProofBox.add (totals 57).2.2 SourceCells.Shared057.output.2.2)=totals 58 := by
  decide +kernel
#print axioms sum057
theorem sum058 :
    (ProofBox.add (totals 58).1 SourceCells.Shared058.output.1,
     ProofBox.add (totals 58).2.1 SourceCells.Shared058.output.2.1,
     ProofBox.add (totals 58).2.2 SourceCells.Shared058.output.2.2)=totals 59 := by
  decide +kernel
#print axioms sum058
theorem sum059 :
    (ProofBox.add (totals 59).1 SourceCells.Shared059.output.1,
     ProofBox.add (totals 59).2.1 SourceCells.Shared059.output.2.1,
     ProofBox.add (totals 59).2.2 SourceCells.Shared059.output.2.2)=totals 60 := by
  decide +kernel
#print axioms sum059
theorem sum060 :
    (ProofBox.add (totals 60).1 SourceCells.Shared060.output.1,
     ProofBox.add (totals 60).2.1 SourceCells.Shared060.output.2.1,
     ProofBox.add (totals 60).2.2 SourceCells.Shared060.output.2.2)=totals 61 := by
  decide +kernel
#print axioms sum060
theorem sum061 :
    (ProofBox.add (totals 61).1 SourceCells.Shared061.output.1,
     ProofBox.add (totals 61).2.1 SourceCells.Shared061.output.2.1,
     ProofBox.add (totals 61).2.2 SourceCells.Shared061.output.2.2)=totals 62 := by
  decide +kernel
#print axioms sum061
theorem sum062 :
    (ProofBox.add (totals 62).1 SourceCells.Shared062.output.1,
     ProofBox.add (totals 62).2.1 SourceCells.Shared062.output.2.1,
     ProofBox.add (totals 62).2.2 SourceCells.Shared062.output.2.2)=totals 63 := by
  decide +kernel
#print axioms sum062
theorem sum063 :
    (ProofBox.add (totals 63).1 SourceCells.Shared063.output.1,
     ProofBox.add (totals 63).2.1 SourceCells.Shared063.output.2.1,
     ProofBox.add (totals 63).2.2 SourceCells.Shared063.output.2.2)=totals 64 := by
  decide +kernel
#print axioms sum063
theorem advance (old : SynergyAnalytic.BoxModel.sharedFold 256 32=some (totals 32)) :
    SynergyAnalytic.BoxModel.sharedFold 256 64=some (totals 64) := by
  have fold032 := old
  have fold033 := (CellFoldSteps.shared_next 32 _ _ fold032
    SourceCells.Shared032.model_eq).trans (congrArg some sum032)
  have fold034 := (CellFoldSteps.shared_next 33 _ _ fold033
    SourceCells.Shared033.model_eq).trans (congrArg some sum033)
  have fold035 := (CellFoldSteps.shared_next 34 _ _ fold034
    SourceCells.Shared034.model_eq).trans (congrArg some sum034)
  have fold036 := (CellFoldSteps.shared_next 35 _ _ fold035
    SourceCells.Shared035.model_eq).trans (congrArg some sum035)
  have fold037 := (CellFoldSteps.shared_next 36 _ _ fold036
    SourceCells.Shared036.model_eq).trans (congrArg some sum036)
  have fold038 := (CellFoldSteps.shared_next 37 _ _ fold037
    SourceCells.Shared037.model_eq).trans (congrArg some sum037)
  have fold039 := (CellFoldSteps.shared_next 38 _ _ fold038
    SourceCells.Shared038.model_eq).trans (congrArg some sum038)
  have fold040 := (CellFoldSteps.shared_next 39 _ _ fold039
    SourceCells.Shared039.model_eq).trans (congrArg some sum039)
  have fold041 := (CellFoldSteps.shared_next 40 _ _ fold040
    SourceCells.Shared040.model_eq).trans (congrArg some sum040)
  have fold042 := (CellFoldSteps.shared_next 41 _ _ fold041
    SourceCells.Shared041.model_eq).trans (congrArg some sum041)
  have fold043 := (CellFoldSteps.shared_next 42 _ _ fold042
    SourceCells.Shared042.model_eq).trans (congrArg some sum042)
  have fold044 := (CellFoldSteps.shared_next 43 _ _ fold043
    SourceCells.Shared043.model_eq).trans (congrArg some sum043)
  have fold045 := (CellFoldSteps.shared_next 44 _ _ fold044
    SourceCells.Shared044.model_eq).trans (congrArg some sum044)
  have fold046 := (CellFoldSteps.shared_next 45 _ _ fold045
    SourceCells.Shared045.model_eq).trans (congrArg some sum045)
  have fold047 := (CellFoldSteps.shared_next 46 _ _ fold046
    SourceCells.Shared046.model_eq).trans (congrArg some sum046)
  have fold048 := (CellFoldSteps.shared_next 47 _ _ fold047
    SourceCells.Shared047.model_eq).trans (congrArg some sum047)
  have fold049 := (CellFoldSteps.shared_next 48 _ _ fold048
    SourceCells.Shared048.model_eq).trans (congrArg some sum048)
  have fold050 := (CellFoldSteps.shared_next 49 _ _ fold049
    SourceCells.Shared049.model_eq).trans (congrArg some sum049)
  have fold051 := (CellFoldSteps.shared_next 50 _ _ fold050
    SourceCells.Shared050.model_eq).trans (congrArg some sum050)
  have fold052 := (CellFoldSteps.shared_next 51 _ _ fold051
    SourceCells.Shared051.model_eq).trans (congrArg some sum051)
  have fold053 := (CellFoldSteps.shared_next 52 _ _ fold052
    SourceCells.Shared052.model_eq).trans (congrArg some sum052)
  have fold054 := (CellFoldSteps.shared_next 53 _ _ fold053
    SourceCells.Shared053.model_eq).trans (congrArg some sum053)
  have fold055 := (CellFoldSteps.shared_next 54 _ _ fold054
    SourceCells.Shared054.model_eq).trans (congrArg some sum054)
  have fold056 := (CellFoldSteps.shared_next 55 _ _ fold055
    SourceCells.Shared055.model_eq).trans (congrArg some sum055)
  have fold057 := (CellFoldSteps.shared_next 56 _ _ fold056
    SourceCells.Shared056.model_eq).trans (congrArg some sum056)
  have fold058 := (CellFoldSteps.shared_next 57 _ _ fold057
    SourceCells.Shared057.model_eq).trans (congrArg some sum057)
  have fold059 := (CellFoldSteps.shared_next 58 _ _ fold058
    SourceCells.Shared058.model_eq).trans (congrArg some sum058)
  have fold060 := (CellFoldSteps.shared_next 59 _ _ fold059
    SourceCells.Shared059.model_eq).trans (congrArg some sum059)
  have fold061 := (CellFoldSteps.shared_next 60 _ _ fold060
    SourceCells.Shared060.model_eq).trans (congrArg some sum060)
  have fold062 := (CellFoldSteps.shared_next 61 _ _ fold061
    SourceCells.Shared061.model_eq).trans (congrArg some sum061)
  have fold063 := (CellFoldSteps.shared_next 62 _ _ fold062
    SourceCells.Shared062.model_eq).trans (congrArg some sum062)
  have fold064 := (CellFoldSteps.shared_next 63 _ _ fold063
    SourceCells.Shared063.model_eq).trans (congrArg some sum063)
  exact fold064
#print axioms advance
end SynergyTangentV2C.CellSharedTotals.Block01
