/- Composition of the actual two C loop bodies. Finite providers must prove
the source endpoint/buffer declarations, tangentCell execution, and J updates.
No output, initialized local buffer, or successful numerical call is assumed. -/
import SynergyTangentV2C.MainPrefix
import SynergyTangentV2C.CellExecute
namespace SynergyTangentV2C.MainCellAPI
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def body (logs : Bool) : List Stmt :=
  match MainLn2.statements[if logs then 11 else 9]?.getD .skip with
  | .whileLoop _ (.sequence ss) => ss
  | _ => []
def expression (logs : Bool) : Expr := match (body logs)[2]?.getD .skip with
  | .eval e => e
  | _ => .nat 0
def width (logs : Bool) : ProofBox :=
  if logs then SynergyAnalytic.BoxModel.rat 15 256
  else SynergyAnalytic.BoxModel.rat 1 96
def base (totals : MainFrames.Totals) (i : Nat) (left : ProofBox)
    (arena : NatArena.Arena) : State :=
  ArrayStages.withArena (MainFrames.base totals i left) arena
def before (totals : MainFrames.Totals) (i : Nat) (arena : NatArena.Arena) : State :=
  ArrayStages.withArena (MainFrames.before totals i) arena

@[irreducible] def edges (logs : Bool) (totals : MainFrames.Totals) (i : Nat)
    (arena : NatArena.Arena) : Option ArraySourceExecute.Outcome :=
  ArraySourceExecute.statements Header.layout MainLn2.service 128 2048
    ((body logs).take 2) (before totals i arena)

def ExactEdges (logs : Bool) (i : Nat) (left : ProofBox) : Prop :=
  ∀ (totals : MainFrames.Totals) (arena : NatArena.Arena),
    edges logs totals i arena =
      some (.continuing (CellExecute.buffers (base totals i left arena)))

theorem actual_partition (logs : Bool) :
    body logs = (body logs).take 2 ++ [.eval (expression logs)] ++
      (body logs).drop 3 := by cases logs <;> rfl

theorem eval_inputs (logs : Bool) (totals : MainFrames.Totals) (i : Nat)
    (left : ProofBox) (arena : NatArena.Arena) :
    evalExpr Header.layout MainLn2.service 128
      (CellExecute.buffers (base totals i left arena)) (expression logs) =
    MainLn2.service "tangentCell"
      (CellExecute.args (base totals i left arena) left (width logs) logs)
      (CellExecute.buffers (base totals i left arena)) := by
  cases logs <;> rfl

theorem seq_append {ss tt : List Stmt} {s middle : State}
    {out : Loops.Flow State Value}
    (first : Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      ss s (.continuing middle))
    (rest : Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      tt middle out) :
    Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      (ss ++ tt) s out := by
  induction ss generalizing s with
  | nil => cases first; exact rest
  | cons head tail ih =>
    cases first with
    | next hhead htail => exact .next hhead (ih htail)

theorem source_prefix {logs : Bool} {i : Nat} {left : ProofBox}
    (edgeProof : ExactEdges logs i left) (totals output : MainFrames.Totals)
    (arena : NatArena.Arena)
    (execution : CellExecute.run (base totals i left arena) left (width logs) logs =
      some (.unit,CellExecute.filled (base totals i left arena) output)) :
    Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      ((body logs).take 2 ++ [.eval (expression logs)]) (before totals i arena)
      (.continuing (CellExecute.filled (base totals i left arena) output)) := by
  have actualEdges := edgeProof totals arena
  unfold edges at actualEdges
  have first := (ArraySourceExecute.sound Header.layout MainLn2.service 128 2048).2.1
    _ _ _ actualEdges
  have run_eq : CellExecute.run (base totals i left arena) left (width logs) logs =
      MainLn2.service "tangentCell"
        (CellExecute.args (base totals i left arena) left (width logs) logs)
        (CellExecute.buffers (base totals i left arena)) := by
    unfold CellExecute.run; rfl
  have call : ArraySourceCalls.Run Header.layout MainLn2.service (.eval (expression logs))
      (CellExecute.buffers (base totals i left arena))
      (.continuing (CellExecute.filled (base totals i left arena) output)) := by
    apply Loops.StmtRun.evaluate
    refine ⟨128, ?_⟩
    rw [eval_inputs]
    exact Eq.mp (congrArg (fun result => result =
      some (.unit,CellExecute.filled (base totals i left arena) output)) run_eq) execution
  exact seq_append first (.next call (.nil _))

#print axioms actual_partition
#print axioms eval_inputs
#print axioms seq_append
#print axioms source_prefix
end SynergyTangentV2C.MainCellAPI
