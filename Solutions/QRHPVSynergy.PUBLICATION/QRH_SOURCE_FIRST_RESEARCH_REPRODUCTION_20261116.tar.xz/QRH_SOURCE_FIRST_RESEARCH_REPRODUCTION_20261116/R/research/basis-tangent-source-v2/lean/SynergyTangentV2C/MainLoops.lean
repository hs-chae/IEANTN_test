/- Finite actual C while-loop composition, including the terminal guard.
Its finite row hypothesis is discharged by the complete source-cell family. -/
import SynergyTangentV2C.MainRowAPI
import ScopedC.ExpressionTemplates
import ScopedC.PoolCalls
namespace SynergyTangentV2C.MainLoops
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def limit (logs : Bool) : Nat := if logs then 256 else 16
def guard (logs : Bool) : Expr := .binary "<" (.var "i")
  (.var (if logs then "cells" else "prefix"))

theorem read_index (call : Call) (totals : MainFrames.Totals) (i : Nat)
    (arena : NatArena.Arena) :
    evalExpr Header.layout call 1 (MainCellAPI.before totals i arena) (.var "i") =
      some (MainFrames.unsigned i,MainCellAPI.before totals i arena) := by rfl

theorem read_limit (call : Call) (logs : Bool) (totals : MainFrames.Totals)
    (i : Nat) (arena : NatArena.Arena) :
    evalExpr Header.layout call 1 (MainCellAPI.before totals i arena)
      (.var (if logs then "cells" else "prefix")) =
      some (MainFrames.unsigned (limit logs),MainCellAPI.before totals i arena) := by
  cases logs <;> rfl

theorem actual_guard (call : Call) (logs : Bool) (totals : MainFrames.Totals)
    (i : Nat) (arena : NatArena.Arena) (bound : i < 2^32) :
    evalExpr Header.layout call 2 (MainCellAPI.before totals i arena) (guard logs) =
      some (Machine.boolean Header.layout (decide (i < limit logs)),
        MainCellAPI.before totals i arena) :=
  ExpressionTemplates.binary Header.layout call
    (by decide) (by decide) (by decide) (by decide)
    (read_index call totals i arena) (read_limit call logs totals i arena)
    (PoolCalls.binary_lt (MainCellAPI.before totals i arena) i (limit logs)
      bound (by cases logs <;> decide))

theorem source_guard (logs : Bool) (totals : MainFrames.Totals) (i : Nat)
    (arena : NatArena.Arena) (bound : i < 2^32) :
    ArraySourceCalls.Eval Header.layout MainLn2.service (guard logs)
      (MainCellAPI.before totals i arena) (MainCellAPI.before totals i arena)
      (Machine.boolean Header.layout (decide (i < limit logs))) :=
  ⟨2,actual_guard MainLn2.service logs totals i arena bound⟩

theorem actual_loop_statement (logs : Bool) :
    MainLn2.statements[if logs then 11 else 9]? =
      some (.whileLoop (guard logs) (.sequence (MainCellAPI.body logs))) := by
  cases logs <;> rfl

def Rows (logs : Bool) (totals : Nat → MainFrames.Totals) (arena : NatArena.Arena) : Prop :=
  ∀ i, i < limit logs → ArraySourceCalls.Run Header.layout MainLn2.service
    (.sequence (MainCellAPI.body logs)) (MainCellAPI.before (totals i) i arena)
    (.continuing (MainCellAPI.before (totals (i+1)) (i+1) arena))

theorem while_suffix (logs : Bool) (totals : Nat → MainFrames.Totals)
    (arena : NatArena.Arena) (rows : Rows logs totals arena)
    (remaining i : Nat) (endpoint : i+remaining = limit logs) :
    Loops.WhileRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      (guard logs) (.sequence (MainCellAPI.body logs))
      (MainCellAPI.before (totals i) i arena)
      (.continuing (MainCellAPI.before (totals (limit logs)) (limit logs) arena)) := by
  have small : limit logs < 2^32 := by cases logs <;> decide
  induction remaining generalizing i with
  | zero =>
    have last : i = limit logs := by omega
    subst i
    exact .done (source_guard logs (totals (limit logs)) (limit logs) arena small)
      (by have truthBoolean (b : Bool) :
            truth (Machine.boolean Header.layout b) = b := by cases b <;> rfl
          rw [truthBoolean]
          simp)
  | succ remaining ih =>
    have hi : i < limit logs := by omega
    exact .next (source_guard logs (totals i) i arena (by omega))
      (by have truthBoolean (b : Bool) :
            truth (Machine.boolean Header.layout b) = b := by cases b <;> rfl
          rw [truthBoolean]
          exact decide_eq_true hi)
      (rows i hi) (ih (i+1) (by omega))

theorem actual_while (logs : Bool) (totals : Nat → MainFrames.Totals)
    (arena : NatArena.Arena) (rows : Rows logs totals arena) :
    ArraySourceCalls.Run Header.layout MainLn2.service
      (.whileLoop (guard logs) (.sequence (MainCellAPI.body logs)))
      (MainCellAPI.before (totals 0) 0 arena)
      (.continuing (MainCellAPI.before (totals (limit logs)) (limit logs) arena)) :=
  Loops.StmtRun.whileLoop (while_suffix logs totals arena rows (limit logs) 0 (by omega))

#print axioms read_index
#print axioms read_limit
#print axioms actual_guard
#print axioms source_guard
#print axioms actual_loop_statement
#print axioms while_suffix
#print axioms actual_while
end SynergyTangentV2C.MainLoops
