/- Exact cumulative sums, using the corresponding accepted fixed-cell model equations. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Shared192
import SynergyTangentV2C.SourceCells.Shared193
import SynergyTangentV2C.SourceCells.Shared194
import SynergyTangentV2C.SourceCells.Shared195
import SynergyTangentV2C.SourceCells.Shared196
import SynergyTangentV2C.SourceCells.Shared197
import SynergyTangentV2C.SourceCells.Shared198
import SynergyTangentV2C.SourceCells.Shared199
import SynergyTangentV2C.SourceCells.Shared200
import SynergyTangentV2C.SourceCells.Shared201
import SynergyTangentV2C.SourceCells.Shared202
import SynergyTangentV2C.SourceCells.Shared203
import SynergyTangentV2C.SourceCells.Shared204
import SynergyTangentV2C.SourceCells.Shared205
import SynergyTangentV2C.SourceCells.Shared206
import SynergyTangentV2C.SourceCells.Shared207
import SynergyTangentV2C.SourceCells.Shared208
import SynergyTangentV2C.SourceCells.Shared209
import SynergyTangentV2C.SourceCells.Shared210
import SynergyTangentV2C.SourceCells.Shared211
import SynergyTangentV2C.SourceCells.Shared212
import SynergyTangentV2C.SourceCells.Shared213
import SynergyTangentV2C.SourceCells.Shared214
import SynergyTangentV2C.SourceCells.Shared215
import SynergyTangentV2C.SourceCells.Shared216
import SynergyTangentV2C.SourceCells.Shared217
import SynergyTangentV2C.SourceCells.Shared218
import SynergyTangentV2C.SourceCells.Shared219
import SynergyTangentV2C.SourceCells.Shared220
import SynergyTangentV2C.SourceCells.Shared221
import SynergyTangentV2C.SourceCells.Shared222
import SynergyTangentV2C.SourceCells.Shared223
namespace SynergyTangentV2C.CellSharedTotals.Block06
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.sharedOnlyTotals
theorem sum192 :
    (ProofBox.add (totals 192).1 SourceCells.Shared192.output.1,
     ProofBox.add (totals 192).2.1 SourceCells.Shared192.output.2.1,
     ProofBox.add (totals 192).2.2 SourceCells.Shared192.output.2.2)=totals 193 := by
  decide +kernel
#print axioms sum192
theorem sum193 :
    (ProofBox.add (totals 193).1 SourceCells.Shared193.output.1,
     ProofBox.add (totals 193).2.1 SourceCells.Shared193.output.2.1,
     ProofBox.add (totals 193).2.2 SourceCells.Shared193.output.2.2)=totals 194 := by
  decide +kernel
#print axioms sum193
theorem sum194 :
    (ProofBox.add (totals 194).1 SourceCells.Shared194.output.1,
     ProofBox.add (totals 194).2.1 SourceCells.Shared194.output.2.1,
     ProofBox.add (totals 194).2.2 SourceCells.Shared194.output.2.2)=totals 195 := by
  decide +kernel
#print axioms sum194
theorem sum195 :
    (ProofBox.add (totals 195).1 SourceCells.Shared195.output.1,
     ProofBox.add (totals 195).2.1 SourceCells.Shared195.output.2.1,
     ProofBox.add (totals 195).2.2 SourceCells.Shared195.output.2.2)=totals 196 := by
  decide +kernel
#print axioms sum195
theorem sum196 :
    (ProofBox.add (totals 196).1 SourceCells.Shared196.output.1,
     ProofBox.add (totals 196).2.1 SourceCells.Shared196.output.2.1,
     ProofBox.add (totals 196).2.2 SourceCells.Shared196.output.2.2)=totals 197 := by
  decide +kernel
#print axioms sum196
theorem sum197 :
    (ProofBox.add (totals 197).1 SourceCells.Shared197.output.1,
     ProofBox.add (totals 197).2.1 SourceCells.Shared197.output.2.1,
     ProofBox.add (totals 197).2.2 SourceCells.Shared197.output.2.2)=totals 198 := by
  decide +kernel
#print axioms sum197
theorem sum198 :
    (ProofBox.add (totals 198).1 SourceCells.Shared198.output.1,
     ProofBox.add (totals 198).2.1 SourceCells.Shared198.output.2.1,
     ProofBox.add (totals 198).2.2 SourceCells.Shared198.output.2.2)=totals 199 := by
  decide +kernel
#print axioms sum198
theorem sum199 :
    (ProofBox.add (totals 199).1 SourceCells.Shared199.output.1,
     ProofBox.add (totals 199).2.1 SourceCells.Shared199.output.2.1,
     ProofBox.add (totals 199).2.2 SourceCells.Shared199.output.2.2)=totals 200 := by
  decide +kernel
#print axioms sum199
theorem sum200 :
    (ProofBox.add (totals 200).1 SourceCells.Shared200.output.1,
     ProofBox.add (totals 200).2.1 SourceCells.Shared200.output.2.1,
     ProofBox.add (totals 200).2.2 SourceCells.Shared200.output.2.2)=totals 201 := by
  decide +kernel
#print axioms sum200
theorem sum201 :
    (ProofBox.add (totals 201).1 SourceCells.Shared201.output.1,
     ProofBox.add (totals 201).2.1 SourceCells.Shared201.output.2.1,
     ProofBox.add (totals 201).2.2 SourceCells.Shared201.output.2.2)=totals 202 := by
  decide +kernel
#print axioms sum201
theorem sum202 :
    (ProofBox.add (totals 202).1 SourceCells.Shared202.output.1,
     ProofBox.add (totals 202).2.1 SourceCells.Shared202.output.2.1,
     ProofBox.add (totals 202).2.2 SourceCells.Shared202.output.2.2)=totals 203 := by
  decide +kernel
#print axioms sum202
theorem sum203 :
    (ProofBox.add (totals 203).1 SourceCells.Shared203.output.1,
     ProofBox.add (totals 203).2.1 SourceCells.Shared203.output.2.1,
     ProofBox.add (totals 203).2.2 SourceCells.Shared203.output.2.2)=totals 204 := by
  decide +kernel
#print axioms sum203
theorem sum204 :
    (ProofBox.add (totals 204).1 SourceCells.Shared204.output.1,
     ProofBox.add (totals 204).2.1 SourceCells.Shared204.output.2.1,
     ProofBox.add (totals 204).2.2 SourceCells.Shared204.output.2.2)=totals 205 := by
  decide +kernel
#print axioms sum204
theorem sum205 :
    (ProofBox.add (totals 205).1 SourceCells.Shared205.output.1,
     ProofBox.add (totals 205).2.1 SourceCells.Shared205.output.2.1,
     ProofBox.add (totals 205).2.2 SourceCells.Shared205.output.2.2)=totals 206 := by
  decide +kernel
#print axioms sum205
theorem sum206 :
    (ProofBox.add (totals 206).1 SourceCells.Shared206.output.1,
     ProofBox.add (totals 206).2.1 SourceCells.Shared206.output.2.1,
     ProofBox.add (totals 206).2.2 SourceCells.Shared206.output.2.2)=totals 207 := by
  decide +kernel
#print axioms sum206
theorem sum207 :
    (ProofBox.add (totals 207).1 SourceCells.Shared207.output.1,
     ProofBox.add (totals 207).2.1 SourceCells.Shared207.output.2.1,
     ProofBox.add (totals 207).2.2 SourceCells.Shared207.output.2.2)=totals 208 := by
  decide +kernel
#print axioms sum207
theorem sum208 :
    (ProofBox.add (totals 208).1 SourceCells.Shared208.output.1,
     ProofBox.add (totals 208).2.1 SourceCells.Shared208.output.2.1,
     ProofBox.add (totals 208).2.2 SourceCells.Shared208.output.2.2)=totals 209 := by
  decide +kernel
#print axioms sum208
theorem sum209 :
    (ProofBox.add (totals 209).1 SourceCells.Shared209.output.1,
     ProofBox.add (totals 209).2.1 SourceCells.Shared209.output.2.1,
     ProofBox.add (totals 209).2.2 SourceCells.Shared209.output.2.2)=totals 210 := by
  decide +kernel
#print axioms sum209
theorem sum210 :
    (ProofBox.add (totals 210).1 SourceCells.Shared210.output.1,
     ProofBox.add (totals 210).2.1 SourceCells.Shared210.output.2.1,
     ProofBox.add (totals 210).2.2 SourceCells.Shared210.output.2.2)=totals 211 := by
  decide +kernel
#print axioms sum210
theorem sum211 :
    (ProofBox.add (totals 211).1 SourceCells.Shared211.output.1,
     ProofBox.add (totals 211).2.1 SourceCells.Shared211.output.2.1,
     ProofBox.add (totals 211).2.2 SourceCells.Shared211.output.2.2)=totals 212 := by
  decide +kernel
#print axioms sum211
theorem sum212 :
    (ProofBox.add (totals 212).1 SourceCells.Shared212.output.1,
     ProofBox.add (totals 212).2.1 SourceCells.Shared212.output.2.1,
     ProofBox.add (totals 212).2.2 SourceCells.Shared212.output.2.2)=totals 213 := by
  decide +kernel
#print axioms sum212
theorem sum213 :
    (ProofBox.add (totals 213).1 SourceCells.Shared213.output.1,
     ProofBox.add (totals 213).2.1 SourceCells.Shared213.output.2.1,
     ProofBox.add (totals 213).2.2 SourceCells.Shared213.output.2.2)=totals 214 := by
  decide +kernel
#print axioms sum213
theorem sum214 :
    (ProofBox.add (totals 214).1 SourceCells.Shared214.output.1,
     ProofBox.add (totals 214).2.1 SourceCells.Shared214.output.2.1,
     ProofBox.add (totals 214).2.2 SourceCells.Shared214.output.2.2)=totals 215 := by
  decide +kernel
#print axioms sum214
theorem sum215 :
    (ProofBox.add (totals 215).1 SourceCells.Shared215.output.1,
     ProofBox.add (totals 215).2.1 SourceCells.Shared215.output.2.1,
     ProofBox.add (totals 215).2.2 SourceCells.Shared215.output.2.2)=totals 216 := by
  decide +kernel
#print axioms sum215
theorem sum216 :
    (ProofBox.add (totals 216).1 SourceCells.Shared216.output.1,
     ProofBox.add (totals 216).2.1 SourceCells.Shared216.output.2.1,
     ProofBox.add (totals 216).2.2 SourceCells.Shared216.output.2.2)=totals 217 := by
  decide +kernel
#print axioms sum216
theorem sum217 :
    (ProofBox.add (totals 217).1 SourceCells.Shared217.output.1,
     ProofBox.add (totals 217).2.1 SourceCells.Shared217.output.2.1,
     ProofBox.add (totals 217).2.2 SourceCells.Shared217.output.2.2)=totals 218 := by
  decide +kernel
#print axioms sum217
theorem sum218 :
    (ProofBox.add (totals 218).1 SourceCells.Shared218.output.1,
     ProofBox.add (totals 218).2.1 SourceCells.Shared218.output.2.1,
     ProofBox.add (totals 218).2.2 SourceCells.Shared218.output.2.2)=totals 219 := by
  decide +kernel
#print axioms sum218
theorem sum219 :
    (ProofBox.add (totals 219).1 SourceCells.Shared219.output.1,
     ProofBox.add (totals 219).2.1 SourceCells.Shared219.output.2.1,
     ProofBox.add (totals 219).2.2 SourceCells.Shared219.output.2.2)=totals 220 := by
  decide +kernel
#print axioms sum219
theorem sum220 :
    (ProofBox.add (totals 220).1 SourceCells.Shared220.output.1,
     ProofBox.add (totals 220).2.1 SourceCells.Shared220.output.2.1,
     ProofBox.add (totals 220).2.2 SourceCells.Shared220.output.2.2)=totals 221 := by
  decide +kernel
#print axioms sum220
theorem sum221 :
    (ProofBox.add (totals 221).1 SourceCells.Shared221.output.1,
     ProofBox.add (totals 221).2.1 SourceCells.Shared221.output.2.1,
     ProofBox.add (totals 221).2.2 SourceCells.Shared221.output.2.2)=totals 222 := by
  decide +kernel
#print axioms sum221
theorem sum222 :
    (ProofBox.add (totals 222).1 SourceCells.Shared222.output.1,
     ProofBox.add (totals 222).2.1 SourceCells.Shared222.output.2.1,
     ProofBox.add (totals 222).2.2 SourceCells.Shared222.output.2.2)=totals 223 := by
  decide +kernel
#print axioms sum222
theorem sum223 :
    (ProofBox.add (totals 223).1 SourceCells.Shared223.output.1,
     ProofBox.add (totals 223).2.1 SourceCells.Shared223.output.2.1,
     ProofBox.add (totals 223).2.2 SourceCells.Shared223.output.2.2)=totals 224 := by
  decide +kernel
#print axioms sum223
theorem advance (old : SynergyAnalytic.BoxModel.sharedFold 256 192=some (totals 192)) :
    SynergyAnalytic.BoxModel.sharedFold 256 224=some (totals 224) := by
  have fold192 := old
  have fold193 := (CellFoldSteps.shared_next 192 _ _ fold192
    SourceCells.Shared192.model_eq).trans (congrArg some sum192)
  have fold194 := (CellFoldSteps.shared_next 193 _ _ fold193
    SourceCells.Shared193.model_eq).trans (congrArg some sum193)
  have fold195 := (CellFoldSteps.shared_next 194 _ _ fold194
    SourceCells.Shared194.model_eq).trans (congrArg some sum194)
  have fold196 := (CellFoldSteps.shared_next 195 _ _ fold195
    SourceCells.Shared195.model_eq).trans (congrArg some sum195)
  have fold197 := (CellFoldSteps.shared_next 196 _ _ fold196
    SourceCells.Shared196.model_eq).trans (congrArg some sum196)
  have fold198 := (CellFoldSteps.shared_next 197 _ _ fold197
    SourceCells.Shared197.model_eq).trans (congrArg some sum197)
  have fold199 := (CellFoldSteps.shared_next 198 _ _ fold198
    SourceCells.Shared198.model_eq).trans (congrArg some sum198)
  have fold200 := (CellFoldSteps.shared_next 199 _ _ fold199
    SourceCells.Shared199.model_eq).trans (congrArg some sum199)
  have fold201 := (CellFoldSteps.shared_next 200 _ _ fold200
    SourceCells.Shared200.model_eq).trans (congrArg some sum200)
  have fold202 := (CellFoldSteps.shared_next 201 _ _ fold201
    SourceCells.Shared201.model_eq).trans (congrArg some sum201)
  have fold203 := (CellFoldSteps.shared_next 202 _ _ fold202
    SourceCells.Shared202.model_eq).trans (congrArg some sum202)
  have fold204 := (CellFoldSteps.shared_next 203 _ _ fold203
    SourceCells.Shared203.model_eq).trans (congrArg some sum203)
  have fold205 := (CellFoldSteps.shared_next 204 _ _ fold204
    SourceCells.Shared204.model_eq).trans (congrArg some sum204)
  have fold206 := (CellFoldSteps.shared_next 205 _ _ fold205
    SourceCells.Shared205.model_eq).trans (congrArg some sum205)
  have fold207 := (CellFoldSteps.shared_next 206 _ _ fold206
    SourceCells.Shared206.model_eq).trans (congrArg some sum206)
  have fold208 := (CellFoldSteps.shared_next 207 _ _ fold207
    SourceCells.Shared207.model_eq).trans (congrArg some sum207)
  have fold209 := (CellFoldSteps.shared_next 208 _ _ fold208
    SourceCells.Shared208.model_eq).trans (congrArg some sum208)
  have fold210 := (CellFoldSteps.shared_next 209 _ _ fold209
    SourceCells.Shared209.model_eq).trans (congrArg some sum209)
  have fold211 := (CellFoldSteps.shared_next 210 _ _ fold210
    SourceCells.Shared210.model_eq).trans (congrArg some sum210)
  have fold212 := (CellFoldSteps.shared_next 211 _ _ fold211
    SourceCells.Shared211.model_eq).trans (congrArg some sum211)
  have fold213 := (CellFoldSteps.shared_next 212 _ _ fold212
    SourceCells.Shared212.model_eq).trans (congrArg some sum212)
  have fold214 := (CellFoldSteps.shared_next 213 _ _ fold213
    SourceCells.Shared213.model_eq).trans (congrArg some sum213)
  have fold215 := (CellFoldSteps.shared_next 214 _ _ fold214
    SourceCells.Shared214.model_eq).trans (congrArg some sum214)
  have fold216 := (CellFoldSteps.shared_next 215 _ _ fold215
    SourceCells.Shared215.model_eq).trans (congrArg some sum215)
  have fold217 := (CellFoldSteps.shared_next 216 _ _ fold216
    SourceCells.Shared216.model_eq).trans (congrArg some sum216)
  have fold218 := (CellFoldSteps.shared_next 217 _ _ fold217
    SourceCells.Shared217.model_eq).trans (congrArg some sum217)
  have fold219 := (CellFoldSteps.shared_next 218 _ _ fold218
    SourceCells.Shared218.model_eq).trans (congrArg some sum218)
  have fold220 := (CellFoldSteps.shared_next 219 _ _ fold219
    SourceCells.Shared219.model_eq).trans (congrArg some sum219)
  have fold221 := (CellFoldSteps.shared_next 220 _ _ fold220
    SourceCells.Shared220.model_eq).trans (congrArg some sum220)
  have fold222 := (CellFoldSteps.shared_next 221 _ _ fold221
    SourceCells.Shared221.model_eq).trans (congrArg some sum221)
  have fold223 := (CellFoldSteps.shared_next 222 _ _ fold222
    SourceCells.Shared222.model_eq).trans (congrArg some sum222)
  have fold224 := (CellFoldSteps.shared_next 223 _ _ fold223
    SourceCells.Shared223.model_eq).trans (congrArg some sum223)
  exact fold224
#print axioms advance
end SynergyTangentV2C.CellSharedTotals.Block06
