/- Pure model correspondence for the SAME actual source-verified footer words.
This module recomputes no finite cell family and imports no old FullKernel. -/
import SynergyTangentV2C.CellTotalModel
import SynergyTangentV2C.MainFooter
namespace SynergyTangentV2C.CellFooterModel
open ScopedNumerical ScopedNumerical.ProofBox SynergyBasis SynergyBasis.Positive
open SynergyAnalytic.BoxModel
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 1024

def logarithm : ProofBox :=
  (logPos 384 (mul p (rat 6 1) (rat 601 2500))).getD zero
def exponential : ProofBox :=
  (safeExp (mul p (rat 256 1) (rat 601 2500))).getD zero

theorem log_model : logPos 384 (mul p (rat 6 1) (rat 601 2500))=some logarithm := by
  decide +kernel
theorem peak_model : safeExp (divN (add one logarithm) 6)=some MainFooter.peak := by
  decide +kernel
theorem exp_model : safeExp (mul p (rat 256 1) (rat 601 2500))=some exponential := by
  decide +kernel
theorem tail_model : safeDiv
    (mul p exponential (add (mul p (rat 256 1) (rat 601 2500)) one))
    (mul p (rat 2 1) (mul p (rat 601 2500) (rat 601 2500)))=some MainFooter.tail := by
  decide +kernel
theorem finish_exact : CellTotalModel.finish (CellTotalsData.prefixTotals 16).1
    (CellTotalsData.sharedOnlyTotals 256) MainFooter.peak MainFooter.tail=MainFooter.output := by
  decide +kernel

theorem total_from_folds
    (prefixComplete : prefixFold 16 16=some (CellTotalsData.prefixTotals 16).1)
    (sharedComplete : sharedFold 256 256=some (CellTotalsData.sharedOnlyTotals 256)) :
    sourceBasis 256=some MainFooter.output :=
  (CellTotalModel.model_from_folds _ _ logarithm MainFooter.peak exponential MainFooter.tail
    prefixComplete sharedComplete log_model peak_model exp_model tail_model).trans
      (congrArg some finish_exact)

#print axioms log_model
#print axioms peak_model
#print axioms exp_model
#print axioms tail_model
#print axioms finish_exact
#print axioms total_from_folds
end SynergyTangentV2C.CellFooterModel
