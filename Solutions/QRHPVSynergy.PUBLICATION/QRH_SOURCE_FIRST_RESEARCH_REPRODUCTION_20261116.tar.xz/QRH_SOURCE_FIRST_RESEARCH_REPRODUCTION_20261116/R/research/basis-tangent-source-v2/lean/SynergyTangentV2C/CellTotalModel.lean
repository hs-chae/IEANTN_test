/- Assemble the unchanged mathematical total from independently proved cell
folds and footer computations. No old FullKernel/CertifiedBasis import. -/
import SynergyAnalytic.TangentTotals
import SynergyTangentV2C.MainFrames
namespace SynergyTangentV2C.CellTotalModel
open ScopedNumerical ScopedNumerical.ProofBox SynergyBasis SynergyBasis.Positive
open SynergyAnalytic.BoxModel
set_option autoImplicit false
set_option maxHeartbeats 0

def finish (preValue : ProofBox) (common : MainFrames.Totals)
    (peakValue tailValue : ProofBox) : MainFrames.Totals :=
  (add (add (add preValue common.1) (mul p (rat 5 6) peakValue)) tailValue,
   add common.2.1 tailValue,add common.2.2 tailValue)

theorem model_from_folds (preValue : ProofBox) (common : MainFrames.Totals)
    (logValue peakValue eValue tailValue : ProofBox)
    (pre : prefixFold 16 16=some preValue)
    (shared : sharedFold 256 256=some common)
    (logarithm : logPos 384 (mul p (rat 6 1) (rat 601 2500))=some logValue)
    (peak : safeExp (divN (add one logValue) 6)=some peakValue)
    (exponential : safeExp (mul p (rat 256 1) (rat 601 2500))=some eValue)
    (tail : safeDiv
      (mul p eValue (add (mul p (rat 256 1) (rat 601 2500)) one))
      (mul p (rat 2 1) (mul p (rat 601 2500) (rat 601 2500)))=some tailValue) :
    sourceBasis 256=some (finish preValue common peakValue tailValue) := by
  change (do
    let first ← prefixFold 16 16
    let total ← sharedFold 256 256
    let logResult ← logPos 384 (mul p (rat 6 1) (rat 601 2500))
    let peakResult ← safeExp (divN (add one logResult) 6)
    let expResult ← safeExp (mul p (rat 256 1) (rat 601 2500))
    let tailResult ← safeDiv
      (mul p expResult (add (mul p (rat 256 1) (rat 601 2500)) one))
      (mul p (rat 2 1) (mul p (rat 601 2500) (rat 601 2500)))
    pure (finish first total peakResult tailResult)) = _
  simp only [pre,shared,logarithm,peak,exponential,tail,
    Option.bind_eq_bind,Option.bind_some,Option.pure_def]

#print axioms model_from_folds
end SynergyTangentV2C.CellTotalModel
