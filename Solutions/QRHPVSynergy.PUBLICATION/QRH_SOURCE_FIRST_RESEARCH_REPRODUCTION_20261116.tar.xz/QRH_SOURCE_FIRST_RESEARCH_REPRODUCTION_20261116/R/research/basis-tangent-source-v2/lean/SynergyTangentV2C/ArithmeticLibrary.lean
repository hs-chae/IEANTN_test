import SynergyTangentV2C.Bundle
import SynergyC.ComputableFullService
import ScopedC.ContractExecute
namespace SynergyTangentV2C.ArithmeticLibrary
open ScopedC ScopedC.Syntax ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev code := Generated.functions
theorem shared_zero : Generated.f_zero = SynergyC.Generated.f_zero := by rfl
theorem installed_zero : SynergyC.Generated.f_zero ∈ code := by
  rw [←shared_zero]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self))))))
#print axioms shared_zero
#print axioms installed_zero
theorem shared_unit : Generated.f_unit = SynergyC.Generated.f_unit := by rfl
theorem installed_unit : SynergyC.Generated.f_unit ∈ code := by
  rw [←shared_unit]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self)))))
#print axioms shared_unit
#print axioms installed_unit
theorem shared_add : Generated.f_add = SynergyC.Generated.f_add := by rfl
theorem installed_add : SynergyC.Generated.f_add ∈ code := by
  rw [←shared_add]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self)))))))
#print axioms shared_add
#print axioms installed_add
theorem shared_mul : Generated.f_mul = SynergyC.Generated.f_mul := by rfl
theorem installed_mul : SynergyC.Generated.f_mul ∈ code := by
  rw [←shared_mul]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self))))))))
#print axioms shared_mul
#print axioms installed_mul
theorem shared_divI : Generated.f_divI = SynergyC.Generated.f_divI := by rfl
theorem installed_divI : SynergyC.Generated.f_divI ∈ code := by
  rw [←shared_divI]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self)))))))))
#print axioms shared_divI
#print axioms installed_divI
theorem shared_divN : Generated.f_divN = SynergyC.Generated.f_divN := by rfl
theorem installed_divN : SynergyC.Generated.f_divN ∈ code := by
  rw [←shared_divN]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self))))))))))
#print axioms shared_divN
#print axioms installed_divN
theorem shared_positiveSub : Generated.f_positiveSub = SynergyC.Generated.f_positiveSub := by rfl
theorem installed_positiveSub : SynergyC.Generated.f_positiveSub ∈ code := by
  rw [←shared_positiveSub]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self)))))))))))
#print axioms shared_positiveSub
#print axioms installed_positiveSub
theorem shared_rat : Generated.f_rat = SynergyC.Generated.f_rat := by rfl
theorem installed_rat : SynergyC.Generated.f_rat ∈ code := by
  rw [←shared_rat]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self))))
#print axioms shared_rat
#print axioms installed_rat
theorem shared_addU : Generated.f_addU = SynergyC.Generated.f_addU := by rfl
theorem installed_addU : SynergyC.Generated.f_addU ∈ code := by
  rw [←shared_addU]
  exact List.mem_cons_of_mem _ (List.mem_cons_self)
#print axioms shared_addU
#print axioms installed_addU
theorem shared_mulU : Generated.f_mulU = SynergyC.Generated.f_mulU := by rfl
theorem installed_mulU : SynergyC.Generated.f_mulU ∈ code := by
  rw [←shared_mulU]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self))
#print axioms shared_mulU
#print axioms installed_mulU
theorem shared_ceilDiv : Generated.f_ceilDiv = SynergyC.Generated.f_ceilDiv := by rfl
theorem installed_ceilDiv : SynergyC.Generated.f_ceilDiv ∈ code := by
  rw [←shared_ceilDiv]
  exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self)))
#print axioms shared_ceilDiv
#print axioms installed_ceilDiv
theorem arithmetic_parameters : SynergyC.ArithmeticService.parameters code = true := by decide +kernel
theorem mixed_parameters : SynergyC.ComputableIntervalService.parameters code = true := by decide +kernel
def library : SynergyC.ComputableIntervalService.Library code := {
  zero := installed_zero
  unit := installed_unit
  add := installed_add
  mul := installed_mul
  divI := installed_divI
  divN := installed_divN
  positiveSub := installed_positiveSub
  rat := installed_rat
  addU := installed_addU
  mulU := installed_mulU
  ceilDiv := installed_ceilDiv
  arithmeticParameters := arithmetic_parameters
  mixedParameters := mixed_parameters}
theorem closed {name : String} {args : List Value} {before after : State} {value : Value}
    (h : SynergyC.ComputableFullService.call name args before = some (value,after)) :
    ArraySourceCalls.SourceCall SynergyC.Header.layout code 3 name args before value after :=
  SynergyC.ComputableFullService.array_closed code library h
#print axioms arithmetic_parameters
#print axioms mixed_parameters
#print axioms closed
end SynergyTangentV2C.ArithmeticLibrary
