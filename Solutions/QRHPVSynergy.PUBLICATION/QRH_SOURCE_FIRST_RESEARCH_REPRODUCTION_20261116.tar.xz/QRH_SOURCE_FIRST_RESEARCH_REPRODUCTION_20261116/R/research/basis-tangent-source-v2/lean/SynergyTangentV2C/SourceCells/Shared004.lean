/- Fixed original shared cell4. Numerical words are proposals;
all three proofs below must pass ordinary declaration kernel checking. -/
import SynergyTangentV2C.CellExecutionExact
import SynergyTangentV2C.MainFrames
import ScopedC.ArrayStages
open Lean Meta Elab Tactic
namespace SynergyTangentV2C.SourceCells.Shared004
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 300000
set_option exponentiation.threshold 1024
def left : ProofBox := SynergyAnalytic.BoxModel.rat 316 256
def width : ProofBox := SynergyAnalytic.BoxModel.rat 15 256
def output : MainFrames.Totals :=
  (⟨14689965669368952683485398886448718373,14689965669368952683485398886448719222⟩,
   ⟨3440756498255849697008036345331502854,3440756498255849697008036345331505150⟩,
   ⟨808669361433842143867264473931181870,808669361433842143867264473931192117⟩)
def base (totals : MainFrames.Totals) (arena : NatArena.Arena) : Machine.State :=
  ArrayStages.withArena (MainFrames.base totals 4 left) arena
theorem model_eq : SynergyAnalytic.BoxModel.sourceCell left width true=some output := by
  decide +kernel
theorem execution (totals : MainFrames.Totals) (arena : NatArena.Arena) :
    CellExecute.run (base totals arena) left width true=
      some (.unit,CellExecute.filled (base totals arena) output) := by
  unfold CellExecute.run
  run_tac do
    let goal ← getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual source execution equality"
    goal.assign (← mkEqRefl args[1]!)
theorem actual_source (totals : MainFrames.Totals) (arena : NatArena.Arena) :
    ArraySourceCalls.SourceCall Header.layout Bundle.code 16 "tangentCell"
      (CellExecute.args (base totals arena) left width true)
      (CellExecute.buffers (base totals arena)) .unit
      (CellExecute.filled (base totals arena) output) :=
  CellExecutionExact.source_of_execution (execution totals arena)
#print axioms model_eq
#print axioms execution
#print axioms actual_source
end SynergyTangentV2C.SourceCells.Shared004
