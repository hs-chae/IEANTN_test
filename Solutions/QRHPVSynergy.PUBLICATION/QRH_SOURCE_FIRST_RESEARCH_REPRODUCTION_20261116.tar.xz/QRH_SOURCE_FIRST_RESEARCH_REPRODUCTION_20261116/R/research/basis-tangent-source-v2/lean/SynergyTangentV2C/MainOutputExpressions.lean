/- Exact actual C reads, casts, guards, index stores, and emitter argument flow. -/
import SynergyTangentV2C.MainOutputData
import SynergyTangentV2C.MainWorldService
namespace SynergyTangentV2C.MainOutputExpressions
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical ScopedIO ScopedIO.WorldIO
open MainOutputData
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

theorem cells : evalExpr Header.layout MainLn2.service 128 MainFooter.after
    (.cast "U" (.var "cells")) = some (SynergyC.Word512.value (word 0),MainFooter.after) := by
  rfl
theorem prefix_value : evalExpr Header.layout MainLn2.service 128 MainFooter.after
    (.cast "U" (.var "prefix")) = some (SynergyC.Word512.value (word 1),MainFooter.after) := by
  rfl
theorem read_lo (i : Nat) (hi : i < 3) :
    evalExpr Header.layout MainLn2.service 128 (atIndex i) loExpr =
      some (SynergyC.Word512.value (word (2+2*i)),atIndex i) := by
  interval_cases i <;> rfl
theorem read_hi (i : Nat) (hi : i < 3) :
    evalExpr Header.layout MainLn2.service 128 (atIndex i) hiExpr =
      some (SynergyC.Word512.value (word (2+2*i+1)),atIndex i) := by
  interval_cases i <;> rfl
theorem reset : evalExpr Header.layout MainLn2.service 128 MainFooter.after
    (.binary "=" (.var "i") (.nat 0)) =
      some (MainFrames.unsigned 0,atIndex 0) := by rfl
theorem increment (i : Nat) (hi : i < 3) :
    evalExpr Header.layout MainLn2.service 128 (atIndex i)
      (.binary "=" (.var "i") (.binary "+" (.var "i") (.nat 1))) =
      some (MainFrames.unsigned (i+1),atIndex (i+1)) := by
  interval_cases i <;> rfl
theorem guard_value (i : Nat) (hi : i ≤ 3) :
    evalExpr Header.layout MainLn2.service 128 (atIndex i) guard =
      some (Machine.boolean Header.layout (decide (i<3)),atIndex i) := by
  interval_cases i <;> rfl

theorem source_emit (platform : Platform) (state : State) (stream : Stream)
    (e : Expr) (x : Int) (range : SynergyC.Word512.Range x)
    (stdout : state.globals.lookup "stdout" = none)
    (argument : evalExpr Header.layout MainLn2.service 128 state e =
      some (SynergyC.Word512.value x,state)) :
    WorldSource.Run Header.layout MainLn2.service (MainWorldService.call platform) platform
      (.eval (.call (.var "emitU") [e])) ⟨state,stream⟩
      (.continuing ⟨state,EmitUNormal.appendWord stream x⟩) :=
  Loops.StmtRun.evaluate (WorldSource.Eval.call
    (.cons (.pure argument) (.nil _))
    (MainWorldService.emit_success platform state x range stream stdout))

#print axioms cells
#print axioms prefix_value
#print axioms read_lo
#print axioms read_hi
#print axioms reset
#print axioms increment
#print axioms guard_value
#print axioms source_emit
end SynergyTangentV2C.MainOutputExpressions
