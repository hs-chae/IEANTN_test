/- Exact source execution retains arbitrary untouched caller totals. Numerical
state proposals acquire authority only through the actual AST execution equality. -/
import SynergyTangentV2C.CellExecute
namespace SynergyTangentV2C.CellExecutionExact
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem source_of_execution {base : State} {left width : ProofBox} {logs : Bool}
    {output : ProofBox × ProofBox × ProofBox}
    (execution : CellExecute.run base left width logs =
      some (.unit, CellExecute.filled base output)) :
    ArraySourceCalls.SourceCall SynergyC.Header.layout Bundle.code 16 "tangentCell"
      (CellExecute.args base left width logs) (CellExecute.buffers base) .unit
      (CellExecute.filled base output) := by
  have run_eq : CellExecute.run base left width logs =
      ContractExecute.execute SynergyC.Header.layout Generated.functions 128 2048
        SynergyC.ComputableFullService.call 13 "tangentCell"
        (CellExecute.args base left width logs) (CellExecute.buffers base) := by
    unfold CellExecute.run
    rfl
  have actual := ContractExecute.execute_sound
    (fun _ _ _ _ _ call => ArithmeticLibrary.closed call)
    (Eq.mp (congrArg (fun result => result =
      some (.unit, CellExecute.filled base output)) run_eq) execution)
  exact Eq.mpr (congrArg (fun code =>
    ArraySourceCalls.SourceCall SynergyC.Header.layout code 16 "tangentCell"
      (CellExecute.args base left width logs) (CellExecute.buffers base) .unit
      (CellExecute.filled base output)) Bundle.code_exact) actual

theorem read_zero (base : State) (output : ProofBox × ProofBox × ProofBox) :
    Machine.read SynergyC.Header.layout (CellExecute.filled base output)
      (CellExecute.address base 0) = some (CellExecute.represented output.1) := by
  simp [CellExecute.filled, CellExecute.address, allocate, Machine.read,
    nested, initialized, CellExecute.represented,
    SynergyC.SourceIntervalMath.represented, SynergyC.ZeroBody.interval,
    SynergyC.Word512.value, List.getElem?_append]

theorem read_one (base : State) (output : ProofBox × ProofBox × ProofBox) :
    Machine.read SynergyC.Header.layout (CellExecute.filled base output)
      (CellExecute.address base 1) = some (CellExecute.represented output.2.1) := by
  simp [CellExecute.filled, CellExecute.address, allocate, Machine.read,
    nested, initialized, CellExecute.represented,
    SynergyC.SourceIntervalMath.represented, SynergyC.ZeroBody.interval,
    SynergyC.Word512.value, List.getElem?_append]

theorem read_two (base : State) (output : ProofBox × ProofBox × ProofBox) :
    Machine.read SynergyC.Header.layout (CellExecute.filled base output)
      (CellExecute.address base 2) = some (CellExecute.represented output.2.2) := by
  simp [CellExecute.filled, CellExecute.address, allocate, Machine.read,
    nested, initialized, CellExecute.represented,
    SynergyC.SourceIntervalMath.represented, SynergyC.ZeroBody.interval,
    SynergyC.Word512.value, List.getElem?_append]

#print axioms source_of_execution
#print axioms read_zero
#print axioms read_one
#print axioms read_two
end SynergyTangentV2C.CellExecutionExact
