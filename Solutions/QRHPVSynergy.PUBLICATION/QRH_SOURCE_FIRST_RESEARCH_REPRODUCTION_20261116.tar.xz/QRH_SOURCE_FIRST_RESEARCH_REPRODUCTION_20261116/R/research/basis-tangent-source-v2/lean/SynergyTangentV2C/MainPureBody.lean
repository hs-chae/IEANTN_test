/- Actual C statements0..18 compose in one initialized main frame.
The only finite providers are the272 source rows, discharged separately. -/
import SynergyTangentV2C.MainHeaderExact
import SynergyTangentV2C.MainLoops
import SynergyTangentV2C.MainWorldLift
import SynergyTangentV2C.MainFooter
namespace SynergyTangentV2C.MainPureBody
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical ScopedIO ScopedIO.WorldIO
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def arena : NatArena.Arena := MainInitialization.initial.nats
abbrev PrefixRows := MainLoops.Rows false CellTotalsData.prefixTotals arena
abbrev SharedRows := MainLoops.Rows true CellTotalsData.sharedTotals arena

theorem actual_partition : MainLn2.statements.take 19 =
    MainLn2.statements.take 9 ++ ([
      .whileLoop (MainLoops.guard false) (.sequence (MainCellAPI.body false)),
      MainLn2.statements[10]?.getD .skip,
      .whileLoop (MainLoops.guard true) (.sequence (MainCellAPI.body true))] ++
      MainFooter.statements) := by rfl

theorem actual_source (prefixRows : PrefixRows) (sharedRows : SharedRows) :
    Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      (MainLn2.statements.take 19) MainInitialization.initial
      (.continuing MainFooter.after) := by
  have prefixLoop := MainLoops.actual_while false CellTotalsData.prefixTotals arena prefixRows
  have sharedLoop := MainLoops.actual_while true CellTotalsData.sharedTotals arena sharedRows
  have prefixLoop' : ArraySourceCalls.Run Header.layout MainLn2.service
      (.whileLoop (MainLoops.guard false) (.sequence (MainCellAPI.body false)))
      (MainFrames.before (CellTotalsData.prefixTotals 0) 0)
      (.continuing (MainFrames.before (CellTotalsData.prefixTotals 16) 16)) := prefixLoop
  have sharedLoop' : ArraySourceCalls.Run Header.layout MainLn2.service
      (.whileLoop (MainLoops.guard true) (.sequence (MainCellAPI.body true)))
      (MainFrames.before (CellTotalsData.sharedTotals 0) 0)
      (.continuing MainFooter.before) := sharedLoop
  have loops := Loops.SeqRun.next prefixLoop'
    (.next MainHeaderExact.actual_reset (.next sharedLoop' (.nil _)))
  have footer : Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      MainFooter.statements MainFooter.before (.continuing MainFooter.after) :=
    MainFooter.actual_source arena
  have all := MainCellAPI.seq_append MainHeaderExact.actual_header
    (MainCellAPI.seq_append loops footer)
  rw [← actual_partition] at all
  exact all

theorem world_source (prefixRows : PrefixRows) (sharedRows : SharedRows)
    (platform : Platform) (call : WorldIO.Call) (stream : Stream) :
    Loops.SeqRun (WorldSource.Eval Header.layout MainLn2.service call platform)
      (WorldSource.Declare Header.layout MainLn2.service) truth WorldSource.Scope
      (MainLn2.statements.take 19) ⟨MainInitialization.initial,stream⟩
      (.continuing ⟨MainFooter.after,stream⟩) :=
  MainWorldLift.statements (actual_source prefixRows sharedRows) stream

#print axioms actual_partition
#print axioms actual_source
#print axioms world_source
end SynergyTangentV2C.MainPureBody
