/- Actual l and zero-buffer declarations from the fixed C main. -/
import SynergyTangentV2C.MainCellAPI
namespace SynergyTangentV2C.MainEdges.Prefix00
open ScopedC ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024
theorem cell000 : MainCellAPI.ExactEdges false 0
    (SynergyAnalytic.BoxModel.rat 80 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell001 : MainCellAPI.ExactEdges false 1
    (SynergyAnalytic.BoxModel.rat 81 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell002 : MainCellAPI.ExactEdges false 2
    (SynergyAnalytic.BoxModel.rat 82 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell003 : MainCellAPI.ExactEdges false 3
    (SynergyAnalytic.BoxModel.rat 83 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell004 : MainCellAPI.ExactEdges false 4
    (SynergyAnalytic.BoxModel.rat 84 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell005 : MainCellAPI.ExactEdges false 5
    (SynergyAnalytic.BoxModel.rat 85 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell006 : MainCellAPI.ExactEdges false 6
    (SynergyAnalytic.BoxModel.rat 86 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell007 : MainCellAPI.ExactEdges false 7
    (SynergyAnalytic.BoxModel.rat 87 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell008 : MainCellAPI.ExactEdges false 8
    (SynergyAnalytic.BoxModel.rat 88 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell009 : MainCellAPI.ExactEdges false 9
    (SynergyAnalytic.BoxModel.rat 89 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell010 : MainCellAPI.ExactEdges false 10
    (SynergyAnalytic.BoxModel.rat 90 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell011 : MainCellAPI.ExactEdges false 11
    (SynergyAnalytic.BoxModel.rat 91 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell012 : MainCellAPI.ExactEdges false 12
    (SynergyAnalytic.BoxModel.rat 92 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell013 : MainCellAPI.ExactEdges false 13
    (SynergyAnalytic.BoxModel.rat 93 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell014 : MainCellAPI.ExactEdges false 14
    (SynergyAnalytic.BoxModel.rat 94 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell015 : MainCellAPI.ExactEdges false 15
    (SynergyAnalytic.BoxModel.rat 95 96) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell000
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell001
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell002
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell003
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell004
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell005
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell006
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell007
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell008
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell009
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell010
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell011
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell012
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell013
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell014
#print axioms SynergyTangentV2C.MainEdges.Prefix00.cell015
end SynergyTangentV2C.MainEdges.Prefix00
