/- Actual first main statement: compute ln2 by executing atanh2 and its
complete actual C callees. The proposed state is checked, not assumed. -/
import SynergyTangentV2C.MainInitialization
import SynergyTangentV2C.MainFrames
import ScopedC.ArrayStages
import ScopedC.ArraySourceCallExecute
import ScopedC.ContractExecute
import SynergyTangentV2C.ArithmeticLibrary
import SynergyBasis.PositiveLog
import SynergyC.SourceIntervalMath
namespace SynergyTangentV2C.MainLn2
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def statements : List Stmt := match Generated.f_main.body with
  | .sequence ss => ss
  | _ => []
def first : Stmt := statements[0]?.getD .skip

def modelLogarithm : ProofBox := SynergyBasis.Positive.atanh2
  (ScopedNumerical.ProofBox.literal SynergyBasis.Positive.p 1 3)
abbrev logarithm := MainFrames.logarithm
abbrev ready := MainFrames.initialized

theorem model_cache_exact : modelLogarithm = logarithm := by
  decide +kernel


def service : Call :=
  ContractExecute.execute SynergyC.Header.layout Generated.functions 128 2048
    SynergyC.ComputableFullService.call 13

theorem actual_body : Generated.f_main.body = .sequence (first :: statements.drop 1) := by
  rfl

theorem checked (arena : NatArena.Arena) :
    ArrayStages.hasNext
      (ArraySourceExecute.statement SynergyC.Header.layout service 128 2048 first
        (ArrayStages.withArena MainInitialization.initial arena)) ready = true := by
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual source initializer equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)

theorem actual_source_statement : ArrayStages.ShapeRun SynergyC.Header.layout service first
    MainInitialization.initial ready :=
  ArrayStages.statement_of_checked checked

theorem actual_callees_closed {name : String} {args : List Value}
    {before after : State} {v : Value}
    (h : service name args before = some (v,after)) :
    ArraySourceCalls.SourceCall SynergyC.Header.layout Generated.functions 16
      name args before v after :=
  ContractExecute.execute_sound (fun _ _ _ _ _ accepted => ArithmeticLibrary.closed accepted) h

#print axioms model_cache_exact
#print axioms actual_body
#print axioms checked
#print axioms actual_source_statement
#print axioms actual_callees_closed
end SynergyTangentV2C.MainLn2
