/- Actual l and zero-buffer declarations from the fixed C main. -/
import SynergyTangentV2C.MainCellAPI
namespace SynergyTangentV2C.MainEdges.Shared06
open ScopedC ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024
theorem cell192 : MainCellAPI.ExactEdges true 192
    (SynergyAnalytic.BoxModel.rat 3136 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell193 : MainCellAPI.ExactEdges true 193
    (SynergyAnalytic.BoxModel.rat 3151 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell194 : MainCellAPI.ExactEdges true 194
    (SynergyAnalytic.BoxModel.rat 3166 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell195 : MainCellAPI.ExactEdges true 195
    (SynergyAnalytic.BoxModel.rat 3181 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell196 : MainCellAPI.ExactEdges true 196
    (SynergyAnalytic.BoxModel.rat 3196 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell197 : MainCellAPI.ExactEdges true 197
    (SynergyAnalytic.BoxModel.rat 3211 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell198 : MainCellAPI.ExactEdges true 198
    (SynergyAnalytic.BoxModel.rat 3226 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell199 : MainCellAPI.ExactEdges true 199
    (SynergyAnalytic.BoxModel.rat 3241 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell200 : MainCellAPI.ExactEdges true 200
    (SynergyAnalytic.BoxModel.rat 3256 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell201 : MainCellAPI.ExactEdges true 201
    (SynergyAnalytic.BoxModel.rat 3271 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell202 : MainCellAPI.ExactEdges true 202
    (SynergyAnalytic.BoxModel.rat 3286 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell203 : MainCellAPI.ExactEdges true 203
    (SynergyAnalytic.BoxModel.rat 3301 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell204 : MainCellAPI.ExactEdges true 204
    (SynergyAnalytic.BoxModel.rat 3316 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell205 : MainCellAPI.ExactEdges true 205
    (SynergyAnalytic.BoxModel.rat 3331 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell206 : MainCellAPI.ExactEdges true 206
    (SynergyAnalytic.BoxModel.rat 3346 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell207 : MainCellAPI.ExactEdges true 207
    (SynergyAnalytic.BoxModel.rat 3361 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell208 : MainCellAPI.ExactEdges true 208
    (SynergyAnalytic.BoxModel.rat 3376 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell209 : MainCellAPI.ExactEdges true 209
    (SynergyAnalytic.BoxModel.rat 3391 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell210 : MainCellAPI.ExactEdges true 210
    (SynergyAnalytic.BoxModel.rat 3406 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell211 : MainCellAPI.ExactEdges true 211
    (SynergyAnalytic.BoxModel.rat 3421 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell212 : MainCellAPI.ExactEdges true 212
    (SynergyAnalytic.BoxModel.rat 3436 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell213 : MainCellAPI.ExactEdges true 213
    (SynergyAnalytic.BoxModel.rat 3451 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell214 : MainCellAPI.ExactEdges true 214
    (SynergyAnalytic.BoxModel.rat 3466 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell215 : MainCellAPI.ExactEdges true 215
    (SynergyAnalytic.BoxModel.rat 3481 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell216 : MainCellAPI.ExactEdges true 216
    (SynergyAnalytic.BoxModel.rat 3496 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell217 : MainCellAPI.ExactEdges true 217
    (SynergyAnalytic.BoxModel.rat 3511 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell218 : MainCellAPI.ExactEdges true 218
    (SynergyAnalytic.BoxModel.rat 3526 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell219 : MainCellAPI.ExactEdges true 219
    (SynergyAnalytic.BoxModel.rat 3541 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell220 : MainCellAPI.ExactEdges true 220
    (SynergyAnalytic.BoxModel.rat 3556 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell221 : MainCellAPI.ExactEdges true 221
    (SynergyAnalytic.BoxModel.rat 3571 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell222 : MainCellAPI.ExactEdges true 222
    (SynergyAnalytic.BoxModel.rat 3586 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell223 : MainCellAPI.ExactEdges true 223
    (SynergyAnalytic.BoxModel.rat 3601 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell192
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell193
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell194
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell195
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell196
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell197
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell198
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell199
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell200
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell201
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell202
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell203
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell204
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell205
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell206
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell207
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell208
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell209
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell210
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell211
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell212
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell213
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell214
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell215
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell216
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell217
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell218
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell219
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell220
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell221
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell222
#print axioms SynergyTangentV2C.MainEdges.Shared06.cell223
end SynergyTangentV2C.MainEdges.Shared06
