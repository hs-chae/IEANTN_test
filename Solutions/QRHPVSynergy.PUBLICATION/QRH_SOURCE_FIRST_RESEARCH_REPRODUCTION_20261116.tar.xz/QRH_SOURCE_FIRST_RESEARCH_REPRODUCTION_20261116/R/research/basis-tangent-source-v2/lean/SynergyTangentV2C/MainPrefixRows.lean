/- Every prefix row is an actual C execution, with no row hypothesis. -/
import SynergyTangentV2C.MainPureBody
import SynergyTangentV2C.MainAccum.Prefix00
namespace SynergyTangentV2C.MainPrefixRows
open ScopedC ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem complete : MainPureBody.PrefixRows := by
  intro i hi
  change i < 16 at hi
  interval_cases i
  · exact MainAccum.Prefix00.source000 MainPureBody.arena
  · exact MainAccum.Prefix00.source001 MainPureBody.arena
  · exact MainAccum.Prefix00.source002 MainPureBody.arena
  · exact MainAccum.Prefix00.source003 MainPureBody.arena
  · exact MainAccum.Prefix00.source004 MainPureBody.arena
  · exact MainAccum.Prefix00.source005 MainPureBody.arena
  · exact MainAccum.Prefix00.source006 MainPureBody.arena
  · exact MainAccum.Prefix00.source007 MainPureBody.arena
  · exact MainAccum.Prefix00.source008 MainPureBody.arena
  · exact MainAccum.Prefix00.source009 MainPureBody.arena
  · exact MainAccum.Prefix00.source010 MainPureBody.arena
  · exact MainAccum.Prefix00.source011 MainPureBody.arena
  · exact MainAccum.Prefix00.source012 MainPureBody.arena
  · exact MainAccum.Prefix00.source013 MainPureBody.arena
  · exact MainAccum.Prefix00.source014 MainPureBody.arena
  · exact MainAccum.Prefix00.source015 MainPureBody.arena

#print axioms complete
end SynergyTangentV2C.MainPrefixRows
