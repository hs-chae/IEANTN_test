/- Closed actual-source emitter calls and the explicit ferror API observation.
The constructive normal-write policy is a model scenario, not an assertion
that host writes always succeed. Actual source/run/byte association is separate. -/
import SynergyTangentV2C.ConditionalWorld
import SynergyTangentV2C.EmitUNormal
import SynergyTangentV2C.WorldError
import SynergyTangentV2C.MainLn2
namespace SynergyTangentV2C.MainWorldService
open ScopedC ScopedC.Machine ScopedIO ScopedIO.WorldIO
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def call (platform : Platform) : WorldIO.Call := fun name args world =>
  if name = "ferror" then WorldError.query platform name args world
  else EmitUService.call platform EmitUNormal.policy name args world

theorem closed (platform : Platform) {name : String} {args : List Value}
    {before after : World} {value : Value}
    (h : call platform name args before = some (value,after)) :
    ConditionalWorld.SourceCall Header.layout Bundle.code platform
      (WorldError.external platform EmitUNormal.policy) 1 name args before value after := by
  by_cases named : name = "ferror"
  · subst name
    have noLegacy : WorldIO.external platform EmitUNormal.policy "ferror" args before =
        none := by rfl
    have api : WorldError.external platform EmitUNormal.policy "ferror" args before =
        some (value,after) := by
      simpa only [call,↓reduceIte,WorldError.external,noLegacy] using h
    exact ConditionalWorld.old_call (WorldSourceWith.external_call api)
  · have actual := EmitUService.closed platform EmitUNormal.policy
      (by simpa only [call,named,↓reduceIte] using h)
    exact ConditionalWorld.old_call (WorldError.lift_old actual)

theorem pure_closed {name : String} {args : List Value} {before after : State}
    {value : Value} (h : MainLn2.service name args before = some (value,after)) :
    ∃ rank, ArraySourceCalls.SourceCall Header.layout Bundle.code rank
      name args before value after := by
  refine ⟨16, ?_⟩
  rw [Bundle.code_exact]
  exact MainLn2.actual_callees_closed h

theorem emit_success (platform : Platform) (caller : State) (x : Int)
    (range : SynergyC.Word512.Range x) (stream : Stream)
    (stdout : caller.globals.lookup "stdout" = none) :
    call platform "emitU" [SynergyC.Word512.value x] ⟨caller,stream⟩ =
      some (.unit,⟨caller,EmitUNormal.appendWord stream x⟩) := by
  simpa only [call,if_neg (by decide : "emitU" ≠ "ferror")] using EmitUNormal.emitU_success
    platform caller x range stream stdout

theorem ferror_healthy (platform : Platform) (world : World)
    (healthy : world.stream.error = false) :
    call platform "ferror" [WorldIO.stdoutValue platform] world =
      some (WorldIO.signed32 0,world) := by
  simp only [call,↓reduceIte,WorldError.query,WorldIO.stdout_handle,healthy,
    Bool.not_false,Bool.true_and]

#print axioms closed
#print axioms pure_closed
#print axioms emit_success
#print axioms ferror_healthy
end SynergyTangentV2C.MainWorldService
