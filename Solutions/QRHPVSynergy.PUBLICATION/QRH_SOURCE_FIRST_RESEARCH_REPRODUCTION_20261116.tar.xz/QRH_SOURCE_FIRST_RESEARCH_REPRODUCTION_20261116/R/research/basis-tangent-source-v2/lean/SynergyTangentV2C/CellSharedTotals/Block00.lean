/- Exact cumulative sums, using the corresponding accepted fixed-cell model equations. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Shared000
import SynergyTangentV2C.SourceCells.Shared001
import SynergyTangentV2C.SourceCells.Shared002
import SynergyTangentV2C.SourceCells.Shared003
import SynergyTangentV2C.SourceCells.Shared004
import SynergyTangentV2C.SourceCells.Shared005
import SynergyTangentV2C.SourceCells.Shared006
import SynergyTangentV2C.SourceCells.Shared007
import SynergyTangentV2C.SourceCells.Shared008
import SynergyTangentV2C.SourceCells.Shared009
import SynergyTangentV2C.SourceCells.Shared010
import SynergyTangentV2C.SourceCells.Shared011
import SynergyTangentV2C.SourceCells.Shared012
import SynergyTangentV2C.SourceCells.Shared013
import SynergyTangentV2C.SourceCells.Shared014
import SynergyTangentV2C.SourceCells.Shared015
import SynergyTangentV2C.SourceCells.Shared016
import SynergyTangentV2C.SourceCells.Shared017
import SynergyTangentV2C.SourceCells.Shared018
import SynergyTangentV2C.SourceCells.Shared019
import SynergyTangentV2C.SourceCells.Shared020
import SynergyTangentV2C.SourceCells.Shared021
import SynergyTangentV2C.SourceCells.Shared022
import SynergyTangentV2C.SourceCells.Shared023
import SynergyTangentV2C.SourceCells.Shared024
import SynergyTangentV2C.SourceCells.Shared025
import SynergyTangentV2C.SourceCells.Shared026
import SynergyTangentV2C.SourceCells.Shared027
import SynergyTangentV2C.SourceCells.Shared028
import SynergyTangentV2C.SourceCells.Shared029
import SynergyTangentV2C.SourceCells.Shared030
import SynergyTangentV2C.SourceCells.Shared031
namespace SynergyTangentV2C.CellSharedTotals.Block00
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.sharedOnlyTotals
theorem sum000 :
    (ProofBox.add (totals 0).1 SourceCells.Shared000.output.1,
     ProofBox.add (totals 0).2.1 SourceCells.Shared000.output.2.1,
     ProofBox.add (totals 0).2.2 SourceCells.Shared000.output.2.2)=totals 1 := by
  decide +kernel
#print axioms sum000
theorem sum001 :
    (ProofBox.add (totals 1).1 SourceCells.Shared001.output.1,
     ProofBox.add (totals 1).2.1 SourceCells.Shared001.output.2.1,
     ProofBox.add (totals 1).2.2 SourceCells.Shared001.output.2.2)=totals 2 := by
  decide +kernel
#print axioms sum001
theorem sum002 :
    (ProofBox.add (totals 2).1 SourceCells.Shared002.output.1,
     ProofBox.add (totals 2).2.1 SourceCells.Shared002.output.2.1,
     ProofBox.add (totals 2).2.2 SourceCells.Shared002.output.2.2)=totals 3 := by
  decide +kernel
#print axioms sum002
theorem sum003 :
    (ProofBox.add (totals 3).1 SourceCells.Shared003.output.1,
     ProofBox.add (totals 3).2.1 SourceCells.Shared003.output.2.1,
     ProofBox.add (totals 3).2.2 SourceCells.Shared003.output.2.2)=totals 4 := by
  decide +kernel
#print axioms sum003
theorem sum004 :
    (ProofBox.add (totals 4).1 SourceCells.Shared004.output.1,
     ProofBox.add (totals 4).2.1 SourceCells.Shared004.output.2.1,
     ProofBox.add (totals 4).2.2 SourceCells.Shared004.output.2.2)=totals 5 := by
  decide +kernel
#print axioms sum004
theorem sum005 :
    (ProofBox.add (totals 5).1 SourceCells.Shared005.output.1,
     ProofBox.add (totals 5).2.1 SourceCells.Shared005.output.2.1,
     ProofBox.add (totals 5).2.2 SourceCells.Shared005.output.2.2)=totals 6 := by
  decide +kernel
#print axioms sum005
theorem sum006 :
    (ProofBox.add (totals 6).1 SourceCells.Shared006.output.1,
     ProofBox.add (totals 6).2.1 SourceCells.Shared006.output.2.1,
     ProofBox.add (totals 6).2.2 SourceCells.Shared006.output.2.2)=totals 7 := by
  decide +kernel
#print axioms sum006
theorem sum007 :
    (ProofBox.add (totals 7).1 SourceCells.Shared007.output.1,
     ProofBox.add (totals 7).2.1 SourceCells.Shared007.output.2.1,
     ProofBox.add (totals 7).2.2 SourceCells.Shared007.output.2.2)=totals 8 := by
  decide +kernel
#print axioms sum007
theorem sum008 :
    (ProofBox.add (totals 8).1 SourceCells.Shared008.output.1,
     ProofBox.add (totals 8).2.1 SourceCells.Shared008.output.2.1,
     ProofBox.add (totals 8).2.2 SourceCells.Shared008.output.2.2)=totals 9 := by
  decide +kernel
#print axioms sum008
theorem sum009 :
    (ProofBox.add (totals 9).1 SourceCells.Shared009.output.1,
     ProofBox.add (totals 9).2.1 SourceCells.Shared009.output.2.1,
     ProofBox.add (totals 9).2.2 SourceCells.Shared009.output.2.2)=totals 10 := by
  decide +kernel
#print axioms sum009
theorem sum010 :
    (ProofBox.add (totals 10).1 SourceCells.Shared010.output.1,
     ProofBox.add (totals 10).2.1 SourceCells.Shared010.output.2.1,
     ProofBox.add (totals 10).2.2 SourceCells.Shared010.output.2.2)=totals 11 := by
  decide +kernel
#print axioms sum010
theorem sum011 :
    (ProofBox.add (totals 11).1 SourceCells.Shared011.output.1,
     ProofBox.add (totals 11).2.1 SourceCells.Shared011.output.2.1,
     ProofBox.add (totals 11).2.2 SourceCells.Shared011.output.2.2)=totals 12 := by
  decide +kernel
#print axioms sum011
theorem sum012 :
    (ProofBox.add (totals 12).1 SourceCells.Shared012.output.1,
     ProofBox.add (totals 12).2.1 SourceCells.Shared012.output.2.1,
     ProofBox.add (totals 12).2.2 SourceCells.Shared012.output.2.2)=totals 13 := by
  decide +kernel
#print axioms sum012
theorem sum013 :
    (ProofBox.add (totals 13).1 SourceCells.Shared013.output.1,
     ProofBox.add (totals 13).2.1 SourceCells.Shared013.output.2.1,
     ProofBox.add (totals 13).2.2 SourceCells.Shared013.output.2.2)=totals 14 := by
  decide +kernel
#print axioms sum013
theorem sum014 :
    (ProofBox.add (totals 14).1 SourceCells.Shared014.output.1,
     ProofBox.add (totals 14).2.1 SourceCells.Shared014.output.2.1,
     ProofBox.add (totals 14).2.2 SourceCells.Shared014.output.2.2)=totals 15 := by
  decide +kernel
#print axioms sum014
theorem sum015 :
    (ProofBox.add (totals 15).1 SourceCells.Shared015.output.1,
     ProofBox.add (totals 15).2.1 SourceCells.Shared015.output.2.1,
     ProofBox.add (totals 15).2.2 SourceCells.Shared015.output.2.2)=totals 16 := by
  decide +kernel
#print axioms sum015
theorem sum016 :
    (ProofBox.add (totals 16).1 SourceCells.Shared016.output.1,
     ProofBox.add (totals 16).2.1 SourceCells.Shared016.output.2.1,
     ProofBox.add (totals 16).2.2 SourceCells.Shared016.output.2.2)=totals 17 := by
  decide +kernel
#print axioms sum016
theorem sum017 :
    (ProofBox.add (totals 17).1 SourceCells.Shared017.output.1,
     ProofBox.add (totals 17).2.1 SourceCells.Shared017.output.2.1,
     ProofBox.add (totals 17).2.2 SourceCells.Shared017.output.2.2)=totals 18 := by
  decide +kernel
#print axioms sum017
theorem sum018 :
    (ProofBox.add (totals 18).1 SourceCells.Shared018.output.1,
     ProofBox.add (totals 18).2.1 SourceCells.Shared018.output.2.1,
     ProofBox.add (totals 18).2.2 SourceCells.Shared018.output.2.2)=totals 19 := by
  decide +kernel
#print axioms sum018
theorem sum019 :
    (ProofBox.add (totals 19).1 SourceCells.Shared019.output.1,
     ProofBox.add (totals 19).2.1 SourceCells.Shared019.output.2.1,
     ProofBox.add (totals 19).2.2 SourceCells.Shared019.output.2.2)=totals 20 := by
  decide +kernel
#print axioms sum019
theorem sum020 :
    (ProofBox.add (totals 20).1 SourceCells.Shared020.output.1,
     ProofBox.add (totals 20).2.1 SourceCells.Shared020.output.2.1,
     ProofBox.add (totals 20).2.2 SourceCells.Shared020.output.2.2)=totals 21 := by
  decide +kernel
#print axioms sum020
theorem sum021 :
    (ProofBox.add (totals 21).1 SourceCells.Shared021.output.1,
     ProofBox.add (totals 21).2.1 SourceCells.Shared021.output.2.1,
     ProofBox.add (totals 21).2.2 SourceCells.Shared021.output.2.2)=totals 22 := by
  decide +kernel
#print axioms sum021
theorem sum022 :
    (ProofBox.add (totals 22).1 SourceCells.Shared022.output.1,
     ProofBox.add (totals 22).2.1 SourceCells.Shared022.output.2.1,
     ProofBox.add (totals 22).2.2 SourceCells.Shared022.output.2.2)=totals 23 := by
  decide +kernel
#print axioms sum022
theorem sum023 :
    (ProofBox.add (totals 23).1 SourceCells.Shared023.output.1,
     ProofBox.add (totals 23).2.1 SourceCells.Shared023.output.2.1,
     ProofBox.add (totals 23).2.2 SourceCells.Shared023.output.2.2)=totals 24 := by
  decide +kernel
#print axioms sum023
theorem sum024 :
    (ProofBox.add (totals 24).1 SourceCells.Shared024.output.1,
     ProofBox.add (totals 24).2.1 SourceCells.Shared024.output.2.1,
     ProofBox.add (totals 24).2.2 SourceCells.Shared024.output.2.2)=totals 25 := by
  decide +kernel
#print axioms sum024
theorem sum025 :
    (ProofBox.add (totals 25).1 SourceCells.Shared025.output.1,
     ProofBox.add (totals 25).2.1 SourceCells.Shared025.output.2.1,
     ProofBox.add (totals 25).2.2 SourceCells.Shared025.output.2.2)=totals 26 := by
  decide +kernel
#print axioms sum025
theorem sum026 :
    (ProofBox.add (totals 26).1 SourceCells.Shared026.output.1,
     ProofBox.add (totals 26).2.1 SourceCells.Shared026.output.2.1,
     ProofBox.add (totals 26).2.2 SourceCells.Shared026.output.2.2)=totals 27 := by
  decide +kernel
#print axioms sum026
theorem sum027 :
    (ProofBox.add (totals 27).1 SourceCells.Shared027.output.1,
     ProofBox.add (totals 27).2.1 SourceCells.Shared027.output.2.1,
     ProofBox.add (totals 27).2.2 SourceCells.Shared027.output.2.2)=totals 28 := by
  decide +kernel
#print axioms sum027
theorem sum028 :
    (ProofBox.add (totals 28).1 SourceCells.Shared028.output.1,
     ProofBox.add (totals 28).2.1 SourceCells.Shared028.output.2.1,
     ProofBox.add (totals 28).2.2 SourceCells.Shared028.output.2.2)=totals 29 := by
  decide +kernel
#print axioms sum028
theorem sum029 :
    (ProofBox.add (totals 29).1 SourceCells.Shared029.output.1,
     ProofBox.add (totals 29).2.1 SourceCells.Shared029.output.2.1,
     ProofBox.add (totals 29).2.2 SourceCells.Shared029.output.2.2)=totals 30 := by
  decide +kernel
#print axioms sum029
theorem sum030 :
    (ProofBox.add (totals 30).1 SourceCells.Shared030.output.1,
     ProofBox.add (totals 30).2.1 SourceCells.Shared030.output.2.1,
     ProofBox.add (totals 30).2.2 SourceCells.Shared030.output.2.2)=totals 31 := by
  decide +kernel
#print axioms sum030
theorem sum031 :
    (ProofBox.add (totals 31).1 SourceCells.Shared031.output.1,
     ProofBox.add (totals 31).2.1 SourceCells.Shared031.output.2.1,
     ProofBox.add (totals 31).2.2 SourceCells.Shared031.output.2.2)=totals 32 := by
  decide +kernel
#print axioms sum031
theorem advance (old : SynergyAnalytic.BoxModel.sharedFold 256 0=some (totals 0)) :
    SynergyAnalytic.BoxModel.sharedFold 256 32=some (totals 32) := by
  have fold000 := old
  have fold001 := (CellFoldSteps.shared_next 0 _ _ fold000
    SourceCells.Shared000.model_eq).trans (congrArg some sum000)
  have fold002 := (CellFoldSteps.shared_next 1 _ _ fold001
    SourceCells.Shared001.model_eq).trans (congrArg some sum001)
  have fold003 := (CellFoldSteps.shared_next 2 _ _ fold002
    SourceCells.Shared002.model_eq).trans (congrArg some sum002)
  have fold004 := (CellFoldSteps.shared_next 3 _ _ fold003
    SourceCells.Shared003.model_eq).trans (congrArg some sum003)
  have fold005 := (CellFoldSteps.shared_next 4 _ _ fold004
    SourceCells.Shared004.model_eq).trans (congrArg some sum004)
  have fold006 := (CellFoldSteps.shared_next 5 _ _ fold005
    SourceCells.Shared005.model_eq).trans (congrArg some sum005)
  have fold007 := (CellFoldSteps.shared_next 6 _ _ fold006
    SourceCells.Shared006.model_eq).trans (congrArg some sum006)
  have fold008 := (CellFoldSteps.shared_next 7 _ _ fold007
    SourceCells.Shared007.model_eq).trans (congrArg some sum007)
  have fold009 := (CellFoldSteps.shared_next 8 _ _ fold008
    SourceCells.Shared008.model_eq).trans (congrArg some sum008)
  have fold010 := (CellFoldSteps.shared_next 9 _ _ fold009
    SourceCells.Shared009.model_eq).trans (congrArg some sum009)
  have fold011 := (CellFoldSteps.shared_next 10 _ _ fold010
    SourceCells.Shared010.model_eq).trans (congrArg some sum010)
  have fold012 := (CellFoldSteps.shared_next 11 _ _ fold011
    SourceCells.Shared011.model_eq).trans (congrArg some sum011)
  have fold013 := (CellFoldSteps.shared_next 12 _ _ fold012
    SourceCells.Shared012.model_eq).trans (congrArg some sum012)
  have fold014 := (CellFoldSteps.shared_next 13 _ _ fold013
    SourceCells.Shared013.model_eq).trans (congrArg some sum013)
  have fold015 := (CellFoldSteps.shared_next 14 _ _ fold014
    SourceCells.Shared014.model_eq).trans (congrArg some sum014)
  have fold016 := (CellFoldSteps.shared_next 15 _ _ fold015
    SourceCells.Shared015.model_eq).trans (congrArg some sum015)
  have fold017 := (CellFoldSteps.shared_next 16 _ _ fold016
    SourceCells.Shared016.model_eq).trans (congrArg some sum016)
  have fold018 := (CellFoldSteps.shared_next 17 _ _ fold017
    SourceCells.Shared017.model_eq).trans (congrArg some sum017)
  have fold019 := (CellFoldSteps.shared_next 18 _ _ fold018
    SourceCells.Shared018.model_eq).trans (congrArg some sum018)
  have fold020 := (CellFoldSteps.shared_next 19 _ _ fold019
    SourceCells.Shared019.model_eq).trans (congrArg some sum019)
  have fold021 := (CellFoldSteps.shared_next 20 _ _ fold020
    SourceCells.Shared020.model_eq).trans (congrArg some sum020)
  have fold022 := (CellFoldSteps.shared_next 21 _ _ fold021
    SourceCells.Shared021.model_eq).trans (congrArg some sum021)
  have fold023 := (CellFoldSteps.shared_next 22 _ _ fold022
    SourceCells.Shared022.model_eq).trans (congrArg some sum022)
  have fold024 := (CellFoldSteps.shared_next 23 _ _ fold023
    SourceCells.Shared023.model_eq).trans (congrArg some sum023)
  have fold025 := (CellFoldSteps.shared_next 24 _ _ fold024
    SourceCells.Shared024.model_eq).trans (congrArg some sum024)
  have fold026 := (CellFoldSteps.shared_next 25 _ _ fold025
    SourceCells.Shared025.model_eq).trans (congrArg some sum025)
  have fold027 := (CellFoldSteps.shared_next 26 _ _ fold026
    SourceCells.Shared026.model_eq).trans (congrArg some sum026)
  have fold028 := (CellFoldSteps.shared_next 27 _ _ fold027
    SourceCells.Shared027.model_eq).trans (congrArg some sum027)
  have fold029 := (CellFoldSteps.shared_next 28 _ _ fold028
    SourceCells.Shared028.model_eq).trans (congrArg some sum028)
  have fold030 := (CellFoldSteps.shared_next 29 _ _ fold029
    SourceCells.Shared029.model_eq).trans (congrArg some sum029)
  have fold031 := (CellFoldSteps.shared_next 30 _ _ fold030
    SourceCells.Shared030.model_eq).trans (congrArg some sum030)
  have fold032 := (CellFoldSteps.shared_next 31 _ _ fold031
    SourceCells.Shared031.model_eq).trans (congrArg some sum031)
  exact fold032
#print axioms advance
end SynergyTangentV2C.CellSharedTotals.Block00
