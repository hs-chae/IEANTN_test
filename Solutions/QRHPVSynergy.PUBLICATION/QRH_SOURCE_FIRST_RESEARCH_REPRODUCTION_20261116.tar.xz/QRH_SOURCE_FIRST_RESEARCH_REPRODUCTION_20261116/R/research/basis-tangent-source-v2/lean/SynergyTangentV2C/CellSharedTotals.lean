import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellSharedTotals.Block00
import SynergyTangentV2C.CellSharedTotals.Block01
import SynergyTangentV2C.CellSharedTotals.Block02
import SynergyTangentV2C.CellSharedTotals.Block03
import SynergyTangentV2C.CellSharedTotals.Block04
import SynergyTangentV2C.CellSharedTotals.Block05
import SynergyTangentV2C.CellSharedTotals.Block06
import SynergyTangentV2C.CellSharedTotals.Block07
namespace SynergyTangentV2C.CellSharedTotals
set_option autoImplicit false
set_option maxHeartbeats 0
theorem complete : SynergyAnalytic.BoxModel.sharedFold 256 256=
    some (CellTotalsData.sharedOnlyTotals 256) := by
  have fold000 : SynergyAnalytic.BoxModel.sharedFold 256 0=
      some (CellTotalsData.sharedOnlyTotals 0) := by rfl
  have fold032 := Block00.advance fold000
  have fold064 := Block01.advance fold032
  have fold096 := Block02.advance fold064
  have fold128 := Block03.advance fold096
  have fold160 := Block04.advance fold128
  have fold192 := Block05.advance fold160
  have fold224 := Block06.advance fold192
  have fold256 := Block07.advance fold224
  exact fold256
#print axioms complete
end SynergyTangentV2C.CellSharedTotals
