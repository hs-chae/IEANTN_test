/- The actual accumulation statements and block-scope restoration. Each finite
row must provide its source execution; proposed cumulative sums are not premises
of the completed program until those finite executions have been discharged. -/
import SynergyTangentV2C.MainCellAPI
namespace SynergyTangentV2C.MainRowAPI
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def totalObject (totals : MainFrames.Totals) : Object := {
  type := "I", isArray := true, cells := [
    some (CellExecute.represented totals.1),
    some (CellExecute.represented totals.2.1),
    some (CellExecute.represented totals.2.2)] }

def after (totals next output : MainFrames.Totals) (i : Nat) (left : ProofBox)
    (arena : NatArena.Arena) : State :=
  let state := CellExecute.filled (MainCellAPI.base totals i left arena) output
  {state with heap := (state.heap.set 5 (totalObject next)).set 6 {
    type := "unsigned int", cells := [some (MainFrames.unsigned (i+1))]}}

@[irreducible] def suffix (logs : Bool) (totals output : MainFrames.Totals)
    (i : Nat) (left : ProofBox) (arena : NatArena.Arena) :
    Option ArraySourceExecute.Outcome :=
  ArraySourceExecute.statements Header.layout MainLn2.service 128 2048
    ((MainCellAPI.body logs).drop 3)
    (CellExecute.filled (MainCellAPI.base totals i left arena) output)

def ExactSuffix (logs : Bool) (totals next output : MainFrames.Totals)
    (i : Nat) (left : ProofBox) : Prop :=
  ∀ arena, suffix logs totals output i left arena =
    some (.continuing (after totals next output i left arena))

theorem restores_scope (totals next output : MainFrames.Totals) (i : Nat)
    (left : ProofBox) (arena : NatArena.Arena) :
    Machine.popScope (MainCellAPI.before totals i arena)
      (after totals next output i left arena) = MainCellAPI.before next (i+1) arena := by
  rfl

theorem actual_body {logs : Bool} {i : Nat} {left : ProofBox}
    (edgeProof : MainCellAPI.ExactEdges logs i left)
    (totals next output : MainFrames.Totals) (arena : NatArena.Arena)
    (execution : CellExecute.run (MainCellAPI.base totals i left arena)
      left (MainCellAPI.width logs) logs =
      some (.unit,CellExecute.filled (MainCellAPI.base totals i left arena) output))
    (suffixProof : ExactSuffix logs totals next output i left) :
    ArraySourceCalls.Run Header.layout MainLn2.service (.sequence (MainCellAPI.body logs))
      (MainCellAPI.before totals i arena)
      (.continuing (MainCellAPI.before next (i+1) arena)) := by
  have prefixProof := MainCellAPI.source_prefix edgeProof totals output arena execution
  have checkedSuffix := suffixProof arena
  unfold suffix at checkedSuffix
  have tailProof := (ArraySourceExecute.sound Header.layout MainLn2.service 128 2048).2.1
    _ _ _ checkedSuffix
  have sequenceProof := MainCellAPI.seq_append prefixProof tailProof
  rw [← MainCellAPI.actual_partition] at sequenceProof
  apply Loops.StmtRun.sequence sequenceProof
  exact (restores_scope totals next output i left arena).symm

#print axioms restores_scope
#print axioms actual_body
end SynergyTangentV2C.MainRowAPI
