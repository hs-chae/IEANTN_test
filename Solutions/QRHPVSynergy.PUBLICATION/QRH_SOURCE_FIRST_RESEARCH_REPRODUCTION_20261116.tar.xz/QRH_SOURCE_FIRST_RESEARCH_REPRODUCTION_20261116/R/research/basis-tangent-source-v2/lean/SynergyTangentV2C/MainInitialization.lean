/- Static storage comes from the actual bound declarations, not a platform
assumption about an initialized application representation. -/
import SynergyTangentV2C.Bundle
import SynergyC.Initialization
namespace SynergyTangentV2C.MainInitialization
open ScopedC ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def boundGlobals : List Syntax.Decl := Bundle.tree.values.filterMap (fun piece =>
  match piece with
  | .global d => some d
  | _ => none)

def initializeGlobals : Option State := do
  let st ← boundGlobals.foldlM SynergyC.Initialization.initializeOne Machine.empty
  pure {st with env := [], globals := st.env}

abbrev initial : State := SynergyC.Initialization.state

theorem actual_global_declarations : boundGlobals = SynergyC.Header.globals := by
  rfl

theorem actual_initialization : initializeGlobals = some initial := by
  change SynergyC.Initialization.initializeGlobals = some SynergyC.Initialization.state
  exact SynergyC.Initialization.actual_initialization

theorem stdout_unshadowed : initial.globals.lookup "stdout" = none := by
  rfl

#print axioms actual_global_declarations
#print axioms actual_initialization
#print axioms stdout_unshadowed
end SynergyTangentV2C.MainInitialization
