/- Exact unchanged mathematical basis interface, now fed by the actual
source-first C producer rather than the standalone kernel-only basis provider. -/
import SynergyTangentV2C.SourceProgramClosed
namespace SynergyTangentC.ClosedCaps
theorem source_universal_basis_caps :
    SynergyAnalytic.UniversalBasisCaps (373/200) (1273/2000) (129/250) :=
  SynergyTangentV2C.SourceProgramClosed.basis_caps
#print axioms source_universal_basis_caps
end SynergyTangentC.ClosedCaps
