/- Exact cumulative sums, using the corresponding accepted fixed-cell model equations. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Shared064
import SynergyTangentV2C.SourceCells.Shared065
import SynergyTangentV2C.SourceCells.Shared066
import SynergyTangentV2C.SourceCells.Shared067
import SynergyTangentV2C.SourceCells.Shared068
import SynergyTangentV2C.SourceCells.Shared069
import SynergyTangentV2C.SourceCells.Shared070
import SynergyTangentV2C.SourceCells.Shared071
import SynergyTangentV2C.SourceCells.Shared072
import SynergyTangentV2C.SourceCells.Shared073
import SynergyTangentV2C.SourceCells.Shared074
import SynergyTangentV2C.SourceCells.Shared075
import SynergyTangentV2C.SourceCells.Shared076
import SynergyTangentV2C.SourceCells.Shared077
import SynergyTangentV2C.SourceCells.Shared078
import SynergyTangentV2C.SourceCells.Shared079
import SynergyTangentV2C.SourceCells.Shared080
import SynergyTangentV2C.SourceCells.Shared081
import SynergyTangentV2C.SourceCells.Shared082
import SynergyTangentV2C.SourceCells.Shared083
import SynergyTangentV2C.SourceCells.Shared084
import SynergyTangentV2C.SourceCells.Shared085
import SynergyTangentV2C.SourceCells.Shared086
import SynergyTangentV2C.SourceCells.Shared087
import SynergyTangentV2C.SourceCells.Shared088
import SynergyTangentV2C.SourceCells.Shared089
import SynergyTangentV2C.SourceCells.Shared090
import SynergyTangentV2C.SourceCells.Shared091
import SynergyTangentV2C.SourceCells.Shared092
import SynergyTangentV2C.SourceCells.Shared093
import SynergyTangentV2C.SourceCells.Shared094
import SynergyTangentV2C.SourceCells.Shared095
namespace SynergyTangentV2C.CellSharedTotals.Block02
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.sharedOnlyTotals
theorem sum064 :
    (ProofBox.add (totals 64).1 SourceCells.Shared064.output.1,
     ProofBox.add (totals 64).2.1 SourceCells.Shared064.output.2.1,
     ProofBox.add (totals 64).2.2 SourceCells.Shared064.output.2.2)=totals 65 := by
  decide +kernel
#print axioms sum064
theorem sum065 :
    (ProofBox.add (totals 65).1 SourceCells.Shared065.output.1,
     ProofBox.add (totals 65).2.1 SourceCells.Shared065.output.2.1,
     ProofBox.add (totals 65).2.2 SourceCells.Shared065.output.2.2)=totals 66 := by
  decide +kernel
#print axioms sum065
theorem sum066 :
    (ProofBox.add (totals 66).1 SourceCells.Shared066.output.1,
     ProofBox.add (totals 66).2.1 SourceCells.Shared066.output.2.1,
     ProofBox.add (totals 66).2.2 SourceCells.Shared066.output.2.2)=totals 67 := by
  decide +kernel
#print axioms sum066
theorem sum067 :
    (ProofBox.add (totals 67).1 SourceCells.Shared067.output.1,
     ProofBox.add (totals 67).2.1 SourceCells.Shared067.output.2.1,
     ProofBox.add (totals 67).2.2 SourceCells.Shared067.output.2.2)=totals 68 := by
  decide +kernel
#print axioms sum067
theorem sum068 :
    (ProofBox.add (totals 68).1 SourceCells.Shared068.output.1,
     ProofBox.add (totals 68).2.1 SourceCells.Shared068.output.2.1,
     ProofBox.add (totals 68).2.2 SourceCells.Shared068.output.2.2)=totals 69 := by
  decide +kernel
#print axioms sum068
theorem sum069 :
    (ProofBox.add (totals 69).1 SourceCells.Shared069.output.1,
     ProofBox.add (totals 69).2.1 SourceCells.Shared069.output.2.1,
     ProofBox.add (totals 69).2.2 SourceCells.Shared069.output.2.2)=totals 70 := by
  decide +kernel
#print axioms sum069
theorem sum070 :
    (ProofBox.add (totals 70).1 SourceCells.Shared070.output.1,
     ProofBox.add (totals 70).2.1 SourceCells.Shared070.output.2.1,
     ProofBox.add (totals 70).2.2 SourceCells.Shared070.output.2.2)=totals 71 := by
  decide +kernel
#print axioms sum070
theorem sum071 :
    (ProofBox.add (totals 71).1 SourceCells.Shared071.output.1,
     ProofBox.add (totals 71).2.1 SourceCells.Shared071.output.2.1,
     ProofBox.add (totals 71).2.2 SourceCells.Shared071.output.2.2)=totals 72 := by
  decide +kernel
#print axioms sum071
theorem sum072 :
    (ProofBox.add (totals 72).1 SourceCells.Shared072.output.1,
     ProofBox.add (totals 72).2.1 SourceCells.Shared072.output.2.1,
     ProofBox.add (totals 72).2.2 SourceCells.Shared072.output.2.2)=totals 73 := by
  decide +kernel
#print axioms sum072
theorem sum073 :
    (ProofBox.add (totals 73).1 SourceCells.Shared073.output.1,
     ProofBox.add (totals 73).2.1 SourceCells.Shared073.output.2.1,
     ProofBox.add (totals 73).2.2 SourceCells.Shared073.output.2.2)=totals 74 := by
  decide +kernel
#print axioms sum073
theorem sum074 :
    (ProofBox.add (totals 74).1 SourceCells.Shared074.output.1,
     ProofBox.add (totals 74).2.1 SourceCells.Shared074.output.2.1,
     ProofBox.add (totals 74).2.2 SourceCells.Shared074.output.2.2)=totals 75 := by
  decide +kernel
#print axioms sum074
theorem sum075 :
    (ProofBox.add (totals 75).1 SourceCells.Shared075.output.1,
     ProofBox.add (totals 75).2.1 SourceCells.Shared075.output.2.1,
     ProofBox.add (totals 75).2.2 SourceCells.Shared075.output.2.2)=totals 76 := by
  decide +kernel
#print axioms sum075
theorem sum076 :
    (ProofBox.add (totals 76).1 SourceCells.Shared076.output.1,
     ProofBox.add (totals 76).2.1 SourceCells.Shared076.output.2.1,
     ProofBox.add (totals 76).2.2 SourceCells.Shared076.output.2.2)=totals 77 := by
  decide +kernel
#print axioms sum076
theorem sum077 :
    (ProofBox.add (totals 77).1 SourceCells.Shared077.output.1,
     ProofBox.add (totals 77).2.1 SourceCells.Shared077.output.2.1,
     ProofBox.add (totals 77).2.2 SourceCells.Shared077.output.2.2)=totals 78 := by
  decide +kernel
#print axioms sum077
theorem sum078 :
    (ProofBox.add (totals 78).1 SourceCells.Shared078.output.1,
     ProofBox.add (totals 78).2.1 SourceCells.Shared078.output.2.1,
     ProofBox.add (totals 78).2.2 SourceCells.Shared078.output.2.2)=totals 79 := by
  decide +kernel
#print axioms sum078
theorem sum079 :
    (ProofBox.add (totals 79).1 SourceCells.Shared079.output.1,
     ProofBox.add (totals 79).2.1 SourceCells.Shared079.output.2.1,
     ProofBox.add (totals 79).2.2 SourceCells.Shared079.output.2.2)=totals 80 := by
  decide +kernel
#print axioms sum079
theorem sum080 :
    (ProofBox.add (totals 80).1 SourceCells.Shared080.output.1,
     ProofBox.add (totals 80).2.1 SourceCells.Shared080.output.2.1,
     ProofBox.add (totals 80).2.2 SourceCells.Shared080.output.2.2)=totals 81 := by
  decide +kernel
#print axioms sum080
theorem sum081 :
    (ProofBox.add (totals 81).1 SourceCells.Shared081.output.1,
     ProofBox.add (totals 81).2.1 SourceCells.Shared081.output.2.1,
     ProofBox.add (totals 81).2.2 SourceCells.Shared081.output.2.2)=totals 82 := by
  decide +kernel
#print axioms sum081
theorem sum082 :
    (ProofBox.add (totals 82).1 SourceCells.Shared082.output.1,
     ProofBox.add (totals 82).2.1 SourceCells.Shared082.output.2.1,
     ProofBox.add (totals 82).2.2 SourceCells.Shared082.output.2.2)=totals 83 := by
  decide +kernel
#print axioms sum082
theorem sum083 :
    (ProofBox.add (totals 83).1 SourceCells.Shared083.output.1,
     ProofBox.add (totals 83).2.1 SourceCells.Shared083.output.2.1,
     ProofBox.add (totals 83).2.2 SourceCells.Shared083.output.2.2)=totals 84 := by
  decide +kernel
#print axioms sum083
theorem sum084 :
    (ProofBox.add (totals 84).1 SourceCells.Shared084.output.1,
     ProofBox.add (totals 84).2.1 SourceCells.Shared084.output.2.1,
     ProofBox.add (totals 84).2.2 SourceCells.Shared084.output.2.2)=totals 85 := by
  decide +kernel
#print axioms sum084
theorem sum085 :
    (ProofBox.add (totals 85).1 SourceCells.Shared085.output.1,
     ProofBox.add (totals 85).2.1 SourceCells.Shared085.output.2.1,
     ProofBox.add (totals 85).2.2 SourceCells.Shared085.output.2.2)=totals 86 := by
  decide +kernel
#print axioms sum085
theorem sum086 :
    (ProofBox.add (totals 86).1 SourceCells.Shared086.output.1,
     ProofBox.add (totals 86).2.1 SourceCells.Shared086.output.2.1,
     ProofBox.add (totals 86).2.2 SourceCells.Shared086.output.2.2)=totals 87 := by
  decide +kernel
#print axioms sum086
theorem sum087 :
    (ProofBox.add (totals 87).1 SourceCells.Shared087.output.1,
     ProofBox.add (totals 87).2.1 SourceCells.Shared087.output.2.1,
     ProofBox.add (totals 87).2.2 SourceCells.Shared087.output.2.2)=totals 88 := by
  decide +kernel
#print axioms sum087
theorem sum088 :
    (ProofBox.add (totals 88).1 SourceCells.Shared088.output.1,
     ProofBox.add (totals 88).2.1 SourceCells.Shared088.output.2.1,
     ProofBox.add (totals 88).2.2 SourceCells.Shared088.output.2.2)=totals 89 := by
  decide +kernel
#print axioms sum088
theorem sum089 :
    (ProofBox.add (totals 89).1 SourceCells.Shared089.output.1,
     ProofBox.add (totals 89).2.1 SourceCells.Shared089.output.2.1,
     ProofBox.add (totals 89).2.2 SourceCells.Shared089.output.2.2)=totals 90 := by
  decide +kernel
#print axioms sum089
theorem sum090 :
    (ProofBox.add (totals 90).1 SourceCells.Shared090.output.1,
     ProofBox.add (totals 90).2.1 SourceCells.Shared090.output.2.1,
     ProofBox.add (totals 90).2.2 SourceCells.Shared090.output.2.2)=totals 91 := by
  decide +kernel
#print axioms sum090
theorem sum091 :
    (ProofBox.add (totals 91).1 SourceCells.Shared091.output.1,
     ProofBox.add (totals 91).2.1 SourceCells.Shared091.output.2.1,
     ProofBox.add (totals 91).2.2 SourceCells.Shared091.output.2.2)=totals 92 := by
  decide +kernel
#print axioms sum091
theorem sum092 :
    (ProofBox.add (totals 92).1 SourceCells.Shared092.output.1,
     ProofBox.add (totals 92).2.1 SourceCells.Shared092.output.2.1,
     ProofBox.add (totals 92).2.2 SourceCells.Shared092.output.2.2)=totals 93 := by
  decide +kernel
#print axioms sum092
theorem sum093 :
    (ProofBox.add (totals 93).1 SourceCells.Shared093.output.1,
     ProofBox.add (totals 93).2.1 SourceCells.Shared093.output.2.1,
     ProofBox.add (totals 93).2.2 SourceCells.Shared093.output.2.2)=totals 94 := by
  decide +kernel
#print axioms sum093
theorem sum094 :
    (ProofBox.add (totals 94).1 SourceCells.Shared094.output.1,
     ProofBox.add (totals 94).2.1 SourceCells.Shared094.output.2.1,
     ProofBox.add (totals 94).2.2 SourceCells.Shared094.output.2.2)=totals 95 := by
  decide +kernel
#print axioms sum094
theorem sum095 :
    (ProofBox.add (totals 95).1 SourceCells.Shared095.output.1,
     ProofBox.add (totals 95).2.1 SourceCells.Shared095.output.2.1,
     ProofBox.add (totals 95).2.2 SourceCells.Shared095.output.2.2)=totals 96 := by
  decide +kernel
#print axioms sum095
theorem advance (old : SynergyAnalytic.BoxModel.sharedFold 256 64=some (totals 64)) :
    SynergyAnalytic.BoxModel.sharedFold 256 96=some (totals 96) := by
  have fold064 := old
  have fold065 := (CellFoldSteps.shared_next 64 _ _ fold064
    SourceCells.Shared064.model_eq).trans (congrArg some sum064)
  have fold066 := (CellFoldSteps.shared_next 65 _ _ fold065
    SourceCells.Shared065.model_eq).trans (congrArg some sum065)
  have fold067 := (CellFoldSteps.shared_next 66 _ _ fold066
    SourceCells.Shared066.model_eq).trans (congrArg some sum066)
  have fold068 := (CellFoldSteps.shared_next 67 _ _ fold067
    SourceCells.Shared067.model_eq).trans (congrArg some sum067)
  have fold069 := (CellFoldSteps.shared_next 68 _ _ fold068
    SourceCells.Shared068.model_eq).trans (congrArg some sum068)
  have fold070 := (CellFoldSteps.shared_next 69 _ _ fold069
    SourceCells.Shared069.model_eq).trans (congrArg some sum069)
  have fold071 := (CellFoldSteps.shared_next 70 _ _ fold070
    SourceCells.Shared070.model_eq).trans (congrArg some sum070)
  have fold072 := (CellFoldSteps.shared_next 71 _ _ fold071
    SourceCells.Shared071.model_eq).trans (congrArg some sum071)
  have fold073 := (CellFoldSteps.shared_next 72 _ _ fold072
    SourceCells.Shared072.model_eq).trans (congrArg some sum072)
  have fold074 := (CellFoldSteps.shared_next 73 _ _ fold073
    SourceCells.Shared073.model_eq).trans (congrArg some sum073)
  have fold075 := (CellFoldSteps.shared_next 74 _ _ fold074
    SourceCells.Shared074.model_eq).trans (congrArg some sum074)
  have fold076 := (CellFoldSteps.shared_next 75 _ _ fold075
    SourceCells.Shared075.model_eq).trans (congrArg some sum075)
  have fold077 := (CellFoldSteps.shared_next 76 _ _ fold076
    SourceCells.Shared076.model_eq).trans (congrArg some sum076)
  have fold078 := (CellFoldSteps.shared_next 77 _ _ fold077
    SourceCells.Shared077.model_eq).trans (congrArg some sum077)
  have fold079 := (CellFoldSteps.shared_next 78 _ _ fold078
    SourceCells.Shared078.model_eq).trans (congrArg some sum078)
  have fold080 := (CellFoldSteps.shared_next 79 _ _ fold079
    SourceCells.Shared079.model_eq).trans (congrArg some sum079)
  have fold081 := (CellFoldSteps.shared_next 80 _ _ fold080
    SourceCells.Shared080.model_eq).trans (congrArg some sum080)
  have fold082 := (CellFoldSteps.shared_next 81 _ _ fold081
    SourceCells.Shared081.model_eq).trans (congrArg some sum081)
  have fold083 := (CellFoldSteps.shared_next 82 _ _ fold082
    SourceCells.Shared082.model_eq).trans (congrArg some sum082)
  have fold084 := (CellFoldSteps.shared_next 83 _ _ fold083
    SourceCells.Shared083.model_eq).trans (congrArg some sum083)
  have fold085 := (CellFoldSteps.shared_next 84 _ _ fold084
    SourceCells.Shared084.model_eq).trans (congrArg some sum084)
  have fold086 := (CellFoldSteps.shared_next 85 _ _ fold085
    SourceCells.Shared085.model_eq).trans (congrArg some sum085)
  have fold087 := (CellFoldSteps.shared_next 86 _ _ fold086
    SourceCells.Shared086.model_eq).trans (congrArg some sum086)
  have fold088 := (CellFoldSteps.shared_next 87 _ _ fold087
    SourceCells.Shared087.model_eq).trans (congrArg some sum087)
  have fold089 := (CellFoldSteps.shared_next 88 _ _ fold088
    SourceCells.Shared088.model_eq).trans (congrArg some sum088)
  have fold090 := (CellFoldSteps.shared_next 89 _ _ fold089
    SourceCells.Shared089.model_eq).trans (congrArg some sum089)
  have fold091 := (CellFoldSteps.shared_next 90 _ _ fold090
    SourceCells.Shared090.model_eq).trans (congrArg some sum090)
  have fold092 := (CellFoldSteps.shared_next 91 _ _ fold091
    SourceCells.Shared091.model_eq).trans (congrArg some sum091)
  have fold093 := (CellFoldSteps.shared_next 92 _ _ fold092
    SourceCells.Shared092.model_eq).trans (congrArg some sum092)
  have fold094 := (CellFoldSteps.shared_next 93 _ _ fold093
    SourceCells.Shared093.model_eq).trans (congrArg some sum093)
  have fold095 := (CellFoldSteps.shared_next 94 _ _ fold094
    SourceCells.Shared094.model_eq).trans (congrArg some sum094)
  have fold096 := (CellFoldSteps.shared_next 95 _ _ fold095
    SourceCells.Shared095.model_eq).trans (congrArg some sum095)
  exact fold096
#print axioms advance
end SynergyTangentV2C.CellSharedTotals.Block02
