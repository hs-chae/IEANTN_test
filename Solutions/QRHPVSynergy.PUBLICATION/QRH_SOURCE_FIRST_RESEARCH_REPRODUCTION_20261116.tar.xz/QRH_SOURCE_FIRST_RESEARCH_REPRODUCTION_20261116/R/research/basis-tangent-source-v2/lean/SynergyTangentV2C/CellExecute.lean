/- Actual tangentCell C-source execution with11 already proved arithmetic bodies.
The exponential, logarithmic, power and tangent bodies execute through the AST. -/
import SynergyTangentV2C.ArithmeticLibrary
import ScopedC.StateWordEquality
import SynergyC.ExecutePilot
import SynergyAnalytic.TangentCompute
namespace SynergyTangentV2C.CellExecute
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000

abbrev zeroBox : ProofBox := SynergyBasis.Positive.zero
abbrev represented := SynergyC.SourceIntervalMath.represented
def address (base : State) (index : Nat) : Address := ⟨base.heap.length+index,0,[]⟩
def filled (base : State) (output : ProofBox × ProofBox × ProofBox) : State :=
  allocate (allocate (allocate base "I" "b0" (some (represented output.1)))
    "I" "b1" (some (represented output.2.1))) "I" "b2" (some (represented output.2.2))
def buffers (base : State) : State := filled base (zeroBox,zeroBox,zeroBox)
def args (base : State) (left width : ProofBox) (logs : Bool) : List Value :=
  [represented left,represented width,.pointer (address base 0) true,
    .pointer (address base 1) true,.pointer (address base 2) true,
    .integer ⟨⟨true,32⟩,if logs then 2 else 0⟩]

@[irreducible] def run (base : State) (left width : ProofBox) (logs : Bool) :
    Option (Value × State) :=
  ContractExecute.execute SynergyC.Header.layout Generated.functions 128 2048
    SynergyC.ComputableFullService.call 13 "tangentCell"
    (args base left width logs) (buffers base)

def readHasBox (state : State) (location : Address) (box : ProofBox) : Bool :=
  match Machine.read SynergyC.Header.layout state location with
  | none => false
  | some value => SynergyC.ExecutePilot.hasBox value box

def resultCheck (base : State) (output : ProofBox × ProofBox × ProofBox)
    (result : Option (Value × State)) : Bool :=
  match result with
  | none => false
  | some (value,after) =>
    StateWordEquality.valueEq 4 value .unit &&
      (readHasBox after (address base 0) output.1 &&
        (readHasBox after (address base 1) output.2.1 &&
          (readHasBox after (address base 2) output.2.2 &&
            StateWordEquality.stateEq 16 after (filled base output))))

def checked (base : State) (left width : ProofBox) (logs : Bool)
    (output : ProofBox × ProofBox × ProofBox) : Bool :=
  resultCheck base output (run base left width logs)

def checkedModel (base : State) (left width : ProofBox) (logs : Bool) : Bool :=
  match SynergyAnalytic.BoxModel.sourceCell left width logs with
  | none => false
  | some output => checked base left width logs output

theorem read_sound {state : State} {location : Address} {box : ProofBox}
    (h : readHasBox state location box=true) :
    Machine.read SynergyC.Header.layout state location=some (represented box) := by
  cases read : Machine.read SynergyC.Header.layout state location with
  | none => simp [readHasBox,read] at h
  | some value =>
    have eq : value=represented box :=
      SynergyC.ExecutePilot.hasBox_sound (by simpa only [readHasBox,read] using h)
    rw [eq]

theorem result_sound {base : State} {output : ProofBox × ProofBox × ProofBox}
    {result : Option (Value × State)} (h : resultCheck base output result=true) :
    ∃ after, result=some (.unit,after) ∧
      Machine.read SynergyC.Header.layout after (address base 0)=some (represented output.1) ∧
      Machine.read SynergyC.Header.layout after (address base 1)=some (represented output.2.1) ∧
      Machine.read SynergyC.Header.layout after (address base 2)=some (represented output.2.2) ∧
      after=filled {base with nats:=after.nats} output := by
  cases result with
  | none => simp [resultCheck] at h
  | some pair =>
    rcases pair with ⟨value,after⟩
    obtain ⟨hv,rest⟩ := StateWordEquality.split_and h
    obtain ⟨h0,rest⟩ := StateWordEquality.split_and rest
    obtain ⟨h1,rest⟩ := StateWordEquality.split_and rest
    obtain ⟨h2,frame⟩ := StateWordEquality.split_and rest
    have eq : value=.unit := StateWordEquality.valueEq_sound 4 hv
    subst value
    exact ⟨after,rfl,read_sound h0,read_sound h1,read_sound h2,
      StateWordEquality.stateEq_sound frame⟩

theorem source_of_checked {base : State} {left width : ProofBox} {logs : Bool}
    {output : ProofBox × ProofBox × ProofBox}
    (h : checked base left width logs output=true) :
    ∃ after, ArraySourceCalls.SourceCall SynergyC.Header.layout Bundle.code 16 "tangentCell"
      (args base left width logs) (buffers base) .unit after ∧
      Machine.read SynergyC.Header.layout after (address base 0)=some (represented output.1) ∧
      Machine.read SynergyC.Header.layout after (address base 1)=some (represented output.2.1) ∧
      Machine.read SynergyC.Header.layout after (address base 2)=some (represented output.2.2) ∧
      after=filled {base with nats:=after.nats} output := by
  obtain ⟨after,execution,h0,h1,h2,frame⟩ := result_sound h
  have run_eq : run base left width logs = ContractExecute.execute SynergyC.Header.layout
      Generated.functions 128 2048 SynergyC.ComputableFullService.call 13 "tangentCell"
      (args base left width logs) (buffers base) := by unfold run; rfl
  have actual := ContractExecute.execute_sound
    (fun _ _ _ _ _ call => ArithmeticLibrary.closed call)
    (Eq.mp (congrArg (fun value=>value=some (.unit,after)) run_eq) execution)
  have bound : ArraySourceCalls.SourceCall SynergyC.Header.layout Bundle.code 16 "tangentCell"
      (args base left width logs) (buffers base) .unit after :=
    Eq.mpr (congrArg (fun code=>ArraySourceCalls.SourceCall SynergyC.Header.layout code 16
      "tangentCell" (args base left width logs) (buffers base) .unit after) Bundle.code_exact) actual
  exact ⟨after,bound,h0,h1,h2,frame⟩

theorem source_of_checkedModel {base : State} {left width : ProofBox} {logs : Bool}
    (h : checkedModel base left width logs=true) :
    ∃ output, SynergyAnalytic.BoxModel.sourceCell left width logs=some output ∧
      ∃ after, ArraySourceCalls.SourceCall SynergyC.Header.layout Bundle.code 16 "tangentCell"
        (args base left width logs) (buffers base) .unit after ∧
        Machine.read SynergyC.Header.layout after (address base 0)=some (represented output.1) ∧
        Machine.read SynergyC.Header.layout after (address base 1)=some (represented output.2.1) ∧
        Machine.read SynergyC.Header.layout after (address base 2)=some (represented output.2.2) ∧
        after=filled {base with nats:=after.nats} output := by
  cases model : SynergyAnalytic.BoxModel.sourceCell left width logs with
  | none => simp [checkedModel,model] at h
  | some output =>
    exact ⟨output,rfl,source_of_checked (by simpa only [checkedModel,model] using h)⟩

#print axioms read_sound
#print axioms result_sound
#print axioms source_of_checked
#print axioms source_of_checkedModel
end SynergyTangentV2C.CellExecute
