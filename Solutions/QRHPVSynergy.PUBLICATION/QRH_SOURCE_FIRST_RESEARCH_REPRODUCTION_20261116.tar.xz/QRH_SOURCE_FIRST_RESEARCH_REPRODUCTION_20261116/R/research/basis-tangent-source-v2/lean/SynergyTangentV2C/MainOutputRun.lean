/- The actual eight emitU calls and three-iteration output loop. -/
import SynergyTangentV2C.MainOutputExpressions
namespace SynergyTangentV2C.MainOutputRun
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical ScopedIO ScopedIO.WorldIO
open MainOutputData
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

theorem world_guard (platform : Platform) (stream : Stream) (i : Nat) (hi : i ≤ 3) :
    WorldSource.Eval Header.layout MainLn2.service (MainWorldService.call platform) platform
      guard ⟨atIndex i,stream⟩ ⟨atIndex i,stream⟩
      (Machine.boolean Header.layout (decide (i<3))) :=
  .pure (MainOutputExpressions.guard_value i hi)

theorem row (platform : Platform) (stream : Stream) (i : Nat) (hi : i < 3) :
    WorldSource.Run Header.layout MainLn2.service (MainWorldService.call platform) platform
      (.sequence body) ⟨atIndex i,streamAfter stream (2+2*i)⟩
      (.continuing ⟨atIndex (i+1),streamAfter stream (2+2*(i+1))⟩) := by
  have lo := MainOutputExpressions.source_emit platform (atIndex i)
    (streamAfter stream (2+2*i)) loExpr (word (2+2*i)) (range _ (by omega))
    (stdout i) (MainOutputExpressions.read_lo i hi)
  have hiProof := MainOutputExpressions.source_emit platform (atIndex i)
    (streamAfter stream (2+2*i+1)) hiExpr (word (2+2*i+1)) (range _ (by omega))
    (stdout i) (MainOutputExpressions.read_hi i hi)
  have increment : WorldSource.Run Header.layout MainLn2.service
      (MainWorldService.call platform) platform
      (.eval (.binary "=" (.var "i") (.binary "+" (.var "i") (.nat 1))))
      ⟨atIndex i,streamAfter stream (2+2*i+1+1)⟩
      (.continuing ⟨atIndex (i+1),streamAfter stream (2+2*i+1+1)⟩) :=
    .evaluate (.pure (MainOutputExpressions.increment i hi))
  have lo' : WorldSource.Run Header.layout MainLn2.service
      (MainWorldService.call platform) platform (.eval (.call (.var "emitU") [loExpr]))
      ⟨atIndex i,streamAfter stream (2+2*i)⟩
      (.continuing ⟨atIndex i,streamAfter stream (2+2*i+1)⟩) := lo
  have hi' : WorldSource.Run Header.layout MainLn2.service
      (MainWorldService.call platform) platform (.eval (.call (.var "emitU") [hiExpr]))
      ⟨atIndex i,streamAfter stream (2+2*i+1)⟩
      (.continuing ⟨atIndex i,streamAfter stream (2+2*i+1+1)⟩) := hiProof
  have all := Loops.SeqRun.next lo'
    (.next hi' (.next increment (.nil _)))
  have last : 2+2*i+1+1 = 2+2*(i+1) := by omega
  rw [last] at all
  refine Loops.StmtRun.sequence all ?_
  change (⟨atIndex (i+1),streamAfter stream (2+2*(i+1))⟩ : World) =
    ⟨Machine.popScope (atIndex i) (atIndex (i+1)),streamAfter stream (2+2*(i+1))⟩
  rw [restored]

theorem output_loop (platform : Platform) (stream : Stream) :
    WorldSource.Run Header.layout MainLn2.service (MainWorldService.call platform) platform
      (.whileLoop guard (.sequence body)) ⟨atIndex 0,streamAfter stream 2⟩
      (.continuing ⟨atIndex 3,streamAfter stream 8⟩) :=
  Loops.StmtRun.whileLoop
    (.next (world_guard platform (streamAfter stream 2) 0 (by decide)) (by decide)
      (row platform stream 0 (by decide))
      (.next (world_guard platform (streamAfter stream 4) 1 (by decide)) (by decide)
        (row platform stream 1 (by decide))
        (.next (world_guard platform (streamAfter stream 6) 2 (by decide)) (by decide)
          (row platform stream 2 (by decide))
          (.done (world_guard platform (streamAfter stream 8) 3 (by decide)) (by decide)))))

theorem output_prefix (platform : Platform) (stream : Stream) :
    Loops.SeqRun (WorldSource.Eval Header.layout MainLn2.service
      (MainWorldService.call platform) platform) (WorldSource.Declare Header.layout MainLn2.service)
      truth WorldSource.Scope ((MainLn2.statements.drop 19).take 4)
      ⟨MainFooter.after,stream⟩ (.continuing ⟨atIndex 3,streamAfter stream 8⟩) := by
  have first := MainOutputExpressions.source_emit platform MainFooter.after stream
    (.cast "U" (.var "cells")) (word 0) (range 0 (by decide))
    (by rfl) MainOutputExpressions.cells
  have second := MainOutputExpressions.source_emit platform MainFooter.after (streamAfter stream 1)
    (.cast "U" (.var "prefix")) (word 1) (range 1 (by decide))
    (by rfl) MainOutputExpressions.prefix_value
  have resetProof : WorldSource.Run Header.layout MainLn2.service
      (MainWorldService.call platform) platform reset
      ⟨MainFooter.after,streamAfter stream 2⟩
      (.continuing ⟨atIndex 0,streamAfter stream 2⟩) :=
    .evaluate (.pure MainOutputExpressions.reset)
  exact .next first (.next second (.next resetProof
    (.next (output_loop platform stream) (.nil _))))

theorem actual_return (platform : Platform) (stream : Stream)
    (healthy : stream.error = false) :
    ConditionalWorld.Run Header.layout MainLn2.service (MainWorldService.call platform) platform
      (.returnStmt (.conditional (.call (.var "ferror") [.var "stdout"]) (.nat 2) (.nat 0)))
      ⟨atIndex 3,streamAfter stream 8⟩
      (.returned ⟨atIndex 3,streamAfter stream 8⟩ (WorldIO.signed32 0)) := by
  have test : WorldSource.Eval Header.layout MainLn2.service
      (MainWorldService.call platform) platform (.call (.var "ferror") [.var "stdout"])
      ⟨atIndex 3,streamAfter stream 8⟩ ⟨atIndex 3,streamAfter stream 8⟩
      (WorldIO.signed32 0) :=
    .call (.cons (.stdout (by rfl)) (.nil _))
      (MainWorldService.ferror_healthy platform _ ((stream_error stream 8).trans healthy))
  apply Loops.StmtRun.returnValue
  exact .conditional (.old test) (.old (.pure (fuel:=1) rfl))

#print axioms world_guard
#print axioms row
#print axioms output_loop
#print axioms output_prefix
#print axioms actual_return
end SynergyTangentV2C.MainOutputRun
