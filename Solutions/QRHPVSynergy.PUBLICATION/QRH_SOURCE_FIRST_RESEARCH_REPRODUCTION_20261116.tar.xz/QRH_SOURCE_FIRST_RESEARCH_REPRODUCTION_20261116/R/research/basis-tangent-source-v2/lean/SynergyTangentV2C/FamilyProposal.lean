/- Untrusted numerical/source-interpreter proposals for every fixed cell.
The generated words and native checks are not accepted proof leaves. -/
import SynergyTangentV2C.CellExecute
import SynergyTangentV2C.MainFrames
open Lean
namespace SynergyTangentV2C.FamilyProposal
open ScopedC ScopedC.Machine ScopedNumerical

def propose (isPrefix : Bool) (index : Nat) : Option Json := do
  let ln := if isPrefix then 80+index else 256+15*index
  let ld := if isPrefix then 96 else 256
  let wn := if isPrefix then 1 else 15
  let wd := if isPrefix then 96 else 256
  let logs := !isPrefix
  let left := SynergyAnalytic.BoxModel.rat ln ld
  let width := SynergyAnalytic.BoxModel.rat wn wd
  let output ← SynergyAnalytic.BoxModel.sourceCell left width logs
  let before := MainFrames.base (CellExecute.zeroBox,CellExecute.zeroBox,CellExecute.zeroBox)
    index left
  if !CellExecute.checked before left width logs output then none else
  pure (Json.mkObj [
    ("kind",Json.str (if isPrefix then "prefix" else "shared")),
    ("index",toJson index), ("left_numerator",toJson ln), ("left_denominator",toJson ld),
    ("width_numerator",toJson wn), ("width_denominator",toJson wd),
    ("logs",toJson logs), ("native_actual_ast_checked",toJson true),
    ("words",toJson ([output.1.lo,output.1.hi,output.2.1.lo,output.2.1.hi,
      output.2.2.lo,output.2.2.hi].map (fun word => toString word)))])

def run : IO Unit := do
  let rows := (List.range 16).mapM (propose true)
  let shared := (List.range 256).mapM (propose false)
  match rows,shared with
  | some preRows,some body =>
    IO.println (Json.mkObj [
      ("classification",Json.str "UNTRUSTED_ALL272_PROPOSALS_NOT_PROOF"),
      ("cells",toJson 256),("prefix",toJson 16),("fractional_bits",toJson 128),
      ("word_bits",toJson 512),("rows",toJson (preRows++body))]).compress
  | _,_ => throw (IO.userError "A fixed cell failed untrusted model/actual-AST proposal execution")

#eval run
end SynergyTangentV2C.FamilyProposal
