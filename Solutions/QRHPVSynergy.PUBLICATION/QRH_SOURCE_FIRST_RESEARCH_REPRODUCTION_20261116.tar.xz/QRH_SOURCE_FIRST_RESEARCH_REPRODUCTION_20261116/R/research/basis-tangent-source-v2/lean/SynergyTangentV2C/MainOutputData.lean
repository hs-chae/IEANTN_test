/- The eight output words refer to the SAME C J storage proved by MainFooter. -/
import SynergyTangentV2C.MainFooter
import SynergyTangentV2C.EmitUNormal
namespace SynergyTangentV2C.MainOutputData
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical ScopedIO
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def words : List Int := [256,16,MainFooter.output.1.lo,MainFooter.output.1.hi,
  MainFooter.output.2.1.lo,MainFooter.output.2.1.hi,
  MainFooter.output.2.2.lo,MainFooter.output.2.2.hi]
def word (i : Nat) : Int := words[i]?.getD 0
def streamAfter (stream : Stream) : Nat → Stream
  | 0 => stream
  | i+1 => EmitUNormal.appendWord (streamAfter stream i) (word i)
def bytes : List Nat := (words.map EmitUBuffer.bytes).flatten
def atIndex (i : Nat) : State := {MainFooter.after with
  heap := MainFooter.after.heap.set 6 {
    type := "unsigned int", cells := [some (MainFrames.unsigned i)]}}
def guard : Expr := .binary "<" (.var "i") (.nat 3)
def loExpr : Expr := .field "." (.index (.var "J") (.var "i")) "lo"
def hiExpr : Expr := .field "." (.index (.var "J") (.var "i")) "hi"
def body : List Stmt := [.eval (.call (.var "emitU") [loExpr]),
  .eval (.call (.var "emitU") [hiExpr]),
  .eval (.binary "=" (.var "i") (.binary "+" (.var "i") (.nat 1)))]
def reset : Stmt := .eval (.binary "=" (.var "i") (.nat 0))

theorem actual_tail : MainLn2.statements.drop 19 = [
    .eval (.call (.var "emitU") [.cast "U" (.var "cells")]),
    .eval (.call (.var "emitU") [.cast "U" (.var "prefix")]),reset,
    .whileLoop guard (.sequence body),
    .returnStmt (.conditional (.call (.var "ferror") [.var "stdout"]) (.nat 2) (.nat 0))] := by
  rfl
theorem range (i : Nat) (hi : i < 8) : SynergyC.Word512.Range (word i) := by
  unfold SynergyC.Word512.Range
  interval_cases i <;> decide +kernel
theorem stdout (i : Nat) : (atIndex i).globals.lookup "stdout" = none := by rfl
theorem restored (i : Nat) : Machine.popScope (atIndex i) (atIndex (i+1)) =
    atIndex (i+1) := by rfl
theorem stream_error (stream : Stream) (i : Nat) :
    (streamAfter stream i).error = stream.error := by
  induction i with
  | zero => rfl
  | succ i ih => exact ih
theorem accepted (stream : Stream) :
    (streamAfter stream 8).accepted = stream.accepted ++ bytes := by
  simp only [streamAfter,EmitUNormal.appendWord,bytes,words,word,List.getElem?_cons_zero,
    List.getElem?_cons_succ,Option.getD_some,List.map_cons,List.map_nil,
    List.flatten_cons,List.flatten_nil,List.append_nil,List.append_assoc]

#print axioms actual_tail
#print axioms range
#print axioms stdout
#print axioms restored
#print axioms stream_error
#print axioms accepted
end SynergyTangentV2C.MainOutputData
