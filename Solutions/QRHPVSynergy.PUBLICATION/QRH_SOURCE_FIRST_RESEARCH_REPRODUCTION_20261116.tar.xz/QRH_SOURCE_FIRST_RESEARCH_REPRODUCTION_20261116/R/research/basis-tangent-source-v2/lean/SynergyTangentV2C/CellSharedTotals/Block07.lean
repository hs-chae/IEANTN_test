/- Exact cumulative sums, using the corresponding accepted fixed-cell model equations. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Shared224
import SynergyTangentV2C.SourceCells.Shared225
import SynergyTangentV2C.SourceCells.Shared226
import SynergyTangentV2C.SourceCells.Shared227
import SynergyTangentV2C.SourceCells.Shared228
import SynergyTangentV2C.SourceCells.Shared229
import SynergyTangentV2C.SourceCells.Shared230
import SynergyTangentV2C.SourceCells.Shared231
import SynergyTangentV2C.SourceCells.Shared232
import SynergyTangentV2C.SourceCells.Shared233
import SynergyTangentV2C.SourceCells.Shared234
import SynergyTangentV2C.SourceCells.Shared235
import SynergyTangentV2C.SourceCells.Shared236
import SynergyTangentV2C.SourceCells.Shared237
import SynergyTangentV2C.SourceCells.Shared238
import SynergyTangentV2C.SourceCells.Shared239
import SynergyTangentV2C.SourceCells.Shared240
import SynergyTangentV2C.SourceCells.Shared241
import SynergyTangentV2C.SourceCells.Shared242
import SynergyTangentV2C.SourceCells.Shared243
import SynergyTangentV2C.SourceCells.Shared244
import SynergyTangentV2C.SourceCells.Shared245
import SynergyTangentV2C.SourceCells.Shared246
import SynergyTangentV2C.SourceCells.Shared247
import SynergyTangentV2C.SourceCells.Shared248
import SynergyTangentV2C.SourceCells.Shared249
import SynergyTangentV2C.SourceCells.Shared250
import SynergyTangentV2C.SourceCells.Shared251
import SynergyTangentV2C.SourceCells.Shared252
import SynergyTangentV2C.SourceCells.Shared253
import SynergyTangentV2C.SourceCells.Shared254
import SynergyTangentV2C.SourceCells.Shared255
namespace SynergyTangentV2C.CellSharedTotals.Block07
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.sharedOnlyTotals
theorem sum224 :
    (ProofBox.add (totals 224).1 SourceCells.Shared224.output.1,
     ProofBox.add (totals 224).2.1 SourceCells.Shared224.output.2.1,
     ProofBox.add (totals 224).2.2 SourceCells.Shared224.output.2.2)=totals 225 := by
  decide +kernel
#print axioms sum224
theorem sum225 :
    (ProofBox.add (totals 225).1 SourceCells.Shared225.output.1,
     ProofBox.add (totals 225).2.1 SourceCells.Shared225.output.2.1,
     ProofBox.add (totals 225).2.2 SourceCells.Shared225.output.2.2)=totals 226 := by
  decide +kernel
#print axioms sum225
theorem sum226 :
    (ProofBox.add (totals 226).1 SourceCells.Shared226.output.1,
     ProofBox.add (totals 226).2.1 SourceCells.Shared226.output.2.1,
     ProofBox.add (totals 226).2.2 SourceCells.Shared226.output.2.2)=totals 227 := by
  decide +kernel
#print axioms sum226
theorem sum227 :
    (ProofBox.add (totals 227).1 SourceCells.Shared227.output.1,
     ProofBox.add (totals 227).2.1 SourceCells.Shared227.output.2.1,
     ProofBox.add (totals 227).2.2 SourceCells.Shared227.output.2.2)=totals 228 := by
  decide +kernel
#print axioms sum227
theorem sum228 :
    (ProofBox.add (totals 228).1 SourceCells.Shared228.output.1,
     ProofBox.add (totals 228).2.1 SourceCells.Shared228.output.2.1,
     ProofBox.add (totals 228).2.2 SourceCells.Shared228.output.2.2)=totals 229 := by
  decide +kernel
#print axioms sum228
theorem sum229 :
    (ProofBox.add (totals 229).1 SourceCells.Shared229.output.1,
     ProofBox.add (totals 229).2.1 SourceCells.Shared229.output.2.1,
     ProofBox.add (totals 229).2.2 SourceCells.Shared229.output.2.2)=totals 230 := by
  decide +kernel
#print axioms sum229
theorem sum230 :
    (ProofBox.add (totals 230).1 SourceCells.Shared230.output.1,
     ProofBox.add (totals 230).2.1 SourceCells.Shared230.output.2.1,
     ProofBox.add (totals 230).2.2 SourceCells.Shared230.output.2.2)=totals 231 := by
  decide +kernel
#print axioms sum230
theorem sum231 :
    (ProofBox.add (totals 231).1 SourceCells.Shared231.output.1,
     ProofBox.add (totals 231).2.1 SourceCells.Shared231.output.2.1,
     ProofBox.add (totals 231).2.2 SourceCells.Shared231.output.2.2)=totals 232 := by
  decide +kernel
#print axioms sum231
theorem sum232 :
    (ProofBox.add (totals 232).1 SourceCells.Shared232.output.1,
     ProofBox.add (totals 232).2.1 SourceCells.Shared232.output.2.1,
     ProofBox.add (totals 232).2.2 SourceCells.Shared232.output.2.2)=totals 233 := by
  decide +kernel
#print axioms sum232
theorem sum233 :
    (ProofBox.add (totals 233).1 SourceCells.Shared233.output.1,
     ProofBox.add (totals 233).2.1 SourceCells.Shared233.output.2.1,
     ProofBox.add (totals 233).2.2 SourceCells.Shared233.output.2.2)=totals 234 := by
  decide +kernel
#print axioms sum233
theorem sum234 :
    (ProofBox.add (totals 234).1 SourceCells.Shared234.output.1,
     ProofBox.add (totals 234).2.1 SourceCells.Shared234.output.2.1,
     ProofBox.add (totals 234).2.2 SourceCells.Shared234.output.2.2)=totals 235 := by
  decide +kernel
#print axioms sum234
theorem sum235 :
    (ProofBox.add (totals 235).1 SourceCells.Shared235.output.1,
     ProofBox.add (totals 235).2.1 SourceCells.Shared235.output.2.1,
     ProofBox.add (totals 235).2.2 SourceCells.Shared235.output.2.2)=totals 236 := by
  decide +kernel
#print axioms sum235
theorem sum236 :
    (ProofBox.add (totals 236).1 SourceCells.Shared236.output.1,
     ProofBox.add (totals 236).2.1 SourceCells.Shared236.output.2.1,
     ProofBox.add (totals 236).2.2 SourceCells.Shared236.output.2.2)=totals 237 := by
  decide +kernel
#print axioms sum236
theorem sum237 :
    (ProofBox.add (totals 237).1 SourceCells.Shared237.output.1,
     ProofBox.add (totals 237).2.1 SourceCells.Shared237.output.2.1,
     ProofBox.add (totals 237).2.2 SourceCells.Shared237.output.2.2)=totals 238 := by
  decide +kernel
#print axioms sum237
theorem sum238 :
    (ProofBox.add (totals 238).1 SourceCells.Shared238.output.1,
     ProofBox.add (totals 238).2.1 SourceCells.Shared238.output.2.1,
     ProofBox.add (totals 238).2.2 SourceCells.Shared238.output.2.2)=totals 239 := by
  decide +kernel
#print axioms sum238
theorem sum239 :
    (ProofBox.add (totals 239).1 SourceCells.Shared239.output.1,
     ProofBox.add (totals 239).2.1 SourceCells.Shared239.output.2.1,
     ProofBox.add (totals 239).2.2 SourceCells.Shared239.output.2.2)=totals 240 := by
  decide +kernel
#print axioms sum239
theorem sum240 :
    (ProofBox.add (totals 240).1 SourceCells.Shared240.output.1,
     ProofBox.add (totals 240).2.1 SourceCells.Shared240.output.2.1,
     ProofBox.add (totals 240).2.2 SourceCells.Shared240.output.2.2)=totals 241 := by
  decide +kernel
#print axioms sum240
theorem sum241 :
    (ProofBox.add (totals 241).1 SourceCells.Shared241.output.1,
     ProofBox.add (totals 241).2.1 SourceCells.Shared241.output.2.1,
     ProofBox.add (totals 241).2.2 SourceCells.Shared241.output.2.2)=totals 242 := by
  decide +kernel
#print axioms sum241
theorem sum242 :
    (ProofBox.add (totals 242).1 SourceCells.Shared242.output.1,
     ProofBox.add (totals 242).2.1 SourceCells.Shared242.output.2.1,
     ProofBox.add (totals 242).2.2 SourceCells.Shared242.output.2.2)=totals 243 := by
  decide +kernel
#print axioms sum242
theorem sum243 :
    (ProofBox.add (totals 243).1 SourceCells.Shared243.output.1,
     ProofBox.add (totals 243).2.1 SourceCells.Shared243.output.2.1,
     ProofBox.add (totals 243).2.2 SourceCells.Shared243.output.2.2)=totals 244 := by
  decide +kernel
#print axioms sum243
theorem sum244 :
    (ProofBox.add (totals 244).1 SourceCells.Shared244.output.1,
     ProofBox.add (totals 244).2.1 SourceCells.Shared244.output.2.1,
     ProofBox.add (totals 244).2.2 SourceCells.Shared244.output.2.2)=totals 245 := by
  decide +kernel
#print axioms sum244
theorem sum245 :
    (ProofBox.add (totals 245).1 SourceCells.Shared245.output.1,
     ProofBox.add (totals 245).2.1 SourceCells.Shared245.output.2.1,
     ProofBox.add (totals 245).2.2 SourceCells.Shared245.output.2.2)=totals 246 := by
  decide +kernel
#print axioms sum245
theorem sum246 :
    (ProofBox.add (totals 246).1 SourceCells.Shared246.output.1,
     ProofBox.add (totals 246).2.1 SourceCells.Shared246.output.2.1,
     ProofBox.add (totals 246).2.2 SourceCells.Shared246.output.2.2)=totals 247 := by
  decide +kernel
#print axioms sum246
theorem sum247 :
    (ProofBox.add (totals 247).1 SourceCells.Shared247.output.1,
     ProofBox.add (totals 247).2.1 SourceCells.Shared247.output.2.1,
     ProofBox.add (totals 247).2.2 SourceCells.Shared247.output.2.2)=totals 248 := by
  decide +kernel
#print axioms sum247
theorem sum248 :
    (ProofBox.add (totals 248).1 SourceCells.Shared248.output.1,
     ProofBox.add (totals 248).2.1 SourceCells.Shared248.output.2.1,
     ProofBox.add (totals 248).2.2 SourceCells.Shared248.output.2.2)=totals 249 := by
  decide +kernel
#print axioms sum248
theorem sum249 :
    (ProofBox.add (totals 249).1 SourceCells.Shared249.output.1,
     ProofBox.add (totals 249).2.1 SourceCells.Shared249.output.2.1,
     ProofBox.add (totals 249).2.2 SourceCells.Shared249.output.2.2)=totals 250 := by
  decide +kernel
#print axioms sum249
theorem sum250 :
    (ProofBox.add (totals 250).1 SourceCells.Shared250.output.1,
     ProofBox.add (totals 250).2.1 SourceCells.Shared250.output.2.1,
     ProofBox.add (totals 250).2.2 SourceCells.Shared250.output.2.2)=totals 251 := by
  decide +kernel
#print axioms sum250
theorem sum251 :
    (ProofBox.add (totals 251).1 SourceCells.Shared251.output.1,
     ProofBox.add (totals 251).2.1 SourceCells.Shared251.output.2.1,
     ProofBox.add (totals 251).2.2 SourceCells.Shared251.output.2.2)=totals 252 := by
  decide +kernel
#print axioms sum251
theorem sum252 :
    (ProofBox.add (totals 252).1 SourceCells.Shared252.output.1,
     ProofBox.add (totals 252).2.1 SourceCells.Shared252.output.2.1,
     ProofBox.add (totals 252).2.2 SourceCells.Shared252.output.2.2)=totals 253 := by
  decide +kernel
#print axioms sum252
theorem sum253 :
    (ProofBox.add (totals 253).1 SourceCells.Shared253.output.1,
     ProofBox.add (totals 253).2.1 SourceCells.Shared253.output.2.1,
     ProofBox.add (totals 253).2.2 SourceCells.Shared253.output.2.2)=totals 254 := by
  decide +kernel
#print axioms sum253
theorem sum254 :
    (ProofBox.add (totals 254).1 SourceCells.Shared254.output.1,
     ProofBox.add (totals 254).2.1 SourceCells.Shared254.output.2.1,
     ProofBox.add (totals 254).2.2 SourceCells.Shared254.output.2.2)=totals 255 := by
  decide +kernel
#print axioms sum254
theorem sum255 :
    (ProofBox.add (totals 255).1 SourceCells.Shared255.output.1,
     ProofBox.add (totals 255).2.1 SourceCells.Shared255.output.2.1,
     ProofBox.add (totals 255).2.2 SourceCells.Shared255.output.2.2)=totals 256 := by
  decide +kernel
#print axioms sum255
theorem advance (old : SynergyAnalytic.BoxModel.sharedFold 256 224=some (totals 224)) :
    SynergyAnalytic.BoxModel.sharedFold 256 256=some (totals 256) := by
  have fold224 := old
  have fold225 := (CellFoldSteps.shared_next 224 _ _ fold224
    SourceCells.Shared224.model_eq).trans (congrArg some sum224)
  have fold226 := (CellFoldSteps.shared_next 225 _ _ fold225
    SourceCells.Shared225.model_eq).trans (congrArg some sum225)
  have fold227 := (CellFoldSteps.shared_next 226 _ _ fold226
    SourceCells.Shared226.model_eq).trans (congrArg some sum226)
  have fold228 := (CellFoldSteps.shared_next 227 _ _ fold227
    SourceCells.Shared227.model_eq).trans (congrArg some sum227)
  have fold229 := (CellFoldSteps.shared_next 228 _ _ fold228
    SourceCells.Shared228.model_eq).trans (congrArg some sum228)
  have fold230 := (CellFoldSteps.shared_next 229 _ _ fold229
    SourceCells.Shared229.model_eq).trans (congrArg some sum229)
  have fold231 := (CellFoldSteps.shared_next 230 _ _ fold230
    SourceCells.Shared230.model_eq).trans (congrArg some sum230)
  have fold232 := (CellFoldSteps.shared_next 231 _ _ fold231
    SourceCells.Shared231.model_eq).trans (congrArg some sum231)
  have fold233 := (CellFoldSteps.shared_next 232 _ _ fold232
    SourceCells.Shared232.model_eq).trans (congrArg some sum232)
  have fold234 := (CellFoldSteps.shared_next 233 _ _ fold233
    SourceCells.Shared233.model_eq).trans (congrArg some sum233)
  have fold235 := (CellFoldSteps.shared_next 234 _ _ fold234
    SourceCells.Shared234.model_eq).trans (congrArg some sum234)
  have fold236 := (CellFoldSteps.shared_next 235 _ _ fold235
    SourceCells.Shared235.model_eq).trans (congrArg some sum235)
  have fold237 := (CellFoldSteps.shared_next 236 _ _ fold236
    SourceCells.Shared236.model_eq).trans (congrArg some sum236)
  have fold238 := (CellFoldSteps.shared_next 237 _ _ fold237
    SourceCells.Shared237.model_eq).trans (congrArg some sum237)
  have fold239 := (CellFoldSteps.shared_next 238 _ _ fold238
    SourceCells.Shared238.model_eq).trans (congrArg some sum238)
  have fold240 := (CellFoldSteps.shared_next 239 _ _ fold239
    SourceCells.Shared239.model_eq).trans (congrArg some sum239)
  have fold241 := (CellFoldSteps.shared_next 240 _ _ fold240
    SourceCells.Shared240.model_eq).trans (congrArg some sum240)
  have fold242 := (CellFoldSteps.shared_next 241 _ _ fold241
    SourceCells.Shared241.model_eq).trans (congrArg some sum241)
  have fold243 := (CellFoldSteps.shared_next 242 _ _ fold242
    SourceCells.Shared242.model_eq).trans (congrArg some sum242)
  have fold244 := (CellFoldSteps.shared_next 243 _ _ fold243
    SourceCells.Shared243.model_eq).trans (congrArg some sum243)
  have fold245 := (CellFoldSteps.shared_next 244 _ _ fold244
    SourceCells.Shared244.model_eq).trans (congrArg some sum244)
  have fold246 := (CellFoldSteps.shared_next 245 _ _ fold245
    SourceCells.Shared245.model_eq).trans (congrArg some sum245)
  have fold247 := (CellFoldSteps.shared_next 246 _ _ fold246
    SourceCells.Shared246.model_eq).trans (congrArg some sum246)
  have fold248 := (CellFoldSteps.shared_next 247 _ _ fold247
    SourceCells.Shared247.model_eq).trans (congrArg some sum247)
  have fold249 := (CellFoldSteps.shared_next 248 _ _ fold248
    SourceCells.Shared248.model_eq).trans (congrArg some sum248)
  have fold250 := (CellFoldSteps.shared_next 249 _ _ fold249
    SourceCells.Shared249.model_eq).trans (congrArg some sum249)
  have fold251 := (CellFoldSteps.shared_next 250 _ _ fold250
    SourceCells.Shared250.model_eq).trans (congrArg some sum250)
  have fold252 := (CellFoldSteps.shared_next 251 _ _ fold251
    SourceCells.Shared251.model_eq).trans (congrArg some sum251)
  have fold253 := (CellFoldSteps.shared_next 252 _ _ fold252
    SourceCells.Shared252.model_eq).trans (congrArg some sum252)
  have fold254 := (CellFoldSteps.shared_next 253 _ _ fold253
    SourceCells.Shared253.model_eq).trans (congrArg some sum253)
  have fold255 := (CellFoldSteps.shared_next 254 _ _ fold254
    SourceCells.Shared254.model_eq).trans (congrArg some sum254)
  have fold256 := (CellFoldSteps.shared_next 255 _ _ fold255
    SourceCells.Shared255.model_eq).trans (congrArg some sum255)
  exact fold256
#print axioms advance
end SynergyTangentV2C.CellSharedTotals.Block07
