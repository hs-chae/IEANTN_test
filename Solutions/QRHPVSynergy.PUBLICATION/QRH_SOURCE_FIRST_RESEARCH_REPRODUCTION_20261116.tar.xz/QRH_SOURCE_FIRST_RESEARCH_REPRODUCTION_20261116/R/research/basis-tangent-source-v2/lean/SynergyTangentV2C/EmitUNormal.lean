/- Constructive normal-I/O scenario for the actual tangent emitter.
It is a model scenario, not an axiom about successful host I/O. -/
import SynergyTangentV2C.EmitUCallWord
namespace SynergyTangentV2C.EmitUNormal
open ScopedC ScopedC.Machine ScopedIO
open SynergyTangentV2C.EmitUStorage
set_option autoImplicit false
set_option maxHeartbeats 20000
set_option maxRecDepth 100000

def policy : WorldIO.FaultPolicy := {
  succeed := fun _ _ => true
  count := fun _ _ => 0 }

def appendWord (stream : Stream) (x : Int) : Stream :=
  {stream with accepted := stream.accepted ++ EmitUBuffer.bytes x}

theorem frame_stdout (caller : State) (x : Int) (i : Nat) :
    Machine.getVar (frame caller x i) "stdout" = caller.globals.lookup "stdout" := by
  simp [Machine.getVar,env_shape,frame,array,EmitUFrames.parameter,Machine.allocate,List.lookup]

theorem invoke_success (platform : WorldIO.Platform) (caller : State) (x : Int)
    (stream : Stream) (stdout : caller.globals.lookup "stdout" = none) :
    EmitUService.invoke platform policy x ⟨caller,stream⟩ =
      some (.unit,⟨caller,appendWord stream x⟩) := by
  have unshadowed : Machine.getVar (frame caller x 8) "stdout" = none := by
    rw [frame_stdout,stdout]
  have io := WorldIO.fwrite_equation platform policy
    (⟨frame caller x 8,stream⟩ : WorldIO.World) (wordsAddress caller) true
    (.integer ⟨⟨true,32⟩,8⟩) (.integer ⟨⟨true,32⟩,8⟩)
    (WorldIO.stdoutValue platform) (EmitUBuffer.bytes x) rfl rfl
    (WorldIO.stdout_handle platform) (EmitUBuffer.actual_bytes caller x)
  unfold EmitUService.invoke
  simp only [unshadowed,ne_eq,not_true_eq_false,↓reduceIte,EmitUService.arguments]
  rw [io]
  rfl

theorem emitU_success (platform : WorldIO.Platform) (caller : State) (x : Int)
    (range : SynergyC.Word512.Range x) (stream : Stream)
    (stdout : caller.globals.lookup "stdout" = none) :
    EmitUService.call platform policy "emitU" [SynergyC.Word512.value x] ⟨caller,stream⟩ =
      some (.unit,⟨caller,appendWord stream x⟩) :=
  (EmitUCallWord.call_word platform policy x range ⟨caller,stream⟩).trans
    (invoke_success platform caller x stream stdout)

theorem source_emission (platform : WorldIO.Platform) (caller : State) (x : Int)
    (range : SynergyC.Word512.Range x) (stream : Stream)
    (stdout : caller.globals.lookup "stdout" = none) :
    WorldSource.SourceCall SynergyC.Header.layout Bundle.code platform policy 1
      "emitU" [SynergyC.Word512.value x] ⟨caller,stream⟩ .unit
      ⟨caller,appendWord stream x⟩ :=
  EmitUService.closed platform policy (emitU_success platform caller x range stream stdout)

#print axioms frame_stdout
#print axioms invoke_success
#print axioms emitU_success
#print axioms source_emission
end SynergyTangentV2C.EmitUNormal
