/- Add only the documented healthy-stream ferror observation, through the
existing parameterized I/O semantics. Old source and runtime definitions are
unchanged. API contract: Linux man-pages ferror(3), RETURN VALUE:
https://man7.org/linux/man-pages/man3/ferror.3.html#RETURN_VALUE
No application output, initialization or write success is a platform leaf. -/
import ScopedIO.WorldSourceWith
namespace SynergyTangentV2C.WorldError
open ScopedC ScopedC.Machine ScopedIO
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Partial healthy-path API model. Error-stream returns are deliberately
outside this observation; zero is never asserted when the indicator is set. -/
def query (platform : WorldIO.Platform) : WorldIO.Call := fun name args world =>
  if name = "ferror" then
    match args with
    | [handle] => if WorldIO.isStdout platform handle && !world.stream.error then
        some (WorldIO.signed32 0,world) else none
    | _ => none
  else none

def external (platform : WorldIO.Platform) (fault : WorldIO.FaultPolicy) : WorldIO.Call :=
  fun name args world => match WorldIO.external platform fault name args world with
    | some result => some result
    | none => query platform name args world

theorem old_included {platform : WorldIO.Platform} {fault : WorldIO.FaultPolicy}
    {name : String} {args : List Value} {before after : WorldIO.World} {value : Value}
    (h : WorldIO.external platform fault name args before = some (value,after)) :
    external platform fault name args before = some (value,after) := by
  unfold external
  rw [h]

theorem ferror_healthy (platform : WorldIO.Platform) (fault : WorldIO.FaultPolicy)
    (world : WorldIO.World) (healthy : world.stream.error = false) :
    external platform fault "ferror" [WorldIO.stdoutValue platform] world =
      some (WorldIO.signed32 0,world) := by
  have core : WorldIO.external platform fault "ferror" [WorldIO.stdoutValue platform] world = none := by
    rfl
  simp only [external,core,query,↓reduceIte,WorldIO.stdout_handle,healthy,Bool.not_false,
    Bool.true_and]

theorem ferror_rejects_error (platform : WorldIO.Platform) (world : WorldIO.World)
    (failed : world.stream.error = true) :
    query platform "ferror" [WorldIO.stdoutValue platform] world = none := by
  simp [query,failed]

/-- Exact transport of the old complete source tree into the existing
parameterized semantics, with no new application call leaf. -/
theorem lift_old {cfg : Layout} {code : List Syntax.Function}
    {platform : WorldIO.Platform} {fault : WorldIO.FaultPolicy} {rank : Nat}
    {name : String} {args : List Value} {before after : WorldIO.World} {value : Value}
    (h : WorldSource.SourceCall cfg code platform fault rank name args before value after) :
    WorldSourceWith.SourceCall cfg code platform (external platform fault)
      rank name args before value after := by
  induction rank generalizing name args before value after with
  | zero => exact old_included h
  | succ rank ih =>
    change _ ∨ _ ∨ _ at h
    rcases h with direct | pure | installed
    · exact Or.inl (old_included direct)
    · exact Or.inr (Or.inl pure)
    · rcases installed with ⟨f,member,named,pure,pureClosed,service,serviceClosed,
        frame,arguments,outcome,run,finish⟩
      exact WorldSourceWith.installed_call f member named pure pureClosed service
        (fun _ _ _ _ _ accepted => ih (serviceClosed _ _ _ _ _ accepted))
        frame arguments outcome run finish

#print axioms old_included
#print axioms ferror_healthy
#print axioms ferror_rejects_error
#print axioms lift_old
end SynergyTangentV2C.WorldError
