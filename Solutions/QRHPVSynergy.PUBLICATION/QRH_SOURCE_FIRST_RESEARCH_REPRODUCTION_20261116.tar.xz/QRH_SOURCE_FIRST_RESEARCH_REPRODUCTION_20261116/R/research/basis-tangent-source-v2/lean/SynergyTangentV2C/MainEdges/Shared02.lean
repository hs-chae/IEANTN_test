/- Actual l and zero-buffer declarations from the fixed C main. -/
import SynergyTangentV2C.MainCellAPI
namespace SynergyTangentV2C.MainEdges.Shared02
open ScopedC ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024
theorem cell064 : MainCellAPI.ExactEdges true 64
    (SynergyAnalytic.BoxModel.rat 1216 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell065 : MainCellAPI.ExactEdges true 65
    (SynergyAnalytic.BoxModel.rat 1231 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell066 : MainCellAPI.ExactEdges true 66
    (SynergyAnalytic.BoxModel.rat 1246 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell067 : MainCellAPI.ExactEdges true 67
    (SynergyAnalytic.BoxModel.rat 1261 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell068 : MainCellAPI.ExactEdges true 68
    (SynergyAnalytic.BoxModel.rat 1276 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell069 : MainCellAPI.ExactEdges true 69
    (SynergyAnalytic.BoxModel.rat 1291 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell070 : MainCellAPI.ExactEdges true 70
    (SynergyAnalytic.BoxModel.rat 1306 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell071 : MainCellAPI.ExactEdges true 71
    (SynergyAnalytic.BoxModel.rat 1321 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell072 : MainCellAPI.ExactEdges true 72
    (SynergyAnalytic.BoxModel.rat 1336 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell073 : MainCellAPI.ExactEdges true 73
    (SynergyAnalytic.BoxModel.rat 1351 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell074 : MainCellAPI.ExactEdges true 74
    (SynergyAnalytic.BoxModel.rat 1366 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell075 : MainCellAPI.ExactEdges true 75
    (SynergyAnalytic.BoxModel.rat 1381 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell076 : MainCellAPI.ExactEdges true 76
    (SynergyAnalytic.BoxModel.rat 1396 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell077 : MainCellAPI.ExactEdges true 77
    (SynergyAnalytic.BoxModel.rat 1411 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell078 : MainCellAPI.ExactEdges true 78
    (SynergyAnalytic.BoxModel.rat 1426 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell079 : MainCellAPI.ExactEdges true 79
    (SynergyAnalytic.BoxModel.rat 1441 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell080 : MainCellAPI.ExactEdges true 80
    (SynergyAnalytic.BoxModel.rat 1456 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell081 : MainCellAPI.ExactEdges true 81
    (SynergyAnalytic.BoxModel.rat 1471 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell082 : MainCellAPI.ExactEdges true 82
    (SynergyAnalytic.BoxModel.rat 1486 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell083 : MainCellAPI.ExactEdges true 83
    (SynergyAnalytic.BoxModel.rat 1501 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell084 : MainCellAPI.ExactEdges true 84
    (SynergyAnalytic.BoxModel.rat 1516 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell085 : MainCellAPI.ExactEdges true 85
    (SynergyAnalytic.BoxModel.rat 1531 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell086 : MainCellAPI.ExactEdges true 86
    (SynergyAnalytic.BoxModel.rat 1546 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell087 : MainCellAPI.ExactEdges true 87
    (SynergyAnalytic.BoxModel.rat 1561 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell088 : MainCellAPI.ExactEdges true 88
    (SynergyAnalytic.BoxModel.rat 1576 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell089 : MainCellAPI.ExactEdges true 89
    (SynergyAnalytic.BoxModel.rat 1591 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell090 : MainCellAPI.ExactEdges true 90
    (SynergyAnalytic.BoxModel.rat 1606 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell091 : MainCellAPI.ExactEdges true 91
    (SynergyAnalytic.BoxModel.rat 1621 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell092 : MainCellAPI.ExactEdges true 92
    (SynergyAnalytic.BoxModel.rat 1636 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell093 : MainCellAPI.ExactEdges true 93
    (SynergyAnalytic.BoxModel.rat 1651 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell094 : MainCellAPI.ExactEdges true 94
    (SynergyAnalytic.BoxModel.rat 1666 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell095 : MainCellAPI.ExactEdges true 95
    (SynergyAnalytic.BoxModel.rat 1681 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell064
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell065
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell066
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell067
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell068
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell069
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell070
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell071
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell072
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell073
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell074
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell075
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell076
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell077
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell078
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell079
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell080
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell081
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell082
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell083
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell084
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell085
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell086
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell087
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell088
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell089
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell090
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell091
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell092
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell093
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell094
#print axioms SynergyTangentV2C.MainEdges.Shared02.cell095
end SynergyTangentV2C.MainEdges.Shared02
