/- Actual V2 declarations and ordered stores before the integration loops.
The array is allocated indeterminate, then each of its three I cells is
initialized by the source. No initialized application array is assumed. -/
import SynergyTangentV2C.MainLn2
namespace SynergyTangentV2C.MainPrefix
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

abbrev unsigned := MainFrames.unsigned
def cells : State := allocate MainLn2.ready "const unsigned int" "cells" (some (unsigned 256))
def prefixState : State := allocate cells "const unsigned int" "prefix" (some (unsigned 16))
def totalObject (count : Nat) : Object := {
  type := "I"
  cells := List.replicate count (some (SynergyC.SourceIntervalMath.represented ⟨0,0⟩)) ++
    List.replicate (3-count) none
  isArray := true }
def totals (count : Nat) : State := {prefixState with
  heap := prefixState.heap ++ [totalObject count]
  env := ("J",⟨prefixState.heap.length,0,[]⟩) :: prefixState.env}
def beforeLoops : State := allocate (totals 3) "unsigned int" "i" (some (unsigned 0))
def statement (i : Nat) : Stmt := MainLn2.statements[i]?.getD .skip

theorem checked_cells (arena : NatArena.Arena) :
    ArrayStages.hasNext (ArraySourceExecute.statement SynergyC.Header.layout MainLn2.service
      128 2048 (statement 1) (ArrayStages.withArena MainLn2.ready arena)) cells = true := by
  rfl
theorem checked_domain (arena : NatArena.Arena) :
    ArrayStages.hasNext (ArraySourceExecute.statement SynergyC.Header.layout MainLn2.service
      128 2048 (statement 2) (ArrayStages.withArena cells arena)) cells = true := by
  rfl
theorem checked_prefix (arena : NatArena.Arena) :
    ArrayStages.hasNext (ArraySourceExecute.statement SynergyC.Header.layout MainLn2.service
      128 2048 (statement 3) (ArrayStages.withArena cells arena)) prefixState = true := by
  rfl
theorem checked_array_storage (arena : NatArena.Arena) :
    ArrayStages.hasNext (ArraySourceExecute.statement SynergyC.Header.layout MainLn2.service
      128 2048 (statement 4) (ArrayStages.withArena prefixState arena)) (totals 0) = true := by
  rfl
theorem checked_zero_0 (arena : NatArena.Arena) :
    ArrayStages.hasNext (ArraySourceExecute.statement SynergyC.Header.layout MainLn2.service
      128 2048 (statement 5) (ArrayStages.withArena (totals 0) arena)) (totals 1) = true := by
  rfl
theorem checked_zero_1 (arena : NatArena.Arena) :
    ArrayStages.hasNext (ArraySourceExecute.statement SynergyC.Header.layout MainLn2.service
      128 2048 (statement 6) (ArrayStages.withArena (totals 1) arena)) (totals 2) = true := by
  rfl
theorem checked_zero_2 (arena : NatArena.Arena) :
    ArrayStages.hasNext (ArraySourceExecute.statement SynergyC.Header.layout MainLn2.service
      128 2048 (statement 7) (ArrayStages.withArena (totals 2) arena)) (totals 3) = true := by
  rfl
theorem checked_index (arena : NatArena.Arena) :
    ArrayStages.hasNext (ArraySourceExecute.statement SynergyC.Header.layout MainLn2.service
      128 2048 (statement 8) (ArrayStages.withArena (totals 3) arena)) beforeLoops = true := by
  rfl

theorem actual_header_chain : ArrayStages.Chain SynergyC.Header.layout MainLn2.service
    (MainLn2.statements.take 9) MainInitialization.initial beforeLoops := by
  change ArrayStages.Chain _ _ [MainLn2.first,statement 1,statement 2,statement 3,
    statement 4,statement 5,statement 6,statement 7,statement 8] _ _
  exact .next MainLn2.actual_source_statement
    (.next (ArrayStages.statement_of_checked checked_cells)
      (.next (ArrayStages.statement_of_checked checked_domain)
        (.next (ArrayStages.statement_of_checked checked_prefix)
          (.next (ArrayStages.statement_of_checked checked_array_storage)
            (.next (ArrayStages.statement_of_checked checked_zero_0)
              (.next (ArrayStages.statement_of_checked checked_zero_1)
                (.next (ArrayStages.statement_of_checked checked_zero_2)
                  (.next (ArrayStages.statement_of_checked checked_index) (.nil _)))))))))

theorem beforeLoops_eq : beforeLoops = MainFrames.before (⟨0,0⟩,⟨0,0⟩,⟨0,0⟩) 0 := by
  rfl

#print axioms checked_cells
#print axioms checked_domain
#print axioms checked_prefix
#print axioms checked_array_storage
#print axioms checked_zero_0
#print axioms checked_zero_1
#print axioms checked_zero_2
#print axioms checked_index
#print axioms actual_header_chain
#print axioms beforeLoops_eq
end SynergyTangentV2C.MainPrefix
