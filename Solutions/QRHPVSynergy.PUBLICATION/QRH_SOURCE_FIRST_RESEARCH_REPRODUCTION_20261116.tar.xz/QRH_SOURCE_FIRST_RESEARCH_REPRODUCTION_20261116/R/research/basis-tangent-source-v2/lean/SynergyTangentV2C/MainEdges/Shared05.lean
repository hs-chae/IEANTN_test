/- Actual l and zero-buffer declarations from the fixed C main. -/
import SynergyTangentV2C.MainCellAPI
namespace SynergyTangentV2C.MainEdges.Shared05
open ScopedC ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024
theorem cell160 : MainCellAPI.ExactEdges true 160
    (SynergyAnalytic.BoxModel.rat 2656 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell161 : MainCellAPI.ExactEdges true 161
    (SynergyAnalytic.BoxModel.rat 2671 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell162 : MainCellAPI.ExactEdges true 162
    (SynergyAnalytic.BoxModel.rat 2686 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell163 : MainCellAPI.ExactEdges true 163
    (SynergyAnalytic.BoxModel.rat 2701 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell164 : MainCellAPI.ExactEdges true 164
    (SynergyAnalytic.BoxModel.rat 2716 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell165 : MainCellAPI.ExactEdges true 165
    (SynergyAnalytic.BoxModel.rat 2731 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell166 : MainCellAPI.ExactEdges true 166
    (SynergyAnalytic.BoxModel.rat 2746 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell167 : MainCellAPI.ExactEdges true 167
    (SynergyAnalytic.BoxModel.rat 2761 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell168 : MainCellAPI.ExactEdges true 168
    (SynergyAnalytic.BoxModel.rat 2776 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell169 : MainCellAPI.ExactEdges true 169
    (SynergyAnalytic.BoxModel.rat 2791 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell170 : MainCellAPI.ExactEdges true 170
    (SynergyAnalytic.BoxModel.rat 2806 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell171 : MainCellAPI.ExactEdges true 171
    (SynergyAnalytic.BoxModel.rat 2821 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell172 : MainCellAPI.ExactEdges true 172
    (SynergyAnalytic.BoxModel.rat 2836 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell173 : MainCellAPI.ExactEdges true 173
    (SynergyAnalytic.BoxModel.rat 2851 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell174 : MainCellAPI.ExactEdges true 174
    (SynergyAnalytic.BoxModel.rat 2866 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell175 : MainCellAPI.ExactEdges true 175
    (SynergyAnalytic.BoxModel.rat 2881 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell176 : MainCellAPI.ExactEdges true 176
    (SynergyAnalytic.BoxModel.rat 2896 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell177 : MainCellAPI.ExactEdges true 177
    (SynergyAnalytic.BoxModel.rat 2911 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell178 : MainCellAPI.ExactEdges true 178
    (SynergyAnalytic.BoxModel.rat 2926 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell179 : MainCellAPI.ExactEdges true 179
    (SynergyAnalytic.BoxModel.rat 2941 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell180 : MainCellAPI.ExactEdges true 180
    (SynergyAnalytic.BoxModel.rat 2956 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell181 : MainCellAPI.ExactEdges true 181
    (SynergyAnalytic.BoxModel.rat 2971 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell182 : MainCellAPI.ExactEdges true 182
    (SynergyAnalytic.BoxModel.rat 2986 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell183 : MainCellAPI.ExactEdges true 183
    (SynergyAnalytic.BoxModel.rat 3001 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell184 : MainCellAPI.ExactEdges true 184
    (SynergyAnalytic.BoxModel.rat 3016 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell185 : MainCellAPI.ExactEdges true 185
    (SynergyAnalytic.BoxModel.rat 3031 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell186 : MainCellAPI.ExactEdges true 186
    (SynergyAnalytic.BoxModel.rat 3046 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell187 : MainCellAPI.ExactEdges true 187
    (SynergyAnalytic.BoxModel.rat 3061 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell188 : MainCellAPI.ExactEdges true 188
    (SynergyAnalytic.BoxModel.rat 3076 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell189 : MainCellAPI.ExactEdges true 189
    (SynergyAnalytic.BoxModel.rat 3091 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell190 : MainCellAPI.ExactEdges true 190
    (SynergyAnalytic.BoxModel.rat 3106 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell191 : MainCellAPI.ExactEdges true 191
    (SynergyAnalytic.BoxModel.rat 3121 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell160
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell161
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell162
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell163
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell164
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell165
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell166
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell167
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell168
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell169
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell170
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell171
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell172
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell173
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell174
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell175
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell176
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell177
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell178
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell179
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell180
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell181
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell182
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell183
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell184
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell185
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell186
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell187
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell188
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell189
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell190
#print axioms SynergyTangentV2C.MainEdges.Shared05.cell191
end SynergyTangentV2C.MainEdges.Shared05
