/- Model fold composition reuses the independently accepted cell equations;
no numerical cell is recomputed by this generic transport. -/
import SynergyAnalytic.TangentTotals
import SynergyTangentV2C.MainFrames
namespace SynergyTangentV2C.CellFoldSteps
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0

theorem prefix_next (index : Nat) (previous : ProofBox) (cell : MainFrames.Totals)
    (old : SynergyAnalytic.BoxModel.prefixFold 16 index=some previous)
    (next : SynergyAnalytic.BoxModel.sourceCell
      (SynergyAnalytic.BoxModel.rat (80+index) 96)
      (SynergyAnalytic.BoxModel.rat 1 96) false=some cell) :
    SynergyAnalytic.BoxModel.prefixFold 16 (index+1)=
      some (ProofBox.add previous cell.1) := by
  simp only [SynergyAnalytic.BoxModel.prefixFold,old,next,
    Option.bind_eq_bind,Option.bind_some,Option.pure_def]

theorem shared_next (index : Nat) (previous cell : MainFrames.Totals)
    (old : SynergyAnalytic.BoxModel.sharedFold 256 index=some previous)
    (next : SynergyAnalytic.BoxModel.sourceCell
      (SynergyAnalytic.BoxModel.rat (256+15*index) 256)
      (SynergyAnalytic.BoxModel.rat 15 256) true=some cell) :
    SynergyAnalytic.BoxModel.sharedFold 256 (index+1)=some
      (ProofBox.add previous.1 cell.1,ProofBox.add previous.2.1 cell.2.1,
       ProofBox.add previous.2.2 cell.2.2) := by
  simp only [SynergyAnalytic.BoxModel.sharedFold,old,next,
    Option.bind_eq_bind,Option.bind_some,Option.pure_def]

#print axioms prefix_next
#print axioms shared_next
end SynergyTangentV2C.CellFoldSteps
