/- Actual l and zero-buffer declarations from the fixed C main. -/
import SynergyTangentV2C.MainCellAPI
namespace SynergyTangentV2C.MainEdges.Shared04
open ScopedC ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024
theorem cell128 : MainCellAPI.ExactEdges true 128
    (SynergyAnalytic.BoxModel.rat 2176 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell129 : MainCellAPI.ExactEdges true 129
    (SynergyAnalytic.BoxModel.rat 2191 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell130 : MainCellAPI.ExactEdges true 130
    (SynergyAnalytic.BoxModel.rat 2206 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell131 : MainCellAPI.ExactEdges true 131
    (SynergyAnalytic.BoxModel.rat 2221 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell132 : MainCellAPI.ExactEdges true 132
    (SynergyAnalytic.BoxModel.rat 2236 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell133 : MainCellAPI.ExactEdges true 133
    (SynergyAnalytic.BoxModel.rat 2251 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell134 : MainCellAPI.ExactEdges true 134
    (SynergyAnalytic.BoxModel.rat 2266 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell135 : MainCellAPI.ExactEdges true 135
    (SynergyAnalytic.BoxModel.rat 2281 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell136 : MainCellAPI.ExactEdges true 136
    (SynergyAnalytic.BoxModel.rat 2296 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell137 : MainCellAPI.ExactEdges true 137
    (SynergyAnalytic.BoxModel.rat 2311 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell138 : MainCellAPI.ExactEdges true 138
    (SynergyAnalytic.BoxModel.rat 2326 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell139 : MainCellAPI.ExactEdges true 139
    (SynergyAnalytic.BoxModel.rat 2341 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell140 : MainCellAPI.ExactEdges true 140
    (SynergyAnalytic.BoxModel.rat 2356 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell141 : MainCellAPI.ExactEdges true 141
    (SynergyAnalytic.BoxModel.rat 2371 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell142 : MainCellAPI.ExactEdges true 142
    (SynergyAnalytic.BoxModel.rat 2386 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell143 : MainCellAPI.ExactEdges true 143
    (SynergyAnalytic.BoxModel.rat 2401 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell144 : MainCellAPI.ExactEdges true 144
    (SynergyAnalytic.BoxModel.rat 2416 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell145 : MainCellAPI.ExactEdges true 145
    (SynergyAnalytic.BoxModel.rat 2431 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell146 : MainCellAPI.ExactEdges true 146
    (SynergyAnalytic.BoxModel.rat 2446 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell147 : MainCellAPI.ExactEdges true 147
    (SynergyAnalytic.BoxModel.rat 2461 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell148 : MainCellAPI.ExactEdges true 148
    (SynergyAnalytic.BoxModel.rat 2476 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell149 : MainCellAPI.ExactEdges true 149
    (SynergyAnalytic.BoxModel.rat 2491 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell150 : MainCellAPI.ExactEdges true 150
    (SynergyAnalytic.BoxModel.rat 2506 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell151 : MainCellAPI.ExactEdges true 151
    (SynergyAnalytic.BoxModel.rat 2521 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell152 : MainCellAPI.ExactEdges true 152
    (SynergyAnalytic.BoxModel.rat 2536 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell153 : MainCellAPI.ExactEdges true 153
    (SynergyAnalytic.BoxModel.rat 2551 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell154 : MainCellAPI.ExactEdges true 154
    (SynergyAnalytic.BoxModel.rat 2566 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell155 : MainCellAPI.ExactEdges true 155
    (SynergyAnalytic.BoxModel.rat 2581 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell156 : MainCellAPI.ExactEdges true 156
    (SynergyAnalytic.BoxModel.rat 2596 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell157 : MainCellAPI.ExactEdges true 157
    (SynergyAnalytic.BoxModel.rat 2611 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell158 : MainCellAPI.ExactEdges true 158
    (SynergyAnalytic.BoxModel.rat 2626 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell159 : MainCellAPI.ExactEdges true 159
    (SynergyAnalytic.BoxModel.rat 2641 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell128
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell129
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell130
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell131
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell132
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell133
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell134
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell135
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell136
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell137
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell138
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell139
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell140
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell141
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell142
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell143
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell144
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell145
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell146
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell147
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell148
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell149
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell150
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell151
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell152
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell153
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell154
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell155
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell156
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell157
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell158
#print axioms SynergyTangentV2C.MainEdges.Shared04.cell159
end SynergyTangentV2C.MainEdges.Shared04
