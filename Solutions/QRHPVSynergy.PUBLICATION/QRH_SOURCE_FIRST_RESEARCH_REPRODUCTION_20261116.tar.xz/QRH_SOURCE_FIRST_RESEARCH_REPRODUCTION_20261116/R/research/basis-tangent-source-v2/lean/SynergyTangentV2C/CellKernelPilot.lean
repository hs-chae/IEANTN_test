/- Actual source execution in the physical caller frame, with arbitrary old
accumulators and arbitrary untouched runtime arena. The cache value is a data
proposal; MainLn2 independently proves that the source computes that cache. -/
import SynergyTangentV2C.CellExecutionExact
import SynergyTangentV2C.MainFrames
import ScopedC.ArrayStages
import SynergyTangentV2C.CellOutputPilot
open Lean Meta Elab Tactic
namespace SynergyTangentV2C.CellKernelPilot
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 300000
set_option exponentiation.threshold 1024

abbrev left := CellOutputPilot.left
abbrev width := CellOutputPilot.width
abbrev output := CellOutputPilot.output
def base (totals : MainFrames.Totals) (arena : NatArena.Arena) : Machine.State :=
  ArrayStages.withArena (MainFrames.base totals 0 left) arena

theorem actual_execution (totals : MainFrames.Totals) (arena : NatArena.Arena) :
    CellExecute.run (base totals arena) left width true =
      some (.unit,CellExecute.filled (base totals arena) output) := by
  unfold CellExecute.run
  run_tac do
    let goal ← getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual source execution equality"
    goal.assign (← mkEqRefl args[1]!)

theorem actual_source (totals : MainFrames.Totals) (arena : NatArena.Arena) :
    ArraySourceCalls.SourceCall SynergyC.Header.layout Bundle.code 16 "tangentCell"
      (CellExecute.args (base totals arena) left width true)
      (CellExecute.buffers (base totals arena)) .unit
      (CellExecute.filled (base totals arena) output) :=
  CellExecutionExact.source_of_execution (actual_execution totals arena)

#print axioms actual_execution
#print axioms actual_source
end SynergyTangentV2C.CellKernelPilot
