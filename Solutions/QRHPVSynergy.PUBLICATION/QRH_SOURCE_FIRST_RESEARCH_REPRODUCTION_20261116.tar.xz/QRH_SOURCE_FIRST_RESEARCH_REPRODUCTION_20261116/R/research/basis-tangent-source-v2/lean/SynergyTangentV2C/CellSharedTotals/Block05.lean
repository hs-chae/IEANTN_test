/- Exact cumulative sums, using the corresponding accepted fixed-cell model equations. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Shared160
import SynergyTangentV2C.SourceCells.Shared161
import SynergyTangentV2C.SourceCells.Shared162
import SynergyTangentV2C.SourceCells.Shared163
import SynergyTangentV2C.SourceCells.Shared164
import SynergyTangentV2C.SourceCells.Shared165
import SynergyTangentV2C.SourceCells.Shared166
import SynergyTangentV2C.SourceCells.Shared167
import SynergyTangentV2C.SourceCells.Shared168
import SynergyTangentV2C.SourceCells.Shared169
import SynergyTangentV2C.SourceCells.Shared170
import SynergyTangentV2C.SourceCells.Shared171
import SynergyTangentV2C.SourceCells.Shared172
import SynergyTangentV2C.SourceCells.Shared173
import SynergyTangentV2C.SourceCells.Shared174
import SynergyTangentV2C.SourceCells.Shared175
import SynergyTangentV2C.SourceCells.Shared176
import SynergyTangentV2C.SourceCells.Shared177
import SynergyTangentV2C.SourceCells.Shared178
import SynergyTangentV2C.SourceCells.Shared179
import SynergyTangentV2C.SourceCells.Shared180
import SynergyTangentV2C.SourceCells.Shared181
import SynergyTangentV2C.SourceCells.Shared182
import SynergyTangentV2C.SourceCells.Shared183
import SynergyTangentV2C.SourceCells.Shared184
import SynergyTangentV2C.SourceCells.Shared185
import SynergyTangentV2C.SourceCells.Shared186
import SynergyTangentV2C.SourceCells.Shared187
import SynergyTangentV2C.SourceCells.Shared188
import SynergyTangentV2C.SourceCells.Shared189
import SynergyTangentV2C.SourceCells.Shared190
import SynergyTangentV2C.SourceCells.Shared191
namespace SynergyTangentV2C.CellSharedTotals.Block05
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.sharedOnlyTotals
theorem sum160 :
    (ProofBox.add (totals 160).1 SourceCells.Shared160.output.1,
     ProofBox.add (totals 160).2.1 SourceCells.Shared160.output.2.1,
     ProofBox.add (totals 160).2.2 SourceCells.Shared160.output.2.2)=totals 161 := by
  decide +kernel
#print axioms sum160
theorem sum161 :
    (ProofBox.add (totals 161).1 SourceCells.Shared161.output.1,
     ProofBox.add (totals 161).2.1 SourceCells.Shared161.output.2.1,
     ProofBox.add (totals 161).2.2 SourceCells.Shared161.output.2.2)=totals 162 := by
  decide +kernel
#print axioms sum161
theorem sum162 :
    (ProofBox.add (totals 162).1 SourceCells.Shared162.output.1,
     ProofBox.add (totals 162).2.1 SourceCells.Shared162.output.2.1,
     ProofBox.add (totals 162).2.2 SourceCells.Shared162.output.2.2)=totals 163 := by
  decide +kernel
#print axioms sum162
theorem sum163 :
    (ProofBox.add (totals 163).1 SourceCells.Shared163.output.1,
     ProofBox.add (totals 163).2.1 SourceCells.Shared163.output.2.1,
     ProofBox.add (totals 163).2.2 SourceCells.Shared163.output.2.2)=totals 164 := by
  decide +kernel
#print axioms sum163
theorem sum164 :
    (ProofBox.add (totals 164).1 SourceCells.Shared164.output.1,
     ProofBox.add (totals 164).2.1 SourceCells.Shared164.output.2.1,
     ProofBox.add (totals 164).2.2 SourceCells.Shared164.output.2.2)=totals 165 := by
  decide +kernel
#print axioms sum164
theorem sum165 :
    (ProofBox.add (totals 165).1 SourceCells.Shared165.output.1,
     ProofBox.add (totals 165).2.1 SourceCells.Shared165.output.2.1,
     ProofBox.add (totals 165).2.2 SourceCells.Shared165.output.2.2)=totals 166 := by
  decide +kernel
#print axioms sum165
theorem sum166 :
    (ProofBox.add (totals 166).1 SourceCells.Shared166.output.1,
     ProofBox.add (totals 166).2.1 SourceCells.Shared166.output.2.1,
     ProofBox.add (totals 166).2.2 SourceCells.Shared166.output.2.2)=totals 167 := by
  decide +kernel
#print axioms sum166
theorem sum167 :
    (ProofBox.add (totals 167).1 SourceCells.Shared167.output.1,
     ProofBox.add (totals 167).2.1 SourceCells.Shared167.output.2.1,
     ProofBox.add (totals 167).2.2 SourceCells.Shared167.output.2.2)=totals 168 := by
  decide +kernel
#print axioms sum167
theorem sum168 :
    (ProofBox.add (totals 168).1 SourceCells.Shared168.output.1,
     ProofBox.add (totals 168).2.1 SourceCells.Shared168.output.2.1,
     ProofBox.add (totals 168).2.2 SourceCells.Shared168.output.2.2)=totals 169 := by
  decide +kernel
#print axioms sum168
theorem sum169 :
    (ProofBox.add (totals 169).1 SourceCells.Shared169.output.1,
     ProofBox.add (totals 169).2.1 SourceCells.Shared169.output.2.1,
     ProofBox.add (totals 169).2.2 SourceCells.Shared169.output.2.2)=totals 170 := by
  decide +kernel
#print axioms sum169
theorem sum170 :
    (ProofBox.add (totals 170).1 SourceCells.Shared170.output.1,
     ProofBox.add (totals 170).2.1 SourceCells.Shared170.output.2.1,
     ProofBox.add (totals 170).2.2 SourceCells.Shared170.output.2.2)=totals 171 := by
  decide +kernel
#print axioms sum170
theorem sum171 :
    (ProofBox.add (totals 171).1 SourceCells.Shared171.output.1,
     ProofBox.add (totals 171).2.1 SourceCells.Shared171.output.2.1,
     ProofBox.add (totals 171).2.2 SourceCells.Shared171.output.2.2)=totals 172 := by
  decide +kernel
#print axioms sum171
theorem sum172 :
    (ProofBox.add (totals 172).1 SourceCells.Shared172.output.1,
     ProofBox.add (totals 172).2.1 SourceCells.Shared172.output.2.1,
     ProofBox.add (totals 172).2.2 SourceCells.Shared172.output.2.2)=totals 173 := by
  decide +kernel
#print axioms sum172
theorem sum173 :
    (ProofBox.add (totals 173).1 SourceCells.Shared173.output.1,
     ProofBox.add (totals 173).2.1 SourceCells.Shared173.output.2.1,
     ProofBox.add (totals 173).2.2 SourceCells.Shared173.output.2.2)=totals 174 := by
  decide +kernel
#print axioms sum173
theorem sum174 :
    (ProofBox.add (totals 174).1 SourceCells.Shared174.output.1,
     ProofBox.add (totals 174).2.1 SourceCells.Shared174.output.2.1,
     ProofBox.add (totals 174).2.2 SourceCells.Shared174.output.2.2)=totals 175 := by
  decide +kernel
#print axioms sum174
theorem sum175 :
    (ProofBox.add (totals 175).1 SourceCells.Shared175.output.1,
     ProofBox.add (totals 175).2.1 SourceCells.Shared175.output.2.1,
     ProofBox.add (totals 175).2.2 SourceCells.Shared175.output.2.2)=totals 176 := by
  decide +kernel
#print axioms sum175
theorem sum176 :
    (ProofBox.add (totals 176).1 SourceCells.Shared176.output.1,
     ProofBox.add (totals 176).2.1 SourceCells.Shared176.output.2.1,
     ProofBox.add (totals 176).2.2 SourceCells.Shared176.output.2.2)=totals 177 := by
  decide +kernel
#print axioms sum176
theorem sum177 :
    (ProofBox.add (totals 177).1 SourceCells.Shared177.output.1,
     ProofBox.add (totals 177).2.1 SourceCells.Shared177.output.2.1,
     ProofBox.add (totals 177).2.2 SourceCells.Shared177.output.2.2)=totals 178 := by
  decide +kernel
#print axioms sum177
theorem sum178 :
    (ProofBox.add (totals 178).1 SourceCells.Shared178.output.1,
     ProofBox.add (totals 178).2.1 SourceCells.Shared178.output.2.1,
     ProofBox.add (totals 178).2.2 SourceCells.Shared178.output.2.2)=totals 179 := by
  decide +kernel
#print axioms sum178
theorem sum179 :
    (ProofBox.add (totals 179).1 SourceCells.Shared179.output.1,
     ProofBox.add (totals 179).2.1 SourceCells.Shared179.output.2.1,
     ProofBox.add (totals 179).2.2 SourceCells.Shared179.output.2.2)=totals 180 := by
  decide +kernel
#print axioms sum179
theorem sum180 :
    (ProofBox.add (totals 180).1 SourceCells.Shared180.output.1,
     ProofBox.add (totals 180).2.1 SourceCells.Shared180.output.2.1,
     ProofBox.add (totals 180).2.2 SourceCells.Shared180.output.2.2)=totals 181 := by
  decide +kernel
#print axioms sum180
theorem sum181 :
    (ProofBox.add (totals 181).1 SourceCells.Shared181.output.1,
     ProofBox.add (totals 181).2.1 SourceCells.Shared181.output.2.1,
     ProofBox.add (totals 181).2.2 SourceCells.Shared181.output.2.2)=totals 182 := by
  decide +kernel
#print axioms sum181
theorem sum182 :
    (ProofBox.add (totals 182).1 SourceCells.Shared182.output.1,
     ProofBox.add (totals 182).2.1 SourceCells.Shared182.output.2.1,
     ProofBox.add (totals 182).2.2 SourceCells.Shared182.output.2.2)=totals 183 := by
  decide +kernel
#print axioms sum182
theorem sum183 :
    (ProofBox.add (totals 183).1 SourceCells.Shared183.output.1,
     ProofBox.add (totals 183).2.1 SourceCells.Shared183.output.2.1,
     ProofBox.add (totals 183).2.2 SourceCells.Shared183.output.2.2)=totals 184 := by
  decide +kernel
#print axioms sum183
theorem sum184 :
    (ProofBox.add (totals 184).1 SourceCells.Shared184.output.1,
     ProofBox.add (totals 184).2.1 SourceCells.Shared184.output.2.1,
     ProofBox.add (totals 184).2.2 SourceCells.Shared184.output.2.2)=totals 185 := by
  decide +kernel
#print axioms sum184
theorem sum185 :
    (ProofBox.add (totals 185).1 SourceCells.Shared185.output.1,
     ProofBox.add (totals 185).2.1 SourceCells.Shared185.output.2.1,
     ProofBox.add (totals 185).2.2 SourceCells.Shared185.output.2.2)=totals 186 := by
  decide +kernel
#print axioms sum185
theorem sum186 :
    (ProofBox.add (totals 186).1 SourceCells.Shared186.output.1,
     ProofBox.add (totals 186).2.1 SourceCells.Shared186.output.2.1,
     ProofBox.add (totals 186).2.2 SourceCells.Shared186.output.2.2)=totals 187 := by
  decide +kernel
#print axioms sum186
theorem sum187 :
    (ProofBox.add (totals 187).1 SourceCells.Shared187.output.1,
     ProofBox.add (totals 187).2.1 SourceCells.Shared187.output.2.1,
     ProofBox.add (totals 187).2.2 SourceCells.Shared187.output.2.2)=totals 188 := by
  decide +kernel
#print axioms sum187
theorem sum188 :
    (ProofBox.add (totals 188).1 SourceCells.Shared188.output.1,
     ProofBox.add (totals 188).2.1 SourceCells.Shared188.output.2.1,
     ProofBox.add (totals 188).2.2 SourceCells.Shared188.output.2.2)=totals 189 := by
  decide +kernel
#print axioms sum188
theorem sum189 :
    (ProofBox.add (totals 189).1 SourceCells.Shared189.output.1,
     ProofBox.add (totals 189).2.1 SourceCells.Shared189.output.2.1,
     ProofBox.add (totals 189).2.2 SourceCells.Shared189.output.2.2)=totals 190 := by
  decide +kernel
#print axioms sum189
theorem sum190 :
    (ProofBox.add (totals 190).1 SourceCells.Shared190.output.1,
     ProofBox.add (totals 190).2.1 SourceCells.Shared190.output.2.1,
     ProofBox.add (totals 190).2.2 SourceCells.Shared190.output.2.2)=totals 191 := by
  decide +kernel
#print axioms sum190
theorem sum191 :
    (ProofBox.add (totals 191).1 SourceCells.Shared191.output.1,
     ProofBox.add (totals 191).2.1 SourceCells.Shared191.output.2.1,
     ProofBox.add (totals 191).2.2 SourceCells.Shared191.output.2.2)=totals 192 := by
  decide +kernel
#print axioms sum191
theorem advance (old : SynergyAnalytic.BoxModel.sharedFold 256 160=some (totals 160)) :
    SynergyAnalytic.BoxModel.sharedFold 256 192=some (totals 192) := by
  have fold160 := old
  have fold161 := (CellFoldSteps.shared_next 160 _ _ fold160
    SourceCells.Shared160.model_eq).trans (congrArg some sum160)
  have fold162 := (CellFoldSteps.shared_next 161 _ _ fold161
    SourceCells.Shared161.model_eq).trans (congrArg some sum161)
  have fold163 := (CellFoldSteps.shared_next 162 _ _ fold162
    SourceCells.Shared162.model_eq).trans (congrArg some sum162)
  have fold164 := (CellFoldSteps.shared_next 163 _ _ fold163
    SourceCells.Shared163.model_eq).trans (congrArg some sum163)
  have fold165 := (CellFoldSteps.shared_next 164 _ _ fold164
    SourceCells.Shared164.model_eq).trans (congrArg some sum164)
  have fold166 := (CellFoldSteps.shared_next 165 _ _ fold165
    SourceCells.Shared165.model_eq).trans (congrArg some sum165)
  have fold167 := (CellFoldSteps.shared_next 166 _ _ fold166
    SourceCells.Shared166.model_eq).trans (congrArg some sum166)
  have fold168 := (CellFoldSteps.shared_next 167 _ _ fold167
    SourceCells.Shared167.model_eq).trans (congrArg some sum167)
  have fold169 := (CellFoldSteps.shared_next 168 _ _ fold168
    SourceCells.Shared168.model_eq).trans (congrArg some sum168)
  have fold170 := (CellFoldSteps.shared_next 169 _ _ fold169
    SourceCells.Shared169.model_eq).trans (congrArg some sum169)
  have fold171 := (CellFoldSteps.shared_next 170 _ _ fold170
    SourceCells.Shared170.model_eq).trans (congrArg some sum170)
  have fold172 := (CellFoldSteps.shared_next 171 _ _ fold171
    SourceCells.Shared171.model_eq).trans (congrArg some sum171)
  have fold173 := (CellFoldSteps.shared_next 172 _ _ fold172
    SourceCells.Shared172.model_eq).trans (congrArg some sum172)
  have fold174 := (CellFoldSteps.shared_next 173 _ _ fold173
    SourceCells.Shared173.model_eq).trans (congrArg some sum173)
  have fold175 := (CellFoldSteps.shared_next 174 _ _ fold174
    SourceCells.Shared174.model_eq).trans (congrArg some sum174)
  have fold176 := (CellFoldSteps.shared_next 175 _ _ fold175
    SourceCells.Shared175.model_eq).trans (congrArg some sum175)
  have fold177 := (CellFoldSteps.shared_next 176 _ _ fold176
    SourceCells.Shared176.model_eq).trans (congrArg some sum176)
  have fold178 := (CellFoldSteps.shared_next 177 _ _ fold177
    SourceCells.Shared177.model_eq).trans (congrArg some sum177)
  have fold179 := (CellFoldSteps.shared_next 178 _ _ fold178
    SourceCells.Shared178.model_eq).trans (congrArg some sum178)
  have fold180 := (CellFoldSteps.shared_next 179 _ _ fold179
    SourceCells.Shared179.model_eq).trans (congrArg some sum179)
  have fold181 := (CellFoldSteps.shared_next 180 _ _ fold180
    SourceCells.Shared180.model_eq).trans (congrArg some sum180)
  have fold182 := (CellFoldSteps.shared_next 181 _ _ fold181
    SourceCells.Shared181.model_eq).trans (congrArg some sum181)
  have fold183 := (CellFoldSteps.shared_next 182 _ _ fold182
    SourceCells.Shared182.model_eq).trans (congrArg some sum182)
  have fold184 := (CellFoldSteps.shared_next 183 _ _ fold183
    SourceCells.Shared183.model_eq).trans (congrArg some sum183)
  have fold185 := (CellFoldSteps.shared_next 184 _ _ fold184
    SourceCells.Shared184.model_eq).trans (congrArg some sum184)
  have fold186 := (CellFoldSteps.shared_next 185 _ _ fold185
    SourceCells.Shared185.model_eq).trans (congrArg some sum185)
  have fold187 := (CellFoldSteps.shared_next 186 _ _ fold186
    SourceCells.Shared186.model_eq).trans (congrArg some sum186)
  have fold188 := (CellFoldSteps.shared_next 187 _ _ fold187
    SourceCells.Shared187.model_eq).trans (congrArg some sum187)
  have fold189 := (CellFoldSteps.shared_next 188 _ _ fold188
    SourceCells.Shared188.model_eq).trans (congrArg some sum188)
  have fold190 := (CellFoldSteps.shared_next 189 _ _ fold189
    SourceCells.Shared189.model_eq).trans (congrArg some sum189)
  have fold191 := (CellFoldSteps.shared_next 190 _ _ fold190
    SourceCells.Shared190.model_eq).trans (congrArg some sum190)
  have fold192 := (CellFoldSteps.shared_next 191 _ _ fold191
    SourceCells.Shared191.model_eq).trans (congrArg some sum191)
  exact fold192
#print axioms advance
end SynergyTangentV2C.CellSharedTotals.Block05
