/- Proposed six words become a model fact only through this kernel proof.
This is a mathematical component; source execution is proved separately. -/
import SynergyTangentV2C.CellExecute
namespace SynergyTangentV2C.CellOutputPilot
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 300000
set_option exponentiation.threshold 1024
def left : ProofBox := SynergyAnalytic.BoxModel.rat 256 256
def width : ProofBox := SynergyAnalytic.BoxModel.rat 15 256
def output : ProofBox × ProofBox × ProofBox :=
  (⟨15612252827742053649381042823221441126,
    15612252827742053649381042823221442792⟩,
   ⟨456760000209594070618427289453533713,
    456760000209594070618427289453541152⟩,
   ⟨17829998436654386643107959485841686,
    17829998436654386643107959485895915⟩)
theorem model_eq : SynergyAnalytic.BoxModel.sourceCell left width true = some output := by
  decide +kernel
#print axioms model_eq
end SynergyTangentV2C.CellOutputPilot
