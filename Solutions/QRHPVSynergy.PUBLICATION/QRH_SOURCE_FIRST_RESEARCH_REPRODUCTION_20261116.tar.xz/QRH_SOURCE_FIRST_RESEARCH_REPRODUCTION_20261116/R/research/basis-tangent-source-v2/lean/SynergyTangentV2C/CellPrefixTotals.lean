/- Every literal prefix sum is kernel checked; fold equations reuse fixed cell.model_eq. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Prefix00
import SynergyTangentV2C.SourceCells.Prefix01
import SynergyTangentV2C.SourceCells.Prefix02
import SynergyTangentV2C.SourceCells.Prefix03
import SynergyTangentV2C.SourceCells.Prefix04
import SynergyTangentV2C.SourceCells.Prefix05
import SynergyTangentV2C.SourceCells.Prefix06
import SynergyTangentV2C.SourceCells.Prefix07
import SynergyTangentV2C.SourceCells.Prefix08
import SynergyTangentV2C.SourceCells.Prefix09
import SynergyTangentV2C.SourceCells.Prefix10
import SynergyTangentV2C.SourceCells.Prefix11
import SynergyTangentV2C.SourceCells.Prefix12
import SynergyTangentV2C.SourceCells.Prefix13
import SynergyTangentV2C.SourceCells.Prefix14
import SynergyTangentV2C.SourceCells.Prefix15
namespace SynergyTangentV2C.CellPrefixTotals
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.prefixTotals
theorem fold00 : SynergyAnalytic.BoxModel.prefixFold 16 0=some (totals 0).1 := by rfl
#print axioms fold00
theorem sum00 : ProofBox.add (totals 0).1 SourceCells.Prefix00.output.1=(totals 1).1 := by
  decide +kernel
theorem fold01 : SynergyAnalytic.BoxModel.prefixFold 16 1=some (totals 1).1 :=
  (CellFoldSteps.prefix_next 0 _ _ fold00 SourceCells.Prefix00.model_eq).trans
    (congrArg some sum00)
#print axioms sum00
#print axioms fold01
theorem sum01 : ProofBox.add (totals 1).1 SourceCells.Prefix01.output.1=(totals 2).1 := by
  decide +kernel
theorem fold02 : SynergyAnalytic.BoxModel.prefixFold 16 2=some (totals 2).1 :=
  (CellFoldSteps.prefix_next 1 _ _ fold01 SourceCells.Prefix01.model_eq).trans
    (congrArg some sum01)
#print axioms sum01
#print axioms fold02
theorem sum02 : ProofBox.add (totals 2).1 SourceCells.Prefix02.output.1=(totals 3).1 := by
  decide +kernel
theorem fold03 : SynergyAnalytic.BoxModel.prefixFold 16 3=some (totals 3).1 :=
  (CellFoldSteps.prefix_next 2 _ _ fold02 SourceCells.Prefix02.model_eq).trans
    (congrArg some sum02)
#print axioms sum02
#print axioms fold03
theorem sum03 : ProofBox.add (totals 3).1 SourceCells.Prefix03.output.1=(totals 4).1 := by
  decide +kernel
theorem fold04 : SynergyAnalytic.BoxModel.prefixFold 16 4=some (totals 4).1 :=
  (CellFoldSteps.prefix_next 3 _ _ fold03 SourceCells.Prefix03.model_eq).trans
    (congrArg some sum03)
#print axioms sum03
#print axioms fold04
theorem sum04 : ProofBox.add (totals 4).1 SourceCells.Prefix04.output.1=(totals 5).1 := by
  decide +kernel
theorem fold05 : SynergyAnalytic.BoxModel.prefixFold 16 5=some (totals 5).1 :=
  (CellFoldSteps.prefix_next 4 _ _ fold04 SourceCells.Prefix04.model_eq).trans
    (congrArg some sum04)
#print axioms sum04
#print axioms fold05
theorem sum05 : ProofBox.add (totals 5).1 SourceCells.Prefix05.output.1=(totals 6).1 := by
  decide +kernel
theorem fold06 : SynergyAnalytic.BoxModel.prefixFold 16 6=some (totals 6).1 :=
  (CellFoldSteps.prefix_next 5 _ _ fold05 SourceCells.Prefix05.model_eq).trans
    (congrArg some sum05)
#print axioms sum05
#print axioms fold06
theorem sum06 : ProofBox.add (totals 6).1 SourceCells.Prefix06.output.1=(totals 7).1 := by
  decide +kernel
theorem fold07 : SynergyAnalytic.BoxModel.prefixFold 16 7=some (totals 7).1 :=
  (CellFoldSteps.prefix_next 6 _ _ fold06 SourceCells.Prefix06.model_eq).trans
    (congrArg some sum06)
#print axioms sum06
#print axioms fold07
theorem sum07 : ProofBox.add (totals 7).1 SourceCells.Prefix07.output.1=(totals 8).1 := by
  decide +kernel
theorem fold08 : SynergyAnalytic.BoxModel.prefixFold 16 8=some (totals 8).1 :=
  (CellFoldSteps.prefix_next 7 _ _ fold07 SourceCells.Prefix07.model_eq).trans
    (congrArg some sum07)
#print axioms sum07
#print axioms fold08
theorem sum08 : ProofBox.add (totals 8).1 SourceCells.Prefix08.output.1=(totals 9).1 := by
  decide +kernel
theorem fold09 : SynergyAnalytic.BoxModel.prefixFold 16 9=some (totals 9).1 :=
  (CellFoldSteps.prefix_next 8 _ _ fold08 SourceCells.Prefix08.model_eq).trans
    (congrArg some sum08)
#print axioms sum08
#print axioms fold09
theorem sum09 : ProofBox.add (totals 9).1 SourceCells.Prefix09.output.1=(totals 10).1 := by
  decide +kernel
theorem fold10 : SynergyAnalytic.BoxModel.prefixFold 16 10=some (totals 10).1 :=
  (CellFoldSteps.prefix_next 9 _ _ fold09 SourceCells.Prefix09.model_eq).trans
    (congrArg some sum09)
#print axioms sum09
#print axioms fold10
theorem sum10 : ProofBox.add (totals 10).1 SourceCells.Prefix10.output.1=(totals 11).1 := by
  decide +kernel
theorem fold11 : SynergyAnalytic.BoxModel.prefixFold 16 11=some (totals 11).1 :=
  (CellFoldSteps.prefix_next 10 _ _ fold10 SourceCells.Prefix10.model_eq).trans
    (congrArg some sum10)
#print axioms sum10
#print axioms fold11
theorem sum11 : ProofBox.add (totals 11).1 SourceCells.Prefix11.output.1=(totals 12).1 := by
  decide +kernel
theorem fold12 : SynergyAnalytic.BoxModel.prefixFold 16 12=some (totals 12).1 :=
  (CellFoldSteps.prefix_next 11 _ _ fold11 SourceCells.Prefix11.model_eq).trans
    (congrArg some sum11)
#print axioms sum11
#print axioms fold12
theorem sum12 : ProofBox.add (totals 12).1 SourceCells.Prefix12.output.1=(totals 13).1 := by
  decide +kernel
theorem fold13 : SynergyAnalytic.BoxModel.prefixFold 16 13=some (totals 13).1 :=
  (CellFoldSteps.prefix_next 12 _ _ fold12 SourceCells.Prefix12.model_eq).trans
    (congrArg some sum12)
#print axioms sum12
#print axioms fold13
theorem sum13 : ProofBox.add (totals 13).1 SourceCells.Prefix13.output.1=(totals 14).1 := by
  decide +kernel
theorem fold14 : SynergyAnalytic.BoxModel.prefixFold 16 14=some (totals 14).1 :=
  (CellFoldSteps.prefix_next 13 _ _ fold13 SourceCells.Prefix13.model_eq).trans
    (congrArg some sum13)
#print axioms sum13
#print axioms fold14
theorem sum14 : ProofBox.add (totals 14).1 SourceCells.Prefix14.output.1=(totals 15).1 := by
  decide +kernel
theorem fold15 : SynergyAnalytic.BoxModel.prefixFold 16 15=some (totals 15).1 :=
  (CellFoldSteps.prefix_next 14 _ _ fold14 SourceCells.Prefix14.model_eq).trans
    (congrArg some sum14)
#print axioms sum14
#print axioms fold15
theorem sum15 : ProofBox.add (totals 15).1 SourceCells.Prefix15.output.1=(totals 16).1 := by
  decide +kernel
theorem fold16 : SynergyAnalytic.BoxModel.prefixFold 16 16=some (totals 16).1 :=
  (CellFoldSteps.prefix_next 15 _ _ fold15 SourceCells.Prefix15.model_eq).trans
    (congrArg some sum15)
#print axioms sum15
#print axioms fold16
theorem complete : SynergyAnalytic.BoxModel.prefixFold 16 16=
    some (CellTotalsData.prefixTotals 16).1 := fold16
#print axioms complete
end SynergyTangentV2C.CellPrefixTotals
