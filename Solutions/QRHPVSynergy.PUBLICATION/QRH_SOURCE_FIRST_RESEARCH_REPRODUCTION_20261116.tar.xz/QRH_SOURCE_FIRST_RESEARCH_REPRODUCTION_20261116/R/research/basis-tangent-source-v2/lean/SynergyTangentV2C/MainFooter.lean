/- Actual C peak/tail calculations and final three stores. All literal words
are proposals; checked proves the seven actual AST statements produce them. -/
import SynergyTangentV2C.MainRowAPI
import SynergyTangentV2C.CellTotalsData
namespace SynergyTangentV2C.MainFooter
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 1024

def q : ProofBox :=
  ⟨81803881007793606616595255626597078034,81803881007793606616595255626597078035⟩
def peak : ProofBox :=
  ⟨270983436314987973496598113033675923767,270983436314987973496598113033675924080⟩
def bq : ProofBox :=
  ⟨20941793537995163293848385440408851976704,20941793537995163293848385440408851976960⟩
def tail : ProofBox := ⟨344818328596335,344818328596881⟩
def output : MainFrames.Totals :=
  (⟨634426550135877581749946416972346335033,
    634426550135877581749946416972346387067⟩,
   ⟨216480793147425769578523839282288619201,
    216480793147425769578523839282288654642⟩,
   ⟨175455803376318914922671818722729996020,
    175455803376318914922671818722730165340⟩)
def before : State := MainFrames.before (CellTotalsData.sharedTotals 256) 256
def afterQ : State := allocate before "I" "q" (some (CellExecute.represented q))
def afterPeak : State := allocate afterQ "I" "M" (some (CellExecute.represented peak))
def afterBq : State := allocate afterPeak "I" "bq" (some (CellExecute.represented bq))
def afterTail : State := allocate afterBq "I" "tail" (some (CellExecute.represented tail))
def after : State := {afterTail with
  heap := afterTail.heap.set 5 (MainRowAPI.totalObject output)}
def statements : List Stmt := (MainLn2.statements.drop 12).take 7

theorem checked (arena : NatArena.Arena) :
    ArraySourceExecute.statements Header.layout MainLn2.service 128 2048 statements
      (ArrayStages.withArena before arena) =
      some (.continuing (ArrayStages.withArena after arena)) := by
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual C peak/tail execution equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)

theorem actual_source (arena : NatArena.Arena) :
    Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      statements (ArrayStages.withArena before arena)
      (.continuing (ArrayStages.withArena after arena)) :=
  (ArraySourceExecute.sound Header.layout MainLn2.service 128 2048).2.1
    _ _ _ (checked arena)

theorem read_zero (arena : NatArena.Arena) :
    Machine.read Header.layout (ArrayStages.withArena after arena) ⟨5,0,[]⟩ =
      some (CellExecute.represented output.1) := by rfl
theorem read_one (arena : NatArena.Arena) :
    Machine.read Header.layout (ArrayStages.withArena after arena) ⟨5,1,[]⟩ =
      some (CellExecute.represented output.2.1) := by rfl
theorem read_two (arena : NatArena.Arena) :
    Machine.read Header.layout (ArrayStages.withArena after arena) ⟨5,2,[]⟩ =
      some (CellExecute.represented output.2.2) := by rfl

#print axioms checked
#print axioms actual_source
#print axioms read_zero
#print axioms read_one
#print axioms read_two
end SynergyTangentV2C.MainFooter
