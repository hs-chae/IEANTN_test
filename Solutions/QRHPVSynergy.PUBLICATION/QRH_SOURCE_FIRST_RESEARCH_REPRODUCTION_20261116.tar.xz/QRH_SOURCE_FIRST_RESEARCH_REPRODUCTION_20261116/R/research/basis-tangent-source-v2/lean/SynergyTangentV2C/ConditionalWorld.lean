/- Additive source semantics for the one missing I/O expression feature.
The integer condition executes first, including its effects, and exactly one
branch executes in that resulting world. This partial extension covers the
actual signed-int literal alternatives 2 and 0 only. It deliberately supplies
no rule for mixed-type alternatives or their usual arithmetic conversions.
Primary language locator: WG14 N3096, 6.5.15 paragraph5 (conditional operator).
Existing C/stdio semantics and all historical execution relations are intact. -/
import ScopedIO.WorldSourceWith
namespace SynergyTangentV2C.ConditionalWorld
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedIO ScopedIO.WorldIO
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

inductive Eval (cfg : Layout) (pure : Machine.Call) (call : WorldIO.Call)
    (platform : Platform) : Expr → World → World → Value → Prop
  | old {e s t v} (run : WorldSource.Eval cfg pure call platform e s t v) :
      Eval cfg pure call platform e s t v
  | conditional {test s middle t value} {condition : Scalar.Value}
      (first : Eval cfg pure call platform test s middle (.integer condition))
      (selected : Eval cfg pure call platform
        (if truth (.integer condition) then .nat 2 else .nat 0)
        middle t value) :
      Eval cfg pure call platform (.conditional test (.nat 2) (.nat 0)) s t value

abbrev Run (cfg : Layout) (pure : Machine.Call) (call : WorldIO.Call)
    (platform : Platform) :=
  Loops.StmtRun (Eval cfg pure call platform) (WorldSource.Declare cfg pure)
    truth WorldSource.Scope

theorem guard_old {cfg : Layout} {pure : Machine.Call} {call : WorldIO.Call}
    {platform : Platform} {cond : Option Expr} {s t : World} {value : Bool}
    (old : Loops.GuardRun (WorldSource.Eval cfg pure call platform) truth cond s t value) :
    Loops.GuardRun (Eval cfg pure call platform) truth cond s t value := by
  cases old with
  | omitted s => exact .omitted s
  | present run => exact .present (.old run)

theorem statement_old {cfg : Layout} {pure : Machine.Call} {call : WorldIO.Call}
    {platform : Platform} {st : Stmt} {s : World} {out : Loops.Flow World Value}
    (old : WorldSource.Run cfg pure call platform st s out) :
    Run cfg pure call platform st s out := by
  exact Loops.StmtRun.rec
    (motive_1 := fun st s out _ => Run cfg pure call platform st s out)
    (motive_2 := fun ss s out _ => Loops.SeqRun (Eval cfg pure call platform)
      (WorldSource.Declare cfg pure) truth WorldSource.Scope ss s out)
    (motive_3 := fun cond step body s out _ => Loops.ForRun (Eval cfg pure call platform)
      (WorldSource.Declare cfg pure) truth WorldSource.Scope cond step body s out)
    (motive_4 := fun cond body s out _ => Loops.WhileRun (Eval cfg pure call platform)
      (WorldSource.Declare cfg pure) truth WorldSource.Scope cond body s out)
    (fun s => .skip s)
    (fun run => .evaluate (.old run))
    (fun run => .declare run)
    (fun run => .returnValue (.old run))
    (fun test _ mapped => .branch (.old test) mapped)
    (fun _ exit mapped => .sequence mapped exit)
    (fun _ _ exit initial loop => .forLoop initial loop exit)
    (fun _ exit initial => .forInitialReturn initial exit)
    (fun _ mapped => .whileLoop mapped)
    (fun s => .nil s)
    (fun _ _ first rest => .next first rest)
    (fun _ mapped => .returned mapped)
    (fun test => .done (guard_old test))
    (fun test _ step _ iteration rest => .next (guard_old test) iteration (.old step) rest)
    (fun test _ iteration => .returned (guard_old test) iteration)
    (fun test stop => .done (.old test) stop)
    (fun test keep _ _ iteration rest => .next (.old test) keep iteration rest)
    (fun test keep _ iteration => .returned (.old test) keep iteration)
    old

theorem statements_old {cfg : Layout} {pure : Machine.Call} {call : WorldIO.Call}
    {platform : Platform} {ss : List Stmt} {s : World} {out : Loops.Flow World Value}
    (old : Loops.SeqRun (WorldSource.Eval cfg pure call platform)
      (WorldSource.Declare cfg pure) truth WorldSource.Scope ss s out) :
    Loops.SeqRun (Eval cfg pure call platform) (WorldSource.Declare cfg pure)
      truth WorldSource.Scope ss s out := by
  induction ss generalizing s out with
  | nil => cases old; exact .nil _
  | cons head tail ih =>
    cases old with
    | next first rest => exact .next (statement_old first) (ih rest)
    | returned first => exact .returned (statement_old first)

def SourceCall (cfg : Layout) (code : List Function) (platform : Platform)
    (external : WorldIO.Call) :
    Nat → String → List Value → World → Value → World → Prop
  | 0,name,args,s,v,t => WorldSourceWith.SourceCall cfg code platform external 0 name args s v t
  | rank+1,name,args,s,v,t =>
      WorldSourceWith.SourceCall cfg code platform external (rank+1) name args s v t ∨
      ∃ f, f ∈ code ∧ f.name = name ∧
        ∃ pure : Machine.Call, (∀ called actual start value final,
          pure called actual start = some (value,final) →
          ∃ oldRank, ArraySourceCalls.SourceCall cfg code oldRank called actual start value final) ∧
        ∃ service : WorldIO.Call, (∀ called actual start value final,
          service called actual start = some (value,final) →
          SourceCall cfg code platform external rank called actual start value final) ∧
        ∃ frame, bindArgs cfg f.parameters args s.app = some frame ∧
          ∃ outcome, Run cfg pure service platform f.body ⟨frame,s.stream⟩ outcome ∧
            WorldSource.Finish cfg f s outcome v t

theorem old_call {cfg : Layout} {code : List Function} {platform : Platform}
    {external : WorldIO.Call} {rank : Nat} {name : String} {args : List Value}
    {s t : World} {v : Value}
    (old : WorldSourceWith.SourceCall cfg code platform external rank name args s v t) :
    SourceCall cfg code platform external rank name args s v t := by
  cases rank with
  | zero => exact old
  | succ rank => exact Or.inl old

theorem installed_call {cfg : Layout} {code : List Function} {platform : Platform}
    {external : WorldIO.Call} {rank : Nat} {name : String} {args : List Value}
    {s t : World} {v : Value} (f : Function) (installed : f ∈ code) (named : f.name = name)
    (pure : Machine.Call) (pure_closed : ∀ called actual start value final,
      pure called actual start = some (value,final) →
      ∃ oldRank, ArraySourceCalls.SourceCall cfg code oldRank called actual start value final)
    (service : WorldIO.Call) (service_closed : ∀ called actual start value final,
      service called actual start = some (value,final) →
      SourceCall cfg code platform external rank called actual start value final)
    (frame : State) (arguments : bindArgs cfg f.parameters args s.app = some frame)
    (outcome : Loops.Flow World Value)
    (run : Run cfg pure service platform f.body ⟨frame,s.stream⟩ outcome)
    (finish : WorldSource.Finish cfg f s outcome v t) :
    SourceCall cfg code platform external (rank+1) name args s v t :=
  Or.inr ⟨f,installed,named,pure,pure_closed,service,service_closed,
    frame,arguments,outcome,run,finish⟩

#print axioms guard_old
#print axioms statement_old
#print axioms statements_old
#print axioms old_call
#print axioms installed_call
end SynergyTangentV2C.ConditionalWorld
