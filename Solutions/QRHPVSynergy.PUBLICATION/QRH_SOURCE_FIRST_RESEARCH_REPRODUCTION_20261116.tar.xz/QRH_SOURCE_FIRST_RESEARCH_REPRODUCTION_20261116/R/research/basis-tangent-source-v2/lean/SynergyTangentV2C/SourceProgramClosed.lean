/- Closed source-first basis program. All272 C cells, accumulations,
both loops and all model correspondences are discharged; no numerical premise. -/
import SynergyTangentV2C.MainSharedRows
import SynergyTangentV2C.MainPrefixRows
import SynergyTangentV2C.CellSharedTotals
import SynergyTangentV2C.ProgramConsumer
namespace SynergyTangentV2C.SourceProgramClosed
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem program_exists : ∃ value, ProgramConsumer.Payload value :=
  ProgramConsumer.exists_output MainPrefixRows.complete MainSharedRows.complete
    CellSharedTotals.complete
noncomputable def sourceOutput : MainFrames.Totals := Classical.choose program_exists
theorem source_output_valid : ProgramConsumer.Payload sourceOutput :=
  Classical.choose_spec program_exists
theorem basis_caps :
    SynergyAnalytic.UniversalBasisCaps (373/200) (1273/2000) (129/250) := by
  have provider := source_output_valid
  exact SynergyTangentC.RealConsumer.caps_from_model_total provider.model
    provider.zeroWord provider.oneWord provider.twoWord

#print axioms program_exists
#print axioms source_output_valid
#print axioms basis_caps
end SynergyTangentV2C.SourceProgramClosed
