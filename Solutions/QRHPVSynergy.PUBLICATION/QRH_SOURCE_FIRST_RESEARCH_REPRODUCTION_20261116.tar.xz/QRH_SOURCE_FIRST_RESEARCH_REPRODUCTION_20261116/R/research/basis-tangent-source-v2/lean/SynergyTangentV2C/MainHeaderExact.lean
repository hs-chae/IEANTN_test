/- Exact actual header execution, including preservation of the arena, and
the source reset between the two C integration loops. -/
import SynergyTangentV2C.MainPrefix
import SynergyTangentV2C.CellTotalsData
namespace SynergyTangentV2C.MainHeaderExact
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 1024

theorem checked_header :
    ArraySourceExecute.statements Header.layout MainLn2.service 128 2048
      (MainLn2.statements.take 9) MainInitialization.initial =
      some (.continuing (MainFrames.before (CellTotalsData.prefixTotals 0) 0)) := by
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual C whole header execution equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)

theorem actual_header :
    Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
      (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
      (MainLn2.statements.take 9) MainInitialization.initial
      (.continuing (MainFrames.before (CellTotalsData.prefixTotals 0) 0)) :=
  (ArraySourceExecute.sound Header.layout MainLn2.service 128 2048).2.1
    _ _ _ checked_header

theorem checked_reset :
    ArraySourceExecute.statement Header.layout MainLn2.service 128 2048
      (MainLn2.statements[10]?.getD .skip)
      (MainFrames.before (CellTotalsData.prefixTotals 16) 16) =
      some (.continuing (MainFrames.before (CellTotalsData.sharedTotals 0) 0)) := by rfl

theorem actual_reset :
    ArraySourceCalls.Run Header.layout MainLn2.service
      (MainLn2.statements[10]?.getD .skip)
      (MainFrames.before (CellTotalsData.prefixTotals 16) 16)
      (.continuing (MainFrames.before (CellTotalsData.sharedTotals 0) 0)) :=
  (ArraySourceExecute.sound Header.layout MainLn2.service 128 2048).1
    _ _ _ checked_reset

#print axioms checked_header
#print axioms actual_header
#print axioms checked_reset
#print axioms actual_reset
end SynergyTangentV2C.MainHeaderExact
