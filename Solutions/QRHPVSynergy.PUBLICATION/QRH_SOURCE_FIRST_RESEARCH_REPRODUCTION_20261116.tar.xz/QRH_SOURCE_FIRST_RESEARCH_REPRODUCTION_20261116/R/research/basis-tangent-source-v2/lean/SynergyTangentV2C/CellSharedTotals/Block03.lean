/- Exact cumulative sums, using the corresponding accepted fixed-cell model equations. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Shared096
import SynergyTangentV2C.SourceCells.Shared097
import SynergyTangentV2C.SourceCells.Shared098
import SynergyTangentV2C.SourceCells.Shared099
import SynergyTangentV2C.SourceCells.Shared100
import SynergyTangentV2C.SourceCells.Shared101
import SynergyTangentV2C.SourceCells.Shared102
import SynergyTangentV2C.SourceCells.Shared103
import SynergyTangentV2C.SourceCells.Shared104
import SynergyTangentV2C.SourceCells.Shared105
import SynergyTangentV2C.SourceCells.Shared106
import SynergyTangentV2C.SourceCells.Shared107
import SynergyTangentV2C.SourceCells.Shared108
import SynergyTangentV2C.SourceCells.Shared109
import SynergyTangentV2C.SourceCells.Shared110
import SynergyTangentV2C.SourceCells.Shared111
import SynergyTangentV2C.SourceCells.Shared112
import SynergyTangentV2C.SourceCells.Shared113
import SynergyTangentV2C.SourceCells.Shared114
import SynergyTangentV2C.SourceCells.Shared115
import SynergyTangentV2C.SourceCells.Shared116
import SynergyTangentV2C.SourceCells.Shared117
import SynergyTangentV2C.SourceCells.Shared118
import SynergyTangentV2C.SourceCells.Shared119
import SynergyTangentV2C.SourceCells.Shared120
import SynergyTangentV2C.SourceCells.Shared121
import SynergyTangentV2C.SourceCells.Shared122
import SynergyTangentV2C.SourceCells.Shared123
import SynergyTangentV2C.SourceCells.Shared124
import SynergyTangentV2C.SourceCells.Shared125
import SynergyTangentV2C.SourceCells.Shared126
import SynergyTangentV2C.SourceCells.Shared127
namespace SynergyTangentV2C.CellSharedTotals.Block03
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.sharedOnlyTotals
theorem sum096 :
    (ProofBox.add (totals 96).1 SourceCells.Shared096.output.1,
     ProofBox.add (totals 96).2.1 SourceCells.Shared096.output.2.1,
     ProofBox.add (totals 96).2.2 SourceCells.Shared096.output.2.2)=totals 97 := by
  decide +kernel
#print axioms sum096
theorem sum097 :
    (ProofBox.add (totals 97).1 SourceCells.Shared097.output.1,
     ProofBox.add (totals 97).2.1 SourceCells.Shared097.output.2.1,
     ProofBox.add (totals 97).2.2 SourceCells.Shared097.output.2.2)=totals 98 := by
  decide +kernel
#print axioms sum097
theorem sum098 :
    (ProofBox.add (totals 98).1 SourceCells.Shared098.output.1,
     ProofBox.add (totals 98).2.1 SourceCells.Shared098.output.2.1,
     ProofBox.add (totals 98).2.2 SourceCells.Shared098.output.2.2)=totals 99 := by
  decide +kernel
#print axioms sum098
theorem sum099 :
    (ProofBox.add (totals 99).1 SourceCells.Shared099.output.1,
     ProofBox.add (totals 99).2.1 SourceCells.Shared099.output.2.1,
     ProofBox.add (totals 99).2.2 SourceCells.Shared099.output.2.2)=totals 100 := by
  decide +kernel
#print axioms sum099
theorem sum100 :
    (ProofBox.add (totals 100).1 SourceCells.Shared100.output.1,
     ProofBox.add (totals 100).2.1 SourceCells.Shared100.output.2.1,
     ProofBox.add (totals 100).2.2 SourceCells.Shared100.output.2.2)=totals 101 := by
  decide +kernel
#print axioms sum100
theorem sum101 :
    (ProofBox.add (totals 101).1 SourceCells.Shared101.output.1,
     ProofBox.add (totals 101).2.1 SourceCells.Shared101.output.2.1,
     ProofBox.add (totals 101).2.2 SourceCells.Shared101.output.2.2)=totals 102 := by
  decide +kernel
#print axioms sum101
theorem sum102 :
    (ProofBox.add (totals 102).1 SourceCells.Shared102.output.1,
     ProofBox.add (totals 102).2.1 SourceCells.Shared102.output.2.1,
     ProofBox.add (totals 102).2.2 SourceCells.Shared102.output.2.2)=totals 103 := by
  decide +kernel
#print axioms sum102
theorem sum103 :
    (ProofBox.add (totals 103).1 SourceCells.Shared103.output.1,
     ProofBox.add (totals 103).2.1 SourceCells.Shared103.output.2.1,
     ProofBox.add (totals 103).2.2 SourceCells.Shared103.output.2.2)=totals 104 := by
  decide +kernel
#print axioms sum103
theorem sum104 :
    (ProofBox.add (totals 104).1 SourceCells.Shared104.output.1,
     ProofBox.add (totals 104).2.1 SourceCells.Shared104.output.2.1,
     ProofBox.add (totals 104).2.2 SourceCells.Shared104.output.2.2)=totals 105 := by
  decide +kernel
#print axioms sum104
theorem sum105 :
    (ProofBox.add (totals 105).1 SourceCells.Shared105.output.1,
     ProofBox.add (totals 105).2.1 SourceCells.Shared105.output.2.1,
     ProofBox.add (totals 105).2.2 SourceCells.Shared105.output.2.2)=totals 106 := by
  decide +kernel
#print axioms sum105
theorem sum106 :
    (ProofBox.add (totals 106).1 SourceCells.Shared106.output.1,
     ProofBox.add (totals 106).2.1 SourceCells.Shared106.output.2.1,
     ProofBox.add (totals 106).2.2 SourceCells.Shared106.output.2.2)=totals 107 := by
  decide +kernel
#print axioms sum106
theorem sum107 :
    (ProofBox.add (totals 107).1 SourceCells.Shared107.output.1,
     ProofBox.add (totals 107).2.1 SourceCells.Shared107.output.2.1,
     ProofBox.add (totals 107).2.2 SourceCells.Shared107.output.2.2)=totals 108 := by
  decide +kernel
#print axioms sum107
theorem sum108 :
    (ProofBox.add (totals 108).1 SourceCells.Shared108.output.1,
     ProofBox.add (totals 108).2.1 SourceCells.Shared108.output.2.1,
     ProofBox.add (totals 108).2.2 SourceCells.Shared108.output.2.2)=totals 109 := by
  decide +kernel
#print axioms sum108
theorem sum109 :
    (ProofBox.add (totals 109).1 SourceCells.Shared109.output.1,
     ProofBox.add (totals 109).2.1 SourceCells.Shared109.output.2.1,
     ProofBox.add (totals 109).2.2 SourceCells.Shared109.output.2.2)=totals 110 := by
  decide +kernel
#print axioms sum109
theorem sum110 :
    (ProofBox.add (totals 110).1 SourceCells.Shared110.output.1,
     ProofBox.add (totals 110).2.1 SourceCells.Shared110.output.2.1,
     ProofBox.add (totals 110).2.2 SourceCells.Shared110.output.2.2)=totals 111 := by
  decide +kernel
#print axioms sum110
theorem sum111 :
    (ProofBox.add (totals 111).1 SourceCells.Shared111.output.1,
     ProofBox.add (totals 111).2.1 SourceCells.Shared111.output.2.1,
     ProofBox.add (totals 111).2.2 SourceCells.Shared111.output.2.2)=totals 112 := by
  decide +kernel
#print axioms sum111
theorem sum112 :
    (ProofBox.add (totals 112).1 SourceCells.Shared112.output.1,
     ProofBox.add (totals 112).2.1 SourceCells.Shared112.output.2.1,
     ProofBox.add (totals 112).2.2 SourceCells.Shared112.output.2.2)=totals 113 := by
  decide +kernel
#print axioms sum112
theorem sum113 :
    (ProofBox.add (totals 113).1 SourceCells.Shared113.output.1,
     ProofBox.add (totals 113).2.1 SourceCells.Shared113.output.2.1,
     ProofBox.add (totals 113).2.2 SourceCells.Shared113.output.2.2)=totals 114 := by
  decide +kernel
#print axioms sum113
theorem sum114 :
    (ProofBox.add (totals 114).1 SourceCells.Shared114.output.1,
     ProofBox.add (totals 114).2.1 SourceCells.Shared114.output.2.1,
     ProofBox.add (totals 114).2.2 SourceCells.Shared114.output.2.2)=totals 115 := by
  decide +kernel
#print axioms sum114
theorem sum115 :
    (ProofBox.add (totals 115).1 SourceCells.Shared115.output.1,
     ProofBox.add (totals 115).2.1 SourceCells.Shared115.output.2.1,
     ProofBox.add (totals 115).2.2 SourceCells.Shared115.output.2.2)=totals 116 := by
  decide +kernel
#print axioms sum115
theorem sum116 :
    (ProofBox.add (totals 116).1 SourceCells.Shared116.output.1,
     ProofBox.add (totals 116).2.1 SourceCells.Shared116.output.2.1,
     ProofBox.add (totals 116).2.2 SourceCells.Shared116.output.2.2)=totals 117 := by
  decide +kernel
#print axioms sum116
theorem sum117 :
    (ProofBox.add (totals 117).1 SourceCells.Shared117.output.1,
     ProofBox.add (totals 117).2.1 SourceCells.Shared117.output.2.1,
     ProofBox.add (totals 117).2.2 SourceCells.Shared117.output.2.2)=totals 118 := by
  decide +kernel
#print axioms sum117
theorem sum118 :
    (ProofBox.add (totals 118).1 SourceCells.Shared118.output.1,
     ProofBox.add (totals 118).2.1 SourceCells.Shared118.output.2.1,
     ProofBox.add (totals 118).2.2 SourceCells.Shared118.output.2.2)=totals 119 := by
  decide +kernel
#print axioms sum118
theorem sum119 :
    (ProofBox.add (totals 119).1 SourceCells.Shared119.output.1,
     ProofBox.add (totals 119).2.1 SourceCells.Shared119.output.2.1,
     ProofBox.add (totals 119).2.2 SourceCells.Shared119.output.2.2)=totals 120 := by
  decide +kernel
#print axioms sum119
theorem sum120 :
    (ProofBox.add (totals 120).1 SourceCells.Shared120.output.1,
     ProofBox.add (totals 120).2.1 SourceCells.Shared120.output.2.1,
     ProofBox.add (totals 120).2.2 SourceCells.Shared120.output.2.2)=totals 121 := by
  decide +kernel
#print axioms sum120
theorem sum121 :
    (ProofBox.add (totals 121).1 SourceCells.Shared121.output.1,
     ProofBox.add (totals 121).2.1 SourceCells.Shared121.output.2.1,
     ProofBox.add (totals 121).2.2 SourceCells.Shared121.output.2.2)=totals 122 := by
  decide +kernel
#print axioms sum121
theorem sum122 :
    (ProofBox.add (totals 122).1 SourceCells.Shared122.output.1,
     ProofBox.add (totals 122).2.1 SourceCells.Shared122.output.2.1,
     ProofBox.add (totals 122).2.2 SourceCells.Shared122.output.2.2)=totals 123 := by
  decide +kernel
#print axioms sum122
theorem sum123 :
    (ProofBox.add (totals 123).1 SourceCells.Shared123.output.1,
     ProofBox.add (totals 123).2.1 SourceCells.Shared123.output.2.1,
     ProofBox.add (totals 123).2.2 SourceCells.Shared123.output.2.2)=totals 124 := by
  decide +kernel
#print axioms sum123
theorem sum124 :
    (ProofBox.add (totals 124).1 SourceCells.Shared124.output.1,
     ProofBox.add (totals 124).2.1 SourceCells.Shared124.output.2.1,
     ProofBox.add (totals 124).2.2 SourceCells.Shared124.output.2.2)=totals 125 := by
  decide +kernel
#print axioms sum124
theorem sum125 :
    (ProofBox.add (totals 125).1 SourceCells.Shared125.output.1,
     ProofBox.add (totals 125).2.1 SourceCells.Shared125.output.2.1,
     ProofBox.add (totals 125).2.2 SourceCells.Shared125.output.2.2)=totals 126 := by
  decide +kernel
#print axioms sum125
theorem sum126 :
    (ProofBox.add (totals 126).1 SourceCells.Shared126.output.1,
     ProofBox.add (totals 126).2.1 SourceCells.Shared126.output.2.1,
     ProofBox.add (totals 126).2.2 SourceCells.Shared126.output.2.2)=totals 127 := by
  decide +kernel
#print axioms sum126
theorem sum127 :
    (ProofBox.add (totals 127).1 SourceCells.Shared127.output.1,
     ProofBox.add (totals 127).2.1 SourceCells.Shared127.output.2.1,
     ProofBox.add (totals 127).2.2 SourceCells.Shared127.output.2.2)=totals 128 := by
  decide +kernel
#print axioms sum127
theorem advance (old : SynergyAnalytic.BoxModel.sharedFold 256 96=some (totals 96)) :
    SynergyAnalytic.BoxModel.sharedFold 256 128=some (totals 128) := by
  have fold096 := old
  have fold097 := (CellFoldSteps.shared_next 96 _ _ fold096
    SourceCells.Shared096.model_eq).trans (congrArg some sum096)
  have fold098 := (CellFoldSteps.shared_next 97 _ _ fold097
    SourceCells.Shared097.model_eq).trans (congrArg some sum097)
  have fold099 := (CellFoldSteps.shared_next 98 _ _ fold098
    SourceCells.Shared098.model_eq).trans (congrArg some sum098)
  have fold100 := (CellFoldSteps.shared_next 99 _ _ fold099
    SourceCells.Shared099.model_eq).trans (congrArg some sum099)
  have fold101 := (CellFoldSteps.shared_next 100 _ _ fold100
    SourceCells.Shared100.model_eq).trans (congrArg some sum100)
  have fold102 := (CellFoldSteps.shared_next 101 _ _ fold101
    SourceCells.Shared101.model_eq).trans (congrArg some sum101)
  have fold103 := (CellFoldSteps.shared_next 102 _ _ fold102
    SourceCells.Shared102.model_eq).trans (congrArg some sum102)
  have fold104 := (CellFoldSteps.shared_next 103 _ _ fold103
    SourceCells.Shared103.model_eq).trans (congrArg some sum103)
  have fold105 := (CellFoldSteps.shared_next 104 _ _ fold104
    SourceCells.Shared104.model_eq).trans (congrArg some sum104)
  have fold106 := (CellFoldSteps.shared_next 105 _ _ fold105
    SourceCells.Shared105.model_eq).trans (congrArg some sum105)
  have fold107 := (CellFoldSteps.shared_next 106 _ _ fold106
    SourceCells.Shared106.model_eq).trans (congrArg some sum106)
  have fold108 := (CellFoldSteps.shared_next 107 _ _ fold107
    SourceCells.Shared107.model_eq).trans (congrArg some sum107)
  have fold109 := (CellFoldSteps.shared_next 108 _ _ fold108
    SourceCells.Shared108.model_eq).trans (congrArg some sum108)
  have fold110 := (CellFoldSteps.shared_next 109 _ _ fold109
    SourceCells.Shared109.model_eq).trans (congrArg some sum109)
  have fold111 := (CellFoldSteps.shared_next 110 _ _ fold110
    SourceCells.Shared110.model_eq).trans (congrArg some sum110)
  have fold112 := (CellFoldSteps.shared_next 111 _ _ fold111
    SourceCells.Shared111.model_eq).trans (congrArg some sum111)
  have fold113 := (CellFoldSteps.shared_next 112 _ _ fold112
    SourceCells.Shared112.model_eq).trans (congrArg some sum112)
  have fold114 := (CellFoldSteps.shared_next 113 _ _ fold113
    SourceCells.Shared113.model_eq).trans (congrArg some sum113)
  have fold115 := (CellFoldSteps.shared_next 114 _ _ fold114
    SourceCells.Shared114.model_eq).trans (congrArg some sum114)
  have fold116 := (CellFoldSteps.shared_next 115 _ _ fold115
    SourceCells.Shared115.model_eq).trans (congrArg some sum115)
  have fold117 := (CellFoldSteps.shared_next 116 _ _ fold116
    SourceCells.Shared116.model_eq).trans (congrArg some sum116)
  have fold118 := (CellFoldSteps.shared_next 117 _ _ fold117
    SourceCells.Shared117.model_eq).trans (congrArg some sum117)
  have fold119 := (CellFoldSteps.shared_next 118 _ _ fold118
    SourceCells.Shared118.model_eq).trans (congrArg some sum118)
  have fold120 := (CellFoldSteps.shared_next 119 _ _ fold119
    SourceCells.Shared119.model_eq).trans (congrArg some sum119)
  have fold121 := (CellFoldSteps.shared_next 120 _ _ fold120
    SourceCells.Shared120.model_eq).trans (congrArg some sum120)
  have fold122 := (CellFoldSteps.shared_next 121 _ _ fold121
    SourceCells.Shared121.model_eq).trans (congrArg some sum121)
  have fold123 := (CellFoldSteps.shared_next 122 _ _ fold122
    SourceCells.Shared122.model_eq).trans (congrArg some sum122)
  have fold124 := (CellFoldSteps.shared_next 123 _ _ fold123
    SourceCells.Shared123.model_eq).trans (congrArg some sum123)
  have fold125 := (CellFoldSteps.shared_next 124 _ _ fold124
    SourceCells.Shared124.model_eq).trans (congrArg some sum124)
  have fold126 := (CellFoldSteps.shared_next 125 _ _ fold125
    SourceCells.Shared125.model_eq).trans (congrArg some sum125)
  have fold127 := (CellFoldSteps.shared_next 126 _ _ fold126
    SourceCells.Shared126.model_eq).trans (congrArg some sum126)
  have fold128 := (CellFoldSteps.shared_next 127 _ _ fold127
    SourceCells.Shared127.model_eq).trans (congrArg some sum127)
  exact fold128
#print axioms advance
end SynergyTangentV2C.CellSharedTotals.Block03
