/- Actual l and zero-buffer declarations from the fixed C main. -/
import SynergyTangentV2C.MainCellAPI
namespace SynergyTangentV2C.MainEdges.Shared07
open ScopedC ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024
theorem cell224 : MainCellAPI.ExactEdges true 224
    (SynergyAnalytic.BoxModel.rat 3616 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell225 : MainCellAPI.ExactEdges true 225
    (SynergyAnalytic.BoxModel.rat 3631 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell226 : MainCellAPI.ExactEdges true 226
    (SynergyAnalytic.BoxModel.rat 3646 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell227 : MainCellAPI.ExactEdges true 227
    (SynergyAnalytic.BoxModel.rat 3661 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell228 : MainCellAPI.ExactEdges true 228
    (SynergyAnalytic.BoxModel.rat 3676 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell229 : MainCellAPI.ExactEdges true 229
    (SynergyAnalytic.BoxModel.rat 3691 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell230 : MainCellAPI.ExactEdges true 230
    (SynergyAnalytic.BoxModel.rat 3706 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell231 : MainCellAPI.ExactEdges true 231
    (SynergyAnalytic.BoxModel.rat 3721 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell232 : MainCellAPI.ExactEdges true 232
    (SynergyAnalytic.BoxModel.rat 3736 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell233 : MainCellAPI.ExactEdges true 233
    (SynergyAnalytic.BoxModel.rat 3751 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell234 : MainCellAPI.ExactEdges true 234
    (SynergyAnalytic.BoxModel.rat 3766 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell235 : MainCellAPI.ExactEdges true 235
    (SynergyAnalytic.BoxModel.rat 3781 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell236 : MainCellAPI.ExactEdges true 236
    (SynergyAnalytic.BoxModel.rat 3796 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell237 : MainCellAPI.ExactEdges true 237
    (SynergyAnalytic.BoxModel.rat 3811 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell238 : MainCellAPI.ExactEdges true 238
    (SynergyAnalytic.BoxModel.rat 3826 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell239 : MainCellAPI.ExactEdges true 239
    (SynergyAnalytic.BoxModel.rat 3841 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell240 : MainCellAPI.ExactEdges true 240
    (SynergyAnalytic.BoxModel.rat 3856 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell241 : MainCellAPI.ExactEdges true 241
    (SynergyAnalytic.BoxModel.rat 3871 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell242 : MainCellAPI.ExactEdges true 242
    (SynergyAnalytic.BoxModel.rat 3886 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell243 : MainCellAPI.ExactEdges true 243
    (SynergyAnalytic.BoxModel.rat 3901 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell244 : MainCellAPI.ExactEdges true 244
    (SynergyAnalytic.BoxModel.rat 3916 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell245 : MainCellAPI.ExactEdges true 245
    (SynergyAnalytic.BoxModel.rat 3931 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell246 : MainCellAPI.ExactEdges true 246
    (SynergyAnalytic.BoxModel.rat 3946 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell247 : MainCellAPI.ExactEdges true 247
    (SynergyAnalytic.BoxModel.rat 3961 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell248 : MainCellAPI.ExactEdges true 248
    (SynergyAnalytic.BoxModel.rat 3976 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell249 : MainCellAPI.ExactEdges true 249
    (SynergyAnalytic.BoxModel.rat 3991 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell250 : MainCellAPI.ExactEdges true 250
    (SynergyAnalytic.BoxModel.rat 4006 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell251 : MainCellAPI.ExactEdges true 251
    (SynergyAnalytic.BoxModel.rat 4021 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell252 : MainCellAPI.ExactEdges true 252
    (SynergyAnalytic.BoxModel.rat 4036 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell253 : MainCellAPI.ExactEdges true 253
    (SynergyAnalytic.BoxModel.rat 4051 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell254 : MainCellAPI.ExactEdges true 254
    (SynergyAnalytic.BoxModel.rat 4066 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
theorem cell255 : MainCellAPI.ExactEdges true 255
    (SynergyAnalytic.BoxModel.rat 4081 256) := by
  intro totals arena
  unfold MainCellAPI.edges
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected actual endpoint/buffer source equality"
    goal.assign (← Lean.Meta.mkEqRefl args[1]!)
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell224
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell225
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell226
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell227
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell228
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell229
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell230
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell231
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell232
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell233
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell234
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell235
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell236
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell237
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell238
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell239
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell240
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell241
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell242
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell243
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell244
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell245
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell246
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell247
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell248
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell249
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell250
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell251
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell252
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell253
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell254
#print axioms SynergyTangentV2C.MainEdges.Shared07.cell255
end SynergyTangentV2C.MainEdges.Shared07
