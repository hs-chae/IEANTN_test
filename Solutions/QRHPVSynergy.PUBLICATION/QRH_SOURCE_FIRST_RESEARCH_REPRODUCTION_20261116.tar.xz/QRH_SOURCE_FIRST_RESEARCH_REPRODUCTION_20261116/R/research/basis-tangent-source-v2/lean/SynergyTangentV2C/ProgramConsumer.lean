/- Source-produced numerical payloads are consumed by the real basis theorem.
The existential producer includes the actual initialized program, SAME J reads,
encoded output, functional-model correspondence, and exact integer comparisons.
Finite row/model providers are discharged in the closed program module. -/
import SynergyTangentV2C.MainWholeSource
import SynergyTangentV2C.CellFooterModel
import SynergyTangentV2C.CellPrefixTotals
import SynergyTangentC.RealConsumer
namespace SynergyTangentV2C.ProgramConsumer
open ScopedC ScopedC.Machine ScopedNumerical ScopedIO ScopedIO.WorldIO
open ScopedNumerical.ProofBox SynergyBasis.Positive SynergyAnalytic.BoxModel
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def platform : Platform := ⟨⟨1000000,0,[]⟩⟩
def emptyStream : Stream := ⟨[],0,false⟩
def encoded (value : MainFrames.Totals) : List Nat :=
  ([256,16,value.1.lo,value.1.hi,value.2.1.lo,value.2.1.hi,
    value.2.2.lo,value.2.2.hi].map EmitUBuffer.bytes).flatten

structure Payload (value : MainFrames.Totals) : Prop where
  initialization : MainInitialization.initializeGlobals = some MainInitialization.initial
  source : ConditionalWorld.SourceCall Header.layout Bundle.code platform
    (WorldError.external platform EmitUNormal.policy) 2 "main" []
    ⟨MainInitialization.initial,emptyStream⟩ (WorldIO.signed32 0)
    ⟨MainFrames.initialized,MainOutputData.streamAfter emptyStream 8⟩
  numerical : Loops.SeqRun (ArraySourceCalls.Eval Header.layout MainLn2.service)
    (ArraySourceCalls.Declare Header.layout MainLn2.service) truth ArraySourceCalls.Scope
    (MainLn2.statements.take 19) MainInitialization.initial (.continuing MainFooter.after)
  readZero : Machine.read Header.layout MainFooter.after ⟨5,0,[]⟩ =
    some (CellExecute.represented value.1)
  readOne : Machine.read Header.layout MainFooter.after ⟨5,1,[]⟩ =
    some (CellExecute.represented value.2.1)
  readTwo : Machine.read Header.layout MainFooter.after ⟨5,2,[]⟩ =
    some (CellExecute.represented value.2.2)
  accepted : (MainOutputData.streamAfter emptyStream 8).accepted = encoded value
  model : sourceBasis 256 = some value
  zeroWord : value.1.hi * 200 ≤ 373 * scale p
  oneWord : value.2.1.hi * 2000 ≤ 1273 * scale p
  twoWord : value.2.2.hi * 250 ≤ 129 * scale p

theorem exists_output (prefixRows : MainPureBody.PrefixRows) (sharedRows : MainPureBody.SharedRows)
    (sharedModel : sharedFold 256 256 = some (CellTotalsData.sharedOnlyTotals 256)) :
    ∃ value, Payload value := by
  refine ⟨MainFooter.output,?_⟩
  exact {
    initialization := MainInitialization.actual_initialization
    source := MainWholeSource.main prefixRows sharedRows platform emptyStream rfl
    numerical := MainPureBody.actual_source prefixRows sharedRows
    readZero := MainFooter.read_zero MainPureBody.arena
    readOne := MainFooter.read_one MainPureBody.arena
    readTwo := MainFooter.read_two MainPureBody.arena
    accepted := MainOutputData.accepted emptyStream
    model := CellFooterModel.total_from_folds CellPrefixTotals.complete sharedModel
    zeroWord := by decide +kernel
    oneWord := by decide +kernel
    twoWord := by decide +kernel }

/-- The mathematical consumer receives its value through the source producer.
Classical choice selects a certified source payload, not an unverified table. -/
noncomputable def output (prefixRows : MainPureBody.PrefixRows)
    (sharedRows : MainPureBody.SharedRows)
    (sharedModel : sharedFold 256 256 = some (CellTotalsData.sharedOnlyTotals 256)) :
    MainFrames.Totals := Classical.choose (exists_output prefixRows sharedRows sharedModel)

theorem output_valid (prefixRows : MainPureBody.PrefixRows) (sharedRows : MainPureBody.SharedRows)
    (sharedModel : sharedFold 256 256 = some (CellTotalsData.sharedOnlyTotals 256)) :
    Payload (output prefixRows sharedRows sharedModel) :=
  Classical.choose_spec (exists_output prefixRows sharedRows sharedModel)

theorem basis_caps (prefixRows : MainPureBody.PrefixRows) (sharedRows : MainPureBody.SharedRows)
    (sharedModel : sharedFold 256 256 = some (CellTotalsData.sharedOnlyTotals 256)) :
    SynergyAnalytic.UniversalBasisCaps (373/200) (1273/2000) (129/250) := by
  have provider := output_valid prefixRows sharedRows sharedModel
  exact SynergyTangentC.RealConsumer.caps_from_model_total provider.model
    provider.zeroWord provider.oneWord provider.twoWord

#print axioms exists_output
#print axioms output_valid
#print axioms basis_caps
end SynergyTangentV2C.ProgramConsumer
