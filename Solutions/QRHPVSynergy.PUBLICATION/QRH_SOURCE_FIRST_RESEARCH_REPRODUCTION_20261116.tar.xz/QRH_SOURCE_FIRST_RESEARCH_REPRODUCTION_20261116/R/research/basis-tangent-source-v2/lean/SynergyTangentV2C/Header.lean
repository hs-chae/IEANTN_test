import SynergyC.Header
namespace SynergyTangentV2C
abbrev layout := SynergyC.Header.layout
namespace Header
abbrev TypeDecl := SynergyC.Header.TypeDecl
abbrev types := SynergyC.Header.types
abbrev globals := SynergyC.Header.globals
abbrev renderType := SynergyC.Header.renderType
abbrev externalPrelude := SynergyC.Header.externalPrelude
abbrev layout := SynergyC.Header.layout
end Header
theorem layout_eq : layout = SynergyC.Header.layout := rfl
#print axioms layout_eq
end SynergyTangentV2C
