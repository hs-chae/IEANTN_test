/- Concrete cache shapes, not initial-state or output assumptions.
MainInitialization/MainLn2/MainPrefix prove that the actual source reaches
these states. Every later cell execution still needs its own source proof. -/
import SynergyTangentV2C.Header
import SynergyC.Initialization
import SynergyC.SourceIntervalMath
namespace SynergyTangentV2C.MainFrames
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

/-- An untrusted proposed intermediate. Both its pure-model identity and
the actual C initializer execution are separate mandatory proof obligations. -/
def logarithm : ProofBox :=
  ⟨235865763225513294137944142764154484360,
   235865763225513294137944142764154484523⟩

def initialized : State := {SynergyC.Initialization.state with
  heap := SynergyC.Initialization.state.heap.set 2 {
    type := "I", cells := [some (SynergyC.SourceIntervalMath.represented logarithm)]}}

def unsigned (n : Int) : Value := .integer ⟨⟨false,32⟩,n⟩
abbrev Totals := ProofBox × ProofBox × ProofBox

def before (totals : Totals) (index : Nat) : State := {initialized with
  heap := initialized.heap ++ [
    {type := "const unsigned int", cells := [some (unsigned 256)]},
    {type := "const unsigned int", cells := [some (unsigned 16)]},
    {type := "I", isArray := true, cells := [
      some (SynergyC.SourceIntervalMath.represented totals.1),
      some (SynergyC.SourceIntervalMath.represented totals.2.1),
      some (SynergyC.SourceIntervalMath.represented totals.2.2)]},
    {type := "unsigned int", cells := [some (unsigned index)]}]
  env := [("i",⟨6,0,[]⟩),("J",⟨5,0,[]⟩),
    ("prefix",⟨4,0,[]⟩),("cells",⟨3,0,[]⟩)]}

/-- Exact caller state after the actual iteration's l declaration and
before its three zero-initialized output buffers are declared. -/
def base (totals : Totals) (index : Nat) (left : ProofBox) : State :=
  allocate (before totals index) "I" "l"
    (some (SynergyC.SourceIntervalMath.represented left))

theorem before_heap_length (totals : Totals) (index : Nat) :
    (before totals index).heap.length = 7 := by rfl
theorem base_heap_length (totals : Totals) (index : Nat) (left : ProofBox) :
    (base totals index left).heap.length = 8 := by rfl
theorem before_globals (totals : Totals) (index : Nat) :
    (before totals index).globals = initialized.globals := by rfl
theorem before_stdout (totals : Totals) (index : Nat) :
    (before totals index).globals.lookup "stdout" = none := by rfl
theorem base_stdout (totals : Totals) (index : Nat) (left : ProofBox) :
    (base totals index left).globals.lookup "stdout" = none := by rfl

#print axioms before_heap_length
#print axioms base_heap_length
#print axioms before_globals
#print axioms before_stdout
#print axioms base_stdout
end SynergyTangentV2C.MainFrames
