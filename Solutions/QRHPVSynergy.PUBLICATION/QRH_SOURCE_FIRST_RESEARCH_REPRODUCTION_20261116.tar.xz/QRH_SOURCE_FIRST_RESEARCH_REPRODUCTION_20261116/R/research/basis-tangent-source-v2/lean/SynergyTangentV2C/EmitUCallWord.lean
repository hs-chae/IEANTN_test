/- The exact public emitter service on a representable unsigned source word. -/
import SynergyTangentV2C.EmitUService
namespace SynergyTangentV2C.EmitUCallWord
open ScopedC ScopedC.Machine
set_option autoImplicit false

theorem call_word (platform : ScopedIO.WorldIO.Platform)
    (fault : ScopedIO.WorldIO.FaultPolicy) (x : Int)
    (hx : SynergyC.Word512.Range x) (world : ScopedIO.WorldIO.World) :
    EmitUService.call platform fault "emitU" [SynergyC.Word512.value x] world =
      EmitUService.invoke platform fault x world := by
  have range : 0 ≤ x ∧ x < 2^512 := hx
  simp [EmitUService.call,SynergyC.Word512.value,SynergyC.Word512.word,range]

#print axioms call_word
end SynergyTangentV2C.EmitUCallWord
