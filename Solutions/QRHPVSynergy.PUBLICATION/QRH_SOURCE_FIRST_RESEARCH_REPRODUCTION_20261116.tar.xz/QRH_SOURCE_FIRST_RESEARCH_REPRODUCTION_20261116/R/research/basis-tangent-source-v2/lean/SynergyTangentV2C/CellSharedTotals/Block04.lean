/- Exact cumulative sums, using the corresponding accepted fixed-cell model equations. -/
import SynergyTangentV2C.CellTotalsData
import SynergyTangentV2C.CellFoldSteps
import SynergyTangentV2C.SourceCells.Shared128
import SynergyTangentV2C.SourceCells.Shared129
import SynergyTangentV2C.SourceCells.Shared130
import SynergyTangentV2C.SourceCells.Shared131
import SynergyTangentV2C.SourceCells.Shared132
import SynergyTangentV2C.SourceCells.Shared133
import SynergyTangentV2C.SourceCells.Shared134
import SynergyTangentV2C.SourceCells.Shared135
import SynergyTangentV2C.SourceCells.Shared136
import SynergyTangentV2C.SourceCells.Shared137
import SynergyTangentV2C.SourceCells.Shared138
import SynergyTangentV2C.SourceCells.Shared139
import SynergyTangentV2C.SourceCells.Shared140
import SynergyTangentV2C.SourceCells.Shared141
import SynergyTangentV2C.SourceCells.Shared142
import SynergyTangentV2C.SourceCells.Shared143
import SynergyTangentV2C.SourceCells.Shared144
import SynergyTangentV2C.SourceCells.Shared145
import SynergyTangentV2C.SourceCells.Shared146
import SynergyTangentV2C.SourceCells.Shared147
import SynergyTangentV2C.SourceCells.Shared148
import SynergyTangentV2C.SourceCells.Shared149
import SynergyTangentV2C.SourceCells.Shared150
import SynergyTangentV2C.SourceCells.Shared151
import SynergyTangentV2C.SourceCells.Shared152
import SynergyTangentV2C.SourceCells.Shared153
import SynergyTangentV2C.SourceCells.Shared154
import SynergyTangentV2C.SourceCells.Shared155
import SynergyTangentV2C.SourceCells.Shared156
import SynergyTangentV2C.SourceCells.Shared157
import SynergyTangentV2C.SourceCells.Shared158
import SynergyTangentV2C.SourceCells.Shared159
namespace SynergyTangentV2C.CellSharedTotals.Block04
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev totals := CellTotalsData.sharedOnlyTotals
theorem sum128 :
    (ProofBox.add (totals 128).1 SourceCells.Shared128.output.1,
     ProofBox.add (totals 128).2.1 SourceCells.Shared128.output.2.1,
     ProofBox.add (totals 128).2.2 SourceCells.Shared128.output.2.2)=totals 129 := by
  decide +kernel
#print axioms sum128
theorem sum129 :
    (ProofBox.add (totals 129).1 SourceCells.Shared129.output.1,
     ProofBox.add (totals 129).2.1 SourceCells.Shared129.output.2.1,
     ProofBox.add (totals 129).2.2 SourceCells.Shared129.output.2.2)=totals 130 := by
  decide +kernel
#print axioms sum129
theorem sum130 :
    (ProofBox.add (totals 130).1 SourceCells.Shared130.output.1,
     ProofBox.add (totals 130).2.1 SourceCells.Shared130.output.2.1,
     ProofBox.add (totals 130).2.2 SourceCells.Shared130.output.2.2)=totals 131 := by
  decide +kernel
#print axioms sum130
theorem sum131 :
    (ProofBox.add (totals 131).1 SourceCells.Shared131.output.1,
     ProofBox.add (totals 131).2.1 SourceCells.Shared131.output.2.1,
     ProofBox.add (totals 131).2.2 SourceCells.Shared131.output.2.2)=totals 132 := by
  decide +kernel
#print axioms sum131
theorem sum132 :
    (ProofBox.add (totals 132).1 SourceCells.Shared132.output.1,
     ProofBox.add (totals 132).2.1 SourceCells.Shared132.output.2.1,
     ProofBox.add (totals 132).2.2 SourceCells.Shared132.output.2.2)=totals 133 := by
  decide +kernel
#print axioms sum132
theorem sum133 :
    (ProofBox.add (totals 133).1 SourceCells.Shared133.output.1,
     ProofBox.add (totals 133).2.1 SourceCells.Shared133.output.2.1,
     ProofBox.add (totals 133).2.2 SourceCells.Shared133.output.2.2)=totals 134 := by
  decide +kernel
#print axioms sum133
theorem sum134 :
    (ProofBox.add (totals 134).1 SourceCells.Shared134.output.1,
     ProofBox.add (totals 134).2.1 SourceCells.Shared134.output.2.1,
     ProofBox.add (totals 134).2.2 SourceCells.Shared134.output.2.2)=totals 135 := by
  decide +kernel
#print axioms sum134
theorem sum135 :
    (ProofBox.add (totals 135).1 SourceCells.Shared135.output.1,
     ProofBox.add (totals 135).2.1 SourceCells.Shared135.output.2.1,
     ProofBox.add (totals 135).2.2 SourceCells.Shared135.output.2.2)=totals 136 := by
  decide +kernel
#print axioms sum135
theorem sum136 :
    (ProofBox.add (totals 136).1 SourceCells.Shared136.output.1,
     ProofBox.add (totals 136).2.1 SourceCells.Shared136.output.2.1,
     ProofBox.add (totals 136).2.2 SourceCells.Shared136.output.2.2)=totals 137 := by
  decide +kernel
#print axioms sum136
theorem sum137 :
    (ProofBox.add (totals 137).1 SourceCells.Shared137.output.1,
     ProofBox.add (totals 137).2.1 SourceCells.Shared137.output.2.1,
     ProofBox.add (totals 137).2.2 SourceCells.Shared137.output.2.2)=totals 138 := by
  decide +kernel
#print axioms sum137
theorem sum138 :
    (ProofBox.add (totals 138).1 SourceCells.Shared138.output.1,
     ProofBox.add (totals 138).2.1 SourceCells.Shared138.output.2.1,
     ProofBox.add (totals 138).2.2 SourceCells.Shared138.output.2.2)=totals 139 := by
  decide +kernel
#print axioms sum138
theorem sum139 :
    (ProofBox.add (totals 139).1 SourceCells.Shared139.output.1,
     ProofBox.add (totals 139).2.1 SourceCells.Shared139.output.2.1,
     ProofBox.add (totals 139).2.2 SourceCells.Shared139.output.2.2)=totals 140 := by
  decide +kernel
#print axioms sum139
theorem sum140 :
    (ProofBox.add (totals 140).1 SourceCells.Shared140.output.1,
     ProofBox.add (totals 140).2.1 SourceCells.Shared140.output.2.1,
     ProofBox.add (totals 140).2.2 SourceCells.Shared140.output.2.2)=totals 141 := by
  decide +kernel
#print axioms sum140
theorem sum141 :
    (ProofBox.add (totals 141).1 SourceCells.Shared141.output.1,
     ProofBox.add (totals 141).2.1 SourceCells.Shared141.output.2.1,
     ProofBox.add (totals 141).2.2 SourceCells.Shared141.output.2.2)=totals 142 := by
  decide +kernel
#print axioms sum141
theorem sum142 :
    (ProofBox.add (totals 142).1 SourceCells.Shared142.output.1,
     ProofBox.add (totals 142).2.1 SourceCells.Shared142.output.2.1,
     ProofBox.add (totals 142).2.2 SourceCells.Shared142.output.2.2)=totals 143 := by
  decide +kernel
#print axioms sum142
theorem sum143 :
    (ProofBox.add (totals 143).1 SourceCells.Shared143.output.1,
     ProofBox.add (totals 143).2.1 SourceCells.Shared143.output.2.1,
     ProofBox.add (totals 143).2.2 SourceCells.Shared143.output.2.2)=totals 144 := by
  decide +kernel
#print axioms sum143
theorem sum144 :
    (ProofBox.add (totals 144).1 SourceCells.Shared144.output.1,
     ProofBox.add (totals 144).2.1 SourceCells.Shared144.output.2.1,
     ProofBox.add (totals 144).2.2 SourceCells.Shared144.output.2.2)=totals 145 := by
  decide +kernel
#print axioms sum144
theorem sum145 :
    (ProofBox.add (totals 145).1 SourceCells.Shared145.output.1,
     ProofBox.add (totals 145).2.1 SourceCells.Shared145.output.2.1,
     ProofBox.add (totals 145).2.2 SourceCells.Shared145.output.2.2)=totals 146 := by
  decide +kernel
#print axioms sum145
theorem sum146 :
    (ProofBox.add (totals 146).1 SourceCells.Shared146.output.1,
     ProofBox.add (totals 146).2.1 SourceCells.Shared146.output.2.1,
     ProofBox.add (totals 146).2.2 SourceCells.Shared146.output.2.2)=totals 147 := by
  decide +kernel
#print axioms sum146
theorem sum147 :
    (ProofBox.add (totals 147).1 SourceCells.Shared147.output.1,
     ProofBox.add (totals 147).2.1 SourceCells.Shared147.output.2.1,
     ProofBox.add (totals 147).2.2 SourceCells.Shared147.output.2.2)=totals 148 := by
  decide +kernel
#print axioms sum147
theorem sum148 :
    (ProofBox.add (totals 148).1 SourceCells.Shared148.output.1,
     ProofBox.add (totals 148).2.1 SourceCells.Shared148.output.2.1,
     ProofBox.add (totals 148).2.2 SourceCells.Shared148.output.2.2)=totals 149 := by
  decide +kernel
#print axioms sum148
theorem sum149 :
    (ProofBox.add (totals 149).1 SourceCells.Shared149.output.1,
     ProofBox.add (totals 149).2.1 SourceCells.Shared149.output.2.1,
     ProofBox.add (totals 149).2.2 SourceCells.Shared149.output.2.2)=totals 150 := by
  decide +kernel
#print axioms sum149
theorem sum150 :
    (ProofBox.add (totals 150).1 SourceCells.Shared150.output.1,
     ProofBox.add (totals 150).2.1 SourceCells.Shared150.output.2.1,
     ProofBox.add (totals 150).2.2 SourceCells.Shared150.output.2.2)=totals 151 := by
  decide +kernel
#print axioms sum150
theorem sum151 :
    (ProofBox.add (totals 151).1 SourceCells.Shared151.output.1,
     ProofBox.add (totals 151).2.1 SourceCells.Shared151.output.2.1,
     ProofBox.add (totals 151).2.2 SourceCells.Shared151.output.2.2)=totals 152 := by
  decide +kernel
#print axioms sum151
theorem sum152 :
    (ProofBox.add (totals 152).1 SourceCells.Shared152.output.1,
     ProofBox.add (totals 152).2.1 SourceCells.Shared152.output.2.1,
     ProofBox.add (totals 152).2.2 SourceCells.Shared152.output.2.2)=totals 153 := by
  decide +kernel
#print axioms sum152
theorem sum153 :
    (ProofBox.add (totals 153).1 SourceCells.Shared153.output.1,
     ProofBox.add (totals 153).2.1 SourceCells.Shared153.output.2.1,
     ProofBox.add (totals 153).2.2 SourceCells.Shared153.output.2.2)=totals 154 := by
  decide +kernel
#print axioms sum153
theorem sum154 :
    (ProofBox.add (totals 154).1 SourceCells.Shared154.output.1,
     ProofBox.add (totals 154).2.1 SourceCells.Shared154.output.2.1,
     ProofBox.add (totals 154).2.2 SourceCells.Shared154.output.2.2)=totals 155 := by
  decide +kernel
#print axioms sum154
theorem sum155 :
    (ProofBox.add (totals 155).1 SourceCells.Shared155.output.1,
     ProofBox.add (totals 155).2.1 SourceCells.Shared155.output.2.1,
     ProofBox.add (totals 155).2.2 SourceCells.Shared155.output.2.2)=totals 156 := by
  decide +kernel
#print axioms sum155
theorem sum156 :
    (ProofBox.add (totals 156).1 SourceCells.Shared156.output.1,
     ProofBox.add (totals 156).2.1 SourceCells.Shared156.output.2.1,
     ProofBox.add (totals 156).2.2 SourceCells.Shared156.output.2.2)=totals 157 := by
  decide +kernel
#print axioms sum156
theorem sum157 :
    (ProofBox.add (totals 157).1 SourceCells.Shared157.output.1,
     ProofBox.add (totals 157).2.1 SourceCells.Shared157.output.2.1,
     ProofBox.add (totals 157).2.2 SourceCells.Shared157.output.2.2)=totals 158 := by
  decide +kernel
#print axioms sum157
theorem sum158 :
    (ProofBox.add (totals 158).1 SourceCells.Shared158.output.1,
     ProofBox.add (totals 158).2.1 SourceCells.Shared158.output.2.1,
     ProofBox.add (totals 158).2.2 SourceCells.Shared158.output.2.2)=totals 159 := by
  decide +kernel
#print axioms sum158
theorem sum159 :
    (ProofBox.add (totals 159).1 SourceCells.Shared159.output.1,
     ProofBox.add (totals 159).2.1 SourceCells.Shared159.output.2.1,
     ProofBox.add (totals 159).2.2 SourceCells.Shared159.output.2.2)=totals 160 := by
  decide +kernel
#print axioms sum159
theorem advance (old : SynergyAnalytic.BoxModel.sharedFold 256 128=some (totals 128)) :
    SynergyAnalytic.BoxModel.sharedFold 256 160=some (totals 160) := by
  have fold128 := old
  have fold129 := (CellFoldSteps.shared_next 128 _ _ fold128
    SourceCells.Shared128.model_eq).trans (congrArg some sum128)
  have fold130 := (CellFoldSteps.shared_next 129 _ _ fold129
    SourceCells.Shared129.model_eq).trans (congrArg some sum129)
  have fold131 := (CellFoldSteps.shared_next 130 _ _ fold130
    SourceCells.Shared130.model_eq).trans (congrArg some sum130)
  have fold132 := (CellFoldSteps.shared_next 131 _ _ fold131
    SourceCells.Shared131.model_eq).trans (congrArg some sum131)
  have fold133 := (CellFoldSteps.shared_next 132 _ _ fold132
    SourceCells.Shared132.model_eq).trans (congrArg some sum132)
  have fold134 := (CellFoldSteps.shared_next 133 _ _ fold133
    SourceCells.Shared133.model_eq).trans (congrArg some sum133)
  have fold135 := (CellFoldSteps.shared_next 134 _ _ fold134
    SourceCells.Shared134.model_eq).trans (congrArg some sum134)
  have fold136 := (CellFoldSteps.shared_next 135 _ _ fold135
    SourceCells.Shared135.model_eq).trans (congrArg some sum135)
  have fold137 := (CellFoldSteps.shared_next 136 _ _ fold136
    SourceCells.Shared136.model_eq).trans (congrArg some sum136)
  have fold138 := (CellFoldSteps.shared_next 137 _ _ fold137
    SourceCells.Shared137.model_eq).trans (congrArg some sum137)
  have fold139 := (CellFoldSteps.shared_next 138 _ _ fold138
    SourceCells.Shared138.model_eq).trans (congrArg some sum138)
  have fold140 := (CellFoldSteps.shared_next 139 _ _ fold139
    SourceCells.Shared139.model_eq).trans (congrArg some sum139)
  have fold141 := (CellFoldSteps.shared_next 140 _ _ fold140
    SourceCells.Shared140.model_eq).trans (congrArg some sum140)
  have fold142 := (CellFoldSteps.shared_next 141 _ _ fold141
    SourceCells.Shared141.model_eq).trans (congrArg some sum141)
  have fold143 := (CellFoldSteps.shared_next 142 _ _ fold142
    SourceCells.Shared142.model_eq).trans (congrArg some sum142)
  have fold144 := (CellFoldSteps.shared_next 143 _ _ fold143
    SourceCells.Shared143.model_eq).trans (congrArg some sum143)
  have fold145 := (CellFoldSteps.shared_next 144 _ _ fold144
    SourceCells.Shared144.model_eq).trans (congrArg some sum144)
  have fold146 := (CellFoldSteps.shared_next 145 _ _ fold145
    SourceCells.Shared145.model_eq).trans (congrArg some sum145)
  have fold147 := (CellFoldSteps.shared_next 146 _ _ fold146
    SourceCells.Shared146.model_eq).trans (congrArg some sum146)
  have fold148 := (CellFoldSteps.shared_next 147 _ _ fold147
    SourceCells.Shared147.model_eq).trans (congrArg some sum147)
  have fold149 := (CellFoldSteps.shared_next 148 _ _ fold148
    SourceCells.Shared148.model_eq).trans (congrArg some sum148)
  have fold150 := (CellFoldSteps.shared_next 149 _ _ fold149
    SourceCells.Shared149.model_eq).trans (congrArg some sum149)
  have fold151 := (CellFoldSteps.shared_next 150 _ _ fold150
    SourceCells.Shared150.model_eq).trans (congrArg some sum150)
  have fold152 := (CellFoldSteps.shared_next 151 _ _ fold151
    SourceCells.Shared151.model_eq).trans (congrArg some sum151)
  have fold153 := (CellFoldSteps.shared_next 152 _ _ fold152
    SourceCells.Shared152.model_eq).trans (congrArg some sum152)
  have fold154 := (CellFoldSteps.shared_next 153 _ _ fold153
    SourceCells.Shared153.model_eq).trans (congrArg some sum153)
  have fold155 := (CellFoldSteps.shared_next 154 _ _ fold154
    SourceCells.Shared154.model_eq).trans (congrArg some sum154)
  have fold156 := (CellFoldSteps.shared_next 155 _ _ fold155
    SourceCells.Shared155.model_eq).trans (congrArg some sum155)
  have fold157 := (CellFoldSteps.shared_next 156 _ _ fold156
    SourceCells.Shared156.model_eq).trans (congrArg some sum156)
  have fold158 := (CellFoldSteps.shared_next 157 _ _ fold157
    SourceCells.Shared157.model_eq).trans (congrArg some sum157)
  have fold159 := (CellFoldSteps.shared_next 158 _ _ fold158
    SourceCells.Shared158.model_eq).trans (congrArg some sum158)
  have fold160 := (CellFoldSteps.shared_next 159 _ _ fold159
    SourceCells.Shared159.model_eq).trans (congrArg some sum159)
  exact fold160
#print axioms advance
end SynergyTangentV2C.CellSharedTotals.Block04
