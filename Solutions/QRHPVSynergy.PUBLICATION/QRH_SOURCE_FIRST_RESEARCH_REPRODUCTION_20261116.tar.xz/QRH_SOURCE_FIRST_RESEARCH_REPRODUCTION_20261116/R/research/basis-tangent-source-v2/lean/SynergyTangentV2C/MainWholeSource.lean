/- Actual complete main: initialized globals, both integration loops, peak/tail,
eight emitU calls, checked ferror expression, return and lifetime restoration.
Only the finite source-row providers remain arguments at this composition layer. -/
import SynergyTangentV2C.MainPureBody
import SynergyTangentV2C.MainOutputRun
namespace SynergyTangentV2C.MainWholeSource
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedNumerical ScopedIO ScopedIO.WorldIO
open MainOutputData
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def returnStatement : Stmt := .returnStmt
  (.conditional (.call (.var "ferror") [.var "stdout"]) (.nat 2) (.nat 0))

theorem actual_partition : Generated.f_main.body = .sequence
    (MainLn2.statements.take 19 ++ ((MainLn2.statements.drop 19).take 4 ++
      [returnStatement])) := by rfl
theorem restores_initial_scope : Machine.popScope MainInitialization.initial (atIndex 3) =
    MainFrames.initialized := by rfl

theorem seq_append {platform : Platform} {ss tt : List Stmt}
    {s middle : World} {out : Loops.Flow World Value}
    (first : Loops.SeqRun (ConditionalWorld.Eval Header.layout MainLn2.service
      (MainWorldService.call platform) platform) (WorldSource.Declare Header.layout MainLn2.service)
      truth WorldSource.Scope ss s (.continuing middle))
    (rest : Loops.SeqRun (ConditionalWorld.Eval Header.layout MainLn2.service
      (MainWorldService.call platform) platform) (WorldSource.Declare Header.layout MainLn2.service)
      truth WorldSource.Scope tt middle out) :
    Loops.SeqRun (ConditionalWorld.Eval Header.layout MainLn2.service
      (MainWorldService.call platform) platform) (WorldSource.Declare Header.layout MainLn2.service)
      truth WorldSource.Scope (ss ++ tt) s out := by
  induction ss generalizing s with
  | nil => cases first; exact rest
  | cons head tail ih =>
    cases first with
    | next hhead htail => exact .next hhead (ih htail)

theorem actual_body (prefixRows : MainPureBody.PrefixRows)
    (sharedRows : MainPureBody.SharedRows) (platform : Platform) (stream : Stream)
    (healthy : stream.error = false) :
    ConditionalWorld.Run Header.layout MainLn2.service (MainWorldService.call platform) platform
      Generated.f_main.body ⟨MainInitialization.initial,stream⟩
      (.returned ⟨MainFrames.initialized,streamAfter stream 8⟩ (WorldIO.signed32 0)) := by
  have first := ConditionalWorld.statements_old
    (MainPureBody.world_source prefixRows sharedRows platform (MainWorldService.call platform) stream)
  have output := ConditionalWorld.statements_old (MainOutputRun.output_prefix platform stream)
  have final : Loops.SeqRun (ConditionalWorld.Eval Header.layout MainLn2.service
      (MainWorldService.call platform) platform) (WorldSource.Declare Header.layout MainLn2.service)
      truth WorldSource.Scope [returnStatement] ⟨atIndex 3,streamAfter stream 8⟩
      (.returned ⟨atIndex 3,streamAfter stream 8⟩ (WorldIO.signed32 0)) :=
    .returned (MainOutputRun.actual_return platform stream healthy)
  have all := seq_append first (seq_append output final)
  rw [actual_partition]
  refine Loops.StmtRun.sequence all ?_
  change WorldIO.signed32 0 = WorldIO.signed32 0 ∧
    (⟨MainFrames.initialized,streamAfter stream 8⟩ : World) =
      ⟨Machine.popScope MainInitialization.initial (atIndex 3),streamAfter stream 8⟩
  exact ⟨rfl,by rw [restores_initial_scope]⟩

theorem main (prefixRows : MainPureBody.PrefixRows) (sharedRows : MainPureBody.SharedRows)
    (platform : Platform) (stream : Stream) (healthy : stream.error = false) :
    ConditionalWorld.SourceCall Header.layout Bundle.code platform
      (WorldError.external platform EmitUNormal.policy) 2 "main" []
      ⟨MainInitialization.initial,stream⟩ (WorldIO.signed32 0)
      ⟨MainFrames.initialized,streamAfter stream 8⟩ := by
  have installed : Generated.f_main ∈ Bundle.code := by
    rw [Bundle.code_exact]
    exact List.mem_of_getElem?
      (show Generated.functions[23]? = some Generated.f_main by rfl)
  exact ConditionalWorld.installed_call Generated.f_main installed rfl
    MainLn2.service (fun _ _ _ _ _ h => MainWorldService.pure_closed h)
    (MainWorldService.call platform)
    (fun _ _ _ _ _ h => MainWorldService.closed platform h)
    MainInitialization.initial rfl
    (.returned ⟨MainFrames.initialized,streamAfter stream 8⟩ (WorldIO.signed32 0))
    (actual_body prefixRows sharedRows platform stream healthy)
    (by constructor <;> rfl)

theorem initialized_program (prefixRows : MainPureBody.PrefixRows)
    (sharedRows : MainPureBody.SharedRows) (platform : Platform) (stream : Stream)
    (healthy : stream.error = false) :
    MainInitialization.initializeGlobals = some MainInitialization.initial ∧
    ConditionalWorld.SourceCall Header.layout Bundle.code platform
      (WorldError.external platform EmitUNormal.policy) 2 "main" []
      ⟨MainInitialization.initial,stream⟩ (WorldIO.signed32 0)
      ⟨MainFrames.initialized,streamAfter stream 8⟩ ∧
    (streamAfter stream 8).accepted = stream.accepted ++ bytes :=
  ⟨MainInitialization.actual_initialization,main prefixRows sharedRows platform stream healthy,
    accepted stream⟩

#print axioms actual_partition
#print axioms restores_initial_scope
#print axioms seq_append
#print axioms actual_body
#print axioms main
#print axioms initialized_program
end SynergyTangentV2C.MainWholeSource
