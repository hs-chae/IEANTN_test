// Copyright (c) 2026 IEANTN contributors. Apache-2.0.
// New unrestricted second-order quadrature research; NOT yet source-PV.
#define main archived_basis_main
#include "basis_fp128_height_v2.cpp"
#undef main
#ifndef BASIS_TANGENT_CELLS
#define BASIS_TANGENT_CELLS 256
#endif
static I powerI(I x,unsigned n) {
  I y=unit();unsigned i=0;
  while (i<n) { y=mul(y,x);i=i+1; }
  return y;
}
// Integral0..width v^j exp(-lambda*v)dv, in exact-real interpretation.
static I exponentialMoment(I lambda,I width,unsigned j) {
  if (j>4) fail();
  I z=mul(lambda,width);I term=unit();I sum=unit();unsigned k=1;
  while (k<=j) { term=divN(mul(term,z),k);sum=add(sum,term);k=k+1; }
  I residue=positiveSub(unit(),mul(expNeg(z),sum));
  unsigned factorial=1;k=1;
  while (k<=j) { factorial=factorial*k;k=k+1; }
  return divI(mul(rat(factorial,1),residue),powerI(lambda,j+1));
}
static void tangentCell(I left,I width,I *zeroBound,I *oneBound,I *twoBound,unsigned logs) {
  I q=rat(601,2500);I a=divN(add(left,rat(2,1)),3);
  // ANY positive tangent parameter is sound. No cube-root accuracy or
  // Newton convergence claim is used in this construction.
  unsigned refinement=0;
  while(refinement<2) {
    a=divN(add(mul(rat(2,1),a),divI(left,mul(a,a))),3);
    refinement=refinement+1;
  }
  I A=divN(mul(rat(5,1),a),6);I B=divI(unit(),mul(rat(6,1),powerI(a,5)));
  I coefficients[5]={add(A,mul(B,mul(left,left))),mul(rat(2,1),mul(B,left)),B,zero(),zero()};
  I moments[5];I lambda=mul(rat(2,1),mul(q,left));unsigned k=0;
  while (k<5) { moments[k]=exponentialMoment(lambda,width,k);k=k+1; }
  I gaussian=expNeg(mul(q,mul(left,left)));
  I logLeft=logs?logPos(left):zero();I invLeft=divI(unit(),left);
  unsigned j=0;
  while (j<=logs) {
    I total=zero();k=0;
    while (k<5) { total=add(total,mul(coefficients[k],moments[k]));k=k+1; }
    I bound=mul(gaussian,total);
    if (j==0) *zeroBound=bound; else if (j==1) *oneBound=bound; else *twoBound=bound;
    I next[5]={zero(),zero(),zero(),zero(),zero()};k=0;
    while (k<5) {
      next[k]=add(next[k],mul(coefficients[k],logLeft));
      if (k<4) next[k+1]=add(next[k+1],mul(coefficients[k],invLeft));
      k=k+1;
    }
    k=0;while(k<5){coefficients[k]=next[k];k=k+1;}j=j+1;
  }
}
static void emitU(U x) {
  uint64_t limbs[8];unsigned k=0;
  while(k<8){limbs[k]=(uint64_t)(x>>(64*k));k=k+1;}
  if(fwrite(limbs,8,8,stdout)!=8)fail();
}
int main() {
  ln2=atanh2(rat(1,3));const unsigned cells=BASIS_TANGENT_CELLS;
  if(cells<16 || cells>65536)fail();const unsigned prefix=cells/16;
  I J[3]={zero(),zero(),zero()};unsigned i=0;
  while(i<prefix) {
    I l=rat(5*prefix+i,6*prefix);I b0=zero(),b1=zero(),b2=zero();
    tangentCell(l,rat(1,6*prefix),&b0,&b1,&b2,0);J[0]=add(J[0],b0);i=i+1;
  }
  i=0;
  while(i<cells) {
    I l=rat(cells+15*i,cells);I b0=zero(),b1=zero(),b2=zero();
    tangentCell(l,rat(15,cells),&b0,&b1,&b2,2);
    J[0]=add(J[0],b0);J[1]=add(J[1],b1);J[2]=add(J[2],b2);i=i+1;
  }
  I q=rat(601,2500);I M=expNeg(divN(add(unit(),logPos(mul(rat(6,1),q))),6));
  I bq=mul(rat(256,1),q);I tail=divI(mul(expNeg(bq),add(bq,unit())),mul(rat(2,1),mul(q,q)));
  J[0]=add(add(J[0],mul(rat(5,6),M)),tail);J[1]=add(J[1],tail);J[2]=add(J[2],tail);
  emitU(cells);emitU(prefix);i=0;
  while(i<3){emitU(J[i].lo);emitU(J[i].hi);i=i+1;}
  return ferror(stdout)?2:0;
}
