#!/usr/bin/env python3
"""Derive a fresh V7 source packet; leave the original extracted packet intact."""
from pathlib import Path
import argparse
import ast
import importlib.util
import json
import os
import shutil

HERE = Path(__file__).resolve().parent
PATCH_SHA = '3d6e72f6cc1f616e1793d9c9318f9213fdfbce131ba3f66cc4876989206e8f58'
FOUNDATION_SHA = '9a60693eca0c040ae522deef38009786fe675a0130bf0ed7d96f04439f9e88c8'
MASTER = 'R/research/complete-clean-reproduction-v1/reproduce_research_v7.py'
FINALIZER = ('R/research/source-repaired-closure-v1/numerics-final-contexts-v1/'
             'finalize_one_context_v3.py')


def sha(path):
    import hashlib
    result = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def need(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    base = args.base.resolve()
    payload = HERE / 'payload'
    need(sha(HERE / 'PATCH_MANIFEST.json') == PATCH_SHA, 'Exact frozen overlay manifest')
    foundation = base / 'R/research/complete-clean-reproduction-v1/foundation_v2.py'
    need(foundation.is_file() and not foundation.is_symlink() and
         sha(foundation) == FOUNDATION_SHA, 'Exact preserved packet foundation')
    spec = importlib.util.spec_from_file_location('overlay_foundation', foundation)
    f = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(f)
    patch = f.read(HERE / 'PATCH_MANIFEST.json')
    need(sha(base / 'INPUT_MANIFEST.json') == patch['base_input_manifest_sha256'],
         'Exact original V7 input manifest')
    old, _ = f.packet_check(base)
    for row in patch['files']:
        path = Path(row['path'])
        need(not path.is_absolute() and '..' not in path.parts, 'Safe overlay path')
        source = payload / path
        need(source.is_file() and not source.is_symlink() and sha(source) == row['sha256']
             and source.stat().st_size == row['bytes'], 'Exact overlay payload ' + str(path))
        target = base / path
        need((sha(target) if target.is_file() else None) == row['old_sha256'],
             'Exact prior overlay target ' + str(path))
    new = f.read(payload / 'INPUT_MANIFEST.json')
    old_rows = {row['path']: row for row in old['files']}
    new_rows = {row['path']: row for row in new['files']}
    need(len(old_rows) == 7038 and len(new_rows) == len(new['files']) == 7045,
         'Exact unique old and new source populations')
    need(set(new_rows) - set(old_rows) == set(patch['added_source_paths']) and
         len(patch['added_source_paths']) == 7 and set(old_rows) <= set(new_rows),
         'Exactly seven reviewed additive control source paths')
    need(all(new_rows[name] == row for name, row in old_rows.items() if name != 'README.md'),
         'Every existing non-README source descriptor preserved')
    need(new['file_count'] == 7045 and new['total_bytes'] == sum(row['bytes'] for row in new_rows.values()),
         'Exact updated source count and bytes')
    old_master = base / 'R/research/complete-clean-reproduction-v1/reproduce_research_v3.py'
    expected = old_master.read_bytes()
    replacements = [(b"B/'foundation_v2.py'", b"B/'foundation_v3.py'", 1),
        (b"self.python(h/'finalize_one_context.py',", b"self.python(h/'finalize_one_context_v3.py',", 1),
        (b"wall=172800", b"wall=86400", 2),
        (b"interfaces/'build_exporter_v2.py'", b"interfaces/'build_exporter_v3.py'", 1),
        (b"interfaces/'build-v2'", b"interfaces/'build-v3'", 1),
        (b"interfaces/'export_context_v4.py'", b"interfaces/'export_context_v5.py'", 2)]
    for before, after, count in replacements:
        need(expected.count(before) == count, 'Exact approved master replacement population')
        expected = expected.replace(before, after)
    def without_exact_method(source):
        lines = source.splitlines(keepends=True)
        tree = ast.parse(source)
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'Research')
        method = next(node for node in cls.body if isinstance(node, ast.FunctionDef)
                      and node.name == 'exact_network_types')
        return b''.join(lines[:method.lineno-1] + lines[method.end_lineno:])
    need(without_exact_method((payload / MASTER).read_bytes()) == without_exact_method(expected),
         'Only approved controller changes and the reviewed complete expected-view method')
    prefix = 'R/research/complete-clean-reproduction-v1/'
    original_foundation = (base / (prefix + 'foundation_v2.py')).read_bytes()
    need(original_foundation.count(b'wall=172800') == 2 and
         (payload / (prefix + 'foundation_v3.py')).read_bytes() ==
         original_foundation.replace(b'wall=172800', b'wall=86400'),
         'Exactly two foundation wall corrections')
    original_bootstrap = (base / (prefix + 'bootstrap_public_v1.py')).read_bytes()
    need(original_bootstrap.count(b'wall=172800') == 1 and
         (payload / (prefix + 'bootstrap_public_v2.py')).read_bytes() ==
         original_bootstrap.replace(b"B/'foundation_v2.py'", b"B/'foundation_v3.py'").replace(
             b'wall=172800', b'wall=86400'), 'Exact bootstrap import and wall corrections')
    if args.check_only:
        need(args.out is None, 'Input-only overlay check creates no output')
        print('PASS_OVERLAY_INPUTS_ONLY_NO_EXECUTION')
        return
    need(args.out is not None, 'Fresh derived packet output required')
    out = args.out.resolve()
    need(not out.exists() and not out.is_relative_to(base) and not base.is_relative_to(out)
         and not out.is_relative_to(HERE) and not HERE.is_relative_to(out),
         'Fresh disjoint derived packet')
    out.mkdir(parents=True)
    for row in old['files']:
        if row['path'] == 'README.md':
            continue
        source, target = base / row['path'], out / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.link(source, target)
        except OSError:
            shutil.copyfile(source, target)
    for row in patch['files']:
        f.regular_copy(payload / row['path'], out / row['path'])
    accepted, _ = f.packet_check(out)
    need(len(accepted['files']) == 7045, 'Actual derived packet complete input verification')
    need(sha(base / 'INPUT_MANIFEST.json') == patch['base_input_manifest_sha256'],
         'Original packet manifest remains unchanged')
    receipt = dict(status='PASS_DERIVED_V7_PACKET_ALL7045_SOURCE_INPUTS_NOT_PROOF_EXECUTION',
        base_input_manifest_sha256=patch['base_input_manifest_sha256'],
        new_input_manifest_sha256=sha(out / 'INPUT_MANIFEST.json'),
        overlay_manifest_sha256=PATCH_SHA, installer_sha256=sha(Path(__file__)),
        source_inputs=7045, preserved_non_README_input_rows=7037,
        mathematical_source_algorithm_parameter_or_assumption_changed=False,
        whole_monolithic_default_executed=False,
        qualification='Fresh source packet only. The old archive and extracted packet are preserved. '
        'Actual scientific component proofs and controls have separate execution evidence.')
    f.atomic(out / 'OVERLAY_RECEIPT.json', receipt)
    print(receipt['status'])


if __name__ == '__main__':
    main()
