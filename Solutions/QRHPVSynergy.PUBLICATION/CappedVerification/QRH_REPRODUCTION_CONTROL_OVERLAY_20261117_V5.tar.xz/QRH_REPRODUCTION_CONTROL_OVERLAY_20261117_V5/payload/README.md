# Reproduce the source-first ANT research

This is a preparation snapshot of the integrated reproduction program. The
source-built research/context/network acceptance receipts remain separate until
their running verification stages finish. The new monolithic default has not
been executed as another uninterrupted full run.

The package contains the published original completion archive as a pinned nested
dependency, the 3,908 research source additions and three final auditors, all
physical include payloads, the basis source generators, native numerical
workloads, four separate scientific contexts, ten graph-proof adapters and the
separate five-theorem algebra supplement and two additional basis-read modules.
It supplies no application object bank.
The original algorithms, mathematical inputs and historical outcomes stay fixed.

## Clean prerequisites

Use Linux amd64, user-systemd and the same namespace functionality used by the
recorded runs. For this complete high-resource route, at least 1 TiB RAM must be
genuinely available and at least 1 TiB disk independently free. The scripts retain
the 300 GiB aggregate memory/scratch and 64 CPU policy and adequate host reserves.
Matching GCC11/libstdc++/glibc development packages and pinned system-tool hashes
are required by the supplied native input manifests. No host setting is changed.
Use a fresh extracted package; do not overlap independent full reproductions on
the same host. Outputs remain inside this experiment-owned tree.

From the extracted package directory, provision public generic dependencies:

```sh
python3 -I -B R/research/complete-clean-reproduction-v1/bootstrap_public_v2.py \
  --packet "$PWD" --out "$PWD/R/work/public-bootstrap"
```

This uses the unchanged official-toolchain/public-dependency bootstrap from the
nested original archive. It provisions the pinned compiler and eight public
dependency commits. It never supplies cached application proofs.

Check the integrated inputs without running numerical or proof phases:

```sh
python3 -I -B R/research/complete-clean-reproduction-v1/reproduce_research_v7.py \
  --packet "$PWD" \
  --environment "$PWD/R/work/public-bootstrap/environment/ENVIRONMENT.json" \
  --check-inputs
```

Run the controller directly:

```sh
python3 -I -B R/research/complete-clean-reproduction-v1/reproduce_research_v7.py \
  --packet "$PWD" \
  --environment "$PWD/R/work/public-bootstrap/environment/ENVIRONMENT.json" \
  --out "$PWD/R/work/full-clean" --jobs 8
```

The controller creates and records each guarded phase itself. Do not wrap the
whole controller in a small memory scope: each large proof phase must be a
separate resource scope. Every output must be fresh; a failed stage retains its
files and cannot produce final acceptance.

## What the default does

1. Checks and extracts the published original archive, provisions only run-local
   generic paths, reruns the original numerical workloads, regenerates all 4,373
   numerical Lean source files and compiles the exact 10,970-source original
   graph from an empty application bank.
2. Builds the 69-module data-free basis frontend plus its one proposal utility
   from source. Its `#eval` recomputes all 272 fixed numerical rows. These are
   explicitly **untrusted witness-generation data**, with no proof authority.
   Only JSON spacing is normalized. The fresh values regenerate all 351 basis
   Lean/C sources; the original and adapted actual C executables are rerun and
   their complete 512 bytes compared. Of those 351 component modules, 349 belong
   to the canonical dependency graph. One generic helper differs only by four
   trailing diagnostic commands: a fresh copy removes exactly those commands and
   must match the pinned canonical source hash. The two additional read modules
   remain separate until the final append. All raw regenerated sources remain
   available; no mathematical declaration or frozen source is changed.
3. Reruns the actual point, mass, first-moment and unpaired-vector C programs and
   checks every recorded point/prefix/output against the fixed numerical data.
4. Compiles the research additions using only the independently validated
   source-built original prefix, then compiles all three final source auditors.
   The ordinary-kernel proofs establish actual C source execution, interval
   correctness, same-output reads and the ANT conclusions. No untrusted proposal
   becomes a mathematical premise.
5. Builds each of the four scientific contexts separately. It freshly compiles
   the original scientific comparison sources, excluding conflicting `Main` and
   `Solution` modules and their reverse dependencies in a comparison-only view.
   It checks all public types and nonproof data against the actual fresh context
   objects, then checks the complete written-source inventory and source boundary.
6. Compiles the eight additional source modules proving ten graph conclusions,
   compares their exact types against separately loaded generated Challenge
   interfaces, then compiles a separate three-module/eight-root append: the two
   optional basis-read modules prove three identities and the pure algebra module
   proves five profile comparisons. These are not eight new discoveries.

The 283 written research rows include 250 source/generic propositions, 32
intentionally kernel-only baselines/helpers and one unchanged nonproof datum.
They are not 283 source-first program-verification theorems. Generated Challenge
`sorry` templates state interfaces; actual Solution proof closures must contain
only the standard three axioms and must not import those selected Challenges.

## Trust, evidence and cleanup

PV means actual C/C++ source to a verified execution model, mathematical
correctness and source-produced outputs consumed by the theorem. The `#eval`
proposer, Python generators, native observations, kernel-only challengers and
metadata comparators are labelled separately. The pinned Lean kernel, standard
axioms, generic compiler/ABI/runtime/I/O/OS/hardware contracts remain explicit.
The original C++ evaluator uses generic Lean core Nat/reference-count APIs; the
new fixed-point programs use Clang unsigned 512-bit arithmetic. Neither fact
makes an untrusted numerical generation result a proof premise.

Modeled accepted writes and source-state reads are distinct from native stdout
association and delivered bytes. No universal application-success, initial-state,
OS-pipe or hardware-memory-trace oracle is assumed. The basis program has no
explicit final flush; its accepted-byte proof and native observation remain
separate. Mathematical conclusions retain their declared analytic assumptions.
No optimality or PV-exclusive coefficient advantage is claimed.

Each phase records exact commands, source/data hashes, compiler/dependency pins,
resource scopes, stdout/stderr and receipts. A monolithic run may emit its final
receipt only after every phase passes. Local canonical Comparator/NanoDa and
official network registration are separate verdicts; this script fabricates
neither an official receipt nor a verified metadata status.

After a completed reproduction is checked, remove only verified-regenerable
raw numerical arrays, duplicate source-materialization directories and native
temporary binaries within its named output tree. Preserve accepted proofs,
original sources, minimal native outputs, exact receipts, manifests and the only
copy of any essential data. The publication contains checked generators in
place of permanent gigabytes of raw numerical arrays.

## Additive execution-control corrections

V7 uses the exact reviewed context finalizerV3 and source-preserving foundationV3.
Five explicit guard requests (two master, two foundation, one public bootstrap)
use the pinned resource launcher's existing maximum of86400seconds perphase
instead of its rejected172800second value. The pinned resource policy is unchanged.
V3 finalizer places fresh comparator outputs in the required interfaces subtree
and atomically publishes canonical readbacks only after all fifteen controls pass.
Original controllers, the234228-byte context-only overlay and the original
44MB archive remain preserved historical evidence. No mathematical source,
algorithm, numerical parameter, analytic assumption or proof statement changes.
The combined V7 full monolithic default remains unexecuted. Input/guard controls
and actual scientific component runs have separate receipts.

The active context metadata path builds ExportV3 through build_exporter_v3.py
and exports both roles with export_context_v5.py. It preserves public names and
all binder bases, scope numbers and expression data; it maps only the approved
compiler-private/binder module origins ContextH02.Main to Main and
ContextPublicMoment.Solution/ContextPublicVector.Solution to Solution. Scientific
Lean statements and proofs are unchanged. Context component controls remain
separate execution evidence; the complete V7 default is still unexecuted.

The exact network-interface phase derives a separate complete14889-object view
from the validated actual source-built readback, checking source/object pins and
collisions before compiling the three expected Challenge interfaces. This avoids
partial IEANTN prefixes shadowing the accepted dependency objects. Actual proof
namespace and source graph remain unchanged. Late proofs use the actual network
parent and never the expected-interface view.

The exact-interface marker readback uses the resource child stdout.txt file,
which contains the actual ten comparison results; the phase wrapper stdout
contains only resource-summary JSON. The completed actual ten-comparison run
and the strict corrected readback remain separate auditable component records.
