#!/usr/bin/env python3
"""Exercise real relocated overlay/master CLIs under normal, -O and -OO Python."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
MASTER = 'R/research/complete-clean-reproduction-v1/reproduce_research_v7.py'
FINALIZER = ('R/research/source-repaired-closure-v1/numerics-final-contexts-v1/'
             'finalize_one_context_v3.py')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--environment', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    need(not out.exists() and not out.is_relative_to(HERE) and not HERE.is_relative_to(out),
         'Fresh disjoint controls output')
    out.mkdir(parents=True)
    relocated = out / 'relocated-overlay'
    shutil.copytree(HERE, relocated)
    rows = []
    start = time.monotonic()
    base_pin = sha(args.base / 'INPUT_MANIFEST.json')

    def run(label, mode, flags, script, argv, expected=None):
        command = [sys.executable, '-I', '-B', *flags, str(script), *map(str, argv)]
        result = subprocess.run(command, capture_output=True, timeout=180)
        (out / (label + '.stdout')).write_bytes(result.stdout)
        (out / (label + '.stderr')).write_bytes(result.stderr)
        if expected is None:
            need(result.returncode == 0, 'Actual successful CLI ' + label)
        else:
            need(result.returncode == 1 and result.stdout == b'' and
                 result.stderr.decode().splitlines()[-1] == 'ValueError: ' + expected,
                 'Exact intended CLI rejection ' + label)
        rows.append(dict(label=label, mode=mode, command=command, exit_code=result.returncode,
                         exact_negative_reason=expected,
                         stdout_sha256=sha(out / (label + '.stdout')),
                         stderr_sha256=sha(out / (label + '.stderr'))))

    for mode, flags in [(0, []), (1, ['-O']), (2, ['-OO'])]:
        prefix = str(mode)
        packet = out / ('packet-' + prefix)
        installer = relocated / 'apply_overlay_v5.py'
        run(prefix + '-overlay-inputs', mode, flags, installer,
            ['--base', args.base, '--check-only'])
        run(prefix + '-overlay-apply', mode, flags, installer,
            ['--base', args.base, '--out', packet])
        need((packet / 'OVERLAY_RECEIPT.json').is_file(), 'Actual derived packet receipt')
        master = packet / MASTER
        arguments = ['--packet', packet, '--environment', args.environment, '--check-inputs']
        run(prefix + '-master-inputs', mode, flags, master, arguments)
        bootstrap = packet / 'R/research/complete-clean-reproduction-v1/bootstrap_public_v2.py'
        bootstrap_out = packet / 'R/work/input-only-bootstrap-not-created'
        run(prefix + '-bootstrap-inputs', mode, flags, bootstrap,
            ['--packet', packet, '--out', bootstrap_out, '--check-inputs'])
        need(not bootstrap_out.exists(), 'Bootstrap input check performs no dependency download')

        run(prefix + '-finalizer-portable-help', mode, flags, packet / FINALIZER, ['--help'])
        finalizer = packet / FINALIZER
        held = finalizer.with_suffix('.held')
        finalizer.replace(held)
        try:
            run(prefix + '-missing-finalizer', mode, flags, master, arguments,
                'source/tool/payload identity ' + FINALIZER)
        finally:
            held.replace(finalizer)
        original_master = master.read_bytes()
        master.write_bytes(original_master + b'\n# deliberate source-pin rejection control\n')
        try:
            run(prefix + '-changed-master', mode, flags, master, arguments,
                'source/tool/payload identity ' + MASTER)
        finally:
            master.write_bytes(original_master)
        forbidden = out / ('must-not-exist-' + prefix)
        run(prefix + '-input-output-conflict', mode, flags, installer,
            ['--base', args.base, '--out', forbidden, '--check-only'],
            'Input-only overlay check creates no output')
        need(not forbidden.exists(), 'Negative creates no derived packet')
        patch = relocated / 'PATCH_MANIFEST.json'
        original_patch = patch.read_bytes()
        patch.write_bytes(original_patch + b' ')
        try:
            run(prefix + '-changed-overlay', mode, flags, installer,
                ['--base', args.base, '--check-only'], 'Exact frozen overlay manifest')
        finally:
            patch.write_bytes(original_patch)
        nested_packet = relocated / ('must-not-nest-packet-' + prefix)
        run(prefix + '-nested-packet-output', mode, flags, installer,
            ['--base', args.base, '--out', nested_packet], 'Fresh disjoint derived packet')
        need(not nested_packet.exists(), 'No nested packet output')
        nested_controls = HERE / ('must-not-nest-controls-' + prefix)
        run(prefix + '-nested-controls-output', mode, flags, Path(__file__),
            ['--base', args.base, '--environment', args.environment, '--out', nested_controls],
            'Fresh disjoint controls output')
        need(not nested_controls.exists(), 'No nested controls output')
        run(prefix + '-master-restored-inputs', mode, flags, master, arguments)
    need(len(rows) == 36, 'Every intended actual optimized CLI route')
    need(sha(args.base / 'INPUT_MANIFEST.json') == base_pin, 'Original V7 packet preserved')
    result = dict(status='PASS36_ACTUAL_PORTABLE_OVERLAY_MASTER_CLIS_NORMAL_O_OO_NOT_PROOF_EXECUTION',
        seconds=time.monotonic() - start, records=rows, original_manifest_sha256=base_pin,
        installer_sha256=sha(relocated / 'apply_overlay_v5.py'),
        controls_sha256=sha(Path(__file__)), whole_monolithic_default_executed=False,
        new_component_proofs_executed=False,
        qualification='Actual derived-packet construction and all7045 input checks in three Python '
        'optimization modes. Each negative reaches its named source/dispatch guard. The actual '
        'fifteen scientific context readback controls are separate component evidence.')
    temporary = out / 'RECEIPT.json.pending'
    temporary.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    temporary.replace(out / 'RECEIPT.json')
    print(result['status'])


if __name__ == '__main__':
    main()
