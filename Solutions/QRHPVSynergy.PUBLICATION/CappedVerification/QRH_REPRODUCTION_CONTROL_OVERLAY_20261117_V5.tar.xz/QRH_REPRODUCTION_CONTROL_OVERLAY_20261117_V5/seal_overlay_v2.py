#!/usr/bin/env python3
"""Rebuild and verify a deterministic archive of only the frozen overlay allowlist."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import math
import tarfile

HERE = Path(__file__).resolve().parent
TOP = 'QRH_REPRODUCTION_CONTROL_OVERLAY_20261117_V5'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    def number(text):
        value = float(text)
        need(math.isfinite(value), 'Nonfinite JSON number')
        return value
    def bad(text):
        raise ValueError('Nonfinite JSON constant ' + text)
    return json.loads(path.read_text(), object_pairs_hook=pairs,
                      parse_float=number, parse_constant=bad)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    receipt = out.with_suffix(out.suffix + '.RECEIPT.json')
    need(not out.exists() and not receipt.exists() and not out.is_relative_to(HERE),
         'Fresh archive and receipt outside the source root')
    lock = read(HERE / 'ALLOWLIST.json')
    rows = lock['files']
    names = [row['path'] for row in rows]
    need(len(names) == len(set(names)) and names == sorted(names), 'Unique sorted explicit allowlist')
    for row in rows:
        path = Path(row['path'])
        source = HERE / path
        need(not path.is_absolute() and '..' not in path.parts and source.is_file()
             and not source.is_symlink() and source.stat().st_size == row['bytes']
             and sha(source.read_bytes()) == row['sha256'], 'Exact allowlisted source ' + str(path))
        need(source.suffix not in {'.olean', '.ilean', '.o', '.so', '.a', '.pyc'}, 'No object or cache input')
    selected = [*names, 'ALLOWLIST.json']
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, 'w:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
        for name in sorted(selected):
            data = (HERE / name).read_bytes()
            info = tarfile.TarInfo(TOP + '/' + name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(data))
    actual = []
    with tarfile.open(out, 'r:xz') as archive:
        entries = archive.getmembers()
        need(len(entries) == len(selected) and
             {row.name for row in entries} == {TOP + '/' + name for name in selected},
             'Exact archive member population')
        for row in entries:
            need(row.isfile(), 'Only regular archive members')
            name = str(Path(row.name).relative_to(TOP))
            data = archive.extractfile(row).read()
            need(data == (HERE / name).read_bytes(), 'Every archived byte matches its source')
            actual.append(dict(path=name, bytes=len(data), sha256=sha(data)))
    result = dict(status='PASS_DETERMINISTIC_SOURCE_OVERLAY_ARCHIVE_ALL_MEMBERS_BYTE_VERIFIED',
        archive_sha256=sha(out.read_bytes()), archive_bytes=out.stat().st_size,
        members=actual, allowlist_sha256=sha((HERE / 'ALLOWLIST.json').read_bytes()),
        sealer_sha256=sha(Path(__file__).read_bytes()), application_objects_included=False,
        whole_monolithic_default_executed=False)
    receipt.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: result[key] for key in ['status', 'archive_sha256', 'archive_bytes']}))


if __name__ == '__main__':
    main()
