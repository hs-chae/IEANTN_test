# Apply the combined reproduction control correction

Keep the original 44,182,004-byte archive and its extracted directory. This
overlay creates a separate source packet; it does not overwrite either one.

From this overlay directory, check the extracted original packet:

```sh
python3 -I -B apply_overlay_v5.py --base /absolute/original-extracted-packet --check-only
```

Create a fresh corrected packet beside it:

```sh
python3 -I -B apply_overlay_v5.py --base /absolute/original-extracted-packet \
  --out /absolute/fresh-corrected-packet
```

Use the corrected packet's `README.md` for the public dependency bootstrap and
the `reproduce_research_v7.py --check-inputs` and full-run commands. The overlay
retains all 7,037 existing non-README input descriptors, updates the instructions,
and adds exactly seven reviewed control sources. The active masterV7 selects the reviewed finalizerV3 and metadata exporterV3,
uses the matching builder/exportdriver and foundationV3, and requests the
pinned guard's supported86400seconds perphase. The finalizer's mathematical inputs and CLI remain
unchanged; it uses fresh comparison files in the required directory and writes
the two final readback receipts atomically after all fifteen controls pass.

The V7 monolithic default has not been run. Overlay/input checks and executed
scientific components have separate receipts. No mathematical source, numerical
algorithm, parameter, analytic assumption, or historical result changes.

To repeat the overlay's portable CLI controls using an existing pinned public
environment, choose a fresh output directory:

```sh
python3 -I -B check_overlay_controls_v7.py \
  --base /absolute/original-extracted-packet \
  --environment /absolute/public-environment.json --out /absolute/fresh-controls
```

This runs the actual installer and relocated master in normal, `-O`, and `-OO`
Python, including the exact intended source/manifest rejection controls. It does
not execute a new scientific proof or native workload.

Choose output directories outside both the original packet and this overlay.
Both V2 helpers reject an output inside their own source directory. Historical
V1 helpers and their passing disjoint-output controls remain preserved separately.

The seven additions are masterV7, foundationV3, bootstrap_publicV2, finalizerV3,
ExportV3.lean, build_exporterV3 and export_contextV7. Existing scientific Lean/C
sources and all14analytic assumptions stay exact. Five literal wall requests
change from the rejected172800seconds to the existing86400second guard maximum.
The bootstrap commands in the corrected packet select bootstrap_public_v2.py.

The36actual portable CLI controls include corrected packet construction, full
7045-input validation, bootstrap input checks, intended pin/output-placement
rejections in normal/O/OO Python; the six actual wall-guard requests have separately recorded component evidence. The
accepted wall canaries execute only /usr/bin/true with1GiB; this is separate
from all scientific proof and numerical execution. Earlier context-only overlay
V2 is preserved as a historical snapshot; the combined V3 overlay is the active
recipe correction.

Run the controls script directly: it creates and records its own guarded canary
phases. An enclosing small resource scope would be counted as the available host
memory by the existing resource guard and would reject its required host reserve.

MasterV7 also supplies the tested complete expected-object view repair, preserving
the accepted scientific namespace and source graph. Its late proof append uses
the actual source-built network parent. The complete V7 monolithic default remains
unexecuted. The standalone archive check only applies this overlay and checks
all7045source inputs; it does not run new scientific proofs or numerical workloads.

The final active controller is MasterV7. Its last correction reads the ten
interface markers from the recorded resource child stdout.txt. All ten actual
separate-environment type/universe comparisons completed with exit0 before
that strict readback was repaired. The complete monolithic route remains
unexecuted; accepted scientific components have separate source-bound receipts.
