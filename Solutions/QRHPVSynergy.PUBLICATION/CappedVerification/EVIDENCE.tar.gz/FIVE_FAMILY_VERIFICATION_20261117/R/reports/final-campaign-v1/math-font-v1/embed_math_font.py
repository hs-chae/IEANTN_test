#!/usr/bin/env python3
"""Presentation-only offline MATH font embedding; exact MathML bytes preserved."""
from pathlib import Path
import argparse
import base64
import hashlib
import html
import json
import re

HERE = Path(__file__).resolve().parent


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def math_blocks(source):
    return re.findall(r"<math\b[^>]*>.*?</math>", source, re.S)


def embed(source, font_path=None, license_path=None):
    font_path = Path(font_path) if font_path else HERE / "subset-v2/IEANTNReportMath.woff2"
    license_path = Path(license_path) if license_path else HERE / "OFL.txt"
    need(sha_bytes(font_path.read_bytes()) == "49f670ea3833348af817a92a884c288611a20e3e18ddde0853776f991ccd2289",
         "Exact reviewed renamed MATH font subset")
    need(sha_bytes(license_path.read_bytes()) == "0c8825913b60d858aacdb33c4ca6660a7d64b0d6464702efbb19313f5765861a",
         "Exact upstream font license")
    need('id="ieantn-offline-math-font"' not in source, "Single explicit font embedding")
    encoded = base64.b64encode(font_path.read_bytes()).decode("ascii")
    css = '''<style id="ieantn-offline-math-font">
@font-face{font-family:'IEANTN Report Math';src:url(data:font/woff2;base64,'''+encoded+''') format('woff2');font-style:normal;font-weight:400;font-display:block}
math,math *{font-family:'IEANTN Report Math','STIX Two Math','Cambria Math','DejaVu Serif',serif!important}
math[display="block"]{min-width:max-content;width:max-content;max-width:none;margin-inline:auto}
.math-font-license{font:14px/1.45 system-ui;margin-top:2rem;overflow-wrap:anywhere}
.math-font-license pre{white-space:pre-wrap;font:12px/1.4 ui-monospace,monospace}
</style>'''
    license_text = html.escape(license_path.read_text())
    license_note = '''<details class="math-font-license" id="math-font-license"><summary>Offline math font and license</summary>
<p>IEANTN Report Math is a renamed subset of STIX Two Math, pinned to upstream commit
<code>744a22a4dd626cd14d75728aef34fc8ad7c85db0</code>.
Its OpenType MATH table and mathematical italic Greek glyphs are embedded in this file.
The font changes presentation only. <a href="https://github.com/stipub/stixfonts/tree/744a22a4dd626cd14d75728aef34fc8ad7c85db0">Pinned upstream source</a>.</p><pre>'''+license_text+'''</pre></details>'''
    if "</head>" in source:
        transformed = source.replace("</head>", css+"\n</head>", 1)
    elif "</style>" in source:
        transformed = source.replace("</style>", "</style>\n"+css, 1)
    else:
        match = re.match(r"(?i)<!doctype[^>]*>", source)
        position = match.end() if match else 0
        transformed = source[:position]+css+source[position:]
    if "</body>" in transformed:
        transformed = transformed.replace("</body>", license_note+"\n</body>", 1)
    else:
        transformed += "\n"+license_note
    need(math_blocks(source) == math_blocks(transformed), "Every original MathML formula remains byte-exact")
    return transformed


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    need(not a.out.exists(), "Fresh additive presentation copy")
    source = a.input.read_text()
    transformed = embed(source)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(transformed)
    receipt = dict(status="PASS_ADDITIVE_OFFLINE_FONT_EMBEDDING_FORMULAS_BYTE_EXACT",
        original_sha256=sha_bytes(a.input.read_bytes()), transformed_sha256=sha_bytes(a.out.read_bytes()),
        math_blocks=len(math_blocks(source)), mathml_sha256=[sha_bytes(x.encode()) for x in math_blocks(source)],
        font_sha256=sha_bytes((HERE/"subset-v2/IEANTNReportMath.woff2").read_bytes()),
        transformer_sha256=sha_bytes(Path(__file__).read_bytes()), qualification="Presentation-only; actual browser/glyph/readability acceptance remains separate.")
    a.out.with_name(a.out.name+".font-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(receipt["status"],len(math_blocks(source)))


if __name__ == "__main__":
    main()
