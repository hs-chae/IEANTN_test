import ContextInterface.ExportV2
import TaskDefinitions
import Formal
import IEANTN.Vocabulary.PrimeReciprocal
import Tail
import SynergyHeightC.ReciprocalRead300
import SynergyHeightC.ReciprocalProgram300
open Lean Elab
set_option maxHeartbeats 0
set_option maxRecDepth 300000
run_elab do
 ContextInterface.ExportV2.exportModules [`TaskDefinitions,`Formal,`IEANTN.Vocabulary.PrimeReciprocal,`Tail,`SynergyHeightC.ReciprocalRead300,`SynergyHeightC.ReciprocalProgram300] "/ryu/hyunsik/playground/independence/codex/ivy/ieantn-qrh-pv-synergy-20261114/research/source-repaired-closure-v1/numerics-final-contexts-v1/interfaces/source-old-H01V1-v4/expressions.jsonl"
