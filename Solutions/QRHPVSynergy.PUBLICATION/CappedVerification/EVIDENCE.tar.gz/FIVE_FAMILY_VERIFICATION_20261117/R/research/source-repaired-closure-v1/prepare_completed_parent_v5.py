"""Flatten the fully checked V5 research source-cold parent into an explicit append prefix.

The unchanged engine checks the resulting prefix again. No new compilation or
proof acceptance is asserted here. Every object and log is a hard link to an
actual, hash-checked parent output; the original runs are never modified.
"""
import argparse
import copy
import importlib.util
import json
import os
from pathlib import Path

Q = Path(__file__).resolve().parent
B = Q
# Additive V5: accept only the actual research namespace launcher and engine.
spec = importlib.util.spec_from_file_location('pinned_chain', Q / 'engine-v5/engine_v3.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def prepare(base_task, task, environment, parent, seed_checkpoint, seed_root, out):
    m.need(not out.exists(), 'fresh experiment-owned completed-parent view')
    base_lock, env, base_index = m.source_check(base_task, environment)
    new_lock, new_env, new_index = m.source_check(task, environment)
    m.need(env == new_env, 'same pinned public compiler and libraries')
    for name, row in base_index.items():
        m.need(name in new_index and new_index[name] == row,
               'append preserves the complete parent source row: ' + name)
    new_payloads = {row['path']: row for row in new_lock['payloads']}
    for row in base_lock['payloads']:
        m.need(new_payloads.get(row['path']) == row,
               'append preserves the complete parent include payload row: ' + row['path'])
    receipt_path = parent / 'data/run/RECEIPT.json'
    outer_path = parent / 'RECEIPT.json'
    parent_hash, outer_hash = m.sha(receipt_path), m.sha(outer_path)
    receipt, outer = m.read(receipt_path), m.read(outer_path)
    m.need(receipt['status'] in {
        'PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS',
        'PASS_EMPTY_APPLICATION_BANK_SOURCE_COLD_GRAPH'}, 'completed parent compiler graph')
    m.need(receipt['source_lock_sha256'] == m.sha(base_task / 'SOURCE_LOCK.json') and
           receipt['environment_sha256'] == m.sha(environment), 'parent source and environment')
    m.need(receipt['source_modules'] == len(base_index), 'complete parent module count')
    audits = receipt['audits']
    m.need(len(audits) == len(base_lock['roots']) and
           {r['name'] for r in audits} == set(base_lock['roots']) and
           all(r['type_repr'] and set(r['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}
               for r in audits), 'all actual parent typed Std3 root audits')
    m.need(outer['status'] == 'PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE' and
           outer['environment_sha256'] == m.sha(environment) and
           outer['launcher_sha256'] == m.sha(B / 'launch_namespace_v5.py') and
           receipt['engine_sha256'] == m.sha(B / 'engine-v5/engine_v3.py'),
           'successful pinned namespace/controller receipts')
    probe = m.read(parent / 'data/NAMESPACE_PROBE.json')
    m.need(probe['status'] == 'PASS_DISTINCT_NAMESPACES_AND_RESTRICTED_PROOF_INPUTS' and
           probe['host_workspace_absent'] is True, 'actual parent namespace probe')
    request = m.read(parent / 'REQUEST.json')
    inputs = m.read(parent / 'INPUTS.json')
    m.need(outer['namespace_probe'] == probe and outer['command'] == request['command'] and
           outer['source_manifest_sha256'] == m.sha(parent / 'INPUTS.json') and
           outer['input_files'] == len(inputs), 'parent namespace/request/input-manifest association')
    m.need(probe['research_git_history_absent'] is True and
           set(probe['namespaces']) == set(request['parent_namespaces']) == {'pid', 'mnt', 'net'} and
           all(probe['namespaces'][k] != request['parent_namespaces'][k] for k in ['pid', 'mnt', 'net']),
           'actual distinct parent namespace identities')
    pins = request['compiler_pins']
    m.need(probe['compiler_pins'] == pins and len({x['path'] for x in pins}) == len(pins) and
           any(x['path'] == env['compiler'] for x in pins) and
           all(m.sha(Path(x['path'])) == x['sha256'] for x in pins),
           'actual pinned compiler/kernel sentinels bound to namespace probe')
    m.need(outer['continuation_engine_source_pins'] == {
        'engine_v3.py': m.sha(B / 'engine-v5/engine_v3.py'),
        'small_module_map_policy.c': m.sha(B / 'engine-v5/small_module_map_policy.c')},
        'exact namespace engine input pins')
    m.need(len({x['path'] for x in inputs}) == len(inputs), 'unique actual parent input paths')
    input_index = {x['path']: x['sha256'] for x in inputs}
    for row in inputs:
        m.need(m.sha(base_task / m.relative(row['path'])) == row['sha256'],
               'actual parent mounted input bytes')
    for row in base_lock['sources'] + base_lock['payloads']:
        m.need(input_index.get(row['path']) == row['sha256'], 'all parent source/payload mount records')
    m.need(input_index.get('SOURCE_LOCK.json') == m.sha(base_task / 'SOURCE_LOCK.json'),
           'parent mounted source lock')
    if seed_checkpoint is None:
        m.need(seed_root is None and receipt['prior_modules'] == 0, 'no unstated parent seeds')
        seeds = {}
    else:
        m.need(seed_root is not None, 'explicit prior origin')
        seeds = m.validate_prior(m.read(seed_checkpoint), seed_root, base_task, environment, base_index)
    expected_seed_inputs = [dict(module=name,
        path=str(seed_root / row['files']['object']['path']),
        sha256=row['files']['object']['sha256']) for name, row in sorted(seeds.items())]
    actual_seed_inputs = request['application_object_inputs']
    m.need(len({x['module'] for x in actual_seed_inputs}) == len(actual_seed_inputs) and
           sorted(actual_seed_inputs, key=lambda x: x['module']) == expected_seed_inputs and
           outer['application_object_inputs'] == actual_seed_inputs,
           'actual namespace object inputs exactly match declared completed-parent seed records')
    expected_cp = m.sha(seed_checkpoint) if seed_checkpoint is not None else None
    m.need(request['prior_checkpoint_sha256'] == outer['prior_checkpoint_sha256'] == expected_cp,
           'exact actual parent namespace seed checkpoint')
    m.need((parent / 'data/run/Audit.lean').read_text() == m.audit_text(base_lock),
           'exact generated parent root audit source')
    ar = receipt['audit_record']
    m.need(ar['exit_code'] == 0 and ar['command'] ==
           [env['compiler'], '-j1', '-R', '/out/run', '/out/run/Audit.lean'],
           'actual complete parent audit command')
    for f in ar['files'].values():
        m.need(m.sha(parent / 'data/run' / m.relative(f['path'])) == f['sha256'],
               'actual parent audit evidence hash')
    audit_stdout = (parent / 'data/run' / ar['files']['stdout']['path']).read_text()
    m.need([m.parse(line.split('BODY_AUDIT ', 1)[1]) for line in audit_stdout.splitlines()
            if 'BODY_AUDIT ' in line] == audits, 'actual compiler typed audit output')
    fresh = receipt['records']
    fresh_by_name = {row['module']: row for row in fresh}
    m.need(len(fresh) == receipt['new_compilations'] and
           len({r['module'] for r in fresh}) == len(fresh), 'unique actual parent compilations')
    m.need(len(seeds) == receipt['prior_modules'] and
           set(seeds) == set(receipt['application_object_inputs']), 'exact explicit seed set')
    m.need(set(seeds).isdisjoint(r['module'] for r in fresh), 'disjoint parent components')
    records = {n: (copy.deepcopy(row), seed_root) for n, row in seeds.items()}
    records.update({row['module']: (copy.deepcopy(row), parent / 'data/run') for row in fresh})
    m.need(set(records) == set(base_index), 'every parent source actually compiled')
    all_files = []
    for name, (row, origin) in records.items():
        source = base_index[name]
        m.need(row['exit_code'] == 0 and row['source_sha256'] == source['sha256'] and
               row['dependencies'] == source['imports'], 'actual parent source/exit/dependency ' + name)
        m.need(row['command'] == m.expected_command(env['compiler'], source, '/task', '/out/run'),
               'actual parent timed command ' + name)
        m.need(set(row['files']) == {'stdout', 'stderr', 'time', 'object'}, 'four evidence files')
        for kind, f in row['files'].items():
            path = origin / m.relative(f['path'])
            m.need(path.is_file() and m.sha(path) == f['sha256'], 'unchanged parent ' + kind + ' ' + name)
            if kind == 'object':
                rel = Path('data/run/objects') / Path(name.replace('.', '/')).with_suffix('.olean')
            else:
                rel = Path('data/run/logs') / (name + '.' + kind)
            all_files.append((path.resolve(strict=True), rel, f['sha256']))
            f['path'] = str(rel)
        # The original timed receipt is checked separately using its original path;
        # normalized paths above refer only to the future self-contained view.
        original = seeds[name] if name in seeds else fresh_by_name[name]
        text = (origin / m.relative(original['files']['time']['path'])).read_text()
        m.need(text.splitlines()[0] == '\tCommand being timed: "' + ' '.join(row['command']) + '"' and
               text.splitlines().count('\tExit status: 0') == 1, 'actual parent GNUtime command/exit')
    out.mkdir(parents=True)
    for source, rel, pin in all_files:
        dest = out / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        os.link(source, dest)
        m.need(dest.is_file() and not dest.is_symlink() and m.sha(dest) == pin,
               'self-contained regular hard-linked evidence')
    provenance = {}
    for label, path in [('PARENT_SOURCE_LOCK.json', base_task / 'SOURCE_LOCK.json'),
                        ('PARENT_RECEIPT.json', receipt_path), ('PARENT_NAMESPACE_RECEIPT.json', outer_path),
                        ('PARENT_NAMESPACE_PROBE.json', parent / 'data/NAMESPACE_PROBE.json'),
                        ('PARENT_REQUEST.json', parent / 'REQUEST.json'),
                        ('PARENT_INPUTS.json', parent / 'INPUTS.json'),
                        ('ENVIRONMENT.json', environment)]:
        dest = out / label
        dest.write_bytes(path.read_bytes())
        provenance[label] = m.sha(dest)
    if seed_checkpoint is not None:
        dest = out / 'PARENT_SEED_CHECKPOINT.json'
        dest.write_bytes(seed_checkpoint.read_bytes())
        provenance[dest.name] = m.sha(dest)
    cp = dict(schema='SOURCE_COLD_CHAIN_CHECKPOINT_V1',
              status='CONTROLLED_FRESH_PREFIX_NOT_FULL_ACCEPTANCE',
              origin_root=str(out), recorded_source_root='/task', recorded_output_root='/out/run',
              source_lock_sha256=m.sha(task / 'SOURCE_LOCK.json'), environment_sha256=m.sha(environment),
              provenance=provenance, records=[records[n][0] for n in sorted(records)],
              qualification='Complete actual isolated parent, now an explicitly validated prefix of the larger '
              'source graph. No new task acceptance, empty-bank claim or application PV claim. '
              'The append must compile every new source and repeat all final typed root audits.')
    cp_path = out / 'CHECKPOINT.json'
    m.atomic(cp_path, cp)
    m.need(m.sha(receipt_path) == parent_hash and m.sha(outer_path) == outer_hash,
           'parent receipts unchanged during view creation')
    m.validate_prior(cp, out, task, environment, new_index)
    result = dict(status='PASS_PREPARED_ACTUAL_COMPLETED_PARENT_AS_APPEND_PREFIX',
                  parent_modules=len(records), task_modules=len(new_index),
                  new_sources=len(new_index) - len(records), checkpoint_sha256=m.sha(cp_path),
                  script_sha256=m.sha(Path(__file__)), parent_receipt_sha256=parent_hash,
                  parent_namespace_sha256=outer_hash,
                  qualification=cp['qualification'])
    m.atomic(out / 'PREPARATION_RECEIPT.json', result)
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ['base-task', 'task', 'environment', 'parent', 'out']:
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--seed-checkpoint', type=Path)
    ap.add_argument('--seed-root', type=Path)
    a = ap.parse_args()
    values = {k: (v.resolve() if v is not None else None) for k, v in vars(a).items()}
    print(json.dumps(prepare(**values)))


if __name__ == '__main__':
    main()
