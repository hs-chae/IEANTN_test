"""Strict missing-selected-kernel-type evidence, never a source-row fallback."""
from pathlib import Path
import importlib.util
Q=Path(__file__).resolve().parent;R=Q.parents[1]
s=importlib.util.spec_from_file_location('kernel_type_engine',Q/'engine-v5/engine_v3.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
STD={'propext','Classical.choice','Quot.sound'}
def key(row):return row['file'],row['line'],row.get('original',row.get('name'))
def bank(inner):
 rows=[dict(module=r['module'],source_sha256=r['source_sha256'],object_sha256=r['files']['object']['sha256']) for r in inner['records']]
 m.need(len(rows)==len({r['module'] for r in rows})==14881,'Exact complete same-object common bank')
 return sorted(rows,key=lambda r:r['module'])
def read(namespace,current_inner,written_rows,sidecar_path=None):
 path=Path(sidecar_path) if sidecar_path is not None else R/'research/capped-final-verification-20261117/COMMON_KERNEL_TYPED_SIDECAR_V2.json'
 m.need(path.is_file(),'Required actual strict kernel typed sidecar exists')
 j=m.read(path)
 m.need(type(j['schema']) is int and j['schema']==1 and j['status']=='PASS_SEALED_ACTUAL_SAME_COMMON_OBJECTS_26_KERNEL_TYPED_ROOTS_30_WRITTEN_ROWS','Actual strict supplemental kernel typed sidecar')
 namespace=Path(namespace).resolve();supp=Path(j['supplemental_namespace']).resolve()
 m.need(Path(j['common_namespace']).resolve()==namespace and namespace==(Q/'final-common-audits-namespace-v1').resolve() and supp==(Q/'final-common-kernel-typed-namespace-v1').resolve(),'Supplemental readout belongs to exact same actual common namespace')
 m.need(j['source_modules']==j['prior_modules']==14881 and j['new_scientific_compilations']==0 and j['original_selected_typed_roots']==20544 and j['supplemental_selected_typed_roots']==20570 and j['same_complete_application_object_universe'] is True,'Metadata selections only, unchanged scientific object universe')
 m.need(j['actual_resource_exit_code']==0 and j['actual_resource_cgroup_drained'] is True and j['input_pins'],'Actual supplemental typed audit scope complete')
 required=[Q/'final-common-audits-task-v1/SOURCE_LOCK.json',Q/'final-common-kernel-roots-task-v1/SOURCE_LOCK.json',Q/'final-common-kernel-roots-task-v1/KERNEL_ROOT_PREPARATION.json',namespace/'RECEIPT.json',namespace/'data/run/RECEIPT.json',Q/'validated-common-kernel14881-prior-v1/CHECKPOINT.json',Q/'validated-common-kernel14881-prior-v1/PREPARATION_RECEIPT.json',supp/'RECEIPT.json',supp/'data/run/RECEIPT.json',supp/'data/run/Audit.lean',supp/'REQUEST.json',supp/'INPUTS.json',supp/'data/NAMESPACE_PROBE.json',Path(j['completed_namespace_view'])/'CHECKPOINT.json',Path(j['completed_namespace_view'])/'PREPARATION_RECEIPT.json',Q/'salvage_kernel_typed_readback_v1.py',Q/'salvage_kernel_typed_readback_v3.py',Path(j['original_postprocess_resource_scope']),R/'scoped/build/current52-public-environment-OO.json',Q/'engine-v5/engine_v3.py',Q/'prepare_completed_parent_v5.py',Q/'launch_namespace_v5.py',Q/'run_kernel_typed_sidecar_pipeline_v2.py',Path(j['bank_identity_path']),Path(j['actual_resource_scope'])]
 m.need(all(str(p) in j['input_pins'] for p in required),'Every essential actual typed audit child/source/object/namespace pin present')
 for name,digest in j['input_pins'].items():m.need(m.sha(Path(name))==digest,'Exact actual typed sidecar namespace/compiler/source/object evidence pin')
 m.need(j['bank_identity_sha256']==m.sha(Path(j['bank_identity_path'])),'Exact same common bank identity hash')
 scope=m.read(Path(j['actual_resource_scope']));cg=Path(scope['cgroup'])/'cgroup.procs'
 m.need(scope['exit_code']==0 and (not cg.exists() or not cg.read_text().strip()),'Actual supplemental typed audit resource exit0/drained')
 for sample in scope['samples']:
  ev=dict(line.split() for line in sample.get('memory.events','').splitlines())
  m.need(all(int(ev.get(k,'0'))==0 for k in ['oom','oom_kill']),'No sampled supplemental typed audit OOM event')
 old=m.read(Q/'final-common-audits-task-v1/SOURCE_LOCK.json');new=m.read(Q/'final-common-kernel-roots-task-v1/SOURCE_LOCK.json')
 m.need(m.sha(Q/'final-common-kernel-roots-task-v1/SOURCE_LOCK.json')=='6eca9e821829496900e8c64ee40b63497ca0bc1c0445b638a77dccc1f46038bb' and new['sources']==old['sources'] and new['payloads']==old['payloads'] and new['root_modules']==old['root_modules'],'No scientific source/payload/root-module changes for typed readout')
 actual=m.read(supp/'data/run/RECEIPT.json');outer=m.read(supp/'RECEIPT.json')
 m.need(outer['status']=='PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE' and actual['status']=='PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS' and actual['source_modules']==actual['prior_modules']==14881 and actual['new_compilations']==0 and actual['records']==[] and len(actual['application_object_inputs'])==14881 and len(actual['audits'])==20570,'Actual isolated existing RootAudit, zero scientific recompiles')
 envpath=R/'scoped/build/current52-public-environment-OO.json';env=m.read(envpath);compiler=Path(env['compiler'])
 m.need(actual['source_lock_sha256']==m.sha(Q/'final-common-kernel-roots-task-v1/SOURCE_LOCK.json') and actual['environment_sha256']==current_inner['environment_sha256']==m.sha(envpath) and actual['engine_sha256']==current_inner['engine_sha256']==m.sha(Q/'engine-v5/engine_v3.py') and m.sha(compiler)==new['compiler_sha256']==old['compiler_sha256'] and str(compiler) in j['input_pins'],'Actual source task/environment/engine/compiler bound to same objects')
 ar=actual['audit_record'];m.need(ar['exit_code']==0 and ar['files'],'Actual supplemental typed audit child exit0')
 for item in ar['files'].values():
  output=supp/'data/run'/m.relative(item['path'])
  m.need(str(output) in j['input_pins'] and m.sha(output)==item['sha256']==j['input_pins'][str(output)],'Every actual supplemental audit child stdout/stderr/time byte checked')
 for kind in ['stdout','stderr','time']:m.need(kind in ar['files'],'Every active supplemental audit output route present')
 raw=(supp/'data/run'/m.relative(ar['files']['stdout']['path'])).read_text()
 emitted=[m.parse(line.split('BODY_AUDIT ',1)[1]) for line in raw.splitlines() if 'BODY_AUDIT ' in line]
 m.need(emitted==actual['audits'] and [r['name'] for r in emitted]==new['roots'],'Actual supplemental typed stdout matches all selected typed receipt rows')
 prior=Q/'validated-common-kernel14881-prior-v1';completed=Path(j['completed_namespace_view'])
 before=m.read(prior/'CHECKPOINT.json');after=m.read(completed/'CHECKPOINT.json');prior_accept=m.read(prior/'PREPARATION_RECEIPT.json');after_accept=m.read(completed/'PREPARATION_RECEIPT.json')
 m.need(prior_accept['parent_receipt_sha256']==m.sha(namespace/'data/run/RECEIPT.json') and prior_accept['parent_namespace_sha256']==m.sha(namespace/'RECEIPT.json') and after_accept['parent_receipt_sha256']==m.sha(supp/'data/run/RECEIPT.json') and after_accept['parent_namespace_sha256']==m.sha(supp/'RECEIPT.json'),'Actual validated common and supplemental completed-parent source/object associations')
 expected_bank=bank(dict(records=before['records']));completed_bank=bank(dict(records=after['records']))
 m.need(completed_bank==expected_bank==m.read(Path(j['bank_identity_path'])),'Every14881 actual source/object identity equals the same accepted common bank')
 names={r['module'] for r in before['records']};fresh={r['module']:r for r in current_inner['records']}
 m.need(len(actual['application_object_inputs'])==len(set(actual['application_object_inputs']))==14881 and set(actual['application_object_inputs'])==names and len(current_inner['application_object_inputs'])==14878 and len(fresh)==3 and not set(current_inner['application_object_inputs']).intersection(fresh) and set(current_inner['application_object_inputs'])|set(fresh)==names,'Exact zero-fresh explicit seed schema and actual common14878plus3 origin')
 by_name={r['module']:r for r in before['records']}
 m.need(all(row['source_sha256']==by_name[name]['source_sha256'] and row['files']['object']['sha256']==by_name[name]['files']['object']['sha256'] for name,row in fresh.items()),'All actual three common fresh objects equal merged source bank')
 failed=m.read(Path(j['original_postprocess_resource_scope']));failed_cg=Path(failed['cgroup'])/'cgroup.procs'
 m.need(j['original_postprocess_resource_exit_code']==failed['exit_code']==1 and (not failed_cg.exists() or not failed_cg.read_text().strip()),'Original audit-enclosing postprocessing failure preserved separately')
 requested={key(r):r for r in written_rows};side_rows={key(r):r for r in j['written_kernel_rows']}
 m.need(len(written_rows)==len(requested)==len(j['written_kernel_rows'])==len(side_rows)==30 and set(requested)==set(side_rows),'Exact30 written preserved-kernel identities without collapse')
 names={r['root'] for r in written_rows};m.need(len(names)==26 and set(j['added_kernel_compiler_roots'])==names and set(new['roots'])==set(old['roots'])|names and len(new['roots'])==20570 and not names.intersection(old['roots']),'Only26 actual existing compiler roots supplement selected audit inventory')
 indexed={r['name']:r for r in actual['audits']};m.need(len(indexed)==20570 and set(j['typed_roots_by_name'])==names,'All26 exact actual typed root records present')
 for k,row in requested.items():
  side=side_rows[k];root=row['root']
  m.need(row['preserve_kernel_path'] is True and row['role']=='intentional_kernel_only_baseline_or_helper' and row['root']==row['original'] and side['root']==root and side['role']==row['role'] and side['preserve_kernel_path'] is True and side['exact_old_type_and_universes'] is True,'Supplement only unchanged kernel baselines, never source rows or other contexts')
  typed=j['typed_roots_by_name'][root]
  m.need(typed==indexed[root] and typed['name']==root and typed['type_repr'] and set(typed['axioms'])<=STD and set(row['axioms'])<=STD,'Exact same-object actual nonempty kernel type and Std3')
 return j['typed_roots_by_name'],dict(path=str(path),sha256=m.sha(path),namespace=str(supp),kind='ACTUAL_ISOLATED_SAME_OBJECT_BANK_SUPPLEMENTAL_KERNEL_TYPED_ROOT_AUDIT')
