/- Metadata-only data exporter: every shared CI/type and all computational values.
Root proof bodies and proof subterm bodies are omitted by compiler-typed Prop
classification; raw inferred proof propositions remain in separate DAG children.
Object SHA256 pins, rather than the diagnostic cached Expr hash, bind proof bodies. -/
/- Exact expression-DAG export for separate compiler contexts. Proof erasure is
used only for data comparison and only after Meta.isProof verifies the subterm.
The erased marker retains the full raw proposition type; Bool/Decidable tags,
all other data, binder annotations, constants and universe levels are retained. -/
import Lean
namespace ContextInterface.ExportV3
open Lean Meta
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 300000
private structure ExportState where
  raw : ExprStructMap Nat := {}
  erased : Std.HashMap (ExprStructEq×Nat) Nat := {}
  next : Nat := 0
private abbrev ExportM := StateT ExportState MetaM
private def node (handle : IO.FS.Handle) (mode tag : String) (data : Json)
    (children : Array Nat) : ExportM Nat := do
  let index:=(←get).next
  modify fun state=>{state with next:=index+1}
  liftM (handle.putStrLn (Json.mkObj [
    ("kind",toJson "node"),("id",toJson index),("mode",toJson mode),
    ("tag",toJson tag),("data",data),("children",toJson children)]).compress)
  return index
/- Exact compiler-private module-prefix relocation; public names are never rewritten. -/
private def moduleRelocations : List (Name × Name) :=
  [(`ContextH02.Main, `Main), (`ContextPublicMoment.Solution, `Solution),
   (`ContextPublicVector.Solution, `Solution)]
private partial def normalizeName (name : Name) : Name :=
  match moduleRelocations.find? (fun pair => name == mkPrivateNameCore pair.1 .anonymous) with
  | some pair => mkPrivateNameCore pair.2 .anonymous
  | none => match name with
    | .str parent text => .str (normalizeName parent) text
    | .num parent value => .num (normalizeName parent) value
    | .anonymous => .anonymous
private def named (name : Name) : Json := toJson (reprStr (normalizeName name))
/- Only binder hygiene origin modules are relocated. The unhygienic binder base,
all scope numbers, BinderInfo, constants, and all expression structure remain exact. -/
private def relocateBinderOrigin (origin : Name) : Name :=
  match moduleRelocations.find? (fun pair => origin == pair.1) with
  | some pair => pair.2
  | none => origin
private partial def splitOriginStrings (name : Name) (parts : List String) : Name × List String :=
  match name with
  | .str parent text => splitOriginStrings parent (text :: parts)
  | other => (other, parts)
private partial def normalizeImportedBinderOrigins (name : Name) : Name :=
  match name with
  | .anonymous => .anonymous
  | .num parent index => .num (normalizeImportedBinderOrigins parent) index
  | .str _ _ =>
    let (parent, parts) := splitOriginStrings name []
    let origin := parts.foldl (fun acc part => Name.str acc part) Name.anonymous
    Name.appendCore (normalizeImportedBinderOrigins parent) (relocateBinderOrigin origin)
private def namedBinder (name : Name) : Json :=
  let view := extractMacroScopes name
  let relocated := { view with
    ctx := relocateBinderOrigin view.ctx
    imported := normalizeImportedBinderOrigins view.imported }
  toJson (reprStr (normalizeName relocated.review))
private partial def raw (handle : IO.FS.Handle) (e : Expr) : ExportM Nat := do
  if let some cached:=(←get).raw.get? ⟨e⟩ then return cached
  let result←match e with
  | .bvar index=>node handle "raw" "bvar" (toJson index) #[]
  | .fvar _=>throwError "raw export received a free local variable"
  | .mvar _=>throwError "compiled expression contains a metavariable"
  | .sort level=>node handle "raw" "sort" (toJson (reprStr level)) #[]
  | .const name levels=>do
    let data:=Json.arr #[named name,toJson (levels.map reprStr)]
    node handle "raw" "const" data #[]
  | .lit (.natVal value)=>node handle "raw" "nat" (toJson (toString value)) #[]
  | .lit (.strVal value)=>node handle "raw" "string" (toJson value) #[]
  | .app f a=>do
    let left←raw handle f
    let right←raw handle a
    node handle "raw" "app" Json.null #[left,right]
  | .lam name type body info | .forallE name type body info=>do
    let domain←raw handle type
    let target←raw handle body
    let tag:=if e.isLambda then "lambda" else "forall"
    node handle "raw" tag (Json.arr #[namedBinder name,toJson (reprStr info)]) #[domain,target]
  | .letE name type value body nondep=>do
    let typeNode←raw handle type
    let valueNode←raw handle value
    let bodyNode←raw handle body
    node handle "raw" "let" (Json.arr #[namedBinder name,toJson nondep]) #[typeNode,valueNode,bodyNode]
  | .mdata metadata body=>do
    let child←raw handle body
    node handle "raw" "metadata" (toJson (reprStr metadata)) #[child]
  | .proj owner index body=>do
    let child←raw handle body
    node handle "raw" "projection" (Json.arr #[named owner,toJson index]) #[child]
  modify fun state=>{state with raw:=state.raw.insert ⟨e⟩ result}
  return result
private partial def erased (handle : IO.FS.Handle) (locals : Array Expr)
    (e : Expr) : ExportM Nat := do
  let key : ExprStructEq×Nat:=(⟨e⟩,locals.size)
  if let some cached:=(←get).erased.get? key then return cached
  let result←if (←isProof e) then do
    let type←inferType e
    let proposition:=(type.abstract locals)
    node handle "typed_proof_erased" "proof" Json.null #[(←raw handle proposition)]
  else match e with
  | .bvar _=>throwError "unopened bound variable during typed erasure"
  | .fvar id=>do
    let some position:=locals.findIdx? (fun value=>value.fvarId! == id)
      | throwError "local variable not in the typed erasure context"
    node handle "typed_proof_erased" "bvar" (toJson (locals.size-1-position)) #[]
  | .mvar _=>throwError "compiled expression contains a metavariable"
  | .sort level=>node handle "typed_proof_erased" "sort" (toJson (reprStr level)) #[]
  | .const name levels=>do
    let data:=Json.arr #[named name,toJson (levels.map reprStr)]
    node handle "typed_proof_erased" "const" data #[]
  | .lit (.natVal value)=>node handle "typed_proof_erased" "nat" (toJson (toString value)) #[]
  | .lit (.strVal value)=>node handle "typed_proof_erased" "string" (toJson value) #[]
  | .app f a=>do
    let left←erased handle locals f
    let right←erased handle locals a
    node handle "typed_proof_erased" "app" Json.null #[left,right]
  | .lam name type body info=>do
    let domain←erased handle locals type
    let saved←get
    let (bodyNode,next)←withLocalDecl name info type fun localValue=>
      (erased handle (locals.push localValue) (body.instantiate1 localValue)).run saved
    set next
    node handle "typed_proof_erased" "lambda"
      (Json.arr #[namedBinder name,toJson (reprStr info)]) #[domain,bodyNode]
  | .forallE name type body info=>do
    let domain←erased handle locals type
    let saved←get
    let (bodyNode,next)←withLocalDecl name info type fun localValue=>
      (erased handle (locals.push localValue) (body.instantiate1 localValue)).run saved
    set next
    node handle "typed_proof_erased" "forall"
      (Json.arr #[namedBinder name,toJson (reprStr info)]) #[domain,bodyNode]
  | .letE name type value body nondep=>do
    let typeNode←erased handle locals type
    let valueNode←erased handle locals value
    let saved←get
    let (bodyNode,next)←withLetDecl name type value fun localValue=>
      (erased handle (locals.push localValue) (body.instantiate1 localValue)).run saved
    set next
    node handle "typed_proof_erased" "let"
      (Json.arr #[namedBinder name,toJson nondep]) #[typeNode,valueNode,bodyNode]
  | .mdata metadata body=>do
    let child←erased handle locals body
    node handle "typed_proof_erased" "metadata" (toJson (reprStr metadata)) #[child]
  | .proj owner index body=>do
    let child←erased handle locals body
    node handle "typed_proof_erased" "projection" (Json.arr #[named owner,toJson index]) #[child]
  modify fun state=>{state with erased:=state.erased.insert key result}
  return result
private def declarationKind : ConstantInfo→String
 | .axiomInfo _=>"axiom" | .defnInfo _=>"definition" | .thmInfo _=>"theorem"
 | .opaqueInfo _=>"opaque" | .quotInfo _=>"quotient" | .inductInfo _=>"inductive"
 | .ctorInfo _=>"constructor" | .recInfo _=>"recursor"
private def computationalMetadata (handle : IO.FS.Handle) (ci : ConstantInfo) : ExportM Json := do
 match ci with
 | .axiomInfo value=>return Json.mkObj [("unsafe",toJson value.isUnsafe)]
 | .defnInfo value=>return Json.mkObj [
   ("safety",toJson (reprStr value.safety)),("hints",toJson (match value.hints with | .opaque=>"opaque" | .abbrev=>"abbrev" | .regular height=>"regular:"++toString height)),
   ("mutual",toJson (value.all.map (fun n => reprStr (normalizeName n))))]
 | .opaqueInfo value=>return Json.mkObj [
   ("unsafe",toJson value.isUnsafe),("mutual",toJson (value.all.map (fun n => reprStr (normalizeName n))))]
 | .inductInfo value=>return Json.mkObj [
   ("parameters",toJson value.numParams),("indices",toJson value.numIndices),
   ("mutual",toJson (value.all.map (fun n => reprStr (normalizeName n)))),("constructors",toJson (value.ctors.map (fun n => reprStr (normalizeName n)))),
   ("nested",toJson value.numNested),("recursive",toJson value.isRec),
   ("unsafe",toJson value.isUnsafe),("reflexive",toJson value.isReflexive)]
 | .ctorInfo value=>return Json.mkObj [
   ("inductive",named value.induct),("index",toJson value.cidx),
   ("parameters",toJson value.numParams),("fields",toJson value.numFields),
   ("unsafe",toJson value.isUnsafe)]
 | .recInfo value=>
   let mut rules : Array Json:=#[]
   for rule in value.rules do
    let rawRule←raw handle rule.rhs
    let erasedRule←erased handle #[] rule.rhs
    rules:=rules.push (Json.mkObj [("constructor",named rule.ctor),
      ("fields",toJson rule.nfields),("raw_rhs",toJson rawRule),("erased_rhs",toJson erasedRule)])
   return Json.mkObj [
    ("mutual",toJson (value.all.map (fun n => reprStr (normalizeName n)))),("parameters",toJson value.numParams),
    ("indices",toJson value.numIndices),("motives",toJson value.numMotives),
    ("minors",toJson value.numMinors),("K",toJson value.k),
    ("unsafe",toJson value.isUnsafe),("rules",Json.arr rules)]
 | .quotInfo value=>return toJson (match value.kind with
   | .type=>"type" | .ctor=>"constructor" | .lift=>"lift" | .ind=>"induction")
 | .thmInfo _=>return Json.null

/- Exact compiler-name collision census over the entire common source parent. -/
def checkNoPublicCollisions (contextModules commonModules : List Name) : MetaM Unit := do
  let env ← getEnv
  let mut publicNames : NameSet := {}
  for moduleName in contextModules do
    let some index := env.getModuleIdx? moduleName
      | throwError "missing actual context module {moduleName}"
    for name in env.header.moduleData[index.toNat]!.constNames do
      if !isPrivateName name then
        unless !publicNames.contains name do
          throwError "duplicate nonprivate context declaration {name}"
        publicNames := publicNames.insert name
  for moduleName in commonModules do
    let some index := env.getModuleIdx? moduleName
      | throwError "missing common-parent module {moduleName}"
    for name in env.header.moduleData[index.toNat]!.constNames do
      if publicNames.contains name then
        throwError "context collides with a nonprivate parent declaration {name}"
  logInfo m!"PASS_EXACT_NONPRIVATE_GLOBAL_COLLISION_CENSUS {contextModules.length} {commonModules.length} {publicNames.toArray.size}"

def exportModules (modules : List Name) (output : System.FilePath) : MetaM Unit := do
  let env←getEnv
  let selected:=modules.foldl (fun names name=>names.insert name) ({} : NameSet)
  let handle←IO.FS.Handle.mk output .write
  for moduleName in modules do
    unless env.header.moduleNames.contains moduleName do
      throwError "requested shared module not actually loaded {moduleName}"
    let object←findOLean moduleName
    handle.putStrLn (Json.mkObj [("kind",toJson "module"),
      ("module",toJson moduleName.toString),("object",toJson object.toString)]).compress
  let mut state : ExportState:={}
  let mut count:=0
  -- Pinned ModuleData.constNames is exactly constants.map ConstantInfo.name.
  -- Enumerate the requested module arrays rather than all millions of unrelated CIs.
  let mut entries : Array (Name×ConstantInfo):=#[]
  let mut seen : NameSet:={}
  for moduleName in modules do
    let some moduleIndex:=env.getModuleIdx? moduleName
      | throwError "requested module index unavailable {moduleName}"
    let data:=env.header.moduleData[moduleIndex.toNat]!
    for name in data.constNames do
      let some owner:=env.getModuleIdxFor? name
        | throwError "declared imported constant has no compiler module owner {name}"
      if owner==moduleIndex && !seen.contains name then
        let some ci:=env.find? name | throwError "declared imported CI absent {name}"
        entries:=entries.push (name,ci)
        seen:=seen.insert name
  for (name,ci) in entries do
    if let some index:=env.getModuleIdxFor? name then
      let moduleName:=env.header.moduleNames[index.toNat]!
      if selected.contains moduleName then
        let proposition←isProp ci.type
        let (typeNode,next)←(raw handle ci.type).run state
        state:=next
        let rawValue : Option Nat:=none
        let mut dataValue : Option Nat:=none
        let mut rootValueHash : Option String:=none
        if let some value:=ci.value? true then
          -- Root proof bodies do not determine shared declaration interfaces.
          -- Full object hashes bind them; this cached Expr hash is diagnostic only.
          rootValueHash:=some (toString value.hash)
          if !proposition then
            let (index,next)←(erased handle #[] value).run state
            dataValue:=some index
            state:=next
        let (metadata,next)←(computationalMetadata handle ci).run state
        state:=next
        handle.putStrLn (Json.mkObj [
          ("kind",toJson "declaration"),("name",toJson name.toString),
          ("name_repr",named name),("module",toJson moduleName.toString),
          ("is_private",toJson (isPrivateName name)),
          ("declaration_kind",toJson (declarationKind ci)),
          ("level_params",toJson (ci.levelParams.map reprStr)),
          ("type",toJson typeNode),("is_prop",toJson proposition),
          ("raw_value",toJson rawValue),("data_value",toJson dataValue),
          ("root_value_hash",toJson rootValueHash),("root_proof_body_omitted",toJson proposition),
          ("computational_metadata",metadata)]).compress
        count:=count+1
  handle.putStrLn (Json.mkObj [("kind",toJson "completed"),
    ("declarations",toJson count),("nodes",toJson state.next),
    ("modules",toJson (modules.map Name.toString))]).compress
  handle.flush
end ContextInterface.ExportV3
