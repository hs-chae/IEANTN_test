"""Reuse the previously exercised namespace executor for offline Lean replay.

This records isolation and command completion, never mathematical acceptance.
Run it inside resource_scope_v2.py; no obsolete address-space limit is imposed.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import os
import subprocess
import time
from urllib.parse import urlparse

B = Path(__file__).resolve().parents[2]/'scoped/current65-joint-source-input-v1/namespace-v1'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read_json(p):
    def pairs(rows):
        d = {}
        for k, v in rows:
            need(k not in d, 'duplicate JSON key')
            d[k] = v
        return d
    def floating(s):
        v = float(s)
        need(math.isfinite(v), 'nonfinite JSON number')
        return v
    def constant(s):
        raise ValueError('nonfinite JSON constant '+s)
    return json.loads(p.read_text(), object_pairs_hook=pairs,
                      parse_float=floating, parse_constant=constant)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', type=Path, required=True)
    ap.add_argument('--environment', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--engine', type=Path, required=True)
    ap.add_argument('--checkpoint', type=Path)
    ap.add_argument('--prior', type=Path)
    ap.add_argument('command', nargs=argparse.REMAINDER)
    args = ap.parse_args()
    source = args.input.resolve()
    out = args.out.resolve()
    command = args.command[1:] if args.command[:1]==['--'] else args.command
    need(source.is_dir() and args.environment.is_file() and command and
         not out.exists() and not out.is_relative_to(source), 'RO source/fresh external output/command')
    inputs = []
    for p in sorted(source.rglob('*')):
        need(not p.is_symlink() and '.git' not in p.relative_to(source).parts,
             'no application links/history')
        if p.is_file():
            need(p.suffix not in {'.olean', '.o', '.so', '.a'}, 'no compiled application input')
            inputs.append(dict(path=p.relative_to(source).as_posix(), sha256=sha(p)))
    engine = args.engine.resolve()
    expected_engine = {'engine_v3.py': '6a19523cbf29935980b33c106760220e893db83864a31c658825b76c73466986',
                       'small_module_map_policy.c': 'aa450ed0f3ecd1678e2e7c0aa07fd13393214dfa2dfd0388336b8c73112b37ac'}
    need(engine.is_dir() and {p.name for p in engine.iterdir()} == set(expected_engine), 'exact source-only engine directory')
    for name, digest in expected_engine.items():
        path = engine/name
        need(path.is_file() and not path.is_symlink() and sha(path) == digest, 'pinned continuation engine source')
    need((args.prior is None) == (args.checkpoint is None), 'explicit prior/checkpoint pair')
    application_inputs = []
    checkpoint_sha = None
    prior = None
    if args.prior is not None:
        prior = args.prior.resolve()
        checkpoint = read_json(args.checkpoint)
        checkpoint_sha = sha(args.checkpoint)
        need(checkpoint['origin_root'] == str(prior) and prior.is_dir(), 'exact prior object origin')
        for row in checkpoint['records']:
            obj = row['files']['object']
            rel = Path(obj['path'])
            need(not rel.is_absolute() and '..' not in rel.parts, 'relative prior object path')
            need((prior/rel).is_file() and sha(prior/rel) == obj['sha256'], 'prior object readback')
            application_inputs.append(dict(module=row['module'], path=str(prior/rel), sha256=obj['sha256']))
        need(bool(application_inputs) and len({p['module'] for p in application_inputs}) == len(application_inputs), 'nonempty unique accepted prior objects')
    environment = read_json(args.environment)
    deps = environment['generic_dependencies']
    lock = read_json(B/'GENERIC_INPUT_LOCK.json')
    need([{k:d[k] for k in ['name','url','commit']} for d in deps]==lock['dependencies'],
         'same pinned public generic identities as accepted source replay')
    expected = {'batteries', 'Qq', 'aesop', 'proofwidgets', 'importGraph',
                'LeanSearchClient', 'plausible', 'mathlib'}
    need(len(deps)==8 and {d['name'] for d in deps}==expected, 'public generic packages only')
    toolchain = Path(environment['compiler']).resolve().parent.parent
    generic = [toolchain]
    for dep in deps:
        s = Path(dep['source']).resolve()
        need(Path(dep['objects']).resolve().is_relative_to(s), 'generic object/source association')
        url = urlparse(dep['url'])
        need(url.scheme=='https' and url.hostname=='github.com' and
             url.username is None and url.password is None, 'public source origin')
        head = subprocess.run(['git', '-C', str(s), 'rev-parse', 'HEAD'],
                              check=True, capture_output=True, text=True).stdout.strip()
        need(head==dep['commit'], 'public generic source commit')
        generic.append(s)
    generic = [p for p in sorted(set(generic)) if not any(
        p!=q and p.is_relative_to(q) for q in generic)]
    compiler_files = [Path(environment['compiler']), toolchain/'lib/lean/libleanshared.so',
                      toolchain/'lib/lean/Init.olean', toolchain/'lib/lean/Std.olean']
    pins = [dict(path=str(p), sha256=sha(p)) for p in compiler_files]
    need(all(r['sha256']==lock['compiler_files'][str(Path(r['path']).relative_to(toolchain))]
             for r in pins), 'pinned complete compiler/kernel identities')
    need(not any(out.is_relative_to(p) for p in generic), 'output outside generic dependencies')
    out.mkdir(parents=True)
    (out/'root').mkdir()
    (out/'data').mkdir()
    entries = [dict(kind='ro', path='/task', source=str(source)),
               dict(kind='rw', path='/out', source=str(out/'data')),
               dict(kind='dir', path='/home/worker'),
               dict(kind='ro', path='/environment.json', source=str(args.environment.resolve())),
               dict(kind='ro', path='/entry.py', source=str(B/'entry_v2.py')),
               dict(kind='ro', path='/request.json', source=str(out/'REQUEST.json'))]
    for path in ['/usr/lib/python3.10', '/usr/lib/x86_64-linux-gnu',
                 '/lib/x86_64-linux-gnu', '/lib64/ld-linux-x86-64.so.2',
                 '/usr/include', '/usr/lib/gcc']:
        need(Path(path).exists(), 'required generic system library '+path)
        entries.append(dict(kind='ro', path=path, source=path))
    tools = {'/usr/bin/x86_64-linux-gnu-gcc-11':'/usr/bin/x86_64-linux-gnu-gcc-11',
             '/usr/bin/python3.10':'/usr/bin/python3.10',
             '/usr/bin/python3':'/usr/bin/python3.10', '/usr/bin/time':'/usr/bin/time',
             '/usr/bin/git':'/usr/bin/git', '/usr/bin/ld':'/usr/bin/ld',
             '/usr/bin/as':'/usr/bin/as', '/bin/sh':'/usr/bin/dash', '/bin/bash':'/usr/bin/bash'}
    for target, original in tools.items():
        entries.append(dict(kind='ro', path=target, source=str(Path(original).resolve())))
    entries.append(dict(kind='ro', path='/engine', source=str(engine)))
    if prior is not None:
        need(not out.is_relative_to(prior) and not prior.is_relative_to(out), 'separate prior/output trees')
        need(not any(prior.is_relative_to(p) or p.is_relative_to(prior) for p in generic), 'prior separate from generic dependencies')
        entries.append(dict(kind='ro', path=str(prior), source=str(prior)))
        entries.append(dict(kind='ro', path='/checkpoint.json', source=str(args.checkpoint.resolve())))
    entries += [dict(kind='ro', path=str(p), source=str(p)) for p in generic]
    canary = out/'HOST_CANARY'
    canary.write_text('Owned namespace probe; excluded from worker mounts.\n')
    request = dict(command=command, compiler_pins=pins,
                   parent_namespaces={n:os.readlink('/proc/self/ns/'+n) for n in ['pid','mnt','net']},
                   host_workspace_canary=str(canary),
                   application_object_inputs=application_inputs, prior_checkpoint_sha256=checkpoint_sha)
    (out/'REQUEST.json').write_text(json.dumps(request, indent=2)+'\n')
    spec = dict(version=1, root=str(out/'root'), cwd='/out', uid=os.getuid(), gid=os.getgid(),
                command=['/usr/bin/python3.10', '-I', '-B', '/entry.py'], network='offline',
                tmpfsSize='128m', tmpSize='1g', entries=entries,
                env=dict(HOME='/home/worker', PATH=str(toolchain/'bin')+':/usr/bin:/bin',
                         LANG='C.UTF-8', LEAN_NUM_THREADS='1', MALLOC_ARENA_MAX='1',
                         MALLOC_MMAP_MAX_='0', MIMALLOC_RESERVE_OS_MEMORY='64G',
                         MIMALLOC_ARENA_EAGER_COMMIT='1'))
    (out/'SPEC.json').write_text(json.dumps(spec, indent=2)+'\n')
    (out/'INPUTS.json').write_text(json.dumps(inputs, indent=2)+'\n')
    cmd = ['unshare', '--user', '--map-root-user', '--mount', '--propagation', 'private',
           '--', '/usr/bin/python3.10', '-I', '-B', str(B/'sandbox.py'), str(out/'SPEC.json')]
    start = time.monotonic()
    with (out/'stdout').open('wb') as so, (out/'stderr').open('wb') as se:
        child = subprocess.run(cmd, stdout=so, stderr=se)
    need(child.returncode==0, 'isolated command failed; inspect preserved stderr')
    probe = read_json(out/'data/NAMESPACE_PROBE.json')
    need(probe['status']=='PASS_DISTINCT_NAMESPACES_AND_RESTRICTED_PROOF_INPUTS' and
         probe['host_workspace_absent'] is True and probe['research_git_history_absent'] is True and
         probe['compiler_pins']==pins and all(probe['namespaces'][n] != request['parent_namespaces'][n]
         for n in request['parent_namespaces']), 'namespace attestation')
    result = read_json(out/'data/COMMAND_RESULT.json')
    need(result['exit_code']==0 and result['command']==command, 'exact completed child command')
    need(all(sha(source/r['path'])==r['sha256'] for r in inputs), 'source unchanged')
    need(all(sha(Path(r['path']))==r['sha256'] for r in pins), 'kernel/runtime unchanged')
    need(all(sha(engine/name)==digest for name,digest in expected_engine.items()), 'engine source unchanged')
    if prior is not None:
        need(sha(args.checkpoint)==checkpoint_sha and all(sha(Path(p['path']))==p['sha256'] for p in application_inputs), 'prior checkpoint/objects unchanged')
    receipt = dict(status='PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE',
                   command=command, seconds=time.monotonic()-start,
                   input_files=len(inputs), application_object_inputs=application_inputs,
                   continuation_engine_source_pins=expected_engine, prior_checkpoint_sha256=checkpoint_sha,
                   launcher_sha256=sha(Path(__file__)),
                   generic_lock_sha256=sha(B/'GENERIC_INPUT_LOCK.json'),
                   environment_sha256=sha(args.environment),
                   executor_sha256=sha(B/'sandbox.py'), entry_sha256=sha(B/'entry_v2.py'),
                   source_manifest_sha256=sha(out/'INPUTS.json'),
                   namespace_probe=probe, resource_scope='SEPARATE_OUTER_RECEIPT_REQUIRED')
    pending = out/'RECEIPT.pending'
    pending.write_text(json.dumps(receipt, indent=2)+'\n')
    pending.replace(out/'RECEIPT.json')
    print(json.dumps({k:receipt[k] for k in ['status','seconds','input_files']}))


if __name__=='__main__':
    main()
