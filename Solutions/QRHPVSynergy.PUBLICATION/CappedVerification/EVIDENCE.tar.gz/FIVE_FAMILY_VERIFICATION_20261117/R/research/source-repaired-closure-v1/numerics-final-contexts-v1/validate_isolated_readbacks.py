#!/usr/bin/env python3
"""Bind actual fresh auditor stdout/objects to a completed source-only namespace."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import re

HERE = Path(__file__).resolve().parent
Q = HERE.parent
R = Q.parents[1]
spec = importlib.util.spec_from_file_location("strict", HERE / "validate_readbacks.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
need, read, sha, parse = v.need, v.read, v.sha, v.parse
STD = {"propext", "Classical.choice", "Quot.sound"}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--namespace-root", type=Path, required=True)
    p.add_argument("--task", type=Path, required=True)
    p.add_argument("--kind", choices=["current250", "H01V1", "H02V1", "PublicMomentV1", "PublicVectorV1"], required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    out = a.out.resolve()
    need(not out.exists() and out.is_relative_to(HERE), "Fresh owned namespace readback")
    ns, task = a.namespace_root.resolve(), a.task.resolve()
    outer_path = ns / "RECEIPT.json"
    inner_path = ns / "data/run/RECEIPT.json"
    outer, inner = read(outer_path), read(inner_path)
    lock_path = task / "SOURCE_LOCK.json"
    lock = read(lock_path)
    need(outer["status"] == "PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE" and
         inner["status"] == "PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS" and
         inner["source_lock_sha256"] == sha(lock_path) and inner["source_modules"] == len(lock["sources"]),
         "Actual successful source-only namespace and exact task")
    need([r["name"] for r in inner["audits"]] == lock["roots"] and
         all(isinstance(r["type_repr"], str) and r["type_repr"] and set(r["axioms"]) <= STD
             for r in inner["audits"]), "Actual entire task typed Std3 audit")
    probe_path = ns / "data/NAMESPACE_PROBE.json"
    probe = read(probe_path)
    need(probe["status"] == "PASS_DISTINCT_NAMESPACES_AND_RESTRICTED_PROOF_INPUTS" and
         probe["host_workspace_absent"] is True and probe["research_git_history_absent"] is True,
         "Actual sandbox isolation probe")
    if a.kind == "current250":
        expected = read(Q / "REPAIR_TARGET_PLAN_V2.json")["contexts"]["current-research-coherent-context-pending-shared-type-data-gate"]
        module = "SourceRepaired.ResearchCurrentAuditSummaryV2"
        repair = "SourceRepaired.ResearchCurrentV1"
        marker = "RESEARCH_SUMMARY_EXACT_WRITTEN_ROOT "
    else:
        plan = read(Q / ("public-vector-context-v1/PLAN.json" if a.kind == "PublicVectorV1" else "numerics-contexts-v2/PLAN.json"))
        context = next(c for c in plan["contexts"] if c["label"] == a.kind)
        expected, module, repair = context["original_written_rows"], context["audit_module"], context["repair_module"]
        marker = "RESEARCH_EXACT_ROOT_CLOSURE "
    sources = {r["module"]: r for r in lock["sources"]}
    fresh = {r["module"]: r for r in inner["records"]}
    need(module in fresh, "Auditor must compile freshly in this actual namespace")
    record = fresh[module]
    source_row = sources[module]
    need(record["source_sha256"] == source_row["sha256"] and record["exit_code"] == 0,
         "Exact actual frozen source compiler record")
    for kind, item in record["files"].items():
        path = ns / "data/run" / item["path"]
        need(path.is_file() and not path.is_symlink() and sha(path) == item["sha256"],
             "Actual fresh auditor source/log/object association " + kind)
    need(sha(task / source_row["path"]) == source_row["sha256"], "Exact actual source bytes")
    cmd = record["command"]
    need(cmd[0:3] == [cmd[0], "-j1", "-R"] and
         cmd[3] == "/task/" + source_row.get("source_root", "source") and
         cmd[4] == "/task/" + source_row["path"], "Actual declared source-root compiler command")
    time_path = ns / "data/run" / record["files"]["time"]["path"]
    time = time_path.read_text().splitlines()
    need(time[0] == '\tCommand being timed: "' + " ".join(cmd) + '"' and time.count("\tExit status: 0") == 1,
         "Actual timed fresh compiler success")
    stdout = ns / "data/run" / record["files"]["stdout"]["path"]
    raw = stdout.read_text()
    rows = [parse(line.split(marker, 1)[1]) for line in raw.splitlines() if marker in line]
    props = [r for r in expected if r["name"] != "IEANTN.primeReciprocal"]
    actual = {(r["file"],r["line"],r["original"]): r for r in rows}
    wanted = {(r["file"],r["line"],r["name"]): r for r in props}
    need(len(rows) == len(actual) == len(props) and set(actual) == set(wanted), "Exact complete written proposition identities")
    for key, row in actual.items():
        preserve = wanted[key]["repair_policy"] == "preserve_original_kernel_path"
        root = row["original"] if preserve else repair + ".actual." + row["original"]
        need(row["root"] == root and row["preserve_kernel_path"] == preserve and
             row["exact_old_type_and_universes"] is True and set(row["axioms"]) <= STD,
             "Exact original statement, role and typed Std3 closure")
        if not preserve and a.kind != "current250":
            need(not row["retained_old_numerical_names"] and not row["old_standalone_basis_reached"],
                 "No old scalar/native or standalone-basis escape")
        facts = row.get("actual_basis_execution_model_facts", row.get("actual_basis_cell_roots_reached"))
        need(facts in {0,544}, "Full actual C272/model family where source basis is reached")
    if len(props) != len(expected):
        need(a.kind == "H01V1" and "RESEARCH_UNCHANGED_DATA IEANTN.primeReciprocal" in raw,
             "Explicit unchanged non-Prop H01 datum")
    result = dict(status="PASS_ACTUAL_ISOLATED_CONTEXT_WRITTEN_SOURCE_AUDIT_READBACK", label=a.kind,
        actual_namespace=str(ns), task=str(task), source_lock_sha256=sha(lock_path), written_rows=len(expected),
        proposition_rows=len(rows), unchanged_data=len(expected)-len(rows), rows=rows,
        actual_auditor_module=module, source_sha256=source_row["sha256"], object_sha256=record["files"]["object"]["sha256"],
        namespace_isolated=True, source_cold_with_explicit_validated_parent=True,
        input_pins={str(p):sha(p) for p in [outer_path,inner_path,lock_path,probe_path,stdout,time_path]},
        validator_sha256=sha(Path(__file__)), qualification="Strict subset readback of actual fresh source audit. The comprehensive parent/seed/native/interface and all283 join remains a separate mandatory final validator.")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + ".pending")
    tmp.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    os.replace(tmp, out)
    print(result["status"], a.kind, len(expected))


if __name__ == "__main__":
    main()
