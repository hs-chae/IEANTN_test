#!/usr/bin/env python3
"""Rebuild original interface sources; comparison-only view, never a PV seed."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import re

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("strict", HERE.parent / "validate_readbacks.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
spec = importlib.util.spec_from_file_location("owned", v.Q / "compile_consumer_v2.py")
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--packet", type=Path, required=True)
    p.add_argument("--parent-namespace", type=Path, required=True)
    p.add_argument("--base-task", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    task, ns, base, out = (getattr(a, name).resolve() for name in ["packet", "parent_namespace", "base_task", "out"])
    v.need(out.is_relative_to(HERE) and not out.exists(), "Fresh comparison-only source baseline")
    mapping_path = task / "provenance/CONTEXT_REMAP.json"
    mapping = v.read(mapping_path)
    lock = v.read(base / "SOURCE_LOCK.json")
    outer = v.read(ns / "RECEIPT.json")
    inner_path = ns / "data/run/RECEIPT.json"
    inner = v.read(inner_path)
    request_path = ns / "REQUEST.json"
    request = v.read(request_path)
    v.need(outer["status"] == "PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE" and
           inner["status"] == "PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS" and
           inner["source_lock_sha256"] == v.sha(base / "SOURCE_LOCK.json") and
           inner["source_modules"] == len(lock["sources"]) == 14878 and
           [r["name"] for r in inner["audits"]] == lock["roots"] and
           all(r["type_repr"] and set(r["axioms"]) <= v.STD for r in inner["audits"]),
           "Genuinely completed source-built common parent, not warm application objects")
    science = [r for r in mapping["source_maps"] if r["role"] == "scientific"]
    input_pins = {str(path):v.sha(path) for path in
                  [mapping_path, base / "SOURCE_LOCK.json", ns / "RECEIPT.json", inner_path, request_path]}
    seed_rows = request["application_object_inputs"]
    expected_objects = {r["module"]:r["sha256"] for r in seed_rows}
    v.need(len(expected_objects) == len(seed_rows) == 10970 and
           set(expected_objects) == set(inner["application_object_inputs"]), "Exact source-built seed object population")
    for row in inner["records"]:
        v.need(row["module"] not in expected_objects and row["exit_code"] == 0, "Disjoint successful fresh source records")
        expected_objects[row["module"]] = row["files"]["object"]["sha256"]
    v.need(len(expected_objects) == len(lock["sources"]) == 14878, "Every complete parent object has an accepted byte identity")
    modules = {r["original_module"] for r in science}
    source_index = {r["module"]:r for r in lock["sources"]}
    # A metadata comparison environment, not a complete-source prefix. The
    # conflicting Main/Solution and their exact reverse dependency closure must
    # never be used as stale imports for the original scientific files.
    excluded = modules & set(source_index)
    while True:
        expanded = excluded | {n for n, r in source_index.items() if set(r["imports"]) & excluded}
        if expanded == excluded:
            break
        excluded = expanded
    out.mkdir()
    bank, sources = out / "objects", out / "source"
    bank.mkdir()
    sources.mkdir()
    parent_objects = ns / "data/run/objects"
    parent_pins = {}
    for module in sorted(set(source_index) - excluded):
        original = parent_objects / (module.replace(".", "/") + ".olean")
        v.need(original.is_file() and v.sha(original) == expected_objects[module],
               "Actual accepted source-built parent object bytes before linking")
        parent_pins[str(original)] = expected_objects[module]
        target = bank / original.relative_to(parent_objects)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.symlink_to(original)
    pending = {r["original_module"]:r for r in science}
    environment = v.read(v.R / "research/framed-points-v1/PLAN.json")
    compiler = Path(environment["compiler"])
    v.need(v.sha(compiler) == lock["compiler_sha256"], "Exact source-built parent's pinned compiler")
    policy = v.read(v.Q / "separate-context-export-v4/RECEIPT.json")["process_policy"]
    env = dict(os.environ, **policy, LEAN_NUM_THREADS="1", LEAN_SYSROOT=str(compiler.parent.parent),
        PATH=str(compiler.parent) + os.pathsep + os.environ.get("PATH", ""),
        LEAN_PATH=":".join([str(bank), *environment["generic_libraries"]]))
    done, records = set(source_index)-excluded, []
    while pending:
        ready = []
        for module, row in pending.items():
            original = task / f"provenance/{mapping['label']}/originals" / (module.replace(".", "/") + ".lean")
            v.need(v.sha(original) == row["original_sha256"], "Exact preserved original scientific source")
            dependencies = re.findall(r"^import\s+([A-Za-z_][A-Za-z_0-9.]*)\s*$", original.read_text(), re.M)
            needed = {n for n in dependencies if n in source_index or n in modules}
            if needed <= done:
                ready.append((module,row,original))
        v.need(ready, "Original scientific closure cannot depend on an excluded stale variant")
        module, row, original = ready[0]
        target = sources / (module.replace(".", "/") + ".lean")
        target.parent.mkdir(parents=True, exist_ok=True)
        os.link(original, target)
        dest = out / ("compile-" + module)
        dest.mkdir()
        obj = bank / (module.replace(".", "/") + ".olean")
        v.need(not obj.exists() and not obj.is_symlink(), "No accepted parent artifact overwritten")
        obj.parent.mkdir(parents=True, exist_ok=True)
        command = ["/usr/bin/time", "-v", "-o", str(dest / "time.txt"), str(compiler), "-j1", "-R", str(sources), str(target), "-o", str(obj)]
        with (dest / "stdout").open("xb") as so, (dest / "stderr").open("xb") as se:
            result = owned.run_owned(command, env, so, se, 900)
        text = (dest / "stdout").read_text() + (dest / "stderr").read_text()
        v.need(result.returncode == 0 and not owned.live_group_members(result.pid) and
               "sorryAx" not in text and not re.search(r"declaration uses ['`]sorry['`]",text),
               "Actual admitted-free original scientific source compile")
        records.append(dict(module=module, source=str(target), source_sha256=v.sha(target),
            object_path=str(obj), object_sha256=v.sha(obj), command=command, exit_code=0,
            stdout_sha256=v.sha(dest / "stdout"), stderr_sha256=v.sha(dest / "stderr")))
        done.add(module)
        del pending[module]
    result = dict(status="PASS_FRESH_ORIGINAL_SCIENTIFIC_SOURCES_FOR_METADATA_COMPARISON_ONLY",
        label=mapping["label"], records=records, excluded_parent_variants_and_reverse_dependencies=sorted(excluded),
        actual_validated_parent_namespace=str(ns), validated_parent_receipt_sha256=v.sha(inner_path),
        parent_source_lock_sha256=v.sha(base / "SOURCE_LOCK.json"), source_remap_sha256=v.sha(mapping_path),
        script_sha256=v.sha(Path(__file__)), compiler_sha256=v.sha(compiler), parent_object_pins=parent_pins,
        input_pins=input_pins,
        qualification="Original sources regenerated from preserved packet payloads. Private comparison-only bank reuses only genuinely source-built parent dependencies, explicitly excludes conflicting/stale Main/Solution closures, and freshly compiles all original scientific modules. This view is NOT a validated complete parent, mathematical improvement, native computation or source-first PV provider.")
    for path, digest in {**input_pins, **parent_pins}.items():
        v.need(v.sha(Path(path)) == digest, "Actual parent/source bytes unchanged after original source compilation")
    target = out / "RECEIPT.json"
    temp = out / "RECEIPT.json.pending"
    temp.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    os.replace(temp, target)
    print(result["status"], mapping["label"], len(records))


if __name__ == "__main__":
    main()
