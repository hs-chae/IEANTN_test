"""Actual final283 CLI positives and focused falsification controls in 0/O/OO.

Run one optimization mode per guarded scope after all five real namespaces and
context interface gates complete. Fixtures only hard-link preserved actual
proof artifacts; rewritten metadata uses atomic replacement, never in-place
writes to original source/objects/stdout. Fixtures confer no proof acceptance.
"""
from pathlib import Path
import argparse,copy,hashlib,importlib.util,json,os,shutil,subprocess,sys
Q=Path(__file__).resolve().parent;R=Q.parents[1]
s=importlib.util.spec_from_file_location('engine',Q/'engine-v5/engine_v3.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def resolve(s):
 p=Path(s);return p.resolve() if p.is_absolute() else (R/p).resolve()
def put(path,data):
 tmp=path.with_name(path.name+'.control-pending');tmp.write_bytes(data);os.replace(tmp,path)
def change_stdout(namespace,module,change):
 p=namespace/'data/run/RECEIPT.json';receipt=m.read(p);row=next(r for r in receipt['records'] if r['module']==module)
 stdout=namespace/'data/run'/m.relative(row['files']['stdout']['path']);raw=stdout.read_text();updated=change(raw);m.need(updated!=raw,'negative fixture actually changes intended stdout')
 put(stdout,updated.encode());row['files']['stdout']['sha256']=m.sha(stdout);m.atomic(p,receipt)
def alter_row(raw,prefix,edit):
 lines=raw.splitlines();indices=[i for i,line in enumerate(lines) if prefix in line];m.need(indices,'fixture has actual source audit rows')
 i=indices[0];before,body=lines[i].split(prefix,1);row=m.parse(body);edit(row);lines[i]=before+prefix+json.dumps(row,separators=(',',':'));return '\n'.join(lines)+'\n'
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--mode',choices=['normal','O','OO'],required=True);a=ap.parse_args()
 m.need(sys.flags.optimize=={'normal':0,'O':1,'OO':2}[a.mode],'actual controls driver optimization matches requested mode')
 out=Q/'isolated283-final-controls-v2'/a.mode;m.need(not out.exists(),'fresh final mode controls');out.mkdir(parents=True)
 validator=Q/'freeze_isolated283_v8.py';m.need(m.sha(validator)=='2c7a4942a4e2011429f451c406a6e874aa421966831c5ce7a5085620eda30d61','Root reviewed final validator')
 manifest_path=Q/'FINAL283_EXECUTION_MANIFEST_V2.json';m.need(m.sha(manifest_path)=='c42f777e78c2cb22160077f3c422377574a353d3321ed7558a2ef7c3771427b9','frozen real five-route destinations');base=m.read(manifest_path)
 pins={}
 for route in base['routes']:
  ns=resolve(route['namespace'])
  for rel in ['RECEIPT.json','data/run/RECEIPT.json','REQUEST.json','INPUTS.json']:pins[str(ns/rel)]=m.sha(ns/rel)
 strict_controls=Q/'kernel-typed-seal-controls-v4/RECEIPT.json';strict=m.read(strict_controls)
 m.need(strict['status']=='PASS_ALL15_STRICT_KERNEL_SIDECAR_READER_POSITIVE_AND_FOCUSED_NEGATIVES_NORMAL_O_OO' and len(strict['records'])==15 and strict['reader_sha256']==m.sha(Q/'read_kernel_typed_sidecar_v5.py') and strict['script_sha256']==m.sha(Q/'seal_kernel_typed_sidecar_v4.py'),'Actual strict supplemental typed reader controls complete')
 expected={(mode,case) for mode in ['normal','O','OO'] for case in ['positive','missing-sidecar','wrong-bank','wrong-type','omitted-written-key']}
 m.need({(row['mode'],row['case']) for row in strict['records']}==expected,'All actual strict typed sidecar helper routes exercised')
 for row in strict['records']:
  m.need(row['python_optimization']=={'normal':0,'O':1,'OO':2}[row['mode']] and row['exit_code']==(0 if row['case']=='positive' else 1),'Actual helper optimization/outcome')
  for kind in ['stdout','stderr']:m.need(m.sha(strict_controls.parent/row['mode']/(row['case']+'.'+kind))==row[kind+'_sha256'],'Actual strict helper child log pins')
 options={'normal':[],'O':['-O'],'OO':['-OO']}[a.mode];records=[]
 def run(tag,manifest,success,count=283):
  mp=out/(tag+'-manifest.json');m.atomic(mp,manifest);dest=out/(tag+'-result')
  cmd=[sys.executable,*options,'-I','-B',str(validator),'--manifest',str(mp),'--out',str(dest),'--expected-written-rows',str(count)]
  p=subprocess.run(cmd,capture_output=True);(out/(tag+'.stdout')).write_bytes(p.stdout);(out/(tag+'.stderr')).write_bytes(p.stderr)
  m.need((p.returncode==0)==success,'actual final CLI expected outcome '+tag)
  if success:m.need(m.read(dest/'RECEIPT.json')['written_count']==283,'actual complete final positive')
  else:
   m.need(not(dest/'RECEIPT.json').exists(),'no false final acceptance for negative')
   intended={
    'wrong-written-population':'exact requested283 universe',
    'missing-active-route':'all five actual namespace routes',
    'false-nonproof-data-interface':'actual complete context public types/nonproof data/no global collisions H01V1',
    'missing-actual-negative-union':'actual exact complete unfiltered source negative union SourceRepaired.ResearchCurrentAuditSummaryV2',
    'nonstandard-row-axiom':'exact role/oldtype/universes/Std3',
    'boolean-source-basis-facts':'schema-specific exact272actual Cexecution/model facts when basis is used'}
   m.need(tag in intended and ('ValueError: '+intended[tag]) in p.stderr.decode(errors='replace'),'negative reaches its intended acceptance guard '+tag)
   m.need(b'PASS_EXACT283_ACTUAL_ISOLATED_WRITTEN_SOURCE_ROLE_AND_INTERFACE_GATE' not in p.stdout,'no PASS output on a focused negative')
  records.append(dict(tag=tag,command=cmd,exit_code=p.returncode,expected_success=success,stdout_sha256=m.sha(out/(tag+'.stdout')),stderr_sha256=m.sha(out/(tag+'.stderr'))))
 run('positive-all-five-routes',base,True)
 run('wrong-written-population',base,False,282)
 missing=copy.deepcopy(base);missing['routes']=missing['routes'][:-1];run('missing-active-route',missing,False)
 falsegate=copy.deepcopy(base);route=next(x for x in falsegate['routes'] if x['label']=='H01V1');gate=m.read(resolve(route['public_interface_receipt']));gate['nonproof_data_matches']=False;p=out/'false-data-interface.json';m.atomic(p,gate);route['public_interface_receipt']=str(p);run('false-nonproof-data-interface',falsegate,False)
 def common_fixture(tag):
  fixture=copy.deepcopy(base);route=next(x for x in fixture['routes'] if x['label']=='CurrentCommon');original=resolve(route['namespace']);ns=out/('fixture-'+tag)
  shutil.copytree(original,ns,symlinks=True,copy_function=os.link,ignore=shutil.ignore_patterns('root','HOST_CANARY'))
  route['namespace']=str(ns);return fixture,ns
 fixture,ns=common_fixture('missing-unfiltered-marker')
 change_stdout(ns,'SourceRepaired.ResearchCurrentAuditSummaryV2',lambda text:text.replace('INDEPENDENT_FULL_SOURCE_UNION_PASS 220 6329251','REMOVED_UNFILTERED_SOURCE_UNION_MARKER',1))
 run('missing-actual-negative-union',fixture,False)
 fixture,ns=common_fixture('nonstandard-row-axiom')
 change_stdout(ns,'SourceRepaired.ResearchCurrentAuditSummaryV2',lambda text:alter_row(text,'RESEARCH_SUMMARY_EXACT_WRITTEN_ROOT ',lambda row:row.__setitem__('axioms',['forged.application_oracle'])))
 run('nonstandard-row-axiom',fixture,False)
 fixture,ns=common_fixture('boolean-basis-facts')
 change_stdout(ns,'SourceRepaired.ResearchCurrentAuditSummaryV2',lambda text:alter_row(text,'RESEARCH_SUMMARY_EXACT_WRITTEN_ROOT ',lambda row:row.__setitem__('actual_basis_execution_model_facts',False)))
 run('boolean-source-basis-facts',fixture,False)
 for name,digest in pins.items():m.need(m.sha(Path(name))==digest,'all original actual namespace evidence unchanged')
 m.atomic(out/'RECEIPT.json',dict(status='PASS_ACTUAL_FINAL283_FIVE_ROUTE_POSITIVE_AND_FOCUSED_NEGATIVES',mode=a.mode,python_optimization=sys.flags.optimize,records=records,validator_sha256=m.sha(validator),driver_sha256=m.sha(Path(__file__)),execution_manifest_sha256=m.sha(manifest_path),original_actual_namespace_pins=pins,qualification='Positive revalidates every actual source-built namespace, source/payload/prior/object/time/log/Std3 route and all283 exact written identities. Metadata-only negative fixtures preserve original actual proof/source artifacts and cannot publish final acceptance.'))
 print(json.dumps(dict(status='PASS',mode=a.mode,actual_CLIs=len(records),receipt_sha256=m.sha(out/'RECEIPT.json'))))
if __name__=='__main__':main()
