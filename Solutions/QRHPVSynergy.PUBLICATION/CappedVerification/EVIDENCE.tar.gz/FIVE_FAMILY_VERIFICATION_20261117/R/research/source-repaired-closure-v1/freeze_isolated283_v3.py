"""Fail-closed actual-namespace readback of the exact283 written research rows.

Every route runs the independently reviewed V5 completed-parent validator as an
actual CLI in the caller's Python optimization mode. Audited source/helper rows
and32 intentional kernel baselines remain distinct; one nonproof datum remains
unchanged. No count of source/generic rows is advertised as a count of complete
source-first program-verification theorems.
"""
from pathlib import Path
import argparse,importlib.util,json,sys,subprocess
Q=Path(__file__).resolve().parent;R=Q.parents[1]
s=importlib.util.spec_from_file_location('engine',Q/'engine-v5/engine_v3.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
STD={'propext','Classical.choice','Quot.sound'}
LABELS={'CurrentCommon','H01V1','H02V1','PublicMomentV1','PublicVectorV1'}
MODULES={'CurrentCommon':['SourceRepaired.ResearchCurrentAuditSummaryV2','SourceRepaired.Theta240AuditSummaryV1','SourceRepaired.VectorCompleteAuditV4'],
 'H01V1':['SourceRepaired.H01V1Audit'],'H02V1':['SourceRepaired.H02V1Audit'],
 'PublicMomentV1':['SourceRepaired.PublicMomentV1Audit'],'PublicVectorV1':['SourceRepaired.PublicVectorV1Audit']}
def resolved(value):
 p=Path(value);return p.resolve() if p.is_absolute() else (R/p).resolve()
def key(row):return row['file'],row['line'],row.get('name',row.get('original'))
def scope_check(path):
 scope=m.read(path);m.need(scope['exit_code']==0,'actual route resource exit0')
 cgroup=Path(scope['cgroup'])/'cgroup.procs';m.need(not cgroup.exists() or not cgroup.read_text().strip(),'actual route child drain')
 for sample in scope['samples']:
  events=dict(line.split() for line in sample.get('memory.events','').splitlines())
  m.need(all(int(events.get(k,'0'))==0 for k in ['oom','oom_kill']),'no sampled route OOM event recorded')
 return scope

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--manifest',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--expected-written-rows',type=int,default=283);a=ap.parse_args()
 out=a.out.resolve();m.need(out.is_relative_to(Q) and not out.exists(),'fresh owned final readback');m.need(a.expected_written_rows==283,'exact requested283 universe')
 plan_path=Q/'REPAIR_TARGET_PLAN_V2.json';plan=m.read(plan_path);wanted_list=[r for values in plan['contexts'].values() for r in values];wanted={key(r):r for r in wanted_list}
 m.need(len(wanted_list)==len(wanted)==283,'full written(file,line,name) inventory without collapse')
 manifest=m.read(a.manifest);routes=manifest['routes'];m.need(len(routes)==len({x['label'] for x in routes})==5 and {x['label'] for x in routes}==LABELS,'all five actual namespace routes')
 packets_path=Q/'numerics-final-contexts-v1/packets-v2/PACKETS.json';m.need(m.sha(packets_path)=='4f1644e35cfa924595c01b8967aaaa594a554025d30ce18415224062f4135cf2','frozen four exact context packets');packets={x['label']:x for x in m.read(packets_path)['packets']}
 m.need(m.sha(Q/'prepare_completed_parent_v5.py')=='20aea653089d66283c987a5484f7f279cd66db0e9215895a8b008233d9157495','independently reviewed complete-parent validator')
 pins={};interface_receipts={}
 for route in routes:
  label=route['label'];task=resolved(route['task']);expected='e0262eb3fd346d31c896e54ed88c0fb0a7b66b82609aa5c2d867e61e5cf1c26a' if label=='CurrentCommon' else packets[label]['source_lock_sha256']
  m.need(m.sha(task/'SOURCE_LOCK.json')==expected,'exact final route source task '+label)
  pins[str(task/'SOURCE_LOCK.json')]=expected
  if label!='CurrentCommon':
   p=resolved(route['public_interface_receipt']);j=m.read(p)
   m.need(j['status']=='PASS_ALL_RELOCATED_CONTEXT_PUBLIC_TYPES_AND_NONPROOF_DATA' and j['label']==label and j['public_type_universe_matches'] is True and j['nonproof_data_matches'] is True and j['nonprivate_global_collisions']==[] and j['source_remap_sha256']==packets[label]['remap_sha256'],'actual complete context public types/nonproof data/no global collisions '+label)
   m.need(resolved(j['actual_namespace'])==resolved(route['namespace']),'public interface export bound to same actual namespace')
   m.need(j['input_pins'] and j['scriptpins'],'exact public interface evidence pins')
   for mapping in [j['input_pins'],j['scriptpins']]:
    for name,digest in mapping.items():m.need(m.sha(resolved(name))==digest,'actual pinned interface source/object/tool '+name)
   interface_receipts[label]=dict(path=str(p),sha256=m.sha(p));pins[str(p)]=m.sha(p)
 out.mkdir();all_rows=[];route_results=[];supplemental_vector_boundary=[]
 optimization=['-O'] if sys.flags.optimize==1 else ['-OO'] if sys.flags.optimize==2 else []
 env=R/'scoped/build/current52-public-environment-OO.json'
 for route in routes:
  label=route['label'];task=resolved(route['task']);namespace=resolved(route['namespace']);prior=resolved(route['prior_root']);scopepath=resolved(route['resource'])/'scope.json';scope=scope_check(scopepath)
  cmd=[sys.executable,*optimization,'-I','-B',str(Q/'prepare_completed_parent_v5.py'),'--base-task',str(task),'--task',str(task),'--environment',str(env),'--parent',str(namespace),'--seed-root',str(prior),'--seed-checkpoint',str(prior/'CHECKPOINT.json'),'--out',str(out/(label+'-validated-view'))]
  run=subprocess.run(cmd,capture_output=True);(out/(label+'.stdout')).write_bytes(run.stdout);(out/(label+'.stderr')).write_bytes(run.stderr);m.need(run.returncode==0,'actual full namespace/source/typed-root/prior/object/time/log route '+label)
  inner=m.read(namespace/'data/run/RECEIPT.json');outer=m.read(namespace/'RECEIPT.json');lock=m.read(task/'SOURCE_LOCK.json');records={r['module']:r for r in inner['records']};source_index={r['module']:r for r in lock['sources']}
  if label!='CurrentCommon':
   interface=m.read(resolved(route['public_interface_receipt']))
   remap=m.read(task/'provenance/CONTEXT_REMAP.json')
   scientific={r['staged_module']:r for r in remap['source_maps'] if r['role']=='scientific'}
   checked=interface['checked_new_modules']
   m.need(set(checked)==set(scientific),'every actual scientific context module covered by public type/data export')
   for module,item in checked.items():
    m.need(module in records and module in source_index,'interface module actually freshly compiled in same namespace')
    rec=records[module];object_path=namespace/'data/run'/m.relative(rec['files']['object']['path'])
    m.need(resolved(item['object_path'])==object_path.resolve() and object_path.is_file() and not object_path.is_symlink() and m.sha(object_path)==item['object_sha256']==rec['files']['object']['sha256'] and item['source_sha256']==rec['source_sha256']==source_index[module]['sha256']==scientific[module]['staged_sha256'],'exact same fresh namespace object/source compiled for each public interface')
    pins[str(object_path)]=rec['files']['object']['sha256']
  m.need(inner['source_modules']==len(source_index) and len(inner['audits'])==len(lock['roots']) and inner['prior_modules']==14878,'exact canonical explicit prior population '+label)
  audit_index={r['name']:r for r in inner['audits']};m.need(len(audit_index)==len(inner['audits']) and all(r['type_repr'] and set(r['axioms'])<=STD for r in audit_index.values()),'all actual nonempty typed Std3 roots '+label)
  actual_source_rows=[];markers=[]
  for module in MODULES[label]:
   m.need(module in records and records[module]['exit_code']==0,'auditor actually freshly compiled in namespace '+module)
   rec=records[module];m.need(rec['source_sha256']==source_index[module]['sha256'],'exact actual auditor source binding')
   for f in rec['files'].values():
    p=namespace/'data/run'/m.relative(f['path']);m.need(m.sha(p)==f['sha256'],'fresh auditor evidence unchanged');pins[str(p)]=f['sha256']
   stdout=(namespace/'data/run'/rec['files']['stdout']['path']).read_text();markers.append(stdout)
   prefix='RESEARCH_SUMMARY_EXACT_WRITTEN_ROOT ' if 'Summary' in module else 'RESEARCH_EXACT_ROOT_CLOSURE '
   emitted=[m.parse(line.split(prefix,1)[1]) for line in stdout.splitlines() if prefix in line]
   if module in ['SourceRepaired.ResearchCurrentAuditSummaryV2','SourceRepaired.Theta240AuditSummaryV1']:
    count,union=(220,6329251) if 'Current' in module else (12,6321084)
    marker=f'INDEPENDENT_FULL_SOURCE_UNION_PASS {count} {union}'
    m.need(stdout.splitlines().count(marker)==1,'actual exact complete unfiltered source negative union '+module)
    population='EXACT250_220_30_POPULATION_PASS' if 'Current' in module else 'EXACT12_12_0_POPULATION_PASS'
    m.need(stdout.splitlines().count(population)==1 and stdout.splitlines().count('INDEPENDENT_PROVIDER_FULL_PASS ScopedC.SourceClosedChecks.checks 6270447')==1 and stdout.splitlines().count('INDEPENDENT_PROVIDER_FULL_PASS SynergyTangentC.ClosedCaps.source_universal_basis_caps 53379')==1,'complete independently checked source provider and role populations')
    for row in emitted:
     row['readback_audit_schema']='SUMMARY_WITH_GLOBAL_UNFILTERED_NEGATIVE_UNION'
     row['readback_negative_gate']=dict(kind='PRESERVED_KERNEL_PATH_OUTSIDE_SOURCE_NEGATIVE_POPULATION' if row['preserve_kernel_path'] else 'EXACT_PINNED_AUDITOR_COMPLETE_UNFILTERED_SOURCE_UNION',module=module,marker=marker,source_rows=count,closure_constants=union,auditor_source_sha256=source_index[module]['sha256'])
   else:
    for row in emitted:row['readback_audit_schema']='EXPLICIT_PER_ROOT_UNFILTERED_CLOSURE'
   if module=='SourceRepaired.VectorCompleteAuditV4':
    m.need(len(emitted)==3,'exact three independent vector boundary roots')
    supplemental_vector_boundary.extend(emitted)
   else:actual_source_rows.extend(emitted)
   pins[str(task/source_index[module]['path'])]=source_index[module]['sha256']
  if label=='CurrentCommon':
   m.need(len(actual_source_rows)==262,'exact250+12 canonical written audit rows')
  else:
   expected=packets[label]['original_written_rows'];m.need(len(actual_source_rows)==expected-(1 if label=='H01V1' else 0),'exact independent context proposition row count '+label)
   if label=='H01V1':
    m.need(sum(s.count('RESEARCH_UNCHANGED_DATA IEANTN.primeReciprocal') for s in markers)==1 and 'IEANTN.primeReciprocal' in audit_index,'actual unchanged nonproof datum namespace root')
    d=next(r for r in wanted_list if r['name']=='IEANTN.primeReciprocal');all_rows.append(dict(**d,context=label,classification='UNCHANGED_NONPROOF_DATA',compiled_identity=d['name'],actual_type_repr=audit_index[d['name']]['type_repr'],public_data_interface=interface_receipts[label]))
  for row in actual_source_rows:
   k=key(row);m.need(k in wanted,'every actual exact written identity is in requested universe');original=wanted[k]
   m.need(row['role']==original['semantic_role'] and row['exact_old_type_and_universes'] is True and set(row['axioms'])<=STD,'exact role/oldtype/universes/Std3')
   preserve=row['preserve_kernel_path'];m.need(type(preserve) is bool,'strict kernel path Boolean')
   m.need(preserve==(original['semantic_role']=='intentional_kernel_only_baseline_or_helper'),'preserve precisely requested kernel baseline role')
   if not preserve:
    if row['readback_audit_schema']=='SUMMARY_WITH_GLOBAL_UNFILTERED_NEGATIVE_UNION':
     m.need(row['readback_negative_gate']['kind']=='EXACT_PINNED_AUDITOR_COMPLETE_UNFILTERED_SOURCE_UNION','summary negative coverage inherited from actual complete unfiltered source union')
     reached=row['actual_basis_execution_model_facts']
    else:
     m.need(row['readback_audit_schema']=='EXPLICIT_PER_ROOT_UNFILTERED_CLOSURE' and row['old_standalone_basis_reached'] is False and row['retained_old_numerical_names']==[],'explicit per-root no old numerical/native/basis providers')
     m.need(type(row['source_basis_alias_reached']) is bool,'explicit strict source basis reachability Boolean')
     reached=row['actual_basis_cell_roots_reached']
     if row['source_basis_alias_reached']:m.need(reached==544,'positive complete actual Cbasis path')
    m.need(type(reached) is int and reached in [0,544],'schema-specific exact272actual Cexecution/model facts when basis is used')
   m.need(row['root'] in audit_index and audit_index[row['root']]['type_repr'],'actual same source root type from namespace auditor')
   all_rows.append(dict(**row,context=label,classification='PRESERVED_KERNEL_BASELINE' if preserve else 'EXACT_TYPE_SOURCE_OR_GENERIC_PROPOSITION',actual_type_repr=audit_index[row['root']]['type_repr']))
  for p in [namespace/'RECEIPT.json',namespace/'data/run/RECEIPT.json',namespace/'data/run/Audit.lean',namespace/'REQUEST.json',namespace/'INPUTS.json',namespace/'data/NAMESPACE_PROBE.json',scopepath]:pins[str(p)]=m.sha(p)
  route_results.append(dict(label=label,namespace=str(namespace),source_modules=inner['source_modules'],typed_roots=len(inner['audits']),new_compilations=inner['new_compilations'],prior_modules=inner['prior_modules'],scope_elapsed_seconds=scope['elapsed_seconds'],oom_classification='NO_SAMPLED_OOM_EVENT_RECORDED',exact_charged_peak_bytes=None,actual_full_route_command=cmd,validated_view=str(out/(label+'-validated-view')),namespace_receipt_sha256=m.sha(namespace/'RECEIPT.json'),engine_receipt_sha256=m.sha(namespace/'data/run/RECEIPT.json')))
 m.need(len(supplemental_vector_boundary)==3 and len({r['root'] for r in supplemental_vector_boundary})==3,'all three supplemental vector source roots')
 for row in supplemental_vector_boundary:
  m.need(key(row) in wanted and row['exact_old_type_and_universes'] is True and set(row['axioms'])<=STD and row['preserve_kernel_path'] is False and row['old_standalone_basis_reached'] is False and row['retained_old_numerical_names']==[] and type(row['actual_basis_cell_roots_reached']) is int and row['actual_basis_cell_roots_reached'] in [0,544] and type(row['source_basis_alias_reached']) is bool,'supplemental vector actual same-type complete source boundary')
  m.need(row['root'] in {r['name'] for r in m.read(resolved(next(x for x in routes if x['label']=='CurrentCommon')['namespace'])/'data/run/RECEIPT.json')['audits']},'actual supplemental vector typed namespace root')
 for row in supplemental_vector_boundary:
  if row['source_basis_alias_reached']:m.need(row['actual_basis_cell_roots_reached']==544,'explicit supplemental vector positive basis handoff')
 m.need(max(r['actual_basis_cell_roots_reached'] for r in supplemental_vector_boundary)==544,'actual full vector final basis source handoff')
 actual={key(r):r for r in all_rows};m.need(len(actual)==len(all_rows)==283 and set(actual)==set(wanted),'exact complete283 written identity join')
 counts={label:sum(r['classification']==label for r in all_rows) for label in ['PRESERVED_KERNEL_BASELINE','UNCHANGED_NONPROOF_DATA','EXACT_TYPE_SOURCE_OR_GENERIC_PROPOSITION']}
 m.need(counts==dict(PRESERVED_KERNEL_BASELINE=32,UNCHANGED_NONPROOF_DATA=1,EXACT_TYPE_SOURCE_OR_GENERIC_PROPOSITION=250),'exact250source/generic+32kernel+1data roles')
 result=dict(status='PASS_EXACT283_ACTUAL_ISOLATED_WRITTEN_SOURCE_ROLE_AND_INTERFACE_GATE',written_rows=all_rows,written_count=283,role_counts=counts,routes=route_results,public_interface_receipts=interface_receipts,supplemental_vector_boundary=supplemental_vector_boundary,input_pins=pins,plan_sha256=m.sha(plan_path),execution_manifest_sha256=m.sha(a.manifest),validator_sha256=m.sha(Path(__file__)),python_optimization=sys.flags.optimize,namespace_isolated=True,source_built_chain=True,empty_application_bank=False,qualification='All283 written identities checked in genuine isolated namespaces chained to the explicitly validated canonical14878source-built parent.250source/generic propositions include auxiliary and conditional statements;32kernel baselines and1nonproof datum retain those roles. This receipt does not relabel all283 declarations as complete source-first PV programs, merge Main/Solution context objects, or remove documented compiler/runtime/OS/API/hardware and theorem hypotheses.')
 m.atomic(out/'RECEIPT.json',result);print(json.dumps(dict(status=result['status'],written_count=283,role_counts=counts,receipt_sha256=m.sha(out/'RECEIPT.json'))))
if __name__=='__main__':main()
