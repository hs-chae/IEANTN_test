"""Additive, explicit source-cold checkpoint continuation; never a new empty-bank claim."""
import argparse,concurrent.futures,hashlib,json,math,os,re,shutil,subprocess,tempfile,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
STD={'propext','Classical.choice','Quot.sound'}
POLICY='aa450ed0f3ecd1678e2e7c0aa07fd13393214dfa2dfd0388336b8c73112b37ac'
BINARY='76c786658fb8c9748bc73c29d83a13df4761b493bf8a5faa81d5a9ed11f20e5b'
GCC='/usr/bin/x86_64-linux-gnu-gcc-11'
GCC_SHA='821af3c74506283c179ca413bb33e6b528805a4dd8a5c09df125e5ad560a9e89'
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for data in iter(lambda:f.read(1048576),b''):h.update(data)
 return h.hexdigest()
def parse(raw):
 def pairs(rows):
  out={}
  for k,v in rows:need(k not in out,'duplicate JSON key');out[k]=v
  return out
 def floating(s):
  value=float(s);need(math.isfinite(value),'nonfinite JSON float');return value
 def bad(s):raise ValueError('nonfinite JSON constant '+s)
 return json.loads(raw,object_pairs_hook=pairs,parse_float=floating,parse_constant=bad)
def read(p):return parse(Path(p).read_text())
def atomic(p,data):
 p=Path(p);fd,tmp=tempfile.mkstemp(dir=p.parent,prefix='.'+p.name+'-')
 with os.fdopen(fd,'w')as f:json.dump(data,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
def relative(p):
 p=Path(p);need(not p.is_absolute()and '..'not in p.parts and bool(p.parts),'safe relative path');return p

def source_check(task,environment):
 lock=read(task/'SOURCE_LOCK.json');env=read(environment)
 sources=lock['sources'];need(bool(sources),'nonempty graph')
 names=[r['module']for r in sources];paths=[r['path']for r in sources]
 need(len(set(names))==len(names)and len(set(paths))==len(paths),'unique source graph')
 index={r['module']:r for r in sources}
 for r in sources:
  need(re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)*',r['module']),'module spelling')
  root=relative(r.get('source_root','source'))
  need(relative(r['path'])==root/Path(r['module'].replace('.','/')).with_suffix('.lean'),'module/exact declared source-root path')
  need((task/root).resolve().is_relative_to(task.resolve()) and not(task/root).is_symlink(),'owned declared source root')
  need((task/r['path']).resolve().is_relative_to((task/root).resolve()),'source stays within its exact declared root')
  need(len(set(r['imports']))==len(r['imports'])and set(r['imports'])<=set(names),'source dependency graph')
 payloads=lock['payloads'];need(len({r['path']for r in payloads})==len(payloads),'unique payloads')
 need(set(paths).isdisjoint(r['path']for r in payloads),'disjoint source/payload paths')
 for row in sources+payloads:
  p=task/relative(row['path']);need(p.is_file()and not p.is_symlink()and p.stat().st_size==row['bytes']and sha(p)==row['sha256'],'frozen input '+row['path'])
 need(len(set(lock['roots']))==len(lock['roots'])and bool(lock['roots']),'unique nonempty roots')
 need(set(lock['root_modules'])<=set(names),'root modules in graph')
 compiler=Path(env['compiler']);need(sha(compiler)==lock['compiler_sha256'],'compiler pin')
 tool=compiler.parent.parent
 for row in lock['runtime_pins']['toolchain_files']:
  p=tool/relative(row['path']);need(p.is_file()and p.stat().st_size==row['bytes']and sha(p)==row['sha256'],'runtime pin')
 q=subprocess.run([str(compiler),'--version'],capture_output=True,text=True,check=True)
 need(q.stdout.strip()==lock['runtime_pins']['lean_version'],'compiler version')
 deps=env['generic_dependencies']
 need([{k:d[k]for k in ['name','commit','url']}for d in deps]==lock['generic_dependencies'],'generic dependencies')
 for dep in deps:
  q=subprocess.run(['/usr/bin/git','-C',dep['source'],'rev-parse','HEAD'],capture_output=True,text=True,check=True)
  need(q.stdout.strip()==dep['commit']and Path(dep['objects']).is_dir(),'public generic identity')
 return lock,env,index

def expected_command(compiler,row,source_root,output_root):
 return [compiler,'-j1','-R',str(Path(source_root)/relative(row.get('source_root','source'))),str(Path(source_root)/row['path']),'-o',str(Path(output_root)/'objects'/Path(row['module'].replace('.','/')).with_suffix('.olean'))]
def legacy_record(root,row,compiler,source_root,output_root):
 name=row['module'];stem='data/run/logs/'+name;obj='data/run/objects/'+name.replace('.','/')+'.olean'
 files={k:stem+suffix for k,suffix in [('stdout','.stdout'),('stderr','.stderr'),('time','.time')]};files['object']=obj
 if not all((root/p).is_file()and not(root/p).is_symlink()for p in files.values()):return None
 command=expected_command(compiler,row,source_root,output_root)
 text=(root/files['time']).read_text()
 if text.splitlines().count('\tExit status: 0')!=1:return None
 need(text.splitlines()[0]=='\tCommand being timed: "'+' '.join(command)+'"','actual legacy timed argv '+name)
 if text.splitlines().count('\tExit status: 0')!=1:return None
 combined=(root/files['stdout']).read_text()+(root/files['stderr']).read_text()
 need(not re.search(r"declaration uses ['`]sorry['`]",combined) and not re.search(r'(^|\n).*: error(?:\(|:)',combined),'legacy diagnostics '+name)
 return dict(module=name,source_sha256=row['sha256'],command=command,exit_code=0,
   dependencies=row['imports'],files={k:dict(path=v,sha256=sha(root/v))for k,v in files.items()},
   association='RECONSTRUCTED_FROM_EXACT_TIMED_ARGV_EXIT0_AND_FROZEN_ISOLATED_INPUTS')

def seal(args):
 need(args.prior and args.out and args.controller_pid and args.controller_pid>0 and args.cgroup and args.resource_report,'explicit drained legacy origin')
 resource_hash=sha(args.resource_report);resource=read(args.resource_report)
 need(isinstance(resource,dict)and{'cgroup','unit','launcher_pid'}<=set(resource),'resource report must be final LIVE/RUNNING-style record with cgroup,unit,launcher_pid')
 need(type(resource['launcher_pid'])is int and resource['launcher_pid']>0,'valid original launcher pid')
 need(resource['cgroup']==args.cgroup and Path(args.cgroup).name==resource['unit'],'exact prior resource/cgroup association')
 need(not Path('/proc',str(resource['launcher_pid'])).exists(),'original resource launcher still live')
 need(not Path('/proc',str(args.controller_pid)).exists(),'original controller still live')
 cg=Path(args.cgroup)
 need(cg.is_absolute()and '..'not in cg.parts and cg.resolve().is_relative_to(Path('/sys/fs/cgroup'))and cg!=Path('/sys/fs/cgroup'),'actual absolute owned cgroup path')
 need(not(cg/'cgroup.procs').exists()or not(cg/'cgroup.procs').read_text().strip(),'original cgroup still live')
 root=args.prior.resolve();lock,env,index=source_check(args.task,args.environment)
 request=read(root/'REQUEST.json');probe=read(root/'data/NAMESPACE_PROBE.json');spec=read(root/'SPEC.json')
 need(request['command']==['/usr/bin/python3.10','-I','-B','/task/reproduce_joint_v2.py','--environment','/environment.json','--out','/out/run','--jobs',str(args.legacy_jobs)],'original exact isolated command')
 need(probe['status']=='PASS_DISTINCT_NAMESPACES_AND_RESTRICTED_PROOF_INPUTS'and probe['host_workspace_absent']is True and probe['research_git_history_absent']is True,'original namespace isolation')
 need(probe['compiler_pins']==request['compiler_pins']and all(probe['namespaces'][n]!=v for n,v in request['parent_namespaces'].items()),'namespace/compiler association')
 entries=spec['entries'];need([e for e in entries if e['path']=='/task']==[dict(kind='ro',path='/task',source=str(args.task.resolve()))],'original frozen source mount')
 need([e for e in entries if e['kind']=='rw']==[dict(kind='rw',path='/out',source=str(root/'data'))],'only original output writable')
 for row in read(root/'INPUTS.json'):
  p=args.task/relative(row['path']);need(p.is_file()and not p.is_symlink()and sha(p)==row['sha256'],'original all input seal')
 records=[]
 for row in lock['sources']:
  value=legacy_record(root,row,env['compiler'],'/task','/out/run')
  if value:records.append(value)
 accepted={r['module']:r for r in records}
 # A file left by an interrupted compile never becomes a dependency seed.
 while True:
  invalid={n for n,r in accepted.items()if not set(r['dependencies'])<=set(accepted)}
  if not invalid:break
  for n in invalid:del accepted[n]
 need(bool(accepted),'nonempty dependency-closed finished prefix')
 provenance={p:sha(root/p)for p in ['REQUEST.json','SPEC.json','INPUTS.json','data/NAMESPACE_PROBE.json']}
 result=dict(schema='SOURCE_COLD_CHAIN_CHECKPOINT_V1',status='SEALED_LEGACY_ISOLATED_PARTIAL_NOT_FULL_ACCEPTANCE',
   origin_root=str(root),recorded_source_root='/task',recorded_output_root='/out/run',source_lock_sha256=sha(args.task/'SOURCE_LOCK.json'),environment_sha256=sha(args.environment),
   old_recipe_sha256=sha(args.task/'reproduce_joint_v2.py'),compiler_sha256=lock['compiler_sha256'],
   controller_pid=args.controller_pid,drained_cgroup=args.cgroup,resource_report_sha256=sha(args.resource_report),provenance=provenance,
   records=list(accepted.values()),excluded_incomplete_or_dependency_nonclosed=len(index)-len(accepted),
   qualification='Only source-associated finished compilations from the original empty-application-bank isolated run. Partial prefix, not a complete source/proof audit. Continuation explicitly consumes these application objects.')
 need(sha(args.resource_report)==resource_hash,'drained resource report unchanged during seal')
 need(not args.out.exists(),'fresh checkpoint receipt');atomic(args.out,result)
 print(json.dumps(dict(status=result['status'],accepted=len(accepted),checkpoint_sha256=sha(args.out))))

def validate_prior(checkpoint,root,task,environment,index):
 need(checkpoint['schema']=='SOURCE_COLD_CHAIN_CHECKPOINT_V1'and checkpoint['status']in{'SEALED_LEGACY_ISOLATED_PARTIAL_NOT_FULL_ACCEPTANCE','CONTROLLED_FRESH_PREFIX_NOT_FULL_ACCEPTANCE'},'checkpoint schema/status')
 need(checkpoint['source_lock_sha256']==sha(task/'SOURCE_LOCK.json')and checkpoint['environment_sha256']==sha(environment),'same source/environment checkpoint')
 need(str(root.resolve())==checkpoint['origin_root'],'prior mounted at same absolute path for reproducible seed links')
 for p,h in checkpoint.get('provenance',{}).items():need(sha(root/relative(p))==h,'prior provenance unchanged')
 rows=checkpoint['records'];need(bool(rows)and len({r['module']for r in rows})==len(rows),'unique nonempty prior records')
 accepted={r['module']:r for r in rows}
 compiler=read(environment)['compiler']
 for name,r in accepted.items():
  need(name in index and r['exit_code']==0 and r['source_sha256']==index[name]['sha256'],'prior source/exit association')
  need(r['command']==expected_command(compiler,index[name],checkpoint['recorded_source_root'],checkpoint['recorded_output_root']),'pinned prior compiler/source/object argv')
  need(r['dependencies']==index[name]['imports']and set(r['dependencies'])<=set(accepted),'prior dependency closure')
  for key,f in r['files'].items():
   need(key in {'stdout','stderr','time','object'},'known evidence kind')
   p=root/relative(f['path']);need(p.is_file()and sha(p)==f['sha256'],'prior evidence hash '+name)
  need(set(r['files'])=={'stdout','stderr','time','object'},'complete prior evidence')
  need(r['files']['object']['path'].endswith('/'+name.replace('.','/')+'.olean'),'exact prior object identity')
  text=(root/r['files']['time']['path']).read_text()
  need(text.splitlines()[0]=='\tCommand being timed: "'+' '.join(r['command'])+'"'and text.splitlines().count('\tExit status: 0')==1,'prior executed argv/exit')
 return accepted

def policy(out):
 source=HERE/'small_module_map_policy.c';need(sha(source)==POLICY and sha(GCC)==GCC_SHA,'reviewed policy/GCC source pin')
 lib=out/'small_module_map_policy.so'
 cmd=[GCC,'-std=c11','-shared','-fPIC','-O2','-Wall','-Wextra','-Werror','-fvisibility=hidden','-nostartfiles','-Wl,-z,defs','-Wl,-z,now',str(source),'-o',str(lib)]
 q=subprocess.run(cmd,capture_output=True);need(q.returncode==0 and sha(lib)==BINARY,'rebuilt identical reviewed process policy')
 settings=dict(MALLOC_MMAP_MAX_='0',MALLOC_ARENA_MAX='1',MALLOC_TOP_PAD_='68719476736',MALLOC_TRIM_THRESHOLD_='18446744073709551615',MIMALLOC_RESERVE_OS_MEMORY='64G',MIMALLOC_ARENA_EAGER_COMMIT='1',LD_PRELOAD=str(lib))
 atomic(out/'PROCESS_POLICY.json',dict(command=cmd,compiler_sha256=GCC_SHA,source_sha256=POLICY,library_sha256=BINARY,settings=settings,stdout_sha256=hashlib.sha256(q.stdout).hexdigest(),stderr_sha256=hashlib.sha256(q.stderr).hexdigest(),qualification='Only Lean compiler/audit subprocesses receive LD_PRELOAD; not application C/C++ execution or source-PV evidence.'))
 return settings

def audit_text(lock):
 imports=''.join('import '+n+'\n'for n in lock['root_modules'])
 head=imports+'import Lean.Util.CollectAxioms\nimport Lean.Elab.Term\nopen Lean Elab\nset_option maxHeartbeats 0\nset_option maxRecDepth 100000\n'
 blocks=[]
 for first in range(0,len(lock['roots']),128):
  roots=lock['roots'][first:first+128]
  blocks.append('run_elab do\n let env ← getEnv\n for n in (['+','.join('`'+n for n in roots)+'] : List Name) do\n  let some ci := env.find? n | throwError "missing {n}"\n  let ax ← Lean.collectAxioms n\n  logInfo m!"BODY_AUDIT {(Json.mkObj [("name",toJson n.toString),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"\n')
 return head+''.join(blocks)

def run(args):
 need(args.out and 1<=args.jobs<=16,'fresh output/jobs1..16')
 need(not args.stop_after or(args.stop_after>0 and args.jobs==1),'bounded canary stop requires jobs1')
 lock,env,index=source_check(args.task,args.environment)
 if args.check_inputs:print(json.dumps(dict(status='PASS_FROZEN_SOURCE_RUNTIME_ENVIRONMENT_INPUTS',sources=len(index),roots=len(lock['roots']))));return
 need((args.prior is None)==(args.checkpoint is None),'prior/checkpoint pair')
 previous=read(args.checkpoint)if args.checkpoint else None
 seeds=validate_prior(previous,args.prior,args.task,args.environment,index)if previous else {}
 need(not args.out.exists()and not args.out.resolve().is_relative_to(args.task.resolve()),'fresh external output')
 args.out.mkdir(parents=True);objects=args.out/'objects';objects.mkdir();logs=args.out/'logs';logs.mkdir();receipts=args.out/'module-receipts';receipts.mkdir()
 engine_sha=sha(Path(__file__));lock_sha=sha(args.task/'SOURCE_LOCK.json');environment_sha=sha(args.environment)
 settings=policy(args.out);compiler_env=os.environ.copy();compiler_env.pop('LD_AUDIT',None);compiler_env.update(settings)
 compiler_env['LEAN_PATH']=':'.join([str(objects)]+[d['objects']for d in env['generic_dependencies']]);compiler_env['LEAN_NUM_THREADS']='1'
 records=[];start=time.monotonic()
 for name,row in seeds.items():
  p=objects/Path(name.replace('.','/')).with_suffix('.olean');p.parent.mkdir(parents=True,exist_ok=True)
  p.symlink_to((args.prior/row['files']['object']['path']).resolve())
  need(sha(p)==row['files']['object']['sha256'],'seed bank byte identity')
  atomic(receipts/(name+'.json'),dict(origin='READONLY_VALIDATED_PRIOR_APPLICATION_OBJECT',checkpoint_sha256=sha(args.checkpoint),record=row))
 atomic(args.out/'INPUT_ASSOCIATION.json',dict(source_lock_sha256=lock_sha,environment_sha256=environment_sha,engine_sha256=engine_sha,prior_checkpoint_sha256=sha(args.checkpoint)if previous else None,application_object_inputs=list(seeds),qualification='Initial empty bank'if not previous else'Explicit validated partial-source-cold continuation; no second empty-bank claim'))
 def execute(name,cmd):
  files={k:logs/(name+suffix)for k,suffix in [('stdout','.stdout'),('stderr','.stderr'),('time','.time')]};t=time.monotonic()
  with files['stdout'].open('xb')as so,files['stderr'].open('xb')as se:q=subprocess.run(['/usr/bin/time','-v','-o',str(files['time']),*cmd],stdout=so,stderr=se,cwd=args.task,env=compiler_env)
  record=dict(module=name,command=cmd,exit_code=q.returncode,seconds=time.monotonic()-t,files={k:dict(path=str(p.relative_to(args.out)),sha256=sha(p))for k,p in files.items()})
  atomic(receipts/(name+'.execution.json'),record)
  need(q.returncode==0,'compiler rejected '+name)
  raw=files['stdout'].read_text()+files['stderr'].read_text();need(not re.search(r"declaration uses ['`]sorry['`]",raw),'sorry warning '+name)
  return record
 def compile(row):
  p=objects/Path(row['module'].replace('.','/')).with_suffix('.olean');p.parent.mkdir(parents=True,exist_ok=True)
  record=execute(row['module'],expected_command(env['compiler'],row,args.task,args.out))
  record.update(source_sha256=row['sha256'],dependencies=row['imports'])
  record['files']['object']=dict(path=str(p.relative_to(args.out)),sha256=sha(p))
  atomic(receipts/(row['module']+'.json'),record)
  return record
 done=set(seeds);pending={n:r for n,r in index.items()if n not in done};running={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs)as pool:
  while pending or running:
   ready=[n for n,r in pending.items()if set(r['imports'])<=done]
   for name in ready[:args.jobs-len(running)]:running[pool.submit(compile,pending.pop(name))]=name
   need(bool(running),'cyclic/missing source imports')
   completed,_=concurrent.futures.wait(running,return_when=concurrent.futures.FIRST_COMPLETED)
   for future in completed:
    name=running.pop(future);records.append(future.result());done.add(name)
    atomic(args.out/'PROGRESS.json',dict(completed=len(done),total=len(index),new=len(records),seeded=len(seeds),seconds=time.monotonic()-start))
   if args.stop_after and len(records)>=args.stop_after:
    need(not running,'controlled stop no pending compiler')
    need(not seeds,'one-stage bounded canary only')
    cp=dict(schema='SOURCE_COLD_CHAIN_CHECKPOINT_V1',status='CONTROLLED_FRESH_PREFIX_NOT_FULL_ACCEPTANCE',origin_root=str(args.out.resolve()),recorded_source_root=str(args.task),recorded_output_root=str(args.out),source_lock_sha256=lock_sha,environment_sha256=environment_sha,records=records,provenance={})
    atomic(args.out/'CHECKPOINT.json',cp);print(json.dumps(dict(status=cp['status'],completed=len(records))));return
 need(done==set(index),'complete final source population')
 audit=args.out/'Audit.lean';audit.write_text(audit_text(lock));ar=execute('audit',[env['compiler'],'-j1','-R',str(args.out),str(audit)])
 audits=[parse(line.split('BODY_AUDIT ',1)[1])for line in(logs/'audit.stdout').read_text().splitlines()if'BODY_AUDIT 'in line]
 need([r['name']for r in audits]==lock['roots'],'exact final root population')
 need(all(isinstance(r['type_repr'],str)and bool(r['type_repr'])and set(r['axioms'])<=STD for r in audits),'actual nonempty typed Std3 final audit')
 source_check(args.task,args.environment)
 need(sha(Path(__file__))==engine_sha and sha(args.task/'SOURCE_LOCK.json')==lock_sha and sha(args.environment)==environment_sha,'recipe/source environment unchanged')
 if previous:validate_prior(previous,args.prior,args.task,args.environment,index)
 for record in records+[ar]:
  for f in record['files'].values():need(sha(args.out/relative(f['path']))==f['sha256'],'final own object/log hashes unchanged')
 need(sha(HERE/'small_module_map_policy.c')==POLICY and sha(args.out/'small_module_map_policy.so')==BINARY,'process policy unchanged')
 result=dict(status='PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS'if seeds else'PASS_EMPTY_APPLICATION_BANK_SOURCE_COLD_GRAPH',source_modules=len(index),roots=len(audits),new_compilations=len(records),prior_modules=len(seeds),records=records,audit_record=ar,audits=audits,elapsed_seconds=time.monotonic()-start,source_lock_sha256=lock_sha,environment_sha256=environment_sha,engine_sha256=engine_sha,application_object_inputs=list(seeds),qualification='Complete frozen source graph and final typed Std3 audits. Prior seeds are explicitly validated finished-source objects; namespace/resource/native association requires the separate outer receipts. No application-native or source-PV conclusion from this controller alone.')
 atomic(args.out/'RECEIPT.json',result);print(json.dumps({k:result[k]for k in ['status','source_modules','roots','new_compilations','prior_modules']}))

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('mode',choices=['seal','run']);ap.add_argument('--task',type=Path,required=True);ap.add_argument('--environment',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--prior',type=Path);ap.add_argument('--checkpoint',type=Path);ap.add_argument('--controller-pid',type=int);ap.add_argument('--cgroup');ap.add_argument('--resource-report',type=Path);ap.add_argument('--legacy-jobs',type=int,default=16);ap.add_argument('--jobs',type=int,default=16);ap.add_argument('--check-inputs',action='store_true');ap.add_argument('--stop-after',type=int)
 args=ap.parse_args()
 for field in ['task','environment','out','prior','checkpoint','resource_report']:
  value=getattr(args,field)
  if value is not None:setattr(args,field,value.resolve())
 seal(args)if args.mode=='seal'else run(args)
if __name__=='__main__':main()
