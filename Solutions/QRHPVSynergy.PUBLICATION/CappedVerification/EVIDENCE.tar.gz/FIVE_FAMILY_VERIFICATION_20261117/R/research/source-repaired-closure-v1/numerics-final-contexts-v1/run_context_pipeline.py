#!/usr/bin/env python3
"""Wait for a genuinely completed parent, then run four isolated guarded contexts."""
from pathlib import Path
import argparse
import datetime
import importlib.util
import json
import os
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
Q = HERE.parent
R = Q.parents[1]
spec = importlib.util.spec_from_file_location("strict", HERE / "validate_readbacks.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
spec = importlib.util.spec_from_file_location("guarded_stages", Q / "run_final_common_pipeline_v1.py")
stages = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stages)
OUT = HERE / "execution-v1"
stages.OUT = OUT


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    plan_path = HERE / "CONTEXT_EXECUTION_PLAN_V1.json"
    v.need(v.sha(plan_path) == "ce85c7de5ea2e185ebb7a6003d581cc0f3e854488a5e8747c531bad11e0ac4ac",
           "Exact independently reviewed context paths and limits")
    v.need(v.sha(HERE / "packets-v2/PACKETS.json") == "4f1644e35cfa924595c01b8967aaaa594a554025d30ce18415224062f4135cf2",
           "Exact independently preflighted four source packets")
    v.need(v.sha(HERE / "packet-controls-v1/RECEIPT.json") == "2dff0228f939574b4c7e437d6ccc66e2badca98a280f031dc0924a5c75af1ca8",
           "Actual optimization-mode source task controls")
    plan = v.read(plan_path)
    controls = v.read(HERE / "packet-controls-v1/RECEIPT.json")
    v.need(controls["status"] == "PASS_ACTUAL15_FOUR_CONTEXT_SOURCE_TASK_PREFLIGHT_CONTROLS_NORMAL_O_OO",
           "Actual four-route source-only input controls")
    components = [plan_path, Q / "prepare_completed_parent_v5.py", Q / "launch_namespace_v5.py",
        Q / "engine-v5/engine_v3.py", Q / "run_final_common_pipeline_v1.py",
        HERE / "validate_isolated_readbacks.py", HERE / "interfaces/export_context_v4.py",
        HERE / "interfaces/build_original_baseline.py",
        HERE / "interfaces/compare_interfaces.py", HERE / "finalize_one_context.py",
        HERE / "interfaces/source/ContextInterface/ExportV2.lean",
        HERE / "interfaces/build-v2/RECEIPT.json", Path(__file__)]
    pins = {str(p):v.sha(p) for p in components}
    if args.check_inputs:
        print(json.dumps(dict(status="PASS_FROZEN_FOUR_CONTEXT_CONTINUATION_INPUTS_NOT_EXECUTION",
            routes=len(plan["routes"]), scripts=len(pins))))
        return
    v.need(not OUT.exists(), "Fresh context continuation")
    OUT.mkdir()
    (OUT / "PINS.json").write_text(json.dumps(pins, indent=2) + "\n")
    parent_scope = R / "resources/research-final-source-replay-v1/scope.json"
    running = v.read(R / "resources/research-final-source-replay-v1/RUNNING.json")
    while not parent_scope.exists() or stages.alive(running["launcher_pid"]):
        stages.save("WAIT_ACTUAL_CANONICAL14878_COMPLETION", parent_launcher_pid=running["launcher_pid"])
        time.sleep(30)
    stages.check_scope(parent_scope)
    parent_ns = R / plan["parent_namespace"]
    parent = v.read(parent_ns / "data/run/RECEIPT.json")
    v.need(parent["source_modules"] == 14878 and parent["prior_modules"] == 10970 and
           parent["new_compilations"] == 3908 and len(parent["audits"]) == 20541,
           "Actual full canonical source-built parent")
    base = R / plan["base_task"]
    seed = R / plan["seed_root"]
    environment = R / "scoped/build/current52-public-environment-OO.json"
    results = []
    for route in plan["routes"]:
        label = route["label"]
        task, namespace, prior = (R / route[x] for x in ["task", "namespace", "prior_root"])
        v.need(v.sha(task / "SOURCE_LOCK.json") == route["source_lock_sha256"], "Exact frozen context source task")
        stage = "numerics-context-prior-" + label.lower() + "-v1"
        command = [sys.executable, "-I", "-B", str(Q / "prepare_completed_parent_v5.py"),
            "--base-task", str(base), "--task", str(task), "--environment", str(environment),
            "--parent", str(parent_ns), "--seed-root", str(seed), "--seed-checkpoint", str(seed / "CHECKPOINT.json"),
            "--out", str(prior)]
        stages.run_scope(stage, 8, 2, 7200, command)
        command = [sys.executable, "-I", "-B", str(Q / "launch_namespace_v5.py"), "--input", str(task),
            "--environment", str(environment), "--engine", str(Q / "engine-v5"), "--prior", str(prior),
            "--checkpoint", str(prior / "CHECKPOINT.json"), "--out", str(namespace), "--",
            "/usr/bin/python3.10", "-I", "-B", "/engine/engine_v3.py", "run", "--task", "/task",
            "--environment", "/environment.json", "--out", "/out/run", "--prior", str(prior),
            "--checkpoint", "/checkpoint.json", "--jobs", str(route["jobs"])]
        stages.run_scope(Path(route["resource"]).name, route["memory_gib"], route["cpus"], 14400, command)
        inner = v.read(namespace / "data/run/RECEIPT.json")
        v.need(inner["status"] == "PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS" and
               inner["prior_modules"] == 14878 and inner["new_compilations"] == route["new_sources"],
               "Actual complete isolated fresh context source population")
        baseline = HERE / "interfaces" / ("source-baseline-" + label + "-v1")
        stages.run_scope("numerics-original-baseline-" + label.lower() + "-v1", 16, 2, 1800,
            [sys.executable, "-I", "-B", str(HERE / "interfaces/build_original_baseline.py"), "--packet", str(task),
             "--parent-namespace", str(parent_ns), "--base-task", str(base), "--out", str(baseline)])
        old_export = HERE / "interfaces" / ("source-old-" + label + "-v4")
        stages.run_scope("numerics-source-old-export-" + label.lower() + "-v1", 16, 2, 1800,
            [sys.executable, "-I", "-B", str(HERE / "interfaces/export_context_v4.py"), "--label", label,
             "--role", "old", "--original-source-baseline", str(baseline), "--out", str(old_export)])
        new_export = HERE / "interfaces" / ("new-" + label + "-v4")
        stages.run_scope("numerics-new-interface-" + label.lower() + "-v1", 32, 2, 1800,
            [sys.executable, "-I", "-B", str(HERE / "interfaces/export_context_v4.py"), "--label", label,
             "--role", "new", "--namespace-root", str(namespace), "--packet", str(task), "--out", str(new_export)])
        # Comparison and raw-auditor readback have no Lean/application execution.
        gate = R / route["public_interface_receipt"]
        readback = OUT / (label + "-isolated-readback.json")
        command = [sys.executable, "-I", "-B", str(HERE / "finalize_one_context.py"), "--label", label,
            "--namespace-root", str(namespace), "--task", str(task), "--new-export", str(new_export),
            "--old-export", str(old_export),
            "--gate", str(gate), "--readback", str(readback), "--out", str(OUT / (label + "-controls"))]
        stages.run_scope("numerics-finalize-context-" + label.lower() + "-v1", 2, 1, 600, command)
        results.append(dict(label=label, task=str(task), namespace=str(namespace), resource=route["resource"],
            prior_root=str(prior), public_interface_receipt=str(gate), public_interface_sha256=v.sha(gate),
            readback_receipt=str(readback), readback_sha256=v.sha(readback),
            namespace_receipt_sha256=v.sha(namespace / "RECEIPT.json"),
            engine_receipt_sha256=v.sha(namespace / "data/run/RECEIPT.json")))
        stages.save("CONTEXT_COMPLETE_SEPARATE_SOURCE_AND_INTERFACE_GATES", label=label, completed=len(results))
    for path, digest in pins.items():
        v.need(v.sha(Path(path)) == digest, "Frozen continuation/helper sources unchanged")
    stages.m.atomic(OUT / "RECEIPT.json", dict(status="PASS_FOUR_ACTUAL_ISOLATED_CONTEXTS_PUBLIC_INTERFACES_AND_WRITTEN_AUDITS",
        routes=results, component_pins=pins, qualification="Four separate context environments with explicit validated source-built parents. Comprehensive all283 collision/role/source-closure/native audit remains separately required; no primary experimental result was changed."))
    stages.save("PASS_ALL_FOUR_SEPARATE_CONTEXTS")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        if OUT.exists():
            stages.save("FAILED_PRESERVED_NO_ACCEPTANCE", error=str(error))
        raise
