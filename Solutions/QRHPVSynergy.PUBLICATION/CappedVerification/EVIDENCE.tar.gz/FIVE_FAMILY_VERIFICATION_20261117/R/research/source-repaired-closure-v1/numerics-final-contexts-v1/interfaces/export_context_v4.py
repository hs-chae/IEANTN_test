#!/usr/bin/env python3
"""Separate compiler environments for original and source-cold context interfaces."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("strict", HERE.parent / "validate_readbacks.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
spec = importlib.util.spec_from_file_location("owned", v.Q / "compile_consumer_v2.py")
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--label", choices=["H01V1", "H02V1", "PublicMomentV1", "PublicVectorV1"], required=True)
    p.add_argument("--role", choices=["old", "new"], required=True)
    p.add_argument("--namespace-root", type=Path)
    p.add_argument("--packet", type=Path)
    p.add_argument("--original-source-baseline", type=Path)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    out = a.out.resolve()
    v.need(out.is_relative_to(HERE) and not out.exists(), "Fresh metadata export directory")
    plan_path = v.Q / ("public-vector-context-v1/PLAN.json" if a.label == "PublicVectorV1" else "numerics-contexts-v2/PLAN.json")
    context = next(x for x in v.read(plan_path)["contexts"] if x["label"] == a.label)
    module_map = {"H01V1": {}, "H02V1": {"Main": "ContextH02.Main"},
        "PublicMomentV1": {"Solution": "ContextPublicMoment.Solution"},
        "PublicVectorV1": {"Solution": "ContextPublicVector.Solution"}}[a.label]
    seeds = context["new_context_source_modules"]
    modules = [r["module"] for r in seeds]
    expected_objects = {}
    checked_new_modules = {}
    actual_namespace = None
    pins = {str(plan_path): v.sha(plan_path), str(Path(__file__)): v.sha(Path(__file__))}
    if a.role == "old":
        v.need(a.original_source_baseline is not None, "Explicit freshly source-regenerated original baseline; no warm default")
        baseline = a.original_source_baseline.resolve()
        baseline_receipt = baseline / "RECEIPT.json"
        receipt = v.read(baseline_receipt)
        v.need(receipt["status"] == "PASS_FRESH_ORIGINAL_SCIENTIFIC_SOURCES_FOR_METADATA_COMPARISON_ONLY" and
               receipt["label"] == a.label, "Actual regenerated original scientific context")
        bank = baseline / "objects"
        accepted = {r["module"]: r for r in receipt["records"]}
        pins[str(baseline_receipt)] = v.sha(baseline_receipt)
        for row in seeds:
            obj = bank / (row["module"].replace(".", "/") + ".olean")
            v.need(v.sha(obj) == accepted[row["module"]]["object_sha256"], "Accepted original source/object")
            expected_objects[row["module"]] = str(obj)
            pins[str(obj)] = v.sha(obj)
    else:
        v.need(a.namespace_root is not None and a.packet is not None, "Actual completed source-only namespace and task")
        ns, task = a.namespace_root.resolve(), a.packet.resolve()
        actual_namespace = str(ns)
        outer = v.read(ns / "RECEIPT.json")
        inner_path = ns / "data/run/RECEIPT.json"
        inner = v.read(inner_path)
        lock = v.read(task / "SOURCE_LOCK.json")
        v.need(outer["status"] == "PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE" and
             inner["status"] == "PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS" and
             inner["source_lock_sha256"] == v.sha(task / "SOURCE_LOCK.json") and
             inner["source_modules"] == len(lock["sources"]), "Actual complete isolated source-built context")
        source_rows = {r["module"]:r for r in lock["sources"]}
        bank = ns / "data/run/objects"
        records = {r["module"]: r for r in inner["records"]}
        modules = [module_map.get(n, n) for n in modules]
        for module in modules:
            row = records[module]
            v.need(row["exit_code"] == 0, "Actual fresh context source compilation")
            obj = ns / "data/run" / row["files"]["object"]["path"]
            v.need(not obj.is_symlink() and v.sha(obj) == row["files"]["object"]["sha256"], "Fresh isolated object, not a host seed")
            expected_objects[module] = str(obj)
            pins[str(obj)] = v.sha(obj)
            v.need(row["source_sha256"] == source_rows[module]["sha256"], "Actual fresh context source record")
            checked_new_modules[module] = dict(object_path=str(obj), object_sha256=v.sha(obj), source_sha256=row["source_sha256"])
        for path in [ns / "RECEIPT.json", inner_path, task / "SOURCE_LOCK.json", task / "provenance/CONTEXT_REMAP.json"]:
            pins[str(path)] = v.sha(path)
    source = HERE / "source/ContextInterface/ExportV2.lean"
    tool = HERE / "build-v2"
    accepted_tool = v.read(tool / "RECEIPT.json")
    obj = tool / "objects/ContextInterface/ExportV2.olean"
    v.need(v.sha(source) == accepted_tool["source_sha256"] and v.sha(obj) == accepted_tool["object_sha256"], "Actual accepted metadata exporter")
    pins[str(source)] = v.sha(source)
    pins[str(obj)] = v.sha(obj)
    compiler_plan = v.read(v.R / "research/framed-points-v1/PLAN.json")
    compiler = Path(compiler_plan["compiler"])
    policy = v.read(v.Q / "separate-context-export-v4/RECEIPT.json")["process_policy"]
    env = dict(os.environ, **policy, LEAN_NUM_THREADS="1", LEAN_PATH=":".join([str(tool / "objects"), str(bank), *compiler_plan["generic_libraries"]]))
    env["LEAN_SYSROOT"] = str(compiler.parent.parent)
    env["PATH"] = str(compiler.parent) + os.pathsep + env.get("PATH", "")
    out.mkdir()
    probe = out / "Probe.lean"
    stream = out / "expressions.jsonl"
    common_lock = v.read(v.Q / "final-replay-capsule-v1/SOURCE_LOCK.json")
    imported = list(dict.fromkeys((common_lock["root_modules"] if a.role == "new" else []) + modules))
    collision = (" ContextInterface.ExportV2.checkNoPublicCollisions [" + ",".join("`" + n for n in modules) + "] [" +
                 ",".join("`" + r["module"] for r in common_lock["sources"]) + "]\n") if a.role == "new" else ""
    probe.write_text("import ContextInterface.ExportV2\n" + "".join("import " + n + "\n" for n in imported) +
        "open Lean Elab\nset_option maxHeartbeats 0\nset_option maxRecDepth 300000\n" +
        "run_elab do\n" + collision + " ContextInterface.ExportV2.exportModules [" +
        ",".join("`" + n for n in modules) + "] " + json.dumps(str(stream)) + "\n")
    command = ["/usr/bin/time", "-v", "-o", str(out / "time.txt"), str(compiler), "-j1", "-R", str(out), str(probe), "-o", str(out / "Probe.olean")]
    with (out / "stdout").open("xb") as so, (out / "stderr").open("xb") as se:
        result = owned.run_owned(command, env, so, se, 1200)
    v.need(result.returncode == 0 and not owned.live_group_members(result.pid), "Successful drained compiler export")
    if a.role == "new":
        v.need("PASS_EXACT_NONPRIVATE_GLOBAL_COLLISION_CENSUS " in (out / "stdout").read_text(), "Actual full-parent collision census")
    unit = load_module("unit", v.Q / "reduce_expr_stream_v1.py")
    typed = load_module("typed", v.Q / "reduce_typed_proof_stream_v2.py")
    fp = unit.reduce_stream(stream)
    fp["validator_sha256"] = v.sha(v.Q / "reduce_expr_stream_v1.py")
    tp = typed.reduce_stream(stream, fp)
    typed_rows = {(r["module"], r["name_repr"]): r for r in tp["records"]}
    for row in fp["records"]:
        row.update(typed_rows[(row["module"], row["name_repr"])])
        v.need(type(row["is_private"]) is bool, "Compiler private-name classification")
    for module, obj in expected_objects.items():
        v.need(Path(fp["module_origins"][module]).resolve() == Path(obj).resolve(), "Actual compiler loaded this exact source-built object")
    for path in [probe, out / "stdout", out / "stderr", out / "time.txt", compiler,
                 v.Q / "reduce_expr_stream_v1.py", v.Q / "reduce_typed_proof_stream_v2.py"]:
        pins[str(path)] = v.sha(path)
    for path, digest in pins.items():
        v.need(v.sha(Path(path)) == digest, "Object/tool/receipt provenance stable")
    record = dict(status="PASS_SEPARATE_ACTUAL_COMPILER_PUBLIC_INTERFACE_EXPORT_NOT_EQUIVALENCE", label=a.label,
        role=a.role, modules=modules, module_map=module_map, records=fp["records"],
        source_stream_sha256=v.sha(stream), object_origins=fp["module_origins"], input_pins=pins,
        actual_namespace=actual_namespace, checked_new_modules=checked_new_modules,
        command=command, compiler_sha256=v.sha(compiler), exporter_sha256=v.sha(source),
        nonprivate_collision_census_complete=a.role == "new", common_modules_scanned=14878 if a.role == "new" else 0,
        qualification="All compiler CIs enumerated; exact explicit private module-prefix alpha relocation only. Public types/universes and all non-Prop data are compared by a separate fail-closed gate.")
    (out / "EXPORT.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
    print(json.dumps(dict(status=record["status"], label=a.label, role=a.role, declarations=len(fp["records"]))))


if __name__ == "__main__":
    main()
