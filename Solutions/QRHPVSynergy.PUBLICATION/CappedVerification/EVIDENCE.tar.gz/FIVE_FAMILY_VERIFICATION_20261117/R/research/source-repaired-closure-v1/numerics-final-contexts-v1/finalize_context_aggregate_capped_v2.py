#!/usr/bin/env python3
"""Publish the original four-route aggregate only from all actual strict gates."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os

H = Path(__file__).resolve().parent
Q = H.parent
R = Q.parents[1]
OUT = H / "execution-v1"
B = R / "research/capped-final-verification-20261117"
spec = importlib.util.spec_from_file_location("stages", Q / "run_final_common_pipeline_v1.py")
stages = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stages)
m = stages.m

def main():
    plan_path = H / "CONTEXT_EXECUTION_PLAN_V1.json"
    m.need(m.sha(plan_path) == "ce85c7de5ea2e185ebb7a6003d581cc0f3e854488a5e8747c531bad11e0ac4ac", "Frozen exact four scientific routes")
    cutoff = datetime.datetime.fromisoformat(m.read(B / "SESSION_PLAN.json")["proof_work_cutoff_utc"])
    m.need(datetime.datetime.now(datetime.timezone.utc) < cutoff, "Aggregate before proof-work cutoff")
    m.need(not (OUT / "RECEIPT.json").exists(), "Fresh four-context aggregate")
    original_pins = m.read(OUT / "PINS.json")
    for path, digest in original_pins.items():
        m.need(m.sha(Path(path)) == digest, "Every original frozen controller/scientific/helper byte preserved")
    pins = dict(original_pins)
    results = []
    labels = []
    for route in m.read(plan_path)["routes"]:
        label = route["label"]
        labels.append(label)
        task, namespace, prior = (R / route[key] for key in ["task", "namespace", "prior_root"])
        m.need(m.sha(task / "SOURCE_LOCK.json") == route["source_lock_sha256"], "Exact frozen context source lock")
        resource = route["resource"] if label != "PublicMomentV1" else "resources/numerics-isolated-publicmomentv1-v2"
        scope = stages.check_scope(R / resource / "scope.json")
        command = scope["command"]
        launcher = str(Q / "launch_namespace_v5.py")
        m.need(command.count(launcher) == 1, "Actual source resource used the exact namespace launcher")
        args = command[command.index(launcher) + 1:]
        args = args[:args.index("--")]
        for option, expected_path in [("--input", task), ("--out", namespace), ("--prior", prior),
            ("--checkpoint", prior / "CHECKPOINT.json"), ("--engine", Q / "engine-v5"),
            ("--environment", R / "scoped/build/current52-public-environment-OO.json")]:
            m.need(args.count(option) == 1 and Path(args[args.index(option) + 1]).resolve() == expected_path.resolve(),
                   "Actual guarded source command binds same task/namespace/prior/engine/environment " + option)
        inner_path = namespace / "data/run/RECEIPT.json"
        inner = m.read(inner_path)
        outer = m.read(namespace / "RECEIPT.json")
        m.need(inner["status"] == "PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS" and
               outer["status"] == "PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE" and
               inner["prior_modules"] == 14878 and inner["new_compilations"] == route["new_sources"] and
               inner["source_modules"] == 14878 + route["new_sources"], "Actual complete same isolated scientific source population")
        gate_path = R / route["public_interface_receipt"]
        gate = m.read(gate_path)
        m.need(gate["status"] == "PASS_ALL_RELOCATED_CONTEXT_PUBLIC_TYPES_AND_NONPROOF_DATA" and
               gate["label"] == label and Path(gate["actual_namespace"]).resolve() == namespace.resolve() and
               gate["public_type_universe_matches"] is True and gate["nonproof_data_matches"] is True and
               gate["nonprivate_global_collisions"] == [], "Actual strict public interface for same namespace")
        for group in [gate["input_pins"], gate["scriptpins"]]:
            for path, digest in group.items():
                m.need(m.sha(Path(path)) == digest, "Actual pinned public interface tools/source/exports")
        for record in gate["checked_new_modules"].values():
            path = Path(record["object_path"])
            m.need(path.is_relative_to(namespace / "data/run/objects") and not path.is_symlink() and
                   m.sha(path) == record["object_sha256"], "Actual same fresh scientific object in accepted namespace")
        readback = OUT / (label + "-isolated-readback.json")
        rb = m.read(readback)
        m.need(rb["status"] == "PASS_ACTUAL_ISOLATED_CONTEXT_WRITTEN_SOURCE_AUDIT_READBACK" and
               rb["label"] == label and Path(rb["actual_namespace"]).resolve() == namespace.resolve(), "Actual strict written source-auditor readback")
        if label == "H01V1":
            controls = OUT / "H01V1-controls-v3/RECEIPT.json"
        elif label == "H02V1":
            controls = OUT / "H02V1-controls-hygiene-v3/RECEIPT.json"
        else:
            controls = H / "execution-public-tail-v2" / (label + "-controls-v3/RECEIPT.json")
        c = m.read(controls)
        m.need(c["status"] == "PASS_ACTUAL15_ISOLATED_CONTEXT_INTERFACE_AND_WRITTEN_READBACK_CONTROLS" and
               c["label"] == label and len(c["records"]) == 15 and
               c["public_interface_receipt_sha256"] == m.sha(gate_path) and
               c["isolated_readback_sha256"] == m.sha(readback) and
               c["script_sha256"] == m.sha(H / "finalize_one_context_v3.py"), "All actual15 fresh strict controls bind actual canonical gates")
        expected = {(mode, "interface", case) for mode in range(3) for case in ["positive", "type", "data", "missing-public"]}
        expected |= {(mode, "isolated-readback", "positive") for mode in range(3)}
        got = {(row["mode"], row["route"], row["case"]) for row in c["records"]}
        m.need(got == expected, "No missing optimized interface or written-readback child route")
        for row in c["records"]:
            positive = row["case"] == "positive"
            m.need(row["exit_code"] == (0 if positive else 1), "Every actual child intended exit")
            stem = str(row["mode"]) + ("-isolated-readback" if row["route"] == "isolated-readback" else "-interface-" + row["case"])
            for kind in ["stdout", "stderr"]:
                m.need(m.sha(controls.parent / (stem + "." + kind)) == row[kind + "_sha256"], "Actual child output log pins")
            if not positive:
                out_index = row["command"].index("--out")
                target = Path(row["command"][out_index + 1])
                field = {"type": "type_differences", "data": "nonproof_value_differences", "missing-public": "only_right"}[row["case"]]
                expected_error = "ValueError: Exact public/nonproof interface match: " + field
                stdout = (controls.parent / (stem + ".stdout")).read_bytes()
                stderr = (controls.parent / (stem + ".stderr")).read_text()
                m.need(target.is_relative_to(H / "interfaces") and not target.exists() and stdout == b"" and
                       stderr.splitlines()[-1] == expected_error,
                       "Each actual optimized negative reaches its exact intended difference without output")
        for path in [controls, gate_path, readback, inner_path, namespace / "RECEIPT.json", R / resource / "scope.json"]:
            pins[str(path)] = m.sha(path)
        results.append(dict(label=label, task=str(task), namespace=str(namespace), resource=resource,
            prior_root=str(prior), public_interface_receipt=str(gate_path), public_interface_sha256=m.sha(gate_path),
            readback_receipt=str(readback), readback_sha256=m.sha(readback),
            namespace_receipt_sha256=m.sha(namespace / "RECEIPT.json"), engine_receipt_sha256=m.sha(inner_path)))
    m.need(labels == ["H01V1", "H02V1", "PublicMomentV1", "PublicVectorV1"], "Four separate exact contexts without collapse")
    tail_path = H / "execution-public-tail-v2/RECEIPT.json"
    tail = m.read(tail_path)
    m.need(tail["status"] == "PASS_TWO_ACTUAL_PUBLIC_CONTEXTS_SOURCE_INTERFACES_AND_WRITTEN_AUDITS_NOT_FOUR_AGGREGATE" and
           [row["label"] for row in tail["routes"]] == ["PublicMomentV1", "PublicVectorV1"],
           "Actual completed two-public-context controller with its final component check")
    expected_tail = {row["label"]: row for row in results if row["label"] in {"PublicMomentV1", "PublicVectorV1"}}
    for row in tail["routes"]:
        m.need(row == expected_tail[row["label"]], "Actual finished public controller binds same two accepted route records")
    for path, digest in tail["component_pins"].items():
        m.need(m.sha(Path(path)) == digest and (path not in pins or pins[path] == digest),
               "Actual completed public controller frozen end pins agree")
        pins[path] = digest
    pins[str(tail_path)] = m.sha(tail_path)
    origin = H / "interfaces/H02_BINDER_ORIGIN_ACCEPTANCE_V1.json"
    acceptance = m.read(origin)
    focused = B / "normalizer-controls-v3/RECEIPT.json"
    m.need(acceptance["status"] == "PASS_H02_STRICT_INTERFACE_AND_REVIEWED_EXACT_BINDER_MODULE_ORIGIN_NORMALIZATION" and
           acceptance["standard_actual_CLI_routes"] == 15 and acceptance["focused_actual_validator_CLIs"] == 21 and
           acceptance["canonical_gate_sha256"] == m.sha(H / "interfaces/gates/H02V1-v1.json"), "Reviewed exact origin-only H02 normalization fully controlled")
    for path, digest in acceptance["input_pins"].items():
        m.need(m.sha(Path(path)) == digest, "Every independent origin normalization review/control/source pin")
    f = m.read(focused)
    m.need(f["actual_validator_CLIs"] == 21 and f["actual_driver_modes"] == 3 and
           f["status"] == "PASS_ACTUAL_BINDER_ORIGIN_RELOCATION_AND_SIX_PRE_EXPORT_NEGATIVES_ALL_OPTIMIZATION_MODES", "Actual focused controls normal/O/OO")
    for path in [origin, focused, H / "finalize_one_context_v3.py", H / "interfaces/source/ContextInterface/ExportV3.lean",
                 H / "interfaces/build_exporter_v3.py", H / "interfaces/export_context_v5.py", Path(__file__)]:
        pins[str(path)] = m.sha(path)
    for path, digest in pins.items():
        m.need(m.sha(Path(path)) == digest, "All accepted four-route components remain exact")
    m.atomic(OUT / "RECEIPT.json", dict(status="PASS_FOUR_ACTUAL_ISOLATED_CONTEXTS_PUBLIC_INTERFACES_AND_WRITTEN_AUDITS",
        routes=results, component_pins=pins, qualification="Four separate source-only contexts with explicitly validated source-built parents, actual public type/universe/nonproof equality and actual15 strict normal/O/OO controls per context. H02 additionally uses the independently reviewed three-origin-only hygienic binder module mapping and21 actual focused pre-export controls; see the pinned normalization sidecar. Comprehensive all283 collision/role/source-closure/native audit remains separately required. Original outcomes and mathematical source/algorithm/parameters/assumptions are unchanged."))
    print("PASS_FOUR_ACTUAL_ISOLATED_CONTEXTS_PUBLIC_INTERFACES_AND_WRITTEN_AUDITS")

if __name__ == "__main__":
    main()
