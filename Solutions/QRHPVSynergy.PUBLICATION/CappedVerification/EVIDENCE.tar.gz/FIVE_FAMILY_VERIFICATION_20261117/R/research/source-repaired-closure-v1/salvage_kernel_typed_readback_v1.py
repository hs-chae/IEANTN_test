"""Strict zero-fresh receipt readback; preserve the earlier postprocess failure."""
from pathlib import Path
import importlib.util,subprocess,sys
Q=Path(__file__).resolve().parent;R=Q.parents[1];B=R/'research/capped-final-verification-20261117'
s=importlib.util.spec_from_file_location('typed_producer',Q/'run_kernel_typed_sidecar_pipeline_v2.py')
p=importlib.util.module_from_spec(s);s.loader.exec_module(p);m=p.m
OUT=Q/'kernel-typed-salvage-v1';NS=p.NS;PRIOR=p.PRIOR;TASK=p.TASK;ENV=p.ENV
def main():
 m.need(not OUT.exists(),'Fresh strict zero-fresh typed audit readback');OUT.mkdir()
 actual=m.read(NS/'data/run/RECEIPT.json');outer=m.read(NS/'RECEIPT.json')
 m.need(actual['status']=='PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS' and outer['status']=='PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE' and actual['source_modules']==actual['prior_modules']==14881 and actual['new_compilations']==0 and actual['records']==[] and len(actual['audits'])==20570,'Actual successful zero-fresh namespace and typed audit')
 failed_scope=R/'resources/research-final-common-kernel-typed-v1/scope.json';failed=m.read(failed_scope);cg=Path(failed['cgroup'])/'cgroup.procs'
 m.need(failed['exit_code']==1 and (not cg.exists() or not cg.read_text().strip()),'Original postprocess failure remains exit1/drained')
 merged=OUT/'validated-completed-namespace'
 command=[sys.executable,'-I','-B',str(Q/'prepare_completed_parent_v5.py'),'--base-task',str(TASK),'--task',str(TASK),'--environment',str(ENV),'--parent',str(NS),'--seed-root',str(PRIOR),'--seed-checkpoint',str(PRIOR/'CHECKPOINT.json'),'--out',str(merged)]
 with (OUT/'validate.stdout').open('wb') as so,(OUT/'validate.stderr').open('wb') as se:child=subprocess.run(command,stdout=so,stderr=se)
 m.need(child.returncode==0,'Actual unchanged V5 zero-fresh complete namespace readback exit0')
 cp=m.read(PRIOR/'CHECKPOINT.json');completed=m.read(merged/'CHECKPOINT.json');before=p.identities(dict(records=cp['records']));after=p.identities(dict(records=completed['records']))
 m.need(before==after and len(actual['application_object_inputs'])==len(set(actual['application_object_inputs']))==14881 and set(actual['application_object_inputs'])=={row['module'] for row in cp['records']},'Exact complete explicit seed population and unchanged14881 source/object triples')
 cp_sha=m.sha(PRIOR/'CHECKPOINT.json')
 for row in cp['records']:
  receipt=m.read(NS/'data/run/module-receipts'/(row['module']+'.json'))
  m.need(receipt['origin']=='READONLY_VALIDATED_PRIOR_APPLICATION_OBJECT' and receipt['checkpoint_sha256']==cp_sha and receipt['record']==row,'Every actual mapped seeded module receipt matches exact validated prior')
  obj=NS/'data/run'/m.relative(row['files']['object']['path'])
  m.need(obj.is_file() and not obj.is_symlink() and m.sha(obj)==row['files']['object']['sha256'],'Every actual same-namespace mapped object byte matches its accepted common seed')
 prep=m.read(TASK/'KERNEL_ROOT_PREPARATION.json');m.need(m.sha(TASK/'KERNEL_ROOT_PREPARATION.json')=='f07f7d5ddac27059bb69033879d909fa9f1f5d7e23caa74536d97a95b5312492','Exact frozen30 written kernel selection')
 names=prep['added_compiler_roots'];written=prep['written_kernel_rows'];indexed={row['name']:row for row in actual['audits']}
 m.need(len(indexed)==20570 and len(names)==26 and len(written)==30 and {r['root'] for r in written}==set(names) and all(row['type_repr'] and set(row['axioms'])<=p.m.STD for row in actual['audits']),'Every actual selected type nonempty and Std3')
 parent_preparation=m.read(PRIOR/'PREPARATION_RECEIPT.json');m.need(parent_preparation['parent_receipt_sha256']==m.sha(p.PARENT/'data/run/RECEIPT.json') and parent_preparation['parent_namespace_sha256']==m.sha(p.PARENT/'RECEIPT.json'),'Entire seed bank is validated from the same actual common namespace')
 bankpath=OUT/'COMMON_BANK_IDENTITY.json';m.atomic(bankpath,before)
 pins={}
 files=[TASK/'SOURCE_LOCK.json',TASK/'KERNEL_ROOT_PREPARATION.json',p.BASE/'SOURCE_LOCK.json',p.PARENT/'RECEIPT.json',p.PARENT/'data/run/RECEIPT.json',PRIOR/'CHECKPOINT.json',PRIOR/'PREPARATION_RECEIPT.json',NS/'RECEIPT.json',NS/'data/run/RECEIPT.json',NS/'data/run/Audit.lean',NS/'REQUEST.json',NS/'INPUTS.json',NS/'data/NAMESPACE_PROBE.json',ENV,Q/'engine-v5/engine_v3.py',Q/'prepare_completed_parent_v5.py',Q/'launch_namespace_v5.py',Q/'run_kernel_typed_sidecar_pipeline_v2.py',Path(__file__),bankpath,failed_scope,merged/'CHECKPOINT.json',merged/'PREPARATION_RECEIPT.json',OUT/'validate.stdout',OUT/'validate.stderr']
 for item in actual['audit_record']['files'].values():files.append(NS/'data/run'/m.relative(item['path']))
 for path in files:pins[str(path)]=m.sha(path)
 result=dict(schema=1,status='STRICT_ZERO_FRESH_TYPED_READBACK_COMPLETE_PENDING_NEW_RESOURCE_DRAIN',common_namespace=str(p.PARENT),supplemental_namespace=str(NS),source_modules=14881,prior_modules=14881,new_scientific_compilations=0,original_selected_typed_roots=20544,supplemental_selected_typed_roots=20570,added_kernel_compiler_roots=names,written_kernel_rows=written,typed_roots_by_name={n:indexed[n] for n in names},same_complete_application_object_universe=True,bank_identity_path=str(bankpath),completed_namespace_view=str(merged),original_common_view=str(PRIOR),application_object_records_schema='ZERO_FRESH_EXPLICIT_APPLICATION_INPUTS_WITH_VALIDATED_CHECKPOINT_AND_ALL_ACTUAL_MAPPED_OBJECTS',original_postprocess_resource_scope=str(failed_scope),original_postprocess_resource_exit_code=1,input_pins=pins,qualification='The original namespace outer command and all20570 typed audit rows passed. Its enclosing32GiB command failed only in naive postprocessing; that exit1 is preserved. This fresh strict readback uses the unchanged V5 adapter, exact explicit checkpoint/wrappers and every actual mapped object byte, with no scientific recompile.')
 m.atomic(OUT/'READBACK.json',result);print('STRICT_ZERO_FRESH_TYPED_READBACK_COMPLETE')
if __name__=='__main__':main()
