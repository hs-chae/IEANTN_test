#!/usr/bin/env python3
"""Compile the metadata-only interface exporter from exact source and core Lean."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("strict", HERE.parent / "validate_readbacks.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    out = a.out.resolve()
    v.need(out.is_relative_to(HERE) and not out.exists(), "Fresh metadata tool output")
    out.mkdir()
    compiler = Path(v.read(v.R / "research/framed-points-v1/PLAN.json")["compiler"])
    source = HERE / "source/ContextInterface/ExportV3.lean"
    obj = out / "objects/ContextInterface/ExportV3.olean"
    obj.parent.mkdir(parents=True)
    env = dict(os.environ, LEAN_PATH="", LEAN_NUM_THREADS="1")
    env.pop("LD_PRELOAD", None)
    env["LEAN_SYSROOT"] = str(compiler.parent.parent)
    env["PATH"] = str(compiler.parent) + os.pathsep + env.get("PATH", "")
    command = [str(compiler), "-j1", "-R", str(HERE / "source"), str(source), "-o", str(obj)]
    result = subprocess.run(command, capture_output=True, env=env, timeout=60)
    (out / "stdout").write_bytes(result.stdout)
    (out / "stderr").write_bytes(result.stderr)
    v.need(result.returncode == 0 and obj.is_file(), "Actual metadata exporter compile")
    text = (result.stdout + result.stderr).decode()
    v.need("sorryAx" not in text and "declaration uses `sorry`" not in text, "No admitted exporter source")
    receipt = dict(status="PASS_CORE_LEAN_METADATA_EXPORTER_SOURCE_COMPILE_NOT_NUMERICAL_PV",
        command=command, compiler_sha256=v.sha(compiler), source_sha256=v.sha(source),
        object_sha256=v.sha(obj), exit_code=result.returncode,
        qualification="Metadata-only comparator; explicit compiler-private prefix relocation. It proves no numerical application statement.")
    temporary = out / "RECEIPT.json.pending"
    temporary.write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, out / "RECEIPT.json")
    print(receipt["status"])


if __name__ == "__main__":
    main()
