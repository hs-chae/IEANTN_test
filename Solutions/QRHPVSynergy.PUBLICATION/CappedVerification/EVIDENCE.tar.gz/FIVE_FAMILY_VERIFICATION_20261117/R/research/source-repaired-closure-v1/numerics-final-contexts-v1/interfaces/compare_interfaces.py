#!/usr/bin/env python3
"""Compare all public compiler interfaces and every non-Prop computational datum."""
from pathlib import Path
import argparse
import copy
import importlib.util
import json
import os

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("strict", HERE.parent / "validate_readbacks.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
spec = importlib.util.spec_from_file_location("comparison", v.Q / "compare_context_fingerprints_v2.py")
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


def prepare(value):
    modules = {new: old for old, new in value["module_map"].items()}
    rows, excluded = [], []
    for original in value["records"]:
        row = copy.deepcopy(original)
        v.need(type(row["is_private"]) is bool and type(row["is_prop"]) is bool,
               "Actual compiler classifications, not namespace heuristics")
        row["module"] = modules.get(row["module"], row["module"])
        if row["is_private"] and row["is_prop"]:
            excluded.append([row["module"], row["name_repr"]])
        else:
            rows.append(row)
    return dict(status="PASS_COMPLETE_TYPED_DAG_FINGERPRINT_REDUCTION", records=rows,
        modules=[modules.get(n, n) for n in value["modules"]], declaration_count=len(rows)), excluded


def accept(comparison):
    for key in ["type_differences", "nonproof_value_differences", "proposition_retaining_data_differences",
                "computational_metadata_differences", "proposition_retaining_metadata_differences", "only_left", "only_right"]:
        v.need(not comparison[key], "Exact public/nonproof interface match: " + key)


def recompute(directory, value):
    spec = importlib.util.spec_from_file_location("ordinary_reducer", v.Q / "reduce_expr_stream_v1.py")
    ordinary = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ordinary)
    spec = importlib.util.spec_from_file_location("typed_reducer", v.Q / "reduce_typed_proof_stream_v2.py")
    typed = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(typed)
    fp = ordinary.reduce_stream(directory / "expressions.jsonl")
    fp["validator_sha256"] = v.sha(v.Q / "reduce_expr_stream_v1.py")
    second = typed.reduce_stream(directory / "expressions.jsonl", fp)
    rows = {(r["module"], r["name_repr"]):r for r in second["records"]}
    for row in fp["records"]:
        row.update(rows[(row["module"], row["name_repr"])])
    v.need(fp["records"] == value["records"] and fp["modules"] == value["modules"] and
           fp["module_origins"] == value["object_origins"], "Independent full compiler-stream recomputation")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--old", type=Path, required=True)
    p.add_argument("--new", type=Path, required=True)
    p.add_argument("--packet", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--negative-case", choices=["type", "data", "missing-public"])
    a = p.parse_args()
    out = a.out.resolve()
    v.need(out.is_relative_to(HERE) and not out.exists(), "Fresh owned interface receipt")
    old_path, new_path = a.old.resolve() / "EXPORT.json", a.new.resolve() / "EXPORT.json"
    old, new = v.read(old_path), v.read(new_path)
    v.need(old["status"] == new["status"] == "PASS_SEPARATE_ACTUAL_COMPILER_PUBLIC_INTERFACE_EXPORT_NOT_EQUIVALENCE"
           and old["role"] == "old" and new["role"] == "new" and old["label"] == new["label"]
           and old["module_map"] == new["module_map"] and old["compiler_sha256"] == new["compiler_sha256"]
           and old["exporter_sha256"] == new["exporter_sha256"], "Exact two distinct compiler environments and one exporter")
    v.need(new["nonprivate_collision_census_complete"] is True and new["common_modules_scanned"] == 14878,
           "Actual complete parent/compiler nonprivate collision census")
    v.need(isinstance(new["actual_namespace"], str) and bool(new["actual_namespace"]) and
           set(new["checked_new_modules"]) == set(new["modules"]), "All scientific modules tied to one actual namespace")
    for module, row in new["checked_new_modules"].items():
        obj = Path(row["object_path"])
        v.need(obj.is_relative_to(Path(new["actual_namespace"]) / "data/run/objects") and
               not obj.is_symlink() and v.sha(obj) == row["object_sha256"], "Same actual fresh namespace object")
    for data in [old, new]:
        for path, digest in data["input_pins"].items():
            v.need(v.sha(Path(path)) == digest, "Actual accepted source/object/tool provenance")
    v.need(v.sha(a.old / "expressions.jsonl") == old["source_stream_sha256"] and
           v.sha(a.new / "expressions.jsonl") == new["source_stream_sha256"], "Both exact actual compiler streams")
    recompute(a.old, old)
    recompute(a.new, new)
    left, excluded_left = prepare(old)
    right, excluded_right = prepare(new)
    comparison = c.compare(left, right)
    accept(comparison)
    if a.negative_case:
        broken = copy.deepcopy(comparison)
        key = dict(type="type_differences", data="nonproof_value_differences", **{"missing-public": "only_right"})[a.negative_case]
        broken[key].append(dict(deliberate_invalid_fixture=True))
        accept(broken)
        raise ValueError("Invalid interface fixture unexpectedly accepted")
    mapping_path = a.packet.resolve() / "provenance/CONTEXT_REMAP.json"
    mapping = v.read(mapping_path)
    v.need(mapping["label"] == old["label"] and mapping["module_relocations"] == old["module_map"], "Exact accepted source relocation map")
    record = dict(status="PASS_ALL_RELOCATED_CONTEXT_PUBLIC_TYPES_AND_NONPROOF_DATA", label=old["label"],
        public_type_universe_matches=True, nonproof_data_matches=True, nonprivate_global_collisions=[],
        source_remap_sha256=v.sha(mapping_path), public_and_nonproof_common_declarations=comparison["common_declarations"],
        actual_namespace=new["actual_namespace"], checked_new_modules=new["checked_new_modules"],
        modules=comparison["shared_modules"], explicit_private_module_prefix_map=old["module_map"],
        excluded_private_Prop_proof_helpers=dict(old=excluded_left, new=excluded_right),
        input_pins={str(old_path):v.sha(old_path),str(new_path):v.sha(new_path),str(mapping_path):v.sha(mapping_path)},
        scriptpins={str(Path(__file__)):v.sha(Path(__file__)),str(v.Q / "compare_context_fingerprints_v2.py"):v.sha(v.Q / "compare_context_fingerprints_v2.py")},
        qualification="Every nonprivate CI type/universe and every non-Prop data value/constructor/recursor computation is compared in separate actual compiler environments. Only compiler-classified private Prop proof helpers and theorem proof bodies are excluded. Three exact compiler-private module prefixes may be alpha-relocated; public names never change. The new export also scans all14878 common module constName arrays for nonprivate collisions.")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + ".pending")
    tmp.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
    os.replace(tmp, out)
    print(json.dumps(dict(status=record["status"], label=record["label"], common=comparison["common_declarations"])))


if __name__ == "__main__":
    main()
