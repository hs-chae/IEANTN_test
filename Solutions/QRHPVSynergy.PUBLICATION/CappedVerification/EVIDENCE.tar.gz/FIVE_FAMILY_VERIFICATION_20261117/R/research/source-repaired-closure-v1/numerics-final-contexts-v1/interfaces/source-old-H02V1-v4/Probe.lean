import ContextInterface.ExportV2
import Main
import SynergyHeightC.ThetaRead300
import SynergyHeightC.ThetaProgram300
open Lean Elab
set_option maxHeartbeats 0
set_option maxRecDepth 300000
run_elab do
 ContextInterface.ExportV2.exportModules [`Main,`SynergyHeightC.ThetaRead300,`SynergyHeightC.ThetaProgram300] "/ryu/hyunsik/playground/independence/codex/ivy/ieantn-qrh-pv-synergy-20261114/research/source-repaired-closure-v1/numerics-final-contexts-v1/interfaces/source-old-H02V1-v4/expressions.jsonl"
