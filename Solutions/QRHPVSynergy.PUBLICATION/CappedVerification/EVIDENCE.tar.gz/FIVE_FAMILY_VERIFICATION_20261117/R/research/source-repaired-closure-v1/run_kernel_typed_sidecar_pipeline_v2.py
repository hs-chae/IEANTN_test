"""Add existing kernel CI audit selections, with no scientific source compilation."""
from pathlib import Path
import argparse, datetime, hashlib, importlib.util, json, os, subprocess, sys, time
Q=Path(__file__).resolve().parent;R=Q.parents[1];B=R/'research/capped-final-verification-20261117'
s=importlib.util.spec_from_file_location('stages',Q/'run_final_common_pipeline_v1.py')
stages=importlib.util.module_from_spec(s);s.loader.exec_module(stages);m=stages.m
OUT=Q/'kernel-typed-sidecar-pipeline-v1';stages.OUT=OUT
TASK=Q/'final-common-kernel-roots-task-v1';BASE=Q/'final-common-audits-task-v1'
PARENT=Q/'final-common-audits-namespace-v1';PRIOR=Q/'validated-common-kernel14881-prior-v1'
NS=Q/'final-common-kernel-typed-namespace-v1';ENV=R/'scoped/build/current52-public-environment-OO.json'
STATUS='PASS_ACTUAL_SAME_COMMON_OBJECTS_26_KERNEL_TYPED_ROOTS_30_WRITTEN_ROWS'
def cutoff():
 m.need(datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(m.read(B/'SESSION_PLAN.json')['proof_work_cutoff_utc']),'No new metadata work after proof cutoff')
def identities(inner):
 rows=[dict(module=r['module'],source_sha256=r['source_sha256'],object_sha256=r['files']['object']['sha256']) for r in inner['records']]
 m.need(len(rows)==len({r['module'] for r in rows})==14881,'Exact same complete application object universe')
 return sorted(rows,key=lambda r:r['module'])
def worker():
 cutoff();m.need(m.sha(TASK/'SOURCE_LOCK.json')=='6eca9e821829496900e8c64ee40b63497ca0bc1c0445b638a77dccc1f46038bb','Frozen metadata-only audit selections')
 m.need(m.sha(BASE/'SOURCE_LOCK.json')=='e0262eb3fd346d31c896e54ed88c0fb0a7b66b82609aa5c2d867e61e5cf1c26a','Frozen actual common source task')
 m.need(m.sha(TASK/'KERNEL_ROOT_PREPARATION.json')=='f07f7d5ddac27059bb69033879d909fa9f1f5d7e23caa74536d97a95b5312492','Frozen exact30 written kernel preparation before execution')
 old=m.read(BASE/'SOURCE_LOCK.json');new=m.read(TASK/'SOURCE_LOCK.json');prep=m.read(TASK/'KERNEL_ROOT_PREPARATION.json')
 names=prep['added_compiler_roots'];written=prep['written_kernel_rows'];m.need({r['root'] for r in written}==set(names),'Exact written-to-compiler kernel mapping');keys={(r['file'],r['line'],r['original']) for r in written}
 m.need(len(written)==len(keys)==30 and len(names)==len(set(names))==26 and all(r['preserve_kernel_path'] is True and r['role']=='intentional_kernel_only_baseline_or_helper' and r['root']==r['original'] for r in written),'All30 exact preserved written identities,26 compiler roots')
 m.need(new['sources']==old['sources'] and new['payloads']==old['payloads'] and new['root_modules']==old['root_modules'] and set(new['roots'])==set(old['roots'])|set(names) and len(new['roots'])==20570,'Only existing typed audit selections change')
 for path,digest in [('prepare_completed_parent_v5.py','20aea653089d66283c987a5484f7f279cd66db0e9215895a8b008233d9157495'),('engine-v5/engine_v3.py','6a19523cbf29935980b33c106760220e893db83864a31c658825b76c73466986')]:m.need(m.sha(Q/path)==digest,'Existing actual source validation/audit engine unchanged')
 seed=Q/'validated-research14878-parent-normal-v1'
 command=[sys.executable,'-I','-B',str(Q/'prepare_completed_parent_v5.py'),'--base-task',str(BASE),'--task',str(TASK),'--environment',str(ENV),'--parent',str(PARENT),'--seed-root',str(seed),'--seed-checkpoint',str(seed/'CHECKPOINT.json'),'--out',str(PRIOR)]
 with (OUT/'parent.stdout').open('wb') as so,(OUT/'parent.stderr').open('wb') as se:p=subprocess.run(command,stdout=so,stderr=se)
 m.need(p.returncode==0,'Actual full common source/object parent validated for audit-only extension')
 receipt=m.read(PRIOR/'PREPARATION_RECEIPT.json');m.need(receipt['parent_modules']==14881 and receipt['task_modules']==14881 and receipt['new_sources']==0,'Zero new scientific source modules')
 cutoff()
 command=[sys.executable,'-I','-B',str(Q/'launch_namespace_v5.py'),'--input',str(TASK),'--environment',str(ENV),'--engine',str(Q/'engine-v5'),'--prior',str(PRIOR),'--checkpoint',str(PRIOR/'CHECKPOINT.json'),'--out',str(NS),'--','/usr/bin/python3.10','-I','-B','/engine/engine_v3.py','run','--task','/task','--environment','/environment.json','--out','/out/run','--prior',str(PRIOR),'--checkpoint','/checkpoint.json','--jobs','1']
 m.atomic(OUT/'NAMESPACE_COMMAND.json',dict(command=command))
 with (OUT/'namespace.stdout').open('wb') as so,(OUT/'namespace.stderr').open('wb') as se:p=subprocess.run(command,stdout=so,stderr=se)
 m.need(p.returncode==0,'Actual isolated supplemental typed audit namespace exit0')
 m.need(m.sha(TASK/'KERNEL_ROOT_PREPARATION.json')=='f07f7d5ddac27059bb69033879d909fa9f1f5d7e23caa74536d97a95b5312492','Frozen exact30 written kernel preparation unchanged after execution')
 parent=m.read(PARENT/'data/run/RECEIPT.json');inner=m.read(NS/'data/run/RECEIPT.json');outer=m.read(NS/'RECEIPT.json')
 m.need(outer['status']=='PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE' and inner['status']=='PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS' and inner['source_modules']==inner['prior_modules']==14881 and inner['new_compilations']==0 and len(inner['audits'])==20570,'Fresh audit only, exact same source-built objects')
 bank=identities(parent);m.need(identities(inner)==bank,'All14881 actual common source/object identities preserved exactly')
 m.atomic(OUT/'COMMON_BANK_IDENTITY.json',bank)
 audit={r['name']:r for r in inner['audits']};m.need(len(audit)==20570 and all(r['type_repr'] and set(r['axioms'])<={'propext','Classical.choice','Quot.sound'} for r in audit.values()),'All20570 actual typed roots nonempty and Std3 only')
 typed={name:audit[name] for name in names};m.need(len(typed)==26,'Every26 selected existing kernel CI resolved')
 pins={}
 for path in [TASK/'SOURCE_LOCK.json',TASK/'KERNEL_ROOT_PREPARATION.json',BASE/'SOURCE_LOCK.json',PARENT/'RECEIPT.json',PARENT/'data/run/RECEIPT.json',PRIOR/'CHECKPOINT.json',PRIOR/'PREPARATION_RECEIPT.json',NS/'RECEIPT.json',NS/'data/run/RECEIPT.json',NS/'data/run/Audit.lean',NS/'REQUEST.json',NS/'INPUTS.json',NS/'data/NAMESPACE_PROBE.json',ENV,Q/'engine-v5/engine_v3.py',Q/'prepare_completed_parent_v5.py',Q/'launch_namespace_v5.py',Path(__file__),OUT/'COMMON_BANK_IDENTITY.json',OUT/'parent.stdout',OUT/'parent.stderr',OUT/'NAMESPACE_COMMAND.json']:
  pins[str(path)]=m.sha(path)
 m.atomic(OUT/'READBACK.json',dict(schema=1,status='ACTUAL_SUPPLEMENTAL_TYPED_AUDIT_COMPLETE_PENDING_RESOURCE_DRAIN',common_namespace=str(PARENT),supplemental_namespace=str(NS),source_modules=14881,prior_modules=14881,new_scientific_compilations=0,original_selected_typed_roots=20544,supplemental_selected_typed_roots=20570,added_kernel_compiler_roots=names,written_kernel_rows=written,typed_roots_by_name=typed,same_complete_application_object_universe=True,bank_identity_path=str(OUT/'COMMON_BANK_IDENTITY.json'),input_pins=pins,qualification='Existing26 kernel CIs freshly selected in the unchanged existing RootAudit engine, not new mathematical statements/modules.30 written identities remain distinct. Source-bearing rows and all four context routes receive no fallback.'))
def main():
 cutoff();m.need(not OUT.exists(),'Fresh supplemental typed audit controller');OUT.mkdir()
 while True:
  cutoff();watch=m.read(B/'CUTOFF_WATCHDOG_LIVE.json')
  if any(r['pid']==os.getpid() for r in watch['controllers']):break
  time.sleep(1)
 stages.run_scope('research-final-common-kernel-typed-v1',32,4,3600,[sys.executable,'-I','-B',str(Path(__file__)),'--worker'])
 scopepath=R/'resources/research-final-common-kernel-typed-v1/scope.json';stages.check_scope(scopepath)
 result=m.read(OUT/'READBACK.json')
 for path,digest in result['input_pins'].items():m.need(m.sha(Path(path))==digest,'All actual supplemental source/object/namespace/compiler evidence unchanged')
 result['status']=STATUS;result['actual_resource_scope']=str(scopepath);result['actual_resource_exit_code']=0;result['actual_resource_cgroup_drained']=True;result['input_pins'][str(scopepath)]=m.sha(scopepath)
 m.atomic(B/'COMMON_KERNEL_TYPED_SIDECAR_V1.json',result)
 m.atomic(OUT/'RECEIPT.json',dict(status=STATUS,sidecar_sha256=m.sha(B/'COMMON_KERNEL_TYPED_SIDECAR_V1.json'),resource_scope_sha256=m.sha(scopepath),script_sha256=m.sha(Path(__file__))))
 stages.save('PASS_SUPPLEMENTAL_ACTUAL_KERNEL_TYPED_READOUT',written_rows=30,compiler_roots=26)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--worker',action='store_true');a=p.parse_args()
 try:worker() if a.worker else main()
 except Exception as error:
  if OUT.exists():stages.save('FAILED_PRESERVED_NO_ACCEPTANCE',error=str(error))
  raise
