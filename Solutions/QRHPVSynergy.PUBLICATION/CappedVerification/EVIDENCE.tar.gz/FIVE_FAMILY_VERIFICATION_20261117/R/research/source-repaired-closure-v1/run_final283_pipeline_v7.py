"""Wait for all five genuine source namespaces, then run final modes in guards."""
from pathlib import Path
import datetime,importlib.util,json,os,subprocess,sys,time
Q=Path(__file__).resolve().parent;R=Q.parents[1]
s=importlib.util.spec_from_file_location('stages',Q/'run_final_common_pipeline_v1.py')
stages=importlib.util.module_from_spec(s);s.loader.exec_module(stages);m=stages.m
OUT=Q/'final283-pipeline-v3'
def save(stage,**fields):m.atomic(OUT/'LIVE.json',dict(stage=stage,pid=os.getpid(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**fields))
def main():
 m.need(not OUT.exists(),'fresh final pipeline');OUT.mkdir()
 pins={'read_kernel_typed_sidecar_v5.py':'27ecc576126f2510055af675bb178a388b2f6cc3d564c01487ca90ac9efee52c','freeze_isolated283_v8.py':'2c7a4942a4e2011429f451c406a6e874aa421966831c5ce7a5085620eda30d61','run_isolated283_controls_v8.py':'62acfbaaf442a118e52e8e7cb6e858d11b94d406b219ea2470b1ecb2360cc9a3','FINAL283_EXECUTION_MANIFEST_V2.json':'c42f777e78c2cb22160077f3c422377574a353d3321ed7558a2ef7c3771427b9'}
 for name,digest in pins.items():m.need(m.sha(Q/name)==digest,'frozen final execution component '+name)
 receipts=[Q/'final-common-pipeline-v1/RECEIPT.json',Q/'numerics-final-contexts-v1/execution-v1/RECEIPT.json']
 while not all(p.exists() for p in receipts):
  for directory in [Q/'final-common-pipeline-v1',Q/'numerics-final-contexts-v1/execution-v1']:
   p=directory/'LIVE.json'
   if p.exists():m.need(m.read(p)['stage']!='FAILED_PRESERVED_NO_ACCEPTANCE','a prerequisite pipeline failed; preserve and repair it before final gate')
  save('WAIT_ACTUAL_COMMON_AND_FOUR_CONTEXTS',ready=[str(p) for p in receipts if p.exists()]);time.sleep(30)
 m.need(m.read(receipts[0])['status']=='PASS_ACTUAL14878_PARENT_AND_14881_COMMON_AUDIT_NAMESPACE','actual common auditor pipeline accepted')
 m.need(m.read(receipts[1])['status']=='PASS_FOUR_ACTUAL_ISOLATED_CONTEXTS_PUBLIC_INTERFACES_AND_WRITTEN_AUDITS','all four actual separate context/interface pipelines accepted')
 for route in m.read(Q/'FINAL283_EXECUTION_MANIFEST_V2.json')['routes']:
  stages.check_scope(R/route['resource']/'scope.json')
 running={};results=[];pending=['normal','O','OO']
 while pending or running:
  while pending and stages.capacity(16):
   mode=pending.pop(0);scope=R/'resources'/('research-final283-controls-'+mode.lower()+'-v2');m.need(not scope.exists(),'fresh actual final mode scope')
   cmd=[sys.executable,'-I','-B',str(R/'scripts/resource_scope_v3.py'),'--family','root_generic','--memory-gib','16','--cpus','2','--wall','28800','--out',str(scope),'--',sys.executable,*({'normal':[],'O':['-O'],'OO':['-OO']}[mode]),'-I','-B',str(Q/'run_isolated283_controls_v8.py'),'--mode',mode]
   m.atomic(OUT/(mode+'-REQUEST.json'),dict(command=cmd))
   so=(OUT/(mode+'.stdout')).open('wb');se=(OUT/(mode+'.stderr')).open('wb');p=subprocess.Popen(cmd,stdout=so,stderr=se);running[mode]=(p,scope,so,se)
   # Wait for the authoritative allocator's actual reservation before estimating
   # headroom for another independent guarded mode. No guessed delay is consent.
   while p.poll() is None:
    registry=R/'evidence/ACTIVE_RUNS.json'
    leases=m.read(registry) if registry.exists() else []
    if any(row['launcher_pid']==p.pid for row in leases):break
    time.sleep(1)
  for mode,(p,scope,so,se) in list(running.items()):
   if p.poll() is None:continue
   so.close();se.close();m.need(p.returncode==0,'actual final mode exit0 '+mode);stages.check_scope(scope/'scope.json')
   receipt=Q/'isolated283-final-controls-v2'/mode/'RECEIPT.json';j=m.read(receipt);m.need(j['status']=='PASS_ACTUAL_FINAL283_FIVE_ROUTE_POSITIVE_AND_FOCUSED_NEGATIVES' and len(j['records'])==7 and j['python_optimization']=={'normal':0,'O':1,'OO':2}[mode],'actual five-route final positive and six focused negatives')
   results.append(dict(mode=mode,scope=str(scope),controls_receipt=str(receipt),controls_receipt_sha256=m.sha(receipt),positive_receipt=str(receipt.parent/'positive-all-five-routes-result/RECEIPT.json'),positive_receipt_sha256=m.sha(receipt.parent/'positive-all-five-routes-result/RECEIPT.json')));del running[mode]
  save('ACTUAL_FINAL283_MODES_EXECUTING',running={k:v[0].pid for k,v in running.items()},pending=pending,completed=[r['mode'] for r in results]);time.sleep(10)
 m.need({r['mode'] for r in results}=={'normal','O','OO'},'all optimization modes complete')
 for name,digest in pins.items():m.need(m.sha(Q/name)==digest,'final execution components unchanged')
 m.atomic(OUT/'RECEIPT.json',dict(status='PASS_ACTUAL_ISOLATED283_FULL_FIVE_ROUTE_GATES_ALL_MODES_AND_NEGATIVES',results=results,script_sha256=m.sha(Path(__file__)),input_pins=pins,qualification='Every actual namespace route and all283 exact written identities revalidated in normal/O/OO CLIs;250 source/generic propositions,32 intentional kernel baselines and1 unchanged datum remain distinct. Separate10newnetwork-adapter and reproducibility/publication stages remain separately reported.'))
 save('PASS_FINAL_ACTUAL283_ALL_MODES')
if __name__=='__main__':
 try:main()
 except Exception as e:
  if OUT.exists():save('FAILED_PRESERVED_NO_ACCEPTANCE',error=str(e))
  raise
