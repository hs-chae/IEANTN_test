"""Seal actual audit child evidence and exercise the strict reader in 0/O/OO."""
from pathlib import Path
import argparse,copy,importlib.util,json,os,subprocess,sys,time
Q=Path(__file__).resolve().parent;R=Q.parents[1];B=R/'research/capped-final-verification-20261117'
spec=importlib.util.spec_from_file_location('typed_reader',Q/'read_kernel_typed_sidecar_v5.py')
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader);m=reader.m
OUT=Q/'kernel-typed-seal-controls-v4'
STATUS='PASS_SEALED_ACTUAL_SAME_COMMON_OBJECTS_26_KERNEL_TYPED_ROOTS_30_WRITTEN_ROWS'
OPTIONS={'normal':[],'O':['-O'],'OO':['-OO']};OPT={'normal':0,'O':1,'OO':2}
def context():
 n=Q/'final-common-audits-namespace-v1';inner=m.read(n/'data/run/RECEIPT.json');prefix='RESEARCH_SUMMARY_EXACT_WRITTEN_ROOT '
 rows=[m.parse(line.split(prefix,1)[1]) for line in (n/'data/run/logs/SourceRepaired.ResearchCurrentAuditSummaryV2.stdout').read_text().splitlines() if prefix in line]
 return n,inner,[row for row in rows if row['preserve_kernel_path'] is True]
def validate(a):
 m.need(sys.flags.optimize==OPT[a.mode],'Actual strict sidecar reader CLI optimization')
 m.need(a.out.is_relative_to(OUT) and not a.out.exists(),'Fresh strict sidecar control output')
 ns,inner,rows=context();typed,evidence=reader.read(ns,inner,rows,a.sidecar)
 m.need(len(rows)==30 and len(typed)==26,'Exact all30 written kernel identities and26 typed CIs')
 m.atomic(a.out,dict(status='PASS_ACTUAL_STRICT_KERNEL_TYPED_READER_CONTROL',python_optimization=sys.flags.optimize,sidecar_sha256=m.sha(a.sidecar),source_evidence=evidence))
 print('PASS_ACTUAL_STRICT_KERNEL_TYPED_READER_CONTROL')
def main():
 m.need(not OUT.exists(),'Fresh strict supplemental typed readout seal/controls');OUT.mkdir()
 original=B/'COMMON_KERNEL_TYPED_SIDECAR_V1.json';data=m.read(original)
 m.need(data['status']=='PASS_ACTUAL_SAME_COMMON_OBJECTS_26_KERNEL_TYPED_ROOTS_30_WRITTEN_ROWS','Actual isolated typed audit completed')
 namespace=Path(data['supplemental_namespace']);actual=m.read(namespace/'data/run/RECEIPT.json');ar=actual['audit_record']
 m.need(ar['exit_code']==0 and all(k in ar['files'] for k in ['stdout','stderr','time']),'Actual complete active typed audit child')
 for item in ar['files'].values():
  p=namespace/'data/run'/m.relative(item['path']);m.need(m.sha(p)==item['sha256'],'Actual typed audit child bytes unchanged');data['input_pins'][str(p)]=m.sha(p)
 env=m.read(R/'scoped/build/current52-public-environment-OO.json');compiler=Path(env['compiler'])
 for p in [original,compiler,Q/'read_kernel_typed_sidecar_v5.py',Path(__file__)]:data['input_pins'][str(p)]=m.sha(p)
 data['bank_identity_sha256']=m.sha(Path(data['bank_identity_path']));data['status']=STATUS
 candidate=OUT/'CANDIDATE.json';m.atomic(candidate,data)
 expected={'missing-sidecar':'Required actual strict kernel typed sidecar exists','wrong-bank':'Exact same common bank identity hash','wrong-type':'Exact same-object actual nonempty kernel type and Std3','omitted-written-key':'Exact30 written preserved-kernel identities without collapse'}
 records=[]
 for mode in ['normal','O','OO']:
  directory=OUT/mode;directory.mkdir()
  for case in ['positive',*expected]:
   fixture=directory/(case+'-sidecar.json')
   if case=='positive':fixture=candidate
   elif case!='missing-sidecar':
    changed=copy.deepcopy(data)
    if case=='wrong-bank':changed['bank_identity_sha256']='0'*64
    elif case=='wrong-type':next(iter(changed['typed_roots_by_name'].values()))['type_repr']+=' FORGED_TYPE'
    else:changed['written_kernel_rows']=changed['written_kernel_rows'][:-1]
    m.atomic(fixture,changed)
   target=directory/(case+'-result.json')
   command=[sys.executable,*OPTIONS[mode],'-I','-B',str(Path(__file__)),'--validate','--mode',mode,'--sidecar',str(fixture),'--out',str(target)]
   started=time.monotonic();child=subprocess.run(command,capture_output=True,timeout=120);elapsed=time.monotonic()-started
   (directory/(case+'.stdout')).write_bytes(child.stdout);(directory/(case+'.stderr')).write_bytes(child.stderr)
   positive=case=='positive';m.need((child.returncode==0)==positive and target.exists()==positive,'Actual strict sidecar control intended result '+case)
   if not positive:m.need(child.returncode==1 and child.stdout==b'' and child.stderr.decode().splitlines()[-1]=='ValueError: '+expected[case],'Focused sidecar negative reaches exact intended guard '+case)
   records.append(dict(mode=mode,python_optimization=OPT[mode],case=case,command=command,exit_code=child.returncode,expected_success=positive,elapsed_seconds=elapsed,stdout_sha256=m.sha(directory/(case+'.stdout')),stderr_sha256=m.sha(directory/(case+'.stderr'))))
 m.need(len(records)==15,'Every actual new typed sidecar child route checked under0/O/OO')
 for path,digest in data['input_pins'].items():m.need(m.sha(Path(path))==digest,'Actual original namespace/source/audit evidence immutable')
 m.atomic(OUT/'RECEIPT.json',dict(status='PASS_ALL15_STRICT_KERNEL_SIDECAR_READER_POSITIVE_AND_FOCUSED_NEGATIVES_NORMAL_O_OO',records=records,reader_sha256=m.sha(Q/'read_kernel_typed_sidecar_v5.py'),script_sha256=m.sha(Path(__file__)),raw_sidecar_sha256=m.sha(original),qualification='Metadata-only exact same-object typed readout controls; original21 final283 cases remain separately mandatory.'))
 m.atomic(B/'COMMON_KERNEL_TYPED_SIDECAR_V2.json',data)
 print(STATUS,m.sha(B/'COMMON_KERNEL_TYPED_SIDECAR_V2.json'),m.sha(OUT/'RECEIPT.json'))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--validate',action='store_true');p.add_argument('--mode',choices=list(OPTIONS),default='normal');p.add_argument('--sidecar',type=Path);p.add_argument('--out',type=Path);a=p.parse_args()
 validate(a) if a.validate else main()
