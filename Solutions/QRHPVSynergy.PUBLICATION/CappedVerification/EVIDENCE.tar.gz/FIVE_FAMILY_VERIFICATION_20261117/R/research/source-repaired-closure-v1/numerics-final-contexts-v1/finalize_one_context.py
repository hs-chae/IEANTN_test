#!/usr/bin/env python3
"""Actual optimization-mode interface and isolated written-audit readback controls."""
from pathlib import Path
import argparse
import importlib.util
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("strict", HERE / "validate_readbacks.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ["namespace-root", "task", "old-export", "new-export", "gate", "readback", "out"]:
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--label", choices=["H01V1", "H02V1", "PublicMomentV1", "PublicVectorV1"], required=True)
    a = p.parse_args()
    out = a.out.resolve()
    v.need(out.is_relative_to(HERE) and not out.exists(), "Fresh context control outputs")
    out.mkdir()
    old = a.old_export.resolve()
    rows, gate_data, read_data = [], None, None
    for mode, flags in [(0, []), (1, ["-O"]), (2, ["-OO"])]:
        for case in ["positive", "type", "data", "missing-public"]:
            label = f"{mode}-interface-{case}"
            target = a.gate.resolve() if mode == 0 and case == "positive" else out / (label + ".json")
            command = [sys.executable, "-I", "-B", *flags, str(HERE / "interfaces/compare_interfaces.py"),
                "--old", str(old), "--new", str(a.new_export.resolve()), "--packet", str(a.task.resolve()),
                "--out", str(target)]
            if case != "positive":
                command.extend(["--negative-case", case])
            child = subprocess.run(command, capture_output=True, timeout=120)
            (out / (label + ".stdout")).write_bytes(child.stdout)
            (out / (label + ".stderr")).write_bytes(child.stderr)
            v.need((child.returncode == 0) == (case == "positive"), "Intended actual interface CLI result")
            v.need(target.exists() == (case == "positive"), "No receipt for invalid interface")
            if case == "positive":
                value = v.read(target)
                v.need(value["status"] == "PASS_ALL_RELOCATED_CONTEXT_PUBLIC_TYPES_AND_NONPROOF_DATA",
                       "Actual successful public type/data gate")
                if gate_data is not None:
                    v.need(value == gate_data, "Optimization-independent public interfaces")
                gate_data = value
            rows.append(dict(route="interface", mode=mode, case=case, command=command, exit_code=child.returncode,
                stdout_sha256=v.sha(out / (label + ".stdout")), stderr_sha256=v.sha(out / (label + ".stderr"))))
        label = f"{mode}-isolated-readback"
        target = a.readback.resolve() if mode == 0 else out / (label + ".json")
        command = [sys.executable, "-I", "-B", *flags, str(HERE / "validate_isolated_readbacks.py"),
            "--namespace-root", str(a.namespace_root.resolve()), "--task", str(a.task.resolve()),
            "--kind", a.label, "--out", str(target)]
        child = subprocess.run(command, capture_output=True, timeout=180)
        (out / (label + ".stdout")).write_bytes(child.stdout)
        (out / (label + ".stderr")).write_bytes(child.stderr)
        v.need(child.returncode == 0 and target.is_file(), "Actual isolated source-auditor readback")
        value = v.read(target)
        v.need(value["status"] == "PASS_ACTUAL_ISOLATED_CONTEXT_WRITTEN_SOURCE_AUDIT_READBACK", "Actual strict source readback")
        if read_data is not None:
            v.need(value == read_data, "Optimization-independent source-audit readback")
        read_data = value
        rows.append(dict(route="isolated-readback", mode=mode, case="positive", command=command, exit_code=child.returncode,
            stdout_sha256=v.sha(out / (label + ".stdout")), stderr_sha256=v.sha(out / (label + ".stderr"))))
    v.need(len(rows) == 15, "Every actual interface/readback route across normal/O/OO")
    record = dict(status="PASS_ACTUAL15_ISOLATED_CONTEXT_INTERFACE_AND_WRITTEN_READBACK_CONTROLS", label=a.label,
        records=rows, public_interface_receipt_sha256=v.sha(a.gate), isolated_readback_sha256=v.sha(a.readback),
        script_sha256=v.sha(Path(__file__)), qualification="Actual completed source-only namespace readbacks and public-interface comparisons; no primary experimental reclassification.")
    (out / "RECEIPT.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
    print(record["status"], a.label)


if __name__ == "__main__":
    main()
