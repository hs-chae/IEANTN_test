"""Continue only after genuine completed-parent acceptance and process drain."""
from pathlib import Path
import datetime,importlib.util,json,os,subprocess,sys,time
Q=Path(__file__).resolve().parent;R=Q.parents[1]
s=importlib.util.spec_from_file_location('engine',Q/'engine-v5/engine_v3.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
OUT=Q/'final-common-pipeline-v1'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(stage,**details):m.atomic(OUT/'LIVE.json',dict(stage=stage,utc=utc(),pid=os.getpid(),**details))
def alive(pid):
 try:return Path('/proc',str(pid),'stat').read_text().split()[2]!='Z'
 except FileNotFoundError:return False
def drained(scope):
 p=Path(scope['cgroup'])/'cgroup.procs'
 return not p.exists() or not p.read_text().strip()
def check_scope(path):
 j=m.read(path);m.need(j['exit_code']==0,'actual guarded command exit0')
 for x in j.get('samples',[]):
  events=dict(line.split() for line in x.get('memory.events','').splitlines())
  m.need(all(int(events.get(k,'0'))==0 for k in ['oom','oom_kill']),'no actual cgroup OOM')
 m.need(drained(j),'actual child cgroup drained');return j
def capacity(memory):
 p=R/'evidence/ACTIVE_RUNS.json';rows=m.read(p) if p.exists() else []
 return sum(r['memory_bytes'] for r in rows if alive(r['launcher_pid']))+memory*1024**3<=300*1024**3
def run_scope(tag,memory,cpus,wall,command):
 dest=R/'resources'/tag;m.need(not dest.exists(),'fresh guarded stage '+tag)
 while not capacity(memory):save('WAIT_ACTUAL_AGGREGATE_CAPACITY',next_stage=tag,memory_gib=memory);time.sleep(30)
 cmd=[sys.executable,'-I','-B',str(R/'scripts/resource_scope_v3.py'),'--family','root_generic','--memory-gib',str(memory),'--cpus',str(cpus),'--wall',str(wall),'--out',str(dest),'--',*command]
 m.atomic(OUT/(tag+'-REQUEST.json'),dict(command=cmd,utc=utc()))
 with (OUT/(tag+'.stdout')).open('wb') as so,(OUT/(tag+'.stderr')).open('wb') as se:
  p=subprocess.Popen(cmd,stdout=so,stderr=se)
  while p.poll() is None:save('GUARDED_STAGE_EXECUTING',stage_name=tag,launcher_pid=p.pid,memory_gib=memory);time.sleep(10)
 m.need(p.returncode==0,'guarded stage success '+tag);scope=check_scope(dest/'scope.json');return scope

def main():
 m.need(not OUT.exists(),'fresh detached pipeline');OUT.mkdir()
 pins={'prepare_completed_parent_v5.py':'20aea653089d66283c987a5484f7f279cd66db0e9215895a8b008233d9157495','prepare_final_audits_v1.py':'7508e0be9c4ebe812eba2f75c430c0fa6c3954816b4ae4cdffa13599e58a16e2','run_final_parent_readback_v1.py':'1b03a4d65b825387e5d743272f2c2c17aa311853f03272aa0fb2835f092ef7c5','engine-v5/engine_v3.py':'6a19523cbf29935980b33c106760220e893db83864a31c658825b76c73466986'}
 for name,digest in pins.items():m.need(m.sha(Q/name)==digest,'frozen pipeline component '+name)
 m.need(m.read(Q/'completed-parent-v5-controls-v1/RECEIPT.json')['status']=='PASS_ACTUAL_V5_NAMESPACE_PARENT_APPEND_AND_NEGATIVES_ALL_OPTIMIZATION_MODES','actual15CLI adapter controls')
 parent_scope=R/'resources/research-final-source-replay-v1/scope.json'
 while not parent_scope.exists() or alive(2532008):
  progress=Q/'final-research-namespace-v1/data/run/PROGRESS.json'
  save('WAIT_ACTUAL_PARENT_COMPLETION',parent_launcher_pid=2532008,parent_launcher_alive=alive(2532008),progress=m.read(progress) if progress.exists() else None);time.sleep(30)
 check_scope(parent_scope)
 run_scope('research-final14878-parent-readback-v1',8,4,7200,[sys.executable,'-I','-B',str(Q/'run_final_parent_readback_v1.py')])
 parent=Q/'validated-research14878-parent-normal-v1';task=Q/'final-common-audits-task-v1';env=R/'scoped/build/current52-public-environment-OO.json';namespace=Q/'final-common-audits-namespace-v1'
 command=[sys.executable,'-I','-B',str(Q/'launch_namespace_v5.py'),'--input',str(task),'--environment',str(env),'--engine',str(Q/'engine-v5'),'--prior',str(parent),'--checkpoint',str(parent/'CHECKPOINT.json'),'--out',str(namespace),'--','/usr/bin/python3.10','-I','-B','/engine/engine_v3.py','run','--task','/task','--environment','/environment.json','--out','/out/run','--prior',str(parent),'--checkpoint','/checkpoint.json','--jobs','1']
 run_scope('research-final-common-audits-v1',192,16,28800,command)
 outer=m.read(namespace/'RECEIPT.json');inner=m.read(namespace/'data/run/RECEIPT.json')
 m.need(outer['status']=='PASS_ISOLATED_COMMAND_NOT_MATHEMATICAL_ACCEPTANCE' and inner['source_modules']==14881 and inner['prior_modules']==14878 and inner['new_compilations']==3 and len(inner['audits'])==20544,'actual final common audit namespace populations')
 save('PASS_ACTUAL_ISOLATED_COMMON_AUDITS_PARENT_READY',namespace=str(namespace),source_modules=14881,new_compilations=3,typed_roots=20544,namespace_receipt_sha256=m.sha(namespace/'RECEIPT.json'),engine_receipt_sha256=m.sha(namespace/'data/run/RECEIPT.json'))
 m.atomic(OUT/'RECEIPT.json',dict(status='PASS_ACTUAL14878_PARENT_AND_14881_COMMON_AUDIT_NAMESPACE',utc=utc(),namespace=str(namespace),parent_readback_receipt_sha256=m.sha(Q/'final-parent-readback-v1/RECEIPT.json'),namespace_receipt_sha256=m.sha(namespace/'RECEIPT.json'),engine_receipt_sha256=m.sha(namespace/'data/run/RECEIPT.json'),script_sha256=m.sha(Path(__file__)),qualification='Canonical shared source-only parent and its3fresh independent auditor modules accepted. Four separate context tasks and10newnetwork adapters remain separate mandatory gates.'))
if __name__=='__main__':
 try:main()
 except Exception as e:
  if OUT.exists():save('FAILED_PRESERVED_NO_ACCEPTANCE',error=str(e))
  raise
