/- Pure downstream transport from the supplied actual-source moment profile.
The sealed H02 mathematical proof and its original study outcome are preserved.
No source-program success or numerical output is introduced as a premise. -/
import IEANTN.Nodes.ThetaSourcePNT.v1.Conclusions
import SynergyPosthocTheta.Transport
open IEANTN Real
set_option autoImplicit false
set_option maxHeartbeats 400000
noncomputable section

theorem ThetaSourcePNT.v1.challenge_theta_profile
    (profile : MomentPNT.v2.early_both_profile) : ThetaSourcePNT.v1.theta_profile := by
  intro A anchor
  exact SynergyPosthocTheta.Transport.theta_from_psi_ray (by linarith)
    (profile A anchor).2

theorem ThetaSourcePNT.v1.challenge_theta_240
    (rounded : MomentPNT.v2.early_both_240) : ThetaSourcePNT.v1.theta_240 := by
  have theta := SynergyPosthocTheta.Transport.theta_from_psi_ray
    (by norm_num : (0 : ℝ) ≤ 240) rounded.2
  have cap : (9963192/1000000000:ℝ) + 16/exp ((240:ℝ)/4) ≤
      9963193/1000000000 := by
    have correction := SynergyPosthocTheta.Transport.correction_240
    norm_num only [show (240:ℝ)/4=60 by norm_num]
    linarith
  intro x hx
  have value := theta x hx
  simp only [pow_zero,mul_one] at value ⊢
  exact value.trans (mul_le_mul_of_nonneg_right cap (Real.rpow_nonneg (by
    have positive := exp_pos (240:ℝ)
    linarith) _))

#print axioms ThetaSourcePNT.v1.challenge_theta_profile
#print axioms ThetaSourcePNT.v1.challenge_theta_240
end
