#!/usr/bin/env python3
"""Canonical measurement hook: preserve command/I/O, transport only reviewed Lean allocator settings."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import os
import resource
import signal
import subprocess
import sys
import time
import uuid

POLICY_BINARY='76c786658fb8c9748bc73c29d83a13df4761b493bf8a5faa81d5a9ed11f20e5b'
POLICY_SOURCE='aa450ed0f3ecd1678e2e7c0aa07fd13393214dfa2dfd0388336b8c73112b37ac'
LANDRUN='846b8048bc29b990a92cc22fe87fac5303a9e85e4ca649f1d48630a03da58a9e'
SETTINGS=dict(MALLOC_MMAP_MAX_='0',MALLOC_ARENA_MAX='1',MALLOC_TOP_PAD_='68719476736',
    MALLOC_TRIM_THRESHOLD_='18446744073709551615',MIMALLOC_RESERVE_OS_MEMORY='64G',
    MIMALLOC_ARENA_EAGER_COMMIT='1')


def need(ok,message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    def pairs(items):
        result={}
        for key,value in items:
            need(key not in result,'duplicate JSON key');result[key]=value
        return result
    def finite(text):
        value=float(text);need(math.isfinite(value),'nonfinite JSON number');return value
    def bad(text):raise ValueError('nonfinite JSON constant '+text)
    return json.loads(path.read_text(),object_pairs_hook=pairs,parse_float=finite,parse_constant=bad)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--policy',type=Path,required=True)
    parser.add_argument('--receipts',type=Path,required=True)
    parser.add_argument('--phase',choices=['build','checker'],required=True)
    parser.add_argument('command',nargs=argparse.REMAINDER)
    args=parser.parse_args();command=args.command[1:] if args.command[:1]==['--'] else args.command
    need(command and sha(Path(command[0]))==LANDRUN,'exact unchanged canonical Landrun binary')
    separator=command.index('--');before,child=command[:separator],command[separator:]
    need(before[1:8]==['--best-effort','--ro','/','--rw','/dev','-ldd','-add-exec'],
         'exact canonical permission prefix')
    policy=read(args.policy);settings=policy['settings'];library=Path(settings['LD_PRELOAD'])
    need(policy['source_sha256']==POLICY_SOURCE and policy['library_sha256']==POLICY_BINARY
         and sha(library)==POLICY_BINARY,'exact independently reviewed generic allocation policy')
    need({name:settings[name] for name in SETTINGS}==SETTINGS and set(settings)==set(SETTINGS)|{'LD_PRELOAD'},
         'only six reviewed allocator variables and pinned policy library')
    env=dict(os.environ);added=[]
    if args.phase=='build':
        for name in [*SETTINGS,'LD_PRELOAD']:
            need(name not in before,'no duplicate canonical policy environment flag')
            added+=['--env',name];env[name]=settings[name]
    forwarded=before+added+child
    need(forwarded[:len(before)]==before and forwarded[len(before)+len(added):]==child,
         'unchanged filesystem/executable permissions and exact original child command')
    args.receipts.mkdir(parents=True,exist_ok=True)
    identifier=args.phase+'-'+uuid.uuid4().hex
    started=time.monotonic();usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
    # Inherit streams exactly: canonical lean4export stdout is the mathematical export.
    result=subprocess.run(forwarded,env=env,check=False)
    usage1=resource.getrusage(resource.RUSAGE_CHILDREN)
    record=dict(status='MEASURED_CANONICAL_PROCESS_POLICY_FORWARDING_NOT_A_VERIFIER_VERDICT',
        phase=args.phase,original_command=command,forwarded_command=forwarded,
        added_environment_names=[*SETTINGS,'LD_PRELOAD'] if args.phase=='build' else [],
        filesystem_or_executable_permissions_changed=False,canonical_tool_source_changed=False,
        policy_receipt_sha256=sha(args.policy),wrapper_sha256=sha(Path(__file__)),
        landrun_sha256=LANDRUN,policy_library_sha256=POLICY_BINARY,
        child_exit_code=result.returncode,seconds=time.monotonic()-started,
        largest_child_RSS_kib=usage1.ru_maxrss,
        child_user_seconds=usage1.ru_utime-usage0.ru_utime,
        child_system_seconds=usage1.ru_stime-usage0.ru_stime,
        qualification='Transport only already reviewed Lean compiler allocation-failure policy '
        'through existing canonical measurement hook. Generic process configuration only; '
        'no proof object, source, export bytes, syscall/host policy or native C program is changed. '
        'The canonical verifier itself must establish its own final verdict.')
    path=args.receipts/(identifier+'.json');temporary=path.with_suffix('.pending')
    temporary.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');temporary.replace(path)
    if result.returncode<0:
        os.kill(os.getpid(),-result.returncode)
    raise SystemExit(result.returncode)


if __name__=='__main__':
    main()
