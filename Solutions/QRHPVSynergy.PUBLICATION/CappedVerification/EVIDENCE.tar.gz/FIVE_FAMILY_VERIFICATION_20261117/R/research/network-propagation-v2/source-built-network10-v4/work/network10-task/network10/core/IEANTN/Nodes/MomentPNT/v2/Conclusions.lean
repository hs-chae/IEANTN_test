/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import IEANTN.Vocabulary.PowerError

namespace MomentPNT.v2
open IEANTN Real

/-- The coefficient from the same source-derived mass and first moment, using
an80-log count anchor. The full family is valid for every A at least240. -/
noncomputable def earlyCoefficient (A : ℝ) : ℝ :=
  (1 + 1 / 1000000000) *
    (1 / 1000000000 +
      A * ((A - 240) * (6330434505 / 1000000000000) +
        520404202477 / 1000000000000) / ((A - 77) * (A - 163)) +
      ((1 / 250000) * A / (A - 160) + 1 / 50000000 +
        (1 / 10000000000) * A / (A - 640 / 3) + 1 / 1000000000000)) +
    1 / 1000000000000 + 1 / 100000000

/-- Exact paired330 plus source-mass future coefficient. This is distinct from
and is not asserted to dominate the first-moment coefficient for all A. -/
noncomputable def pairedMassCoefficient (A : ℝ) : ℝ :=
  (1 + 1 / 1000000000) *
    (1 / 1000000000000 +
      (253 * ((8433850764 / 1000000000000) / (1 - 1 / 100000000)) +
        (A - 330) * (6330434505 / 1000000000000)) / (A - 77) +
      ((1 / 250000) * A / (A - 160) + 1 / 50000000 +
        (1 / 1000000000000) * A / (A - 880 / 3) + 1 / 1000000000000)) +
    1 / 1000000000000 + 1 / 100000000

/-- Both normalized errors on each entire ray starting at any exp A, A>=240.
Actual mass and first-moment reads supply the two numerical statistics. -/
def early_both_profile : Prop :=
  ∀ A : ℝ, 240 ≤ A →
    HasPowerLogBound Eπ (earlyCoefficient A) 0 (7 / 8) (exp A) ∧
    HasPowerLogBound Eψ (earlyCoefficient A) 0 (7 / 8) (exp A)

/-- Rounded exp240 consequence of the reusable profile. -/
def early_both_240 : Prop :=
  HasPowerLogBound Eπ (9963192 / 1000000000) 0 (7 / 8) (exp 240) ∧
  HasPowerLogBound Eψ (9963192 / 1000000000) 0 (7 / 8) (exp 240)

/-- Both errors from the actual paired330 and mass reads. -/
def paired_mass_both_profile : Prop :=
  ∀ A : ℝ, 330 ≤ A →
    HasPowerLogBound Eπ (pairedMassCoefficient A) 0 (7 / 8) (exp A) ∧
    HasPowerLogBound Eψ (pairedMassCoefficient A) 0 (7 / 8) (exp A)

/-- At least0.00002898*x^(7/8)/log x primes in the stated interval, x>=exp400.
This is a downstream consequence of the profile, not a new numerical discovery. -/
def paired_mass_prime_interval : Prop :=
  ∀ x : ℝ, exp 400 ≤ x →
    (1449 / 50000000 : ℝ) * x ^ ((7 : ℝ) / 8) / log x ≤
      primeCounting (x + (2 / 125 : ℝ) * x ^ ((7 : ℝ) / 8)) - primeCounting x

end MomentPNT.v2
