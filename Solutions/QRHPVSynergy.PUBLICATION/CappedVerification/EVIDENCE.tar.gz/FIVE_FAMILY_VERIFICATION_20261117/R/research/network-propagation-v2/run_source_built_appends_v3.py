#!/usr/bin/env python3
"""Append exact network proofs and the separate read/algebra supplement.

This controller has no large enclosing cgroup. Every child phase receives its
own aggregate-accounted resource scope. It waits for actual completed source
parents, never a warm object directory or a planned receipt.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import time

B = Path(__file__).resolve().parent
R = B.parents[1]
M = R/'research/complete-clean-reproduction-v1'
Q = R/'research/source-repaired-closure-v1'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


master = load('source_built_research_master', M/'reproduce_research_v3.py')
f = master.f

# Session-only orchestration repair: no proof source or resource-policy changes.
from datetime import datetime, timezone
PROOF_CUTOFF = datetime(2026, 11, 17, 13, 38, 49, tzinfo=timezone.utc)

class CappedResearch(master.Research):
    def execute(self, label, command, memory=8, cpus=4, wall=7200, native=False):
        remaining = int((PROOF_CUTOFF - datetime.now(timezone.utc)).total_seconds())
        f.need(remaining > 0, 'owner proof-work cutoff reached before phase admission')
        return super().execute(label, command, memory=memory, cpus=cpus,
                               wall=min(wall, 86400, remaining), native=native)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--environment', type=Path, required=True)
    parser.add_argument('--parent-task', type=Path, required=True)
    parser.add_argument('--parent-namespace', type=Path, required=True)
    parser.add_argument('--parent-seed', type=Path, required=True)
    parser.add_argument('--parent-resource', type=Path, required=True)
    parser.add_argument('--parent-pipeline-receipt', type=Path, required=True)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--late-out', type=Path)
    parser.add_argument('--check-inputs', action='store_true')
    parser.add_argument('--wait', action='store_true')
    args = parser.parse_args()
    plan = f.read(B/'SOURCE_BUILT_APPEND_PLAN_V2.json')
    plan_sha = f.sha(B/'SOURCE_BUILT_APPEND_PLAN_V2.json')
    controller_sha = f.sha(Path(__file__))
    def frozen():
        f.need(f.sha(Path(__file__)) == controller_sha, 'unchanged additive capped controller source')
        f.need(f.sha(B/'SOURCE_BUILT_APPEND_PLAN_V2.json') == plan_sha, 'unchanged frozen append plan')
        for row in plan['code_inputs']:
            f.need(f.sha(R/row['path']) == row['sha256'], 'frozen controller input '+row['path'])
    frozen()
    f.need(2 == plan['version'], 'append plan version')
    parent_lock = f.read(args.parent_task/'SOURCE_LOCK.json')
    f.need(f.sha(args.parent_task/'SOURCE_LOCK.json') == plan['common_source_lock_sha256'],
           'exact reviewed common14881 source task')
    f.need(len(parent_lock['sources']) == 14881 and len(parent_lock['roots']) == 20544,
           'exact source-built parent population')
    env = f.read(args.environment)
    f.need(f.sha(Path(env['compiler'])) == parent_lock['compiler_sha256'], 'same pinned compiler')
    if args.check_inputs:
        f.need(args.out is None and args.late_out is None and not args.wait,
               'input check creates neither acceptance nor waiting job')
        print(json.dumps(dict(status='PASS_NETWORK10_LATE3_CONTROLLER_INPUTS_ONLY',
                              source_built_parent_completed=False, proof_execution=False)))
        return
    f.need(args.out is not None and args.late_out is not None, 'fresh output directories required')
    out, late = args.out.resolve(), args.late_out.resolve()
    f.need(out.is_relative_to(B) and late.is_relative_to(M) and not out.exists() and not late.exists(),
           'fresh disjoint experiment-owned append outputs')
    f.need(not out.is_relative_to(late) and not late.is_relative_to(out), 'independent output roots')
    out.mkdir(parents=True)
    f.atomic(out/'LAUNCH.json', dict(status='WAITING_FOR_ACTUAL14881_PARENT', pid=os.getpid(),
        plan_sha256=f.sha(B/'SOURCE_BUILT_APPEND_PLAN_V2.json'),
        parent_pipeline_receipt=str(args.parent_pipeline_receipt),
        planned_network_sources=14889, planned_network_roots=20554,
        planned_late_sources=14892, planned_late_roots=20562))
    while not args.parent_pipeline_receipt.exists():
        f.need(args.wait, 'actual completed parent receipt does not yet exist')
        if (out/'STOP_REQUESTED').exists():
            f.atomic(out/'STOPPED.json', dict(status='STOPPED_BEFORE_PROOF_ADMISSION',
                                            mathematical_acceptance=False))
            return
        time.sleep(20)
    frozen()
    parent = f.read(args.parent_pipeline_receipt)
    f.need(parent['status'] == 'PASS_ACTUAL14878_PARENT_AND_14881_COMMON_AUDIT_NAMESPACE',
           'actual complete common parent pipeline')
    resource = f.read(args.parent_resource/'scope.json')
    f.need(resource['exit_code'] == 0, 'parent resource completed successfully')
    running_path = args.parent_resource/'RUNNING.json'
    if running_path.exists():
        running = f.read(running_path)
        pid = running.get('launcher_pid')
        f.need(type(pid) is int and not Path('/proc', str(pid)).exists(), 'actual parent launcher drained')
    for key in ['sources', 'payloads']:
        identity = 'module' if key == 'sources' else 'path'
        f.need(len({row[identity] for row in parent_lock[key]}) == len(parent_lock[key]),
               'unique actual parent '+key)
    run = CappedResearch(B, args.environment, out, 2)
    run.runtime = R
    run.q = Q
    run.work = out/'work'
    run.work.mkdir()
    run.env = args.environment.resolve()
    run.common = args.parent_task.resolve()
    run.common_ns = args.parent_namespace.resolve()
    run.common_seed = args.parent_seed.resolve()
    frozen()
    run.network()
    frozen()
    expected = out/'expected-core'
    for node in ['MomentPNT.v2', 'SourceVectorPNT.v1', 'ThetaSourcePNT.v1']:
        path = Path('IEANTN/Nodes')/Path(node.replace('.', '/'))/'Challenge.lean'
        f.regular_copy(B/'stage/network'/path, expected/path)
    run.exact_network_types(source_root=expected)
    frozen()
    lock = f.read(run.network_task/'SOURCE_LOCK.json')
    f.need(len(lock['sources']) == 14889 and len(lock['roots']) == 20554,
           'complete exact14889/20554 network source population')
    f.atomic(out/'RECEIPT.json', dict(
        status='PASS_SOURCE_BUILT_NETWORK10_APPEND_AND_EXACT_CHALLENGE_TYPES',
        sources=14889, roots=20554, new_sources=8, new_roots=10,
        plan_sha256=f.sha(B/'SOURCE_BUILT_APPEND_PLAN_V2.json'), controller_sha256=controller_sha, commands=run.commands,
        source_lock_sha256=f.sha(run.network_task/'SOURCE_LOCK.json'),
        parent_pipeline_receipt_sha256=f.sha(args.parent_pipeline_receipt),
        parent_resource_sha256=f.sha(args.parent_resource/'scope.json'),
        namespace_receipt_sha256=f.sha(run.network_ns/'data/run/RECEIPT.json'),
        exact_type_receipt_sha256=f.sha(out/'NETWORK_EXACT_TYPES.json'),
        source_built_parent_validation=True, empty_application_bank=False,
        qualification='Eight fresh modules over an explicitly validated source-built14881 parent. '
        'All ten exact generated interfaces are checked separately from admitted Challenge templates. '
        'Canonical local Comparator/NanoDa and official network status remain separate.'))
    late.mkdir(parents=True)
    late_run = CappedResearch(B, args.environment, late, 1)
    late_run.runtime = R
    late_run.q = Q
    late_run.work = late/'work'
    late_run.work.mkdir()
    late_run.env = run.env
    late_run.network_task, late_run.network_ns, late_run.network_seed = (
        run.network_task, run.network_ns, run.network_seed)
    basis = R/'research/basis-tangent-source-v2/lean/SynergyTangentV2C'
    late_run.optional_basis_read_sources = {
        'SynergyTangentV2C.SourceRead': basis/'SourceRead.lean',
        'SynergyTangentV2C.SourceProgramRead': basis/'SourceProgramRead.lean'}
    frozen()
    late_run.late_algebra()
    frozen()
    f.atomic(late/'RECEIPT.json', dict(
        status='PASS_SOURCE_BUILT_LATE_BASIS_READ2_AND_PORTFOLIO1_APPEND',
        sources=14892, roots=20562, new_sources=3, new_roots=8,
        optional_basis_read_modules=2, optional_basis_read_roots=3,
        pure_portfolio_comparison_modules=1, pure_portfolio_comparison_roots=5,
        controller_sha256=controller_sha, commands=late_run.commands, network_receipt_sha256=f.sha(out/'RECEIPT.json'),
        qualification='Separate read identities and pure algebra. Frozen283 research rows and '
        'ten core conclusions are unchanged. This is a validated source-built chain, not a fresh empty bank.'))


if __name__ == '__main__':
    main()
