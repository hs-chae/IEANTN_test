/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import IEANTN.Vocabulary.PowerError

namespace SourceVectorPNT.v1
open IEANTN Real

/-- Whole-ray prime-counting bound from the actual unpaired U300 C++ output.
The numerical coefficient already existed as an ordinary-kernel control. -/
def source_pi : Prop :=
  HasPowerLogBound Eπ (8732871 / 1000000000) 0 (7 / 8) (exp 300)

/-- The same source-linked U300 and mass reads bound the Chebyshev error. -/
def source_psi : Prop :=
  HasPowerLogBound Eψ (8732871 / 1000000000) 0 (7 / 8) (exp 300)

/-- Exact vector-plus-mass future coefficient. The density profile anchor varies;
the separate count polynomial remains at its valid 300/100 anchor. -/
noncomputable def futureCoefficient (A : ℝ) : ℝ :=
  (1 + 1 / 1000000000) *
    (1 / 1000000000000 +
     (223 * (8724268952 / 1000000000000) +
       (A - 300) * (6330434505 / 1000000000000)) / (A - 77) +
     ((1 / 250000) * A / (A - 160) + 1 / 50000000 +
       (1 / 1000000000000) * A / (A - 880 / 3) + 1 / 1000000000000)) +
    1 / 1000000000000 + 1 / 100000000

/-- Both actual source statistics give this prime-error profile at every onset
A at least 300, with all fourteen mathematical inputs unchanged. -/
def source_future_pi : Prop :=
  ∀ A : ℝ, 300 ≤ A → HasPowerLogBound Eπ (futureCoefficient A) 0 (7 / 8) (exp A)

/-- The same exact profile also bounds the normalized Chebyshev error. -/
def source_future_psi : Prop :=
  ∀ A : ℝ, 300 ≤ A → HasPowerLogBound Eψ (futureCoefficient A) 0 (7 / 8) (exp A)

end SourceVectorPNT.v1
