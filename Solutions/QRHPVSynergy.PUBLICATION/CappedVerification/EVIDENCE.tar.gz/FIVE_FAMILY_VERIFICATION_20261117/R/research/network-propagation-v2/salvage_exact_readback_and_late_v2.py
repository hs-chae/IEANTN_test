#!/usr/bin/env python3
"""Resume exact interfaces and late proofs from the actual accepted14889 source graph."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import importlib.util

B = Path(__file__).resolve().parent
R = B.parents[1]
M = R / 'research/complete-clean-reproduction-v1'
Q = R / 'research/source-repaired-closure-v1'
spec = importlib.util.spec_from_file_location('exact_complete_view_master', M / 'reproduce_research_v7.py')
master = importlib.util.module_from_spec(spec)
spec.loader.exec_module(master)
f = master.f
CUTOFF = datetime(2026, 11, 17, 13, 38, 49, tzinfo=timezone.utc)


class CappedResearch(master.Research):
    def execute(self, label, command, memory=8, cpus=4, wall=7200, native=False):
        remaining = int((CUTOFF - datetime.now(timezone.utc)).total_seconds())
        f.need(remaining > 0, 'owner proof-work cutoff reached before phase admission')
        return super().execute(label, command, memory=memory, cpus=cpus,
                               wall=min(wall, 86400, remaining), native=native)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--environment', type=Path, required=True)
    p.add_argument('--accepted-network', type=Path, required=True)
    p.add_argument('--accepted-exact', type=Path, required=True)
    p.add_argument('--out', type=Path)
    p.add_argument('--late-out', type=Path)
    p.add_argument('--check-inputs', action='store_true')
    a = p.parse_args()
    old = a.accepted_network.resolve()
    f.need(old == B / 'source-built-network10-v4', 'exact actual accepted source graph')
    plan_path = B / 'SOURCE_BUILT_APPEND_PLAN_V2.json'
    plan = f.read(plan_path)
    pins = {Path(__file__): f.sha(Path(__file__)),
            M / 'reproduce_research_v7.py':
                '77d0a737d13a4362086c66d8d1fc375c8c45992da724a87e94eebee14e89f42b',
            M / 'foundation_v3.py': f.sha(M / 'foundation_v3.py'),
            plan_path: '6a795f4eb1fccdb8687227626046e3f216002fb993d35f726c3dbf0cd2effcb4'}
    for row in plan['code_inputs']:
        pins[R / row['path']] = row['sha256']

    def frozen():
        for path, pin in pins.items():
            f.need(f.sha(path) == pin, 'exact frozen resume/source-controller input ' + str(path))

    frozen()
    task = old / 'work/network10-task'
    namespace = old / 'work/network10-namespace'
    seed = old / 'work/common_to_network10-view'
    view = old / 'work/network10_full_readback-view'
    lock = f.read(task / 'SOURCE_LOCK.json')
    inner = f.read(namespace / 'data/run/RECEIPT.json')
    f.need(len(lock['sources']) == 14889 and len(lock['roots']) == 20554 and
           inner['status'] == 'PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS'
           and inner['source_modules'] == 14889 and len(inner['records']) == 8
           and len(inner['audits']) == 20554 and
           all(row['type_repr'] and set(row['axioms']) <= f.STD for row in inner['audits']),
           'actual eight fresh compiles and all20554 complete typed standard closures')
    for label in ['network10', 'network10_full_readback']:
        scope = f.read(old / 'resources' / label / 'scope.json')
        f.need(scope['exit_code'] == 0 and not Path(scope['cgroup']).exists(),
               'actual completed and drained source proof/readback ' + label)
    prep = f.read(view / 'PREPARATION_RECEIPT.json')
    cp = f.read(view / 'CHECKPOINT.json')
    f.need(prep['status'] == 'PASS_PREPARED_ACTUAL_COMPLETED_PARENT_AS_APPEND_PREFIX' and
           prep['parent_modules'] == prep['task_modules'] == 14889 and
           prep['new_sources'] == 0 and prep['checkpoint_sha256'] == f.sha(view / 'CHECKPOINT.json')
           and cp['source_lock_sha256'] == f.sha(task / 'SOURCE_LOCK.json'),
           'exact complete accepted actual source-built readback view')
    if a.check_inputs:
        f.need(a.out is None and a.late_out is None, 'input-only resume creates no acceptance')
        print('PASS_RESUME_ACTUAL14889_SOURCE_PARENT_INPUTS_ONLY_NOT_INTERFACE_ACCEPTANCE')
        return
    f.need(a.out is not None and a.late_out is not None, 'fresh separate exact/late outputs required')
    out, late = a.out.resolve(), a.late_out.resolve()
    f.need(out.is_relative_to(B) and late.is_relative_to(M) and not out.exists() and
           not late.exists() and not out.is_relative_to(late) and not late.is_relative_to(out),
           'fresh disjoint experiment-owned exact and late outputs')
    out.mkdir()
    run = CappedResearch(B, a.environment, out, 2)
    run.runtime, run.q, run.env = R, Q, a.environment.resolve()
    run.work = out / 'work'
    run.work.mkdir()
    run.network_task, run.network_ns, run.network_seed = task, namespace, seed
    run.network_full_view = view
    executed=a.accepted_exact.resolve()
    f.need(executed==B/'source-built-network10-v5','exact actual separate-view execution')
    exact_scope=executed/'resources/exact_source_built_network_types/scope.json'
    scope=f.read(exact_scope)
    f.need(scope['exit_code']==0 and not Path(scope['cgroup']).exists(),
        'actual completed and drained exact-type execution')
    stdout_path=executed/'resources/exact_source_built_network_types/stdout.txt'
    stderr_path=executed/'resources/exact_source_built_network_types/stderr.txt'
    f.need(stderr_path.read_bytes()==b'','actual exact-type execution stderr empty')
    actual=[line.split('EXACT_NETWORK_TYPE ',1)[1] for line in stdout_path.read_text().splitlines()
        if line.startswith('EXACT_NETWORK_TYPE ')]
    expected=f.read(B/'network10-extension-v1/EXTENSION.json')['roots']
    f.need(len(actual)==len(set(actual))==10 and set(actual)==set(expected),
        'all ten actual comparisons from the exact resource child stdout')
    object_view=executed/'EXPECTED_OBJECT_VIEW.json'
    bindings=f.read(object_view)
    f.need(bindings['status']=='PASS14889_SEPARATE_EXPECTED_OBJECT_VIEW_BINDINGS_NOT_INTERFACE_ACCEPTANCE'
        and bindings['source_lock_sha256']==f.sha(task/'SOURCE_LOCK.json')
        and len(bindings['objects'])==14889
        and {row['module'] for row in bindings['objects']}=={row['module'] for row in lock['sources']},
        'actual complete byte/source-pinned expected object view')
    frozen()
    f.atomic(out/'NETWORK_EXACT_TYPES.json',dict(status='PASS10_EXACT_SOURCE_BUILT_NETWORK_TYPES',
        roots=actual,expected_templates_are_interfaces_not_proofs=True,
        actual_proof_imports_selected_Challenge=False,official_receipt=False,
        actual_execution=str(executed),actual_scope_sha256=f.sha(exact_scope),
        actual_stdout_sha256=f.sha(stdout_path),actual_stderr_sha256=f.sha(stderr_path),
        object_view_bindings_sha256=f.sha(object_view),readback_controller_sha256=pins[Path(__file__)],
        qualification='Actual three expected interface compiles and all ten separate-environment exact type/universe comparisons ran with exit0 inV5. This fresh gate corrects only which recorded stdout file is parsed; no proof or object is recompiled.'))
    f.atomic(out / 'RECEIPT.json', dict(
        status='PASS_SOURCE_BUILT_NETWORK10_APPEND_AND_EXACT_CHALLENGE_TYPES',
        sources=14889, roots=20554, new_sources=8, new_roots=10,
        accepted_source_graph=str(old), source_lock_sha256=f.sha(task / 'SOURCE_LOCK.json'),
        source_namespace_receipt_sha256=f.sha(namespace / 'data/run/RECEIPT.json'),
        source_full_readback_sha256=f.sha(view / 'PREPARATION_RECEIPT.json'),
        exact_type_receipt_sha256=f.sha(out / 'NETWORK_EXACT_TYPES.json'),
        expected_object_view_sha256=f.sha(object_view), actual_execution_scope_sha256=f.sha(exact_scope),
        controller_sha256=pins[Path(__file__)], master_sha256=pins[M / 'reproduce_research_v7.py'],
        commands=run.commands, source_built_parent_validation=True,
        empty_application_bank=False, official_network_receipt=False,
        qualification='Eight fresh source compiles and full20554 audits were actually accepted inV4. '
        'This additive exact-interface phase uses a byte-checked separate complete object view. '
        'Actual proof namespace is unchanged; expected admitted templates are interface-only.'))
    late.mkdir()
    follow = CappedResearch(B, a.environment, late, 1)
    follow.runtime, follow.q, follow.env = R, Q, run.env
    follow.work = late / 'work'
    follow.work.mkdir()
    follow.network_task, follow.network_ns, follow.network_seed = task, namespace, seed
    basis = R / 'research/basis-tangent-source-v2/lean/SynergyTangentV2C'
    follow.optional_basis_read_sources = {
        'SynergyTangentV2C.SourceRead': basis / 'SourceRead.lean',
        'SynergyTangentV2C.SourceProgramRead': basis / 'SourceProgramRead.lean'}
    frozen()
    follow.late_algebra()
    frozen()
    f.atomic(late / 'RECEIPT.json', dict(
        status='PASS_SOURCE_BUILT_LATE_BASIS_READ2_AND_PORTFOLIO1_APPEND',
        sources=14892, roots=20562, new_sources=3, new_roots=8,
        optional_basis_read_modules=2, optional_basis_read_roots=3,
        pure_portfolio_comparison_modules=1, pure_portfolio_comparison_roots=5,
        network_receipt_sha256=f.sha(out / 'RECEIPT.json'), commands=follow.commands,
        actual_parent_namespace=str(namespace), expected_object_view_used_as_parent=False,
        qualification='Three actual source-only additions over the accepted real network graph. '
        'The separate expected-interface object view is never a late proof parent; frozen283 unchanged.'))


if __name__ == '__main__':
    main()
