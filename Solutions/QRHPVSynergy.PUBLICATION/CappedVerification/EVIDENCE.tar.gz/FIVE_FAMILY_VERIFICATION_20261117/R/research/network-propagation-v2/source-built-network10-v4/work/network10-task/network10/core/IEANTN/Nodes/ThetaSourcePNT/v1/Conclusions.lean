/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import IEANTN.Nodes.MomentPNT.v2.Conclusions

namespace ThetaSourcePNT.v1
open IEANTN Real

/-- Prime-power correction supplied by the sealed H02 mathematical transport. -/
noncomputable def coefficient (A : ℝ) : ℝ :=
  MomentPNT.v2.earlyCoefficient A + 16 / exp (A / 4)

/-- A whole-ray theta profile derived from the same both-error moment profile.
No bound is assumed at prime-power roots below the onset. -/
def theta_profile : Prop :=
  ∀ A : ℝ, 240 ≤ A →
    HasPowerLogBound Eθ (coefficient A) 0 (7 / 8) (exp A)

/-- Rounded exp240 corollary with the explicit prime-power correction. -/
def theta_240 : Prop :=
  HasPowerLogBound Eθ (9963193 / 1000000000) 0 (7 / 8) (exp 240)

end ThetaSourcePNT.v1
