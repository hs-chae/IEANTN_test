/- Exact four-conclusion source adapter; actual FinalProgram must be accepted.
No admitted Challenge is imported and no output is assumed. -/
import IEANTN.Nodes.MomentSourceInputs.v1.Conclusions
import IEANTN.Nodes.SourceVectorPNT.v1.Conclusions
import IEANTN.Nodes.PlattTrudgian.v1.Conclusions
import IEANTN.Nodes.OpenAIQRH.v1.Conclusions
import SourceRepaired.VectorCompleteV1

open MomentSourceInputs.v1
set_option maxHeartbeats 400000
set_option maxRecDepth 100000
noncomputable section

private theorem primary
    (low : low_zeta) (revers : revers_zeta) (mean : mollifier_mean_square)
    (smooth : source_smoothing) (right : source_right_moment)
    (rectangle : source_rectangle) (unsmooth : source_unsmoothing)
    (interpolation : source_interpolation) :
    WinnerNewHeightSource.PrimaryInputs (3681 / 10000) (3599 / 10000) :=
  ⟨low, revers, mean, smooth, right, rectangle, unsmooth, interpolation⟩

private theorem finite_rh (h : PlattTrudgian.v1.rh_up_to) :
    IEANTN.RiemannHypothesisUpTo WinnerOriginalScalars.height := by
  convert h using 1 <;> norm_num [PlattTrudgian.v1.rh_up_to, WinnerOriginalScalars.height]

section Inputs
variable
    (low : low_zeta) (revers : revers_zeta) (mean : mollifier_mean_square)
    (smooth : source_smoothing) (right : source_right_moment)
    (rectangle : source_rectangle) (unsmooth : source_unsmoothing)
    (interpolation : source_interpolation) (chj : original_chj)
    (rvm : ZeroCount.v1.rvm_error_bound) (small : ZeroCount.v1.rvm_error_small)
    (first : LowZeroes.v1.no_zeroes_below_first_ordinate)
    (rh : PlattTrudgian.v1.rh_up_to) (qrh : OpenAIQRH.v1.zeta_seven_eighths)

include low revers mean smooth right rectangle unsmooth interpolation chj rvm small first rh qrh

private theorem source_results :
    SourceVectorPNT.v1.source_pi ∧ SourceVectorPNT.v1.source_psi ∧
      SourceVectorPNT.v1.source_future_pi ∧ SourceVectorPNT.v1.source_future_psi := by
  let platform : ScopedIO.WorldIO.Platform := ⟨⟨0, 0, []⟩⟩
  let stream : ScopedIO.Stream := ⟨[], 0, false⟩
  obtain ⟨vectorTrace, vectorFinal, massTrace, massFinal, vectorExecution, massExecution,
      ant, future⟩ := SourceRepaired.VectorCompleteV1.actual.SynergyVectorC300.FinalProgram.source_pi_psi_and_future platform stream
    (primary low revers mean smooth right rectangle unsmooth interpolation)
    chj rvm small first (finite_rh rh) qrh
  refine ⟨ant.1, ant.2, ?_, ?_⟩
  · intro A anchor
    simpa only [SourceVectorPNT.v1.futureCoefficient,
      SynergyAnalytic.finitePNTCoefficient, SynergyAnalytic.vectorMassEnvelope,
      SynergyAnalytic.momentTail, SynergyVector300.rawUpper, SynergyVector300.Data.rawUpper,
      SynergyMomentMath.PNT300.massUpper, Int.cast_ofNat] using (future A anchor).1
  · intro A anchor
    simpa only [SourceVectorPNT.v1.futureCoefficient,
      SynergyAnalytic.finitePNTCoefficient, SynergyAnalytic.vectorMassEnvelope,
      SynergyAnalytic.momentTail, SynergyVector300.rawUpper, SynergyVector300.Data.rawUpper,
      SynergyMomentMath.PNT300.massUpper, Int.cast_ofNat] using (future A anchor).2

theorem SourceVectorPNT.v1.challenge_source_pi : SourceVectorPNT.v1.source_pi :=
  (source_results low revers mean smooth right rectangle unsmooth interpolation chj
    rvm small first rh qrh).1

theorem SourceVectorPNT.v1.challenge_source_psi : SourceVectorPNT.v1.source_psi :=
  (source_results low revers mean smooth right rectangle unsmooth interpolation chj
    rvm small first rh qrh).2.1

theorem SourceVectorPNT.v1.challenge_source_future_pi : SourceVectorPNT.v1.source_future_pi :=
  (source_results low revers mean smooth right rectangle unsmooth interpolation chj
    rvm small first rh qrh).2.2.1

theorem SourceVectorPNT.v1.challenge_source_future_psi : SourceVectorPNT.v1.source_future_psi :=
  (source_results low revers mean smooth right rectangle unsmooth interpolation chj
    rvm small first rh qrh).2.2.2

end Inputs
end

#print axioms SourceVectorPNT.v1.challenge_source_pi
#print axioms SourceVectorPNT.v1.challenge_source_psi
#print axioms SourceVectorPNT.v1.challenge_source_future_pi
#print axioms SourceVectorPNT.v1.challenge_source_future_psi
