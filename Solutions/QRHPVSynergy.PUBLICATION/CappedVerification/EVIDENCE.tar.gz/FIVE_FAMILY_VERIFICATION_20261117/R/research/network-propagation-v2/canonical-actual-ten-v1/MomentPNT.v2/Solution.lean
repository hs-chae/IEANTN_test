/- Additive exact graph adapter. Repaired source producers must pass the
independent numerical-source closure gate; this file has no admitted proof. -/
import IEANTN.Nodes.MomentPNT.v2.Conclusions
import IEANTN.Nodes.MomentSourceInputs.v1.Conclusions
import IEANTN.Nodes.PlattTrudgian.v1.Conclusions
import IEANTN.Nodes.OpenAIQRH.v1.Conclusions
import SourceRepaired.ResearchCurrentV1
open MomentSourceInputs.v1
set_option maxHeartbeats 400000
set_option maxRecDepth 100000
noncomputable section
private theorem primary
    (low : low_zeta) (revers : revers_zeta) (mean : mollifier_mean_square)
    (smooth : source_smoothing) (right : source_right_moment)
    (rectangle : source_rectangle) (unsmooth : source_unsmoothing)
    (interpolation : source_interpolation) :
    WinnerNewHeightSource.PrimaryInputs (3681 / 10000) (3599 / 10000) :=
  ⟨low, revers, mean, smooth, right, rectangle, unsmooth, interpolation⟩

private theorem finite_rh (h : PlattTrudgian.v1.rh_up_to) :
    IEANTN.RiemannHypothesisUpTo WinnerOriginalScalars.height := by
  convert h using 1 <;> norm_num [PlattTrudgian.v1.rh_up_to, WinnerOriginalScalars.height]

section Inputs
variable
    (low : low_zeta) (revers : revers_zeta) (mean : mollifier_mean_square)
    (smooth : source_smoothing) (right : source_right_moment)
    (rectangle : source_rectangle) (unsmooth : source_unsmoothing)
    (interpolation : source_interpolation) (chj : original_chj)
    (rvm : ZeroCount.v1.rvm_error_bound) (small : ZeroCount.v1.rvm_error_small)
    (first : LowZeroes.v1.no_zeroes_below_first_ordinate)
    (rh : PlattTrudgian.v1.rh_up_to) (qrh : OpenAIQRH.v1.zeta_seven_eighths)

include low revers mean smooth right rectangle unsmooth interpolation chj rvm small first rh qrh

private theorem early_result : MomentPNT.v2.early_both_profile := by
  let platform : ScopedIO.WorldIO.Platform := ⟨⟨0,0,[]⟩⟩
  let stream : ScopedIO.Stream := ⟨[],0,false⟩
  obtain ⟨mt,mf,nt,nf,mass,moment,both⟩ :=
    SourceRepaired.ResearchCurrentV1.actual.SynergyMomentCHi.Early240Profiles.source_pi_psi_profiles
      platform stream (primary low revers mean smooth right rectangle unsmooth interpolation)
      chj rvm small first (finite_rh rh) qrh
  intro A anchor
  simpa only [MomentPNT.v2.earlyCoefficient,SynergyEarly240.finitePNTCoefficient80,
    SynergyEarly240.momentTail80,SynergyAnalytic.momentEnvelope,
    SynergyMomentMath.PNT300.massUpper,SynergyMomentMath.PNT300.momentUpper]
    using both A anchor

private theorem paired_result : MomentPNT.v2.paired_mass_both_profile := by
  let platform : ScopedIO.WorldIO.Platform := ⟨⟨0,0,[]⟩⟩
  let stream : ScopedIO.Stream := ⟨[],0,false⟩
  obtain ⟨pt,pf,po,mt,mf,paired,mass,both,rounded,rich,strict⟩ :=
    SourceRepaired.ResearchCurrentV1.actual.SynergyMomentCHi.PairedMassProgram.source_both_and_prime_rich
      platform stream (primary low revers mean smooth right rectangle unsmooth interpolation)
      chj rvm small first (finite_rh rh) qrh
  intro A anchor
  simpa only [MomentPNT.v2.pairedMassCoefficient,SynergyAnalytic.sourceMassCoefficient,
    SynergyAnalytic.finitePNTCoefficient,SynergyAnalytic.massForwardEnvelope,
    SynergyAnalytic.momentTail] using both A anchor

theorem MomentPNT.v2.challenge_early_both_profile : MomentPNT.v2.early_both_profile :=
  early_result low revers mean smooth right rectangle unsmooth interpolation chj
    rvm small first rh qrh

theorem MomentPNT.v2.challenge_paired_mass_both_profile :
    MomentPNT.v2.paired_mass_both_profile :=
  paired_result low revers mean smooth right rectangle unsmooth interpolation chj
    rvm small first rh qrh

end Inputs

private theorem early_cap : MomentPNT.v2.earlyCoefficient 240 ≤
    (9963192/1000000000:ℝ) := by
  norm_num [MomentPNT.v2.earlyCoefficient]

theorem MomentPNT.v2.challenge_early_both_240
    (profile : MomentPNT.v2.early_both_profile) : MomentPNT.v2.early_both_240 := by
  have both := profile 240 (by norm_num)
  constructor
  · intro x hx
    have value := both.1 x hx
    simp only [pow_zero,mul_one] at value ⊢
    exact value.trans (mul_le_mul_of_nonneg_right early_cap (Real.rpow_nonneg (by
      have q:=Real.exp_pos (240:ℝ); linarith) _))
  · intro x hx
    have value := both.2 x hx
    simp only [pow_zero,mul_one] at value ⊢
    exact value.trans (mul_le_mul_of_nonneg_right early_cap (Real.rpow_nonneg (by
      have q:=Real.exp_pos (240:ℝ); linarith) _))

theorem MomentPNT.v2.challenge_paired_mass_prime_interval
    (profile : MomentPNT.v2.paired_mass_both_profile) :
    MomentPNT.v2.paired_mass_prime_interval := by
  have piProfile : SynergyAnalytic.SourceMassProfile := by
    intro A anchor
    simpa only [MomentPNT.v2.pairedMassCoefficient,SynergyAnalytic.sourceMassCoefficient,
      SynergyAnalytic.finitePNTCoefficient,SynergyAnalytic.massForwardEnvelope,
      SynergyAnalytic.momentTail] using (profile A anchor).1
  intro x hx
  exact SourceRepaired.ResearchCurrentV1.actual.SynergyAnalytic.source_mass_prime_rich_016
    piProfile hx

#print axioms MomentPNT.v2.challenge_early_both_profile
#print axioms MomentPNT.v2.challenge_early_both_240
#print axioms MomentPNT.v2.challenge_paired_mass_both_profile
#print axioms MomentPNT.v2.challenge_paired_mass_prime_interval
end
