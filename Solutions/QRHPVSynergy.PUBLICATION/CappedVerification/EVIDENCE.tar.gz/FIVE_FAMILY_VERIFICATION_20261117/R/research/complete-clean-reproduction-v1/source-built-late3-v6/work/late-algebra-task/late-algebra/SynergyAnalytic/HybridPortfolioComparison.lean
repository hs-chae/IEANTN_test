/- Supplemental comparison of the existing completed envelopes. This is ordinary
kernel mathematics, not a new numerical provider or a source-first PV program.
All four certified numerical interfaces and transfer allowances are unchanged. -/
import SynergyAnalytic.SourceStatisticProfiles

namespace SynergyAnalytic
open Real
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option maxRecDepth 100000
noncomputable section

theorem moment_mass_difference {C M0 M1 L : ℝ} (separated : 163 < L) :
    momentEnvelope M0 M1 L - massForwardEnvelope C M0 L =
      ((253 * M0 + M1 - 253 * C / (1 - 1 / 100000000)) * L +
        163 * 253 * C / (1 - 1 / 100000000) - 53790 * M0) /
        ((L - 77) * (L - 163)) := by
  have left : L - 77 ≠ 0 := by linarith
  have right : L - 163 ≠ 0 := by linarith
  unfold momentEnvelope massForwardEnvelope
  field_simp
  <;> ring

theorem vector_mass_difference (U C M L : ℝ) :
    vectorMassEnvelope U M L - massForwardEnvelope C M L =
      (223 * U - 253 * C / (1 - 1 / 100000000) + 30 * M) / (L - 77) := by
  unfold vectorMassEnvelope massForwardEnvelope
  ring

theorem source_mass_below_moment_to_600 {L : ℝ}
    (lower : 330 ≤ L) (upper : L ≤ 600) :
    massForwardEnvelope (8433850764 / 1000000000000)
      (6330434505 / 1000000000000) L <
    momentEnvelope (6330434505 / 1000000000000)
      (520404202477 / 1000000000000) L := by
  have slope : (253 * (6330434505 / 1000000000000 : ℝ) +
      520404202477 / 1000000000000 -
      253 * (8433850764 / 1000000000000) / (1 - 1 / 100000000)) < 0 := by
    norm_num
  have endpoint : (0 : ℝ) <
      (253 * (6330434505 / 1000000000000) + 520404202477 / 1000000000000 -
        253 * (8433850764 / 1000000000000) / (1 - 1 / 100000000)) * 600 +
        163 * 253 * (8433850764 / 1000000000000) / (1 - 1 / 100000000) -
        53790 * (6330434505 / 1000000000000) := by
    norm_num
  have numerator : (0 : ℝ) <
      (253 * (6330434505 / 1000000000000) + 520404202477 / 1000000000000 -
        253 * (8433850764 / 1000000000000) / (1 - 1 / 100000000)) * L +
        163 * 253 * (8433850764 / 1000000000000) / (1 - 1 / 100000000) -
        53790 * (6330434505 / 1000000000000) := by
    nlinarith
  apply sub_pos.mp
  rw [moment_mass_difference (by linarith : (163 : ℝ) < L)]
  exact div_pos numerator (mul_pos (by linarith) (by linarith))

theorem source_mass_below_vector {L : ℝ} (lower : 330 ≤ L) :
    massForwardEnvelope (8433850764 / 1000000000000)
      (6330434505 / 1000000000000) L <
    vectorMassEnvelope (8724268952 / 1000000000000)
      (6330434505 / 1000000000000) L := by
  apply sub_pos.mp
  rw [vector_mass_difference]
  apply div_pos _ (by linarith)
  norm_num

theorem source_hybrid_below_completed_portfolio {L : ℝ}
    (lower : 330 < L) (upper : L ≤ 600) :
    finitePNTCoefficient
      (massForwardEnvelope (8433850764 / 1000000000000)
        (6330434505 / 1000000000000) L) L <
    min (finitePNTCoefficient
      (momentEnvelope (6330434505 / 1000000000000)
        (520404202477 / 1000000000000) L) L)
      (min (finitePNTCoefficient
        (vectorMassEnvelope (8724268952 / 1000000000000)
          (6330434505 / 1000000000000) L) L)
        (rationalHeightCoefficient (8433850764 / 1000000000000) L)) := by
  apply lt_min
  · exact finitePNTCoefficient_strict (source_mass_below_moment_to_600 lower.le upper)
  · apply lt_min
    · exact finitePNTCoefficient_strict (source_mass_below_vector lower.le)
    · exact source_mass_profile_strict lower

#print axioms moment_mass_difference
#print axioms vector_mass_difference
#print axioms source_mass_below_moment_to_600
#print axioms source_mass_below_vector
#print axioms source_hybrid_below_completed_portfolio
end
end SynergyAnalytic
