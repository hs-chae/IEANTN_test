/- The source producer's selected value is exactly the three I objects read
from the actual C J array before the eight writes. -/
import SynergyTangentV2C.ProgramConsumer
namespace SynergyTangentV2C.SourceRead
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem represented_injective : Function.Injective CellExecute.represented := by
  intro a b h
  cases a
  cases b
  simp_all [CellExecute.represented,SynergyC.SourceIntervalMath.represented,
    SynergyC.ZeroBody.interval,SynergyC.Word512.value,SynergyC.Word512.word]

theorem payload_exact {value : MainFrames.Totals} (provider : ProgramConsumer.Payload value) :
    value = MainFooter.output := by
  have zeroEq := Option.some.inj
    (provider.readZero.symm.trans (MainFooter.read_zero MainPureBody.arena))
  have oneEq := Option.some.inj
    (provider.readOne.symm.trans (MainFooter.read_one MainPureBody.arena))
  have twoEq := Option.some.inj
    (provider.readTwo.symm.trans (MainFooter.read_two MainPureBody.arena))
  exact Prod.ext (represented_injective zeroEq)
    (Prod.ext (represented_injective oneEq) (represented_injective twoEq))

#print axioms represented_injective
#print axioms payload_exact
end SynergyTangentV2C.SourceRead
