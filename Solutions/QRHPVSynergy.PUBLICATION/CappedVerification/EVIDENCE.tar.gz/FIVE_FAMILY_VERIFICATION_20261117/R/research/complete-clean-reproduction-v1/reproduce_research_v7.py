#!/usr/bin/env python3
"""Sequential clean research controller; each phase has a separate recorded resource scope.

No application objects are distributed. A source-built prefix is reused only
after the pinned complete-parent validator has checked its entire provenance.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
import time

B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('foundation',B/'foundation_v3.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)


class Research(f.Run):
    def proof(self,label,task,seed=None,jobs=None,memory=192,cpus=16):
        namespace=self.work/(label+'-namespace')
        command=self.python(self.q/'launch_namespace_v5.py','--input',task,'--environment',self.env,
            '--engine',self.q/'engine-v5','--out',namespace)
        if seed is not None:command+=['--prior',str(seed),'--checkpoint',str(seed/'CHECKPOINT.json')]
        command+=['--','/usr/bin/python3.10','-I','-B','/engine/engine_v3.py','run',
            '--task','/task','--environment','/environment.json','--out','/out/run',
            '--jobs',str(jobs or self.jobs)]
        if seed is not None:command+=['--prior',str(seed),'--checkpoint','/checkpoint.json']
        scope=self.execute(label,command,memory=memory,cpus=cpus,wall=86400)
        inner=f.read(namespace/'data/run/RECEIPT.json')
        f.need(inner['status'] in ['PASS_EMPTY_APPLICATION_BANK_SOURCE_COLD_GRAPH',
            'PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS'],'actual source graph completion')
        f.need(all(row['type_repr'] and set(row['axioms'])<=f.STD for row in inner['audits']),
               'all selected root identities/types/standard axioms')
        return namespace,scope

    def frontier(self):
        common=self.q/'final-common-audits-task-v1'
        old=f.read(self.original_task/'SOURCE_LOCK.json');catalog=f.read(common/'SOURCE_LOCK.json')
        index={r['module']:r for r in catalog['sources']};originals={r['module'] for r in old['sources']}
        source=self.n/'lean/SynergyTangentV2C/FamilyProposal.lean'
        imports=re.findall(r'^import\s+(\S+)',source.read_text(),re.M);pending=list(imports);seen=set()
        while pending:
            name=pending.pop()
            if name in seen or name not in index:continue
            seen.add(name);pending+=index[name]['imports']
        names=seen-originals;f.need(len(names)==69,'exact data-free frontend import closure')
        literal_names={r['namespace'] for r in f.read(self.n/'family-plan-v1/FAMILY_API_V1.json')['rows']}
        f.need(names.isdisjoint(literal_names) and len(literal_names)==272,'no circular cell-data generation')
        utility=dict(module='SynergyTangentV2C.FamilyProposal',
            path='utilities/basis/SynergyTangentV2C/FamilyProposal.lean',source_root='utilities/basis',
            sha256=f.sha(source),bytes=source.stat().st_size,imports=imports)
        selected=[r for r in catalog['sources'] if r['module'] in names]+[utility]
        lock=dict(old);lock['sources']=old['sources']+selected
        lock['payloads']=catalog['payloads']
        lock['roots']=old['roots']+['SynergyTangentV2C.FamilyProposal.propose','SynergyTangentV2C.FamilyProposal.run']
        lock['root_modules']=old['root_modules']+['SynergyTangentV2C.FamilyProposal']
        holder=self.work/'frontier-schema';holder.mkdir()
        (holder/'SOURCE_LOCK.json').write_text(json.dumps(lock,indent=2)+'\n')
        task=self.work/'frontier-task'
        f.materialize_task(holder/'SOURCE_LOCK.json',[self.original_task,common],task,
                           {'SynergyTangentV2C.FamilyProposal':source})
        prior=self.parent('original_to_frontier',self.original_task,task,self.original_namespace)
        ns,_=self.proof('numeric_frontend',task,prior,jobs=4,memory=64,cpus=8)
        self.parent('frontier_complete_readback',task,task,ns,prior)
        raw=ns/'data/run/logs/SynergyTangentV2C.FamilyProposal.stdout'
        values=f.parse(raw.read_text())
        diagnostic=dict(classification='UNTRUSTED_NATIVE_DIAGNOSTIC_NO_NUMERICAL_THEOREM',
                        source_sha256=f.sha(source),exit_code=0)
        normalized=self.work/'fresh272proposal.jsonl'
        normalized.write_text(json.dumps(values)+'\n'+json.dumps(diagnostic)+'\n')
        f.need(f.sha(normalized)==f.sha(self.n/'family-input-controls-v1/valid.jsonl'),
               'all freshly computed fixed numerical data agree; only JSON spacing is normalized')
        self.execute('fresh_basis_proposal_schema',self.python(self.n/'prepare_family_v2.py',
            '--proposal',normalized,'--check-only'),memory=4)
        shutil.copyfile(normalized,self.n/'family-input-controls-v1/valid.jsonl')
        compiler=Path(f.read(self.env)['compiler']).with_name('clang')
        for mode in ['regenerate','native']:
            output=self.n/'reproduction-v2'/('clean-'+mode)
            self.execute('basis_'+mode,self.python(self.n/'reproduction-v2/reproduce.py',mode,
                '--compiler',compiler,'--out',output),memory=8,native=True)
        generated=self.n/'reproduction-v2/clean-regenerate/source-project'
        self.basis_generated=generated
        raw_sources={row['module']:generated/row['source']
            for row in f.read(self.n/'reproduction-v2/MANIFEST.json')['modules']}
        f.need(len(raw_sources)==351,'all351 regenerated component proof sources')
        canonical={row['module']:row for row in f.read(
            self.q/'final-common-audits-task-v1/SOURCE_LOCK.json')['sources']}
        self.basis_overrides={};self.optional_basis_read_sources={};diagnostic_delta=[]
        optional={'SynergyTangentV2C.SourceRead','SynergyTangentV2C.SourceProgramRead'}
        trailer='''
#print axioms ScopedIO.WorldSourceWith.pure_call
#print axioms ScopedIO.WorldSourceWith.legacy_call
#print axioms ScopedIO.WorldSourceWith.external_call
#print axioms ScopedIO.WorldSourceWith.installed_call
'''
        for name,source in raw_sources.items():
            if name not in canonical:
                f.need(name in optional,'only two declared optional read identities outside canonical349')
                self.optional_basis_read_sources[name]=source
                continue
            if f.sha(source)!=canonical[name]['sha256']:
                f.need(name=='ScopedIO.WorldSourceWith' and source.read_text().endswith(trailer),
                       'only four known trailing audit commands may differ')
                target=self.work/'diagnostic-only-source-rebinding/ScopedIO/WorldSourceWith.lean'
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_text(source.read_text()[:-len(trailer)])
                f.need(f.sha(target)==canonical[name]['sha256'],
                       'declarations/imports/proofs remain exact original source bytes')
                diagnostic_delta.append(dict(module=name,raw_sha256=f.sha(source),
                    canonical_sha256=f.sha(target),removed=trailer,mathematical_source_changed=False))
                source=target
            self.basis_overrides[name]=source
        f.need(len(self.basis_overrides)==349 and set(self.optional_basis_read_sources)==optional,
               '351component union =349canonical dependencies +2optional read modules')
        f.atomic(self.out/'BASIS_CANONICAL_SOURCE_RECONCILIATION.json',dict(
            regenerated_component_modules=351,canonical_dependency_modules=349,
            optional_read_modules=sorted(optional),diagnostic_only_delta=diagnostic_delta,
            original_10970_source_unchanged=True))
        f.atomic(self.out/'FRESH_BASIS_DATA_ASSOCIATION.json',dict(
            status='PASS_UNTRUSTED_FRESH272_PROPOSALS_AND351_SOURCE_REGENERATION',
            native_Lean_generation_is_untrusted=True,proposal_sha256=f.sha(normalized),
            actual_C_PV_authority=False,source_frontend_modules=11040,
            qualification='All actual C cells/model/read/ANT proof sources are independently compiled later.'))

    def native_research(self):
        compiler=Path(f.read(self.env)['compiler']).with_name('clang')
        moment=self.runtime/'research/moment-source-capsule-v4'
        target=self.work/'moment-native-regenerated'
        self.execute('height_mass_first_moment_native',self.python(moment/'reproduce_numerics.py',
            '--compiler',compiler,'--out',target),memory=8,native=True)
        f.need(f.read(target/'RECEIPT.json')['status']==
            'PASS_ALL_DETERMINISTIC_C_PROPOSALS_REGENERATED_AND_SOURCE_WORD_DATA_MATCHED',
            'actual height/mass/first-moment points and every prefix regenerated')
        vector=self.runtime/'research/vector-source-program-v1'
        self.execute('unpaired300_native',self.python(vector/'reproduce_cpp_v2.py',
            '--compiler',compiler,'--baseline',target/'height/run.stdout','--out',self.work/'vector-native'),
            memory=8,native=True)
        kernel=self.runtime/'research/direct-vector-source-capsule-v3'
        output=self.work/'fresh_kernel_vector_proposal'
        self.execute('kernel_vector_numerical_proposal',self.python(kernel/'regenerate_proposal.py',
            '--out',output),memory=4)
        data=output/'Data.lean'
        expected=next(row for row in f.read(self.q/'final-common-audits-task-v1/SOURCE_LOCK.json')['sources']
                      if row['module']=='SynergyVector300.Data')
        f.need(f.sha(data)==expected['sha256'],'fresh kernel-only vector data source matches fixed algorithm')
        self.basis_overrides['SynergyVector300.Data']=data

    def research(self):
        common_input=self.q/'final-common-audits-task-v1'
        canonical_schema=self.q/'final-replay-capsule-v1/SOURCE_LOCK.json'
        canonical=self.work/'canonical14878-task'
        f.materialize_task(canonical_schema,[self.original_task,common_input],canonical,self.basis_overrides)
        prior=self.parent('original_to_research',self.original_task,canonical,self.original_namespace)
        ns,scope=self.proof('research3908',canonical,prior)
        common=self.work/'common14881-task'
        f.materialize_task(common_input/'SOURCE_LOCK.json',[canonical,common_input],common)
        canonical_view=self.parent('canonical_to_common',canonical,common,ns,prior)
        common_ns,common_scope=self.proof('common_three_source_audits',common,canonical_view,jobs=1)
        common_view=self.parent('complete_common_readback',common,common,common_ns,canonical_view)
        self.canonical,self.canonical_ns,self.canonical_seed=canonical,ns,prior
        self.common,self.common_ns,self.common_seed=common,common_ns,canonical_view
        self.common_view=common_view
        self.routes=[dict(label='CurrentCommon',task=str(common),namespace=str(common_ns),
            prior_root=str(canonical_view),resource=str(common_scope))]
        policy=f.read(ns/'data/run/PROCESS_POLICY.json')
        settings=dict(policy['settings']);settings['LD_PRELOAD']=str(ns/'data/run/small_module_map_policy.so')
        f.need(f.sha(Path(settings['LD_PRELOAD']))==policy['library_sha256'],'fresh source-built generic allocation policy')
        dest=self.q/'separate-context-export-v4/RECEIPT.json'
        f.atomic(dest,dict(status='FRESH_REBUILT_PROCESS_POLICY_PATH_ASSOCIATION_NOT_PV',process_policy=settings,
            policy_source_sha256=policy['source_sha256'],library_sha256=policy['library_sha256'],
            source_receipt_sha256=f.sha(ns/'data/run/PROCESS_POLICY.json'),
            qualification='Only generic Lean compiler allocation policy; never supplied to native numerical applications.'))

    def contexts(self):
        h=self.q/'numerics-final-contexts-v1';interfaces=h/'interfaces'
        self.execute('interface_exporter_source',self.python(interfaces/'build_exporter_v3.py',
            '--out',interfaces/'build-v3'),memory=8)
        for item in f.read(h/'packets-v2/PACKETS.json')['packets']:
            label=item['label'];packet=self.runtime/item['path'];task=self.work/(label+'-task')
            f.materialize_task(packet/'SOURCE_LOCK.json',[self.canonical,packet],task)
            for source in (packet/'provenance').rglob('*'):
                if source.is_file():f.regular_copy(source,task/source.relative_to(packet))
            prior=self.parent(label+'_parent',self.canonical,task,self.canonical_ns,self.canonical_seed)
            ns,scope=self.proof(label+'_source',task,prior,jobs=1,memory=64,cpus=8)
            self.parent(label+'_complete',task,task,ns,prior)
            baseline=interfaces/(label+'-source-original')
            self.execute(label+'_original_source',self.python(interfaces/'build_original_baseline.py',
                '--packet',task,'--parent-namespace',self.canonical_ns,'--base-task',self.canonical,
                '--out',baseline),memory=64,cpus=8)
            old,new=interfaces/(label+'-old-export'),interfaces/(label+'-new-export')
            self.execute(label+'_old_interface',self.python(interfaces/'export_context_v5.py',
                '--label',label,'--role','old','--original-source-baseline',baseline,'--out',old),memory=64,cpus=8)
            self.execute(label+'_new_interface',self.python(interfaces/'export_context_v5.py',
                '--label',label,'--role','new','--namespace-root',ns,'--packet',task,'--out',new),memory=64,cpus=8)
            gate=interfaces/(label+'-public-interface.json');readback=h/(label+'-source-readback.json')
            self.execute(label+'_interface_and_source_gate',self.python(h/'finalize_one_context_v3.py',
                '--label',label,'--namespace-root',ns,'--task',task,'--old-export',old,
                '--new-export',new,'--gate',gate,'--readback',readback,
                '--out',h/(label+'-all-mode-controls')),memory=8,wall=7200)
            self.routes.append(dict(label=label,task=str(task),namespace=str(ns),prior_root=str(prior),
                resource=str(scope),public_interface_receipt=str(gate)))
        route_manifest=self.work/'ACTUAL283_ROUTES.json';f.atomic(route_manifest,dict(routes=self.routes))
        final=self.q/'clean-final283'
        self.execute('full283_source_readback',self.python(self.q/'freeze_isolated283_v3.py',
            '--manifest',route_manifest,'--out',final),memory=16,wall=86400)
        self.full283=final

    def network(self):
        utility=self.runtime/'research/network-propagation-v2'
        task=self.work/'network10-task'
        self.execute('materialize_network10',self.python(utility/'materialize_network10_v2.py',
            '--parent-task',self.common,'--out',task),memory=8)
        prior=self.parent('common_to_network10',self.common,task,self.common_ns,self.common_seed)
        ns,scope=self.proof('network10',task,prior,jobs=2,memory=192,cpus=8)
        self.parent('network10_full_readback',task,task,ns,prior)
        self.network_task,self.network_ns,self.network_seed=task,ns,prior
        self.network_scope=scope

    def exact_network_types(self, source_root=None):
        utility=self.runtime/'research/network-propagation-v2'
        source_root=source_root or utility/'expected-core'
        output=self.work/'expected-challenge-objects';output.mkdir()
        generic=[row['objects'] for row in f.read(self.env)['generic_dependencies']]
        compiler=Path(f.read(self.env)['compiler'])
        actual_policy=f.read(self.network_ns/'data/run/PROCESS_POLICY.json')
        policy=dict(actual_policy['settings'])
        policy['LD_PRELOAD']=str(self.network_ns/'data/run/small_module_map_policy.so')
        f.need(f.sha(Path(policy['LD_PRELOAD']))==actual_policy['library_sha256'],
               'same source-built namespace allocation policy for the exact-type checker')
        command_env=dict(os.environ,**policy,LEAN_SYSROOT=str(compiler.parent.parent),
            PATH=str(compiler.parent)+os.pathsep+os.environ.get('PATH',''),
            LEAN_PATH=':'.join([str(output),str(self.network_ns/'data/run/objects'),*generic]))
        # A partial IEANTN output prefix shadows other IEANTN search roots in Lean.
        # Derive a complete separate expected-object view from the accepted readback.
        view=getattr(self,'network_full_view',self.work/'network10_full_readback-view')
        preparation=f.read(view/'PREPARATION_RECEIPT.json')
        checkpoint=f.read(view/'CHECKPOINT.json')
        lock=f.read(self.network_task/'SOURCE_LOCK.json')
        f.need(preparation['status']=='PASS_PREPARED_ACTUAL_COMPLETED_PARENT_AS_APPEND_PREFIX'
            and preparation['parent_modules']==14889 and preparation['task_modules']==14889
            and preparation['new_sources']==0
            and preparation['checkpoint_sha256']==f.sha(view/'CHECKPOINT.json')
            and checkpoint['source_lock_sha256']==f.sha(self.network_task/'SOURCE_LOCK.json'),
            'complete accepted14889 source-built expected-view parent')
        source_index={row['module']:row for row in lock['sources']}
        records=checkpoint['records']
        f.need(len(source_index)==len(records)==14889 and
            {row['module'] for row in records}==set(source_index),
            'every actual source module belongs to the separate complete object view')
        object_rows=[]
        expected_modules={'IEANTN.Nodes.'+node+'.Challenge' for node in
            ['MomentPNT.v2','SourceVectorPNT.v1','ThetaSourcePNT.v1']}
        f.need(expected_modules.isdisjoint(source_index),
            'expected Challenge interfaces do not collide with actual proof modules')
        for record in records:
            name=record['module'];row=source_index[name]
            rel=Path('data/run/objects')/Path(name.replace('.','/')).with_suffix('.olean')
            obj=record['files']['object']
            f.need(record['source_sha256']==row['sha256'] and obj['path']==str(rel),
                'exact written source/module/object binding '+name)
            object_rows.append(dict(module=name,source=str(view/rel),
                target=str(output/Path(name.replace('.','/')).with_suffix('.olean')),
                object_sha256=obj['sha256'],source_sha256=row['sha256']))
        # This file is generated inside this one fresh work tree, not a source/theorem alteration.
        helper=self.work/'run_exact_network_types.py'
        helper.write_text('''from pathlib import Path
import os,subprocess,json
environment=dict(os.environ,**json.loads(Path(__file__).with_suffix('.env.json').read_text()))
commands=json.loads(Path(__file__).with_suffix('.commands.json').read_text())
import hashlib
plan=json.loads(Path(__file__).with_suffix('.bindings.json').read_text())
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as handle:
  for chunk in iter(lambda:handle.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
for path,pin in plan['parent_pins'].items():
 need(sha(Path(path))==pin,'unchanged exact expected-view parent evidence')
rows=plan['objects']
need(len(rows)==len({row['module'] for row in rows})==14889,'all unique expected-view object bindings')
for row in rows:
 source,target=Path(row['source']),Path(row['target'])
 need(source.is_file() and not source.is_symlink() and sha(source)==row['object_sha256'],
      'actual byte-checked source-built object '+row['module'])
 need(not target.exists(),'no expected-object collision '+row['module'])
 target.parent.mkdir(parents=True,exist_ok=True)
 os.link(source,target)
 need(target.samefile(source),'exact regular hard-linked expected object')
receipt=Path(plan['receipt'])
value=dict(status='PASS14889_SEPARATE_EXPECTED_OBJECT_VIEW_BINDINGS_NOT_INTERFACE_ACCEPTANCE',
 source_lock_sha256=plan['source_lock_sha256'],objects=rows,
 qualification='Only byte-checked accepted actual source-built objects; actual proof namespace unchanged. Three expected admitted interfaces are compiled separately afterward.')
temporary=receipt.with_suffix('.pending')
temporary.write_text(json.dumps(value,indent=2)+'\\n');temporary.replace(receipt)
for command in commands:
 result=subprocess.run(command,env=environment,check=False)
 if result.returncode!=0:raise RuntimeError('Exact source-built network type check failed')
''')
        commands=[]
        for node in ['MomentPNT.v2','SourceVectorPNT.v1','ThetaSourcePNT.v1']:
            module='IEANTN.Nodes.'+node+'.Challenge'
            path=Path(module.replace('.','/')).with_suffix('.lean')
            obj=output/Path(module.replace('.','/')).with_suffix('.olean');obj.parent.mkdir(parents=True,exist_ok=True)
            commands.append([str(compiler),'-j1','-R',str(source_root),str(source_root/path),'-o',str(obj)])
        for actual in ['MomentPNTV2Adapter','SourceVectorPNTRepairedAdapter','ThetaSourcePNTAdapter']:
            commands.append([str(compiler),'--run',str(utility/'lean/AuditExactNetworkV2.lean'),actual])
        public_overrides={name:command_env[name] for name in
            ['LEAN_SYSROOT','PATH','LEAN_PATH',*policy]}
        helper.with_suffix('.env.json').write_text(json.dumps(public_overrides)+'\n')
        helper.with_suffix('.commands.json').write_text(json.dumps(commands)+'\n')
        helper.with_suffix('.bindings.json').write_text(json.dumps(dict(
            objects=object_rows,receipt=str(self.out/'EXPECTED_OBJECT_VIEW.json'),
            source_lock_sha256=f.sha(self.network_task/'SOURCE_LOCK.json'),
            parent_pins={str(path):f.sha(path) for path in
                [view/'PREPARATION_RECEIPT.json',view/'CHECKPOINT.json',self.network_task/'SOURCE_LOCK.json']}))+'\n')
        self.execute('exact_source_built_network_types',self.python(helper),memory=192,cpus=4,wall=7200)
        stdout=(self.out/'resources/exact_source_built_network_types/stdout.txt').read_text()
        expected=f.read(utility/'network10-extension-v1/EXTENSION.json')['roots']
        actual=[line.split('EXACT_NETWORK_TYPE ',1)[1] for line in stdout.splitlines()
                if line.startswith('EXACT_NETWORK_TYPE ')]
        f.need(len(actual)==len(set(actual))==10 and set(actual)==set(expected),
               'all ten exact source-built interfaces, separate expected admitted templates')
        f.atomic(self.out/'NETWORK_EXACT_TYPES.json',dict(status='PASS10_EXACT_SOURCE_BUILT_NETWORK_TYPES',
            roots=actual,expected_templates_are_interfaces_not_proofs=True,
            actual_proof_imports_selected_Challenge=False,official_receipt=False))

    def late_algebra(self):
        source=self.runtime/'research/analytic/lean/SynergyAnalytic/HybridPortfolioComparison.lean'
        f.need(f.sha(source)=='25f924b032e706dc3c471887053d07a84da7e63b5a3a4c375057d66ae8016aa8',
               'exact separately accepted algebra supplement')
        lock=f.read(self.network_task/'SOURCE_LOCK.json')
        name='SynergyAnalytic.HybridPortfolioComparison'
        row=dict(module=name,path='late-algebra/'+name.replace('.','/')+'.lean',
            source_root='late-algebra',sha256=f.sha(source),bytes=source.stat().st_size,
            imports=re.findall(r'^import\s+(\S+)',source.read_text(),re.M))
        roots=['SynergyAnalytic.'+n for n in ['moment_mass_difference','vector_mass_difference',
            'source_mass_below_moment_to_600','source_mass_below_vector',
            'source_hybrid_below_completed_portfolio']]
        extra_rows=[]
        for module,actual in self.optional_basis_read_sources.items():
            extra_rows.append(dict(module=module,path='late-basis/'+module.replace('.','/')+'.lean',
                source_root='late-basis',sha256=f.sha(actual),bytes=actual.stat().st_size,
                imports=re.findall(r'^import\s+(\S+)',actual.read_text(),re.M)))
        extra_roots=['SynergyTangentV2C.SourceRead.represented_injective',
                     'SynergyTangentV2C.SourceRead.payload_exact',
                     'SynergyTangentV2C.SourceProgramRead.source_output_exact']
        lock['sources']=lock['sources']+extra_rows+[row];lock['roots']=lock['roots']+extra_roots+roots
        lock['root_modules']=lock['root_modules']+list(self.optional_basis_read_sources)+[name]
        schema=self.work/'late-algebra-schema';schema.mkdir()
        (schema/'SOURCE_LOCK.json').write_text(json.dumps(lock,indent=2)+'\n')
        task=self.work/'late-algebra-task'
        f.materialize_task(schema/'SOURCE_LOCK.json',[self.network_task],task,
                           {name:source,**self.optional_basis_read_sources})
        prior=self.parent('network_to_late_algebra',self.network_task,task,self.network_ns,self.network_seed)
        ns,_=self.proof('late_algebra',task,prior,jobs=1,memory=192,cpus=4)
        self.parent('late_algebra_full_readback',task,task,ns,prior)
        f.atomic(self.out/'LATE_ALGEBRA.json',dict(status='PASS_SEPARATE_SOURCE_ONLY_ALGEBRA_APPEND',
            sources=3,pure_algebra_sources=1,optional_basis_read_sources=2,
            roots=extra_roots+roots,frozen_283_and_10_core_conclusions_changed=False,
            mathematical_scope='S<U for A>=330; S<min(M,U,R) for330<A<=600',
            qualification='Pure algebra, not a new program, PV-exclusive claim or optimal crossing.'))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet',type=Path,required=True)
    parser.add_argument('--environment',type=Path,required=True)
    parser.add_argument('--out',type=Path)
    parser.add_argument('--jobs',type=int,default=8)
    parser.add_argument('--check-inputs',action='store_true')
    args=parser.parse_args();f.need(1<=args.jobs<=8,'bounded adequate proof concurrency')
    manifest,archive=f.packet_check(args.packet.resolve());env=f.read(args.environment)
    f.need(Path(env['compiler']).is_file(),'actual explicit pinned environment')
    if args.check_inputs:
        f.need(args.out is None,'input check creates no acceptance')
        print(json.dumps(dict(status='PASS_CLEAN_RESEARCH_CONTROLLER_SOURCE_INPUTS_NOT_EXECUTION',
            files=manifest['file_count'],whole_clean_run_executed=False)))
        return
    f.need(args.out is not None,'fresh owned clean output required')
    meminfo={line.split(':')[0]:int(line.split()[1])*1024
             for line in Path('/proc/meminfo').read_text().splitlines()}
    f.need(meminfo['MemAvailable']>=2**40 and shutil.disk_usage(f.R).free>=2**40,
           'full high-resource reproduction requires independently available RAM and disk of at least1TiB')
    run=Research(args.packet.resolve(),args.environment,args.out,args.jobs)
    run.initialize(manifest,archive)
    run.original();run.frontier();run.native_research();run.research();run.contexts();run.network()
    run.exact_network_types();run.late_algebra()
    f.atomic(run.out/'RECEIPT.json',dict(status='PASS_CLEAN_RESEARCH_SOURCE_BUILT283_AND_NETWORK10',
        commands=run.commands,seconds=time.monotonic()-run.started,
        application_object_inputs_at_start=[],source_built_original_modules=10970,
        research_modules=14881,selected_written_research_rows=283,network_conclusions=10,
        original_archive_sha256=f.ORIGINAL_SHA,untrusted_eval_proposals_have_no_proof_authority=True,
        separate_late_pure_algebra_modules=1,separate_late_pure_algebra_roots=5,
        separate_optional_basis_read_modules=2,separate_optional_basis_read_roots=3,
        source_built_exact_Challenge_type_comparisons=10,
        official_network_receipt=False,local_canonical_verifier_executed=False,
        qualification='Actual execution only may create this receipt. Original numerical sources '
        'and all272basis proposals are recomputed;351sources regenerated;actualCnative '
        'workloads rerun;allresearch proofs/common audits/fourisolated scientific contexts '
        'andten newnetwork proofs are compiled with explicit validated source-built parents. '
        'Canonical Comparator/NanoDa and official registration remain separately recorded.'))


if __name__=='__main__':
    main()
