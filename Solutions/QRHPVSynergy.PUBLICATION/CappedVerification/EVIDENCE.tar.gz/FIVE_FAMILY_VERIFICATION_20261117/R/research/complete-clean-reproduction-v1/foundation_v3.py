#!/usr/bin/env python3
"""Clean numerical regeneration and source-only research verification controller.

This controller runs outside the guarded phase cgroups. Each actual numerical,
proof and readback phase receives its own aggregate-accounted resource scope.
The provided monolithic route is distinct from the executed historical chain.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import os
import shutil
import subprocess
import tarfile
import time

B=Path(__file__).resolve().parent
R=B.parents[1]
ORIGINAL_SHA='dfa9c3770b1215ba16bfc02ba537b7c81641852e0ff02d2a2680b02116afc369'
STD={'propext','Classical.choice','Quot.sound'}


def need(ok,message):
    if not ok:
        raise ValueError(message)


def unique(items):
    result={}
    for key,value in items:
        need(key not in result,'duplicate JSON key')
        result[key]=value
    return result


def floating(text):
    value=float(text)
    need(math.isfinite(value),'nonfinite JSON number')
    return value


def bad(text):
    raise ValueError('nonfinite JSON constant '+text)


def parse(text):
    return json.loads(text,object_pairs_hook=unique,parse_float=floating,parse_constant=bad)


def read(path):
    return parse(path.read_text())


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def atomic(path,value):
    need(not path.exists(),'fresh acceptance output')
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.pending')
    with temporary.open('x') as handle:
        handle.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
    temporary.replace(path)


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def regular_copy(source,target):
    need(source.is_file() and not source.is_symlink(),'regular source input')
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        need(sha(source)==sha(target),'duplicate source bytes agree')
    else:
        shutil.copyfile(source,target)


def packet_check(packet):
    manifest=read(packet/'INPUT_MANIFEST.json')
    need(manifest['schema']=='INTEGRATED_RESEARCH_REPRO_INPUTS_V1','explicit source input schema')
    seen=set()
    for row in manifest['files']:
        p=Path(row['path'])
        need(not p.is_absolute() and '..' not in p.parts and str(p) not in seen,'unique safe source path')
        seen.add(str(p));source=packet/p
        need(source.is_file() and not source.is_symlink() and sha(source)==row['sha256']
             and source.stat().st_size==row['bytes'],'source/tool/payload identity '+str(p))
        need(source.suffix not in {'.olean','.ilean','.o','.so','.a','.pyc'},'no application object input')
    need(len(seen)==manifest['file_count'],'exact source input population')
    archive=packet/'dependencies/ORIGINAL_SOURCE_FIRST_COMPLETE_20261116_V2.tar.xz'
    need(sha(archive)==ORIGINAL_SHA==manifest['nested_original_archive_sha256'],'published original dependency')
    return manifest,archive


def extract_original(archive,out):
    need(not out.exists(),'fresh original distribution extraction')
    out.mkdir(parents=True)
    with tarfile.open(archive,'r:xz') as source:
        rows=source.getmembers();names=set()
        for row in rows:
            p=Path(row.name)
            need(not p.is_absolute() and '..' not in p.parts and p.parts[0]=='ORIGINAL_SOURCE_FIRST_COMPLETE_20261116_V2',
                 'safe original archive root')
            need((row.isfile() or row.isdir()) and row.name not in names,'regular unique archive members')
            names.add(row.name)
        source.extractall(out,members=rows)
    return out/'ORIGINAL_SOURCE_FIRST_COMPLETE_20261116_V2'


def materialize_task(lock_path,origins,out,overrides=None):
    """Every module is selected by exact identity/hash, never a namespace heuristic."""
    lock=read(lock_path);need(not out.exists(),'fresh full source task');out.mkdir(parents=True)
    overrides=overrides or {}
    for kind in ['sources','payloads']:
        for row in lock[kind]:
            overridden=kind=='sources' and row['module'] in overrides
            candidates=([overrides[row['module']]] if overridden else
                        [root/row['path'] for root in origins])
            matches=[p for p in candidates if p.is_file() and not p.is_symlink() and sha(p)==row['sha256']]
            need(matches,'every exact source/payload available '+row.get('module',row['path']))
            regular_copy(matches[0],out/row['path'])
    regular_copy(lock_path,out/'SOURCE_LOCK.json')
    return lock


class Run:
    def __init__(self,packet,environment,out,jobs):
        self.packet=packet;self.environment=environment.resolve();self.out=out.resolve();self.jobs=jobs
        self.runtime=self.out/'runtime';self.commands=[];self.started=time.monotonic()

    def execute(self,label,command,memory=8,cpus=4,wall=7200,native=False):
        (R/'evidence').mkdir(parents=True,exist_ok=True)
        folder=self.out/'phases'/label;folder.mkdir(parents=True)
        scope=self.out/'resources'/label
        argv=['/usr/bin/python3.10',str(R/'scripts/resource_scope_v3.py'),'--family','root_generic',
              '--memory-gib',str(memory),'--cpus',str(cpus),'--wall',str(wall),'--out',str(scope),'--',*command]
        env=dict(os.environ)
        if native:
            for name in ['LD_PRELOAD','MALLOC_MMAP_MAX_','MALLOC_ARENA_MAX','MALLOC_TOP_PAD_',
                         'MALLOC_TRIM_THRESHOLD_','MIMALLOC_RESERVE_OS_MEMORY','MIMALLOC_ARENA_EAGER_COMMIT']:
                env.pop(name,None)
        with (folder/'stdout').open('wb') as so,(folder/'stderr').open('wb') as se:
            result=subprocess.run(argv,stdout=so,stderr=se,env=env,check=False)
        record=dict(label=label,command=argv,exit_code=result.returncode,
            stdout_sha256=sha(folder/'stdout'),stderr_sha256=sha(folder/'stderr'))
        atomic(folder/'ATTEMPT.json',record)
        need(result.returncode==0,'phase failed; source/math acceptance not inferred: '+label)
        resource=read(scope/'scope.json');need(resource['exit_code']==0,'actual phase scope completed')
        record['scope_sha256']=sha(scope/'scope.json');self.commands.append(record)
        return scope

    def python(self,path,*args):
        return ['/usr/bin/python3.10','-I','-B',str(path),*[str(x) for x in args]]

    def initialize(self,manifest,archive):
        need(not self.out.exists() and self.out.is_relative_to(R),'fresh experiment-owned output under resource root')
        self.out.mkdir(parents=True);self.runtime.mkdir()
        original=extract_original(archive,self.out/'original-distribution')
        self.execute('original_distribution_bytes',self.python(original/'verify_package.py'),memory=8)
        for row in manifest['files']:
            if row['path'].startswith('R/'):
                regular_copy(self.packet/row['path'],self.runtime/Path(row['path']).relative_to('R'))
        for directory in ['scoped','scripts']:
            for source in (original/directory).rglob('*'):
                if source.is_file():regular_copy(source,self.runtime/source.relative_to(original))
        regular_copy(original/'RESOURCE_POLICY.json',self.runtime/'RESOURCE_POLICY.json')
        # Generic tool/dependency locations are per-run parameters, not mathematical source changes.
        env=read(self.environment);dest=self.runtime/'scoped/build/current52-public-environment-OO.json'
        recorded=dest.with_name('RECORDED_CURRENT52_ENVIRONMENT.json')
        if dest.exists():regular_copy(dest,recorded)
        dest.unlink(missing_ok=True);shutil.copyfile(self.environment,dest)
        self.env=dest
        plan_path=self.runtime/'research/framed-points-v1/PLAN.json'
        plan=read(plan_path);before=sha(plan_path)
        generic=env.get('lean_path') or env.get('generic_libraries') or [
            dependency['objects'] for dependency in env.get('generic_dependencies',[])]
        need(isinstance(generic,list) and generic,'explicit pinned generic library paths')
        plan['compiler']=env['compiler'];plan['generic_libraries']=generic
        plan_path.write_text(json.dumps(plan,indent=2)+'\n')
        atomic(self.out/'GENERIC_PATH_BINDINGS.json',dict(environment_sha256=sha(self.env),
            source_plan_before_sha256=before,source_plan_after_sha256=sha(plan_path),
            changed_fields=['compiler','generic_libraries'],mathematical_source_changed=False))
        self.q=self.runtime/'research/source-repaired-closure-v1'
        self.n=self.runtime/'research/basis-tangent-source-v2'
        self.work=self.runtime/'work';self.work.mkdir()

    def parent(self,label,base,task,namespace,seed=None):
        view=self.work/(label+'-view')
        command=self.python(self.q/'prepare_completed_parent_v5.py','--base-task',base,'--task',task,
            '--environment',self.env,'--parent',namespace,'--out',view)
        if seed is not None:command+=['--seed-root',str(seed),'--seed-checkpoint',str(seed/'CHECKPOINT.json')]
        self.execute(label,command,memory=8,cpus=4,wall=7200)
        need(read(view/'PREPARATION_RECEIPT.json')['status']=='PASS_PREPARED_ACTUAL_COMPLETED_PARENT_AS_APPEND_PREFIX',
             'actual complete source-built parent gate')
        return view

    def proof(self,label,task,seed=None,jobs=None):
        namespace=self.work/(label+'-namespace')
        command=self.python(self.q/'launch_namespace_v5.py','--input',task,'--environment',self.env,
            '--engine',self.q/'engine-v5','--out',namespace)
        if seed is not None:command+=['--prior',str(seed),'--checkpoint',str(seed/'CHECKPOINT.json')]
        command+=['--','/usr/bin/python3.10','-I','-B','/engine/engine_v3.py','run','--task','/task',
                  '--environment','/environment.json','--out','/out/run','--jobs',str(jobs or self.jobs)]
        if seed is not None:command+=['--prior',str(seed),'--checkpoint','/checkpoint.json']
        scope=self.execute(label,command,memory=192,cpus=16,wall=86400)
        inner=read(namespace/'data/run/RECEIPT.json')
        need(inner['status'] in ['PASS_EMPTY_APPLICATION_BANK_SOURCE_COLD_GRAPH',
            'PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS'],'source-only graph actually completed')
        need(all(row['type_repr'] and set(row['axioms'])<=STD for row in inner['audits']),
             'all actual selected root types exist and use only standard axioms')
        return namespace,scope

    def original(self):
        addon=self.runtime/'scoped/original-regeneration-addon-v1'
        numerical=self.work/'original-numerical'
        self.execute('original_numerical',self.python(addon/'reproduce_numerics_v1.py',
            '--environment',self.env,'--out',numerical),memory=8,wall=86400,native=True)
        need(read(numerical/'RECEIPT.json')['status']=='PASS_ALL_ORIGINAL_NUMERICAL_DATA_AND_WORD_SOURCE_REGENERATION',
             'actual original numerical stages complete')
        master=module('fresh_original_materializer',addon/'reproduce_complete_v2.py')
        task=self.work/'original-task';association=master.materialize(numerical,task)
        atomic(self.out/'ORIGINAL_FRESH_SOURCE_ASSOCIATION.json',association)
        namespace,scope=self.proof('original_source',task)
        self.original_task,self.original_namespace=task,namespace
        return task,namespace,scope


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet',type=Path,required=True)
    parser.add_argument('--environment',type=Path,required=True)
    parser.add_argument('--out',type=Path)
    parser.add_argument('--jobs',type=int,default=8)
    parser.add_argument('--check-inputs',action='store_true')
    parser.add_argument('--run-through',choices=['original'],default='original',
        help='V1 checked foundation; later research stages are added in a separate version before publication.')
    args=parser.parse_args();need(1<=args.jobs<=8,'fixed bounded proof concurrency')
    manifest,archive=packet_check(args.packet.resolve());env=read(args.environment)
    need(Path(env['compiler']).is_file(),'actual explicit public environment')
    if args.check_inputs:
        need(args.out is None,'input-only route creates no acceptance')
        print(json.dumps(dict(status='PASS_INTEGRATED_SOURCE_INPUT_FOUNDATION_ONLY',
            files=manifest['file_count'],original_archive_sha256=ORIGINAL_SHA,
            default_complete_research_route=False,proof_execution=False)))
        return
    need(args.out is not None,'fresh output required')
    run=Run(args.packet.resolve(),args.environment,args.out,args.jobs)
    run.initialize(manifest,archive)
    run.original()
    atomic(run.out/'FOUNDATION_RECEIPT.json',dict(status='PASS_CLEAN_ORIGINAL_FOUNDATION_NOT_FULL_RESEARCH',
        commands=run.commands,seconds=time.monotonic()-run.started,
        qualification='Only the explicitly requested V1 original foundation is executed. '
        'No full283/context/network/default-research acceptance is claimed.'))


if __name__=='__main__':
    main()
