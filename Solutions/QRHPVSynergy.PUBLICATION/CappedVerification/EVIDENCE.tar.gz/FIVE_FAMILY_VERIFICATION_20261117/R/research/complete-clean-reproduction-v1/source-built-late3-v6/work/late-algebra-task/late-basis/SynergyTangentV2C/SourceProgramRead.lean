/- Closed numerical identity derived from all three actual C J-array reads. -/
import SynergyTangentV2C.SourceProgramClosed
import SynergyTangentV2C.SourceRead
namespace SynergyTangentV2C.SourceProgramRead
theorem source_output_exact : SourceProgramClosed.sourceOutput = MainFooter.output :=
  SourceRead.payload_exact SourceProgramClosed.source_output_valid
#print axioms source_output_exact
end SynergyTangentV2C.SourceProgramRead
