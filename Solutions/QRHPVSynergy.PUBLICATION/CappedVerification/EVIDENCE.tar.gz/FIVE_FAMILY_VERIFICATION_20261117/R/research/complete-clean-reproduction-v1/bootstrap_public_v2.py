#!/usr/bin/env python3
"""Provision pinned public generic dependencies; no application object is seeded."""
from pathlib import Path
import argparse
import importlib.util

B=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('foundation',B/'foundation_v3.py')
f=importlib.util.module_from_spec(s);s.loader.exec_module(f)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--check-inputs',action='store_true')
    args=parser.parse_args();manifest,archive=f.packet_check(args.packet.resolve())
    if args.check_inputs:
        print('PASS_PUBLIC_GENERIC_BOOTSTRAP_INPUTS_ONLY_NOT_EXECUTION')
        return
    out=args.out.resolve();f.need(out.is_relative_to(f.R) and not out.exists(),'fresh owned bootstrap output')
    out.mkdir(parents=True)
    original=f.extract_original(archive,out/'source-distribution')
    run=f.Run(args.packet.resolve(),Path('/dev/null'),out/'phase-control',8)
    # Only execute() is needed: no application environment or proof prefix exists yet.
    run.execute('public_generic_dependencies',run.python(original/
        'scoped/original-regeneration-addon-v1/environment-bootstrap/scripts/bootstrap.py',
        '--work',out/'environment','--receipt',out/'BOOTSTRAP_RECEIPT.json'),
        memory=16,cpus=4,wall=86400)
    f.need((out/'environment/ENVIRONMENT.json').is_file(),'actual generic public environment created')
    f.atomic(out/'RECEIPT.json',dict(status='PASS_PINNED_PUBLIC_GENERIC_BOOTSTRAP_NO_APPLICATION_OBJECT_SEED',
        commands=run.commands,environment=str(out/'environment/ENVIRONMENT.json'),
        environment_sha256=f.sha(out/'environment/ENVIRONMENT.json'),
        qualification='Public generic compiler/dependency provisioning only. No numerical or source-PV result.'))


if __name__=='__main__':
    main()
