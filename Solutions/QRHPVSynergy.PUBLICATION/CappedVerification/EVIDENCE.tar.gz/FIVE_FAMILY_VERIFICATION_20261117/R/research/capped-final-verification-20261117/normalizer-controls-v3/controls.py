"""Focused metadata-only controls for the exact binder-origin exporter repair.

Compile separate tiny OLD/NEW fixtures before export. No application source,
proof object bank, mathematical statement or active context file is edited.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

B = Path(__file__).resolve().parent
S = B.parent
R = S.parents[1]
Q = R / "research/source-repaired-closure-v1"
H = Q / "numerics-final-contexts-v1/interfaces"
CASES = ["positive", "binder-base", "imported-index", "outer-index", "binder-info", "formula", "value"]
OPTIONS = {"normal": [], "O": ["-O"], "OO": ["-OO"]}
MODES = {"normal": 0, "O": 1, "OO": 2}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


c = load("fixed_comparison", Q / "compare_context_fingerprints_v2.py")
ordinary = load("fixed_ordinary", Q / "reduce_expr_stream_v1.py")
typed = load("fixed_typed", Q / "reduce_typed_proof_stream_v2.py")


def atomic(path, value):
    temporary = path.with_name(path.name + ".pending")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, path)


BUILDER = '''import Lean
open Lean Elab Command
set_option autoImplicit false
namespace NormalizerFixture
private def fixtureName (origin : Name) (base : String) (inner outer : Nat) : Name :=
  let n := Name.str (Name.str Name.anonymous base) "_@"
  let n := Name.num (Name.appendCore n origin) 4182612516
  let n := Name.num (Name.str n "_hygCtx") inner
  let n := Name.num (Name.appendCore n origin) 4182612516
  Name.num (Name.str (Name.str n "_hygCtx") "_hyg") outer
elab "normalizer_fixture" origin:str which:str : command => do
  let origin := (origin.getString.splitOn ".").foldl Name.str Name.anonymous
  let which := which.getString
  let base := if which == "binder-base" then "changed_base" else "x"
  let inner := if which == "imported-index" then 142 else 141
  let outer := if which == "outer-index" then 204 else 203
  let binder := fixtureName origin base inner outer
  let info := if which == "binder-info" then BinderInfo.implicit else BinderInfo.default
  let domain := mkConst (if which == "formula" then ``Bool else ``Nat)
  let body := if which == "value" then mkApp (mkConst ``Nat.succ) (mkBVar 0) else mkBVar 0
  liftTermElabM do
    addDecl (.defnDecl {
      name := `NormalizerFixture.value
      levelParams := []
      type := mkForall binder info domain domain
      value := mkLambda binder info domain body
      hints := .regular 0
      safety := .safe })
end NormalizerFixture
'''


def compiler_environment(compiler, paths):
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, paths)), LEAN_NUM_THREADS="1")
    env.pop("LD_PRELOAD", None)
    env["LEAN_SYSROOT"] = str(compiler.parent.parent)
    env["PATH"] = str(compiler.parent) + os.pathsep + env.get("PATH", "")
    return env


def execute(tag, argv, env, directory):
    result = subprocess.run(argv, capture_output=True, env=env, timeout=120)
    (directory / (tag + ".stdout")).write_bytes(result.stdout)
    (directory / (tag + ".stderr")).write_bytes(result.stderr)
    need(result.returncode == 0, "Actual metadata compiler/export command exit0 " + tag)
    return dict(command=argv, exit_code=result.returncode,
                stdout_sha256=sha(directory / (tag + ".stdout")),
                stderr_sha256=sha(directory / (tag + ".stderr")))


def prepare():
    out = B / "prepared"
    need(not out.exists(), "Fresh focused metadata fixture preparation")
    out.mkdir()
    compiler = Path(c.read(R / "research/framed-points-v1/PLAN.json")["compiler"])
    accepted = c.read(H / "build-v3/RECEIPT.json")
    source = H / "source/ContextInterface/ExportV3.lean"
    obj = H / "build-v3/objects/ContextInterface/ExportV3.olean"
    need(sha(source) == accepted["source_sha256"] == "293a6e9bbda7116376bfcae56328b4a12d38043a3c7f48a0b05b1e9da50553e2",
         "Exact independently reviewed actual V3 exporter source")
    need(sha(obj) == accepted["object_sha256"] and sha(compiler) == accepted["compiler_sha256"],
         "Actual accepted V3 exporter object/compiler")
    builder = out / "builder/source/NormalizerFixture/Builder.lean"
    builder.parent.mkdir(parents=True)
    builder.write_text(BUILDER)
    builder_objects = out / "builder/objects"
    builder_object = builder_objects / "NormalizerFixture/Builder.olean"
    builder_object.parent.mkdir(parents=True)
    common_env = compiler_environment(compiler, [builder_objects, H / "build-v3/objects"])
    builder_run = execute("builder", [str(compiler), "-j1", "-R", str(out / "builder/source"),
                          str(builder), "-o", str(builder_object)], common_env, out)
    entries = {}
    pins = {str(p): sha(p) for p in [Path(__file__), compiler, source, obj, H / "build-v3/RECEIPT.json",
             builder, builder_object, Q / "compare_context_fingerprints_v2.py",
             Q / "reduce_expr_stream_v1.py", Q / "reduce_typed_proof_stream_v2.py"]}
    for case in ["old", *CASES]:
        directory = out / case
        directory.mkdir()
        module = "Main" if case == "old" else "ContextH02.Main"
        which = "positive" if case == "old" else case
        fixture = directory / "source" / (module.replace(".", "/") + ".lean")
        fixture.parent.mkdir(parents=True)
        fixture.write_text('import NormalizerFixture.Builder\nnormalizer_fixture "' + module + '" "' + which + '"\n')
        objects = directory / "objects"
        object_path = objects / (module.replace(".", "/") + ".olean")
        object_path.parent.mkdir(parents=True)
        env = compiler_environment(compiler, [objects, builder_objects, H / "build-v3/objects"])
        compile_run = execute("fixture", [str(compiler), "-j1", "-R", str(directory / "source"),
                           str(fixture), "-o", str(object_path)], env, directory)
        stream = directory / "expressions.jsonl"
        probe = directory / "Probe.lean"
        probe.write_text("import ContextInterface.ExportV3\nimport " + module + "\n"
            "set_option maxHeartbeats 0\nset_option maxRecDepth 300000\n"
            "run_elab do\n ContextInterface.ExportV3.exportModules [`" + module + "] " + json.dumps(str(stream)) + "\n")
        probe_object = directory / "Probe.olean"
        export_run = execute("export", [str(compiler), "-j1", "-R", str(directory), str(probe),
                               "-o", str(probe_object)], env, directory)
        for p in [fixture, object_path, probe, probe_object, stream]:
            pins[str(p)] = sha(p)
        entries[case] = dict(module=module, fixture=str(fixture), object=str(object_path), stream=str(stream),
                             compile=compile_run, export=export_run)
    manifest = dict(status="PREPARED_KERNEL_CHECKED_FOCUSED_METADATA_FIXTURES_NOT_APPLICATION_ACCEPTANCE",
        schema=1, cases=entries, builder=builder_run, input_pins=pins,
        mutation_stage="Actual Lean fixture input before compilation and V3 export; no comparison result or stream is mutated.",
        qualification="Tiny metadata-only public identity-function CI, separate OLD/NEW module objects. No application proof or source changed.")
    atomic(out / "MANIFEST.json", manifest)
    print("PREPARED_METADATA_FIXTURES", sha(out / "MANIFEST.json"))


def reduce_fixture(entry):
    fp = ordinary.reduce_stream(Path(entry["stream"]))
    fp["validator_sha256"] = sha(Q / "reduce_expr_stream_v1.py")
    second = typed.reduce_stream(Path(entry["stream"]), fp)
    indexed = {(r["module"], r["name_repr"]): r for r in second["records"]}
    for row in fp["records"]:
        row.update(indexed[(row["module"], row["name_repr"])])
    need(len(fp["records"]) == 1 and fp["modules"] == [entry["module"]], "Exact one actual compiled fixture CI")
    row = fp["records"][0]
    need(row["name_repr"] == "`NormalizerFixture.value" and row["is_private"] is False
         and row["is_prop"] is False and row["declaration_kind"] == "definition",
         "Actual complete public nonproof fixture CI")
    row["module"] = "Main"
    return dict(status="PASS_COMPLETE_TYPED_DAG_FINGERPRINT_REDUCTION", records=[row], modules=["Main"], declaration_count=1)


def validate(a):
    need(sys.flags.optimize == MODES[a.mode], "Actual focused validator Python optimization")
    manifest_path = B / "prepared/MANIFEST.json"
    need(sha(manifest_path) == a.manifest_sha, "Frozen actual fixture manifest")
    manifest = c.read(manifest_path)
    need(manifest["schema"] == 1 and set(manifest["cases"]) == {"old", *CASES}, "Complete exact focused fixture universe")
    for path, digest in manifest["input_pins"].items():
        need(sha(path) == digest, "Actual fixed compiled fixture/export/source/tool bytes")
    left = reduce_fixture(manifest["cases"]["old"])
    right = reduce_fixture(manifest["cases"][a.case])
    comparison = c.compare(left, right)
    for key in ["type_differences", "nonproof_value_differences", "proposition_retaining_data_differences",
                "computational_metadata_differences", "proposition_retaining_metadata_differences", "only_left", "only_right"]:
        need(not comparison[key], "Exact fixture interface match: " + key)
    out = a.out.resolve()
    need(out.is_relative_to(B) and not out.exists(), "Fresh focused positive receipt")
    atomic(out, dict(status="PASS_ACTUAL_COMPILED_METADATA_FIXTURE_INTERFACE", case=a.case,
        python_optimization=sys.flags.optimize, manifest_sha256=a.manifest_sha, comparison=comparison,
        qualification="Metadata normalizer control only, not application acceptance."))
    print("PASS_ACTUAL_COMPILED_METADATA_FIXTURE_INTERFACE")


def mode(a):
    need(sys.flags.optimize == MODES[a.mode], "Actual focused driver Python optimization")
    out = B / "modes" / a.mode
    need(not out.exists(), "Fresh focused mode controls")
    out.mkdir(parents=True)
    manifest = B / "prepared/MANIFEST.json"
    digest = sha(manifest)
    rows = []
    for case in CASES:
        target = out / (case + ".json")
        argv = [sys.executable, *OPTIONS[a.mode], "-I", "-B", str(Path(__file__)), "--action", "validate",
                "--mode", a.mode, "--case", case, "--manifest-sha", digest, "--out", str(target)]
        child = subprocess.run(argv, capture_output=True, timeout=60)
        (out / (case + ".stdout")).write_bytes(child.stdout)
        (out / (case + ".stderr")).write_bytes(child.stderr)
        positive = case == "positive"
        need((child.returncode == 0) == positive and target.exists() == positive, "Actual focused fixture CLI outcome " + case)
        if not positive:
            guard = "nonproof_value_differences" if case == "value" else "type_differences"
            need(child.returncode == 1 and child.stdout == b"" and
                 child.stderr.decode().splitlines()[-1] == "ValueError: Exact fixture interface match: " + guard,
                 "Focused negative reaches exact intended fixture guard " + case)
        rows.append(dict(case=case, command=argv, exit_code=child.returncode, expected_success=positive,
            stdout_sha256=sha(out / (case + ".stdout")), stderr_sha256=sha(out / (case + ".stderr"))))
    atomic(out / "RECEIPT.json", dict(status="PASS_FOCUSED_ACTUAL_PRE_EXPORT_FIXTURE_CONTROLS_ONE_MODE",
        mode=a.mode, python_optimization=sys.flags.optimize, actual_CLIs=7, records=rows,
        manifest_sha256=digest, script_sha256=sha(Path(__file__))))


def all_modes():
    need(sys.flags.optimize == 0, "Normal light orchestration; drivers and validators exercise all three modes")
    prepare()
    records = []
    for label in ["normal", "O", "OO"]:
        argv = [sys.executable, *OPTIONS[label], "-I", "-B", str(Path(__file__)), "--action", "mode", "--mode", label]
        child = subprocess.run(argv, capture_output=True, timeout=600)
        (B / (label + ".stdout")).write_bytes(child.stdout)
        (B / (label + ".stderr")).write_bytes(child.stderr)
        need(child.returncode == 0, "Actual focused driver exit0 " + label)
        p = B / "modes" / label / "RECEIPT.json"
        receipt = c.read(p)
        need(receipt["status"] == "PASS_FOCUSED_ACTUAL_PRE_EXPORT_FIXTURE_CONTROLS_ONE_MODE"
             and receipt["actual_CLIs"] == 7 and receipt["python_optimization"] == MODES[label], "Actual seven focused CLIs per optimization mode")
        records.append(dict(mode=label, command=argv, receipt_sha256=sha(p)))
    atomic(B / "RECEIPT.json", dict(status="PASS_ACTUAL_BINDER_ORIGIN_RELOCATION_AND_SIX_PRE_EXPORT_NEGATIVES_ALL_OPTIMIZATION_MODES",
        schema=1, actual_validator_CLIs=21, actual_driver_modes=3, records=records,
        manifest_sha256=sha(B / "prepared/MANIFEST.json"), script_sha256=sha(Path(__file__)),
        mutation_stage="Actual tiny Lean fixture before kernel checking and accepted V3 export.",
        qualification="Focused metadata-only repair controls. Does not establish application math, four-context or283 acceptance."))
    print("PASS_ACTUAL_BINDER_ORIGIN_RELOCATION_AND_SIX_PRE_EXPORT_NEGATIVES_ALL_OPTIMIZATION_MODES", sha(B / "RECEIPT.json"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--action", choices=["all", "mode", "validate"], default="all")
    parser.add_argument("--mode", choices=list(MODES), default="normal")
    parser.add_argument("--case", choices=CASES, default="positive")
    parser.add_argument("--manifest-sha")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if args.action == "all":
        all_modes()
    elif args.action == "mode":
        mode(args)
    else:
        validate(args)
