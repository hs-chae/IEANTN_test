import ContextInterface.ExportV3
import Main
set_option maxHeartbeats 0
set_option maxRecDepth 300000
run_elab do
 ContextInterface.ExportV3.exportModules [`Main] "/ryu/hyunsik/playground/independence/codex/ivy/ieantn-qrh-pv-synergy-20261114/research/capped-final-verification-20261117/normalizer-controls-v2/prepared/old/expressions.jsonl"
