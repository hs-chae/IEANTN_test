"""Seal explicit reviewed evidence paths, reusing the source-package sealing pattern."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import io
import json
import math
import os
import tarfile

B = Path(__file__).resolve().parent
R = B.parents[1]
TOP = 'FIVE_FAMILY_VERIFICATION_20261117'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(2**20), b''):
            digest.update(block)
    return digest.hexdigest()


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def finite(number):
    value = float(number)
    need(math.isfinite(value), 'finite JSON number')
    return value


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    manifest = json.loads(args.manifest.read_text(), object_pairs_hook=pairs, parse_float=finite,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    need(manifest['schema'] == 1 and type(manifest['schema']) is int, 'exact evidence schema')
    need(manifest['status'] == 'REVIEWED_EXPLICIT_PUBLIC_EVIDENCE_ALLOWLIST', 'reviewed explicit allowlist')
    members = {}
    for row in manifest['files']:
        name = row['path']
        relative = PurePosixPath(name)
        need(not relative.is_absolute() and '..' not in relative.parts
             and relative.as_posix() == name and TOP+'/R/'+name not in members, 'unique relative written path')
        path = R/name
        need(path.resolve().is_relative_to(R) and path.is_file() and not path.is_symlink(), 'actual owned regular evidence')
        need(not {'.git', '__pycache__', 'memory', 'human_input'} & set(relative.parts)
             and path.suffix not in {'.olean', '.ilean', '.ir', '.o', '.a', '.so', '.pyc'}, 'source and evidence, no object bank or private context')
        need(type(row['bytes']) is int and row['bytes'] >= 0, 'integer nonboolean byte count')
        need(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'exact reviewed member bytes')
        members[TOP+'/R/'+name] = (path, row['sha256'])
    need(members, 'nonempty explicit evidence')
    out = args.out.resolve()
    need(out.is_relative_to(R) and not out.exists() and not out.with_suffix(out.suffix+'.pending').exists(), 'fresh owned archive')
    out.parent.mkdir(parents=True, exist_ok=True)
    temporary = out.with_suffix(out.suffix+'.pending')
    receipt_path = out.with_name(out.name+'.RECEIPT.json')
    need(not receipt_path.exists() and not receipt_path.with_name(receipt_path.name+'.pending').exists(),
         'fresh artifact receipt before archive mutation')
    manifest_bytes = args.manifest.read_bytes()
    with temporary.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as archive:
                info = tarfile.TarInfo(TOP+'/INPUT_MANIFEST.json')
                info.size, info.mode = len(manifest_bytes), 0o644
                archive.addfile(info, io.BytesIO(manifest_bytes))
                for name, (path, _) in sorted(members.items()):
                    info = archive.gettarinfo(str(path), arcname=name)
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    info.mode = 0o644
                    with path.open('rb') as handle:
                        archive.addfile(info, handle)
    expected = {name: digest for name, (_, digest) in members.items()}
    expected[TOP+'/INPUT_MANIFEST.json'] = hashlib.sha256(manifest_bytes).hexdigest()
    seen = set()
    with tarfile.open(temporary, 'r:gz') as archive:
        for info in archive:
            need(info.isfile() and info.name in expected and info.name not in seen, 'exact regular unique archive membership')
            seen.add(info.name)
            handle = archive.extractfile(info)
            need(handle is not None, 'readable archive member')
            digest = hashlib.sha256()
            for block in iter(lambda: handle.read(2**20), b''):
                digest.update(block)
            need(digest.hexdigest() == expected[info.name], 'every actual archived byte')
    need(seen == set(expected) and temporary.stat().st_size < 100_000_000, 'complete public single-file archive')
    os.replace(temporary, out)
    receipt = {'status': 'PASS_REVIEWED_SOURCE_EVIDENCE_ARCHIVE_MEMBERS_AND_BYTES',
               'path': str(out.relative_to(R)), 'sha256': sha(out), 'bytes': out.stat().st_size,
               'input_manifest_sha256': sha(args.manifest), 'sealer_sha256': sha(Path(__file__)),
               'members': len(expected),
               'qualification': 'Artifact-byte verification only; mathematical, source-first and full-run statuses remain in the actual component receipts.'}
    pending = receipt_path.with_name(receipt_path.name+'.pending')
    pending.write_text(json.dumps(receipt, indent=2)+'\n')
    os.replace(pending, receipt_path)
    print(receipt['status'], receipt['bytes'], receipt['sha256'])


if __name__ == '__main__':
    main()
