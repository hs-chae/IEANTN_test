import NormalizerFixture.Builder
normalizer_fixture "Main" "positive"
