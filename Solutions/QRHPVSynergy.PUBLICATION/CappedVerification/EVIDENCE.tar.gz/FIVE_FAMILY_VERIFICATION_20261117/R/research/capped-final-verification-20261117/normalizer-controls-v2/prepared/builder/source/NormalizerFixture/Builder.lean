import Lean
open Lean Elab Command
set_option autoImplicit false
namespace NormalizerFixture
private def fixtureName (origin : Name) (base : String) (inner outer : Nat) : Name :=
  let n := Name.str (Name.str Name.anonymous base) "_@"
  let n := Name.num (Name.appendCore n origin) 4182612516
  let n := Name.num (Name.str n "_hygCtx") inner
  let n := Name.num (Name.appendCore n origin) 4182612516
  Name.num (Name.str (Name.str n "_hygCtx") "_hyg") outer
elab "normalizer_fixture" origin:str which:str : command => do
  let origin := (origin.getString.splitOn ".").foldl Name.str Name.anonymous
  let which := which.getString
  let base := if which == "binder-base" then "changed_base" else "x"
  let inner := if which == "imported-index" then 142 else 141
  let outer := if which == "outer-index" then 204 else 203
  let binder := fixtureName origin base inner outer
  let info := if which == "binder-info" then BinderInfo.implicit else BinderInfo.default
  let domain := mkConst (if which == "formula" then ``Bool else ``Nat)
  let body := if which == "value" then mkApp (mkConst ``Nat.succ) (mkBVar 0) else mkBVar 0
  liftTermElabM do
    addDecl (.defnDecl {
      name := `NormalizerFixture.value
      levelParams := []
      type := mkForall binder info domain domain
      value := mkLambda binder info domain body
      hints := .regular 0
      safety := .safe })
end NormalizerFixture
