"""Record actual capped-session receipts without upgrading incomplete gates."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import math
import os

B = Path(__file__).resolve().parent
R = B.parents[1]
Q = R/'research/source-repaired-closure-v1'
N = R/'research/network-propagation-v2'
M = R/'research/complete-clean-reproduction-v1'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def finite(number):
        value = float(number)
        need(math.isfinite(value), 'nonfinite JSON number')
        return value
    return json.loads(path.read_text(), object_pairs_hook=pairs, parse_float=finite,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(2**20), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    need(out.is_relative_to(B) and not out.exists(), 'fresh owned session snapshot')
    phases = []
    for label, path in [
        ('Validated canonical parent, all three modes', Q/'final-parent-readback-v1/RECEIPT.json'),
        ('Three common source-use auditors', Q/'final-common-pipeline-v1/RECEIPT.json'),
        ('Four independent contexts and interface comparisons', Q/'numerics-final-contexts-v1/execution-v1/RECEIPT.json'),
        ('Complete283 written-target source/role gate, all modes', Q/'final283-pipeline-v3/RECEIPT.json'),
        ('Ten new network consumers and exact Challenge types', N/'source-built-network10-v6/RECEIPT.json'),
        ('Separate read identities and five algebra roots', M/'source-built-late3-v6/RECEIPT.json')]:
        row = dict(label=label, path=str(path.relative_to(R)), receipt_present=path.is_file())
        if path.is_file():
            receipt = read(path)
            row.update(status=receipt.get('status'), sha256=sha(path), bytes=path.stat().st_size)
        else:
            row['status'] = 'PENDING_NO_FINAL_RECEIPT'
        phases.append(row)
    resource_roots = set()
    for path in B.rglob('*JOBS.json'):
        job = read(path)
        for key in ['resource_roots', 'owned_resource_roots']:
            for value in job.get(key, []):
                root = Path(value).resolve()
                need(root.is_relative_to(R), 'explicit experiment-owned resource root')
                resource_roots.add(root)
    scopes = []
    for root in sorted(resource_roots):
        candidates = [root/'scope.json'] if (root/'scope.json').is_file() else []
        if not candidates and root.is_dir():
            candidates = list(root.glob('*/scope.json'))
        for path in candidates:
            data = read(path)
            samples = data.get('samples', [])
            memory, events, disk, free_disk, available_ram = [], {}, [], [], []
            for sample in samples:
                if 'memory.current' in sample:
                    memory.append(int(sample['memory.current']))
                if 'supplemental_workspace_written_bytes' in sample:
                    disk.append(int(sample['supplemental_workspace_written_bytes']))
                if 'free_disk_bytes' in sample:
                    free_disk.append(int(sample['free_disk_bytes']))
                if 'host_available_RAM_bytes' in sample:
                    available_ram.append(int(sample['host_available_RAM_bytes']))
                for line in sample.get('memory.events', '').splitlines():
                    key, value = line.split()
                    events[key] = max(events.get(key, 0), int(value))
            group = Path(data['cgroup'])/'cgroup.procs' if data.get('cgroup') else None
            scopes.append(dict(path=str(path.relative_to(R)), sha256=sha(path),
                exit_code=data.get('exit_code'), elapsed_seconds=data.get('elapsed_seconds'),
                RAM_limit_bytes=data.get('requested_memory_bytes'), CPUs=data.get('cpus'),
                sampled_charged_RAM_lower_bound_bytes=max(memory) if memory else None,
                exact_cgroup_RAM_peak_bytes=None, sampled_memory_events=events,
                sampled_OOM_evidence_only=True, exact_per_run_disk_peak_bytes=None,
                sampled_aggregate_workspace_allocated_bytes_max=max(disk) if disk else None,
                sampled_host_free_disk_bytes_min=min(free_disk) if free_disk else None,
                sampled_host_available_RAM_bytes_min=min(available_ram) if available_ram else None,
                disk_qualification='Shared aggregate workspace allocation, not exclusive per-run storage.',
                resource_sample_count=len(samples),
                policy_sha256=data.get('policy_sha256'), launcher_sha256=data.get('launcher_sha256'),
                actual_cgroup_drained=group is not None and (not group.exists() or not group.read_text().strip()),
                stop_reason=data.get('stop_reason')))
    result = dict(schema=1, status='ACTUAL_RECEIPT_SNAPSHOT_NOT_A_SUBSTITUTE_FOR_FINAL_SOURCE_PROOF_ACCEPTANCE',
        recorded_utc=datetime.now(timezone.utc).isoformat(), session_plan_sha256=sha(B/'SESSION_PLAN.json'),
        collector_sha256=sha(Path(__file__)), phases=phases, resource_scopes=scopes,
        all_selected_phase_receipts_present=all(row['receipt_present'] for row in phases),
        qualification='Each listed status belongs to its existing actual receipt. A missing receipt '
        'is pending, not failure or mathematical invalidity. Native observations, source proofs, '
        'kernel-only baselines, generic transfers and official network registration remain separate. '
        'Sampled charged memory is a lower bound; unavailable exact peaks are not inferred.')
    temporary = out.with_name(out.name+'.pending')
    temporary.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    os.replace(temporary, out)
    print('ACTUAL_SESSION_SNAPSHOT', len(scopes), 'completed resource scopes',
          sum(row['receipt_present'] for row in phases), '/', len(phases), 'final receipts')


if __name__=='__main__':
    main()
