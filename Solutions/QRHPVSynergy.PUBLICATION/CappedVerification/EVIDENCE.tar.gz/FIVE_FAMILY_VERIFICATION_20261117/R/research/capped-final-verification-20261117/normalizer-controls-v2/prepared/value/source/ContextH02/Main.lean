import NormalizerFixture.Builder
normalizer_fixture "ContextH02.Main" "value"
