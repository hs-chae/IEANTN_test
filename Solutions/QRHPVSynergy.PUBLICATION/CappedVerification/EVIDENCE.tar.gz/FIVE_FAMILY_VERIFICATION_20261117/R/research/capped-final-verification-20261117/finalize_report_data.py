"""Freeze the actual capped-session outcome after an independently checked worker stop."""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import importlib.util
import json
import os

B = Path(__file__).resolve().parent
R = B.parents[1]
spec = importlib.util.spec_from_file_location('capped_renderer', B/'render_report.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--snapshot', type=Path, required=True)
    ap.add_argument('--stop-record', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    stop, snapshot = v.read(args.stop_record), v.read(args.snapshot)
    v.need(stop['status'] == 'PASS_SESSION_OWNED_JOBS_DRAINED'
           and stop['remaining_owned_controllers'] == [] and stop['remaining_owned_resource_leases'] == [],
           'actual owned workers stopped before freezing final report')
    d = v.read(B/'DRAFT_REPORT_DATA_PRESTOP.json')
    d['status'] = 'FROZEN_CAPPED_SESSION_RESULTS_WITH_EXPLICIT_PENDING_GATES'
    d['all_session_jobs_drained'] = True
    d['stopped_utc'] = stop['utc']
    seconds = (datetime.fromisoformat(stop['utc'])-datetime.fromisoformat(d['started_utc'])).total_seconds()
    d['session_elapsed_display'] = f'{int(seconds//3600)}h {int(seconds%3600//60)}m'
    d['gates'], d['resources'] = [], []
    for phase in snapshot['phases']:
        d['gates'].append({'name': phase['label'], 'status': phase['status'],
                           'meaning': 'Actual final component receipt.' if phase['receipt_present'] else
                                      'No final receipt; partial executions do not establish final acceptance.'})
    for row in snapshot['resource_scopes']:
        events = row['sampled_memory_events']
        if 'oom' in events and 'oom_kill' in events:
            oom = f'Sampled oom={events["oom"]}, oom_kill={events["oom_kill"]}'
        else:
            oom = 'No cgroup event sample; OOM absence not inferred'
        d['resources'].append({'label': row['path'].removesuffix('/scope.json'),
            'exit_code': row['exit_code'], 'elapsed_seconds': row['elapsed_seconds'],
            'RAM_limit_bytes': row['RAM_limit_bytes'],
            'sampled_charged_RAM_lower_bound_bytes': row['sampled_charged_RAM_lower_bound_bytes'],
            'OOM_classification': oom})
    final283 = next(x for x in snapshot['phases'] if 'Complete283' in x['label'])
    full_pass = final283['receipt_present'] and str(final283['status']).startswith('PASS_')
    d['headline'] = 'Five core families verified; '+('combined283 gate passed' if full_pass else 'combined283 gate incomplete')
    d['outcome_summary'] = ('The five core source-first chains, all four separate context/type/data routes, '
        'ten exact network consumers and the eight-root late append passed. '+
        ('The complete283-entry combined all-mode gate also passed. ' if full_pass else
         'The final combined283-entry gate has no completed final receipt. ')+
        'The portable strict end-to-end replay remains unfinished; local canonical acceptance is2/10.')
    d['pending'] = [x for x in d['pending'] if not x.startswith('Final283 combined')]
    if not full_pass:
        d['pending'].insert(0, 'Finish the final283 combined acceptance: the report does not promote partial modes/cases to full acceptance. Exact stopped progress is in the retained run evidence.')
    evidence = {x['id']: x for x in d['evidence']}
    def add(identity, path):
        path = Path(path).resolve()
        v.need(path.is_relative_to(R) and path.is_file(), 'actual report evidence path')
        evidence[identity] = {'id': identity, 'path': str(path.relative_to(R)), 'sha256': v.sha(path)}
    add('actual-worker-stop', args.stop_record)
    add('actual-phase-resource-snapshot', args.snapshot)
    add('context-lean-child-rss', B/'SESSION/FOUR_CONTEXT_SOURCE_RSS_MEASUREMENTS_V1.json')
    add('native-source-build-identities', B/'analytic_NATIVE_PROGRAM_IDENTITIES.json')
    add('exact-preserved-PNT-formulations', B/'analytic_PNT_FORMULATIONS.json')
    add('independent-core-readback', B/'ROOT_INDEPENDENT_CORE_READBACK.json')
    add('sealer-actual18-CLI-controls', B/'sealer-controls-v2/RECEIPT.json')
    overlay = R/'research/complete-clean-reproduction-v1/sealed-combined-reproduction-overlay-v5/QRH_REPRODUCTION_CONTROL_OVERLAY_20261117_V5.tar.xz'
    add('source-control-snapshot-overlay', overlay)
    for n, phase in enumerate(snapshot['phases']):
        if phase['receipt_present']:
            add('actual-phase-'+str(n+1), R/phase['path'])
    sidecar = B/'COMMON_KERNEL_TYPED_SIDECAR_V2.json'
    if sidecar.exists():
        add('actual26-baseline-typed-sidecar', sidecar)
    d['evidence'] = list(evidence.values())
    d['reproduction_overlay']['full_final283_clean_replay_complete'] = False
    d['failures_and_limitations'].extend([
        'The supplemental20570-root audit passed without new scientific compilation. Its strict host readback required the actual zero-fresh receipt and exact seed-link layout; failed postprocessors remain failed historical attempts.',
        'The actual two-conclusion Theta project passed both NanoDa and Lean kernels. Moment4 and Vector4 compiled with standard axioms but reached the configured900-second export limits; no mathematical rejection or completed canonical verdict is inferred.',
        'The v7 source/control snapshot is not a complete clean end-to-end replay: the portable strict26-root final283 hook remains unfinished. Input-only/overlay tests do not establish full-run reproduction.'
    ])
    out = args.out.resolve()
    v.need(out.is_relative_to(B) and not out.exists(), 'fresh final result record')
    pending = out.with_name(out.name+'.pending')
    pending.write_text(json.dumps(d, indent=2, allow_nan=False)+'\n')
    os.replace(pending, out)
    print('FROZEN_ACTUAL_CAPPED_REPORT_DATA', v.sha(out), 'full283', full_pass)


if __name__ == '__main__':
    main()
