"""Record actual registered worker drain; do not turn open ledgers into execution claims."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import json
import importlib.util
import os

B = Path(__file__).resolve().parent
R = B.parents[1]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def identity(pid):
    try:
        stat = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
        if stat[0] in {'Z', 'X'}:
            return None
        command = Path('/proc', str(pid), 'cmdline').read_bytes().replace(b'\0', b' ').decode().strip()
        return {'pid': pid, 'start_tick': int(stat[19]), 'command': command, 'state': stat[0]}
    except FileNotFoundError:
        return None


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    controllers, roots = {}, set()
    for path in B.rglob('*JOBS.json'):
        job = json.loads(path.read_text())
        for row in job.get('controllers', []):
            controllers[(row['pid'], row.get('start_tick'))] = row
        for key in ['resource_roots', 'owned_resource_roots']:
            for name in job.get(key, []):
                p = Path(name).resolve()
                need(p.is_relative_to(R), 'registered owned resource root')
                roots.add(p)
    remaining = []
    for (pid, tick), _ in controllers.items():
        actual = identity(pid)
        if actual is not None and str(R) in actual['command'] and (tick is None or actual['start_tick'] == tick):
            remaining.append(actual)
    leases, stale_leases = [], []
    spec = importlib.util.spec_from_file_location('actual_resource_guard', R/'scripts/resource_scope_v3.py')
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    for row in json.loads((R/'evidence/ACTIVE_RUNS.json').read_text()):
        path = Path(row['out']).resolve()
        if any(path == root or path.is_relative_to(root) for root in roots):
            (leases if guard.reservation_alive(row) else stale_leases).append(row)
    # Both explicitly session-owned cutoff watchers must also have exited.
    for pid, token in [(326170, 'stop_at_cutoff.py'), (322778, 'stop_contexts_at_cutoff.py')]:
        actual = identity(pid)
        if actual is not None and token in actual['command'] and str(B) in actual['command']:
            remaining.append(actual)
    result = {'status': 'PASS_SESSION_OWNED_JOBS_DRAINED' if not remaining and not leases else 'NOT_DRAINED',
              'utc': datetime.now(timezone.utc).isoformat(),
              'remaining_owned_controllers': remaining, 'remaining_owned_resource_leases': leases,
              'inactive_owned_ledger_entries_not_running_jobs': stale_leases,
              'registered_controller_identities_checked': len(controllers),
              'registered_resource_roots_checked': len(roots),
              'qualification': 'Exact registered PID/start identities and experiment-owned resource roots only; no unrelated workspace or process is stopped.'}
    out = args.out.resolve()
    need(out.is_relative_to(B) and not out.exists(), 'fresh actual stop record')
    need(result['status'] == 'PASS_SESSION_OWNED_JOBS_DRAINED', json.dumps(result))
    pending = out.with_name(out.name+'.pending')
    pending.write_text(json.dumps(result, indent=2)+'\n')
    os.replace(pending, out)
    print(result['status'])


if __name__ == '__main__':
    main()
