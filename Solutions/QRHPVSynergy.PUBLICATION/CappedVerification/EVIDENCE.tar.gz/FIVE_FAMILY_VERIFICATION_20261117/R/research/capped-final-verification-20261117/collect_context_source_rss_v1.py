"""Measure exactly four completed source namespaces; no new run or global acceptance."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import math
import os
import re
import sys
B = Path(__file__).resolve().parent
R = B.parents[1]
Q = R / "research/source-repaired-closure-v1"
H = Q / "numerics-final-contexts-v1"
def need(ok, message):
    if not ok: raise ValueError(message)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pairs(items):
    result = {}
    for key,value in items:
        need(key not in result, "Duplicate JSON key")
        result[key] = value
    return result
def read(path):
    def floating(text):
        value = float(text)
        need(math.isfinite(value), "Finite measurement")
        return value
    def constant(text): raise ValueError("Invalid JSON constant " + text)
    return json.loads(Path(path).read_text(), object_pairs_hook=pairs, parse_float=floating, parse_constant=constant)
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--out",type=Path,required=True);a=parser.parse_args();out=a.out.resolve()
    need(out.is_relative_to(B) and not out.exists(), "Fresh owned measurement snapshot")
    base={x["module"] for x in read(Q/"final-replay-capsule-v1/SOURCE_LOCK.json")["sources"]};rows=[]
    for label in ["H01V1","H02V1","PublicMomentV1","PublicVectorV1"]:
        namespace=H/"isolated"/label;receipt=namespace/"data/run/RECEIPT.json";task=H/"packets-v2"/label/"SOURCE_LOCK.json"
        scope_path=R/"resources"/("numerics-isolated-"+label.lower()+("-v2" if label=="PublicMomentV1" else "-v1"))/"scope.json"
        j,scope=read(receipt),read(scope_path);own={x["module"] for x in read(task)["sources"]}-base
        need(j["status"]=="PASS_COMPLETE_SOURCE_COLD_CHAIN_WITH_EXPLICIT_PRIOR_SEEDS" and j["new_compilations"]==len(own) and scope["exit_code"]==0, "Actual completed own source namespace")
        command=scope["command"];launcher=str(Q/"launch_namespace_v5.py");need(command.count(launcher)==1,"Actual source launcher")
        args=command[command.index(launcher)+1:];args=args[:args.index("--")]
        need(Path(args[args.index("--out")+1]).resolve()==namespace.resolve(),"Time records bound to same actual namespace")
        selected=[(x["module"],x) for x in j["records"] if x["module"] in own]+[("FINAL_TYPED_ROOT_AUDIT",j["audit_record"])];need(len(selected)==len(own)+1,"Exactly own commands plus final typed audit")
        times=[]
        for module,record in selected:
            item=record["files"]["time"];path=namespace/"data/run"/item["path"];need(sha(path)==item["sha256"],"Actual bound GNU time bytes")
            text=path.read_text();rss=re.search(r"^\s*Maximum resident set size \(kbytes\): (\d+)\s*$",text,re.M);status=re.search(r"^\s*Exit status: (\d+)\s*$",text,re.M)
            need(rss is not None and status is not None and int(status[1])==0 and record["exit_code"]==0,"Successful actual GNU time command")
            times.append(dict(module_or_command=module,actual_namespace=str(namespace),time_path=str(path),time_sha256=item["sha256"],actual_command=record["command"],max_child_RSS_KiB=int(rss[1]),recorded_command_seconds=record["seconds"]))
        samples=scope["samples"];rows.append(dict(label=label,namespace_receipt_sha256=sha(receipt),scope_sha256=sha(scope_path),source_modules=j["source_modules"],fresh_modules=len(own),typed_roots=len(j["audits"]),scope_elapsed_seconds=scope["elapsed_seconds"],scope_exit_code=scope["exit_code"],scope_requested_memory_bytes=scope["requested_memory_bytes"],exact_charged_peak_bytes=None,sampled_charged_max_LOWER_BOUND_bytes=max(int(x.get("memory.current",0)) for x in samples),max_reported_own_command_child_RSS_KiB=max(x["max_child_RSS_KiB"] for x in times),own_fresh_Lean_and_final_audit_commands=times))
    result=dict(status="FOUR_COMPLETED_SOURCE_NAMESPACES_RESOURCE_MEASUREMENTS_NOT_INTERFACE_OR_GLOBAL_ACCEPTANCE",utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),selection="Exactly fresh context modules (frozen packet module names minus canonical14878) plus each namespace final typed root audit. Borrowed parent timelogs excluded.",qualification="GNU time process/child maximum RSS per command is separate from cgroup charged peak and aggregate RAM. Charged samples are LOWER BOUNDS; exact charged peaks unavailable. Source/typed-root counts overlap across contexts and must not be added.",collector_sha256=sha(Path(__file__)),python_version=sys.version,completed=rows,pending_labels=[])
    out.parent.mkdir(parents=True,exist_ok=True);temporary=out.with_name(out.name+".pending");temporary.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n");os.replace(temporary,out)
    print(json.dumps(dict(path=str(out),sha256=sha(out),completed=[{k:x[k] for k in ["label","scope_elapsed_seconds","max_reported_own_command_child_RSS_KiB","sampled_charged_max_LOWER_BOUND_bytes"]} for x in rows])))
if __name__=="__main__": main()
