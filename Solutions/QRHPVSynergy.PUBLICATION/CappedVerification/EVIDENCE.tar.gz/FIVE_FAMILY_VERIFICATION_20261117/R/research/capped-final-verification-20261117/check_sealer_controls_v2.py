"""Actual archive-acceptance CLIs in all Python optimization modes; no ANT proof claim."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

B = Path(__file__).resolve().parent
R = B.parents[1]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    out = B/'sealer-controls-v2'
    need(not out.exists(), 'fresh actual sealer controls')
    out.mkdir()
    sample = B/'check_html.py'
    template = {'schema': 1, 'status': 'REVIEWED_EXPLICIT_PUBLIC_EVIDENCE_ALLOWLIST',
                'files': [{'path': str(sample.relative_to(R)), 'bytes': sample.stat().st_size,
                           'sha256': sha(sample), 'role': 'metadata checker fixture input'}]}
    records, archives = [], []
    expected = {'nonfinite': 'finite JSON number', 'boolean-byte': 'integer nonboolean byte count',
                'wrong-hash': 'exact reviewed member bytes', 'duplicate-path': 'unique relative written path',
                'old-receipt': 'fresh artifact receipt before archive mutation'}
    for mode, flags in [('normal', []), ('O', ['-O']), ('OO', ['-OO'])]:
        for case in ['positive', *expected]:
            folder = out/(mode+'-'+case)
            folder.mkdir()
            manifest = folder/'INPUT.json'
            archive = folder/'EVIDENCE.tar.gz'
            data = json.loads(json.dumps(template))
            if case == 'boolean-byte':
                data['files'][0]['bytes'] = True
            elif case == 'wrong-hash':
                data['files'][0]['sha256'] = '0'*64
            elif case == 'duplicate-path':
                data['files'].append(dict(data['files'][0]))
            body = json.dumps(data, sort_keys=True)
            if case == 'nonfinite':
                body = body[:-1]+', "unused_overflow": 1e999}'
            manifest.write_text(body+'\n')
            receipt = folder/'EVIDENCE.tar.gz.RECEIPT.json'
            if case == 'old-receipt':
                receipt.write_text('EXISTING_FIXTURE_RECEIPT_MUST_SURVIVE\n')
                before = sha(receipt)
            command = [sys.executable, '-I', '-B', *flags, str(B/'seal_evidence.py'),
                       '--manifest', str(manifest), '--out', str(archive)]
            child = subprocess.run(command, capture_output=True, timeout=60)
            (folder/'stdout').write_bytes(child.stdout)
            (folder/'stderr').write_bytes(child.stderr)
            if case == 'positive':
                need(child.returncode == 0 and archive.is_file() and receipt.is_file(), 'actual positive archive and receipt')
                value = json.loads(receipt.read_text())
                need(value['status'] == 'PASS_REVIEWED_SOURCE_EVIDENCE_ARCHIVE_MEMBERS_AND_BYTES'
                     and value['sha256'] == sha(archive), 'actual complete archive acceptance')
                archives.append(sha(archive))
            else:
                need(child.returncode == 1 and not child.stdout
                     and child.stderr.decode().splitlines()[-1] == 'ValueError: '+expected[case]
                     and not archive.exists() and not archive.with_suffix('.gz.pending').exists(),
                     'negative reaches exact intended guard before archive publication')
                need(sha(receipt) == before if case == 'old-receipt' else not receipt.exists(),
                     'prior receipt preserved and no false new receipt')
            records.append({'mode': mode, 'case': case, 'command': command,
                            'exit_code': child.returncode, 'stdout_sha256': sha(folder/'stdout'),
                            'stderr_sha256': sha(folder/'stderr')})
    need(len(records) == 18 and len(set(archives)) == 1, 'all18 actual CLIs and deterministic archive across optimization modes')
    result = {'status': 'PASS_SEALER18_ACTUAL_CLI_CONTROLS_NORMAL_O_OO',
              'script_sha256': sha(Path(__file__)), 'sealer_sha256': sha(B/'seal_evidence.py'),
              'records': records, 'positive_archive_sha256': archives[0],
              'qualification': 'Artifact-byte and rejection checks only; no mathematical or source-first program-verification result.'}
    pending = out/'RECEIPT.json.pending'
    pending.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    os.replace(pending, out/'RECEIPT.json')
    print(result['status'])


if __name__ == '__main__':
    main()
