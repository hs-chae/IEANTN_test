# MomentPNT source and verification evidence

Open network/Solutions/MomentPNT.v1/README.md for clean source and exactly validated read-only-parent reproduction. The archive includes the complete support source, core snapshot, portable generic environment preparer and actual isolated append evidence. Its normal Lake path dependency is complete inside this network layout. Dependencies are pinned public generic libraries; no private warm proof cache is an accepted environment input.

Actual acceptance:8 fresh modules over the separately validated isolated4486 source-built read-only parent; all6 current Challenge types exactly compared in separate environments; all6 complete closures use only propext, Classical.choice and Quot.sound. The actual Solution environment never imports the admitted Challenge template. Runtime130.30seconds,16GiB reservation,0OOM; exact measurements are in evidence/resource-scope.json. This is a chained source-cold append, not an empty-bank proof and not an official IEANTN Comparator receipt.

The source-program moment claims consume physical source-derived reads. The direct-vector control remains ordinary-kernel verification; PrimeRich is derived from only the future profile. All14 original analytic inputs remain explicit. Compiler/runtime/ABI/linker/CRT, modeled normal-I/O, OS/hardware trust boundaries are retained. No optimality, best-known-result or PV necessity claim is made.

The new objects in evidence/new-objects are retained generated artifacts, not source inputs to reproduction. Expected Challenge template objects are deliberately excluded from that directory. The original accepted4486 parent objects are not duplicated here; reproduce them using the included full source recipe or supply the exact locked independently accepted parent.

Source files, exact parameters, dependency versions/commits, commands, numerical generators, receipts and artifact hashes are preserved. Bundle-manifest paths have no symlinks, Git history, private memory or unrelated workspaces.
