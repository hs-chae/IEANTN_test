/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import SynergyC.PositiveSubBody
import SynergyC.SourceIntervalMath
import SynergyBasis.PositiveDivision

namespace SynergyC.SourceIntervalMath
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
open ScopedNumerical SynergyBasis
set_option autoImplicit false
set_option maxHeartbeats 0

theorem source_positiveSub (code : List Function) (installed : Generated.f_positiveSub ∈ code)
    (s : State) {a b : ProofBox} (ha : representable a) (hb : representable b) :
    SourceCall Header.layout code 1 "positiveSub" [represented a,represented b] s
      (represented (Positive.positiveSub a b)) s := by
  rw [Positive.positiveSub_endpoints]
  exact PositiveSubBody.source_positiveSub code installed s ha.1 ha.2 hb.1 hb.2

theorem source_positiveSub_enclosure (code : List Function) (installed : Generated.f_positiveSub ∈ code)
    (s : State) {a b : ProofBox} {x y : ℝ} (ha : representable a) (hb : representable b)
    (hx : RealBox.Contains 128 a x) (hy : RealBox.Contains 128 b y) :
    SourceCall Header.layout code 1 "positiveSub" [represented a,represented b] s
      (represented (Positive.positiveSub a b)) s ∧
      RealBox.Contains 128 (Positive.positiveSub a b) (max 0 (x-y)) :=
  ⟨source_positiveSub code installed s ha hb,Positive.positiveSub_sound hx hy⟩

end SynergyC.SourceIntervalMath
