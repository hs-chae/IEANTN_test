/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.SourceBundle.Tree
import SynergyC.Header
import SynergyC.Generated
namespace SynergyC.Bundle
open ScopedC.Syntax ScopedC.SourceBundle
set_option maxHeartbeats 0
set_option maxRecDepth 100000
inductive Piece where
  | prelude
  | typeDecl (d : Header.TypeDecl)
  | global (d : Decl)
  | function (f : Function)
inductive Piece.Bound : Piece → File → Prop where
  | prelude {file} (h : file.text = Header.externalPrelude) : Bound .prelude file
  | typeDecl {d file} (h : file.text = Header.renderType d) : Bound (.typeDecl d) file
  | global {d file} (h : (do pure ("static "++(←renderDecl d)++";\n")) = some file.text) : Bound (.global d) file
  | function {f file} (h : renderFunction f = some file.text) : Bound (.function f) file

def file0 : File := ⟨"prelude.inc",include_str "../../payloads/a2238618d35c63d38ba3dbac5814c15fb430caaf2297833f275e40b5503f8367-prelude.inc"⟩
def piece0 : Piece := .prelude
theorem bound0 : Piece.Bound piece0 file0 := .prelude (by rfl)
def tree0 : ScopedC.SourceBundle.Tree Piece := .leaf file0 piece0
theorem tree_bound0 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree0 := .leaf bound0
def file1 : File := ⟨"type_U.inc",include_str "../../payloads/fb521cb83ba91e5314ee96993acb2e8c290f427c444ae994957e8ae0e0688334-type_U.inc"⟩
def piece1 : Piece := .typeDecl (.unsignedAlias "U" 512)
theorem bound1 : Piece.Bound piece1 file1 := .typeDecl (by rfl)
def tree1 : ScopedC.SourceBundle.Tree Piece := .leaf file1 piece1
theorem tree_bound1 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree1 := .leaf bound1
def file2 : File := ⟨"type_I.inc",include_str "../../payloads/59168d82e720996eb78c3b7c0e99fa2f108ac27a0d8c3df4010581f2efa3abc1-type_I.inc"⟩
def piece2 : Piece := .typeDecl (.record "I" [("U","lo"),("U","hi")])
theorem bound2 : Piece.Bound piece2 file2 := .typeDecl (by rfl)
def tree2 : ScopedC.SourceBundle.Tree Piece := .leaf file2 piece2
theorem tree_bound2 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree2 := .leaf bound2
def file3 : File := ⟨"global_S.inc",include_str "../../payloads/13f08b71d1275ce9d5ef8bb9d7887d2b0351c844abd731b1e14bbcb7778a731c-global_S.inc"⟩
def piece3 : Piece := .global {type:="const U",name:="S",value:=(some (.binary "<<" (.cast "U" (.nat 1)) (.nat 128))),arrayExtent:=none}
theorem bound3 : Piece.Bound piece3 file3 := .global (by decide +kernel)
def tree3 : ScopedC.SourceBundle.Tree Piece := .leaf file3 piece3
theorem tree_bound3 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree3 := .leaf bound3
def file4 : File := ⟨"global_MAXU.inc",include_str "../../payloads/f7bf8c0c70015e46c04b90a19bd693b743b32bc04a053cbd038f5870b43c78bd-global_MAXU.inc"⟩
def piece4 : Piece := .global {type:="const U",name:="MAXU",value:=(some (.cast "U" (.unary "-" (.nat 1)))),arrayExtent:=none}
theorem bound4 : Piece.Bound piece4 file4 := .global (by decide +kernel)
def tree4 : ScopedC.SourceBundle.Tree Piece := .leaf file4 piece4
theorem tree_bound4 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree4 := .leaf bound4
def file5 : File := ⟨"global_ln2.inc",include_str "../../payloads/145cfe8fcb25ddb864df4ce5eeaec163eba8fb435ff4971ef816b90bfcf091da-global_ln2.inc"⟩
def piece5 : Piece := .global {type:="I",name:="ln2",value:=none,arrayExtent:=none}
theorem bound5 : Piece.Bound piece5 file5 := .global (by decide +kernel)
def tree5 : ScopedC.SourceBundle.Tree Piece := .leaf file5 piece5
theorem tree_bound5 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree5 := .leaf bound5
def file6 : File := ⟨"function_fail.inc",include_str "../../payloads/c9063ec33e9bcb7d34685ccf1643a35c3e48e8a019db46213fa904626d5486cc-function_fail.inc"⟩
def piece6 : Piece := .function Generated.f_fail
theorem bound6 : Piece.Bound piece6 file6 := .function (by simpa only [file6] using Generated.render_fail)
def tree6 : ScopedC.SourceBundle.Tree Piece := .leaf file6 piece6
theorem tree_bound6 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree6 := .leaf bound6
def file7 : File := ⟨"function_addU.inc",include_str "../../payloads/98700f6ccb2a4e3ec7d0b8bfcb7f0cabbf0e9010786d82b2c50b0bb0189017aa-function_addU.inc"⟩
def piece7 : Piece := .function Generated.f_addU
theorem bound7 : Piece.Bound piece7 file7 := .function (by simpa only [file7] using Generated.render_addU)
def tree7 : ScopedC.SourceBundle.Tree Piece := .leaf file7 piece7
theorem tree_bound7 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree7 := .leaf bound7
def file8 : File := ⟨"function_mulU.inc",include_str "../../payloads/7085b951aab27ff25458df95e812925528d943eddbbeb3c2928b302430fc6b6c-function_mulU.inc"⟩
def piece8 : Piece := .function Generated.f_mulU
theorem bound8 : Piece.Bound piece8 file8 := .function (by simpa only [file8] using Generated.render_mulU)
def tree8 : ScopedC.SourceBundle.Tree Piece := .leaf file8 piece8
theorem tree_bound8 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree8 := .leaf bound8
def file9 : File := ⟨"function_ceilDiv.inc",include_str "../../payloads/614fdc276986d14899bcfef7104d75441194ee386afbd1d4c6e5de5e007a8589-function_ceilDiv.inc"⟩
def piece9 : Piece := .function Generated.f_ceilDiv
theorem bound9 : Piece.Bound piece9 file9 := .function (by simpa only [file9] using Generated.render_ceilDiv)
def tree9 : ScopedC.SourceBundle.Tree Piece := .leaf file9 piece9
theorem tree_bound9 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree9 := .leaf bound9
def file10 : File := ⟨"function_rat.inc",include_str "../../payloads/600a167bf3fa36e26d0915b956e8f56e3d17b353b65a09909c8affeef22760b5-function_rat.inc"⟩
def piece10 : Piece := .function Generated.f_rat
theorem bound10 : Piece.Bound piece10 file10 := .function (by simpa only [file10] using Generated.render_rat)
def tree10 : ScopedC.SourceBundle.Tree Piece := .leaf file10 piece10
theorem tree_bound10 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree10 := .leaf bound10
def file11 : File := ⟨"function_unit.inc",include_str "../../payloads/298deceda7bb8f95b4d09d133d5d52c53790ccd832dd6238a85b4356ded3ae4f-function_unit.inc"⟩
def piece11 : Piece := .function Generated.f_unit
theorem bound11 : Piece.Bound piece11 file11 := .function (by simpa only [file11] using Generated.render_unit)
def tree11 : ScopedC.SourceBundle.Tree Piece := .leaf file11 piece11
theorem tree_bound11 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree11 := .leaf bound11
def file12 : File := ⟨"function_zero.inc",include_str "../../payloads/b64af6d98ffe56ddb47b3027b6b5166fb17b0e563ca6a93dde8573e37c55ab0b-function_zero.inc"⟩
def piece12 : Piece := .function Generated.f_zero
theorem bound12 : Piece.Bound piece12 file12 := .function (by simpa only [file12] using Generated.render_zero)
def tree12 : ScopedC.SourceBundle.Tree Piece := .leaf file12 piece12
theorem tree_bound12 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree12 := .leaf bound12
def file13 : File := ⟨"function_add.inc",include_str "../../payloads/944c0eb8c98507502d81eafa54caa2513c80a1bb967db452e40a382d470f5242-function_add.inc"⟩
def piece13 : Piece := .function Generated.f_add
theorem bound13 : Piece.Bound piece13 file13 := .function (by simpa only [file13] using Generated.render_add)
def tree13 : ScopedC.SourceBundle.Tree Piece := .leaf file13 piece13
theorem tree_bound13 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree13 := .leaf bound13
def file14 : File := ⟨"function_mul.inc",include_str "../../payloads/e94c945d726f9f21834e94f700449847643a11cc50e47c660def63849885fdd1-function_mul.inc"⟩
def piece14 : Piece := .function Generated.f_mul
theorem bound14 : Piece.Bound piece14 file14 := .function (by simpa only [file14] using Generated.render_mul)
def tree14 : ScopedC.SourceBundle.Tree Piece := .leaf file14 piece14
theorem tree_bound14 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree14 := .leaf bound14
def file15 : File := ⟨"function_divI.inc",include_str "../../payloads/e0bba4374e428c6ce0cd9cd32502da3c910de553ec1a10638093f4d59d99d838-function_divI.inc"⟩
def piece15 : Piece := .function Generated.f_divI
theorem bound15 : Piece.Bound piece15 file15 := .function (by simpa only [file15] using Generated.render_divI)
def tree15 : ScopedC.SourceBundle.Tree Piece := .leaf file15 piece15
theorem tree_bound15 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree15 := .leaf bound15
def file16 : File := ⟨"function_divN.inc",include_str "../../payloads/a2a1cd4449e0fe55fa055ea743fdec61aac81d8de58e81e555a1ebbb21abd302-function_divN.inc"⟩
def piece16 : Piece := .function Generated.f_divN
theorem bound16 : Piece.Bound piece16 file16 := .function (by simpa only [file16] using Generated.render_divN)
def tree16 : ScopedC.SourceBundle.Tree Piece := .leaf file16 piece16
theorem tree_bound16 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree16 := .leaf bound16
def file17 : File := ⟨"function_positiveSub.inc",include_str "../../payloads/55b94739b90267d943a1d8c15509fa4fc1a4df896ab8473983c334deea8f69ff-function_positiveSub.inc"⟩
def piece17 : Piece := .function Generated.f_positiveSub
theorem bound17 : Piece.Bound piece17 file17 := .function (by simpa only [file17] using Generated.render_positiveSub)
def tree17 : ScopedC.SourceBundle.Tree Piece := .leaf file17 piece17
theorem tree_bound17 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree17 := .leaf bound17
def file18 : File := ⟨"function_expNeg.inc",include_str "../../payloads/4ba08ceb64b1f4a2e596fffd54cb6f3f724460e8b313f99ab436dbc72b1c073c-function_expNeg.inc"⟩
def piece18 : Piece := .function Generated.f_expNeg
theorem bound18 : Piece.Bound piece18 file18 := .function (by simpa only [file18] using Generated.render_expNeg)
def tree18 : ScopedC.SourceBundle.Tree Piece := .leaf file18 piece18
theorem tree_bound18 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree18 := .leaf bound18
def file19 : File := ⟨"function_atanh2.inc",include_str "../../payloads/cedce9f1e84f80d0efbf9534119296168362ce340b2381337a8851a9ad51b6c2-function_atanh2.inc"⟩
def piece19 : Piece := .function Generated.f_atanh2
theorem bound19 : Piece.Bound piece19 file19 := .function (by simpa only [file19] using Generated.render_atanh2)
def tree19 : ScopedC.SourceBundle.Tree Piece := .leaf file19 piece19
theorem tree_bound19 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree19 := .leaf bound19
def file20 : File := ⟨"function_logPos.inc",include_str "../../payloads/830e29e0cd9853d18a7687a5610d33d0cd1998bdef01e34282f2662bc08a1dd3-function_logPos.inc"⟩
def piece20 : Piece := .function Generated.f_logPos
theorem bound20 : Piece.Bound piece20 file20 := .function (by simpa only [file20] using Generated.render_logPos)
def tree20 : ScopedC.SourceBundle.Tree Piece := .leaf file20 piece20
theorem tree_bound20 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree20 := .leaf bound20
def file21 : File := ⟨"function_floorCube.inc",include_str "../../payloads/177c5a4e89ef4eb4f4cb5bc41c60862c6fd0871137ed5598155e133c60a99f5a-function_floorCube.inc"⟩
def piece21 : Piece := .function Generated.f_floorCube
theorem bound21 : Piece.Bound piece21 file21 := .function (by simpa only [file21] using Generated.render_floorCube)
def tree21 : ScopedC.SourceBundle.Tree Piece := .leaf file21 piece21
theorem tree_bound21 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree21 := .leaf bound21
def file22 : File := ⟨"function_cubeRoot.inc",include_str "../../payloads/1f5fa7cb80056a0ff46170ac55d95d3460cd6d6248816744ab9e9cd29210cd32-function_cubeRoot.inc"⟩
def piece22 : Piece := .function Generated.f_cubeRoot
theorem bound22 : Piece.Bound piece22 file22 := .function (by simpa only [file22] using Generated.render_cubeRoot)
def tree22 : ScopedC.SourceBundle.Tree Piece := .leaf file22 piece22
theorem tree_bound22 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree22 := .leaf bound22
def file23 : File := ⟨"function_gaussianCell.inc",include_str "../../payloads/c3c815a1ac4ebdbc7f9d610bdb0b603d342643b5cd2d02a1e3f982deeb344bf1-function_gaussianCell.inc"⟩
def piece23 : Piece := .function Generated.f_gaussianCell
theorem bound23 : Piece.Bound piece23 file23 := .function (by simpa only [file23] using Generated.render_gaussianCell)
def tree23 : ScopedC.SourceBundle.Tree Piece := .leaf file23 piece23
theorem tree_bound23 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree23 := .leaf bound23
def file24 : File := ⟨"function_main.inc",include_str "../../payloads/9bc3d844bce5daba7daf6d0015af2417e4554322569b1efab524445ce607fed2-function_main.inc"⟩
def piece24 : Piece := .function Generated.f_main
theorem bound24 : Piece.Bound piece24 file24 := .function (by simpa only [file24] using Generated.render_main)
def tree24 : ScopedC.SourceBundle.Tree Piece := .leaf file24 piece24
theorem tree_bound24 : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree24 := .leaf bound24
def join_file0 : File := ⟨"join_000.inc",include_str "../../payloads/7681d9e6107cc2070291ba0996b2a00b74cdd924c3e97729540c406b2a1bb915-join_000.inc"⟩
def join_tree0 : ScopedC.SourceBundle.Tree Piece := .pair join_file0 tree1 tree2
theorem join_bound0 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree0 := .pair tree_bound1 tree_bound2 (by decide +kernel)
def join_file1 : File := ⟨"join_001.inc",include_str "../../payloads/71920d4f765b1b2f6964811ea78ed460521ac3a0549d7f209218fe6c1fa9853b-join_001.inc"⟩
def join_tree1 : ScopedC.SourceBundle.Tree Piece := .pair join_file1 tree0 join_tree0
theorem join_bound1 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree1 := .pair tree_bound0 join_bound0 (by decide +kernel)
def join_file2 : File := ⟨"join_002.inc",include_str "../../payloads/0f48c4ed08a0f5a9eff7e13564dadaf41b2e86859de69a75b69345cf40d38654-join_002.inc"⟩
def join_tree2 : ScopedC.SourceBundle.Tree Piece := .pair join_file2 tree4 tree5
theorem join_bound2 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree2 := .pair tree_bound4 tree_bound5 (by decide +kernel)
def join_file3 : File := ⟨"join_003.inc",include_str "../../payloads/44427726a80d94b75f32abcbc113fc1ae73e50762abeff41c43ceeac48d5a7e5-join_003.inc"⟩
def join_tree3 : ScopedC.SourceBundle.Tree Piece := .pair join_file3 tree3 join_tree2
theorem join_bound3 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree3 := .pair tree_bound3 join_bound2 (by decide +kernel)
def join_file4 : File := ⟨"join_004.inc",include_str "../../payloads/e73843c7905989b625bbea01cb48dc9017d898b1b63b182b142f91229c8dac87-join_004.inc"⟩
def join_tree4 : ScopedC.SourceBundle.Tree Piece := .pair join_file4 join_tree1 join_tree3
theorem join_bound4 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree4 := .pair join_bound1 join_bound3 (by decide +kernel)
def join_file5 : File := ⟨"join_005.inc",include_str "../../payloads/f1c03322d0b97fd277e03ea8e4150de284cacaf5ab17f5a64d567108b39d4c90-join_005.inc"⟩
def join_tree5 : ScopedC.SourceBundle.Tree Piece := .pair join_file5 tree7 tree8
theorem join_bound5 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree5 := .pair tree_bound7 tree_bound8 (by decide +kernel)
def join_file6 : File := ⟨"join_006.inc",include_str "../../payloads/12a4d89ccfa4db7c2f9765861474dc7724ae64bb8d45f332630ab9897c4cd08c-join_006.inc"⟩
def join_tree6 : ScopedC.SourceBundle.Tree Piece := .pair join_file6 tree6 join_tree5
theorem join_bound6 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree6 := .pair tree_bound6 join_bound5 (by decide +kernel)
def join_file7 : File := ⟨"join_007.inc",include_str "../../payloads/8302c992a4a7e32c5d03dc0211de9c9c2eb07ade211e364c2a2dd8ce5bac05f9-join_007.inc"⟩
def join_tree7 : ScopedC.SourceBundle.Tree Piece := .pair join_file7 tree10 tree11
theorem join_bound7 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree7 := .pair tree_bound10 tree_bound11 (by decide +kernel)
def join_file8 : File := ⟨"join_008.inc",include_str "../../payloads/533cfc89913f00d16c1aa84f615ac697e508e2bf1f7c6f444c688aa0fa473859-join_008.inc"⟩
def join_tree8 : ScopedC.SourceBundle.Tree Piece := .pair join_file8 tree9 join_tree7
theorem join_bound8 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree8 := .pair tree_bound9 join_bound7 (by decide +kernel)
def join_file9 : File := ⟨"join_009.inc",include_str "../../payloads/806821f2f023778ccf158c4d64e92238ee3e3463dfd954c8afa51af62a146006-join_009.inc"⟩
def join_tree9 : ScopedC.SourceBundle.Tree Piece := .pair join_file9 join_tree6 join_tree8
theorem join_bound9 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree9 := .pair join_bound6 join_bound8 (by decide +kernel)
def join_file10 : File := ⟨"join_010.inc",include_str "../../payloads/44e458fd43a87b36733173dfdd70bd3656ac7320f465ba7adb3b857144a5cf85-join_010.inc"⟩
def join_tree10 : ScopedC.SourceBundle.Tree Piece := .pair join_file10 join_tree4 join_tree9
theorem join_bound10 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree10 := .pair join_bound4 join_bound9 (by decide +kernel)
def join_file11 : File := ⟨"join_011.inc",include_str "../../payloads/4b3c299cbedbec658ce01e66d23a81a2a23b083c0d97471514a048b80ed33022-join_011.inc"⟩
def join_tree11 : ScopedC.SourceBundle.Tree Piece := .pair join_file11 tree13 tree14
theorem join_bound11 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree11 := .pair tree_bound13 tree_bound14 (by decide +kernel)
def join_file12 : File := ⟨"join_012.inc",include_str "../../payloads/b70812a803fc8de6e8274a50d91bbe60c81efdd29dfd2c3d9518aaa31a4eea01-join_012.inc"⟩
def join_tree12 : ScopedC.SourceBundle.Tree Piece := .pair join_file12 tree12 join_tree11
theorem join_bound12 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree12 := .pair tree_bound12 join_bound11 (by decide +kernel)
def join_file13 : File := ⟨"join_013.inc",include_str "../../payloads/cd933c9749a0e4092bcb1b651ed8317d9066dfbded6d10c0050be00248819387-join_013.inc"⟩
def join_tree13 : ScopedC.SourceBundle.Tree Piece := .pair join_file13 tree16 tree17
theorem join_bound13 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree13 := .pair tree_bound16 tree_bound17 (by decide +kernel)
def join_file14 : File := ⟨"join_014.inc",include_str "../../payloads/a1db01b0e570594cdb498af14c91c7057c51baba0ca5a112a1a261f82ab773f8-join_014.inc"⟩
def join_tree14 : ScopedC.SourceBundle.Tree Piece := .pair join_file14 tree15 join_tree13
theorem join_bound14 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree14 := .pair tree_bound15 join_bound13 (by decide +kernel)
def join_file15 : File := ⟨"join_015.inc",include_str "../../payloads/c49f3b440cc8e43d766df14e827be5c6836cea6bf1265641c7794dd768c9478c-join_015.inc"⟩
def join_tree15 : ScopedC.SourceBundle.Tree Piece := .pair join_file15 join_tree12 join_tree14
theorem join_bound15 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree15 := .pair join_bound12 join_bound14 (by decide +kernel)
def join_file16 : File := ⟨"join_016.inc",include_str "../../payloads/9b546704aef386d16a609fbf66b221762d6ba64f7dd4a074caa08507f9793db1-join_016.inc"⟩
def join_tree16 : ScopedC.SourceBundle.Tree Piece := .pair join_file16 tree19 tree20
theorem join_bound16 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree16 := .pair tree_bound19 tree_bound20 (by decide +kernel)
def join_file17 : File := ⟨"join_017.inc",include_str "../../payloads/e3d40eaa249e05a49f29022eee648dacd517898ea662f3929f2f1d5052cdf0b4-join_017.inc"⟩
def join_tree17 : ScopedC.SourceBundle.Tree Piece := .pair join_file17 tree18 join_tree16
theorem join_bound17 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree17 := .pair tree_bound18 join_bound16 (by decide +kernel)
def join_file18 : File := ⟨"join_018.inc",include_str "../../payloads/62e65fd79d4f28e8795be453d987f8faddc9dcf5f90e44414ab44e330752a2de-join_018.inc"⟩
def join_tree18 : ScopedC.SourceBundle.Tree Piece := .pair join_file18 tree21 tree22
theorem join_bound18 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree18 := .pair tree_bound21 tree_bound22 (by decide +kernel)
def join_file19 : File := ⟨"join_019.inc",include_str "../../payloads/d6d9eec359032fbb03b9f48082888ea40e5adbd4623c6b6058a7f79c24503df7-join_019.inc"⟩
def join_tree19 : ScopedC.SourceBundle.Tree Piece := .pair join_file19 tree23 tree24
theorem join_bound19 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree19 := .pair tree_bound23 tree_bound24 (by decide +kernel)
def join_file20 : File := ⟨"join_020.inc",include_str "../../payloads/89e2fcc13b63b416f3f6cc24fa9e1ee9adbd5930a41ab532e0cda2e7736db79a-join_020.inc"⟩
def join_tree20 : ScopedC.SourceBundle.Tree Piece := .pair join_file20 join_tree18 join_tree19
theorem join_bound20 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree20 := .pair join_bound18 join_bound19 (by decide +kernel)
def join_file21 : File := ⟨"join_021.inc",include_str "../../payloads/5dfc0d1f8e3b49a13149da8918d41bccdebcb3fdb7a99fb15d165caf203eceec-join_021.inc"⟩
def join_tree21 : ScopedC.SourceBundle.Tree Piece := .pair join_file21 join_tree17 join_tree20
theorem join_bound21 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree21 := .pair join_bound17 join_bound20 (by decide +kernel)
def join_file22 : File := ⟨"join_022.inc",include_str "../../payloads/ef80b06f775f257180287f3a0fd8855658f05827d4a5782a0e762cb00f718682-join_022.inc"⟩
def join_tree22 : ScopedC.SourceBundle.Tree Piece := .pair join_file22 join_tree15 join_tree21
theorem join_bound22 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree22 := .pair join_bound15 join_bound21 (by decide +kernel)
def join_file23 : File := ⟨"join_023.inc",include_str "../../payloads/20f61c6360e79acce52fa08a04441d277e589e1b86c05ea9385f169b59c768e4-join_023.inc"⟩
def join_tree23 : ScopedC.SourceBundle.Tree Piece := .pair join_file23 join_tree10 join_tree22
theorem join_bound23 : ScopedC.SourceBundle.Tree.Bound Piece.Bound join_tree23 := .pair join_bound10 join_bound22 (by decide +kernel)
def tree : ScopedC.SourceBundle.Tree Piece := join_tree23
theorem bound : ScopedC.SourceBundle.Tree.Bound Piece.Bound tree := join_bound23
def code : List Function := tree.values.flatMap (fun p => match p with | .function f => [f] | _ => [])
theorem code_exact : code = Generated.functions := by rfl
def actualFiles : List File := tree.files ++ [⟨"basis_bundle.cpp",include_str "../../payloads/7863d969e1ccaa982b3a355977c754bdd0ca3cf36184593ce330275c9491d6ea-basis_bundle.cpp"⟩]
#print axioms bound
#print axioms code_exact
end SynergyC.Bundle
