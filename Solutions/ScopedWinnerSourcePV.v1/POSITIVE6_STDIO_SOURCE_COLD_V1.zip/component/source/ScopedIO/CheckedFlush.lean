/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedIO.Contracts
import ScopedCheckedIO.Bindings
import ScopedC.ExpressionBinary
import ScopedC.Header

namespace ScopedIO.CheckedFlush
open ScopedC ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def condition : Expr := .binary "!=" (.call (.var "fflush") [.var "stdout"]) (.nat 0)
def statement : Stmt := .branch condition (.eval (.call (.var "fail") [])) .skip

theorem actual_main_statement :
    (match ScopedCheckedIO.f_main.body with | .sequence xs => xs[2]? | _ => none) =
      some statement := rfl

/-- Actual source-memory applicability of the external stdout handle.
The opaque stream slot is a generic platform object; this context neither
asserts application initialization nor an expected numerical output. -/
structure Context (platform : Platform) (s : State) where
  address : Address
  located : getVar s "stdout" = some address
  object : Object
  heap_entry : s.heap[address.object]? = some object
  scalar : object.isArray = false
  contents : Machine.read ScopedC.Header.layout s address =
    some (.pointer ⟨platform.stdoutSlot,0,[]⟩ true)

theorem eval_stdout (platform : Platform) (service : Call) (fuel : Nat)
    {s : State} (ctx : Context platform s) :
    evalExpr ScopedC.Header.layout service (fuel+1) s (.var "stdout") =
      some (.pointer ⟨platform.stdoutSlot,0,[]⟩ true,s) := by
  rw [evalExpr]
  simp [ctx.located,ctx.heap_entry,ctx.scalar,ctx.contents]

/-- This is a conditional *execution theorem* for the actual checked source
branch, universal in the fault policy. No success value is installed as an
axiom; the separate zero-return contract derives delivery from API behavior.
The complete application printing/whole-main theorem is still required. -/
theorem actual_checked_flush_success (platform : Platform) (fault : FaultPolicy)
    {s : State} {before : Stream} (ctx : Context platform s)
    (read : readStream s platform.stdoutSlot = some before)
    (ok : fault.succeed "fflush" s = true) :
    ∃ t, Run ScopedC.Header.layout (external platform fault) statement s (.continuing t) ∧
      ∃ after, readStream t platform.stdoutSlot = some after ∧
        after.accepted = before.accepted ∧ after.delivered = before.accepted.length := by
  let t := storeStream s platform.stdoutSlot (flush before true (fault.count "fflush" s))
  have call : external platform fault "fflush" [.pointer ⟨platform.stdoutSlot,0,[]⟩ true] s =
      some (intResult 0,t) := by
    change stdio platform fault "fflush" [.pointer ⟨platform.stdoutSlot,0,[]⟩ true] s = _
    simpa only [ok,↓reduceIte,t] using fflush_equation platform fault read true
  have ce : evalExpr ScopedC.Header.layout (external platform fault) 4 s
      (.call (.var "fflush") [.var "stdout"]) = some (intResult 0,t) :=
    ExpressionTemplates.call_one ScopedC.Header.layout (external platform fault)
      (eval_stdout platform _ 2 ctx) call
  have check : Eval ScopedC.Header.layout (external platform fault) condition s t
      (boolean ScopedC.Header.layout false) := by
    refine ⟨5,?_⟩
    exact ExpressionTemplates.binary ScopedC.Header.layout (external platform fault)
      (by decide) (by decide) (by decide) (by decide) ce (by rfl) (by rfl)
  refine ⟨t,?_,?_⟩
  · apply Loops.StmtRun.branch check
    exact Loops.StmtRun.skip t
  · apply fflush_zero platform fault true read
    change stdio platform fault "fflush" [.pointer ⟨platform.stdoutSlot,0,[]⟩ true] s = _
    simpa only [ok,↓reduceIte,t] using fflush_equation platform fault read true

end ScopedIO.CheckedFlush
