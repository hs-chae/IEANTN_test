/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedIO.Storage

namespace ScopedIO
open ScopedC ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

structure Platform where
  stdoutSlot : Nat

/-- Arbitrary generic I/O failures and partial acceptance. No success policy
is asserted for the application. The application proofs must hold for every
such policy and use the checked source branches. -/
structure FaultPolicy where
  succeed : String → State → Bool
  count : String → State → Nat

def intResult (n : Int) : Value := .integer ⟨⟨true,32⟩,n⟩

def readCString : Nat → State → Address → Option (List Nat)
  | 0,_,_ => none
  | fuel+1,s,a => do
    if !a.fields.isEmpty then none else
    let obj ← s.heap[a.object]?
    if obj.type != "char" || !obj.isArray then none else
    let some (.integer v) ← obj.cells[a.index]? | none
    if v.number = 0 then some [] else
    if 0 < v.number ∧ v.number < 128 then
      let rest ← readCString fuel s {a with index:=a.index+1}
      pure (v.number.toNat::rest)
    else none

def ascii (s : String) : List Nat := s.toList.map Char.toNat

/-- Precisely the two actual printf formats used by printI. There is no
fallback accepting an unparsed or arbitrary application-produced string. -/
def printfBytes (args : List Value) (s : State) : Option (List Nat) := do
  match args with
  | [.pointer address _] =>
    let text ← readCString 64 s address
    if text = ascii ",-100," then some text else none
  | [.pointer address _,.integer n] =>
    let text ← readCString 64 s address
    if text = ascii ",-100,%u\n" ∧ n.type = ⟨false,32⟩ ∧ 0 ≤ n.number ∧ n.number < 2^32 then
      some (ascii ",-100," ++ ascii (toString n.number.toNat) ++ [10])
    else none
  | _ => none

def stdio (platform : Platform) (fault : FaultPolicy) : Call := fun name args s => do
  let before ← readStream s platform.stdoutSlot
  if name = "putchar" then
    let [.integer c] := args | none
    if Scalar.InRange ⟨true,32⟩ c.number then
      let byte := (c.number%256).toNat
      let ok := fault.succeed name s
      let after := writeBytes before [byte] ok (fault.count name s)
      some (intResult (if ok then byte else -1),storeStream s platform.stdoutSlot after)
    else none
  else if name = "printf" then
    let bytes ← printfBytes args s
    if bytes.length < 2^31 then
      let ok := fault.succeed name s
      let after := writeBytes before bytes ok (fault.count name s)
      some (intResult (if ok then bytes.length else -1),storeStream s platform.stdoutSlot after)
    else none
  else if name = "fflush" then
    let [.pointer handle _] := args | none
    if handle = (⟨platform.stdoutSlot,0,[]⟩ : Address) then
      let ok := fault.succeed name s
      some (intResult (if ok then 0 else -1),
        storeStream s platform.stdoutSlot (flush before ok (fault.count name s)))
    else none
  else none

/-- Generic Nat operations have their preserved original contract. Only
documented stdio calls are added; evaluate/runRow/main and mathematical
operations never become platform leaves. -/
def external (platform : Platform) (fault : FaultPolicy) : Call := fun name args s =>
  match RuntimeCore.call name args s with
  | some result => some result
  | none => stdio platform fault name args s

theorem runtime_included (platform : Platform) (fault : FaultPolicy)
    {name : String} {args : List Value} {s t : State} {v : Value}
    (h : RuntimeCore.call name args s = some (v,t)) :
    external platform fault name args s = some (v,t) := by simp [external,h]

theorem no_application_leaves (platform : Platform) (fault : FaultPolicy)
    (args : List Value) (s : State) :
    external platform fault "evaluate" args s = none ∧
    external platform fault "runRow" args s = none ∧
    external platform fault "main" args s = none := by
  cases h : readStream s platform.stdoutSlot <;>
    simp [external,RuntimeCore.call,RuntimeCore.binaryName,stdio,h,Option.bind]

end ScopedIO
