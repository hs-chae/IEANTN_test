/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedIO.Stream

namespace ScopedIO
open ScopedC ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Representation of an opaque platform FILE contract in the abstract heap.
These are ghost fields, not claimed libc struct offsets or compiled data.
Application source never inspects them. Their slot must be disjoint from the
application's arrays/locals, and present before its verified initialization. -/
def ghostNat (n : Nat) : Value := .integer ⟨⟨false,64⟩,(n:Int)⟩

def streamObject (st : Stream) : Object := {
  type:="FILE"
  cells:=[some (.aggregate (st.accepted.map ghostNat)),some (ghostNat st.delivered),
    some (ghostNat (if st.error then 1 else 0))]
  isArray:=false
  writable:=true}

def decodeNat : Value → Option Nat
  | .integer n => if 0 ≤ n.number then some n.number.toNat else none
  | _ => none

def decodeObject (obj : Object) : Option Stream := do
  if obj.type != "FILE" || obj.isArray then none else
  let [some (.aggregate values),some count,some failed] := obj.cells | none
  let bytes ← values.mapM decodeNat
  let delivered ← decodeNat count
  let flag ← decodeNat failed
  if flag > 1 then none else
  pure ⟨bytes,delivered,flag == 1⟩

def readStream (s : State) (slot : Nat) : Option Stream := do
  let obj ← s.heap[slot]?
  decodeObject obj

def storeStream (s : State) (slot : Nat) (st : Stream) : State :=
  {s with heap:=s.heap.set slot (streamObject st)}

theorem decode_ghost_nat (n : Nat) : decodeNat (ghostNat n) = some n := by
  simp [decodeNat,ghostNat]

theorem decode_ghost_bytes (bytes : List Nat) :
    (bytes.map ghostNat).mapM decodeNat = some bytes := by
  induction bytes with
  | nil => rfl
  | cons b bs ih => simp [decode_ghost_nat,ih]

theorem decode_ghost_composed (bytes : List Nat) :
    bytes.mapM (decodeNat ∘ ghostNat) = some bytes := by
  induction bytes with
  | nil => rfl
  | cons b bs ih => simp [Function.comp,decode_ghost_nat,ih]

theorem decode_encoded_stream (st : Stream) : decodeObject (streamObject st) = some st := by
  cases st with
  | mk bytes count failed =>
    cases failed <;> simp [decodeObject,streamObject,decode_ghost_nat,decode_ghost_bytes,decode_ghost_composed]

theorem read_after_store (s : State) (slot : Nat) (st : Stream) (h : slot < s.heap.length) :
    readStream (storeStream s slot st) slot = some st := by
  simp [readStream,storeStream,List.getElem?_set_self h,decode_encoded_stream]

theorem store_preserves_shape (s : State) (slot : Nat) (st : Stream) :
    (storeStream s slot st).heap.length = s.heap.length ∧
    (storeStream s slot st).env = s.env ∧ (storeStream s slot st).globals = s.globals ∧
    (storeStream s slot st).nats = s.nats := by simp [storeStream]

theorem store_preserves_other_object (s : State) (slot other : Nat) (st : Stream)
    (h : other ≠ slot) :
    (storeStream s slot st).heap[other]? = s.heap[other]? := by
  simp [storeStream,List.getElem?_set,h,Ne.symm h]

end ScopedIO
