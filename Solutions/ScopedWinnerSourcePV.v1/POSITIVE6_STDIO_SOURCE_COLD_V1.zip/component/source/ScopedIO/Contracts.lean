/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedIO.Runtime

namespace ScopedIO
open ScopedC ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def integerNumber : Value → Int
  | .integer n => n.number
  | _ => 0

theorem stream_slot_present {s : State} {slot : Nat} {before : Stream}
    (h : readStream s slot = some before) : slot < s.heap.length := by
  by_contra hn
  have hnone : s.heap[slot]? = none := List.getElem?_eq_none_iff.mpr (by omega)
  simp [readStream,hnone] at h

theorem putchar_equation (platform : Platform) (fault : FaultPolicy) {s : State} {before : Stream}
    (read : readStream s platform.stdoutSlot = some before) (c : Int)
    (range : Scalar.InRange ⟨true,32⟩ c) :
    stdio platform fault "putchar" [intResult c] s =
      some (intResult (if fault.succeed "putchar" s then (c%256).toNat else -1),
        storeStream s platform.stdoutSlot
          (writeBytes before [(c%256).toNat] (fault.succeed "putchar" s) (fault.count "putchar" s))) := by
  simp [stdio,read,intResult,range]

theorem printf_equation (platform : Platform) (fault : FaultPolicy) {s : State} {before : Stream}
    (read : readStream s platform.stdoutSlot = some before) {args : List Value} {bytes : List Nat}
    (parsed : printfBytes args s = some bytes) (fits : bytes.length < 2^31) :
    stdio platform fault "printf" args s =
      some (intResult (if fault.succeed "printf" s then bytes.length else -1),
        storeStream s platform.stdoutSlot
          (writeBytes before bytes (fault.succeed "printf" s) (fault.count "printf" s))) := by
  simp [stdio,read,parsed,fits]
  exact fits

theorem fflush_equation (platform : Platform) (fault : FaultPolicy) {s : State} {before : Stream}
    (read : readStream s platform.stdoutSlot = some before) (writable : Bool) :
    stdio platform fault "fflush" [.pointer ⟨platform.stdoutSlot,0,[]⟩ writable] s =
      some (intResult (if fault.succeed "fflush" s then 0 else -1),
        storeStream s platform.stdoutSlot (flush before (fault.succeed "fflush" s) (fault.count "fflush" s))) := by
  simp [stdio,read]

/-- A nonnegative printf return is enough to infer exactly its parsed bytes
were accepted. Failure, including partial writes, remains possible. -/
theorem printf_nonnegative (platform : Platform) (fault : FaultPolicy)
    {s t : State} {before : Stream} {args : List Value} {bytes : List Nat} {n : Int}
    (read : readStream s platform.stdoutSlot = some before)
    (parsed : printfBytes args s = some bytes) (fits : bytes.length < 2^31)
    (call : stdio platform fault "printf" args s = some (intResult n,t)) (hn : 0 ≤ n) :
    ∃ after, readStream t platform.stdoutSlot = some after ∧
      after.accepted = before.accepted++bytes := by
  rw [printf_equation platform fault read parsed fits] at call
  have equal := Option.some.inj call
  have number := congrArg (fun p : Value × State => integerNumber p.1) equal
  have state := congrArg Prod.snd equal
  cases ok : fault.succeed "printf" s
  · simp [ok,integerNumber,intResult] at number
    omega
  · simp only [ok,↓reduceIte] at state
    rw [←state]
    refine ⟨writeBytes before bytes true (fault.count "printf" s),?_,rfl⟩
    exact read_after_store s platform.stdoutSlot _ (stream_slot_present read)

/-- A zero fflush return proves delivery of all previously accepted bytes;
the generic API contract never asserts the application's output was correct. -/
theorem fflush_zero (platform : Platform) (fault : FaultPolicy)
    {s t : State} {before : Stream} (writable : Bool)
    (read : readStream s platform.stdoutSlot = some before)
    (call : stdio platform fault "fflush" [.pointer ⟨platform.stdoutSlot,0,[]⟩ writable] s =
      some (intResult 0,t)) :
    ∃ after, readStream t platform.stdoutSlot = some after ∧
      after.accepted = before.accepted ∧ after.delivered = before.accepted.length := by
  rw [fflush_equation platform fault read writable] at call
  have equal := Option.some.inj call
  have number := congrArg (fun p : Value × State => integerNumber p.1) equal
  have state := congrArg Prod.snd equal
  cases ok : fault.succeed "fflush" s
  · simp [ok,integerNumber,intResult] at number
  · simp only [ok,↓reduceIte] at state
    rw [←state]
    refine ⟨flush before true (fault.count "fflush" s),?_,rfl,rfl⟩
    exact read_after_store s platform.stdoutSlot _ (stream_slot_present read)

end ScopedIO
