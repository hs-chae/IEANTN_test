# Source-cold arithmetic and StdIO component — partial verification

This package contains52 written application-source modules and53 byte-exact include payloads. A real fresh HOST build from empty application objects compiled every source and audited24 actual theorem roots using only propext, Classical.choice and Quot.sound in238.34seconds. It is not namespace isolation or a complete application/ANT source-PV claim. It does not repeat the actual numerical C runs.

Six actual C512 body contracts are covered: addU,mulU,zero,unit,add,ceilDiv. The ceiling guard/parameter conversions/rounding and overflow-from-input proof are included; interval addition is connected to its real enclosure. The actual global initialization supplies MAXU and S, rather than assuming application heap contents.

The StdIO extension reuses existing Machine/Loops, adds precisely generic stream effects, and proves old pure SourceCall transport. printf parses only the two actual source formats. All policies may fail or accept partial prefixes; there is no assumed SuccessfulEffects or correct output. A zero fflush return establishes delivery of previously accepted bytes. The actual C56 main flush statement is linked and its successful branch proved. Whole printS/printI/main normal-return correctness, FILE/buffer nonaliasing and lifetime applicability, numerical programs and final ANT output consumption remain open. The trusted generic C stdio/compiler/runtime contracts remain explicit.

## Clean reproduction

Obtain Linuxx86-64 Lean4.34.0-rc2 (commit6a10ac8c22beadecabdbb0919c2b50214762f91d), and Mathlib71a80585ee495fc24472fd0eaffc89d94e4fd8d6 with its pinned public packages/cache. SOURCE_LOCK.json lists every exact package URL/commit, kernel/runtime sentinel and source/payload SHA. No old application library or private research context is required.

Run:

    python3 prepare_environment.py --toolchain /path/to/lean-4.34.0-rc2-linux --mathlib /path/to/mathlib --out /fresh/public-env.json
    python3 reproduce.py --environment /fresh/public-env.json --out /fresh/replay --jobs 2

The environment preparer was actually tested in normal,-O,-OO modes on this source lock, including invalid destinations/toolchains. The source runner checks exact pins before and after, builds52 sources into fresh objects, compiles actual audits, and writes the receipt only after all24 roots pass. The supplied accepted receipt is a historical run, not a substitute for reproduction. No numerical randomness.
