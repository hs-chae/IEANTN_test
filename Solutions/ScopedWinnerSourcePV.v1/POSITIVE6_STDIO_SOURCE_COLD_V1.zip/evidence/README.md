# StdIO source execution extension — partial work

This component reuses the exact existing Machine memory/expression and Loops statement semantics. SourceWith parameterizes the external generic-platform Call relation, with a proved transport of every original pure SourceCall proof and an equivalence at the unchanged RuntimeCore boundary. No existing Machine/State/source function is edited.

The Stream/Storage/Runtime files model an opaque platform FILE object using ghost fields in an already allocated, application-disjoint heap slot. These ghost fields are not concrete libc offsets or application initialization. The application may hold an ordinary pointer handle; source proofs must establish its correct binding, buffer validity and all nonaliasing/lifetime conditions. The initial application's own globals and pool still need actual source initialization proofs. The admitted platform object must have Stream.Valid; no correct numerical output is an initial condition.

FaultPolicy leaves write failures and partial accepted prefixes arbitrary. A nonnegative printf return means the exact parsed format bytes were accepted; successful fflush delivers all previously accepted bytes to the host environment. This is neither durable disk persistence nor a proof that those bytes represent correct mathematics. Full printing/whole-main source proofs and connection to the final numerical theorem are still required. The functions evaluate/runRow/main are explicitly rejected as platform leaves.

Source contract: WG14 N1570,7.21.5.2 paragraphs2/4;7.21.6.3 paragraphs2/3;7.21.7.3 paragraphs2/3;7.21.7.8 paragraphs2/3. The primary draft itself was downloaded from a University of Florida mirror; original WG14 URL timed out. sources/PROVENANCE.json pins both URLs, the actual PDF and exact pages. This is generic standard-library contract trust; Clang/libc implementations are not verified here. Actual pinned headers have EOF=-1 and8bit bytes; final applicability/build/runtime association remains mandatory.

Completed module receipts live in proof/. Failed drafts are retained. Do not call the unfinished component or checked-C56 program fully source-first PV.
