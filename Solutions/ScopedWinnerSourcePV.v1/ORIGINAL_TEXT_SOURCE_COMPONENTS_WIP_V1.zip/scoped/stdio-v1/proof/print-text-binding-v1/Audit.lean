import ScopedIO.PrintTextBinding
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxHeartbeats 0
run_elab do
 let env ← getEnv
 for n in ([`ScopedIO.PrintTextBinding.printS_render,`ScopedIO.PrintTextBinding.printI_render,`ScopedIO.PrintTextBinding.printS_source,`ScopedIO.PrintTextBinding.printI_source] : List Name) do
  let some ci := env.find? n | throwError "missing declaration {n}"
  let ax ← Lean.collectAxioms n
  logInfo m!"BUILD_AUDIT {(Json.mkObj [("name",toJson n.toString),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"
