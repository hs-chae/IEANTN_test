# Original text output: development checkpoint

Nine accepted additive Lean modules / 44 audited roots; no whole-function count increment. The original helper bytes and -100 formats are preserved. Do not confuse this with the separate height program binary -128 output.

Build each module in INDEX order using scoped/build/scripts/build_lean.py and the pinned scoped/build/DEVELOPMENT_ENVIRONMENT.json from the original source checkpoint. Example: python3 scoped/build/scripts/build_lean.py --source-root scoped/stdio-v1/lean --module ScopedIO.TextWorldRuntime --out FRESH --publish --audit ScopedIO.TextWorldIO.no_application_leaves --require-std3. Run inside scripts/resource_scope_v2.py. This is a source-associated warm development recipe; a combined clean-bank/isolated final replay remains pending. Source57 and full4057 capsules supply the separate original/source-array imports.

TextWorldIO has only documented generic runtime/stdio leaves. Application functions never become leaves. The finite world executor proves successful evaluations carry complete actual-body source trees. Typed digit reads require the generated-prefix invariant, which the pending generation-loop proof must establish; this is not assumed as a final output theorem. Signed zero is represented faithfully. printS ignores I/O errors, so exit0 does not prove complete delivery.
