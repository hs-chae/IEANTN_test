/- The exact main-weight model's real coefficient functions and domain decoding. -/
import SynergyHeightC.MainWeightReal
import SynergyAnalytic.HeightPointWordBounds
namespace SynergyHeightC.MainWeightModel
open ScopedNumerical SynergyBasis
open SynergyAnalytic SynergyAnalytic.HeightPoint SynergyHeightC.PointExecuteAPI
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

@[irreducible] def gridInput (i : Nat) : ProofBox := (logCell i).getD ⟨0,0⟩
@[irreducible] def modelPair (i : Nat) : ProofBox × ProofBox :=
  (modelOutputs (gridInput (i+1))).getD (⟨0,0⟩,⟨0,0⟩)
noncomputable def pointC (i : Nat) : ℝ := realWord (modelPair i).1.hi
noncomputable def fullC (i : Nat) : ℝ := realWord (adjustedC (modelPair i).1).hi
noncomputable def pointD (i : Nat) : ℝ := realWord (modelPair i).2.hi
noncomputable def realTerm (i : Nat) : ℝ :=
  2*((1/heightEndpoint i-1/heightEndpoint (i+1))*fullC i)*
    pairedFactor (pointD i) (1/8) 330


theorem fullC_eq (i : Nat) : fullC i=pointC i+21600 := by
  have hs := RealBox.scale_real_pos 128
  have hLit : ProofBox.literal 128 21600 1 =
      ⟨21600*ProofBox.scale 128,21600*ProofBox.scale 128⟩ := by decide +kernel
  simp only [fullC,pointC,adjustedC,hLit,ProofBox.add,realWord,Int.cast_add,Int.cast_mul,
    Int.cast_ofNat,add_div,mul_div_cancel_right₀ _ hs.ne']


set_option maxHeartbeats 5000 in
theorem domain_spec {i : Nat} (checked : cellDomain i=true) :
    logCell i=some (gridInput i) ∧
    logCell (i+1)=some (gridInput (i+1)) ∧
    modelOutputs (gridInput (i+1))=some (modelPair i) ∧
    (0 ≤ (gridInput i).lo ∧ (gridInput i).lo ≤ (gridInput i).hi ∧
      (gridInput i).hi ≤ 64*ProofBox.scale 128 ∧
      0 ≤ (gridInput (i+1)).lo ∧ (gridInput (i+1)).lo ≤ (gridInput (i+1)).hi ∧
      (gridInput (i+1)).hi ≤ 64*ProofBox.scale 128 ∧
      0 ≤ (adjustedC (modelPair i).1).hi ∧ 0 ≤ (modelPair i).2.hi ∧
      (modelPair i).2.hi < 330*ProofBox.scale 128 ∧
      0 ≤ (term (gridInput i) (gridInput (i+1)) (modelPair i).1 (modelPair i).2).lo ∧
      (term (gridInput i) (gridInput (i+1)) (modelPair i).1 (modelPair i).2).lo ≤
        (term (gridInput i) (gridInput (i+1)) (modelPair i).1 (modelPair i).2).hi ∧
      (term (gridInput i) (gridInput (i+1)) (modelPair i).1 (modelPair i).2).hi ≤
        ProofBox.scale 128) := by
  cases hl : logCell i with
  | none => simp [cellDomain,hl] at checked
  | some left =>
      cases hr : logCell (i+1) with
      | none => simp [cellDomain,hl,hr] at checked
      | some right =>
          cases hm : modelOutputs right with
          | none => simp [cellDomain,hl,hr,hm] at checked
          | some pair =>
              rcases pair with ⟨c,d⟩
              have hc : 0 ≤ left.lo ∧ left.lo ≤ left.hi ∧
                  left.hi ≤ 64*ProofBox.scale 128 ∧
                  0 ≤ right.lo ∧ right.lo ≤ right.hi ∧
                  right.hi ≤ 64*ProofBox.scale 128 ∧
                  0 ≤ (adjustedC c).hi ∧ 0 ≤ d.hi ∧
                  d.hi < 330*ProofBox.scale 128 ∧
                  0 ≤ (term left right c d).lo ∧
                  (term left right c d).lo ≤ (term left right c d).hi ∧
                  (term left right c d).hi ≤ ProofBox.scale 128 := by
                simpa only [cellDomain,hl,hr,hm,decide_eq_true_eq] using checked
              simpa only [gridInput,modelPair,hl,hr,hm,Option.getD_some] using
                And.intro hl (And.intro hr (And.intro hm hc))



#print axioms SynergyHeightC.MainWeightModel.domain_spec
end SynergyHeightC.MainWeightModel
