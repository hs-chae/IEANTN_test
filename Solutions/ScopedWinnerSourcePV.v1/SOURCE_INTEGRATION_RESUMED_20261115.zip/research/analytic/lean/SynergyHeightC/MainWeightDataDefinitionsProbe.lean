/- The exact main-weight model's real coefficient functions and domain decoding. -/
import SynergyHeightC.MainWeightReal
import SynergyAnalytic.HeightPointWordBounds
namespace SynergyHeightC.MainWeightModel
open ScopedNumerical SynergyBasis
open SynergyAnalytic SynergyAnalytic.HeightPoint SynergyHeightC.PointExecuteAPI
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

@[irreducible] def gridInput (i : Nat) : ProofBox := (logCell i).getD ⟨0,0⟩
@[irreducible] def modelPair (i : Nat) : ProofBox × ProofBox :=
  (modelOutputs (gridInput (i+1))).getD (⟨0,0⟩,⟨0,0⟩)
noncomputable def pointC (i : Nat) : ℝ := realWord (modelPair i).1.hi
noncomputable def fullC (i : Nat) : ℝ := realWord (adjustedC (modelPair i).1).hi
noncomputable def pointD (i : Nat) : ℝ := realWord (modelPair i).2.hi
noncomputable def realTerm (i : Nat) : ℝ :=
  2*((1/heightEndpoint i-1/heightEndpoint (i+1))*fullC i)*
    pairedFactor (pointD i) (1/8) 330



end SynergyHeightC.MainWeightModel
