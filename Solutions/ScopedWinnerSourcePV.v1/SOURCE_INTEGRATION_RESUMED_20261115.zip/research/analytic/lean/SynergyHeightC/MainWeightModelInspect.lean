import SynergyHeightC.MainWeightModel
set_option pp.all false
#print SynergyHeightC.MainWeightModel.cellDomain
#print SynergyHeightC.MainWeightModel.cellDomain.match_1
#print SynergyHeightC.MainWeightModel.cellDomain.match_2
