import SynergyHeightC.MainWeightModel
import Lean
open Lean Meta Elab
set_option maxHeartbeats 20000
run_elab do
  let env ← getEnv
  let some (.defnInfo source) := env.find? ``SynergyHeightC.MainWeightModel.cellDomain
    | throwError "missing checker"
  let used := source.value.getUsedConstants
  logInfo m!"CHECKER_CONSTANTS {(toJson (used.toList.map Name.toString)).compress}"
  logInfo m!"CHECKER_TYPE {source.type}"
  logInfo m!"CHECKER_SIZE {source.value.approxDepth}"
