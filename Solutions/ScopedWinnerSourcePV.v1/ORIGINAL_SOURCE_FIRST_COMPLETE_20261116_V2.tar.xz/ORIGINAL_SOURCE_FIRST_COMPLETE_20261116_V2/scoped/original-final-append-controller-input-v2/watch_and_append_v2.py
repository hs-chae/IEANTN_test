#!/usr/bin/env python3
"""Wait for the real completed10338 parent, validate it, then append632.

Only the audit builder changed in engineV4; original source/claims are unchanged. Pending
or failed parent work never authorizes an append or a mathematical success.
"""
import argparse
import importlib.util
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
R = HERE.parents[1]
CHAIN = R / "scoped/joint-cold-chain-v1"
BASE = R / "scoped/current65-joint-source-input-v1/capsule-v6"
TASK = R / "scoped/original-final-source-append-v1"
ENV = R / "scoped/build/current52-public-environment-OO.json"
PARENT = CHAIN / "audit-salvage-v2/namespace"
BASE_SCOPE = R / "resources/original10338-audit-salvage-v2"
SEED_ROOT = CHAIN / "audit-salvage-v2/all10338-compiled-prefix"
SEED_CHECKPOINT = SEED_ROOT / "CHECKPOINT.json"
WORK = R / "scoped/original-final-append-controller-v2"
APPEND_SCOPE = R / "resources/original-final-source-append-run-v2"
BASE_SHA = "90421606468e1441a129f54a5047b572c72d908858e8ae9e12b9c693d257def1"
TASK_SHA = "8ca3be96d7f3f0c92fabf847fa0c0a6dc825fd40b9292b1acbfc850b41b7afc2"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


adapter = load_module("reviewed_completed_parent", CHAIN / "prepare_completed_parent_v3.py")
m = adapter.m
marker_gate = load_module("exact_v6_marker_gate", HERE / "marker_gate_v1.py")


def pins():
    p = m.read(HERE / "SOURCE_PINS.json")
    for row in p["files"]:
        m.need(m.sha(R / row["path"]) == row["sha256"], "frozen controller/source/tool pin")
    m.need(m.sha(BASE / "SOURCE_LOCK.json") == BASE_SHA and
           m.sha(TASK / "SOURCE_LOCK.json") == TASK_SHA, "exact original base/full task")
    old = m.read(BASE / "SOURCE_LOCK.json")
    new = m.read(TASK / "SOURCE_LOCK.json")
    m.need(len(old["sources"]) == 10338 and len(old["roots"]) == 20225 and
           len(new["sources"]) == 10970 and len(new["roots"]) == 20306,
           "exact fixed source/root populations")
    return p


def proc_identity(pid):
    try:
        raw = Path("/proc", str(pid), "stat").read_text().rsplit(") ", 1)[1].split()
    except FileNotFoundError:
        return None
    return dict(state=raw[0], start_ticks=raw[19])


def parent_state():
    running = m.read(BASE_SCOPE / "RUNNING.json")
    unit = running["unit"]
    m.need(unit.startswith("ieantn-r2-recovery-") and unit.endswith(".scope"), "actual base unit")
    p = subprocess.run(["systemctl", "--user", "show", unit,
                        "--property=ControlGroup", "--value"], capture_output=True, text=True)
    group = p.stdout.strip()
    occupied = ""
    if group:
        cg = Path("/sys/fs/cgroup") / group.lstrip("/")
        m.need(cg.is_relative_to(Path("/sys/fs/cgroup")) and ".." not in cg.parts and
               cg.name == unit, "actual base cgroup path")
        try:
            occupied = (cg / "cgroup.procs").read_text().strip()
        except FileNotFoundError:
            pass
    processes = {str(pid): proc_identity(pid) for pid in
                 [running["launcher_pid"], running["systemd_run_pid"]]}
    live = bool(occupied) or any(v is not None and v["state"] != "Z" for v in processes.values())
    return dict(live=live, unit=unit, cgroup=group, processes=processes,
                cgroup_has_processes=bool(occupied),
                resource_receipt_exists=(BASE_SCOPE / "scope.json").is_file(),
                namespace_receipt_exists=(PARENT / "RECEIPT.json").is_file(),
                proof_receipt_exists=(PARENT / "data/run/RECEIPT.json").is_file())


def command(work):
    view = work / "parent-view"
    namespace = work / "namespace"
    return ["/usr/bin/python3.10", str(R / "scripts/resource_scope_v3.py"),
            "--family", "root_generic", "--memory-gib", "192", "--cpus", "24",
            "--wall", "43200", "--out", str(APPEND_SCOPE), "--",
            "/usr/bin/python3.10", str(R / "scripts/record_command_peak_v1.py"),
            "--receipt", str(work / "KERNEL_RESOURCE_PEAK.json"), "--",
            "/usr/bin/python3.10", str(CHAIN / "launch_chain_v3.py"),
            "--input", str(TASK), "--environment", str(ENV), "--out", str(namespace),
            "--engine", str(CHAIN / "input-v4"), "--prior", str(view),
            "--checkpoint", str(view / "CHECKPOINT.json"), "--",
            "/usr/bin/python3.10", "-I", "-B", "/engine/engine_v3.py", "run",
            "--task", "/task", "--environment", "/environment.json", "--out", "/out/run",
            "--prior", str(view), "--checkpoint", "/checkpoint.json", "--jobs", "12"]


def resource_complete(path):
    scope = m.read(path)
    m.need(scope["exit_code"] == 0, "actual successful drained resource scope")
    # Report resource events independently of mathematical/source proof acceptance.
    events = {}
    for sample in scope["samples"]:
        for key, value in (x.split() for x in sample.get("memory.events", "").splitlines()):
            events[key] = max(events.get(key, 0), int(value))
    return dict(elapsed_seconds=scope["elapsed_seconds"], events=events,
                scope_sha256=m.sha(path), requested_memory_bytes=scope["requested_memory_bytes"],
                sampled_charged_RAM_lower_bound_bytes=max(
                    int(x.get("memory.current", "0")) for x in scope["samples"]),
                exact_aggregate_peak_RAM_bytes=None)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check-inputs", action="store_true")
    ap.add_argument("--poll-once", action="store_true")
    ap.add_argument("--execute", action="store_true")
    a = ap.parse_args()
    m.need(sum([a.check_inputs, a.poll_once, a.execute]) == 1, "exactly one explicit mode")
    pin = pins()
    if a.check_inputs:
        print(json.dumps(dict(status="PASS_FROZEN_WATCHER_PINS_NOT_EXECUTION",
                              base_modules=10338, full_modules=10970, roots=20306,
                              planned_command=command(WORK))))
        return
    if a.poll_once:
        print(json.dumps(dict(status="PENDING_PARENT_NO_APPEND_ACCEPTANCE", state=parent_state())))
        return
    m.need(not WORK.exists() and not APPEND_SCOPE.exists(), "fresh owned controller/resource output")
    WORK.mkdir(parents=True)
    m.atomic(WORK / "PLAN.json", dict(pins=pin, command=command(WORK),
        qualification="Wait for actual complete parent and cgroup drain, validate all parent source/object/log/audit evidence, then explicitly chained10970/20306 append. Never a second empty-bank or retroactive primary-success claim."))
    start = time.monotonic()
    while True:
        state = parent_state()
        m.atomic(WORK / "WAITING.json", dict(status="WAITING_PARENT_NO_NEW_PROOF_WORKER",
                                            seconds=time.monotonic() - start, state=state))
        if not state["live"]:
            break
        time.sleep(30)
    m.need(state["resource_receipt_exists"] and state["namespace_receipt_exists"] and
           state["proof_receipt_exists"], "base drained without complete success; preserve prefix, do not append")
    base_resource = resource_complete(BASE_SCOPE / "scope.json")
    pins()
    parent_view = adapter.prepare(BASE, TASK, ENV, PARENT, SEED_CHECKPOINT,
                                  SEED_ROOT, WORK / "parent-view")
    m.atomic(WORK / "VALIDATED_PARENT.json", dict(preparation=parent_view, resource=base_resource))
    m.need(not parent_state()["live"], "parent remains fully drained before append")
    cmd = command(WORK)
    with (WORK / "append.stdout").open("xb") as so, (WORK / "append.stderr").open("xb") as se:
        result = subprocess.run(cmd, stdout=so, stderr=se)
    m.atomic(WORK / "APPEND_COMMAND_RESULT.json", dict(command=cmd, exit_code=result.returncode,
             qualification="Command completion only; final readback and numerical-source census required."))
    m.need(result.returncode == 0, "append command failed; preserve actual partial evidence")
    append_resource = resource_complete(APPEND_SCOPE / "scope.json")
    final = adapter.prepare(TASK, TASK, ENV, WORK / "namespace",
                            WORK / "parent-view/CHECKPOINT.json", WORK / "parent-view",
                            WORK / "final-validated-view")
    raw = WORK / "namespace/data/run/logs/ScopedC.SourceFinalLeafAuditV6.stdout"
    census = marker_gate.check(raw.read_text(), HERE / "audit-inputs")
    pins()
    m.atomic(WORK / "RECEIPT.json", dict(
        status="PASS_ORIGINAL10970_CHAINED_SOURCE_ONLY_REPLAY_AND_EXACT_SOURCE49_CENSUS",
        parent_modules=10338, new_modules=632, full_modules=10970, typed_Std3_roots=20306,
        source_lock_sha256=TASK_SHA, parent_source_lock_sha256=BASE_SHA,
        completed_parent_preparation=parent_view, final_full_readback=final,
        base_resource=base_resource, append_resource=append_resource,
        final_source_census=census, census_stdout_sha256=m.sha(raw),
        controller_sha256=m.sha(Path(__file__)),
        qualification="All10338 original sources compiled, but their original giant audit FAILED code-generator recursion. The separately identified V4 audit-only namespace consumed all validated10338 objects and completed the full20225-root audit. This audited parent is followed by632 new modules and all20306 actual typed Std3 audits. This is explicitly chained/supplemental acceptance, never a repaired historical receipt or another uninterrupted empty-bank run. Numerical regeneration/build/run evidence remains separate."))
    print("PASS_ORIGINAL10970_CHAINED_SOURCE_ONLY_REPLAY_AND_EXACT_SOURCE49_CENSUS")


if __name__ == "__main__":
    main()
