# Exact pure validation segment extracted from the accepted V6 gate.
from pathlib import Path
import json, math
STD = {'propext', 'Classical.choice', 'Quot.sound'}

def need(v, m):
    if not v:
        raise ValueError(m)

def strict_text(s):

    def pairs(xs):
        d = {}
        for k, v in xs:
            need(k not in d, 'duplicate JSON key')
            d[k] = v
        return d

    def floating(s):
        x = float(s)
        need(math.isfinite(x), 'overflow/nonfinite JSON')
        return x

    def bad(s):
        raise ValueError('nonfinite ' + s)
    return json.loads(s, object_pairs_hook=pairs, parse_float=floating, parse_constant=bad)

def read(p):
    return strict_text(Path(p).read_text())

def check(raw, metadata_dir):
    B = Path(metadata_dir)
    prep = read(B / 'FINAL_UNFILTERED_AUDIT_PREPARATION_V6.json')
    targets = read(B / 'FINAL42_TARGET_IDENTITIES_PREPARED_V1.json')['targets']
    markers = {'SOURCE_FINAL_EXACT_TYPE_STD3': [], 'SOURCE_UNFILTERED_CLOSURE': [], 'SOURCE_FINAL_POPULATION': [], 'SOURCE_ABSTRACT_PROOF_SOURCE_FIELDS': []}
    for line in raw.splitlines():
        for marker in markers:
            if marker + ' ' in line:
                markers[marker].append(strict_text(line.split(marker + ' ', 1)[1]))
    facts = markers['SOURCE_FINAL_EXACT_TYPE_STD3']
    population = markers['SOURCE_FINAL_POPULATION']
    closures = markers['SOURCE_UNFILTERED_CLOSURE']
    need(len(population) == 1, 'one exact population record')
    pop = population[0]
    old = [z['original'] for z in facts]
    roots = [z['root'] for z in facts]
    metadata = pop['unchanged_nonprop_roots']
    need(len(set(old)) == len(old) and len(set(metadata)) == len(metadata) and set(old).isdisjoint(metadata) and (set(old) | set(metadata) == set(targets)), 'complete exact42partition')
    need(pop['targets'] == 42 and pop['proved_prop_roots'] == len(facts), 'honest Prop/data counts')
    for z in facts:
        need(z['root'] == 'ScopedC.SourceFinalConsumers.actual.' + z['original'] and z['exact_expression'] is True and (z['nonempty_type'] is True) and (set(z['axioms']) <= STD), 'exact typed Std3 root')
    need(len(closures) == 2 and {z['label'] for z in closures} == {'all_final_prop_roots', 'strict_comparison_separate'}, 'two independent closures')
    for z in closures:
        expected = roots if z['label'] == 'all_final_prop_roots' else ['ScopedC.SourceFinalConsumers.actual.ScopedWinnerA.Comparison.scoped_strict']
        need(z['roots'] == expected, 'exact closure roots')
        need(z['reachable_constants'] >= len(expected) > 0 and z['missing'] == z['forbidden_old_kernel_leaves'] == z['forbidden_original_native_names'] == 0 and (z['old_leaf_universe'] == 53) and (z['forbidden_original_scalar_owners'] == 0) and (z['original_scalar_owner_universe'] == 16) and (z['forbidden_original_derived_gamma'] == 0) and (z['original_derived_gamma_universe'] == 1), 'all53 old leaves,16 scalar owners and1derivedGamma absent unrestricted')
    fieldrows = markers['SOURCE_ABSTRACT_PROOF_SOURCE_FIELDS']
    need(len(fieldrows) == len(facts) and {z['original'] for z in fieldrows} == set(old), 'everyProp independent fieldcensus')
    need(len({z['original'] for z in fieldrows}) == len(fieldrows), 'unique perrootcensus')
    fields = prep['source_projection_fields']
    leafinfo = read(B / 'NUMERICAL_LEAF_IDENTITIES_V1.json')['leaves']
    byfield = {'ScopedC.SourceNumericChecks.Checks.' + z['field']: z for z in leafinfo}
    fieldrecords = []
    for z in fieldrows:
        used = z['source_projection_constants']
        need(z['generic_root'] == 'ScopedC.SourceConsumersLiftAll.closed.' + z['original'] and len(used) == len(set(used)) == z['source_projection_count'] and (set(used) <= set(fields)) and isinstance(z['outer_source_argument_ignored'], bool), 'exact projectionrecord')
        need(z['reachable_constants'] > 0, 'actual generic closure')
        mapped = sorted({byfield[f]['original_fact'] for f in used})
        sensitivity = 'ScopedC.SourceNumericChecks.Checks.sensitivity' in used
        fieldrecords.append(dict(**z, original_fact_names_mapped_from_selected_fields=mapped, canonical_C_row_predicates=len(used) - int(sensitivity), additive56_C_rows=[52, 53, 54, 55] if sensitivity else [], qualification='Source-field counts on the generic lifted proof, not the whole actual Checks argument. Mapped original native identities are historical ledger associations, not a new traversal of the pre-migration native source.'))
    registry = read(B / 'NATIVE_FACT_REGISTRY_V1.json')
    reconciliations = []
    for original, count in registry['root_counts'].items():
        expected = {fact['name'] for fact in registry['facts'] if original in fact['selected_root_paths']}
        need(len(expected) == count, 'original exact native root paths/count reconcile')
        found = next((z for z in fieldrecords if z['original'] == original), None)
        need(found is not None, 'historical selected root covered by actual final source census')
        actual = set(found['original_fact_names_mapped_from_selected_fields'])
        need(actual == expected, 'actual source predicates must cover EXACT original native identities for ' + original)
        reconciliations.append(dict(original=original, original_native_identities=sorted(expected), original_native_count=count, actual_source_fields=found['source_projection_constants'], canonical_C_rows=found['canonical_C_row_predicates'], additive56_C_rows=found['additive56_C_rows'], mapped_identity_count=len(actual), exact_identity_coverage=True, qualification='Original actual constant-closure paths are compared with actual generic source-proof projection fields through the explicit primitive-to-row identity map. Projection presence is read from both constant and primitive forms; no transformation cache counts.'))
    comparison = next((z for z in fieldrows if z['original'] == 'ScopedWinnerA.Comparison.scoped_strict'))
    need(comparison['source_projection_count'] == 0, 'preserve pure arithmetic comparison classification')
    return dict(targets=42, proved_prop_roots=len(facts), unchanged_nonprop_roots=metadata, closures=closures, source_projection_census=fieldrecords, original_native_identity_reconciliation=reconciliations)
