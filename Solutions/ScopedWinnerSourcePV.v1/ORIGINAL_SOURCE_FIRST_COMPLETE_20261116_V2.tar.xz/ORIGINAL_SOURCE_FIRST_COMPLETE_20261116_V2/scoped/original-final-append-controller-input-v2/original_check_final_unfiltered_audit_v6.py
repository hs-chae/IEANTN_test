"""Fail-closed receipt gate for the executed independent final closure auditor."""
from pathlib import Path
import argparse,hashlib,json,math,os,re
B=Path(__file__).resolve().parent.parent;R=B.parents[1];STD={'propext','Classical.choice','Quot.sound'}
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def strict_text(s):
 def pairs(xs):
  d={}
  for k,v in xs:need(k not in d,'duplicate JSON key');d[k]=v
  return d
 def floating(s):
  x=float(s);need(math.isfinite(x),'overflow/nonfinite JSON');return x
 def bad(s):raise ValueError('nonfinite '+s)
 return json.loads(s,object_pairs_hook=pairs,parse_float=floating,parse_constant=bad)
def read(p):return strict_text(Path(p).read_text())
def inputs():
 prep=read(B/'FINAL_UNFILTERED_AUDIT_PREPARATION_V6.json');source=R/prep['source'];need(sha(source)==prep['source_sha256'],'exact prepared auditor source');targets=read(B/'FINAL42_TARGET_IDENTITIES_PREPARED_V1.json')['targets'];leaves=read(B/'NUMERICAL_LEAF_IDENTITIES_V1.json')['leaves'];need(len(targets)==42==len(set(targets))and len(leaves)==53,'exact written universes');need(sha(B/'FINAL42_TARGET_IDENTITIES_PREPARED_V1.json')==prep['target_identities_sha256']and sha(B/'NUMERICAL_LEAF_IDENTITIES_V1.json')==prep['leaf_identities_sha256'],'prepared universe pins');need(sha(B/'SOURCE_OWNER16_REPLACEMENT_PLAN_V1.json')==prep['owner_replacement_plan_sha256'],'exact16owner plan');need(sha(R/'scoped/audit/NATIVE_FACT_REGISTRY_V1.json')==prep['original_native_registry_sha256'],'pinned original actual native registry');need(len(prep['forbidden_old_scalar_owners'])==16==len(set(prep['forbidden_old_scalar_owners'])),'exact16 forbidden scalar owners');return prep,source,targets

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--proof',type=Path);ap.add_argument('--scope',type=Path);ap.add_argument('--out',type=Path);ap.add_argument('--check-inputs',action='store_true');a=ap.parse_args();prep,source,targets=inputs()
 if a.check_inputs:print('PASS_EXACT_PREPARED_UNFILTERED_AUDITOR_INPUTS_NOT_EXECUTION');return
 need(a.proof is not None and a.scope is not None and a.out is not None,'actual proof/scope/output required');proof=a.proof.resolve();out=a.out.resolve();need(not out.exists()and out.is_relative_to(B),'freshowned output')
 p=proof/'RECEIPT.json';d=read(p);need(d['status']=='PASS_HOST_DEVELOPMENT_COMPILE'and d['exit_code']==0 and d['source_unchanged']is True,'actual accepted compile');need(d['source_sha256']==sha(source),'compiled exact source')
 so=proof/'stdout.txt';se=proof/'stderr.txt';raw=so.read_text();errors=se.read_text();need(d['stdout_sha256']==sha(so)and d['stderr_sha256']==sha(se),'raw compiler logs');need("declaration uses 'sorry'"not in raw+errors and'declaration uses `sorry`'not in raw+errors and'sorryAx'not in raw+errors,'no unfinished proof diagnostic')
 cmd=d['command'];need(cmd[-5:] == ['-R',str(source.parents[1]),str(source),'-o',str(proof/'ScopedC/SourceFinalLeafAuditV6.olean')],'exact compile source/object command');need(sha(cmd[4])==d['compiler_sha256'],'actual compiler pin');obj=proof/'ScopedC/SourceFinalLeafAuditV6.olean';need(sha(obj)==d['object_sha256']==sha(d['published_object']),'actual compiled/published object')
 markers={'SOURCE_FINAL_EXACT_TYPE_STD3':[],'SOURCE_UNFILTERED_CLOSURE':[],'SOURCE_FINAL_POPULATION':[],'SOURCE_ABSTRACT_PROOF_SOURCE_FIELDS':[]}
 for line in raw.splitlines():
  for marker in markers:
   if marker+' 'in line:markers[marker].append(strict_text(line.split(marker+' ',1)[1]))
 facts=markers['SOURCE_FINAL_EXACT_TYPE_STD3'];population=markers['SOURCE_FINAL_POPULATION'];closures=markers['SOURCE_UNFILTERED_CLOSURE'];need(len(population)==1,'one exact population record');pop=population[0];old=[z['original']for z in facts];roots=[z['root']for z in facts];metadata=pop['unchanged_nonprop_roots']
 need(len(set(old))==len(old)and len(set(metadata))==len(metadata)and set(old).isdisjoint(metadata)and set(old)|set(metadata)==set(targets),'complete exact42partition');need(pop['targets']==42 and pop['proved_prop_roots']==len(facts),'honest Prop/data counts')
 for z in facts:need(z['root']=='ScopedC.SourceFinalConsumers.actual.'+z['original']and z['exact_expression']is True and z['nonempty_type']is True and set(z['axioms'])<=STD,'exact typed Std3 root')
 need(len(closures)==2 and {z['label']for z in closures}=={'all_final_prop_roots','strict_comparison_separate'},'two independent closures')
 for z in closures:
  expected=roots if z['label']=='all_final_prop_roots'else['ScopedC.SourceFinalConsumers.actual.ScopedWinnerA.Comparison.scoped_strict'];need(z['roots']==expected,'exact closure roots');need(z['reachable_constants']>=len(expected)>0 and z['missing']==z['forbidden_old_kernel_leaves']==z['forbidden_original_native_names']==0 and z['old_leaf_universe']==53 and z['forbidden_original_scalar_owners']==0 and z['original_scalar_owner_universe']==16 and z['forbidden_original_derived_gamma']==0 and z['original_derived_gamma_universe']==1,'all53 old leaves,16 scalar owners and1derivedGamma absent unrestricted')
 fieldrows=markers['SOURCE_ABSTRACT_PROOF_SOURCE_FIELDS'];need(len(fieldrows)==len(facts)and {z['original']for z in fieldrows}==set(old),'everyProp independent fieldcensus');need(len({z['original']for z in fieldrows})==len(fieldrows),'unique perrootcensus')
 fields=prep['source_projection_fields'];leafinfo=read(B/'NUMERICAL_LEAF_IDENTITIES_V1.json')['leaves'];byfield={'ScopedC.SourceNumericChecks.Checks.'+z['field']:z for z in leafinfo};fieldrecords=[]
 for z in fieldrows:
  used=z['source_projection_constants'];need(z['generic_root']=='ScopedC.SourceConsumersLiftAll.closed.'+z['original']and len(used)==len(set(used))==z['source_projection_count']and set(used)<=set(fields)and isinstance(z['outer_source_argument_ignored'],bool),'exact projectionrecord')
  need(z['reachable_constants']>0,'actual generic closure');mapped=sorted({byfield[f]['original_fact']for f in used});sensitivity='ScopedC.SourceNumericChecks.Checks.sensitivity'in used
  fieldrecords.append(dict(**z,original_fact_names_mapped_from_selected_fields=mapped,canonical_C_row_predicates=len(used)-int(sensitivity),additive56_C_rows=[52,53,54,55]if sensitivity else[],qualification='Source-field counts on the generic lifted proof, not the whole actual Checks argument. Mapped original native identities are historical ledger associations, not a new traversal of the pre-migration native source.'))
 registry=read(R/'scoped/audit/NATIVE_FACT_REGISTRY_V1.json');reconciliations=[]
 for original,count in registry['root_counts'].items():
  expected={fact['name']for fact in registry['facts']if original in fact['selected_root_paths']};need(len(expected)==count,'original exact native root paths/count reconcile')
  found=next((z for z in fieldrecords if z['original']==original),None);need(found is not None,'historical selected root covered by actual final source census');actual=set(found['original_fact_names_mapped_from_selected_fields']);need(actual==expected,'actual source predicates must cover EXACT original native identities for '+original)
  reconciliations.append(dict(original=original,original_native_identities=sorted(expected),original_native_count=count,actual_source_fields=found['source_projection_constants'],canonical_C_rows=found['canonical_C_row_predicates'],additive56_C_rows=found['additive56_C_rows'],mapped_identity_count=len(actual),exact_identity_coverage=True,qualification='Original actual constant-closure paths are compared with actual generic source-proof projection fields through the explicit primitive-to-row identity map. Projection presence is read from both constant and primitive forms; no transformation cache counts.'))
 comparison=next(z for z in fieldrows if z['original']=='ScopedWinnerA.Comparison.scoped_strict');need(comparison['source_projection_count']==0,'preserve pure arithmetic comparison classification')
 audit=proof/'audit.stdout';aa=[strict_text(x.split('BUILD_AUDIT ',1)[1])for x in audit.read_text().splitlines()if'BUILD_AUDIT 'in x];need(aa==d['audit']and len(aa)==1 and aa[0]['name']=='ScopedC.SourceFinalLeafAuditV6.completed'and aa[0]['type_repr']and set(aa[0]['axioms'])<=STD,'actual completed audit gate');need(sha(audit)==d['audit_stdout_sha256'],'rawaudit pin')
 scope=read(a.scope);need(scope['exit_code']==0,'actual resource scope0');need(re.search(r'Exit status: 0\s*$',(proof/'time.txt').read_text())is not None,'actual GNUtime0')
 rec=dict(status='PASS_INDEPENDENT_FINAL_TYPED_STD3_SOURCE_IDENTITY_COVERAGE_AND_OLD_LEAF_OWNER_ABSENCE',targets=42,proved_prop_roots=len(facts),unchanged_nonprop_roots=metadata,forbidden_old_kernel_leaves=53,closures=closures,proof_receipt_sha256=sha(p),scope_receipt_sha256=sha(a.scope),source_sha256=sha(source),object_sha256=sha(obj),stdout_sha256=sha(so),stderr_sha256=sha(se),time_sha256=sha(proof/'time.txt'),preparation_sha256=sha(B/'FINAL_UNFILTERED_AUDIT_PREPARATION_V6.json'),validator_sha256=sha(__file__),source_projection_census=fieldrecords,original_native_identity_reconciliation=reconciliations,forbidden_original_scalar_owners=prep['forbidden_old_scalar_owners'],forbidden_derived_gamma=prep['forbidden_derived_gamma'],original_native_registry_sha256=prep['original_native_registry_sha256'],qualification='Warm compiler execution of an independent unrestricted type/body/constructor closure audit. No application whitelist/transformation cache reused. Native axioms,53old checker leaves,16whole scalar owners and1derivedGamma theorem excluded; exact original selected native identities reconciled against actual C-row source projections; comparison audited separately. Not a new source-cold/isolated proof replay.')
 temp=out.with_suffix('.pending');temp.write_text(json.dumps(rec,indent=2,allow_nan=False)+'\n');os.replace(temp,out);print(rec['status'])
if __name__=='__main__':main()
