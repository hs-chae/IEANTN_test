"""Run only inside the existing isolated executor; attest before proof replay."""
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import time


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read_json(p):
    def pairs(rows):
        d = {}
        for k, v in rows:
            need(k not in d, 'duplicate JSON key')
            d[k] = v
        return d
    def floating(s):
        v = float(s)
        need(math.isfinite(v), 'nonfinite JSON number')
        return v
    def constant(s):
        raise ValueError('nonfinite JSON constant '+s)
    return json.loads(p.read_text(), object_pairs_hook=pairs,
                      parse_float=floating, parse_constant=constant)


def main():
    request = read_json(Path('/request.json'))
    namespaces = {n: os.readlink('/proc/self/ns/'+n) for n in ['pid', 'mnt', 'net']}
    need(all(namespaces[n] != request['parent_namespaces'][n] for n in namespaces),
         'distinct process/mount/offline-network namespaces required')
    need(not Path(request['host_workspace_canary']).exists() and
         not Path('/task/.git').exists(), 'host workspace and research history absent')
    for row in request['compiler_pins']:
        need(hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],
             'same pinned kernel/runtime inside namespace')
    probe = dict(status='PASS_DISTINCT_NAMESPACES_AND_RESTRICTED_PROOF_INPUTS',
                 namespaces=namespaces, host_workspace_absent=True,
                 research_git_history_absent=True, compiler_pins=request['compiler_pins'])
    Path('/out/NAMESPACE_PROBE.json').write_text(json.dumps(probe, indent=2)+'\n')
    start = time.monotonic()
    child = subprocess.run(request['command'], check=False)
    result = dict(exit_code=child.returncode, seconds=time.monotonic()-start,
                  command=request['command'], namespace_probe=probe['status'])
    Path('/out/COMMAND_RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    raise SystemExit(child.returncode)


if __name__=='__main__':
    main()
