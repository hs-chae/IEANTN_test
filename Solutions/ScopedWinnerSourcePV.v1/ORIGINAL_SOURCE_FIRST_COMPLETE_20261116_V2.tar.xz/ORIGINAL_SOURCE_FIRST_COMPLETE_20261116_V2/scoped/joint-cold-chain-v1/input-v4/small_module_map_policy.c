#define _GNU_SOURCE
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

_Static_assert(sizeof(void *) == 8, "This pinned policy targets Linux x86_64.");
_Static_assert(sizeof(off_t) == 8, "The mmap offset ABI must be 64 bits.");

/* Generic resource policy for the exact small fixed file-map request shape
 * used by the pinned Lean module reader. It never examines file bytes/names.
 * ENOMEM preserves the target address range and exercises Lean's existing
 * malloc/read fallback. All other calls use the actual Linux mmap syscall. */
static void *map_request(void *address, size_t length, int protection, int flags,
                         int descriptor, off64_t offset) {
    if (address != NULL && length > 0 && length <= 65536 &&
        protection == (PROT_READ | PROT_WRITE) &&
        flags == (MAP_PRIVATE | MAP_FIXED_NOREPLACE) &&
        descriptor >= 0 && offset == 0) {
        errno = ENOMEM;
        return MAP_FAILED;
    }
    return (void *)syscall(SYS_mmap, address, length, (long)protection,
                          (long)flags, (long)descriptor, offset);
}

__attribute__((visibility("default")))
void *mmap(void *address, size_t length, int protection, int flags,
           int descriptor, off_t offset) {
    return map_request(address, length, protection, flags, descriptor, offset);
}

__attribute__((visibility("default")))
void *mmap64(void *address, size_t length, int protection, int flags,
             int descriptor, off64_t offset) {
    return map_request(address, length, protection, flags, descriptor, offset);
}
