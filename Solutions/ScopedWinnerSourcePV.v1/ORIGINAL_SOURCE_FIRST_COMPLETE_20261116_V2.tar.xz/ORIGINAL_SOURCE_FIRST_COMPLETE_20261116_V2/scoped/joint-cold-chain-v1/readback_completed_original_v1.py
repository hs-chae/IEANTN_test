"""Read-only completed original10970 chain audit, with a fresh temporary view.
All original run/source/evidence files stay unchanged. No Lean build is rerun.
"""
import argparse
import importlib.util
from pathlib import Path

B = Path(__file__).resolve().parent
R = B.parents[1]
spec = importlib.util.spec_from_file_location('completed_original', B / 'continue_original_append_v3.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
m = c.m


def verify(out):
    m.need(not out.exists() and out.resolve().is_relative_to(B), 'fresh owned readback output')
    c.check()
    out.mkdir()
    actual = m.read(c.WORK / 'RECEIPT.json')
    m.need(actual['status'] == 'PASS_ORIGINAL10970_CHAINED_SOURCE_ONLY_REPLAY_AND_EXACT_SOURCE49_CENSUS'
           and actual['full_modules'] == 10970 and actual['new_modules'] == 632
           and actual['typed_Std3_roots'] == 20306, 'actual completed original population')
    proof = c.c.resource_complete(c.PROOF_SCOPE / 'scope.json')
    readback = c.c.resource_complete(c.READ_SCOPE / 'scope.json')
    verified = c.c.adapter.prepare(c.c.TASK, c.c.TASK, c.c.ENV, c.WORK / 'namespace',
                                   c.PRIOR / 'CHECKPOINT.json', c.PRIOR, out / 'temporary-view')
    raw = c.WORK / 'namespace/data/run/logs/ScopedC.SourceFinalLeafAuditV6.stdout'
    census = c.c.marker_gate.check(raw.read_text(), c.c.HERE / 'audit-inputs')
    m.need(census == actual['final_source_census'], 'same independent numerical-source census')
    m.need(verified['parent_modules'] == verified['task_modules'] == 10970
           and verified['new_sources'] == 0, 'every source/object/log/audit verified')
    result = dict(status='PASS_READ_ONLY_COMPLETE10970_SOURCE_CHAIN_AND_EXACT_SOURCE49',
        full_modules=10970, new_modules=632, typed_Std3_roots=20306,
        source_lock_sha256=c.c.TASK_SHA, environment_sha256=m.sha(c.c.ENV),
        actual_completion_receipt_sha256=m.sha(c.WORK / 'RECEIPT.json'),
        inner_receipt_sha256=m.sha(c.WORK / 'namespace/data/run/RECEIPT.json'),
        namespace_receipt_sha256=m.sha(c.WORK / 'namespace/RECEIPT.json'),
        proof_resource=proof, final_readback_resource=readback,
        final_source_census=census, validator_sha256=m.sha(Path(__file__)),
        qualification='Readback only, not another Lean replay. All10970 source/object/compiler/log '
        'and20306 typed Std3 records rechecked, plus original49/50/0/1 source identity census. '
        'Original failed giant audit and rejected nested admission remain preserved. '
        'Actual accepted proof study is explicit chained/supplemental acceptance. '
        'Temporary view contains only redundant hardlinks; accepted original artifacts are preserved.')
    m.atomic(out / 'RECEIPT.json', result)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    verify(a.out.resolve())
    print('PASS_READ_ONLY_COMPLETE10970_SOURCE_CHAIN_AND_EXACT_SOURCE49', flush=True)

if __name__ == '__main__':
    main()
