"""Run guarded proof and readback as siblings, never inside a1GiB watcher.

The prior watcher fully validated the parent, then its nested192GiB admission
correctly failed due the watcher ancestor's1GiB limit. That failure is retained.
This light host controller launches the SAME append in a disjoint192GiB scope,
then a separate4GiB evidence readback. No resource guard is weakened or bypassed.
"""
import argparse
import importlib.util
from pathlib import Path
import subprocess
import sys

B=Path(__file__).resolve().parent
R=B.parents[1]
spec=importlib.util.spec_from_file_location('original_controller_v2',
    R/'scoped/original-final-append-controller-input-v2/watch_and_append_v2.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
m=c.m
WORK=R/'scoped/original-final-append-controller-v3'
PRIOR=c.WORK/'parent-view'
PROOF_SCOPE=R/'resources/original-final-source-append-run-v3'
READ_SCOPE=R/'resources/original-final-source-readback-v3'
PINS=B/'ORIGINAL_APPEND_V3_PINS.json'


def check():
    c.pins()
    for row in m.read(PINS)['files']:
        m.need(m.sha(R/row['path'])==row['sha256'],'V3 sibling orchestration source pin')
    resource=m.read(R/'resources/original-final-append-watcher-v2/scope.json')
    live=m.read(R/'resources/original-final-append-watcher-v2/LIVE.json')
    m.need(resource['exit_code']==1 and not Path('/proc',str(live['launcher_pid'])).exists(),
           'prior watcher actually failed and drained; do not nest heavy scope')
    cg=Path(resource['cgroup'])
    m.need(not(cg/'cgroup.procs').exists()or not(cg/'cgroup.procs').read_text().strip(),
           'old watcher cgroup drained')
    m.need(not(c.WORK/'namespace').exists(),'no application source was compiled in rejected attempt')
    failed=m.read(c.WORK/'APPEND_COMMAND_RESULT.json')
    m.need(failed['exit_code']==1 and 'insufficient actual host RAM headroom' in
           (c.WORK/'append.stderr').read_text(),'specific preserved pre-admission rejection')
    validated=m.read(c.WORK/'VALIDATED_PARENT.json')
    prepared=m.read(PRIOR/'PREPARATION_RECEIPT.json')
    m.need(validated['preparation']==prepared and
           prepared['status']=='PASS_PREPARED_ACTUAL_COMPLETED_PARENT_AS_APPEND_PREFIX'and
           prepared['parent_modules']==10338 and prepared['new_sources']==632 and
           m.sha(PRIOR/'CHECKPOINT.json')==prepared['checkpoint_sha256'],
           'actual validated complete audited parent and exact prefix pin')
    c.resource_complete(c.BASE_SCOPE/'scope.json')
    return prepared


def proof_command():
    cmd=c.command(WORK)
    cmd=[str(PROOF_SCOPE)if s==str(c.APPEND_SCOPE)else str(PRIOR)if s==str(WORK/'parent-view')
         else str(PRIOR/'CHECKPOINT.json')if s==str(WORK/'parent-view/CHECKPOINT.json')
         else s for s in cmd]
    return cmd


def readback():
    check()
    m.need(not(WORK/'final-validated-view').exists()and not(WORK/'RECEIPT.json').exists(),
           'fresh final evidence acceptance')
    final=c.adapter.prepare(c.TASK,c.TASK,c.ENV,WORK/'namespace',PRIOR/'CHECKPOINT.json',
                            PRIOR,WORK/'final-validated-view')
    raw=WORK/'namespace/data/run/logs/ScopedC.SourceFinalLeafAuditV6.stdout'
    census=c.marker_gate.check(raw.read_text(),c.HERE/'audit-inputs')
    append_resource=c.resource_complete(PROOF_SCOPE/'scope.json')
    base_resource=c.resource_complete(c.BASE_SCOPE/'scope.json')
    m.atomic(WORK/'RECEIPT.json',dict(
        status='PASS_ORIGINAL10970_CHAINED_SOURCE_ONLY_REPLAY_AND_EXACT_SOURCE49_CENSUS',
        parent_modules=10338,new_modules=632,full_modules=10970,typed_Std3_roots=20306,
        source_lock_sha256=c.TASK_SHA,parent_source_lock_sha256=c.BASE_SHA,
        parent_preparation=m.read(c.WORK/'VALIDATED_PARENT.json'),final_full_readback=final,
        base_resource=base_resource,append_resource=append_resource,
        final_source_census=census,census_stdout_sha256=m.sha(raw),
        controller_sha256=m.sha(Path(__file__)),
        qualification='Original10338 source compiles succeeded, original giant auditFAILED. '
        'Supplemental V4audit-only20225roots passed. Validatedparent then632newsourcecompiles '
        'and all20306typedStd3 roots plus V6numerical-source census. Explicit chainedacceptance, '
        'not another uninterruptedemptybankrun. Failed watcher nested-resource rejection '
        'preserved; heavyproof/readback ran in disjoint guarded siblings. Numerical '
        'regeneration/native evidence remain the separate mandatory addon.'))
    print('PASS_ORIGINAL10970_CHAINED_SOURCE_ONLY_REPLAY_AND_EXACT_SOURCE49_CENSUS',flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--check-inputs',action='store_true')
    p.add_argument('--execute',action='store_true')
    p.add_argument('--final-readback',action='store_true')
    a=p.parse_args()
    m.need(sum([a.check_inputs,a.execute,a.final_readback])==1,'one explicit mode')
    check()
    if a.check_inputs:
        print('PASS_V3_DISJOINT_GUARDED_PHASE_INPUTS_NOT_EXECUTION');return
    if a.final_readback:readback();return
    m.need(not WORK.exists()and not PROOF_SCOPE.exists()and not READ_SCOPE.exists(),
           'fresh append/readback proof scopes')
    WORK.mkdir()
    command=proof_command()
    m.atomic(WORK/'PLAN.json',dict(command=command,pins=m.read(PINS),
        qualification='Host controller does not set host limits. Actual heavy proof and '
        'finalreadback each receive independent resource_scope_v3 admission.'))
    for role,cmd in [('append',command),('final-readback',[
        sys.executable,str(R/'scripts/resource_scope_v3.py'),'--family','root_generic',
        '--memory-gib','4','--cpus','2','--wall','3600','--out',str(READ_SCOPE),'--',
        sys.executable,'-I','-B',str(Path(__file__)),'--final-readback'])]:
        with(WORK/(role+'.stdout')).open('xb')as so,(WORK/(role+'.stderr')).open('xb')as se:
            result=subprocess.run(cmd,stdout=so,stderr=se)
        m.atomic(WORK/(role+'.COMMAND_RESULT.json'),dict(command=cmd,exit_code=result.returncode))
        m.need(result.returncode==0,'preserved '+role+' failure; no final success')
    m.need((WORK/'RECEIPT.json').is_file(),'actual final acceptance receipt')
    print('PASS_GUARDED_ORIGINAL_APPEND_AND_READBACK_V3',flush=True)

if __name__=='__main__':main()
