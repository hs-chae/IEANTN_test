"""Validate all successful compilations from a namespace whose final audit failed.

The resulting checkpoint is deliberately NOT mathematical acceptance. Only a new
complete typed audit may accept it. Original source and evidence stay unchanged.
"""
import argparse
import copy
import importlib.util
import os
import re
from pathlib import Path

B = Path(__file__).resolve().parent
R = B.parents[1]
spec = importlib.util.spec_from_file_location('old_engine', B/'input-v3/engine_v3.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
OLD = 'b267edba365449043ebee7a2f076ede1bc683760b06b542621b2c47170e28ad3'


def prepare(task, environment, parent, checkpoint, prior, resource, out):
    m.need(not out.exists(), 'fresh prefix output')
    m.need(m.sha(B/'input-v3/engine_v3.py') == OLD, 'unchanged original engine')
    lock, env, index = m.source_check(task, environment)
    seeds = m.validate_prior(m.read(checkpoint), prior, task, environment, index)
    files = [parent/p for p in ['REQUEST.json', 'SPEC.json', 'INPUTS.json',
              'data/NAMESPACE_PROBE.json', 'data/COMMAND_RESULT.json',
              'data/run/INPUT_ASSOCIATION.json', 'data/run/PROGRESS.json',
              'data/run/Audit.lean', 'data/run/module-receipts/audit.execution.json']]
    files += [task/'SOURCE_LOCK.json', environment, checkpoint, resource, resource.parent/'RUNNING.json', resource.parent/'LIVE.json']
    before = {str(p): m.sha(p) for p in files}
    req, ns, inputs, spec0 = [m.read(parent/p) for p in
        ['REQUEST.json','data/NAMESPACE_PROBE.json','INPUTS.json','SPEC.json']]
    assoc, command, progress = [m.read(parent/p) for p in
        ['data/run/INPUT_ASSOCIATION.json','data/COMMAND_RESULT.json','data/run/PROGRESS.json']]
    expected_command = ['/usr/bin/python3.10','-I','-B','/engine/engine_v3.py','run',
        '--task','/task','--environment','/environment.json','--out','/out/run',
        '--prior',str(prior),'--checkpoint','/checkpoint.json','--jobs','16']
    m.need(req['command'] == command['command'] == expected_command and command['exit_code'] == 1,
           'exact failed original namespace command')
    m.need(not (parent/'RECEIPT.json').exists() and not (parent/'data/run/RECEIPT.json').exists(),
           'failed original audit has no complete acceptance')
    m.need(ns['status'] == 'PASS_DISTINCT_NAMESPACES_AND_RESTRICTED_PROOF_INPUTS' and
           ns['host_workspace_absent'] is True and ns['research_git_history_absent'] is True and
           set(ns['namespaces']) == set(req['parent_namespaces']) == {'pid','mnt','net'} and
           all(ns['namespaces'][k] != req['parent_namespaces'][k] for k in ns['namespaces']),
           'actual isolated failed namespace')
    pins = req['compiler_pins']
    m.need(ns['compiler_pins'] == pins and len({p['path'] for p in pins}) == len(pins) and
           any(p['path'] == env['compiler'] for p in pins) and
           all(m.sha(p['path']) == p['sha256'] for p in pins), 'actual compiler/kernel pins')
    expected_mounts = {'/task':str(task),'/environment.json':str(environment),
        '/engine':str(B/'input-v3'),'/checkpoint.json':str(checkpoint),str(prior):str(prior)}
    for virtual, actual in expected_mounts.items():
        m.need([e for e in spec0['entries'] if e['path'] == virtual] ==
               [dict(kind='ro',path=virtual,source=actual)], 'original read-only mapping '+virtual)
    m.need([e for e in spec0['entries'] if e['kind'] == 'rw'] ==
           [dict(kind='rw',path='/out',source=str(parent/'data'))], 'single original output')
    m.need(len({v['path'] for v in inputs}) == len(inputs), 'unique original input paths')
    inp = {v['path']:v['sha256'] for v in inputs}
    for v in inputs:
        m.need(m.sha(task/m.relative(v['path'])) == v['sha256'], 'original mounted input '+v['path'])
    for v in lock['sources'] + lock['payloads']:
        m.need(inp.get(v['path']) == v['sha256'], 'complete source/payload mounts')
    m.need(inp.get('SOURCE_LOCK.json') == m.sha(task/'SOURCE_LOCK.json'), 'mounted lock')
    expected_objects = [dict(module=n,path=str(prior/v['files']['object']['path']),
                        sha256=v['files']['object']['sha256']) for n,v in sorted(seeds.items())]
    m.need(sorted(req['application_object_inputs'],key=lambda x:x['module']) == expected_objects and
           req['prior_checkpoint_sha256'] == m.sha(checkpoint), 'exact original seed inputs')
    m.need(assoc['source_lock_sha256'] == m.sha(task/'SOURCE_LOCK.json') and
           assoc['environment_sha256'] == m.sha(environment) and assoc['engine_sha256'] == OLD and
           assoc['prior_checkpoint_sha256'] == m.sha(checkpoint) and
           set(assoc['application_object_inputs']) == set(seeds), 'source/engine/prior association')
    m.need(progress['completed'] == progress['total'] == len(index) and
           progress['seeded'] == len(seeds) and progress['new'] + len(seeds) == len(index),
           'all original modules finished')
    m.need((parent/'data/run/Audit.lean').read_text() == m.audit_text(lock), 'exact failed old audit')
    audit = m.read(parent/'data/run/module-receipts/audit.execution.json')
    m.need(audit['command'] == [env['compiler'],'-j1','-R','/out/run','/out/run/Audit.lean'] and
           audit['exit_code'] == 1, 'actual failed final audit command')
    for v in audit['files'].values():
        m.need(m.sha(parent/'data/run'/m.relative(v['path'])) == v['sha256'], 'failed audit raw hash')
    raw = (parent/'data/run'/audit['files']['stdout']['path']).read_text()
    m.need('maximum recursion depth reached in the code generator' in raw and
           'inferInstance' in raw and 'BODY_AUDIT ' not in raw, 'specific audit-only codegen failure')
    rs = m.read(resource)
    running, live = m.read(resource.parent/'RUNNING.json'), m.read(resource.parent/'LIVE.json')
    m.need(running['unit'] == live['unit'] == rs['unit'] and live['cgroup'] == rs['cgroup'] and
           running['launcher_pid'] == live['launcher_pid'] and type(live['launcher_pid']) is int,
           'actual recorded resource launcher and final scope association')
    m.need(rs['exit_code'] == 1 and not Path('/proc',str(live['launcher_pid'])).exists(),
           'original resource controller actually failed and drained')
    cg = Path(rs['cgroup'])
    m.need(cg.is_absolute() and cg.is_relative_to('/sys/fs/cgroup') and
           (not (cg/'cgroup.procs').exists() or not (cg/'cgroup.procs').read_text().strip()),
           'original resource scope empty')
    rows = {}
    for p in sorted((parent/'data/run/module-receipts').glob('*.json')):
        if p.name.endswith('.execution.json'): continue
        v = m.read(p)
        if v.get('origin') == 'READONLY_VALIDATED_PRIOR_APPLICATION_OBJECT':
            n = v['record']['module']
            m.need(n in seeds and v['record'] == seeds[n] and
                   v['checkpoint_sha256'] == m.sha(checkpoint), 'exact inherited seed wrapper')
            origin, record = prior, seeds[n]
        else:
            n, origin, record = v['module'], parent/'data/run', v
            m.need(n not in seeds, 'fresh vs seeded disjoint')
        m.need(n not in rows, 'unique compiled record')
        rows[n] = (copy.deepcopy(record), origin, p)
    m.need(set(rows) == set(index), 'all exact10338 successful compile records')
    links = []
    for n, (v, origin, receipt) in rows.items():
        expected = index[n]
        m.need(v['exit_code'] == 0 and v['source_sha256'] == expected['sha256'] and
               v['dependencies'] == expected['imports'] and set(v['dependencies']) <= set(rows) and
               v['command'] == m.expected_command(env['compiler'],expected,'/task','/out/run'),
               'exact source/dependencies/executed compiler '+n)
        m.need(set(v['files']) == {'object','stdout','stderr','time'}, 'complete files '+n)
        original_files = copy.deepcopy(v['files'])
        for kind, f in v['files'].items():
            src = origin/m.relative(f['path'])
            m.need(src.is_file() and not src.is_symlink() and m.sha(src) == f['sha256'],
                   'unchanged '+kind+' '+n)
            rel = (Path('data/run/objects')/Path(n.replace('.','/')).with_suffix('.olean')
                   if kind == 'object' else Path('data/run/logs')/(n+'.'+kind))
            links.append((src,rel,f['sha256']))
            f['path'] = str(rel)
        timing = (origin/original_files['time']['path']).read_text()
        m.need(timing.splitlines()[0] == '\tCommand being timed: "'+' '.join(v['command'])+'"' and
               timing.splitlines().count('\tExit status: 0') == 1, 'actual GNUtime exit0 '+n)
        diagnostic = ''.join((origin/original_files[k]['path']).read_text() for k in ['stdout','stderr'])
        m.need(not re.search(r"declaration uses ['`]sorry['`]",diagnostic) and
               not re.search(r'(^|\n).*: error(?:\(|:)',diagnostic), 'no incomplete proof '+n)
    m.need(all(m.sha(p) == h for p,h in before.items()), 'origin evidence unchanged during validation')
    out.mkdir(parents=True)
    for src, rel, digest in links:
        dst = out/rel; dst.parent.mkdir(parents=True,exist_ok=True); os.link(src,dst)
    provenance = {}
    for i,p in enumerate(files):
        rel = Path('provenance')/(str(i)+'-'+p.name); dst=out/rel
        dst.parent.mkdir(exist_ok=True); dst.write_bytes(p.read_bytes());provenance[str(rel)] = m.sha(dst)
    cp = dict(schema='SOURCE_COLD_CHAIN_CHECKPOINT_V1',
        status='CONTROLLED_FRESH_PREFIX_NOT_FULL_ACCEPTANCE',origin_root=str(out),
        recorded_source_root='/task',recorded_output_root='/out/run',
        source_lock_sha256=m.sha(task/'SOURCE_LOCK.json'),environment_sha256=m.sha(environment),
        provenance=provenance,records=[rows[n][0] for n in sorted(rows)],
        qualification='All original10338 source compilations succeeded; original final audit FAILED '
        'code-generator recursion, not mathematical acceptance. A new supplemental full typed audit '
        'must pass before this prefix becomes an audited complete parent. No empty-bank rerun claim.')
    m.atomic(out/'CHECKPOINT.json',cp)
    m.validate_prior(cp,out,task,environment,index)
    result=dict(status='PASS_ALL_COMPILED_PREFIX_ONLY_AUDIT_STILL_PENDING',modules=len(rows),
        seeded=len(seeds),fresh=len(rows)-len(seeds),failed_audit=audit,
        script_sha256=m.sha(Path(__file__)),checkpoint_sha256=m.sha(out/'CHECKPOINT.json'),
        qualification=cp['qualification'])
    m.atomic(out/'PREPARATION_RECEIPT.json',result)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ['task','environment','parent','checkpoint','prior','resource','out']:
        p.add_argument('--'+key,type=Path,required=True)
    a=p.parse_args();print(m.parse(__import__('json').dumps(prepare(**{k:v.resolve() for k,v in vars(a).items()}))))

if __name__ == '__main__':main()
