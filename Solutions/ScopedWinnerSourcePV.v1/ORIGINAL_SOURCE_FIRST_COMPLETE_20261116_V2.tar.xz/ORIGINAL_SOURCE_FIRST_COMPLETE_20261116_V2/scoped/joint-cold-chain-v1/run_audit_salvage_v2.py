"""Actual audit-only recovery; no numerical/application source is recompiled."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

B=Path(__file__).resolve().parent
R=B.parents[1]
BASE=R/'scoped/current65-joint-source-input-v1/capsule-v6'
ENV=R/'scoped/build/current52-public-environment-OO.json'
OLD=B/'continuation-v1/namespace'
WORK=B/'audit-salvage-v2'
VIEW=WORK/'all10338-compiled-prefix'
OUT=WORK/'namespace'

def need(x,s):
    if not x:raise ValueError(s)

def main():
    need(not WORK.exists(),'fresh audit salvage directory')
    WORK.mkdir()
    command=[sys.executable,'-I','-B',str(B/'prepare_failed_audit_prefix_v2.py'),
        '--task',str(BASE),'--environment',str(ENV),'--parent',str(OLD),
        '--checkpoint',str(B/'continuation-v1/LEGACY_CHECKPOINT.json'),
        '--prior',str(R/'scoped/build/current66-joint-isolated-v1/namespace'),
        '--resource',str(R/'resources/current66-joint-continuation-v1/scope.json'),
        '--out',str(VIEW)]
    print('VALIDATE_ALL10338_COMPILE_RECORDS_START',flush=True)
    with (WORK/'prefix.stdout').open('xb') as so,(WORK/'prefix.stderr').open('xb') as se:
        q=subprocess.run(command,stdout=so,stderr=se)
    need(q.returncode==0,'all10338 compile-prefix validation failed; original retained')
    print('VALIDATE_ALL10338_COMPILE_RECORDS_PASS_AUDIT_PENDING',flush=True)
    inner=['/usr/bin/python3.10','-I','-B','/engine/engine_v3.py','run',
        '--task','/task','--environment','/environment.json','--out','/out/run',
        '--prior',str(VIEW),'--checkpoint','/checkpoint.json','--jobs','1']
    command=[sys.executable,'-I','-B',str(B/'launch_chain_v3.py'),
        '--input',str(BASE),'--environment',str(ENV),'--out',str(OUT),
        '--engine',str(B/'input-v4'),'--prior',str(VIEW),
        '--checkpoint',str(VIEW/'CHECKPOINT.json'),'--',*inner]
    print('AUDIT_ONLY_NAMESPACE_START_10338_PRIOR_0_NEW_20225_ROOTS',flush=True)
    with (WORK/'namespace.stdout').open('xb') as so,(WORK/'namespace.stderr').open('xb') as se:
        q=subprocess.run(command,stdout=so,stderr=se)
    need(q.returncode==0,'new bounded supplemental audit failed; no success accepted')
    spec=importlib.util.spec_from_file_location('m4',B/'input-v4/engine_v3.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    receipt=m.read(OUT/'data/run/RECEIPT.json')
    m.need(receipt['source_modules']==10338 and receipt['roots']==20225 and
           receipt['new_compilations']==0 and receipt['prior_modules']==10338,
           'exact audit-only population')
    m.atomic(WORK/'RECEIPT.json',dict(status='PASS_SUPPLEMENTAL_10338_AUDIT_ONLY_RECOVERY',
        audit_receipt_sha256=m.sha(OUT/'data/run/RECEIPT.json'),
        namespace_receipt_sha256=m.sha(OUT/'RECEIPT.json'),
        prior_checkpoint_sha256=m.sha(VIEW/'CHECKPOINT.json'),
        source_modules=10338,roots=20225,new_compilations=0,
        qualification='Original10338 successful source compilations retained. Original final giant '
        'audit failed codegen recursion. New bounded full typed audit is supplemental/chained, '
        'not an uninterrupted successful old run or another empty-application-bank run.'))
    print('PASS_SUPPLEMENTAL_10338_AUDIT_ONLY_RECOVERY',flush=True)

if __name__=='__main__':main()
