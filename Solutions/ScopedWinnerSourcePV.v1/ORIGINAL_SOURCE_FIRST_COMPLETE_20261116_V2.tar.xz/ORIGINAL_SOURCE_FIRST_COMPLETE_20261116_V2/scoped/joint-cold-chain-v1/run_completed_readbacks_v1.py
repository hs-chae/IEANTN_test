from pathlib import Path
import concurrent.futures
import importlib.util
import subprocess

B = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('strict', B / 'input-v4/engine_v3.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def main():
    out = B / 'original10970-readback-modes-v1'
    m.need(not out.exists(), 'fresh three-mode readback')
    out.mkdir()
    def run(item):
        name, options = item
        destination = out / name
        command = ['/usr/bin/python3.10', *options, '-I', '-B',
                   str(B / 'readback_completed_original_v1.py'), '--out', str(destination)]
        with (out / (name + '.stdout')).open('xb') as stdout, \
                (out / (name + '.stderr')).open('xb') as stderr:
            result = subprocess.run(['/usr/bin/time', '-v', '-o', str(out / (name + '.time')),
                                     *command], stdout=stdout, stderr=stderr)
        m.need(result.returncode == 0, 'actual completed readback rejected ' + name)
        receipt = destination / 'RECEIPT.json'
        return dict(mode=name, command=command, receipt_sha256=m.sha(receipt))
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        records = list(executor.map(run, [('normal', []), ('O', ['-O']), ('OO', ['-OO'])]))
    m.need(len({row['receipt_sha256'] for row in records}) == 1,
           'three actual acceptance routes byte-identical')
    m.atomic(out / 'RECEIPT.json', dict(
        status='PASS_COMPLETED10970_FULL_SOURCE_READBACK_NORMAL_O_OO_BYTEIDENTICAL',
        records=records, qualification='Full evidence/source validation only; no extra Lean build. '
        'Original accepted source/proof artifacts retained; actual chained proof remains separate.'))
    print('PASS_COMPLETED10970_FULL_SOURCE_READBACK_NORMAL_O_OO_BYTEIDENTICAL', flush=True)

if __name__ == '__main__':
    main()
