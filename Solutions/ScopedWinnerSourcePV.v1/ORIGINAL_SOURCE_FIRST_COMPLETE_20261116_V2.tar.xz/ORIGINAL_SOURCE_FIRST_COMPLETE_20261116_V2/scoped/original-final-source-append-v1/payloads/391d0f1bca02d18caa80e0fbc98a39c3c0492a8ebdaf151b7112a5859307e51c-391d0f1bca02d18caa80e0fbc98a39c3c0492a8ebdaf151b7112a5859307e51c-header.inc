#include <lean/lean.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
extern "C" void lean_initialize_runtime_module(void);
typedef lean_object* N;
struct S{N mag;unsigned neg;};
struct Q{S num;N den;};
struct RI{Q lo;Q hi;};
struct I{S lo;S hi;unsigned ok;};
struct Node{unsigned op;unsigned a;unsigned b;const char* num;const char* den;};
struct Row{const Node* nodes;unsigned count;unsigned cells;};
static N pool[4000000];
static unsigned poolTop=0;
static unsigned poolHigh=0;
static unsigned depth=24;
static N scale100;
static Q expCoeffs[65];
static Q atanhCoeffs[65];
static RI preparedLn2;
