int main(){lean_initialize_runtime_module();
prepare(24);
unsigned int mark=poolTop;
for(unsigned int j=0;(j<4);(j=(j+1))){I result=runRow((heightRows[j]),mark,0);
printI(result);
clearTo(mark);
lean_dec(((result.lo).mag));
lean_dec(((result.hi).mag));}
fprintf(stderr,"poolHigh=%u\n",poolHigh);
clearTo(0);
return 0;}
