# Original Scoped Winner source-first verification: complete

This package reproduces the original fixed experiment, with its unchanged
8,192 versus16,384 integration cells,39 recorded comparator identities and
conditional coefficient improvement
**0.009474458010474448 → 0.009471462010471452**. The original strict comparison
on **[exp(330), exp(331)]** is preserved. The refined prime-counting bound applies
from exp(300). This does not claim optimality, a best-known bound, or a PV-exclusive
mathematical advantage.

The actual C++ application has its **own** evaluator, interval arithmetic and
loops. It uses the pinned Lean **core Nat and reference-count runtime API** as
primitive arithmetic/storage; it does not call a Lean application evaluator,
`native_decide`, or a preverified output oracle. Source/AST correspondence,
execution, interval correctness, physical result words/flags and their actual
mathematical consumers are connected. Canonical52,physical4 and the additive56
programs retain their full initialized source execution. The latter supplies the
four sensitivity cases without changing the original52-row programme.

The27 mathematical target interfaces retain their exact old types;15 data
interfaces retain their values. The original seven grouped input contracts are
unchanged. Unpacking the actual preserved `PrimaryInputs` structure gives14
propositions; this count is established from the original signature, not inferred
from the broader research. See `ScopedWinnerA/Result.lean` and
`WinnerDensityA/HeightPrimary.lean` in the source task, and the preserved
source/definition-value audit under `Evidence/source-claims/`.

The independent final source census checks all original49 primary native
identities,50 in the joint result, and the four sensitivity C computations.
All53 old numerical checker leaves,16 old inline scalar owners and the old
Gamma theorem are absent from the selected final proof closures. Only the
standard three axioms remain. The arithmetic comparison itself was already
native-free and uses no source fields; its classification remains separate.

## Actual completed verification

All10,970 modules and20,306 selected typed standard-axiom roots passed inside
source-only namespaces with explicit validated source-built seeds. The actual
history is deliberately preserved:

1. An earlier3,976-module source-built prefix was validated.
2. The next6,362 modules compiled, completing10,338, but their giant final audit
   failed code-generator recursion (`inferInstance`). No old success receipt was
   fabricated.
3. A supplemental audit-only run verified the same10,338 objects and all20,225
   root identities using bounded audit blocks. It compiled zero application modules.
4. The632-module repair append compiled, followed by all20,306 typed audits and
   the independent exact original source-identity census. This192GiB scope took
   2,934.23s with zero OOM. Sampled charged RAM reached at least95,450,693,632B;
   exact aggregate peak was unavailable. Largest compiler child RSS was
   38,619,693,056B. These are distinct measurements.
5. Full source/object/command/log/namespace/census readbacks in normal,`-O` and
   `-OO` passed byte-identically. They are validation, not three new Lean builds.

The ten actual C++ numerical proposers, all3,840 numerical transcript sources,
the fresh52/4/56 native programs and all533 word-proof sources were regenerated
and checked separately. Execution commands, versions, parameters, hashes,
failures and receipts are included. All calculations are deterministic; random
seeds do not apply.

## Reproduce from a clean application environment

Use Linux amd64 with the exact matching compiler/development/runtime packages
recorded in `scoped/original-regeneration-addon-v1/SYSTEM_DEPENDENCIES_BEFORE_NATIVE_V1.json`.
A user-systemd service and the existing namespace functionality are required.
No host configuration change is performed. Provision public generic dependencies
using the supplied unchanged bootstrap:

```sh
python3 scoped/original-regeneration-addon-v1/environment-bootstrap/scripts/bootstrap.py \
  --work "$PWD/work/public-environment" \
  --receipt "$PWD/work/public-environment-receipt.json"
```

The official toolchain archive SHA and all public dependency commits are pinned
under that bootstrap directory. Then inspect the complete recipe inputs:

```sh
python3 -I -B scoped/original-regeneration-addon-v1/reproduce_complete_v2.py \
  --environment "$PWD/work/public-environment/ENVIRONMENT.json" --check-inputs
```

Run the complete source-only default under adequate resources. The archive includes
`evidence/.keep` so the resource registry directory exists after extraction;
creating it explicitly is also safe:

```sh
mkdir -p evidence
python3 scripts/resource_scope_v3.py --family root_generic \
  --memory-gib 192 --cpus 24 --wall 86400 --out "$PWD/work/resource-full" -- \
  python3 -I -B scoped/original-regeneration-addon-v1/reproduce_complete_v2.py \
  --environment "$PWD/work/public-environment/ENVIRONMENT.json" \
  --out "$PWD/work/full" --jobs 12
```

Resource admission checks actual separate RAM/disk availability and aggregate
host headroom; budget is not measured peak.

The default rebuilds/runs every numerical workload, regenerates all4,373
numerical source files, checks their exact hashes, materializes the complete
10,970-source graph and compiles it from an **empty application object bank**.
It then checks all20,306 typed roots and the independent source census. No
application `.olean`,binary cache or trusted certificate is supplied.

The composed default is provided and input-tested; it was **not** executed as
another uninterrupted full run. The actual completed study consists of the
checked numerical stages and the explicit source-built chain described above.
`NUMERICAL_SOURCE_REGENERATION_OMISSIONS.json` lists every omitted regenerable
source file/hash. The6597 fixed source files and all1299 include payloads are
included. Failure never becomes acceptance and every output directory must be fresh.

## Trust and limits

The pinned Lean kernel, standard axioms, generic core Nat/RC runtime, C++
compiler/ABI, documented I/O/runtime and OS/hardware contracts remain explicit.
Source programme output/initialization/success is not trusted as a platform fact.
Modeled accepted CSV bytes and physical source-state reads are verified under
normal I/O; actual native stdout/source/build/runtime association is checked
separately. This is not a formal OS-pipe or hardware-memory-trace theorem.

This completes the original independent mathematical/source-first experiment.
It does not fabricate an official IEANTN Comparator receipt or network status.
Broader Moment/Vector/theta research source-only replay remains a separate study.
Historical archives and primary experimental outcomes are unchanged.

This additive distribution V2 fixes only the resource-workspace bootstrap. The
first archive remains preserved. All 10,970 Lean source identities, 1,299 include
payloads, mathematical inputs, source lock and resource launcher source are
unchanged. Fresh archive verification and actual relocated resource admission
are recorded separately; no new mathematical proof replay is implied.
