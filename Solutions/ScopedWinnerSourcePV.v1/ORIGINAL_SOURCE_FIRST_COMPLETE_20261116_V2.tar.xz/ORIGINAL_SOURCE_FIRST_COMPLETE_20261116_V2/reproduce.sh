#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 scripts/resource_scope_v3.py --family root_generic --memory-gib 192 --cpus 24 \
  --wall 86400 --out "$PWD/work/resource-full" -- \
  python3 -I -B scoped/original-regeneration-addon-v1/reproduce_complete_v2.py \
  --environment "$PWD/work/public-environment/ENVIRONMENT.json" \
  --out "$PWD/work/full" --jobs 12
