"""Publish the completed59-source audit; rewrite hyperlinks only, never mathematics."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib,html,json,re,shutil,urllib.parse
B=Path(__file__).resolve().parent;R=B.parents[1];N=R/'network';D=N/'Solutions/MomentPNT.v1.PUBLICATION/SourceAudit'
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def main():
 need(not D.exists(),'fresh publication supplement');D.mkdir()
 originals=['RECEIPT_V2.json','REVIEW_DELTA_V3.csv','SCOPE59_V1.csv','PRIMARY14_IDENTITIES_V1.json','PRIMARY8_IDENTITIES.json','SUPPORT_OBJECTS_V1.json','EXPLICIT_SUPPORT_FORMULAS_V1.json','PRIMARY_REVIEW_NOTES.md','RENDER_RECEIPT_V4.json','source_locators_v1.py','explicit_support_formulas_v1.py']
 for rel in originals:shutil.copyfile(B/rel,D/rel)
 (D/'papers').mkdir()
 for rel in ['MANIFEST_V1.json','MANIFEST_ADDITIONS_V1.json']:shutil.copyfile(B/'papers'/rel,D/'papers'/rel)
 manifests=[json.loads((B/'papers/MANIFEST_V1.json').read_text())['primary_sources'],json.loads((B/'papers/MANIFEST_ADDITIONS_V1.json').read_text())['sources']]
 papers={Path(x['path']).name:x for rows in manifests for x in rows}
 # Version labels are read from the actual cached PDF title pages, not latest URLs.
 urls={'CH2_2512.15709.pdf':'https://arxiv.org/pdf/2512.15709v1','CHJ2111.10001v5.pdf':'https://arxiv.org/pdf/2111.10001v5','CullyTrudgian1911.07369.pdf':'https://arxiv.org/pdf/1911.07369v1','FKS2204.02588v3.pdf':'https://arxiv.org/pdf/2204.02588v3','Hiary1507.01261v4.pdf':'https://arxiv.org/pdf/1507.01261v4','PlattTrudgian2004.09765.pdf':'https://arxiv.org/pdf/2004.09765v1','Revers2602.05614v1.pdf':'https://arxiv.org/pdf/2602.05614v1','KLN2018_authors.pdf':'https://www.cs.uleth.ca/~kadiri/articles/Explicit-zero-density-for-the-Riemann-zeta-function-JMAA-May2018.pdf','OpenAIQRH_20260930.pdf':'https://github.com/openai/math/raw/7ef5c0cc5ca4b0e072b7a050fca09ab24bc6fa3a/preprints/The-Quasi-Riemann-Hypothesis-September-30-2026/paper.pdf'}
 need(set(urls)==set(papers),'exactnine primary identities')
 import fitz
 publicpapers=[]
 for name,url in urls.items():
  p=B/'papers'/name;need(sha(p)==papers[name]['sha256'],'actual cached primary hash');doc=fitz.open(p);first=doc[0].get_text();versions=re.findall(r'arXiv\s*:\s*([0-9.]+v\d+)',first)
  if 'arxiv.org' in url:need(len(versions)==1 and url.endswith('/'+versions[0]),'actual title-page version')
  publicpapers.append(dict(cached_name=name,cached_sha256=sha(p),pages=len(doc),actual_title_page_arxiv=versions,primary_url=url,original_manifest_record=papers[name],identity_qualification=('ActualMay2018authors24page manuscript, creationDateD:20180524161743-06; author primary directory explicitly lists this file. LivePDF origin timed out in urllib and web; no fresh byte identity or current availability claimed. Associated arXivv1 is not substituted for the pinned author PDF.'if name=='KLN2018_authors.pdf'else 'PinnedGitcommit source; the raw route addresses the same paper blob.'if name.startswith('OpenAI')else 'Version read from exact pinned cached titlepage; page anchors retain physical PDFpage numbers.')))
 report='PRIMARY14_AND_SUPPORT_SOURCE_AUDIT_V4.html';original=(B/report).read_text();mapping={};snapshots=[]
 def change(m):
  old=html.unescape(m.group(1));u=urllib.parse.urlsplit(old)
  if u.scheme or old.startswith('#'):new=old
  elif u.path.endswith('.pdf'):
   name=Path(u.path).name;need(name in urls,'known actual primary PDF');new=urls[name]+('#'+u.fragment if u.fragment else '')
  elif u.path.startswith('../../'):
   source=(B/urllib.parse.unquote(u.path)).resolve();need(source.is_relative_to(R)and source.is_file(),'actual source link');rel=source.relative_to(R);target=D/'SourceSnapshots'/rel;target.parent.mkdir(parents=True,exist_ok=True)
   if not target.exists():shutil.copyfile(source,target);snapshots.append(dict(original_source=str(rel),published_path=str(target.relative_to(D)),sha256=sha(source)))
   need(sha(source)==sha(target),'samebyte source snapshot');new=str(target.relative_to(D))+('#'+u.fragment if u.fragment else '')
  else:
   need((D/u.path).is_file(),'copied exactlocal evidence '+old);new=old
  mapping[old]=new;return 'href="'+html.escape(new,quote=True)+'"'
 published=re.sub(r'href="([^"]+)"',change,original)
 strip=lambda t:re.sub(r'href="[^"]+"','href=""',t)
 need(strip(original)==strip(published),'link-only byte/text gate')
 math=lambda t:re.findall(r'<math\b[\s\S]*?</math>',t)
 need(len(math(original))==83 and math(original)==math(published),'all83 statically rendered formula bytes unchanged')
 (D/report).write_text(published)
 (D/'PRIMARY_PAPERS.json').write_text(json.dumps(dict(status='PINNED_NINE_PRIMARY_IDENTITIES_AND_PRECISE_PDF_PAGE_ROUTES',papers=publicpapers,PDFs_republished=False,qualification='Primary source provenance and cached exact hashes retained; external availability is separate from source identity. KLN author origin currently timedout; source remains exactcached2018manuscript.'),indent=2)+'\n')
 manifest=dict(status='LINK_ONLY_PUBLICATION_OF_COMPLETE_EXISTING59_SOURCE_AUDIT',original_report_sha256=sha(B/report),published_report_sha256=sha(D/report),report=report,hyperlink_occurrences=len(re.findall(r'href="',original)),unique_hyperlinks=len(mapping),mapping=mapping,all83_mathml_sha256=[digest(x)for x in math(published)],non_href_text_sha256=digest(strip(published)),source_snapshots=snapshots,original_copies=[dict(path=f,sha256=sha(D/f))for f in originals+['papers/MANIFEST_V1.json','papers/MANIFEST_ADDITIONS_V1.json']],qualification='Only href attributes rewritten. The original HTML can be restored byte-for-byte by reversing this exact mapping; all source/math prose and all83 MathML formulas are unchanged.15 same-byte source snapshot files;9 primary URL identities and exact physical page numbers, no PDF republication. Original source claims/outcomes and paper authority unchanged.')
 (D/'LINK_ONLY_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
 meta=N/'IEANTN/Nodes/MomentSourceInputs/v1/formalization.yaml';before=meta.read_text();after=before.replace('audit/primary14-source-audit-v1/RECEIPT_V2.json','Solutions/MomentPNT.v1.PUBLICATION/SourceAudit/RECEIPT_V2.json').replace('PRIMARY14_AND_SUPPORT_SOURCE_AUDIT_V4.html','Solutions/MomentPNT.v1.PUBLICATION/SourceAudit/PRIMARY14_AND_SUPPORT_SOURCE_AUDIT_V4.html').replace('REVIEW_DELTA_V3.csv','Solutions/MomentPNT.v1.PUBLICATION/SourceAudit/REVIEW_DELTA_V3.csv')
 need(after!=before and 'audit/primary14-source-audit-v1/RECEIPT_V2.json'not in after,'actual repository evidence paths');meta.write_text(after)
 (D/'METADATA_PATH_ONLY_UPDATE.json').write_text(json.dumps(dict(metadata=str(meta.relative_to(N)),before_sha256=digest(before),after_sha256=digest(after),qualification='Only three evidence-location strings rewritten; no formula, primarysource URL, locator, status, imports, Lean declaration or source package changed.'),indent=2)+'\n')
 print('published',len(mapping),len(snapshots),len(publicpapers),sha(D/report))
if __name__=='__main__':main()
