from pathlib import Path
import re,json,hashlib
B=Path(__file__).resolve().parent;R=B.parents[1];O='scoped/kernel-overlay51-v1/lean/'
GROUPS=[
(O+'OriginalScalarSemantics.lean','WinnerOriginalScalars',['height','sourceM0'],'KLN3.15; FKS2.8 updated height'),
(O+'WinnerBetaA/ActualObject.lean','WinnerBetaA.ActualObject',['vertical','mollifier','mollifiedError','cumulativeSquare','scaledCriticalF','smoothingWeight','sourceMoment'],'KLN2.4,2.5,2.10,2.11,3.17'),
(O+'WinnerBetaA/Moment.lean','WinnerBetaA.Minkowski',['gaussianWeight'],'KLN4.13 at beta2'),
(O+'WinnerBetaA/HeightSource.lean','WinnerBetaA.HeightSource',['meanOne','meanTwo','rightFive','rightSixExact','rightVExact'],'KLN4.1 proof beforeuniformization;3.10/3.11;4.19/4.20'),
(O+'WinnerDensityA/HeightContext.lean','WinnerNewHeightSource',['alpha','Hstar','shifted','rightLine','sourceOmega','sourceFdiff'],'KLN3.18/3.19;4.1; actualchosenparameters'),
(O+'WinnerDensityA/ActualLowerContour.lean','WinnerLowerContour',['rawRectangleBound'],'KLN2.3,2.9;4.14firstproofdisplay +FKS2.7proof C8/2'),
(O+'OriginalBoundaryScalars.lean','WinnerOriginalScalars',['sourceBSix','boundaryEta','boundaryMu','sourceBFive','sourceBSeven','sourceBEight','sourceBNine','sourceCSeven','sourceBEleven','sourceCEightBase','sourceBTen','sourceCEight'],'KLN4.44/4.45/4.50/4.51/4.56/4.59/4.63/4.66/4.68'),
(O+'LowerContourLimit.lean','WinnerLowerContour',['bEightAt','bNineAt','cSevenAt'],'KLN4.51/4.59/4.56 with actual lowerh'),
(O+'OriginalZeta.lean','WinnerOriginalScalars',['positiveZeta'],'KLNrealpositivezeta operands; exact positiveZeta_complex identity'),
('network/IEANTN/Vocabulary/Zeta.lean','IEANTN',['zetaZeroes','zetaZeroesIn','zetaOrder','zetaZeroesSum','zetaN\''],'KLN1.1counting convention; zero multiplicity'),
('network/IEANTN/Nodes/ZeroCount/v1/Conclusions.lean','ZeroCount.v1',['zetaNClosed','rvmMain'],'CH2AppendixBdefinition ofN/Q'),
]
rows=[]
for file,namespace,names,source in GROUPS:
 p=R/file;text=p.read_text()
 for name in names:
  pattern=r'(?m)^(?:noncomputable )?def '+re.escape(name)+r'(?![\w\'])';m=re.search(pattern,text)
  if not m:raise ValueError('Missing exact supportdef '+file+':'+name)
  end=re.search(r'(?m)^(?:theorem|lemma|def|noncomputable def|end |/--)',text[m.end():]);stop=m.end()+end.start()if end else len(text)
  rows.append({'file':file,'decl_line':text[:m.start()].count('\n')+1,'lean_name':namespace+'.'+name,'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'written_definition':text[m.start():stop].rstrip(),'primary_correspondence':source})
if len({(x['file'],x['decl_line'],x['lean_name'])for x in rows})!=len(rows):raise ValueError('Duplicate supportidentity')
p=B/'SUPPORT_OBJECTS_V1.json'
if p.exists():raise ValueError('Fresh support inventory')
p.write_text(json.dumps({'selection':'Definitions actually instantiated in the eight field formulas, recursively through source-owned operands, plus actual zero-count conventions of the six external interfaces. Ordinary Mathlib infrastructure is outside the requested universe. These supportdefinitions are not extra input hypotheses.','rows':rows,'actual_parameters':{'d':'3681/10000','delta':'3599/10000','alpha':'601/5000','k':'1','eta':'507/2000','mu':'1237/1000','height':'3000000000000','Hstar':'height-1','sigma_range':'[3/4,7/8]','T_range':'T>=height'},'qualification':'Source-definition inventory only; per-interface comparison and domain derivations are recorded separately.'},indent=2)+'\n');print(p,'objects',len(rows),hashlib.sha256(p.read_bytes()).hexdigest())
if __name__=='__main__':pass
