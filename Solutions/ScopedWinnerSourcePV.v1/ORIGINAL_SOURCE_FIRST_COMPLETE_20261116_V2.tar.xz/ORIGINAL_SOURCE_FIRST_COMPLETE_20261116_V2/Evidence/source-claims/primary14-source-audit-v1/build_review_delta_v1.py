"""Per-identity mathematical source/contract delta for the exact14+45 universe."""
from pathlib import Path
import json,csv,hashlib,re
B=Path(__file__).resolve().parent;R=B.parents[1]
read=lambda p:json.loads(p.read_text())
primary=read(B/'PRIMARY14_IDENTITIES_V1.json')['rows'];support=read(B/'SUPPORT_OBJECTS_V1.json')['rows']
REV={
'lowZeta':('Hiary, An explicit van der Corput estimate, arXiv1507.01261v4, Theorem1.1 first sentence; Lemma2.2',
 '|zeta(1/2+it)|<=1.461 for0<=t<=3.',
 'Actual vertical(1/2,u)=1/2+iu,1461/1000=1.461, identical closed0..3 domain. The small-t interval computation inLemma2.2 is separate from the later large-t.63 argument.',
 '0<=u<=3; no zero/pole on this line. The primary theorem is unconditional.'),
'reversZeta':('Revers, arXiv2602.05614v1 Theorem1.1(a), PDFp3',
 '|zeta(1/2+it)|<=0.611*t^(1/6)*logt for EVERYt>=3.',
 'Exact coefficient611/1000, exponent1/6 and closed lower endpoint3. This usesRevers itself; HPY.618 is not substituted. ActualPDFtheorem checked.',
 'u>=3, realpositive powers; no pole oncritical line.'),
'mollifierMeanSquare':('KLN2018 Lemma4.1 PROOF PDFp9 before uniformization;3.5-3.7,3.14,3.15; object2.4',
 'For cutoffX>=1e9 and integration endpointt>0, mean-value+arithmetic estimates give integral0..t|M_X(1/2+iu)|^2 <= [(6/pi^2+b2/logX)*t+(pi*m0*b1/logX+6*m0/(pi*X)+pi*m0*b2/(XlogX))*X]*logX; b1=.62,b2=1.048,m0=sqrt(1+(2/3)sqrt(6/5)).',
 'Rename the source integrationendpoint to t, set cutoffX=T, retain the exactX-dependent proof expression. This is stronger than the printed uniformC1/C2 version and follows from the displayed preuniform proof, not mere substitution in its final statement. Code meanOne/meanTwo exactly match.',
 'ActualT>=3e12>=1e9; integrationt>0. Integer cutofffloorT realizesn<=T. All logs/denominatorspositive.'),
'sourceSmoothing':('KLN2018 Lemma3.7 Eqs3.17-3.18 andLemma4.5 Eq4.13 PDFp11',
 'M_{g,T}(X,sigma)<=4*omega1(sigma,T,alpha)^2*alpha*beta*integral_0^infinity x^(beta-1)*exp(-2alpha*x^beta)*F_X(sigma,xT)dx; g=(s-1)/s*exp(alpha(s/T)^2),omega1=exp(alpha(sigma/T)^2).',
 'Set beta2,sigma1/2,alpha601/5000,X=T. Coefficient becomes8alpha*exp(alpha/(2T^2)); gaussianWeight=x*exp(-2alpha*x^2), scaledCriticalF=F_T(1/2,xT). Actualf,M,g objectsmatch2.4/2.5/2.10/2.11. No chosenU or moment conclusion assumed.',
 'alpha=.1202>0,T>=3e12, sigma=.5. LebesgueIoi0 integral matches0..infinity; excludingoneendpoint doesnotchange integral.'),
'sourceRightMoment':('KLN2018 Lemma3.4 Eqs3.10-3.11;Lemma4.3 proof PDFp10;Lemma4.7 proof Eqs4.19-4.20 PDFpp12-13',
 'Before uniformizingX, C5=pi*m0*b4/(2delta)*(1+2delta/logX)^2*exp(2delta*gamma/logX); C6exact=b4/(5delta*expdelta)*(1+delta/logX)^2*exp(delta*(gamma-log5)/logX)+b3exp(-2delta)/logX^2. The smoothed rightmoment is<=8alpha*omega1^2*[(C5+C6exact*pi*m0/X)I(1,0)+C6exact*T/X*I(2,0)]logX^2.',
 'SetX=T,k1,b4=.529,b3=.605,gamma=Eulerconstant. ExactGaussianI1=1/(4alpha),I2=sqrtpi/(8alpha*sqrt(2alpha)). This is exactlyrightVExact. Retained negativeC6 exponent comes from3.11; printed4.11 alreadyrelaxes it to1. No unjustified uniform-coefficient strengthening.',
 'Actualdelta=.3599>0; underlying4.1/4.3/4.7 requirepositive delta, nottop-leveldensitytheorem displayeddelta>=1. X=T>=1e9; sigma2=1+delta/logT>1.'),
'sourceRectangle':('KLN2018 Eqs2.3,2.9;Lemma4.14 firstproofdisplay PDFp21;4.12/4.13; FKS2204.02588v3 Theorem2.7 proof/Eq2.16 PDFp7; Cully-HugillTrudgian1911.07369Theorem2',
 'At regularupper/loweredges, N(sigma,T)-N(sigma,h) <= [(T-h)log(1+(F_X(sigmap,T)-F_X(sigmap,h))/(T-h))+(C7(eta,h)*(mu-sigmap)+C8(k,mu)/2)logT]/[2pi(sigma-sigmap)]. C8/2 isFKS explicit divisor-sum correction toKLNright-edge term.',
 'ActualrawRectangleBound matches this BEFORE optimizeddensity/moment substitution; X=T,sigmap=sigma-d/logT,mu1.237. Fullb5..b11/C7/C8 and actualcSevenAt(lowerh) checkedagainstKLN4.44/45/50/51/56/59/63/66/68. Improvedsumd(n)^2<=xlog^3x(x>=7) halves the old2xlog^3x contribution linearly before uniformization. Countableexception sets cover actual top/lowerzeroordinates; cutofffloorT gives a countableunion of fixed-mollifier exceptional sets.',
 'Actuald=.3681>0,sigma in[.75,.875],logT>28 =>.5<sigmap<sigma<1<mu. eta.2535 in(eta0,.5);mu1.237 in[1+eta0,1+eta];T>=height3e12; h in(height-1,height),h>=1002,h>2pi*m0,h<T; X=T>=1e9,X<=T,k1. H0update3e12 explicitlyFKS2.7/Remark2.8. No finiteRH required in this count-difference field.'),
'sourceUnsmoothing':('KLN2018 Lemma3.7 Eq3.19;Lemma4.9 proof PDFp14 before moment substitution',
 'F_X(sigma,T)-F_X(sigma,H) <= M_{g,T}(X,sigma)/(2*omega2(sigma,T,alpha)^2),omega2=(1-1/H)exp(alpha(sigma/T)^2-alpha).',
 'ActualsourceOmega usesH=height-1,actualsigma=shifted(d,sigma,T),X=T,alpha.1202. Factor2 is from bothsignedordinates in the smoothed all-real moment. ActualFdiff is thedifference ofthe same fixedX cumulative squares; loweredge movement keepsX fixed.',
 'H=3e12-1>1,T>=3e12,H<T;shifted>.5;omega2>0. No pole encounter on the evaluated line.'),
'sourceInterpolation':('KLN2018 Lemma4.4 Eq4.12 PDFp11',
 'M_g(X,sigma)<=M_g(X,sigma1)^((sigma2-sigma)/(sigma2-sigma1))*M_g(X,sigma2)^((sigma-sigma1)/(sigma2-sigma1)) for1/2<=sigma1<=sigma<=sigma2 andsigma1<1<sigma2.',
 'sigma1=.5,sigma=shifted(d,sigma,T),sigma2=rightLine(delta,T),X=T. Both exponentweights and their denominator exactlymatch. No chosenmoment/density conclusion added. Source analyticpole removal changes atmosta singlepointof totalizedLean integrand anddoesnotchange theintegrals; actualusedvertical lines avoidthepole.',
 'logT>28 implies shifted>.736>.5 andshifted<1<rightLine; denominatorspositive. Gaussianweight gives the source moment domain/integrability.'),
'OriginalCHJSource':('Cully-HugillJohnston2111.10001v5 Theorem1.2 Eq1.5 PDFp2;Table4 PDFp20firstrow',
 '|psi(x)-x+sum_{nontrivialrho,|Imrho|<=T}x^rho/rho|<=6.431*x*logx/T forx>=exp40 andmax(51,logx)<T<(sqrtx-2)/2. Table4rowlogxM40,alpha1/2,lambda.48,M6.431.',
 'OriginalCHJSource has exactly6431/1000 andsame domains/closedheight/nontrivialzeroes/multiplicity. Takingrealpart onlyweakens sourcecomplexbound. Table4 supplies the named allowance; intro5.03 doesnotmake this validweakerallowance a mismatch. ActualtablePDFviewed.',
 'Realx>=exp40>0; sourceTstrictlower/upperbounds exact. Sumfinite and excludespole/trivialzeros by0<Re<1.'),
'RVMlarge':('ChirreHelfgott2512.15709 AppendixB LemmaB.1 secondhalf',
 'N(t) counts0<Imrho<=t withmultiplicity; Q=N-[t/(2pi)log(t/(2pi))-t/(2pi)+7/8]. For t>=1,|Q(t)|<=(1/5)logt+2.',
 'ActualzetaNClosed usesIoc0t andrvmMain hasidentical constants. Source-endpoint convention ispreserved; not silentlyreplaced byIoo. Zero sums boundedandfinite, so totalizedtsum branch unused.',
 't>=1,positive logarguments; allpositive-imaginaryzeros are nontrivial.'),
'RVMsmall':('ChirreHelfgott2512.15709 AppendixB LemmaB.1 firsthalf',
 'With the sameclosedheightN andQ,|Q(t)|<1 for0<t<=280.',
 'Both strict errorinequality andclosedt<=280 match. ActualNClosed/Q definitions inspected, including multiplicity andallpositiveordinates.',
 '0<t<=280,exact source domain.'),
'LowZeroFirst':('ChirreHelfgott2512.15709 AppendixB passage immediatelybeforeLemmaB.1',
 'The firstnontrivialpositive ordinate is14.13472514...; therefore thereare nozeroes with0<Imrho<14.134725.',
 'Code usesstrict openinterval0..14.134725 andemptyset, withmargin0=1. Trivialzeros are real,so univrealpart includesnoextra positive-imaginaryzero. It doesnotclaim exactequality withtruncateddigits ornewzerolist verification.',
 'Strict0<Im<14.134725; sourcecomputedfirstzero remains literature/databacked.'),
'RHupTo3e12':('PlattTrudgian2004.09765 abstract PDFp1 andTheorem1 PDFp2',
 'Allnontrivialzeroes with0<Imrho<=3e12 lie onRe1/2;Theorem1 giveslarger exactheight3000175332800.',
 'ActualIEANTNpredicate onlyexcludesRein(.5,1),henceis implied. Upperendpointclosed matches. Its inclusionofIm0 is suppliedbyexistingreal-axisnonvanishingZetaReal01; actualkernelproof-bearinguses havepositiveordinates. Alignedendpointtransfer,nothingmaterialcountedasfinding.',
 'Finiteheight3e12,realpart(.5,1); no unlimitedRH claim.'),
'QRH7/8':('OpenAI September30,2026 Theorem1.1 PDFp4; pinnedopenai/math7ef5c0cc',
 'Everyfinite-orderHeckeL overQ(sqrt(-3)) andeveryDirichletL includingzeta iszero-free inRe>7/8; principalpoleats1allowed.',
 'ActualZetaZeroFreeHalfPlane quantifiesallcomplexs with7/8<Res ands!=1. Openboundary/poleexception exactlymatch; no statementonRe7/8. Actual199pagePDFp4 viewed. No newindependent199pageproofaudit orcross-toolchaincompiledproof claim.',
 'Allcomplexs,openRes>7/8,pole1excluded; nofiniteRH substitution.'),
}
FIELDS=['file','decl_line','lean_name','kind','proposed_verification_status','actual_lean_declaration','actual_primary_source_statement_or_explicit_absence','original_locator','domain_and_hypotheses','lean_source_comparison','mathematical_check','full_scope_attribution_evidence','trust_boundary','notes']
rows=[]
for x in primary:
 label=x.get('interface_label')or x['lean_name'].split('.')[-1];loc,stmt,comparison,domain=REV[label]
 rows.append(dict(zip(FIELDS,[x['file'],x['decl_line'],x['lean_name'],'source_input_field'if'PrimaryInputs.'in x['lean_name']else'source_input_predicate','external_verified',x['written_formula'],stmt,loc,domain,comparison,'Exact sourceformula/domain/constants andactual objectdefinitions reviewed; see PRIMARY_REVIEW_NOTES andSUPPORT_OBJECTS. No mismatchfound in this interface.',
 'Inspected actual declaration,enclosingstructure/fullmodule,SourceContext attribution,actual instantiated45definitions,actual finalconsumer andnamedprimarypaper sections. No standaloneBlueprint labels supplied forscopedfields; exactsource modulesare correspondence; existingnetworkpredicates alsohave theirConclusions/formalization.yaml. The repositorycontainsnoBlueprint chapterfor these scopedfields.',
 'Independentliteratureanalytical/numerical input. Thisaudit compares mathematicalcontracts,notproofinternals orsourcefirstPV; existingkernel/sourceexecution verification separate.',
 'Actuald=.3681,delta=.3599,k1,alpha=.1202,H0=3e12. No newassumption orstatementchange. '+('UnderlyingKLNlemmas requirepositive delta; do notuse a displayedtop-leveldensitytheorem delta>=1 as the justification.'if label in['sourceRightMoment','sourceRectangle']else'No optimality/bestknown claim.') ])))
for x in support:
 n=x['lean_name'].split('.')[-1]
 choices=n in['height','alpha','Hstar','boundaryEta','boundaryMu','shifted','rightLine','scaledCriticalF','sourceFdiff']
 stmt='Actualsource-owned mathematicalobject in '+x['primary_correspondence']+'. Its displayeddefiningformula is thecorresponding KLNobject afterX=T,k1 andthe chosenparameters; eachscalar/algebraicterm isreviewed inPRIMARY_REVIEW_NOTES andthe parentinterface comparisons.'
 if choices:stmt='Project-selected parameter or exactspecialization ofthesourceobjects, not an attributednewtheorem. Chosenvalues lie in theexplicit sourcedomains recorded inPRIMARY_REVIEW_NOTES. '+x['primary_correspondence']
 rows.append(dict(zip(FIELDS,[x['file'],x['decl_line'],x['lean_name'],'support_definition','internal_verified'if choices else'external_verified',x['written_definition'],stmt,x['primary_correspondence'],
 'Onlyactualinstantiations in14interfaces: X=T>=3e12,k1,alpha.1202,d.3681,delta.3599,eta.2535,mu1.237,gammaEuler,sigma in[.75,.875],Hstar=3e12-1. Positivezetaarguments>1; allzero-countheights positiveandfinite.',
 'Displayeddefinition inspectedagainst named sourceequation/proof object. Definitions ofM,f,F,g,Mg,Gaussianweight,exactrightcoefficients,b5-b11,C7/C8 andzero-count/multiplicity conventions were expanded, not treatedasopaque functions. '+('Choice/specialization only; no external theorem isclaimed bythisdefinition.'if choices else'Equation/objectalignment found on actualdomain.'),
 'Full45definition census explicitlyfrozenwithfile/line/hash; comparetheactualwrittendefinition andparentinterfaceformula. No out-of-domain totalizationis counted as a materialfinding.',
 'Inspected definition,enclosingsection andfullsource-ownedmodule plusitsinstantiation inPrimaryInputs/actual finalconsumer; modulefamily attributionandpaper correspondence retained. No declaration-localcitation absence heuristic. No standaloneBlueprintlabel; actualmodule/source-objectequation is the correspondence.',
 'Definitionsintroduceno newmathematicalpremise; sourceclaims rely ontheexplicit literatureinput interfaces. GenericMathlibinfrastructure outside requesteduniverse.',
 'Thisrowis oneofthe45 supportingdefinitions, not an extraassumption ornewnumericalresult.' ])))
keys=[(str(x['file']),str(x['decl_line']),x['lean_name'])for x in rows]
if len(rows)!=59 or len(set(keys))!=59:raise ValueError('Exact59universe')
for name,fields,records in [('SCOPE59_V1.csv',['file','decl_line','lean_name'],rows),('REVIEW_DELTA_V1.csv',FIELDS,rows)]:
 p=B/name
 if p.exists():raise ValueError('Fresh isolatedworker delta')
 with p.open('w',newline='')as h:
  w=csv.DictWriter(h,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
print('wrote',len(rows),'rows; structural finalgate not yet run')
