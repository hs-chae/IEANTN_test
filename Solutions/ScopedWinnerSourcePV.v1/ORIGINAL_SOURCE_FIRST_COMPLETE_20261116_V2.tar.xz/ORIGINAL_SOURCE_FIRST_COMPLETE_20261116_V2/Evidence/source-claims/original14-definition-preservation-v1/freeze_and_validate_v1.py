"""Freeze exact source pairs and validate the source/data preservation scope.
No proof acceptance or external-source re-audit is inferred from this check.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,math,os,re
B=Path(__file__).resolve().parent;R=B.parents[1];W=R.parent

def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(p):
 def pairs(xs):
  d={}
  for k,v in xs:need(k not in d,'duplicateJSON '+k);d[k]=v
  return d
 def bad(x):raise ValueError('nonfiniteJSON '+x)
 def number(s):
  v=float(s);need(math.isfinite(v),'overflowJSON');return v
 return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=bad,parse_float=number)
def atomic(p,d):
 q=p.with_suffix('.pending');q.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');os.replace(q,p)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--freeze',action='store_true');ap.add_argument('--check-live',action='store_true');ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();out=a.out.resolve();need(not out.exists()and out.is_relative_to(B),'fresh owned receipt')
 spec=importlib.util.spec_from_file_location('extract',B/'extract_source_v2.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 d=strict(B/'EXTRACTION_V2.json');need(d['requested_interfaces']==14 and d['primary_groups']==7 and d['seed_support_objects']==45,'exact requested universe')
 need(len(d['modules'])==17 and d['total_written_data_definitions']==77 and len(d['compiler_data_closure'])==48,'exact derived scope')
 need(not d['unmatched']and not d['scope_mismatches'],'no unresolved formula/scope mismatch')
 need(not[x for x in d['compiler_proof_boundaries']if x['kind']=='nonwritten_generated_or_unresolved'],'no unresolved generated data dependency')
 inventory=[];defs=0
 for row in d['modules']:
  rel=Path(row['module'].replace('.','/')).with_suffix('.lean');old=B/'evidence/original'/rel;cur=B/'evidence/current'/rel
  for dst,source,key in [(old,W/row['original_source'],'original_sha256'),(cur,R/row['current_source'],'current_sha256')]:
   if a.freeze:
    need(not dst.exists(),'fresh exact frozen source');need(sha(source)==row[key],'live source beforefreeze');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(source.read_bytes())
   need(dst.is_file()and sha(dst)==row[key],'frozen source identity')
   if a.check_live:need(source.is_file()and sha(source)==row[key],'current actual source identity')
  olddata=[x for x in mod.declarations(old)if x['kind']not in{'theorem','lemma'}];curdata=[x for x in mod.declarations(cur)if x['kind']not in{'theorem','lemma'}]
  om={x['short']:x for x in olddata};cm={x['short']:x for x in curdata};need(len(om)==len(olddata)and len(cm)==len(curdata)and om.keys()==cm.keys(),'full written data population')
  expected={x['name']:x for x in row['all_written_data_definitions']};need(expected.keys()==om.keys(),'exact extracted declaration population')
  for name in om:
   need(om[name]['tokens']==cm[name]['tokens']and expected[name]['tokens_equal'],'complete definition body equality '+name);defs+=1
  def scopes(p):return[mod.tokens(x)for x in mod.no_comments(p.read_text()).splitlines()if re.match(r'^\s*(namespace|end|open|variable|universe|local\s+(notation|infix|prefix)|notation|infix|prefix|postfix)\b',x)]
  need(scopes(old)==scopes(cur),'exact lexical scopes')
  def imports(p):return[x.strip()for x in mod.no_comments(p.read_text()).splitlines()if x.startswith('import ')]
  need(imports(old)==imports(cur)==row['imports_original']==row['imports_current'],'unchanged actual imports')
  inventory.append(dict(module=row['module'],original=str(old.relative_to(B)),current=str(cur.relative_to(B)),original_sha256=sha(old),current_sha256=sha(cur),declarations=len(om)))
 need(defs==77,'complete77 bodies')
 # Parser canaries: altered numeric values/operators/names must never collapse.
 for x,y in [('def a:=3681/10000','def a:=3682/10000'),('def a:=x<=y','def a:=x< =y'),('def a:=foo bar','def a:=foobar'),('def a:="-- /-"','def a:="other"')]:need(mod.tokens(x)!=mod.tokens(y),'changed-value/name/operator rejection')
 need(mod.tokens('def a := x‖≤y')==mod.tokens('def a:=x‖ ≤ y'),'norm delimiter spacing')
 need(mod.tokens('def a := x /- nested /- block -/ comment -/')==mod.tokens('def a:=x'),'nestedcomments preserve tokens')
 receipt=dict(status='PASS_ORIGINAL_SEVEN_GROUP_FOURTEEN_INPUT_COMPLETE_WRITTEN_DATA_PRESERVATION',interfaces=14,primary_groups=7,explicit_audited_support=45,recursive_compiler_data_or_projection_dependencies=48,source_modules=17,complete_written_data_definitions=77,all_body_tokens_equal=True,all_lexical_scopes_and_imports_equal=True,source_snapshots=inventory,extraction_sha256=sha(B/'EXTRACTION_V2.json'),extractor_sha256=sha(B/'extract_source_v2.py'),validator_sha256=sha(Path(__file__)),parser_changedvalue_name_operator_rejection_controls=True,optimization=os.environ.get('PYTHONOPTIMIZE','0'),check_live=a.check_live,compiler_Expr_value_recomparison=False,source_first_PV=False,new_proof_acceptance=False,qualification='Actual full definition/abbreviation/structure source bodies, source imports and namespace/open/variable/notation scopes match the frozen original after comment and lexical-spacing normalization. This checks mathematical data, not only theorem types or declaration names. Existing compiled exact42-type preservation is separate supporting evidence. Application-only compiler inventory supplies48 transitive data/projection records; thirteen core seed names absent from that filtered inventory are explicitly covered in whole core source modules. All ordinary Mathlib implementation internals remain outside this declared input-data scope. Theorem proof bodies are intentionally excluded; no new numerical/formal/source-first-PV acceptance follows from source-token equality.')
 atomic(out,receipt);print(receipt['status'],defs,len(inventory))
if __name__=='__main__':main()
