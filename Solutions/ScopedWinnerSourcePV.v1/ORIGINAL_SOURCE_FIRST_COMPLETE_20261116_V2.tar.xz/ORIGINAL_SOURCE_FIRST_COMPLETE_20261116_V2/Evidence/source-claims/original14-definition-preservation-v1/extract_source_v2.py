"""Conservative source-command equality for the unchanged analytic contracts.

This is a source/token audit, not compiler reflection or new proof acceptance.
Complete definition bodies and surrounding lexical scope are retained; theorem
proof bodies are irrelevant to the input-value comparison.
"""
from pathlib import Path
import hashlib,json,re,unicodedata
R=Path(__file__).resolve().parents[2]
W=R.parent
OLD=W/'qrh-scoped-winner-20261104/network'
B=Path(__file__).resolve().parent

def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def no_comments(s):
 out=[];i=0;depth=0;string=False
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;out.extend('  ');i+=2
   elif s.startswith('-/',i):depth-=1;out.extend('  ');i+=2
   else:out.append('\n'if s[i]=='\n'else' ');i+=1
  elif string:
   out.append(s[i])
   if s[i]=='\\'and i+1<len(s):out.append(s[i+1]);i+=2
   elif s[i]=='"':string=False;i+=1
   else:i+=1
  elif s.startswith('/-',i):depth=1;out.extend('  ');i+=2
  elif s.startswith('--',i):
   j=s.find('\n',i);j=len(s)if j<0 else j;out.extend(' '*(j-i));i=j
  else:
   if s[i]=='"':string=True
   out.append(s[i]);i+=1
 need(not depth and not string,'unterminated source comment/string')
 return ''.join(out)
def tokens(s):
 s=no_comments(s);out=[];i=0
 def ident(c):return c=='_'or c=="'"or unicodedata.category(c)[0]in'LMN'
 delimiters='(){}[],:;.'
 while i<len(s):
  c=s[i]
  if c.isspace():i+=1;continue
  j=i+1
  if c=='"':
   while j<len(s):
    if s[j]=='\\':j+=2;continue
    if s[j]=='"':j+=1;break
    j+=1
  elif c=='«':
   j=s.find('»',j);need(j>=0,'escaped identifier');j+=1
  elif ident(c):
   while j<len(s)and ident(s[j]):j+=1
  elif c==':'and s.startswith(':=',i):j=i+2
  elif c in delimiters or ord(c)>=128:pass
  else:
   while j<len(s)and not s[j].isspace()and not ident(s[j])and s[j]not in delimiters+'"«'and ord(s[j])<128:j+=1
  out.append(s[i:j]);i=j
 return out
COMMAND=re.compile(r'(?m)^[ \t]*(?:(?:noncomputable|private|protected|unsafe|partial)\s+)*(def|abbrev|structure|inductive|theorem|lemma|axiom|opaque|instance)\s+([^\s(:{]+)')
BOUNDARY=re.compile(r'(?m)^[ \t]*(?:import|namespace|end|open|variable|universe|set_option|attribute|local\s+(?:notation|instance|infix|macro)|notation|infix|prefix|postfix|syntax|macro|elab|#\w+)\b')
def declarations(p):
 raw=p.read_text();s=no_comments(raw);matches=list(COMMAND.finditer(s));boundaries=list(BOUNDARY.finditer(s));rows=[]
 for i,m in enumerate(matches):
  stop=matches[i+1].start()if i+1<len(matches)else len(s)
  candidates=[b.start()for b in boundaries if m.end()<b.start()<stop]
  if candidates:stop=min(candidates)
  fragment=raw[m.start():stop].strip();rows.append(dict(kind=m.group(1),short=m.group(2),line=raw.count('\n',0,m.start())+1,text=fragment,tokens=tokens(fragment)))
 return rows

def main():
 compiled=json.loads((R/'scoped/audit/compiler-original-v1.json').read_text());by={x['name']:x for x in compiled['declarations']}
 primary=json.loads((R/'audit/primary14-source-audit-v1/PRIMARY14_IDENTITIES_V1.json').read_text())['rows']
 support=json.loads((R/'audit/primary14-source-audit-v1/SUPPORT_OBJECTS_V1.json').read_text())['rows']
 # The explicit59 audited interfaces/support objects are a seed, never a closure claim.
 seeds={x['lean_name']for x in primary+support};queue=sorted(seeds);visited=set();closure={};proof_boundaries=[]
 overlay=json.loads((R/'scoped/kernel-overlay51-v3/PLAN.json').read_text())
 over={x['module']:R/'scoped/kernel-overlay51-v3'/x['path']for x in overlay['modules']}
 module_sources={};source_rows={}
 def source(module):
  if module not in module_sources:
   rel=Path(module.replace('.','/')).with_suffix('.lean')
   old=([OLD/rel]if(OLD/rel).is_file()else list((OLD/'Solutions').glob('*/'+str(rel))))
   need(len(old)==1,'unique frozen original source '+module+' '+str(old))
   current=over.get(module,R/'scoped/numerical/kernel-plane-capsule-v6/source'/rel)
   need(current.is_file(),'actual current source '+str(current))
   module_sources[module]=(old[0],current);source_rows[module]=declarations(old[0])
  return module_sources[module]
 while queue:
  name=queue.pop()
  if name in visited:continue
  visited.add(name);record=by.get(name)
  if not record:continue
  module=record['module'];source(module);short=name.rsplit('.',1)[-1]
  candidates=[x for x in source_rows[module]if x['short']==short]
  if len(candidates)==1:
   row=candidates[0]
   if row['kind']in{'theorem','lemma'}:
    proof_boundaries.append(dict(name=name,module=module,kind=row['kind']));continue
   closure[name]=dict(module=module,kind=row['kind'],source_line=row['line'])
  elif name.startswith('WinnerNewHeightSource.PrimaryInputs.'):
   closure[name]=dict(module=module,kind='structure_generated_projection',source_line=11)
  elif '._proof_'in name or '._aux_'in name:
   proof_boundaries.append(dict(name=name,module=module,kind='compiler_generated_proof_or_auxiliary'));continue
  else:
   proof_boundaries.append(dict(name=name,module=module,kind='nonwritten_generated_or_unresolved',matches=len(candidates)));continue
  queue+=record['body_constants']+record['type_constants']
 # Include source-level contracts not present in the compiler's application-only census.
 module_names=set(x['module']for x in closure.values())
 for row in primary+support:
  if row['lean_name']in by:module_names.add(by[row['lean_name']]['module'])
  elif row['file'].startswith('network/'):
   module_names.add(row['file'][len('network/'):-len('.lean')].replace('/','.'))
 # The QRH/finite-RH source wrappers are actual nonnumerical mathematical data too.
 module_names|={'IEANTN.Nodes.OpenAIQRH.v1.Conclusions','IEANTN.Nodes.PlattZeroSum.v1.Conclusions'}
 results=[];unmatched=[];all_definitions=0
 for module in sorted(module_names):
  old,cur=source(module);os=declarations(old);cs=declarations(cur)
  old_data=[x for x in os if x['kind']not in{'theorem','lemma'}]
  current_data=[x for x in cs if x['kind']not in{'theorem','lemma'}]
  om={x['short']:x for x in old_data};cm={x['short']:x for x in current_data}
  need(len(om)==len(old_data)and len(cm)==len(current_data),'unique written declaration names within module '+module)
  defs=[]
  for name in sorted(set(om)|set(cm)):
   a=om.get(name);b=cm.get(name);ok=a is not None and b is not None and a['tokens']==b['tokens']
   rec=dict(name=name,old_line=a['line']if a else None,current_line=b['line']if b else None,kind=a['kind']if a else b['kind'],tokens_equal=ok,original=a['text']if a else None,current=b['text']if b else None)
   defs.append(rec);all_definitions+=1
   if not ok:unmatched.append(dict(module=module,**rec))
  # Preserve lexical environment commands, excluding imports/options, separately.
  def scopes(p):
   s=no_comments(p.read_text());return[tokens(x)for x in s.splitlines()if re.match(r'^\s*(namespace|end|open|variable|universe|local\s+(notation|infix|prefix)|notation|infix|prefix|postfix)\b',x)]
  scope_equal=scopes(old)==scopes(cur)
  imports_original=[x.strip()for x in no_comments(old.read_text()).splitlines()if x.startswith('import ')]
  imports_current=[x.strip()for x in no_comments(cur.read_text()).splitlines()if x.startswith('import ')]
  results.append(dict(module=module,original_source=str(old.relative_to(W)),current_source=str(cur.relative_to(R)),original_sha256=sha(old),current_sha256=sha(cur),lexical_scope_equal=scope_equal,imports_original=imports_original,imports_current=imports_current,imports_equal=imports_original==imports_current,all_written_data_definitions=defs))
 data=dict(status='SOURCE_EXTRACTION_PENDING_REVIEW_NOT_ACCEPTANCE',requested_interfaces=14,primary_groups=7,seed_support_objects=len(support),compiler_data_closure=closure,compiler_proof_boundaries=proof_boundaries,compiler_unrecorded_seed_names=sorted(seeds-set(by)),modules=results,total_written_data_definitions=all_definitions,unmatched=unmatched,scope_mismatches=[x['module']for x in results if not x['lexical_scope_equal']],compiler_inventory_sha256=sha(R/'scoped/audit/compiler-original-v1.json'),overlay_plan_sha256=sha(R/'scoped/kernel-overlay51-v3/PLAN.json'),qualification='Exact written source and token comparisons of full bodies, not name/type equality; proof-only theorem bodies excluded. Unrecorded core definitions are covered by entire explicit source modules, not silently omitted. Compiler data closure still needs generated-declaration boundary review and final receipt gate.')
 (B/'EXTRACTION_V2.json').write_text(json.dumps(data,indent=2)+'\n')
 print('modules',len(results),'definitions',all_definitions,'closure',len(closure),'unmatched',len(unmatched),'scope',data['scope_mismatches'])
 for x in unmatched:print(x['module'],x['name'])
 print('generatedpending',[x['name']for x in proof_boundaries if x['kind']=='nonwritten_generated_or_unresolved'])
if __name__=='__main__':main()
