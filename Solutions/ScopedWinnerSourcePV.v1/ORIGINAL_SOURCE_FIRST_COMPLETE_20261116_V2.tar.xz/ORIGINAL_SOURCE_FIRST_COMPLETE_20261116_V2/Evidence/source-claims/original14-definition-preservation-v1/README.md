# Original analytic inputs: complete source definition preservation

The requested seven groups contain fourteen actual mathematical interfaces:
the eight-field primary source package, original CHJ explicit formula, two
Riemann–von Mangoldt bounds, first-zero exclusion, finite RH, and QRH. This audit
compares their actual source-owned mathematical data with the preserved original
Scoped Winner checkout, beyond names or theorem types.

`FINAL_RECEIPT_V1.json` records the final gate. Every complete definition,
abbreviation and structure body in the seventeen relevant modules matches its
original lexical tokens. All imports and namespace/open/variable/notation scopes
also match. The check includes seventy-seven complete written data declarations,
the forty-eight recursive compiler-recorded data/projection dependencies, and
the complete written owners of forty-eight generated numeral proof terms.
Twelve core seed names omitted by the compiler's filtered application inventory
are explicitly covered by their entire core source modules.

`EXACT59_IDENTITY_AND_SPECIALIZATION_MAP_V1.json` binds each of the fourteen
interfaces and forty-five previously primary-source-audited support definitions
to exact original and current file, declaration, line and source hash. It records
the existing exact forty-two-consumer type comparison separately; that comparison
preserves the actual parameter specializations. The forty-three-file core byte
comparison is cited only as a separate subset check.

The full original/current source pairs are preserved under `evidence/`. They
include complete definition bodies, so this is stronger than comparing names,
constant dependency lists, signatures, or conclusion counts. The separately
completed primary-source audit is in `../primary14-source-audit-v1/`; its offline
HTML renders the actual mathematical formulas and paper comparisons.

## Reproduce

The original audit reads the preserved baseline checkout and current source
files, pins both, and freezes the exact seventeen source pairs. The accepted
extractor is `extract_source_v2.py`. Its V1 output conservatively flagged three
adjacent delimiter/inequality spacing cases; V2 correctly splits the norm and
absolute-value delimiters from the Unicode relation symbol. All three formulas
were unchanged. The exact earlier draft is retained.

Revalidate the frozen source pairs without a private compiled object bank:

```sh
python3 audit/original14-definition-preservation-v1/freeze_and_validate_v3.py \
  --out audit/original14-definition-preservation-v1/my-replay.json
```

Add `--check-live` to require every actual source file to still have its pinned
hash. Use a fresh output filename. Normal Python, `-O`, and `-OO` all passed the
real CLI with explicit checks, including changed-number/name/operator rejection
controls. The receipts record the actual interpreter optimization mode. No seed
or generated numerical dataset is involved.

The final source gate does not claim a new compiler Expr-value equality proof,
new numerical proof, formal reproof of the primary papers, all-Mathlib audit, or
complete source-first PV. Ordinary Mathlib implementation internals are outside
the declared input-data scope. Theorem proof bodies are intentionally excluded;
the mathematical values and contracts they prove are compared in full.
