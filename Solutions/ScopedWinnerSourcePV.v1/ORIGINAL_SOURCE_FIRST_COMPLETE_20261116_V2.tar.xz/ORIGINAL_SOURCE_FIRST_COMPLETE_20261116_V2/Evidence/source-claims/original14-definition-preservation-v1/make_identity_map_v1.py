from pathlib import Path
import json,hashlib,re,subprocess
B=Path(__file__).resolve().parent;R=B.parents[1];W=R.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,m):
 if not v:raise ValueError(m)
def main():
 d=json.loads((B/'EXTRACTION_V2.json').read_text());mods={r['module']:r for r in d['modules']};comp=json.loads((R/'scoped/audit/compiler-original-v1.json').read_text());by={r['name']:r for r in comp['declarations']};primary=json.loads((R/'audit/primary14-source-audit-v1/PRIMARY14_IDENTITIES_V1.json').read_text())['rows'];support=json.loads((R/'audit/primary14-source-audit-v1/SUPPORT_OBJECTS_V1.json').read_text())['rows'];rows=[]
 for role,pop in [('primary',primary),('support',support)]:
  for x in pop:
   n=x['lean_name'];module=by[n]['module']if n in by else x['file'][8:-5].replace('/','.')
   m=mods[module];parent='PrimaryInputs'if '.PrimaryInputs.'in n else n.rsplit('.',1)[-1];entry=next(t for t in m['all_written_data_definitions']if t['name']==parent)
   field=n.rsplit('.',1)[-1]if '.PrimaryInputs.'in n else None
   orig=(W/m['original_source']).read_text().splitlines();cur=(R/m['current_source']).read_text().splitlines()
   def line(lines,key,fallback):
    if key is None:return fallback
    found=[i+1 for i,l in enumerate(lines)if re.match(r'^\s*'+re.escape(key)+r'\s*:(?!=)',l)]
    need(len(found)==1,'unique field identity '+n)
    return found[0]
   rows.append(dict(role=role,name=n,module=module,original_identity=dict(file=m['original_source'],line=line(orig,field,entry['old_line']),source_sha256=m['original_sha256']),current_identity=dict(file=m['current_source'],line=line(cur,field,entry['current_line']),source_sha256=m['current_sha256']),compared_written_owner=parent,complete_owner_body_tokens_equal=entry['tokens_equal'],namespace_scope_and_imports_equal=m['lexical_scope_equal']and m['imports_equal'],verdict='UNCHANGED_COMPLETE_SOURCE_MATHEMATICAL_DATA'))
 need(len(rows)==59 and len({(r['current_identity']['file'],r['current_identity']['line'],r['name'])for r in rows})==59,'exact59written identities')
 params=json.loads((R/'audit/primary14-source-audit-v1/SUPPORT_OBJECTS_V1.json').read_text())['actual_parameters']
 manifest=dict(status='ALL14_PRIMARY_AND45_SUPPORT_WRITTEN_SOURCE_IDENTITIES_BOUND',primary_groups=7,primary_count=14,support_count=45,rows=rows,actual_specializations=params,existing42_type_preservation_receipt='scoped/numerical/FULL51_UNCHANGED_CONSUMER_ACCEPTANCE_V1.json',existing42_type_preservation_receipt_sha256=sha(R/'scoped/numerical/FULL51_UNCHANGED_CONSUMER_ACCEPTANCE_V1.json'),core43_subset_gate='research/core-integration-v1/CORE_FROZEN_SOURCE_OVERLAP_V1.json',core43_subset_gate_sha256=sha(R/'research/core-integration-v1/CORE_FROZEN_SOURCE_OVERLAP_V1.json'),original_checkout_commit=subprocess.run(['git','-C',str(W/'qrh-scoped-winner-20261104/network'),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),qualification='The existing42 exact elaborated type checks preserve these actual parameters at consumer interfaces; this fresh source gate independently compares full source-owned definition values and contracts. No merely name/type-based claim. Core43 byte gate is only a named subset cross-check.')
 p=B/'EXACT59_IDENTITY_AND_SPECIALIZATION_MAP_V1.json';p.write_text(json.dumps(manifest,indent=2)+'\n');print(p.name,sha(p))
if __name__=='__main__':main()
