"""Regenerate all numerical bytes, check Lean proposal identities, rebuild proofs.
This pipeline is kernel-only mathematical verification, explicitly not C PV.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
B=Path(__file__).resolve().parent

def need(ok,message):
 if not ok:raise RuntimeError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--environment',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--jobs',type=int,default=2);a=ap.parse_args();out=a.out.resolve();need(not out.exists()and B not in out.parents,'fresh external output required');out.mkdir(parents=True);e=json.loads(a.environment.read_text());cc=Path(e['compiler']).with_name('clang');numeric=B/'numerics';raw=numeric/'regeneration'/('run-'+hashlib.sha256(str(out).encode()).hexdigest()[:20]);steps=[];start=time.monotonic()
 def run(command,name):
  t=time.monotonic()
  with(out/(name+'.stdout')).open('wb')as so,(out/(name+'.stderr')).open('wb')as se:q=subprocess.run(command,stdout=so,stderr=se)
  need(q.returncode==0,name+' failed');steps.append({'name':name,'command':command,'seconds':time.monotonic()-t})
 run([sys.executable,str(numeric/'reproduce_height_numerics_v1.py'),'--compiler',str(cc),'--out',str(raw)],'numerics')
 run([sys.executable,str(numeric/'verify_regenerated_height_words_v1.py'),'--source-root',str(B/'source'),'--raw-root',str(raw),'--out',str(out/'NUMERICAL_WORD_ASSOCIATION.json')],'word-association')
 run([sys.executable,str(B/'reproduce.py'),'--environment',str(a.environment.resolve()),'--out',str(out/'math'),'--jobs',str(a.jobs)],'mathematical-proofs')
 m=json.loads((out/'math/RECEIPT.json').read_text());need(m['status']=='PASS_KERNEL_ONLY_HEIGHT_PNT_SOURCE_COLD','mathematical replay receipt')
 receipt={'status':'FULL_KERNEL_VALIDITY_AND_NUMERICAL_REGENERATION_PASS','seconds':time.monotonic()-start,'steps':steps,'mathematical_receipt_sha256':sha(out/'math/RECEIPT.json'),'numerical_receipt':str(raw/'RECEIPT.json'),'numerical_receipt_sha256':sha(raw/'RECEIPT.json'),'word_association_sha256':sha(out/'NUMERICAL_WORD_ASSOCIATION.json'),'source_lock_sha256':sha(B/'SOURCE_LOCK.json'),'selected_mathematical_axioms':'propext,Classical.choice,Quot.sound only','source_first_PV':False,'qualification':'Fresh application-source rebuild with pinned public generic libraries, plus deterministic executable numerical regeneration. C source-to-model/application-execution proofs remain separate obligations; no compiler/hardware output is promoted into mathematical truth by this receipt.'};(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'seconds':receipt['seconds']}))
if __name__=='__main__':main()
