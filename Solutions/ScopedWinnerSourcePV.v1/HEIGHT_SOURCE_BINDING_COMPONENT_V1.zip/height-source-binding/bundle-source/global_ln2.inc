static I ln2;
