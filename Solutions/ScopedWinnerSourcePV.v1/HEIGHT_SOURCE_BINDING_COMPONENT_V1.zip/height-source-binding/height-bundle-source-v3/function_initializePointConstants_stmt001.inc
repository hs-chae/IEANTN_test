initializeConstants();
