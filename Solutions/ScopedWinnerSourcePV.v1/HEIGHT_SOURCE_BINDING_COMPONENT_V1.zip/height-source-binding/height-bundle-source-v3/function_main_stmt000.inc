initializePointConstants();
