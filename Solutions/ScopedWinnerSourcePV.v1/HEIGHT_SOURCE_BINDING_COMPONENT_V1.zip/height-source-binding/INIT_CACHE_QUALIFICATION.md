# Actual initializer poststate proposal — verification still pending

`SynergyHeightC.InitCacheProposal.postState(arena)` contains all fourteen
objects after the unchanged actual C initializer: both unsigned constants,
eleven interval globals and the 58-entry interval array. It keeps the actual
returned Nat arena as a parameter. It is **untrusted proof data** until the
source-execution/state-equality theorem validates the entire poststate.

The C wrapper renames only the original `main`, includes the actual 524-file
source tree, calls `initializePointConstants`, and emits every global integer
word. It changes no original application body or input. The 140 words occupy
8,960 bytes; exact object types, cell counts, array flags, writable flags,
global names and addresses appear in
`height-init-c-untrusted-proposal-v2/MAPPING.json` and `PROPOSAL.json`.
The metadata is a proposed mapping from the actual declarations and model
initializer, not an assumed initial application representation.

The executable dump reproduced byte-identically with Python normal, `-O`
and `-OO`; see `height-init-proposal-three-modes-v1/RECEIPT.json`. The original
524 source hashes, compiler hash, actual commands, wrapper/binary/raw/proposal
hashes and runtime assumptions are retained. Four newly generated dump
binaries were deleted only after their exact identities and all three replay
results passed; source, small raw data and receipts remain.

From the repository root, regenerate in a fresh experiment-owned directory:

```sh
python research/analytic/generate_height_init_c_proposal_v1.py \
  --out research/analytic/height-init-c-proposal-fresh
```

The source first needs the already documented pinned C environment and actual
source-binding tree. This command generates a candidate; it does not verify
that candidate or reproduce a source-first PV theorem.

The separate accepted data-identity module is
`SynergyHeightC.InitCacheModelIdentity`. Its data identities are native-free: `proposed_constant_array` uses only
`propext`, and the other two have no axioms:

- `proposed_constant_array`: candidate object 13 contains exactly the existing
  58 `HeightPoint.constantValues` boxes in their source representation.
- `proposed_heap_population`: the candidate has fourteen objects.
- `proposed_constant_address`: `constantNodes` resolves to object 13.

These are literal data identities. They become useful after actual source
execution proves that this candidate is the returned state; they do not
independently establish execution or numerical correctness.

The first native `#eval` of the actual source AST returned `none`. This was
traced to an exact unsupported model path: the frozen square-root function
initializes the two-element local array `U n[2]={...}`, while the current
`ScopedC.Machine.declarations` rejects every initialized array. It is neither
an out-of-memory event nor a mathematical counterexample. The failed export
and precise diagnosis remain in `height-init-untrusted-proposal-v3`; source
semantics support and a fresh kernel source checker are required. Increasing
fuel or trusting this C dump would not discharge that obligation.

Root owns the actual initializer, bounded state-word equality checker and
source-sound cached-state wrapper. Point calls must then consume the proved
poststate and preserve correct caller allocation/readback, output stream and
source-output-to-ANT correspondence. Complete source-first PV remains open.
