#define main archived_height_main
#include "/ryu/hyunsik/playground/independence/codex/ivy/ieantn-qrh-pv-synergy-20261114/research/analytic/height-bundle-source-v3/height_bundle.cpp"
#undef main
int main(){initializePointConstants();
emitU(S);
emitU(MAXU);
emitI(ln2);
emitI(piBox);
emitI(m0Box);
emitI(gaussianBox);
emitI(peakBox);
emitI(sqrtPi);
emitI(sqrt2Alpha);
emitI(alphaBox);
emitI(dBox);
emitI(deltaBox);
emitI(smoothingBox);
unsigned proposalIndex=0;while(proposalIndex<58){emitI(constantNodes[proposalIndex]);proposalIndex=proposalIndex+1;}
if(fflush(stdout)!=0)fail();return 0;}
