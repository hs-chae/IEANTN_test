import SynergyHeightC.Bundle
open Lean
#eval IO.println ("HEIGHT_FILES_JSON " ++ (toJson (SynergyHeightC.Bundle.actualFiles.map (fun f=>Json.mkObj [("name",toJson f.name),("text",toJson f.text)]))).compress)
