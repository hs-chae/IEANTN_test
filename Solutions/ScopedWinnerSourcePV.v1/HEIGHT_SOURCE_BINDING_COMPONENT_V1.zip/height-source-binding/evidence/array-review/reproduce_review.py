"""Finite source/hash gates accompanying a bounded independent code review.
The script does not replace a Lean build or prove C++ semantics by string tests.
"""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent

def need(ok,message):
    if not ok:
        raise RuntimeError(message)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    lock=json.loads((R/'scoped/positive11-init-execute-cold-v1/capsule-v1/SOURCE_LOCK.json').read_text())
    old={row['module']:row for row in lock['sources']}
    sources=[]
    for name in ['Machine','SourceCalls']:
        p=R/('scoped/frontend/lean/ScopedC/'+name+'.lean')
        need(sha(p)==old['ScopedC.'+name]['sha256'],'historical semantics changed')
        sources.append({'path':str(p.relative_to(R)),'sha256':sha(p),'unchanged_historical':True})
    for name in ['ArrayDeclarations','ArraySourceCalls','ArraySourceExecute','ArraySourceCallExecute','StateWordEquality']:
        p=R/('scoped/frontend/lean/ScopedC/'+name+'.lean')
        sources.append({'path':str(p.relative_to(R)),'sha256':sha(p)})
    ast=R/'research/analytic/height-frontend-v1/STRUCTURED_AST.json'
    data=json.loads(ast.read_text())
    initialized=[]
    def walk(node,owner):
        if isinstance(node,list):
            if len(node)==2 and node[0]=='declare':
                for declaration in node[1]:
                    if declaration['arrayExtent'] is not None and declaration['value'] is not None:
                        initialized.append({'function':owner,'declaration':declaration})
            for child in node:
                walk(child,owner)
    for function in data['functions']:
        walk(function['body'],function['name'])
    need(len(initialized)==2,'full39-function initialized-array population changed')
    functions={f['name']:f for f in data['functions']}
    def calls(node):
        result=set()
        if isinstance(node,list):
            if len(node)==3 and node[0]=='call' and isinstance(node[1],list) and node[1][0]=='var':
                result.add(node[1][1])
            for child in node:
                result.update(calls(child))
        elif isinstance(node,dict):
            for child in node.values():
                result.update(calls(child))
        return result
    pending=['main'];reachable=set()
    while pending:
        name=pending.pop()
        if name in reachable or name not in functions:
            continue
        reachable.add(name)
        pending.extend(calls(functions[name]['body']))
    selected=[row for row in initialized if row['function'] in reachable]
    excluded=[row for row in initialized if row['function'] not in reachable]
    need(len(selected)==1 and len(excluded)==1,'height actual-call closure array population')
    need(excluded[0]['function']=='archived_basis_main' and excluded[0]['declaration']['type']=='I' and excluded[0]['declaration']['arrayExtent']==3,'archived array changed')
    actual=selected[0]
    d=actual['declaration']
    need(actual['function']=='sqrtInterval' and d['name']=='n' and d['type']=='U' and d['arrayExtent']==2,'wrong selected source array')
    need(d['value'][0]=='record' and len(d['value'][1])==2,'initializer shape')
    need(all(e[0]=='call' and e[1]==['var','mulU'] for e in d['value'][1]),'initializer element type/callee')
    need(next(f for f in data['functions'] if f['name']=='mulU')['returnType']=='static U','source element/target type differs')
    audit=R/'research/analytic/work/height-main-prefix-defs-v1'
    receipt=json.loads((audit/'RECEIPT.json').read_text())
    need(receipt['exit_code']==0 and receipt['source_unchanged'],'audit Lean build failed')
    output=(audit/'stdout.txt').read_text()
    roots=['ScopedC.ArrayDeclarations.one_legacy','ScopedC.ArrayDeclarations.all_legacy','ScopedC.ArraySourceExecute.statement_sound','ScopedC.ArraySourceCallExecute.execute_sound','SynergyHeightC.MainPrefix.source_of_checked']
    for root in roots:
        match=re.search("'"+re.escape(root)+r"' depends on axioms: \[([^]]*)\]",output)
        need(match is not None,'missing complete root audit')
        need({v.strip() for v in match[1].split(',')}<={'propext','Classical.choice','Quot.sound'},'unaccepted axiom')
    readback=R/'research/analytic/work/height-init-cache-readback-v2'
    need(json.loads((readback/'RECEIPT.json').read_text())['exit_code']==0,'readback compile receipt')
    text=(readback/'stdout.txt').read_text()
    for root in ['maxContext','scaleContext','constant_read','actual_constant_read']:
        need("'SynergyHeightC.InitCacheReadback."+root+"' depends on axioms: [propext, Classical.choice, Quot.sound]" in text,'readback full audit')
    result={'status':'BOUNDED_ARRAY_EXTENSION_AND_CACHE_READBACK_REVIEW_NO_SCOPED_DEFECT_FOUND','scope':'All39 written height-source functions inventoried; actual main call closure has one fully initialized local U[2], additive array execution semantics and conditional cached-state readback. Not universal C++ verification, a new full-source replay or complete source-first application PV.','sources':sources,'structured_ast_sha256':sha(ast),'all39_written_initialized_arrays':initialized,'executing_height_initialized_arrays':selected,'unreachable_archived_initialized_arrays':excluded,'main_reachable_functions':sorted(reachable),'complete_kernel_audit_roots':roots,'kernel_audit_receipt_sha256':sha(audit/'RECEIPT.json'),'readback_receipt_sha256':sha(readback/'RECEIPT.json'),'primary_locators':[{'url':'https://timsong-cpp.github.io/cppwp/n4659/basic.scope.pdecl#1','claim':'N4659 C++17 point of declaration precedes the initializer.'},{'url':'https://timsong-cpp.github.io/cppwp/n4659/dcl.init.aggr#2','claim':'Array aggregate elements follow increasing subscript order; paragraph3 matches clauses to elements.'},{'url':'https://timsong-cpp.github.io/cppwp/n4659/dcl.init.list#4','claim':'N4659 C++17 list clauses and their side effects are sequenced in source order.'}],'review_conclusions':['Array storage/name are introduced before evaluating the first initializer expression.','Each source initializer is evaluated, converted by the existing typed write rule and stored before the next expression.','The actual height main call closure has two U-returning mulU calls initializing exactly two U elements, so no narrowing conversion is needed. This model is not presented as a C++ typechecker; unused generic narrowing cases are outside this scoped applicability claim.','Empty/incomplete/noninteger/unsupported initializer forms fail closed; zero extent is rejected. The written but main-unreachable archived_basis_main has an initialized I[3], currently unsupported; it is explicitly inventoried and is not an accepted executing path.','Legacy Machine/SourceCalls are byte-identical to the previously accepted cold source; legacy array/scalar branches are proved equal.','Actual helper callees must execute at lower source-call rank; the extension introduces no application output oracle.','State-word equality compares all14 heap objects and both environments; the actual Nat arena is retained, never guessed equal.','Conditional cache readback and Max/Scale contexts identify the proposed58 model boxes; they do not prove initialization or authorize using an unverified application state.'],'remaining_obligations':['Kernel actual initializePointConstants execution and complete14-object state check','Actual main-prefix/point/caller allocation/readback/output sequencing and final source-output-to-ANT join'],'source_first_PV':False}
    (HERE/'REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'])

if __name__=='__main__':
    main()
