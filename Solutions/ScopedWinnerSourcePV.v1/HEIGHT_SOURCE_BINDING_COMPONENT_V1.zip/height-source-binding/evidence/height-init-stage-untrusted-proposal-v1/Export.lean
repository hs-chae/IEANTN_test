import Lean
import ScopedC.ArraySourceCallExecute
import ScopedC.StateWordEquality
/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import SynergyHeightC.Definitions
import SynergyC.Initialization
import SynergyC.UnitBody

set_option exponentiation.threshold 1024
namespace SynergyHeightC.Initialization
open ScopedC ScopedC.Machine
open SynergyC.Word512 SynergyC.WordFrames
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Static storage is initialized from the actual source declarations. The
array branch implements static zero initialization; no computed constants or
initial application representation are accepted as a platform assumption. -/
def initializeOne (st : State) (d : Syntax.Decl) : Option State := do
  match d.arrayExtent with
  | some extent =>
    if d.value.isSome then none else
    let zero ← SynergyC.Initialization.zeroValue 10 d.type
    pure {st with
      heap:=st.heap++[{type:=d.type,cells:=List.replicate extent (some zero),isArray:=true}]
      env:=(d.name,⟨st.heap.length,0,[]⟩)::st.env}
  | none => SynergyC.Initialization.initializeOne st d

def initializeGlobals : Option State := do
  let st ← Generated.globals.foldlM initializeOne Machine.empty
  pure {st with env:=[],globals:=st.env}

def zeroI : Value := .record "I" [value 0,value 0]
def state : State := {
  heap:=[
    {type:="const U",cells:=[some (value (2^128))]},
    {type:="const U",cells:=[some (value maxWord)]}]++
      List.replicate 11 {type:="I",cells:=[some zeroI]}++
      [{type:="I",cells:=List.replicate 58 (some zeroI),isArray:=true}]
  env:=[]
  globals:=[("constantNodes",⟨13,0,[]⟩),("smoothingBox",⟨12,0,[]⟩),
    ("deltaBox",⟨11,0,[]⟩),("dBox",⟨10,0,[]⟩),("alphaBox",⟨9,0,[]⟩),
    ("sqrt2Alpha",⟨8,0,[]⟩),("sqrtPi",⟨7,0,[]⟩),("peakBox",⟨6,0,[]⟩),
    ("gaussianBox",⟨5,0,[]⟩),("m0Box",⟨4,0,[]⟩),("piBox",⟨3,0,[]⟩),
    ("ln2",⟨2,0,[]⟩),("MAXU",⟨1,0,[]⟩),("S",⟨0,0,[]⟩)]
  nats:=NatArena.empty}

theorem actual_initialization : initializeGlobals = some state := by
  rfl

def maxContext : MaxContext state := {
  address:=⟨1,0,[]⟩
  located:=by rfl
  allocated:=by decide +kernel
  object:={type:="const U",cells:=[some (value maxWord)]}
  heap_entry:=by rfl
  scalar:=by rfl
  contents:=by rfl}

def scaleContext : SynergyC.UnitBody.ScaleContext state := {
  address:=⟨0,0,[]⟩
  located:=by rfl
  allocated:=by decide +kernel
  object:={type:="const U",cells:=[some (value (2^128))]}
  heap_entry:=by rfl
  scalar:=by rfl
  contents:=by rfl}

#print axioms actual_initialization
#print axioms maxContext
#print axioms scaleContext
end SynergyHeightC.Initialization

namespace SynergyHeightC.InitProposal
open ScopedC ScopedC.Machine Lean
set_option maxRecDepth 100000
set_option maxHeartbeats 0
private def jstr (s:String) : Lean.Json := .str s
private def jnat (n:Nat) : Lean.Json := toJson n
private def jbool (b:Bool) : Lean.Json := toJson b
private def jobject (items:List (String × Lean.Json)) : Lean.Json := Lean.Json.mkObj items
private def jarray (items:List Lean.Json) : Lean.Json := toJson items
private def intType (t:Scalar.IntType) : Lean.Json := jobject [("signed",jbool t.signed),("width",jnat t.width)]
private partial def value : Value → Lean.Json
 | .integer v => jobject [("kind",jstr "integer"),("type",intType v.type),("number",jstr (toString v.number))]
 | .record t vs => jobject [("kind",jstr "record"),("type",jstr t),("values",jarray (vs.map value))]
 | .aggregate vs => jobject [("kind",jstr "aggregate"),("values",jarray (vs.map value))]
 | .pointer a w => jobject [("kind",jstr "pointer"),("object",jnat a.object),("index",jnat a.index),("fields",toJson a.fields),("writable",jbool w)]
 | .natObject slot => jobject [("kind",jstr "natObject"),("slot",jnat slot)]
 | .null => jobject [("kind",jstr "null")]
 | .uninitialized => jobject [("kind",jstr "uninitialized")]
 | .unit => jobject [("kind",jstr "unit")]
private def cell : Option Value → Lean.Json
 | none => Lean.Json.null
 | some v => value v
private def object (obj:Object) : Lean.Json := jobject [("type",jstr obj.type),("isArray",jbool obj.isArray),("writable",jbool obj.writable),("cells",jarray (obj.cells.map cell))]
private def address (a:Address) : Lean.Json := jobject [("object",jnat a.object),("index",jnat a.index),("fields",toJson a.fields)]
private def binding (item:String × Address) : Lean.Json := jobject [("name",jstr item.1),("address",address item.2)]

private def stateJSON (s : State) : Lean.Json := jobject [
  ("heap",jarray (s.heap.map object)),("env",jarray (s.env.map binding)),
  ("globals",jarray (s.globals.map binding)),
  ("nat_arena",jstr "OMITTED: retain actual returned arena")]
private def row (name : String) (index : Nat) (s : State) : Lean.Json :=
  jobject [("function",jstr name),("after_statement_index",jnat index),("state",stateJSON s)]
private def steps (name : String) (service : Call) : Nat → List Syntax.Stmt → State →
    Option (State × List Lean.Json)
  | _,[],s => some (s,[])
  | index,st::rest,s => do
    let .continuing t ← ArraySourceExecute.statement SynergyC.Header.layout service 128 2048 st s | none
    let (u,rows) ← steps name service (index+1) rest t
    pure (u,row name index t::rows)
private def trace : Option Lean.Json := do
  let .sequence outer := Generated.f_initializePointConstants.body | none
  let first :: _second :: remaining := outer | none
  let initial := Initialization.state
  let outerService := ArraySourceCallExecute.execute SynergyC.Header.layout Generated.functions 128 2048 15
  let innerService := ArraySourceCallExecute.execute SynergyC.Header.layout Generated.functions 128 2048 14
  let .continuing afterLn ← ArraySourceExecute.statement SynergyC.Header.layout outerService 128 2048 first initial | none
  let f := Generated.f_initializeConstants
  let .sequence inner := f.body | none
  let frame ← Machine.bindArgs SynergyC.Header.layout f.parameters [] afterLn
  let (lastInner,innerRows) ← steps "initializeConstants" innerService 0 inner frame
  let (.unit,afterConstants) ← ArraySourceCallExecute.finish SynergyC.Header.layout f afterLn (.continuing lastInner) | none
  let (.unit,directConstants) ← ArraySourceCallExecute.execute SynergyC.Header.layout Generated.functions 128 2048 15 "initializeConstants" [] afterLn | none
  if !(StateWordEquality.stateEq 8 afterConstants directConstants) then none else
  let (lastOuter,outerRows) ← steps "initializePointConstants" outerService 2 remaining afterConstants
  let (.unit,after) ← ArraySourceCallExecute.finish SynergyC.Header.layout Generated.f_initializePointConstants initial (.continuing lastOuter) | none
  let (.unit,direct) ← ArraySourceCallExecute.execute SynergyC.Header.layout Generated.functions 128 2048 16 "initializePointConstants" [] initial | none
  if !(StateWordEquality.stateEq 8 after direct) then none else
  pure (jobject [("status",jstr "UNTRUSTED_ACTUAL_SOURCE_EXECUTION_PROPOSAL"),
    ("returned",value .unit),("heap",jarray (after.heap.map object)),
    ("env",jarray (after.env.map binding)),("globals",jarray (after.globals.map binding)),
    ("nat_arena",jstr "OMITTED: retain actual returned arena"),
    ("stage_records",jarray ([row "initialSourceGlobals" 0 initial,row "initializePointConstants" 0 afterLn]++innerRows++[row "initializePointConstants" 1 afterConstants]++outerRows)),
    ("native_consistency",jstr "Staged actual statement execution matches complete actual SourceCall; NOT a proof")])
def proposal : Lean.Json := trace.getD (jobject [("status",jstr "SOURCE_AST_STAGE_EXECUTION_NONE")])
#eval IO.println proposal.compress
end SynergyHeightC.InitProposal
