# Actual height C source-binding component

This source-only component preserves all 524 actual C files, 39 source AST
functions, 14 globals, every short renderer/bound and its complete dependency
closure: 112 Lean source modules, 574 source payloads and 16 audit roots.
There are no application object-cache inputs. Source/build/output association
and warm accepted receipts are retained in `evidence`.

The accepted application initialization is **only the fourteen source static
globals**. The computation of the 58-node cache is **not kernel accepted**:
the actual 12 GiB run had oom=1/oom_kill=1. Native actual-source execution
matches all 140 C poststate words and both environments; the 13-inner/60-outer
statement trace is untrusted proposal data. These diagnostics are not PV or
mathematical premises. `InitExecute.source_of_checked` is a proved conditional
API; its required checked=true instance remains unproved in this snapshot.

## Fresh public environment and component recipe

The pinned public bootstrap is the same as the existing project. On Linux
x86-64 with Python3, Git, tar/zstd and C/C++ headers:

    python environment-bootstrap/scripts/bootstrap.py --work /new/public-environment --receipt /new/public-bootstrap.json
    python prepare_environment.py --toolchain /new/public-environment/lean-4.34.0-rc2-linux --mathlib /new/public-environment/mathlib --out /new/environment.json
    python reproduce.py --environment /new/environment.json --out /new/height-source-proof --jobs 2
    python reproduce_cpp.py --compiler /new/public-environment/lean-4.34.0-rc2-linux/bin/clang --out /new/height-cpp-run

The fresh proof recipe is **prepared, not executed in this archive**. It
rebuilds every application source from an empty object directory and audits
all16 exact roots; a progress file is never an acceptance receipt. It uses
pinned public generic libraries and is host source-cold, not namespace
isolation. Use the normal resource admission policy; inspect actual RAM/disk
separately. Larger source-kernel evaluations need justified resources, never
the obsolete4GiB cap. This component excludes the unaccepted init instance.

`reproduce_cpp.py` compiles/runs the actual physical source tree and verifies
its exact1538-word output hash. This repeats raw output association, not
execution correctness. It preserves source, output and receipts, deleting
only the newly generated identified binary after output acceptance.

The actual array model allocates/binds before initializer expressions and
stores each typed result before the next expression. The selected height-main
call closure uses the exact-full U[2] initializer. The written but unreachable
archived basis main's I[3] initializer is explicitly inventoried and unsupported
by this integer-only extension. Old Machine/SourceCalls are unchanged. See the
bounded review and primary C++17 N4659 locators in `evidence/array-review`.

The mathematical theorem, all original analytic assumptions and historical
outcomes are unchanged. Full actual source init, main-prefix/point/caller
execution, output stream and output-to-ANT join remain open. This source
component is **not complete source-first PV**.
