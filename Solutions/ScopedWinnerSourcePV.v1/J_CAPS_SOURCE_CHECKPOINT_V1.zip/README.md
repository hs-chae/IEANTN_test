# Unconditional Gaussian-basis cap checkpoint

`SynergyAnalytic.tangent256_universal_basis_caps` proves, for every b>=1, `basisZero b<=373/200`, `basisOne b<=1273/2000`, `basisTwo b<=129/250`. All definitions and written non-generic imports are under source/. Exact final theorem axioms are propext, Classical.choice, Quot.sound. No desired-moment premise or native execution axiom is used by this theorem.

The exact source/receipt manifest preserves the actual272-cell ordinary-kernel integer-box reduction (793.279459s) and the real soundness/tail chain. The final unconditional wrapper compiled unchanged in6.006791s. Its source SHA is4222e7fa9e1ff0af0dbaf214e8c66c06ef7e234afae986fc7d69b42d66419bd1.

This is a source-only progress checkpoint, NOT a newly executed source-cold replay or a verified C program. Current successful commands are recorded in each evidence/RECEIPT.json. They used the pinned Lean4.34.0-rc2 generic environment and explicit warm application object banks. The source/ tree contains the complete written application dependency closure of the final theorem so a later clean application replay need not read the old workspaces; Mathlib and its generic dependencies remain external pinned prerequisites. That replay has NOT yet been executed for this new closure. The enclosed compile helper records the original warm-development method; it is not a portable clean-bootstrap promise.

UniversalBasisCaps currently lives in ActualMoment, which imports more old application math than the final proof uses. These unused imports are preserved rather than silently changing the proved source. Some historical imported modules have native facts, but the actual final theorem axiom audit above excludes those facts. Extracting the identical pure predicate and conducting a new source-cold replay is the next packaging task.

Physical C++ source correspondence, Word512 safety, initialization/body/call/serialization/I/O correctness remain separate pending obligations. The exact J theorem is kernel mathematics, not source-PV. No new completed height/PNT numerical instance is claimed. Height candidates and the six inherited old native scalar facts remain open; see checkpoint/HANDOFF_USAGE_STOP_J_CAPS_V1.md.

No original experimental scores, source assumptions or network metadata were changed by this checkpoint. No private model transcripts, application objects, numerical caches or binary outputs are included.
