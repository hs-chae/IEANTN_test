# Source-bound exponential component: complete fresh replay

This archive proves a **finite-input actual C library call**, not a complete ANT program migration. It executes the actual bound `rat(1,3)` and `expNeg` statement trees, all 48 Horner steps, six squarings and callees, checks typed 512-bit arithmetic, guards and memory, and proves the returned interval contains exp(-1/3). The explicit words and actual C readback agree.

The actual complete default replay rebuilt **357 application source modules**, audited **75 roots** with only `propext`, `Classical.choice`, `Quot.sound`, regenerated the actual 50-file C bundle and compiled/executed the readback driver. It reused **no application object inputs**. Its outer resource run took 1643.664 seconds under a 24 GiB reservation with two compilation workers. This was a **host source-cold replay**, not a namespace-isolated discovery session. The compiler/runtime/platform trust boundary is explicit below.

## Reproduce from clean application sources

Use Linux x86-64, Python3, Git, `/usr/bin/time`, GCC11 development headers, the exact Lean4.34.0-rc2 toolchain and public Mathlib checkout pinned in `capsule-v1/SOURCE_LOCK.json`. Toolchain identity is also pinned by file hashes. No numerical random seed is used. Build or download only the public generic dependency caches; prior IEANTN application objects are neither needed nor accepted. Public dependency versions/URLs/commits and captured byte-identical source payloads are included.

With a Lean toolchain at `/path/to/lean` and the pinned Mathlib checkout (including its exact pinned Lake dependencies) at `/path/to/mathlib`:

```sh
python3 capsule-v1/prepare_environment.py --toolchain /path/to/lean --mathlib /path/to/mathlib --out /fresh/PUBLIC_GENERIC_ENV.json
python3 reproduce_component.py --environment /fresh/PUBLIC_GENERIC_ENV.json --out /fresh/complete-run --jobs 2
```

The output directory must not exist and must be outside this archive. `RECEIPT.json` is written atomically only after source/runtime checks, full base rebuild, all root audits, readback proof, actual C run and exact output comparison succeed. The generated C binary is hashed and then removed; its source and output remain. Other generated objects/logs can be regenerated. Preserve the supplied source, receipts and manifests.

The optional `--approved-base` route accepts only the exact historical approved base receipt and verifies all its source/object hashes. It is labeled **composed approved-base reuse**, not a fresh full replay. That route passed in normal, `-O` and `-OO` harness modes; the full default clean route was also actually executed. It is optional and is not required for clean reproduction.

## Exact result and limits

The endpoint integers are 243822970335011067903414604203639432295 and 243822970335011067903414604203639432528, each divided by 2^128. The actual 48-byte little-endian output SHA256 is `522dbfabcb0cc99b694359f581742bbe1125239eecf047c7f8d10f65115c36bf`.

Eleven generic source-body contracts are included: addU, mulU, zero, unit, add, ceilDiv, positiveSub, mul, divI, rat and divN. Also included are the actual eight-global initialization/start component and partial generic StdIO/checked-flush proofs. They do not complete the old68-function or new19-function application, the numerical integration programs, printing/entrypoint correctness or final ANT source-first PV. Historical descriptions inside the immutable base capsule refer only to that earlier proof-only base replay; `reproduce_component.py` adds the explicit-word proof and actual C reproduction.

Lean's kernel, the pinned generic compiler/core runtime, standard ABI/OS/library and hardware contracts remain trusted. Source execution uses the documented pinned Clang22.1.4/Itanium ordinary-call left-to-right evaluation contract; ISO C++17 does not guarantee that order for arbitrary ordinary call arguments. The compiler addendum documents exact primary-source locators, actual POD call-site conditions and bounded IR canaries; finite canaries are not a compiler proof. Application states, calls, guards and results are proved, never generic platform facts. The auxiliary driver and its StdIO serialization are executed and compared but are **outside the source proof**. No axiom, native execution fact or admitted proof is introduced by the accepted component.
