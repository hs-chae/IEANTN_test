# Eleven arithmetic bodies, initialization and actual source-execution pilot

Run `python3 reproduce.py --environment /absolute/PUBLIC_GENERIC_ENV.json --out /fresh/output --jobs 2`.
Use `prepare_environment.py --help` to prepare the pinned public toolchain/mathlib environment.
Only public generic dependency objects are accepted; every application module is rebuilt from source.
The exact Lean kernel/runtime files and generic source commits are checked before and after the run.

The actual source-AST execution instances are rat(1,3) and expNeg on the interval for one third.
The latter executes the real 48-iteration Horner loop, six squarings and all actual C callees,
then connects its returned interval to the mathematical exp(-1/3) enclosure. It is a finite-input
library-call verification component. The public C source is in the captured include payloads.
This replay does not execute a C binary or prove serialization/main or the full ANT source-first path.
Compiler/runtime/OS and hardware applicability remains at the project's documented pinned boundary.

Eleven of nineteen positive-backend functions additionally have generic source-body proofs.
Their explicit intermediate-product and initialized-memory premises must be discharged by future
whole-program instances. The earlier six-body cold run is preserved as separate evidence.
