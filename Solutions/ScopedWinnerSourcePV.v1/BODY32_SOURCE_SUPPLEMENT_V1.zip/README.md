# Accepted 32-body host source supplement

This supplement freezes32of68 original C function body contracts and15
additional source-to-mathematics refinements. All recorded own builds and
requested theorem axiom audits passed with only standard Lean axioms.
The new signed/rational comparator and min/max routines execute the actual
installed AST bodies, including repeated calls, six precise allocation/keep
effects, typed frames, actual <=/swapped-branch selection and cleanup.
The explicit mathematical domains (positive rational denominators and signed
zero normalization where required) remain part of the proved contracts.

This is HOST development evidence. The combined source-cold recipe below has
NOT been executed for this supplement. A separate earlier16-body/46-source
component has an actual host source-cold receipt; its scope is narrower.
Root's later28-body/C56 cold component is separate. None completes the68-body
application, initial heap, full loops, checked stdio, source-derived numerical
providers, unchanged ANT consumers or final namespace-isolated replay.
Ordinary kernel numerical checks alone are not source-first PV.

## Clean proof reproduction recipe

Use Linux x86-64 and the pinned Lean4.34.0-rc2/Mathlib/generic dependency
versions inSOURCE_LOCK.json. Prepare PUBLIC_GENERIC_ENV.json using the same
compiler+generic_dependencies schema as the earlier accepted body component;
each generic dependency has name,url,commit,source,objects. Source Git commits,
the actual kernel/runtime/stdlib/header sentinel hashes and Lean version are
checked. Prior application-object paths in the environment are ignored.

```
python3 reproduce.py --environment /absolute/PUBLIC_GENERIC_ENV.json --out /fresh/outside-capsule
```

The recipe builds the entire frozen written application source closure into
an empty object directory, then reflects the exact32body+15refinement roots
and rejects nonstandard axioms. It needs only pinned public generic libraries.
The compiler/core Nat runtime/preprocessor/ABI and hardware remain explicit
generic trust boundaries; this is not verification of their implementations.
Actual application correctness and applicability cannot be assumed from them.

actual-c/ preserves the original executable C++ arithmetic/input sources;
their algorithms,52rows,8192/16384cell grids and numerical constants are
unchanged. Parent C56/source-binding artifacts separately preserve the actual
compile/run and source-to-AST association; this proof recipe does not rerun
those programs or imply a new accepted numerical result. Numerical randomness
is absent. evidence/ preserves successful warm proof receipts/logs and their
original working commands; source hashes and manifest bind the portable files.
