/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.PoolCursor

namespace ScopedC.AllocatedFrames
open ScopedC.Machine ScopedC.PoolCalls ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem context_allocate {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high : Nat}
    (h : GenericPoolContext l s cells top high) (type name : String) (v : Value) :
    GenericPoolContext l (allocate s type name (some v)) cells top high :=
  context_env (context_append h [{type:=type,cells:=[some v]}]) ((name,⟨s.heap.length,0,[]⟩)::s.env)

theorem store_commute (s : State) (i : Nat) (o : Object) (hi : i<s.heap.length)
    (type name : String) (v : Value) :
    allocate (storeObject s i o) type name (some v)=storeObject (allocate s type name (some v)) i o := by
  simp [storeObject,allocate,List.set_append_left i o hi]

theorem result_allocate {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high slot : Nat}
    (h : GenericPoolContext l s cells top high) (type name : String) (v : Value) :
    keepResult l (allocate s type name (some v)) cells top high slot=
      allocate (keepResult l s cells top high slot) type name (some v) := by
  have hp := (List.getElem?_eq_some_iff.mp h.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp h.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp h.high_read).choose
  have hs : keepStored l (allocate s type name (some v)) cells top slot=
      allocate (keepStored l s cells top slot) type name (some v) := (store_commute s l.pool _ hp type name v).symm
  have ht' : l.top<(keepStored l s cells top slot).heap.length := by
    simpa [keepStored,storePool,storeObject] using ht
  have hb : keepStepped l (allocate s type name (some v)) cells top slot=
      allocate (keepStepped l s cells top slot) type name (some v) := by
    unfold keepStepped
    rw [hs]
    exact (store_commute _ l.top _ ht' type name v).symm
  have hh' : l.high<(keepStepped l s cells top slot).heap.length := by
    simpa [keepStepped,keepStored,storeTop,storePool,storeObject] using hh
  unfold keepResult
  split
  · rw [hb]
    exact (store_commute _ l.high _ hh' type name v).symm
  · exact hb

theorem binary_allocate {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high n : Nat}
    (h : GenericPoolContext l s cells top high) (type name : String) (v : Value) :
    binaryResult l (allocate s type name (some v)) cells top high n=
      allocate (binaryResult l s cells top high n) type name (some v) :=
  result_allocate (context_nats h (NatArena.allocate s.nats n).2) type name v

theorem pop_two {s t : State} (ta na : String) (va : Value) (tb nb : String) (vb : Value)
    (length : t.heap.length=s.heap.length) (env : t.env=s.env) :
    popScope s (allocate (allocate t ta na (some va)) tb nb (some vb))=t := by
  cases t
  simp_all [popScope,allocate,List.append_assoc]

end ScopedC.AllocatedFrames
