/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCrossCalls
import ScopedC.CallEventDistinct

namespace ScopedC.RationalCompareCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def middle (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  RationalCrossCalls.c3 l c a.numerator b.denominator
def final (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  RationalCrossCalls.c3 l (middle l c a b) b.numerator a.denominator
def left (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Endpoint :=
  RationalCrossCalls.result l c a.numerator b.denominator
def right (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Endpoint :=
  RationalCrossCalls.result l (middle l c a b) b.numerator a.denominator

theorem top_middle (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (middle l c a b).top=c.top+3 := rfl

theorem middle_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) : Valid l (middle l c a b) :=
  (RationalCrossCalls.contexts ctx (by omega) a.numerator b.denominator).2.2

theorem final_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) : Valid l (final l c a b) :=
  (RationalCrossCalls.contexts (middle_context ctx room a b)
    (by simpa only [top_middle] using room) b.numerator a.denominator).2.2

theorem input_middle {l : PoolCalls.PoolLayout} {c : Cursor} {a b q : Input} (h : q.Live c.state) :
    q.Live (middle l c a b).state :=
  Input.live_after (Input.live_after (Input.live_after h))

theorem left_final (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (left l c a b).Live (final l c a b).state :=
  PoolCursor.preserves (PoolCursor.preserves (PoolCursor.preserves
    (RationalCrossCalls.result_live l c a.numerator b.denominator)))

theorem right_final (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (right l c a b).Live (final l c a b).state :=
  RationalCrossCalls.result_live l (middle l c a b) b.numerator a.denominator

theorem middle_size (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (middle l c a b).state.nats.values.length=c.state.nats.values.length+3 := by
  have s1 := PoolCursor.size l c 0
  have s2 := PoolCursor.size l (RationalCrossCalls.c1 l c) (a.numerator.magnitude*b.denominator)
  have s3 := PoolCursor.size l (RationalCrossCalls.c2 l c a.numerator b.denominator) 0
  change (next l (RationalCrossCalls.c2 l c a.numerator b.denominator) 0).state.nats.values.length=_
  rw [s3]
  change (next l (RationalCrossCalls.c1 l c) (a.numerator.magnitude*b.denominator)).state.nats.values.length+1=_
  rw [s2]
  change (next l c 0).state.nats.values.length+1+1=c.state.nats.values.length+3
  rw [s1]

theorem frame_distinct (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    frame (middle l c a b).state a b ≠ frame c.state a b := by
  intro equal
  have h := congrArg (fun s : State => s.nats.values.length) equal
  change (middle l c a b).state.nats.values.length=c.state.nats.values.length at h
  rw [middle_size] at h
  omega

theorem shape (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (final l c a b).state.heap.length=c.state.heap.length ∧ (final l c a b).state.env=c.state.env := by
  have h1 := RationalCrossCalls.shape l c a.numerator b.denominator
  have h2 := RationalCrossCalls.shape l (middle l c a b) b.numerator a.denominator
  exact ⟨h2.1.trans h1.1,h2.2.trans h1.2⟩

end ScopedC.RationalCompareCalls
