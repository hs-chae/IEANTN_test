/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.NatResultFrames
import ScopedC.PositiveCasts

namespace ScopedC.NatWrapperCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def unsigned64 (n : Nat) : Value := .integer ⟨⟨false,64⟩,(n:Int)⟩

theorem unbox_runtime {s : State} {slot n : Nat} (live : NatArena.Borrow s.nats slot n)
    (bound : n < 2^32) :
    RuntimeCore.call "lean_unbox" [.natObject slot] s = some (unsigned64 n,s) := by
  have h63 : n < 2^63 := by omega
  have range : Scalar.InRange ⟨false,64⟩ (n:Int) := by
    simp only [Scalar.InRange,Scalar.lower,Scalar.upper,Scalar.modulus,Bool.false_eq_true,↓reduceIte]
    constructor
    · decide
    · constructor
      · omega
      · exact_mod_cast (show n < 2^64 by omega)
  simp [RuntimeCore.call,RuntimeCore.binaryName,NatArena.read_of_borrow live,h63,
    RuntimeCore.unsignedResult,Scalar.checked,range,unsigned64]
  exact h63

theorem cast64_to_unsigned (s : State) {n : Nat} (bound : n < 2^32) :
    castValue Header.layout s 100 "unsigned int" (unsigned64 n) = some (unsigned32 n) := by
  have range : Scalar.InRange ⟨false,32⟩ (n:Int) := by
    simp only [Scalar.InRange,Scalar.lower,Scalar.upper,Scalar.modulus,Bool.false_eq_true,↓reduceIte]
    exact ⟨by decide,by omega,by exact_mod_cast bound⟩
  change (do let x ← Scalar.cast ⟨false,32⟩ ⟨⟨false,64⟩,(n:Int)⟩
             pure (Value.integer x)) = some (unsigned32 n)
  simp only [Scalar.cast]
  rw [Scalar.make_exact range]
  rfl

theorem small_call (code : List Function) (installed : Generated.f_small ∈ code)
    (nuInstalled : Generated.f_nu ∈ code) (nleInstalled : Generated.f_nle ∈ code)
    (keepInstalled : Generated.f_keep ∈ code)
    {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high slot n : Nat}
    (context : GenericPoolContext l s cells top high) (room : top < capacity)
    (live : NatArena.Borrow s.nats slot n) (bound : n < 2^32) :
    SourceCall Header.layout code 3 "small" [.natObject slot] s (unsigned32 n)
      (binaryResult l s cells top high 4294967295) := by
  let frame := OneFrames.frame s "N" "a" (.natObject slot)
  let next := binaryResult l s cells top high 4294967295
  let after := OneFrames.frame next "N" "a" (.natObject slot)
  let maxSlot := s.nats.values.length
  have frameNats : frame.nats = s.nats := rfl
  have frameContext : GenericPoolContext l frame cells top high := OneFrames.context_frame context _ _ _
  have firstLive : NatArena.Borrow after.nats slot n :=
    binary_result_preserves (l:=l) (s:=s) (cells:=cells) (top:=top) (high:=high) (result:=4294967295) live
  have maxLive : NatArena.Borrow after.nats maxSlot 4294967295 :=
    binary_result_borrow l s cells top high 4294967295
  have hle : n ≤ 4294967295 := by omega
  have nuProof : SourceCall Header.layout code 2 "nu" [unsigned32 4294967295]
      frame (.natObject maxSlot) after := by
    have h := nu_call (n:=4294967295) (input:=unsigned32 4294967295) code nuInstalled keepInstalled
      frameContext room (by decide) rfl
    have fn : (OneFrames.frame s "N" "a" (.natObject slot)).nats = s.nats := rfl
    simpa only [frame,after,next,maxSlot,binary_result_one_frame context,fn] using h
  have leProof : SourceCall Header.layout code 2 "nle" [.natObject slot,.natObject maxSlot]
      after (PrimitiveCalls.u32 true) after := by
    have h := raise_once (HelperCodeAdapters.nle_for_code code nleInstalled firstLive maxLive)
    simpa only [hle,decide_true] using h
  let nuEvent : CallEvents.Event Header.layout code 2 :=
    ⟨"nu",[unsigned32 4294967295],frame,.natObject maxSlot,after,nuProof⟩
  let leEvent : CallEvents.Event Header.layout code 2 :=
    ⟨"nle",[.natObject slot,.natObject maxSlot],after,PrimitiveCalls.u32 true,after,leProof⟩
  let unboxEvent : CallEvents.Event Header.layout code 2 :=
    ⟨"lean_unbox",[.natObject slot],after,unsigned64 n,after,runtime_leaf (unbox_runtime firstLive bound)⟩
  let service := CallEvents.append (CallEvents.one nuEvent)
    (CallEvents.append (CallEvents.one leEvent) (CallEvents.one unboxEvent))
  have nuAnswer : service "nu" [unsigned32 4294967295] frame = some (.natObject maxSlot,after) :=
    CallEvents.append_left (CallEvents.one_self nuEvent)
  have leAnswer : service "nle" [.natObject slot,.natObject maxSlot] after = some (PrimitiveCalls.u32 true,after) :=
    CallEvents.append_right (CallEvents.one_other nuEvent (by change ("nle":String) ≠ "nu"; decide +kernel) _ _)
      (CallEvents.append_left (CallEvents.one_self leEvent))
  have unboxAnswer : service "lean_unbox" [.natObject slot] after = some (unsigned64 n,after) :=
    CallEvents.append_right (CallEvents.one_other nuEvent (by change ("lean_unbox":String) ≠ "nu"; decide +kernel) _ _)
      (CallEvents.append_right (CallEvents.one_other leEvent (by change ("lean_unbox":String) ≠ "nle"; decide +kernel) _ _)
        (CallEvents.one_self unboxEvent))
  have beforeVar (fuel : Nat) : evalExpr Header.layout service (fuel+1) frame (.var "a") =
      some (.natObject slot,frame) :=
    TypedFrames.allocate_eval Header.layout service fuel {s with env:=[]} "N" "a" (.natObject slot)
      rfl (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have afterVar (fuel : Nat) : evalExpr Header.layout service (fuel+1) after (.var "a") =
      some (.natObject slot,after) :=
    TypedFrames.allocate_eval Header.layout service fuel {next with env:=[]} "N" "a" (.natObject slot)
      rfl (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have test : evalExpr Header.layout service 5 frame
      (.call (.var "nle") [.var "a",.call (.var "nu") [.uint 4294967295]]) =
      some (PrimitiveCalls.u32 true,after) :=
    ExpressionTemplates.call_two Header.layout service (beforeVar 3)
      (ExpressionTemplates.call_one Header.layout service (show evalExpr Header.layout service 3 frame (.uint 4294967295) = some (unsigned32 4294967295,frame) from rfl) nuAnswer) leAnswer
  have guard : Eval Header.layout service
      (.unary "!" (.call (.var "nle") [.var "a",.call (.var "nu") [.uint 4294967295]]))
      frame after (boolean Header.layout false) := by
    refine ⟨6,?_⟩
    rw [evalExpr,test]
    rfl
  have first : Run Header.layout service
      (.branch (.unary "!" (.call (.var "nle") [.var "a",.call (.var "nu") [.uint 4294967295]]))
        (.eval (.call (.var "fail") [])) .skip) frame (.continuing after) := by
    apply Loops.StmtRun.branch guard
    exact Loops.StmtRun.skip after
  have expression : Eval Header.layout service
      (.cast "unsigned int" (.call (.var "lean_unbox") [.var "a"])) after after (unsigned32 n) :=
    ⟨4,ExpressionTemplates.cast Header.layout service
      (ExpressionTemplates.call_one Header.layout service (afterVar 1) unboxAnswer) (cast64_to_unsigned after bound)⟩
  have nextShape : next.heap.length = s.heap.length ∧ next.env = s.env :=
    ⟨(keep_result_shape l {s with nats:=(NatArena.allocate s.nats 4294967295).2} cells top high maxSlot).1,
      (keep_result_shape l {s with nats:=(NatArena.allocate s.nats 4294967295).2} cells top high maxSlot).2.1⟩
  have shape : after.heap.length = frame.heap.length ∧ after.env = frame.env := by
    constructor
    · simpa only [after,frame,OneFrames.frame,allocate,List.length_append,List.length_singleton] using congrArg (fun x => x+1) nextShape.1
    · simp only [after,frame,OneFrames.frame,allocate,nextShape.1]
  have statement : Run Header.layout service Generated.f_small.body frame (.returned after (unsigned32 n)) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next first (Loops.SeqRun.returned (Loops.StmtRun.returnValue expression)))
    exact ⟨rfl,(pop_same shape.1 shape.2).symm⟩
  apply installed_body (rank:=2) (service:=service) installed
    (fun _ _ _ _ _ h => CallEvents.append_closed
      (fun _ _ _ _ _ hc => CallEvents.one_closed nuEvent hc)
      (fun _ _ _ _ _ hc => CallEvents.append_closed
        (fun _ _ _ _ _ h0 => CallEvents.one_closed leEvent h0)
        (fun _ _ _ _ _ h0 => CallEvents.one_closed unboxEvent h0) hc) h)
    (TypedFrames.bind_one Header.layout s "N" "a" (.natObject slot) (.natObject slot) (PrimitiveCalls.cast_N live)) statement
  change castValue Header.layout after 100 "static unsigned int" (unsigned32 n) = some (unsigned32 n) ∧ next = popScope s after
  constructor
  · exact PositiveCasts.cast_unsigned after 99 n bound
  · exact (OneFrames.pop_frame _ _ _ nextShape.1 nextShape.2).symm

end ScopedC.NatWrapperCalls
