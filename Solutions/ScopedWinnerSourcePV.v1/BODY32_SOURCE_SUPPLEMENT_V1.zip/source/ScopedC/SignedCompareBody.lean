/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SignedAddShape

namespace ScopedC.SignedCompareCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation
open ScopedC.SignedPairFrames (frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def integer (n : Int) : Value := .integer ⟨⟨true,32⟩,n⟩
def different (a b : Endpoint) : Bool := a.negative != b.negative
def equal (a b : Endpoint) : Bool := a.magnitude == b.magnitude
def less (a b : Endpoint) : Bool := decide (a.magnitude < b.magnitude)
def resultInt (a b : Endpoint) : Int :=
  if different a b then (if a.negative then -1 else 1)
  else if equal a b then 0
  else if less a b then (if a.negative then 1 else -1)
  else (if a.negative then -1 else 1)

def differentTest : Expr := .binary "!=" (.field "." (.var "a") "neg") (.field "." (.var "b") "neg")
def equalTest : Expr := .call (.var "ne") [.field "." (.var "a") "mag",.field "." (.var "b") "mag"]
def lessTest : Expr := .call (.var "nlt") [.field "." (.var "a") "mag",.field "." (.var "b") "mag"]
def ordinaryReturn : Expr := .conditional (.field "." (.var "a") "neg") (.unary "-" (.nat 1)) (.nat 1)
def lessReturn : Expr := .conditional (.field "." (.var "a") "neg") (.nat 1) (.unary "-" (.nat 1))

theorem different_value (s : State) (a b : Bool) :
    binaryValue Header.layout s "!=" (unsigned32 (SignedNegCalls.bit a)) (unsigned32 (SignedNegCalls.bit b)) =
      some (boolean Header.layout (a != b)) := by
  cases a <;> cases b <;> rfl

theorem different_eval (call : Call) (s : State) (a b : Endpoint) :
    Eval Header.layout call differentTest (frame s a b) (frame s a b) (boolean Header.layout (different a b)) := by
  refine ⟨4,?_⟩
  exact ExpressionTemplates.binary Header.layout call (by decide) (by decide) (by decide) (by decide)
    (SignedPairFrames.eval_a_neg call 1 s a b) (SignedPairFrames.eval_b_neg call 1 s a b)
    (different_value (frame s a b) _ _)

theorem eval_zero (call : Call) (s : State) :
    evalExpr Header.layout call 4 s (.nat 0) = some (integer 0,s) := by rfl
theorem eval_one (call : Call) (s : State) :
    evalExpr Header.layout call 3 s (.nat 1) = some (integer 1,s) := by rfl
theorem eval_neg_one (call : Call) (s : State) :
    evalExpr Header.layout call 3 s (.unary "-" (.nat 1)) = some (integer (-1),s) := by rfl

theorem ordinary_eval (call : Call) (s : State) (a b : Endpoint) :
    Eval Header.layout call ordinaryReturn (frame s a b) (frame s a b)
      (integer (if a.negative then -1 else 1)) := by
  refine ⟨4,?_⟩
  rw [ordinaryReturn,evalExpr,SignedPairFrames.eval_a_neg call 1 s a b]
  cases hn : a.negative <;>
    simp [Bind.bind,Option.bind,NatWrapperCalls.unsigned32,SignedNegCalls.bit,truth,Scalar.truth,hn,
      eval_one,eval_neg_one]

theorem less_eval (call : Call) (s : State) (a b : Endpoint) :
    Eval Header.layout call lessReturn (frame s a b) (frame s a b)
      (integer (if a.negative then 1 else -1)) := by
  refine ⟨4,?_⟩
  rw [lessReturn,evalExpr,SignedPairFrames.eval_a_neg call 1 s a b]
  cases hn : a.negative <;>
    simp [Bind.bind,Option.bind,NatWrapperCalls.unsigned32,SignedNegCalls.bit,truth,Scalar.truth,hn,
      eval_one,eval_neg_one]

theorem body (call : Call) (s : State) (a b : Endpoint)
    (eqEval : Eval Header.layout call equalTest (frame s a b) (frame s a b)
      (unsigned32 (SignedNegCalls.bit (equal a b))))
    (ltEval : Eval Header.layout call lessTest (frame s a b) (frame s a b)
      (unsigned32 (SignedNegCalls.bit (less a b)))) :
    Run Header.layout call Generated.f_sc.body (frame s a b)
      (.returned (frame s a b) (integer (resultInt a b))) := by
  change Run Header.layout call (.sequence [
    .branch differentTest (.returnStmt ordinaryReturn) .skip,
    .branch equalTest (.returnStmt (.nat 0)) .skip,
    .branch lessTest (.returnStmt lessReturn) .skip,.returnStmt ordinaryReturn])
    (frame s a b) (.returned (frame s a b) (integer (resultInt a b)))
  have hd := different_eval call s a b
  cases hdiff : different a b with
  | true =>
    have hit : Run Header.layout call (.branch differentTest (.returnStmt ordinaryReturn) .skip)
        (frame s a b) (.returned (frame s a b) (integer (resultInt a b))) := by
      apply Loops.StmtRun.branch hd
      simpa only [SignedAddCalls.truth_boolean,hdiff,↓reduceIte,resultInt,hdiff] using
        Loops.StmtRun.returnValue (ordinary_eval call s a b)
    exact Loops.StmtRun.sequence (Loops.SeqRun.returned hit) ⟨rfl,(PrimitiveCalls.pop_self _).symm⟩
  | false =>
    have skip1 : Run Header.layout call (.branch differentTest (.returnStmt ordinaryReturn) .skip)
        (frame s a b) (.continuing (frame s a b)) := by
      apply Loops.StmtRun.branch hd
      simpa only [SignedAddCalls.truth_boolean,hdiff,Bool.false_eq_true,↓reduceIte] using Loops.StmtRun.skip (frame s a b)
    cases heq : equal a b with
    | true =>
      have hit : Run Header.layout call (.branch equalTest (.returnStmt (.nat 0)) .skip)
          (frame s a b) (.returned (frame s a b) (integer (resultInt a b))) := by
        apply Loops.StmtRun.branch eqEval
        simpa only [SignedAddCalls.truth_bit,heq,↓reduceIte,resultInt,hdiff,heq,Bool.false_eq_true] using
          Loops.StmtRun.returnValue (show Eval Header.layout call (.nat 0) (frame s a b) (frame s a b) (integer 0) from ⟨4,eval_zero call _⟩)
      exact Loops.StmtRun.sequence (Loops.SeqRun.next skip1 (Loops.SeqRun.returned hit)) ⟨rfl,(PrimitiveCalls.pop_self _).symm⟩
    | false =>
      have skip2 : Run Header.layout call (.branch equalTest (.returnStmt (.nat 0)) .skip)
          (frame s a b) (.continuing (frame s a b)) := by
        apply Loops.StmtRun.branch eqEval
        simpa only [SignedAddCalls.truth_bit,heq,Bool.false_eq_true,↓reduceIte] using Loops.StmtRun.skip (frame s a b)
      cases hlt : less a b with
      | true =>
        have hit : Run Header.layout call (.branch lessTest (.returnStmt lessReturn) .skip)
            (frame s a b) (.returned (frame s a b) (integer (resultInt a b))) := by
          apply Loops.StmtRun.branch ltEval
          simpa only [SignedAddCalls.truth_bit,hlt,↓reduceIte,resultInt,hdiff,heq,hlt,Bool.false_eq_true] using
            Loops.StmtRun.returnValue (less_eval call s a b)
        exact Loops.StmtRun.sequence (Loops.SeqRun.next skip1 (Loops.SeqRun.next skip2 (Loops.SeqRun.returned hit)))
          ⟨rfl,(PrimitiveCalls.pop_self _).symm⟩
      | false =>
        have skip3 : Run Header.layout call (.branch lessTest (.returnStmt lessReturn) .skip)
            (frame s a b) (.continuing (frame s a b)) := by
          apply Loops.StmtRun.branch ltEval
          simpa only [SignedAddCalls.truth_bit,hlt,Bool.false_eq_true,↓reduceIte] using Loops.StmtRun.skip (frame s a b)
        have ret : Eval Header.layout call ordinaryReturn (frame s a b) (frame s a b) (integer (resultInt a b)) := by
          simpa only [resultInt,hdiff,heq,hlt,Bool.false_eq_true,↓reduceIte] using ordinary_eval call s a b
        exact Loops.StmtRun.sequence (Loops.SeqRun.next skip1 (Loops.SeqRun.next skip2
          (Loops.SeqRun.next skip3 (Loops.SeqRun.returned (Loops.StmtRun.returnValue ret)))))
          ⟨rfl,(PrimitiveCalls.pop_self _).symm⟩

theorem sc_closed (code : List Function) (installed : Generated.f_sc∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    {s : State} (a b : Endpoint) (aLive : a.Live s) (bLive : b.Live s) :
    SourceCall Header.layout code 2 "sc" [a.source,b.source] s (integer (resultInt a b)) s := by
  let before := frame s a b
  have eqProof : SourceCall Header.layout code 1 "ne" [.natObject a.slot,.natObject b.slot]
      before (unsigned32 (SignedNegCalls.bit (equal a b))) before := by
    simpa [equal,SignedNegCalls.bit,unsigned32,PrimitiveCalls.u32] using
      HelperCodeAdapters.ne_for_code code neInstalled (s:=before) aLive bLive
  have ltProof : SourceCall Header.layout code 1 "nlt" [.natObject a.slot,.natObject b.slot]
      before (unsigned32 (SignedNegCalls.bit (less a b))) before := by
    simpa [less,SignedNegCalls.bit,unsigned32,PrimitiveCalls.u32] using
      HelperCodeAdapters.nlt_for_code code nltInstalled (s:=before) aLive bLive
  let eqEvent : CallEvents.Event Header.layout code 1 :=
    ⟨"ne",[.natObject a.slot,.natObject b.slot],before,unsigned32 (SignedNegCalls.bit (equal a b)),before,eqProof⟩
  let ltEvent : CallEvents.Event Header.layout code 1 :=
    ⟨"nlt",[.natObject a.slot,.natObject b.slot],before,unsigned32 (SignedNegCalls.bit (less a b)),before,ltProof⟩
  let service := CallEvents.append (CallEvents.one eqEvent) (CallEvents.one ltEvent)
  have eqAnswer : service "ne" [.natObject a.slot,.natObject b.slot] before =
      some (unsigned32 (SignedNegCalls.bit (equal a b)),before) := CallEvents.append_left (CallEvents.one_self eqEvent)
  have ltAnswer : service "nlt" [.natObject a.slot,.natObject b.slot] before =
      some (unsigned32 (SignedNegCalls.bit (less a b)),before) :=
    CallEvents.append_right (CallEvents.one_other eqEvent (by change ("nlt":String)≠"ne"; decide +kernel) _ _) (CallEvents.one_self ltEvent)
  have eqEval : Eval Header.layout service equalTest before before (unsigned32 (SignedNegCalls.bit (equal a b))) :=
    ⟨5,ExpressionTemplates.call_two Header.layout service
      (SignedPairFrames.eval_a_mag service 2 s a b) (SignedPairFrames.eval_b_mag service 2 s a b) eqAnswer⟩
  have ltEval : Eval Header.layout service lessTest before before (unsigned32 (SignedNegCalls.bit (less a b))) :=
    ⟨5,ExpressionTemplates.call_two Header.layout service
      (SignedPairFrames.eval_a_mag service 2 s a b) (SignedPairFrames.eval_b_mag service 2 s a b) ltAnswer⟩
  apply installed_body (f:=Generated.f_sc) (rank:=1) (service:=service) installed
    (fun _ _ _ _ _ h => CallEvents.append_closed
      (fun _ _ _ _ _ h => CallEvents.one_closed eqEvent h)
      (fun _ _ _ _ _ h => CallEvents.one_closed ltEvent h) h)
    (SignedPairFrames.bind a b aLive bLive) (body service s a b eqEval ltEval)
  constructor
  · change castValue Header.layout before 100 "static int" (integer (resultInt a b)) = some (integer (resultInt a b))
    have range : Scalar.InRange ⟨true,32⟩ (resultInt a b) := by
      unfold resultInt
      split_ifs <;> decide +kernel
    change (do let x ← Scalar.cast ⟨true,32⟩ ⟨⟨true,32⟩,resultInt a b⟩; pure (Value.integer x)) = _
    unfold Scalar.cast
    rw [Scalar.make_exact range]
    rfl
  · exact (TwoFrames.pop_frame "S" "a" a.source "S" "b" b.source rfl rfl).symm

end ScopedC.SignedCompareCalls
