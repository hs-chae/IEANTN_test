/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCompareData

namespace ScopedC.RationalCompareCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def leftExpr : Expr := .call (.var "sm") [.field "." (.var "a") "num",
  .call (.var "smake") [.field "." (.var "b") "den",.nat 0]]
def rightExpr : Expr := .call (.var "sm") [.field "." (.var "b") "num",
  .call (.var "smake") [.field "." (.var "a") "den",.nat 0]]

theorem qc_closed (code : List Function) (installed : Generated.f_qc∈code)
    (scInstalled : Generated.f_sc∈code) (smInstalled : Generated.f_sm∈code)
    (nmInstalled : Generated.f_nm∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state) :
    SourceCall Header.layout code 6 "qc" [a.source,b.source] c.state
      (SignedCompareCalls.integer (SignedCompareCalls.resultInt (left l c a b) (right l c a b)))
      (final l c a b).state := by
  let m := middle l c a b
  let f := final l c a b
  let x := left l c a b
  let y := right l c a b
  have mc := middle_context ctx room a b
  have aMiddle : a.Live m.state := input_middle aLive
  have bMiddle : b.Live m.state := input_middle bLive
  have roomM : m.top+2<PoolCalls.capacity := by simpa only [m,top_middle] using room
  have p1 := RationalCrossCalls.make_on_frame code smakeInstalled nzInstalled nuInstalled neInstalled keepInstalled
    ctx (by omega) a b bLive.2
  have p2 := RationalCrossCalls.multiply_on_frame code smInstalled nmInstalled smakeInstalled nzInstalled nuInstalled
    neInstalled keepInstalled ctx (by omega) a b a.numerator aLive.1 bLive.2
  have p3 := RationalCrossCalls.make_on_frame code smakeInstalled nzInstalled nuInstalled neInstalled keepInstalled
    mc (by rw [top_middle];omega) a b aMiddle.2
  have p4 := RationalCrossCalls.multiply_on_frame code smInstalled nmInstalled smakeInstalled nzInstalled nuInstalled
    neInstalled keepInstalled mc roomM a b b.numerator bMiddle.1 aMiddle.2
  have p5 := SignedCompareCalls.sc_closed code scInstalled neInstalled nltInstalled
    (s:=frame f.state a b) x y (left_final l c a b) (right_final l c a b)
  let e1 : CallEvents.Event Header.layout code 5 :=
    ⟨"smake",[.natObject b.denSlot,SignedCompareCalls.integer 0],frame c.state a b,
      (RationalCrossCalls.positive b.denSlot b.denominator).source,
      frame (RationalCrossCalls.c1 l c).state a b,raise_once p1⟩
  let e2 : CallEvents.Event Header.layout code 5 :=
    ⟨"sm",[a.numerator.source,(RationalCrossCalls.positive b.denSlot b.denominator).source],
      frame (RationalCrossCalls.c1 l c).state a b,x.source,frame m.state a b,p2⟩
  let e3 : CallEvents.Event Header.layout code 5 :=
    ⟨"smake",[.natObject a.denSlot,SignedCompareCalls.integer 0],frame m.state a b,
      (RationalCrossCalls.positive a.denSlot a.denominator).source,
      frame (RationalCrossCalls.c1 l m).state a b,raise_once p3⟩
  let e4 : CallEvents.Event Header.layout code 5 :=
    ⟨"sm",[b.numerator.source,(RationalCrossCalls.positive a.denSlot a.denominator).source],
      frame (RationalCrossCalls.c1 l m).state a b,y.source,frame f.state a b,p4⟩
  let e5 : CallEvents.Event Header.layout code 5 :=
    ⟨"sc",[x.source,y.source],frame f.state a b,
      SignedCompareCalls.integer (SignedCompareCalls.resultInt x y),frame f.state a b,
      raise_once (raise_once (raise_once p5))⟩
  let tail4 := CallEvents.append (CallEvents.one e4) (CallEvents.one e5)
  let tail3 := CallEvents.append (CallEvents.one e3) tail4
  let tail2 := CallEvents.append (CallEvents.one e2) tail3
  let service := CallEvents.append (CallEvents.one e1) tail2
  have a1 : service "smake" [.natObject b.denSlot,SignedCompareCalls.integer 0] (frame c.state a b) =
      some ((RationalCrossCalls.positive b.denSlot b.denominator).source,frame (RationalCrossCalls.c1 l c).state a b) :=
    CallEvents.append_left (CallEvents.one_self e1)
  have a2 : service "sm" [a.numerator.source,(RationalCrossCalls.positive b.denSlot b.denominator).source]
      (frame (RationalCrossCalls.c1 l c).state a b) = some (x.source,frame m.state a b) :=
    CallEvents.append_right (CallEvents.one_other e1 (by change ("sm":String)≠"smake";decide +kernel) _ _)
      (CallEvents.append_left (CallEvents.one_self e2))
  have a3 : service "smake" [.natObject a.denSlot,SignedCompareCalls.integer 0] (frame m.state a b) =
      some ((RationalCrossCalls.positive a.denSlot a.denominator).source,frame (RationalCrossCalls.c1 l m).state a b) :=
    CallEvents.append_right (CallEvents.one_before_other e1 (frame_distinct l c a b))
      (CallEvents.append_right (CallEvents.one_other e2 (by change ("smake":String)≠"sm";decide +kernel) _ _)
        (CallEvents.append_left (CallEvents.one_self e3)))
  have framesDifferent : frame (RationalCrossCalls.c1 l m).state a b ≠ frame (RationalCrossCalls.c1 l c).state a b := by
    intro eq
    have h := congrArg (fun s : State => s.nats.values.length) eq
    change (next l m 0).state.nats.values.length = (next l c 0).state.nats.values.length at h
    rw [PoolCursor.size,PoolCursor.size] at h
    have hm := middle_size l c a b
    change m.state.nats.values.length=c.state.nats.values.length+3 at hm
    omega
  have a4 : service "sm" [b.numerator.source,(RationalCrossCalls.positive a.denSlot a.denominator).source]
      (frame (RationalCrossCalls.c1 l m).state a b) = some (y.source,frame f.state a b) :=
    CallEvents.append_right (CallEvents.one_other e1 (by change ("sm":String)≠"smake";decide +kernel) _ _)
      (CallEvents.append_right (CallEvents.one_before_other e2 framesDifferent)
        (CallEvents.append_right (CallEvents.one_other e3 (by change ("sm":String)≠"smake";decide +kernel) _ _)
          (CallEvents.append_left (CallEvents.one_self e4))))
  have a5 : service "sc" [x.source,y.source] (frame f.state a b) =
      some (SignedCompareCalls.integer (SignedCompareCalls.resultInt x y),frame f.state a b) :=
    CallEvents.append_right (CallEvents.one_other e1 (by change ("sc":String)≠"smake";decide +kernel) _ _)
      (CallEvents.append_right (CallEvents.one_other e2 (by change ("sc":String)≠"sm";decide +kernel) _ _)
        (CallEvents.append_right (CallEvents.one_other e3 (by change ("sc":String)≠"smake";decide +kernel) _ _)
          (CallEvents.append_right (CallEvents.one_other e4 (by change ("sc":String)≠"sm";decide +kernel) _ _)
            (CallEvents.one_self e5))))
  have leftEval : evalExpr Header.layout service 7 (frame c.state a b) leftExpr = some (x.source,frame m.state a b) := by
    exact ExpressionTemplates.call_two Header.layout service
      (RationalPairFrames.eval_a_num service 4 c.state a b)
      (ExpressionTemplates.call_two Header.layout service (RationalPairFrames.eval_b_den service 3 c.state a b) (by rfl) a1) a2
  have rightEval : evalExpr Header.layout service 7 (frame m.state a b) rightExpr = some (y.source,frame f.state a b) := by
    exact ExpressionTemplates.call_two Header.layout service
      (RationalPairFrames.eval_b_num service 4 m.state a b)
      (ExpressionTemplates.call_two Header.layout service (RationalPairFrames.eval_a_den service 3 m.state a b) (by rfl) a3) a4
  have expr : Eval Header.layout service (.call (.var "sc") [leftExpr,rightExpr])
      (frame c.state a b) (frame f.state a b) (SignedCompareCalls.integer (SignedCompareCalls.resultInt x y)) :=
    ⟨8,ExpressionTemplates.call_two Header.layout service leftEval rightEval a5⟩
  have shapeF := shape l c a b
  have body : Run Header.layout service Generated.f_qc.body (frame c.state a b)
      (.returned (frame f.state a b) (SignedCompareCalls.integer (SignedCompareCalls.resultInt x y))) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.returned (Loops.StmtRun.returnValue expr))
    refine ⟨rfl,?_⟩
    have len : (frame f.state a b).heap.length=(frame c.state a b).heap.length := by simp [frame,TwoFrames.frame,allocate,f,shapeF.1]
    have env : (frame f.state a b).env=(frame c.state a b).env := by simp [frame,TwoFrames.frame,allocate,f,shapeF.1]
    exact (PoolCalls.pop_same len env).symm
  have closed : ∀ name args before value after, service name args before=some (value,after) →
      SourceCall Header.layout code 5 name args before value after := by
    intro name args before value after h
    exact CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e1 h)
      (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e2 h)
        (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e3 h)
          (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e4 h)
            (fun _ _ _ _ _ h=>CallEvents.one_closed e5 h) h) h) h) h
  apply installed_body (f:=Generated.f_qc) (rank:=5) (service:=service) installed closed
    (RationalPairFrames.bind a b aLive bLive) body
  constructor
  · change castValue Header.layout (frame f.state a b) 100 "static int"
      (SignedCompareCalls.integer (SignedCompareCalls.resultInt x y)) = _
    have range : Scalar.InRange ⟨true,32⟩ (SignedCompareCalls.resultInt x y) := by
      unfold SignedCompareCalls.resultInt
      split_ifs <;> decide +kernel
    change (do let v ← Scalar.cast ⟨true,32⟩ ⟨⟨true,32⟩,SignedCompareCalls.resultInt x y⟩; pure (Value.integer v)) = _
    unfold Scalar.cast
    rw [Scalar.make_exact range]
    rfl
  · exact (TwoFrames.pop_frame "Q" "a" a.source "Q" "b" b.source shapeF.1 shapeF.2).symm

end ScopedC.RationalCompareCalls
