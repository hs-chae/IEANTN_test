/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.RationalUnsignedCall

namespace ScopedC.PoolCursor
open ScopedC.Machine ScopedC.PoolCalls ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Proof metadata for an existing owned pool. A cursor is not an assumed
execution or a trusted application output. Each next state is exactly the
existing actual allocation/keep effect, instantiated by source-body proofs. -/
structure Cursor where
  state : State
  cells : List (Option Value)
  top : Nat
  high : Nat

def Valid (l : PoolLayout) (c : Cursor) : Prop := GenericPoolContext l c.state c.cells c.top c.high

def next (l : PoolLayout) (c : Cursor) (n : Nat) : Cursor := {
  state:=binaryResult l c.state c.cells c.top c.high n
  cells:=c.cells.set c.top (some (.natObject c.state.nats.values.length))
  top:=c.top+1
  high:=max c.high (c.top+1) }

theorem next_valid {l : PoolLayout} {c : Cursor} (n : Nat) (h : Valid l c) (room : c.top<capacity) :
    Valid l (next l c n) := binary_result_context h room

theorem next_borrow (l : PoolLayout) (c : Cursor) (n : Nat) :
    NatArena.Borrow (next l c n).state.nats c.state.nats.values.length n :=
  binary_result_borrow l c.state c.cells c.top c.high n

theorem preserves {l : PoolLayout} {c : Cursor} {n slot m : Nat}
    (live : NatArena.Borrow c.state.nats slot m) :
    NatArena.Borrow (next l c n).state.nats slot m := binary_result_preserves live

theorem nats (l : PoolLayout) (c : Cursor) (n : Nat) :
    (next l c n).state.nats=(NatArena.allocate c.state.nats n).2 := binary_result_nats _ _ _ _ _ _

theorem size (l : PoolLayout) (c : Cursor) (n : Nat) :
    (next l c n).state.nats.values.length=c.state.nats.values.length+1 := by
  rw [nats]
  simp [NatArena.allocate]

theorem shape (l : PoolLayout) (c : Cursor) (n : Nat) :
    (next l c n).state.heap.length=c.state.heap.length ∧ (next l c n).state.env=c.state.env :=
  RationalUnsignedCalls.binary_shape _ _ _ _ _ _

end ScopedC.PoolCursor
