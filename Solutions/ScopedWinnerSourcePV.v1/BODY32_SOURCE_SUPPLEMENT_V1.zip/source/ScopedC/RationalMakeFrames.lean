/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.AllocatedFrames
import ScopedC.DyadicRepresentation

namespace ScopedC.RationalMakeFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def params (s : State) (a : Endpoint) (den : Nat) : State :=
  TwoFrames.frame s "S" "a" a.source "N" "b" (.natObject den)
def gFrame (s : State) (a : Endpoint) (den g : Nat) : State :=
  allocate (params s a den) "N" "g" (some (.natObject g))

theorem params_nats (s : State) (a : Endpoint) (den : Nat) : (params s a den).nats=s.nats := rfl
theorem local_nats (s : State) (a : Endpoint) (den g : Nat) : (gFrame s a den g).nats=s.nats := rfl

theorem bind {s : State} (a : Endpoint) {den d : Nat} (ha : a.Live s) (hd : NatArena.Borrow s.nats den d) :
    bindArgs Header.layout Generated.f_qm.parameters [a.source,.natObject den] s=some (params s a den) :=
  TypedFrames.bind_two Header.layout s "S" "a" "N" "b" a.source (.natObject den) a.source (.natObject den)
    (Endpoint.cast 98 "S" (by decide +kernel) ha)
    (PositiveCasts.cast_N Header.layout _ 99 den d hd)

theorem params_context {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high : Nat}
    (h : GenericPoolContext l s cells top high) (a : Endpoint) (den : Nat) :
    GenericPoolContext l (params s a den) cells top high := TwoFrames.context_frame h _ _ _ _ _ _

theorem local_context {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high : Nat}
    (h : GenericPoolContext l s cells top high) (a : Endpoint) (den g : Nat) :
    GenericPoolContext l (gFrame s a den g) cells top high :=
  AllocatedFrames.context_allocate (params_context h a den) "N" "g" (.natObject g)

theorem binary_params {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high n : Nat}
    (h : GenericPoolContext l s cells top high) (a : Endpoint) (den : Nat) :
    binaryResult l (params s a den) cells top high n=params (binaryResult l s cells top high n) a den :=
  binary_result_two_frame h _ _ _ _ _ _

theorem binary_local {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high n : Nat}
    (h : GenericPoolContext l s cells top high) (a : Endpoint) (den g : Nat) :
    binaryResult l (gFrame s a den g) cells top high n=gFrame (binaryResult l s cells top high n) a den g := by
  unfold gFrame
  rw [AllocatedFrames.binary_allocate (params_context h a den),binary_params h]

set_option maxRecDepth 100000 in
 theorem eval_param_a (call : Call) (fuel : Nat) (s : State) (a : Endpoint) (den : Nat) :
    evalExpr Header.layout call (fuel+1) (params s a den) (.var "a")=some (a.source,params s a den) := by
  simp [evalExpr,getVar,params,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_param_b (call : Call) (fuel : Nat) (s : State) (a : Endpoint) (den : Nat) :
    evalExpr Header.layout call (fuel+1) (params s a den) (.var "b")=some (.natObject den,params s a den) := by
  simp [evalExpr,getVar,params,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized]

theorem eval_local_a (call : Call) (fuel : Nat) (s : State) (a : Endpoint) (den g : Nat) :
    evalExpr Header.layout call (fuel+1) (gFrame s a den g) (.var "a")=some (a.source,gFrame s a den g) := by
  simp [evalExpr,getVar,gFrame,params,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_local_b (call : Call) (fuel : Nat) (s : State) (a : Endpoint) (den g : Nat) :
    evalExpr Header.layout call (fuel+1) (gFrame s a den g) (.var "b")=some (.natObject den,gFrame s a den g) := by
  simp [evalExpr,getVar,gFrame,params,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized]

theorem eval_local_g (call : Call) (fuel : Nat) (s : State) (a : Endpoint) (den g : Nat) :
    evalExpr Header.layout call (fuel+1) (gFrame s a den g) (.var "g")=some (.natObject g,gFrame s a den g) :=
  TypedFrames.allocate_eval Header.layout call fuel (params s a den) "N" "g" (.natObject g)
    rfl (by decide) (by decide) (by decide) (by decide)

theorem eval_param_mag (call : Call) (fuel : Nat) (s : State) (a : Endpoint) (den : Nat) :
    evalExpr Header.layout call (fuel+2) (params s a den) (.field "." (.var "a") "mag")=
      some (.natObject a.slot,params s a den) := by
  apply ExpressionTemplates.field Header.layout call (eval_param_a call fuel s a den)
  rfl

theorem eval_local_mag (call : Call) (fuel : Nat) (s : State) (a : Endpoint) (den g : Nat) :
    evalExpr Header.layout call (fuel+2) (gFrame s a den g) (.field "." (.var "a") "mag")=
      some (.natObject a.slot,gFrame s a den g) := by
  apply ExpressionTemplates.field Header.layout call (eval_local_a call fuel s a den g)
  rfl

theorem eval_local_neg (call : Call) (fuel : Nat) (s : State) (a : Endpoint) (den g : Nat) :
    evalExpr Header.layout call (fuel+2) (gFrame s a den g) (.field "." (.var "a") "neg")=
      some (unsigned32 (SignedNegCalls.bit a.negative),gFrame s a den g) := by
  apply ExpressionTemplates.field Header.layout call (eval_local_a call fuel s a den g)
  rfl

end ScopedC.RationalMakeFrames
