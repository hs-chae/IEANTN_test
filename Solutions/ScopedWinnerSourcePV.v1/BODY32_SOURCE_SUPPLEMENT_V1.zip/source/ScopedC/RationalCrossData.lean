/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPairFrames

namespace ScopedC.RationalCrossCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c1 (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := next l c 0
def c2 (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Cursor := next l (c1 l c) (a.magnitude*d)
def c3 (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Cursor := next l (c2 l c a d) 0
def positive (slot d : Nat) : Endpoint := ⟨slot,d,false⟩
def result (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Endpoint :=
  ⟨(c1 l c).state.nats.values.length,a.magnitude*d,if a.magnitude*d=0 then false else a.negative⟩

theorem contexts {l : PoolCalls.PoolLayout} {c : Cursor} (h : Valid l c)
    (room : c.top+2 < PoolCalls.capacity) (a : Endpoint) (d : Nat) :
    Valid l (c1 l c) ∧ Valid l (c2 l c a d) ∧ Valid l (c3 l c a d) := by
  have h1 := next_valid 0 h (by omega)
  have h2 := next_valid (a.magnitude*d) h1 (by simpa only [c1,next] using (show c.top+1<PoolCalls.capacity by omega))
  have h3 := next_valid 0 h2 (by simpa only [c2,c1,next] using room)
  exact ⟨h1,h2,h3⟩

theorem result_live (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    (result l c a d).Live (c3 l c a d).state := by
  exact preserves (next_borrow l (c1 l c) (a.magnitude*d))

theorem source_result (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (slot d : Nat) :
    (result l c a d).source = SignedMultiplyCalls.result (c1 l c).state a (positive slot d) := by
  by_cases hz : a.magnitude*d=0 <;>
    simp [result,Endpoint.source,SignedMultiplyCalls.result,SignedMultiplyCalls.resultSign,positive,hz,SignedNegCalls.bit]

theorem shape (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    (c3 l c a d).state.heap.length=c.state.heap.length ∧ (c3 l c a d).state.env=c.state.env := by
  have s1 := PoolCursor.shape l c 0
  have s2 := PoolCursor.shape l (c1 l c) (a.magnitude*d)
  have s3 := PoolCursor.shape l (c2 l c a d) 0
  exact ⟨s3.1.trans (s2.1.trans s1.1),s3.2.trans (s2.2.trans s1.2)⟩

theorem zero_normalized (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    SignedNormalization.ZeroNormalized (result l c a d).mathematical := by
  intro zero
  change a.magnitude*d=0 at zero
  simp [result,Endpoint.mathematical,zero]

theorem value (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    (result l c a d).mathematical.value = a.mathematical.value*(d:Int) := by
  by_cases zero : a.magnitude*d=0
  · have z : a.magnitude=0 ∨ d=0 := Nat.mul_eq_zero.mp zero
    rcases z with h | h <;> simp [result,Endpoint.mathematical,ScopedNumerical.Signed.value,h]
  · cases hn : a.negative <;> simp [result,Endpoint.mathematical,ScopedNumerical.Signed.value,zero,hn,Int.natCast_mul]

end ScopedC.RationalCrossCalls
