/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.RationalMakeFrames
import ScopedNumerical.RatArithmetic

namespace ScopedC.RationalMakeCalls
open ScopedC.Machine ScopedC.NatWrapperCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c0 (s : State) (cells : List (Option Value)) (top high : Nat) : Cursor := ⟨s,cells,top,high⟩
def c1 (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := next l c 0
def divisor (a : Endpoint) (d : Nat) : Nat := a.magnitude.gcd d
def c2 (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Cursor := next l (c1 l c) (divisor a d)
def c3 (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Cursor := next l (c2 l c a d) (a.magnitude/divisor a d)
def c4 (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Cursor := next l (c3 l c a d) 0
def c5 (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Cursor := next l (c4 l c a d) (d/divisor a d)

def gSlot (l : PoolCalls.PoolLayout) (c : Cursor) : Nat := (c1 l c).state.nats.values.length
def numSlot (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Nat := (c2 l c a d).state.nats.values.length
def denSlot (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Nat := (c4 l c a d).state.nats.values.length

def sign (a : Endpoint) (d : Nat) : Nat :=
  if a.magnitude/divisor a d==0 then 0 else SignedNegCalls.bit a.negative

def result (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) : Value :=
  RecordCasts.rational (numSlot l c a d) (sign a d) (denSlot l c a d)

theorem divisor_positive (a : Endpoint) {d : Nat} (hd : 0<d) : 0<divisor a d :=
  Nat.gcd_pos_of_pos_right _ hd

theorem contexts {l : PoolCalls.PoolLayout} {c : Cursor} (a : Endpoint) (d : Nat)
    (hc : Valid l c) (room : c.top+4<PoolCalls.capacity) :
    Valid l (c1 l c) ∧ Valid l (c2 l c a d) ∧ Valid l (c3 l c a d) ∧
      Valid l (c4 l c a d) ∧ Valid l (c5 l c a d) := by
  have r0 : c.top<PoolCalls.capacity := by omega
  have r1 : (c1 l c).top<PoolCalls.capacity := by change c.top+1<PoolCalls.capacity; omega
  have r2 : (c2 l c a d).top<PoolCalls.capacity := by change c.top+1+1<PoolCalls.capacity; omega
  have r3 : (c3 l c a d).top<PoolCalls.capacity := by change c.top+1+1+1<PoolCalls.capacity; omega
  have r4 : (c4 l c a d).top<PoolCalls.capacity := by change c.top+1+1+1+1<PoolCalls.capacity; omega
  have h1 := next_valid 0 hc r0
  have h2 := next_valid (divisor a d) h1 r1
  have h3 := next_valid (a.magnitude/divisor a d) h2 r2
  have h4 := next_valid 0 h3 r3
  exact ⟨h1,h2,h3,h4,next_valid (d/divisor a d) h4 r4⟩

theorem gcd_live (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    NatArena.Borrow (c2 l c a d).state.nats (gSlot l c) (divisor a d) := next_borrow _ _ _

theorem numerator_live (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    NatArena.Borrow (c5 l c a d).state.nats (numSlot l c a d) (a.magnitude/divisor a d) :=
  preserves (preserves (next_borrow _ _ _))

theorem denominator_live (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    NatArena.Borrow (c5 l c a d).state.nats (denSlot l c a d) (d/divisor a d) := next_borrow _ _ _

/-- Exact source fields, including canonical gcd information used by log2
reduction selection; value-only rational equality is deliberately insufficient. -/
theorem decoded_result (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) {d : Nat} (hd : 0<d) :
    NumericRepresentation.rational (c5 l c a d).state (result l c a d)=
      some (Rational.normalize a.mathematical d) := by
  have positive : 0<d/divisor a d := (Rational.normalize_normalized a.mathematical d (by omega)).1
  have norm : NumericRepresentation.signed (c5 l c a d).state
      (SignedValues.value (numSlot l c a d) (sign a d))=
      some (Signed.make (a.magnitude/divisor a d) a.negative) := by
    by_cases zero : a.magnitude/divisor a d=0
    · simpa [sign,Signed.make,SignedNegCalls.bit,zero] using
        NumericRepresentation.signed_value false (numerator_live l c a d)
    · simpa [sign,Signed.make,zero] using
        NumericRepresentation.signed_value a.negative (numerator_live l c a d)
  simp only [NumericRepresentation.rational,result,RecordCasts.rational]
  rw [norm]
  simp only [NatArena.read_of_borrow (denominator_live l c a d),bind,Option.bind]
  rw [if_pos positive]
  rfl

end ScopedC.RationalMakeCalls
