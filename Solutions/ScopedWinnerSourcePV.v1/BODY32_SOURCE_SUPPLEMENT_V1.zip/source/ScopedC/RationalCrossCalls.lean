/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCrossData

namespace ScopedC.RationalCrossCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem make_on_frame (code : List Function)
    (smakeInstalled : Generated.f_smake∈code) (nzInstalled : Generated.f_nz∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top<PoolCalls.capacity) (a b : Input) {slot d : Nat}
    (live : NatArena.Borrow c.state.nats slot d) :
    SourceCall Header.layout code 4 "smake" [.natObject slot,SignedCompareCalls.integer 0]
      (frame c.state a b) (positive slot d).source (frame (c1 l c).state a b) := by
  have ctxFrame := TwoFrames.context_frame ctx "Q" "a" a.source "Q" "b" b.source
  have h := SignedCalls.smake_call (input:=SignedCompareCalls.integer 0) code smakeInstalled nzInstalled nuInstalled
    neInstalled keepInstalled ctxFrame room live (n:=d) (neg:=0) (by decide +kernel) (by rfl)
  have final : binaryResult l (frame c.state a b) c.cells c.top c.high 0 = frame (c1 l c).state a b :=
    RationalPairFrames.cursor_frame ctx a b 0
  change SourceCall Header.layout code 4 "smake" [.natObject slot,SignedCompareCalls.integer 0]
    (frame c.state a b) (SignedValues.value slot 0) (frame (c1 l c).state a b)
  change SourceCall Header.layout code 4 "smake" [.natObject slot,SignedCompareCalls.integer 0]
    (frame c.state a b) (SignedValues.value slot (if d==0 then 0 else 0))
    (binaryResult l (frame c.state a b) c.cells c.top c.high 0) at h
  rw [final] at h
  simpa only [ite_self] using h

theorem multiply_on_frame (code : List Function)
    (smInstalled : Generated.f_sm∈code) (nmInstalled : Generated.f_nm∈code)
    (smakeInstalled : Generated.f_smake∈code) (nzInstalled : Generated.f_nz∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) (a b : Input) (n : Endpoint) {slot d : Nat}
    (nLive : n.Live c.state) (dLive : NatArena.Borrow c.state.nats slot d) :
    SourceCall Header.layout code 5 "sm" [n.source,(positive slot d).source]
      (frame (c1 l c).state a b) (result l c n d).source (frame (c3 l c n d).state a b) := by
  have h1 := (contexts ctx room n d).1
  have h2 := (contexts ctx room n d).2.1
  have nLive1 : n.Live (c1 l c).state := PoolCursor.preserves nLive
  have dLive1 : (positive slot d).Live (c1 l c).state := PoolCursor.preserves dLive
  have h := SignedMultiplyCalls.sm_closed code smInstalled nmInstalled smakeInstalled nzInstalled nuInstalled
    neInstalled keepInstalled (s:=frame (c1 l c).state a b) (l:=l)
    (cells:=(c1 l c).cells) (top:=(c1 l c).top) (high:=(c1 l c).high) n (positive slot d) nLive1 dLive1
    (TwoFrames.context_frame h1 "Q" "a" a.source "Q" "b" b.source) (by simpa only [c1,next] using room)
  have final : SignedMultiplyCalls.smResult l (frame (c1 l c).state a b)
      (c1 l c).cells (c1 l c).top (c1 l c).high n (positive slot d) = frame (c3 l c n d).state a b := by
    change binaryResult l
      (binaryResult l (frame (c1 l c).state a b) (c1 l c).cells (c1 l c).top (c1 l c).high (n.magnitude*d))
      ((c1 l c).cells.set (c1 l c).top (some (.natObject (c1 l c).state.nats.values.length)))
      ((c1 l c).top+1) (max (c1 l c).high ((c1 l c).top+1)) 0 = _
    rw [RationalPairFrames.cursor_frame h1 a b (n.magnitude*d)]
    exact RationalPairFrames.cursor_frame h2 a b 0
  rw [final] at h
  change SourceCall Header.layout code 5 "sm" [n.source,(positive slot d).source]
      (frame (c1 l c).state a b) (result l c n d).source (frame (c3 l c n d).state a b)
  rw [source_result l c n slot d]
  exact h

end ScopedC.RationalCrossCalls
