/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.RationalMakeCalls

namespace ScopedC.RationalMakeCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.RationalMakeFrames (params gFrame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def gInitializer : Expr := .call (.var "ng") [.field "." (.var "a") "mag",.var "b"]
def rInitializer : Expr := .record [
  .call (.var "smake") [.call (.var "nd") [.field "." (.var "a") "mag",.var "g"],.field "." (.var "a") "neg"],
  .call (.var "nd") [.var "b",.var "g"]]

theorem qm_closed (code : List Function) (installed : Generated.f_qm∈code)
    (nzInstalled : Generated.f_nz∈code) (ngInstalled : Generated.f_ng∈code)
    (ndInstalled : Generated.f_nd∈code) (smakeInstalled : Generated.f_smake∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (a : Endpoint) {den d : Nat}
    (aLive : a.Live c.state) (denLive : NatArena.Borrow c.state.nats den d) (positive : 0<d)
    (context : Valid l c) (room : c.top+4<PoolCalls.capacity) :
    SourceCall Header.layout code 5 "qm" [a.source,.natObject den] c.state
      (result l c a d) (c5 l c a d).state := by
  let p0 := params c.state a den
  let p1 := params (c1 l c).state a den
  let p2 := params (c2 l c a d).state a den
  let s2 := gFrame (c2 l c a d).state a den (gSlot l c)
  let s3 := gFrame (c3 l c a d).state a den (gSlot l c)
  let s4 := gFrame (c4 l c a d).state a den (gSlot l c)
  let s5 := gFrame (c5 l c a d).state a den (gSlot l c)
  let p5 := params (c5 l c a d).state a den
  let out := result l c a d
  let outNum := SignedValues.value (numSlot l c a d) (sign a d)
  have lower := lower_calls code nzInstalled ngInstalled ndInstalled smakeInstalled nuInstalled neInstalled
    keepInstalled a aLive denLive positive context room
  let nzEvent : CallEvents.Event Header.layout code 4 :=
    ⟨"nz",[.natObject den],p0,PrimitiveCalls.u32 false,p1,raise_once lower.1⟩
  let ngEvent : CallEvents.Event Header.layout code 4 :=
    ⟨"ng",[.natObject a.slot,.natObject den],p1,.natObject (gSlot l c),p2,raise_once (raise_once lower.2.1)⟩
  let numEvent : CallEvents.Event Header.layout code 4 :=
    ⟨"nd",[.natObject a.slot,.natObject (gSlot l c)],s2,.natObject (numSlot l c a d),s3,
      raise_once (raise_once lower.2.2.1)⟩
  let makeEvent : CallEvents.Event Header.layout code 4 :=
    ⟨"smake",[.natObject (numSlot l c a d),unsigned32 (SignedNegCalls.bit a.negative)],s3,outNum,s4,lower.2.2.2.1⟩
  let denEvent : CallEvents.Event Header.layout code 4 :=
    ⟨"nd",[.natObject den,.natObject (gSlot l c)],s4,.natObject (denSlot l c a d),s5,
      raise_once (raise_once lower.2.2.2.2)⟩
  let service := CallEvents.append (CallEvents.one nzEvent) (CallEvents.append (CallEvents.one ngEvent)
    (CallEvents.append (CallEvents.one numEvent) (CallEvents.append (CallEvents.one makeEvent) (CallEvents.one denEvent))))
  have hnz : service "nz" [.natObject den] p0=some (PrimitiveCalls.u32 false,p1) :=
    CallEvents.append_left (CallEvents.one_self nzEvent)
  have hng : service "ng" [.natObject a.slot,.natObject den] p1=some (.natObject (gSlot l c),p2) :=
    CallEvents.append_right (CallEvents.one_other nzEvent (by change ("ng":String)≠"nz"; decide) _ _)
      (CallEvents.append_left (CallEvents.one_self ngEvent))
  have hnum : service "nd" [.natObject a.slot,.natObject (gSlot l c)] s2=some (.natObject (numSlot l c a d),s3) :=
    CallEvents.append_right (CallEvents.one_other nzEvent (by change ("nd":String)≠"nz"; decide) _ _)
      (CallEvents.append_right (CallEvents.one_other ngEvent (by change ("nd":String)≠"ng"; decide) _ _)
        (CallEvents.append_left (CallEvents.one_self numEvent)))
  have hmake : service "smake" [.natObject (numSlot l c a d),unsigned32 (SignedNegCalls.bit a.negative)] s3=some (outNum,s4) :=
    CallEvents.append_right (CallEvents.one_other nzEvent (by change ("smake":String)≠"nz"; decide) _ _)
      (CallEvents.append_right (CallEvents.one_other ngEvent (by change ("smake":String)≠"ng"; decide) _ _)
        (CallEvents.append_right (CallEvents.one_other numEvent (by change ("smake":String)≠"nd"; decide) _ _)
          (CallEvents.append_left (CallEvents.one_self makeEvent))))
  have length2 : (c4 l c a d).state.nats.values.length=(c2 l c a d).state.nats.values.length+1+1 := by
    simp only [c4,c3,PoolCursor.size]
  have distinct : s4≠s2 := by
    intro eq
    have sizes := congrArg (fun s : State => s.nats.values.length) eq
    simp only [s4,s2,RationalMakeFrames.local_nats] at sizes
    omega
  have noNum : CallEvents.one numEvent "nd" [.natObject den,.natObject (gSlot l c)] s4=none := by
    simp [CallEvents.one,numEvent,distinct]
  have hden : service "nd" [.natObject den,.natObject (gSlot l c)] s4=some (.natObject (denSlot l c a d),s5) :=
    CallEvents.append_right (CallEvents.one_other nzEvent (by change ("nd":String)≠"nz"; decide) _ _)
      (CallEvents.append_right (CallEvents.one_other ngEvent (by change ("nd":String)≠"ng"; decide) _ _)
        (CallEvents.append_right noNum (CallEvents.append_right
          (CallEvents.one_other makeEvent (by change ("nd":String)≠"smake"; decide) _ _) (CallEvents.one_self denEvent))))
  have closed : ∀ name args before value after,service name args before=some (value,after) →
      SourceCall Header.layout code 4 name args before value after := by
    intro name args before value after h
    exact CallEvents.append_closed (fun _ _ _ _ _ h => CallEvents.one_closed nzEvent h)
      (fun _ _ _ _ _ h => CallEvents.append_closed (fun _ _ _ _ _ h => CallEvents.one_closed ngEvent h)
        (fun _ _ _ _ _ h => CallEvents.append_closed (fun _ _ _ _ _ h => CallEvents.one_closed numEvent h)
          (fun _ _ _ _ _ h => CallEvents.append_closed (fun _ _ _ _ _ h => CallEvents.one_closed makeEvent h)
            (fun _ _ _ _ _ h => CallEvents.one_closed denEvent h) h) h) h) h
  have testNZ : Eval Header.layout service (.call (.var "nz") [.var "b"]) p0 p1 (PrimitiveCalls.u32 false) :=
    ⟨4,ExpressionTemplates.call_one Header.layout service (RationalMakeFrames.eval_param_b service 2 c.state a den) hnz⟩
  have branchNZ : Run Header.layout service
      (.branch (.call (.var "nz") [.var "b"]) (.eval (.call (.var "fail") [])) .skip) p0 (.continuing p1) := by
    apply Loops.StmtRun.branch testNZ
    change Run Header.layout service .skip p1 (.continuing p1)
    exact Loops.StmtRun.skip p1
  have evalG : evalExpr Header.layout service 1000 p1 gInitializer=some (.natObject (gSlot l c),p2) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalMakeFrames.eval_param_mag service 997 (c1 l c).state a den)
      (RationalMakeFrames.eval_param_b service 998 (c1 l c).state a den) hng
  have castG : castValue Header.layout p2 100 "N" (.natObject (gSlot l c))=some (.natObject (gSlot l c)) :=
    PositiveCasts.cast_N Header.layout p2 99 _ _ (gcd_live l c a d)
  have declG : Declare Header.layout service
      [{type:="N",name:="g",value:=some gInitializer,arrayExtent:=none}] p1 s2 := by
    simp [Declare,declarations,List.foldlM,evalG,castG,s2,p2,RationalMakeFrames.gFrame]
  have evalNum : evalExpr Header.layout service 998 s2
      (.call (.var "nd") [.field "." (.var "a") "mag",.var "g"])=some (.natObject (numSlot l c a d),s3) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalMakeFrames.eval_local_mag service 995 (c2 l c a d).state a den (gSlot l c))
      (RationalMakeFrames.eval_local_g service 996 (c2 l c a d).state a den (gSlot l c)) hnum
  have evalMake : evalExpr Header.layout service 999 s2
      (.call (.var "smake") [.call (.var "nd") [.field "." (.var "a") "mag",.var "g"],.field "." (.var "a") "neg"])=
      some (outNum,s4) :=
    ExpressionTemplates.call_two Header.layout service evalNum
      (RationalMakeFrames.eval_local_neg service 996 (c3 l c a d).state a den (gSlot l c)) hmake
  have evalDen : evalExpr Header.layout service 999 s4 (.call (.var "nd") [.var "b",.var "g"])=
      some (.natObject (denSlot l c a d),s5) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalMakeFrames.eval_local_b service 997 (c4 l c a d).state a den (gSlot l c))
      (RationalMakeFrames.eval_local_g service 997 (c4 l c a d).state a den (gSlot l c)) hden
  have evalR : evalExpr Header.layout service 1000 s2 rInitializer=
      some (.aggregate [outNum,.natObject (denSlot l c a d)],s5) :=
    ExpressionTemplates.record_two Header.layout service evalMake evalDen
  have signBound : sign a d<2^32 := by unfold sign; split; decide; exact SignedNegCalls.bit_bound _
  have castR : castValue Header.layout s5 100 "Q" (.aggregate [outNum,.natObject (denSlot l c a d)])=some out :=
    RecordCasts.rational_aggregate s5 97 (numerator_live l c a d) (denominator_live l c a d) signBound
  have declR : Declare Header.layout service
      [{type:="Q",name:="r",value:=some rInitializer,arrayExtent:=none}] s2 (allocate s5 "Q" "r" (some out)) := by
    simp [Declare,declarations,List.foldlM,evalR,castR]
  have retR : Eval Header.layout service (.var "r") (allocate s5 "Q" "r" (some out))
      (allocate s5 "Q" "r" (some out)) out :=
    ⟨2,TypedFrames.allocate_eval Header.layout service 1 s5 "Q" "r" out rfl (by decide) (by decide) (by decide) (by decide)⟩
  have sh1 := PoolCursor.shape l c 0
  have sh2 := PoolCursor.shape l (c1 l c) (divisor a d)
  have sh3 := PoolCursor.shape l (c2 l c a d) (a.magnitude/divisor a d)
  have sh4 := PoolCursor.shape l (c3 l c a d) 0
  have sh5 := PoolCursor.shape l (c4 l c a d) (d/divisor a d)
  have finalShape : (c5 l c a d).state.heap.length=c.state.heap.length ∧ (c5 l c a d).state.env=c.state.env :=
    ⟨sh5.1.trans (sh4.1.trans (sh3.1.trans (sh2.1.trans sh1.1))),
      sh5.2.trans (sh4.2.trans (sh3.2.trans (sh2.2.trans sh1.2)))⟩
  have paramLength : p5.heap.length=p0.heap.length := by
    simpa only [p5,p0,params,RationalMakeFrames.params,TwoFrames.frame,allocate,List.length_append,List.length_singleton]
      using congrArg (fun n => n+1+1) finalShape.1
  have paramEnv : p5.env=p0.env := by
    simp only [p5,p0,params,RationalMakeFrames.params,TwoFrames.frame,allocate,List.length_append,List.length_singleton,finalShape.1]
  have sourceBody : Run Header.layout service Generated.f_qm.body p0 (.returned p5 out) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next branchNZ (Loops.SeqRun.next (Loops.StmtRun.declare declG)
      (Loops.SeqRun.next (Loops.StmtRun.declare declR) (Loops.SeqRun.returned (Loops.StmtRun.returnValue retR)))))
    exact ⟨rfl,(AllocatedFrames.pop_two "N" "g" (.natObject (gSlot l c)) "Q" "r" out paramLength paramEnv).symm⟩
  apply installed_body (f:=Generated.f_qm) (rank:=4) (service:=service) installed closed
    (RationalMakeFrames.bind a aLive denLive) sourceBody
  exact ⟨RecordCasts.rational_record p5 97 "static Q" (by decide +kernel)
    (numerator_live l c a d) (denominator_live l c a d) signBound,
    (TwoFrames.pop_frame "S" "a" a.source "N" "b" (.natObject den) finalShape.1 finalShape.2).symm⟩

end ScopedC.RationalMakeCalls
