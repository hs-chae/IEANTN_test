/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSelectBody

namespace ScopedC.NumericRationalSelectRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.NumericRationalCompareRefinement
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000


theorem compare_le (x y : Rat) : compareRat x y ≤ 0 ↔ x ≤ y := by
  unfold compareRat
  by_cases hxy : x < y
  · rw [if_pos hxy]
    exact iff_of_true (by decide +kernel) hxy.le
  · rw [if_neg hxy]
    by_cases he : x = y
    · rw [if_pos he]
      exact iff_of_true (by decide +kernel) he.le
    · rw [if_neg he]
      exact iff_of_false (by decide +kernel) (fun h => he (le_antisymm h (le_of_not_gt hxy)))


theorem pick_le (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    RationalSelectCalls.pick "<=" (RationalCompareCalls.left l c a b) (RationalCompareCalls.right l c a b) =
      decide (a.mathematical.value≤b.mathematical.value) := by
  change decide (SignedCompareCalls.resultInt (RationalCompareCalls.left l c a b) (RationalCompareCalls.right l c a b)≤0)=_
  simp only [result_correct l c a b ha hb,compare_le]


theorem minimum_value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    (RationalSelectCalls.selected false "<=" l c a b).mathematical.value = min a.mathematical.value b.mathematical.value := by
  unfold RationalSelectCalls.selected
  rw [pick_le l c a b ha hb]
  by_cases h : a.mathematical.value≤b.mathematical.value
  · simp only [h,decide_true,↓reduceIte]
    exact (min_eq_left h).symm
  · simp only [h,decide_false,Bool.false_eq_true,↓reduceIte]
    exact (min_eq_right (le_of_not_ge h)).symm


theorem maximum_value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    (RationalSelectCalls.selected true "<=" l c a b).mathematical.value = max a.mathematical.value b.mathematical.value := by
  unfold RationalSelectCalls.selected
  rw [pick_le l c a b ha hb]
  by_cases h : a.mathematical.value≤b.mathematical.value
  · simp only [h,decide_true,↓reduceIte]
    exact (max_eq_right h).symm
  · simp only [h,decide_false,Bool.false_eq_true,↓reduceIte]
    exact (max_eq_left (le_of_not_ge h)).symm


theorem selected_decoded {l : PoolCalls.PoolLayout} {c : Cursor} (flip : Bool)
    (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    NumericRepresentation.rational (RationalCompareCalls.final l c a b).state
      (RationalSelectCalls.selected flip "<=" l c a b).source =
        some (RationalSelectCalls.selected flip "<=" l c a b).mathematical := by
  have choices : RationalSelectCalls.selected flip "<=" l c a b=a ∨ RationalSelectCalls.selected flip "<=" l c a b=b := by
    unfold RationalSelectCalls.selected
    split <;> split <;> simp
  rcases choices with hs | hs
  · rw [hs]
    exact Input.decoded (RationalSelectCalls.input_final (a:=a) (b:=b) aLive) ha
  · rw [hs]
    exact Input.decoded (RationalSelectCalls.input_final (a:=a) (b:=b) bLive) hb


theorem qmin_math (code : List Function) (installed : Generated.f_qmin∈code)
    (qcInstalled : Generated.f_qc∈code) (scInstalled : Generated.f_sc∈code) (smInstalled : Generated.f_sm∈code)
    (nmInstalled : Generated.f_nm∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    SourceCall Header.layout code 7 "qmin" [a.source,b.source] c.state
      (RationalSelectCalls.selected false "<=" l c a b).source (RationalCompareCalls.final l c a b).state ∧
    NumericRepresentation.rational (RationalCompareCalls.final l c a b).state
      (RationalSelectCalls.selected false "<=" l c a b).source = some (RationalSelectCalls.selected false "<=" l c a b).mathematical ∧
    (RationalSelectCalls.selected false "<=" l c a b).mathematical.value = min a.mathematical.value b.mathematical.value :=
  ⟨RationalSelectCalls.qmin_closed code installed qcInstalled scInstalled smInstalled nmInstalled smakeInstalled
    nzInstalled nuInstalled neInstalled nltInstalled keepInstalled ctx room a b aLive bLive,
    selected_decoded false a b aLive bLive ha hb,minimum_value l c a b ha hb⟩


theorem qmax_math (code : List Function) (installed : Generated.f_qmax∈code)
    (qcInstalled : Generated.f_qc∈code) (scInstalled : Generated.f_sc∈code) (smInstalled : Generated.f_sm∈code)
    (nmInstalled : Generated.f_nm∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    SourceCall Header.layout code 7 "qmax" [a.source,b.source] c.state
      (RationalSelectCalls.selected true "<=" l c a b).source (RationalCompareCalls.final l c a b).state ∧
    NumericRepresentation.rational (RationalCompareCalls.final l c a b).state
      (RationalSelectCalls.selected true "<=" l c a b).source = some (RationalSelectCalls.selected true "<=" l c a b).mathematical ∧
    (RationalSelectCalls.selected true "<=" l c a b).mathematical.value = max a.mathematical.value b.mathematical.value :=
  ⟨RationalSelectCalls.qmax_closed code installed qcInstalled scInstalled smInstalled nmInstalled smakeInstalled
    nzInstalled nuInstalled neInstalled nltInstalled keepInstalled ctx room a b aLive bLive,
    selected_decoded true a b aLive bLive ha hb,maximum_value l c a b ha hb⟩

end ScopedC.NumericRationalSelectRefinement
