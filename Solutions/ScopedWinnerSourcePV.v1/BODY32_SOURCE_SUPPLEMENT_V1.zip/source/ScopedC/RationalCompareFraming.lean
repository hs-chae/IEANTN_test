/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalCompareRefinement
import ScopedC.CursorFrames

namespace ScopedC.RationalCompareFraming
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.CursorFrames
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def steps (a b : Input) : List Nat :=
  [0,a.numerator.magnitude*b.denominator,0,0,b.numerator.magnitude*a.denominator,0]

theorem final_eq_advance (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    RationalCompareCalls.final l c a b = advance l c (steps a b) := rfl

theorem middle_framed {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input)
    (ta na : String) (va : Value) (tb nb : String) (vb : Value) :
    RationalCompareCalls.middle l (framed c ta na va tb nb vb) a b =
      framed (RationalCompareCalls.middle l c a b) ta na va tb nb vb := by
  exact advance_framed ctx [0,a.numerator.magnitude*b.denominator,0] (by simp;omega) ta na va tb nb vb

theorem final_framed {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input)
    (ta na : String) (va : Value) (tb nb : String) (vb : Value) :
    RationalCompareCalls.final l (framed c ta na va tb nb vb) a b =
      framed (RationalCompareCalls.final l c a b) ta na va tb nb vb := by
  rw [final_eq_advance,final_eq_advance]
  exact advance_framed ctx (steps a b) (by simp [steps];omega) ta na va tb nb vb

theorem cross_framed {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (ta na : String) (va : Value) (tb nb : String) (vb : Value)
    (n : DyadicRepresentation.Endpoint) (d : Nat) :
    RationalCrossCalls.result l (framed c ta na va tb nb vb) n d = RationalCrossCalls.result l c n d := by
  unfold RationalCrossCalls.result RationalCrossCalls.c1
  rw [next_framed ctx ta na va tb nb vb 0]
  rfl

theorem left_framed {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a b : Input) (ta na : String) (va : Value) (tb nb : String) (vb : Value) :
    RationalCompareCalls.left l (framed c ta na va tb nb vb) a b = RationalCompareCalls.left l c a b :=
  cross_framed ctx ta na va tb nb vb a.numerator b.denominator

theorem right_framed {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input)
    (ta na : String) (va : Value) (tb nb : String) (vb : Value) :
    RationalCompareCalls.right l (framed c ta na va tb nb vb) a b = RationalCompareCalls.right l c a b := by
  unfold RationalCompareCalls.right
  rw [middle_framed ctx room a b ta na va tb nb vb]
  exact cross_framed (RationalCompareCalls.middle_context ctx room a b) ta na va tb nb vb b.numerator a.denominator

theorem qc_on_frame (code : List Function) (installed : Generated.f_qc∈code)
    (scInstalled : Generated.f_sc∈code) (smInstalled : Generated.f_sm∈code)
    (nmInstalled : Generated.f_nm∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state) :
    SourceCall Header.layout code 6 "qc" [a.source,b.source] (RationalPairFrames.frame c.state a b)
      (SignedCompareCalls.integer (SignedCompareCalls.resultInt (RationalCompareCalls.left l c a b) (RationalCompareCalls.right l c a b)))
      (RationalPairFrames.frame (RationalCompareCalls.final l c a b).state a b) := by
  have h := RationalCompareCalls.qc_closed code installed scInstalled smInstalled nmInstalled smakeInstalled
    nzInstalled nuInstalled neInstalled nltInstalled keepInstalled
    (framed_valid ctx "Q" "a" a.source "Q" "b" b.source) room a b aLive bLive
  rw [final_framed ctx room a b "Q" "a" a.source "Q" "b" b.source,
    left_framed ctx a b "Q" "a" a.source "Q" "b" b.source,
    right_framed ctx room a b "Q" "a" a.source "Q" "b" b.source] at h
  exact h

end ScopedC.RationalCompareFraming
