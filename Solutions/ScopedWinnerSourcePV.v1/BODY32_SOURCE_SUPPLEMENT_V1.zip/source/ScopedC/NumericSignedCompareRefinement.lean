/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SignedCompareBody
import ScopedC.SignedNormalization

namespace ScopedC.NumericSignedCompareRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
open ScopedC.DyadicRepresentation ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def compareInt (x y : Int) : Int := if x < y then -1 else if x = y then 0 else 1

/-- The actual sign-first comparator needs the constructor-established zero
sign invariant. No claim is made for raw negative-zero representations. -/
theorem mathematical (a b : Endpoint)
    (ha : SignedNormalization.ZeroNormalized a.mathematical)
    (hb : SignedNormalization.ZeroNormalized b.mathematical) :
    SignedCompareCalls.resultInt a b = compareInt a.mathematical.value b.mathematical.value := by
  have ha0 : a.magnitude = 0 → a.negative = false := ha
  have hb0 : b.magnitude = 0 → b.negative = false := hb
  cases hna : a.negative <;> cases hnb : b.negative <;>
    by_cases he : a.magnitude = b.magnitude <;> by_cases hl : a.magnitude < b.magnitude
  all_goals simp only [hna,hnb] at ha0 hb0
  all_goals simp [SignedCompareCalls.resultInt,SignedCompareCalls.different,
    SignedCompareCalls.equal,SignedCompareCalls.less,Endpoint.mathematical,Signed.value,
    compareInt,hna,hnb,he,hl,beq_self_eq_true,ne_eq,Bool.false_eq_true,Bool.true_eq_false,
    decide_true,decide_false,↓reduceIte]
  all_goals try split_ifs
  all_goals first | omega | simp_all

theorem compare_negative (x y : Int) : compareInt x y < 0 ↔ x < y := by
  unfold compareInt
  split_ifs <;> simp_all <;> omega

theorem compare_zero (x y : Int) : compareInt x y = 0 ↔ x = y := by
  unfold compareInt
  split_ifs <;> simp_all <;> omega

theorem compare_positive (x y : Int) : 0 < compareInt x y ↔ y < x := by
  unfold compareInt
  split_ifs <;> simp_all <;> omega

/-- This theorem joins actual source execution, decoding and mathematical
comparison correctness; it is not an independent truth merely paired with a
source hash or with an assumed successful application run. -/
theorem sc_math (code : List Function) (installed : Generated.f_sc∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    {s : State} (a b : Endpoint) (aLive : a.Live s) (bLive : b.Live s)
    (ha : SignedNormalization.ZeroNormalized a.mathematical)
    (hb : SignedNormalization.ZeroNormalized b.mathematical) :
    SourceCall Header.layout code 2 "sc" [a.source,b.source] s
        (SignedCompareCalls.integer (compareInt a.mathematical.value b.mathematical.value)) s ∧
    NumericRepresentation.signed s a.source = some a.mathematical ∧
    NumericRepresentation.signed s b.source = some b.mathematical ∧
    (SignedCompareCalls.resultInt a b < 0 ↔ a.mathematical.value < b.mathematical.value) ∧
    (SignedCompareCalls.resultInt a b = 0 ↔ a.mathematical.value = b.mathematical.value) ∧
    (0 < SignedCompareCalls.resultInt a b ↔ b.mathematical.value < a.mathematical.value) := by
  have h := SignedCompareCalls.sc_closed code installed neInstalled nltInstalled a b aLive bLive
  rw [mathematical a b ha hb] at h
  refine ⟨h,Endpoint.decoded aLive,Endpoint.decoded bLive,?_,?_,?_⟩
  all_goals rw [mathematical a b ha hb]
  · exact compare_negative _ _
  · exact compare_zero _ _
  · exact compare_positive _ _

end ScopedC.NumericSignedCompareRefinement
