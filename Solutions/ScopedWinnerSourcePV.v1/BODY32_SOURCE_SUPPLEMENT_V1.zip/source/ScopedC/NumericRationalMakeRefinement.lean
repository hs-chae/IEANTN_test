/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.RationalMakeBody

namespace ScopedC.NumericRationalMakeRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem normalized_value (a : Signed) (d : Nat) (positive : 0<d) :
    (Rational.normalize a d).value=(a.value:Rat)/(d:Rat) := by
  rw [Rational.normalize_value a d (Nat.ne_of_gt positive),Rat.normalize_eq_mkRat,
    Rat.mkRat_eq_divInt,Rat.divInt_eq_div,Int.cast_natCast]

/-- Source qm computes the old exact normalization, including gcd-one fields,
positive denominator and canonical Rat numerator/denominator. The field
identities, beyond value equality, justify representation-sensitive log2 steps. -/
theorem qm_math (code : List Function) (installed : Generated.f_qm∈code)
    (nzInstalled : Generated.f_nz∈code) (ngInstalled : Generated.f_ng∈code)
    (ndInstalled : Generated.f_nd∈code) (smakeInstalled : Generated.f_smake∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (a : Endpoint) {den d : Nat}
    (aLive : a.Live c.state) (denLive : NatArena.Borrow c.state.nats den d) (positive : 0<d)
    (context : Valid l c) (room : c.top+4<PoolCalls.capacity) :
    SourceCall Header.layout code 5 "qm" [a.source,.natObject den] c.state
        (RationalMakeCalls.result l c a d) (RationalMakeCalls.c5 l c a d).state ∧
    NumericRepresentation.rational (RationalMakeCalls.c5 l c a d).state (RationalMakeCalls.result l c a d)=
      some (Rational.normalize a.mathematical d) ∧
    (Rational.normalize a.mathematical d).Normalized ∧
    (Rational.normalize a.mathematical d).Represents (Rat.normalize a.mathematical.value d (Nat.ne_of_gt positive)) ∧
    (Rational.normalize a.mathematical d).value=(a.mathematical.value:Rat)/(d:Rat) ∧
    (Rational.normalize a.mathematical d).num.mag=(Rat.normalize a.mathematical.value d (Nat.ne_of_gt positive)).num.natAbs ∧
    (Rational.normalize a.mathematical d).den=(Rat.normalize a.mathematical.value d (Nat.ne_of_gt positive)).den := by
  have represented := Rational.normalize_represents a.mathematical d (Nat.ne_of_gt positive)
  refine ⟨RationalMakeCalls.qm_closed code installed nzInstalled ngInstalled ndInstalled smakeInstalled
    nuInstalled neInstalled keepInstalled a aLive denLive positive context room,
    RationalMakeCalls.decoded_result l c a positive,
    Rational.normalize_normalized _ _ (Nat.ne_of_gt positive),represented,
    normalized_value _ _ positive,?_,represented.2⟩
  rw [← represented.1]
  exact (Signed.natAbs_value _).symm

end ScopedC.NumericRationalMakeRefinement
