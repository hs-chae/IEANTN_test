/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPairFrames

namespace ScopedC.CursorFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def framed (c : Cursor) (ta na : String) (a : Value) (tb nb : String) (b : Value) : Cursor :=
  ⟨TwoFrames.frame c.state ta na a tb nb b,c.cells,c.top,c.high⟩

theorem framed_valid {l : PoolCalls.PoolLayout} {c : Cursor} (h : Valid l c)
    (ta na : String) (a : Value) (tb nb : String) (b : Value) :
    Valid l (framed c ta na a tb nb b) := TwoFrames.context_frame h ta na a tb nb b

theorem next_framed {l : PoolCalls.PoolLayout} {c : Cursor} (h : Valid l c)
    (ta na : String) (a : Value) (tb nb : String) (b : Value) (n : Nat) :
    next l (framed c ta na a tb nb b) n = framed (next l c n) ta na a tb nb b := by
  unfold next framed
  dsimp only
  rw [NatWrapperCalls.binary_result_two_frame h ta na a tb nb b]
  rfl

def advance (l : PoolCalls.PoolLayout) : Cursor → List Nat → Cursor
  | c,[] => c
  | c,n::rest => advance l (next l c n) rest

theorem top_advance (l : PoolCalls.PoolLayout) (c : Cursor) (ns : List Nat) :
    (advance l c ns).top = c.top+ns.length := by
  induction ns generalizing c with
  | nil => rfl
  | cons n ns ih =>
    rw [advance,ih]
    change c.top+1+ns.length=c.top+(ns.length+1)
    omega

theorem advance_valid {l : PoolCalls.PoolLayout} {c : Cursor} (h : Valid l c) (ns : List Nat)
    (room : c.top+ns.length≤PoolCalls.capacity) : Valid l (advance l c ns) := by
  induction ns generalizing c with
  | nil => exact h
  | cons n ns ih =>
    apply ih (next_valid n h (by simp only [List.length_cons] at room;omega))
    change c.top+1+ns.length≤PoolCalls.capacity
    simp only [List.length_cons] at room
    omega

theorem advance_framed {l : PoolCalls.PoolLayout} {c : Cursor} (h : Valid l c) (ns : List Nat)
    (room : c.top+ns.length≤PoolCalls.capacity)
    (ta na : String) (a : Value) (tb nb : String) (b : Value) :
    advance l (framed c ta na a tb nb b) ns = framed (advance l c ns) ta na a tb nb b := by
  induction ns generalizing c with
  | nil => rfl
  | cons n ns ih =>
    rw [advance,advance,next_framed h ta na a tb nb b n]
    apply ih (next_valid n h (by simp only [List.length_cons] at room;omega))
    change c.top+1+ns.length≤PoolCalls.capacity
    simp only [List.length_cons] at room
    omega

end ScopedC.CursorFrames
