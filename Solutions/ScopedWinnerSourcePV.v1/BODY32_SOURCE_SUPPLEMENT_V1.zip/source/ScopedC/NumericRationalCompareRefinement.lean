/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCompareBody

namespace ScopedC.NumericRationalCompareRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor ScopedNumerical
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def compareRat (x y : Rat) : Int := if x < y then -1 else if x = y then 0 else 1

theorem cross_lt (a b : Input) (ha : 0<a.denominator) (hb : 0<b.denominator) :
    a.numerator.mathematical.value*(b.denominator:Int) < b.numerator.mathematical.value*(a.denominator:Int) ↔
      a.mathematical.value < b.mathematical.value := by
  have ha' : (0:Rat)<a.denominator := by exact_mod_cast ha
  have hb' : (0:Rat)<b.denominator := by exact_mod_cast hb
  change _ ↔ (a.numerator.mathematical.value:Rat)/(a.denominator:Rat) <
    (b.numerator.mathematical.value:Rat)/(b.denominator:Rat)
  rw [div_lt_div_iff₀ ha' hb']
  constructor <;> intro h <;> exact_mod_cast h

theorem cross_eq (a b : Input) (ha : 0<a.denominator) (hb : 0<b.denominator) :
    a.numerator.mathematical.value*(b.denominator:Int) = b.numerator.mathematical.value*(a.denominator:Int) ↔
      a.mathematical.value = b.mathematical.value := by
  have ha' : (a.denominator:Rat) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt ha)
  have hb' : (b.denominator:Rat) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hb)
  change _ ↔ (a.numerator.mathematical.value:Rat)/(a.denominator:Rat) =
    (b.numerator.mathematical.value:Rat)/(b.denominator:Rat)
  rw [div_eq_div_iff ha' hb']
  constructor <;> intro h <;> exact_mod_cast h

theorem result_correct (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    SignedCompareCalls.resultInt (RationalCompareCalls.left l c a b) (RationalCompareCalls.right l c a b) =
      compareRat a.mathematical.value b.mathematical.value := by
  unfold RationalCompareCalls.left RationalCompareCalls.right
  rw [NumericSignedCompareRefinement.mathematical _ _
    (RationalCrossCalls.zero_normalized l c a.numerator b.denominator)
    (RationalCrossCalls.zero_normalized l (RationalCompareCalls.middle l c a b) b.numerator a.denominator)]
  rw [RationalCrossCalls.value,RationalCrossCalls.value]
  unfold NumericSignedCompareRefinement.compareInt compareRat
  simp only [cross_lt a b ha hb,cross_eq a b ha hb]

theorem qc_math (code : List Function) (installed : Generated.f_qc∈code)
    (scInstalled : Generated.f_sc∈code) (smInstalled : Generated.f_sm∈code)
    (nmInstalled : Generated.f_nm∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    SourceCall Header.layout code 6 "qc" [a.source,b.source] c.state
      (SignedCompareCalls.integer (compareRat a.mathematical.value b.mathematical.value))
      (RationalCompareCalls.final l c a b).state ∧
    NumericRepresentation.rational c.state a.source=some a.mathematical ∧
    NumericRepresentation.rational c.state b.source=some b.mathematical := by
  have h := RationalCompareCalls.qc_closed code installed scInstalled smInstalled nmInstalled smakeInstalled
    nzInstalled nuInstalled neInstalled nltInstalled keepInstalled ctx room a b aLive bLive
  rw [result_correct l c a b ha hb] at h
  exact ⟨h,Input.decoded aLive ha,Input.decoded bLive hb⟩

end ScopedC.NumericRationalCompareRefinement
