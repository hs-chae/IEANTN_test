/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.RationalMakeData
import ScopedC.NatWrapperCalls

namespace ScopedC.RationalMakeCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.RationalMakeFrames (params gFrame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Every actual lower-rank application body on the source qm success path.
The local g is its real ng result; the two nd calls consume that live result. -/
theorem lower_calls (code : List Function)
    (nzInstalled : Generated.f_nz∈code) (ngInstalled : Generated.f_ng∈code)
    (ndInstalled : Generated.f_nd∈code) (smakeInstalled : Generated.f_smake∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (a : Endpoint) {den d : Nat}
    (aLive : a.Live c.state) (denLive : NatArena.Borrow c.state.nats den d) (positive : 0<d)
    (context : Valid l c) (room : c.top+4<PoolCalls.capacity) :
    SourceCall Header.layout code 3 "nz" [.natObject den] (params c.state a den)
        (PrimitiveCalls.u32 false) (params (c1 l c).state a den) ∧
    SourceCall Header.layout code 2 "ng" [.natObject a.slot,.natObject den] (params (c1 l c).state a den)
        (.natObject (gSlot l c)) (params (c2 l c a d).state a den) ∧
    SourceCall Header.layout code 2 "nd" [.natObject a.slot,.natObject (gSlot l c)] (gFrame (c2 l c a d).state a den (gSlot l c))
        (.natObject (numSlot l c a d)) (gFrame (c3 l c a d).state a den (gSlot l c)) ∧
    SourceCall Header.layout code 4 "smake" [.natObject (numSlot l c a d),unsigned32 (SignedNegCalls.bit a.negative)]
        (gFrame (c3 l c a d).state a den (gSlot l c)) (SignedValues.value (numSlot l c a d) (sign a d))
        (gFrame (c4 l c a d).state a den (gSlot l c)) ∧
    SourceCall Header.layout code 2 "nd" [.natObject den,.natObject (gSlot l c)] (gFrame (c4 l c a d).state a den (gSlot l c))
        (.natObject (denSlot l c a d)) (gFrame (c5 l c a d).state a den (gSlot l c)) := by
  have states := contexts a d context room
  have h1 := states.1
  have h2 := states.2.1
  have h3 := states.2.2.1
  have h4 := states.2.2.2.1
  have r0 : c.top<PoolCalls.capacity := by omega
  have r1 : (c1 l c).top<PoolCalls.capacity := by change c.top+1<PoolCalls.capacity; omega
  have r2 : (c2 l c a d).top<PoolCalls.capacity := by change c.top+1+1<PoolCalls.capacity; omega
  have r3 : (c3 l c a d).top<PoolCalls.capacity := by change c.top+1+1+1<PoolCalls.capacity; omega
  have r4 : (c4 l c a d).top<PoolCalls.capacity := by change c.top+1+1+1+1<PoolCalls.capacity; omega
  have move1 : binaryResult l (params c.state a den) c.cells c.top c.high 0=params (c1 l c).state a den :=
    RationalMakeFrames.binary_params context a den
  have move2 : binaryResult l (params (c1 l c).state a den) (c1 l c).cells (c1 l c).top (c1 l c).high (divisor a d)=
      params (c2 l c a d).state a den := RationalMakeFrames.binary_params h1 a den
  have move3 : binaryResult l (gFrame (c2 l c a d).state a den (gSlot l c))
      (c2 l c a d).cells (c2 l c a d).top (c2 l c a d).high (a.magnitude/divisor a d)=
      gFrame (c3 l c a d).state a den (gSlot l c) := RationalMakeFrames.binary_local h2 a den (gSlot l c)
  have move4 : binaryResult l (gFrame (c3 l c a d).state a den (gSlot l c))
      (c3 l c a d).cells (c3 l c a d).top (c3 l c a d).high 0=
      gFrame (c4 l c a d).state a den (gSlot l c) := RationalMakeFrames.binary_local h3 a den (gSlot l c)
  have move5 : binaryResult l (gFrame (c4 l c a d).state a den (gSlot l c))
      (c4 l c a d).cells (c4 l c a d).top (c4 l c a d).high (d/divisor a d)=
      gFrame (c5 l c a d).state a den (gSlot l c) := RationalMakeFrames.binary_local h4 a den (gSlot l c)
  have zeroFlag : (d==0)=false := by simp [Nat.ne_of_gt positive]
  have hz := nz_call code nzInstalled nuInstalled neInstalled keepInstalled
    (RationalMakeFrames.params_context context a den) r0 denLive
  have nz : SourceCall Header.layout code 3 "nz" [.natObject den] (params c.state a den)
      (PrimitiveCalls.u32 false) (params (c1 l c).state a den) := by
    simpa only [zeroFlag,move1] using hz
  change binaryResult l (params (c1 l c).state a den) (c1 l c).cells (c1 l c).top (c1 l c).high (a.magnitude.gcd d)=
    params (c2 l c a d).state a den at move2
  have a1 : NatArena.Borrow (c1 l c).state.nats a.slot a.magnitude := preserves aLive
  have d1 : NatArena.Borrow (c1 l c).state.nats den d := preserves denLive
  have hg := ng_call code ngInstalled keepInstalled (RationalMakeFrames.params_context h1 a den) r1 a1 d1
  have gcdCall : SourceCall Header.layout code 2 "ng" [.natObject a.slot,.natObject den] (params (c1 l c).state a den)
      (.natObject (gSlot l c)) (params (c2 l c a d).state a den) := by
    simpa only [RationalMakeFrames.params_nats,gSlot,move2] using hg
  have a2 : NatArena.Borrow (c2 l c a d).state.nats a.slot a.magnitude := preserves a1
  have g2 := gcd_live l c a d
  have gnz : divisor a d≠0 := Nat.ne_of_gt (divisor_positive a positive)
  have hn := nd_call code ndInstalled keepInstalled (RationalMakeFrames.local_context h2 a den (gSlot l c)) r2 a2 g2 gnz
  have numeratorCall : SourceCall Header.layout code 2 "nd" [.natObject a.slot,.natObject (gSlot l c)]
      (gFrame (c2 l c a d).state a den (gSlot l c)) (.natObject (numSlot l c a d))
      (gFrame (c3 l c a d).state a den (gSlot l c)) := by
    simpa only [RationalMakeFrames.local_nats,numSlot,move3] using hn
  have n3 : NatArena.Borrow (c3 l c a d).state.nats (numSlot l c a d) (a.magnitude/divisor a d) := next_borrow _ _ _
  have hm := SignedCalls.smake_call (input:=unsigned32 (SignedNegCalls.bit a.negative)) code smakeInstalled
    nzInstalled nuInstalled neInstalled keepInstalled (RationalMakeFrames.local_context h3 a den (gSlot l c)) r3 n3
    (SignedNegCalls.bit_bound _) (RationalUnsignedCalls.cast_parameter
      (allocate {gFrame (c3 l c a d).state a den (gSlot l c) with env:=[]} "N" "mag" (some (.natObject (numSlot l c a d))))
      _ (SignedNegCalls.bit_bound _))
  have makeCall : SourceCall Header.layout code 4 "smake"
      [.natObject (numSlot l c a d),unsigned32 (SignedNegCalls.bit a.negative)]
      (gFrame (c3 l c a d).state a den (gSlot l c)) (SignedValues.value (numSlot l c a d) (sign a d))
      (gFrame (c4 l c a d).state a den (gSlot l c)) := by
    simpa only [move4,sign] using hm
  have d4 : NatArena.Borrow (c4 l c a d).state.nats den d := preserves (preserves (preserves d1))
  have g4 : NatArena.Borrow (c4 l c a d).state.nats (gSlot l c) (divisor a d) := preserves (preserves g2)
  have hd := nd_call code ndInstalled keepInstalled (RationalMakeFrames.local_context h4 a den (gSlot l c)) r4 d4 g4 gnz
  have denominatorCall : SourceCall Header.layout code 2 "nd" [.natObject den,.natObject (gSlot l c)]
      (gFrame (c4 l c a d).state a den (gSlot l c)) (.natObject (denSlot l c a d))
      (gFrame (c5 l c a d).state a den (gSlot l c)) := by
    simpa only [RationalMakeFrames.local_nats,denSlot,move5] using hd
  exact ⟨nz,gcdCall,numeratorCall,makeCall,denominatorCall⟩

end ScopedC.RationalMakeCalls
