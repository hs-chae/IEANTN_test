/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEvents

namespace ScopedC.CallEvents
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false

theorem one_before_other {cfg : Layout} {code : List Function} {rank : Nat}
    (event : Event cfg code rank) {name : String} {args : List Value} {before : State}
    (different : before ≠ event.before) : one event name args before = none := by
  classical
  simp only [one]
  split_ifs with h
  · exact False.elim (different h.2.2)
  · rfl

end ScopedC.CallEvents
