/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericSignedCompareRefinement
import ScopedC.RationalMakeData

namespace ScopedC.RationalPairFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

structure Input where
  numerator : Endpoint
  denSlot : Nat
  denominator : Nat

namespace Input
def source (q : Input) : Value := .record "Q" [q.numerator.source,.natObject q.denSlot]
def mathematical (q : Input) : Rational := ⟨q.numerator.mathematical,q.denominator⟩
def Live (s : State) (q : Input) : Prop := q.numerator.Live s ∧ NatArena.Borrow s.nats q.denSlot q.denominator

theorem cast {s : State} (type : String) (hn : normalizeType type = "Q")
    {q : Input} (h : q.Live s) : castValue Header.layout s 100 type q.source = some q.source :=
  RecordCasts.rational_record s 97 type hn h.1 h.2 (SignedNegCalls.bit_bound _)

theorem decoded {s : State} {q : Input} (h : q.Live s) (positive : 0 < q.denominator) :
    NumericRepresentation.rational s q.source = some q.mathematical :=
  NumericRepresentation.rational_value q.numerator.negative h.1 h.2 positive

theorem live_after {l : PoolCalls.PoolLayout} {c : PoolCursor.Cursor} {n : Nat} {q : Input}
    (h : q.Live c.state) : q.Live (PoolCursor.next l c n).state :=
  ⟨PoolCursor.preserves h.1,PoolCursor.preserves h.2⟩
end Input

def frame (s : State) (a b : Input) : State := TwoFrames.frame s "Q" "a" a.source "Q" "b" b.source

theorem bind {s : State} (a b : Input) (ha : a.Live s) (hb : b.Live s) :
    bindArgs Header.layout [("Q","a"),("Q","b")] [a.source,b.source] s = some (frame s a b) :=
  TypedFrames.bind_two Header.layout s "Q" "a" "Q" "b" a.source b.source a.source b.source
    (Input.cast "Q" (by decide +kernel) ha) (Input.cast "Q" (by decide +kernel) hb)

theorem eval_a (call : Call) (fuel : Nat) (s : State) (a b : Input) :
    evalExpr Header.layout call (fuel+1) (frame s a b) (.var "a") = some (a.source,frame s a b) := by
  simp [evalExpr,getVar,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_b (call : Call) (fuel : Nat) (s : State) (a b : Input) :
    evalExpr Header.layout call (fuel+1) (frame s a b) (.var "b") = some (b.source,frame s a b) := by
  simp [evalExpr,getVar,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_a_num (call : Call) (fuel : Nat) (s : State) (a b : Input) :
    evalExpr Header.layout call (fuel+2) (frame s a b) (.field "." (.var "a") "num") =
      some (a.numerator.source,frame s a b) := by
  apply ExpressionTemplates.field Header.layout call (eval_a call fuel s a b)
  rfl

theorem eval_b_num (call : Call) (fuel : Nat) (s : State) (a b : Input) :
    evalExpr Header.layout call (fuel+2) (frame s a b) (.field "." (.var "b") "num") =
      some (b.numerator.source,frame s a b) := by
  apply ExpressionTemplates.field Header.layout call (eval_b call fuel s a b)
  rfl

theorem eval_a_den (call : Call) (fuel : Nat) (s : State) (a b : Input) :
    evalExpr Header.layout call (fuel+2) (frame s a b) (.field "." (.var "a") "den") =
      some (.natObject a.denSlot,frame s a b) := by
  apply ExpressionTemplates.field Header.layout call (eval_a call fuel s a b)
  rfl

theorem eval_b_den (call : Call) (fuel : Nat) (s : State) (a b : Input) :
    evalExpr Header.layout call (fuel+2) (frame s a b) (.field "." (.var "b") "den") =
      some (.natObject b.denSlot,frame s a b) := by
  apply ExpressionTemplates.field Header.layout call (eval_b call fuel s a b)
  rfl

theorem cursor_frame {l : PoolCalls.PoolLayout} {c : PoolCursor.Cursor}
    (ctx : PoolCursor.Valid l c) (a b : Input) (n : Nat) :
    binaryResult l (frame c.state a b) c.cells c.top c.high n =
      frame (PoolCursor.next l c n).state a b := by
  exact binary_result_two_frame ctx "Q" "a" a.source "Q" "b" b.source

end ScopedC.RationalPairFrames
