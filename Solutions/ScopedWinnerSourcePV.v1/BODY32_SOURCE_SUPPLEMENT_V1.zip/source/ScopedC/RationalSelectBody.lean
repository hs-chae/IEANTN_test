/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCompareFraming

namespace ScopedC.RationalSelectCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def test (op : String) : Expr := .binary op (.call (.var "qc") [.var "a",.var "b"]) (.nat 0)
def pick (op : String) (x y : Endpoint) : Bool :=
  if op="<=" then decide (SignedCompareCalls.resultInt x y≤0) else decide (0≤SignedCompareCalls.resultInt x y)
def selected (flip : Bool) (op : String) (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Input :=
  if pick op (RationalCompareCalls.left l c a b) (RationalCompareCalls.right l c a b) then (if flip then b else a) else (if flip then a else b)

theorem comparison (s : State) (op : String) (allowed : op="<=" ∨ op=">=") (x y : Endpoint) :
    binaryValue Header.layout s op (SignedCompareCalls.integer (SignedCompareCalls.resultInt x y))
      (SignedCompareCalls.integer 0) = some (boolean Header.layout (pick op x y)) := by
  rcases allowed with rfl | rfl
  · change binaryValue Header.layout s "<=" (SignedCompareCalls.integer (SignedCompareCalls.resultInt x y))
      (SignedCompareCalls.integer 0) = some (boolean Header.layout (decide (SignedCompareCalls.resultInt x y≤0)))
    unfold SignedCompareCalls.resultInt
    split_ifs <;> rfl
  · change binaryValue Header.layout s ">=" (SignedCompareCalls.integer (SignedCompareCalls.resultInt x y))
      (SignedCompareCalls.integer 0) = some (boolean Header.layout (decide (0≤SignedCompareCalls.resultInt x y)))
    unfold SignedCompareCalls.resultInt
    split_ifs <;> rfl

theorem input_final {l : PoolCalls.PoolLayout} {c : Cursor} {a b q : Input} (h : q.Live c.state) :
    q.Live (RationalCompareCalls.final l c a b).state :=
  Input.live_after (Input.live_after (Input.live_after (RationalCompareCalls.input_middle h)))

theorem selection_closed (code : List Function) (function : Function) (installed : function∈code)
    (op : String) (allowed : op="<=" ∨ op=">=") (flip : Bool)
    (params : function.parameters=[("Q","a"),("Q","b")]) (returns : function.returnType="static Q")
    (source : function.body=.sequence [.returnStmt (.conditional (test op) (if flip then .var "b" else .var "a") (if flip then .var "a" else .var "b"))])
    (qcInstalled : Generated.f_qc∈code) (scInstalled : Generated.f_sc∈code) (smInstalled : Generated.f_sm∈code)
    (nmInstalled : Generated.f_nm∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state) :
    SourceCall Header.layout code 7 function.name [a.source,b.source] c.state
      (selected flip op l c a b).source (RationalCompareCalls.final l c a b).state := by
  let f := RationalCompareCalls.final l c a b
  let x := RationalCompareCalls.left l c a b
  let y := RationalCompareCalls.right l c a b
  have proof := RationalCompareFraming.qc_on_frame code qcInstalled scInstalled smInstalled nmInstalled smakeInstalled
    nzInstalled nuInstalled neInstalled nltInstalled keepInstalled ctx room a b aLive bLive
  let event : CallEvents.Event Header.layout code 6 :=
    ⟨"qc",[a.source,b.source],frame c.state a b,
      SignedCompareCalls.integer (SignedCompareCalls.resultInt x y),frame f.state a b,proof⟩
  let service := CallEvents.one event
  have qcEval : evalExpr Header.layout service 4 (frame c.state a b) (.call (.var "qc") [.var "a",.var "b"]) =
      some (SignedCompareCalls.integer (SignedCompareCalls.resultInt x y),frame f.state a b) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalPairFrames.eval_a service 2 c.state a b) (RationalPairFrames.eval_b service 2 c.state a b)
      (CallEvents.one_self event)
  have condition : evalExpr Header.layout service 5 (frame c.state a b) (test op) =
      some (boolean Header.layout (pick op x y),frame f.state a b) := by
    apply ExpressionTemplates.binary Header.layout service
    · rcases allowed with rfl | rfl <;> decide +kernel
    · rcases allowed with rfl | rfl <;> decide +kernel
    · rcases allowed with rfl | rfl <;> decide +kernel
    · rcases allowed with rfl | rfl <;> decide +kernel
    · exact qcEval
    · rfl
    · exact comparison (frame f.state a b) op allowed x y
  have branch : evalExpr Header.layout service 5 (frame f.state a b)
      (if truth (boolean Header.layout (pick op x y)) then (if flip then .var "b" else .var "a") else (if flip then .var "a" else .var "b")) =
      some ((selected flip op l c a b).source,frame f.state a b) := by
    rw [SignedAddCalls.truth_boolean]
    change evalExpr Header.layout service 5 (frame f.state a b)
      (if pick op x y then (if flip then .var "b" else .var "a") else (if flip then .var "a" else .var "b")) =
      some ((if pick op x y then (if flip then b else a) else (if flip then a else b)).source,frame f.state a b)
    cases flip <;> cases hp : pick op x y
    all_goals simp only [hp,Bool.false_eq_true,↓reduceIte]
    all_goals first | exact RationalPairFrames.eval_a service 4 f.state a b | exact RationalPairFrames.eval_b service 4 f.state a b

  have expr : Eval Header.layout service (.conditional (test op) (if flip then .var "b" else .var "a") (if flip then .var "a" else .var "b"))
      (frame c.state a b) (frame f.state a b) (selected flip op l c a b).source :=
    ⟨6,ExpressionTemplates.conditional Header.layout service condition branch⟩
  have shapeF := RationalCompareCalls.shape l c a b
  have body : Run Header.layout service function.body (frame c.state a b)
      (.returned (frame f.state a b) (selected flip op l c a b).source) := by
    rw [source]
    apply Loops.StmtRun.sequence (Loops.SeqRun.returned (Loops.StmtRun.returnValue expr))
    refine ⟨rfl,?_⟩
    have len : (frame f.state a b).heap.length=(frame c.state a b).heap.length := by simp [frame,TwoFrames.frame,allocate,f,shapeF.1]
    have env : (frame f.state a b).env=(frame c.state a b).env := by simp [frame,TwoFrames.frame,allocate,f,shapeF.1]
    exact (PoolCalls.pop_same len env).symm
  have selectedLive : (selected flip op l c a b).Live f.state := by
    cases hf : flip <;> cases hp : pick op (RationalCompareCalls.left l c a b) (RationalCompareCalls.right l c a b)
    all_goals first
      | simpa only [selected,hf,hp,Bool.false_eq_true,↓reduceIte] using (input_final (a:=a) (b:=b) aLive)
      | simpa only [selected,hf,hp,Bool.false_eq_true,↓reduceIte] using (input_final (a:=a) (b:=b) bLive)

  have arguments : bindArgs Header.layout function.parameters [a.source,b.source] c.state = some (frame c.state a b) := by
    rw [params]
    exact RationalPairFrames.bind a b aLive bLive
  apply installed_body (f:=function) (rank:=6) (service:=service) installed
    (fun _ _ _ _ _ h=>CallEvents.one_closed event h) arguments body
  constructor
  · rw [returns]
    exact Input.cast "static Q" (by decide +kernel) selectedLive
  · exact (TwoFrames.pop_frame "Q" "a" a.source "Q" "b" b.source shapeF.1 shapeF.2).symm

theorem qmin_closed (code : List Function) (installed : Generated.f_qmin∈code)
    (qcInstalled : Generated.f_qc∈code) (scInstalled : Generated.f_sc∈code) (smInstalled : Generated.f_sm∈code)
    (nmInstalled : Generated.f_nm∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state) :
    SourceCall Header.layout code 7 "qmin" [a.source,b.source] c.state
      (selected false "<=" l c a b).source (RationalCompareCalls.final l c a b).state :=
  selection_closed code Generated.f_qmin installed "<=" (Or.inl rfl) false rfl rfl rfl
    qcInstalled scInstalled smInstalled nmInstalled smakeInstalled nzInstalled nuInstalled neInstalled nltInstalled
    keepInstalled ctx room a b aLive bLive

theorem qmax_closed (code : List Function) (installed : Generated.f_qmax∈code)
    (qcInstalled : Generated.f_qc∈code) (scInstalled : Generated.f_sc∈code) (smInstalled : Generated.f_sm∈code)
    (nmInstalled : Generated.f_nm∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (nltInstalled : Generated.f_nlt∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state) :
    SourceCall Header.layout code 7 "qmax" [a.source,b.source] c.state
      (selected true "<=" l c a b).source (RationalCompareCalls.final l c a b).state :=
  selection_closed code Generated.f_qmax installed "<=" (Or.inl rfl) true rfl rfl rfl
    qcInstalled scInstalled smInstalled nmInstalled smakeInstalled nzInstalled nuInstalled neInstalled nltInstalled
    keepInstalled ctx room a b aLive bLive

end ScopedC.RationalSelectCalls
