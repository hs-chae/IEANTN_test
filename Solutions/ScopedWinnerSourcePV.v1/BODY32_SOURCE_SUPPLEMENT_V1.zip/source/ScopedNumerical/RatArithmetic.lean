/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedNumerical.Arithmetic

namespace ScopedNumerical

namespace Signed

theorem value_div (a : Signed) (g : Nat) (h : g ∣ a.mag) :
    (make (a.mag/g) a.neg).value = a.value/(g : Int) := by
  rw [value_make]
  have hd : (g : Int) ∣ (a.mag : Int) := Int.ofNat_dvd.mpr h
  cases ha : a.neg <;> simp only [ha, value, Bool.false_eq_true, ↓reduceIte]
  · exact Int.natCast_ediv _ _
  · rw [Int.neg_ediv_of_dvd hd, Int.natCast_ediv]

end Signed

namespace Rational

def normalize (a : Signed) (den : Nat) : Rational :=
  let g := a.mag.gcd den
  ⟨Signed.make (a.mag/g) a.neg, den/g⟩

def Represents (a : Rational) (q : Rat) : Prop := a.num.value = q.num ∧ a.den = q.den

theorem Represents.value_eq {a : Rational} {q : Rat} (h : a.Represents q) : a.value = q := by
  unfold value
  rw [h.1,h.2]
  exact Rat.num_div_den q

theorem normalize_represents (a : Signed) (den : Nat) (hd : den ≠ 0) :
    (normalize a den).Represents (Rat.normalize a.value den hd) := by
  constructor
  · simp only [normalize, Rat.num_normalize, Signed.natAbs_value]
    exact Signed.value_div a _ (Nat.gcd_dvd_left _ _)
  · simp only [normalize, Rat.den_normalize, Signed.natAbs_value]

theorem normalize_value (a : Signed) (den : Nat) (hd : den ≠ 0) :
    (normalize a den).value = Rat.normalize a.value den hd :=
  (normalize_represents a den hd).value_eq

theorem normalize_normalized (a : Signed) (den : Nat) (hd : den ≠ 0) :
    (normalize a den).Normalized := by
  have h := normalize_represents a den hd
  refine ⟨?_, ?_, ?_⟩
  · rw [h.2]; exact Rat.den_pos _
  · have hr := (Rat.normalize a.value den hd).reduced
    rw [← h.1, Signed.natAbs_value, ← h.2] at hr
    exact hr
  · intro hz
    simp only [normalize, Signed.make_mag] at hz
    simp [normalize, Signed.make, hz]

end Rational
end ScopedNumerical
