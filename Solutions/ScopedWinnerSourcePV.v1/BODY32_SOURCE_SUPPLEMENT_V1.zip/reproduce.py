# Copyright (c) 2026 IEANTN contributors. All rights reserved.
# Released under Apache 2.0 license as described in the file LICENSE.
# Authors: OpenAI (Codex)
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
BASE=Path(__file__).resolve().parent
def require(value,message):
 if not value:raise ValueError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description='Fresh32-body supplement proof rebuild; public generic dependencies only.')
 ap.add_argument('--environment',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
 lock=json.loads((BASE/'SOURCE_LOCK.json').read_text());e=json.loads(a.environment.read_text())
 tool=Path(e['compiler']).parent.parent
 runtime=lock['runtime_pins']
 def runtime_check():
  for r in runtime['toolchain_files']:
   p=tool/r['path'];require(p.is_file()and p.stat().st_size==r['bytes']and sha(p)==r['sha256'],'runtime/kernel pin '+r['path'])
  q=subprocess.run([e['compiler'],'--version'],capture_output=True,text=True,check=True)
  require(q.stdout.strip()==runtime['lean_version'],'kernel version mismatch')
 runtime_check()
 require(sha(Path(e['compiler']))==lock['compiler_sha256'],'compiler pin mismatch')
 deps=e['generic_dependencies'];require([{k:d[k]for k in ['name','commit','url']}for d in deps]==lock['generic_dependencies'],'generic dependency population/pin mismatch')
 for d in deps:
  q=subprocess.run(['git','-C',d['source'],'rev-parse','HEAD'],capture_output=True,text=True,check=True)
  require(q.stdout.strip()==d['commit'],'generic source commit mismatch '+d['name'])
  require(Path(d['objects']).is_dir(),'generic object root missing '+d['name'])
 out=a.out.resolve();require(not out.exists(),'output must be fresh');require(BASE not in out.parents,'output must be outside sealed capsule');out.mkdir(parents=True);objects=out/'objects';objects.mkdir()
 for row in lock['sources']:
  p=BASE/row['path'];require(p.stat().st_size==row['bytes']and sha(p)==row['sha256'],'source pin mismatch '+row['module'])
 env=os.environ.copy();env['LEAN_PATH']=':'.join([str(objects)]+[d['objects']for d in deps]);env['LEAN_NUM_THREADS']='1';records=[];start=time.monotonic()
 def execute(name,cmd):
  so=out/(name+'.stdout');se=out/(name+'.stderr');t=time.monotonic()
  with so.open('w')as f,se.open('w')as g:q=subprocess.run(cmd,stdout=f,stderr=g,cwd=BASE,env=env)
  record=dict(name=name,command=cmd,exit_code=q.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(so),stderr_sha256=sha(se));records.append(record)
  require(q.returncode==0,'failed '+name)
  require("declaration uses 'sorry'"not in so.read_text()+se.read_text(),'sorry in '+name)
 for row in lock['sources']:
  obj=objects/Path(row['module'].replace('.','/')).with_suffix('.olean');obj.parent.mkdir(parents=True,exist_ok=True)
  execute(row['module'],[e['compiler'],'-j1','-R',str(BASE/'source'),str(BASE/row['path']),'-o',str(obj)])
  records[-1]['object_sha256']=sha(obj)
 audit=out/'Audit.lean';audit.write_text(''.join('import '+n+'\n'for n in lock['root_modules'])+'import Lean.Util.CollectAxioms\nopen Lean Elab\nset_option maxHeartbeats 0\nrun_elab do\n let env ← getEnv\n for n in (['+','.join('`'+n for n in lock['roots'])+'] : List Name) do\n  let some ci := env.find? n | throwError "missing {n}"\n  let ax ← Lean.collectAxioms n\n  logInfo m!"BODY_AUDIT {(Json.mkObj [("name",toJson n.toString),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"\n')
 execute('audit',[e['compiler'],'-j1','-R',str(out),str(audit)])
 rows=[json.loads(x.split('BODY_AUDIT ',1)[1])for x in(out/'audit.stdout').read_text().splitlines()if'BODY_AUDIT 'in x]
 require([x['name']for x in rows]==lock['roots'],'audit exact population mismatch')
 require(all(set(x['axioms'])<={'propext','Classical.choice','Quot.sound'}for x in rows),'nonstandard axiom')
 for row in lock['sources']:require(sha(BASE/row['path'])==row['sha256'],'source changed during replay')
 runtime_check()
 result=dict(status='PASS_HOST_GENERIC_ONLY_SOURCE_COLD_BODY32_SUPPLEMENT',source_lock_sha256=sha(BASE/'SOURCE_LOCK.json'),reproducer_sha256=sha(Path(__file__)),source_modules=len(lock['sources']),theorem_roots=len(rows),records=records,audits=rows,elapsed_seconds=time.monotonic()-start,application_object_inputs=[],generic_dependencies=lock['generic_dependencies'],qualification='Host source-cold32conditionalactualhelperbodycontracts plus15mathematicalrefinements; noapplicationobjectinputs; notnamespaceisolation, whole68functionPV, main/stdiooutputororiginalnumeric/mathconsumercompletion.')
 temp=out/'RECEIPT.pending';temp.write_text(json.dumps(result,indent=2)+'\n');os.replace(temp,out/'RECEIPT.json');print(json.dumps({k:result[k]for k in ['status','source_modules','theorem_roots','elapsed_seconds']}))
if __name__=='__main__':main()
