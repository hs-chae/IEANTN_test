# Pure pi and direct-psi300 continuation:482 sources/78 roots

This adds nine mathematical source modules/eighteen roots to the completed pure473 chain.
It preserves exactly the current fourteen analytic hypotheses and the fixed330 numerical
workload, proving both normalized errors<=0.009354674*x^(-1/8) for all x>=exp300.
The psi conclusion uses the original psi explicit formula directly, not a pi implication.

This is kernel-only verification, never source-first PV. It is a strengthened posthoc
comparison using this campaign's numerical272Gaussian/768height checkpoint, not original
P0/frozen initial evidence, an evidence-free analytic gift or exposure/discovery causality.
No actual C correctness, new source/algorithm, optimality or best-known claim follows.

All sources, public dependency/bootstrap pins, numerical proposers and recipes are included
recursively under base/. Start from base/base/README.md to prepare the exact public Lean
4.34.0-rc2 environment, then use fresh external output directories:

```sh
python3 base/base/reproduce_all.py --environment /absolute/new/public-environment.json \
  --out /absolute/new/pure471 --jobs 3
python3 base/reproduce.py --environment /absolute/new/public-environment.json \
  --base-run /absolute/new/pure471 --out /absolute/new/pure473
python3 reproduce.py --environment /absolute/new/public-environment.json \
  --base471-run /absolute/new/pure471 --base-run /absolute/new/pure473 \
  --out /absolute/new/pure482
```

For mathematical source-only replay, base/base/reproduce.py replaces reproduce_all.py.
The last command recursively checks every prior source, actual command, object, log and
all60raw complete axiom audits before and after. Only those exact same-pipeline fresh473
objects seed one coherent bank. It compiles nine new sources and audits all78 roots.
It does not accept any historical warm application object as an extra input.
Only final RECEIPT.json is acceptance. --check-inputs-only checks locked identities,
never proof acceptance. Namespace isolation is separate and not claimed by this recipe.

Use scripts/resource_scope_v2.py from the project, actual host capacities, aggregate300GiB/
64CPU and host reserves. The tiny append can use an8GiB helper window after the current
exposure24GiB reservation drains; do not add an extra helper to a fully reserved host.
The inherited471 numerical run used24GiB/jobs3, not the obsolete4GiB cap.

No random seed is involved. Keep accepted source, certificates, proof artifacts, receipts,
exact commands, dependency commits and hashes. Regenerate disposable binaries/arrays and
remove only verified owned regenerable temporaries after reproduction has been checked.
At preparation time new482full replay is pending; no inherited receipt closes it implicitly.
