# Standalone kernel-only rational PNT comparator

This capsule freezes471 Lean application sources and49 exact theorem roots. It retains
all463 sources, numerical words, algorithms and original fourteen expanded mathematical
premises of the previously accepted mathematical height experiment, then adds eight pure
analytic/guard/consumer modules. It imports no ScopedC, ScopedIO, SynergyHeightC,
SourceMainFrames, SourceMainBudget or SourcePointSlopes source module.

The selected final theorem is
`SynergyAnalytic.HeightPoint.PureKernelRationalProfile.pi_rational_point`.
It proves exactly the same rational future PNT function as the actual-source route, and
the same future caps0.007648883/500,0.007010158/1000,0.006470481/1000000 and narrowed
prime-rich widths0.0154/exp500 and0.0141/exp1000. All original analytic premises remain
explicit. This is kernel-only verification, not source-first PV. It establishes no
correctness claim for the actual executable C implementation; that is a separate result.

`PREPARATION.json` records preparation only. Development proofs and their warm receipts
are outside this capsule. A full source-cold run is accepted only after its actual final
RECEIPT.json. A pending run or source-identity-only check is not proof acceptance.

## Reproduce from a clean public environment

Use Linux x86-64, Python3, Git, tar/zstd and ordinary C build headers. The included public
bootstrap pins Lean4.34.0-rc2 commit6a10ac8c22beadecabdbb0919c2b50214762f91d and eight
public Mathlib/dependency commits. Compiler/runtime file hashes are in SOURCE_LOCK.json.
No application object cache is an input.

```sh
python3 environment-bootstrap/scripts/bootstrap.py \
  --work /absolute/new/public-environment \
  --receipt /absolute/new/public-environment-receipt.json
python3 prepare_environment.py \
  --toolchain /absolute/new/public-environment/lean-4.34.0-rc2-linux \
  --mathlib /absolute/new/public-environment/mathlib \
  --out /absolute/new/public-environment.json
python3 reproduce_all.py --environment /absolute/new/public-environment.json \
  --out /absolute/new/kernel-rational-full --jobs 3
```

The full script compiles five unchanged C proposal generators, regenerates all58 constant
boxes, log-height/survival endpoints,768 coefficient/slope pairs and24 budget blocks,
checks exact word agreement with the locked Lean sources, then compiles every application
source from an empty bank and audits all49 theorem closures. Raw proposal outputs are never
accepted as mathematical premises. All computations are deterministic; no random seed is
used. Original parameters:768 logarithmic-height cells, scale6,128 fractional bits,
unsigned512bit proposal storage, endpoint allowance21600, QRH7/8, finiteRH3e12.

For the mathematical source-only replay, with the exact locked proposal words already
included, run:

```sh
python3 reproduce.py --environment /absolute/new/public-environment.json \
  --out /absolute/new/kernel-rational-proofs --jobs 3
```

The internal reproduce_kernel_graph.py is the unchanged generic source-only builder from
the accepted463-source capsule. It also accepts the new471-source lock and starts from an
empty application object directory. A live study launch may invoke that internal builder
directly; its receipt pins the exact source lock,49 audits, all source/object/log hashes,
execution commands, elapsed time and per-module maximum RSS. Public generic compiled
libraries are permitted, while historical application objects are absent from LEAN_PATH.
Namespace isolation is a separate property and must not be inferred from these host recipes.

Source identity checking, without proof acceptance:

```sh
python3 check_inputs.py --out /absolute/new/pure-input-check
```

Use actual separate RAM/disk availability. The new study reserves24GiB/6CPU with three
single-threaded Lean workers and preserves the host's aggregate300GiB/64CPU policy. It
uses no obsolete4GiB limit. Increase resources only if measured need and host capacity
justify it; free disk is not available RAM. All scripts use explicit acceptance errors,
not Python assert. The control matrix exercises real CLIs under normal/-O/-OO.

## Mathematical mechanism and fair comparison

The already verified finite330 sum is at most0.008433850764. Cheap new table-only guards
prove all768 D values lie in77..163 and all weights are nonnegative. The freely shared
paired-factor contraction and unchanged analytic tail transfer then produce the full
future rational function, without source-program execution facts or new768-point
transcendental evaluations. See the selected Lean source for the exact formula, theorem,
hypotheses and generic definitions. The immediate prior prime-rich baseline has width
0.017 and onset exp330; smaller new widths trade later onsets for narrower intervals.

This comparator supplies the improved-analytic/frozen-verified-evidence configuration.
The mathematical coefficient gain cannot be attributed uniquely to source-first PV.
The source route adds the actual C execution/output guarantee. Old written/Arb profile
comparisons keep their original trust tier; this does not retroactively close their
unrelated parameter/range obligations or modify original exposure scores.

## Storage and trust

Preserve all sources, lock files, receipts, exact statements/parameters, hashes and accepted
proof artifacts. Full numerical regeneration keeps its small output words and source/run
receipts. Only the five fresh, hash-identified regenerable executables are removed after
successful exact-output checks. No original source, unrelated workspace, accepted proof,
irreplaceable certificate or only reproducibility copy is deleted. Generated numerical
outputs are written outside the immutable capsule.

The pinned Lean kernel and agreed public generic libraries establish the mathematical
proofs. Numerical reproducibility additionally uses the pinned compiler/core runtime and
applicable C/OS/ABI/hardware contracts. This kernel-only route does not prove those C
programs correct and must never be labeled source-first PV.
