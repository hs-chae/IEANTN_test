"""Exact471-source pure-kernel capsule integrity; never proof acceptance."""
from pathlib import Path
import argparse,hashlib,json,math,os
B=Path(__file__).resolve().parent

def need(x,m):
    if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(text):
    def pairs(rows):
        d={}
        for k,v in rows:
            need(k not in d,'duplicate JSON key '+k);d[k]=v
        return d
    def invalid(value):raise ValueError('nonfinite JSON '+value)
    return json.loads(text,object_pairs_hook=pairs,parse_constant=invalid)
def source_inputs(check_files=True):
    p=B/'SOURCE_LOCK.json';d=strict(p.read_text())
    need(len(d['sources'])==471 and len(d['roots'])==len(set(d['roots']))==49,'exact471sources/49roots')
    names={r['module'] for r in d['sources']}
    need(len(names)==471 and all(set(r['imports'])<=names for r in d['sources']),'unique complete application import closure')
    need(not any(n.startswith(('ScopedC.','ScopedIO.','SynergyHeightC.','SourceMainFrames','SourceMainBudget','SourcePointSlopes')) for n in names),'pure comparator only')
    need({str(p.relative_to(B)) for p in (B/'source').rglob('*.lean')}=={r['path'] for r in d['sources']},'exact source population')
    need(not list((B/'source').rglob('*.olean')),'no application object in source capsule')
    for row in d['sources']+d['payloads']:
        p=B/row['path'];need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'source identity '+row['path'])
    if check_files:
        files=strict((B/'CAPSULE_FILES_V2.json').read_text())
        for row in files['files']:
            p=B/row['path'];need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'capsule file identity '+row['path'])
    return d

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    d=source_inputs();out=a.out.resolve();need(not out.exists() and B not in out.parents,'fresh external control output')
    out.mkdir(parents=True)
    record=dict(status='PASS471_PURE_SOURCE_IDENTITIES_ONLY_NOT_REPLAY',source_modules=471,theorem_roots=49,
        source_lock_sha256=sha(B/'SOURCE_LOCK.json'),validator_sha256=sha(Path(__file__)),
        proof_replay_completed=False,source_first_PV=False,python_optimization=__import__('sys').flags.optimize)
    t=out/'RECEIPT.pending';t.write_text(json.dumps(record,indent=2)+'\n');os.replace(t,out/'RECEIPT.json')
    print(record['status'])
if __name__=='__main__':main()
