"""Regenerate all original numerical proposals, then compile standalone471 kernel proofs.
Raw C outputs are checked as proposals, never mathematical premises or source-first PV.
"""
from pathlib import Path
import argparse,json,subprocess,sys,time,os
from check_inputs import source_inputs,need,sha,strict
B=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--environment',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True);ap.add_argument('--jobs',type=int,default=3)
    a=ap.parse_args();source_inputs();out=a.out.resolve()
    need(not out.exists() and B not in out.parents,'fresh output outside immutable capsule')
    need(1<=a.jobs<=4 and a.environment.is_file(),'jobs1..4 and pinned public environment')
    e=strict(a.environment.read_text());out.mkdir(parents=True);start=time.monotonic();records=[]
    flags=['-OO'] if sys.flags.optimize>=2 else ['-O'] if sys.flags.optimize else []
    commands=[('numerics',[sys.executable,*flags,str(B/'numerics/reproduce_height_numerics_v1.py'),
        '--compiler',str(Path(e['compiler']).with_name('clang')),'--out',str(out/'numerics')]),
        ('word-association',[sys.executable,*flags,str(B/'numerics/verify_regenerated_height_words_v1.py'),
        '--source-root',str(B/'source'),'--raw-root',str(out/'numerics'),'--out',str(out/'WORD_ASSOCIATION.json')]),
        ('proofs',[sys.executable,*flags,str(B/'reproduce.py'),'--environment',str(a.environment.resolve()),
        '--out',str(out/'mathematics'),'--jobs',str(a.jobs)])]
    for name,command in commands:
        began=time.monotonic()
        with (out/(name+'.stdout')).open('wb') as f,(out/(name+'.stderr')).open('wb') as g:
            q=subprocess.run(command,stdout=f,stderr=g)
        need(q.returncode==0,'failed '+name+'; preserve partial files')
        records.append(dict(name=name,command=command,seconds=time.monotonic()-began,exit_code=q.returncode))
    source_inputs();proof=out/'mathematics/RECEIPT.json';r=strict(proof.read_text())
    need(r['status']=='PASS471_PURE_KERNEL_RATIONAL_PROFILE_SOURCE_COLD','complete mathematical consumer')
    d=dict(status='PASS_FULL_NUMERICAL_REGENERATION_AND471_KERNEL_RATIONAL_PROFILE',seconds=time.monotonic()-start,
        records=records,source_modules=471,theorem_roots=49,mathematical_receipt_sha256=sha(proof),
        numerical_receipt_sha256=sha(out/'numerics/RECEIPT.json'),word_association_sha256=sha(out/'WORD_ASSOCIATION.json'),
        source_lock_sha256=sha(B/'SOURCE_LOCK.json'),source_first_PV=False,namespace_isolated=False,
        qualification='Kernel-only mathematical verification with regenerated exact proposals. Generic compiler runtime OS ABI hardware apply to numerical reproducibility; final mathematical truth is independently checked by Lean kernel.')
    t=out/'RECEIPT.pending';t.write_text(json.dumps(d,indent=2)+'\n');os.replace(t,out/'RECEIPT.json');print(d['status'])
if __name__=='__main__':main()
