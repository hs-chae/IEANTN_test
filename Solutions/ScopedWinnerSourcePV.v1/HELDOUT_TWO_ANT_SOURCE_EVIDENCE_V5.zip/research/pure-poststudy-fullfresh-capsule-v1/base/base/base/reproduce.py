"""Run standalone471-source pure-kernel comparator from an empty application bank."""
from pathlib import Path
import argparse,json,subprocess,sys,hashlib,os,time
from check_inputs import source_inputs,need,sha,strict
B=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--environment',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True);ap.add_argument('--jobs',type=int,default=3)
    a=ap.parse_args();need(1<=a.jobs<=4,'jobs1..4')
    lock=source_inputs();out=a.out.resolve();need(not out.exists() and B not in out.parents,'fresh output outside immutable capsule')
    need(a.environment.is_file(),'pinned public generic environment required')
    out.mkdir(parents=True);start=time.monotonic();flags=['-OO'] if sys.flags.optimize>=2 else ['-O'] if sys.flags.optimize else []
    command=[sys.executable,*flags,str(B/'reproduce_kernel_graph.py'),'--environment',str(a.environment.resolve()),
        '--out',str(out/'proofs'),'--jobs',str(a.jobs)]
    with (out/'proofs.stdout').open('wb') as f,(out/'proofs.stderr').open('wb') as g:
        q=subprocess.run(command,stdout=f,stderr=g)
    need(q.returncode==0,'471-source proof replay failed; preserve partial logs')
    p=out/'proofs/RECEIPT.json';r=strict(p.read_text())
    need(r['status']=='PASS_KERNEL_ONLY_HEIGHT_PNT_SOURCE_COLD' and r['source_modules']==471 and
        r['theorem_roots']==49 and r['application_object_inputs']==[],'full471/49 actual acceptance')
    need([x['name'] for x in r['audits']]==lock['roots'] and all(set(x['axioms'])<=
        {'propext','Classical.choice','Quot.sound'} for x in r['audits']),'exact final standard-axiom population')
    source_inputs()
    d=dict(status='PASS471_PURE_KERNEL_RATIONAL_PROFILE_SOURCE_COLD',seconds=time.monotonic()-start,
        command=command,source_modules=471,theorem_roots=49,proof_receipt_sha256=sha(p),
        source_lock_sha256=sha(B/'SOURCE_LOCK.json'),reproducer_sha256=sha(Path(__file__)),
        application_object_inputs=[],source_first_PV=False,namespace_isolated=False,
        qualification='Fresh independent strengthened posthoc kernel-only build of campaign-generated numerical evidence; no C source-execution module imports. The actual-source implementation guarantee is established separately, and no coefficient advantage of PV is claimed.')
    t=out/'RECEIPT.pending';t.write_text(json.dumps(d,indent=2)+'\n');os.replace(t,out/'RECEIPT.json');print(d['status'])
if __name__=='__main__':main()
