"""Freeze an additive full-fresh numerical + kernel-only comparator, without proof claims."""
from pathlib import Path
import json,hashlib,shutil,re
R=Path(__file__).resolve().parents[2];B=R/'research/pure-poststudy-fullfresh-capsule-v1'
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 need(not B.exists(),'fresh capsule');B.mkdir()
 shutil.copytree(R/'research/kernel-pi-psi300-extension-v1',B/'base',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.olean'))
 for case,mods in[('H01-PROSE',['TaskDefinitions','Formal','Tail']),('H02-STRUCTURED',['Main'])]:
  d=B/'candidate'/case;d.mkdir(parents=True)
  for m in mods:
   p=R/'exposure/heldout-study-v1/cases'/case/'submission'/(m+'.lean');shutil.copy2(p,d/p.name)
 d=B/'source/SynergyPostStudyNPlus';d.mkdir(parents=True)
 reciprocal=(R/'research/poststudy-ant-v1/lean/SynergyHeightC/ReciprocalRead300.lean').read_text()
 reciprocal=reciprocal.replace('import SynergyHeightC.MainPiPsi300Read','import SynergyAnalytic.PureKernelPiPsi300').replace('namespace SynergyHeightC.ReciprocalRead300','namespace SynergyPostStudyNPlus.Reciprocal300').replace('end SynergyHeightC.ReciprocalRead300','end SynergyPostStudyNPlus.Reciprocal300')
 reciprocal=reciprocal.replace('open ScopedC ScopedC.Machine ScopedNumerical SynergyBasis ScopedIO\n','')
 start=reciprocal.index('    {out : ProofBox}');end=reciprocal.index('    (h : PrimaryInputs',start);reciprocal=reciprocal[:start]+reciprocal[end:]
 reciprocal=reciprocal.replace('from_actual_total_read','prime_reciprocal')
 reciprocal=reciprocal.replace('have ray := (MainPiPsi300Read.pi_psi_300_from_actual_total_read read\n    h hCHJ hrvm hsmall hlow hRH hQRH).1','have ray := SynergyAnalytic.HeightPoint.PureKernelPiPsi300.pi_300\n    h hCHJ hrvm hsmall hlow hRH hQRH')
 reciprocal=reciprocal.replace('/- Poststudy integration of the unchanged, independently checked H01-PROSE proof.\nThe actual source-produced total read supplies its sole prime-counting input. -/','/- Strengthened posthoc kernel-only N+ comparator. The original H01-PROSE\nsource is unchanged; its sole pi input is supplied without C execution proofs. -/')
 (d/'Reciprocal300.lean').write_text(reciprocal)
 theta=(R/'research/poststudy-ant-v1/lean/SynergyHeightC/ThetaRead300.lean').read_text()
 theta=theta.replace('import SynergyHeightC.MainPiPsi300Read','import SynergyAnalytic.PureKernelPiPsi300').replace('namespace SynergyHeightC.ThetaRead300','namespace SynergyPostStudyNPlus.Theta300').replace('end SynergyHeightC.ThetaRead300','end SynergyPostStudyNPlus.Theta300').replace('open ScopedC ScopedC.Machine ScopedNumerical SynergyBasis ScopedIO\n','')
 start=theta.index('    {out : ProofBox}');end=theta.index('    (h : PrimaryInputs',start);theta=theta[:start]+theta[end:]
 theta=theta.replace('from_actual_total_read','theta')
 theta=theta.replace('have ray := (MainPiPsi300Read.pi_psi_300_from_actual_total_read read\n    h hCHJ hrvm hsmall hlow hRH hQRH).2','have ray := SynergyAnalytic.HeightPoint.PureKernelPiPsi300.psi_300\n    h hCHJ hrvm hsmall hlow hRH hQRH')
 theta=theta.replace('/- Poststudy integration of unchanged H02-STRUCTURED. The psi input is discharged\nfrom the same actual C source-main physical total read, with all fourteen inputs. -/','/- Strengthened posthoc kernel-only N+ comparator of unchanged H02-STRUCTURED.\nThe psi input comes from the campaign numerical evidence, not C execution proofs. -/')
 (d/'Theta300.lean').write_text(theta)
 d=B/'source/IEANTN/Vocabulary';d.mkdir(parents=True);shutil.copy2(R/'research/poststudy-ant-v1/lean/IEANTN/Vocabulary/PrimeReciprocal.lean',d/'PrimeReciprocal.lean')
 (B/'LSP_FALLBACK.json').write_text(json.dumps(dict(status='LSP_REJECTED_EXISTING_EXPLICIT_BANK_FILE_NO_LEAN_TOOLCHAIN_ANCESTOR',queried_file='research/poststudy-ant-v1/lean/SynergyHeightC/ReciprocalRead300.lean',queried_line=46,fallback='Pinned explicit source-bank compilation in authorized24GiB run; no LSP success claimed.'),indent=2)+'\n')
 for p in B.rglob('*.lean'):
  if p.is_relative_to(B/'source'):
   need(not any(x in p.read_text()for x in['ScopedC.','ScopedIO.','SynergyHeightC.','native_decide','sorry','axiom ']),'no C/native/admit proof imports')
 print(B)
if __name__=='__main__':main()
