"""Freeze complete source-only4076-source two-consumer continuation; no replay claim."""
from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parents[2];B=R/'research/source-poststudy-ant-capsule-v1'
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 need(not B.exists(),'fresh source capsule');B.mkdir();shutil.copytree(R/'research/source-rational-profile-overlay-capsule-v3',B/'base',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.olean'))
 common=[]
 for step in json.loads((R/'research/earlier-onset-v1/SOURCE_RECEIPT.json').read_text())['steps']:
  receipt=Path(step['receipt']);data=json.loads(receipt.read_text());source=receipt.parent/'source.lean';need(data['status']=='PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES','actual accepted source300step');p=B/'source/shared'/Path(step['module'].replace('.','/')).with_suffix('.lean');p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,p)
  common.append(dict(module=step['module'],path=str(p.relative_to(B)),source_root='source/shared',sha256=sha(p),bytes=p.stat().st_size,roots=step['roots'],accepted_receipt=str(receipt.relative_to(R)),accepted_receipt_sha256=sha(receipt)))
 extra=[]
 for case,modules in[('H01-PROSE',['TaskDefinitions','Formal','Tail']),('H02-STRUCTURED',['Main'])]:
  for module in modules:
   source=R/'research/poststudy-ant-v1'/('original-'+case)/(module+'.lean');p=B/'candidate'/case/source.name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,p);extra.append(dict(identity=case+'/'+module,module=module,path=str(p.relative_to(B)),source_root='candidate/'+case,sha256=sha(p),bytes=p.stat().st_size))
 for p in sorted((R/'research/poststudy-ant-v1/lean').rglob('*.lean')):
  dest=B/'source/consumers'/p.relative_to(R/'research/poststudy-ant-v1/lean');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);module=str(p.relative_to(R/'research/poststudy-ant-v1/lean').with_suffix('')).replace('/','.');extra.append(dict(identity=module,module=module,path=str(dest.relative_to(B)),source_root='source/consumers',sha256=sha(dest),bytes=dest.stat().st_size))
 branch=[dict(name='reciprocal',source_order=['H01-PROSE/'+x for x in['TaskDefinitions','Formal','Tail']]+['IEANTN.Vocabulary.PrimeReciprocal','SynergyHeightC.ReciprocalRead300','SynergyHeightC.ReciprocalProgram300'],roots=['IEANTN.primeReciprocal']+['SynergyHeightC.ReciprocalRead300.'+x for x in['pi_alias','li_alias','error_alias','reciprocal_alias','from_actual_total_read']]+['SynergyHeightC.ReciprocalProgram300.main_observed_prime_reciprocal','ExposureTask.final_consumer'],root_modules=['SynergyHeightC.ReciprocalProgram300']),dict(name='theta',source_order=['H02-STRUCTURED/Main','SynergyHeightC.ThetaRead300','SynergyHeightC.ThetaProgram300'],roots=['SynergyHeightC.ThetaRead300.'+x for x in['psi_alias','theta_alias','from_actual_total_read']]+['SynergyHeightC.ThetaProgram300.main_observed_theta']+['ExposureTask.'+x for x in['theta_two_term','theta_transport','theta_target']],root_modules=['SynergyHeightC.ThetaProgram300'])]
 lock=dict(schema='SOURCE4076_TWO_POSTSTUDY_ANT_CONSUMERS_CONTINUATION_V1',base4057_source_lock_sha256=sha(B/'base/SOURCE_LOCK.json'),base_modules=4057,base_roots=12234,shared_sources=common,branch_sources=extra,branches=branch,total_written_source_files=4076,same14_analytic_inputs=True,actual_C_source_algorithm_output_unchanged=True,original_exposure_sources_and_scores_unchanged=True,qualification='Prepared source-only continuation; warm5module/11root parent acceptance is separate. Complete fresh isolated replay remains pending; separate branch banks preserve original ExposureTask.C declarations.')
 (B/'SOURCE_LOCK.json').write_text(json.dumps(lock,indent=2)+'\n')
 print(len(common),len(extra),sha(B/'SOURCE_LOCK.json'))
if __name__=='__main__':main()
