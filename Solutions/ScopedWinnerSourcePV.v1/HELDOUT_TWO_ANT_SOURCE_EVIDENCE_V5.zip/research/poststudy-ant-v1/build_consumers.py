"""Build additive source-read/whole-main consumers using separate coherent banks."""
from pathlib import Path
import json,hashlib,subprocess,sys,os,time
R=Path(__file__).resolve().parents[2];B=R/'research/poststudy-ant-v1'
def need(x,m):
 if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 steps=[
  ('reciprocal','IEANTN.Vocabulary.PrimeReciprocal',['IEANTN.primeReciprocal'],'vocabulary-v1'),
  ('reciprocal','SynergyHeightC.ReciprocalRead300',['SynergyHeightC.ReciprocalRead300.'+x for x in['pi_alias','li_alias','error_alias','reciprocal_alias','from_actual_total_read']],'reciprocal-read-v1'),
  ('reciprocal','SynergyHeightC.ReciprocalProgram300',['SynergyHeightC.ReciprocalProgram300.main_observed_prime_reciprocal'],'reciprocal-program-v1'),
  ('theta','SynergyHeightC.ThetaRead300',['SynergyHeightC.ThetaRead300.'+x for x in['psi_alias','theta_alias','from_actual_total_read']],'theta-read-v1'),
  ('theta','SynergyHeightC.ThetaProgram300',['SynergyHeightC.ThetaProgram300.main_observed_theta'],'theta-program-v1')]
 out=B/'build-v1';need(not out.exists(),'fresh poststudy build');out.mkdir();records=[];start=time.monotonic()
 for branch,module,roots,attempt in steps:
  bank=B/(branch+'-bank-v1/objects');target=out/attempt
  command=[sys.executable,str(R/'research/main-weight-v1/compile_consumer.py'),'--source-root',str(B/'lean'),'--module',module,'--bank',str(bank),'--out',str(target),'--publish-object']
  for root in roots:command+=['--root',root]
  q=subprocess.run(command,cwd=R,capture_output=True,text=True);(out/(attempt+'.stdout')).write_text(q.stdout);(out/(attempt+'.stderr')).write_text(q.stderr);need(q.returncode==0,'poststudy exact-source consumer failed '+attempt)
  receipt=target/'RECEIPT.json';d=json.loads(receipt.read_text());need(d['status']=='PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES'and d['roots']==roots,'strict exact roots '+attempt)
  records.append(dict(branch=branch,module=module,roots=roots,receipt=str(receipt.relative_to(R)),receipt_sha256=sha(receipt),seconds=d['seconds']))
 result=dict(status='PASS_POSTSTUDY_ORIGINAL_H01_H02_PROOFS_CONSUME_ACTUAL_SOURCE_MAIN_READ_AND_OBSERVED_OUTPUT',steps=records,seconds=time.monotonic()-start,source_cold=False,namespace_isolated=False,original_cases_and_outcomes_unchanged=True,qualification='New poststudy source-read/program composition only; independent original candidate source proofs stay byte-identical. Separate coherent branch banks avoid ExposureTask.C collision. Same14inputs, actual same read genuinely supplies pi/psi premise; no raw output oracle. Whole new source-cold namespace continuation remains separate.')
 tmp=out/'RECEIPT.pending';tmp.write_text(json.dumps(result,indent=2)+'\n');os.replace(tmp,out/'RECEIPT.json');print(result['status'])
if __name__=='__main__':main()
