"""One coherent accepted parent plus exact original independently checked candidate objects.

Never union two ExposureTask implementations; never import the uncompiled diagnostic stubs.
"""
from pathlib import Path
import hashlib,json,os,shutil
R=Path(__file__).resolve().parents[2];B=R/'research/poststudy-ant-v1'
def need(x,m):
 if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 parent=R/'research/main-final-total-bank-v3/objects';inputs=[]
 for p in sorted(parent.rglob('*.olean')):inputs.append((p,p.relative_to(parent),sha(p)))
 need(inputs and not any((parent/n).exists()for n in['TaskDefinitions.olean','Formal.olean','Tail.olean','Main.olean']),'one coherent parent has no candidate collision')
 verification=R/'exposure/heldout-independent-v1/namespace/data/verification';cases=[('reciprocal','H01-PROSE',['TaskDefinitions','Formal','Tail']),('theta','H02-STRUCTURED',['Main'])]
 receipts=[]
 for branch,case,modules in cases:
  out=B/(branch+'-bank-v1');need(not out.exists(),'fresh branch bank');bank=out/'objects';bank.mkdir(parents=True)
  for source,rel,digest in inputs:
   target=bank/rel;target.parent.mkdir(parents=True,exist_ok=True);os.link(source,target);need(sha(target)==digest,'immutable one-parent hardlink')
  original=R/'exposure/heldout-study-v1/cases'/case/'submission';receipt=verification/case/'RECEIPT.json';record=json.loads(receipt.read_text());need(not record['nonstandard_axiom_roots'],'original exact root closures standard')
  source_root=B/('original-'+case);source_root.mkdir(exist_ok=False);added=[]
  for module in modules:
   command=next(x for x in record['commands']if x['module']==module);source=original/(module+'.lean');obj=verification/case/'objects'/(module+'.olean')
   need(command['exit_code']==0 and command['source_sha256']==sha(source)and command['object_sha256']==sha(obj),'original source/object/command')
   need(not(bank/(module+'.olean')).exists(),'no object shadowing');os.link(obj,bank/(module+'.olean'));shutil.copy2(source,source_root/source.name)
   added.append(dict(module=module,source=str(source.relative_to(R)),source_sha256=sha(source),object=str(obj.relative_to(R)),object_sha256=sha(obj)))
  result=dict(status='ONE_COHERENT_PARENT_PLUS_EXACT_ORIGINAL_CHECKED_CANDIDATE_NO_SOURCE_CONSUMER_BUILD_YET',branch=branch,parent=str(parent.relative_to(R)),parent_objects=[dict(module=str(rel.with_suffix('')).replace('/','.'),sha256=digest)for _,rel,digest in inputs],candidate=case,candidate_receipt=str(receipt.relative_to(R)),candidate_receipt_sha256=sha(receipt),candidate_objects=added,source_copy_root=str(source_root.relative_to(R)),qualification='Poststudy integration only. Original candidate sources/locks/primary outcomes untouched. Separate banks because both original tasks define ExposureTask.C. Physical total-read/program join still must compile; no new source-first acceptance from seeding.')
  (out/'SEED_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n');receipts.append(dict(branch=branch,parent_count=len(inputs),candidate_modules=modules,bank=str(bank.relative_to(R))))
 print(json.dumps(receipts))
if __name__=='__main__':main()
