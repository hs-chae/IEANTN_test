# Verified fresh1412 source-point/conditional ANT supplement

ACTUAL PASS: the unchanged source-only input component now has a complete fresh
replay of all1412 application modules,574 payloads and2350 complete selected
standard-axiom closures, with no old application-object inputs. Actual524-file
C compile/run, allfive numerical regenerations and exact word associations
also passed. This is supplemental evidence, never a retroactive primary result.

Scope wall8132.540s; full pipeline8130.873s; proof phase8102.192s. All recorded
OOM events were zero. Sampled charged peak88,929,918,976B is a lower bound;
true charged peak was unavailable. Maximum individual compiler/audit RSS was
18,477,228,032B across1413 records. Final owned regular-file bytes334,699,469;
disk peak was not instrumented. These are separate measurements.

Extract SOURCE_INPUTS.zip and follow its unchanged README/prepare_environment.py
and reproduce_all.py to regenerate the actual C/numerical data and all proofs.
The source archive is self-contained and uses only the pinned public generic
Lean/mathlib environment; no prior research application objects are needed.
All original source locks, raw receipts, parameters and historical outcomes
are preserved. The independent readback checks every source/object/log/time,
allnine validator identities and exact2350 raw/receipt axiom roots.

QUALIFICATION_ERRATUM.json explains the preparation-time 'fresh replay pending'
sentence copied into the immutable inner receipt; the actual run fields, raw
compile/audit records and independent readback prove completion. Raw bytes
were not edited to hide the stale boilerplate.

This accepts the finite bare-cache source-point/ANT graph. The complete main,
physical frames, C-expression accumulation and I/O graph are separate appended
replays. It is host source-cold verification, not final namespace isolation or
complete migration of the original68-function program. Generic compiler/core
runtime, ABI, OS/API and hardware trust boundaries remain documented.
