"""Freeze actual source/object compile associations for the unchanged point backend."""
import collections,hashlib,json,shutil
from pathlib import Path
B=Path(__file__).resolve().parent;R=B.parents[1];F=R/'research/source-points-v2';W=R.parent

def need(x,m):
 if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 need(not(B/'SOURCE_LOCK.json').exists(),'already frozen');rows=json.loads((F/'DEPENDENCY_OBJECTS.json').read_text());index=collections.defaultdict(list)
 for base in [R/'research/analytic/work',R/'scoped/frontend',R/'scoped/build',R/'research/basis-source']:
  for p in base.rglob('RECEIPT.json'):
   try:d=json.loads(p.read_text())
   except(ValueError,OSError):continue
   if d.get('exit_code')==0 and d.get('source_unchanged')and d.get('source_sha256')and d.get('object_sha256')and d.get('module'):index[(d['module'],d['object_sha256'])].append((p,d))
 old=W/'ieantn-computation-led-20261111/routes/density_optimization/pnt-clean-reproduction-v1';oldr=old/'RECEIPT.json';oldj=json.loads(oldr.read_text());need(oldj['status']=='PASS','actual previous source-cold baseline')
 for d in oldj['modules']:
  if d['exit_code']==0 and not d['sorryAx']:
   index[(d['module'],d['object_sha256'])].append((oldr,dict(d,source=str(old/'source'/Path(d['module'].replace('.','/')).with_suffix('.lean')))))
 cold=R/'scoped/height-init-source-cold-v1/capsule-v1';cp=R/'scoped/build/height-init113-source-cold-v1/RECEIPT.json';cj=json.loads(cp.read_text());cl=json.loads((cold/'SOURCE_LOCK.json').read_text());need(cj['status']=='PASS_HEIGHT_ACTUAL_SOURCE_INIT113_SOURCE_COLD'and sha(cold/'SOURCE_LOCK.json')==cj['source_lock_sha256'],'accepted113 source lock')
 cmap={x['module']:x for x in cl['sources']}
 for d in cj['records']:
  if d.get('name')in cmap and d['exit_code']==0:
   row=cmap[d['name']];index[(d['name'],d['object_sha256'])].append((cp,dict(module=d['name'],source=str(cold/row['path']),source_sha256=row['sha256'])))
 sources=[];missing=[];roots=[R/'scoped/frontend/lean',R/'research/basis-source/lean',R/'research/analytic/lean']
 for row in rows:
  rel=Path(row['module'].replace('.','/')).with_suffix('.lean');candidates=[]
  for p,d in index[(row['module'],row['sha256'])]:
   for q in [p.parent/'source.lean',*[b/rel for b in roots],Path(d.get('source','/nonexistent'))]:
    if q.is_file()and sha(q)==d['source_sha256']:candidates.append((q,p,d['source_sha256']))
  if not candidates:missing.append(row['module']);continue
  q,receipt,h=candidates[0];dest=B/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(q,dest);sources.append(dict(module=row['module'],path=str(rel),sha256=h,compiled_import_object_sha256=row['sha256'],actual_source_origin=str(q),compile_receipt=str(receipt),compile_receipt_sha256=sha(receipt)))
 need(not missing,'missing exact object/source association '+str(missing))
 copied=[]
 for p in sorted((R/'research/analytic/height-bundle-source-v3').iterdir()):
  need(p.is_file()and not p.is_symlink(),'physical C tree only');dest=B/'height-bundle-source-v3'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(p,dest);copied.append(dict(path=p.name,sha256=sha(p)))
 for row in json.loads((F/'PLAN.json').read_text())['sources']:
  p=F/'source'/row['path'];need(sha(p)==row['sha256'],'actual768 point sourcepin');dest=B/'source'/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 lock=dict(status='FROZEN388_ACTUAL_OBJECT_SOURCE_ASSOCIATIONS_AND768_POINT_SOURCES',modules=sources,point_plan_sha256=sha(F/'PLAN.json'),physical_C_files=copied,source_first_full_program_complete=False,qualification='Source-only reproduction inputs, not a new cold acceptance. Actual past source/object receipts matched for every388 imported application module. Startup/main/I/O still required.')
 (B/'SOURCE_LOCK.json').write_text(json.dumps(lock,indent=2)+'\n');shutil.copyfile(F/'PLAN.json',B/'POINT_PLAN.json');print(json.dumps(dict(status=lock['status'],application_modules=len(sources),points=768,C_files=len(copied))))
if __name__=='__main__':main()
