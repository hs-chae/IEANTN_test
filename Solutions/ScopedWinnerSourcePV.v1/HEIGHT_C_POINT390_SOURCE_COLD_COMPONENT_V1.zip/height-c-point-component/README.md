# Reproduce the actual height C point component

This source-only component freezes every source used by the 388 application modules actually imported by the point checker, together with all 768 point-proof sources and all 524 physical C files. Each imported object was matched to its actual compiler receipt and exact source hash before source capture. `SOURCE_ASSOCIATIONS.json` records that correspondence; it is provenance, not an instruction to trust or import old application objects.

The default proof recipe starts with an empty application-object directory, rebuilds those 388 modules, and checks actual C point calls 0 and 767. It audits ten complete roots, including source-call correctness, real-output enclosure linkage, both exact input definitions, both checked executions and both actual pointer-output theorems. The optional full recipe rebuilds all 1,156 modules (388 plus 768 points) and audits 2,308 roots. No application object inputs are allowed. A written recipe is not an accepted run: consult its final receipt rather than a progress file.

These are **host source-cold component replays**. They do not establish namespace isolation or the complete C startup/main/input/loop/output path. The actual point calls begin from the explicitly specified bare cache with empty runtime arena. The actual initializer and the actual main frame need their own source proofs and connection to this state. Connecting the same actual pointer outputs to the PNT consumer is tracked separately; an unused SourceRun is never appended to an independently proved numerical claim.

## Clean environment

On Linux x86-64, install Python3, Git, tar/zstd and C/C++ system headers. Bootstrap only the exact public compiler and generic libraries:

```sh
python3 environment-bootstrap/scripts/bootstrap.py --work /fresh/public-env --receipt /fresh/bootstrap.json
python3 prepare_environment.py --toolchain /fresh/public-env/lean-4.34.0-rc2-linux --mathlib /fresh/public-env/mathlib --out /fresh/environment.json
python3 reproduce.py --environment /fresh/environment.json --out /fresh/point-component --jobs 1
```

To execute every point in a new source-cold run:

```sh
python3 reproduce.py --environment /fresh/environment.json --out /fresh/all-points --jobs 4 --all-points
```

Use the owner's resource policy and inspect RAM and free disk separately before launching. One point's accepted full-contract benchmarks took about 68–75 seconds and sampled 10.5–11.2 GB of charged memory; individual RSS includes shared imported pages and can be higher. Parallel jobs multiply working memory. Earlier larger initializer computations are a different workload and have their own resource receipts. No arbitrary 4 GiB cap is appropriate. Keep the study's aggregate limit and host reserves intact.

Every recipe validates compiler/runtime bytes, generic dependency commits, the full source/payload hashes before and after compilation, compiler exits, absence of admitted proofs, exact selected root population and standard-only axiom closures. Acceptance uses explicit errors and survives Python optimization. The numerical program has 128-bit directed intervals, 768 logarithmic cells, 58 constants and a 187-value expression program with coefficient/slope outputs184/186. The eleven subroutine summaries prove actual C source-call contracts; they accelerate proof checking without changing the C numerical algorithm, parameters or results. There is no random seed.

## Reproduce compiled C association

```sh
python3 reproduce_cpp.py --compiler /fresh/public-env/lean-4.34.0-rc2-linux/bin/clang --out /fresh/cpp-run
```

This compiles the exact physical C bundle and compares all 1,538 output words with the locked hash. The owned executable is removed only after exact output checks and a binary hash are recorded. This raw association run is distinct from the source execution proof, and does not by itself prove application correctness or the output stream.

## Trust and retained evidence

Trusted boundaries are Lean's kernel, the pinned compiler/core runtime, ABI and documented OS/API/hardware contracts. Pinned Clang/Itanium ordinary-call order and the precise scalar-comparison route are explicitly documented in the research evidence. Generic compiler correctness is not proved here. Application state, allocation/lifetime applicability, successful effects and correct outputs are proof obligations.

Keep proof sources, locked inputs, accepted proof artifacts and final receipts. The package contains no application object caches. Generated C binaries, duplicate scratch objects and raw AST dumps can be regenerated; remove only verified experiment-owned copies after checking reproduction. Never remove the only copy of essential evidence. Historical original experiments and stronger conditional mathematical theorems remain unchanged.
