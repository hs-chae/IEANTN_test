"""Actual malformed-environment CLI routes in every Python optimization mode."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[2]
C=R/'research/direct-vector-source-capsule-v3'
OUT=R/'research/analytic/root568-json-cli-v2'

def need(ok,msg):
    if not ok:raise ValueError(msg)
def main():
    need(not OUT.exists(),'fresh control directory');OUT.mkdir()
    records=[]
    bads=['{"a":1,"a":2}','{"a":NaN}','{"a":Infinity}','{"a":1e999}','{"a":-1e999}','{']
    for mode in range(3):
        for index,bad in enumerate(bads):
            env=OUT/('environment-'+str(mode)+'-'+str(index)+'.json');env.write_text(bad)
            out=OUT/('run-'+str(mode)+'-'+str(index))
            command=[sys.executable,'-B']+(['-'+('O'*mode)] if mode else [])+[str(C/'reproduce.py'),'--environment',str(env),'--out',str(out)]
            child=subprocess.run(command,cwd=R,capture_output=True,text=True,timeout=60)
            (OUT/(str(mode)+'-'+str(index)+'.stdout')).write_text(child.stdout)
            (OUT/(str(mode)+'-'+str(index)+'.stderr')).write_text(child.stderr)
            need(child.returncode!=0 and not(out/'RECEIPT.json').exists(),'bad environment must not publish acceptance')
            need((out/'proposal/Data.lean').is_file(),'actual full proof route reached environment parse after proposal regeneration')
            records.append(dict(mode=mode,case=index,exit_code=child.returncode,command=command))
    result=dict(status='PASS568_ACTUAL_MALFORMED_ENVIRONMENT_CLIS_0_O_OO',actual_CLI_negative_cases=18,python_modes=[0,1,2],records=records,qualification='All18actualfull-route CLI invocations regenerated the locked768cell Data source and then rejected malformed environment JSON before Lean launch; no final mathematical acceptance receipt. This verifies strict rejection survives Python optimization, not a mathematical replay.',recipe_sha256=hashlib.sha256((C/'reproduce.py').read_bytes()).hexdigest(),validator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    target=R/'research/analytic/ROOT568_ACTUAL_JSON_CLI_CONTROLS_V2.json';need(not target.exists(),'fresh receipt');tmp=target.with_suffix('.pending');tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.replace(target)
    print(result['status'])
if __name__=='__main__':main()
