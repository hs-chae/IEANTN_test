"""Root actual CLI/input/schema controls for the fixed565+3 continuation.
This is a bounded recipe/launcher/mathematical read-through review, not a
new Lean execution, complete primary-source audit or full clean568 replay.
"""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[2]
C=R/'research/direct-vector-source-capsule-v3'
OUT=R/'research/analytic/root568-bounded-controls-v2'

def need(ok,msg):
    if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    need(not OUT.exists(),'fresh owned control output')
    OUT.mkdir()
    pins=[(C/'reproduce.py','d9b74c9c79f92f6f8f210720c7a240363ad248f980c0a267a9f42085bc5c6177'),(R/'research/namespace-replay-v1/launch_chained568_v1.py','c2c31ba5cf3bae057de68edc90b22dc5ea2b1c6e586368ba3d585efb8ef5db3b')]
    for p,digest in pins:need(sha(p)==digest,'reviewed frozen code')
    runs=[]
    for level in range(3):
        flags=['-'+('O'*level)] if level else []
        for case in ['accepted-inputs','reject-existing-output','reject-missing-environment','reject-unknown-option']:
            out=OUT/(str(level)+'-'+case)
            args=['--out',str(out)]
            if case=='accepted-inputs':args+=['--check-inputs-only']
            elif case=='reject-existing-output':args=['--out',str(OUT)]
            elif case=='reject-unknown-option':args+=['--not-an-option']
            cmd=[sys.executable,'-B',*flags,str(C/'reproduce.py'),*args]
            child=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60)
            stem=OUT/(str(level)+'-'+case)
            Path(str(stem)+'.stdout').write_text(child.stdout)
            Path(str(stem)+'.stderr').write_text(child.stderr)
            if case=='accepted-inputs':
                need(child.returncode==0,'actual accepted CLI')
                d=json.loads((out/'RECEIPT.json').read_text())
                need(d['status']=='PASS568_EXACT_SOURCES_AND_REGENERATED_PROPOSAL_ONLY_NOT_REPLAY','input route only')
            else:
                need(child.returncode!=0,'actual rejected CLI')
                need(not (out/'RECEIPT.json').exists(),'no stale success after rejected route')
            runs.append(dict(mode=level,case=case,exit_code=child.returncode,command=cmd))
    parsers=[]
    for path,function in [(C/'reproduce.py','parse'),(R/'research/namespace-replay-v1/launch_chained568_v1.py','read_json'),(R/'research/namespace-replay-v1/entry_chained568_v1.py','read_json')]:
        spec=importlib.util.spec_from_file_location('review_'+path.stem,path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        parser=getattr(module,function)
        for n,bad in enumerate(['{"a":1,"a":2}','{"a":NaN}','{"a":Infinity}','{"a":1e999}','{"a":-1e999}','{']):
            inp=OUT/('bad-'+path.stem+'-'+str(n)+'.json');inp.write_text(bad)
            try:parser(bad if function=='parse' else inp)
            except (ValueError,json.JSONDecodeError):pass
            else:raise ValueError('malformed JSON accepted')
            parsers.append(dict(parser=str(path.relative_to(R)),case=n,rejected=True))
    result=dict(status='PASS_ROOT_BOUNDED568_RECIPE_LAUNCHER_AND_MATHEMATICAL_READ_THROUGH_CONTROLS',actual_CLI_cases=12,direct_JSON_negative_cases=18,python_modes=[0,1,2],runs=runs,parser_cases=parsers,code_pins={str(p.relative_to(R)):digest for p,digest in pins},scope='Root manually read entire recipe, launcher, entry, Model/Real and Data namespace/declaration/print sections, and verified all17 written file/line/qualified-root identities against accepted warm receipts. Validated actual CLI input/proposal-regeneration route and bounded negative routes; not final isolated proof execution.',math_review=['Exact mass boxes recovered from proved prefix addition without an assumed numerical provider.','Positive interval division derives full vector rational enclosure with each D<=163<300.','Proved sign discards paired exponential only for an upper bound.','Vector sum reaches both pi/psi exp300 consumers under unchanged14 assertions.','Strict .008732871<.008848544 is proved; this is ordinary kernel checking, not source-first PV.'],qualification='Prior V1/V2 root inventory was rejected by actual finalaudit after all3sourcecompiles; its historical failure/reviewlimitation is preserved. New V3 exactwritten inventory fixes only names; unchanged3Lean sources and mathematical candidate. Final568run is a checked565same-pipeline RO seed plus3new proof modules, not an empty-bank568run. Full-clean565+3 route provided but not executed by these controls. Typed17newroot gate now explicitly checks nonemptytype_repr and Std3. Fullprimarysourceaudit/globallystrongestN+ notclaimed.',new_Lean_replay=False,source_first_PV=False,validator_sha256=sha(Path(__file__)))
    target=R/'research/analytic/ROOT568_BOUNDED_REVIEW_CONTROLS_V2.json'
    need(not target.exists(),'fresh review receipt')
    temporary=target.with_suffix('.pending');temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(target)
    print(json.dumps(dict(status=result['status'],CLI_cases=12,JSON_negative_cases=18,receipt_sha256=sha(target))))
if __name__=='__main__':main()
