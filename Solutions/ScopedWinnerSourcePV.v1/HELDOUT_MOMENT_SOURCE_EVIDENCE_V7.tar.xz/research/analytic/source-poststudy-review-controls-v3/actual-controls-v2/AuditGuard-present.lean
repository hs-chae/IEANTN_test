import Lean.Elab.Term
import Lean.Util.CollectAxioms
open Lean Elab
run_elab do
 let env ← getEnv
 let n := `Nat.add_comm
 let some _ := env.find? n | throwError "missing theorem guard control"
 let ax ← Lean.collectAxioms n
 logInfo m!"AUDIT_GUARD_CONTROL {(Json.mkObj [("name",toJson n.toString),("axioms",toJson (ax.toList.map Name.toString))]).compress}"
