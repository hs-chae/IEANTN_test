"""Recheck actual corrected N+ chain, retaining the initial failedfullattempt."""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parents[2]
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(p):
 def pairs(xs):
  d={}
  for k,v in xs:need(k not in d,'duplicate JSON key');d[k]=v
  return d
 return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in()).throw(ValueError(x)))
def scope_metrics(p):
 a=strict(p);samples=a['samples'];charge=max([int(x.get('memory.current','0'))for x in samples]or[0]);oom=max([int(m.group(1))for x in samples for m in re.finditer(r'^oom_kill\s+(\d+)$',x.get('memory.events',''),re.M)]or[0]);return dict(exit_code=a['exit_code'],elapsed_seconds=a['elapsed_seconds'],sampled_charged_RAM_lower_bound_bytes=charge,exact_aggregate_peak_RAM_bytes=None,observed_OOM_kills=oom,scope_sha256=sha(p))
def main():
 first=R/'research/pure-poststudy-fullfresh489-run-v1';run=R/'research/pure-poststudy-resume489-run-v2';capsule=R/'research/pure-poststudy-fullfresh-capsule-v2';out=R/'research/analytic/PURE489_RESUMED_ACCEPTANCE_V2.json';need(not out.exists(),'fresh summary');r=strict(run/'RECEIPT.json');need(r['status']=='PASS_RESUMED_FRESH482_PLUS_CORRECTED_TWO_KERNEL_ONLY_ANT_BRANCHES'and r['source_files']==489 and r['resumed_after_failed_V1']and r['C_proposal_executions']==0 and r['same_pipeline_prior_C_proposal_executions']==15 and r['outside_application_object_inputs']==[],'actual corrected resumedchain status')
 need(r['source_lock_sha256']==sha(capsule/'SOURCE_LOCK.json')and r['reproducer_sha256']==sha(capsule/'reproduce.py')and r['base482_association_sha256']==sha(run/'BASE482_ASSOCIATION.json'),'actual accepted source/runner/parent associations');branches=[]
 for br in r['branches']:
  text=(run/'logs'/(br['name']+'-audit.stdout')).read_text();rows=[json.loads(s.split('POSTSTUDY_NPLUS_AUDIT ',1)[1])for s in text.splitlines()if'POSTSTUDY_NPLUS_AUDIT 'in s];need(rows==br['audits']and len(rows)==br['selected_roots']and all(x['type']and set(x['axioms'])<={'propext','Classical.choice','Quot.sound'}for x in rows),'actual typedpresent completeStd3audit')
  source=(run/br['name']/'Audit.lean').read_text();need('env.find? n | throwError "missing {n}"'in source,'missingrootrejection actualexecutedaudit');need(len(list((run/br['name']/'objects').rglob('*.olean')))==br['source_modules'],'actual branch objectpopulation');branches.append(dict(name=br['name'],source_modules=br['source_modules'],present_typed_Std3_roots=len(rows)))
 for rec in r['records']:
  need(rec['exit_code']==0,'all repairedcompiles/audits successful')
  for suffix,k in[('.stdout','stdout_sha256'),('.stderr','stderr_sha256'),('.time','time_sha256')]:need(sha(run/'logs'/(rec['name']+suffix))==rec[k],'unchanged actualrepairlog')
 failed=strict(first/'FAILURE.json');need(failed['status']=='FAILED_PRESERVED_NOT_ACCEPTED','originalfullattemptremainsfailed');initialscope=scope_metrics(R/'resources/pure-poststudy-fullfresh489-v1/scope.json');repair=scope_metrics(R/'resources/pure-poststudy-resume489-v2/scope.json');need(initialscope['exit_code']==1 and repair['exit_code']==0,'actual drainedscopes')
 rss=[]
 for root in[first,run]:
  for p in root.rglob('*.time'):
   m=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',p.read_text())
   if m:rss.append(int(m.group(1))*1024)
 result=dict(status='PASS_VALIDATED_FRESH482_PLUS_REPAIRED7_SOURCE_CHAIN_169_PRESENT_TYPED_STD3_ROOTS',source_files=489,branches=branches,actual15_C_proposals_regenerated_in_prior_attempt=True,new_C_proposals_regenerated_during_resume=False,initial_full489_attempt='FAILED_PRESERVED_NOT_RETROACTIVE_SUCCESS',initial_failure='Generated pureconsumer callee typo; no mathematical counterexample/resourcefailure. Failedmodulewitherror-generatedsorryAx was never accepted or reused.',initial_attempt_metrics=initialscope,resume_metrics=repair,cumulative_scope_wall_seconds=initialscope['elapsed_seconds']+repair['elapsed_seconds'],max_recorded_child_RSS_bytes=max(rss),exact_aggregate_peak_RAM_bytes=None,source_first_PV=False,namespace_isolated=False,original_exposure_scores_unchanged=True,accepted_recipe='research/pure-poststudy-fullfresh-capsule-v2',accepted_receipt_sha256=sha(run/'RECEIPT.json'),qualified_portable_recipe='research/pure-poststudy-fullfresh-capsule-v3',qualification='Same14inputs and identical prime-reciprocal/theta conclusions as source-read route. Credible strengthened posthoc kernel-only alternative; no PVcoefficientadvantage/necessity/causalityclaim. Campaign272Gaussian/768height facts and allkernelcosts charged, not originalP0gift. V2actualresume+prior482isaccepted; V3fullcleanorchestration separatelyprepared/reviewed, notuninterruptedfull489replay.')
 out.write_text(json.dumps(result,indent=2)+'\n');print(result['status'])
if __name__=='__main__':main()
