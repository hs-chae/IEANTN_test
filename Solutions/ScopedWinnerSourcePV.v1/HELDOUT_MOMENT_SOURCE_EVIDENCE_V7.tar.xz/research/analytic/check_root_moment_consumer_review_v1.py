"""Bounded independent read-through record and byte/receipt checks, not a new Lean replay.
Root manually read all five selected source-consumer modules and PNT300. This
script checks the selected accepted build evidence remains exactly associated.
It does not mechanically establish mathematical semantics or audit all sources.
"""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
CASES = [
 ("research/moment-hi-program-v1/lean/SynergyMomentCHi/AllRows.lean",
  "research/moment-actual-world-rows-v1/RECEIPT.json", 3),
 ("research/moment-hi-program-v1/lean/SynergyMomentCHi/CompleteProgram.lean",
  "research/moment-close-v1/SynergyMomentCHi.CompleteProgram/RECEIPT.json", 3),
 ("research/moment-hi-program-v1/lean/SynergyMomentCHi/ReadConsumer.lean",
  "research/moment-read-close-v1/SynergyMomentCHi.ReadConsumer/RECEIPT.json", 6),
 ("research/moment-hi-program-v1/lean/SynergyMomentCHi/ObservedOutput.lean",
  "research/moment-final-program-v1/SynergyMomentCHi.ObservedOutput/RECEIPT.json", 3),
 ("research/moment-hi-program-v1/lean/SynergyMomentCHi/FinalProgram.lean",
  "research/moment-final-program-v1/SynergyMomentCHi.FinalProgram/RECEIPT.json", 2),
 ("research/moment-program-v1/lean/SynergyMomentMath/PNT300.lean",
  "research/moment-pnt300-closed-v2/RECEIPT.json", 5)]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    records = []
    identities = set()
    for source_name, receipt_name, count in CASES:
        source, receipt = ROOT/source_name, ROOT/receipt_name
        result = json.loads(receipt.read_text())
        need(result["status"] == "PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES"
             and result["exit_code"] == 0 and result["source_unchanged"], "accepted build")
        need(sha(source) == result["source_sha256"], "exact source identity")
        outputs = [result["command"][i+1] for i, token in enumerate(result["command"][:-1])
                   if token == "-o" and result["command"][i+1].endswith(".olean")]
        need(len(outputs) == 1, "one exact Lean object output, excluding time -o")
        object_path = Path(outputs[0])
        need(sha(object_path) == result["object_sha256"], "compiled object identity")
        need(len(result["roots"]) == count and set(result["audits"]) == set(result["roots"]),
             "selected audited population")
        need(all(set(axioms) <= {"propext", "Classical.choice", "Quot.sound"}
                 for axioms in result["audits"].values()), "no native or admitted axioms")
        for root in result["roots"]:
            identity = (source_name, root)
            need(identity not in identities, "duplicate written-source identity")
            identities.add(identity)
        records.append(dict(source=source_name, source_sha256=sha(source),
                            receipt=receipt_name, receipt_sha256=sha(receipt),
                            object_sha256=sha(object_path), roots=result["roots"]))
    need(len(identities) == 22 and len(records) == 6, "frozen bounded population")
    review = dict(
        status="PASS_BOUNDED_ROOT_MOMENT_CONSUMER_READ_THROUGH_AND_ACCEPTED_BYTE_ASSOCIATION",
        selected_source_consumer_modules=5, selected_source_consumer_roots=17,
        selected_mathematical_support_modules=1, selected_mathematical_support_roots=5,
        scope_creator="Root reviewer; this is a bounded final-consumer review, not the owner's full source-claim census.",
        inclusion="The five concrete new moment row/main/read/observation/final-consumer modules plus PNT300.",
        exclusion="Upstream generic semantics, all 768 numerical blocks, every external analytic source, original Scoped Winner whole-program closure, and core graph registration are not independently re-audited here.",
        source_read_chain=[
          "AllRows derives actual high words from proved old point executions and instantiates all source budget guards and output effects.",
          "CompleteProgram proves global initialization, all 768 rows, both footer words, successful-model flush, return and both scope pops.",
          "ReadConsumer identifies the actual modeled C total heap read with independently proved interval sums, then derives BOTH M0 and M1 caps.",
          "ObservedOutput constants are checked against computed final totals and their exact bytes; the constants are not new mathematical premises.",
          "FinalProgram passes both read-derived caps into the actual ANT consumers; source executions are not unused added conjuncts.",
          "PNT300 proves conditional pi/psi coefficient 8848544/1000000000 at exp300 with the same14 analytic assertions."],
        qualifications=[
          "Physical read means a read in the formally defined C execution heap model; no OS-pipe parser or measured hardware-memory trace is claimed.",
          "The final theorem explicitly selects a successful-stdio policy. Native source/build/linker/CRT/output association is established in separate receipts.",
          "Clang unsigned _BitInt(512) is the modeled arithmetic. Boost is used only by untrusted proposal/regeneration tools.",
          "No general V1-to-V2 whole-program bisimulation is claimed; new high-only source is proved and fixed native output byte equivalence is separately measured.",
          "This new bound is conditional on unchanged14 analytic inputs, including finite RH and QRH; no unconditional or best-known claim.",
          "The uniform exp300 ray improves the old exp300 coefficient; the new future family is worse than old contraction at L330 and400.",
          "Matching pure-kernel N+ can prove the same coefficient. Numerical improvement is not exclusive to source-first PV.",
          "The original39-comparator8192/16384 Scoped Winner full source-program migration remains incomplete."],
        fresh_Lean_recompilation=False, namespace_replay=False,
        all_external_sources_independently_audited=False,
        records=records, validator_sha256=sha(Path(__file__)))
    out=ROOT/"research/analytic"/("ROOT_MOMENT_CONSUMER_REVIEW_V1"+"_O"*sys.flags.optimize+".json")
    need(not out.exists(), "fresh review receipt required")
    out.write_text(json.dumps(review,indent=2)+"\n")
    print(json.dumps(dict(status=review["status"], modules=6, roots=22, sha256=sha(out))))


if __name__ == "__main__":
    main()
