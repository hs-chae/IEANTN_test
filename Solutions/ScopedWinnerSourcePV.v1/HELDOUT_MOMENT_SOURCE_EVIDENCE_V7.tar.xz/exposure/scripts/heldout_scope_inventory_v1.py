"""Freeze per-case written declaration identities before mathematical review."""
from pathlib import Path
import argparse,csv,hashlib,json,re,os
R=Path(__file__).resolve().parents[2];D=R/'exposure';B=D/'heldout-verification-input-v1';V=D/'heldout-independent-v1/namespace/data/verification'
def need(x,m):
 if not x:raise ValueError(m)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();need(not a.out.exists(),'fresh inventory')
 case=next(x for x in json.loads((B/'CASES.json').read_text())['cases']if x['case']==a.case);rows=[];files=[];private_pending=[]
 for source in case['source_modules']:
  p=B/source['path'];text=p.read_text();need(hashlib.sha256(p.read_bytes()).hexdigest()==source['sha256'],'source unchanged');ilean=V/a.case/'logs'/(source['module']+'.ilean');byline={}
  if ilean.is_file():
   for n,pos in json.loads(ilean.read_text()).get('decls',{}).items():byline.setdefault(pos[4]+1,[]).append(n)
  stack=[];namespace=[];count=0
  for line_no,line in enumerate(text.splitlines(),1):
   s=line.strip()
   m=re.match(r'namespace\s+([A-Za-z0-9_.]+)',s)
   if m:stack.append(('namespace',list(namespace)));namespace+=m[1].split('.');continue
   if re.match(r'(?:noncomputable\s+)?section(?:\s|$)',s):stack.append(('section',list(namespace)));continue
   if re.match(r'end(?:\s|$)',s):
    if stack:_,namespace=stack.pop()
    continue
   m=re.match(r'(?P<mods>(?:(?:noncomputable|private|protected|unsafe|partial)\s+)*)(?P<kind>theorem|lemma|def|abbrev|axiom|constant|structure|class|inductive|opaque|instance)\s+(?P<name>[^\s(:{=]+)',s)
   if not m:continue
   name=m['name'];qualified='.'.join(namespace+[name]);compiled=byline.get(line_no,[]);matched=[n for n in compiled if n==qualified or n.endswith('.'+qualified)or n.endswith('.'+name)]
   if len(matched)==1:qualified=matched[0]
   elif'private'in m['mods'].split():private_pending.append(dict(file=source['path'],line=line_no,written_name=qualified))
   rows.append(dict(file=str(Path('exposure/heldout-study-v1/cases')/a.case/'submission'/p.name),decl_line=line_no,lean_name=qualified,kind=m['kind'],source_sha256=source['sha256'],compiler_name_resolved=bool(len(matched)==1),source_module=source['module']));count+=1
  files.append(dict(path=source['path'],source_sha256=source['sha256'],written_declarations=count))
 need(len({(r['file'],r['decl_line'],r['lean_name'])for r in rows})==len(rows),'unique written identities');a.out.parent.mkdir(parents=True,exist_ok=True)
 with a.out.open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=['file','decl_line','lean_name','kind','source_sha256','compiler_name_resolved','source_module']);w.writeheader();w.writerows(rows)
 a.out.with_suffix('.json').write_text(json.dumps(dict(status='WRITTEN_IDENTITY_SCOPE_FROZEN_BEFORE_CONTRACT_REVIEW',case=a.case,files=files,rows=len(rows),private_compiler_names_pending=private_pending,scope='All supplied candidate Lean files in this case, including copied original definition stubs and private helpers. Generated auxiliaries are separately covered by complete compiler-census/axiom closures; no mathematical success asserted.'),indent=2)+'\n');print(a.case,len(rows),'private pending',len(private_pending))
if __name__=='__main__':main()
