"""Immutable source/evidence checkpoint ZIP; no private controller/session context."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];OUT=R/'research/analytic'
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 archive=OUT/'HELDOUT_TWO_ANT_SOURCE_EVIDENCE_V5.zip';manifest=OUT/'HELDOUT_TWO_ANT_SOURCE_EVIDENCE_V5_FILES.json';need(not archive.exists()and not manifest.exists(),'fresh immutable bundle');files=set()
 def addtree(rel,exclude=()):
  b=R/rel
  for p in b.rglob('*'):
   if p.is_file()and not p.is_symlink()and'__pycache__'not in p.parts and p.suffix not in{'.pyc','.olean','.o','.so','.a'}and not any(x in p.parts for x in exclude)and p.name not in{'HELDOUT_AND_TWO_ANT_CONSUMERS_REPORT_V1.html','HELDOUT_AND_TWO_ANT_CONSUMERS_REPORT_V2.html','HELDOUT_AND_TWO_ANT_CONSUMERS_REPORT_V3.html','HELDOUT_AND_TWO_ANT_CONSUMERS_REPORT_V4.html'}:files.add(p)
 for root in['research/source-poststudy-ant-capsule-v3','research/pure-poststudy-fullfresh-capsule-v1','research/pure-poststudy-fullfresh-capsule-v2','research/pure-poststudy-fullfresh-capsule-v3','exposure/heldout-verification-input-v1','exposure/heldout-packets-v1']:addtree(root)
 for root in['exposure/heldout-audit-v1','exposure/heldout-controls-v1','exposure/heldout-summary-controls-v1','exposure/heldout-reproduction-cli-controls-v1','research/analytic/source-poststudy-review-controls-v3/actual-controls-v2','research/analytic/pure489-v3-controls-v1/actual']:addtree(root,exclude=('report-browser-v1','report-browser-v2','report-browser-v3','report-browser-v4'))
 # Add immutable public original submissions, without events, account/controller configs or private context.
 for d in (R/'exposure/heldout-study-v1/cases').iterdir():
  if(d/'submission').is_dir():addtree(str((d/'submission').relative_to(R)))
 addtree('exposure/heldout-independent-v1/namespace/data/verification',exclude=('objects',))
 addtree('research/pure-poststudy-resume489-run-v2',exclude=('objects',))
 addtree('research/pure-poststudy-fullfresh489-run-v1',exclude=('objects',))
 for rel in['HELDOUT_CHECKPOINT_README.md','network/IEANTN/Vocabulary/ErrorTerms.lean','exposure/design/HELDOUT_LOCK_V1.json','exposure/design/HELDOUT_PACKET_AUDIT_V1.json','exposure/heldout-study-v1/STUDY_SEALED.json','exposure/heldout-study-v1/PREFLIGHT_RECEIPT.json','exposure/heldout-study-v1/CONTEXT_FIXTURE_RECEIPT.json','exposure/heldout-independent-v1/namespace/RECEIPT.json','exposure/heldout-independent-v1/resources/scope.json','exposure/heldout-independent-v1/LSP_FALLBACK.json','resources/poststudy-ant-consumers-v1/scope.json','research/poststudy-ant-v1/COMPLETION_INDEX_V1.json','research/poststudy-ant-v1/README.md','research/source-poststudy-ant-regeneration-recheck-v2.json','research/analytic/SOURCE_POSTSTUDY_CONTINUATION_REVIEW_CONTROLS_V3.json','research/pure-poststudy-fullfresh-launch-v1/PLAN.json','resources/pure-poststudy-fullfresh489-v1/scope.json','resources/pure-poststudy-resume489-v2/scope.json','research/analytic/PURE489_RESUMED_ACCEPTANCE_V2.json','research/analytic/summarize_resumed_nplus_v2.py','research/analytic/PURE489_RESUMED_REVIEW_CONTROLS_V2.json','research/analytic/PURE489_RESUMED_REVIEW_CONTROLS_V3.json','research/pure-poststudy-resume489-launch-v2/PLAN.json','research/pure-poststudy-parent482-association-v2.json']:
  p=R/rel;need(p.is_file(),'essential evidence '+rel);files.add(p)
 for name in['finalize_heldout_results_v1.py','render_heldout_report_v5.py','check_heldout_report_v5.py','reproduce_heldout_proofs_v1.py','heldout_verify_inner_v1.py','prepare_heldout_verification_v1.py','heldout_scope_inventory_v1.py','build_heldout_audit_ledger_v1.py','package_heldout_checkpoint_v5.py']:files.add(R/'exposure/scripts'/name)
 for rel in['lean','build-v1']:
  addtree('research/poststudy-ant-v1/'+rel)
 for name in['seed_banks.py','build_consumers.py','prepare_source_capsule_v1.py','prepare_pure_fullfresh_v1.py','BUILD_PLAN_V1.json']:files.add(R/'research/poststudy-ant-v1'/name)
 # Check every current-report evidence link against actual packaged members.
 from html.parser import HTMLParser
 class Links(HTMLParser):
  def handle_starttag(self,tag,attributes):
   if tag=='a':
    href=dict(attributes).get('href');target=(R/'exposure/heldout-audit-v1'/href).resolve();need(target in files,'report link absent from archive '+href)
 need(R/'exposure/heldout-audit-v1/HELDOUT_AND_TWO_ANT_CONSUMERS_REPORT_V5.html'in files,'current report itself is packaged')
 parser=Links();parser.feed((R/'exposure/heldout-audit-v1/HELDOUT_AND_TWO_ANT_CONSUMERS_REPORT_V5.html').read_text())
 rows=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)];need(len({r['path']for r in rows})==len(rows),'unique paths');metadata=dict(status='FROZEN_COMPLETED_STUDY_AND_WARM_TWO_CONSUMERS_WITH_PENDING_COLD_RECIPES',files=rows,source_first_warm_consumers=2,completed_original_formal_targets=5,original_formal_partial=1,source4076_cold_replay_completed=False,pure489_uninterrupted_fresh_replay_completed=False,pure489_validated482_plus7_resumed_chain_completed=True,private_controller_context_included=False,accepted_proof_objects_deleted=False,qualification='All original six outcomes preserved. Public source/proof logs/receipts and clean reproduction included; accepted objects retained locally and reproducible rather than duplicated. Source4076cold replay remains pending; full489V1failedafter482passed andV2validatedseven-sourcechainpassed. No uninterrupted489success is inferred. This is a bounded completed-checkpoint bundle, not entire Scoped Winner migration completion.')
 manifest.write_text(json.dumps(metadata,indent=2)+'\n')
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(files):
   info=zipfile.ZipInfo(str(p.relative_to(R)),date_time=(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
  info=zipfile.ZipInfo(str(manifest.relative_to(R)),date_time=(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,manifest.read_bytes())
 with zipfile.ZipFile(archive)as z:
  need(len(z.namelist())==len(rows)+1 and len(set(z.namelist()))==len(rows)+1,'exact archive population')
  for row in rows:
   b=z.read(row['path']);need(len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256'],'archive readback '+row['path'])
  need(z.read(str(manifest.relative_to(R)))==manifest.read_bytes(),'archive manifest bytes')
 result=dict(status='PASS_ALL_ARCHIVE_MEMBERS_READ_BACK_AND_HASHED',archive=str(archive.relative_to(R)),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,manifest_sha256=sha(manifest),members=len(rows)+1,qualification=metadata['qualification']);(OUT/'HELDOUT_TWO_ANT_SOURCE_EVIDENCE_V5.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
