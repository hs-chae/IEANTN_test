"""Portable host replay of the exact sealed six-case independent proof census.

It adapts only three fixed path bindings and the host/isolation qualification in the
preserved namespace verifier. It never edits candidate Lean source or changes outcomes.
The already completed original namespace receipt is separate evidence.
"""
from pathlib import Path
import argparse,hashlib,json,os,sys,types,subprocess
R=Path(__file__).resolve().parents[2]
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(p):
 def pairs(xs):
  d={}
  for k,v in xs:need(k not in d,'duplicate JSON key '+k);d[k]=v
  return d
 def bad(s):raise ValueError('nonfinite JSON '+s)
 return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=bad)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input',type=Path,required=True);ap.add_argument('--environment',type=Path);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--check-inputs-only',action='store_true');a=ap.parse_args();source=a.input.resolve();out=a.out.resolve();need(not out.exists()and source not in out.parents,'fresh external output');pins=strict(source/'INPUTS.json')
 for row in pins['files']:
  p=source/row['path'];need(p.is_file()and not p.is_symlink()and sha(p)==row['sha256']and p.stat().st_size==row['bytes'],'exact sealed source/validator input '+row['path'])
 meta=strict(source/'CASES.json');need(len(meta['cases'])==6 and not list(source.rglob('*.olean')),'six exact source-only cases');out.mkdir(parents=True)
 if a.check_inputs_only:
  pending=out/'RECEIPT.pending';pending.write_text(json.dumps(dict(status='PASS_SEALED_SIX_CASE_INPUTS_ONLY_NOT_PROOF_REPLAY',proof_replay=False,input_manifest_sha256=sha(source/'INPUTS.json')),indent=2)+'\n');os.replace(pending,out/'RECEIPT.json');return
 need(a.environment is not None and a.environment.is_file(),'pinned public generic environment');environment=strict(a.environment);lock=strict(R/'research/source-poststudy-ant-capsule-v3/base/SOURCE_LOCK.json');compiler=Path(environment['compiler']);need(sha(compiler)==lock['compiler_sha256'],'pinned compiler')
 need([{k:x[k]for k in['name','commit','url']}for x in environment['generic_dependencies']]==lock['generic_dependencies'],'pinned public library commits')
 for dep in environment['generic_dependencies']:
  p=subprocess.run(['git','-C',dep['source'],'rev-parse','HEAD'],capture_output=True,text=True);need(p.returncode==0 and p.stdout.strip()==dep['commit']and Path(dep['objects']).is_dir(),'public generic library '+dep['name'])
 environment['project_objects_reused']=False;ep=out/'environment.json';ep.write_text(json.dumps(environment,indent=2)+'\n');text=(source/'verify.py').read_text();original_hash=sha(source/'verify.py')
 changes=[("B=Path('/task');OUT=Path('/out/verification')",'B=Path('+repr(str(source))+');OUT=Path('+repr(str(out/'verification'))+')'),("strict(Path('/environment.json'))",'strict(Path('+repr(str(ep))+'))'),("namespace='outer existing launcher attestation'","namespace='NONE_PORTABLE_HOST_REPLAY'"),("Fresh generic-only namespace compile/type/axiom census","Fresh generic-only portable-host compile/type/axiom census")]
 for old,new in changes:need(text.count(old)==1,'exact portable-only binding '+old);text=text.replace(old,new)
 adapted=out/'portable-verifier.py';adapted.write_text(text);module=types.ModuleType('exact_candidate_portable_path_adapter');module.__file__=str(adapted);exec(compile(text,str(adapted),'exec'),module.__dict__);module.main()
 proof=out/'verification/RECEIPT.json';result=strict(proof);need(len(result['cases'])==6 and all(not x['nonstandard_axiom_roots']for x in result['cases']),'all six complete actual compiled theorem closures standard')
 need([x['case']for x in result['cases']]==[x['case']for x in meta['cases']],'exact original cases');receipt=dict(status='PASS_PORTABLE_HOST_SIX_ORIGINAL_CASE_COMPILATION_AND_CENSUS',namespace_isolated=False,source_first_PV=False,original_verifier_sha256=original_hash,portable_verifier_sha256=sha(adapted),input_manifest_sha256=sha(source/'INPUTS.json'),proof_receipt_sha256=sha(proof),original_outcomes_unchanged=True,qualification='Only paths and host/isolation labels adapted. Candidate mathematical sources unchanged. Original diagnostic failures remain visible; task/contract acceptance requires separate preserved source audit. No fresh model call or source-first PV claim.')
 tmp=out/'RECEIPT.pending';tmp.write_text(json.dumps(receipt,indent=2)+'\n');os.replace(tmp,out/'RECEIPT.json');print(receipt['status'])
if __name__=='__main__':main()
