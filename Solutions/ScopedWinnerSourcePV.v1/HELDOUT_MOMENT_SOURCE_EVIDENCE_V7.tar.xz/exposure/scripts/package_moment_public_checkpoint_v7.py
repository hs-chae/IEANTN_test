"""Deterministic source/evidence bundle after both new isolated replays accept."""
from pathlib import Path
from html.parser import HTMLParser
import argparse,hashlib,json,math,zipfile
R=Path(__file__).resolve().parents[2];D=R/'research/analytic'
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(text):
 def pairs(xs):
  d={}
  for k,v in xs:need(k not in d,'duplicateJSON');d[k]=v
  return d
 def bad(s):raise ValueError('nonfiniteJSON')
 def floating(s):
  v=float(s);need(math.isfinite(v),'overflowJSON');return v
 return json.loads(text,object_pairs_hook=pairs,parse_float=floating,parse_constant=bad)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--version',default='V7');ap.add_argument('--report-version',default='V6');a=ap.parse_args();archive=D/('HELDOUT_MOMENT_SOURCE_EVIDENCE_'+a.version+'.zip');manifest=archive.with_name(archive.stem+'_FILES.json');receipt=archive.with_suffix('.json');need(not any(p.exists()for p in[archive,manifest,receipt]),'fresh artifacts');report=R/'exposure/heldout-audit-v1'/('HELDOUT_AND_MOMENT_ANT_REPORT_'+a.report_version+'.html');need(report.is_file(),'final current report required')
 pure=R/'research/isolated-moment-nplus565-v1/namespace/data/run';source=R/'research/isolated-moment-source4486-v1/namespace/data/run'
 need(parse((pure/'RECEIPT.json').read_text())['status']=='PASS565_FRESH_PURE_MOMENT_NUMERICS_AND_FULL_ANT_SOURCE_GRAPH','actual565 acceptance required')
 need(parse((source/'RECEIPT.json').read_text())['status']=='PASS4486_CHAINED_SOURCE_FIRST_MOMENT_PROGRAMS_TO_STRONGER_PNT','actual4486 acceptance required')
 vector=R/'research/isolated-direct-vector568-v2/namespace/data/run';need(parse((vector/'RECEIPT.json').read_text())['status']=='PASS568_CHAINED565_PLUS3_KERNEL_VECTOR_STRONGER_PNT','actual corrected568 acceptance required');need((D/'ROOT_SOURCE4486_VECTOR568_INDEPENDENT_REVIEW_V1.json').is_file(),'independent final readbacks required')
 files=set();old=parse((D/'HELDOUT_TWO_ANT_SOURCE_EVIDENCE_V5_FILES.json').read_text())
 for row in old['files']:
  path=row['path']
  if path=='HELDOUT_CHECKPOINT_README.md' or any(n in path for n in['pure-poststudy-fullfresh-capsule-v1/','pure-poststudy-fullfresh-capsule-v2/','pure-poststudy-fullfresh-capsule-v3/','source-poststudy-ant-capsule-v3/','report-browser-']):continue
  p=R/path;need(p.is_file()and sha(p)==row['sha256'],'unchanged previous evidence '+path);files.add(p)
 def tree(rel,exclude=()):
  b=R/rel;need(b.is_dir(),'required source/evidence tree '+rel)
  for p in b.rglob('*'):
   if not p.is_file():continue
   need(not p.is_symlink(),'no symbolic source/evidence '+str(p))
   if'__pycache__'in p.parts or p.suffix in{'.pyc','.olean','.o','.so','.a'}or any(x in p.relative_to(b).parts for x in exclude):continue
   need(p.stat().st_size<150*1024**2,'unexpected huge evidence payload '+str(p));files.add(p)
 for rel in['research/moment-source-capsule-v3','research/moment-source-capsule-v4','research/moment-pure-source-capsule-v3','research/direct-vector-source-capsule-v2','research/direct-vector-source-capsule-v3','research/direct-vector300-v1','research/source-poststudy-ant-capsule-v4','research/pure-poststudy-fullfresh-capsule-v4','research/moment-program-v1/lean','research/moment-program-v1/word-source','research/moment-program-v1/numeric-source','research/moment-program-v1/source','research/moment-hi-program-v1/lean','research/moment-hi-program-v1/budget-source','research/moment-hi-program-v1/family-source','research/moment-hi-program-v1/source']:tree(rel)
 for rel in['research/isolated-moment-nplus565-v1','research/isolated-moment-source4486-v1','research/isolated-moment-native-preflight-v1','research/isolated-moment-native-preflight-v2','research/isolated-direct-vector568-v1','research/isolated-direct-vector568-v2']:tree(rel,exclude=('root','objects'))
 for rel in['resources/isolated-moment-nplus565-v1','resources/isolated-moment-source4486-v1','resources/isolated-moment-native-preflight-v1','resources/isolated-moment-native-preflight-v2','resources/moment-full-family-v1','resources/moment-adapters-v1','resources/isolated-direct-vector568-v1','resources/isolated-direct-vector568-v2','resources/direct-vector300-model-v1','resources/direct-vector300-model-v2','resources/direct-vector300-data-v1','resources/direct-vector300-real-v1']:tree(rel)
 for rel in['research/analytic/moment-pure-v3-controls-v1/actual','research/analytic/moment-source-v3-controls-v1/actual']:tree(rel,exclude=('objects',))
 for pattern in['MOMENT_*REVIEW_CONTROLS*.json','MOMENT_PURE_COLLECTOR_REVIEW_CONTROLS_V1.json','ROOT568*CONTROLS*.json','ROOT_MOMENT*REVIEW*.json','ROOT_PURE565*.json','ROOT_SOURCE4486_VECTOR568*.json','ROOT_*READBACK*.json','MOMENT_SOURCE4486_READBACK_V1.json','DIRECT_VECTOR568_READBACK_V1.json']:
  files.update(D.glob(pattern))
 for rel in['research/moment-final-program-v1/RECEIPT.json','research/moment-full-family-v1/RECEIPT.json','research/moment-adapters-v1/RECEIPT.json','research/moment-hi-program-v1/WORLD_SOURCE_COMPONENTS_V2.json','research/moment-hi-program-v1/SOURCE_PLAN_V1.json','research/moment-program-v1/SOURCE_PLAN_V2.json','research/moment-program-v1/HANDOFF_ACTIVE_MOMENT_V3.md','research/namespace-replay-v1/ROOT_SOURCE4057_READBACK_V1.json','research/analytic/source4076-independent-readback-v1/RECEIPT.json','scripts/resource_scope_v2.py','scripts/record_command_peak_v1.py','evidence/RESOURCE_POLICY.json']:
  p=R/rel
  if p.is_file():files.add(p)
 for name in['launch_v2.py','entry_v2.py','launch_chained4486_v1.py','entry_chained4486_v1.py','launch_chained568_v1.py','entry_chained568_v1.py','launch_chained4076_v1.py','entry_chained4076_v1.py','launch_moment_v1.py','sandbox.py','GENERIC_INPUT_LOCK.json']:files.add(R/'research/namespace-replay-v1'/name)
 for name in['render_moment_report_v6.py','check_moment_report_v6.py','package_moment_checkpoint_v6.py']:files.add(R/'exposure/scripts'/name)
 for rel in['research/direct-vector300-model-v2','research/direct-vector300-data-v1','research/direct-vector300-real-v1','research/direct-vector300-model-v1']:tree(rel,exclude=('objects',))
 for name in['check_fresh565_v1.py','check_final_replays_v1.py','HANDOFF_ACTIVE_MOMENT_V4.md']:
  files.add(R/'research/moment-program-v1'/name)
 for name in['check_root_moment_consumer_review_v1.py','review568_bounded_controls_v1.py','review568_bounded_controls_v2.py','review568_actual_json_cli_v1.py','review568_actual_json_cli_v2.py']:
  files.add(D/name)
 browser=R/'exposure/heldout-audit-v1'/('report-browser-moment-'+a.report_version.lower());need((browser/'RECEIPT.json').is_file(),'actual final browsercheck');files.add(browser/'RECEIPT.json')
 for p in browser.glob('top-*.png'):files.add(p)
 files.add(R/'README.md')
 files.add(R/'exposure/scripts/package_moment_public_checkpoint_v7.py')
 files={p for p in files if 'HANDOFF'not in p.name.upper()and p.name!='HOST_CANARY'and 'transcript'not in p.name.lower()}
 files.add(report)
 class Links(HTMLParser):
  def handle_starttag(self,tag,attrs):
   if tag!='a':return
   href=dict(attrs).get('href');need(href is not None and not href.startswith(('http:','https:')),'offline local evidence links');p=(report.parent/href).resolve();need(p.is_file()and p.is_relative_to(R),'actual evidence target '+href);files.add(p)
 parser=Links();parser.feed(report.read_text());need(report in files,'current report itself packaged')
 rows=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)];need(len(rows)==len({r['path']for r in rows}),'unique paths')
 metadata=dict(publication_private_handoffs_transcripts_canary_files_excluded=True,report_version=a.report_version,bundle_version=a.version,status='FROZEN_ORIGINAL_SIX_STUDY_PLUS_COMPLETED_SOURCE_FIRST_MOMENT_ANT',files=rows,completed_original_formal_targets=5,original_formal_partial=1,source4057_empty_bank_completed=True,source4076_chained4057_plus19_completed=True,moment565_empty_bank_completed=True,moment4486_chained4057_plus429_completed=True,coefficient='0.008848544',onset='exp(300)',analytic_inputs=14,source_first_PV=True,matching_kernel_only_same_math=True,stronger_fixed_vector_kernel_coefficient='0.008732871',stronger_checker568_chained565_plus3_completed=True,initial_checker568_audit_inventory_failure_preserved=True,exclusive_coefficient_advantage=False,core_graph_registration_complete=False,private_controller_context_included=False,accepted_proof_objects_deleted=False,qualification='Current source-first moment result plus fresh matching N+, explicitly chained source replay, and independently verified stronger fixed-vector kernel checker. Accepted4486 usedV3+extra actual2835nonempty-type readback; supplied portableV4 is not a retroactive kernel replay. Initial568 audit-inventory failure remainsfailed; corrected same-source3-module retry passes. Original scores unchanged. Full source/commands/receipts/audits and clean regeneration included; accepted proof objects retained locally/reproducible, not redundantly distributed. Separate68-body migration remains incomplete; no whole-project/optimality/global-strongest claim.')
 manifest.write_text(json.dumps(metadata,indent=2,allow_nan=False)+'\n')
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(files|{manifest}):
   info=zipfile.ZipInfo(str(p.relative_to(R)),date_time=(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
 with zipfile.ZipFile(archive)as z:
  need(len(z.namelist())==len(rows)+1==len(set(z.namelist())),'exact archive population')
  for row in rows:
   data=z.read(row['path']);need(len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256'],'archive readback '+row['path'])
  need(z.read(str(manifest.relative_to(R)))==manifest.read_bytes(),'manifest readback')
 result=dict(status='PASS_ALL_ARCHIVE_MEMBERS_READ_BACK_AND_HASHED',archive=str(archive.relative_to(R)),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,manifest_sha256=sha(manifest),members=len(rows)+1,current_report_sha256=sha(report),qualification=metadata['qualification']);receipt.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
