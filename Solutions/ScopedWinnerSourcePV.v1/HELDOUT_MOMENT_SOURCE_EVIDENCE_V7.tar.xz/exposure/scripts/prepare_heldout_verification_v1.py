"""Prepare exact candidate-only verification inputs only after all six sessions seal."""
from pathlib import Path
import argparse,json,hashlib,re,shutil,os
R=Path(__file__).resolve().parents[2];D=R/'exposure'
def need(x,m):
 if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):
 def unique(rows):
  d={}
  for k,v in rows:need(k not in d,'duplicate JSON key');d[k]=v
  return d
 return json.loads(p.read_text(),object_pairs_hook=unique)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();out=a.out.resolve();need(out.is_relative_to(D)and not out.exists(),'fresh owned input capsule')
 study=D/'heldout-study-v1';sealed=load(study/'STUDY_SEALED.json');need(sealed['completed']==6 and sealed['status']=='ALL_SIX_NEW_SESSIONS_SEALED_PENDING_INDEPENDENT_MATH_AND_LEAN_REVIEW','all six sealed before any candidate inspection')
 lock=load(D/'design/HELDOUT_LOCK_V1.json');need(sha(D/'design/HELDOUT_LOCK_V1.json')==sealed['lock_sha256'],'exact before-outcome design')
 rows=[];out.mkdir(parents=True)
 interfaces=out/'provided-interfaces';interfaces.mkdir()
 for task in ['H01','H02','H03']:
  packet=R/next(x['path']for x in lock['packets']if x['task']==task and x['arm']=='STRUCTURED')
  directory=interfaces/task;directory.mkdir();shutil.copy2(packet/'TaskDefinitions.lean',directory/'TaskDefinitions.lean')
 for row in sealed['rows']:
  name=row['case'];case=study/'cases'/name;result=load(case/'result.json');need(sha(case/'result.json')==row['result_sha256'],'sealed metadata identity')
  target=out/name;target.mkdir();source=target/'source';source.mkdir();files=[];admitted=bool(result.get('discovery_admissible_for_evaluation'));export=result.get('artifact_export',{})
  if export.get('consistent'):
   submission=case/'submission';manifest=load(submission/'LOCK.json');expected=export['files'];need(sha(submission/'LOCK.json')==export['lock_sha256'],'sealed lock')
   need([dict(path=x['path'],sha256=x['sha256'])for x in expected]==manifest['files'],'exact exported population')
   for item in expected:
    f=submission/item['path'];need(f.is_file()and not f.is_symlink()and sha(f)==item['sha256']and f.stat().st_size==item['bytes'],'sealed candidate bytes')
    
    compiled=f.suffix in {'.olean','.o','.so','.a','.ilean'} or '.olean.' in f.name
    if not compiled:shutil.copy2(f,target/f.name)
    files.append(dict(path=f.name,sha256=sha(f),bytes=f.stat().st_size,verification_input=not compiled))
  else:
   # Preserve rejected/deadline candidates as diagnostic only; do not silently rescore them.
   snapshot=result.get('deadline_snapshot',{});snap=case/'deadline-sealed'
   if(snap/'SNAPSHOT.json').is_file():
    metadata=load(snap/'SNAPSHOT.json')
    for item in metadata.get('files',[]):
     f=snap/item['stored_path'];need(sha(f)==item['sha256'],'deadline draft identity')
     compiled=f.suffix in {'.olean','.o','.so','.a','.ilean'} or '.olean.' in f.name
     if not compiled:shutil.copy2(f,target/f.name)
     files.append(dict(path=f.name,sha256=sha(f),bytes=f.stat().st_size,verification_input=not compiled))
  packet=R/next(x['path']for x in lock['packets']if x['task']==row['task']and x['arm']==row['arm']);definitions=packet/'TaskDefinitions.lean';issues=[];vocabulary_warning=[]
  for f in sorted(target.glob('*.lean')):
   if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*\.lean',f.name):issues.append('Unsupported flat Lean module filename '+f.name);continue
   shutil.copy2(f,source/f.name)
  if(source/'TaskDefinitions.lean').exists():
   if sha(source/'TaskDefinitions.lean')!=sha(definitions):vocabulary_warning.append('Submitted TaskDefinitions differs from supplied source; mathematical object/constant equivalence requires manual audit, even if kernel compilation passes.')
  elif any(re.search(r'^\s*(?:public\s+)?import\s+(?:all\s+)?[^\n]*\bTaskDefinitions\b',f.read_text(),re.M) for f in source.glob('*.lean')):
   shutil.copy2(definitions,source/'TaskDefinitions.lean')
  modules={f.stem:f for f in source.glob('*.lean')};imports={}
  for module,p in modules.items():
   lines=p.read_text().splitlines();needed=[]
   for line in lines:
    m=re.match(r'\s*(?:public\s+)?import\s+(?:all\s+)?(.+)',line)
    if m:
     for imp in m[1].split('--',1)[0].split():
      if imp in modules:needed.append(imp)
      elif not imp.startswith(('Mathlib','Lean','Std','Batteries','Aesop','Qq','Plausible','ImportGraph','LeanSearchClient','ProofWidgets','Init')):issues.append('Unavailable non-generic import '+imp+' in '+p.name)
   imports[module]=set(needed)
  order=[];pending=dict(imports)
  while pending:
   ready=sorted(n for n,v in pending.items()if set(v)<=set(order))
   if not ready:issues.append('Own-module import cycle or unresolved order');break
   for n in ready:order.append(n);pending.pop(n)
  rows.append(dict(case=name,task=row['task'],arm=row['arm'],mechanically_admitted=admitted,known_target=row['task']=='H03',result_sha256=sha(case/'result.json'),locked_files=files,source_modules=[dict(module=n,path=str(modules[n].relative_to(out)),sha256=sha(modules[n]))for n in order],preparation_issues=issues,vocabulary_warnings=vocabulary_warning,mathematical_scope_accepted=False))
 shutil.copy2(D/'scripts/heldout_verify_inner_v1.py',out/'verify.py');(out/'CASES.json').write_text(json.dumps(dict(status='EXACT_SEALED_CANDIDATES_FOR_INDEPENDENT_VERIFICATION_NOT_RESULT_ACCEPTANCE',source_study_seal_sha256=sha(study/'STUDY_SEALED.json'),cases=rows),indent=2)+'\n')
 inputs=[dict(path=str(p.relative_to(out)),sha256=sha(p),bytes=p.stat().st_size)for p in sorted(out.rglob('*'))if p.is_file()];(out/'INPUTS.json').write_text(json.dumps(dict(files=inputs),indent=2)+'\n');print('prepared all6 original sealed candidates, no proof modifications')
if __name__=='__main__':main()
