"""Record the completed file-scope source/contract review; no experimental rescore."""
from pathlib import Path
import csv,json,re,hashlib
R=Path(__file__).resolve().parents[2];B=R/'exposure/heldout-audit-v1'
FIELDS=['file','decl_line','lean_name','kind','proposed_verification_status','actual_lean_declaration','actual_primary_source_statement_or_explicit_absence','original_locator','domain_and_hypotheses','lean_source_comparison','mathematical_check','full_scope_attribution_evidence','trust_boundary','notes']
def need(x,m):
 if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readcsv(p):
 with p.open()as f:return list(csv.DictReader(f))
def main():
 scope=readcsv(B/'ALL_WRITTEN_SCOPE.csv');need(len(scope)==172,'exact requested submitted-file population')
 env=json.loads((R.parent/'ieantn-exposure-maximal-20261109/evolution/work/environment-cold-v1/ENVIRONMENT.json').read_text());mathlib=Path(next(x['source']for x in env['generic_dependencies']if x['name']=='mathlib'));pin=next(x['commit']for x in env['generic_dependencies']if x['name']=='mathlib')
 sourcefiles={r['file']for r in scope};evidence={};rows=[]
 def primary(relative,name):
  key=(relative,name)
  if key not in evidence:
   p=mathlib/relative;lines=p.read_text().splitlines();found=None
   for i,l in enumerate(lines):
    if re.search(r'^(?:private\s+)?(?:theorem|lemma)\s+(?:_root_\.)?'+re.escape(name)+r'(?:\s|\{|\()',l):found=i;break
   need(found is not None,'exact primary formal source '+name);chunk=[]
   for l in lines[found:]:
    chunk.append(l)
    if ':='in l:break
   evidence[key]=dict(source=relative,commit=pin,line=found+1,name=name,statement='\n'.join(chunk).split(':=',1)[0].strip(),source_sha256=sha(p))
  d=evidence[key];return d['statement'],f"Mathlib@{pin}:{relative}:{d['line']} ({name})"
 for item in scope:
  p=R/item['file'];text=p.read_text();lines=text.splitlines();line=int(item['decl_line']);same=[int(x['decl_line'])for x in scope if x['file']==item['file']and int(x['decl_line'])>line];end=min(same)-1 if same else len(lines);chunk='\n'.join(lines[line-1:end]).strip();signature=chunk.split(':=',1)[0].strip()if item['kind']in['theorem','lemma']else chunk
  case=p.parts[-3];task=case.split('-')[0];short=item['lean_name'].split('.')[-1];source='';locator='';external=False
  taskpath=R/'exposure/heldout-packets-v1'/case/'task.md';packet=taskpath.read_text().split('\n\n',2)[-1]
  source='Internal mathematical derivation, not an external-paper formula. Locked task source: '+packet
  locator=str(taskpath.relative_to(R))+'; declaration/section/full-module/candidate.md source-claim boundary (no standalone Blueprint declaration).'
  if task=='H01':
   comparison='Actual pi is Nat.primeCounting of natural floor; H includes primes at x; offset Li2 starts at2. Positive-denominator normalization is used only t>=exp300. All compact identities use x>=2; no low-height PNT assumption is inferred.'
   if short in ['prime_partial_summation']:
    source,locator=primary('Mathlib/NumberTheory/AbelSummation.lean','sum_mul_eq_sub_integral_mul₁');external=True
    comparison+=' The general formal Abel statement is specialized with c=primeIndicator, c0=c1=0, f(t)=1/t and derivative -1/t²; finite counting identities yield the actual-prime formula, including p=2.'
   elif short=='pi_weight_integrable':
    source,locator=primary('Mathlib/NumberTheory/AbelSummation.lean','integrableOn_mul_sum_Icc');external=True
    comparison+=' Specialize the public integrability theorem with a=2,m=0,g=1/t², prove its continuity/integrability, and identify the finite prime indicator sum with actual pi.'
   elif short in ['sum_primeIndicator','count_indicator','weighted_sum_primeIndicator','reciprocal_indicator','primeIndicator']:
    comparison+=' Exact finite indicator sums are identified with primeCounting and H; p0/p1 have zero indicator, without a continuous proxy.'
   elif short in ['Li2_hasDerivAt','Li2_partial_summation','Li2_continuousOn','log_pos_on','invLog_continuousOn','log_integrand_continuous','Li2_weight_integrable']:
    comparison+=' log is positive on [2,x]; Li2(2)=0 and its actual derivative is1/log. The resulting main term is loglogx-loglog2, retaining the lower-endpoint constant.'
   elif short in ['residual_identity','reciprocal_error_identity','exact_tail_identity']:
    comparison+=' The exact residual is -loglog2+(pi-Li2)/x plus the finite error integral. Tail splitting uses proved actual-error integrability, not a new premise.'
   elif short in ['power_tail','log_tail_integrable','log_tail_bound','input_weight_bound','actual_error_integrable','actual_tail_bound','error_weight_integrable']:
    comparison+=' The exponent is -9/8<-1; for t>x>=exp300 the stated PNT input applies and logt>=logx>0. Domination proves actual-error integrability and the8*x^(-1/8)/logx tail bound.'
   elif short in ['whole_ray_error','sharper_whole_ray_error','prime_reciprocal_tendsto','final_consumer','unique_reciprocal_limit','reciprocalConstant']:
    comparison+=' B uses the exact finite integral below exp300 plus the absolutely convergent error tail above it. The1+8 allowance gives9C; the real-atTop limit and uniqueness follow. B is not numerically identified with a literature constant.'
   elif short in ['PrimeCountingInput','raw_error_of_input','boundary_error_on_ray','error_bound_at','endpoint_error_bound']:
    comparison+=' Only the explicit whole-ray normalized error is assumed. Clearing t/logt uses proved t>1, never the input at smaller arguments.'
  elif task=='H02':
   comparison='The actual Epsi/Etheta formulas are definitionally IEANTN Eψ/Eθ. The only analytic input is psiInput at the final x>=exp300. Smaller prime-power arguments use a proved global theta bound, not an out-of-range psi estimate.'
   mapping={"sum_PrimePow_eq_sum_sum'":"sum_PrimePow_eq_sum_sum'",'sum_PrimePow_eq_sum_sum':'sum_PrimePow_eq_sum_sum',"psi_eq_sum_theta'":"psi_eq_sum_theta'",'psi_eq_sum_theta':'psi_eq_sum_theta',"psi_eq_theta_add_sum_theta'":"psi_eq_theta_add_sum_theta'",'psi_eq_theta_add_sum_theta':'psi_eq_theta_add_sum_theta','theta_le_log4_mul_x':'theta_le_log4_mul_x','abs_remainder':'abs_psi_sub_theta_le_sqrt_mul_log','abs_psi_sub_theta_le_sqrt_mul_log':'abs_psi_sub_theta_le_sqrt_mul_log','exact_prime_powers':'psi_eq_theta_add_sum_theta','remainder_exact':'psi_eq_theta_add_sum_theta'}
   if short in mapping:
    source,locator=primary('Mathlib/NumberTheory/Chebyshev.lean',mapping[short]);external=True
    comparison+=' Header explicitly attributes these arithmetic portions to this pinned Mathlib file. Compare exact finite cutoff floor(logx/log2), prime/exponent indexing and real endpoints; subtraction-form corollaries rearrange the same equality.'
   elif short in ['preliminary','remainder_bound']:
    source,locator=primary('Mathlib/Analysis/SpecialFunctions/Pow/Real.lean','log_le_rpow_div');external=True
    comparison+=' Use the already proved arithmetic remainder<=2sqrtx*logx and the primary log bound at exponent1/8 to obtain16*x^(5/8), preserving x>=1.'
   elif short in ['exp75_lower','exp75_large','quarter_lower','quarter_large','normalized_remainder','absorbed_remainder']:
    comparison+=' Exponential certificates are ordinary kernel inequalities. Positivity and x^(1/4)>=exp75 absorb the lower-order prime-power remainder on the entire stated ray.'
   elif short in ['theta_transport','theta_two_term','theta_target','requested_bound']:
    comparison+=' Triangle inequality joins only the allowed psi input and proved arithmetic remainder. Structured source retains the stronger two-term form and exact16/exp75; prose proves the rational1e-13 allowance. Both prove the requested1e-9 allowance.'
  else:
   comparison='Finite nonnegative weights and slopes77..163 plus F330<=finiteCap are precisely the mathematical inputs. For Epi results the separate provided consumer is used only L>=330; backward finite-factor estimates do not extend it.'
   if short in ['pi','Li2','Epi','paired','finiteCap']:
    comparison+=' Definition bodies equal the packet formulas. Totalized values at a vanished denominator are unused: all proof-bearing P(D,L) uses prove L>D.'
   elif short in ['exp_small','exp_future_small','paired_lower','paired_base_lower','paired_upper','point_transfer','future_factor','backward_factor','ratio_future','ratio_back']:
    comparison+=' Prove positive denominators; exp(-(330-D)/8) is bounded by1/1048576(structured) or1e-6(prose). The sign of L-330 selects lower endpoint77 forward and upper endpoint163 backward; no weight distribution premise is added.'
   elif short in ['finiteSum','F','sum_transfer','future_envelope','backward_envelope']:
    comparison+=' Pointwise factor comparisons are multiplied by nonnegative weights and summed; n=0 remains valid. Helper comparison hypotheses are explicitly discharged by the final envelope proofs.'
   elif short in ['actual_epi_envelope','actual_Epi_envelope','actual_epi_checkpoints','actual_checkpoints','actual_checkpoint','Consumer','consumerRHS','epiEnvelope','H','remainder']:
    comparison+=' Exact consumer normalization is Epi(expL)*exp(L/8); multiplying by positive exp(-L/8) gives the actual Epi bound. Fixed checkpoints hold on whole future rays by antitonicity, not numerical sampling.'
   else:
    comparison+=' Rational antitonicity and exact endpoint inequalities certify full-ray bounds. The proved nonconstancy concerns the upper envelope, not F (which may be zero). These are known-target reconstructions and are weaker than the coordinator prior1e-8 envelope.'
  full='Read this declaration, all enclosing namespace/sections, the complete submitted Lean module and all candidate.md/STATUS.md provenance (when present), locked task/definitions, and source-owned proof construction. H02 header explicitly separates Mathlib arithmetic from new transport; H01 cites formal Abel support; H03 claims no upstream QRH/density proof. No declaration-local-only absence inference.'
  trust='Original discovery and independent verification are separate. New independent compile/type/axiom census is source-only, public generic inputs in distinct PID/mount/network namespaces; only Std3 in successful roots, no native execution axiom. This pure math is not source-first PV. PNT/finite-data/consumer hypotheses remain explicit as allowed; poststudy source integration is separate.'
  notes='No standalone Blueprint label for this experimental declaration; exact locked '+task+' task is correspondence. Source file/SHA/line/name identity is preserved; generated auxiliaries are separately in complete dependency/census evidence and are not extra discoveries.'
  if item['file'].endswith('TaskDefinitionsInput.lean')or(case=='H03-PROSE'and item['file'].endswith('TaskDefinitions.lean')):
   notes+=' This is an intentionally archived unmodified supplied stub; its Real def C/finiteCap lacks noncomputable and compilation fails as documented. It is not imported by the successful final proof chain. Mathematical bodies are unchanged; do not infer a false mathematical premise or invalidate the standalone proof.'
  if case=='H01-STRUCTURED':notes+=' This original case honestly stops before a Lean improper-tail/existsB theorem. Its finite identities and written derivation are valid, but original formal target completion remains partial; no retrospective rescore.'
  if case.startswith('H03'):notes+=' Predeclared known-target reconstruction, not new discovery, source-first PV or evidence of an original coefficient advantage.'
  rows.append(dict(file=item['file'],decl_line=item['decl_line'],lean_name=item['lean_name'],kind=item['kind'],proposed_verification_status='external_verified'if external else'internal_verified',actual_lean_declaration=signature,actual_primary_source_statement_or_explicit_absence=source,original_locator=locator,domain_and_hypotheses=signature,lean_source_comparison=comparison,mathematical_check='Checked exact formula, quantifiers, real domains, normalization, constants and proof-bearing branches against locked task and named primary formal support. '+comparison,full_scope_attribution_evidence=full,trust_boundary=trust,notes=notes))
 out=B/'ALL_WRITTEN_LEDGER_V1.csv';need(not out.exists(),'fresh ledger')
 with out.open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
 primaryrows=list(evidence.values());(B/'PINNED_PRIMARY_FORMAL_SUPPORT_V1.json').write_text(json.dumps(dict(status='EXACT_NAMED_FORMAL_LIBRARY_SUPPORT_CHECKED',sources=primaryrows),indent=2)+'\n');print('ledger',len(rows),'primary support',len(primaryrows))
if __name__=='__main__':main()
