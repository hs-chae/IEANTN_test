"""Actual offline browser geometry/static math/evidence-link and keyboard check."""
from pathlib import Path
import argparse,hashlib,json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[2];B=R/'exposure/heldout-audit-v1'
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--version',default='V6_DRAFT2');a=ap.parse_args();source=B/('HELDOUT_AND_MOMENT_ANT_REPORT_'+a.version+'.html');out=B/('report-browser-moment-'+a.version.lower())
 need(not out.exists(),'fresh browser evidence');out.mkdir();rows=[]
 with sync_playwright()as p:
  browser=p.chromium.launch(headless=True)
  for width,height in[(390,844),(1280,1000)]:
   ctx=browser.new_context(viewport=dict(width=width,height=height),offline=True);page=ctx.new_page();page.goto(source.as_uri(),wait_until='load');page.wait_for_function('document.fonts.status === "loaded"')
   a=page.evaluate(r'''() => ({width:innerWidth,scroll:document.documentElement.scrollWidth,scripts:document.scripts.length,math:document.querySelectorAll('math').length,external:[...document.querySelectorAll('script[src],link[href],img[src]')].map(x=>x.src||x.href).filter(x=>/^https?:/.test(x)),rawTeX:/\\\(|\\\[|\$\$/.test(document.body.innerText),formulaOverflow:[...document.querySelectorAll('.formula')].map(x=>({w:x.clientWidth,s:x.scrollWidth})).filter(x=>x.s>x.w),links:[...document.querySelectorAll('a[href]')].map(x=>x.getAttribute('href'))})''')
   need(a['scroll']<=width and not a['formulaOverflow'],'body/formula horizontal overflow');need(a['scripts']==0 and not a['external']and not a['rawTeX']and a['math']>0,'static offline rendered math')
   for href in a['links']:need(not href.startswith(('http:','https:'))and(B/href).is_file(),'actual local evidence link '+href)
   page.keyboard.press('Tab');focus=page.evaluate('document.activeElement.tagName');need(focus=='A','ordinary keyboard link navigation')
   shot=out/('width-'+str(width)+'.png');page.screenshot(path=str(shot),full_page=True)
   # Return to the title after the actual keyboard-navigation check.
   page.evaluate('scrollTo(0,0)')
   # Readable bounded screenshots for independent visual inspection.
   bounded=out/('top-'+str(width)+'.png');page.screenshot(path=str(bounded))
   rows.append(dict(width=width,metrics=a,first_tab=focus,screenshot_sha256=sha(shot),bounded_screenshot_sha256=sha(bounded)));ctx.close()
  version=browser.version;browser.close()
 result=dict(status='PASS_ACTUAL_OFFLINE_STATIC_MATH_LINKS_PHONE_DESKTOP_KEYBOARD',source_sha256=sha(source),browser=version,views=rows,qualification='Actual browser geometry/links/keyboard gates; visual screenshot review separately recorded.')
 (out/'RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'])
if __name__=='__main__':main()
