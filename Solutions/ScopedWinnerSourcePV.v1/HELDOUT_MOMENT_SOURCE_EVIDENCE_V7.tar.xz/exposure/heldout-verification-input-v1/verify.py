"""Fresh generic-only namespace compile and complete own-declaration axiom/type census.

Does not declare that a compiled candidate fulfills its mathematical task contract.
"""
from pathlib import Path
import json,hashlib,os,subprocess,time
B=Path('/task');OUT=Path('/out/verification');STD3={'propext','Classical.choice','Quot.sound'}
def need(x,m):
 if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(p):
 def unique(rows):
  d={}
  for k,v in rows:need(k not in d,'duplicate JSON key');d[k]=v
  return d
 return json.loads(p.read_text(),object_pairs_hook=unique)
def main():
 OUT.mkdir(exist_ok=False);meta=strict(Path('/environment.json'));need(meta['project_objects_reused']is False,'only pinned public generic object inputs');compiler=Path(meta['compiler']);generic=[x['objects']for x in meta['generic_dependencies']];caseRows=strict(B/'CASES.json')['cases'];need(len(caseRows)==6,'all six original candidates')
 for row in strict(B/'INPUTS.json')['files']:
  p=B/row['path'];need(p.is_file()and not p.is_symlink()and sha(p)==row['sha256']and p.stat().st_size==row['bytes'],'exact read-only candidate/validator input')
 interface_checks=[]
 for task in ['H01','H02','H03']:
  directory=OUT/('provided-interface-'+task);directory.mkdir();source=B/'provided-interfaces'/task/'TaskDefinitions.lean';env=dict(os.environ,LEAN_PATH=':'.join(generic),LEAN_NUM_THREADS='1');command=[str(compiler),'-j1','-R',str(source.parent),str(source),'-o',str(directory/'TaskDefinitions.olean')]
  with(directory/'stdout').open('wb')as so,(directory/'stderr').open('wb')as se:q=subprocess.run(['/usr/bin/time','-v','-o',str(directory/'time'),*command],cwd=directory,env=env,stdout=so,stderr=se)
  interface_checks.append(dict(task=task,source_sha256=sha(source),command=command,exit_code=q.returncode,stdout_sha256=sha(directory/'stdout'),stderr_sha256=sha(directory/'stderr'),qualification='Exact originally supplied definition source only; its objects are never candidate verification inputs. A failure remains a shared task-artifact limitation, not silently repaired.'))
 (OUT/'PROVIDED_INTERFACE_CHECKS.json').write_text(json.dumps(interface_checks,indent=2)+'\n')
 results=[]
 for case in caseRows:
  name=case['case'];out=OUT/name;out.mkdir();objects=out/'objects';objects.mkdir();logs=out/'logs';logs.mkdir();env=dict(os.environ,LEAN_PATH=':'.join([str(objects),*generic]),LEAN_NUM_THREADS='1');commands=[];failed=[];start=time.monotonic()
  def execute(module,source,output=None):
   command=[str(compiler),'-j1','-R',str(B/name/'source'if output else out),str(source)]
   if output:command+=['-o',str(output),'-i',str(logs/(module+'.ilean'))]
   with(logs/(module+'.stdout')).open('wb')as so,(logs/(module+'.stderr')).open('wb')as se:q=subprocess.run(['/usr/bin/time','-v','-o',str(logs/(module+'.time')),*command],cwd=out,env=env,stdout=so,stderr=se)
   commands.append(dict(module=module,command=command,exit_code=q.returncode,source_sha256=sha(source),stdout_sha256=sha(logs/(module+'.stdout')),stderr_sha256=sha(logs/(module+'.stderr')),time_sha256=sha(logs/(module+'.time')),object_sha256=sha(output)if output and output.is_file()else None,ilean_sha256=sha(logs/(module+'.ilean'))if(logs/(module+'.ilean')).is_file()else None))
   return q.returncode==0
  names=[r['module']for r in case['source_modules']];compiled_names=[];submitted=[r for r in case['locked_files']if r['path'].endswith('.lean')];rows=[]
  if not case['preparation_issues']:
   for source in case['source_modules']:
    need(sha(B/source['path'])==source['sha256'],'candidate unchanged before compile')
    if execute(source['module'],B/source['path'],objects/(source['module']+'.olean')):compiled_names.append(source['module'])
    else:failed.append(source['module'])
   if compiled_names:
    census_name='IndependentContractCensusV1'
    while census_name in names:census_name+='Extra'
    audit=out/(census_name+'.lean');owned='['+','.join('Name.mkSimple '+json.dumps(n)for n in compiled_names)+']'
    audit.write_text(''.join('import '+n+'\n'for n in compiled_names)+'import Lean.Util.CollectAxioms\nopen Lean Elab\nset_option maxHeartbeats 0\nset_option maxRecDepth 100000\nrun_elab do\n let env ← getEnv\n let owned : List Name := '+owned+'\n for (name, info) in env.constants.toList do\n  if let some idx := env.getModuleIdxFor? name then\n   let moduleName := env.header.moduleNames[idx]!\n   if owned.contains moduleName then\n    let ax ← Lean.collectAxioms name\n    let kind := if info.isTheorem then "theorem" else if info.isAxiom then "axiom" else "definition-or-generated"\n    logInfo m!"HELDOUT_DECL {(Json.mkObj [("name",toJson name.toString),("module",toJson moduleName.toString),("kind",toJson kind),("type",toJson (toString info.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"\n')
    if execute('census',audit):
     for line in(logs/'census.stdout').read_text().splitlines():
      if'HELDOUT_DECL 'in line:rows.append(json.loads(line.split('HELDOUT_DECL ',1)[1]))
    else:failed.append('census')
  written=[]
  for module in names:
   ilean=logs/(module+'.ilean')
   if ilean.is_file():
    info=strict(ilean)
    for lean_name,positions in info.get('decls',{}).items():
     need(isinstance(positions,list)and len(positions)>=8,'compiler declaration range schema')
     written.append(dict(module=module,file=module+'.lean',decl_line=positions[4]+1,lean_name=lean_name,compiler_range=positions))
  extra=[r for r in rows if not set(r['axioms'])<=STD3];theorems=[r for r in rows if r['kind']=='theorem']
  status='GENERIC_ONLY_COMPILE_AND_COMPLETE_DECLARATION_CENSUS_PASS_PENDING_MATHEMATICAL_CONTRACT_AUDIT'if submitted and not failed and not case['preparation_issues']and rows and not extra else'PARTIAL_OR_FAILED_FORMAL_CHECK_PRESERVED'
  result=dict(case=name,status=status,mechanically_admitted=case['mechanically_admitted'],known_target=case['known_target'],seconds=time.monotonic()-start,submitted_Lean_files=len(submitted),source_module_order=names,successfully_compiled_modules=compiled_names,preparation_issues=case['preparation_issues'],vocabulary_warnings=case.get('vocabulary_warnings',[]),failed_modules=failed,commands=commands,written_declarations=written,declarations=rows,theorems=len(theorems),nonstandard_axiom_roots=extra,mathematical_task_contract_accepted=False,source_first_PV=False,qualification='Fresh generic-only namespace compile/type/axiom census of original submitted bytes. Compilation is not proof that the exact requested mathematical statement or only its allowed premises were proved. Human source/contract audit remains mandatory; no repair or rescore.')
  tmp=out/'RECEIPT.pending';tmp.write_text(json.dumps(result,indent=2)+'\n');os.replace(tmp,out/'RECEIPT.json');results.append(result);print(json.dumps(dict(case=name,status=status,theorems=len(theorems),failures=failed)),flush=True)
 result=dict(status='ALL_SIX_INDEPENDENT_FORMAL_CHECKS_EXECUTED_MATHEMATICAL_CONTRACT_AUDIT_PENDING',cases=results,provided_interface_checks=interface_checks,namespace='outer existing launcher attestation',old_outcomes_unchanged=True,source_first_PV=False);tmp=OUT/'RECEIPT.pending';tmp.write_text(json.dumps(result,indent=2)+'\n');os.replace(tmp,OUT/'RECEIPT.json')
if __name__=='__main__':main()
