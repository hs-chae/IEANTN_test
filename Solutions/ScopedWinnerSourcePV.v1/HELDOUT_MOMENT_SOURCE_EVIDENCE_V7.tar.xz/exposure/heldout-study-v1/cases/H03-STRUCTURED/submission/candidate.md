# Whole-function finite-data transfer and conditional actual Epi bound

## Established results
Write
\[
 C=8433850764/10^{12},\qquad k=1048576/1048575,
\]
and define the explicit nonconstant envelope
\[
 \boxed{B(L)=Ck\frac{253L}{330(L-77)}}\quad(L\ge330).
\]
For **every** finite family in the question, including the empty family,
\[
 F(L)\le B(L)\qquad(L\ge330).
\]
The envelope is decreasing, satisfies B(500)<B(330), and on the **entire ray** L>=500 has B(L)<C. It does not assume a distribution of weights or a positive total weight. (It need not attain the input cap at 330.)

The separate backward result is
\[
 \boxed{F(L)\le Ck\frac{167L}{330(L-163)}<0.00935}
       \qquad(300\le L\le330).
\]
This result uses only the same finite input and slope interval; it makes no assertion about the analytic consumer below 330.

Put
\[
 R(L)=\frac{4}{10^6}\frac L{L-160}+\frac2{10^8}
       +\frac1{10^{12}}\frac L{L-880/3}+\frac2{10^{12}},
\qquad
 A(L)=(1+10^{-9})(B(L)+R(L))+10^{-12}+10^{-8}.
\]
Under exactly the question's second input, for the actual `Epi` defined using prime counting and the integral Li2,
\[
 \boxed{\operatorname{Epi}(\exp L)\le A(L)\exp(-L/8)}\qquad(L\ge330).
\]
A is decreasing. The following are strict whole-ray checkpoints, not isolated-point tests:

| Entire domain | Conditional actual Epi upper bound |
|---|---|
| L>=500 | 0.00765 exp(-L/8) |
| L>=1000 | 0.00702 exp(-L/8) |
| L>=10000 | 0.00653 exp(-L/8) |

All displayed bounds and checkpoint strictness are kernel-checked in `Envelope.lean`. Exact rational checkpoint evaluation uses `norm_num`, not floating-point estimates.

## Derivation
For D in [77,163], set t=330-D>=167. The elementary exponential inequality exp(1)>=2, raised to the twentieth power, and monotonicity give
\[
 \exp(t/8)\ge\exp(20)\ge2^{20}=1048576,
 \qquad \exp(-t/8)\le1/1048576.
\]
Since 0<=D<=330 and 330-D>0,
\[
 P(D,330)\ge\frac{330-D/1048576}{330-D}
 \ge\frac{1048575}{1048576}\frac{330}{330-D}.
\]
For every L>D, nonnegativity of the subtracted exponential term also gives P(D,L)<=L/(L-D). These two estimates imply
\[
 P(D,L)\le k\frac{L(330-D)}{330(L-D)}P(D,330).
\]
Equivalently, this follows by multiplying the preceding positive lower bound; no division by P or by a weight is needed.

For L>=330, cross multiplication shows
\[
 \frac{330-D}{L-D}\le\frac{253}{L-77};
\]
the numerator of the difference after multiplying positive denominators is (L-330)(D-77)>=0. For 300<=L<=330 the other endpoint applies:
\[
 \frac{330-D}{L-D}\le\frac{167}{L-163},
\]
with difference numerator (330-L)(163-D)>=0. Multiplication by each nonnegative weight and summation yield the two envelopes using F(330)<=C. All multiplying factors are nonnegative.

For a>=0 and a<X<=L, direct cross multiplication proves
\[
 \frac{L}{L-a}\le\frac{X}{X-a}.
\]
This establishes monotonicity of B (a=77), of the backward envelope (a=163), and of R (a=160 and 880/3). Rational evaluation at 500 gives B(500)<C, hence strict improvement on the entire ray. Evaluation of the backward envelope at 300 gives <0.00935. The same monotonicity and rational arithmetic give the three A checkpoints. Substituting F<=B in the supplied consumer and multiplying by positive exp(-L/8) proves the actual Epi statements because exp(L/8)exp(-L/8)=1.

Denominators hold on their full domains: for L>=330, L-D>=167, L-77>=253, L-160>=170, L-880/3>=110/3, and 330-D>=167. For L>=300, L-D>=137 and L-163>=137. The Lean development includes explicit positive-denominator certificates as well as the positivity facts used locally in the algebraic proofs.

## Proof and reproducibility
- `Envelope.lean`: complete Lean proofs, with no `sorry`, new axioms, or `native_decide`. Main theorems: `future_envelope`, `backward_envelope`, `strict_improvement`, `actual_epi_envelope`, `actual_epi_checkpoints`. `finiteSum` uses `Fin n`, equivalent to indexing i<n. Real rational notation is used throughout.
- `TaskDefinitions.lean`: supplied definitions with the sole elaboration repair described below. The definitions of pi, Li2, Epi and paired are unchanged.
- `TaskDefinitions.original.txt`: exact unmodified supplied file.
- `check.py`: reproduces the build and optional exact rational diagnostic evaluations. Execute `/usr/bin/python3.10 check.py` from the submission directory. It runs `/bin/lean -o /work/objects/TaskDefinitions.olean TaskDefinitions.lean`, then the analogous command for Envelope.lean.
- `compile.log`: actual successful compile output and axiom reports. Only standard library axioms `propext`, `Classical.choice`, `Quot.sound` are reported for the main theorems.
- `numerics.txt`: executed diagnostic rational evaluations with decimal renderings; these are not used as proof premises.

The exact supplied `def finiteCap : ℝ := ...` fails executable-code compilation in the pinned toolchain: `TaskDefinitions.lean:9:4: error(lean.dependsOnNoncomputable): failed to compile definition, consider marking it as 'noncomputable' because it depends on 'instDivInvMonoid', which is 'noncomputable'`. The submitted compiling version changes only `def finiteCap` to `noncomputable def finiteCap`. This does not change its mathematical value or introduce a premise. The original is preserved so this repair is explicit. Earlier draft tactic errors were corrected; `compile.log` is the final reproducible build, not a claim that drafts compiled.

## Scope and limitations
No additional mathematical hypotheses are used. The consumer is a hypothesis, not an upstream theorem proved here. There is no proof of QRH, zero density, or the analytic sources of that consumer. There is no extension of the consumer to 300. Optimality is not claimed; the harmless factor k loses a small amount at the initial point. There are no remaining proof obligations for the statements above. This is an ordinary Lean kernel proof and known-target reconstruction, **not source-first program verification**: no executable analytic algorithm-to-semantics correctness boundary is asserted.
