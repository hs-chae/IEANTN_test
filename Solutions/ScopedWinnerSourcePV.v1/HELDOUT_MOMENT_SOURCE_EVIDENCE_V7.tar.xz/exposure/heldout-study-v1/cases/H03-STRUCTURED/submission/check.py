# Offline reproducible kernel build and rational diagnostic computations.
import os, subprocess
from fractions import Fraction as Q
os.chdir(os.path.dirname(os.path.abspath(__file__)))
os.makedirs('/work/objects', exist_ok=True)
with open('compile.log','w') as log:
    for source in ['TaskDefinitions.lean','Envelope.lean']:
        cmd=['/bin/lean','-o','/work/objects/'+source.replace('.lean','.olean'),source]
        log.write('$ '+' '.join(cmd)+'\n'); log.flush()
        result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        log.write(result.stdout+'Exit code: '+str(result.returncode)+'\n'); log.flush()
        if result.returncode: raise SystemExit(result.returncode)
C=Q(8433850764,10**12)
with open('numerics.txt','w') as out:
    out.write('Exact rational evaluations (diagnostics, not proof by numerical experiment):\n')
    for L in [330,500,1000,10000]:
        B=C*Q(1048576,1048575)*Q(253*L,330*(L-77))
        R=Q(4,10**6)*Q(L,L-160)+Q(2,10**8)+Q(1,10**12)*Q(L,Q(L)-Q(880,3))+Q(2,10**12)
        A=(1+Q(1,10**9))*(B+R)+Q(1,10**12)+Q(1,10**8)
        out.write(f'L={L}: B={B}; A={A}; decimals B={float(B):.16g}, A={float(A):.16g}\n')
    H=C*Q(1048576,1048575)*Q(167*300,330*137)
    out.write(f'Backward300={H}; decimal={float(H):.16g}\n')
