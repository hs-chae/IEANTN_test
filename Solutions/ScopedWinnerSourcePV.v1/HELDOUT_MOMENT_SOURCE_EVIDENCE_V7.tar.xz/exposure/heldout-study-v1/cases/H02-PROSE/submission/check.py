"""Reproduce kernel elaboration/checking; generated olean is outside payload."""
import os, subprocess
os.chdir(os.path.dirname(os.path.abspath(__file__)))
commands = [["/bin/lean", "--version"],
            ["/bin/lean", "-o", "/work/Main.olean", "Main.lean"]]
with open("compile.log", "w") as log:
    for cmd in commands:
        log.write("$ " + " ".join(cmd) + "\n")
        p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log.write(p.stdout)
        log.write("exit_code=" + str(p.returncode) + "\n")
        log.flush()
        if p.returncode:
            raise SystemExit(p.returncode)
