# Whole-ray transport for the actual Chebyshev functions

## Established result

Put C = 9354674/1000000000. Assume precisely

    for every real t ≥ exp(300), |Chebyshev.psi t − t|/t ≤ C t^(−1/8).

Then, for **every real x ≥ exp(300)**,

    |Chebyshev.theta x − x|/x
      ≤ (C + 1/10000000000000) x^(−1/8).

Thus the coefficient can be 93546740001/10000000000000. In particular the requested coefficient C + 10^(−9) is valid. Both conclusions are kernel-checked in `Main.lean` as `ExposureTask.theta_transport` and `ExposureTask.requested_bound`.

These are conditional theorems with the stated psi estimate as their sole analytic hypothesis. The estimate is not asserted unconditionally. No RH, small-height analytic estimate, or experimental premise is used.

## Arithmetic bridge and real endpoints

Write N = floor_nat(log x/log 2). For x ≥ 2 we prove the finite exact identity

    psi(x) − theta(x) = sum_{k=2}^N theta(x^(1/k)).                  (1)

All these are the actual Mathlib functions, with their natural-floor definitions; powers with a real exponent are real powers. `exact_prime_powers` states (1). The `ArithmeticBridge` namespace includes the full finite reindexing and psi-to-theta derivation, reproduced from the generic Mathlib source, and used in the submitted remainder proof. This is a proved arithmetic bridge, not an additional theorem parameter.

Here is the reindexing argument, including its termination justification. In psi, von Mangoldt is zero off prime powers. Every remaining integer n has a unique representation p^k with p prime and positive integer k. For n ≤ x we have 2^k ≤ p^k ≤ x, hence k log 2 ≤ log x. Consequently k ≤ N. Also p ≤ p^k ≤ x. For nonnegative real x and positive k,

    p^k ≤ x  iff  p ≤ x^(1/k).

Since p and p^k are integers, their inequalities against the nonnegative real endpoints are exactly their inequalities against the corresponding natural floors. This gives a bijection between prime powers in the finite defining sum and pairs

    1 ≤ k ≤ N, p prime, 0 < p ≤ floor_nat(x^(1/k)).

Its injectivity is uniqueness of positive powers of primes; surjectivity is prime-power factorization. On each pair, vonMangoldt(p^k) = log p. Thus psi is the sum of theta(x^(1/k)) over 1 ≤ k ≤ N. Since x ≥ 2 implies N ≥ 1, removing k = 1 gives (1). The same proof in the source allows any finite upper cutoff at least N. No unjustified infinite series or integer-only endpoint restriction appears.

## Elementary control of the complete remainder

Let R(x) = psi(x) − theta(x). Positivity of log p gives R(x) ≥ 0. The elementary Chebyshev inequality

    theta(y) ≤ log(4) y   for every real y ≥ 0

is a proved generic-library theorem, `Chebyshev.theta_le_log4_mul_x`. It follows by writing theta(y) as log of the primorial at floor_nat(y), using primorial(n) ≤ 4^n and floor_nat(y) ≤ y. This elementary inequality, unlike the analytic hypothesis, applies at **every** root argument in (1), including those below exp(300).

For x ≥ 2 and 2 ≤ k ≤ N we have x^(1/k) ≤ sqrt(x). The number of terms in (1) is N−1 ≤ log x/log 2. Therefore

    0 ≤ R(x) ≤ (log x/log 2) log(4) sqrt(x)
             = 2 sqrt(x) log x.                                 (2)

For 1 ≤ x < 2 both psi and theta vanish, and the same bound holds. The source includes and uses the complete finite-sum proof of the absolute-value version of (2), `ArithmeticBridge.abs_psi_sub_theta_le_sqrt_mul_log`.

The elementary inequality log x ≤ x^a/a for x ≥ 0 and a > 0, applied with a = 1/8, now gives

    0 ≤ R(x) ≤ 16 x^(5/8)                    (x ≥ 1).             (3)

This is `remainder_bound`. The logarithmic estimate is the proved real-analysis library lemma `Real.log_le_rpow_div`. Neither (2) nor (3) uses the psi hypothesis.

## Uniform absorption on the entire ray

The exponential threshold is certified by rational arithmetic and elementary exponential identities:

    exp(3) ≥ 3+1 = 4,
    exp(75) = exp(3)^25 ≥ 4^25
            = 1125899906842624 ≥ 160000000000000.

For every x ≥ exp(300), monotonicity of nonnegative real powers gives

    x^(1/4) ≥ exp(75) ≥ 160000000000000.

Multiply by x^(5/8) ≥ 0, use x^(5/8)x^(1/4) = x^(7/8), and divide the integer coefficient. With (3), this yields the uniform bound

    0 ≤ R(x) ≤ 10^(−13) x^(7/8).                                (4)

The Lean lemmas `exp75_large`, `quarter_large`, and `absorbed_remainder` prove exactly these statements. The integer inequalities are proved by `norm_num`, not by floating-point experiments.

Finally, the triangle inequality and R(x) ≥ 0 give

    |theta(x)−x| ≤ |psi(x)−x| + R(x).

Use the analytic hypothesis only at t = x, insert (4), divide by positive x, and use x^(7/8)/x = x^(−1/8). This proves the stated stronger bound. In particular no analytic hypothesis is ever applied at a root argument. The final coefficient comparison to C + 10^(−9) is exact rational arithmetic.

## Proof artifacts and reproducibility

* `Main.lean`: complete checked proof source. It imports the generic `Mathlib`; the task definitions are reproduced verbatim inside a `noncomputable section` so that `def C : ℝ` elaborates. No replacement/proxy Chebyshev functions are introduced.
* `check.py`: exact executable checking commands. Run `/usr/bin/python3.10 /work/submission/check.py`. It writes the compiled object to `/work/Main.olean`, outside the payload.
* `compile.log`: final command output and exit codes, including Lean version and axiom reports.
* `development.txt`: development diagnostics and scope notes.

The final Lean run exits 0. The two final theorems depend only on the standard Lean foundational axioms `propext`, `Classical.choice`, and `Quot.sound`; neither uses `sorryAx`, new axioms, or `native_decide`. No numerical experiment was needed or executed. This is ordinary Lean mathematical kernel checking, **not** a claim of source-first program verification.

ArithmeticBridge provenance: `/generic-source/mathlib/NumberTheory/Chebyshev.lean`, SHA256 `074796f7737b6d08e00f07240e4436349e99a9e033cfc4128b96327bdcff8625`. The reproduced proofs run from `sum_PrimePow_eq_sum_sum'` through the finite theta identities, and include `abs_psi_sub_theta_le_sqrt_mul_log`. Their attribution is retained in the Lean source. Standard Mathlib arithmetic and analysis results used by these proofs remain imported library dependencies, not extra mathematical assumptions.

## Remaining obligations

None for the stated conditional bounds. The psi estimate itself is explicitly an input, not proved here. No claim about correctness of the Lean compiler implementation or a source-to-semantics boundary is made.
