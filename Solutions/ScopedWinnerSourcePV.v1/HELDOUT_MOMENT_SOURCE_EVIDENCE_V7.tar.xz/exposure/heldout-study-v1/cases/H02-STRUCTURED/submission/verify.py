"""Recompile the submitted proof; no numerical experiment or source-first PV claim."""
import subprocess
from pathlib import Path
root = Path(__file__).resolve().parent
cmd = ["/bin/lean", str(root / "Main.lean")]
v = subprocess.run(["/bin/lean", "--version"], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
log = "COMMAND: /bin/lean --version\n" + v.stdout
log += "COMMAND: " + " ".join(cmd) + "\n" + p.stdout
log += "EXIT STATUS: " + str(p.returncode) + "\n"
(root / "compile.log").write_text(log)
print(log, end="")
raise SystemExit(p.returncode)
