# Whole-ray transport for the actual Chebyshev functions

## Established result

Put C = 9354674/1000000000. Assume only

    ∀ t ∈ ℝ, exp(300) ≤ t → |Chebyshev.psi(t) − t|/t ≤ C t^(−1/8).

For **every real x ≥ exp(300)**, the kernel-checked theorem `theta_transport` proves

    |Chebyshev.theta(x) − x|/x ≤ (C + 16/exp(75)) x^(−1/8).

In particular `theta_target` proves the requested bound with C + 1/1000000000.
Also `theta_two_term` proves the more informative pointwise bound

    |theta(x) − x|/x ≤ C x^(−1/8) + 2 sqrt(x) log(x)/x.

All powers here are real powers; the objects are exactly Mathlib's `Chebyshev.psi`
and `Chebyshev.theta`. No extra hypotheses, low-height analytic estimates, or RH
are used. The analytic hypothesis remains a theorem parameter, not a claimed
unconditional fact.

## Arithmetic bridge and real endpoints

Write N = floor_nat(log(x)/log(2)). The formal arithmetic section proves, for
real x ≥ 2,

    psi(x) − theta(x) = sum_{k=2}^N theta(x^(1/k)) ≥ 0.                 (1)

This is a finite identity, not an input parameter. The proof in `Main.lean`
includes the prime-power reindexing and the endpoint argument, adapted from the
supplied generic Mathlib Chebyshev source, rather than postulating the identity.
Here are the details of that argument.

By definition psi sums the von Mangoldt function Λ(n) for 0 < n ≤ floor_nat(x),
and theta sums log(p) over primes in that interval. The support of Λ is the
prime powers, and Λ(p^k) = log(p) for prime p and positive integer k. Such a
representation is unique (prime-base and positive-exponent uniqueness). For
x ≥ 0, p^k ≤ floor_nat(x) is equivalent to the real inequality p^k ≤ x.
For k ≥ 1 this is equivalent to p ≤ x^(1/k), and hence to
p ≤ floor_nat(x^(1/k)). No rounding of x or its roots is suppressed.

A contributing prime satisfies p ≥ 2. Thus 2^k ≤ p^k ≤ x, so
k log(2) ≤ log(x), whence k ≤ N. Conversely every prime and exponent in these
ranges gives a contributing integer. The explicit `sum_bij` in
`Arithmetic.sum_PrimePow_eq_sum_sum'` proves this bijection, including
surjectivity, injectivity, and these endpoint/cutoff statements. It even permits
any larger integer cutoff; the extra terms are zero. Applying it to Λ gives

    psi(x) = sum_{k=1}^N theta(x^(1/k)).

For x ≥ 2 we have N ≥ 1; removing the k=1 term gives (1). All summands in
(1) are nonnegative. For x < 2 both functions are zero, so nonnegativity of the
remainder holds for every real x.

## Elementary control of every root, including small arguments

For every real y ≥ 0 one has

    0 ≤ theta(y) ≤ log(4) y.                                       (2)

The upper bound follows by writing theta(y) as log of the primorial of
floor_nat(y), using the elementary integer bound primorial(n) ≤ 4^n, and
floor_nat(y) ≤ y. Its formal derivation is included in the arithmetic section;
the primorial inequality itself is a generic library theorem. There is no use
of the assumed psi estimate here, at y or anywhere else.

For x ≥ 2 and k ≥ 2, x^(1/k) ≤ sqrt(x). Apply (2) separately to every term
of (1). There are N−1 terms, so

    0 ≤ psi(x) − theta(x)
      ≤ (N−1) log(4) sqrt(x)
      ≤ [log(x)/log(2)] log(4) sqrt(x)
      = 2 sqrt(x) log(x).                                         (3)

For 1 ≤ x < 2 the same absolute-value bound holds since the remainder is zero.
The proof `Arithmetic.abs_remainder` checks this sum bound with the actual
natural cardinality, floor inequality and log(4)=2 log(2). In particular all
higher powers have been controlled, even when their roots are below exp(300),
near 2, or have crossed an integer endpoint.

## Uniform absorption

The elementary inequality log(x) ≤ x^epsilon/epsilon for x ≥ 0, epsilon > 0,
with epsilon = 1/8 gives from (3), for x ≥ 1,

    |psi(x) − theta(x)| ≤ 16 x^(5/8).

For x ≥ exp(300), x^(1/4) ≥ exp(75). Therefore, using positivity of x,

    |psi(x) − theta(x)|/x
      ≤ 16 x^(−3/8)
      ≤ [16/exp(75)] x^(−1/8).                                    (4)

For a rational certificate of the requested coefficient comparison,
exp(1) ≥ 2 implies exp(75) ≥ 2^75. Thus

    16/exp(75) ≤ 16/2^75 = 1/2361183241434822606848 < 1/1000000000.

The Lean comparison uses only exponential identities, monotonicity and exact
rational normalization, not floating-point computation.

Finally the triangle inequality gives

    |theta(x)−x| ≤ |psi(x)−x| + |psi(x)−theta(x)|.

Divide by positive x, apply the analytic hypothesis at x itself, and apply
(4). This proves the displayed whole-ray result. Applying (3) instead gives
`theta_two_term`. The input is never specialized to a smaller root.

## Formal status and reproducibility

- `Main.lean` contains complete submitted proof source. The arithmetic section
  is adapted, with attribution, from the supplied generic library, and is
  rechecked as part of this file. Other elementary Mathlib theorems (e.g. the
  primorial bound and von Mangoldt support/prime-power facts) are imported,
  not assumed as new axioms.
- The task definitions are reproduced verbatim within a `noncomputable section`
  (necessary for real-number `C` to elaborate in this standalone file).
- Run `/usr/bin/python3.10 /work/submission/verify.py`. It invokes
  `/bin/lean /work/submission/Main.lean` and records `compile.log`.
- Final compilation exit status is 0 under Lean 4.34.0-rc2. The log records
  `#print axioms` for the arithmetic bijection, exact remainder, elementary
  remainder bound, and all three final consumer theorems. Each reports only
  `propext`, `Classical.choice`, and `Quot.sound`. There are no `sorry`, new
  axioms, or `native_decide` invocations.
- No numerical experiments were used or performed. Exact rational normalization
  inside Lean is part of the checked proofs.
- This is ordinary Lean kernel theorem proving, **not source-first program
  verification**. No executable source-to-semantics claim is made.

### Remaining obligations

None for the stated conditional transport theorem or its arithmetic remainder.
The analytic psi estimate is the supplied input and has not been proved here.
The result makes no assertion of that input below exp(300).

Generic Chebyshev source consulted: `/generic-source/mathlib/NumberTheory/Chebyshev.lean`.
SHA256: 074796f7737b6d08e00f07240e4436349e99a9e033cfc4128b96327bdcff8625
