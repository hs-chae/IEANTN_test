"""Rebuild the submitted proofs using only the assigned offline Lean wrapper."""
import os
import subprocess
from pathlib import Path
root = Path(__file__).resolve().parent
os.chdir(root)
Path('/work/objects').mkdir(parents=True, exist_ok=True)
commands = [
    ['/bin/lean', '--version'],
    ['/bin/lean', '-o', '/work/objects/TaskDefinitions.olean', 'TaskDefinitions.lean'],
    ['/bin/lean', '-o', '/work/objects/Formal.olean', 'Formal.lean'],
    ['/bin/lean', '-o', '/work/objects/Tail.olean', 'Tail.lean'],
    ['/bin/lean', 'audit.lean'],
]
with open('compile.log', 'w') as log:
    for cmd in commands:
        log.write('$ ' + ' '.join(cmd) + '\n')
        log.flush()
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        log.write(p.stdout)
        log.write('EXIT ' + str(p.returncode) + '\n\n')
        log.flush()
        if p.returncode:
            raise SystemExit(p.returncode)
