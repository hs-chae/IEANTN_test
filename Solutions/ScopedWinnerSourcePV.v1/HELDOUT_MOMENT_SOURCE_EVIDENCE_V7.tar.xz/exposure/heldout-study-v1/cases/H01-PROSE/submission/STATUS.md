# Status and reproduction

**Complete:** the requested conditional theorem is Lean kernel-checked, not merely generated source. `Tail.lean: final_consumer` proves existence, real-atTop convergence, and the 9C bound for all real x ≥ exp(300), for the actual packet definitions. `sharper_whole_ray_error` proves the stronger integral-tail bound. `unique_reciprocal_limit` proves uniqueness. No mathematical or Lean obligations remain for these statements.

## Source map
- `TaskDefinitions.lean`: packet definitions with one elaboration-only addition described below.
- `Formal.lean`: identifies prime-indicator sums with actual primeCounting and H; specializes Mathlib's proved Abel summation to obtain the discrete-prime identity; proves the offset Li2 cancellation, compact integrability, and exact finite error identity.
- `Tail.lean`: elementary improper power integral and logarithmic tail majorant; converts the sole input into a pointwise weighted error bound; proves actual error integrability, tail bound, exact tail identity, final bound, convergence and uniqueness. `PrimeCountingInput` is a definition of a proposition, not a theorem or axiom; every theorem using it takes it as an explicit argument.
- `candidate.md`: readable mathematical derivation with the exact B used in Lean.
- `audit.lean`: displays the final statement and transitive axiom dependencies.
- `build.py`, `compile.log`: exact rebuilding commands and their actual final diagnostics. All commands exit 0. Warnings are only locale and tactic/style linters.

## Definition-file elaboration adjustment
The exact packet file was first compiled from /work/submission with

    /bin/lean -o /work/objects/TaskDefinitions.olean TaskDefinitions.lean

and returned exit 1 with:

    TaskDefinitions.lean:10:4: error(lean.dependsOnNoncomputable): failed to compile definition, consider marking it as 'noncomputable' because it depends on 'instDivInvMonoid', which is 'noncomputable'

The submitted file adds ONLY `noncomputable section` immediately after `import Mathlib`. This allows the given real rational constant `def C` to elaborate; it changes none of the mathematical definitions, hypotheses, normalization, or domains. All definition bodies are otherwise identical to /task/TaskDefinitions.lean.

## Reproduce
From /work/submission run:

    /usr/bin/python3.10 build.py

This uses /bin/lean (the assigned Lean 4.34.0-rc2 wrapper), the preinstalled generic Mathlib, and a fresh build of each submitted imported module under /work/objects. No application-specific proof cache is used. The wrapper's LEAN_PATH supplies generic libraries and /work/objects. All research shell invocations used non-login /bin/bash; all Python used /usr/bin/python3.10. No numerical experiments, network requests, delegation, or external mathematical sources were used.

The audit reports only the standard foundational dependencies `propext`, `Classical.choice`, `Quot.sound`, with no added axioms or admitted proofs. No native_decide is used. The proof is ordinary Lean kernel verification of mathematics, **not source-first program verification**; no executable source-to-semantics boundary is asserted.
