# Prime-reciprocal constant from the stated prime-counting input

## Result (mathematical derivation and Lean kernel-checked theorem)
Put A=exp(300), a=1/8, C=9354674/1000000000, and use exactly the definitions in TaskDefinitions.lean. Assume only

    Epi(t) ≤ C t^(-1/8) for every real t ≥ A.

There is a unique real B such that, as real x tends to +infinity,

    H(x) - log(log x) → B.

For EVERY real x≥A, including prime endpoints,

    |H(x)-log(log x)-B|
      ≤ C [x^(-1/8)/log x + ∫_x^∞ t^(-9/8)/log t dt]
      ≤ 9 C x^(-1/8)/log x.

The first displayed bound is stronger. No information about Epi below A is used.

## Discrete summation identity, including endpoints
For x≥2, put N=floor(x) and let primes be natural prime numbers. For each prime p≤x,

    1/p = 1/x + ∫_p^x dt/t².

Sum this finite equality. On [2,x], the sum of the indicators 1_{p≤t}, over primes p≤x, is exactly pi(t). Interchanging this FINITE sum and integral is valid; each indicator times t^(-2) is bounded and has at most one discontinuity on this compact interval. Inclusion/exclusion of individual integration endpoints does not change the integral. Consequently

    H(x) = pi(x)/x + ∫_2^x pi(t)/t² dt.                 (1)

At x=2, this says 1/2=1/2+0. Thus the prime 2 is not accidentally lost. Equivalently for y≥x≥2,

    H(y)-H(x) = pi(y)/y-pi(x)/x + ∫_x^y pi(t)/t² dt.  (2)

This also verifies the convention that H(x) includes a prime at x, whereas the difference sums primes in (x,y]. Pi(t) is the actual step counting function, since for t≥0 the natural floor satisfies p≤floor(t) iff the real cast of p is ≤t.

## Subtracting the offset logarithmic integral
Let L(t)=Li2(t) and R(t)=pi(t)-L(t). On [2,∞), L is continuously differentiable, L(2)=0, and L'(t)=1/log t. Integration by parts gives

    L(x)/x + ∫_2^x L(t)/t² dt
       = ∫_2^x dt/(t log t)
       = log(log x)-log(log 2).

Every denominator is positive on this domain. Subtracting this from (1) yields

    H(x)-log(log x)
      = -log(log 2) + R(x)/x + ∫_2^x R(t)/t² dt.       (3)

R is locally integrable on [2,∞): pi is a finite step function on every compact interval, and L is continuous. Thus none of these compact integrals needs a prime-counting estimate.

## Tail and construction of B
For t≥A, log t≥300 and t>0, so multiplying the given normalized error inequality by the POSITIVE denominator t/log t proves

    |R(t)| ≤ C t^(7/8)/log t,
    |R(t)|/t² ≤ C t^(-9/8)/log t.                    (4)

For x≥A, monotonicity of log and the elementary power integral imply

    ∫_x^∞ t^(-9/8)/log t dt
       ≤ (1/log x) ∫_x^∞ t^(-9/8) dt
       = 8 x^(-1/8)/log x.                          (5)

For completeness the antiderivative is -8 t^(-1/8); its value tends to zero at infinity. The bound (4), local integrability, and (5) imply absolute convergence of the improper integral of R(t)/t² from A to infinity. Define the real number

    B = -log(log 2) + ∫_2^A R(t)/t² dt
                         + ∫_A^∞ R(t)/t² dt.        (6)

For every x≥A, additivity of the absolutely convergent integral and (3) now give the EXACT tail formula

    H(x)-log(log x)-B = R(x)/x - ∫_x^∞ R(t)/t² dt.    (7)

Taking absolute values, using (4) at x, then (4) under the tail integral, gives the first bound in the result. Applying (5) gives 9C. Since x^(-1/8)/log x tends to zero, (7) also proves convergence. Uniqueness follows from uniqueness of a real limit. This proves the mathematical theorem with no extra analytic premises. B is not numerically identified with any literature constant.

## Verification boundary
The final consumer, whole-ray bound, sharper integral bound, convergence, and uniqueness are all Lean kernel-checked: see Tail.lean, Formal.lean, audit.lean, and compile.log. STATUS.md documents the exact build and the single elaboration-only repair to the packet definitions. There are no remaining mathematical or formal proof obligations for the claimed result. No numerical experiment is used. This is not source-first program verification: no executable arithmetic consumer semantics is verified here.
