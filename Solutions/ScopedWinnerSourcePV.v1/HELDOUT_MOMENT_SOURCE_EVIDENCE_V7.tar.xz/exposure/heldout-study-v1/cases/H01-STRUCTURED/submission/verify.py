"""Reproduce compile diagnostics; this is not a numerical experiment."""
import os
import subprocess
from pathlib import Path
root = Path(__file__).resolve().parent
os.chdir(root)
Path('/work/objects').mkdir(exist_ok=True)
commands = [
    ['/bin/lean', '--version'],
    ['/bin/lean', 'TaskDefinitionsInput.lean'],
    ['/bin/lean', '-o', '/work/objects/TaskDefinitions.olean', 'TaskDefinitions.lean'],
    ['/bin/lean', '-o', '/work/objects/Formal.olean', 'Formal.lean'],
]
with open('compile.log', 'w') as log:
    for i, cmd in enumerate(commands):
        log.write('$ ' + ' '.join(cmd) + '\n')
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        log.write(result.stdout)
        log.write('EXIT ' + str(result.returncode) + '\n\n')
        log.flush()
        if i != 1 and result.returncode:
            raise SystemExit(result.returncode)
print('Annotated definitions and Formal.lean: compiled successfully.')
