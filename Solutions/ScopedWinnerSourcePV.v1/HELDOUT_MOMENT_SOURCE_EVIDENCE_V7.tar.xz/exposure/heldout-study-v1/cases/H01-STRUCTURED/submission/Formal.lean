import TaskDefinitions
import Mathlib.NumberTheory.AbelSummation
namespace ExposureTask
open Real MeasureTheory Finset
noncomputable section

def primeIndicator (n : ℕ) : ℝ := if n.Prime then 1 else 0

lemma count_indicator (x : ℝ) :
    (∑ n ∈ Finset.Icc 0 ⌊x⌋₊, primeIndicator n) = pi x := by
  rw [pi, ← Nat.primesLE_card_eq_primeCounting]
  rw [Nat.primesLE_eq_filter_Icc_zero]
  simp [primeIndicator, Finset.sum_ite]

lemma reciprocal_indicator (x : ℝ) :
    (∑ n ∈ Finset.Icc 0 ⌊x⌋₊, (1 / (n:ℝ)) * primeIndicator n) =
      primeReciprocal x := by
  unfold primeReciprocal
  rw [← Nat.primesLE_eq_filter_range, Nat.primesLE_eq_filter_Icc_zero]
  simp [primeIndicator, Finset.sum_ite]

lemma inv_deriv (t : ℝ) (ht : t ≠ 0) :
    deriv (fun s : ℝ => 1 / s) t = -(1 / t^2) := by
  simpa using (hasDerivAt_id t).one_div ht |>.deriv

/-- Actual prime partial summation, including both endpoints. -/
theorem prime_partial_summation (x : ℝ) (hx : 2 ≤ x) :
    primeReciprocal x = pi x / x +
      ∫ t in Set.Ioc (2:ℝ) x, pi t / t^2 := by
  have hd : ∀ t ∈ Set.Icc (2:ℝ) x,
      DifferentiableAt ℝ (fun s : ℝ => 1 / s) t := by
    intro t ht
    exact (differentiableAt_const (1:ℝ)).div differentiableAt_id (by linarith [ht.1])
  have he : Set.EqOn (deriv (fun s : ℝ => 1 / s))
      (fun t : ℝ => -(1 / t^2)) (Set.Icc 2 x) := by
    intro t ht
    exact inv_deriv t (by linarith [ht.1])
  have hi : IntegrableOn (deriv (fun s : ℝ => 1 / s)) (Set.Icc 2 x) := by
    apply IntegrableOn.congr_fun _ he.symm measurableSet_Icc
    apply ContinuousOn.integrableOn_Icc
    apply ContinuousOn.neg
    exact continuousOn_const.div (continuousOn_id.pow 2) (by
      intro t ht
      exact pow_ne_zero _ (by linarith [ht.1]))
  have h := sum_mul_eq_sub_integral_mul₁ primeIndicator (by simp [primeIndicator, Nat.not_prime_zero, Nat.not_prime_one])
    (by simp [primeIndicator, Nat.not_prime_zero, Nat.not_prime_one]) x hd hi
  rw [reciprocal_indicator, count_indicator] at h
  have heq : (∫ t in Set.Ioc (2:ℝ) x,
      deriv (fun s : ℝ => 1 / s) t * ∑ k ∈ Icc 0 ⌊t⌋₊, primeIndicator k) =
      -(∫ t in Set.Ioc (2:ℝ) x, pi t / t^2) := by
    rw [← integral_neg]
    apply setIntegral_congr_fun measurableSet_Ioc
    intro t ht
    dsimp only
    rw [count_indicator, inv_deriv t (by linarith [ht.1])]
    ring
  rw [heq] at h
  convert! h using 1 <;> ring

lemma log_pos_on {t : ℝ} (ht : 2 ≤ t) : 0 < log t :=
  Real.log_pos (by linarith)

lemma log_integrand_continuous {x : ℝ} (hx : 2 ≤ x) :
    ContinuousOn (fun t : ℝ => 1 / log t) (Set.Icc 2 x) := by
  exact continuousOn_const.div (Real.continuousOn_log.mono (by
    intro t ht
    exact ne_of_gt (by linarith [ht.1])))
    (fun t ht => ne_of_gt (log_pos_on ht.1))

lemma Li2_hasDerivAt {t : ℝ} (ht : 2 ≤ t) :
    HasDerivAt Li2 (1 / log t) t := by
  apply intervalIntegral.integral_hasDerivAt_right
  · exact (show ContinuousOn (fun t : ℝ => 1 / log t) (Set.uIcc 2 t) by
      simpa [Set.uIcc_of_le ht] using log_integrand_continuous ht).intervalIntegrable
  · exact (measurable_const.div Real.measurable_log).stronglyMeasurable.stronglyMeasurableAtFilter
  · exact continuousAt_const.div (Real.continuousAt_log (by linarith))
      (ne_of_gt (log_pos_on ht))

/-- The offset-Li model contributes exactly log log, with its lower-endpoint constant. -/
theorem Li2_partial_summation (x : ℝ) (hx : 2 ≤ x) :
    Li2 x / x + (∫ t in (2:ℝ)..x, Li2 t / t^2) =
      log (log x) - log (log 2) := by
  have hlog : ContinuousOn (fun t : ℝ => 1 / log t) (Set.uIcc 2 x) := by
    simpa [Set.uIcc_of_le hx] using log_integrand_continuous hx
  have hinv : ContinuousOn (fun t : ℝ => -(1 / t^2)) (Set.uIcc 2 x) := by
    rw [Set.uIcc_of_le hx]
    exact (continuousOn_const.div (continuousOn_id.pow 2)
      (fun t ht => pow_ne_zero _ (show t ≠ 0 by linarith [ht.1]))).neg
  have hparts := intervalIntegral.integral_mul_deriv_eq_deriv_mul
    (u := Li2) (v := fun t : ℝ => 1 / t)
    (u' := fun t : ℝ => 1 / log t) (v' := fun t : ℝ => -(1 / t^2))
    (fun t ht => Li2_hasDerivAt ((Set.uIcc_of_le hx ▸ ht).1))
    (fun t ht => by
      simpa [one_div] using hasDerivAt_inv (show t ≠ 0 by
        have := (Set.uIcc_of_le hx ▸ ht).1
        linarith))
    hlog.intervalIntegrable hinv.intervalIntegrable
  have hmain : (∫ t in (2:ℝ)..x, (1 / log t) * (1 / t)) =
      log (log x) - log (log 2) := by
    apply intervalIntegral.integral_eq_sub_of_hasDerivAt
    · intro t ht
      have ht2 : 2 ≤ t := (Set.uIcc_of_le hx ▸ ht).1
      convert! (Real.hasDerivAt_log (ne_of_gt (log_pos_on ht2))).comp t
        (Real.hasDerivAt_log (show t ≠ 0 by linarith)) using 1 <;> norm_num [one_div]
    · exact (hlog.mul (by
        rw [Set.uIcc_of_le hx]
        exact continuousOn_const.div continuousOn_id (fun t ht => by linarith [ht.1]))).intervalIntegrable
  have hneg : (∫ t in (2:ℝ)..x, Li2 t * -(1 / t^2)) =
      -(∫ t in (2:ℝ)..x, Li2 t / t^2) := by
    rw [← intervalIntegral.integral_neg]
    apply intervalIntegral.integral_congr
    intro t ht
    dsimp
    ring
  rw [hmain, hneg] at hparts
  have hzero : Li2 2 = 0 := by simp [Li2]
  rw [hzero] at hparts
  simp only [div_eq_mul_inv, one_div, zero_mul, sub_zero] at *
  linarith

lemma pi_weight_integrable (x : ℝ) (hx : 2 ≤ x) :
    IntervalIntegrable (fun t => pi t / t^2) volume 2 x := by
  rw [intervalIntegrable_iff_integrableOn_Icc_of_le hx]
  have hg : IntegrableOn (fun t : ℝ => 1 / t^2) (Set.Icc 2 x) := by
    exact (continuousOn_const.div (continuousOn_id.pow 2)
      (fun t ht => pow_ne_zero _ (show t ≠ 0 by linarith [ht.1]))).integrableOn_Icc
  have h := integrableOn_mul_sum_Icc primeIndicator (m := 0) (by norm_num : (0:ℝ) ≤ 2) hg
  simp_rw [count_indicator] at h
  convert! h using 1
  ext t
  ring

lemma Li2_weight_integrable (x : ℝ) (hx : 2 ≤ x) :
    IntervalIntegrable (fun t => Li2 t / t^2) volume 2 x := by
  apply ContinuousOn.intervalIntegrable
  rw [Set.uIcc_of_le hx]
  apply ContinuousOn.div
  · intro t ht
    exact (Li2_hasDerivAt ht.1).continuousAt.continuousWithinAt
  · exact continuousOn_id.pow 2
  · intro t ht
    exact pow_ne_zero _ (show t ≠ 0 by linarith [ht.1])

/-- Exact actual-prime residual formula before passing to an improper integral. -/
theorem residual_identity (x : ℝ) (hx : 2 ≤ x) :
    primeReciprocal x - log (log x) = -log (log 2) +
      (pi x - Li2 x) / x +
      ∫ t in (2:ℝ)..x, (pi t - Li2 t) / t^2 := by
  have hp := prime_partial_summation x hx
  rw [← intervalIntegral.integral_of_le hx] at hp
  have hl := Li2_partial_summation x hx
  have hr : (∫ t in (2:ℝ)..x, (pi t - Li2 t) / t^2) =
      (∫ t in (2:ℝ)..x, pi t / t^2) - (∫ t in (2:ℝ)..x, Li2 t / t^2) := by
    simp_rw [sub_div]
    exact intervalIntegral.integral_sub (pi_weight_integrable x hx) (Li2_weight_integrable x hx)
  rw [hr, sub_div]
  linarith

/-- Multiplication of the supplied normalized estimate by its positive denominator.
No assertion about smaller arguments is included. -/
theorem raw_error_of_input {t : ℝ} (ht : 0 < t) (hlt : 0 < log t)
    (h : Epi t ≤ C * t ^ (-(1:ℝ)/8)) :
    |pi t - Li2 t| ≤ C * t ^ (-(1:ℝ)/8) * (t / log t) := by
  exact (div_le_iff₀ (div_pos ht hlt)).mp h

/-- On the entire specified ray, the boundary error is bounded directly from the
sole analytic input. Real powers use the exponent -(1:ℝ)/8. -/
theorem boundary_error_on_ray
    (hPNT : ∀ t : ℝ, exp 300 ≤ t → Epi t ≤ C * t ^ (-(1:ℝ)/8))
    {t : ℝ} (ht : exp 300 ≤ t) :
    |(pi t - Li2 t) / t| ≤ C * t ^ (-(1:ℝ)/8) / log t := by
  have htp : 0 < t := lt_of_lt_of_le (exp_pos _) ht
  have htl : 300 ≤ log t := by
    have h := Real.log_le_log (exp_pos 300) ht
    simpa using h
  have hlp : 0 < log t := by linarith
  have h := raw_error_of_input htp hlp (hPNT t ht)
  rw [abs_div, abs_of_pos htp]
  apply (div_le_iff₀ htp).mpr
  convert! h using 1 <;> ring

#print axioms prime_partial_summation
#print axioms Li2_partial_summation
#print axioms residual_identity
#print axioms boundary_error_on_ray

end
end ExposureTask
