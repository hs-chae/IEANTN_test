# Whole-function finite-data transfer

Let C=8433850764/10^12 and k=1000000/999999. Under precisely the finite-data hypotheses in the question, the envelopes proved here are

B(L) = C k · 253 L / (330(L−77))  (L≥330),

Back(L) = C k · 167 L / (330(L−163))  (300≤L≤330).

Then F(L)≤B(L) on the full future domain and F(L)≤Back(L) on the full backward interval. In particular B(L)<C for **every L≥500**; Back(L)<9347/10^6 throughout the backward interval. No restriction on n or distribution of the nonnegative weights is imposed. Empty sums are included. B is genuinely nonconstant: L/(L−77)=1+77/(L−77) is strictly decreasing for L>77, and its coefficient is positive. Its limiting value is C k·253/330, about 0.006466 (the approximation is not used).

## Derivation

Put δ=10^−6. The elementary exponential inequality exp(1)≥2 gives exp(20)≥2^20>10^6. Since (330−D)/8≥167/8>20,

0<exp(−(330−D)/8)≤δ.

For all L≥330 the same upper bound holds for exp(−(L−D)/8). All L−D, 330−D, L−77, L−160 and L−880/3 are positive on this domain. On the backward interval L−D and L−163 are positive as well.

The baseline factor satisfies

P(D,330) ≥ (1−δ)330/(330−D).

Indeed its subtracted term is at most δD/(330−D)≤δ330/(330−D). For any L>D, positivity of the exponential gives P(D,L)≤L/(L−D). For L≥330, cross multiplication of positive denominators gives

[L/(L−D)]/[330/(330−D)] ≤ 253L/[330(L−77)].

The difference after cross multiplication has the sign of (D−77)(L−330)≥0. For 300≤L≤330 the analogous maximum is at D=163, giving 167L/[330(L−163)]; its cross-product sign is (163−D)(330−L)≥0. Combine each inequality with the baseline lower bound, multiply by w_i≥0, sum, and use F(330)≤C. This proves both envelopes without estimating the total weight or assuming a weight distribution.

Each positive-d rational L/(L−d) is decreasing for L>d: cross multiplication reduces this to d(L−A)≥0 for L≥A>d. This proves ray-wise bounds, not just point evaluations. In particular B(L)≤B(500)<C on L≥500.

## Conditional actual prime-counting error result

Define, in the normalization of the question,

H(L)=(1+10^−9)[ B(L)+4·10^−6 L/(L−160)+2·10^−8
                    +10^−12 L/(L−880/3)+2·10^−12 ]+10^−12+10^−8.

Assume the supplied generic consumer for all L≥330, with the actual Epi defined from Nat.primeCounting and the integral Li2. Then

**Epi(exp L) ≤ H(L) exp(−L/8), for every L≥330.**

This follows by substituting the full envelope in the consumer and dividing by the positive exp(L/8). H is decreasing on this whole domain, by the rational comparison just proved. Exact rational arithmetic at the left endpoints therefore proves the following strict whole-ray checkpoints:

| Entire domain | Strict upper bound for Epi(exp L) |
|---|---|
| L≥500 | (7649/10^6) exp(−L/8) |
| L≥1000 | (7011/10^6) exp(−L/8) |
| L≥2000 | (6730/10^6) exp(−L/8) |
| L≥10000 | (6521/10^6) exp(−L/8) |

These use no consumer below 330. The backward result is only about F; it does not establish an Epi bound on 300≤L<330.

## Sources, verification and limitations

`Envelope.lean` is self-contained proof source importing only Mathlib. It repeats the exact task definitions within a `noncomputable section` (needed for the real-valued finiteCap definition) and gives the finite sum, explicit envelopes, consumer proposition, complete transfer proofs and actual-Epi ray checkpoints. `TaskDefinitions.lean` is the unmodified input for reference, not a separate imported module. Principal results: `future_envelope`, `backward_envelope`, `strict_improvement`, `actual_Epi_envelope`, `actual_checkpoints`, `Back_uniform`. `denominators` certifies the future denominators.

No QRH, zero-density theorem, or upstream justification of the consumer is claimed. The only mathematical premises in the transfer theorems are the stated finite input and slope/weight conditions, plus the explicit consumer for the Epi results. The conservative exponential loss k is intentional; no optimality is claimed. This is ordinary Lean kernel proof, **not source-first program verification**: there is no executable source-to-semantics bridge or verified numerical data-generation pipeline. The given finite cap is an input, not an experimental conclusion.

See compile.log and verification.txt for the final compiler command, diagnostics, exit status and axiom audit. No unfinished proof is intended in the final accepted compile. Standard Lean/Mathlib foundations (propext, Classical.choice, Quot.sound) are not additional analytic hypotheses. Any supporting numerical output is exploratory and is not substituted for a kernel theorem.
