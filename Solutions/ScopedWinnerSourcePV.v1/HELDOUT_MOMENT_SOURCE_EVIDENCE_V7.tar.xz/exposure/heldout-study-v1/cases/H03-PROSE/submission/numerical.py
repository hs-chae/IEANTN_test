from fractions import Fraction as Q
# Exploratory display only; Lean norm_num proves the rational checkpoint inequalities.
C = Q(8433850764, 10**12)
k = Q(1000000, 999999)
for L in [330, 500, 1000, 2000, 10000]:
    b = C*k*Q(253*L, 330*(L-77))
    h = (1+Q(1,10**9))*(b + Q(4,10**6)*Q(L,L-160)
        + Q(2,10**8) + Q(1,10**12)*Q(L,Q(L)-Q(880,3))
        + Q(2,10**12)) + Q(1,10**12) + Q(1,10**8)
    print(f"L={L}: B≈{float(b):.16g}; H≈{float(h):.16g}")
    print("  exact B =", b)
    print("  exact H =", h)
back300 = C*k*Q(167*300,330*137)
print("Back(300) exact =", back300, "; approximate =", float(back300))
print("B limit exact =", C*k*Q(253,330), "; approximate =", float(C*k*Q(253,330)))
