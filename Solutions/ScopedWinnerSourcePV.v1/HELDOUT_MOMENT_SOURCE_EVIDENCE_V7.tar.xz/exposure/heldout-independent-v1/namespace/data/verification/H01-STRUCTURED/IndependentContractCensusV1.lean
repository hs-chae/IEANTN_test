import TaskDefinitions
import Formal
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxHeartbeats 0
set_option maxRecDepth 100000
run_elab do
 let env ← getEnv
 let owned : List Name := [Name.mkSimple "TaskDefinitions",Name.mkSimple "Formal"]
 for (name, info) in env.constants.toList do
  if let some idx := env.getModuleIdxFor? name then
   let moduleName := env.header.moduleNames[idx]!
   if owned.contains moduleName then
    let ax ← Lean.collectAxioms name
    let kind := if info.isTheorem then "theorem" else if info.isAxiom then "axiom" else "definition-or-generated"
    logInfo m!"HELDOUT_DECL {(Json.mkObj [("name",toJson name.toString),("module",toJson moduleName.toString),("kind",toJson kind),("type",toJson (toString info.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"
