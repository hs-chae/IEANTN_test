# Reproduce the six-session checks and two poststudy ANT consumers

The six generative research sessions are historical sealed evidence. Their task/format
content, lock times, exact budgets, scheduling/paired seeds, prompts, final sources and
metrics are preserved. Provider sampling randomness was not controlled, so a new model
call cannot be promised to reproduce the same discoveries or token counts. Independent
Lean compilation and the resulting mathematical theorems are reproducible without any
new generative call. Original scores, including H01-STRUCTURED formal partial, stay fixed.

## Clean public environment

Start from source-poststudy-ant-capsule-v3/base/README.md. Its included bootstrap pins
Lean4.34.0-rc2 commit6a10ac8c22beadecabdbb0919c2b50214762f91d and eight public generic
library commits (Mathlib71a80585ee495fc24472fd0eaffc89d94e4fd8d6). Use Linux x86-64,
Python3, Git, tar/zstd, ordinary C headers and Boost. Public generic library objects are
allowed only at the pinned identities; historical application objects are forbidden.
No private account credentials or research-source checkout is required to check proofs.

## Six original mathematical submissions

From the evidence-bundle root, run:

    python3 exposure/scripts/reproduce_heldout_proofs_v1.py \
      --input exposure/heldout-verification-input-v1 \
      --environment /absolute/new/public-environment.json \
      --out /absolute/new/six-case-proof-check

The portable adapter uses the exact preserved independent namespace verifier, changing
only its input/output/environment path bindings and its explicit host/isolation label.
It never repairs a candidate source or imports an application proof cache. Each case
gets a fresh bank and complete own-declaration type/axiom census. Intentionally retained
original diagnostic stubs still fail; the actual proof chains and genuine H01 structured
unfinished target remain distinguished. Successful compiler closures are not themselves
a source-contract audit or a new source-first PV result.

The portable replay recipe's input identities have been checked; its fresh full execution
is separately pending. The accepted original independently isolated run and exact logs
remain in heldout-independent-v1. Do not infer namespace isolation from an ordinary host
run. The original runner files document the previously exercised namespace procedure.
All original candidate source bytes and their sealed locks are preserved.

The exact first-pass source scope is all172written `(file,line,name)` identities in13Lean
files, including private helpers and archived stubs. `ALL_WRITTEN_LEDGER_V1.csv` has149
internal checks and23checked pinned formal-library supports. The independent source
second pass covers10selectedH02identities, not the whole172. No original-paper/full-network
source-audit completion claim is made. The skill's final gate is:

    python3 /path/to/lean-source-math-audit/scripts/validate_ledger.py \
      --scope exposure/heldout-audit-v1/ALL_WRITTEN_SCOPE.csv \
      --ledger exposure/heldout-audit-v1/ALL_WRITTEN_LEDGER_V1.csv --require-final

## Actual C-source consumers

Use `research/source-poststudy-ant-capsule-v3/reproduce.py` and its README. The clean route
regenerates the exact numerical data, compiles/runs the unchanged actual C main, regenerates
its observed-output Lean source and builds the4057-source base from an empty application
bank. It then builds the ten source300modules and two separate original-candidate/consumer
branches (4076distinct written source files). Every existing base source/command/object/log,
all12234complete raw root audits, actual numerical/C outputs and observed footer are checked
before and after a chained continuation. Source, model, algorithm and14analyticinputs are
unchanged. The same physical final read genuinely supplies the pi/psi premises.

The warm five-module/eleven-root composition passed. The complete new cold isolated
continuation is separately pending. The two new consumers are the actual-prime reciprocal
limit/tail and psi-to-theta bounds; three theta output forms are not three discoveries.
The C program computes the finite spectral budget, not the reciprocal limiting constant.

## Strongest strengthened posthoc kernel-only comparator

Use `research/pure-poststudy-fullfresh-capsule-v3/reproduce.py` and its README. It executes
all five unchanged C proposal generators in normal/-O/-OO modes (15runs), exact-word checks,
full fresh471→473→482 mathematical builds, then the original two mathematical consumers in
separate banks. These489source files import no C execution proof graph. This is kernel-only
verification, never source-first PV. The original full run failed at a generated wrapper after its482-source parent
passed; a corrected seven-source continuation has actually passed with169present typed
Std3rootchecks. It is resumed/chained, not uninterruptedfull489; the V3clean recipe is
separately corrected and no new full no-resume execution is inferred. Previously accepted473source mathematical evidence remains unchanged.

The later pure checkpoint includes numerical facts newly generated during this campaign;
those costs remain charged. It is not original initial-evidence P0 or a free analytical gift.
No coefficient advantage or causal necessity of source-first PV is claimed.

## Resources, trust and storage

Use actual separate RAM/disk capacity and an external resource scope. The existing host
has an aggregate300GiB/64CPU policy; a large full-base run uses256GiB, the pure full-fresh
comparison24GiB and small development scopes are coordinated. There is no obsolete4GiB
cap. Keep adequate host reserve. Exact aggregate memory.peak was unavailable; published
sampled charged RAM is a lower bound, compiler RSS is a single-child measure, and retained
directory bytes are not peak physical disk usage. All observed OOM counters and failures
remain visible.

The accepted source-first boundary retains pinned Lean kernel/public generic libraries,
compiler/core runtime, source binding, documented C ABI, ordinary stdio/OS contracts and
hardware. Modeled successful stdio is not universal actual-I/O success. The final128physical
bytes were separately Lean-compared; the full98432byte run is retained by hash. Neither the
six mathematical workers nor ordinary kernel-only proofs establish executable correctness.
The separate8192/16384 Scoped Winner source-body migration remains incomplete.

All exact sources, parameters, commands, dependency versions/commits, small raw numerical
outputs, receipts, hashes and accepted proof artifacts are retained. Only fresh generators'
own hash-identified regenerable binaries are removed after exact checks. No large essential
data is omitted, no accepted proof artifact is deleted, and unrelated workspaces are never
cleanup targets. Pending recipes and actual completed results are clearly separated.

Core-network node registration and complete14-input provider mapping remain pending.
The accepted two mathematical applications currently exist as actual conditional proof
modules and separate per-node banks; no automatic metadata/whole-network update is claimed.
