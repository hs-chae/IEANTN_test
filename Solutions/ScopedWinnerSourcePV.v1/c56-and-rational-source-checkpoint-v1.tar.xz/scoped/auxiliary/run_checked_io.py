"""Actual compiled-source run and external readback, explicitly not PV."""
import argparse, hashlib, json, os, re, subprocess, time
from fractions import Fraction
from pathlib import Path

def need(v, m):
    if not v:
        raise ValueError(m)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source-root', type=Path, required=True)
    ap.add_argument('--toolchain', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--reference-first52', type=Path, required=True)
    ap.add_argument('--reference-aux4', type=Path, required=True)
    a = ap.parse_args()
    B, T, out = a.source_root.resolve(), a.toolchain.resolve(), a.out.resolve()
    need(not out.exists() and B not in out.parents, 'fresh output outside source')
    d = json.loads((B/'PREPARATION.json').read_text())
    need(d['original_rows'] == 52 and d['sensitivity_rows'] == 4 and len(d['records']) == 56, 'exact input universe')
    pins = {str(B/r['path']):r['sha256'] for r in d['source_files']}
    for p in [Path(__file__).resolve(), B/'PREPARATION.json', T/'bin/clang', T/'lib/lean/libleanshared.so', T/'include/lean/lean.h', T/'include/lean/config.h', a.reference_first52.resolve(), a.reference_aux4.resolve()]:
        pins[str(p)] = sha(p)
    need(all(sha(Path(p)) == h for p,h in pins.items()), 'source pin mismatch')
    out.mkdir(parents=True)
    common = [str(T/'bin/clang'), '-std=c++17', '-O2', '-I'+str(T/'include'),
              '-isystem', '/usr/include/c++/11', '-isystem', '/usr/include/x86_64-linux-gnu/c++/11',
              '-isystem', '/usr/lib/gcc/x86_64-linux-gnu/11/include']
    link = ['-L'+str(T/'lib/lean'), '-lleanshared', '-Wl,-rpath,'+str(T/'lib/lean')]
    binary = out/'scoped_all'
    start = time.monotonic()
    steps = []
    def run(role, cmd, stdout=None, expected=0):
        so, se, metrics = out/(role+'.stdout'), out/(role+'.stderr'), out/(role+'.time')
        t = time.monotonic()
        with (so if stdout is None else stdout).open('wb') as f, se.open('wb') as e:
            q = subprocess.run(['/usr/bin/time','-v','-o',str(metrics),*cmd], stdout=f, stderr=e)
        need(q.returncode == expected, role+' unexpected exit '+str(q.returncode))
        peak = re.search(r'Maximum resident set size \(kbytes\): (\d+)', metrics.read_text())
        steps.append(dict(role=role, command=cmd, exit_code=q.returncode, seconds=time.monotonic()-t,
                          peak_rss_bytes=int(peak[1])*1024 if peak else None,
                          stderr_sha256=sha(se), stdout_sha256=sha(so) if stdout is None else None,
                          qualification='Actual host execution; not source correctness proof.'))
    run('build', [*common,str(B/'source/scoped_all_bundle.cpp'),*link,'-o',str(binary)])
    # Test actual changed printing code against a failing output device before
    # the long numerical run. This is a regression check, not a formal I/O proof.
    probe = out/'io_probe.cpp'
    probe.write_text('#define main preserved_application_main\n#include '+json.dumps(str(B/'source/scoped_all_bundle.cpp'))+'\n#undef main\nint main(){lean_initialize_runtime_module();printI(izero());if(fflush(stdout)!=0)fail();return 0;}\n')
    run('probe-build', [*common,str(probe),*link,'-o',str(out/'io_probe')])
    run('probe-ok', [str(out/'io_probe')])
    need((out/'probe-ok.stdout').read_bytes() == b'0,-100,0,-100,1\n', 'printing format regression')
    run('probe-full-device', [str(out/'io_probe')], Path('/dev/full'), 3)
    run('numerical', [str(binary)])
    data = (out/'numerical.stdout').read_bytes()
    lines = data.decode('ascii').splitlines(keepends=True)
    need(len(lines) == 56, 'output population')
    checks = []
    for i,(line,r) in enumerate(zip(lines,d['records'])):
        need(re.fullmatch(r'-?\d+,-100,-?\d+,-100,1\n',line) is not None, 'strict output syntax')
        lo,le,hi,he,ok = map(int,line.split(','))
        need(lo <= hi and le == he == -100 and ok == 1, 'ordered valid interval')
        bound = Fraction(*map(int,r['bound']))
        good = Fraction(hi,2**100) <= bound if r['direction'] == 'upper' else bound <= Fraction(lo,2**100)
        need(good, 'external exact readback failed row '+str(i))
        checks.append(dict(row=i, native_fact=r['native_fact'], row_index=r['row_index'], lo=str(lo), hi=str(hi), passed=True))
    first = ''.join(lines[:52]).encode('ascii')
    aux = ''.join(lines[52:]).encode('ascii')
    need(first == a.reference_first52.read_bytes(), 'original52 numerical bytes changed')
    need(aux == a.reference_aux4.read_bytes(), 'original4 sensitivity numerical bytes changed')
    need(all(sha(Path(p)) == h for p,h in pins.items()), 'source/runtime changed during execution')
    receipt = dict(status='PASS_ACTUAL_CHECKED_IO_C56_RAW_NOT_PV', seconds=time.monotonic()-start,
                   rows=56, unchanged_original_rows=52, unchanged_sensitivity_rows=4, steps=steps,
                   pins=pins, output_sha256=hashlib.sha256(data).hexdigest(), external_row_checks=checks,
                   source_first_PV=False, qualification='Actual C56 run, exact external readback, byte-identical original numerical outputs and real /dev/full rejection. Complete application-body, arithmetic/math, whole-source binding, I/O execution and theorem-provider proofs remain mandatory.')
    (out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ['status','seconds','rows','source_first_PV']}))

if __name__ == '__main__':
    main()
