# Copyright (c) 2026 IEANTN contributors. Apache-2.0.
# Additional ORIGINAL sensitivity CLI inputs; no evaluated outputs embedded.
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent;R=B.parents[1];src=R/'scoped/numerical/source/scoped_eval.cpp';core=src.read_text().split('#include "height_input.inc"',1)[0];d=json.loads((B/'INPUTS_V1.json').read_text());code=[core];records=[]
for i,item in enumerate(d['records']):
 if len(item['program'])!=1:raise ValueError('single originalcoefficientrowrequired')
 row=item['program'][0];nodes=[];seen={}
 def walk(e):
  key=json.dumps(e,separators=(',',':'))
  if key in seen:return seen[key]
  op=e[0];a=b=0;n=den='0'
  if op=='const':tag=0;n,den=e[1:]
  elif op=='var':tag=1;a=e[1]
  elif op in ['add','mul']:tag=2 if op=='add'else 3;a=walk(e[1]);b=walk(e[2])
  elif op in ['neg','inv','exp','log']:tag={'neg':4,'inv':5,'exp':6,'log':7}[op];a=walk(e[1])
  elif op=='namedConst':
   tag=8
   if e[1]=='LeanCert.Core.MathConst.pi':a=0
   elif e[1]=='LeanCert.Core.MathConst.eulerMascheroni':a=1
   else:raise ValueError('unsupportednamedconstant')
  else:raise ValueError('unsupportedExpr')
  out=len(nodes);nodes.append([tag,a,b,n,den]);seen[key]=out;return out
 root=walk(row['body'])
 if root!=len(nodes)-1 or row['cells']!=1:raise ValueError('sensitivityshapechanged')
 name='sensitivity'+str(i);code.append('static const Node '+name+'[]={\n'+''.join(' {'+','.join([str(t),str(a),str(b),json.dumps(n),json.dumps(den)])+'},\n'for t,a,b,n,den in nodes)+'};');records.append(dict(name=name,beta=item['beta'],nodes=nodes,cells=1,bound=[item['bound_num'],item['bound_den']],direction='upper',taylor_depth=24))
code.append('static const Row auxRows[]={'+','.join('{'+x['name']+','+str(len(x['nodes']))+',1}'for x in records)+'};');code.append('int main(void){lean_initialize_runtime_module();prepare(24);unsigned mark=poolTop;for(unsigned i=0;i<4;i=i+1){I result=runRow(auxRows[i],mark,0);printI(result);clearTo(mark);lean_dec(result.lo.mag);lean_dec(result.hi.mag);}clearTo(0);return 0;}');p=B/'source_aux.cpp'
if p.exists():raise ValueError('immutableauxsourceexists')
p.write_text('\n'.join(code)+'\n');(B/'SERIALIZATION_V1.json').write_text(json.dumps(dict(status='UNTRUSTED_ORIGINAL4_SENSITIVITY_INPUTS_ONLY',records=records,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),computed_output_table=False),indent=2)+'\n');print('PreparedactualC4rows; fixedoriginalβ/L=240/bounds.')
