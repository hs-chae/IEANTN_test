"""Additive checked-I/O source variant; preparation is not a PV proof.

All 65 non-I/O function bodies and the 52 original numerical inputs remain
byte-identical. Four original sensitivity inputs are appended, never substituted.
"""
import copy, hashlib, importlib.util, json, os, shutil
from pathlib import Path

B = Path(__file__).resolve().parent
R = B.parents[1]
OUT = R / 'scoped/checked-io-v1'
OLD = R / 'scoped/source-bundle'

def need(v, m):
    if not v:
        raise ValueError(m)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    need(not OUT.exists(), 'fresh checked-I/O variant required')
    spec = importlib.util.spec_from_file_location('source_renderer', R / 'scoped/frontend/generate_ast.py')
    g = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g)
    shutil.copytree(OLD / 'source', OUT / 'source')
    source = OUT / 'source'
    functions = copy.deepcopy(json.loads((R / 'scoped/frontend/generated-epoch2/AST.json').read_text())['functions'])
    changed = []
    def checked_statements(s):
        if s[0] == 'eval' and s[1][0] == 'call' and s[1][1] in [['var', 'putchar'], ['var', 'printf']]:
            return ['branch', ['binary', '<', s[1], ['nat', 0]],
                    ['eval', ['call', ['var', 'fail'], []]], ['skip']]
        if s[0] == 'sequence':
            return ['sequence', [checked_statements(x) for x in s[1]]]
        if s[0] == 'branch':
            return ['branch', s[1], checked_statements(s[2]), checked_statements(s[3])]
        if s[0] == 'whileLoop':
            return ['whileLoop', s[1], checked_statements(s[2])]
        return s
    for f in functions:
        if f['name'] in ['printS', 'printI']:
            f['body'] = checked_statements(f['body'])
            changed.append(f)
    # Whole-row main is constructed from the original main structure; the
    # arithmetic evaluator, row order and 8192/16384 cell counts are unchanged.
    call = lambda name, args: ['eval', ['call', ['var', name], args]]
    var = lambda name: ['var', name]
    nat = lambda n: ['nat', n]
    decl = lambda t, n, e: ['declare', [dict(type=t, name=n, value=e, arrayExtent=None)]]
    rowbody = ['sequence', [
        call('prepare', [['index', var('allDepths'), var('j')]]),
        decl('unsigned int', 'mark', var('poolTop')),
        decl('I', 'result', ['call', var('runRow'), [['index', var('allRows'), var('j')], var('mark'), nat(0)]]),
        call('printI', [var('result')]), call('clearTo', [var('mark')]),
        call('lean_dec', [['field', '.', ['field', '.', var('result'), 'lo'], 'mag']]),
        call('lean_dec', [['field', '.', ['field', '.', var('result'), 'hi'], 'mag']]),
        call('clearTo', [nat(0)])]]
    mainf = dict(name='main', returnType='int', parameters=[], body=['sequence', [
        call('lean_initialize_runtime_module', []),
        ['forLoop', decl('unsigned int', 'j', nat(0)), ['binary', '<', var('j'), nat(56)],
         ['binary', '=', var('j'), ['binary', '+', var('j'), nat(1)]], rowbody],
        ['branch', ['binary', '!=', ['call', var('fflush'), [var('stdout')]], nat(0)], call('fail', []), ['skip']],
        call('fprintf', [var('stderr'), ['stringLiteral', 'poolHigh=%u\n'], var('poolHigh')]),
        ['returnStmt', nat(0)]]])
    functions[-1] = mainf
    changed.append(mainf)
    need(len(functions) == 68, 'function population')
    for i, f in enumerate(functions):
        if f['name'] not in ['printS', 'printI', 'main']:
            continue
        text = f['returnType'] + ' ' + f['name'] + '(' + ','.join(t+' '+n for t,n in f['parameters']) + ')' + g.cs(f['body']) + '\n'
        (source / ('function_%02d_%s.inc' % (i, f['name']))).write_text(text)
    oldrecords = json.loads((R / 'scoped/numerical/ALL50_INPUT_SERIALIZATION_V1.json').read_text())['records']
    aux = json.loads((B / 'SERIALIZATION_V1.json').read_text())['records']
    for r in aux:
        text = 'static const Node ' + r['name'] + '[' + str(len(r['nodes'])) + ']={'
        text += ','.join('{'+','.join([str(n[0])+'u', str(n[1])+'u', str(n[2])+'u', json.dumps(str(n[3])), json.dumps(str(n[4]))])+'}' for n in r['nodes'])
        (source / (r['name'] + '_array.inc')).write_text(text + '};\n')
    rows = [(r['name'], r['nodes'], r['cells']) for r in oldrecords] + [(r['name'], len(r['nodes']), 1) for r in aux]
    depths = [r['taylor_depth'] for r in oldrecords] + [24]*4
    (source / 'allRows_array.inc').write_text('static const Row allRows[56]={' + ','.join('{'+n+','+str(c)+'u,'+str(k)+'u}' for n,c,k in rows) + '};\n')
    (source / 'allDepths_array.inc').write_text('static const unsigned allDepths[56]={' + ','.join(str(k)+'u' for k in depths) + '};\n')
    prep = json.loads((OLD / 'PREPARATION.json').read_text())
    def leaves(t):
        return [t['file']] if t['kind'] == 'leaf' else leaves(t['left']) + leaves(t['right'])
    tops = leaves(prep['root'])
    i = tops.index('allRows_array.inc')
    tops[i:i] = [r['name']+'_array.inc' for r in aux]
    count = 0
    def tree(items):
        nonlocal count
        if len(items) == 1:
            return items[0]
        half = len(items)//2
        a, b = tree(items[:half]), tree(items[half:])
        name = 'checked_translation_%03d.inc' % count
        count += 1
        (source / name).write_text('#include "'+a+'"\n#include "'+b+'"\n')
        return name
    root = tree(tops)
    (source / 'scoped_all_bundle.cpp').write_text('#include "'+root+'"\n')
    p = OUT / 'lean/ScopedCheckedIO/Bindings.lean'
    p.parent.mkdir(parents=True)
    lines = ['import ScopedC.GeneratedAll', 'namespace ScopedCheckedIO', 'open ScopedC.Syntax',
             'set_option maxHeartbeats 0', 'set_option maxRecDepth 200000']
    for f in changed:
        name = f['name']
        i = next(i for i,x in enumerate(functions) if x['name'] == name)
        params = '['+','.join('('+g.quote(t)+','+g.quote(n)+')' for t,n in f['parameters'])+']'
        path = source / ('function_%02d_%s.inc' % (i, name))
        lines += ['def f_'+name+' : Function := {returnType:='+g.quote(f['returnType'])+',name:='+g.quote(name)+',parameters:='+params+',body:='+g.ls(f['body'])+'}',
                  'def actual_'+name+' : String := include_str '+g.quote(os.path.relpath(path,p.parent)),
                  'theorem bound_'+name+' : renderFunction f_'+name+' = some actual_'+name+' := by decide +kernel']
    lines += ['def functions : List Function := ScopedC.Generated.functions.take 64 ++ [f_printS,f_printI,ScopedC.Generated.f_runRow,f_main]',
              'theorem arithmetic_bodies_unchanged : functions.take 64 = ScopedC.Generated.functions.take 64 := by rfl',
              'theorem runRow_body_unchanged : functions[66]? = some ScopedC.Generated.f_runRow := by rfl', 'end ScopedCheckedIO']
    p.write_text('\n'.join(lines)+'\n')
    records = oldrecords + [dict(r, native_fact='ScopedWinnerA.Sensitivity.checked', row_index=i) for i,r in enumerate(aux)]
    files = [dict(path=str(p.relative_to(OUT)), sha256=sha(p), bytes=p.stat().st_size) for p in sorted(source.iterdir())]
    report = dict(status='PREPARED_ADDITIVE_CHECKED_IO_VARIANT_NOT_PV', original_rows=52, sensitivity_rows=4,
                  functions=68, changed_bodies=['printS','printI','main'], retained_arithmetic_bodies=65,
                  algorithms='Original exact-dyadic arithmetic and 8192/16384 grids unchanged; check output errors and flush before success.',
                  source_files=files, records=records, ast_functions=functions,
                  pending=['Compile actual C and new leaf bindings', 'Bind four additional input arrays and whole include tree',
                           'Prove complete source arithmetic/loop/initialization/I/O execution and ANT output consumption'])
    (OUT / 'PREPARATION.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['status','original_rows','sensitivity_rows','functions','changed_bodies','retained_arithmetic_bodies']}))

if __name__ == '__main__':
    main()
