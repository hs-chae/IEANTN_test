"""Untrusted preparation of compositional actual-source binding obligations."""
import hashlib, json, os, re
from pathlib import Path

B = Path(__file__).resolve().parent
R = B.parents[1]
C = R/'scoped/checked-io-v1'
OLD = R/'scoped/source-bundle'

def q(s):
    return json.dumps(s,ensure_ascii=False)

def main():
    out = C/'lean/ScopedCheckedIO'
    p = out/'Whole.lean'
    cp = out/'CopiedFiles.lean'
    if p.exists() or cp.exists():
        raise ValueError('fresh generated obligations required')
    pre = ['/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/',
           'import ScopedC.SourceBundle.Whole','import ScopedCheckedIO.Bindings',
           'import ScopedAux.SourceInputs','namespace ScopedCheckedIO.Bundle',
           'open ScopedC.Syntax ScopedC.SourceBundle',
           'set_option maxHeartbeats 0','set_option maxRecDepth 200000']
    copied = [*pre]
    copies = []
    for original in sorted((OLD/'source').iterdir()):
        actual = C/'source'/original.name
        if actual.read_bytes() != original.read_bytes():
            continue
        i = len(copies)
        copied += ['theorem copied'+str(i)+' : (include_str '+q(os.path.relpath(actual,cp.parent))+') = (include_str '+q(os.path.relpath(original,cp.parent))+') := by rfl']
        copies.append(original.name)
    copied += ['end ScopedCheckedIO.Bundle']
    cp.write_text('\n'.join(copied)+'\n')
    lines = [*pre]
    # The direct-array form uses exactly the same typed Decl/renderer and
    # execution model. It changes only source organization: a complete small
    # initializer instead of an initializer assembled from include fragments.
    lines += ['inductive Atom where', '  | prior (p : Piece)', '  | directArray (d : Decl)',
              'def Atom.Bound : Atom → File → Prop',
              '  | .prior v,f => Piece.Bound v f',
              '  | .directArray d,f => (do pure ((←renderDecl d)++";\\n")) = some f.text',
              'def Atom.functions : Atom → List Function',
              '  | .prior p => p.functions', '  | .directArray _ => []',
              'def Atom.globals : Atom → List Decl',
              '  | .prior p => p.globals', '  | .directArray d => [d]',
              'def Atom.types : Atom → List ScopedC.Header.TypeDecl',
              '  | .prior p => p.types', '  | .directArray _ => []']
    oldprep = json.loads((OLD/'PREPARATION.json').read_text())
    leaves = {x['name']:x for x in oldprep['leaves'] if x['kind'] in ['prelude','type','global','function','array','row_array','depth_array']}
    headernames = [x['name'] for x in oldprep['leaves'] if x['kind'] in ['prelude','type','global']]
    aux = json.loads((B/'SERIALIZATION_V1.json').read_text())['records']
    auxnames = {r['name']+'_array.inc':i for i,r in enumerate(aux)}
    records = json.loads((R/'scoped/numerical/ALL50_INPUT_SERIALIZATION_V1.json').read_text())['records']
    rowvals = [(r['name'],r['nodes'],r['cells']) for r in records] + [(r['name'],len(r['nodes']),1) for r in aux]
    rows = '['+','.join('('+q(n)+','+str(c)+','+str(k)+')' for n,c,k in rowvals)+']'
    depths = '['+','.join(str(r['taylor_depth']) for r in records)+',24,24,24,24]'
    lines += ['def rows : Decl := ScopedC.CData.rowArray '+rows,
              'def depths : Decl := ScopedC.CData.depthArray '+depths]
    li = ji = 0
    def build(name):
        nonlocal li,ji,lines
        file = C/'source'/name
        if name in leaves or name in auxnames:
            i = li
            li += 1
            stem = 'leaf'+str(i)
            lines.append('def '+stem+'File : File := ⟨'+q(name)+',include_str '+q(os.path.relpath(file,p.parent))+'⟩')
            if name in auxnames:
                k = auxnames[name]
                piece = '.directArray (ScopedC.CData.nodeArray '+q(aux[k]['name'])+' ScopedAux.SourceInputs.nodes'+str(k)+')'
                proof = 'by change ScopedC.CData.renderArray '+q(aux[k]['name'])+' ScopedAux.SourceInputs.nodes'+str(k)+' = some ScopedAux.SourceInputs.actual'+str(k)+'; exact ScopedAux.SourceInputs.source'+str(k)
            else:
                a = leaves[name]
                kind = a['kind']
                if kind in ['prelude','type','global']:
                    ns = 'ScopedC.SourceBundle.Headers'
                    k = headernames.index(name)
                    piece = '.prior '+ns+'.piece'+str(k)
                    proof = ns+'.bound'+str(k)
                elif kind == 'array':
                    ns = 'ScopedC.SourceBundle.Arrays.Fact'+str(a['fact_index'])+'Row'+str(a['row_index'])
                    piece = '.prior '+ns+'.piece'
                    proof = ns+'.bound'
                elif kind in ['row_array','depth_array']:
                    piece = '.directArray '+('rows' if kind == 'row_array' else 'depths')
                    proof = 'by unfold Atom.Bound '+stem+'Atom '+stem+'File; decide +kernel'
                else:
                    k = a['index']
                    if a['function'] in ['printS','printI','main']:
                        piece = '.prior (.function ScopedCheckedIO.f_'+a['function']+')'
                        proof = 'Piece.Bound.function ScopedCheckedIO.bound_'+a['function']
                    else:
                        piece = '.prior ScopedC.SourceBundle.Functions.piece'+str(k)
                        proof = 'ScopedC.SourceBundle.Functions.bound'+str(k)
            lines += ['def '+stem+'Atom : Atom := '+piece,
                      'def '+stem+' : ScopedC.SourceBundle.Tree Atom := .leaf '+stem+'File '+stem+'Atom',
                      'theorem '+stem+'Bound : '+stem+'.Bound Atom.Bound := .leaf (by exact '+proof+')']
            return stem,stem+'Bound'
        children = re.fullmatch(r'#include "([^"\n]+)"\n#include "([^"\n]+)"\n',file.read_text())
        if children is None:
            raise ValueError('unexpected include syntax '+name)
        a,ap = build(children[1])
        b,bp = build(children[2])
        i = ji
        ji += 1
        stem = 'join'+str(i)
        lines += ['def '+stem+'File : File := ⟨'+q(name)+',include_str '+q(os.path.relpath(file,p.parent))+'⟩',
                  'def '+stem+' : ScopedC.SourceBundle.Tree Atom := .pair '+stem+'File '+a+' '+b,
                  'theorem '+stem+'Bound : '+stem+'.Bound Atom.Bound := .pair '+ap+' '+bp+' (by decide +kernel)']
        return stem,stem+'Bound'
    entry = C/'source/scoped_all_bundle.cpp'
    root = re.fullmatch(r'#include "([^"\n]+)"\n',entry.read_text())
    if root is None:
        raise ValueError('entry exact directive')
    tr,bp = build(root[1])
    lines += ['def tree : ScopedC.SourceBundle.Tree Atom := '+tr,
              'theorem bound : tree.Bound Atom.Bound := '+bp,
              'def code : List Function := tree.values.flatMap Atom.functions',
              'def globals : List Decl := tree.values.flatMap Atom.globals',
              'def types : List ScopedC.Header.TypeDecl := tree.values.flatMap Atom.types',
              'theorem functions_exact : code = ScopedCheckedIO.functions := by rfl',
              'theorem types_exact : types = ScopedC.Header.typeDeclarations := by rfl']
    ds = ['ScopedC.CData.nodeArray '+q(r['name'])+' ScopedNumerical.InputData.Fact'+str(r['fact_index'])+'Row'+str(r['row_index'])+'.nodes' for r in records]
    ds += ['ScopedC.CData.nodeArray '+q(r['name'])+' ScopedAux.SourceInputs.nodes'+str(i) for i,r in enumerate(aux)]
    ds += ['rows','depths']
    lines += ['theorem globals_exact : globals = ScopedC.Header.globals ++ ['+','.join(ds)+'] := by rfl',
              'def entry : File := ⟨"scoped_all_bundle.cpp",include_str '+q(os.path.relpath(entry,p.parent))+'⟩',
              'theorem entry_exact : entry.text = directive tree.file.name := by decide +kernel',
              'end ScopedCheckedIO.Bundle']
    p.write_text('\n'.join(lines)+'\n')
    d = dict(status='PREPARED_SOURCE_AST_OBLIGATIONS_NOT_PROVED', copied_files=len(copies), top_pieces=li, joins=ji,
             obligations=[str(x.relative_to(C)) for x in [p,cp]], qualification='Source binding only; full execution/math/consumer proof remains separate.')
    (C/'WHOLE_PREPARATION.json').write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps(d))

if __name__ == '__main__':
    main()
