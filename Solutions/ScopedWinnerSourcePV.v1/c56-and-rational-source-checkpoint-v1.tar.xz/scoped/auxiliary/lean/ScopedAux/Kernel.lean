/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import WinnerBetaA.Numerical

/- This is a kernel-only numerical fact, not source-first program verification.
   The exact original four sensitivity inputs and algorithm are unchanged.
   It deliberately does not import the owning Sensitivity module. -/
namespace ScopedAux.Kernel
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem original_four_sensitivity_checks :
    ([(7/8,19026839/10000000000),(9/10,13343142/10000000000),
      (15/16,6682697/10000000000),(31/32,2842002/10000000000)] :
      List (ℚ × ℚ)).all (fun z => WinnerBetaA.Numerical.check z.1 240 z.2) = true := by
  decide +kernel

end ScopedAux.Kernel
