/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CData
import WinnerBetaA.Numerical
namespace ScopedAux.SourceInputs
open ScopedNumerical.Input
set_option maxHeartbeats 0
set_option maxRecDepth 200000
def nodes0 : List Node := [⟨(0),(0),(0),(500001),(1000000)⟩,⟨(0),(0),(0),(1),(1)⟩,⟨(0),(0),(0),(7),(8)⟩,⟨(4),(2),(0),(0),(0)⟩,⟨(2),(1),(3),(0),(0)⟩,⟨(3),(4),(1),(0),(0)⟩,⟨(3),(4),(5),(0),(0)⟩,⟨(0),(0),(0),(2),(1)⟩,⟨(8),(0),(0),(0),(0)⟩,⟨(3),(7),(8),(0),(0)⟩,⟨(5),(9),(0),(0),(0)⟩,⟨(3),(6),(10),(0),(0)⟩,⟨(5),(8),(0),(0),(0)⟩,⟨(2),(7),(12),(0),(0)⟩,⟨(3),(13),(4),(0),(0)⟩,⟨(0),(0),(0),(240),(1)⟩,⟨(5),(15),(0),(0),(0)⟩,⟨(3),(14),(16),(0),(0)⟩,⟨(2),(11),(17),(0),(0)⟩,⟨(3),(0),(18),(0),(0)⟩,⟨(0),(0),(0),(16),(5)⟩,⟨(3),(15),(1),(0),(0)⟩,⟨(3),(15),(21),(0),(0)⟩,⟨(5),(22),(0),(0),(0)⟩,⟨(3),(20),(23),(0),(0)⟩,⟨(2),(19),(24),(0),(0)⟩]
theorem wf0 : wellFormed nodes0 = true := by decide +kernel
theorem decode0 : decode nodes0 = WinnerBetaA.Numerical.coefficientExpr (7/8) 240 := by decide +kernel
def actual0 : String := include_str "../../../checked-io-v1/source/sensitivity0_array.inc"
theorem source0 : ScopedC.CData.renderArray "sensitivity0" nodes0 = some actual0 := by decide +kernel
def nodes1 : List Node := [⟨(0),(0),(0),(500001),(1000000)⟩,⟨(0),(0),(0),(1),(1)⟩,⟨(0),(0),(0),(9),(10)⟩,⟨(4),(2),(0),(0),(0)⟩,⟨(2),(1),(3),(0),(0)⟩,⟨(3),(4),(1),(0),(0)⟩,⟨(3),(4),(5),(0),(0)⟩,⟨(0),(0),(0),(2),(1)⟩,⟨(8),(0),(0),(0),(0)⟩,⟨(3),(7),(8),(0),(0)⟩,⟨(5),(9),(0),(0),(0)⟩,⟨(3),(6),(10),(0),(0)⟩,⟨(5),(8),(0),(0),(0)⟩,⟨(2),(7),(12),(0),(0)⟩,⟨(3),(13),(4),(0),(0)⟩,⟨(0),(0),(0),(240),(1)⟩,⟨(5),(15),(0),(0),(0)⟩,⟨(3),(14),(16),(0),(0)⟩,⟨(2),(11),(17),(0),(0)⟩,⟨(3),(0),(18),(0),(0)⟩,⟨(0),(0),(0),(16),(5)⟩,⟨(3),(15),(1),(0),(0)⟩,⟨(3),(15),(21),(0),(0)⟩,⟨(5),(22),(0),(0),(0)⟩,⟨(3),(20),(23),(0),(0)⟩,⟨(2),(19),(24),(0),(0)⟩]
theorem wf1 : wellFormed nodes1 = true := by decide +kernel
theorem decode1 : decode nodes1 = WinnerBetaA.Numerical.coefficientExpr (9/10) 240 := by decide +kernel
def actual1 : String := include_str "../../../checked-io-v1/source/sensitivity1_array.inc"
theorem source1 : ScopedC.CData.renderArray "sensitivity1" nodes1 = some actual1 := by decide +kernel
def nodes2 : List Node := [⟨(0),(0),(0),(500001),(1000000)⟩,⟨(0),(0),(0),(1),(1)⟩,⟨(0),(0),(0),(15),(16)⟩,⟨(4),(2),(0),(0),(0)⟩,⟨(2),(1),(3),(0),(0)⟩,⟨(3),(4),(1),(0),(0)⟩,⟨(3),(4),(5),(0),(0)⟩,⟨(0),(0),(0),(2),(1)⟩,⟨(8),(0),(0),(0),(0)⟩,⟨(3),(7),(8),(0),(0)⟩,⟨(5),(9),(0),(0),(0)⟩,⟨(3),(6),(10),(0),(0)⟩,⟨(5),(8),(0),(0),(0)⟩,⟨(2),(7),(12),(0),(0)⟩,⟨(3),(13),(4),(0),(0)⟩,⟨(0),(0),(0),(240),(1)⟩,⟨(5),(15),(0),(0),(0)⟩,⟨(3),(14),(16),(0),(0)⟩,⟨(2),(11),(17),(0),(0)⟩,⟨(3),(0),(18),(0),(0)⟩,⟨(0),(0),(0),(16),(5)⟩,⟨(3),(15),(1),(0),(0)⟩,⟨(3),(15),(21),(0),(0)⟩,⟨(5),(22),(0),(0),(0)⟩,⟨(3),(20),(23),(0),(0)⟩,⟨(2),(19),(24),(0),(0)⟩]
theorem wf2 : wellFormed nodes2 = true := by decide +kernel
theorem decode2 : decode nodes2 = WinnerBetaA.Numerical.coefficientExpr (15/16) 240 := by decide +kernel
def actual2 : String := include_str "../../../checked-io-v1/source/sensitivity2_array.inc"
theorem source2 : ScopedC.CData.renderArray "sensitivity2" nodes2 = some actual2 := by decide +kernel
def nodes3 : List Node := [⟨(0),(0),(0),(500001),(1000000)⟩,⟨(0),(0),(0),(1),(1)⟩,⟨(0),(0),(0),(31),(32)⟩,⟨(4),(2),(0),(0),(0)⟩,⟨(2),(1),(3),(0),(0)⟩,⟨(3),(4),(1),(0),(0)⟩,⟨(3),(4),(5),(0),(0)⟩,⟨(0),(0),(0),(2),(1)⟩,⟨(8),(0),(0),(0),(0)⟩,⟨(3),(7),(8),(0),(0)⟩,⟨(5),(9),(0),(0),(0)⟩,⟨(3),(6),(10),(0),(0)⟩,⟨(5),(8),(0),(0),(0)⟩,⟨(2),(7),(12),(0),(0)⟩,⟨(3),(13),(4),(0),(0)⟩,⟨(0),(0),(0),(240),(1)⟩,⟨(5),(15),(0),(0),(0)⟩,⟨(3),(14),(16),(0),(0)⟩,⟨(2),(11),(17),(0),(0)⟩,⟨(3),(0),(18),(0),(0)⟩,⟨(0),(0),(0),(16),(5)⟩,⟨(3),(15),(1),(0),(0)⟩,⟨(3),(15),(21),(0),(0)⟩,⟨(5),(22),(0),(0),(0)⟩,⟨(3),(20),(23),(0),(0)⟩,⟨(2),(19),(24),(0),(0)⟩]
theorem wf3 : wellFormed nodes3 = true := by decide +kernel
theorem decode3 : decode nodes3 = WinnerBetaA.Numerical.coefficientExpr (31/32) 240 := by decide +kernel
def actual3 : String := include_str "../../../checked-io-v1/source/sensitivity3_array.inc"
theorem source3 : ScopedC.CData.renderArray "sensitivity3" nodes3 = some actual3 := by decide +kernel
end ScopedAux.SourceInputs
