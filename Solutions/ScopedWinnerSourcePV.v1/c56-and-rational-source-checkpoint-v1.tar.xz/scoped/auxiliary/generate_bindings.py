"""Prepare proofs of actual sensitivity source inputs, never output values."""
import json, os
from pathlib import Path

B = Path(__file__).resolve().parent
R = B.parents[1]

def main():
    d = json.loads((B/'SERIALIZATION_V1.json').read_text())['records']
    p = B/'lean/ScopedAux/SourceInputs.lean'
    if p.exists():
        raise ValueError('fresh generated module required')
    lines = ['/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/',
             'import ScopedC.CData', 'import WinnerBetaA.Numerical',
             'namespace ScopedAux.SourceInputs', 'open ScopedNumerical.Input',
             'set_option maxHeartbeats 0', 'set_option maxRecDepth 200000']
    for i,r in enumerate(d):
        nodes = '['+','.join('⟨'+','.join('('+str(x)+')' for x in n)+'⟩' for n in r['nodes'])+']'
        source = R/'scoped/checked-io-v1/source'/(r['name']+'_array.inc')
        lines += ['def nodes'+str(i)+' : List Node := '+nodes,
                  'theorem wf'+str(i)+' : wellFormed nodes'+str(i)+' = true := by decide +kernel',
                  'theorem decode'+str(i)+' : decode nodes'+str(i)+' = WinnerBetaA.Numerical.coefficientExpr ('+r['beta']+') 240 := by decide +kernel',
                  'def actual'+str(i)+' : String := include_str '+json.dumps(os.path.relpath(source,p.parent)),
                  'theorem source'+str(i)+' : ScopedC.CData.renderArray '+json.dumps(r['name'])+' nodes'+str(i)+' = some actual'+str(i)+' := by decide +kernel']
    lines += ['end ScopedAux.SourceInputs']
    p.write_text('\n'.join(lines)+'\n')
    print('Prepared four original input-domain/decode/actual-source bindings; no output computation.')

if __name__ == '__main__':
    main()
