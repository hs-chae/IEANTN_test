#include "function_30_qc.inc"
#include "function_31_qabs.inc"
