#include "function_47_atanhPoint.inc"
#include "checked_translation_116.inc"
