#include "function_27_qs.inc"
#include "function_28_qt.inc"
