"""Repackage the frozen manifest's exact source bytes; never overwrite an archive.

Derived from the existing source-cold44 packager. Repacking normalizes container
metadata, so a new ZIP container may have a different hash; all manifest source,
receipt and payload byte hashes remain exact. This does not run Lean.
"""
from pathlib import Path
import argparse,hashlib,json,zipfile
B=Path(__file__).resolve().parent
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();target=a.out.resolve();need(not target.exists(),'fresh archive required');manifest=(B/'ARTIFACT_MANIFEST.json').read_bytes();d=json.loads(manifest);need(d['actual_old_C_bodies']==52 and not d['combined_fresh_replay_completed'],'fixed source-only52 boundary');files={}
 for row in d['files']:
  p=Path(row['path']);need(not p.is_absolute()and'..'not in p.parts,'relative manifest path');src=B/p;need(src.is_file()and not src.is_symlink(),'ordinary source/receipt file');data=src.read_bytes();need(len(data)==row['bytes']and sha(data)==row['sha256'],'exact frozen bytes '+str(p));need(str(p)not in files,'unique manifest member');files[str(p)]=data
 files['ARTIFACT_MANIFEST.json']=manifest
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,data in sorted(files.items()):
   info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data,compresslevel=9)
 with zipfile.ZipFile(target)as z:
  need(z.testzip()is None and len(z.namelist())==len(files)and set(z.namelist())==set(files),'complete archive membership/CRC')
  for name,data in files.items():need(z.read(name)==data,'complete byte readback '+name)
 print(json.dumps(dict(status='PASS_EXACT_MANIFEST_SOURCE_REPACKAGE_NO_LEAN_REPLAY',archive=str(target),bytes=target.stat().st_size,sha256=sha(target.read_bytes()),members=len(files),combined_fresh_replay_completed=False)))
if __name__=='__main__':main()
