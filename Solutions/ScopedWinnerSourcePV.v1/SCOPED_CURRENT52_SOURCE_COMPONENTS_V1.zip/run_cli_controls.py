#!/usr/bin/env python3
"""Exercise actual clean-source CLI acceptance/rejection in all Python modes."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import time

B=Path(__file__).resolve().parent
def need(value, message):
    if not value:
        raise RuntimeError(message)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args=parser.parse_args()
    out=args.out.resolve()
    need(not out.exists() and B not in out.parents, 'fresh experiment-owned directory outside capsule')
    out.mkdir(parents=True)
    lock=json.loads((B/'SOURCE_LOCK.json').read_text())
    rows=[]
    started=time.monotonic()
    for mode, flags in [('normal',[]),('O',['-O']),('OO',['-OO'])]:
        folder=out/mode
        folder.mkdir()
        command=[sys.executable,*flags,str(B/'reproduce.py'),'--check-source-only','--out',str(folder/'positive')]
        result=subprocess.run(command,capture_output=True,text=True)
        need(result.returncode==0,'actual positive source assembly: '+result.stderr[-2000:])
        receipt=json.loads((folder/'positive/ASSEMBLY_RECEIPT.json').read_text())
        need(receipt['status']=='PASS_SOURCE_ASSEMBLY_ONLY_NO_LEAN_REPLAY' and receipt['source_modules']==644
             and receipt['theorem_roots']==767 and receipt['actual_body_count']==52,'exact positive population')
        rows.append(dict(mode=mode,case='source_assembly',exit_code=0,receipt=receipt))
        command=[sys.executable,*flags,str(B/'reproduce.py'),'--out',str(folder/'unknown'),'--unknown']
        result=subprocess.run(command,capture_output=True,text=True)
        need(result.returncode!=0 and 'unrecognized arguments' in result.stderr,'actual unknown-option rejection')
        need(not (folder/'unknown').exists(),'unknown option wrote output')
        rows.append(dict(mode=mode,case='unknown_option',exit_code=result.returncode))
        clone=folder/'corrupted_capsule'
        shutil.copytree(B,clone,ignore=shutil.ignore_patterns('*.zip','ARTIFACT_MANIFEST.json','SOURCE_ARCHIVE_RECEIPT*.json'))
        archive=lock['base_archive']
        shutil.copyfile(B/archive,clone/archive)
        target=clone/lock['sources'][0]['path']
        target.write_bytes(target.read_bytes()+b'\n-- Deliberate experiment-owned hash rejection control.\n')
        command=[sys.executable,*flags,str(clone/'reproduce.py'),'--check-source-only','--out',str(folder/'corrupt_output')]
        result=subprocess.run(command,capture_output=True,text=True)
        need(result.returncode!=0 and 'exact source' in result.stderr,'actual corrupted-source rejection')
        need(not (folder/'corrupt_output/ASSEMBLY_RECEIPT.json').exists()
             and not (folder/'corrupt_output/RECEIPT.json').exists(),'corruption published an acceptance receipt')
        rows.append(dict(mode=mode,case='corrupted_source',exit_code=result.returncode,source=lock['sources'][0]['path']))
    receipt=dict(status='PASS_ALL9_ACTUAL_CURRENT52_SOURCE_CLI_CONTROLS',seconds=time.monotonic()-started,
        cases=rows,source_lock_sha256=digest(B/'SOURCE_LOCK.json'),reproducer_sha256=digest(B/'reproduce.py'),
        qualification='Source assembly and real rejection controls only; no Lean replay acceptance.')
    (out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='cases'}))
if __name__=='__main__':
    main()
