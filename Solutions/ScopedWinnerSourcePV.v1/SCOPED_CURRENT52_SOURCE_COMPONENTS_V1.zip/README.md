# Current52 actual-source proof components

This is an additive source-only reproducibility capsule for52 of the original68 Scoped Winner C functions. It preserves the immutable499-source/419-root source-cold44 component and adds145 exact accepted sources, yielding644 application modules and767 selected theorem roots. Original experimental outcomes and all previous archives remain unchanged.

Whole original iinv is included with both actual source branches, the original decimal10^30 producer, genuine short circuit, typed declarations/return, all scopes, and the exact original invIntervalDyadic/validity result at precision−100. This includes old input representations with equal endpoint values and coarse zero. The current52 population is controls26 plus numerics26; original qpow/rpow/taylor bodies and exact mathematical joins are also included.

This archive initially records a prepared source snapshot. The combined fresh644-source replay remains PENDING until a separate actual full replay receipt says otherwise. Individual new selected roots have accepted host-development Lean receipts with only propext, Classical.choice and Quot.sound. That is not a claim of full Scoped Winner source-first PV: application prepare, complete evaluate/runRow/main and source-linked final I/O/ANT consumption remain incomplete. The native-free106-module/42-root numerical consumer study is separate kernel-only evidence.

## Reproduce from a clean environment

Use Python3, git/curl and the pinned public Lean4.34.0-rc2 and Mathlib generic dependencies. No application .olean, private workspace or transcript is required. Existing public-only bootstrap instructions and exact compiler/library/runtime pins are in the nested source-cold44/43 capsule and SOURCE_LOCK.json.

1. Prepare the public generic environment:

   python prepare_environment.py --toolchain /path/to/lean-4.34.0-rc2-linux --mathlib /path/to/pinned/mathlib --out /tmp/current52-public-environment.json

2. Check and assemble the exact644 source modules and885 payloads without running Lean:

   python reproduce.py --check-source-only --out /tmp/current52-source-assembly

3. In a separately fresh output directory, rebuild every application source and audit all767 exact selected roots:

   python reproduce.py --environment /tmp/current52-public-environment.json --out /tmp/current52-full-replay --jobs 2

Allocate memory according to actual available host capacity; the measured previous499-source replay used24GiB/jobs2. The clean recipe admits public generic dependencies only, verifies all source/receipt/payload hashes, creates a new object bank, and rejects any nonstandard execution axiom in every selected closure. It writes acceptance only after all644 sources and767 root audits pass. Failure logs/partial progress must be retained and cannot be called acceptance. Python normal/-O/-OO modes retain the same explicit checks.

## Exact inputs and source scope

BODY52_INDEX.json enumerates all52 actual function identities and exact mathematical qualifications. NUMERICS_V23_INDEX.json records the numerical component snapshot. SOURCE_LOCK.json pins all145 new modules, their source associations, selected roots,767 exact root population, the immutable baseline archive and885 C/input payloads. The dependency closure is complete; no application source is silently replaced by a generic object. prepare.py is the maintainer snapshot tool; it is not a clean-environment prerequisite.

The controls selector includes117 registered builder modules and the numerical V23 index. The one separate initialized-array conservative extension ArrayLegacyLift is outside this original SourceCalls52-body graph and is separately preserved/reproduced in the height component; it is not counted as an extra function or omitted from its own source graph. PREPARATION_FAILURE_V1.json records the initial overly broad selection and correction. All52 body/math dependencies and the existing entire actual evaluator literal branch remain included.

## Trust boundary

These are actual executable-source-associated AST/body proofs and mathematical joins. Proof-only finite call services require a complete lower actual-source execution witness for every answer; no expected numerical output, initialized application cache, SuccessfulEffects or arbitrary application-function service is a runtime leaf. Native evaluation and ordinary certificate checking are not relabeled PV.

The formal source correspondence/model and Lean kernel still rely on the explicitly documented pinned compiler/C++ evaluation-order and generic Lean C-runtime/API/OS/hardware boundary. The compiler and operating system are not proved here. Actual source preparation must establish the physical pool, scale, input-buffer, coefficient-array, capacity and lifetime conditions before a whole application conclusion follows. The source snapshot contains no accepted binary object or private context. Original sources, accepted proof artifacts and historical outcomes are preserved; only checked-regenerable experiment-owned control copies may be cleaned.
