"""Assemble immutable499-source baseline plus current52 delta; run existing kernel replay."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,zipfile
B=Path(__file__).resolve().parent
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
 q=p.with_suffix('.pending');q.write_text(json.dumps(d,indent=2)+'\n');os.replace(q,p)
def extract(archive,dest):
 dest.mkdir()
 with zipfile.ZipFile(archive)as z:
  names=set()
  for info in z.infolist():
   p=Path(info.filename);need(not p.is_absolute()and'..'not in p.parts and not info.is_dir(),'regular relative archive member');need(info.filename not in names,'unique archive path');names.add(info.filename);need((info.external_attr>>16)&0o170000!=0o120000,'regular source archive');target=dest/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(info))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--environment',type=Path);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--jobs',type=int,default=2);ap.add_argument('--check-source-only',action='store_true');a=ap.parse_args();need(1<=a.jobs<=4,'jobs1..4');need(a.check_source_only or(a.environment and a.environment.is_file()),'public environment JSON required for Lean replay')
 lock=json.loads((B/'SOURCE_LOCK.json').read_text());need(lock['actual_body_count']==52 and len(lock['actual_body_functions'])==52 and len(set(lock['actual_body_functions']))==52,'exact actual52 function population');need(sha(B/'BODY52_INDEX.json')==lock['body_index_sha256'],'body index identity');body=json.loads((B/'BODY52_INDEX.json').read_text());need(sorted(body['aggregate_functions'])==lock['actual_body_functions'],'body identities equal index')
 need(sha(B/'replay_engine.py')==lock['engine_sha256']and sha(B/'prepare_environment.py')==lock['prepare_environment_sha256'],'existing public replay engine/bootstrap identities')
 for row in lock['accepted_host_records']:need(sha(B/row['receipt'])==row['receipt_sha256'],'host receipt pin '+row['module'])
 archive=B/lock['base_archive'];need(sha(archive)==lock['base_archive_sha256'],'unchanged actual source-cold44 archive')
 out=a.out.resolve();need(not out.exists()and B not in out.parents,'fresh experiment-owned output outside capsule');out.mkdir(parents=True);extract(archive,out/'base44');base44=out/'base44';need(sha(base44/'SOURCE_LOCK.json')==lock['base44_lock_sha256'],'base44 source lock');l44=json.loads((base44/'SOURCE_LOCK.json').read_text());archive43=base44/'SCOPED_CURRENT43_SOURCE_COMPONENTS_V1.zip';need(sha(archive43)==l44['base_archive_sha256'],'base43 archive identity');extract(archive43,out/'base43');base43=out/'base43/capsule-v1';need(sha(base43/'SOURCE_LOCK.json')==lock['base43_lock_sha256'],'base43 lock identity');l43=json.loads((base43/'SOURCE_LOCK.json').read_text())
 assembly=out/'assembled';assembly.mkdir();rows=[];names=set()
 def copy_source(src,row,expected):
  need(src.is_file()and not src.is_symlink()and sha(src)==expected,'exact source '+row['module']);need(row['module']not in names,'disjoint source extension '+row['module']);names.add(row['module']);dest=assembly/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes());rows.append(dict(module=row['module'],path=row['path'],sha256=sha(dest),bytes=dest.stat().st_size,imports=row['imports']))
 for row in l43['sources']:copy_source(base43/row['path'],row,row['sha256'])
 for row in l43['payloads']:
  src=base43/row['path'];need(src.is_file()and not src.is_symlink()and src.stat().st_size==row['bytes']and sha(src)==row['sha256'],'base C/input payload '+row['path']);dest=assembly/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
 for row in l44['sources']:
  r=dict(row);r['imports']=lock['base44_imports'][row['module']];copy_source(base44/row['path'],r,row['source_sha256'])
 for row in lock['sources']:copy_source(B/row['path'],row,row['sha256'])
 need(len(rows)==lock['total_application_sources']==644,'complete exact644 source population');need(len(lock['roots'])==767 and len(set(lock['roots']))==767,'exact767 theorem-root population');need(all(set(r['imports'])<=names for r in rows),'complete application dependency closure');need(set(lock['root_modules'])<=names,'all root modules present')
 combined=dict(schema='ASSEMBLED_CURRENT52_CLEAN_REPLAY_V1',sources=rows,payloads=l43['payloads'],roots=lock['roots'],root_modules=lock['root_modules'],compiler_sha256=lock['compiler_sha256'],generic_dependencies=lock['generic_dependencies'],runtime_pins=lock['runtime_pins'],qualification=lock['qualification']);write(assembly/'SOURCE_LOCK.json',combined);shutil.copyfile(B/'replay_engine.py',assembly/'reproduce.py')
 receipt=dict(status='PASS_SOURCE_ASSEMBLY_ONLY_NO_LEAN_REPLAY',source_modules=len(rows),payloads=len(l43['payloads']),theorem_roots=len(lock['roots']),actual_body_count=52,source_lock_sha256=sha(B/'SOURCE_LOCK.json'),assembled_lock_sha256=sha(assembly/'SOURCE_LOCK.json'),reproducer_sha256=sha(Path(__file__)),combined_fresh_replay_completed=False,whole_program_source_first_PV_complete=False);write(out/'ASSEMBLY_RECEIPT.json',receipt)
 if a.check_source_only:print(json.dumps(receipt));return
 opt=['-OO']if sys.flags.optimize>=2 else['-O']if sys.flags.optimize else[]
 command=[sys.executable,*opt,str(assembly/'reproduce.py'),'--environment',str(a.environment.resolve()),'--out',str(out/'verification'),'--jobs',str(a.jobs)];q=subprocess.run(command);need(q.returncode==0,'actual complete source-cold proof replay failed; preserve outputs');result=json.loads((out/'verification/RECEIPT.json').read_text());need(result['status']=='PASS_HOST_GENERIC_ONLY_SOURCE_COLD_CURRENT52_COMPONENTS'and result['source_modules']==644 and result['theorem_roots']==767 and result['application_object_inputs']==[],'complete actual clean kernel result');need([r['name']for r in result['audits']]==lock['roots']and all(set(r['axioms'])<={'propext','Classical.choice','Quot.sound'}for r in result['audits']),'all actual complete Std3 closures')
 receipt.update(status='PASS_CLEAN_CURRENT52_SOURCE_REPLAY',combined_fresh_replay_completed=True,command=command,verification_receipt_sha256=sha(out/'verification/RECEIPT.json'));write(out/'RECEIPT.json',receipt);print(json.dumps(receipt))
if __name__=='__main__':main()
