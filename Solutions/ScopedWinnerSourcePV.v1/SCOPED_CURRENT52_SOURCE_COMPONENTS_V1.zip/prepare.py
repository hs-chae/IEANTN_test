"""Freeze the exact current52 source delta over immutable source-cold44."""
from pathlib import Path
import hashlib,json,importlib.util,re,shutil
B=Path(__file__).resolve().parent;R=B.parents[1]
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):
 p=Path(p);return p if p.is_absolute()else R/p

def main():
 spec=importlib.util.spec_from_file_location('old_snapshot',R/'scoped/body43-supplement-v1/prepare_snapshot.py');scanner=importlib.util.module_from_spec(spec);spec.loader.exec_module(scanner)
 base43=json.loads((R/'scoped/body43-supplement-v1/capsule-v1/SOURCE_LOCK.json').read_text());base44=json.loads((R/'scoped/body44-extension-v1/SOURCE_LOCK.json').read_text())
 numericPath=R/'scoped/frontend/proof/SOURCE_HELPER_SUPPORT_INDEX_V23.json';numeric=json.loads(numericPath.read_text());bodyPath=R/'scoped/evaluate-source-v1/CURRENT_CONTROLS_BODY_AND_MATH_INDEX_V10.json';body=json.loads(bodyPath.read_text());need(body['aggregate_actual_whole_bodies']==52 and len(body['aggregate_functions'])==52,'exact actual52 body population')
 base={r['module']:r for r in base43['sources']};base.update({r['module']:r for r in base44['sources']});need(len(base)==499,'frozen499 baseline')
 own='ArrayFrames CallEventArgumentKeys CallEventArgumentRefinement CallEventKeys CallEventNames CallEventService CursorSingleFrames DataContextFrames DataNodeCasts DecimalSourceTrace DecimalTraceLoop DyadicInverseAlgorithm DyadicInverseBody DyadicInverseBodyRuns DyadicInverseCombinedEvents DyadicInverseConversion DyadicInverseEventData DyadicInverseEventLemmas DyadicInverseFallbackSource DyadicInverseFallbackStages DyadicInverseFlagLocal DyadicInversePrefix DyadicInverseReciprocalEffects DyadicInverseReciprocals DyadicInverseValidCalls DyadicInverseValidSource DyadicInverseValidStages DyadicInverseValidity DyadicMultiplyBody DyadicMultiplyStages DyadicNatsExtensionality DyadicRoundingValues DyadicToRIPair EvaluateArrayStore EvaluateFrames EvaluateGuards EvaluateLiteral EvaluateLiteralBranch EvaluateLiteralCommit EvaluateLiteralRHS EvaluateLiteralRHSExpression EvaluateLiteralRHSTrace EvaluateLiteralRationalStages EvaluateLiteralSigned EvaluateLiteralTraceStages EvaluateMagnitude EvaluateMagnitudeCaller EvaluateMagnitudeTrace EvaluateNodeRead EvaluateSyntax FloorQFrames FloorQIncrementCalls FloorQNegativeCalls FloorQNegativeFrames FromRIAllocationTrace FromRIExpressions FromRIFactor FromRIFrames FromRIMemory FromRIOutput FromRIServices FromRIStages LiteralAllocationEffects LocalBinding LocalBindingSeparation NumericDyadicInverseRefinement NumericDyadicMultiplyRefinement NumericFromRIRefinement NumericIntervalCompleteness NumericNatsExtensionality NumericToRIRefinement PoolContextPop RationalDivideTrace RationalIntervalHullTrace RationalMultiplyTrace RationalNaturalLiteral RationalNaturalLiteralEffects RationalNaturalLiteralLocal RationalReciprocalCalls RationalReciprocalLocal RationalReciprocalLocalEffects RationalSortCalls RationalSortLocal RationalSymmetricLocal RationalUnsignedTrace RationalZeroCompare ReadonlyAllocatedBuffers ReadonlyCallEffects SourceCeilData SourceCeilQ SourceCeilQFraming SourceCeilQTrace SourceFloorQAll SourceFloorQBudget SourceFloorQFraming SourceFloorQIntegral SourceFloorQNonintegral SourceFloorQNonnegative SourceFloorQNonnegativeMath SourceFloorQTrace SourceFromRI SourceFromRIAnyFlag SourceFromRIArguments SourceFromRIBoolean SourceFromRIDecoded SourceFromRITraceMath SourceFromS SourceFromSTrace SourceIconst SourceIconstTrace SourceRoundProduct SourceScaleFrames SourceToRI ToRIFrames ToRIStages ToRITrace UnsignedRelations'.split()
 receipts={}
 for r in numeric['files']:
  src=resolve(r['source']);p=resolve(r['receipt']);need(sha(src)==r['source_sha256']and sha(p)==r['receipt_sha256'],'stable numerical source/receipt '+r['module']);receipts[r['module']]=p
 for p in (R/'scoped/frontend/proof').rglob('RECEIPT.json'):
  if p.stat().st_size>30000000:continue
  try:d=json.loads(p.read_text())
  except (ValueError,OSError):continue
  if d.get('status')!='PASS_HOST_DEVELOPMENT_COMPILE' or d.get('module','').removeprefix('ScopedC.')not in own:continue
  src=resolve(d['source'])
  if src.is_file()and sha(src)==d['source_sha256']:receipts[d['module']]=p
 need({'ScopedC.'+x for x in own}<=set(receipts),'all current own helpers accepted')
 roots=list(base43['roots'])+[n for row in base44['sources']for n in row['roots']];rootModules=list(base43['root_modules'])+[r['module']for r in base44['sources']]
 need(len(roots)==419 and len(set(roots))==419,'fixed419 baseline roots')
 records=[];sources={};known={m for m in base}
 def accepted(module):
  p=receipts[module];d=json.loads(p.read_text());src=resolve(d['source']);need(d['exit_code']==0 and d['source_unchanged'] and sha(src)==d['source_sha256'],'accepted unchanged '+module);need(all(set(a['axioms'])<={'propext','Classical.choice','Quot.sound'}for a in d['audit']),'full Std3 '+module)
  return p,d,src
 for m in sorted(receipts):
  p,d,src=accepted(m)
  if m in base:
   old=base[m].get('original_sha256',base[m].get('source_sha256'));need(sha(src)==old,'immutable base source drift '+m);continue
  need('include_str'not in src.read_text(),'new payload needs explicit portability '+m)
  sources[m]=src
  if m not in rootModules:rootModules.append(m)
  for a in d['audit']:
   if a['name']not in roots:roots.append(a['name'])
  dest=B/'evidence/receipts'/Path(m.replace('.','/')).with_suffix('.json');dest.parent.mkdir(parents=True,exist_ok=True);need(not dest.exists()or sha(dest)==sha(p),'unchanged partial receipt copy');dest.write_bytes(p.read_bytes());records.append(dict(module=m,source=str(src.relative_to(R)),source_sha256=sha(src),receipt=str(dest.relative_to(B)),receipt_sha256=sha(dest),roots=[dict(name=a['name'],axioms=a['axioms'])for a in d['audit']]))
 numericLockPath=R/'scoped/numerical/kernel-plane-capsule-v6/SOURCE_LOCK.json';numericFrozen={x['module']:x for x in json.loads(numericLockPath.read_text())['sources']};dependencyAssociations=[]
 env=json.loads((R/'scoped/build/DEVELOPMENT_ENVIRONMENT.json').read_text());generic=[Path(x['objects'])for x in env['generic_dependencies']]+[Path(env['compiler']).parent.parent/'lib/lean'];state={};order=[];newrows=[]
 def genericModule(m):return any((p/Path(m.replace('.','/')).with_suffix('.olean')).is_file()for p in generic)
 def visit(m):
  if m in base:return
  if m in state:need(state[m]=='done','acyclic actual source closure '+m);return
  need(m in sources,'new dependency missing accepted source '+m);state[m]='active';src=sources[m];imports=[]
  for child in scanner.imports(src.read_text()):
   if genericModule(child):continue
   if child not in base and child not in sources:
    need(child in numericFrozen,'uncovered application source '+child);row=numericFrozen[child];p=Path(row['original_source']);need(p.is_file()and sha(p)==row['original_sha256'],'pinned unchanged original-model dependency '+child);sources[child]=p;dependencyAssociations.append(dict(module=child,source=str(p.relative_to(R)),source_sha256=sha(p),frozen_lock_sha256=sha(numericLockPath),individual_new_host_receipt_claimed=False))
   imports.append(child);visit(child)
  rel=Path('source')/Path(m.replace('.','/')).with_suffix('.lean');dst=B/rel;dst.parent.mkdir(parents=True,exist_ok=True);need(not dst.exists()or sha(dst)==sha(src),'unchanged partial source copy');dst.write_bytes(src.read_bytes());newrows.append(dict(module=m,path=str(rel),sha256=sha(dst),bytes=dst.stat().st_size,imports=imports,original_source_sha256=sha(src)));state[m]='done';order.append(m)
 for m in sorted(sources):visit(m)
 archive=R/'scoped/body44-extension-v1/SCOPED_CURRENT44_SOURCE_COLD_COMPONENT_V1.zip';shutil.copyfile(archive,B/'SCOPED_CURRENT44_SOURCE_COLD_COMPONENT_V1.zip')
 for label,p in [('BODY52_INDEX.json',bodyPath),('NUMERICS_V23_INDEX.json',numericPath)]:shutil.copyfile(p,B/label)
 engine=(R/'scoped/body43-supplement-v1/reproduce.py').read_text().replace('PASS_HOST_GENERIC_ONLY_SOURCE_COLD_CURRENT43_COMPONENTS','PASS_HOST_GENERIC_ONLY_SOURCE_COLD_CURRENT52_COMPONENTS')
 (B/'replay_engine.py').write_text(engine);shutil.copyfile(R/'scoped/body43-supplement-v1/prepare_environment.py',B/'prepare_environment.py')
 baselineRoot=R/'scoped/build/current44-clean-default-OO-v1/RECEIPT.json'
 lock=dict(schema='CURRENT52_SOURCE_ONLY_ADDITIVE_REPLAY_V1',status='SOURCE_ONLY_PREPARED_COMBINED_FRESH_REPLAY_PENDING',base_archive='SCOPED_CURRENT44_SOURCE_COLD_COMPONENT_V1.zip',base_archive_sha256=sha(archive),base44_lock_sha256=sha(R/'scoped/body44-extension-v1/SOURCE_LOCK.json'),base43_lock_sha256=sha(R/'scoped/body43-supplement-v1/capsule-v1/SOURCE_LOCK.json'),base_completed_receipt_sha256=sha(baselineRoot),base_application_sources=499,base_selected_roots=419,sources=newrows,total_application_sources=499+len(newrows),roots=roots,root_modules=list(dict.fromkeys(rootModules)),actual_body_functions=sorted(body['aggregate_functions']),actual_body_count=52,body_index_sha256=sha(B/'BODY52_INDEX.json'),numerics_index_sha256=sha(B/'NUMERICS_V23_INDEX.json'),accepted_host_records=records,additional_original_model_dependencies=dependencyAssociations,compiler_sha256=base43['compiler_sha256'],generic_dependencies=base43['generic_dependencies'],runtime_pins=base43['runtime_pins'],engine_sha256=sha(B/'replay_engine.py'),prepare_environment_sha256=sha(B/'prepare_environment.py'),whole_program_source_first_PV_complete=False,combined_fresh_replay_completed=False,qualification='Immutable actual499-source/419-root source-cold44 plus exact accepted current52 body/math, whole original inverse source/math and actual evaluator literal-branch source dependency delta. All new component roots individually passed host Std3 builds. This combined48 closure has NOT received a fresh full replay. No application object files are distributed or accepted by the clean recipe. Original outcomes, C algorithms, analytic premises and source44 archives are preserved; complete prepare/evaluate/main/I/O/output-to-ANT source-PV remains incomplete. Actual52 bodies do not imply whole-program completion.')
 lock['base44_imports']={r['module']:[n for n in scanner.imports((R/'scoped/body44-extension-v1'/r['path']).read_text())if n in set(base)|set(sources)]for r in base44['sources']}
 (B/'SOURCE_LOCK.json').write_text(json.dumps(lock,indent=2)+'\n');print(json.dumps(dict(sources=lock['total_application_sources'],delta=len(newrows),roots=len(roots),bodies=52,combined_fresh_replay_completed=False)))
if __name__=='__main__':main()
