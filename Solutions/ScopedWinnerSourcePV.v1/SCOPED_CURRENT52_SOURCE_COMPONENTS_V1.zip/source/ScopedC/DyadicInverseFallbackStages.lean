/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalNaturalLiteralLocal
import ScopedC.RationalSymmetricLocal
import ScopedC.SourceFromRIAnyFlag
import ScopedC.NumericNatsExtensionality
namespace ScopedC.DyadicInverseFallbackStages
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DecimalText (digits)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000
attribute [local irreducible] RationalMakeCalls.c5

structure Library (code : List Function) : Prop where
  literal : RationalNaturalLiteral.Library code
  fromRI : Generated.f_fromRI∈code
  qt : Generated.f_qt∈code
  floorQ : Generated.f_floorQ∈code
  ceilQ : Generated.f_ceilQ∈code
  qn : Generated.f_qn∈code
  sn : Generated.f_sn∈code
  qtLib : RationalMultiplyCalls.Library code
  roundLib : FloorQNegativeCalls.Library code

def symmetricInterval (n : Nat) : IntervalRat := ⟨-(n:Rat),(n:Rat),by
  have nonnegative : (0:Rat)≤n := by positivity
  linarith⟩

private theorem rat_ext {a b : IntervalRat} (lo : a.lo=b.lo) (hi : a.hi=b.hi) : a=b := by
  cases a
  cases b
  simp_all
def wideCursor {code : List Function} {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : RationalNaturalLiteral.Stages code l c n) : Cursor := RationalNaturalLiteralLocal.after D
def roundCursor {code : List Function} {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : RationalNaturalLiteral.Stages code l c n) : Cursor := RationalSymmetricLocal.after l (wideCursor D) D.output

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (n : Nat) where
  literal : RationalNaturalLiteral.Stages code l c n
  negate : SourceCall Header.layout code 6 "qn" [literal.output.source] (wideCursor literal).state
    (RationalSymmetricLocal.output literal.output).lo.source (next l (wideCursor literal) 0).state
  rounded : Cursor
  low : Endpoint
  high : Endpoint
  trace : List Nat
  roundCall : SourceCall Header.layout code 8 "fromRI"
    [(RationalSymmetricLocal.output literal.output).source,DecimalDigits.integer 0] (roundCursor literal).state
    (DyadicCasts.value low.source high.source false) rounded.state
  valid : Valid l rounded
  lowLive : low.Live rounded.state
  highLive : high.Live rounded.state
  decoded : DyadicRepresentation.interval rounded.state (DyadicCasts.value low.source high.source false)=
    some (IntervalDyadic.ofIntervalRat (symmetricInterval n) (-100),false)
  advance : rounded=CursorFrames.advance l (roundCursor literal) trace
  length : trace.length ≤ 38

/-- All fallback values are produced by their actual source computations:
initialized decimal bytes, complete parser, smake/nu/qm, qn and fromRI.
Specializing n=10^30 preserves the original source and inverse fallback. -/
theorem stages_exist (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (n : Nat) (room : c.top+46+4*(digits n).length < capacity)
    {object slot : Nat} (scale : SourceFromS.ScaleAt c.state object slot (2^100)) :
    Nonempty (Stages code l c n) := by
  obtain ⟨D⟩ := RationalNaturalLiteral.stages_exist code lib.literal ctx n (by omega)
  have wctx : Valid l (wideCursor D) := CursorLocals.allocated_valid D.valid "Q" "wide" D.output.source
  have wtop : (wideCursor D).top=c.top+8+4*(digits n).length := RationalNaturalLiteral.top D
  have wlive : D.output.Live (wideCursor D).state := D.live
  have wscale : SourceFromS.ScaleAt (wideCursor D).state object slot (2^100) :=
    ReadonlyCallEffects.scale_allocate (RationalNaturalLiteral.scale D ctx scale) "Q" "wide" _
  have wroom : (wideCursor D).top < capacity := by rw [wtop];omega
  have negate := RationalSymmetricLocal.source_call code lib.qn lib.sn lib.literal.smake lib.literal.nz
    lib.literal.nu lib.literal.ne lib.literal.keep wctx wroom D.output wlive D.positive
  have rctx : Valid l (roundCursor D) := RationalSymmetricLocal.after_valid wctx wroom D.output
  have rscale : SourceFromS.ScaleAt (roundCursor D).state object slot (2^100) :=
    RationalSymmetricLocal.scale wctx D.output wscale
  have roundRoom : (roundCursor D).top+37 < capacity := by
    change (wideCursor D).top+1+37 < capacity
    rw [wtop]
    omega
  have nonnegative : 0≤D.output.mathematical.value := by rw [D.value];positivity
  have decoded : NumericRepresentation.interval (roundCursor D).state (RationalSymmetricLocal.output D.output).source=
      some (symmetricInterval n) := by
    have initial := RationalSymmetricLocal.decoded (l:=l) (c:=wideCursor D) D.output wlive D.positive nonnegative
    have same : (⟨-D.output.mathematical.value,D.output.mathematical.value,by linarith⟩:IntervalRat)=symmetricInterval n :=
      rat_ext (by change -D.output.mathematical.value=-(n:Rat);rw [D.value])
        (by change D.output.mathematical.value=(n:Rat);exact D.value)
    rw [same] at initial
    exact (NumericNatsExtensionality.interval (s:=(next l (wideCursor D) 0).state)
      (t:=(roundCursor D).state) (by rfl) (RationalSymmetricLocal.output D.output).source).symm.trans initial
  obtain ⟨out,lo,hi,trace,call,valid,loLive,hiLive,decodedOutput,advance,length⟩ :=
    SourceFromRIAnyFlag.source code lib.fromRI lib.qt lib.floorQ lib.ceilQ lib.qn lib.sn lib.qtLib lib.roundLib
      rctx (RationalSymmetricLocal.output D.output).source false (DecimalDigits.integer 0) (symmetricInterval n)
      (by intro state;rfl) rscale decoded roundRoom
  exact ⟨⟨D,negate,out,lo,hi,trace,call,valid,loLive,hiLive,decodedOutput,advance,length⟩⟩

end ScopedC.DyadicInverseFallbackStages
