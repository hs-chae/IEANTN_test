/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicRepresentation
namespace ScopedC.DyadicNatsExtensionality
open ScopedC.Machine
set_option autoImplicit false

/-- Stack/heap frame restoration cannot change the immediate dyadic decoder
when the actual Nat arena is preserved. No equality of Nat-owner functions
or application output is guessed; equality of the whole arena is required. -/
theorem interval {s t : State} (h : s.nats=t.nats) (v : Value) :
    DyadicRepresentation.interval s v=DyadicRepresentation.interval t v := by
  cases s
  cases t
  cases h
  rfl

end ScopedC.DyadicNatsExtensionality
