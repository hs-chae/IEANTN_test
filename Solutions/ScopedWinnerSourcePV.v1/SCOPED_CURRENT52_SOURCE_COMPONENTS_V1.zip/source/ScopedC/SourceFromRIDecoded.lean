/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceFromRIBoolean
namespace ScopedC.SourceFromRIDecoded
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.FromRIFrames ScopedC.DyadicRepresentation LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 0

private theorem rat_ext {a b : IntervalRat} (lo : a.lo=b.lo) (hi : a.hi=b.hi) : a=b := by
  cases a
  cases b
  simp_all

/-- Compose a proved actual RI output directly with the actual fromRI source.
Decoder inversion discharges both Q liveness/denominator obligations. The
argument is the actual logical-result C value, with its typed cast proved by
SourceFromRIBoolean. No expected output or caller representation is assumed. -/
theorem fromRI_of_decoded (code : List Function) (installed : Generated.f_fromRI∈code)
    (qtInstalled : Generated.f_qt∈code) (floorInstalled : Generated.f_floorQ∈code)
    (ceilInstalled : Generated.f_ceilQ∈code) (qnInstalled : Generated.f_qn∈code)
    (snInstalled : Generated.f_sn∈code) (qtLib : RationalMultiplyCalls.Library code)
    (roundLib : FloorQNegativeCalls.Library code) {l : PoolLayout} {c : Cursor}
    (valid : Valid l c) (input : Value) (ok : Bool) (r : IntervalRat) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100))
    (decodedInput : NumericRepresentation.interval c.state input=some r)
    (room : c.top+37 < capacity) :
    ∃ out : Cursor, ∃ lo hi : Endpoint,
      SourceCall Header.layout code 8 "fromRI" [input,boolean Header.layout ok]
        c.state (DyadicCasts.value lo.source hi.source ok) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source ok)=
        some (IntervalDyadic.ofIntervalRat r (-100),ok) := by
  obtain ⟨pair,pairSource,pairLive,pairPositive,lowValue,highValue⟩ := NumericInputCompleteness.interval decodedInput
  let a : InputRI := ⟨pair.lo,pair.hi⟩
  have sourceEq : a.source=input := pairSource
  have ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value := by
    change pair.lo.mathematical.value ≤ pair.hi.mathematical.value
    rw [lowValue,highValue]
    exact r.le
  have same : (⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩:IntervalRat)=r :=
    rat_ext lowValue highValue
  obtain ⟨out,lo,hi,source,outValid,loLive,hiLive,decoded⟩ :=
    SourceFromRIBoolean.boolean_math code installed qtInstalled floorInstalled ceilInstalled qnInstalled snInstalled
      qtLib roundLib valid a ok scale pairLive pairPositive.1 pairPositive.2 ordered room
  rw [sourceEq] at source
  rw [same] at decoded
  exact ⟨out,lo,hi,source,outValid,loLive,hiLive,decoded⟩

end ScopedC.SourceFromRIDecoded
