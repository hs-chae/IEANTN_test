/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEventLists
namespace ScopedC.CallEvents
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- A selection key also distinguishes actual arguments: an unconsumed qi(0)
branch and the subsequent actual qi(1) can share a physical allocation count.
Every event still requires its complete actual lower source-call proof. -/
def argumentKey {cfg : Layout} {code : List Function} {rank : Nat} (e : Event cfg code rank) :
    String × List Value × Nat := (e.name,e.args,e.before.nats.values.length)

theorem one_other_argumentKey {cfg : Layout} {code : List Function} {rank : Nat}
    (e : Event cfg code rank) (name : String) (args : List Value) (s : State)
    (different : (name,args,s.nats.values.length)≠argumentKey e) : one e name args s=none := by
  unfold one
  split_ifs with same
  · exact False.elim (different (by simp only [argumentKey,same.1,same.2.1,same.2.2]))
  · rfl

theorem service_self_argumentKeys {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map argumentKey).Nodup)
    (e : Event cfg code rank) (member : e∈events) :
    service events e.name e.args e.before=some (e.value,e.after) := by
  induction events with
  | nil => contradiction
  | cons first rest ih =>
    rcases List.mem_cons.mp member with equal|member
    · subst e
      exact append_left (one_self first)
    · have hn : argumentKey first∉rest.map argumentKey := (List.nodup_cons.mp unique).1
      have hm : argumentKey e∈rest.map argumentKey := List.mem_map.mpr ⟨e,member,rfl⟩
      have different : argumentKey e≠argumentKey first := by intro equal;exact hn (equal ▸ hm)
      exact append_right (one_other_argumentKey first _ _ _ different) (ih (List.nodup_cons.mp unique).2 member)

theorem list_service_arguments {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map argumentKey).Nodup) :
    ∃service : Call,
      (∀e∈events,service e.name e.args e.before=some (e.value,e.after)) ∧
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall cfg code rank name args before value after) :=
  ⟨service events,fun e member=>service_self_argumentKeys events unique e member,
    fun _ _ _ _ _ answer=>service_closed events answer⟩

end ScopedC.CallEvents
