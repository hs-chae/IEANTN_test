/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalReciprocalLocal
namespace ScopedC.RationalReciprocalLocal
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalReciprocalCalls (Result)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem top {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {a : Input}
    (R : Result code l c a) (ctx : Valid l c) (room : c.top+15 < capacity) (name : String) :
    (after R name).top=c.top+(RationalReciprocalCalls.steps l c a).length := by
  change (RationalReciprocalCalls.after l c a).top=_
  rw [RationalReciprocalCalls.after_advance ctx room,CursorFrames.top_advance]

theorem preserve_input {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {a : Input}
    (R : Result code l c a) (ctx : Valid l c) (room : c.top+15 < capacity) (name : String)
    (q : Input) (h : q.Live c.state) : q.Live (after R name).state := by
  change q.Live (RationalReciprocalCalls.after l c a).state
  rw [RationalReciprocalCalls.after_advance ctx room]
  exact ⟨CursorBorrow.preserves _ h.1,CursorBorrow.preserves _ h.2⟩

theorem output_live {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {a : Input}
    (R : Result code l c a) (name : String) : R.output.Live (after R name).state := R.live

end ScopedC.RationalReciprocalLocal
