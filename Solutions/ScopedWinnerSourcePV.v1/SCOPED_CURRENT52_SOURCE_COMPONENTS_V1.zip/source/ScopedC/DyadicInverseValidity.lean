/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseConversion
import ScopedC.RationalZeroCompare
import ScopedC.LocalBindingSeparation
namespace ScopedC.DyadicInverseValidity
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def lowerPositive (a : Pair) : Bool := decide (0<a.lo.mathematical.value)
def valid (a : Pair) : Bool := lowerPositive a || decide (a.hi.mathematical.value<0)
def middle (l : PoolLayout) (c : Cursor) (a : Pair) : Cursor := RationalZeroCompare.after l c a.lo
def finish (l : PoolLayout) (c : Cursor) (a : Pair) : Cursor := RationalZeroCompare.after l (middle l c a) a.hi
def tested (l : PoolLayout) (c : Cursor) (a : Pair) : Cursor := if lowerPositive a then middle l c a else finish l c a
def steps (l : PoolLayout) (c : Cursor) (a : Pair) : List Nat :=
  if lowerPositive a then RationalZeroCompare.steps l c a.lo
  else RationalZeroCompare.steps l c a.lo++RationalZeroCompare.steps l (middle l c a) a.hi

def expression : Expr := .binary "||"
  (.binary ">" (.call (.var "qc") [.field "." (.var "q") "lo",.call (.var "qi") [.nat 0]]) (.nat 0))
  (.binary "<" (.call (.var "qc") [.field "." (.var "q") "hi",.call (.var "qi") [.nat 0]]) (.nat 0))

theorem tested_advance (l : PoolLayout) (c : Cursor) (a : Pair) :
    tested l c a=CursorFrames.advance l c (steps l c a) := by
  cases h:lowerPositive a
  · simp only [tested,steps,h,Bool.false_eq_true,↓reduceIte,finish,middle]
    rw [RationalZeroCompare.after_advance,RationalZeroCompare.after_advance,←CursorSingleFrames.advance_append]
  · simpa only [tested,steps,h,↓reduceIte,middle] using RationalZeroCompare.after_advance l c a.lo

theorem steps_length (l : PoolLayout) (c : Cursor) (a : Pair) : (steps l c a).length ≤ 18 := by
  cases h:lowerPositive a <;> simp [steps,h,RationalZeroCompare.steps,RationalCompareFraming.steps]

/-- Actual qi/qc executions for both sides of iinv's source domain guard.
The second side is constructed as a valid lower execution; source short-circuit
semantics below determines whether that execution is actually consumed. -/
theorem source_calls (code : List Function) (lib : RationalZeroCompare.Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+17 < capacity) (a : Pair) (live : a.Live c.state) (positive : a.Positive) :
    (SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 0] c.state
      (RationalZeroCompare.zero l c).source (RationalZeroCompare.first l c).state) ∧
    (SourceCall Header.layout code 6 "qc" [a.lo.source,(RationalZeroCompare.zero l c).source] (RationalZeroCompare.first l c).state
      (SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat a.lo.mathematical.value 0)) (middle l c a).state) ∧
    (SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 0] (middle l c a).state
      (RationalZeroCompare.zero l (middle l c a)).source (RationalZeroCompare.first l (middle l c a)).state) ∧
    (SourceCall Header.layout code 6 "qc" [a.hi.source,(RationalZeroCompare.zero l (middle l c a)).source]
      (RationalZeroCompare.first l (middle l c a)).state
      (SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat a.hi.mathematical.value 0)) (finish l c a).state) ∧
    Valid l (tested l c a) := by
  have first:=RationalZeroCompare.source_calls code lib ctx (by omega) a.lo live.1 positive.1
  have highLive : a.hi.Live (middle l c a).state := by
    rw [middle,RationalZeroCompare.after_advance]
    exact ⟨CursorBorrow.preserves _ live.2.1,CursorBorrow.preserves _ live.2.2⟩
  have secondRoom : (middle l c a).top+8 < capacity := by
    rw [middle,RationalZeroCompare.after_advance,CursorFrames.top_advance]
    change c.top+9+8 < capacity
    omega
  have second:=RationalZeroCompare.source_calls code lib first.2.2 secondRoom a.hi highLive positive.2
  refine ⟨first.1,first.2.1,second.1,second.2.1,?_⟩
  cases h:lowerPositive a
  · simpa only [tested,h,Bool.false_eq_true,↓reduceIte,finish,middle] using second.2.2
  · simpa only [tested,h,↓reduceIte,middle] using first.2.2

/-- Genuine source short circuit: q.hi and the second qi/qc pair are evaluated
only when the first endpoint was not strictly positive. -/
theorem source_expression (service : Call) {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (slot : Nat)
    (binding : LocalBinding.At c.state "q" "RI" a.source slot)
    (qiLo : service "qi" [DecimalDigits.integer 0] c.state=
      some ((RationalZeroCompare.zero l c).source,(RationalZeroCompare.first l c).state))
    (qcLo : service "qc" [a.lo.source,(RationalZeroCompare.zero l c).source] (RationalZeroCompare.first l c).state=
      some (SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat a.lo.mathematical.value 0),(middle l c a).state))
    (qiHi : service "qi" [DecimalDigits.integer 0] (middle l c a).state=
      some ((RationalZeroCompare.zero l (middle l c a)).source,(RationalZeroCompare.first l (middle l c a)).state))
    (qcHi : service "qc" [a.hi.source,(RationalZeroCompare.zero l (middle l c a)).source]
      (RationalZeroCompare.first l (middle l c a)).state=
      some (SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat a.hi.mathematical.value 0),(finish l c a).state)) :
    evalExpr Header.layout service 1000 c.state expression=
      some (boolean Header.layout (valid a),(tested l c a).state) := by
  have lowArgument : evalExpr Header.layout service 997 c.state (.field "." (.var "q") "lo")=some (a.lo.source,c.state) :=
    RationalIntervalFrames.eval_lo service 995 binding (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have low:=RationalZeroCompare.condition service 995 true a.lo _ lowArgument qiLo qcLo
  have safe:=LocalBinding.noncounter_separated ctx binding (by decide +kernel)
  have middleBinding : LocalBinding.At (middle l c a).state "q" "RI" a.source slot := by
    rw [middle,RationalZeroCompare.after_advance]
    exact LocalBinding.advance binding _ safe.1 safe.2.1 safe.2.2
  have highArgument : evalExpr Header.layout service 997 (middle l c a).state (.field "." (.var "q") "hi")=
      some (a.hi.source,(middle l c a).state) :=
    RationalIntervalFrames.eval_hi service 995 middleBinding (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have high:=RationalZeroCompare.condition service 995 false a.hi _ highArgument qiHi qcHi
  simp only [Bool.false_eq_true,↓reduceIte] at low high
  have truth_boolean (b : Bool) : truth (boolean Header.layout b)=b := by cases b <;> rfl
  change evalExpr Header.layout service 1000 c.state (.binary "||" _ _)=_
  rw [evalExpr,low]
  simp only [Bind.bind,Option.bind]
  rw [truth_boolean]
  cases h:lowerPositive a
  · have lower : decide (0<a.lo.mathematical.value)=false := h
    simp only [lower,Bool.false_eq_true,↓reduceIte]
    simp only [middle,finish] at high
    rw [high]
    simp only [Bind.bind,Option.bind]
    rw [truth_boolean]
    simp only [valid,tested,lowerPositive,finish,middle]
    simp only [lower,Bool.false_or,Bool.false_eq_true,↓reduceIte]
    all_goals rfl
  · have lower : decide (0<a.lo.mathematical.value)=true := h
    simp only [lower,↓reduceIte]
    simp only [valid,tested,lowerPositive,middle]
    simp only [lower,Bool.true_or,↓reduceIte]
    all_goals rfl

end ScopedC.DyadicInverseValidity
