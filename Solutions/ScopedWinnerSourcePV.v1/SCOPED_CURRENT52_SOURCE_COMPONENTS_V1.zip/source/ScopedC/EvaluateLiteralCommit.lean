/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.EvaluateLiteralRHSTrace
import ScopedC.EvaluateArrayStore
namespace ScopedC.EvaluateLiteralCommit
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.DecimalText
open ScopedC.EvaluateLiteralRationalStages (Library)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- The actual values[k] assignment in evaluate's literal branch, including
its genuine numerical source execution and checked typed store. Caller table
and counter storage are proved to survive those executions using the complete
allocation trace. No expected output, table preservation or successful store
is introduced as an application assumption. -/
theorem source_commit (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (n : ScopedNumerical.Input.Node) (base magSlot nodeSlot magLocal signLocal : Nat)
    (magLive : NatArena.Borrow c.state.nats magSlot n.num.natAbs)
    (magAt : LocalBinding.At c.state "mag" "N" (.natObject magSlot) magLocal)
    (negativeAt : LocalBinding.At c.state "negative" "unsigned int"
      (NatWrapperCalls.unsigned32 (EvaluateLiteral.flag n)) signLocal)
    (nodeAt : LocalBinding.At c.state "n" "Node" (DataNode.represented base n) nodeSlot)
    (denWindow : DecimalBuffer.At c.state ⟨base+1,0,[]⟩ (digits n.den)) (positive : 0 < n.den)
    {scaleObject scaleSlot : Nat} (scale : SourceFromS.ScaleAt c.state scaleObject scaleSlot (2^100))
    (room : c.top+44+4*(digits n.den).length < capacity)
    (cells : List (Option Value)) (tableSlot k counterSlot : Nat)
    (array : EvaluateArrayStore.At c.state cells tableSlot)
    (counter : LocalBinding.At c.state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) counterSlot)
    (bound : k<cells.length) :
    ∃service : Call,∃out : Cursor,∃lo hi : Endpoint,
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 9 name args before value after) ∧
      Run Header.layout service EvaluateSyntax.literalCommit c.state (.continuing out.state) ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (IntervalDyadic.ofIntervalRat (IntervalRat.singleton (mkRat n.num n.den)) (-100),true) ∧
      EvaluateArrayStore.At out.state (cells.set k (some (DyadicCasts.value lo.source hi.source true))) tableSlot := by
  obtain ⟨service,valueCursor,lo,hi,trace,closed,right,valueValid,loLive,hiLive,decoded,valueTrace,_⟩ :=
    EvaluateLiteralRHSTrace.source_rhs_traced code lib ctx n base magSlot nodeSlot magLocal signLocal
      magLive magAt negativeAt nodeAt denWindow positive scale room
  have arrayAfter : EvaluateArrayStore.At valueCursor.state cells tableSlot := by
    rw [valueTrace]
    exact EvaluateArrayStore.advance ctx array trace
  have counterSafe:=LocalBinding.noncounter_separated ctx counter (by decide +kernel)
  have counterAfter : LocalBinding.At valueCursor.state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) counterSlot := by
    rw [valueTrace]
    exact LocalBinding.advance counter trace counterSafe.1 counterSafe.2.1 counterSafe.2.2
  let value:=DyadicCasts.value lo.source hi.source true
  let out : Cursor := {valueCursor with state:=EvaluateArrayStore.changed valueCursor.state cells tableSlot k value}
  have cast : castValue Header.layout valueCursor.state 100 "I" value=some value :=
    DyadicCasts.record _ 97 "I" (by decide +kernel) _ _ true
      (Endpoint.cast 97 "S" (by decide +kernel) loLive) (Endpoint.cast 97 "S" (by decide +kernel) hiLive)
  have expression := EvaluateArrayStore.source_assignment service 998 right arrayAfter counterAfter bound cast
  have run : Run Header.layout service EvaluateSyntax.literalCommit c.state (.continuing out.state) := by
    rw [EvaluateLiteralRHS.actual_literal_commit]
    exact Loops.StmtRun.evaluate ⟨1001,expression⟩
  have safe:=EvaluateArrayStore.separated valueValid arrayAfter
  have outValid : Valid l out := by
    constructor
    · exact valueValid.global_pool
    · exact valueValid.global_top
    · exact valueValid.global_high
    · simpa only [out,EvaluateArrayStore.changed,List.getElem?_set_ne safe.1] using valueValid.pool_read
    · simpa only [out,EvaluateArrayStore.changed,List.getElem?_set_ne safe.2.1] using valueValid.top_read
    · simpa only [out,EvaluateArrayStore.changed,List.getElem?_set_ne safe.2.2] using valueValid.high_read
    · exact valueValid.extent
    · exact valueValid.high_range
    · exact valueValid.top_range
  refine ⟨service,out,lo,hi,closed,run,outValid,loLive,hiLive,decoded,?_⟩
  constructor
  · exact arrayAfter.lookup
  · have present:=(List.getElem?_eq_some_iff.mp arrayAfter.memory).choose
    simp only [out,EvaluateArrayStore.changed,List.getElem?_set_self present]
    rfl

end ScopedC.EvaluateLiteralCommit
