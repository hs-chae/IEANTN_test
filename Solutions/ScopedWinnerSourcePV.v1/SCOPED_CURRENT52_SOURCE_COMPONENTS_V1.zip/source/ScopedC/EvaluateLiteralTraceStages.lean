/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.EvaluateLiteralRationalStages
import ScopedC.SourceIconstTrace
namespace ScopedC.EvaluateLiteralTraceStages
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.DecimalText
open ScopedC.RationalPairFrames (Input)
open ScopedC.EvaluateLiteralRationalStages (Library signedCursor rationalCursor)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (n : ScopedNumerical.Input.Node)
    (base magSlot nodeSlot : Nat) where
  denominator : Cursor
  denSlot : Nat
  q : Input
  out : Cursor
  lo : Endpoint
  hi : Endpoint
  makeCall : SourceCall Header.layout code 4 "smake" [.natObject magSlot,NatWrapperCalls.unsigned32 (EvaluateLiteral.flag n)]
    c.state (EvaluateLiteralSigned.endpoint magSlot n.num).source (signedCursor l c).state
  decimalCall : SourceCall Header.layout code 3 "decimal" [.pointer ⟨base+1,0,[]⟩ false]
    (signedCursor l c).state (.natObject denSlot) denominator.state
  qmCall : SourceCall Header.layout code 5 "qm" [(EvaluateLiteralSigned.endpoint magSlot n.num).source,.natObject denSlot]
    denominator.state q.source (rationalCursor l denominator n magSlot).state
  iconstCall : SourceCall Header.layout code 9 "iconst" [q.source] (rationalCursor l denominator n magSlot).state
    (DyadicCasts.value lo.source hi.source true) out.state
  nodeAfterMake : LocalBinding.At (signedCursor l c).state "n" "Node" (DataNode.represented base n) nodeSlot
  outValid : Valid l out
  loLive : lo.Live out.state
  hiLive : hi.Live out.state
  decoded : DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
    some (IntervalDyadic.ofIntervalRat (IntervalRat.singleton (mkRat n.num n.den)) (-100),true)
  trace : List Nat
  outTrace : out=CursorFrames.advance l c trace
  traceLength : trace.length ≤ 45+4*(digits n.den).length

/-- Execute the literal's actual smake, denominator parser, normalized rational
constructor and dyadic singleton. Each successive source call consumes the
prior source output. No magnitude, denominator or final value is trusted. -/
theorem stages_exist (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (n : ScopedNumerical.Input.Node) (base magSlot nodeSlot : Nat)
    (magLive : NatArena.Borrow c.state.nats magSlot n.num.natAbs)
    (nodeAt : LocalBinding.At c.state "n" "Node" (DataNode.represented base n) nodeSlot)
    (denWindow : DecimalBuffer.At c.state ⟨base+1,0,[]⟩ (digits n.den)) (positive : 0 < n.den)
    {scaleObject scaleSlot : Nat} (scale : SourceFromS.ScaleAt c.state scaleObject scaleSlot (2^100))
    (room : c.top+44+4*(digits n.den).length < capacity) :
    Nonempty (Stages code l c n base magSlot nodeSlot) := by
  let c1 := signedCursor l c
  let num := EvaluateLiteralSigned.endpoint magSlot n.num
  have makeCall := EvaluateLiteralSigned.smake_source code lib.smake lib.nz lib.nu lib.ne lib.keep ctx n magSlot magLive (by omega)
  have valid1 : Valid l c1 := next_valid 0 ctx (by omega)
  have bufferSafe := DecimalBuffer.separate denWindow ctx
  have buffer1 : DecimalBuffer.At c1.state ⟨base+1,0,[]⟩ (digits n.den) :=
    DecimalExpressions.next_buffer denWindow 0 bufferSafe.1 bufferSafe.2.1 bufferSafe.2.2
  have scale1 : SourceFromS.ScaleAt c1.state scaleObject scaleSlot (2^100) :=
    SourceScaleFrames.advance ctx scale [0]
  have nodeSafe := LocalBinding.noncounter_separated ctx nodeAt (by decide +kernel)
  have nodeAfterMake : LocalBinding.At c1.state "n" "Node" (DataNode.represented base n) nodeSlot :=
    LocalBinding.advance nodeAt [0] nodeSafe.1 nodeSafe.2.1 nodeSafe.2.2
  obtain ⟨denominator,denSlot,decimalCall,denLive,valid2,_,top2,_,_,_,_,trace2,preserves⟩ :=
    DecimalSource.decimal_traced code lib.decimal lib.nu lib.nm lib.na lib.keep valid1 buffer1 (digits_valid n.den)
      (by change c.top+1+4*(digits n.den).length < capacity;omega)
  have denExact : NatArena.Borrow denominator.state.nats denSlot n.den := by
    simpa only [DecimalText.digits_value] using denLive
  have numLive : num.Live denominator.state := preserves magSlot n.num.natAbs (PoolCursor.preserves (c:=c) magLive)
  have scale2 : SourceFromS.ScaleAt denominator.state scaleObject scaleSlot (2^100) := by
    rw [trace2]
    exact SourceScaleFrames.advance valid1 scale1 _
  have qmRoom : denominator.top+4 < capacity := by rw [top2];change c.top+1+1+4*(digits n.den).length+4 < capacity;omega
  have qm := NumericRationalMakeRefinement.qm_math code lib.qm lib.nz lib.ng lib.nd lib.smake lib.nu lib.ne lib.keep
    num numLive denExact positive valid2 qmRoom
  obtain ⟨q,qSource,qLive,qMath,qPositive⟩ := NumericInputCompleteness.rational qm.2.1
  have qValue : q.mathematical.value=mkRat n.num n.den := by
    rw [qMath,NumericRationalMakeRefinement.normalized_value _ _ positive,EvaluateLiteralSigned.endpoint_value,
      Rat.mkRat_eq_divInt,Rat.divInt_eq_div,Int.cast_natCast]
  have valid3 : Valid l (rationalCursor l denominator n magSlot) :=
    (RationalMakeCalls.contexts num n.den valid2 qmRoom).2.2.2.2
  have scale3 : SourceFromS.ScaleAt (rationalCursor l denominator n magSlot).state scaleObject scaleSlot (2^100) := by
    rw [rationalCursor,SourceFromSTrace.c5_advance]
    exact SourceScaleFrames.advance valid2 scale2 _
  have iconstRoom : (rationalCursor l denominator n magSlot).top+37 < capacity := by
    rw [rationalCursor,SourceFromSTrace.c5_advance,CursorFrames.top_advance,top2]
    change c.top+1+1+4*(digits n.den).length+5+37 < capacity
    omega
  obtain ⟨out,lo,hi,iconstTrace,iconstCall,outValid,loLive,hiLive,decoded,iconstOutTrace,iconstTraceLength⟩ :=
    SourceIconstTrace.iconst_traced code lib.iconst lib.point lib.fromRI lib.qt lib.floorQ lib.ceilQ lib.qn lib.sn
      lib.qtLib lib.roundLib valid3 q scale3 qLive qPositive iconstRoom
  have qmCall : SourceCall Header.layout code 5 "qm" [num.source,.natObject denSlot] denominator.state
      q.source (rationalCursor l denominator n magSlot).state := by
    rw [qSource]
    exact qm.1
  rw [qValue] at decoded
  let trace := [0]++(0::DecimalExpressions.allocationSteps 0 (digits n.den))++SourceFromSTrace.steps num n.den++iconstTrace
  have outTrace : out=CursorFrames.advance l c trace := by
    rw [iconstOutTrace,rationalCursor,SourceFromSTrace.c5_advance,trace2]
    simp only [trace,List.append_assoc,CursorSingleFrames.advance_append]
    rfl
  have decimalLength : (0::DecimalExpressions.allocationSteps 0 (digits n.den)).length=1+4*(digits n.den).length := by
    have h:=top2
    rw [trace2,CursorFrames.top_advance] at h
    omega
  have traceLength : trace.length ≤ 45+4*(digits n.den).length := by
    simp only [trace,List.length_append,List.length_cons,List.length_nil]
    change 1+(0::DecimalExpressions.allocationSteps 0 (digits n.den)).length+5+iconstTrace.length ≤ _
    omega
  exact ⟨⟨denominator,denSlot,q,out,lo,hi,makeCall,decimalCall,qmCall,iconstCall,nodeAfterMake,outValid,loLive,hiLive,decoded,trace,outTrace,traceLength⟩⟩


end ScopedC.EvaluateLiteralTraceStages
