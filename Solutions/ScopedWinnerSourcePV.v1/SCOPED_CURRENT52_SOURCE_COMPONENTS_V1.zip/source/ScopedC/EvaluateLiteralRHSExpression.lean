/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.EvaluateLiteralRHSTrace
namespace ScopedC.EvaluateLiteralRHSExpression
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.DecimalText
open ScopedC.EvaluateLiteralRationalStages (signedCursor rationalCursor)
open ScopedC.EvaluateLiteralTraceStages (Stages)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem expression {code : List Function} {l : PoolLayout} {c : Cursor} {n : ScopedNumerical.Input.Node}
    {base magSlot nodeSlot magLocal signLocal : Nat} (D : Stages code l c n base magSlot nodeSlot)
    (service : Call)
    (magAt : LocalBinding.At c.state "mag" "N" (.natObject magSlot) magLocal)
    (negativeAt : LocalBinding.At c.state "negative" "unsigned int"
      (NatWrapperCalls.unsigned32 (EvaluateLiteral.flag n)) signLocal)
    (answer1 : service "smake" [.natObject magSlot,NatWrapperCalls.unsigned32 (EvaluateLiteral.flag n)] c.state=
      some ((EvaluateLiteralSigned.endpoint magSlot n.num).source,(signedCursor l c).state))
    (answer2 : service "decimal" [.pointer ⟨base+1,0,[]⟩ false] (signedCursor l c).state=
      some (.natObject D.denSlot,D.denominator.state))
    (answer3 : service "qm" [(EvaluateLiteralSigned.endpoint magSlot n.num).source,.natObject D.denSlot] D.denominator.state=
      some (D.q.source,(rationalCursor l D.denominator n magSlot).state))
    (answer4 : service "iconst" [D.q.source] (rationalCursor l D.denominator n magSlot).state=
      some (DyadicCasts.value D.lo.source D.hi.source true,D.out.state)) :
    evalExpr Header.layout service 1000 c.state EvaluateLiteralRHS.rhs=
      some (DyadicCasts.value D.lo.source D.hi.source true,D.out.state) := by
  have signedExpr : evalExpr Header.layout service 998 c.state (.call (.var "smake") [.var "mag",.var "negative"])=
      some ((EvaluateLiteralSigned.endpoint magSlot n.num).source,(signedCursor l c).state) :=
    EvaluateLiteralSigned.smake_expression service magAt negativeAt answer1 996
  have denField : evalExpr Header.layout service 997 (signedCursor l c).state (.field "." (.var "n") "den")=
      some (.pointer ⟨base+1,0,[]⟩ false,(signedCursor l c).state) :=
    ExpressionTemplates.field Header.layout service
      (LocalBinding.eval service 995 D.nodeAfterMake (by decide +kernel) (by decide +kernel)
        (by decide +kernel) (by decide +kernel)) (DataReads.node_fields base n).2.2.2.2
  have denExpr : evalExpr Header.layout service 998 (signedCursor l c).state
      (.call (.var "decimal") [.field "." (.var "n") "den"])=some (.natObject D.denSlot,D.denominator.state) :=
    ExpressionTemplates.call_one Header.layout service denField answer2
  have rationalExpr : evalExpr Header.layout service 999 c.state (.call (.var "qm") [
      .call (.var "smake") [.var "mag",.var "negative"],.call (.var "decimal") [.field "." (.var "n") "den"]])=
      some (D.q.source,(rationalCursor l D.denominator n magSlot).state) :=
    ExpressionTemplates.call_two Header.layout service signedExpr denExpr answer3
  exact ExpressionTemplates.call_one Header.layout service rationalExpr answer4

end ScopedC.EvaluateLiteralRHSExpression
