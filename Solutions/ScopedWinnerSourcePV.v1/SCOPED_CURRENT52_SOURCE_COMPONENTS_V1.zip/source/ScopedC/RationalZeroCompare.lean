/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalUnsignedTrace
import ScopedC.DecimalDigits
import ScopedC.RationalCompareFraming
import ScopedC.SourceScaleFrames
namespace ScopedC.RationalZeroCompare
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.NumericRationalCompareRefinement (compareRat)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  qi : Generated.f_qi∈code
  si : Generated.f_si∈code
  qc : Generated.f_qc∈code
  sc : Generated.f_sc∈code
  sm : Generated.f_sm∈code
  nm : Generated.f_nm∈code
  smake : Generated.f_smake∈code
  nz : Generated.f_nz∈code
  nu : Generated.f_nu∈code
  ne : Generated.f_ne∈code
  nlt : Generated.f_nlt∈code
  keep : Generated.f_keep∈code

def first (l : PoolLayout) (c : Cursor) : Cursor := RationalUnsignedTrace.after l c 0
def zero (l : PoolLayout) (c : Cursor) : Input := RationalUnsignedTrace.output l c 0
def after (l : PoolLayout) (c : Cursor) (a : Input) : Cursor := RationalCompareCalls.final l (first l c) a (zero l c)
def steps (l : PoolLayout) (c : Cursor) (a : Input) : List Nat := [0,0,1]++RationalCompareFraming.steps a (zero l c)

theorem after_advance (l : PoolLayout) (c : Cursor) (a : Input) :
    after l c a=CursorFrames.advance l c (steps l c a) := by
  rw [after,RationalCompareFraming.final_eq_advance,steps,CursorSingleFrames.advance_append]
  rfl

theorem greater (s : State) (x : Rat) :
    binaryValue Header.layout s ">" (SignedCompareCalls.integer (compareRat x 0)) (DecimalDigits.integer 0)=
      some (boolean Header.layout (decide (0 < x))) := by
  rcases lt_trichotomy x 0 with negative|equal|positive
  · rw [compareRat,if_pos negative,show decide ((0:Rat)<x)=false from decide_eq_false (not_lt.mpr negative.le)]
    rfl
  · subst x
    rfl
  · rw [compareRat,if_neg (not_lt.mpr positive.le),if_neg (ne_of_gt positive),show decide ((0:Rat)<x)=true from decide_eq_true positive]
    rfl

theorem less (s : State) (x : Rat) :
    binaryValue Header.layout s "<" (SignedCompareCalls.integer (compareRat x 0)) (DecimalDigits.integer 0)=
      some (boolean Header.layout (decide (x < 0))) := by
  rcases lt_trichotomy x 0 with negative|equal|positive
  · rw [compareRat,if_pos negative,show decide (x<(0:Rat))=true from decide_eq_true negative]
    rfl
  · subst x
    rfl
  · rw [compareRat,if_neg (not_lt.mpr positive.le),if_neg (ne_of_gt positive),show decide (x<(0:Rat))=false from decide_eq_false (not_lt.mpr positive.le)]
    rfl

/-- Both actual callees in qc(endpoint,qi(0)); literal0 keeps its actual signed
C type before qi's proved unsigned parameter conversion. -/
theorem source_calls (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+8 < capacity) (a : Input) (live : a.Live c.state) (positive : 0 < a.denominator) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 0] c.state (zero l c).source (first l c).state ∧
    SourceCall Header.layout code 6 "qc" [a.source,(zero l c).source] (first l c).state
      (SignedCompareCalls.integer (compareRat a.mathematical.value 0)) (after l c a).state ∧
    Valid l (after l c a) := by
  have qi:=RationalUnsignedTrace.qi_traced code lib.qi lib.si lib.smake lib.nz lib.nu lib.ne lib.keep
    ctx 0 (by decide +kernel) (by omega) (DecimalDigits.integer 0) (by rfl)
  have endpointLive : a.Live (first l c).state :=
    ⟨CursorBorrow.preserves [0,0,1] live.1,CursorBorrow.preserves [0,0,1] live.2⟩
  have qcRoom : (first l c).top+5 < capacity := by change c.top+1+1+1+5 < capacity;omega
  have qc:=NumericRationalCompareRefinement.qc_math code lib.qc lib.sc lib.sm lib.nm lib.smake lib.nz lib.nu lib.ne lib.nlt lib.keep
    qi.2.1 qcRoom a (zero l c) endpointLive qi.2.2.1 positive (by change 0<(1:Nat);omega)
  have zeroValue : (zero l c).mathematical.value=0 := (RationalUnsignedTrace.mathematical l c 0).1
  rw [zeroValue] at qc
  exact ⟨qi.1,qc.1,RationalCompareCalls.final_context qi.2.1 qcRoom a (zero l c)⟩

/-- Actual signed C comparison condition around both source calls. The
argument-read premise describes an ordinary caller read, not a call output. -/
theorem condition (service : Call) (fuel : Nat) (positive : Bool) {l : PoolLayout} {c : Cursor} (a : Input) (arg : Expr)
    (argument : evalExpr Header.layout service (fuel+2) c.state arg=some (a.source,c.state))
    (qi : service "qi" [DecimalDigits.integer 0] c.state=some ((zero l c).source,(first l c).state))
    (qc : service "qc" [a.source,(zero l c).source] (first l c).state=
      some (SignedCompareCalls.integer (compareRat a.mathematical.value 0),(after l c a).state)) :
    evalExpr Header.layout service (fuel+4) c.state
      (.binary (if positive then ">" else "<") (.call (.var "qc") [arg,.call (.var "qi") [.nat 0]]) (.nat 0))=
      some (boolean Header.layout (if positive then decide (0<a.mathematical.value) else decide (a.mathematical.value<0)),(after l c a).state) := by
  have zeroExpr : evalExpr Header.layout service (fuel+2) c.state (.call (.var "qi") [.nat 0])=
      some ((zero l c).source,(first l c).state) := ExpressionTemplates.call_one Header.layout service (by rfl) qi
  have compareExpr : evalExpr Header.layout service (fuel+3) c.state (.call (.var "qc") [arg,.call (.var "qi") [.nat 0]])=
      some (SignedCompareCalls.integer (compareRat a.mathematical.value 0),(after l c a).state) :=
    ExpressionTemplates.call_two Header.layout service argument zeroExpr qc
  cases positive
  · exact ExpressionTemplates.binary Header.layout service (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) compareExpr (by rfl) (less _ _)
  · exact ExpressionTemplates.binary Header.layout service (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) compareExpr (by rfl) (greater _ _)

end ScopedC.RationalZeroCompare
