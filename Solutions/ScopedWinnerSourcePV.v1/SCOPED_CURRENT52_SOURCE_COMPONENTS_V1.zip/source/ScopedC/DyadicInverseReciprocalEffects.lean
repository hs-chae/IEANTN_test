/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseReciprocals
namespace ScopedC.DyadicInverseReciprocals.Stages
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
variable {code : List Function} {l : PoolLayout} {c : Cursor} {q : Pair}

theorem second_room (D : Stages code l c q) (ctx : Valid l c) (room : c.top+31 < capacity) :
    (middle D).top+15 < capacity := by
  rw [middle,RationalReciprocalLocal.top D.first ctx (by omega)]
  have h := RationalReciprocalCalls.length l c q.hi
  omega

theorem after_top (D : Stages code l c q) (ctx : Valid l c) (room : c.top+31 < capacity) :
    (after D).top ≤ c.top+32 := by
  rw [after,RationalReciprocalLocal.top D.second (RationalReciprocalLocal.after_valid D.first "l") (D.second_room ctx room)]
  rw [RationalReciprocalLocal.top D.first ctx (by omega)]
  have first := RationalReciprocalCalls.length l c q.hi
  have second := RationalReciprocalCalls.length l (middle D) q.lo
  dsimp only [middle] at second
  omega

theorem left_binding (D : Stages code l c q) (ctx : Valid l c) (room : c.top+31 < capacity) :
    LocalBinding.At (after D).state "l" "Q" D.first.output.source
      (RationalReciprocalCalls.after l c q.hi).state.heap.length :=
  RationalReciprocalLocal.preserve_binding D.second (RationalReciprocalLocal.after_valid D.first "l")
    (D.second_room ctx room) "h" (RationalReciprocalLocal.binding D.first "l")
    (by decide +kernel) (by decide +kernel)

theorem right_binding (D : Stages code l c q) :
    LocalBinding.At (after D).state "h" "Q" D.second.output.source
      (RationalReciprocalCalls.after l (middle D) q.lo).state.heap.length :=
  RationalReciprocalLocal.binding D.second "h"

theorem preserve_binding (D : Stages code l c q) (ctx : Valid l c) (room : c.top+31 < capacity)
    {name type : String} {value : Value} {slot : Nat}
    (h : LocalBinding.At c.state name type value slot) (typeDifferent : type≠"unsigned")
    (notLeft : "l"≠name) (notRight : "h"≠name) :
    LocalBinding.At (after D).state name type value slot := by
  have first := RationalReciprocalLocal.preserve_binding D.first ctx (by omega) "l" h typeDifferent notLeft
  exact RationalReciprocalLocal.preserve_binding D.second (RationalReciprocalLocal.after_valid D.first "l")
    (D.second_room ctx room) "h" first typeDifferent notRight

theorem first_live (D : Stages code l c q) (ctx : Valid l c) (room : c.top+31 < capacity) :
    D.first.output.Live (after D).state :=
  RationalReciprocalLocal.preserve_input D.second (RationalReciprocalLocal.after_valid D.first "l")
    (D.second_room ctx room) "h" D.first.output (RationalReciprocalLocal.output_live D.first "l")

theorem second_live (D : Stages code l c q) : D.second.output.Live (after D).state :=
  RationalReciprocalLocal.output_live D.second "h"

theorem scale (D : Stages code l c q) (ctx : Valid l c) (room : c.top+31 < capacity)
    {object slot d : Nat} (h : SourceFromS.ScaleAt c.state object slot d) :
    SourceFromS.ScaleAt (after D).state object slot d := by
  have first := RationalReciprocalLocal.scale D.first ctx (by omega) "l" h
  exact RationalReciprocalLocal.scale D.second (RationalReciprocalLocal.after_valid D.first "l")
    (D.second_room ctx room) "h" first

end ScopedC.DyadicInverseReciprocals.Stages
