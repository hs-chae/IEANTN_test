/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.LocalBinding
namespace ScopedC.LocalBinding
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Actual scalar local storage cannot alias the array pool; its declared
non-counter type also excludes either pool counter. This derives applicability
from physical types rather than imposing an application disjointness oracle. -/
theorem noncounter_separated {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    {name type : String} {value : Value} {slot : Nat} (h : At c.state name type value slot)
    (different : type≠"unsigned") : slot≠l.pool ∧ slot≠l.top ∧ slot≠l.high := by
  have hp : slot≠l.pool := by
    intro same
    have memory:=h.memory
    rw [same,ctx.pool_read] at memory
    have flags:=congrArg (fun x : Option Object=>x.map Object.isArray) memory
    change some true=some false at flags
    contradiction
  have ht : slot≠l.top := by
    intro same
    have memory:=h.memory
    rw [same,ctx.top_read] at memory
    have types:=congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "unsigned"=some type at types
    exact different (Option.some.inj types).symm
  have hh : slot≠l.high := by
    intro same
    have memory:=h.memory
    rw [same,ctx.high_read] at memory
    have types:=congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "unsigned"=some type at types
    exact different (Option.some.inj types).symm
  exact ⟨hp,ht,hh⟩

end ScopedC.LocalBinding
