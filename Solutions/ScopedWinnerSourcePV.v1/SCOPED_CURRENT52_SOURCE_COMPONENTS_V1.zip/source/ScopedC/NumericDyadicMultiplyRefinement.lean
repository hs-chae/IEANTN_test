/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicMultiplyBody
import ScopedC.DyadicRoundingValues
import ScopedC.NumericToRIRefinement
namespace ScopedC.NumericDyadicMultiplyRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.DyadicValueEquivalence
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicMultiplyStages (Library)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Exact original four-product dyadic multiplication has precisely the same
rational endpoints as the original four-product rational operation. -/
theorem mul_toIntervalRat (a b : IntervalDyadic) :
    IntervalRat.mul a.toIntervalRat b.toIntervalRat=(IntervalDyadic.mul a b).toIntervalRat := by
  simp only [IntervalDyadic.mul,IntervalDyadic.toIntervalRat,IntervalRat.mul,IntervalRat.mk.injEq]
  constructor <;> simp only [LeanCert.Core.Dyadic.min4,LeanCert.Core.Dyadic.max4,
    LeanCert.Core.Dyadic.min_toRat,LeanCert.Core.Dyadic.max_toRat,
    LeanCert.Core.Dyadic.toRat_mul,IntervalRat.min4,IntervalRat.max4]

private theorem rat_ext {a b : IntervalRat} (lo : a.lo=b.lo) (hi : a.hi=b.hi) : a=b := by
  cases a
  cases b
  simp_all

/-- Source-to-original-algorithm multiplication, including old inputs with
coarser but endpoint-value-equivalent exponents. The conclusion preserves
exact endpoint values and the actual flag; it never equates differing dyadic
representations merely because their values coincide. -/
theorem imul_math (code : List Function) (installed : Generated.f_imul∈code) (lib : Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : InputI)
    (ha : a.Live c.state) (hb : b.Live c.state)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (room : c.top+137 < capacity)
    (oldA oldB : IntervalDyadic) (repA : Represents c.state a.source oldA a.ok)
    (repB : Represents c.state b.source oldB b.ok) :
    ∃out : Cursor,∃lo hi : Endpoint,
      SourceCall Header.layout code 9 "imul" [a.source,b.source] c.state
        (DyadicCasts.value lo.source hi.source (a.ok&&b.ok)) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      Represents out.state (DyadicCasts.value lo.source hi.source (a.ok&&b.ok))
        ((IntervalDyadic.mul oldA oldB).roundOut (-100)) (a.ok&&b.ok) := by
  have aw := NumericToRIRefinement.represented_words a.lo a.hi a.ok ha.1 ha.2 oa oldA repA
  have bw := NumericToRIRefinement.represented_words b.lo b.hi b.ok hb.1 hb.2 ob oldB repB
  have ae : DyadicToRIPair.divided a (2^100) oa=oldA.toIntervalRat := rat_ext aw.1.symm aw.2.symm
  have be : DyadicToRIPair.divided b (2^100) ob=oldB.toIntervalRat := rat_ext bw.1.symm bw.2.symm
  obtain ⟨out,lo,hi,source,valid,loLive,hiLive,decoded⟩ :=
    DyadicMultiplyCalls.imul_closed code installed lib ctx a b ha hb oa ob scale room
  rw [ae,be,mul_toIntervalRat] at decoded
  exact ⟨out,lo,hi,source,valid,loLive,hiLive,_,decoded,DyadicRoundingValues.roundOut_values (IntervalDyadic.mul oldA oldB) 100⟩

end ScopedC.NumericDyadicMultiplyRefinement
