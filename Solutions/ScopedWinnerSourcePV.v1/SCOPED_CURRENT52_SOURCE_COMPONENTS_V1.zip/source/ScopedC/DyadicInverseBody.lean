/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseBodyRuns
import ScopedC.DyadicInverseAlgorithm
import ScopedC.DyadicToRIPair
import ScopedC.DyadicNatsExtensionality
namespace ScopedC.DyadicInverseCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicInverseBodyRuns (flagCursor)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000
attribute [local irreducible] RationalMakeCalls.c5 RationalSortCalls.after RationalReciprocalCalls.after

structure Library (code : List Function) : Prop where
  toRI : Generated.f_toRI∈code
  toRILib : ToRIStages.Library code
  compare : RationalZeroCompare.Library code
  reciprocal : DyadicInverseValidStages.Library code
  fallback : DyadicInverseFallbackStages.Library code

private theorem finish (code : List Function) (installed : Generated.f_iinv∈code)
    {c : Cursor} (a : InputI) (aLive : a.Live c.state)
    (service : Call)
    (closed : ∀name args before value after,service name args before=some (value,after) →
      SourceCall Header.layout code 8 name args before value after)
    (inner : Cursor) (lo hi : Endpoint) (ok : Bool) (loLive : lo.Live inner.state) (hiLive : hi.Live inner.state)
    (body : Run Header.layout service Generated.f_iinv.body (DyadicInverseConversion.parameters c a).state
      (.returned (popScope (DyadicInverseConversion.parameters c a).state inner.state) (DyadicCasts.value lo.source hi.source ok))) :
    SourceCall Header.layout code 9 "iinv" [a.source] c.state (DyadicCasts.value lo.source hi.source ok)
      (PoolContextPop.unframe c.state inner).state := by
  apply installed_body (f:=Generated.f_iinv) (rank:=8) (service:=service) installed closed
    (TypedFrames.bind_one Header.layout c.state "I" "a" a.source a.source
      (InputI.cast (s:={c.state with env:=[]}) aLive "I" (by decide +kernel))) body
  constructor
  · exact DyadicCasts.record _ 97 "static I" (by decide +kernel) lo.source hi.source ok
      (Endpoint.cast 97 "S" (by decide +kernel) loLive) (Endpoint.cast 97 "S" (by decide +kernel) hiLive)
  · exact (SourceFromS.scope_twice c.state (DyadicInverseConversion.parameters c a).state inner.state
      (by simp [DyadicInverseConversion.parameters,CursorSingleFrames.framed,OneFrames.frame,allocate])).symm

/-- Entire actual old iinv source body, both reciprocal and decimal10^30
fallback branches, typed declarations/return, actual short circuit and all
scopes. Its same source output equals the unchanged original inverse
algorithm at precision-100 and its original validity flag. -/
theorem iinv_closed (code : List Function) (installed : Generated.f_iinv∈code) (lib : Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : InputI) (aLive : a.Live c.state)
    (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (room : c.top+198 < capacity) :
    ∃out : Cursor,∃lo hi : Endpoint,
      SourceCall Header.layout code 9 "iinv" [a.source] c.state
        (DyadicCasts.value lo.source hi.source
          (a.ok&&DyadicInverseAlgorithm.good (DyadicToRIPair.divided a (2^100) ordered))) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state
        (DyadicCasts.value lo.source hi.source
          (a.ok&&DyadicInverseAlgorithm.good (DyadicToRIPair.divided a (2^100) ordered)))=
        some (IntervalDyadic.ofIntervalRat (LeanCert.Engine.invInterval (DyadicToRIPair.divided a (2^100) ordered)) (-100),
          a.ok&&DyadicInverseAlgorithm.good (DyadicToRIPair.divided a (2^100) ordered)) := by
  obtain ⟨D⟩ := DyadicInverseConversion.conversion_exists code lib.toRI lib.toRILib ctx a aLive ordered scale (by omega)
  have qTop := D.top
  have guardRoom : (DyadicInverseConversion.after D).top+17 < capacity := by rw [qTop];omega
  have fctx : Valid l (flagCursor D) := DyadicInverseFlagLocal.after_valid D.after_valid guardRoom D.interval
  have ftop : (flagCursor D).top ≤ c.top+28 := by
    change (DyadicInverseValidity.tested l (DyadicInverseConversion.after D) D.interval).top ≤ _
    rw [DyadicInverseValidity.tested_advance,CursorFrames.top_advance,qTop]
    have h := DyadicInverseValidity.steps_length l (DyadicInverseConversion.after D) D.interval
    omega
  have qLive : D.interval.Live (flagCursor D).state :=
    ⟨DyadicInverseFlagLocal.preserve_input D.interval D.interval.lo D.live.1,
     DyadicInverseFlagLocal.preserve_input D.interval D.interval.hi D.live.2⟩
  have fscale : SourceFromS.ScaleAt (flagCursor D).state object slot (2^100) :=
    DyadicInverseFlagLocal.scale D.after_valid D.interval (D.scale ctx scale)
  have guards := DyadicInverseAlgorithm.pair_good D.interval (DyadicToRIPair.divided a (2^100) ordered) D.low D.high
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  cases guard : DyadicInverseValidity.valid D.interval with
  | false =>
    have oldGuard : DyadicInverseAlgorithm.good (DyadicToRIPair.divided a (2^100) ordered)=false := guards.symm.trans guard
    have digitCount : (DecimalText.digits (10^30)).length=31 := by decide +kernel
    have space : (flagCursor D).top+46+4*(DecimalText.digits (10^30)).length < capacity := by rw [digitCount];omega
    obtain ⟨F⟩ := DyadicInverseFallbackStages.stages_exist code lib.fallback fctx (10^30) space fscale
    obtain ⟨service,closed,body⟩ := DyadicInverseBodyRuns.fallback_body code lib.compare D guardRoom F guard
    let out := PoolContextPop.unframe c.state F.rounded
    have call := finish code installed a aLive service closed F.rounded F.low F.high false F.lowLive F.highLive body
    have decoded := F.decoded
    rw [DyadicInverseAlgorithm.fallback_exact _ oldGuard] at decoded
    refine ⟨out,F.low,F.high,?_,PoolContextPop.valid F.valid hp ht hh,F.lowLive,F.highLive,?_⟩
    · simpa only [oldGuard,Bool.and_false] using call
    · rw [DyadicNatsExtensionality.interval (s:=out.state) (t:=F.rounded.state) (by rfl)]
      simpa only [oldGuard,Bool.and_false] using decoded
  | true =>
    have oldGuard : DyadicInverseAlgorithm.good (DyadicToRIPair.divided a (2^100) ordered)=true := guards.symm.trans guard
    have space : (flagCursor D).top+81 < capacity := by omega
    obtain ⟨V⟩ := DyadicInverseValidStages.stages_exist code lib.reciprocal fctx space D.interval qLive D.positive a.ok fscale
    obtain ⟨service,closed,body⟩ := DyadicInverseBodyRuns.valid_body code lib.compare D ctx guardRoom V fctx space guard
    let out := PoolContextPop.unframe c.state V.rounded
    have call := finish code installed a aLive service closed V.rounded V.low V.high a.ok V.lowLive V.highLive body
    have inverse := (DyadicInverseAlgorithm.pair_sorted D.interval
      (DyadicToRIPair.divided a (2^100) ordered) D.low D.high).trans
      (DyadicInverseAlgorithm.valid_exact _ oldGuard)
    have decoded := V.decoded
    rw [inverse] at decoded
    refine ⟨out,V.low,V.high,?_,PoolContextPop.valid V.valid hp ht hh,V.lowLive,V.highLive,?_⟩
    · simpa only [oldGuard,Bool.and_true] using call
    · rw [DyadicNatsExtensionality.interval (s:=out.state) (t:=V.rounded.state) (by rfl)]
      simpa only [oldGuard,Bool.and_true] using decoded

end ScopedC.DyadicInverseCalls
