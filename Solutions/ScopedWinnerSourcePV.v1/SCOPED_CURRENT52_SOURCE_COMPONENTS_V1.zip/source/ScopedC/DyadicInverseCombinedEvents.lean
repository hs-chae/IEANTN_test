/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseEventLemmas
namespace ScopedC.DyadicInverseCombinedEvents
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicInverseConversion (Conversion)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.DyadicInverseEventData (prefixEvents valid fallback)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000
attribute [local irreducible] RationalMakeCalls.c5 RationalSortCalls.after RationalReciprocalCalls.after
  DyadicInverseValidity.middle DyadicInverseValidity.finish RationalZeroCompare.first RationalZeroCompare.zero

/-- The potential unconsumed qi(0) guard call and the subsequent qi(1) body
call are distinct by their actual signed C arguments, even if their allocation
counts coincide. No output or function determinism assumption is required. -/
theorem valid_separate (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity)
    {l' : PoolLayout} {c' : Cursor} {q : Pair} (b : InputI)
    (V : DyadicInverseValidStages.Stages code l' c' q b.ok) :
    ∀x∈(prefixEvents code lib D room).map CallEvents.argumentKey,
      ∀y∈(valid code b V).map CallEvents.argumentKey,x≠y := by
  simp [prefixEvents,valid,CallEvents.argumentKey,DecimalDigits.integer]

theorem fallback_separate (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity)
    {l' : PoolLayout} {c' : Cursor} {n : Nat} (F : DyadicInverseFallbackStages.Stages code l' c' n) :
    ∀x∈(prefixEvents code lib D room).map CallEvents.argumentKey,
      ∀y∈(fallback code F).map CallEvents.argumentKey,x≠y := by
  simp [prefixEvents,fallback,CallEvents.argumentKey]

theorem valid_keys (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity)
    {l' : PoolLayout} {c' : Cursor} {q : Pair} (b : InputI)
    (V : DyadicInverseValidStages.Stages code l' c' q b.ok) (ctx : Valid l' c') (space : c'.top+81 < capacity) :
    ((prefixEvents code lib D room++valid code b V).map CallEvents.argumentKey).Nodup := by
  rw [List.map_append]
  exact List.nodup_append.mpr ⟨CallEvents.argument_nodup_of_keys _
      (DyadicInverseEventLemmas.prefix_keys code lib D room),
    CallEvents.argument_nodup_of_keys _ (DyadicInverseEventLemmas.valid_keys code b V ctx space),
    valid_separate code lib D room b V⟩

theorem fallback_keys (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity)
    {l' : PoolLayout} {c' : Cursor} {n : Nat} (F : DyadicInverseFallbackStages.Stages code l' c' n) :
    ((prefixEvents code lib D room++fallback code F).map CallEvents.argumentKey).Nodup := by
  rw [List.map_append]
  exact List.nodup_append.mpr ⟨CallEvents.argument_nodup_of_keys _
      (DyadicInverseEventLemmas.prefix_keys code lib D room),
    CallEvents.argument_nodup_of_keys _ (DyadicInverseEventLemmas.fallback_keys code F),
    fallback_separate code lib D room F⟩

end ScopedC.DyadicInverseCombinedEvents
