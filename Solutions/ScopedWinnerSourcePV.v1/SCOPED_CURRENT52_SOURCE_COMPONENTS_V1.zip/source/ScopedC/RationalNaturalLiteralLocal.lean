/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalNaturalLiteralEffects
import ScopedC.CursorLocals
namespace ScopedC.RationalNaturalLiteralLocal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalNaturalLiteral (Stages endpoint)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def initializer (n : Nat) : Expr := .call (.var "qm") [
  .call (.var "smake") [.call (.var "decimal") [.stringLiteral (toString n)],.nat 0],
  .call (.var "nu") [.nat 1]]
def after {code : List Function} {l : PoolLayout} {c : Cursor} {n : Nat} (D : Stages code l c n) : Cursor :=
  CursorLocals.allocated (RationalNaturalLiteral.after D) "Q" "wide" D.output.source

theorem expression (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : Stages code l c n)
    (decimal : service "decimal" [.pointer ⟨c.state.heap.length,0,[]⟩ false] (RationalNaturalLiteral.textCursor c n).state=
      some (.natObject D.magSlot,D.parsed.state))
    (smake : service "smake" [.natObject D.magSlot,DecimalDigits.integer 0] D.parsed.state=
      some ((endpoint D.magSlot n).source,(next l D.parsed 0).state))
    (nu : service "nu" [DecimalDigits.integer 1] (next l D.parsed 0).state=
      some (.natObject (next l D.parsed 0).state.nats.values.length,(next l (next l D.parsed 0) 1).state))
    (qm : service "qm" [(endpoint D.magSlot n).source,.natObject (next l D.parsed 0).state.nats.values.length]
      (next l (next l D.parsed 0) 1).state=some (D.output.source,(RationalNaturalLiteral.after D).state)) :
    evalExpr Header.layout service 1000 c.state (initializer n)=some (D.output.source,(RationalNaturalLiteral.after D).state) := by
  have text : evalExpr Header.layout service 997 c.state (.stringLiteral (toString n))=
      some (.pointer ⟨c.state.heap.length,0,[]⟩ false,(RationalNaturalLiteral.textCursor c n).state) :=
    DecimalText.evaluate_literal service c.state (toString n) (DecimalText.natural_ascii n) 996
  have parsed := ExpressionTemplates.call_one Header.layout service text decimal
  have signed : evalExpr Header.layout service 999 c.state
      (.call (.var "smake") [.call (.var "decimal") [.stringLiteral (toString n)],.nat 0])=
      some ((endpoint D.magSlot n).source,(next l D.parsed 0).state) :=
    ExpressionTemplates.call_two Header.layout service parsed (by rfl) smake
  have unit : evalExpr Header.layout service 999 (next l D.parsed 0).state (.call (.var "nu") [.nat 1])=
      some (.natObject (next l D.parsed 0).state.nats.values.length,(next l (next l D.parsed 0) 1).state) :=
    ExpressionTemplates.call_one Header.layout service (by rfl) nu
  exact ExpressionTemplates.call_two Header.layout service signed unit qm

theorem declaration (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : Stages code l c n)
    (decimal : service "decimal" [.pointer ⟨c.state.heap.length,0,[]⟩ false] (RationalNaturalLiteral.textCursor c n).state=
      some (.natObject D.magSlot,D.parsed.state))
    (smake : service "smake" [.natObject D.magSlot,DecimalDigits.integer 0] D.parsed.state=
      some ((endpoint D.magSlot n).source,(next l D.parsed 0).state))
    (nu : service "nu" [DecimalDigits.integer 1] (next l D.parsed 0).state=
      some (.natObject (next l D.parsed 0).state.nats.values.length,(next l (next l D.parsed 0) 1).state))
    (qm : service "qm" [(endpoint D.magSlot n).source,.natObject (next l D.parsed 0).state.nats.values.length]
      (next l (next l D.parsed 0) 1).state=some (D.output.source,(RationalNaturalLiteral.after D).state)) :
    Declare Header.layout service [{type:="Q",name:="wide",value:=some (initializer n)}] c.state (after D).state := by
  have expr := expression service D decimal smake nu qm
  have cast : castValue Header.layout (RationalNaturalLiteral.after D).state 100 "Q" D.output.source=some D.output.source :=
    RationalPairFrames.Input.cast "Q" (by decide +kernel) D.live
  change declarations Header.layout service [_] _ = _
  simp only [declarations,List.foldlM,expr,cast,Bind.bind,Option.bind]
  rfl

theorem binding {code : List Function} {l : PoolLayout} {c : Cursor} {n : Nat} (D : Stages code l c n) :
    LocalBinding.At (after D).state "wide" "Q" D.output.source (RationalNaturalLiteral.after D).state.heap.length :=
  LocalBinding.allocate_head (RationalNaturalLiteral.after D).state "wide" "Q" D.output.source rfl

end ScopedC.RationalNaturalLiteralLocal
