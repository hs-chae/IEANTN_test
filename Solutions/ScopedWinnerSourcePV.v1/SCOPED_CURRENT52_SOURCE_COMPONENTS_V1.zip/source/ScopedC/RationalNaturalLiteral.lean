/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.LiteralAllocationEffects
import ScopedC.DecimalSourceTrace
import ScopedC.NumericRationalCompleteness
import ScopedC.SourceFromSTrace
namespace ScopedC.RationalNaturalLiteral
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
open ScopedC.DecimalText (digits)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  decimal : Generated.f_decimal∈code
  nu : Generated.f_nu∈code
  nm : Generated.f_nm∈code
  na : Generated.f_na∈code
  keep : Generated.f_keep∈code
  smake : Generated.f_smake∈code
  nz : Generated.f_nz∈code
  ne : Generated.f_ne∈code
  qm : Generated.f_qm∈code
  ng : Generated.f_ng∈code
  nd : Generated.f_nd∈code

def textCursor (c : Cursor) (n : Nat) : Cursor := DecimalInitialized.inputCursor c (toString n)
def endpoint (slot n : Nat) : Endpoint := ⟨slot,n,false⟩

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (n : Nat) where
  parsed : Cursor
  magSlot : Nat
  parsedValid : Valid l parsed
  magLive : NatArena.Borrow parsed.state.nats magSlot n
  parserCall : SourceCall Header.layout code 3 "decimal" [.pointer ⟨c.state.heap.length,0,[]⟩ false]
    (textCursor c n).state (.natObject magSlot) parsed.state
  parserTrace : parsed=CursorFrames.advance l (textCursor c n)
    (0::DecimalExpressions.allocationSteps 0 (digits n))
  parserTop : parsed.top=c.top+1+4*(digits n).length
  makeCall : SourceCall Header.layout code 4 "smake" [.natObject magSlot,DecimalDigits.integer 0]
    parsed.state (endpoint magSlot n).source (next l parsed 0).state
  unitCall : SourceCall Header.layout code 2 "nu" [DecimalDigits.integer 1] (next l parsed 0).state
    (.natObject (next l parsed 0).state.nats.values.length) (next l (next l parsed 0) 1).state
  output : Input
  rationalCall : SourceCall Header.layout code 5 "qm"
    [(endpoint magSlot n).source,.natObject (next l parsed 0).state.nats.values.length]
    (next l (next l parsed 0) 1).state output.source
    (RationalMakeCalls.c5 l (next l (next l parsed 0) 1) (endpoint magSlot n) 1).state
  valid : Valid l (RationalMakeCalls.c5 l (next l (next l parsed 0) 1) (endpoint magSlot n) 1)
  live : output.Live (RationalMakeCalls.c5 l (next l (next l parsed 0) 1) (endpoint magSlot n) 1).state
  positive : 0<output.denominator
  value : output.mathematical.value=(n:Rat)

def after {code : List Function} {l : PoolLayout} {c : Cursor} {n : Nat} (D : Stages code l c n) : Cursor :=
  RationalMakeCalls.c5 l (next l (next l D.parsed 0) 1) (endpoint D.magSlot n) 1

/-- The complete source construction qm(smake(decimal(text),0),nu(1)) for
any natural decimal literal. The parser consumes the actual initialized byte
array and computes the magnitude; no hardcoded numerical output is a leaf. -/
theorem stages_exist (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (n : Nat) (room : c.top+7+4*(digits n).length < capacity) :
    Nonempty (Stages code l c n) := by
  have textValid : Valid l (textCursor c n) := DecimalInitialized.input_valid ctx _
  obtain ⟨parsed,slot,parser,live,pctx,buffer,top,heap,env,size,other,trace,preserved⟩ :=
    DecimalSource.decimal_traced code lib.decimal lib.nu lib.nm lib.na lib.keep textValid
      (DecimalText.natural_window c.state n) (DecimalText.digits_valid n) (by change c.top+4*(digits n).length < capacity;omega)
  have nLive : NatArena.Borrow parsed.state.nats slot n := by simpa only [DecimalText.digits_value] using live
  change parsed.top=c.top+1+4*(digits n).length at top
  have parsedRoom : parsed.top+6 < capacity := by rw [top];omega
  have make : SourceCall Header.layout code 4 "smake" [.natObject slot,DecimalDigits.integer 0]
      parsed.state (endpoint slot n).source (next l parsed 0).state := by
    have actual := SignedCalls.smake_call (neg:=0) (input:=DecimalDigits.integer 0)
      code lib.smake lib.nz lib.nu lib.ne lib.keep pctx (by omega) nLive (by decide +kernel) (by rfl)
    have zero : (if n==0 then 0 else 0)=0 := by split <;> rfl
    simpa only [zero,endpoint,Endpoint.source,SignedNegCalls.bit,Bool.false_eq_true,ite_false,PoolCursor.next] using actual
  have signedValid : Valid l (next l parsed 0) := next_valid 0 pctx (by omega)
  have unit : SourceCall Header.layout code 2 "nu" [DecimalDigits.integer 1] (next l parsed 0).state
      (.natObject (next l parsed 0).state.nats.values.length) (next l (next l parsed 0) 1).state :=
    NatWrapperCalls.nu_call code lib.nu lib.keep signedValid (by change parsed.top+1 < capacity;omega)
      (by decide +kernel) (by rfl)
  have unitValid : Valid l (next l (next l parsed 0) 1) := next_valid 1 signedValid (by change parsed.top+1 < capacity;omega)
  have magnitude : (endpoint slot n).Live (next l (next l parsed 0) 1).state :=
    PoolCursor.preserves (PoolCursor.preserves nLive)
  have unitLive := next_borrow l (next l parsed 0) 1
  have qmRoom : (next l (next l parsed 0) 1).top+4 < capacity := by change parsed.top+1+1+4 < capacity;omega
  have rational := NumericRationalMakeRefinement.qm_math code lib.qm lib.nz lib.ng lib.nd lib.smake lib.nu lib.ne lib.keep
    (endpoint slot n) magnitude unitLive (by decide +kernel) unitValid qmRoom
  obtain ⟨output,source,outputLive,mathematical,positive⟩ := NumericInputCompleteness.rational rational.2.1
  have rationalCall := rational.1
  rw [←source] at rationalCall
  have outValid : Valid l (RationalMakeCalls.c5 l (next l (next l parsed 0) 1) (endpoint slot n) 1) :=
    (RationalMakeCalls.contexts (endpoint slot n) 1 unitValid qmRoom).2.2.2.2
  have value : output.mathematical.value=(n:Rat) := by
    rw [mathematical,rational.2.2.2.2.1]
    simp [endpoint,Endpoint.mathematical,ScopedNumerical.Signed.value]
  exact ⟨⟨parsed,slot,pctx,nLive,parser,trace,top,make,unit,output,rationalCall,outValid,outputLive,positive,value⟩⟩

end ScopedC.RationalNaturalLiteral
