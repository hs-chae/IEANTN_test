/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseEventData
namespace ScopedC.DyadicInverseEventLemmas
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicInverseConversion (Conversion parameters)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalReciprocalCalls (oneInput oneCursor)
open ScopedC.DyadicInverseValidStages (sortCursor roundCursor sorted)
open ScopedC.DyadicInverseEventData (prefixEvents valid fallback prefix_length valid_length fallback_length)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000
attribute [local irreducible] RationalMakeCalls.c5 RationalSortCalls.after RationalReciprocalCalls.after
  DyadicInverseValidity.middle DyadicInverseValidity.finish RationalZeroCompare.first RationalZeroCompare.zero

theorem prefix_keys (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity) :
    ((prefixEvents code lib D room).map CallEvents.key).Nodup := by
  let start := DyadicInverseConversion.after D
  have loLive : D.interval.lo.Live start.state := D.live.1
  have hiLive : D.interval.hi.Live start.state := D.live.2
  have calls := DyadicInverseValidity.source_calls code lib D.after_valid room D.interval
    ⟨loLive,hiLive⟩ D.positive
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"toRI",[a.source],(parameters c a).state,D.interval.source,D.returned.state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.call⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 0],start.state,(RationalZeroCompare.zero l start).source,
      (RationalZeroCompare.first l start).state,SourceRanks.monotone (by omega : 6 ≤ 8) calls.1⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"qc",[D.interval.lo.source,(RationalZeroCompare.zero l start).source],
      (RationalZeroCompare.first l start).state,
      SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat D.interval.lo.mathematical.value 0),
      (DyadicInverseValidity.middle l start D.interval).state,SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.1⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 0],(DyadicInverseValidity.middle l start D.interval).state,
      (RationalZeroCompare.zero l (DyadicInverseValidity.middle l start D.interval)).source,
      (RationalZeroCompare.first l (DyadicInverseValidity.middle l start D.interval)).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.2.1⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qc",[D.interval.hi.source,(RationalZeroCompare.zero l (DyadicInverseValidity.middle l start D.interval)).source],
      (RationalZeroCompare.first l (DyadicInverseValidity.middle l start D.interval)).state,
      SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat D.interval.hi.mathematical.value 0),
      (DyadicInverseValidity.finish l start D.interval).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.2.2.1⟩
  let events := [e0,e1,e2,e3,e4]
  have middleSize : (DyadicInverseValidity.middle l start D.interval).state.nats.values.length=
      start.state.nats.values.length+9 := by
    rw [DyadicInverseValidity.middle,RationalZeroCompare.after_advance,CursorEffects.size]
    rfl
  have firstSize (x : Cursor) : (RationalZeroCompare.first l x).state.nats.values.length=
      x.state.nats.values.length+3 := by
    rw [RationalZeroCompare.first,RationalUnsignedTrace.after,CursorEffects.size]
    rfl
  have unique : (events.map CallEvents.key).Nodup := by
    simp only [events,List.map_cons,List.map_nil,CallEvents.key,e0,e1,e2,e3,e4]
    simp [List.nodup_cons,firstSize,middleSize]
  exact unique

theorem valid_keys (code : List Function) {l : PoolLayout} {c : Cursor} {q : Pair}
    (a : InputI) (D : DyadicInverseValidStages.Stages code l c q a.ok) (ctx : Valid l c) (room : c.top+81 < capacity) :
    ((valid code a D).map CallEvents.key).Nodup := by
  let first := D.reciprocals.first
  let next := DyadicInverseReciprocals.middle D.reciprocals
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 1],c.state,(oneInput l c).source,(oneCursor l c).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) first.oneCall⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"qv",[(oneInput l c).source,q.hi.source],(oneCursor l c).state,first.output.source,
      (RationalReciprocalCalls.after l c q.hi).state,SourceRanks.monotone (by omega : 7 ≤ 8) first.divideCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 1],next.state,(oneInput l next).source,(oneCursor l next).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) D.reciprocals.second.oneCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qv",[(oneInput l next).source,q.lo.source],(oneCursor l next).state,D.reciprocals.second.output.source,
      (RationalReciprocalCalls.after l next q.lo).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.reciprocals.second.divideCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qmin",[first.output.source,D.reciprocals.second.output.source],(sortCursor D.reciprocals).state,
      (sorted D.reciprocals).lo.source,
      (RationalSortCalls.middle l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.minCall⟩
  let e5 : CallEvents.Event Header.layout code 8 :=
    ⟨"qmax",[first.output.source,D.reciprocals.second.output.source],
      (RationalSortCalls.middle l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      (sorted D.reciprocals).hi.source,
      (RationalSortCalls.after l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.maxCall⟩
  let e6 : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[(sorted D.reciprocals).source,NatWrapperCalls.unsigned32 (SignedNegCalls.bit a.ok)],
      (roundCursor D.reciprocals).state,DyadicCasts.value D.low.source D.high.source a.ok,D.rounded.state,D.roundCall⟩
  let events := [e0,e1,e2,e3,e4,e5,e6]
  have size (x : Cursor) : (oneCursor l x).state.nats.values.length=x.state.nats.values.length+3 :=
    CursorEffects.size l x [1,0,1]
  have nextSize : next.state.nats.values.length=c.state.nats.values.length+(RationalReciprocalCalls.steps l c q.hi).length := by
    change (RationalReciprocalCalls.after l c q.hi).state.nats.values.length=_
    rw [RationalReciprocalCalls.after_advance ctx (by omega),CursorEffects.size]
  have lower : 7 ≤ (RationalReciprocalCalls.steps l c q.hi).length := by
    by_cases zero : q.hi.numerator.magnitude=0 <;>
      simp [RationalReciprocalCalls.steps,RationalDivideTrace.steps,zero,
        RationalDivideTrace.productSteps,RationalMultiplyTrace.steps]
  have qiDifferent : c.state.nats.values.length≠next.state.nats.values.length := by rw [nextSize];omega
  have qvDifferent : (oneCursor l c).state.nats.values.length≠(oneCursor l next).state.nats.values.length := by
    rw [size,size,nextSize]
    omega
  have unique : (events.map CallEvents.key).Nodup := by
    simpa [events,CallEvents.key,e0,e1,e2,e3,e4,e5,e6] using And.intro qiDifferent qvDifferent
  exact unique

theorem fallback_keys (code : List Function) {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : DyadicInverseFallbackStages.Stages code l c n) : ((fallback code D).map CallEvents.key).Nodup := by
  let N := D.literal
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"decimal",[.pointer ⟨c.state.heap.length,0,[]⟩ false],(RationalNaturalLiteral.textCursor c n).state,
      .natObject N.magSlot,N.parsed.state,SourceRanks.monotone (by omega : 3 ≤ 8) N.parserCall⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"smake",[.natObject N.magSlot,DecimalDigits.integer 0],N.parsed.state,
      (RationalNaturalLiteral.endpoint N.magSlot n).source,(next l N.parsed 0).state,
      SourceRanks.monotone (by omega : 4 ≤ 8) N.makeCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"nu",[DecimalDigits.integer 1],(next l N.parsed 0).state,
      .natObject (next l N.parsed 0).state.nats.values.length,(next l (next l N.parsed 0) 1).state,
      SourceRanks.monotone (by omega : 2 ≤ 8) N.unitCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qm",[(RationalNaturalLiteral.endpoint N.magSlot n).source,.natObject (next l N.parsed 0).state.nats.values.length],
      (next l (next l N.parsed 0) 1).state,N.output.source,(RationalNaturalLiteral.after N).state,
      SourceRanks.monotone (by omega : 5 ≤ 8) N.rationalCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qn",[N.output.source],(DyadicInverseFallbackStages.wideCursor N).state,(RationalSymmetricLocal.output N.output).lo.source,
      (next l (DyadicInverseFallbackStages.wideCursor N) 0).state,SourceRanks.monotone (by omega : 6 ≤ 8) D.negate⟩
  let e5 : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[(RationalSymmetricLocal.output N.output).source,DecimalDigits.integer 0],(DyadicInverseFallbackStages.roundCursor N).state,
      DyadicCasts.value D.low.source D.high.source false,D.rounded.state,D.roundCall⟩
  let events := [e0,e1,e2,e3,e4,e5]
  have unique : (events.map CallEvents.key).Nodup := by simp [events,CallEvents.key,e0,e1,e2,e3,e4,e5]
  exact unique

theorem prefix_run (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity) (service : Call)
    (answers : ∀e∈prefixEvents code lib D room,service e.name e.args e.before=some (e.value,e.after)) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      DyadicInversePrefix.statements (parameters c a).state
      (.continuing (DyadicInverseFlagLocal.after l (DyadicInverseConversion.after D) D.interval).state) := by
  exact DyadicInversePrefix.sequence service D
    (answers ((prefixEvents code lib D room)[0]'(by rw [prefix_length];omega)) (List.getElem_mem (by rw [prefix_length];omega)))
    (answers ((prefixEvents code lib D room)[1]'(by rw [prefix_length];omega)) (List.getElem_mem (by rw [prefix_length];omega)))
    (answers ((prefixEvents code lib D room)[2]'(by rw [prefix_length];omega)) (List.getElem_mem (by rw [prefix_length];omega)))
    (answers ((prefixEvents code lib D room)[3]'(by rw [prefix_length];omega)) (List.getElem_mem (by rw [prefix_length];omega)))
    (answers ((prefixEvents code lib D room)[4]'(by rw [prefix_length];omega)) (List.getElem_mem (by rw [prefix_length];omega)))

theorem valid_run (code : List Function) {l : PoolLayout} {c : Cursor} {q : Pair}
    (a : InputI) (D : DyadicInverseValidStages.Stages code l c q a.ok) (ctx : Valid l c) (room : c.top+81 < capacity)
    (qSlot aSlot : Nat) (qBinding : LocalBinding.At c.state "q" "RI" q.source qSlot)
    (aBinding : LocalBinding.At c.state "a" "I" a.source aSlot) (service : Call)
    (answers : ∀e∈valid code a D,service e.name e.args e.before=some (e.value,e.after)) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      DyadicInverseValidSource.statements c.state
      (.returned D.rounded.state (DyadicCasts.value D.low.source D.high.source a.ok)) := by
  exact DyadicInverseValidSource.sequence service a D ctx room qSlot aSlot qBinding aBinding
    (answers ((valid code a D)[0]'(by rw [valid_length];omega)) (List.getElem_mem (by rw [valid_length];omega)))
    (answers ((valid code a D)[1]'(by rw [valid_length];omega)) (List.getElem_mem (by rw [valid_length];omega)))
    (answers ((valid code a D)[2]'(by rw [valid_length];omega)) (List.getElem_mem (by rw [valid_length];omega)))
    (answers ((valid code a D)[3]'(by rw [valid_length];omega)) (List.getElem_mem (by rw [valid_length];omega)))
    (answers ((valid code a D)[4]'(by rw [valid_length];omega)) (List.getElem_mem (by rw [valid_length];omega)))
    (answers ((valid code a D)[5]'(by rw [valid_length];omega)) (List.getElem_mem (by rw [valid_length];omega)))
    (answers ((valid code a D)[6]'(by rw [valid_length];omega)) (List.getElem_mem (by rw [valid_length];omega)))

theorem fallback_run (code : List Function) {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : DyadicInverseFallbackStages.Stages code l c n) (service : Call)
    (answers : ∀e∈fallback code D,service e.name e.args e.before=some (e.value,e.after)) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      (DyadicInverseFallbackSource.statements n) c.state
      (.returned D.rounded.state (DyadicCasts.value D.low.source D.high.source false)) := by
  exact DyadicInverseFallbackSource.sequence service D
    (answers ((fallback code D)[0]'(by rw [fallback_length];omega)) (List.getElem_mem (by rw [fallback_length];omega)))
    (answers ((fallback code D)[1]'(by rw [fallback_length];omega)) (List.getElem_mem (by rw [fallback_length];omega)))
    (answers ((fallback code D)[2]'(by rw [fallback_length];omega)) (List.getElem_mem (by rw [fallback_length];omega)))
    (answers ((fallback code D)[3]'(by rw [fallback_length];omega)) (List.getElem_mem (by rw [fallback_length];omega)))
    (answers ((fallback code D)[4]'(by rw [fallback_length];omega)) (List.getElem_mem (by rw [fallback_length];omega)))
    (answers ((fallback code D)[5]'(by rw [fallback_length];omega)) (List.getElem_mem (by rw [fallback_length];omega)))

end ScopedC.DyadicInverseEventLemmas
