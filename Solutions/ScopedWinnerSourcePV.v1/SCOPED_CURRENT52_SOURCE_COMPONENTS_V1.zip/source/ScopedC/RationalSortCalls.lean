/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalHullData
import ScopedC.RationalCompareFraming
import ScopedC.CursorSingleFrames
namespace ScopedC.RationalSortCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

@[irreducible] def middle (l : PoolLayout) (c : Cursor) (a b : Input) : Cursor := RationalCompareCalls.final l c a b
def after (l : PoolLayout) (c : Cursor) (a b : Input) : Cursor := RationalCompareCalls.final l (middle l c a b) a b
def low (l : PoolLayout) (c : Cursor) (a b : Input) : Input := RationalSelectCalls.selected false "<=" l c a b
def high (l : PoolLayout) (c : Cursor) (a b : Input) : Input := RationalSelectCalls.selected true "<=" l (middle l c a b) a b
def output (l : PoolLayout) (c : Cursor) (a b : Input) : Pair := ⟨low l c a b,high l c a b⟩
def steps (a b : Input) : List Nat := RationalCompareFraming.steps a b++RationalCompareFraming.steps a b

theorem after_advance (l : PoolLayout) (c : Cursor) (a b : Input) :
    after l c a b=CursorFrames.advance l c (steps a b) := by
  rw [after,middle,RationalCompareFraming.final_eq_advance,RationalCompareFraming.final_eq_advance]
  exact (CursorSingleFrames.advance_append l c _ _).symm

theorem calls (code : List Function) (lib : RationalIntervalHullCalls.Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+11 < capacity)
    (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 7 "qmin" [a.source,b.source] c.state (low l c a b).source (middle l c a b).state ∧
    SourceCall Header.layout code 7 "qmax" [a.source,b.source] (middle l c a b).state
      (high l c a b).source (after l c a b).state ∧
    Valid l (after l c a b) ∧ (output l c a b).Live (after l c a b).state ∧
    (output l c a b).Positive ∧
    NumericRepresentation.interval (after l c a b).state (output l c a b).source=
      some (⟨min a.mathematical.value b.mathematical.value,max a.mathematical.value b.mathematical.value,
        le_trans (min_le_left _ _) (le_max_left _ _)⟩:IntervalRat) := by
  have first := NumericRationalSelectRefinement.qmin_math code lib.qmin lib.qc lib.sc lib.sm lib.nm lib.smake
    lib.nz lib.nu lib.ne lib.nlt lib.keep ctx (by omega) a b aLive bLive pa pb
  have middleValid : Valid l (middle l c a b) := by
    unfold middle
    exact RationalCompareCalls.final_context ctx (by omega) a b
  have middleTop : (middle l c a b).top=c.top+6 := by
    rw [middle,RationalCompareFraming.final_eq_advance,CursorFrames.top_advance]
    rfl
  have nextRoom : (middle l c a b).top+5 < capacity := by rw [middleTop];omega
  have aNext : a.Live (middle l c a b).state := by unfold middle;exact RationalSelectCalls.input_final aLive
  have bNext : b.Live (middle l c a b).state := by unfold middle;exact RationalSelectCalls.input_final bLive
  have second := NumericRationalSelectRefinement.qmax_math code lib.qmax lib.qc lib.sc lib.sm lib.nm lib.smake
    lib.nz lib.nu lib.ne lib.nlt lib.keep middleValid nextRoom a b aNext bNext pa pb
  have outValid : Valid l (after l c a b) := RationalCompareCalls.final_context middleValid nextRoom a b
  have lowLive : (low l c a b).Live (after l c a b).state := by
    have firstLive : (low l c a b).Live (middle l c a b).state := by
      unfold middle
      exact RationalIntervalHullCalls.selected_live false l c a b aLive bLive
    exact RationalSelectCalls.input_final (c:=middle l c a b) (a:=a) (b:=b) firstLive
  have highLive : (high l c a b).Live (after l c a b).state :=
    RationalIntervalHullCalls.selected_live true l (middle l c a b) a b aNext bNext
  have pl := RationalIntervalHullCalls.selected_positive false l c a b pa pb
  have ph := RationalIntervalHullCalls.selected_positive true l (middle l c a b) a b pa pb
  have dl := Input.decoded lowLive pl
  have dh := Input.decoded highLive ph
  have lv := NumericRationalSelectRefinement.minimum_value l c a b pa pb
  have hv := NumericRationalSelectRefinement.maximum_value l (middle l c a b) a b pa pb
  have firstCall : SourceCall Header.layout code 7 "qmin" [a.source,b.source] c.state
      (low l c a b).source (middle l c a b).state := by
    simpa only [low,middle] using first.1
  refine ⟨firstCall,second.1,outValid,⟨lowLive,highLive⟩,⟨pl,ph⟩,?_⟩
  simp only [output,Pair.source,NumericRepresentation.interval,IntervalCasts.value,dl,dh,
    Bind.bind,Option.bind,Pure.pure]
  change (low l c a b).mathematical.value=min a.mathematical.value b.mathematical.value at lv
  change (high l c a b).mathematical.value=max a.mathematical.value b.mathematical.value at hv
  simp [lv,hv,le_trans (min_le_left a.mathematical.value b.mathematical.value)
    (le_max_left a.mathematical.value b.mathematical.value)]

end ScopedC.RationalSortCalls
