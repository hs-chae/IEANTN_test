/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInversePrefix
import ScopedC.DyadicInverseValidCalls
import ScopedC.DyadicInverseFallbackSource
import ScopedC.CallEventArgumentRefinement
namespace ScopedC.DyadicInverseEventData
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicInverseConversion (Conversion parameters)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalReciprocalCalls (oneInput oneCursor)
open ScopedC.DyadicInverseValidStages (sortCursor roundCursor sorted)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000
attribute [local irreducible] RationalMakeCalls.c5 RationalSortCalls.after RationalReciprocalCalls.after

/-- Source-witness metadata reused for whole-body composition. Each entry
retains its complete previously proved lower actual-source execution. -/
def prefixEvents (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity) :
    List (CallEvents.Event Header.layout code 8) := by
  let start := DyadicInverseConversion.after D
  have loLive : D.interval.lo.Live start.state := D.live.1
  have hiLive : D.interval.hi.Live start.state := D.live.2
  have calls := DyadicInverseValidity.source_calls code lib D.after_valid room D.interval
    ⟨loLive,hiLive⟩ D.positive
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"toRI",[a.source],(parameters c a).state,D.interval.source,D.returned.state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.call⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 0],start.state,(RationalZeroCompare.zero l start).source,
      (RationalZeroCompare.first l start).state,SourceRanks.monotone (by omega : 6 ≤ 8) calls.1⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"qc",[D.interval.lo.source,(RationalZeroCompare.zero l start).source],
      (RationalZeroCompare.first l start).state,
      SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat D.interval.lo.mathematical.value 0),
      (DyadicInverseValidity.middle l start D.interval).state,SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.1⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 0],(DyadicInverseValidity.middle l start D.interval).state,
      (RationalZeroCompare.zero l (DyadicInverseValidity.middle l start D.interval)).source,
      (RationalZeroCompare.first l (DyadicInverseValidity.middle l start D.interval)).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.2.1⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qc",[D.interval.hi.source,(RationalZeroCompare.zero l (DyadicInverseValidity.middle l start D.interval)).source],
      (RationalZeroCompare.first l (DyadicInverseValidity.middle l start D.interval)).state,
      SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat D.interval.hi.mathematical.value 0),
      (DyadicInverseValidity.finish l start D.interval).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.2.2.1⟩
  let events := [e0,e1,e2,e3,e4]
  exact events

def valid (code : List Function) {l : PoolLayout} {c : Cursor} {q : Pair}
    (a : InputI) (D : DyadicInverseValidStages.Stages code l c q a.ok) :
    List (CallEvents.Event Header.layout code 8) := by
  let first := D.reciprocals.first
  let next := DyadicInverseReciprocals.middle D.reciprocals
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 1],c.state,(oneInput l c).source,(oneCursor l c).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) first.oneCall⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"qv",[(oneInput l c).source,q.hi.source],(oneCursor l c).state,first.output.source,
      (RationalReciprocalCalls.after l c q.hi).state,SourceRanks.monotone (by omega : 7 ≤ 8) first.divideCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 1],next.state,(oneInput l next).source,(oneCursor l next).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) D.reciprocals.second.oneCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qv",[(oneInput l next).source,q.lo.source],(oneCursor l next).state,D.reciprocals.second.output.source,
      (RationalReciprocalCalls.after l next q.lo).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.reciprocals.second.divideCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qmin",[first.output.source,D.reciprocals.second.output.source],(sortCursor D.reciprocals).state,
      (sorted D.reciprocals).lo.source,
      (RationalSortCalls.middle l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.minCall⟩
  let e5 : CallEvents.Event Header.layout code 8 :=
    ⟨"qmax",[first.output.source,D.reciprocals.second.output.source],
      (RationalSortCalls.middle l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      (sorted D.reciprocals).hi.source,
      (RationalSortCalls.after l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.maxCall⟩
  let e6 : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[(sorted D.reciprocals).source,NatWrapperCalls.unsigned32 (SignedNegCalls.bit a.ok)],
      (roundCursor D.reciprocals).state,DyadicCasts.value D.low.source D.high.source a.ok,D.rounded.state,D.roundCall⟩
  let events := [e0,e1,e2,e3,e4,e5,e6]
  exact events

def fallback (code : List Function) {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : DyadicInverseFallbackStages.Stages code l c n) :
    List (CallEvents.Event Header.layout code 8) := by
  let N := D.literal
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"decimal",[.pointer ⟨c.state.heap.length,0,[]⟩ false],(RationalNaturalLiteral.textCursor c n).state,
      .natObject N.magSlot,N.parsed.state,SourceRanks.monotone (by omega : 3 ≤ 8) N.parserCall⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"smake",[.natObject N.magSlot,DecimalDigits.integer 0],N.parsed.state,
      (RationalNaturalLiteral.endpoint N.magSlot n).source,(next l N.parsed 0).state,
      SourceRanks.monotone (by omega : 4 ≤ 8) N.makeCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"nu",[DecimalDigits.integer 1],(next l N.parsed 0).state,
      .natObject (next l N.parsed 0).state.nats.values.length,(next l (next l N.parsed 0) 1).state,
      SourceRanks.monotone (by omega : 2 ≤ 8) N.unitCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qm",[(RationalNaturalLiteral.endpoint N.magSlot n).source,.natObject (next l N.parsed 0).state.nats.values.length],
      (next l (next l N.parsed 0) 1).state,N.output.source,(RationalNaturalLiteral.after N).state,
      SourceRanks.monotone (by omega : 5 ≤ 8) N.rationalCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qn",[N.output.source],(DyadicInverseFallbackStages.wideCursor N).state,(RationalSymmetricLocal.output N.output).lo.source,
      (next l (DyadicInverseFallbackStages.wideCursor N) 0).state,SourceRanks.monotone (by omega : 6 ≤ 8) D.negate⟩
  let e5 : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[(RationalSymmetricLocal.output N.output).source,DecimalDigits.integer 0],(DyadicInverseFallbackStages.roundCursor N).state,
      DyadicCasts.value D.low.source D.high.source false,D.rounded.state,D.roundCall⟩
  let events := [e0,e1,e2,e3,e4,e5]
  exact events

theorem prefix_length (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity) : (prefixEvents code lib D room).length=5 := rfl

theorem valid_length (code : List Function) {l : PoolLayout} {c : Cursor} {q : Pair}
    (a : InputI) (D : DyadicInverseValidStages.Stages code l c q a.ok) : (valid code a D).length=7 := rfl

theorem fallback_length (code : List Function) {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : DyadicInverseFallbackStages.Stages code l c n) : (fallback code D).length=6 := rfl

end ScopedC.DyadicInverseEventData
