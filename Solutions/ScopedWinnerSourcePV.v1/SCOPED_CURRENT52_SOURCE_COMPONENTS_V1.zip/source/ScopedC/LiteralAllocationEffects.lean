/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalInitialized
import ScopedC.SourceScaleFrames
import ScopedC.LocalBinding
namespace ScopedC.LiteralAllocationEffects
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem scale {c : Cursor} {object slot d : Nat} (h : SourceFromS.ScaleAt c.state object slot d) (text : String) :
    SourceFromS.ScaleAt (DecimalInitialized.inputCursor c text).state object slot d := by
  have bound := (List.getElem?_eq_some_iff.mp h.storage).choose
  constructor
  · exact h.lookup
  · simpa only [DecimalInitialized.inputCursor,DecimalText.appendLiteral,List.getElem?_append_left bound] using h.storage
  · exact h.live

theorem binding {c : Cursor} {name type : String} {value : Value} {slot : Nat}
    (h : LocalBinding.At c.state name type value slot) (text : String) :
    LocalBinding.At (DecimalInitialized.inputCursor c text).state name type value slot := by
  have bound := (List.getElem?_eq_some_iff.mp h.memory).choose
  exact LocalBinding.memory h rfl (by
    simp only [DecimalInitialized.inputCursor,DecimalText.appendLiteral,List.getElem?_append_left bound])

end ScopedC.LiteralAllocationEffects
