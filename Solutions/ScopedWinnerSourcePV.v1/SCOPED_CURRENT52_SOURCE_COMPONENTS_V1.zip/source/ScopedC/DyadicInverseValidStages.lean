/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseReciprocalEffects
import ScopedC.RationalSortLocal
import ScopedC.SourceFromRIAnyFlag
import ScopedC.NumericNatsExtensionality
namespace ScopedC.DyadicInverseValidStages
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000
attribute [local irreducible] RationalSortCalls.after

structure Library (code : List Function) : Prop where
  qv : Generated.f_qv∈code
  divide : RationalDivideCalls.Library code
  select : RationalIntervalHullCalls.Library code
  fromRI : Generated.f_fromRI∈code
  qt : Generated.f_qt∈code
  floorQ : Generated.f_floorQ∈code
  ceilQ : Generated.f_ceilQ∈code
  qn : Generated.f_qn∈code
  sn : Generated.f_sn∈code
  qtLib : RationalMultiplyCalls.Library code
  roundLib : FloorQNegativeCalls.Library code

def reciprocalInterval (q : Pair) : IntervalRat :=
  ⟨min (1/q.hi.mathematical.value) (1/q.lo.mathematical.value),
    max (1/q.hi.mathematical.value) (1/q.lo.mathematical.value),
    le_trans (min_le_left _ _) (le_max_left _ _)⟩

def sortCursor {code : List Function} {l : PoolLayout} {c : Cursor} {q : Pair}
    (D : DyadicInverseReciprocals.Stages code l c q) : Cursor := DyadicInverseReciprocals.after D
def roundCursor {code : List Function} {l : PoolLayout} {c : Cursor} {q : Pair}
    (D : DyadicInverseReciprocals.Stages code l c q) : Cursor :=
  RationalSortLocal.after l (sortCursor D) D.first.output D.second.output
def sorted {code : List Function} {l : PoolLayout} {c : Cursor} {q : Pair}
    (D : DyadicInverseReciprocals.Stages code l c q) : Pair :=
  RationalSortCalls.output l (sortCursor D) D.first.output D.second.output

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (q : Pair) (ok : Bool) where
  reciprocals : DyadicInverseReciprocals.Stages code l c q
  minCall : SourceCall Header.layout code 7 "qmin" [reciprocals.first.output.source,reciprocals.second.output.source]
    (sortCursor reciprocals).state (sorted reciprocals).lo.source
    (RationalSortCalls.middle l (sortCursor reciprocals) reciprocals.first.output reciprocals.second.output).state
  maxCall : SourceCall Header.layout code 7 "qmax" [reciprocals.first.output.source,reciprocals.second.output.source]
    (RationalSortCalls.middle l (sortCursor reciprocals) reciprocals.first.output reciprocals.second.output).state
    (sorted reciprocals).hi.source
    (RationalSortCalls.after l (sortCursor reciprocals) reciprocals.first.output reciprocals.second.output).state
  sortedLive : (sorted reciprocals).Live
    (RationalSortCalls.after l (sortCursor reciprocals) reciprocals.first.output reciprocals.second.output).state
  rounded : Cursor
  low : Endpoint
  high : Endpoint
  trace : List Nat
  roundCall : SourceCall Header.layout code 8 "fromRI"
    [(sorted reciprocals).source,NatWrapperCalls.unsigned32 (SignedNegCalls.bit ok)] (roundCursor reciprocals).state
    (DyadicCasts.value low.source high.source ok) rounded.state
  valid : Valid l rounded
  lowLive : low.Live rounded.state
  highLive : high.Live rounded.state
  decoded : DyadicRepresentation.interval rounded.state (DyadicCasts.value low.source high.source ok)=
    some (IntervalDyadic.ofIntervalRat (reciprocalInterval q) (-100),ok)
  advance : rounded=CursorFrames.advance l (roundCursor reciprocals) trace
  length : trace.length ≤ 38

/-- Every numeric output on the valid suffix comes from its actual installed
qi/qv/qmin/qmax/fromRI source bodies and is consumed by the next such body.
The two declaration/return expression joins are separate source lemmas. -/
theorem stages_exist (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+81 < capacity) (q : Pair) (live : q.Live c.state)
    (positive : q.Positive) (ok : Bool) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) : Nonempty (Stages code l c q ok) := by
  obtain ⟨D⟩ := DyadicInverseReciprocals.stages_exist code lib.qv lib.divide ctx (by omega) q live positive
  have dctx : Valid l (sortCursor D) := D.after_valid
  have dtop : (sortCursor D).top ≤ c.top+32 := D.after_top ctx (by omega)
  have sortRoom : (sortCursor D).top+11 < capacity := by omega
  have sort := RationalSortCalls.calls code lib.select dctx sortRoom D.first.output D.second.output
    (D.first_live ctx (by omega)) D.second_live D.first.positive D.second.positive
  have rctx : Valid l (roundCursor D) := CursorLocals.allocated_valid sort.2.2.1 "RI" "r" (sorted D).source
  have rscale : SourceFromS.ScaleAt (roundCursor D).state object slot (2^100) :=
    RationalSortLocal.scale dctx D.first.output D.second.output (D.scale ctx (by omega) scale)
  have rtop : (roundCursor D).top=(sortCursor D).top+12 := by
    change (RationalSortCalls.after l (sortCursor D) D.first.output D.second.output).top=_
    rw [RationalSortCalls.after_advance,CursorFrames.top_advance]
    rfl
  have roundRoom : (roundCursor D).top+37 < capacity := by rw [rtop];omega
  have input : NumericRepresentation.interval (roundCursor D).state (sorted D).source=some (reciprocalInterval q) := by
    have initial := sort.2.2.2.2.2
    rw [D.lower_value,D.upper_value] at initial
    exact (NumericNatsExtensionality.interval
      (s:=(RationalSortCalls.after l (sortCursor D) D.first.output D.second.output).state)
      (t:=(roundCursor D).state) (by rfl) (sorted D).source).symm.trans initial
  obtain ⟨out,lo,hi,trace,call,valid,loLive,hiLive,decoded,advance,length⟩ :=
    SourceFromRIAnyFlag.source code lib.fromRI lib.qt lib.floorQ lib.ceilQ lib.qn lib.sn lib.qtLib lib.roundLib
      rctx (sorted D).source ok (NatWrapperCalls.unsigned32 (SignedNegCalls.bit ok)) (reciprocalInterval q)
      (by intro state;cases ok <;> rfl) rscale input roundRoom
  exact ⟨⟨D,sort.1,sort.2.1,sort.2.2.2.1,out,lo,hi,trace,call,valid,loLive,hiLive,decoded,advance,length⟩⟩

end ScopedC.DyadicInverseValidStages
