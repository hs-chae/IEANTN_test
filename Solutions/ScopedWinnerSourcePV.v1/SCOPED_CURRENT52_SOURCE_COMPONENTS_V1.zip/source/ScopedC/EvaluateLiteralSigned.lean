/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.EvaluateMagnitude
import ScopedC.SourceScaleFrames
import ScopedC.LocalBinding
namespace ScopedC.EvaluateLiteralSigned
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.NatWrapperCalls ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- The source flag has already been derived from the actual minus byte. -/
def sign (z : Int) : Bool := decide (z<0)
def endpoint (slot : Nat) (z : Int) : Endpoint :=
  ⟨slot,z.natAbs,if z.natAbs=0 then false else sign z⟩

theorem flag_bit (n : ScopedNumerical.Input.Node) : EvaluateLiteral.flag n=SignedNegCalls.bit (sign n.num) := by
  by_cases h : n.num<0 <;> simp [EvaluateLiteral.flag,sign,SignedNegCalls.bit,h]

theorem endpoint_value (slot : Nat) (z : Int) : (endpoint slot z).mathematical.value=z := by
  cases z with
  | ofNat n => simp [endpoint,sign,Endpoint.mathematical,ScopedNumerical.Signed.value,ScopedNumerical.Signed.make]
  | negSucc n =>
    have negative : Int.negSucc n<0 := by omega
    simp only [endpoint,show (Int.negSucc n).natAbs=n+1 from rfl,Nat.add_one_ne_zero,↓reduceIte,
      sign,decide_eq_true negative,Endpoint.mathematical,ScopedNumerical.Signed.value]
    omega

theorem endpoint_source (slot : Nat) (n : ScopedNumerical.Input.Node) :
    (endpoint slot n.num).source=SignedValues.value slot (if n.num.natAbs==0 then 0 else EvaluateLiteral.flag n) := by
  by_cases zero : n.num.natAbs=0 <;> simp [endpoint,Endpoint.source,SignedValues.value,SignedNegCalls.bit,zero,flag_bit]

/-- Actual smake called by the evaluate literal branch; the output's integer
value is the original signed source literal, including zero normalization. -/
theorem smake_source (code : List Function) (installed : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (n : ScopedNumerical.Input.Node) (slot : Nat)
    (live : NatArena.Borrow c.state.nats slot n.num.natAbs) (room : c.top < capacity) :
    SourceCall Header.layout code 4 "smake" [.natObject slot,unsigned32 (EvaluateLiteral.flag n)] c.state
      (endpoint slot n.num).source (next l c 0).state := by
  have flagBound : EvaluateLiteral.flag n<2^32 := by
    rw [flag_bit]
    exact SignedNegCalls.bit_bound _
  rw [endpoint_source]
  exact SignedCalls.smake_call code installed nzInstalled nuInstalled neInstalled keepInstalled ctx room live flagBound
    (PositiveCasts.cast_unsigned (allocate {c.state with env:=[]} "N" "mag" (some (.natObject slot))) 99 _ flagBound)

/-- The source expression reads its actual N and unsigned flag local cells
before invoking the already proved lower source execution. -/
theorem smake_expression (service : Call) {c out : Cursor} {n : ScopedNumerical.Input.Node}
    {slot magLocal signLocal : Nat}
    (magAt : LocalBinding.At c.state "mag" "N" (.natObject slot) magLocal)
    (negativeAt : LocalBinding.At c.state "negative" "unsigned int" (unsigned32 (EvaluateLiteral.flag n)) signLocal)
    (answer : service "smake" [.natObject slot,unsigned32 (EvaluateLiteral.flag n)] c.state=
      some ((endpoint slot n.num).source,out.state)) (fuel : Nat) :
    evalExpr Header.layout service (fuel+2) c.state (.call (.var "smake") [.var "mag",.var "negative"])=
      some ((endpoint slot n.num).source,out.state) :=
  ExpressionTemplates.call_two Header.layout service
    (LocalBinding.eval service fuel magAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (LocalBinding.eval service fuel negativeAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) answer

end ScopedC.EvaluateLiteralSigned
