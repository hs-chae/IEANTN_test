/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalUnsignedTrace
import ScopedC.DecimalDigits
import ScopedC.RationalDivideTrace
import ScopedC.NumericRationalCompleteness
namespace ScopedC.RationalReciprocalCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def oneCursor (l : PoolLayout) (c : Cursor) : Cursor := RationalUnsignedTrace.after l c 1
def oneInput (l : PoolLayout) (c : Cursor) : Input := RationalUnsignedTrace.output l c 1
def after (l : PoolLayout) (c : Cursor) (a : Input) : Cursor :=
  RationalDivideCalls.after l (oneCursor l c) (oneInput l c) a
def steps (l : PoolLayout) (c : Cursor) (a : Input) : List Nat :=
  [1,0,1]++RationalDivideTrace.steps l (oneCursor l c) (oneInput l c) a

/-- Constructed by the actual qi(1) and qv bodies, including the source's
explicit zero-divisor path. No reciprocal result is assumed as a service. -/
structure Result (code : List Function) (l : PoolLayout) (c : Cursor) (a : Input) where
  output : Input
  oneCall : SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1] c.state
    (oneInput l c).source (oneCursor l c).state
  divideCall : SourceCall Header.layout code 7 "qv" [(oneInput l c).source,a.source]
    (oneCursor l c).state output.source (after l c a).state
  valid : Valid l (after l c a)
  live : output.Live (after l c a).state
  positive : 0<output.denominator
  value : output.mathematical.value=1/a.mathematical.value

theorem result_exists (code : List Function) (installed : Generated.f_qv∈code)
    (lib : RationalDivideCalls.Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+15 < capacity) (a : Input)
    (live : a.Live c.state) (positive : 0<a.denominator) : Nonempty (Result code l c a) := by
  have qi := RationalUnsignedTrace.qi_traced code lib.qi lib.si lib.mul.smake lib.mul.nz lib.mul.nu lib.mul.ne lib.mul.keep
    ctx 1 (by decide +kernel) (by omega) (DecimalDigits.integer 1) (by rfl)
  have aLive : a.Live (oneCursor l c).state :=
    ⟨CursorBorrow.preserves [1,0,1] live.1,CursorBorrow.preserves [1,0,1] live.2⟩
  have divideRoom : (oneCursor l c).top+12 < capacity := by
    change c.top+1+1+1+12 < capacity
    omega
  have qv := NumericRationalDivideRefinement.qv_math code installed lib qi.2.1 divideRoom
    (oneInput l c) a qi.2.2.1 aLive (by change 0<(1:Nat);omega) positive
  obtain ⟨output,source,outputLive,mathematical,outputPositive⟩ := NumericInputCompleteness.rational qv.2.2.1
  have call := qv.1
  rw [←source] at call
  have value : output.mathematical.value=1/a.mathematical.value := by
    rw [mathematical,qv.2.2.2]
    have one : (oneInput l c).mathematical.value=1 := (RationalUnsignedTrace.mathematical l c 1).1
    rw [one]
  exact ⟨⟨output,qi.1,call,qv.2.1,outputLive,outputPositive,value⟩⟩

theorem after_advance {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+15 < capacity) (a : Input) : after l c a=CursorFrames.advance l c (steps l c a) := by
  have oneValid : Valid l (oneCursor l c) := CursorFrames.advance_valid ctx [1,0,1] (by change c.top+3 ≤ capacity;omega)
  have divideRoom : (oneCursor l c).top+12 < capacity := by change c.top+1+1+1+12 < capacity;omega
  rw [after,RationalDivideTrace.after_advance oneValid divideRoom]
  exact (CursorSingleFrames.advance_append l c [1,0,1] _).symm

theorem length (l : PoolLayout) (c : Cursor) (a : Input) : (steps l c a).length ≤ 16 := by
  have h := RationalDivideTrace.length l (oneCursor l c) (oneInput l c) a
  simp only [steps,List.length_append,List.length_cons,List.length_nil] at *
  omega

end ScopedC.RationalReciprocalCalls
