/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceScaleFrames
import ScopedC.DecimalSourceTrace
namespace ScopedC.ReadonlyCallEffects
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem scale_allocate {c : Cursor} {object slot d : Nat}
    (h : SourceFromS.ScaleAt c.state object slot d) (type name : String) (value : Option Value) :
    SourceFromS.ScaleAt (allocate c.state type name value) object slot d := by
  have bound:=(List.getElem?_eq_some_iff.mp h.storage).choose
  constructor
  · exact h.lookup
  · simpa only [allocate,List.getElem?_append_left bound] using h.storage
  · exact h.live

/-- Immutable source bytes remain readable through the exact allocation/keep
trace. Separation follows from their existing char-buffer type at the caller. -/
theorem buffer_advance {l : PoolLayout} {c : Cursor} {buf : Address} {digits : List Nat}
    (h : DecimalBuffer.At c.state buf digits) (trace : List Nat)
    (hp : buf.object≠l.pool) (ht : buf.object≠l.top) (hh : buf.object≠l.high) :
    DecimalBuffer.At (CursorFrames.advance l c trace).state buf digits := by
  induction trace generalizing c with
  | nil => exact h
  | cons n rest ih => exact ih (DecimalExpressions.next_buffer h n hp ht hh)

end ScopedC.ReadonlyCallEffects
