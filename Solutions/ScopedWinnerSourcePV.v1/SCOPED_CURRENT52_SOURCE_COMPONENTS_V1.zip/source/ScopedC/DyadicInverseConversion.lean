/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceToRI
import ScopedC.DyadicPairFrames
import ScopedC.ReadonlyCallEffects
import ScopedC.NumericIntervalCompleteness
namespace ScopedC.DyadicInverseConversion
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def parameters (c : Cursor) (a : InputI) : Cursor := CursorSingleFrames.framed c "I" "a" a.source

def initializer : Expr := .call (.var "toRI") [.var "a"]

structure Conversion (code : List Function) (l : PoolLayout) (c : Cursor) (a : InputI) where
  returned : Cursor
  interval : Pair
  call : SourceCall Header.layout code 7 "toRI" [a.source] (parameters c a).state interval.source returned.state
  trace : returned=CursorFrames.advance l (parameters c a) (ToRITrace.steps a.lo a.hi (2^100))
  valid : Valid l returned
  live : interval.Live returned.state
  positive : interval.Positive
  low : interval.lo.mathematical.value=(a.lo.mathematical.value:Rat)/(2^100:Nat)
  high : interval.hi.mathematical.value=(a.hi.mathematical.value:Rat)/(2^100:Nat)

def after {code : List Function} {l : PoolLayout} {c : Cursor} {a : InputI}
    (D : Conversion code l c a) : Cursor := CursorLocals.allocated D.returned "RI" "q" D.interval.source

/-- iinv's actual first conversion, executed from its real I parameter frame.
The returned RI value is inverted into a live physical pair by the proved
numeric decoder inverse, not supplied as initialized application state. -/
theorem conversion_exists (code : List Function) (installed : Generated.f_toRI∈code) (lib : ToRIStages.Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : InputI) (live : a.Live c.state)
    (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (room : c.top+9 < capacity) :
    Nonempty (Conversion code l c a) := by
  have frameValid : Valid l (parameters c a) := OneFrames.context_frame ctx "I" "a" a.source
  have frameScale : SourceFromS.ScaleAt (parameters c a).state object slot (2^100) :=
    SourceScaleFrames.framed scale "I" "a" a.source
  obtain ⟨returned,lo,hi,call,valid,loLive,hiLive,loPositive,hiPositive,trace,decoded⟩ :=
    SourceToRI.toRI_closed code installed lib frameValid a.lo a.hi a.ok frameScale (by positivity)
      live.1 live.2 ordered room
  obtain ⟨pair,source,livePair,positivePair,low,high⟩ := NumericInputCompleteness.interval decoded
  rw [←source] at call
  exact ⟨⟨returned,pair,call,trace,valid,livePair,positivePair,low,high⟩⟩

namespace Conversion
variable {code : List Function} {l : PoolLayout} {c : Cursor} {a : InputI}

theorem after_valid (D : Conversion code l c a) : Valid l (after D) :=
  CursorLocals.allocated_valid D.valid "RI" "q" D.interval.source

theorem q_binding (D : Conversion code l c a) :
    LocalBinding.At (after D).state "q" "RI" D.interval.source D.returned.state.heap.length :=
  LocalBinding.allocate_head D.returned.state "q" "RI" D.interval.source (Pair.initialized D.interval)

theorem a_binding (D : Conversion code l c a) (ctx : Valid l c) :
    LocalBinding.At (after D).state "a" "I" a.source c.state.heap.length := by
  have initial : LocalBinding.At (parameters c a).state "a" "I" a.source c.state.heap.length :=
    LocalBinding.allocate_head {c.state with env:=[]} "a" "I" a.source (InputI.initialized a)
  have hp:=(List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht:=(List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh:=(List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have parsed : LocalBinding.At D.returned.state "a" "I" a.source c.state.heap.length := by
    rw [D.trace]
    exact LocalBinding.advance initial (ToRITrace.steps a.lo a.hi (2^100)) (by omega) (by omega) (by omega)
  exact LocalBinding.allocate_other parsed "q" "RI" (some D.interval.source) (by decide +kernel)

theorem scale (D : Conversion code l c a) (ctx : Valid l c) {object slot : Nat}
    (h : SourceFromS.ScaleAt c.state object slot (2^100)) :
    SourceFromS.ScaleAt (after D).state object slot (2^100) := by
  have frameValid : Valid l (parameters c a) := OneFrames.context_frame ctx "I" "a" a.source
  have initial : SourceFromS.ScaleAt (parameters c a).state object slot (2^100) :=
    SourceScaleFrames.framed h "I" "a" a.source
  have returned : SourceFromS.ScaleAt D.returned.state object slot (2^100) := by
    rw [D.trace]
    exact SourceScaleFrames.advance frameValid initial _
  exact ReadonlyCallEffects.scale_allocate returned "RI" "q" (some D.interval.source)

theorem top (D : Conversion code l c a) : (after D).top=c.top+10 := by
  change D.returned.top=_
  rw [D.trace,CursorFrames.top_advance]
  rfl

/-- The actual RI declaration's argument read and typed source return value;
the service answer is closed by the preceding actual toRI execution. -/
theorem declaration (D : Conversion code l c a) (service : Call)
    (answer : service "toRI" [a.source] (parameters c a).state=some (D.interval.source,D.returned.state)) :
    Declare Header.layout service [{type:="RI",name:="q",value:=some initializer}]
      (parameters c a).state (after D).state := by
  have argument : evalExpr Header.layout service 999 (parameters c a).state (.var "a")=
      some (a.source,(parameters c a).state) :=
    TypedFrames.allocate_eval Header.layout service 998 {c.state with env:=[]} "I" "a" a.source
      (InputI.initialized a) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have expression : evalExpr Header.layout service 1000 (parameters c a).state initializer=
      some (D.interval.source,D.returned.state) := ExpressionTemplates.call_one Header.layout service argument answer
  have cast:=Pair.cast D.live "RI" (by decide +kernel)
  change declarations Header.layout service [_] _ = _
  simp only [declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

end Conversion
end ScopedC.DyadicInverseConversion
