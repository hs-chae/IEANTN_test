/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.EvaluateMagnitudeTrace
import ScopedC.EvaluateArrayStore
import ScopedC.EvaluateSyntax
namespace ScopedC.EvaluateMagnitudeCaller
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.EvaluateLiteral ScopedC.EvaluateMagnitude
open ScopedC.EvaluateMagnitudeTrace (Stages after)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

private theorem array_allocate {s : State} {cells : List (Option Value)} {slot : Nat}
    (h : EvaluateArrayStore.At s cells slot) (type name : String) (value : Option Value) (different : name≠"values") :
    EvaluateArrayStore.At (allocate s type name value) cells slot := by
  have bound:=(List.getElem?_eq_some_iff.mp h.memory).choose
  constructor
  · simp only [allocate,List.lookup]
    rw [show ("values"==name)=false from beq_eq_false_iff_ne.mpr (Ne.symm different)]
    exact h.lookup
  · simpa only [allocate,List.getElem?_append_left bound] using h.memory

theorem array {code : List Function} {l : PoolLayout} {c : Cursor} {base : Nat} {n : ScopedNumerical.Input.Node}
    (D : Stages code l c base n) (ctx : Valid l c) {cells : List (Option Value)} {slot : Nat}
    (h : EvaluateArrayStore.At c.state cells slot) : EvaluateArrayStore.At (after D).state cells slot := by
  have nodeArray : EvaluateArrayStore.At (nodeCursor c base n).state cells slot :=
    array_allocate h "Node" "n" (some (DataNode.represented base n)) (by decide +kernel)
  have flagArray : EvaluateArrayStore.At (flagged c base n).state cells slot :=
    array_allocate nodeArray "unsigned int" "negative" (some (NatWrapperCalls.unsigned32 (flag n))) (by decide +kernel)
  have parsedArray : EvaluateArrayStore.At D.parsed.state cells slot := by
    rw [D.parsedTrace]
    exact EvaluateArrayStore.advance (flagged_valid ctx base n) flagArray D.trace
  exact array_allocate parsedArray "N" "mag" (some (.natObject D.slot)) (by decide +kernel)

theorem counter {code : List Function} {l : PoolLayout} {c : Cursor} {base : Nat} {n : ScopedNumerical.Input.Node}
    (D : Stages code l c base n) (ctx : Valid l c) {k slot : Nat}
    (h : LocalBinding.At c.state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) slot) :
    LocalBinding.At (after D).state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) slot := by
  have nodeAt : LocalBinding.At (nodeCursor c base n).state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) slot :=
    LocalBinding.allocate_other h "n" "Node" (some (DataNode.represented base n)) (by decide +kernel)
  have flagAt : LocalBinding.At (flagged c base n).state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) slot :=
    LocalBinding.allocate_other nodeAt "negative" "unsigned int" (some (NatWrapperCalls.unsigned32 (flag n))) (by decide +kernel)
  have safe:=LocalBinding.noncounter_separated (flagged_valid ctx base n) flagAt (by decide +kernel)
  have parsedAt : LocalBinding.At D.parsed.state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) slot := by
    rw [D.parsedTrace]
    exact LocalBinding.advance flagAt D.trace safe.1 safe.2.1 safe.2.2
  exact LocalBinding.allocate_other parsedAt "mag" "N" (some (.natObject D.slot)) (by decide +kernel)

/-- The two actual declarations, with a caller-supplied service answer that
must be closed by the corresponding actual decimal source execution. -/
theorem source_prefix {code : List Function} {l : PoolLayout} {c : Cursor} {base : Nat} {n : ScopedNumerical.Input.Node}
    (D : Stages code l c base n) (service : Call)
    (num : c.state.heap[base]?=some (DecimalText.literalObject (toString n.num)))
    (answer : service "decimal" [.pointer ⟨base,DecimalText.offset n.num,[]⟩ false] (flagged c base n).state=
      some (.natObject D.slot,D.parsed.state)) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      [EvaluateSyntax.negativeDecl,EvaluateSyntax.magnitudeDecl]
      (nodeCursor c base n).state (.continuing (after D).state) := by
  have expression : evalExpr Header.layout service 1000 (flagged c base n).state
      (.call (.var "decimal") [pointerExpr])=some (.natObject D.slot,D.parsed.state) :=
    ExpressionTemplates.call_one Header.layout service (source_pointer service 996 num) answer
  have cast:=PrimitiveCalls.cast_N D.live
  have declaration : Declare Header.layout service [{type:="N",name:="mag",value:=some (.call (.var "decimal") [pointerExpr])}]
      (flagged c base n).state (after D).state := by
    change declarations Header.layout service [_] _ = _
    simp only [declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
    rfl
  exact Loops.SeqRun.next (Loops.StmtRun.declare (negative_declaration service num))
    (Loops.SeqRun.next (Loops.StmtRun.declare declaration) (Loops.SeqRun.nil _))

end ScopedC.EvaluateMagnitudeCaller
