/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEventArgumentKeys
import ScopedC.CallEventKeys
namespace ScopedC.CallEvents
open ScopedC.Syntax ScopedC.Machine
set_option autoImplicit false

theorem argument_nodup_of_keys {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map key).Nodup) :
    (events.map argumentKey).Nodup := by
  apply List.Nodup.of_map (f:=fun x : String×List Value×Nat=>(x.1,x.2.2))
  rw [List.map_map]
  change (events.map key).Nodup
  exact unique

end ScopedC.CallEvents
