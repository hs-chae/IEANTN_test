/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseValidity
namespace ScopedC.DyadicInverseFlagLocal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.DyadicInverseValidity (valid tested steps)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def after (l : PoolLayout) (c : Cursor) (a : Pair) : Cursor :=
  CursorLocals.allocated (tested l c a) "unsigned int" "valid" (NatWrapperCalls.unsigned32 (SignedNegCalls.bit (valid a)))

theorem after_valid {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+17 < capacity) (a : Pair) :
    Valid l (after l c a) := by
  have stateValid : Valid l (tested l c a) := by
    rw [DyadicInverseValidity.tested_advance]
    exact CursorFrames.advance_valid ctx _ (by have h:=DyadicInverseValidity.steps_length l c a;omega)
  exact CursorLocals.allocated_valid stateValid "unsigned int" "valid" _

theorem flag_binding (l : PoolLayout) (c : Cursor) (a : Pair) :
    LocalBinding.At (after l c a).state "valid" "unsigned int"
      (NatWrapperCalls.unsigned32 (SignedNegCalls.bit (valid a))) (tested l c a).state.heap.length :=
  LocalBinding.allocate_head (tested l c a).state "valid" "unsigned int" _ rfl

theorem preserve_binding {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair)
    {name type : String} {value : Value} {slot : Nat} (h : LocalBinding.At c.state name type value slot)
    (typeDifferent : type≠"unsigned") (nameDifferent : "valid"≠name) :
    LocalBinding.At (after l c a).state name type value slot := by
  have safe:=LocalBinding.noncounter_separated ctx h typeDifferent
  have testedBinding : LocalBinding.At (tested l c a).state name type value slot := by
    rw [DyadicInverseValidity.tested_advance]
    exact LocalBinding.advance h _ safe.1 safe.2.1 safe.2.2
  exact LocalBinding.allocate_other testedBinding "valid" "unsigned int" _ nameDifferent

theorem preserve_input {l : PoolLayout} {c : Cursor} (a : Pair) (q : RationalPairFrames.Input) (h : q.Live c.state) :
    q.Live (after l c a).state := by
  change q.Live (tested l c a).state
  rw [DyadicInverseValidity.tested_advance]
  exact ⟨CursorBorrow.preserves _ h.1,CursorBorrow.preserves _ h.2⟩

theorem scale {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) {object slot d : Nat}
    (h : SourceFromS.ScaleAt c.state object slot d) : SourceFromS.ScaleAt (after l c a).state object slot d := by
  have testedScale : SourceFromS.ScaleAt (tested l c a).state object slot d := by
    rw [DyadicInverseValidity.tested_advance]
    exact SourceScaleFrames.advance ctx h _
  exact ReadonlyCallEffects.scale_allocate testedScale "unsigned int" "valid" _

theorem invalid_expression (service : Call) (fuel : Nat) (l : PoolLayout) (c : Cursor) (a : Pair) :
    evalExpr Header.layout service (fuel+2) (after l c a).state (.unary "!" (.var "valid"))=
      some (boolean Header.layout (!(valid a)),(after l c a).state) := by
  rw [evalExpr,LocalBinding.eval service fuel (flag_binding l c a) (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)]
  cases h:valid a <;> rfl

theorem declaration (service : Call) {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (slot : Nat)
    (binding : LocalBinding.At c.state "q" "RI" a.source slot)
    (qiLo : service "qi" [DecimalDigits.integer 0] c.state=
      some ((RationalZeroCompare.zero l c).source,(RationalZeroCompare.first l c).state))
    (qcLo : service "qc" [a.lo.source,(RationalZeroCompare.zero l c).source] (RationalZeroCompare.first l c).state=
      some (SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat a.lo.mathematical.value 0),
        (DyadicInverseValidity.middle l c a).state))
    (qiHi : service "qi" [DecimalDigits.integer 0] (DyadicInverseValidity.middle l c a).state=
      some ((RationalZeroCompare.zero l (DyadicInverseValidity.middle l c a)).source,
        (RationalZeroCompare.first l (DyadicInverseValidity.middle l c a)).state))
    (qcHi : service "qc" [a.hi.source,(RationalZeroCompare.zero l (DyadicInverseValidity.middle l c a)).source]
      (RationalZeroCompare.first l (DyadicInverseValidity.middle l c a)).state=
      some (SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat a.hi.mathematical.value 0),
        (DyadicInverseValidity.finish l c a).state)) :
    Declare Header.layout service [{type:="unsigned int",name:="valid",value:=some DyadicInverseValidity.expression}]
      c.state (after l c a).state := by
  have expression:=DyadicInverseValidity.source_expression service ctx a slot binding qiLo qcLo qiHi qcHi
  have cast : castValue Header.layout (tested l c a).state 100 "unsigned int" (boolean Header.layout (valid a))=
      some (NatWrapperCalls.unsigned32 (SignedNegCalls.bit (valid a))) := by
    cases h:valid a <;> rfl
  change declarations Header.layout service [_] _ = _
  simp only [declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

end ScopedC.DyadicInverseFlagLocal
