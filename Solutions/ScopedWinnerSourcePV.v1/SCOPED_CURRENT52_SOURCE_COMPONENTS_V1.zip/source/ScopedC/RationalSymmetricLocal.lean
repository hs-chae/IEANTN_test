/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSubData
import ScopedC.RationalIntervalFrames
import ScopedC.LocalBindingSeparation
import ScopedC.ReadonlyCallEffects
namespace ScopedC.RationalSymmetricLocal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def output (a : Input) : Pair := ⟨RationalSubCalls.negative a,a⟩
def after (l : PoolLayout) (c : Cursor) (a : Input) : Cursor :=
  CursorLocals.allocated (next l c 0) "RI" "r" (output a).source
def initializer : Syntax.Expr := .record [.call (.var "qn") [.var "wide"],.var "wide"]

theorem source_call (code : List Function) (installed : Generated.f_qn∈code)
    (snInstalled : Generated.f_sn∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top < capacity)
    (a : Input) (live : a.Live c.state) (positive : 0<a.denominator) :
    SourceCall Header.layout code 6 "qn" [a.source] c.state (output a).lo.source (next l c 0).state := by
  have h := NumericNegationRefinement.qn_math code installed snInstalled smakeInstalled nzInstalled nuInstalled neInstalled keepInstalled
    a.numerator.negative ctx room live.1 live.2 positive
  rw [output,RationalSubCalls.negative_source]
  exact h.1

theorem live {l : PoolLayout} {c : Cursor} {a : Input} (h : a.Live c.state) :
    (output a).Live (next l c 0).state :=
  ⟨RationalSubCalls.negative_live (Input.live_after h),Input.live_after h⟩

theorem decoded {l : PoolLayout} {c : Cursor} (a : Input) (h : a.Live c.state)
    (positive : 0<a.denominator) (nonnegative : 0≤a.mathematical.value) :
    NumericRepresentation.interval (next l c 0).state (output a).source=
      some (⟨-a.mathematical.value,a.mathematical.value,by linarith⟩:IntervalRat) := by
  have outLive := live (l:=l) (c:=c) h
  have dl := Input.decoded outLive.1 positive
  have dh := Input.decoded outLive.2 positive
  change NumericRepresentation.rational (next l c 0).state (RationalSubCalls.negative a).source=
    some (RationalSubCalls.negative a).mathematical at dl
  change NumericRepresentation.rational (next l c 0).state a.source=some a.mathematical at dh
  have order : -a.mathematical.value≤a.mathematical.value := by linarith
  simp [NumericRepresentation.interval,output,Pair.source,IntervalCasts.value,dl,dh,RationalSubCalls.negative_value,order]

theorem declaration (service : Call) {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Input)
    (inputLive : a.Live c.state) (slot : Nat) (binding : LocalBinding.At c.state "wide" "Q" a.source slot)
    (qn : service "qn" [a.source] c.state=some ((output a).lo.source,(next l c 0).state)) :
    Declare Header.layout service [{type:="RI",name:="r",value:=some initializer}] c.state (after l c a).state := by
  have safe := LocalBinding.noncounter_separated ctx binding (by decide +kernel)
  have nextBinding : LocalBinding.At (next l c 0).state "wide" "Q" a.source slot :=
    LocalBinding.advance binding [0] safe.1 safe.2.1 safe.2.2
  have first : evalExpr Header.layout service 999 c.state (.call (.var "qn") [.var "wide"])=
      some ((output a).lo.source,(next l c 0).state) :=
    ExpressionTemplates.call_one Header.layout service
      (LocalBinding.eval service 997 binding (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) qn
  have second := LocalBinding.eval service 998 nextBinding (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have expr : evalExpr Header.layout service 1000 c.state initializer=
      some (.aggregate [(output a).lo.source,a.source],(next l c 0).state) :=
    ExpressionTemplates.record_two Header.layout service first second
  have outLive := live (l:=l) (c:=c) inputLive
  have cl : castValue Header.layout (next l c 0).state 99 "Q" (output a).lo.source=some (output a).lo.source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) outLive.1.1 outLive.1.2 (SignedNegCalls.bit_bound _)
  have ch : castValue Header.layout (next l c 0).state 99 "Q" a.source=some a.source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) outLive.2.1 outLive.2.2 (SignedNegCalls.bit_bound _)
  have cast : castValue Header.layout (next l c 0).state 100 "RI" (.aggregate [(output a).lo.source,a.source])=
      some (output a).source := IntervalCasts.aggregate _ 96 _ _ cl ch
  change declarations Header.layout service [_] _ = _
  simp only [declarations,List.foldlM,expr,cast,Bind.bind,Option.bind]
  rfl

theorem after_valid {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top < capacity) (a : Input) :
    Valid l (after l c a) := CursorLocals.allocated_valid (next_valid 0 ctx room) "RI" "r" (output a).source

theorem binding (l : PoolLayout) (c : Cursor) (a : Input) :
    LocalBinding.At (after l c a).state "r" "RI" (output a).source (next l c 0).state.heap.length :=
  LocalBinding.allocate_head (next l c 0).state "r" "RI" (output a).source (Pair.initialized _)

theorem scale {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Input) {object slot d : Nat}
    (h : SourceFromS.ScaleAt c.state object slot d) : SourceFromS.ScaleAt (after l c a).state object slot d :=
  ReadonlyCallEffects.scale_allocate (SourceScaleFrames.advance ctx h [0]) "RI" "r" _

end ScopedC.RationalSymmetricLocal
