/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalHullData
import ScopedC.CursorSingleFrames
namespace ScopedC.RationalIntervalHullTrace
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 0

def steps (a b : Pair) : List Nat :=
  RationalCompareFraming.steps a.lo b.lo++RationalCompareFraming.steps a.hi b.hi

theorem finish_advance (l : PoolLayout) (c : Cursor) (a b : Pair) :
    RationalIntervalHullCalls.finish l c a b=
      CursorFrames.advance l (RationalIntervalHullCalls.base c a b) (steps a b) := by
  unfold RationalIntervalHullCalls.finish RationalIntervalHullCalls.middle
  rw [RationalCompareFraming.final_eq_advance,RationalCompareFraming.final_eq_advance]
  exact (CursorSingleFrames.advance_append _ _ _ _).symm

/-- Both actual qmin/qmax comparisons allocate six Nat objects; all caller
stack frames are removed and the exact twelve-step global-pool trace remains. -/
theorem after_advance {l : PoolLayout} {c : Cursor} (valid : Valid l c) (a b : Pair)
    (room : c.top+11 < capacity) :
    RationalIntervalHullCalls.after l c a b=CursorFrames.advance l c (steps a b) := by
  unfold RationalIntervalHullCalls.after
  rw [finish_advance]
  change PoolContextPop.unframe c.state
    (CursorFrames.advance l (CursorFrames.framed c "RI" "a" a.source "RI" "b" b.source) (steps a b))=_
  rw [CursorFrames.advance_framed valid (steps a b) (by change c.top+12 ≤ capacity;omega)
    "RI" "a" a.source "RI" "b" b.source]
  have pop := TwoFrames.pop_frame (s:=c.state) "RI" "a" a.source "RI" "b" b.source
    (CursorEffects.shape l c (steps a b)).1 (CursorEffects.shape l c (steps a b)).2
  dsimp only [PoolContextPop.unframe,CursorFrames.framed]
  rw [pop]

end ScopedC.RationalIntervalHullTrace
