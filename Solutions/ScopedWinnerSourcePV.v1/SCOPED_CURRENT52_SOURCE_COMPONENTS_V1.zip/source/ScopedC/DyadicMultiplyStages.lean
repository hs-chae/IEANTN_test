/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicToRIPair
import ScopedC.NumericRationalIntervalMultiplyRefinement
import ScopedC.RationalIntervalMultiplyEffects
import ScopedC.SourceFromRIDecoded
namespace ScopedC.DyadicMultiplyStages
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DyadicPairFrames (InputI)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] RationalIntervalMultiplyCalls.after

structure Library (code : List Function) : Prop where
  toRI : Generated.f_toRI∈code
  toRILib : ToRIStages.Library code
  rmul : Generated.f_rmul∈code
  rmulLib : RationalIntervalMultiplyCalls.Library code
  fromRI : Generated.f_fromRI∈code
  qt : Generated.f_qt∈code
  floorQ : Generated.f_floorQ∈code
  ceilQ : Generated.f_ceilQ∈code
  qn : Generated.f_qn∈code
  sn : Generated.f_sn∈code
  qtLib : RationalMultiplyCalls.Library code
  roundLib : FloorQNegativeCalls.Library code

def productCursor {code : List Function} {l : PoolLayout} {c : Cursor} {a b : InputI}
    (D : DyadicToRIPair.Stages code l c a b (2^100)) : Cursor :=
  RationalIntervalMultiplyCalls.after l D.second D.left D.right

def productValue {code : List Function} {l : PoolLayout} {c : Cursor} {a b : InputI}
    (D : DyadicToRIPair.Stages code l c a b (2^100)) : Value :=
  RationalIntervalMultiplyCalls.result l D.second D.left D.right

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (a b : InputI)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) where
  conversions : DyadicToRIPair.Stages code l c a b (2^100)
  inside : Cursor
  low : Endpoint
  high : Endpoint
  productCall : SourceCall Header.layout code 8 "rmul" [conversions.left.source,conversions.right.source]
    conversions.second.state (productValue conversions) (productCursor conversions).state
  roundCall : SourceCall Header.layout code 8 "fromRI"
    [productValue conversions,boolean Header.layout (a.ok&&b.ok)] (productCursor conversions).state
    (DyadicCasts.value low.source high.source (a.ok&&b.ok)) inside.state
  insideValid : Valid l inside
  lowLive : low.Live inside.state
  highLive : high.Live inside.state
  decoded : DyadicRepresentation.interval inside.state (DyadicCasts.value low.source high.source (a.ok&&b.ok))=
    some (IntervalDyadic.ofIntervalRat
      (IntervalRat.mul (DyadicToRIPair.divided a (2^100) oa) (DyadicToRIPair.divided b (2^100) ob)) (-100),a.ok&&b.ok)

private theorem rat_ext {a b : IntervalRat} (lo : a.lo=b.lo) (hi : a.hi=b.hi) : a=b := by
  cases a
  cases b
  simp_all

/-- The full numerical subexecution of actual imul. The two conversions,
four-product rational multiplication, and directed dyadic rounding are each
actual installed source executions; their outputs are composed directly. -/
theorem stages_exist (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (a b : InputI) (ha : a.Live c.state) (hb : b.Live c.state)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (room : c.top+137 < capacity) :
    Nonempty (Stages code l c a b oa ob) := by
  obtain ⟨D⟩ := DyadicToRIPair.stages_exist code lib.toRI lib.toRILib ctx a b ha hb oa ob scale
    (by positivity) (by omega)
  have leftOrdered : D.left.lo.mathematical.value ≤ D.left.hi.mathematical.value := by
    rw [D.leftLow,D.leftHigh]
    exact (DyadicToRIPair.divided a (2^100) oa).le
  have rightOrdered : D.right.lo.mathematical.value ≤ D.right.hi.mathematical.value := by
    rw [D.rightLow,D.rightHigh]
    exact (DyadicToRIPair.divided b (2^100) ob).le
  have productRoom : D.second.top+79 < capacity := by rw [D.second_top];omega
  have product := NumericRationalIntervalMultiplyRefinement.rmul_math code lib.rmul lib.rmulLib D.secondValid
    productRoom D.left D.right D.leftLive D.rightLive D.leftPositive D.rightPositive leftOrdered rightOrdered
  have exactLeft : (⟨D.left.lo.mathematical.value,D.left.hi.mathematical.value,leftOrdered⟩:IntervalRat)=
      DyadicToRIPair.divided a (2^100) oa := rat_ext D.leftLow D.leftHigh
  have exactRight : (⟨D.right.lo.mathematical.value,D.right.hi.mathematical.value,rightOrdered⟩:IntervalRat)=
      DyadicToRIPair.divided b (2^100) ob := rat_ext D.rightLow D.rightHigh
  have decodedProduct : NumericRepresentation.interval (productCursor D).state (productValue D)=some
      (IntervalRat.mul (DyadicToRIPair.divided a (2^100) oa) (DyadicToRIPair.divided b (2^100) ob)) := by
    simpa only [productCursor,productValue,exactLeft,exactRight] using product.2
  have productValid : Valid l (productCursor D) :=
    RationalIntervalMultiplyCalls.after_valid D.secondValid productRoom D.left D.right
  have productScale : SourceFromS.ScaleAt (productCursor D).state object slot (2^100) :=
    RationalIntervalMultiplyCalls.preserves_scale D.secondValid D.left D.right (D.scale ctx scale)
  have roundRoom : (productCursor D).top+37 < capacity := by
    rw [productCursor,RationalIntervalMultiplyCalls.after_top,D.second_top]
    omega
  obtain ⟨inside,low,high,roundCall,insideValid,lowLive,highLive,decoded⟩ :=
    SourceFromRIDecoded.fromRI_of_decoded code lib.fromRI lib.qt lib.floorQ lib.ceilQ lib.qn lib.sn lib.qtLib
      lib.roundLib productValid (productValue D) (a.ok&&b.ok)
      (IntervalRat.mul (DyadicToRIPair.divided a (2^100) oa) (DyadicToRIPair.divided b (2^100) ob))
      productScale decodedProduct roundRoom
  exact ⟨⟨D,inside,low,high,product.1,roundCall,insideValid,lowLive,highLive,decoded⟩⟩

/-- Physical caller binding survives the actual multiplication. Its storage
is known to precede the callee's frames and not to alias any pool object. -/
theorem product_binding {code : List Function} {l : PoolLayout} {c : Cursor} {a b : InputI}
    (D : DyadicToRIPair.Stages code l c a b (2^100)) (ctx : Valid l c)
    {name : String} {p : InputI} {i : Nat} (binding : LocalBinding.At D.second.state name "I" p.source i)
    (lower : c.state.heap.length ≤ i) : LocalBinding.At (productCursor D).state name "I" p.source i := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.memory binding (RationalIntervalMultiplyCalls.after_env l D.second D.left D.right)
    (RationalIntervalMultiplyCalls.after_other l D.second D.left D.right i
      ((List.getElem?_eq_some_iff.mp binding.memory).choose) (by omega) (by omega) (by omega))

end ScopedC.DyadicMultiplyStages
