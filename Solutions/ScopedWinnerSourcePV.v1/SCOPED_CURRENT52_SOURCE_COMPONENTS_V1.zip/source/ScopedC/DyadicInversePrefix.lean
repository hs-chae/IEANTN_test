/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseFlagLocal
import ScopedC.CallEventService
import ScopedC.CursorEffects
import ScopedC.SourceRanks
namespace ScopedC.DyadicInversePrefix
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicInverseConversion (Conversion parameters)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

def statements : List Stmt := [
  .declare [{type:="RI",name:="q",value:=some DyadicInverseConversion.initializer}],
  .declare [{type:="unsigned int",name:="valid",value:=some DyadicInverseValidity.expression}]]

theorem actual_source_prefix : ∃ tail, Generated.f_iinv.body = .sequence (statements++tail) := by
  exact ⟨_,rfl⟩

/-- The real first two iinv declarations, retaining both locals for the
following source branch. All five possible callee answers below must be
installed only after proving the corresponding actual lower source bodies. -/
theorem sequence (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor} {a : InputI}
    (D : Conversion code l c a)
    (toRI : service "toRI" [a.source] (parameters c a).state=some (D.interval.source,D.returned.state))
    (qiLo : service "qi" [DecimalDigits.integer 0] (DyadicInverseConversion.after D).state=
      some ((RationalZeroCompare.zero l (DyadicInverseConversion.after D)).source,
        (RationalZeroCompare.first l (DyadicInverseConversion.after D)).state))
    (qcLo : service "qc" [D.interval.lo.source,(RationalZeroCompare.zero l (DyadicInverseConversion.after D)).source]
      (RationalZeroCompare.first l (DyadicInverseConversion.after D)).state=
      some (SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat D.interval.lo.mathematical.value 0),
        (DyadicInverseValidity.middle l (DyadicInverseConversion.after D) D.interval).state))
    (qiHi : service "qi" [DecimalDigits.integer 0]
      (DyadicInverseValidity.middle l (DyadicInverseConversion.after D) D.interval).state=
      some ((RationalZeroCompare.zero l (DyadicInverseValidity.middle l (DyadicInverseConversion.after D) D.interval)).source,
        (RationalZeroCompare.first l (DyadicInverseValidity.middle l (DyadicInverseConversion.after D) D.interval)).state))
    (qcHi : service "qc" [D.interval.hi.source,
      (RationalZeroCompare.zero l (DyadicInverseValidity.middle l (DyadicInverseConversion.after D) D.interval)).source]
      (RationalZeroCompare.first l (DyadicInverseValidity.middle l (DyadicInverseConversion.after D) D.interval)).state=
      some (SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat D.interval.hi.mathematical.value 0),
        (DyadicInverseValidity.finish l (DyadicInverseConversion.after D) D.interval).state)) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      statements (parameters c a).state
      (.continuing (DyadicInverseFlagLocal.after l (DyadicInverseConversion.after D) D.interval).state) := by
  have q := D.declaration service toRI
  have flag := DyadicInverseFlagLocal.declaration service D.after_valid D.interval _ D.q_binding qiLo qcLo qiHi qcHi
  exact Loops.SeqRun.next (Loops.StmtRun.declare q)
    (Loops.SeqRun.next (Loops.StmtRun.declare flag) (Loops.SeqRun.nil _))

attribute [local irreducible] DyadicInverseValidity.middle DyadicInverseValidity.finish
  RationalZeroCompare.first RationalZeroCompare.zero

/-- A source-closed service for that prefix. Repeated qi/qc calls have distinct
proved physical allocation states; the second pair is consumed only along
the actual short-circuit path. This is not a complete iinv-body theorem. -/
theorem source_prefix_exists (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity) :
    ∃ service : Call,
      (∀ name args before value after, service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
        statements (parameters c a).state
        (.continuing (DyadicInverseFlagLocal.after l (DyadicInverseConversion.after D) D.interval).state) := by
  let start := DyadicInverseConversion.after D
  have loLive : D.interval.lo.Live start.state := D.live.1
  have hiLive : D.interval.hi.Live start.state := D.live.2
  have calls := DyadicInverseValidity.source_calls code lib D.after_valid room D.interval
    ⟨loLive,hiLive⟩ D.positive
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"toRI",[a.source],(parameters c a).state,D.interval.source,D.returned.state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.call⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 0],start.state,(RationalZeroCompare.zero l start).source,
      (RationalZeroCompare.first l start).state,SourceRanks.monotone (by omega : 6 ≤ 8) calls.1⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"qc",[D.interval.lo.source,(RationalZeroCompare.zero l start).source],
      (RationalZeroCompare.first l start).state,
      SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat D.interval.lo.mathematical.value 0),
      (DyadicInverseValidity.middle l start D.interval).state,SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.1⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 0],(DyadicInverseValidity.middle l start D.interval).state,
      (RationalZeroCompare.zero l (DyadicInverseValidity.middle l start D.interval)).source,
      (RationalZeroCompare.first l (DyadicInverseValidity.middle l start D.interval)).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.2.1⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qc",[D.interval.hi.source,(RationalZeroCompare.zero l (DyadicInverseValidity.middle l start D.interval)).source],
      (RationalZeroCompare.first l (DyadicInverseValidity.middle l start D.interval)).state,
      SignedCompareCalls.integer (NumericRationalCompareRefinement.compareRat D.interval.hi.mathematical.value 0),
      (DyadicInverseValidity.finish l start D.interval).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) calls.2.2.2.1⟩
  let events := [e0,e1,e2,e3,e4]
  have middleSize : (DyadicInverseValidity.middle l start D.interval).state.nats.values.length=
      start.state.nats.values.length+9 := by
    rw [DyadicInverseValidity.middle,RationalZeroCompare.after_advance,CursorEffects.size]
    rfl
  have firstSize (x : Cursor) : (RationalZeroCompare.first l x).state.nats.values.length=
      x.state.nats.values.length+3 := by
    rw [RationalZeroCompare.first,RationalUnsignedTrace.after,CursorEffects.size]
    rfl
  have unique : (events.map CallEvents.key).Nodup := by
    simp only [events,List.map_cons,List.map_nil,CallEvents.key,e0,e1,e2,e3,e4]
    simp [List.nodup_cons,firstSize,middleSize]
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service events unique
  refine ⟨service,closed,?_⟩
  exact sequence service D (answers e0 (by simp [events])) (answers e1 (by simp [events]))
    (answers e2 (by simp [events])) (answers e3 (by simp [events])) (answers e4 (by simp [events]))

end ScopedC.DyadicInversePrefix
