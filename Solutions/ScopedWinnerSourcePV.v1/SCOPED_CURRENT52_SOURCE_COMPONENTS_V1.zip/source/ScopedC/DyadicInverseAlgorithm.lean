/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseFallbackStages
import ScopedC.DyadicInverseValidStages
import ScopedC.DyadicInverseValidity
import LeanCert.Engine.IntervalEvalDyadic
namespace ScopedC.DyadicInverseAlgorithm
open LeanCert.Core
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def good (I : IntervalRat) : Bool := decide (0<I.lo)||decide (I.hi<0)
def sorted (I : IntervalRat) : IntervalRat :=
  ⟨min (1/I.hi) (1/I.lo),max (1/I.hi) (1/I.lo),le_trans (min_le_left _ _) (le_max_left _ _)⟩

private theorem rat_ext {a b : IntervalRat} (lo : a.lo=b.lo) (hi : a.hi=b.hi) : a=b := by
  cases a
  cases b
  simp_all

/-- The actual source's min/max sorting is exactly the original model's
two reciprocal branches, including its tie and total Rat conventions. -/
theorem valid_exact (I : IntervalRat) (h : good I=true) : sorted I=LeanCert.Engine.invInterval I := by
  by_cases pos : 0<I.lo
  all_goals by_cases neg : I.hi<0
  all_goals by_cases order : I.hi⁻¹≤I.lo⁻¹
  all_goals simp [good,pos,neg] at h
  all_goals simp [sorted,LeanCert.Engine.invInterval,pos,neg,order,min_def,max_def]

/-- Source's literal10^30 fallback equals the original failed-domain result;
the validity flag is false on this branch, as in the original evaluator. -/
theorem fallback_exact (I : IntervalRat) (h : good I=false) :
    DyadicInverseFallbackStages.symmetricInterval (10^30)=LeanCert.Engine.invInterval I := by
  by_cases pos : 0<I.lo
  all_goals by_cases neg : I.hi<0
  all_goals simp [good,pos,neg] at h
  all_goals simp [DyadicInverseFallbackStages.symmetricInterval,LeanCert.Engine.invInterval,
    LeanCert.Engine.invWideBound,pos,neg,Nat.cast_pow]
  all_goals norm_num

theorem pair_good (q : Pair) (I : IntervalRat)
    (lo : q.lo.mathematical.value=I.lo) (hi : q.hi.mathematical.value=I.hi) :
    DyadicInverseValidity.valid q=good I := by
  simp only [DyadicInverseValidity.valid,DyadicInverseValidity.lowerPositive,good,lo,hi]

theorem pair_sorted (q : Pair) (I : IntervalRat)
    (lo : q.lo.mathematical.value=I.lo) (hi : q.hi.mathematical.value=I.hi) :
    DyadicInverseValidStages.reciprocalInterval q=sorted I :=
  rat_ext (by change min (1/q.hi.mathematical.value) (1/q.lo.mathematical.value)=min (1/I.hi) (1/I.lo);rw [lo,hi])
    (by change max (1/q.hi.mathematical.value) (1/q.lo.mathematical.value)=max (1/I.hi) (1/I.lo);rw [lo,hi])

end ScopedC.DyadicInverseAlgorithm
