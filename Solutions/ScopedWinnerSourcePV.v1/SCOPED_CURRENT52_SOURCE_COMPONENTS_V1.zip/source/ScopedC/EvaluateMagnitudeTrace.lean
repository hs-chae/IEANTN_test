/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.EvaluateMagnitude
import ScopedC.ReadonlyCallEffects
import ScopedC.LocalBindingSeparation
import ScopedC.ReadonlyAllocatedBuffers
namespace ScopedC.EvaluateMagnitudeTrace
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.NatWrapperCalls ScopedC.DecimalText
open ScopedC.EvaluateLiteral ScopedC.EvaluateMagnitude
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (base : Nat) (n : ScopedNumerical.Input.Node) where
  parsed : Cursor
  slot : Nat
  trace : List Nat
  call : SourceCall Header.layout code 3 "decimal" [.pointer ⟨base,offset n.num,[]⟩ false]
    (flagged c base n).state (.natObject slot) parsed.state
  valid : Valid l parsed
  live : NatArena.Borrow parsed.state.nats slot n.num.natAbs
  parsedTrace : parsed=CursorFrames.advance l (flagged c base n) trace
  top : parsed.top=c.top+1+4*(digits n.num.natAbs).length
  size : parsed.state.nats.values.length=c.state.nats.values.length+1+4*(digits n.num.natAbs).length

def after {code : List Function} {l : PoolLayout} {c : Cursor} {base : Nat} {n : ScopedNumerical.Input.Node}
    (D : Stages code l c base n) : Cursor := magCursor D.parsed D.slot

/-- Full actual numerator parser, now retaining the allocation trace that
later source computations need for their original caller storage. -/
theorem stages_exist (code : List Function)
    (decimalInstalled : Generated.f_decimal∈code) (nuInstalled : Generated.f_nu∈code)
    (nmInstalled : Generated.f_nm∈code) (naInstalled : Generated.f_na∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolLayout} {c : Cursor} {base : Nat} {n : ScopedNumerical.Input.Node}
    (ctx : Valid l c) (num : c.state.heap[base]?=some (literalObject (toString n.num)))
    (room : c.top+4*(digits n.num.natAbs).length < capacity) : Nonempty (Stages code l c base n) := by
  have storage:=num_storage num
  have window : DecimalBuffer.At (flagged c base n).state ⟨base,offset n.num,[]⟩ (digits n.num.natAbs) := by
    apply DecimalBuffer.of_array (padding n.num)
    · simpa only [integer_object] using storage
    · rfl
    · rfl
  obtain ⟨parsed,slot,source,live,valid,_,top,_,_,size,_,trace,preserves⟩ :=
    DecimalSource.decimal_traced code decimalInstalled nuInstalled nmInstalled naInstalled keepInstalled
      (flagged_valid ctx base n) window (digits_valid n.num.natAbs) room
  exact ⟨⟨parsed,slot,_,source,valid,by simpa only [digits_value] using live,trace,top,size⟩⟩

namespace Stages
variable {code : List Function} {l : PoolLayout} {c : Cursor} {base : Nat} {n : ScopedNumerical.Input.Node}

theorem after_valid (D : Stages code l c base n) : Valid l (after D) :=
  AllocatedFrames.context_allocate D.valid "N" "mag" (.natObject D.slot)

theorem mag_binding (D : Stages code l c base n) :
    LocalBinding.At (after D).state "mag" "N" (.natObject D.slot) D.parsed.state.heap.length :=
  LocalBinding.allocate_head D.parsed.state "mag" "N" (.natObject D.slot) rfl

private theorem node_flagged (c : Cursor) (base : Nat) (n : ScopedNumerical.Input.Node) :
    LocalBinding.At (flagged c base n).state "n" "Node" (DataNode.represented base n) c.state.heap.length :=
  LocalBinding.allocate_other (LocalBinding.allocate_head c.state "n" "Node" (DataNode.represented base n)
    (DataReads.node_initialized base n)) "negative" "unsigned int" (some (unsigned32 (flag n))) (by decide +kernel)

private theorem sign_flagged (c : Cursor) (base : Nat) (n : ScopedNumerical.Input.Node) :
    LocalBinding.At (flagged c base n).state "negative" "unsigned int" (unsigned32 (flag n)) (c.state.heap.length+1) := by
  simpa only [flagged,nodeCursor,EvaluateNodeRead.nodeState,allocate,List.length_append,List.length_singleton] using
    LocalBinding.allocate_head (nodeCursor c base n).state "negative" "unsigned int" (unsigned32 (flag n)) rfl

theorem node_binding (D : Stages code l c base n) (ctx : Valid l c) :
    LocalBinding.At (after D).state "n" "Node" (DataNode.represented base n) c.state.heap.length := by
  have initial:=node_flagged c base n
  have safe:=LocalBinding.noncounter_separated (flagged_valid ctx base n) initial (by decide +kernel)
  have parsed : LocalBinding.At D.parsed.state "n" "Node" (DataNode.represented base n) c.state.heap.length := by
    rw [D.parsedTrace]
    exact LocalBinding.advance initial D.trace safe.1 safe.2.1 safe.2.2
  exact LocalBinding.allocate_other parsed "mag" "N" (some (.natObject D.slot)) (by decide +kernel)

theorem sign_binding (D : Stages code l c base n) (ctx : Valid l c) :
    LocalBinding.At (after D).state "negative" "unsigned int" (unsigned32 (flag n)) (c.state.heap.length+1) := by
  have initial:=sign_flagged c base n
  have safe:=LocalBinding.noncounter_separated (flagged_valid ctx base n) initial (by decide +kernel)
  have parsed : LocalBinding.At D.parsed.state "negative" "unsigned int" (unsigned32 (flag n)) (c.state.heap.length+1) := by
    rw [D.parsedTrace]
    exact LocalBinding.advance initial D.trace safe.1 safe.2.1 safe.2.2
  exact LocalBinding.allocate_other parsed "mag" "N" (some (.natObject D.slot)) (by decide +kernel)

theorem scale (D : Stages code l c base n) (ctx : Valid l c) {object slot d : Nat}
    (h : SourceFromS.ScaleAt c.state object slot d) : SourceFromS.ScaleAt (after D).state object slot d := by
  have nodeScale : SourceFromS.ScaleAt (nodeCursor c base n).state object slot d :=
    ReadonlyCallEffects.scale_allocate h "Node" "n" (some (DataNode.represented base n))
  have signScale : SourceFromS.ScaleAt (flagged c base n).state object slot d :=
    ReadonlyCallEffects.scale_allocate nodeScale "unsigned int" "negative" (some (unsigned32 (flag n)))
  have parsedScale : SourceFromS.ScaleAt D.parsed.state object slot d := by
    rw [D.parsedTrace]
    exact SourceScaleFrames.advance (flagged_valid ctx base n) signScale D.trace
  exact ReadonlyCallEffects.scale_allocate parsedScale "N" "mag" (some (.natObject D.slot))

theorem denominator_window (D : Stages code l c base n) (ctx : Valid l c)
    (den : c.state.heap[base+1]?=some (literalObject (toString n.den))) :
    DecimalBuffer.At (after D).state ⟨base+1,0,[]⟩ (digits n.den) := by
  have original : DecimalBuffer.At c.state ⟨base+1,0,[]⟩ (digits n.den) := by
    apply DecimalBuffer.of_array []
    · simpa only [natural_object] using den
    · rfl
    · rfl
  have nodeWindow : DecimalBuffer.At (nodeCursor c base n).state ⟨base+1,0,[]⟩ (digits n.den) :=
    ReadonlyAllocatedBuffers.allocate original "Node" "n" (some (DataNode.represented base n))
  have signWindow : DecimalBuffer.At (flagged c base n).state ⟨base+1,0,[]⟩ (digits n.den) :=
    ReadonlyAllocatedBuffers.allocate nodeWindow "unsigned int" "negative" (some (unsigned32 (flag n)))
  have safe:=DecimalBuffer.separate signWindow (flagged_valid ctx base n)
  have parsedWindow : DecimalBuffer.At D.parsed.state ⟨base+1,0,[]⟩ (digits n.den) := by
    rw [D.parsedTrace]
    exact ReadonlyCallEffects.buffer_advance signWindow D.trace safe.1 safe.2.1 safe.2.2
  exact ReadonlyAllocatedBuffers.allocate parsedWindow "N" "mag" (some (.natObject D.slot))

end Stages
end ScopedC.EvaluateMagnitudeTrace
