/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ReadonlyCallEffects
import ScopedC.DecimalIntegerText
namespace ScopedC.ReadonlyAllocatedBuffers
open ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem memory {s t : State} {buf : Address} {digits : List Nat}
    (h : DecimalBuffer.At s buf digits) (same : t.heap=s.heap) : DecimalBuffer.At t buf digits := by
  constructor
  · simpa only [same] using h.allocated
  · exact h.fields
  · intro k bound
    simpa only [addressType,same] using h.address k bound
  · intro k bound
    simpa only [Machine.read,same] using h.contents k bound

theorem allocate {s : State} {buf : Address} {digits : List Nat}
    (h : DecimalBuffer.At s buf digits) (type name : String) (value : Option Value) :
    DecimalBuffer.At (Machine.allocate s type name value) buf digits :=
  memory (DecimalText.buffer_append h [{type:=type,cells:=[value]}]) rfl

end ScopedC.ReadonlyAllocatedBuffers
