/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericUnsignedRefinement
import ScopedC.SourceScaleFrames
namespace ScopedC.RationalUnsignedTrace
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.DyadicRepresentation ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def after (l : PoolLayout) (c : Cursor) (n : Nat) : Cursor := CursorFrames.advance l c [n,0,1]
def output (l : PoolLayout) (c : Cursor) (n : Nat) : Input :=
  ⟨⟨c.state.nats.values.length,n,false⟩,(next l (next l c n) 0).state.nats.values.length,1⟩

theorem state (l : PoolLayout) (c : Cursor) (n : Nat) :
    (after l c n).state=RationalUnsignedCalls.qiResult l c.state c.cells c.top c.high n := rfl

theorem source (l : PoolLayout) (c : Cursor) (n : Nat) :
    (output l c n).source=RecordCasts.rational c.state.nats.values.length 0
      (SignedCalls.siResult l c.state c.cells c.top c.high n).nats.values.length := rfl

theorem live (l : PoolLayout) (c : Cursor) (n : Nat) : (output l c n).Live (after l c n).state :=
  ⟨PoolCursor.preserves (c:=next l (next l c n) 0)
    (PoolCursor.preserves (c:=next l c n) (PoolCursor.next_borrow l c n)),
    PoolCursor.next_borrow l (next l (next l c n) 0) 1⟩

theorem mathematical (l : PoolLayout) (c : Cursor) (n : Nat) :
    (output l c n).mathematical.value=(n:Rat) ∧ (output l c n).mathematical.Normalized := by
  simp [output,Input.mathematical,Endpoint.mathematical,Rational.value,Rational.Normalized,Signed.value]

/-- General existing qi source call with actual parameter-cast proof, now
retaining its exact three allocations and a live normalized output Input. -/
theorem qi_traced (code : List Function) (installed : Generated.f_qi∈code)
    (siInstalled : Generated.f_si∈code) (smakeInstalled : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (n : Nat) (bound : n<2^32)
    (room : c.top+2 < capacity) (input : Value)
    (parameter : castValue Header.layout {c.state with env:=[]} 100 "unsigned int" input=some (NatWrapperCalls.unsigned32 n)) :
    SourceCall Header.layout code 6 "qi" [input] c.state (output l c n).source (after l c n).state ∧
    Valid l (after l c n) ∧ (output l c n).Live (after l c n).state ∧
    (output l c n).mathematical.value=(n:Rat) ∧ (output l c n).mathematical.Normalized := by
  refine ⟨?_,CursorFrames.advance_valid ctx [n,0,1] (by change c.top+3 ≤ capacity;omega),live l c n,
    (mathematical l c n).1,(mathematical l c n).2⟩
  rw [source,state]
  exact RationalUnsignedCalls.qi_call code installed siInstalled smakeInstalled nzInstalled nuInstalled neInstalled keepInstalled
    ctx room bound parameter

end ScopedC.RationalUnsignedTrace
