/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalNaturalLiteral
namespace ScopedC.RationalNaturalLiteral
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DecimalText (digits)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def trace {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n : Nat} (D : Stages code l c n) : List Nat :=
  (0::DecimalExpressions.allocationSteps 0 (digits n))++([0,1]++SourceFromSTrace.steps (endpoint D.magSlot n) 1)

theorem after_advance {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n : Nat} (D : Stages code l c n) :
    after D=CursorFrames.advance l (textCursor c n) (trace D) := by
  rw [after,SourceFromSTrace.c5_advance,trace,CursorSingleFrames.advance_append,
    CursorSingleFrames.advance_append,←D.parserTrace]
  rfl

theorem allocationSteps_length (acc : Nat) (ds : List Nat) :
    (DecimalExpressions.allocationSteps acc ds).length=4*ds.length := by
  induction ds generalizing acc with
  | nil => rfl
  | cons d ds ih => simp [DecimalExpressions.allocationSteps,ih];omega

theorem trace_length {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : Stages code l c n) : (trace D).length=8+4*(digits n).length := by
  simp [trace,allocationSteps_length,SourceFromSTrace.steps]
  omega

theorem top {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : Stages code l c n) : (after D).top=c.top+8+4*(digits n).length := by
  rw [after_advance,CursorFrames.top_advance,trace_length]
  change c.top+(8+4*(digits n).length)=_
  omega

theorem scale {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : Stages code l c n) (ctx : Valid l c) {object slot d : Nat}
    (h : SourceFromS.ScaleAt c.state object slot d) : SourceFromS.ScaleAt (after D).state object slot d := by
  rw [after_advance]
  exact SourceScaleFrames.advance (DecimalInitialized.input_valid ctx _) (LiteralAllocationEffects.scale h _) _

end ScopedC.RationalNaturalLiteral
