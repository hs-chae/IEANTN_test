/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalFrames
namespace ScopedC.NumericInputCompleteness
open ScopedC.Machine
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

/-- Invert a successful RI decoder into both actual live Q records and their
positive denominators. This derives application call applicability from the
already proved source output; it assumes no desired function result. -/
theorem interval {s : State} {v : Value} {r : IntervalRat}
    (h : NumericRepresentation.interval s v=some r) :
    ∃ a : Pair,a.source=v ∧ a.Live s ∧ a.Positive ∧
      a.lo.mathematical.value=r.lo ∧ a.hi.mathematical.value=r.hi := by
  unfold NumericRepresentation.interval at h
  split at h
  · rename_i tag lo hi
    by_cases ht : tag="RI"
    · cases hl : NumericRepresentation.rational s lo with
      | none => simp [ht,hl] at h
      | some l =>
        cases hh : NumericRepresentation.rational s hi with
        | none => simp [ht,hl,hh] at h
        | some u =>
          by_cases ordered : l.value ≤ u.value
          · have result : (⟨l.value,u.value,ordered⟩:IntervalRat)=r := by simpa [ht,hl,hh,ordered] using h
            obtain ⟨low,lowSource,lowLive,lowMath,lowPositive⟩ := rational hl
            obtain ⟨high,highSource,highLive,highMath,highPositive⟩ := rational hh
            refine ⟨⟨low,high⟩,?_,⟨lowLive,highLive⟩,⟨lowPositive,highPositive⟩,?_,?_⟩
            · change Value.record "RI" [low.source,high.source]=_
              rw [lowSource,highSource,ht]
            · change low.mathematical.value=r.lo
              rw [lowMath]
              exact congrArg IntervalRat.lo result
            · change high.mathematical.value=r.hi
              rw [highMath]
              exact congrArg IntervalRat.hi result
          · simp [ht,hl,hh,ordered] at h
    · simp [ht] at h
  · contradiction

end ScopedC.NumericInputCompleteness
