/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalReciprocalCalls
import ScopedC.RationalIntervalFrames
import ScopedC.LocalBindingSeparation
import ScopedC.ReadonlyCallEffects
namespace ScopedC.RationalReciprocalLocal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalReciprocalCalls (Result oneCursor oneInput)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def selected (upper : Bool) (q : Pair) : RationalPairFrames.Input := if upper then q.hi else q.lo
def initializer (upper : Bool) : Expr := .call (.var "qv")
  [.call (.var "qi") [.nat 1],.field "." (.var "q") (if upper then "hi" else "lo")]
def after {code : List Function} {l : PoolLayout} {c : Cursor} {a : RationalPairFrames.Input}
    (R : Result code l c a) (name : String) : Cursor :=
  CursorLocals.allocated (RationalReciprocalCalls.after l c a) "Q" name R.output.source

theorem expression (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (upper : Bool) (q : Pair) (slot : Nat)
    (binding : LocalBinding.At c.state "q" "RI" q.source slot)
    (R : Result code l c (selected upper q))
    (qi : service "qi" [DecimalDigits.integer 1] c.state=
      some ((oneInput l c).source,(oneCursor l c).state))
    (qv : service "qv" [(oneInput l c).source,(selected upper q).source] (oneCursor l c).state=
      some (R.output.source,(RationalReciprocalCalls.after l c (selected upper q)).state)) :
    evalExpr Header.layout service 1000 c.state (initializer upper)=
      some (R.output.source,(RationalReciprocalCalls.after l c (selected upper q)).state) := by
  have safe := LocalBinding.noncounter_separated ctx binding (by decide +kernel)
  have nextBinding : LocalBinding.At (oneCursor l c).state "q" "RI" q.source slot :=
    LocalBinding.advance binding [1,0,1] safe.1 safe.2.1 safe.2.2
  have one : evalExpr Header.layout service 999 c.state (.call (.var "qi") [.nat 1])=
      some ((oneInput l c).source,(oneCursor l c).state) :=
    ExpressionTemplates.call_one Header.layout service (by rfl) qi
  have argument : evalExpr Header.layout service 999 (oneCursor l c).state
      (.field "." (.var "q") (if upper then "hi" else "lo"))=
      some ((selected upper q).source,(oneCursor l c).state) := by
    cases upper
    · exact RationalIntervalFrames.eval_lo service 997 nextBinding (by decide +kernel) (by decide +kernel)
        (by decide +kernel) (by decide +kernel)
    · exact RationalIntervalFrames.eval_hi service 997 nextBinding (by decide +kernel) (by decide +kernel)
        (by decide +kernel) (by decide +kernel)
  exact ExpressionTemplates.call_two Header.layout service one argument qv

theorem declaration (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (upper : Bool) (q : Pair) (slot : Nat)
    (binding : LocalBinding.At c.state "q" "RI" q.source slot)
    (R : Result code l c (selected upper q)) (name : String)
    (qi : service "qi" [DecimalDigits.integer 1] c.state=
      some ((oneInput l c).source,(oneCursor l c).state))
    (qv : service "qv" [(oneInput l c).source,(selected upper q).source] (oneCursor l c).state=
      some (R.output.source,(RationalReciprocalCalls.after l c (selected upper q)).state)) :
    Declare Header.layout service [{type:="Q",name:=name,value:=some (initializer upper)}]
      c.state (after R name).state := by
  have expr := expression service ctx upper q slot binding R qi qv
  have cast := RationalPairFrames.Input.cast "Q" (by decide +kernel) R.live
  change declarations Header.layout service [_] _ = _
  simp only [declarations,List.foldlM,expr,cast,Bind.bind,Option.bind]
  rfl

theorem after_valid {code : List Function} {l : PoolLayout} {c : Cursor} {a : RationalPairFrames.Input}
    (R : Result code l c a) (name : String) : Valid l (after R name) :=
  CursorLocals.allocated_valid R.valid "Q" name R.output.source

theorem binding {code : List Function} {l : PoolLayout} {c : Cursor} {a : RationalPairFrames.Input}
    (R : Result code l c a) (name : String) :
    LocalBinding.At (after R name).state name "Q" R.output.source
      (RationalReciprocalCalls.after l c a).state.heap.length :=
  LocalBinding.allocate_head (RationalReciprocalCalls.after l c a).state name "Q" R.output.source rfl

theorem preserve_binding {code : List Function} {l : PoolLayout} {c : Cursor} {a : RationalPairFrames.Input}
    (R : Result code l c a) (ctx : Valid l c) (room : c.top+15 < capacity) (newName : String)
    {name type : String} {value : Value} {slot : Nat}
    (h : LocalBinding.At c.state name type value slot) (typeDifferent : type≠"unsigned")
    (nameDifferent : newName≠name) : LocalBinding.At (after R newName).state name type value slot := by
  have safe := LocalBinding.noncounter_separated ctx h typeDifferent
  have returned : LocalBinding.At (RationalReciprocalCalls.after l c a).state name type value slot := by
    rw [RationalReciprocalCalls.after_advance ctx room]
    exact LocalBinding.advance h _ safe.1 safe.2.1 safe.2.2
  exact LocalBinding.allocate_other returned newName "Q" (some R.output.source) nameDifferent

theorem scale {code : List Function} {l : PoolLayout} {c : Cursor} {a : RationalPairFrames.Input}
    (R : Result code l c a) (ctx : Valid l c) (room : c.top+15 < capacity) (name : String)
    {object slot d : Nat} (h : SourceFromS.ScaleAt c.state object slot d) :
    SourceFromS.ScaleAt (after R name).state object slot d := by
  have returned : SourceFromS.ScaleAt (RationalReciprocalCalls.after l c a).state object slot d := by
    rw [RationalReciprocalCalls.after_advance ctx room]
    exact SourceScaleFrames.advance ctx h _
  exact ReadonlyCallEffects.scale_allocate returned "Q" name (some R.output.source)

end ScopedC.RationalReciprocalLocal
