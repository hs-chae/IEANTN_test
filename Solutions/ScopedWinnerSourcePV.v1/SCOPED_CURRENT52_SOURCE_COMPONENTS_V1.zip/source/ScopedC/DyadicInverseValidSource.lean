/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseValidStages
import ScopedC.DyadicPairFrames
namespace ScopedC.DyadicInverseValidSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalReciprocalCalls (oneInput oneCursor)
open ScopedC.DyadicInverseValidStages (Stages sortCursor roundCursor sorted)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000
attribute [local irreducible] RationalSortCalls.after

def returnExpression : Expr := .call (.var "fromRI") [.var "r",.field "." (.var "a") "ok"]
def statements : List Stmt := DyadicInverseReciprocals.statements++[
  .declare [{type:="RI",name:="r",value:=some RationalSortLocal.initializer}],
  .returnStmt returnExpression]

theorem actual_source_suffix : ∃ initial, Generated.f_iinv.body=.sequence (initial++statements) := by
  exact ⟨[_,_,_],rfl⟩

/-- All actual declarations and the actual final fromRI(r,a.ok) return of
iinv's reciprocal suffix. Callee answers are explicitly supplied here; the
accepted stage constructor supplies their complete actual source proofs. -/
theorem sequence (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor} {q : Pair}
    (a : InputI) (D : Stages code l c q a.ok) (ctx : Valid l c) (room : c.top+81 < capacity)
    (qSlot aSlot : Nat) (qBinding : LocalBinding.At c.state "q" "RI" q.source qSlot)
    (aBinding : LocalBinding.At c.state "a" "I" a.source aSlot)
    (qi0 : service "qi" [DecimalDigits.integer 1] c.state=some ((oneInput l c).source,(oneCursor l c).state))
    (qv0 : service "qv" [(oneInput l c).source,q.hi.source] (oneCursor l c).state=
      some (D.reciprocals.first.output.source,(RationalReciprocalCalls.after l c q.hi).state))
    (qi1 : service "qi" [DecimalDigits.integer 1] (DyadicInverseReciprocals.middle D.reciprocals).state=
      some ((oneInput l (DyadicInverseReciprocals.middle D.reciprocals)).source,
        (oneCursor l (DyadicInverseReciprocals.middle D.reciprocals)).state))
    (qv1 : service "qv" [(oneInput l (DyadicInverseReciprocals.middle D.reciprocals)).source,q.lo.source]
      (oneCursor l (DyadicInverseReciprocals.middle D.reciprocals)).state=
      some (D.reciprocals.second.output.source,
        (RationalReciprocalCalls.after l (DyadicInverseReciprocals.middle D.reciprocals) q.lo).state))
    (qmin : service "qmin" [D.reciprocals.first.output.source,D.reciprocals.second.output.source] (sortCursor D.reciprocals).state=
      some ((sorted D.reciprocals).lo.source,
        (RationalSortCalls.middle l (sortCursor D.reciprocals) D.reciprocals.first.output D.reciprocals.second.output).state))
    (qmax : service "qmax" [D.reciprocals.first.output.source,D.reciprocals.second.output.source]
      (RationalSortCalls.middle l (sortCursor D.reciprocals) D.reciprocals.first.output D.reciprocals.second.output).state=
      some ((sorted D.reciprocals).hi.source,
        (RationalSortCalls.after l (sortCursor D.reciprocals) D.reciprocals.first.output D.reciprocals.second.output).state))
    (round : service "fromRI" [(sorted D.reciprocals).source,NatWrapperCalls.unsigned32 (SignedNegCalls.bit a.ok)]
      (roundCursor D.reciprocals).state=some (DyadicCasts.value D.low.source D.high.source a.ok,D.rounded.state)) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      statements c.state (.returned D.rounded.state (DyadicCasts.value D.low.source D.high.source a.ok)) := by
  have reciprocals := D.reciprocals.sequence service ctx (by omega) qSlot qBinding qi0 qv0 qi1 qv1
  have sortContext : Valid l (sortCursor D.reciprocals) := D.reciprocals.after_valid
  have rDeclaration := RationalSortLocal.declaration service sortContext D.reciprocals.first.output D.reciprocals.second.output
    _ _ (D.reciprocals.left_binding ctx (by omega)) D.reciprocals.right_binding D.sortedLive qmin qmax
  have aSort := D.reciprocals.preserve_binding ctx (by omega) aBinding
    (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have aRound := RationalSortLocal.preserve_binding sortContext D.reciprocals.first.output D.reciprocals.second.output
    aSort (by decide +kernel) (by decide +kernel)
  have rExpression : evalExpr Header.layout service 999 (roundCursor D.reciprocals).state (.var "r")=
      some ((sorted D.reciprocals).source,(roundCursor D.reciprocals).state) :=
    LocalBinding.eval service 998 (RationalSortLocal.binding l (sortCursor D.reciprocals)
      D.reciprocals.first.output D.reciprocals.second.output)
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have flagExpression : evalExpr Header.layout service 999 (roundCursor D.reciprocals).state (.field "." (.var "a") "ok")=
      some (NatWrapperCalls.unsigned32 (SignedNegCalls.bit a.ok),(roundCursor D.reciprocals).state) :=
    DyadicPairFrames.eval_ok service 997 aRound
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have returned : Run Header.layout service (.returnStmt returnExpression) (roundCursor D.reciprocals).state
      (.returned D.rounded.state (DyadicCasts.value D.low.source D.high.source a.ok)) :=
    Loops.StmtRun.returnValue ⟨1000,ExpressionTemplates.call_two Header.layout service rExpression flagExpression round⟩
  cases reciprocals with
  | next first rest =>
    cases rest with
    | next second ending =>
      cases ending
      exact Loops.SeqRun.next first (Loops.SeqRun.next second
        (Loops.SeqRun.next (Loops.StmtRun.declare rDeclaration) (Loops.SeqRun.returned returned)))

end ScopedC.DyadicInverseValidSource
