/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseCombinedEvents
namespace ScopedC.DyadicInverseBodyRuns
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicInverseConversion (Conversion parameters)
open ScopedC.DyadicInverseEventData (prefixEvents)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000
attribute [local irreducible] RationalMakeCalls.c5 RationalSortCalls.after RationalReciprocalCalls.after

def flagCursor {code : List Function} {l : PoolLayout} {c : Cursor} {a : InputI}
    (D : Conversion code l c a) : Cursor :=
  DyadicInverseFlagLocal.after l (DyadicInverseConversion.after D) D.interval

theorem flag_heap {code : List Function} {l : PoolLayout} {c : Cursor} {a : InputI}
    (D : Conversion code l c a) : (flagCursor D).state.heap.length=(parameters c a).state.heap.length+2 := by
  have returned : D.returned.state.heap.length=(parameters c a).state.heap.length := by
    rw [D.trace]
    exact (CursorEffects.shape _ _ _).1
  have tested : (DyadicInverseValidity.tested l (DyadicInverseConversion.after D) D.interval).state.heap.length=
      (DyadicInverseConversion.after D).state.heap.length := by
    rw [DyadicInverseValidity.tested_advance]
    exact (CursorEffects.shape _ _ _).1
  simp only [flagCursor,DyadicInverseFlagLocal.after,CursorLocals.allocated,allocate,List.length_append,List.length_singleton]
  rw [tested]
  simp only [DyadicInverseConversion.after,CursorLocals.allocated,allocate,List.length_append,List.length_singleton]
  rw [returned]

private theorem append {service : Call} {ss tt : List Stmt} {s middle : State} {out : Loops.Flow State Value}
    (first : Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope ss s (.continuing middle))
    (rest : Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope tt middle out) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope (ss++tt) s out := by
  induction ss generalizing s with
  | nil => cases first;exact rest
  | cons head tail ih =>
    cases first with
    | next first restFirst => exact Loops.SeqRun.next first (ih restFirst)

/-- Complete actual iinv AST execution when the proved source guard is true.
The source prefix, caller objects, branch condition and all suffix calls use
one source-closed service, not independent function-output assumptions. -/
theorem valid_body (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a) (ctx : Valid l c)
    (room : (DyadicInverseConversion.after D).top+17 < capacity)
    (V : DyadicInverseValidStages.Stages code l (flagCursor D) D.interval a.ok)
    (vctx : Valid l (flagCursor D)) (space : (flagCursor D).top+81 < capacity)
    (guard : DyadicInverseValidity.valid D.interval=true) :
    ∃service : Call,
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      Run Header.layout service Generated.f_iinv.body (parameters c a).state
        (.returned (popScope (parameters c a).state V.rounded.state) (DyadicCasts.value V.low.source V.high.source a.ok)) := by
  let ps := prefixEvents code lib D room
  let vs := DyadicInverseEventData.valid code a V
  have unique := DyadicInverseCombinedEvents.valid_keys code lib D room a V vctx space
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service_arguments (ps++vs) unique
  have pre := DyadicInverseEventLemmas.prefix_run code lib D room service
    (fun e h=>answers e (List.mem_append_left vs h))
  have qAt := DyadicInverseFlagLocal.preserve_binding D.after_valid D.interval D.q_binding
    (by decide +kernel) (by decide +kernel)
  have aAt := DyadicInverseFlagLocal.preserve_binding D.after_valid D.interval (D.a_binding ctx)
    (by decide +kernel) (by decide +kernel)
  have tail := DyadicInverseEventLemmas.valid_run code a V vctx space _ _ qAt aAt service
    (fun e h=>answers e (List.mem_append_right ps h))
  have condition : Eval Header.layout service (.unary "!" (.var "valid")) (flagCursor D).state
      (flagCursor D).state (boolean Header.layout false) :=
    ⟨2,by simpa only [guard,Bool.not_true,flagCursor,Nat.zero_add] using
      DyadicInverseFlagLocal.invalid_expression service 0 l (DyadicInverseConversion.after D) D.interval⟩
  have branch : Run Header.layout service
      (.branch (.unary "!" (.var "valid")) (.sequence (DyadicInverseFallbackSource.statements (10^30))) .skip)
      (flagCursor D).state (.continuing (flagCursor D).state) := by
    apply Loops.StmtRun.branch condition
    exact Loops.StmtRun.skip _
  have whole := append pre (Loops.SeqRun.next branch tail)
  refine ⟨service,closed,?_⟩
  rw [DyadicInverseFallbackSource.actual_body,List.append_assoc]
  exact Loops.StmtRun.sequence whole ⟨rfl,rfl⟩

/-- Complete actual AST execution of the false-guard path, including the
inner fallback scope and the outer function-body scope. The original source
literal and false validity flag are preserved. -/
theorem fallback_body (code : List Function) (lib : RationalZeroCompare.Library code)
    {l : PoolLayout} {c : Cursor} {a : InputI} (D : Conversion code l c a)
    (room : (DyadicInverseConversion.after D).top+17 < capacity)
    (F : DyadicInverseFallbackStages.Stages code l (flagCursor D) (10^30))
    (guard : DyadicInverseValidity.valid D.interval=false) :
    ∃service : Call,
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      Run Header.layout service Generated.f_iinv.body (parameters c a).state
        (.returned (popScope (parameters c a).state F.rounded.state) (DyadicCasts.value F.low.source F.high.source false)) := by
  let ps := prefixEvents code lib D room
  let fs := DyadicInverseEventData.fallback code F
  have unique := DyadicInverseCombinedEvents.fallback_keys code lib D room F
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service_arguments (ps++fs) unique
  have pre := DyadicInverseEventLemmas.prefix_run code lib D room service
    (fun e h=>answers e (List.mem_append_left fs h))
  have tail := DyadicInverseEventLemmas.fallback_run code F service
    (fun e h=>answers e (List.mem_append_right ps h))
  have inner : Run Header.layout service (.sequence (DyadicInverseFallbackSource.statements (10^30))) (flagCursor D).state
      (.returned (popScope (flagCursor D).state F.rounded.state) (DyadicCasts.value F.low.source F.high.source false)) :=
    Loops.StmtRun.sequence tail ⟨rfl,rfl⟩
  have condition : Eval Header.layout service (.unary "!" (.var "valid")) (flagCursor D).state
      (flagCursor D).state (boolean Header.layout true) :=
    ⟨2,by simpa only [guard,Bool.not_false,flagCursor,Nat.zero_add] using
      DyadicInverseFlagLocal.invalid_expression service 0 l (DyadicInverseConversion.after D) D.interval⟩
  have branch : Run Header.layout service
      (.branch (.unary "!" (.var "valid")) (.sequence (DyadicInverseFallbackSource.statements (10^30))) .skip)
      (flagCursor D).state
      (.returned (popScope (flagCursor D).state F.rounded.state) (DyadicCasts.value F.low.source F.high.source false)) := by
    apply Loops.StmtRun.branch condition
    exact inner
  have whole := append pre (Loops.SeqRun.returned (tail:=DyadicInverseValidSource.statements) branch)
  refine ⟨service,closed,?_⟩
  rw [DyadicInverseFallbackSource.actual_body,List.append_assoc]
  have raw : Run Header.layout service
      (.sequence (DyadicInversePrefix.statements++
        .branch (.unary "!" (.var "valid")) (.sequence (DyadicInverseFallbackSource.statements (10^30))) .skip::
          DyadicInverseValidSource.statements)) (parameters c a).state
      (.returned (popScope (parameters c a).state (popScope (flagCursor D).state F.rounded.state))
        (DyadicCasts.value F.low.source F.high.source false)) :=
    Loops.StmtRun.sequence whole ⟨rfl,rfl⟩
  rw [SourceFromS.scope_twice (parameters c a).state (flagCursor D).state F.rounded.state
    (by rw [flag_heap];omega)] at raw
  exact raw

end ScopedC.DyadicInverseBodyRuns
