/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseFallbackStages
import ScopedC.DyadicInversePrefix
import ScopedC.DyadicInverseValidSource
import ScopedC.CallEventService
import ScopedC.SourceRanks
namespace ScopedC.DyadicInverseFallbackSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicInverseFallbackStages (Stages wideCursor roundCursor)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000
attribute [local irreducible] RationalMakeCalls.c5

def returnExpression : Expr := .call (.var "fromRI") [.var "r",.nat 0]
def statements (n : Nat) : List Stmt := [
  .declare [{type:="Q",name:="wide",value:=some (RationalNaturalLiteralLocal.initializer n)}],
  .declare [{type:="RI",name:="r",value:=some RationalSymmetricLocal.initializer}],
  .returnStmt returnExpression]

theorem actual_body : Generated.f_iinv.body=.sequence
    (DyadicInversePrefix.statements++[
      .branch (.unary "!" (.var "valid")) (.sequence (statements (10^30))) .skip]++
      DyadicInverseValidSource.statements) := by
  have text : toString (10^30:Nat)="1000000000000000000000000000000" := by decide +kernel
  unfold statements RationalNaturalLiteralLocal.initializer
  rw [text]
  rfl

theorem sequence (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor} {n : Nat}
    (D : Stages code l c n)
    (decimal : service "decimal" [.pointer ⟨c.state.heap.length,0,[]⟩ false] (RationalNaturalLiteral.textCursor c n).state=
      some (.natObject D.literal.magSlot,D.literal.parsed.state))
    (smake : service "smake" [.natObject D.literal.magSlot,DecimalDigits.integer 0] D.literal.parsed.state=
      some ((RationalNaturalLiteral.endpoint D.literal.magSlot n).source,(next l D.literal.parsed 0).state))
    (nu : service "nu" [DecimalDigits.integer 1] (next l D.literal.parsed 0).state=
      some (.natObject (next l D.literal.parsed 0).state.nats.values.length,(next l (next l D.literal.parsed 0) 1).state))
    (qm : service "qm" [(RationalNaturalLiteral.endpoint D.literal.magSlot n).source,
      .natObject (next l D.literal.parsed 0).state.nats.values.length]
      (next l (next l D.literal.parsed 0) 1).state=
      some (D.literal.output.source,(RationalNaturalLiteral.after D.literal).state))
    (qn : service "qn" [D.literal.output.source] (wideCursor D.literal).state=
      some ((RationalSymmetricLocal.output D.literal.output).lo.source,(next l (wideCursor D.literal) 0).state))
    (round : service "fromRI" [(RationalSymmetricLocal.output D.literal.output).source,DecimalDigits.integer 0]
      (roundCursor D.literal).state=some (DyadicCasts.value D.low.source D.high.source false,D.rounded.state)) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      (statements n) c.state (.returned D.rounded.state (DyadicCasts.value D.low.source D.high.source false)) := by
  have wide := RationalNaturalLiteralLocal.declaration service D.literal decimal smake nu qm
  have wctx : Valid l (wideCursor D.literal) := CursorLocals.allocated_valid D.literal.valid "Q" "wide" D.literal.output.source
  have wlive : D.literal.output.Live (wideCursor D.literal).state := D.literal.live
  have r := RationalSymmetricLocal.declaration service wctx D.literal.output wlive _
    (RationalNaturalLiteralLocal.binding D.literal) qn
  have rExpression : evalExpr Header.layout service 999 (roundCursor D.literal).state (.var "r")=
      some ((RationalSymmetricLocal.output D.literal.output).source,(roundCursor D.literal).state) :=
    LocalBinding.eval service 998 (RationalSymmetricLocal.binding l (wideCursor D.literal) D.literal.output)
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have returned : Run Header.layout service (.returnStmt returnExpression) (roundCursor D.literal).state
      (.returned D.rounded.state (DyadicCasts.value D.low.source D.high.source false)) :=
    Loops.StmtRun.returnValue ⟨1000,ExpressionTemplates.call_two Header.layout service rExpression (by rfl) round⟩
  exact Loops.SeqRun.next (Loops.StmtRun.declare wide)
    (Loops.SeqRun.next (Loops.StmtRun.declare r) (Loops.SeqRun.returned returned))

/-- Actual complete three-statement fallback and its source-linked dyadic
result. Each of six service entries is backed by the actual lower C body. -/
theorem source_fallback (code : List Function) {l : PoolLayout} {c : Cursor} {n : Nat} (D : Stages code l c n) :
    ∃service : Call,
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
        (statements n) c.state (.returned D.rounded.state (DyadicCasts.value D.low.source D.high.source false)) ∧
      DyadicRepresentation.interval D.rounded.state (DyadicCasts.value D.low.source D.high.source false)=
        some (LeanCert.Core.IntervalDyadic.ofIntervalRat (DyadicInverseFallbackStages.symmetricInterval n) (-100),false) := by
  let N := D.literal
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"decimal",[.pointer ⟨c.state.heap.length,0,[]⟩ false],(RationalNaturalLiteral.textCursor c n).state,
      .natObject N.magSlot,N.parsed.state,SourceRanks.monotone (by omega : 3 ≤ 8) N.parserCall⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"smake",[.natObject N.magSlot,DecimalDigits.integer 0],N.parsed.state,
      (RationalNaturalLiteral.endpoint N.magSlot n).source,(next l N.parsed 0).state,
      SourceRanks.monotone (by omega : 4 ≤ 8) N.makeCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"nu",[DecimalDigits.integer 1],(next l N.parsed 0).state,
      .natObject (next l N.parsed 0).state.nats.values.length,(next l (next l N.parsed 0) 1).state,
      SourceRanks.monotone (by omega : 2 ≤ 8) N.unitCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qm",[(RationalNaturalLiteral.endpoint N.magSlot n).source,.natObject (next l N.parsed 0).state.nats.values.length],
      (next l (next l N.parsed 0) 1).state,N.output.source,(RationalNaturalLiteral.after N).state,
      SourceRanks.monotone (by omega : 5 ≤ 8) N.rationalCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qn",[N.output.source],(wideCursor N).state,(RationalSymmetricLocal.output N.output).lo.source,
      (next l (wideCursor N) 0).state,SourceRanks.monotone (by omega : 6 ≤ 8) D.negate⟩
  let e5 : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[(RationalSymmetricLocal.output N.output).source,DecimalDigits.integer 0],(roundCursor N).state,
      DyadicCasts.value D.low.source D.high.source false,D.rounded.state,D.roundCall⟩
  let events := [e0,e1,e2,e3,e4,e5]
  have unique : (events.map CallEvents.key).Nodup := by simp [events,CallEvents.key,e0,e1,e2,e3,e4,e5]
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service events unique
  refine ⟨service,closed,?_,D.decoded⟩
  exact sequence service D (answers e0 (by simp [events])) (answers e1 (by simp [events]))
    (answers e2 (by simp [events])) (answers e3 (by simp [events])) (answers e4 (by simp [events]))
    (answers e5 (by simp [events]))

end ScopedC.DyadicInverseFallbackSource
