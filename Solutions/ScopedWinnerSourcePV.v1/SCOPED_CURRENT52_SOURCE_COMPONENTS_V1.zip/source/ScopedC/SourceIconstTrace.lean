/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceIconst
import ScopedC.SourceFromRITraceMath
import ScopedC.RationalPointBody
import ScopedC.CallEventNames

namespace ScopedC.SourceIconstTrace
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.FromRIFrames ScopedC.DyadicRepresentation LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

open ScopedC.SourceIconst (framed scale_framed)

/-- Actual iconst source executes point(q), casts its signed literal-one
argument in fromRI, rounds through all six verified source calls, returns its
typed I value and removes both caller frames. The decoded output is exactly
the unchanged old -100 singleton constructor. -/
theorem iconst_traced (code : List Function) (installed : Generated.f_iconst∈code)
    (pointInstalled : Generated.f_point∈code) (fromRIInstalled : Generated.f_fromRI∈code)
    (qtInstalled : Generated.f_qt∈code) (floorInstalled : Generated.f_floorQ∈code)
    (ceilInstalled : Generated.f_ceilQ∈code) (qnInstalled : Generated.f_qn∈code)
    (snInstalled : Generated.f_sn∈code) (qtLib : RationalMultiplyCalls.Library code)
    (roundLib : FloorQNegativeCalls.Library code) {l : PoolLayout} {c : Cursor}
    (valid : Valid l c) (q : Input) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (live : q.Live c.state)
    (positive : 0 < q.denominator) (room : c.top+37 < capacity) :
    ∃ out : Cursor, ∃ lo hi : Endpoint, ∃trace : List Nat,
      SourceCall Header.layout code 9 "iconst" [q.source] c.state
        (DyadicCasts.value lo.source hi.source true) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (IntervalDyadic.ofIntervalRat (IntervalRat.singleton q.mathematical.value) (-100),true) ∧
      out=CursorFrames.advance l c trace ∧ trace.length ≤ 38 := by
  let a : InputRI := ⟨q,q⟩
  have frameValid : Valid l (framed c q) := OneFrames.context_frame valid "Q" "q" q.source
  have pairLive : a.Live (framed c q).state := ⟨live,live⟩
  have pointCall : SourceCall Header.layout code 1 "point" [q.source] (framed c q).state
      a.source (framed c q).state :=
    RationalPointCalls.point_closed code pointInstalled live.1 live.2 (SignedNegCalls.bit_bound _)
  obtain ⟨inside,lo,hi,trace,fromRI,insideValid,loLive,hiLive,decoded,insideTrace,traceLength⟩ :=
    SourceFromRITraceMath.with_arguments_traced code fromRIInstalled qtInstalled floorInstalled ceilInstalled qnInstalled
      snInstalled qtLib roundLib frameValid a true (scale_framed q scale) pairLive positive positive le_rfl room
      (DecimalDigits.integer 1) (SourceFromRIArguments.bind_literal_one (framed c q).state a pairLive)
  let ep : CallEvents.Event Header.layout code 8 :=
    ⟨"point",[q.source],(framed c q).state,a.source,(framed c q).state,
      SourceRanks.monotone (by omega : 1 ≤ 8) pointCall⟩
  let er : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[a.source,DecimalDigits.integer 1],(framed c q).state,
      DyadicCasts.value lo.source hi.source true,inside.state,fromRI⟩
  let events := [ep,er]
  have unique : (events.map CallEvents.Event.name).Nodup := by
    change (["point","fromRI"]:List String).Nodup
    decide +kernel
  let service := CallEvents.service events
  have pointAnswer := CallEvents.service_self_names events unique ep (by simp [events])
  have fromRIAnswer := CallEvents.service_self_names events unique er (by simp [events])
  have readQ : evalExpr Header.layout service 997 (framed c q).state (.var "q")=
      some (q.source,(framed c q).state) :=
    TypedFrames.allocate_eval Header.layout service 996 {c.state with env:=[]}
      "Q" "q" q.source rfl (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have pointExpr : evalExpr Header.layout service 998 (framed c q).state (.call (.var "point") [.var "q"])=
      some (a.source,(framed c q).state) :=
    ExpressionTemplates.call_one Header.layout service readQ pointAnswer
  have expression : Eval Header.layout service (.call (.var "fromRI")
      [.call (.var "point") [.var "q"],.nat 1]) (framed c q).state inside.state
      (DyadicCasts.value lo.source hi.source true) :=
    ⟨1000,ExpressionTemplates.call_two Header.layout service pointExpr (by rfl) fromRIAnswer⟩
  have body : Run Header.layout service Generated.f_iconst.body (framed c q).state
      (.returned (popScope (framed c q).state inside.state) (DyadicCasts.value lo.source hi.source true)) :=
    Loops.StmtRun.sequence (Loops.SeqRun.returned (Loops.StmtRun.returnValue expression)) ⟨rfl,rfl⟩
  let out := PoolContextPop.unframe c.state inside
  have bp := (List.getElem?_eq_some_iff.mp valid.pool_read).choose
  have bt := (List.getElem?_eq_some_iff.mp valid.top_read).choose
  have bh := (List.getElem?_eq_some_iff.mp valid.high_read).choose
  have outTrace : out=CursorFrames.advance l c trace := by
    change PoolContextPop.unframe c.state inside=_
    rw [insideTrace]
    change PoolContextPop.unframe c.state (CursorFrames.advance l (CursorSingleFrames.framed c "Q" "q" q.source) trace)=_
    rw [CursorSingleFrames.advance_framed valid "Q" "q" q.source trace (by omega)]
    have pop := OneFrames.pop_frame (s:=c.state) "Q" "q" q.source
      (CursorEffects.shape l c trace).1 (CursorEffects.shape l c trace).2
    dsimp only [PoolContextPop.unframe,CursorSingleFrames.framed]
    rw [pop]
  refine ⟨out,lo,hi,trace,?_,PoolContextPop.valid insideValid bp bt bh,loLive,hiLive,decoded,outTrace,traceLength⟩
  apply installed_body (f:=Generated.f_iconst) (rank:=8) (service:=service) installed
    (fun _ _ _ _ _ h => CallEvents.service_closed events h)
    (TypedFrames.bind_one Header.layout c.state "Q" "q" q.source q.source
      (RecordCasts.rational_record {c.state with env:=[]} 97 "Q" (by decide +kernel)
        live.1 live.2 (SignedNegCalls.bit_bound _))) body
  constructor
  · exact DyadicCasts.record _ 97 "static I" (by decide +kernel) lo.source hi.source true
      (Endpoint.cast 97 "S" (by decide +kernel) loLive)
      (Endpoint.cast 97 "S" (by decide +kernel) hiLive)
  · exact (SourceFromS.scope_twice c.state (framed c q).state inside.state
      (by simp [framed,OneFrames.frame,allocate])).symm

end ScopedC.SourceIconstTrace
