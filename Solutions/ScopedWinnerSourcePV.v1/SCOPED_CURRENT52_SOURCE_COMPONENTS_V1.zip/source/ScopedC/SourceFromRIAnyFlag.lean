/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceFromRITraceMath
import ScopedC.NumericIntervalCompleteness
namespace ScopedC.SourceFromRIAnyFlag
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.FromRIFrames ScopedC.DyadicRepresentation
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

private theorem rat_ext {a b : IntervalRat} (lo : a.lo=b.lo) (hi : a.hi=b.hi) : a=b := by
  cases a
  cases b
  simp_all

/-- The actual RI output and actual source flag representation are composed
with fromRI. A flag's ordinary unsigned parameter cast must be proved for
all states; this is an ABI conversion, not an application-output premise.
Both the original exact rounding and complete allocation trace are retained. -/
theorem source (code : List Function) (installed : Generated.f_fromRI∈code)
    (qtInstalled : Generated.f_qt∈code) (floorInstalled : Generated.f_floorQ∈code)
    (ceilInstalled : Generated.f_ceilQ∈code) (qnInstalled : Generated.f_qn∈code)
    (snInstalled : Generated.f_sn∈code) (qtLib : RationalMultiplyCalls.Library code)
    (roundLib : FloorQNegativeCalls.Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (input : Value) (ok : Bool) (flagInput : Value) (r : IntervalRat)
    (flagCast : ∀s : State,castValue Header.layout s 100 "unsigned int" flagInput=
      some (NatWrapperCalls.unsigned32 (SignedNegCalls.bit ok))) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100))
    (decodedInput : NumericRepresentation.interval c.state input=some r) (room : c.top+37 < capacity) :
    ∃out : Cursor,∃lo hi : Endpoint,∃trace : List Nat,
      SourceCall Header.layout code 8 "fromRI" [input,flagInput] c.state (DyadicCasts.value lo.source hi.source ok) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source ok)=
        some (IntervalDyadic.ofIntervalRat r (-100),ok) ∧
      out=CursorFrames.advance l c trace ∧ trace.length ≤ 38 := by
  obtain ⟨pair,pairSource,pairLive,pairPositive,lowValue,highValue⟩ := NumericInputCompleteness.interval decodedInput
  let a : InputRI := ⟨pair.lo,pair.hi⟩
  have ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value := by
    change pair.lo.mathematical.value ≤ pair.hi.mathematical.value
    rw [lowValue,highValue]
    exact r.le
  have same : (⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩:IntervalRat)=r := rat_ext lowValue highValue
  have arguments : bindArgs Header.layout Generated.f_fromRI.parameters [a.source,flagInput] c.state=
      some (parameters c.state a ok) :=
    TypedFrames.bind_two Header.layout c.state "RI" "a" "unsigned int" "ok" a.source flagInput a.source
      (NatWrapperCalls.unsigned32 (SignedNegCalls.bit ok))
      (InputRI.cast {c.state with env:=[]} 96 a pairLive "RI" (by decide +kernel))
      (flagCast (allocate {c.state with env:=[]} "RI" "a" (some a.source)))
  obtain ⟨out,lo,hi,trace,source,valid,loLive,hiLive,decoded,afterTrace,length⟩ :=
    SourceFromRITraceMath.with_arguments_traced code installed qtInstalled floorInstalled ceilInstalled qnInstalled snInstalled
      qtLib roundLib ctx a ok scale pairLive pairPositive.1 pairPositive.2 ordered room flagInput arguments
  have sourceEq : a.source=input := pairSource
  rw [sourceEq] at source
  rw [same] at decoded
  exact ⟨out,lo,hi,trace,source,valid,loLive,hiLive,decoded,afterTrace,length⟩

end ScopedC.SourceFromRIAnyFlag
