/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceFromRIBoolean
import ScopedC.CursorLocals
namespace ScopedC.FromRIAllocationTrace
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.FromRIFrames ScopedC.FromRIStages
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

private theorem unframe_factor (before : State) (out : Cursor)
    (length : out.state.heap.length=before.heap.length) (environment : out.state.env=before.env)
    (a : InputRI) (ok : Bool) (factor : RationalPairFrames.Input) :
    PoolContextPop.unframe before
      (CursorLocals.allocated (CursorFrames.framed out "RI" "a" a.source "unsigned int" "ok"
        (NatWrapperCalls.unsigned32 (SignedNegCalls.bit ok))) "Q" "factor" factor.source)=out := by
  cases out
  rename_i state cells top high
  cases state
  simp_all [PoolContextPop.unframe,CursorLocals.allocated,CursorFrames.framed,TwoFrames.frame,
    allocate,popScope,List.append_assoc,List.take_append]

def steps {code : List Function} {l : PoolLayout} {c : Cursor} {a : InputRI} {ok : Bool} {slot d : Nat}
    (D : Stages code l c a ok slot d) : List Nat := [0,1]++D.lowSteps++D.highSteps

/-- Directed rounding's complete actual helper trace, with all RI/flag/factor
stack frames removed. The trace is derived from source execution stages and
retains each allocation, rather than assuming caller memory survived. -/
theorem final_advance {code : List Function} {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    {a : InputRI} {ok : Bool} {slot d : Nat} (D : Stages code l c a ok slot d)
    (room : c.top+37 < capacity) : SourceFromRI.final D=CursorFrames.advance l c (steps D) := by
  let core := FromRIFactor.c2 l c
  have coreValid : Valid l core := next_valid 1 (next_valid 0 ctx (by omega)) (by change c.top+1 < capacity;omega)
  let tail := D.lowSteps++D.highSteps
  have tailRoom : core.top+tail.length ≤ capacity := by
    change c.top+1+1+(D.lowSteps++D.highSteps).length ≤ capacity
    rw [List.length_append]
    have lowLength:=D.lowLength
    have highLength:=D.highLength
    omega
  have finishTrace : D.finish=CursorFrames.advance l (start l c a ok slot d) tail := by
    rw [D.finishTrace,D.middleTrace,←CursorSingleFrames.advance_append]
  have startEq : start l c a ok slot d=
      CursorLocals.allocated (CursorFrames.framed core "RI" "a" a.source "unsigned int" "ok"
        (NatWrapperCalls.unsigned32 (SignedNegCalls.bit ok))) "Q" "factor" (FromRIFactor.factor l c slot d).source := rfl
  have frameValid : Valid l (CursorFrames.framed core "RI" "a" a.source "unsigned int" "ok"
      (NatWrapperCalls.unsigned32 (SignedNegCalls.bit ok))) :=
    CursorFrames.framed_valid coreValid "RI" "a" a.source "unsigned int" "ok" _
  unfold SourceFromRI.final
  rw [finishTrace,startEq,CursorLocals.advance_allocated frameValid tail tailRoom,
    CursorFrames.advance_framed coreValid tail tailRoom]
  have coreShape : core.state.heap.length=c.state.heap.length ∧ core.state.env=c.state.env :=
    ⟨(PoolCursor.shape l (FromRIFactor.c1 l c) 1).1.trans (PoolCursor.shape l c 0).1,
      (PoolCursor.shape l (FromRIFactor.c1 l c) 1).2.trans (PoolCursor.shape l c 0).2⟩
  have tailShape:=CursorEffects.shape l core tail
  rw [unframe_factor c.state (CursorFrames.advance l core tail)
    (tailShape.1.trans coreShape.1) (tailShape.2.trans coreShape.2)]
  change CursorFrames.advance l core tail=CursorFrames.advance l c ([0,1]++tail)
  exact (CursorSingleFrames.advance_append l c [0,1] tail).symm

theorem length {code : List Function} {l : PoolLayout} {c : Cursor} {a : InputRI} {ok : Bool} {slot d : Nat}
    (D : Stages code l c a ok slot d) : (steps D).length ≤ 38 := by
  simp only [steps,List.length_append,List.length_cons,List.length_nil]
  have lowLength:=D.lowLength
  have highLength:=D.highLength
  omega

end ScopedC.FromRIAllocationTrace
