/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseBody
import ScopedC.NumericToRIRefinement
namespace ScopedC.NumericDyadicInverseRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.DyadicValueEquivalence
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicInverseCalls (Library)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

private theorem rat_ext {a b : IntervalRat} (lo : a.lo=b.lo) (hi : a.hi=b.hi) : a=b := by
  cases a
  cases b
  simp_all

/-- Actual old iinv source to the unchanged original invIntervalDyadic
consumer, including the false-domain flag and coarse zero input encodings.
No stronger domain or altered fallback is introduced. -/
theorem iinv_math (code : List Function) (installed : Generated.f_iinv∈code) (lib : Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a : InputI) (live : a.Live c.state)
    (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (room : c.top+198 < capacity)
    (old : IntervalDyadic) (rep : Represents c.state a.source old a.ok)
    (cfg : LeanCert.Engine.DyadicConfig) (precision : cfg.precision = -100) :
    ∃out : Cursor,∃lo hi : Endpoint,
      SourceCall Header.layout code 9 "iinv" [a.source] c.state
        (DyadicCasts.value lo.source hi.source (a.ok&&DyadicInverseAlgorithm.good old.toIntervalRat)) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      Represents out.state (DyadicCasts.value lo.source hi.source (a.ok&&DyadicInverseAlgorithm.good old.toIntervalRat))
        (LeanCert.Engine.invIntervalDyadic old cfg) (a.ok&&DyadicInverseAlgorithm.good old.toIntervalRat) := by
  have words := NumericToRIRefinement.represented_words a.lo a.hi a.ok live.1 live.2 ordered old rep
  have input : DyadicToRIPair.divided a (2^100) ordered=old.toIntervalRat := rat_ext words.1.symm words.2.symm
  obtain ⟨out,lo,hi,source,valid,loLive,hiLive,decoded⟩ :=
    DyadicInverseCalls.iinv_closed code installed lib ctx a live ordered scale room
  rw [input] at source decoded
  have output : LeanCert.Engine.invIntervalDyadic old cfg=
      IntervalDyadic.ofIntervalRat (LeanCert.Engine.invInterval old.toIntervalRat) (-100) := by
    simp only [LeanCert.Engine.invIntervalDyadic,precision]
  rw [←output] at decoded
  exact ⟨out,lo,hi,source,valid,loLive,hiLive,_,decoded,same_refl _⟩

end ScopedC.NumericDyadicInverseRefinement
