/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicValueEquivalence
import ScopedNumerical.BoxSound
namespace ScopedC.DyadicRoundingValues
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

private theorem pow2 (n : Nat) : LeanCert.Core.Dyadic.pow2Nat n=2^n := by
  simp [LeanCert.Core.Dyadic.pow2Nat,Nat.shiftLeft_eq]

theorem scaled (a : LeanCert.Core.Dyadic) (p : Nat) :
    a.toRat*(2:Rat)^p=(a.mantissa:Rat)*(2:Rat)^(a.exponent+(p:Int)) := by
  rw [LeanCert.Core.Dyadic.toRat_eq,zpow_add₀ (by norm_num : (2:Rat)≠0),zpow_natCast]
  ring

private theorem scaled_int (a : LeanCert.Core.Dyadic) (p : Nat) (h : -(p:Int) ≤ a.exponent) :
    a.toRat*(2:Rat)^p=((a.mantissa*(2^(a.exponent+(p:Int)).toNat:Nat):Int):Rat) := by
  rw [scaled]
  have exp : a.exponent+(p:Int)=((a.exponent+(p:Int)).toNat:Int) := by omega
  conv_lhs => rw [exp,zpow_natCast]
  simp only [Int.cast_mul,Int.cast_pow,Int.cast_ofNat,Int.cast_natCast,Nat.cast_pow,Nat.cast_ofNat]

private theorem scaled_div (a : LeanCert.Core.Dyadic) (p : Nat) (h : ¬(-(p:Int) ≤ a.exponent)) :
    a.toRat*(2:Rat)^p=(a.mantissa:Rat)/(2:Rat)^((-(p:Int)-a.exponent).toNat) := by
  rw [scaled]
  have exp : a.exponent+(p:Int)=-(((-(p:Int)-a.exponent).toNat):Int) := by omega
  rw [exp,zpow_neg,zpow_natCast]
  rfl

/-- Exact value of the existing downward dyadic shift, including endpoints
whose stored exponent is coarser than the target grid. -/
theorem down (a : LeanCert.Core.Dyadic) (p : Nat) :
    (a.shiftDown (-(p:Int))).toRat=(⌊a.toRat*(2:Rat)^p⌋:Rat)/(2:Rat)^p := by
  by_cases h : -(p:Int) ≤ a.exponent
  · rw [LeanCert.Core.Dyadic.shiftDown,if_pos h]
    apply (eq_div_iff (by positivity : (2:Rat)^p≠0)).2
    have floor : ⌊a.toRat*(2:Rat)^p⌋=a.mantissa*(2^(a.exponent+(p:Int)).toNat:Nat) := by
      rw [scaled_int a p h]
      exact Int.floor_intCast _
    rw [floor]
    exact scaled_int a p h
  · rw [LeanCert.Core.Dyadic.shiftDown,if_neg h,LeanCert.Core.Dyadic.toRat_eq]
    simp only [LeanCert.Core.Dyadic.shiftRightInt,pow2,zpow_neg,zpow_natCast]
    rw [scaled_div a p h]
    have denom : (0:Int)<(2^((-(p:Int)-a.exponent).toNat):Nat) := by positivity
    rw [show (2:Rat)^((-(p:Int)-a.exponent).toNat)=((2^((-(p:Int)-a.exponent).toNat):Nat):Int) by simp,
      Int.floor_div_cast_of_nonneg denom.le,Int.floor_intCast]
    rfl

private theorem ceil_div (m d : Int) (hd : 0 < d) :
    ⌈(m:Rat)/(d:Rat)⌉=m/d+(if m%d=0 then 0 else 1) := by
  have remNonneg := Int.emod_nonneg m (by omega : d≠0)
  have remLt := Int.emod_lt_of_pos m hd
  have split := Int.ediv_mul_add_emod m d
  have denRat : (0:Rat)<(d:Rat) := by exact_mod_cast hd
  by_cases zero : m%d=0
  · simp only [zero,↓reduceIte,add_zero]
    apply Int.ceil_eq_iff.mpr
    constructor
    · apply (lt_div_iff₀ denRat).2
      have eq : (m:Rat)=((m/d:Int):Rat)*(d:Rat) := by exact_mod_cast (by nlinarith [split] : m=(m/d)*d)
      rw [eq]
      nlinarith
    · apply (div_le_iff₀ denRat).2
      exact_mod_cast (by nlinarith [split] : m ≤ (m/d)*d)
  · have remPos : 0 < m%d := by omega
    simp only [zero,↓reduceIte]
    apply Int.ceil_eq_iff.mpr
    constructor
    · apply (lt_div_iff₀ denRat).2
      exact_mod_cast (by nlinarith [split] : (m/d+1-1)*d < m)
    · apply (div_le_iff₀ denRat).2
      exact_mod_cast (by nlinarith [split] : m ≤ (m/d+1)*d)

/-- Exact value of the existing upward shift. Its remainder branch is proved
to implement mathematical ceiling; it is not an independently guessed bound. -/
theorem up (a : LeanCert.Core.Dyadic) (p : Nat) :
    (a.shiftUp (-(p:Int))).toRat=(⌈a.toRat*(2:Rat)^p⌉:Rat)/(2:Rat)^p := by
  by_cases h : -(p:Int) ≤ a.exponent
  · rw [LeanCert.Core.Dyadic.shiftUp,if_pos h]
    apply (eq_div_iff (by positivity : (2:Rat)^p≠0)).2
    have ceil : ⌈a.toRat*(2:Rat)^p⌉=a.mantissa*(2^(a.exponent+(p:Int)).toNat:Nat) := by
      rw [scaled_int a p h]
      exact Int.ceil_intCast _
    rw [ceil]
    exact scaled_int a p h
  · rw [LeanCert.Core.Dyadic.shiftUp,if_neg h,scaled_div a p h]
    have denom : (0:Int)<(2^((-(p:Int)-a.exponent).toNat):Nat) := by positivity
    rw [show (2:Rat)^((-(p:Int)-a.exponent).toNat)=((2^((-(p:Int)-a.exponent).toNat):Nat):Int) by simp,
      ceil_div a.mantissa _ denom]
    dsimp only
    by_cases rem : a.mantissa % (2^((-(p:Int)-a.exponent).toNat):Nat)=0
    · have bits : LeanCert.Core.Dyadic.hasLowBits a.mantissa ((-(p:Int)-a.exponent).toNat)=false := by
        simp only [LeanCert.Core.Dyadic.hasLowBits,pow2,rem,ne_eq,not_true_eq_false,decide_false]
      rw [bits]
      simp only [Bool.false_eq_true,↓reduceIte,rem,add_zero,LeanCert.Core.Dyadic.toRat_eq,
        LeanCert.Core.Dyadic.shiftRightInt,pow2,zpow_neg,zpow_natCast]
      rfl
    · have bits : LeanCert.Core.Dyadic.hasLowBits a.mantissa ((-(p:Int)-a.exponent).toNat)=true := by
        simp only [LeanCert.Core.Dyadic.hasLowBits,pow2,rem,ne_eq,not_false_eq_true,decide_true]
      rw [bits]
      simp only [↓reduceIte,rem,LeanCert.Core.Dyadic.toRat_eq,
        LeanCert.Core.Dyadic.shiftRightInt,pow2,zpow_neg,zpow_natCast,Int.cast_add,Int.cast_one]
      rfl

/-- Value correspondence with rational outward conversion for the original
roundOut, valid for every stored dyadic exponent, including coarser zero. -/
theorem roundOut_values (a : IntervalDyadic) (p : Nat) :
    DyadicValueEquivalence.SameValues
      (IntervalDyadic.ofIntervalRat a.toIntervalRat (-(p:Int))) (a.roundOut (-(p:Int))) := by
  constructor
  · rw [show (a.roundOut (-(p:Int))).lo=a.lo.shiftDown (-(p:Int)) from rfl,down]
    simp [IntervalDyadic.ofIntervalRat,IntervalDyadic.toIntervalRat,LeanCert.Core.Dyadic.ofInt,LeanCert.Core.Dyadic.scale2,
      LeanCert.Core.Dyadic.toRat_eq,zpow_neg,zpow_natCast,div_eq_mul_inv]
  · rw [show (a.roundOut (-(p:Int))).hi=a.hi.shiftUp (-(p:Int)) from rfl,up]
    simp [IntervalDyadic.ofIntervalRat,IntervalDyadic.toIntervalRat,LeanCert.Core.Dyadic.ofInt,LeanCert.Core.Dyadic.scale2,
      LeanCert.Core.Dyadic.toRat_eq,zpow_neg,zpow_natCast,div_eq_mul_inv]

end ScopedC.DyadicRoundingValues
