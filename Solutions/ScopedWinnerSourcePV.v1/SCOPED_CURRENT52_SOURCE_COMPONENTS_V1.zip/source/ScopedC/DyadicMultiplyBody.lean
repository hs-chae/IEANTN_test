/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicMultiplyStages
import ScopedC.CallEventService
namespace ScopedC.DyadicMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicToRIPair (base steps)
open ScopedC.DyadicMultiplyStages (Library Stages productCursor productValue)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] RationalIntervalMultiplyCalls.after

/-- Actual parsed imul body, including both nested toRI calls, actual rmul,
actual C short-circuit flag evaluation, actual fromRI and typed return/scopes.
The numerical result is exactly the original rational product rounded at -100.
All application computations are proved source calls, not execution oracles. -/
theorem imul_closed (code : List Function) (installed : Generated.f_imul∈code) (lib : Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : InputI)
    (ha : a.Live c.state) (hb : b.Live c.state)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (room : c.top+137 < capacity) :
    ∃out : Cursor,∃lo hi : Endpoint,
      SourceCall Header.layout code 9 "imul" [a.source,b.source] c.state
        (DyadicCasts.value lo.source hi.source (a.ok&&b.ok)) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source (a.ok&&b.ok))=
        some (IntervalDyadic.ofIntervalRat
          (IntervalRat.mul (DyadicToRIPair.divided a (2^100) oa) (DyadicToRIPair.divided b (2^100) ob)) (-100),a.ok&&b.ok) := by
  obtain ⟨D⟩ := DyadicMultiplyStages.stages_exist code lib ctx a b ha hb oa ob scale room
  let T := D.conversions
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"toRI",[a.source],(base c a b).state,T.left.source,T.first.state,
      SourceRanks.monotone (by omega : 7 ≤ 8) T.firstCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"toRI",[b.source],T.first.state,T.right.source,T.second.state,
      SourceRanks.monotone (by omega : 7 ≤ 8) T.secondCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"rmul",[T.left.source,T.right.source],T.second.state,productValue T,(productCursor T).state,D.productCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[productValue T,boolean Header.layout (a.ok&&b.ok)],(productCursor T).state,
      DyadicCasts.value D.low.source D.high.source (a.ok&&b.ok),D.inside.state,D.roundCall⟩
  let events := [e1,e2,e3,e4]
  have size : T.first.state.nats.values.length=(base c a b).state.nats.values.length+10 := by
    rw [T.firstTrace,CursorEffects.size]
    rfl
  have neq : (base c a b).state.nats.values.length ≠ T.first.state.nats.values.length := by omega
  have unique : (events.map CallEvents.key).Nodup := by
    simpa [events,CallEvents.key,e1,e2,e3,e4] using neq
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service events unique
  have answer1 := answers e1 (by simp [events])
  have answer2 := answers e2 (by simp [events])
  have answer3 := answers e3 (by simp [events])
  have answer4 := answers e4 (by simp [events])
  have expression1 : evalExpr Header.layout service 998 (base c a b).state (.call (.var "toRI") [.var "a"])=
      some (T.left.source,T.first.state) :=
    ExpressionTemplates.call_one Header.layout service
      (LocalBinding.eval service 996 (DyadicPairFrames.a_at c.state a b)
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) answer1
  have expression2 : evalExpr Header.layout service 998 T.first.state (.call (.var "toRI") [.var "b"])=
      some (T.right.source,T.second.state) :=
    ExpressionTemplates.call_one Header.layout service
      (LocalBinding.eval service 996 (T.first_b_at ctx)
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) answer2
  have productExpr : evalExpr Header.layout service 999 (base c a b).state
      (.call (.var "rmul") [.call (.var "toRI") [.var "a"],.call (.var "toRI") [.var "b"]])=
      some (productValue T,(productCursor T).state) :=
    ExpressionTemplates.call_two Header.layout service expression1 expression2 answer3
  have aAt := DyadicMultiplyStages.product_binding T ctx (T.second_a_at ctx) (by omega)
  have bAt := DyadicMultiplyStages.product_binding T ctx (T.second_b_at ctx) (by omega)
  have flagExpr : evalExpr Header.layout service 999 (productCursor T).state
      (.binary "&&" (.field "." (.var "a") "ok") (.field "." (.var "b") "ok"))=
      some (boolean Header.layout (a.ok&&b.ok),(productCursor T).state) :=
    DyadicPairFrames.logical_and service a.ok b.ok
      (DyadicPairFrames.eval_ok service 996 aAt
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
      (DyadicPairFrames.eval_ok service 996 bAt
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
  have expression : Eval Header.layout service
      (.call (.var "fromRI") [.call (.var "rmul") [.call (.var "toRI") [.var "a"],.call (.var "toRI") [.var "b"]],
        .binary "&&" (.field "." (.var "a") "ok") (.field "." (.var "b") "ok")])
      (base c a b).state D.inside.state (DyadicCasts.value D.low.source D.high.source (a.ok&&b.ok)) :=
    ⟨1000,ExpressionTemplates.call_two Header.layout service productExpr flagExpr answer4⟩
  have body : Run Header.layout service Generated.f_imul.body (base c a b).state
      (.returned (popScope (base c a b).state D.inside.state) (DyadicCasts.value D.low.source D.high.source (a.ok&&b.ok))) :=
    Loops.StmtRun.sequence (Loops.SeqRun.returned (Loops.StmtRun.returnValue expression)) ⟨rfl,rfl⟩
  let out := PoolContextPop.unframe c.state D.inside
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  refine ⟨out,D.low,D.high,?_,PoolContextPop.valid D.insideValid hp ht hh,D.lowLive,D.highLive,D.decoded⟩
  apply installed_body (f:=Generated.f_imul) (rank:=8) (service:=service) installed closed
    (DyadicPairFrames.bind a b ha hb) body
  constructor
  · exact DyadicCasts.record _ 97 "static I" (by decide +kernel) D.low.source D.high.source (a.ok&&b.ok)
      (Endpoint.cast 97 "S" (by decide +kernel) D.lowLive) (Endpoint.cast 97 "S" (by decide +kernel) D.highLive)
  · exact (SourceFromS.scope_twice c.state (base c a b).state D.inside.state
      (by simp [base,DyadicPairFrames.framed,CursorFrames.framed,TwoFrames.frame,allocate])).symm

end ScopedC.DyadicMultiplyCalls
