/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSortCalls
import ScopedC.LocalBindingSeparation
import ScopedC.ReadonlyCallEffects
namespace ScopedC.RationalSortLocal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000
attribute [local irreducible] RationalSortCalls.after

def initializer : Expr := .record [
  .call (.var "qmin") [.var "l",.var "h"],
  .call (.var "qmax") [.var "l",.var "h"]]
def after (l : PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  CursorLocals.allocated (RationalSortCalls.after l c a b) "RI" "r" (RationalSortCalls.output l c a b).source

theorem expression (service : Call) {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input)
    (leftSlot rightSlot : Nat) (left : LocalBinding.At c.state "l" "Q" a.source leftSlot)
    (right : LocalBinding.At c.state "h" "Q" b.source rightSlot)
    (qmin : service "qmin" [a.source,b.source] c.state=
      some ((RationalSortCalls.low l c a b).source,(RationalSortCalls.middle l c a b).state))
    (qmax : service "qmax" [a.source,b.source] (RationalSortCalls.middle l c a b).state=
      some ((RationalSortCalls.high l c a b).source,(RationalSortCalls.after l c a b).state)) :
    evalExpr Header.layout service 1000 c.state initializer=
      some (.aggregate [(RationalSortCalls.low l c a b).source,(RationalSortCalls.high l c a b).source],
        (RationalSortCalls.after l c a b).state) := by
  have lsafe := LocalBinding.noncounter_separated ctx left (by decide +kernel)
  have rsafe := LocalBinding.noncounter_separated ctx right (by decide +kernel)
  have nextLeft : LocalBinding.At (RationalSortCalls.middle l c a b).state "l" "Q" a.source leftSlot := by
    rw [RationalSortCalls.middle,RationalCompareFraming.final_eq_advance]
    exact LocalBinding.advance left _ lsafe.1 lsafe.2.1 lsafe.2.2
  have nextRight : LocalBinding.At (RationalSortCalls.middle l c a b).state "h" "Q" b.source rightSlot := by
    rw [RationalSortCalls.middle,RationalCompareFraming.final_eq_advance]
    exact LocalBinding.advance right _ rsafe.1 rsafe.2.1 rsafe.2.2
  exact ExpressionTemplates.record_two Header.layout service
    (ExpressionTemplates.call_two Header.layout service
      (LocalBinding.eval service 997 left (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
      (LocalBinding.eval service 997 right (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) qmin)
    (ExpressionTemplates.call_two Header.layout service
      (LocalBinding.eval service 997 nextLeft (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
      (LocalBinding.eval service 997 nextRight (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) qmax)

theorem declaration (service : Call) {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input)
    (leftSlot rightSlot : Nat) (left : LocalBinding.At c.state "l" "Q" a.source leftSlot)
    (right : LocalBinding.At c.state "h" "Q" b.source rightSlot)
    (live : (RationalSortCalls.output l c a b).Live (RationalSortCalls.after l c a b).state)
    (qmin : service "qmin" [a.source,b.source] c.state=
      some ((RationalSortCalls.low l c a b).source,(RationalSortCalls.middle l c a b).state))
    (qmax : service "qmax" [a.source,b.source] (RationalSortCalls.middle l c a b).state=
      some ((RationalSortCalls.high l c a b).source,(RationalSortCalls.after l c a b).state)) :
    Declare Header.layout service [{type:="RI",name:="r",value:=some initializer}] c.state (after l c a b).state := by
  have expr := expression service ctx a b leftSlot rightSlot left right qmin qmax
  have cl : castValue Header.layout (RationalSortCalls.after l c a b).state 99 "Q"
      (RationalSortCalls.low l c a b).source=some (RationalSortCalls.low l c a b).source := RecordCasts.rational_record (RationalSortCalls.after l c a b).state 96 "Q" (by decide +kernel)
    live.1.1 live.1.2 (SignedNegCalls.bit_bound _)
  have ch : castValue Header.layout (RationalSortCalls.after l c a b).state 99 "Q"
      (RationalSortCalls.high l c a b).source=some (RationalSortCalls.high l c a b).source := RecordCasts.rational_record (RationalSortCalls.after l c a b).state 96 "Q" (by decide +kernel)
    live.2.1 live.2.2 (SignedNegCalls.bit_bound _)
  have cast : castValue Header.layout (RationalSortCalls.after l c a b).state 100 "RI"
      (.aggregate [(RationalSortCalls.low l c a b).source,(RationalSortCalls.high l c a b).source])=
        some (RationalSortCalls.output l c a b).source := IntervalCasts.aggregate (RationalSortCalls.after l c a b).state 96 _ _ cl ch
  change declarations Header.layout service [_] _ = _
  simp only [declarations,List.foldlM,expr,cast,Bind.bind,Option.bind]
  rfl

theorem binding (l : PoolLayout) (c : Cursor) (a b : Input) :
    LocalBinding.At (after l c a b).state "r" "RI" (RationalSortCalls.output l c a b).source
      (RationalSortCalls.after l c a b).state.heap.length :=
  LocalBinding.allocate_head (RationalSortCalls.after l c a b).state "r" "RI"
    (RationalSortCalls.output l c a b).source (Pair.initialized _)

theorem preserve_binding {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input)
    {name type : String} {value : Value} {slot : Nat}
    (h : LocalBinding.At c.state name type value slot) (typeDifferent : type≠"unsigned") (nameDifferent : "r"≠name) :
    LocalBinding.At (after l c a b).state name type value slot := by
  have safe := LocalBinding.noncounter_separated ctx h typeDifferent
  have returned : LocalBinding.At (RationalSortCalls.after l c a b).state name type value slot := by
    rw [RationalSortCalls.after_advance]
    exact LocalBinding.advance h _ safe.1 safe.2.1 safe.2.2
  exact LocalBinding.allocate_other returned "r" "RI" _ nameDifferent

theorem scale {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) {object slot d : Nat}
    (h : SourceFromS.ScaleAt c.state object slot d) : SourceFromS.ScaleAt (after l c a b).state object slot d := by
  have returned : SourceFromS.ScaleAt (RationalSortCalls.after l c a b).state object slot d := by
    rw [RationalSortCalls.after_advance]
    exact SourceScaleFrames.advance ctx h _
  exact ReadonlyCallEffects.scale_allocate returned "RI" "r" _

end ScopedC.RationalSortLocal
