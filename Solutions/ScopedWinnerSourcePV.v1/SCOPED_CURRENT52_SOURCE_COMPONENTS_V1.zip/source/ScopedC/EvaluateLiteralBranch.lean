/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.EvaluateMagnitudeCaller
import ScopedC.EvaluateLiteralRHSExpression
import ScopedC.EvaluateLiteralCommit
namespace ScopedC.EvaluateLiteralBranch
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.DecimalText
open ScopedC.EvaluateLiteral ScopedC.EvaluateMagnitude
open ScopedC.EvaluateLiteralRationalStages (Library signedCursor rationalCursor)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

/-- Entire actual opcode-zero branch: source byte/sign reads, complete actual
numerator parser, genuine signed/rational/dyadic computation, actual values[k]
store, and removal of only branch-local stack cells. Existing table entries
are preserved by the physical source trace and concrete single-cell store.
This is a branch theorem; the complete evaluate dispatch/loop remains separate. -/
theorem source_branch (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (n : ScopedNumerical.Input.Node) (base : Nat)
    (num : c.state.heap[base]?=some (literalObject (toString n.num)))
    (den : c.state.heap[base+1]?=some (literalObject (toString n.den))) (positive : 0 < n.den)
    {scaleObject scaleSlot : Nat} (scale : SourceFromS.ScaleAt c.state scaleObject scaleSlot (2^100))
    (room : c.top+45+4*(digits n.num.natAbs).length+4*(digits n.den).length < capacity)
    (cells : List (Option Value)) (tableSlot k counterSlot : Nat)
    (array : EvaluateArrayStore.At c.state cells tableSlot)
    (counter : LocalBinding.At c.state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) counterSlot)
    (bound : k<cells.length) :
    ∃service : Call,∃out : Cursor,∃lo hi : Endpoint,
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 9 name args before value after) ∧
      Run Header.layout service EvaluateSyntax.literalBranch (nodeCursor c base n).state (.continuing out.state) ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (IntervalDyadic.ofIntervalRat (IntervalRat.singleton (mkRat n.num n.den)) (-100),true) ∧
      EvaluateArrayStore.At out.state (cells.set k (some (DyadicCasts.value lo.source hi.source true))) tableSlot := by
  obtain ⟨P⟩ := EvaluateMagnitudeTrace.stages_exist code lib.decimal lib.nu lib.nm lib.na lib.keep ctx num (by omega)
  let start := EvaluateMagnitudeTrace.after P
  have startValid : Valid l start := P.after_valid
  have afterTop : start.top=c.top+1+4*(digits n.num.natAbs).length := P.top
  have rightRoom : start.top+44+4*(digits n.den).length < capacity := by rw [afterTop];omega
  obtain ⟨D⟩ := EvaluateLiteralTraceStages.stages_exist code lib startValid n base P.slot c.state.heap.length P.live
    (P.node_binding ctx) (P.denominator_window ctx den) positive (P.scale ctx scale) rightRoom
  let e0 : CallEvents.Event Header.layout code 9 :=
    ⟨"decimal",[.pointer ⟨base,offset n.num,[]⟩ false],(flagged c base n).state,.natObject P.slot,P.parsed.state,
      SourceRanks.monotone (by omega : 3 ≤ 9) P.call⟩
  let e1 : CallEvents.Event Header.layout code 9 :=
    ⟨"smake",[.natObject P.slot,NatWrapperCalls.unsigned32 (flag n)],start.state,
      (EvaluateLiteralSigned.endpoint P.slot n.num).source,(signedCursor l start).state,
      SourceRanks.monotone (by omega : 4 ≤ 9) D.makeCall⟩
  let e2 : CallEvents.Event Header.layout code 9 :=
    ⟨"decimal",[.pointer ⟨base+1,0,[]⟩ false],(signedCursor l start).state,.natObject D.denSlot,D.denominator.state,
      SourceRanks.monotone (by omega : 3 ≤ 9) D.decimalCall⟩
  let e3 : CallEvents.Event Header.layout code 9 :=
    ⟨"qm",[(EvaluateLiteralSigned.endpoint P.slot n.num).source,.natObject D.denSlot],D.denominator.state,
      D.q.source,(rationalCursor l D.denominator n P.slot).state,
      SourceRanks.monotone (by omega : 5 ≤ 9) D.qmCall⟩
  let e4 : CallEvents.Event Header.layout code 9 :=
    ⟨"iconst",[D.q.source],(rationalCursor l D.denominator n P.slot).state,
      DyadicCasts.value D.lo.source D.hi.source true,D.out.state,D.iconstCall⟩
  let events := [e0,e1,e2,e3,e4]
  have different : (flagged c base n).state.nats.values.length ≠ (signedCursor l start).state.nats.values.length := by
    change c.state.nats.values.length ≠ (next l start 0).state.nats.values.length
    rw [PoolCursor.size]
    change c.state.nats.values.length ≠ P.parsed.state.nats.values.length+1
    have size:=P.size
    omega
  have unique : (events.map CallEvents.key).Nodup := by simpa [events,CallEvents.key,e0,e1,e2,e3,e4] using different
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service events unique
  have answer0 := answers e0 (by simp [events])
  have answer1 := answers e1 (by simp [events])
  have answer2 := answers e2 (by simp [events])
  have answer3 := answers e3 (by simp [events])
  have answer4 := answers e4 (by simp [events])
  have prefixRun:=EvaluateMagnitudeCaller.source_prefix P service num answer0
  have rhs:=EvaluateLiteralRHSExpression.expression D service P.mag_binding (P.sign_binding ctx)
    answer1 answer2 answer3 answer4
  have arrayStart : EvaluateArrayStore.At start.state cells tableSlot := EvaluateMagnitudeCaller.array P ctx array
  have counterStart : LocalBinding.At start.state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) counterSlot :=
    EvaluateMagnitudeCaller.counter P ctx counter
  have arrayAfter : EvaluateArrayStore.At D.out.state cells tableSlot := by
    rw [D.outTrace]
    exact EvaluateArrayStore.advance startValid arrayStart D.trace
  have counterSafe:=LocalBinding.noncounter_separated startValid counterStart (by decide +kernel)
  have counterAfter : LocalBinding.At D.out.state "k" "unsigned int" (NatWrapperCalls.unsigned32 k) counterSlot := by
    rw [D.outTrace]
    exact LocalBinding.advance counterStart D.trace counterSafe.1 counterSafe.2.1 counterSafe.2.2
  let value:=DyadicCasts.value D.lo.source D.hi.source true
  let stored : Cursor := {D.out with state:=EvaluateArrayStore.changed D.out.state cells tableSlot k value}
  have cast : castValue Header.layout D.out.state 100 "I" value=some value :=
    DyadicCasts.record _ 97 "I" (by decide +kernel) _ _ true
      (Endpoint.cast 97 "S" (by decide +kernel) D.loLive) (Endpoint.cast 97 "S" (by decide +kernel) D.hiLive)
  have assignment:=EvaluateArrayStore.source_assignment service 998 rhs arrayAfter counterAfter bound cast
  have commitRun : Run Header.layout service EvaluateSyntax.literalCommit start.state (.continuing stored.state) := by
    rw [EvaluateLiteralRHS.actual_literal_commit]
    exact Loops.StmtRun.evaluate ⟨1001,assignment⟩
  have tableSafe:=EvaluateArrayStore.separated D.outValid arrayAfter
  have storedValid : Valid l stored := by
    constructor
    · exact D.outValid.global_pool
    · exact D.outValid.global_top
    · exact D.outValid.global_high
    · simpa only [stored,EvaluateArrayStore.changed,List.getElem?_set_ne tableSafe.1] using D.outValid.pool_read
    · simpa only [stored,EvaluateArrayStore.changed,List.getElem?_set_ne tableSafe.2.1] using D.outValid.top_read
    · simpa only [stored,EvaluateArrayStore.changed,List.getElem?_set_ne tableSafe.2.2] using D.outValid.high_read
    · exact D.outValid.extent
    · exact D.outValid.high_range
    · exact D.outValid.top_range
  let out := PoolContextPop.unframe (nodeCursor c base n).state stored
  have body : Run Header.layout service EvaluateSyntax.literalBranch (nodeCursor c base n).state (.continuing out.state) := by
    rw [EvaluateSyntax.actual_literal_decomposition]
    refine Loops.StmtRun.sequence (inner:=.continuing stored.state) ?_ ?_
    · cases prefixRun with
      | next negative rest =>
        cases rest with
        | next magnitude ending =>
          cases ending
          exact Loops.SeqRun.next negative (Loops.SeqRun.next magnitude (Loops.SeqRun.next commitRun (Loops.SeqRun.nil _)))
    · rfl
  have hp:=(List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht:=(List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh:=(List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have nodeLength : (nodeCursor c base n).state.heap.length=c.state.heap.length+1 := by
    simp [nodeCursor,EvaluateNodeRead.nodeState,allocate]
  have outValid : Valid l out := PoolContextPop.valid storedValid
    (by rw [nodeLength];omega) (by rw [nodeLength];omega) (by rw [nodeLength];omega)
  refine ⟨service,out,D.lo,D.hi,closed,body,outValid,D.loLive,D.hiLive,D.decoded,?_⟩
  constructor
  · simpa [out,PoolContextPop.unframe,popScope,nodeCursor,EvaluateNodeRead.nodeState,allocate,List.lookup] using array.lookup
  · have present:=(List.getElem?_eq_some_iff.mp arrayAfter.memory).choose
    have originalPresent:=(List.getElem?_eq_some_iff.mp array.memory).choose
    change ((D.out.state.heap.set tableSlot (ArrayFrames.object "I" (cells.set k (some value)))).take (nodeCursor c base n).state.heap.length)[tableSlot]?=_
    rw [List.getElem?_take_of_lt (by rw [nodeLength];omega),List.getElem?_set_self present]

end ScopedC.EvaluateLiteralBranch
