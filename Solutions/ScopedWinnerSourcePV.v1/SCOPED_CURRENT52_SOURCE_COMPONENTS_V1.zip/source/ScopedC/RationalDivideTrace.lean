/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalDivideRefinement
import ScopedC.RationalMultiplyTrace
import ScopedC.SourceFromSTrace
import ScopedC.SourceScaleFrames
namespace ScopedC.RationalDivideTrace
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalDivideCalls
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

private theorem unframe_three (before : State) (out : Cursor)
    (length : out.state.heap.length=before.heap.length) (environment : out.state.env=before.env)
    (ta na : String) (va : Value) (tb nb : String) (vb : Value) (tc nc : String) (vc : Value) :
    PoolContextPop.unframe before (CursorLocals.allocated (CursorFrames.framed out ta na va tb nb vb) tc nc vc)=out := by
  cases out
  rename_i state cells top high
  cases state
  simp_all [PoolContextPop.unframe,CursorLocals.allocated,CursorFrames.framed,TwoFrames.frame,
    allocate,popScope,List.append_assoc]

def productSteps (l : PoolLayout) (c : Cursor) (a b : Input) : List Nat :=
  RationalMultiplyTrace.steps l (inverseCursor l c a b) a (inverse b)
def steps (l : PoolLayout) (c : Cursor) (a b : Input) : List Nat :=
  if b.numerator.magnitude=0 then [0,0,0,1] else [0,0]++productSteps l c a b

theorem zero_advance {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12 < capacity) (a b : Input) :
    zeroAfter l c a b=CursorFrames.advance l c [0,0,0,1] := by
  unfold zeroAfter zeroEnd
  rw [tested_framed ctx a b]
  change PoolContextPop.unframe c.state
    (CursorFrames.advance l (CursorFrames.framed (next l c 0) "Q" "a" a.source "Q" "b" b.source) [0,0,1])=_
  rw [CursorFrames.advance_framed (next_valid 0 ctx (by omega)) [0,0,1] (by change c.top+1+3 ≤ capacity;omega)]
  have firstShape:=PoolCursor.shape l c 0
  have tailShape:=CursorEffects.shape l (next l c 0) [0,0,1]
  have pop:=TwoFrames.pop_frame (s:=c.state) "Q" "a" a.source "Q" "b" b.source
    (tailShape.1.trans firstShape.1) (tailShape.2.trans firstShape.2)
  dsimp only [PoolContextPop.unframe,CursorFrames.framed]
  rw [pop]
  rfl

theorem nonzero_advance {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12 < capacity) (a b : Input) :
    nonzeroAfter l c a b=CursorFrames.advance l c ([0,0]++productSteps l c a b) := by
  let core:=next l (next l c 0) 0
  let tail:=productSteps l c a b
  have coreValid : Valid l core := next_valid 0 (next_valid 0 ctx (by omega)) (by change c.top+1 < capacity;omega)
  have tailRoom : core.top+tail.length ≤ capacity := by change c.top+1+1+11 ≤ capacity;omega
  have doublePop : nonzeroAfter l c a b=PoolContextPop.unframe c.state (productEnd l c a b) := by
    change {productEnd l c a b with state:=popScope c.state (popScope (base c a b).state (productEnd l c a b).state)}=_
    rw [SourceFromS.scope_twice c.state (base c a b).state (productEnd l c a b).state
      (by simp [base,CursorFrames.framed,TwoFrames.frame,allocate])]
    rfl
  rw [doublePop]
  have productTrace : productEnd l c a b=CursorFrames.advance l (inverseCursor l c a b) tail := by
    rw [productEnd,RationalMultiplyTrace.c11_advance]
    rfl
  rw [productTrace]
  have frameEq : inverseCursor l c a b=CursorLocals.allocated
      (CursorFrames.framed core "Q" "a" a.source "Q" "b" b.source) "Q" "inverse" (inverse b).source := by
    unfold inverseCursor
    rw [made_framed ctx room a b]
    rfl
  rw [frameEq,CursorLocals.advance_allocated (CursorFrames.framed_valid coreValid "Q" "a" a.source "Q" "b" b.source) tail tailRoom,
    CursorFrames.advance_framed coreValid tail tailRoom]
  have coreShape : core.state.heap.length=c.state.heap.length ∧ core.state.env=c.state.env :=
    ⟨(PoolCursor.shape l (next l c 0) 0).1.trans (PoolCursor.shape l c 0).1,
      (PoolCursor.shape l (next l c 0) 0).2.trans (PoolCursor.shape l c 0).2⟩
  have tailShape:=CursorEffects.shape l core tail
  rw [unframe_three c.state (CursorFrames.advance l core tail)
    (tailShape.1.trans coreShape.1) (tailShape.2.trans coreShape.2)]
  change CursorFrames.advance l core tail=CursorFrames.advance l c ([0,0]++tail)
  exact (CursorSingleFrames.advance_append l c [0,0] tail).symm

/-- Both real source division branches have exact caller-preserving effects:
four allocations for the explicit zero return, thirteen for division. -/
theorem after_advance {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12 < capacity) (a b : Input) :
    after l c a b=CursorFrames.advance l c (steps l c a b) := by
  by_cases zero : b.numerator.magnitude=0
  · simpa only [after,steps,if_pos zero] using zero_advance ctx room a b
  · simpa only [after,steps,if_neg zero] using nonzero_advance ctx room a b

theorem length (l : PoolLayout) (c : Cursor) (a b : Input) : (steps l c a b).length ≤ 13 := by
  by_cases zero : b.numerator.magnitude=0 <;> simp [steps,zero,productSteps,RationalMultiplyTrace.steps]

theorem preserves_nat {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12 < capacity) (a b : Input) {slot n : Nat} (h : NatArena.Borrow c.state.nats slot n) :
    NatArena.Borrow (after l c a b).state.nats slot n := by
  rw [after_advance ctx room a b]
  exact CursorBorrow.preserves _ h

theorem preserves_scale {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12 < capacity) (a b : Input) {object slot d : Nat}
    (h : SourceFromS.ScaleAt c.state object slot d) : SourceFromS.ScaleAt (after l c a b).state object slot d := by
  rw [after_advance ctx room a b]
  exact SourceScaleFrames.advance ctx h _

end ScopedC.RationalDivideTrace
