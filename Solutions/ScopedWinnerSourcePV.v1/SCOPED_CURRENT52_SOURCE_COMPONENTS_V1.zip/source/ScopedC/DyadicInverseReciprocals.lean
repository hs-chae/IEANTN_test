/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalReciprocalLocalEffects
import ScopedC.CallEventService
import ScopedC.SourceRanks
namespace ScopedC.DyadicInverseReciprocals
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalReciprocalCalls (Result oneCursor oneInput)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (q : Pair) where
  first : Result code l c q.hi
  second : Result code l (RationalReciprocalLocal.after first "l") q.lo

def middle {code : List Function} {l : PoolLayout} {c : Cursor} {q : Pair}
    (D : Stages code l c q) : Cursor := RationalReciprocalLocal.after D.first "l"
def after {code : List Function} {l : PoolLayout} {c : Cursor} {q : Pair}
    (D : Stages code l c q) : Cursor := RationalReciprocalLocal.after D.second "h"

def statements : List Stmt := [
  .declare [{type:="Q",name:="l",value:=some (RationalReciprocalLocal.initializer true)}],
  .declare [{type:="Q",name:="h",value:=some (RationalReciprocalLocal.initializer false)}]]

theorem actual_source_fragment : ∃ initial tail,
    Generated.f_iinv.body=.sequence (initial++statements++tail) := by
  refine ⟨[_,_,_],_,rfl⟩

theorem stages_exist (code : List Function) (installed : Generated.f_qv∈code)
    (lib : RationalDivideCalls.Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+31 < capacity) (q : Pair)
    (live : q.Live c.state) (positive : q.Positive) : Nonempty (Stages code l c q) := by
  obtain ⟨first⟩ := RationalReciprocalCalls.result_exists code installed lib ctx (by omega) q.hi live.2 positive.2
  have firstValid := RationalReciprocalLocal.after_valid first "l"
  have secondRoom : (RationalReciprocalLocal.after first "l").top+15 < capacity := by
    rw [RationalReciprocalLocal.top first ctx (by omega)]
    have h := RationalReciprocalCalls.length l c q.hi
    omega
  have loLive := RationalReciprocalLocal.preserve_input first ctx (by omega) "l" q.lo live.1
  obtain ⟨second⟩ := RationalReciprocalCalls.result_exists code installed lib firstValid secondRoom q.lo loLive positive.1
  exact ⟨⟨first,second⟩⟩

namespace Stages
variable {code : List Function} {l : PoolLayout} {c : Cursor} {q : Pair}

theorem after_valid (D : Stages code l c q) : Valid l (after D) :=
  RationalReciprocalLocal.after_valid D.second "h"

theorem lower_value (D : Stages code l c q) : D.first.output.mathematical.value=1/q.hi.mathematical.value := D.first.value
theorem upper_value (D : Stages code l c q) : D.second.output.mathematical.value=1/q.lo.mathematical.value := D.second.value

theorem sequence (D : Stages code l c q) (service : Call) (ctx : Valid l c)
    (room : c.top+31 < capacity) (slot : Nat) (binding : LocalBinding.At c.state "q" "RI" q.source slot)
    (qi0 : service "qi" [DecimalDigits.integer 1] c.state=some ((oneInput l c).source,(oneCursor l c).state))
    (qv0 : service "qv" [(oneInput l c).source,q.hi.source] (oneCursor l c).state=
      some (D.first.output.source,(RationalReciprocalCalls.after l c q.hi).state))
    (qi1 : service "qi" [DecimalDigits.integer 1] (middle D).state=
      some ((oneInput l (middle D)).source,(oneCursor l (middle D)).state))
    (qv1 : service "qv" [(oneInput l (middle D)).source,q.lo.source] (oneCursor l (middle D)).state=
      some (D.second.output.source,(RationalReciprocalCalls.after l (middle D) q.lo).state)) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      statements c.state (.continuing (after D).state) := by
  have first := RationalReciprocalLocal.declaration service ctx true q slot binding D.first "l" qi0 qv0
  have secondBinding := RationalReciprocalLocal.preserve_binding D.first ctx (by omega) "l" binding
    (by decide +kernel) (by decide +kernel)
  have second := RationalReciprocalLocal.declaration service (RationalReciprocalLocal.after_valid D.first "l")
    false q slot secondBinding D.second "h" qi1 qv1
  exact Loops.SeqRun.next (Loops.StmtRun.declare first)
    (Loops.SeqRun.next (Loops.StmtRun.declare second) (Loops.SeqRun.nil _))

end Stages
end ScopedC.DyadicInverseReciprocals
