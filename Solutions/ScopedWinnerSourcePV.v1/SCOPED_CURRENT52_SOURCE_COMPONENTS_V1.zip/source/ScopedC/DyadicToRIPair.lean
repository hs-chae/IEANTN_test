/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceToRI
import ScopedC.DyadicPairFrames
import ScopedC.NumericIntervalCompleteness
namespace ScopedC.DyadicToRIPair
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def base (c : Cursor) (a b : InputI) : Cursor := DyadicPairFrames.framed c a b
def steps (a : InputI) (d : Nat) : List Nat := ToRITrace.steps a.lo a.hi d

def divided (a : InputI) (d : Nat) (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) : IntervalRat :=
  ⟨(a.lo.mathematical.value:Rat)/(d:Rat),(a.hi.mathematical.value:Rat)/(d:Rat),
    div_le_div_of_nonneg_right (by exact_mod_cast ordered) (Nat.cast_nonneg d)⟩

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (a b : InputI) (d : Nat) where
  first : Cursor
  second : Cursor
  left : Pair
  right : Pair
  firstCall : SourceCall Header.layout code 7 "toRI" [a.source] (base c a b).state left.source first.state
  secondCall : SourceCall Header.layout code 7 "toRI" [b.source] first.state right.source second.state
  firstTrace : first=CursorFrames.advance l (base c a b) (steps a d)
  secondTrace : second=CursorFrames.advance l first (steps b d)
  firstValid : Valid l first
  secondValid : Valid l second
  leftLive : left.Live second.state
  rightLive : right.Live second.state
  leftPositive : left.Positive
  rightPositive : right.Positive
  leftLow : left.lo.mathematical.value=(a.lo.mathematical.value:Rat)/(d:Rat)
  leftHigh : left.hi.mathematical.value=(a.hi.mathematical.value:Rat)/(d:Rat)
  rightLow : right.lo.mathematical.value=(b.lo.mathematical.value:Rat)/(d:Rat)
  rightHigh : right.hi.mathematical.value=(b.hi.mathematical.value:Rat)/(d:Rat)

theorem base_valid {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : InputI) : Valid l (base c a b) :=
  CursorFrames.framed_valid ctx "I" "a" a.source "I" "b" b.source

theorem scale_base {c : Cursor} (a b : InputI) {object slot d : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot d) :
    SourceFromS.ScaleAt (base c a b).state object slot d := by
  have bound := (List.getElem?_eq_some_iff.mp scale.storage).choose
  constructor
  · exact scale.lookup
  · change (c.state.heap ++ [_] ++ [_])[object]? = _
    rw [List.getElem?_append_left (by simp only [List.length_append,List.length_singleton];omega),
      List.getElem?_append_left bound]
    exact scale.storage
  · exact scale.live

/-- Both conversions execute their actual installed source bodies. All later
physical liveness and exact rational endpoint fields are derived from those
outputs and their proved allocation traces, rather than assumed outputs. -/
theorem stages_exist (code : List Function) (installed : Generated.f_toRI∈code)
    (lib : ToRIStages.Library code) {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a b : InputI) (ha : a.Live c.state) (hb : b.Live c.state)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value)
    {object slot d : Nat} (scale : SourceFromS.ScaleAt c.state object slot d) (positive : 0 < d)
    (room : c.top+19 < capacity) : Nonempty (Stages code l c a b d) := by
  let initial := base c a b
  have initValid := base_valid ctx a b
  obtain ⟨first,lo1,hi1,call1,valid1,liveLo1,liveHi1,posLo1,posHi1,trace1,decode1⟩ :=
    SourceToRI.toRI_closed code installed lib (c:=initial) initValid a.lo a.hi a.ok
      (scale_base a b scale) positive ha.1 ha.2 oa (by change c.top+9 < capacity;omega)
  obtain ⟨left,leftSource,leftLive,leftPositive,leftLo,leftHi⟩ := NumericInputCompleteness.interval decode1
  have firstScale : SourceFromS.ScaleAt first.state object slot d := by
    rw [trace1]
    exact SourceScaleFrames.advance initValid (scale_base a b scale) (steps a d)
  have bLive : b.Live first.state := by
    rw [trace1]
    exact ⟨CursorBorrow.preserves (steps a d) hb.1,CursorBorrow.preserves (steps a d) hb.2⟩
  have secondRoom : first.top+9 < capacity := by
    rw [trace1,CursorFrames.top_advance]
    change c.top+10+9 < capacity
    omega
  obtain ⟨second,lo2,hi2,call2,valid2,liveLo2,liveHi2,posLo2,posHi2,trace2,decode2⟩ :=
    SourceToRI.toRI_closed code installed lib valid1 b.lo b.hi b.ok firstScale positive bLive.1 bLive.2 ob secondRoom
  obtain ⟨right,rightSource,rightLive,rightPositive,rightLo,rightHi⟩ := NumericInputCompleteness.interval decode2
  have finalLeft : left.Live second.state := by
    rw [trace2]
    exact ⟨⟨CursorBorrow.preserves (steps b d) leftLive.1.1,CursorBorrow.preserves (steps b d) leftLive.1.2⟩,
      ⟨CursorBorrow.preserves (steps b d) leftLive.2.1,CursorBorrow.preserves (steps b d) leftLive.2.2⟩⟩
  rw [←leftSource] at call1
  rw [←rightSource] at call2
  exact ⟨⟨first,second,left,right,call1,call2,trace1,trace2,valid1,valid2,finalLeft,rightLive,
    leftPositive,rightPositive,leftLo,leftHi,rightLo,rightHi⟩⟩

namespace Stages
variable {code : List Function} {l : PoolLayout} {c : Cursor} {a b : InputI} {d : Nat}

theorem second_top (D : Stages code l c a b d) : D.second.top=c.top+20 := by
  rw [D.secondTrace,CursorFrames.top_advance,D.firstTrace,CursorFrames.top_advance]
  rfl

theorem scale (D : Stages code l c a b d) (ctx : Valid l c) {object slot : Nat}
    (h : SourceFromS.ScaleAt c.state object slot d) : SourceFromS.ScaleAt D.second.state object slot d := by
  have firstScale : SourceFromS.ScaleAt D.first.state object slot d := by
    rw [D.firstTrace]
    exact SourceScaleFrames.advance (base_valid ctx a b) (scale_base a b h) (steps a d)
  rw [D.secondTrace]
  exact SourceScaleFrames.advance D.firstValid firstScale (steps b d)

private theorem safe_slots (ctx : Valid l c) :
    c.state.heap.length≠l.pool ∧ c.state.heap.length≠l.top ∧ c.state.heap.length≠l.high ∧
    c.state.heap.length+1≠l.pool ∧ c.state.heap.length+1≠l.top ∧ c.state.heap.length+1≠l.high := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  omega

theorem first_b_at (D : Stages code l c a b d) (ctx : Valid l c) :
    LocalBinding.At D.first.state "b" "I" b.source (c.state.heap.length+1) := by
  rw [D.firstTrace]
  have safe := safe_slots ctx
  exact LocalBinding.advance (c:=base c a b) (DyadicPairFrames.b_at c.state a b) (steps a d)
    safe.2.2.2.1 safe.2.2.2.2.1 safe.2.2.2.2.2

theorem second_a_at (D : Stages code l c a b d) (ctx : Valid l c) :
    LocalBinding.At D.second.state "a" "I" a.source c.state.heap.length := by
  rw [D.secondTrace,D.firstTrace]
  have safe := safe_slots ctx
  exact LocalBinding.advance (LocalBinding.advance (c:=base c a b) (DyadicPairFrames.a_at c.state a b)
    (steps a d) safe.1 safe.2.1 safe.2.2.1) (steps b d) safe.1 safe.2.1 safe.2.2.1

theorem second_b_at (D : Stages code l c a b d) (ctx : Valid l c) :
    LocalBinding.At D.second.state "b" "I" b.source (c.state.heap.length+1) := by
  rw [D.secondTrace]
  have safe := safe_slots ctx
  exact LocalBinding.advance (D.first_b_at ctx) (steps b d)
    safe.2.2.2.1 safe.2.2.2.2.1 safe.2.2.2.2.2

end Stages
end ScopedC.DyadicToRIPair
