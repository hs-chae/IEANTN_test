/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEventKeys
namespace ScopedC.CallEvents
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- An opaque adapter for finite collections of already established source
executions. Every answer retains its actual lower-rank source proof; key
uniqueness is used solely to select that proof, never to assume an output. -/
theorem list_service {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map key).Nodup) :
    ∃service : Call,
      (∀e∈events,service e.name e.args e.before=some (e.value,e.after)) ∧
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall cfg code rank name args before value after) :=
  ⟨service events,fun e member=>service_self_keys events unique e member,
    fun _ _ _ _ _ answer=>service_closed events answer⟩

end ScopedC.CallEvents
