/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.EvaluateLiteralRationalStages
import ScopedC.EvaluateSyntax
import ScopedC.CallEventService
namespace ScopedC.EvaluateLiteralRHS
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.DecimalText
open ScopedC.EvaluateLiteralRationalStages
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def rhs : Syntax.Expr := .call (.var "iconst") [.call (.var "qm") [
  .call (.var "smake") [.var "mag",.var "negative"],
  .call (.var "decimal") [.field "." (.var "n") "den"]]]

theorem actual_literal_commit : EvaluateSyntax.literalCommit=
    .eval (.binary "=" (.index (.var "values") (.var "k")) rhs) := rfl

/-- Actual source literal RHS: physical local reads, all four actual callees,
exact original mkRat constructor and original -100 outward singleton. The
assignment target, preceding magnitude prefix and whole loop are separate
remaining joins; this theorem makes no whole-evaluate completion claim. -/
theorem source_rhs (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (n : ScopedNumerical.Input.Node) (base magSlot nodeSlot magLocal signLocal : Nat)
    (magLive : NatArena.Borrow c.state.nats magSlot n.num.natAbs)
    (magAt : LocalBinding.At c.state "mag" "N" (.natObject magSlot) magLocal)
    (negativeAt : LocalBinding.At c.state "negative" "unsigned int"
      (NatWrapperCalls.unsigned32 (EvaluateLiteral.flag n)) signLocal)
    (nodeAt : LocalBinding.At c.state "n" "Node" (DataNode.represented base n) nodeSlot)
    (denWindow : DecimalBuffer.At c.state ⟨base+1,0,[]⟩ (digits n.den)) (positive : 0 < n.den)
    {scaleObject scaleSlot : Nat} (scale : SourceFromS.ScaleAt c.state scaleObject scaleSlot (2^100))
    (room : c.top+44+4*(digits n.den).length < capacity) :
    ∃service : Call,∃out : Cursor,∃lo hi : Endpoint,
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 9 name args before value after) ∧
      evalExpr Header.layout service 1000 c.state rhs=
        some (DyadicCasts.value lo.source hi.source true,out.state) ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (IntervalDyadic.ofIntervalRat (IntervalRat.singleton (mkRat n.num n.den)) (-100),true) := by
  obtain ⟨D⟩ := stages_exist code lib ctx n base magSlot nodeSlot magLive nodeAt denWindow positive scale room
  let e1 : CallEvents.Event Header.layout code 9 :=
    ⟨"smake",[.natObject magSlot,NatWrapperCalls.unsigned32 (EvaluateLiteral.flag n)],c.state,
      (EvaluateLiteralSigned.endpoint magSlot n.num).source,(signedCursor l c).state,
      SourceRanks.monotone (by omega : 4 ≤ 9) D.makeCall⟩
  let e2 : CallEvents.Event Header.layout code 9 :=
    ⟨"decimal",[.pointer ⟨base+1,0,[]⟩ false],(signedCursor l c).state,.natObject D.denSlot,D.denominator.state,
      SourceRanks.monotone (by omega : 3 ≤ 9) D.decimalCall⟩
  let e3 : CallEvents.Event Header.layout code 9 :=
    ⟨"qm",[(EvaluateLiteralSigned.endpoint magSlot n.num).source,.natObject D.denSlot],D.denominator.state,
      D.q.source,(rationalCursor l D.denominator n magSlot).state,
      SourceRanks.monotone (by omega : 5 ≤ 9) D.qmCall⟩
  let e4 : CallEvents.Event Header.layout code 9 :=
    ⟨"iconst",[D.q.source],(rationalCursor l D.denominator n magSlot).state,
      DyadicCasts.value D.lo.source D.hi.source true,D.out.state,D.iconstCall⟩
  let events := [e1,e2,e3,e4]
  have unique : (events.map CallEvents.key).Nodup := by simp [events,CallEvents.key,e1,e2,e3,e4]
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service events unique
  have answer1 := answers e1 (by simp [events])
  have answer2 := answers e2 (by simp [events])
  have answer3 := answers e3 (by simp [events])
  have answer4 := answers e4 (by simp [events])
  have signedExpr : evalExpr Header.layout service 998 c.state (.call (.var "smake") [.var "mag",.var "negative"])=
      some ((EvaluateLiteralSigned.endpoint magSlot n.num).source,(signedCursor l c).state) :=
    EvaluateLiteralSigned.smake_expression service magAt negativeAt answer1 996
  have denField : evalExpr Header.layout service 997 (signedCursor l c).state (.field "." (.var "n") "den")=
      some (.pointer ⟨base+1,0,[]⟩ false,(signedCursor l c).state) :=
    ExpressionTemplates.field Header.layout service
      (LocalBinding.eval service 995 D.nodeAfterMake (by decide +kernel) (by decide +kernel)
        (by decide +kernel) (by decide +kernel)) (DataReads.node_fields base n).2.2.2.2
  have denExpr : evalExpr Header.layout service 998 (signedCursor l c).state
      (.call (.var "decimal") [.field "." (.var "n") "den"])=some (.natObject D.denSlot,D.denominator.state) :=
    ExpressionTemplates.call_one Header.layout service denField answer2
  have rationalExpr : evalExpr Header.layout service 999 c.state (.call (.var "qm") [
      .call (.var "smake") [.var "mag",.var "negative"],.call (.var "decimal") [.field "." (.var "n") "den"]])=
      some (D.q.source,(rationalCursor l D.denominator n magSlot).state) :=
    ExpressionTemplates.call_two Header.layout service signedExpr denExpr answer3
  exact ⟨service,D.out,D.lo,D.hi,closed,
    ExpressionTemplates.call_one Header.layout service rationalExpr answer4,D.outValid,D.loLive,D.hiLive,D.decoded⟩

end ScopedC.EvaluateLiteralRHS
