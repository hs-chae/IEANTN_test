/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.FromRIAllocationTrace
namespace ScopedC.SourceFromRITraceMath
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.FromRIFrames ScopedC.FromRIStages ScopedC.DyadicRepresentation
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Actual directed conversion, exact old mathematical result, and complete
bounded allocation trace. The explicit parameter conversion is an ordinary
source binding proof that each actual caller must discharge. -/
theorem with_arguments_traced (code : List Function) (installed : Generated.f_fromRI∈code)
    (qtInstalled : Generated.f_qt∈code) (floorInstalled : Generated.f_floorQ∈code)
    (ceilInstalled : Generated.f_ceilQ∈code) (qnInstalled : Generated.f_qn∈code)
    (snInstalled : Generated.f_sn∈code) (qtLib : RationalMultiplyCalls.Library code)
    (roundLib : FloorQNegativeCalls.Library code) {l : PoolLayout} {c : Cursor}
    (valid : Valid l c) (a : InputRI) (ok : Bool) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (live : a.Live c.state)
    (lp : 0 < a.lo.denominator) (hp : 0 < a.hi.denominator)
    (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) (room : c.top+37 < capacity)
    (flagInput : Value) (arguments : bindArgs Header.layout Generated.f_fromRI.parameters [a.source,flagInput] c.state=
      some (parameters c.state a ok)) :
    ∃out : Cursor,∃lo hi : Endpoint,∃trace : List Nat,
      SourceCall Header.layout code 8 "fromRI" [a.source,flagInput]
        c.state (DyadicCasts.value lo.source hi.source ok) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source ok)=
        some (IntervalDyadic.ofIntervalRat ⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩ (-100),ok) ∧
      out=CursorFrames.advance l c trace ∧ trace.length ≤ 38 := by
  obtain ⟨D⟩ := stages_exist code qtInstalled floorInstalled ceilInstalled qnInstalled snInstalled
    qtLib roundLib valid a ok scale live lp hp room
  have source := SourceFromRIArguments.with_arguments code installed roundLib valid a ok scale live (by omega) D flagInput arguments
  refine ⟨SourceFromRI.final D,D.low,D.high,FromRIAllocationTrace.steps D,
    source.1,source.2.1,source.2.2.1,source.2.2.2,?_,
    FromRIAllocationTrace.final_advance valid D room,FromRIAllocationTrace.length D⟩
  exact NumericFromRIRefinement.decoded_exact a ok D.low D.high source.2.2.1 source.2.2.2 ordered
    (by simpa only [Nat.cast_pow,Nat.cast_ofNat] using D.lowValue)
    (by simpa only [Nat.cast_pow,Nat.cast_ofNat] using D.highValue)

end ScopedC.SourceFromRITraceMath
