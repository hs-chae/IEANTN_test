/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalSource
import ScopedC.CursorBorrow
import ScopedC.CursorSingleFrames
namespace ScopedC.DecimalExpressions
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Exact allocation effects of the existing four-allocation source iteration. -/
def execute (l : PoolLayout) (c : Cursor) (acc : Nat) : List Nat → Cursor
  | [] => c
  | d::rest => execute l (DecimalCalls.c4 l c acc d) (acc*10+d) rest

def allocationSteps (acc : Nat) : List Nat → List Nat
  | [] => []
  | d::rest => [10,acc*10,d,acc*10+d]++allocationSteps (acc*10+d) rest

theorem execute_advance (l : PoolLayout) (c : Cursor) (acc : Nat) (digits : List Nat) :
    execute l c acc digits=CursorFrames.advance l c (allocationSteps acc digits) := by
  induction digits generalizing c acc with
  | nil => rfl
  | cons d rest ih =>
    rw [execute,ih,allocationSteps,CursorSingleFrames.advance_append]
    rfl

theorem loop_exists_traced (code : List Function)
    (nuInstalled : Generated.f_nu∈code) (nmInstalled : Generated.f_nm∈code)
    (naInstalled : Generated.f_na∈code) (keepInstalled : Generated.f_keep∈code)
    (digits : List Nat) (good : ∀ d∈digits,d<10) (length : digits.length<2^32)
    {remaining consumed : List Nat} {l : PoolLayout} {c : Cursor} {buf : Address} {slot acc : Nat}
    (input : digits=consumed++remaining)
    (live : NatArena.Borrow c.state.nats slot acc) (valid : Valid l c)
    (room : c.top+4*remaining.length≤capacity) (hbuf : DecimalBuffer.At c.state buf digits)
    (hp : buf.object≠l.pool) (ht : buf.object≠l.top) (hh : buf.object≠l.high) :
    ∃ outputSlot events,LoopPost code l c (execute l c acc remaining) buf slot outputSlot acc digits consumed remaining events := by
  induction remaining generalizing consumed c slot acc with
  | nil =>
    change ∃ outputSlot events,LoopPost code l c c buf slot outputSlot acc digits consumed [] events
    have endIndex : consumed.length=digits.length := by simp [input]
    refine ⟨slot,[],valid,live,hbuf,?_,rfl,rfl,?_,?_,?_,?_⟩
    · simp
    · simp
    · rfl
    · intro i hi ht hh
      rfl
    · intro service answers
      rw [endIndex]
      exact Loops.WhileRun.done (source_terminator service hbuf) rfl
  | cons d rest ih =>
    have hk : consumed.length<digits.length := by simp [input]
    have digitAt : digits[consumed.length]=d := by simp [input,List.getElem_append_right]
    have hd : digits[consumed.length]<10 := good _ (List.getElem_mem hk)
    have hd' : d<10 := by simpa only [digitAt] using hd
    have rstep : c.top+3<capacity := by simp only [List.length_cons] at room;omega
    obtain ⟨headEvents,headCounts,headSource⟩ := step_events code nuInstalled nmInstalled naInstalled keepInstalled
      live valid rstep hbuf hk hd length hp ht hh
    rw [digitAt] at headSource
    let nextCursor := DecimalCalls.c4 l c acc d
    let nextSlot := DecimalCalls.resultSlot l c acc d
    have nextValid : Valid l nextCursor := (DecimalCalls.contexts acc d valid rstep).2.2.2
    have nextLive : NatArena.Borrow nextCursor.state.nats nextSlot (acc*10+d) :=
      next_borrow l (DecimalCalls.c3 l c acc d) (acc*10+d)
    have b1 : DecimalBuffer.At (DecimalCalls.c1 l c).state buf digits := next_buffer hbuf 10 hp ht hh
    have b2 : DecimalBuffer.At (DecimalCalls.c2 l c acc).state buf digits := next_buffer b1 (acc*10) hp ht hh
    have b3 : DecimalBuffer.At (DecimalCalls.c3 l c acc d).state buf digits := next_buffer b2 d hp ht hh
    have nextBuffer : DecimalBuffer.At nextCursor.state buf digits := next_buffer b3 (acc*10+d) hp ht hh
    have nextInput : digits=(consumed++[d])++rest := by simpa [List.append_assoc] using input
    have nextRoom : nextCursor.top+4*rest.length≤capacity := by
      change c.top+1+1+1+1+4*rest.length≤capacity
      simp only [List.length_cons] at room
      omega
    obtain ⟨outSlot,tailEvents,post⟩ := ih nextInput nextLive nextValid nextRoom nextBuffer
    let final := execute l nextCursor (acc*10+d) rest
    change ∃ outputSlot events,LoopPost code l c final buf slot outputSlot acc digits consumed (d::rest) events
    have hs := four_shape l c acc d
    have hn := four_size l c acc d
    refine ⟨outSlot,headEvents++tailEvents,post.valid,?_,post.buffer,?_,
      post.heap.trans hs.1,post.environment.trans hs.2,?_,?_,?_,?_⟩
    · exact post.live
    · have htop := post.top
      change final.top=(c.top+1+1+1+1)+4*rest.length at htop
      simp only [List.length_cons]
      omega
    · rw [post.size,hn]
      simp only [List.length_cons]
      omega
    · simp only [CallEvents.counts,List.map_append]
      change CallEvents.counts headEvents++CallEvents.counts tailEvents=_
      rw [headCounts,post.counts,hn]
      change List.range' c.state.nats.values.length 4++
        List.range' (c.state.nats.values.length+4) (4*rest.length)=_
      rw [List.range'_append_1]
      congr 1
      simp only [List.length_cons]
      omega
    · intro i hi hit hih
      exact (post.other i hi hit hih).trans (four_other l c acc d i hi hit hih)
    · intro service answers
      have headAnswers : Answers service headEvents := fun e he => answers e (List.mem_append_left _ he)
      have tailAnswers : Answers service tailEvents := fun e he => answers e (List.mem_append_right _ he)
      have headRun := headSource service headAnswers
      have tailRun := post.source service tailAnswers
      have nextIndex : (consumed++[d]).length=consumed.length+1 := by simp
      rw [nextIndex] at tailRun
      exact Loops.WhileRun.next (source_condition service hbuf hk hd) rfl headRun tailRun


end ScopedC.DecimalExpressions
