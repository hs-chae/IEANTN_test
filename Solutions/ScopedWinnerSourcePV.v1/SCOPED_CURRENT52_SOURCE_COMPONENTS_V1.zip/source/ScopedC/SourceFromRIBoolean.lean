/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceFromRIArguments
import ScopedC.NumericIntervalCompleteness
import ScopedC.DyadicPairFrames
namespace ScopedC.SourceFromRIBoolean
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.FromRIFrames ScopedC.FromRIStages ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- The actual C++ logical-result value is cast to the actual uint32 flag
parameter. It is not silently replaced with an unsigned source literal. -/
theorem bind_boolean (s : State) (a : InputRI) (ok : Bool) (live : a.Live s) :
    bindArgs Header.layout Generated.f_fromRI.parameters [a.source,boolean Header.layout ok] s=
      some (parameters s a ok) :=
  TypedFrames.bind_two Header.layout s "RI" "a" "unsigned int" "ok" a.source (boolean Header.layout ok)
    a.source (NatWrapperCalls.unsigned32 (SignedNegCalls.bit ok))
    (InputRI.cast {s with env:=[]} 96 a live "RI" (by decide +kernel)) (by cases ok <;> rfl)

theorem boolean_math (code : List Function) (installed : Generated.f_fromRI∈code)
    (qtInstalled : Generated.f_qt∈code) (floorInstalled : Generated.f_floorQ∈code)
    (ceilInstalled : Generated.f_ceilQ∈code) (qnInstalled : Generated.f_qn∈code)
    (snInstalled : Generated.f_sn∈code) (qtLib : RationalMultiplyCalls.Library code)
    (roundLib : FloorQNegativeCalls.Library code) {l : PoolLayout} {c : Cursor}
    (valid : Valid l c) (a : InputRI) (ok : Bool) {object slot : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot (2^100)) (live : a.Live c.state)
    (lp : 0 < a.lo.denominator) (hp : 0 < a.hi.denominator)
    (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) (room : c.top+37 < capacity) :
    ∃ out : Cursor, ∃ lo hi : Endpoint,
      SourceCall Header.layout code 8 "fromRI" [a.source,boolean Header.layout ok]
        c.state (DyadicCasts.value lo.source hi.source ok) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source ok)=
        some (LeanCert.Core.IntervalDyadic.ofIntervalRat
          ⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩ (-100),ok) := by
  obtain ⟨D⟩ := stages_exist code qtInstalled floorInstalled ceilInstalled qnInstalled snInstalled
    qtLib roundLib valid a ok scale live lp hp room
  have h := SourceFromRIArguments.with_arguments code installed roundLib valid a ok scale live (by omega) D
    (boolean Header.layout ok) (bind_boolean c.state a ok live)
  refine ⟨SourceFromRI.final D,D.low,D.high,h.1,h.2.1,h.2.2.1,h.2.2.2,
    NumericFromRIRefinement.decoded_exact a ok D.low D.high h.2.2.1 h.2.2.2 ordered ?_ ?_⟩
  · simpa only [Nat.cast_pow,Nat.cast_ofNat] using D.lowValue
  · simpa only [Nat.cast_pow,Nat.cast_ofNat] using D.highValue


end ScopedC.SourceFromRIBoolean
