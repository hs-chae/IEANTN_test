/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ArrayFrames
import ScopedC.LocalBinding
import ScopedC.CursorSingleFrames
namespace ScopedC.EvaluateArrayStore
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Actual initialized array object and its source local pointer binding.
Elements may still be uninitialized, as in the actual evaluate declaration. -/
structure At (s : State) (cells : List (Option Value)) (slot : Nat) : Prop where
  lookup : s.env.lookup "values"=some ⟨slot,0,[]⟩
  memory : s.heap[slot]?=some (ArrayFrames.object "I" cells)

theorem separated {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    {cells : List (Option Value)} {slot : Nat} (h : At c.state cells slot) :
    slot≠l.pool ∧ slot≠l.top ∧ slot≠l.high := by
  have neq (i : Nat) (other : c.state.heap[i]?=some (poolObject [])) : slot≠i := by
    intro same
    have memory:=h.memory
    rw [same,other] at memory
    have types:=congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "N"=some "I" at types
    contradiction
  have hp : slot≠l.pool := by
    intro same
    have memory:=h.memory
    rw [same,ctx.pool_read] at memory
    have types:=congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "N"=some "I" at types
    contradiction
  have counter (i n : Nat) (other : c.state.heap[i]?=some (counterObject n)) : slot≠i := by
    intro same
    have memory:=h.memory
    rw [same,other] at memory
    have types:=congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "unsigned"=some "I" at types
    contradiction
  exact ⟨hp,counter l.top c.top ctx.top_read,counter l.high c.high ctx.high_read⟩

theorem advance {l : PoolLayout} {c : Cursor} {cells : List (Option Value)} {slot : Nat}
    (ctx : Valid l c) (h : At c.state cells slot) (trace : List Nat) :
    At (CursorFrames.advance l c trace).state cells slot := by
  have safe:=separated ctx h
  constructor
  · rw [(CursorEffects.shape l c trace).2]
    exact h.lookup
  · rw [CursorSingleFrames.advance_other l c trace slot safe.1 safe.2.1 safe.2.2]
    exact h.memory

def changed (s : State) (cells : List (Option Value)) (slot k : Nat) (value : Value) : State :=
  {s with heap:=s.heap.set slot (ArrayFrames.object "I" (cells.set k (some value)))}

theorem eval_values (service : Call) (fuel : Nat) {s : State} {cells : List (Option Value)} {slot : Nat}
    (h : At s cells slot) :
    evalExpr Header.layout service (fuel+1) s (.var "values")=some (.pointer ⟨slot,0,[]⟩ true,s) := by
  simp [evalExpr,getVar,h.lookup,h.memory,ArrayFrames.object]

theorem lvalue (service : Call) (fuel : Nat) {s : State} {cells : List (Option Value)} {slot k counter : Nat}
    (array : At s cells slot) (index : LocalBinding.At s "k" "unsigned int" (NatWrapperCalls.unsigned32 k) counter)
    (bound : k<cells.length) :
    evalLValue Header.layout service (fuel+2) s (.index (.var "values") (.var "k"))=
      some (⟨slot,k,[]⟩,true,s) := by
  rw [evalLValue,eval_values service fuel array]
  simp only [List.isEmpty_nil,Bool.not_true,Bool.false_eq_true,↓reduceIte,Bind.bind,Option.bind]
  rw [LocalBinding.eval service fuel index (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)]
  simp [asNat,NatWrapperCalls.unsigned32,addressType,array.memory,ArrayFrames.object,bound,typeAt]

theorem write_cell {s : State} {cells : List (Option Value)} {slot k : Nat} {value : Value}
    (array : At s cells slot) (bound : k<cells.length)
    (convert : castValue Header.layout s 100 "I" value=some value) :
    write Header.layout s ⟨slot,k,[]⟩ true value=some (value,changed s cells slot k value) := by
  simp [write,addressType,array.memory,ArrayFrames.object,bound,typeAt,convert,
    List.getElem?_eq_getElem bound,changed]

theorem source_assignment (service : Call) (fuel : Nat) {s middle : State} {cells : List (Option Value)}
    {slot k counter : Nat} {value : Value} {rhs : Expr}
    (right : evalExpr Header.layout service (fuel+2) s rhs=some (value,middle))
    (array : At middle cells slot)
    (index : LocalBinding.At middle "k" "unsigned int" (NatWrapperCalls.unsigned32 k) counter)
    (bound : k<cells.length) (convert : castValue Header.layout middle 100 "I" value=some value) :
    evalExpr Header.layout service (fuel+3) s (.binary "=" (.index (.var "values") (.var "k")) rhs)=
      some (value,changed middle cells slot k value) := by
  rw [evalExpr,right]
  simp only [Bind.bind,Option.bind]
  rw [lvalue service fuel array index bound]
  exact write_cell array bound convert

end ScopedC.EvaluateArrayStore
