/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicInverseValidSource
import ScopedC.CallEventService
import ScopedC.SourceRanks
namespace ScopedC.DyadicInverseValidCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalReciprocalCalls (oneInput oneCursor)
open ScopedC.DyadicInverseValidStages (Stages sortCursor roundCursor sorted)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000
attribute [local irreducible] RationalSortCalls.after RationalReciprocalCalls.after

/-- Complete actual-call closure of the four-statement reciprocal suffix.
Its final dyadic enclosure is exactly the one produced and rounded by that
same source execution. The outer domain guard/fallback are still separate. -/
theorem source_suffix (code : List Function) {l : PoolLayout} {c : Cursor} {q : Pair}
    (a : InputI) (D : Stages code l c q a.ok) (ctx : Valid l c) (room : c.top+81 < capacity)
    (qSlot aSlot : Nat) (qBinding : LocalBinding.At c.state "q" "RI" q.source qSlot)
    (aBinding : LocalBinding.At c.state "a" "I" a.source aSlot) :
    ∃service : Call,
      (∀name args before value after, service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
        DyadicInverseValidSource.statements c.state
        (.returned D.rounded.state (DyadicCasts.value D.low.source D.high.source a.ok)) ∧
      DyadicRepresentation.interval D.rounded.state (DyadicCasts.value D.low.source D.high.source a.ok)=
        some (LeanCert.Core.IntervalDyadic.ofIntervalRat (DyadicInverseValidStages.reciprocalInterval q) (-100),a.ok) := by
  let first := D.reciprocals.first
  let next := DyadicInverseReciprocals.middle D.reciprocals
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 1],c.state,(oneInput l c).source,(oneCursor l c).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) first.oneCall⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"qv",[(oneInput l c).source,q.hi.source],(oneCursor l c).state,first.output.source,
      (RationalReciprocalCalls.after l c q.hi).state,SourceRanks.monotone (by omega : 7 ≤ 8) first.divideCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer 1],next.state,(oneInput l next).source,(oneCursor l next).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) D.reciprocals.second.oneCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qv",[(oneInput l next).source,q.lo.source],(oneCursor l next).state,D.reciprocals.second.output.source,
      (RationalReciprocalCalls.after l next q.lo).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.reciprocals.second.divideCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qmin",[first.output.source,D.reciprocals.second.output.source],(sortCursor D.reciprocals).state,
      (sorted D.reciprocals).lo.source,
      (RationalSortCalls.middle l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.minCall⟩
  let e5 : CallEvents.Event Header.layout code 8 :=
    ⟨"qmax",[first.output.source,D.reciprocals.second.output.source],
      (RationalSortCalls.middle l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      (sorted D.reciprocals).hi.source,
      (RationalSortCalls.after l (sortCursor D.reciprocals) first.output D.reciprocals.second.output).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) D.maxCall⟩
  let e6 : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[(sorted D.reciprocals).source,NatWrapperCalls.unsigned32 (SignedNegCalls.bit a.ok)],
      (roundCursor D.reciprocals).state,DyadicCasts.value D.low.source D.high.source a.ok,D.rounded.state,D.roundCall⟩
  let events := [e0,e1,e2,e3,e4,e5,e6]
  have size (x : Cursor) : (oneCursor l x).state.nats.values.length=x.state.nats.values.length+3 :=
    CursorEffects.size l x [1,0,1]
  have nextSize : next.state.nats.values.length=c.state.nats.values.length+(RationalReciprocalCalls.steps l c q.hi).length := by
    change (RationalReciprocalCalls.after l c q.hi).state.nats.values.length=_
    rw [RationalReciprocalCalls.after_advance ctx (by omega),CursorEffects.size]
  have lower : 7 ≤ (RationalReciprocalCalls.steps l c q.hi).length := by
    by_cases zero : q.hi.numerator.magnitude=0 <;>
      simp [RationalReciprocalCalls.steps,RationalDivideTrace.steps,zero,
        RationalDivideTrace.productSteps,RationalMultiplyTrace.steps]
  have qiDifferent : c.state.nats.values.length≠next.state.nats.values.length := by rw [nextSize];omega
  have qvDifferent : (oneCursor l c).state.nats.values.length≠(oneCursor l next).state.nats.values.length := by
    rw [size,size,nextSize]
    omega
  have unique : (events.map CallEvents.key).Nodup := by
    simpa [events,CallEvents.key,e0,e1,e2,e3,e4,e5,e6] using And.intro qiDifferent qvDifferent
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service events unique
  refine ⟨service,closed,?_,D.decoded⟩
  exact DyadicInverseValidSource.sequence service a D ctx room qSlot aSlot qBinding aBinding
    (answers e0 (by simp [events])) (answers e1 (by simp [events])) (answers e2 (by simp [events]))
    (answers e3 (by simp [events])) (answers e4 (by simp [events])) (answers e5 (by simp [events]))
    (answers e6 (by simp [events]))

end ScopedC.DyadicInverseValidCalls
