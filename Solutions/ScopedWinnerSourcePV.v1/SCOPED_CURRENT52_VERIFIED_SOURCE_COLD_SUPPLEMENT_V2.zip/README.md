# Verified source-cold current52 component

The unchanged original52-body source capsule now has an actual completed HOST application-source replay:644 sources,885 C/input payloads and767 selected complete theorem-closure audits. Every selected closure uses standard Lean axioms only; no application object files were admitted. This is a component result. The full Scoped Winner program from preparation through evaluation/quadrature/main/printing and its source-linked ANT outputs remains incomplete.

## Reproduce

Unzip SCOPED_CURRENT52_SOURCE_COMPONENTS_V1.zip into a fresh source directory. Its source lock, scripts, compiler/runtime pins, exact public dependency commits and actual52 C function identities are unchanged. Obtain the pinned Lean4.34.0-rc2 toolchain and public Mathlib dependency tree, then run from that extracted directory:

    python prepare_environment.py --toolchain /path/to/lean-4.34.0-rc2-linux --mathlib /path/to/pinned/mathlib --out /tmp/current52-public.json
    python -OO reproduce.py --environment /tmp/current52-public.json --out /tmp/current52-fresh --jobs 2

Use a new output directory each time. This is exactly the unchanged clean recipe that passed. It reconstructs the nested source components, verifies all source/input identities, compiles every application module from source, then audits the exact767 requested roots. Public generic caches are allowed; old application object caches are not. The source/AST correspondence and mathematical helper inputs are in the locked source capsule. This source-body proof collection creates no new numerical-data claim; separate original numerical-run and complete-program consumers retain their own boundaries.

## Results and trust

Actual proof payload2261.907853605s; resource scope2264.602043178s. Requested24GiB/4CPU/jobs2. Sampled aggregate charged-memory peak8,884,277,248B (a lower bound); maximum individual compiler RSS14,730,981,376B across645 compiler/audit processes. These are different measurements. Zero max/OOM/OOM-kill events. Final run regular-file bytes360,156,501; per-run disk peak was not instrumented. Source/receipt/log/object identities were independently read back after successful completion.

The run uses the pinned generic compiler/kernel/runtime and documented platform contracts. It does not prove the compiler, repeat actual C execution in this particular proof recipe, establish namespace-isolated acceptance, finish the remaining16 source bodies or replace application initialization/lifetime/output obligations with a trusted success assumption.

## Preserved history and qualifier correction

The earlier469/644 run stopped at the owner's pause and remains interrupted. The original52 source ZIP remains byte-identical, SHA2562658f15e1ee18ba23e56a6ff5a04771d9138895c947ed264ff5b97dd807cc745. A copied lock qualifier still says an older combined48 closure had not received a fresh full replay; that historical boilerplate was copied verbatim into the new raw receipt. QUALIFICATION_ERRATUM.json explains why the actual644-module/767-root run records establish the new completed component. No historical source, result or raw receipt was rewritten. This supplemental successful run is not a retroactive primary experimental outcome.

Original sources, locked inputs and accepted proof artifacts remain preserved. Generated binaries and checked-regenerable CLI fixture copies were removed under separate preview/cleanup receipts; accepted proof objects and essential evidence are retained.
