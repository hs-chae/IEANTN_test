"""Offline supplemental report with receipt-gated, deliberately bounded claims."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parents[1]
STD = {'propext', 'Classical.choice', 'Quot.sound'}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read(name):
    p = R/name
    return json.loads(p.read_text())


def formula(body):
    return '<div class="formula"><math xmlns="http://www.w3.org/1998/Math/MathML" display="block">'+body+'</math></div>'


def main():
    for name, root in [
        ('research/main-weight-v1/final-PNT-v1/RECEIPT.json',
         'SourceMainWeightsV1.PNT.source_pi_actual_weights'),
        ('research/main-weight-v1/prime-rich-v1/RECEIPT.json',
         'SourceMainWeightsV1.PNT.source_prime_rich_actual_weights')]:
        d = read(name)
        need(d['status']=='PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES' and
             root in d['audits'] and set(d['audits'][root]) <= STD, 'actual numerical ANT consumer')
    d = read('research/main-weight-v1/aggregate-v5/RECEIPT.json')
    need(d['status']=='PASS_ALL768_EXACT_C_EXPRESSION_MODEL_SUM_AND_DOMAINS', 'actual C-expression sum')
    need((R/'scoped/build/current52-source-cold-resume-v2/RECEIPT.json').is_file(), 'fresh52 receipt')
    d = read('research/analytic/work/main-complete-model-v1/RECEIPT.json')
    root = 'SynergyHeightC.MainCompleteModel.complete_source_main_and_pnt'
    need(d['status']=='PASS_SELECTED_CONSUMERS_FULL_STD3_CLOSURES' and
         root in d['audits'] and set(d['audits'][root]) <= STD,
         'complete modeled main-to-ANT proof')
    d = read('scoped/frontend/proof/SOURCE_HELPER_SUPPORT_INDEX_V31.json')
    need(len(d['concrete_functions'])==28, 'numerics whole-body count28')
    s = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>IEANTN resumed source verification: 15 November 2026</title>
<style>body{font:17px/1.5 system-ui,sans-serif;background:#f2f5f8;color:#183044;max-width:960px;margin:auto;padding:20px;overflow-wrap:anywhere}h1{font-size:1.8rem;line-height:1.2}h2{font-size:1.18rem}section{background:white;border:1px solid #ccd6df;border-left:6px solid #24835c;border-radius:9px;padding:17px;margin:16px 0}.pending{border-left-color:#ba7b1e}.meta{font-size:.86rem;color:#4a6072}a{color:#125c9d}a:focus{outline:3px solid #bc771b}code{font-size:.83em}.formula{overflow:auto}math{font-size:1.03em}li{margin:7px 0}@media(max-width:600px){body{padding:10px}h1{font-size:1.5rem}section{padding:13px}math{font-size:.93em}}</style>
<h1>Actual C numerical outputs reach the conditional PNT theorem</h1>
<p><strong>Substantial new source proofs are complete. The entire original program migration and full research campaign remain unfinished.</strong> This is a supplemental proof checkpoint; historical experimental outcomes are unchanged.</p>
<section><h2>The original frozen result is preserved</h2>
<p>The 39 comparator identities, original mathematical assumptions and the two integration algorithms remain fixed. The original strict comparison on the interval below already has a complete ordinary-kernel proof with no native execution axioms. That proof is kernel-only; it does not complete source-first verification of the original C program.</p>'''
    s += formula('<mtable><mtr><mtd><mrow><mn>0.009474458010474448</mn><mo>→</mo></mrow></mtd></mtr><mtr><mtd><mn>0.009471462010471452</mn></mtd></mtr><mtr><mtd><mrow><mo>[</mo><msup><mi>e</mi><mn>330</mn></msup><mo>,</mo><msup><mi>e</mi><mn>331</mn></msup><mo>]</mo></mrow></mtd></mtr></mtable>')
    s += '''<p>The original and evolved numerical algorithms use 8,192 and 16,384 integration cells. All 3,840 chunks, ten rows and 122,880 cells have kernel-only verification. The full 106-module build preserves all 42 selected theorem types; the comparison closure is audited separately.</p></section>
<section><h2>A completed actual-C numerical connection</h2>
<p>All 768 actual C point executions are proved in the real main caller frame, for every accumulated total. All 768 input-edge constructions and 768 arithmetic suffixes are proved. The suffixes include the actual exponential subtraction, direct interval division, rounding and total update. The C code and parameters are unchanged.</p>
<p>The exact C-expression model has all 24 numerical blocks and every domain condition checked by Lean’s ordinary kernel. Its upper total word is:</p>'''
    s += formula('<mtable><mtr><mtd><mfrac><mn>2869890699926766771254572444732902052</mn><msup><mn>2</mn><mn>128</mn></msup></mfrac></mtd></mtr><mtr><mtd><mrow><mo>≤</mo><mn>0.008433850764</mn></mrow></mtd></mtr></mtable>')
    s += '''<p>The final PNT and prime-rich consumers use the actual source-produced point intervals and this actual-C weight sum. No finite numerical-provider premise remains. The complete selected closures contain only the standard logical axioms <code>propext</code>, <code>Classical.choice</code> and <code>Quot.sound</code>.</p>'''
    s += formula('<mrow><msub><mi>E</mi><mi>π</mi></msub><mo>(</mo><mi>x</mi><mo>)</mo><mo>≤</mo><mn>0.008441646</mn><msup><mi>x</mi><mrow><mo>−</mo><mfrac><mn>1</mn><mn>8</mn></mfrac></mrow></msup><mspace width="1em"/><mo>(</mo><mi>x</mi><mo>≥</mo><msup><mi>e</mi><mn>330</mn></msup><mo>)</mo></mrow>')
    s += formula('<mrow><msub><mi>E</mi><mi>π</mi></msub><mo>(</mo><mi>x</mi><mo>)</mo><mo>=</mo><mfrac><mrow><mo>|</mo><mi>π</mi><mo>(</mo><mi>x</mi><mo>)</mo><mo>−</mo><msub><mi>Li</mi><mn>2</mn></msub><mo>(</mo><mi>x</mi><mo>)</mo><mo>|</mo></mrow><mrow><mi>x</mi><mo>/</mo><mi>log</mi><mo>(</mo><mi>x</mi><mo>)</mo></mrow></mfrac></mrow>')
    s += '''<p>The prime-rich theorem gives at least the following count in the displayed interval:</p>'''
    s += formula('<mrow><mfrac><mrow><mn>0.000114</mn><msup><mi>x</mi><mfrac><mn>7</mn><mn>8</mn></mfrac></msup></mrow><mrow><mi>log</mi><mo>(</mo><mi>x</mi><mo>)</mo></mrow></mfrac><mspace width="1em"/><mtext>primes in</mtext><mspace width=".5em"/><mo>(</mo><mi>x</mi><mo>,</mo><mi>x</mi><mo>+</mo><mn>0.017</mn><msup><mi>x</mi><mfrac><mn>7</mn><mn>8</mn></mfrac></msup><mo>]</mo></mrow>')
    s += '''<p>All eight original <code>PrimaryInputs</code> fields and six separate analytic hypotheses remain: the original CHJ source contract, both RVM error contracts, low-zero input, RH through 3 trillion and QRH’s open zero-free half-plane with real part greater than 7/8, preserving the pole convention. QRH is an explicit input; an OpenAI QRH formal proof is not instantiated in this compiler bank. No optimality, best-known or global full-function dominance claim is made.</p>
<p><a href="OWNER_SCOPE_PNT_MECHANISM_V1.html">Mathematical explanation and exact source correspondences</a> · <a href="evidence/resumed-20261115/ARTIFACTS.json">Archive identities</a></p></section>
<section><h2>Complete source main: checked normal-output path</h2>
<p>Accepted Lean components compose the actual main initialization, 768-row loop, accumulation recurrence, physical total read, the same interval’s 128 output bytes, checked flush and return. The output-to-PNT theorem uses the physically read total. The source-bound global initialization equality is proved rather than assumed.</p>
<p>The final concrete model constructs all 768 row-output calls, the final emitter and flush, with no remaining application or I/O-trace premise. Its explicit all-success standard-I/O model is a modeled scenario, not an unconditional host-success fact. Short writes and flush failures remain modeled; accepted bytes and delivered bytes are distinct. The fresh compiled run and source/build/run association remain separate acceptance work.</p></section>
<section><h2>Original program: 54 of 68 bodies</h2>
<p>The original program now has 54 whole-function source contracts in source-associated host builds. New completed additions are <code>atanhPoint</code>, including its original-model and real-validity joins under explicit coefficient/depth applicability, and <code>expRemainder</code>, including the complete source factorial loop and exact original numerical-model result. These are separate from the height program’s complete main composition.</p>
<p>A fresh replay of the fixed 52-function checkpoint has actually passed: all 644 application modules, 885 payloads and 767 selected root audits. It took 2,261.908 proof seconds and 2,264.602 scope seconds, with zero OOM events and no application object inputs. This is fresh52; it does not establish a fresh replay of all54. The owner-paused earlier 469/644 attempt remains preserved.</p>
<p><a href="SCOPED_CURRENT52_VERIFIED_SOURCE_COLD_SUPPLEMENT_V2.zip">Verified fresh52 source and receipts</a> · <a href="SOURCE_INTEGRATION_RESUMED_20261115.zip">Dated53-function source/evidence checkpoint, including explicitly rejected drafts</a></p></section>
<section class="pending"><h2>Clean reproduction and remaining obligations</h2>
<p>The 390-source C component and the fixed52 checkpoint have completed host source-cold replays. The larger 1,412-source C-to-PNT replay is recorded separately; its input archive alone is not proof of acceptance. A second capsule appends 860 sources for a total 2,272-source framed-point/actual-weight PNT graph. The full main graph requires a further extension. Consult each capsule’s final receipts before attributing completion.</p>
<p><a href="SOURCE_PNT_COMPOSITION_SOURCE_ONLY_COMPONENT_V1.zip">1,412-source clean reproduction input</a> · <a href="SOURCE_ACTUAL_FRAME_WEIGHT_PNT_SOURCE_ONLY_COMPONENT_V1.zip">2,272-source chained reproduction input</a></p>
<p>All capsules preserve code, exact inputs and parameters, pinned dependencies, commands and hashes; completed runs preserve verification receipts. Prepared inputs are labeled separately from completed replays. Host source-cold proof development is separate from final namespace-isolated acceptance.</p>
<p>The remaining work includes the other original C function bodies and full original-program consumers, final observed-run/source/build association, the full selected clean-source closure, final isolated acceptance, confirmatory matched exposure experiments, stronger same-premise challengers and the complete research report/bundle. Historical67/192 outcomes and eight exploratory sessions are unchanged. No causal exposure advantage or necessity of source-first PV has been established.</p></section>
<section class="pending"><h2>Trust and resources</h2>
<p>Source-first PV means actual C source → bound AST → formally defined execution → mathematical correctness → IEANTN theorem. Ordinary kernel computation and certificate checking alone do not meet that definition. The selected proofs introduce no new axiom or admission; runtime application, compiler applicability and actual observed-run association are separately audited.</p>
<p>Remaining platform trust includes the precise pinned compiler/core runtime, ABI, documented OS/I/O contracts and hardware. Application initialization, desired output or unconditional I/O success are not generic platform facts.</p>
<p>The policy independently checks available RAM and free disk. The study retains a 300 GiB aggregate RAM allowance and 300 GiB scratch allowance, host reserves and matched treatment. The framed768 proof used 192 GiB, with 159,547,240,448 sampled charged bytes and zero OOM; input edges used 48 GiB and 30,129,745,920 sampled charged bytes. Sampled charged peaks are lower bounds on true peaks, and per-process RSS is reported separately. External interruptions are preserved as interruptions, never mathematical failures or passes.</p>
<p class="meta">This is a bounded, receipt-backed progress report, not an exhaustive primary-source audit or the final exposure research report. Older dated reports, original outcomes and protected branches are preserved.</p></section></html>'''
    out = R/'reports/RESUMED_SOURCE_PROGRESS_V6.html'
    out.write_text(s)
    print(json.dumps(dict(path=str(out), bytes=out.stat().st_size,
                          sha256=hashlib.sha256(out.read_bytes()).hexdigest())))


if __name__ == '__main__':
    main()
