"""Read the published checkpoint offline and bind geometry/math checks to bytes."""
import argparse
import hashlib
import json
from pathlib import Path
from playwright.sync_api import sync_playwright


def need(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--report', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--expected-math-count', type=int, required=True)
    args = ap.parse_args()
    need(args.expected_math_count > 0, 'positive math population')
    report = args.report.resolve()
    out = args.out.resolve()
    need(report.is_file() and not out.exists(), 'report and fresh output')
    out.mkdir(parents=True)
    rows = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        for width in [390, 1440]:
            page = browser.new_page(viewport={'width': width, 'height': 950})
            errors = []
            page.on('pageerror', lambda e: errors.append(str(e)))
            page.route('**/*', lambda route: route.continue_() if route.request.url.startswith('file:') else route.abort())
            page.goto(report.as_uri(), wait_until='load')
            row = page.evaluate('''() => ({viewport:innerWidth,
                documentWidth:document.documentElement.scrollWidth,
                mathCount:document.querySelectorAll('math').length,
                formulaOverflow:[...document.querySelectorAll('.formula')].filter(e=>e.scrollWidth>e.clientWidth).map(e=>({scroll:e.scrollWidth,client:e.clientWidth})),
                badBinaryMath:[...document.querySelectorAll('mfrac,msup,msub,mroot')]
                    .filter(e=>e.children.length!==2).map(e=>e.outerHTML),
                badTernaryMath:[...document.querySelectorAll('msubsup')]
                    .filter(e=>e.children.length!==3).map(e=>e.outerHTML)})''')
            image = out / f'{width}.png'
            page.screenshot(path=str(image), full_page=True)
            row.update(screenshot_sha256=hashlib.sha256(image.read_bytes()).hexdigest(), errors=errors)
            rows.append(row)
            (out / 'PARTIAL.json').write_text(json.dumps(rows, indent=2)+'\n')
            need(row['documentWidth'] <= width and row['mathCount'] == args.expected_math_count and
                 not row['formulaOverflow'] and not row['badBinaryMath'] and not row['badTernaryMath'] and not errors,
                 'offline math or layout')
            page.close()
        browser.close()
    receipt = dict(status='PASS_OFFLINE_MATH_ARITY_MOBILE_DESKTOP', rows=rows,
                   report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(), no_network=True)
    pending = out / 'RECEIPT.pending'
    pending.write_text(json.dumps(receipt, indent=2)+'\n')
    pending.replace(out / 'RECEIPT.json')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
