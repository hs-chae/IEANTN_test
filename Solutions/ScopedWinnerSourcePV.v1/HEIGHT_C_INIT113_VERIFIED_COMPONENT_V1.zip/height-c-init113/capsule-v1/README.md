# Actual C height initialization — source-cold113 component

This extends the immutable112-source source-binding component with the complete actual `initializePointConstants` execution. The58computed constants are accepted only after every actual source operation executes and complete application memory agrees with the model cache. The source-associated host proof completed at96GiB with Std3 only; this new combined113source replay is initially PENDING until its own receipt says PASS.

Prepare the exact pinned public generic dependency environment using `prepare_environment.py`, then run:

```
python3 reproduce.py --environment /path/to/PUBLIC_GENERIC_ENV.json --out /fresh/output --jobs 2
```

No application object input is accepted. Expect a substantial kernel computation: the actual host initializer took719.34seconds and about66GBchargedRAM. Use an outer resource limit of96GiB or a justified larger allocation, maintaining the owner's aggregate resource budget. No hidden64GiBvirtual-memory cap applies. Exact runtime/kernel/payload identities are checked before and after replay. The root audit rejects every axiom except propext, Classical.choice and Quot.sound. Actual C compilation/run association is reproduced separately by the included source-component CPP script; this proof replay does not claim to repeat that execution.

This is a finite-input actual C source-execution component, not completed source-first PNT PV. The full768point source computations, actual main input/loop/output path and mathematical consumer connection remain additional obligations. The generic compiler/core runtime/ABI/OS/hardware contracts remain explicit; metadata/native association checks are not promoted into mathematical proof leaves. Older evidence under evidence/ is historical and is not this replay's receipt. No random seed is used.
