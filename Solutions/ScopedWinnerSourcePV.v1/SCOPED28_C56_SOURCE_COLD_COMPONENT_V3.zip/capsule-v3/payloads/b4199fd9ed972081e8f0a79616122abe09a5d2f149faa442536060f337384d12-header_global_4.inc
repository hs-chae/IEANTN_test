static N scale100;
