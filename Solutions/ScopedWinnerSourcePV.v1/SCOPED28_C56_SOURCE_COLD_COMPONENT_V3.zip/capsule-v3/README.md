# Fresh 28-body and checked C56 source-binding proof component

Run `python3 reproduce.py --environment /absolute/PUBLIC_GENERIC_ENV.json --out /fresh/output --jobs 2`.
The existing environment schema has compiler and generic_dependencies entries, each with name,commit,url,source,objects.
Only public generic dependency objects are used; all application objects start absent.
Exact runtime/kernel/toolchain identities are checked before and after the replay.

All written application sources are copied from their recorded identities. Only actual include_str pathname literals are ported; every referenced payload is copied byte-exact and hashed. C56 source-file organization/run association and its separately recorded raw56-row execution are not repeated by this proof-only replay. There is no namespace-isolation or whole-program/source-first-PV completion claim.

## Preparing a clean public environment

Use Linux x86-64 and the pinned Lean4.34.0-rc2 distribution (commit6a10ac8c22beadecabdbb0919c2b50214762f91d). The exact16runtime/kernel/stdlib/compiler sentinels and all public dependency commits are in SOURCE_LOCK.json. Obtain the official toolchain and clone leanprover-community/mathlib4 at71a80585ee495fc24472fd0eaffc89d94e4fd8d6. In that checkout, use the pinned toolchain's lake executable to run `lake exe cache get`; the pinned lake manifest selects the public libraries. Do not copy application object banks.

Then run:

```
python3 prepare_environment.py --toolchain /path/to/lean-4.34.0-rc2-linux --mathlib /path/to/mathlib --out /fresh/public-env.json
python3 reproduce.py --environment /fresh/public-env.json --out /fresh/replay --jobs 2
```

The preparer only records public generic library paths and rejects wrong source/runtime identities and existing output files. Actual normal/-O/-OO command-line controls passed; the full proof replay was executed once in normal mode. Public library implementations and the exact pinned generic compiler/kernel/runtime/hardware remain the documented foundation. No application initialization, desired output, successful evaluator execution or whole-program correctness is a platform assumption.

## Actual accepted replay

The saved replay compiled343application modules with885byte-exact captured include payloads from empty application objects, then reflected60full theoremtypes/transitive axiom closures. Every selected closure has only propext, Classical.choice and Quot.sound. Runtime1571.555514seconds,24GiB memory reservation,0OOM events; maximum individual processRSS14742102016bytes. This is HOST source-cold; namespace isolation is false. ActualC56execution was not repeated by this proof component; its separate56-row run remains distinct. The imported context contains unused native declarations, including WinnerBetaA.Numerical.all_checks; none occurs in these60accepted theorem closures.

These28helper contracts and C56source bindings are partial components. Rational/Taylor/DAG/whole-loop/stdio/main/application output-to-ANT proofs and the complete final isolated migration still remain open.
