"""Resume only the final audit of a fully source-associated2272-module replay.

The original failed run, all locked source bytes, all objects and its logs are
read-only inputs. No unassociated application object is admitted. This receipt
is explicitly a resumed source-cold pipeline, never a fresh uninterrupted run.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import time

STD3 = {'propext', 'Classical.choice', 'Quot.sound'}

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def strict(text):
    def pairs(rows):
        result = {}
        for key, value in rows:
            need(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=invalid)

def atomic(path, value):
    temp = path.with_suffix('.pending')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(temp, path)

def validate(capsule, run, base_run, environment):
    spec = importlib.util.spec_from_file_location('exact_failed_append', capsule / 'reproduce_append.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    lock, base = module.source_inputs()
    e = module.environment_inputs(environment, lock)
    _, association = module.validated_base(base_run, base, lock)
    need(strict((run / 'BASE_ASSOCIATION.json').read_text()) == association, 'same fresh1412 base association')
    failure = strict((run / 'FAILURE.json').read_text())
    need(failure['status'] == 'FAILED_PRESERVED_NOT_ACCEPTED'
         and failure['error'] == 'compiler failed: audit', 'exact preserved final-audit failure')
    old_audit = (run / 'logs/audit.stdout').read_text()
    need('maximum recursion depth reached in the code generator' in old_audit
         and 'APPEND_AUDIT ' not in old_audit, 'known code-generator failure before any audit acceptance')
    check = strict((run / 'CHECKPOINT.json').read_text())
    need(check['status'] == 'PARTIAL_NOT_ACCEPTED'
         and check['source_lock_sha256'] == sha(capsule / 'SOURCE_LOCK.json')
         and check['base_association_sha256'] == sha(run / 'BASE_ASSOCIATION.json')
         and check['records'] == failure['records'], 'last complete source checkpoint/failure association')
    records = check['records']
    names = {r['module'] for r in lock['sources']}
    need(len(records) == 861 and {r['name'] for r in records} == names | {'seed-imports'},
         'all860 actual source commands plus seed import probe')
    by_name = {r['name']: r for r in records}
    for name, row in by_name.items():
        need(row['exit_code'] == 0, 'actual source compile exit: ' + name)
        for suffix, field in [('.stdout', 'stdout_sha256'), ('.stderr', 'stderr_sha256'), ('.time', 'time_sha256')]:
            p = run / 'logs' / (name + suffix)
            need(p.is_file() and not p.is_symlink() and sha(p) == row[field], 'source compile log identity: ' + name)
        module.diagnostic((run / 'logs' / (name + '.stdout')).read_text(),
                          (run / 'logs' / (name + '.stderr')).read_text(), name)
    objects = []
    for row in association['associated_objects']:
        p = run / 'objects' / Path(row['module'].replace('.', '/')).with_suffix('.olean')
        need(p.is_file() and not p.is_symlink() and sha(p) == row['object_sha256'],
             'same fresh1412 seeded object: ' + row['module'])
        objects.append(row)
    seeded = strict((run / 'SEEDED_BASE_OBJECTS.json').read_text())
    need(seeded['status'] == 'VALIDATED_FRESH_BASE_OBJECTS_ONLY'
         and seeded['outside_application_object_inputs'] == []
         and seeded['objects'] == [dict(module=r['module'], object_sha256=r['object_sha256'])
                                 for r in association['associated_objects']], 'exact seeded fresh1412 population')
    for row in lock['sources']:
        record = by_name[row['module']]
        p = run / 'objects' / Path(row['module'].replace('.', '/')).with_suffix('.olean')
        command = record['command']
        need(len(command) == 7 and command[1:3] == ['-j1', '-R'] and command[5] == '-o'
             and Path(command[3]).resolve() == (capsule / 'source').resolve()
             and Path(command[4]).resolve() == (capsule / row['path']).resolve()
             and Path(command[6]).resolve() == p.resolve()
             and sha(Path(command[0])) == lock['compiler_sha256']
             and record['source_sha256'] == row['sha256']
             and sha(Path(command[4])) == row['sha256']
             and p.is_file() and not p.is_symlink() and sha(p) == record['object_sha256'],
             'complete actual source-to-object association: ' + row['module'])
        objects.append(dict(module=row['module'], source_sha256=row['sha256'], object_sha256=sha(p)))
    expected = {str(Path(r['module'].replace('.', '/')).with_suffix('.olean')) for r in objects}
    need(len(objects) == 2272 and {str(p.relative_to(run / 'objects'))
         for p in (run / 'objects').rglob('*.olean')} == expected, 'exact coherent2272 source-built bank')
    return lock, base, module, e, dict(status='VALIDATED_ALL2272_SAME_PIPELINE_SOURCE_BUILT_OBJECTS',
        capsule=str(capsule), partial_run=str(run), base_run=str(base_run),
        source_lock_sha256=sha(capsule / 'SOURCE_LOCK.json'),
        reproducer_sha256=sha(capsule / 'reproduce_append.py'),
        reproducer_lock_sha256=sha(capsule / 'REPRODUCER_LOCK.json'),
        preserved_failure_sha256=sha(run / 'FAILURE.json'),
        checkpoint_sha256=sha(run / 'CHECKPOINT.json'),
        base_association_sha256=sha(run / 'BASE_ASSOCIATION.json'),
        seeded_base_objects_sha256=sha(run / 'SEEDED_BASE_OBJECTS.json'),
        source_modules=2272, fresh_base_source_modules=1412, fresh_append_source_modules=860,
        objects=objects, outside_application_object_inputs=[])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capsule', type=Path, required=True)
    parser.add_argument('--partial-run', type=Path, required=True)
    parser.add_argument('--base-run', type=Path, required=True)
    parser.add_argument('--environment', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    capsule, run, base_run, environment, out = [getattr(args, name).resolve()
        for name in ['capsule', 'partial_run', 'base_run', 'environment', 'out']]
    need(not out.exists() and capsule not in out.parents and run not in out.parents
         and base_run not in out.parents, 'fresh continuation output outside every preserved input')
    start = time.monotonic()
    lock, base, module, e, association = validate(capsule, run, base_run, environment)
    out.mkdir(parents=True)
    atomic(out / 'SOURCE_ASSOCIATION.json', association)
    roots = list(dict.fromkeys(base['roots'] + lock['roots']))
    modules = list(dict.fromkeys(base['root_modules'] + lock['root_modules']))
    need(len(roots) == 5613, 'exact5613 final roots')
    audit = out / 'Audit.lean'
    text = ''.join('import ' + n + '\n' for n in modules)
    text += 'import Lean.Util.CollectAxioms\nopen Lean Elab\nset_option maxHeartbeats 0\nset_option maxRecDepth 100000\n'
    for begin in range(0, len(roots), 64):
        text += 'run_elab do\n let env ← getEnv\n for n in ([' + ','.join('`' + n for n in roots[begin:begin + 64])
        text += '] : List Name) do\n  let some _ := env.find? n | throwError "missing {n}"\n'
        text += '  let ax ← Lean.collectAxioms n\n  logInfo m!"RESUMED_AUDIT {(Json.mkObj [("name",toJson n.toString),("axioms",toJson (ax.toList.map Name.toString))]).compress}"\n'
    audit.write_text(text)
    env = os.environ.copy()
    env['LEAN_PATH'] = ':'.join([str(run / 'objects')] + [d['objects'] for d in e['generic_dependencies']])
    env['LEAN_NUM_THREADS'] = '1'
    command = [e['compiler'], '-j1', '-R', str(out), str(audit)]
    with (out / 'audit.stdout').open('w') as f, (out / 'audit.stderr').open('w') as g:
        q = subprocess.run(['/usr/bin/time', '-v', '-o', str(out / 'audit.time'), *command],
                           stdout=f, stderr=g, cwd=out, env=env)
    need(q.returncode == 0, 'chunked final audit failed; all original evidence preserved')
    module.diagnostic((out / 'audit.stdout').read_text(), (out / 'audit.stderr').read_text(), 'resumed audit')
    rows = [strict(line.split('RESUMED_AUDIT ', 1)[1]) for line in (out / 'audit.stdout').read_text().splitlines()
            if 'RESUMED_AUDIT ' in line]
    need([r['name'] for r in rows] == roots and len(rows) == 5613
         and all(set(r['axioms']) <= STD3 for r in rows), 'complete5613 ordered final standard-axiom closures')
    _, _, _, _, final_association = validate(capsule, run, base_run, environment)
    need(final_association == association, 'all original source/object/log identities unchanged after audit')
    result = dict(status='PASS_RESUMED2272_SOURCE_COLD_GRAPH_COMPLETE5613_STD3_AUDIT',
        source_modules=2272, selected_theorem_roots=5613, resumed_final_audit_only=True,
        uninterrupted_fresh_replay=False, complete_source_cold_pipeline=True,
        namespace_isolated=False, outside_application_object_inputs=[],
        source_association_sha256=sha(out / 'SOURCE_ASSOCIATION.json'),
        source_lock_sha256=association['source_lock_sha256'], reproducer_sha256=sha(Path(__file__)),
        audit_source_sha256=sha(audit), command=command, audit_exit_code=q.returncode,
        stdout_sha256=sha(out / 'audit.stdout'), stderr_sha256=sha(out / 'audit.stderr'),
        time_sha256=sha(out / 'audit.time'), audits=rows, elapsed_seconds=time.monotonic() - start,
        qualification='All2272 application objects originate from the same validated source-cold1412+860 pipeline. The original append final audit failed in code generation before any closure audit. Only the audit harness was resumed with64-root code-generation batches; all5613 complete closures are now checked. Original failure/source/objects/logs preserved. This is resumed host source-cold verification, not an uninterrupted or namespace-isolated run; original68-function migration remains separate.')
    atomic(out / 'RECEIPT.json', result)
    print(json.dumps({k: result[k] for k in ['status', 'source_modules', 'selected_theorem_roots', 'elapsed_seconds']}))

if __name__ == '__main__':
    main()
