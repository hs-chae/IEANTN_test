# Verified resumed2272-source actual-frame/weight/ANT supplement

All1412base and860append application modules were rebuilt from source in one
associated pipeline, with no outside application object input. All5613 distinct
complete Lean theorem closures passed using only propext/Classical.choice/Quot.sound.
The860source compilation run took5574.89s. Its final single-list audit failed in
Lean code generation before producing any audit rows. That original failure remains
unchanged. A separately recorded64-root-batch audit then passed after exhaustive
source/command/log/object association before and after execution. This is resumed
host source-cold verification, not an uninterrupted or namespace-isolated run.

source-input.zip contains all2272sources, originalCpayloads/numericalproposals,
exactparameters and the original recipes; it contains no application object.
continuation/reproduce.py is the source-linked audit repair. accepted-resumed/
contains the actual5613rawaudit/receipt, complete2272objecthash associations and
independent readback/resources. preserved-source-run/ keeps original failure,
sourcecheckpoint and all actualcompiler stdout/stderr/timing. fresh1412/ records
the accepted source-cold base. Acceptedobjects remain preserved in the experiment
workspace and can be regenerated from the distributed source; they are not warm
inputs to clean reproduction.

## Reproduction

Extract source-input.zip to a fresh directory CAPSULE. Fetch only the pinned
public generic environment using environment-bootstrap/scripts/bootstrap.py
--work FRESH_PUBLIC --receipt FRESH_PUBLIC_RECEIPT, then run
CAPSULE/base/prepare_environment.py --toolchain PINNED_LEAN --mathlib PINNED_MATHLIB
--out ENVIRONMENT_JSON. Allscripts expose actual--help flags; use absolute paths.

Run CAPSULE/base/reproduce_all.py --environment ENVIRONMENT_JSON --out FRESH_BASE
--jobs 8 --point-jobs 8 (write each option/value as separate shellwords). Then run
CAPSULE/reproduce_append.py --environment ENVIRONMENT_JSON --base-run FRESH_BASE
--out FRESH_APPEND --jobs 14 --frame-jobs 14 --weight-jobs 6. This preserved original
recipe is expected to finish all860compiles and fail only its large-list final
audit. Run continuation/reproduce.py --capsule CAPSULE --partial-run FRESH_APPEND
--base-run FRESH_BASE --environment ENVIRONMENT_JSON --out FRESH_AUDIT. The repair
requires the exact known code-generator failure, all860actual compiler records,
source/object/command/log hashes and the complete associated fresh1412bank; it
never accepts arbitrary cached objects. It emits its own final receipt only after
all5613closures and the final identity readback pass. Actualcomponentcommands above
were executed in this study; this textual combined wrapper is not a new run.

Reserve resources with actual separate RAM/disk checks. Study reservations used
256GiB/16CPU forsourcecompile and24GiB/2CPU forresumedfinalaudit, with an aggregate
300GiB/64CPU cap and hostreserves. Observed sampled aggregatecharged compilepeak
157667737600B is a lowerbound, not an instrumentedtruepeak; maxindividualRSS was
28843167744B. Finalaudit maxindividualRSS7712018432B. No recorded OOMevents.
Disk snapshots and precise times/commands/hashes are in the independent receipt;
diskpeak was notinstrumented. Original14analyticpremises/C/model/algorithms and
numericalwords are unchanged. Allcomputations deterministic; no randomseed.

Thisselectedsourcechain proves actualframe/weighttoANT correctness under its
unchanged analytic assumptions. It doesnot finish the entireoriginal68function
migration or finalisolatedwholemain replay. Genericpinned compiler/kernel/library,
coreruntime/ABI/OS/API/hardwarecontracts remain; no compilerproof or universalhost
I/Osuccessclaim ismade. Cleanuphasnotdeleted source, acceptedobjects or original
evidence. Regenerableexecutablesonlywere removed by the originalcheckedrecipes.
