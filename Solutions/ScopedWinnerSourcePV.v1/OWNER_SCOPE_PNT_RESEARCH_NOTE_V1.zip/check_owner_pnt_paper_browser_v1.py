"""Check the actual offline report at phone and desktop widths."""
from pathlib import Path
import hashlib,json
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parent

def need(ok,message):
    if not ok:
        raise RuntimeError(message)

def main():
    out=P/'owner-pnt-paper-browser-v1'
    need(not out.exists(),'fresh browser result required')
    out.mkdir()
    source=P/'OWNER_SCOPE_PNT_MECHANISM_V1.html'
    rows=[]
    with sync_playwright() as playwright:
        browser=playwright.chromium.launch(headless=True)
        for width,height in [(390,844),(1280,1000)]:
            context=browser.new_context(viewport={'width':width,'height':height},offline=True)
            page=context.new_page()
            page.goto(source.as_uri(),wait_until='load')
            metrics=page.evaluate('''() => ({width:innerWidth,scroll:document.documentElement.scrollWidth,scriptCount:document.scripts.length,external: [...document.querySelectorAll('script[src],link[href],img[src]')].map(x=>x.src||x.href).filter(x=>/^https?:/.test(x)),rawTeX:/\\\\\(|\\\\\[|\\$\\$/.test(document.body.innerText)})''')
            need(metrics['scroll']<=metrics['width'],'horizontal overflow')
            need(metrics['scriptCount']==0 and metrics['external']==[],'not offline/self-contained')
            need(not metrics['rawTeX'],'raw TeX visible')
            screenshot=out/('width-'+str(width)+'.png')
            page.screenshot(path=str(screenshot),full_page=True)
            rows.append({'width':width,'height':height,'metrics':metrics,'screenshot_sha256':hashlib.sha256(screenshot.read_bytes()).hexdigest()})
            context.close()
        version=browser.version
        browser.close()
    receipt={'status':'OFFLINE_MOBILE_DESKTOP_REPORT_PASS','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'browser':'Chromium '+version,'checks':rows,'qualification':'Geometry/offline/math-delimiter checks; actual screenshot inspection is additional.'}
    (out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(receipt['status'])

if __name__=='__main__':
    main()
