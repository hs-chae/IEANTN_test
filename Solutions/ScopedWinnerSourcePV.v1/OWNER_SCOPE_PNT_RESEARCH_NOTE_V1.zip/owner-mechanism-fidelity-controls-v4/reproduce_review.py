from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3]
p=Path(__file__).with_name('REVIEW.json');d=json.loads(p.read_text())
for name,expected in d['source_hashes'].items():
 q=R/name
 if not q.is_file()or hashlib.sha256(q.read_bytes()).hexdigest()!=expected:raise RuntimeError('source identity changed: '+name)
if d['blocking_findings']:raise RuntimeError('unresolved blocking findings')
print(json.dumps(dict(status='PASS_PINNED_REVIEW_IDENTITIES',files=len(d['source_hashes']),qualification='Hash check only; does not independently rerun Lean or a literature audit.')))
