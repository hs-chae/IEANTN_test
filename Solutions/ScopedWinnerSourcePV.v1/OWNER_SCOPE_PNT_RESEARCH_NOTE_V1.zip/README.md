# Conditional PNT research note

Open OWNER_SCOPE_PNT_MECHANISM_V1.html. All math renders offline.
The reviewed mathematical construction proves Epi <= 0.008441646*x^(-1/8)
for x >= exp330 under exactly the original eight bundled and six separate
analytic premises. It also proves the stated prime-rich interval count.
No optimality, best-known or causal-exposure claim is made.

## Reproduce the exposition

Run python render_owner_scope_pnt_mechanism_v1.py from this directory.
Its logical source paths are resolved inside this component and checked
against pinned hashes. Actual clean-directory regeneration passed in normal,
-O and -OO modes (OWNER_SCOPE_PAPER_REGENERATION_V1.json).

## Reproduce the complete mathematical result

Extract HEIGHT_KERNEL_VALIDITY_REPRODUCIBILITY_V1.tar.gz and follow its README
and pinned public bootstrap. It includes all463 application sources, exact C
numerical regeneration, kernel checks and all nine final proof audits. The
actual fresh source replay passed; it was host source-cold, not namespace
isolation. Dependencies, commands, hashes and measured resources are included.
The two older source checkpoint ZIPs linked by the exposition retain their
original pending status and are not overwritten by later successes.

## Source-first program verification boundary

Actual source binding covers39 functions,14 globals and524 physical files.
The actual58-constant initializer has an accepted source-execution proof;
its measured96GiB receipt and proof sources are included. This note does not
provide a new clean replay of that initializer; the dedicated source component
is separately tracked. The eight new conditional source-output consumer APIs
are compiled and audited, but their all768 source-execution provider remains
open. Original main input/frame/output handling and the full numerical source
chain must also close before application source-first PV can be claimed.
The finite source-provider arguments are explicit outstanding proof obligations,
not added analytic hypotheses, axioms or accepted unverified numerical facts.

## Reviews and artifacts

The V3 reader review covers the mathematical exposition; V4 fidelity review
checks the byte-identical math plus the limited accepted-initializer status
delta. The exact V3 snapshot is preserved. Browser receipts and actual phone/
desktop screenshots are included. No review claims exhaustive original-paper
auditing or application PV completion. MANIFEST.json pins every payload.
