from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3]
d=json.loads(Path(__file__).with_name('REVIEW.json').read_text())
for name,h in d['source_hashes'].items():
 p=R/name
 if not p.is_file()or hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise RuntimeError('reviewed source changed '+name)
print(json.dumps(dict(status='PASS_REVIEW_SOURCE_IDENTITIES',files=len(d['source_hashes']),qualification='Identity check only; finite source checks and full PV remain open.')))
