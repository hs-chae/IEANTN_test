"""Freeze the exact accepted57-body inventory; never retroactively enlarge fresh52."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re

B = Path(__file__).resolve().parent
R = B.parents[1]
STD3 = {'propext', 'Classical.choice', 'Quot.sound'}

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    def pairs(rows):
        result = {}
        for key, value in rows:
            need(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(path.read_text(), object_pairs_hook=pairs, parse_constant=invalid)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    need(not out.exists(), 'fresh inventory output required')
    old_path = B / 'CURRENT_CONTROLS_BODY_AND_MATH_INDEX_V10.json'
    numeric_path = R / 'scoped/frontend/proof/SOURCE_HELPER_SUPPORT_INDEX_V42.json'
    named_path = R / 'scoped/frontend/proof/NAMED_CONSTRUCTOR_PROGRESS_RESUME_V4.json'
    fresh_path = R / 'scoped/build/current52-source-cold-resume-v2/verification/RECEIPT.json'
    old, numeric, named, fresh = [load(p) for p in [old_path, numeric_path, named_path, fresh_path]]
    need(len(old['controls_functions']) == 26 and len(numeric['concrete_functions']) == 30
         and named['whole_named_body_complete'] is True, 'fixed26+30+1 source function groups')
    need(fresh['source_modules'] == 644 and fresh['theorem_roots'] == 767
         and fresh['application_object_inputs'] == [], 'historical fresh52 exact population')
    fresh_audits = {row['name']: row for row in fresh['audits']}
    controls = dict(old['controls_functions'])
    for name, row in controls.items():
        need(row['theorem'] in fresh_audits and set(fresh_audits[row['theorem']]['axioms']) <= STD3,
             'historical controls full closure: ' + name)
    current_audits = {}
    modules = {}
    for row in numeric['files'] + named['modules']:
        source, receipt = R / row['source'], R / row['receipt']
        need(source.is_file() and not source.is_symlink() and sha(source) == row['source_sha256']
             and sha(receipt) == row['receipt_sha256'], 'accepted source/receipt identity: ' + row['module'])
        d = load(receipt)
        need(d['status'] == 'PASS_HOST_DEVELOPMENT_COMPILE' and d['exit_code'] == 0
             and d['source_unchanged'] is True and d['source_sha256'] == row['source_sha256'],
             'actual accepted module: ' + row['module'])
        need(bool(d['audit']) and all(set(a['axioms']) <= STD3 for a in d['audit']),
             'all exact selected standard closures: ' + row['module'])
        for audit in d['audit']:
            current_audits[audit['name']] = dict(name=audit['name'], axioms=audit['axioms'],
                module=row['module'], source=row['source'], source_sha256=row['source_sha256'])
        if row['module'] in modules:
            need(modules[row['module']]['source_sha256'] == row['source_sha256'], 'unique source identity')
        modules[row['module']] = dict(module=row['module'], source=row['source'],
            source_sha256=row['source_sha256'], receipt=row['receipt'], receipt_sha256=row['receipt_sha256'])
    for name, row in numeric['concrete_functions'].items():
        need(row['theorem'] in current_audits, 'numerical body root actually audited: ' + name)
        if 'source_execution_root' in row:
            need(row['source_execution_root'] in current_audits, 'actual source execution root: ' + name)
    named_root = 'ScopedC.NamedBody.named_closed'
    named_math = 'ScopedC.NamedBody.named_closed_math'
    need(named_root in current_audits and named_math in current_audits, 'whole named source/model/math closures')
    need('named' not in controls and 'named' not in numeric['concrete_functions'], 'one newly counted function')
    controls['named'] = dict(theorem=named_root, mathematical_theorem=named_math, rank=9,
        source='scoped/frontend/lean/ScopedC/NamedBody.lean',
        mathematical_output='Actual both branches/everyuint32input; exact original LeanCert MathConst interval rounded to-100, actual real constant containment; valid physical pool/scale/range/capacity and syntactic source-library installation remain explicit.')
    union = dict(controls)
    for name, row in numeric['concrete_functions'].items():
        need(name not in union, 'disjoint controls/numerics: ' + name)
        union[name] = row
    generated = (R / 'scoped/frontend/lean/ScopedC/Generated.lean').read_text()
    match = re.search(r'^def functions : List Function := \[(.*?)\]', generated, re.M)
    need(match is not None, 'actual source function population')
    actual = re.findall(r'\bf_([A-Za-z0-9_]+)\b', match.group(1))
    need(len(actual) == len(set(actual)) == 68 and len(union) == 57 and set(union) <= set(actual),
         'exact57 unique functions from actual68-body source')
    result = dict(status='ACCEPTED57_ACTUAL_SOURCE_BODY_COMPONENTS_NOT_FULL_EXPERIMENT_PV',
        actual_old_C_function_population=68, controls_actual_whole_bodies=27,
        numerics_actual_whole_bodies=30, aggregate_actual_whole_bodies=57,
        controls_functions=controls, aggregate_functions=union,
        remaining_functions=[name for name in actual if name not in union],
        accepted_current_module_sources=list(modules.values()),
        selected_current_standard_roots=list(current_audits.values()),
        controls_prior_index=dict(path=str(old_path.relative_to(R)), sha256=sha(old_path)),
        numerics_index=dict(path=str(numeric_path.relative_to(R)), sha256=sha(numeric_path)),
        named_index=dict(path=str(named_path.relative_to(R)), sha256=sha(named_path)),
        historical_fresh52=dict(receipt=str(fresh_path.relative_to(R)), sha256=sha(fresh_path),
            source_modules=644, distinct_roots=767, function_count=52),
        fresh57_replay_completed=False, namespace_isolated=False,
        source_algorithms_changed=False, new_analytic_assumptions=[],
        qualification='Exact disjoint inventory of accepted actual-body components. Historical52source-cold result remains fixed52; the later57body union has not received its own complete fresh application-source replay. This does not close the full original68-function program, final49numerical-fact/8192-versus16384consumer or whole experiment. Per-component physical initialization/input/borrow/scale/pool/capacity preconditions and pinned generic compiler/runtime/OS/ABI/hardware contracts remain explicit.')
    out.parent.mkdir(parents=True, exist_ok=True)
    temp = out.with_suffix('.pending')
    temp.write_text(json.dumps(result, indent=2) + '\n')
    os.replace(temp, out)
    print(json.dumps(dict(controls=27, numerics=30, total=57, remaining=result['remaining_functions'],
        sources=len(modules), current_audited_roots=len(current_audits), output_sha256=sha(out))))

if __name__ == '__main__':
    main()
