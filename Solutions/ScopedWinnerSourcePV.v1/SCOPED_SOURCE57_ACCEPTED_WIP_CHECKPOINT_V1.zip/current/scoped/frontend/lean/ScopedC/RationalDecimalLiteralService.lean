/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalDecimalLiteralEffects
import ScopedC.CallEventService
import ScopedC.SourceRanks
namespace ScopedC.RationalDecimalLiteral
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Finite actual-source execution witnesses for the four original calls.
The service is proof metadata, not an executable numerical-output provider. -/
theorem source_expression {code : List Function} {l : PoolLayout} {c : Cursor}
    {n d : Nat} (D : Stages code l c n d) :
    ∃service : Call,
      (∀name args before result final, service name args before=some (result,final) →
        SourceCall Header.layout code 5 name args before result final) ∧
      evalExpr Header.layout service 1000 c.state (initializer n d)=
        some (D.output.source,(after D).state) := by
  let e0 : CallEvents.Event Header.layout code 5 :=
    ⟨"decimal",[.pointer ⟨c.state.heap.length,0,[]⟩ false],(textCursor c n).state,
      .natObject D.numeratorSlot,D.numerator.state,
      SourceRanks.monotone (by omega : 3≤5) D.numeratorCall⟩
  let e1 : CallEvents.Event Header.layout code 5 :=
    ⟨"smake",[.natObject D.numeratorSlot,DecimalDigits.integer 0],D.numerator.state,
      (endpoint D.numeratorSlot n).source,(next l D.numerator 0).state,
      SourceRanks.monotone (by omega : 4≤5) D.signedCall⟩
  let e2 : CallEvents.Event Header.layout code 5 :=
    ⟨"decimal",[.pointer ⟨(next l D.numerator 0).state.heap.length,0,[]⟩ false],
      (textCursor (next l D.numerator 0) d).state,
      .natObject D.denominatorSlot,D.denominator.state,
      SourceRanks.monotone (by omega : 3≤5) D.denominatorCall⟩
  let e3 : CallEvents.Event Header.layout code 5 :=
    ⟨"qm",[(endpoint D.numeratorSlot n).source,.natObject D.denominatorSlot],
      D.denominator.state,D.output.source,(after D).state,D.rationalCall⟩
  let events := [e0,e1,e2,e3]
  have size : D.numerator.state.nats.values.length=
      c.state.nats.values.length+(0::DecimalExpressions.allocationSteps 0 (DecimalText.digits n)).length := by
    rw [D.numeratorTrace,CursorEffects.size]
    rfl
  have distinct : (textCursor c n).state.nats.values.length ≠
      (textCursor (next l D.numerator 0) d).state.nats.values.length := by
    change c.state.nats.values.length ≠ (next l D.numerator 0).state.nats.values.length
    rw [PoolCursor.size,size]
    simp only [List.length_cons]
    omega
  have unique : (events.map CallEvents.key).Nodup := by
    simp [events,CallEvents.key,e0,e1,e2,e3,distinct]
  obtain ⟨service,answers,closed⟩ := CallEvents.list_service events unique
  exact ⟨service,closed,expression service D
    (answers e0 (by simp [events])) (answers e1 (by simp [events]))
    (answers e2 (by simp [events])) (answers e3 (by simp [events]))⟩

end ScopedC.RationalDecimalLiteral
