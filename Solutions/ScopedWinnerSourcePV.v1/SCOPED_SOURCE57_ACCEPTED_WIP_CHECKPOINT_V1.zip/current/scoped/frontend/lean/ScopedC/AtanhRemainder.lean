/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhErrorExpression
import ScopedC.RationalSymmetricLocal

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

noncomputable def remainderPair {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) : Pair :=
  RationalSymmetricLocal.output (errorInput stage positive)

noncomputable def afterRemainder {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) : Cursor :=
  CursorLocals.allocated (next l (storedError stage positive) 0) "RI" "remainder"
    (remainderPair stage positive).source

def remainderExpression : Expr := .record [.call (.var "qn") [.var "error"],.var "error"]

theorem stored_error_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (room : c.top+750<PoolCalls.capacity) : Valid l (storedError stage positive) :=
  CursorLocals.allocated_valid (error_valid stage positive room) "Q" "error" _

theorem remainder_call (code : List Function) (qn : Generated.f_qn∈code)
    (sn : Generated.f_sn∈code) (lib : ErrorLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} {d : Nat}
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (room : c.top+750<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qn" [(errorInput stage positive).source]
      (storedError stage positive).state (remainderPair stage positive).lo.source
      (next l (storedError stage positive) 0).state := by
  have top:=stage.top
  rw[guard_top] at top
  have errorTop:=error_top stage positive narrow
  exact RationalSymmetricLocal.source_call code qn sn lib.narrow.guard.absolute.smake
    lib.narrow.guard.absolute.nz lib.narrow.guard.absolute.nu lib.narrow.guard.absolute.ne
    lib.narrow.guard.absolute.keep (stored_error_valid stage positive room)
    (by change (errorCursor stage positive).top<PoolCalls.capacity;omega)
    (errorInput stage positive) (error_live stage positive) (error_den_positive stage positive)

theorem remainder_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} {d : Nat}
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (room : c.top+750<PoolCalls.capacity)
    (answer : service "qn" [(errorInput stage positive).source] (storedError stage positive).state=
      some ((remainderPair stage positive).lo.source,(next l (storedError stage positive) 0).state)) :
    Declare Header.layout service [{type:="RI",name:="remainder",value:=some remainderExpression,arrayExtent:=none}]
      (storedError stage positive).state (afterRemainder stage positive).state := by
  have before:=error_binding stage positive
  have safe:=LocalStorageSeparation.pool (stored_error_valid stage positive room) before
    (by decide +kernel : ("Q":String)≠"unsigned")
  have afterBinding : LocalBinding.At (next l (storedError stage positive) 0).state
      "error" "Q" (errorInput stage positive).source (errorCursor stage positive).state.heap.length :=
    LocalBinding.advance before [0] safe.1 safe.2.1 safe.2.2
  have left:=ExpressionTemplates.call_one Header.layout service
    (LocalBinding.eval service 998 before (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)) answer
  have right:=LocalBinding.eval service 998 afterBinding (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have expression : evalExpr Header.layout service 1000 (storedError stage positive).state
      remainderExpression=some (.aggregate [(remainderPair stage positive).lo.source,
        (remainderPair stage positive).hi.source],(next l (storedError stage positive) 0).state) :=
    ExpressionTemplates.record_two Header.layout service left right
  have live:=RationalSymmetricLocal.live (l:=l) (c:=storedError stage positive) (error_live stage positive)
  have low : castValue Header.layout (next l (storedError stage positive) 0).state 99 "Q"
      (remainderPair stage positive).lo.source=some (remainderPair stage positive).lo.source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) live.1.1 live.1.2 (SignedNegCalls.bit_bound _)
  have high : castValue Header.layout (next l (storedError stage positive) 0).state 99 "Q"
      (remainderPair stage positive).hi.source=some (remainderPair stage positive).hi.source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) live.2.1 live.2.2 (SignedNegCalls.bit_bound _)
  have cast:=IntervalCasts.aggregate _ 96 _ _ low high
  simp only[Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem remainder_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) :
    (remainderPair stage positive).Live (afterRemainder stage positive).state :=
  RationalSymmetricLocal.live (l:=l) (c:=storedError stage positive) (error_live stage positive)

theorem remainder_positive {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) :
    (remainderPair stage positive).Positive :=
  ⟨error_den_positive stage positive,error_den_positive stage positive⟩

theorem remainder_order {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (remainderPair stage positive).lo.mathematical.value≤
      (remainderPair stage positive).hi.mathematical.value := by
  change (RationalSubCalls.negative (errorInput stage positive)).mathematical.value≤
    (errorInput stage positive).mathematical.value
  rw[RationalSubCalls.negative_value]
  have nonnegative:=error_nonnegative stage positive narrow
  linarith

end ScopedC.AtanhCalls
