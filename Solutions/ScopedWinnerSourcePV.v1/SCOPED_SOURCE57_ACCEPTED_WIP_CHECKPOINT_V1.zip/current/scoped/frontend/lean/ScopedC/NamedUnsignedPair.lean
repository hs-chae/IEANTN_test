/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedRecordLifecycle
namespace ScopedC.NamedUnsignedPair
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalRecordFields ScopedC.NamedRecordLifecycle
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor)
    (lowNumerator highNumerator denominator slot : Nat) (oldHi : Value) where
  low : RationalUnsignedRatio.Stages code l c lowNumerator denominator
  high : RationalUnsignedRatio.Stages code l
    (stored (RationalUnsignedRatio.after l c lowNumerator denominator) slot low.output.source oldHi)
    highNumerator denominator

def middle {code : List Function} {l : PoolLayout} {c : Cursor} {nl nh den slot : Nat}
    {oldHi : Value} (D : Stages code l c nl nh den slot oldHi) : Cursor :=
  stored (RationalUnsignedRatio.after l c nl den) slot D.low.output.source oldHi

def finish {code : List Function} {l : PoolLayout} {c : Cursor} {nl nh den slot : Nat}
    {oldHi : Value} (D : Stages code l c nl nh den slot oldHi) : Cursor :=
  stored (RationalUnsignedRatio.after l (middle D) nh den) slot D.low.output.source D.high.output.source

def input {code : List Function} {l : PoolLayout} {c : Cursor} {nl nh den slot : Nat}
    {oldHi : Value} (D : Stages code l c nl nh den slot oldHi) : FromRIFrames.InputRI :=
  ⟨D.low.output,D.high.output⟩

theorem stages_exist (code : List Function) (qv : Generated.f_qv∈code)
    (lib : RationalDivideCalls.Library code) {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    {oldLo oldHi : Value} {slot : Nat} (record : At c.state oldLo oldHi slot)
    (nl nh den : Nat) (nlo : nl<2^32) (nhi : nh<2^32) (db : den<2^32)
    (room : c.top+90<capacity) : Nonempty (Stages code l c nl nh den slot oldHi) := by
  have lowRoom : c.top+18<capacity := by omega
  obtain ⟨lo⟩ := RationalUnsignedRatio.stages_exist code qv lib ctx nl den nlo db lowRoom
  have lowAt := RationalUnsignedRatio.record ctx nl den lowRoom record
  have midValid : Valid l (stored (RationalUnsignedRatio.after l c nl den) slot lo.output.source oldHi) :=
    RationalRecordFields.valid lo.valid lowAt _ _
  have lowTop := RationalUnsignedRatio.top_bound ctx nl den lowRoom
  have highRoom : (stored (RationalUnsignedRatio.after l c nl den) slot lo.output.source oldHi).top+18<capacity := by
    change (RationalUnsignedRatio.after l c nl den).top+18<capacity
    omega
  obtain ⟨hi⟩ := RationalUnsignedRatio.stages_exist code qv lib midValid nh den nhi db highRoom
  exact ⟨⟨lo,hi⟩⟩

theorem middle_valid {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot) (room : c.top+18<capacity) :
    Valid l (middle D) ∧ At (middle D).state D.low.output.source oldHi slot := by
  have atLow := RationalUnsignedRatio.record ctx nl den room record
  exact ⟨RationalRecordFields.valid D.low.valid atLow _ _,binding atLow _ _⟩

theorem stored_result {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot)
    (lowRoom : c.top+18<capacity) (highRoom : (middle D).top+18<capacity) :
    Valid l (finish D) ∧ At (finish D).state D.low.output.source D.high.output.source slot ∧
      (input D).Live (finish D).state := by
  have mid := middle_valid D ctx record lowRoom
  have highAt := RationalUnsignedRatio.record mid.1 nh den highRoom mid.2
  have lowLive : D.low.output.Live (RationalUnsignedRatio.after l (middle D) nh den).state :=
    ⟨RationalUnsignedRatio.preserves_nat mid.1 nh den highRoom D.low.live.1,
     RationalUnsignedRatio.preserves_nat mid.1 nh den highRoom D.low.live.2⟩
  exact ⟨RationalRecordFields.valid D.high.valid highAt _ _,binding highAt _ _,lowLive,D.high.live⟩

theorem top_bound {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot) (room : c.top+90<capacity) :
    (finish D).top≤c.top+38 := by
  have lowRoom : c.top+18<capacity := by omega
  have lo := RationalUnsignedRatio.top_bound ctx nl den lowRoom
  have mid := middle_valid D ctx record lowRoom
  have highRoom : (middle D).top+18<capacity := by
    change (RationalUnsignedRatio.after l c nl den).top+18<capacity
    omega
  have hi := RationalUnsignedRatio.top_bound mid.1 nh den highRoom
  change (RationalUnsignedRatio.after l (middle D) nh den).top≤c.top+38
  change (RationalUnsignedRatio.after l (middle D) nh den).top≤
    (RationalUnsignedRatio.after l c nl den).top+19 at hi
  omega

theorem scale {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot object valueSlot number : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot)
    (lowRoom : c.top+18<capacity) (highRoom : (middle D).top+18<capacity)
    (h : SourceFromS.ScaleAt c.state object valueSlot number) :
    SourceFromS.ScaleAt (finish D).state object valueSlot number := by
  have lowAt := RationalUnsignedRatio.record ctx nl den lowRoom record
  have lowScale := RationalUnsignedRatio.scale ctx nl den lowRoom h
  have mid := middle_valid D ctx record lowRoom
  have midScale : SourceFromS.ScaleAt (middle D).state object valueSlot number :=
    RationalRecordFields.scale_store lowAt lowScale _ _
  have highAt := RationalUnsignedRatio.record mid.1 nh den highRoom mid.2
  exact RationalRecordFields.scale_store highAt
    (RationalUnsignedRatio.scale mid.1 nh den highRoom midScale) _ _

#print axioms stages_exist
#print axioms middle_valid
#print axioms stored_result
#print axioms top_bound
#print axioms scale
end ScopedC.NamedUnsignedPair
