/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerIterationData
import ScopedC.RationalPowerCondition

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def accumulatorStatement : Stmt := .eval (.binary "=" (.var "result") (.call (.var "qt") [.var "result",.var "a"]))
def halfStatement : Stmt := .eval (.binary "=" (.var "n") (.binary "/" (.var "n") (.nat 2)))
def squareStatement : Stmt := .eval (.binary "=" (.var "a") (.call (.var "qt") [.var "a",.var "a"]))
def oddStatement : Stmt := .branch oddCondition accumulatorStatement .skip
def remainingStatement : Stmt := .branch condition squareStatement .skip
def loopBody : Stmt := .sequence [oddStatement,halfStatement,remainingStatement]

def AccumulatorAnswer (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l) : Prop :=
  f.exponent%2=1 → service "qt" [f.accumulator.source,f.current.source] f.cursor.state=
    some ((accProduct f).source,(RationalMultiplyCalls.c11 l f.cursor f.accumulator f.current).state)
def SquareAnswer (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+21<PoolCalls.capacity) : Prop :=
  0<(halved f room).exponent → service "qt" [(halved f room).current.source,(halved f room).current.source]
    (halved f room).cursor.state=
    some ((squareProduct (halved f room)).source,
      (RationalMultiplyCalls.c11 l (halved f room).cursor (halved f room).current (halved f room).current).state)

theorem odd_run (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+21<PoolCalls.capacity) (answer : AccumulatorAnswer service f) :
    Run Header.layout service oddStatement f.cursor.state (.continuing (afterOdd f room).cursor.state) := by
  by_cases odd : f.exponent%2=1
  · rw[afterOdd,if_pos odd]
    apply Loops.StmtRun.branch (odd_eval service f)
    simp only[UnsignedLiteralControl.truth_boolean,odd,decide_true,↓reduceIte]
    exact Loops.StmtRun.evaluate (accumulate_source service f (by omega) (answer odd))
  · rw[afterOdd,if_neg odd]
    apply Loops.StmtRun.branch (odd_eval service f)
    simp only[UnsignedLiteralControl.truth_boolean,odd,decide_false,Bool.false_eq_true,↓reduceIte]
    exact Loops.StmtRun.skip _

theorem remaining_run (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+21<PoolCalls.capacity) (answer : SquareAnswer service f room) :
    Run Header.layout service remainingStatement (halved f room).cursor.state
      (.continuing (iteration f room).cursor.state) := by
  by_cases remaining : 0<(halved f room).exponent
  · rw[iteration,if_pos remaining]
    apply Loops.StmtRun.branch (condition_eval service (halved f room))
    simp only[UnsignedLiteralControl.truth_boolean,remaining,decide_true,↓reduceIte]
    exact Loops.StmtRun.evaluate (square_source service (halved f room)
      (by have h:=halved_top_le f room;omega) (answer remaining))
  · rw[iteration,if_neg remaining]
    apply Loops.StmtRun.branch (condition_eval service (halved f room))
    simp only[UnsignedLiteralControl.truth_boolean,remaining,decide_false,Bool.false_eq_true,↓reduceIte]
    exact Loops.StmtRun.skip _

theorem iteration_shape {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (iteration f room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (iteration f room).cursor.state.env=f.cursor.state.env := by
  have oddShape : (afterOdd f room).cursor.state.heap.length=f.cursor.state.heap.length ∧
      (afterOdd f room).cursor.state.env=f.cursor.state.env := by
    unfold afterOdd
    split
    · exact accumulate_shape _ _
    · exact ⟨rfl,rfl⟩
  have halfShape:=half_shape (afterOdd f room)
  have together : (halved f room).cursor.state.heap.length=f.cursor.state.heap.length ∧
      (halved f room).cursor.state.env=f.cursor.state.env :=
    ⟨halfShape.1.trans oddShape.1,halfShape.2.1.trans oddShape.2⟩
  unfold iteration
  split
  · have squareShape:=square_shape (halved f room) (by have h:=halved_top_le f room;omega)
    exact ⟨squareShape.1.trans together.1,squareShape.2.trans together.2⟩
  · exact together

/-- Complete actual source while-body execution. The two conditional call
answers are later supplied only by actual lower-rank qt execution events. -/
theorem iteration_run (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+21<PoolCalls.capacity)
    (acc : AccumulatorAnswer service f) (sqr : SquareAnswer service f room) :
    Run Header.layout service loopBody f.cursor.state (.continuing (iteration f room).cursor.state) := by
  apply Loops.StmtRun.sequence
    (Loops.SeqRun.next (odd_run service f room acc)
      (Loops.SeqRun.next (Loops.StmtRun.evaluate (half_source service (afterOdd f room)))
        (Loops.SeqRun.next (remaining_run service f room sqr) (Loops.SeqRun.nil _))))
  have shape:=iteration_shape f room
  exact (PoolCalls.pop_same shape.1 shape.2).symm

end ScopedC.RationalPowerCalls
