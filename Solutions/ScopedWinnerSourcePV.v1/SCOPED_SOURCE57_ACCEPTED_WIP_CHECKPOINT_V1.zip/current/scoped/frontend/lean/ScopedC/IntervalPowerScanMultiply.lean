/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerScanFrame

namespace ScopedC.IntervalPowerScan
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem multiplied_call (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (fromA : Bool) (room : f.cursor.top+79<PoolCalls.capacity) :
    SourceCall Header.layout code 8 "rmul" [(left f fromA).source,f.result.source] f.cursor.state
      (product f fromA).source (IntervalProductApplicability.next l f.cursor (left f fromA) f.result).state := by
  unfold IntervalProductApplicability.next
  exact RationalIntervalMultiplyCalls.rmul_closed code installed lib f.context room (left f fromA) f.result
    (left_live f fromA) f.rLive (left_positive f fromA) f.rPositive

def multiplyExpression (fromA : Bool) : ScopedC.Syntax.Expr :=
  .binary "=" (.var "result") (.call (.var "rmul") [.var (leftName fromA),.var "result"])

theorem multiplied_source (service : Call) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (fromA : Bool) (room : f.cursor.top+79<PoolCalls.capacity)
    (answer : service "rmul" [(left f fromA).source,f.result.source] f.cursor.state=
      some ((product f fromA).source,(IntervalProductApplicability.next l f.cursor (left f fromA) f.result).state)) :
    Eval Header.layout service (multiplyExpression fromA) f.cursor.state
      (multiplied f fromA room).cursor.state (product f fromA).source := by
  have rhs:=ExpressionTemplates.call_two Header.layout service
    (LocalBinding.eval service 1 (left_binding f fromA)
      (by cases fromA <;> decide +kernel) (by cases fromA <;> decide +kernel)
      (by cases fromA <;> decide +kernel) (by cases fromA <;> decide +kernel))
    (LocalBinding.eval service 1 f.rAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) answer
  have safe:=LocalStorageSeparation.pool f.context f.rAt (by decide +kernel : ("RI":String)≠"unsigned")
  have middle:=IntervalProductApplicability.binding (left f fromA) f.result f.rAt safe.1 safe.2.1 safe.2.2
  refine ⟨4,?_⟩
  exact LocalAssignment.evaluate service 2 rhs middle
    (Pair.cast (IntervalProductApplicability.live l f.cursor (left f fromA) f.result) "RI" (by decide +kernel))

theorem multiplied_shape {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (fromA : Bool) (room : f.cursor.top+79<PoolCalls.capacity) :
    (multiplied f fromA room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (multiplied f fromA room).cursor.state.env=f.cursor.state.env := by
  change ((IntervalProductApplicability.next l f.cursor (left f fromA) f.result).state.heap.set f.rSlot _).length=_ ∧ _
  rw[List.length_set]
  exact IntervalProductApplicability.shape l f.cursor (left f fromA) f.result

theorem multiplied_top {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (fromA : Bool) (room : f.cursor.top+79<PoolCalls.capacity) :
    (multiplied f fromA room).cursor.top=f.cursor.top+80 := IntervalProductApplicability.top l f.cursor (left f fromA) f.result

def mathematical {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) : IntervalRat :=
  ⟨f.result.lo.mathematical.value,f.result.hi.mathematical.value,f.rOrder⟩
def original {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) : IntervalRat :=
  ⟨f.a.lo.mathematical.value,f.a.hi.mathematical.value,f.aOrder⟩

theorem multiplied_math {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (fromA : Bool) (room : f.cursor.top+79<PoolCalls.capacity) :
    mathematical (multiplied f fromA room)=IntervalRat.mul (if fromA then original f else mathematical f) (mathematical f) := by
  have lo:=NumericRationalIntervalMultiplyRefinement.low_value l f.cursor (left f fromA) f.result (left_positive f fromA) f.rPositive
  have hi:=NumericRationalIntervalMultiplyRefinement.high_value l f.cursor (left f fromA) f.result (left_positive f fromA) f.rPositive
  cases fromA <;> simp only[left,Bool.false_eq_true,↓reduceIte] at lo hi
  all_goals
    simp only[mathematical,original,multiplied,product,IntervalProductApplicability.output,
      RationalIntervalMultiplyCalls.outputPair,IntervalRat.mul,IntervalRat.min4,IntervalRat.max4,
      IntervalRat.mk.injEq,Bool.false_eq_true,↓reduceIte]
    exact ⟨lo,hi⟩

end ScopedC.IntervalPowerScan
