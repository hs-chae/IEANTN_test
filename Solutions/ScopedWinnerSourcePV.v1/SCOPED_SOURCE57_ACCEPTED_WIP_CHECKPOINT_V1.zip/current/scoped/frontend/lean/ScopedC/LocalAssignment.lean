/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.LocalBinding

namespace ScopedC.LocalAssignment
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- The exact one-cell heap update made by a typed scalar/record local store. -/
def changed (s : State) (slot : Nat) (type : String) (value : Value) : State :=
  PoolCalls.storeObject s slot {type:=type,cells:=[some value]}
def cursor (c : Cursor) (slot : Nat) (type : String) (value : Value) : Cursor :=
  {c with state:=changed c.state slot type value}

theorem write_local {s : State} {name type : String} {old value : Value} {slot : Nat}
    (h : LocalBinding.At s name type old slot)
    (convert : castValue Header.layout s 100 type value=some value) :
    write Header.layout s ⟨slot,0,[]⟩ true value=some (value,changed s slot type value) := by
  simp [write,addressType,typeAt,h.memory,convert,changed,PoolCalls.storeObject]

theorem lvalue (service : Call) (fuel : Nat) {s : State} {name type : String} {old : Value} {slot : Nat}
    (h : LocalBinding.At s name type old slot) :
    evalLValue Header.layout service (fuel+1) s (.var name)=some (⟨slot,0,[]⟩,true,s) := by
  simp [evalLValue,getVar,h.lookup,h.memory]

theorem binding {s : State} {name type : String} {old value : Value} {slot : Nat}
    (h : LocalBinding.At s name type old slot) (init : initialized 1000 value=true) :
    LocalBinding.At (changed s slot type value) name type value slot := by
  have bound:=(List.getElem?_eq_some_iff.mp h.memory).choose
  constructor
  · exact h.lookup
  · simp [changed,PoolCalls.storeObject,bound]
  · exact init

theorem other_binding {s : State} {name type changedType : String} {old value : Value} {slot target : Nat}
    (h : LocalBinding.At s name type old slot) (different : slot≠target) :
    LocalBinding.At (changed s target changedType value) name type old slot := by
  apply LocalBinding.memory (t:=changed s target changedType value) h rfl
  simp [changed,PoolCalls.storeObject,different,Ne.symm different]

theorem valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (slot : Nat) (type : String) (value : Value)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    Valid l (cursor c slot type value) := by
  constructor
  · exact ctx.global_pool
  · exact ctx.global_top
  · exact ctx.global_high
  · simpa [cursor,changed,PoolCalls.storeObject,hp,Ne.symm hp] using ctx.pool_read
  · simpa [cursor,changed,PoolCalls.storeObject,ht,Ne.symm ht] using ctx.top_read
  · simpa [cursor,changed,PoolCalls.storeObject,hh,Ne.symm hh] using ctx.high_read
  · exact ctx.extent
  · exact ctx.high_range
  · exact ctx.top_range

/-- RHS first, actual local lvalue next, checked conversion and store last,
matching the source expression rule rather than an independent loop model. -/
theorem evaluate (service : Call) (fuel : Nat) {s middle : State} {rhs : Expr}
    {name type : String} {old value : Value} {slot : Nat}
    (right : evalExpr Header.layout service (fuel+1) s rhs=some (value,middle))
    (atMiddle : LocalBinding.At middle name type old slot)
    (convert : castValue Header.layout middle 100 type value=some value) :
    evalExpr Header.layout service (fuel+2) s (.binary "=" (.var name) rhs)=
      some (value,changed middle slot type value) := by
  rw[evalExpr,right]
  simp only[Bind.bind,Option.bind]
  rw[lvalue service fuel atMiddle]
  exact write_local atMiddle convert

end ScopedC.LocalAssignment
