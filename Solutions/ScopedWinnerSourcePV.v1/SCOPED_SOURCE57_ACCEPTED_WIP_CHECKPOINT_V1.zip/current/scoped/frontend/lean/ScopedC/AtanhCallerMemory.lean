/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhCallerEffects

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard sumCursor

theorem remainder_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (slot : Nat) (old : slot<stage.out.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (afterRemainder stage positive).state.heap[slot]?=stage.out.state.heap[slot]? := by
  have errorOld : slot<(errorCursor stage positive).state.heap.length := by
    rw[error_heap stage positive narrow];exact old
  have storedOld : slot<(storedError stage positive).state.heap.length := by
    change slot<((errorCursor stage positive).state.heap++[_]).length
    rw[List.length_append,List.length_singleton];omega
  change ((next l (storedError stage positive) 0).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left (by rw[(PoolCursor.shape l (storedError stage positive) 0).1];exact storedOld)]
  rw[PoolCursor.other l (storedError stage positive) 0 slot hp ht hh]
  change ((errorCursor stage positive).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left errorOld]
  exact error_other stage positive narrow slot old hp ht hh

theorem sum_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1)
    (slot : Nat) (old : slot<c.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (sumCursor t).state.heap[slot]?=c.state.heap[slot]? := by
  have stageOld : slot<stage.out.state.heap.length := by rw[stage.heap_length,guard_heap];omega
  have remOld : slot<(afterRemainder stage positive).state.heap.length := by
    rw[remainder_heap stage positive narrow];omega
  unfold sumCursor
  rw[RationalIntervalAddCalls.after_other l t.out (taylorPair t) (remainderPair stage positive) slot
    (by rw[t.heap_length];exact remOld) hp ht hh]
  rw[t.other slot remOld hp ht hh,remainder_other stage positive narrow slot stageOld hp ht hh]
  rw[stage.other slot (by rw[guard_heap];omega) hp ht hh]
  exact guard_other l c q slot old hp ht hh

noncomputable def narrowOut {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) : Cursor :=
  PoolContextPop.unframe c.state (PoolContextPop.unframe (parameters c q).state (sumCursor t))

theorem narrowOut_shape {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1) :
    (narrowOut t).state.heap.length=c.state.heap.length ∧ (narrowOut t).state.env=c.state.env := by
  constructor
  · change (((sumCursor t).state.heap.take (parameters c q).state.heap.length).take c.state.heap.length).length=_
    rw[List.length_take,List.length_take,parameters_length,sum_heap t narrow]
    omega
  · rfl

theorem narrowOut_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1) :
    (narrowOut t).state.globals=c.state.globals := sum_globals t narrow

theorem narrowOut_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1)
    {slot value : Nat} (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (narrowOut t).state.nats slot value := sum_borrow t narrow h

theorem narrowOut_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1)
    (slot : Nat) (old : slot<c.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (narrowOut t).state.heap[slot]?=c.state.heap[slot]? := by
  change (((sumCursor t).state.heap.take (parameters c q).state.heap.length).take c.state.heap.length)[slot]?=_
  rw[List.getElem?_take_of_lt old,List.getElem?_take_of_lt (by rw[parameters_length];omega)]
  exact sum_other t narrow slot old hp ht hh

end ScopedC.AtanhCalls
