/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderCallerPrefix
import ScopedC.ExpRemainderErrorEffects

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax

theorem afterThree_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) :
    (afterThree f).state.heap.length=c.state.heap.length+6 := by
  change (CursorFrames.advance l (BeforeError f) [3,0,1]).state.heap.length=_
  rw[(CursorEffects.shape l (BeforeError f) [3,0,1]).1,factorial_heap]

theorem radius_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    r.out.state.heap.length=c.state.heap.length+6 := by
  rw[r.heap_length,p.heap_length,afterThree_heap]

theorem radius_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    r.out.state.globals=c.state.globals := by
  rw[r.globals,p.globals]
  change (CursorFrames.advance l (BeforeError f) [3,0,1]).state.globals=_
  rw[CursorSingleFrames.advance_globals,factorial_globals]

theorem radius_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    {slot value : Nat} (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow r.out.state.nats slot value :=
  r.preserves _ _ (p.preserves _ _
    (CursorBorrow.preserves (l:=l) (c:=BeforeError f) [3,0,1] (factorial_borrow f h)))

theorem radius_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (slot : Nat) (old : slot<c.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    r.out.state.heap[slot]?=c.state.heap[slot]? := by
  rw[r.other slot (by rw[p.heap_length,afterThree_heap];omega) hp ht hh,
    p.other slot (by rw[afterThree_heap];omega) hp ht hh]
  change (CursorFrames.advance l (BeforeError f) [3,0,1]).state.heap[slot]?=_
  rw[CursorSingleFrames.advance_other l (BeforeError f) [3,0,1] slot hp ht hh]
  exact factorial_other f slot old hp ht hh

end ScopedC.ExpRemainderCalls
