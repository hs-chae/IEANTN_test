/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplyEffects
import ScopedC.NumericRationalIntervalMultiplyRefinement

namespace ScopedC.IntervalProductApplicability
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000

def output (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Pair :=
  RationalIntervalMultiplyCalls.outputPair l c a b

@[irreducible] def next (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  RationalIntervalMultiplyCalls.after l c a b

theorem context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (next l c a b) := by
  unfold next
  exact RationalIntervalMultiplyCalls.after_valid ctx room a b

theorem source (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (output l c a b).source=RationalIntervalMultiplyCalls.result l c a b := rfl

theorem live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : (output l c a b).Live (next l c a b).state := by
  unfold next
  exact RationalIntervalMultiplyCalls.after_live l c a b

theorem positive (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (pa : a.Positive) (pb : b.Positive) :
    (output l c a b).Positive := RationalIntervalMultiplyCalls.output_positive l c a b pa pb

theorem preserves_pair {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Pair) {p : Pair}
    (hp : p.Live c.state) : p.Live (next l c a b).state := by
  unfold next
  exact ⟨⟨RationalIntervalMultiplyCalls.preserves_nat a b hp.1.1,
    RationalIntervalMultiplyCalls.preserves_nat a b hp.1.2⟩,
    ⟨RationalIntervalMultiplyCalls.preserves_nat a b hp.2.1,
    RationalIntervalMultiplyCalls.preserves_nat a b hp.2.2⟩⟩

theorem binding {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Pair)
    {name ty : String} {v : Value} {slot : Nat} (h : LocalBinding.At c.state name ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    LocalBinding.At (next l c a b).state name ty v slot := by
  unfold next
  exact LocalBinding.memory h (RationalIntervalMultiplyCalls.after_env l c a b)
    (RationalIntervalMultiplyCalls.after_other l c a b slot (List.getElem?_eq_some_iff.mp h.memory).choose hp ht hh)

theorem shape (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (next l c a b).state.heap.length=c.state.heap.length ∧ (next l c a b).state.env=c.state.env := by
  unfold next
  exact ⟨RationalIntervalMultiplyCalls.after_heap_length l c a b,RationalIntervalMultiplyCalls.after_env l c a b⟩

theorem top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : (next l c a b).top=c.top+80 := by
  unfold next
  exact RationalIntervalMultiplyCalls.after_top l c a b

theorem order (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (pa : a.Positive) (pb : b.Positive) :
    (output l c a b).lo.mathematical.value ≤ (output l c a b).hi.mathematical.value := by
  change (RationalIntervalMultiplyCalls.lowQ l c a b).mathematical.value ≤
    (RationalIntervalMultiplyCalls.highQ l c a b).mathematical.value
  rw[NumericRationalIntervalMultiplyRefinement.low_value l c a b pa pb,
    NumericRationalIntervalMultiplyRefinement.high_value l c a b pa pb]
  exact le_trans (min_le_of_left_le (min_le_left _ _)) (le_max_of_le_left (le_max_left _ _))

end ScopedC.IntervalProductApplicability
