/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerReady

namespace ScopedC.IntervalPowerCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def startFromHigh {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (n : Nat)
    (nonzero : 0<n) (bound : n<2^32) (high : IntervalPowerBits.Certificate (initialBitFrame ctx a n nonzero bound))
    (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) : IntervalPowerScan.Frame l n :=
  scanStart high.finish a c.state.heap.length (highest_a ctx a n nonzero bound high)
    (highest_live ctx a n nonzero bound high alive) positive order

theorem entry_bit_length (c : Cursor) (a : Pair) (n : Nat) :
    (bitStart c a n).state.heap.length=c.state.heap.length+3 := by
  simp only[bitStart,CursorLocals.allocated,allocate,List.length_append,List.length_singleton,parameters_length]

theorem start_heap_length {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (n : Nat)
    (nonzero : 0<n) (bound : n<2^32) (high : IntervalPowerBits.Certificate (initialBitFrame ctx a n nonzero bound))
    (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) :
    (startFromHigh ctx a n nonzero bound high alive positive order).cursor.state.heap.length=c.state.heap.length+4 := by
  change ((high.finish.cursor.state.heap++[_]).set high.finish.bitSlot _).length=_
  rw[List.length_set,List.length_append,List.length_singleton,high.shape.1]
  change (bitStart c a n).state.heap.length+1=_
  rw[entry_bit_length]

theorem start_globals {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (n : Nat)
    (nonzero : 0<n) (bound : n<2^32) (high : IntervalPowerBits.Certificate (initialBitFrame ctx a n nonzero bound))
    (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) :
    (startFromHigh ctx a n nonzero bound high alive positive order).cursor.state.globals=c.state.globals := high.shape.2.2.1

theorem start_nats {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (n : Nat)
    (nonzero : 0<n) (bound : n<2^32) (high : IntervalPowerBits.Certificate (initialBitFrame ctx a n nonzero bound))
    (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) :
    (startFromHigh ctx a n nonzero bound high alive positive order).cursor.state.nats=c.state.nats := high.shape.2.2.2.1

theorem start_slots {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (n : Nat)
    (nonzero : 0<n) (bound : n<2^32) (high : IntervalPowerBits.Certificate (initialBitFrame ctx a n nonzero bound))
    (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) :
    (startFromHigh ctx a n nonzero bound high alive positive order).bitSlot=c.state.heap.length+2 ∧
      (startFromHigh ctx a n nonzero bound high alive positive order).rSlot=c.state.heap.length+3 := by
  constructor
  · exact high.bitSlot
  · change high.finish.cursor.state.heap.length=c.state.heap.length+3
    rw[high.shape.1]
    exact entry_bit_length c a n

/-- Entry and highest-bit processing write only fresh source stack cells. -/
theorem start_other {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (n : Nat)
    (nonzero : 0<n) (bound : n<2^32) (high : IntervalPowerBits.Certificate (initialBitFrame ctx a n nonzero bound))
    (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (slot : Nat) (old : slot < c.state.heap.length) :
    (startFromHigh ctx a n nonzero bound high alive positive order).cursor.state.heap[slot]?=c.state.heap[slot]? := by
  have bitSlot : high.finish.bitSlot=c.state.heap.length+2:=high.bitSlot
  have highLength : high.finish.cursor.state.heap.length=c.state.heap.length+3:=
    high.shape.1.trans (entry_bit_length c a n)
  change ((high.finish.cursor.state.heap++[_]).set high.finish.bitSlot _)[slot]?=_
  rw[List.getElem?_set_ne (by rw[bitSlot];omega),List.getElem?_append_left (by rw[highLength];omega)]
  rw[high.other slot (by change slot≠c.state.heap.length+2;omega)]
  simp [initialBitFrame,bitStart,parameters,CursorLocals.allocated,CursorFrames.framed,TwoFrames.frame,allocate,List.getElem?_append_left old]

end ScopedC.IntervalPowerCalls
