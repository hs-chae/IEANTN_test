/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorEventShapes

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

abbrev While (service : Call) :=
  Loops.WhileRun (Eval Header.layout service) (Declare Header.layout service) truth Scope condition loopBody

structure LoopCertificate (code : List Function) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (start : Frame l base coeffs) where
  finish : Frame l base coeffs
  events : List (Event code)
  unique : (events.map CallEvents.nameKey).Nodup
  bounds : ∀e∈events,start.cursor.state.nats.values.length ≤ e.before.nats.values.length ∧
    e.before.nats.values.length < finish.cursor.state.nats.values.length
  event_shape : ∀e∈events,e.before.heap.length=start.cursor.state.heap.length ∧ e.before.env=start.cursor.state.env
  nats_le : start.cursor.state.nats.values.length ≤ finish.cursor.state.nats.values.length
  execution : ∀service,EventAnswers service events → While service start.cursor.state (.continuing finish.cursor.state)
  stopped : finish.k=0
  original_eq : original finish=original start
  mathematical_eq : mathematical finish=LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues coeffs) (original start)
  top_le : finish.cursor.top ≤ start.cursor.top+108*start.k
  shape : finish.cursor.state.heap.length=start.cursor.state.heap.length ∧ finish.cursor.state.env=start.cursor.state.env

/-- Complete source Horner while-loop, with the existing exact rational
interval fold as its invariant and actual source executions at every call. -/
theorem loop_certificate (code : List Function) (lib : Library code) (k : Nat)
    {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input} (f : Frame l base coeffs)
    (counterEq : f.k=k)
    (invariant : mathematical f=LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop f.k)) (original f))
    (room : f.cursor.top+108*k ≤ PoolCalls.capacity) : Nonempty (LoopCertificate code f) := by
  induction k generalizing f with
  | zero =>
    refine ⟨{
      finish:=f
      events:=[]
      unique:=by simp
      bounds:=by simp
      event_shape:=by simp
      nats_le:=Nat.le_refl _
      execution:=?_
      stopped:=counterEq
      original_eq:=rfl
      mathematical_eq:=by simpa only[counterEq,List.drop_zero] using invariant
      top_le:=by omega
      shape:=⟨rfl,rfl⟩
    }⟩
    intro service _
    exact Loops.WhileRun.done (condition_eval service f)
      (by simp [UnsignedLiteralControl.truth_boolean,counterEq])
  | succ k ih =>
    have positive : 0<f.k := by omega
    have stepRoom : f.cursor.top+107<PoolCalls.capacity := by omega
    let next:=iteration f positive stepRoom
    have nextK : next.k=k := by rw[iteration_k,counterEq];omega
    have nextInvariant : mathematical next=LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop next.k)) (original next) := by
      rw[show next.k=f.k-1 from iteration_k f positive stepRoom,
        show original next=original f from iteration_original f positive stepRoom]
      exact iteration_math f positive stepRoom invariant
    have nextRoom : next.cursor.top+108*k ≤ PoolCalls.capacity := by
      change (iteration f positive stepRoom).cursor.top+108*k ≤ PoolCalls.capacity
      rw[iteration_top]
      omega
    obtain ⟨tail⟩:=ih next nextK nextInvariant nextRoom
    have nle : f.cursor.state.nats.values.length ≤ next.cursor.state.nats.values.length := by
      dsimp only[next]
      rw[iteration_size]
      omega
    let front:=iterationEvents code lib f positive stepRoom
    refine ⟨{
      finish:=tail.finish
      events:=front++tail.events
      unique:=?_
      bounds:=?_
      event_shape:=?_
      nats_le:=nle.trans tail.nats_le
      execution:=?_
      stopped:=tail.stopped
      original_eq:=tail.original_eq.trans (iteration_original f positive stepRoom)
      mathematical_eq:=?_
      top_le:=?_
      shape:=?_
    }⟩
    · rw[List.map_append,List.nodup_append]
      refine ⟨iteration_unique code lib f positive stepRoom,tail.unique,?_⟩
      intro a ha b hb same
      obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
      obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
      have keyEq:=congrArg Prod.fst (ka.trans (same.trans kb.symm))
      change ea.before.nats.values.length=eb.before.nats.values.length at keyEq
      have leftBound:=iteration_bounds code lib f positive stepRoom ea hea
      have rightBound:=tail.bounds eb heb
      dsimp only[next] at rightBound
      omega
    · intro e member
      rcases List.mem_append.mp member with frontMember | tailMember
      · have h:=iteration_bounds code lib f positive stepRoom e frontMember
        exact ⟨h.1,Nat.lt_of_lt_of_le h.2 tail.nats_le⟩
      · have h:=tail.bounds e tailMember
        exact ⟨nle.trans h.1,h.2⟩
    · intro e member
      rcases List.mem_append.mp member with frontMember | tailMember
      · exact iteration_event_shape code lib f positive stepRoom e frontMember
      · have h:=tail.event_shape e tailMember
        have shape:=iteration_shape f positive stepRoom
        exact ⟨h.1.trans shape.1,h.2.trans shape.2⟩
    · intro service answers
      exact Loops.WhileRun.next (condition_eval service f)
        (by simp [UnsignedLiteralControl.truth_boolean,positive])
        (iteration_run code lib f positive stepRoom service (fun e h=>answers e (List.mem_append_left _ h)))
        (tail.execution service (fun e h=>answers e (List.mem_append_right _ h)))
    · rw[tail.mathematical_eq,show original next=original f from iteration_original f positive stepRoom]
    · have h:=tail.top_le
      change tail.finish.cursor.top ≤ next.cursor.top+108*next.k at h
      rw[nextK,show next.cursor.top=f.cursor.top+108 from iteration_top f positive stepRoom] at h
      rw[counterEq]
      omega
    · have h:=iteration_shape f positive stepRoom
      exact ⟨tail.shape.1.trans h.1,tail.shape.2.trans h.2⟩

end ScopedC.TaylorCalls
