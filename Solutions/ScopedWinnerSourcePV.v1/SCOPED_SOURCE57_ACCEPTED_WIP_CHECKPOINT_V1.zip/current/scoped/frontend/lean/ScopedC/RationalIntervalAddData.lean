/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalFrames
import ScopedC.NumericRationalAddRefinement
import ScopedC.PoolContextPop
namespace ScopedC.RationalIntervalAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair framed frame)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def base (c : Cursor) (a b : Pair) : Cursor := framed c a b
@[irreducible] def middle (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  RationalAddCalls.c14 l (base c a b) a.lo b.lo
def finish (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  RationalAddCalls.c14 l (middle l c a b) a.hi b.hi
def after (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  PoolContextPop.unframe c.state (finish l c a b)
def low (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Value :=
  RationalAddCalls.result l (base c a b) a.lo b.lo
def high (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Value :=
  RationalAddCalls.result l (middle l c a b) a.hi b.hi
def result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Value :=
  IntervalCasts.value (low l c a b) (high l c a b)

theorem middle_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (middle l c a b).top=c.top+14 := by
  unfold middle
  exact RationalAddCalls.top14 l (base c a b) a.lo b.lo

theorem middle_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+27<PoolCalls.capacity) (a b : Pair) : Valid l (middle l c a b) := by
  unfold middle
  apply RationalAddCalls.context (c:=base c a b) (CursorFrames.framed_valid ctx "RI" "a" a.source "RI" "b" b.source)
  change c.top+13<PoolCalls.capacity
  omega

theorem finish_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+27<PoolCalls.capacity) (a b : Pair) : Valid l (finish l c a b) := by
  apply RationalAddCalls.context (middle_valid ctx room a b)
  rw[middle_top]
  omega

theorem after_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+27<PoolCalls.capacity) (a b : Pair) : Valid l (after l c a b) :=
  PoolContextPop.valid (finish_valid ctx room a b)
    ((List.getElem?_eq_some_iff.mp ctx.pool_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.top_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.high_read).choose)

theorem middle_live {l : PoolCalls.PoolLayout} {c : Cursor} {a b p : Pair} (h : p.Live c.state) :
    p.Live (middle l c a b).state := by
  unfold middle
  exact Pair.live_add (c:=base c a b) (a:=a.lo) (b:=b.lo) h

theorem middle_a_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Pair) :
    LocalBinding.At (middle l c a b).state "a" "RI" a.source c.state.heap.length := by
  unfold middle
  rw[RationalAddCalls.trace]
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.advance (c:=base c a b) (RationalIntervalFrames.a_at c.state a b) _
    (by omega) (by omega) (by omega)

theorem middle_b_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Pair) :
    LocalBinding.At (middle l c a b).state "b" "RI" b.source (c.state.heap.length+1) := by
  unfold middle
  rw[RationalAddCalls.trace]
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.advance (c:=base c a b) (RationalIntervalFrames.b_at c.state a b) _
    (by omega) (by omega) (by omega)

theorem low_input (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (pa : a.Positive) (pb : b.Positive) :
    ∃q : Input,q.source=low l c a b ∧ q.Live (middle l c a b).state ∧
      q.mathematical=ScopedNumerical.Rational.normalize (RationalAddCalls.sum l (base c a b) a.lo b.lo).mathematical
        (RationalAddCalls.denominator a.lo b.lo) ∧ 0<q.denominator := by
  unfold middle
  exact NumericInputCompleteness.rational (RationalAddCalls.result_decoded l (base c a b) a.lo b.lo pa.1 pb.1)

theorem high_input (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (pa : a.Positive) (pb : b.Positive) :
    ∃q : Input,q.source=high l c a b ∧ q.Live (finish l c a b).state ∧
      q.mathematical=ScopedNumerical.Rational.normalize (RationalAddCalls.sum l (middle l c a b) a.hi b.hi).mathematical
        (RationalAddCalls.denominator a.hi b.hi) ∧ 0<q.denominator :=
  NumericInputCompleteness.rational (RationalAddCalls.result_decoded l (middle l c a b) a.hi b.hi pa.2 pb.2)
end ScopedC.RationalIntervalAddCalls
