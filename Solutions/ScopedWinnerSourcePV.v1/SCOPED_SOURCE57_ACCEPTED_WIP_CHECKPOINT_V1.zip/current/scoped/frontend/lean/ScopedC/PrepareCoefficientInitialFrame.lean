/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientInitialTables

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def coeffInitialCursor {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) : Cursor :=
  CursorLocals.allocated (initAtanhCursor s room) "unsigned int" "k" (PoolCalls.word 1)

/-- Both first coefficients and the counter are constructed from their actual
source stores/declaration. The subsequent source while starts with k=1. -/
def coeffInitialFrame {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    CoeffFrame l object d eb ab := {
  cursor:=coeffInitialCursor s room
  expCoeffs:=[initOne s]
  atanhCoeffs:=[initZero s]
  k:=1
  kSlot:=(initAtanhCursor s room).state.heap.length
  context:=CursorLocals.allocated_valid (initAtanh_valid s room) "unsigned int" "k" _
  expAt:=CoefficientTableRead.allocated (initAtanhExpTable s room) "unsigned int" "k" _
  atanhAt:=CoefficientTableRead.allocated (initAtanhTable s room) "unsigned int" "k" _
  expLength:=rfl
  atanhLength:=rfl
  expExtent:=by rw[CoefficientTableRead.allocated_cells];exact initAtanh_exp_extent s room
  atanhExtent:=by rw[CoefficientTableRead.allocated_cells];exact initAtanh_atanh_extent s room
  expValues:=by
    have value : (initOne s).mathematical.value=1:=(RationalUnsignedTrace.mathematical l s.cursor 1).1
    simp only[TaylorCalls.coefficientValues,List.map_cons,List.map_nil,List.range_succ,List.range_zero,
      List.nil_append,List.map_cons,List.map_nil,value,exp_zero]
  atanhValues:=by
    have value : (initZero s).mathematical.value=0:=(RationalUnsignedTrace.mathematical l (initExpCursor s) 0).1
    simp only[TaylorCalls.coefficientValues,List.map_cons,List.map_nil,List.range_succ,List.range_zero,
      List.nil_append,List.map_cons,List.map_nil,value,atanh_zero]
  expLookup:=by
    change (initAtanhCursor s room).state.globals.lookup "expCoeffs"=some eb
    rw[initAtanh_globals]
    exact s.expLookup
  atanhLookup:=by
    change (initAtanhCursor s room).state.globals.lookup "atanhCoeffs"=some ab
    rw[initAtanh_globals]
    exact s.atanhLookup
  expUnshadowed:=by
    change (("k",_)::(initAtanhCursor s room).state.env).lookup "expCoeffs"=none
    rw[initAtanh_env]
    simpa only[List.lookup,String.reduceBEq] using s.expUnshadowed
  atanhUnshadowed:=by
    change (("k",_)::(initAtanhCursor s room).state.env).lookup "atanhCoeffs"=none
    rw[initAtanh_env]
    simpa only[List.lookup,String.reduceBEq] using s.atanhUnshadowed
  depthAt:=SourceUnsignedGlobal.allocated (initAtanh_depth s room) "unsigned int" "k" _
  depthUnshadowed:=by
    change (("k",_)::(initAtanhCursor s room).state.env).lookup "depth"=none
    rw[initAtanh_env]
    simpa only[List.lookup,String.reduceBEq] using s.depthUnshadowed
  kAt:=LocalBinding.allocate_head _ "k" "unsigned int" _ (by rfl)
  kPositive:=by decide +kernel
  kBound:=by omega
  depthBound:=s.depthBound
  arraysApart:=s.arraysApart
  depthApart:=s.depthApart }

end ScopedC.PrepareSource
