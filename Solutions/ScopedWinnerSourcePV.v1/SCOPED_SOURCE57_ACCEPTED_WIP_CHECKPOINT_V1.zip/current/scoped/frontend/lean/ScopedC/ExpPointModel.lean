/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointSum

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

section
variable {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
variable {stage : CeilStage code l c q} {positive : 0 < q.denominator}
variable {base : Address} {coeffs : List Input} {d : Nat}
variable {t : TaylorStage stage positive base coeffs d}

theorem input_model :
    (⟨(inputPair stage positive).lo.mathematical.value,
        (inputPair stage positive).hi.mathematical.value,input_ordered stage positive⟩ : IntervalRat) =
      IntervalRat.singleton (ExpPointReduction.reduced q.mathematical.value) := by
  rw [IntervalRat.mk.injEq]
  exact ⟨reduction_value stage positive,reduction_value stage positive⟩

theorem polynomial_values (t : TaylorStage stage positive base coeffs d) :
    t.output.lo.mathematical.value =
      (IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
        (IntervalRat.singleton (ExpPointReduction.reduced q.mathematical.value))).lo ∧
    t.output.hi.mathematical.value =
      (IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
        (IntervalRat.singleton (ExpPointReduction.reduced q.mathematical.value))).hi := by
  have values := Pair.values_of_decoded t.live t.positive t.decoded
  rw [input_model] at values
  exact values

theorem remainder_values (r : RemainderStage t) :
    r.output.lo.mathematical.value =
      (IntervalRat.expRemainderBoundComputable
        (IntervalRat.singleton (ExpPointReduction.reduced q.mathematical.value)) d).lo ∧
    r.output.hi.mathematical.value =
      (IntervalRat.expRemainderBoundComputable
        (IntervalRat.singleton (ExpPointReduction.reduced q.mathematical.value)) d).hi := by
  have values := Pair.values_of_decoded r.live r.positive r.decoded
  rw [input_model] at values
  exact values

theorem sum_model (r : RemainderStage t) :
    (⟨(sumPair r).lo.mathematical.value,(sumPair r).hi.mathematical.value,sum_ordered r⟩ : IntervalRat) =
      IntervalRat.add
        (IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
          (IntervalRat.singleton (ExpPointReduction.reduced q.mathematical.value)))
        (IntervalRat.expRemainderBoundComputable
          (IntervalRat.singleton (ExpPointReduction.reduced q.mathematical.value)) d) := by
  have sum := IntervalAddApplicability.output_spec l r.out t.output r.output
    t.positive r.positive (taylor_ordered t) r.ordered
  have polynomial := polynomial_values t
  have remainder := remainder_values r
  rw [IntervalRat.mk.injEq]
  constructor
  · change (sumPair r).lo.mathematical.value = _+_
    exact sum.2.2.2.1.trans (congrArg₂ (fun x y : Rat => x+y) polynomial.1 remainder.1)
  · change (sumPair r).hi.mathematical.value = _+_
    exact sum.2.2.2.2.trans (congrArg₂ (fun x y : Rat => x+y) polynomial.2 remainder.2)

/-- Exact old mathematical algorithm: same argument reduction, coefficient
list, remainder and final repeated power. This establishes equality of outputs,
not merely a wider enclosure with a different numerical algorithm. -/
theorem final_model {r : RemainderStage t} (p : PowerStage r) :
    NumericRepresentation.interval p.out.state p.output.source = some
      (IntervalRat.expPointComputableWithCoeffs q.mathematical.value d
        (TaylorCalls.coefficientValues coeffs)) := by
  have same : IntervalRat.pow
      ⟨(sumPair r).lo.mathematical.value,(sumPair r).hi.mathematical.value,sum_ordered r⟩
      (powerValue stage) = IntervalRat.expPointComputableWithCoeffs q.mathematical.value d
        (TaylorCalls.coefficientValues coeffs) := by
    rw [sum_model r,power_value stage positive]
    rfl
  exact p.decoded.trans (congrArg some same)

end
end ScopedC.ExpPointCalls
