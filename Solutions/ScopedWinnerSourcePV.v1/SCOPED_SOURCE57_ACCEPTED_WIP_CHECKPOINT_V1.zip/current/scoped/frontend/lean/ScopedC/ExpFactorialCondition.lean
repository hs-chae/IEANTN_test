/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpFactorialStep

namespace ScopedC.ExpFactorial
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.PoolCalls ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem binary_le (s : State) (n k : Nat) (hn : n<2^32) (hk : k<2^32) :
    binaryValue Header.layout s "<=" (unsigned32 n) (unsigned32 k)=
      some (boolean Header.layout (decide (n≤k))) := by
  simp [binaryValue,unsigned32,Scalar.binary,Scalar.common,Scalar.promote,scalar_u32_cast n hn,
    scalar_u32_cast k hk,Scalar.boolean,Scalar.truth,boolean,u32_range n hn,u32_range k hk]
    <;> split_ifs <;> (first | rfl | omega)

def condition : Expr := .binary "<=" (.var "k") (.binary "+" (.var "depth") (.nat 1))

theorem condition_eval (service : Call) {l : PoolLayout} {object d : Nat}
    (f : Frame l object d) :
    Eval Header.layout service condition f.cursor.state f.cursor.state
      (boolean Header.layout (decide (f.k≤d+1))) := by
  have db:=f.depthBound
  have kb:=f.kBound
  have depthEval:=SourceUnsignedGlobal.eval service 1 f.depthAt f.depthUnshadowed
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have limitEval:=ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    depthEval (show evalExpr Header.layout service 2 f.cursor.state (.nat 1)=
      some (DecimalDigits.integer 1,f.cursor.state) from rfl)
    (PoolCalls.binary_add_one f.cursor.state d (by omega))
  exact ⟨4,ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 2 f.kAt (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)) limitEval
    (binary_le f.cursor.state f.k (d+1) (by omega) (by omega))⟩

theorem stepped_factorial {l : PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<capacity)
    (invariant : f.fact.mathematical.value=((f.k-1).factorial:Rat)) :
    (stepped f active room).fact.mathematical.value=
      (((stepped f active room).k-1).factorial:Rat) := by
  rw[stepped_fact,invariant,stepped_k]
  have kp:=f.kPositive
  rw[show f.k+1-1=f.k by omega]
  have eqk : f.k-1+1=f.k := by omega
  have fact:=Nat.factorial_succ (f.k-1)
  rw[eqk] at fact
  rw[fact,Nat.cast_mul]
  exact mul_comm _ _

end ScopedC.ExpFactorial
