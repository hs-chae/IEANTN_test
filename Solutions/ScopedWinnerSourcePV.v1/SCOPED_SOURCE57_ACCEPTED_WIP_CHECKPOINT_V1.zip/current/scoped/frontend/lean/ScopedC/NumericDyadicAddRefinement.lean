/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicAddBody
namespace ScopedC.NumericDyadicAddRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicAddCalls
open ScopedNumerical LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem low_value (c : Cursor) (a b : InputI) :
    (low c a b).mathematical.value=a.lo.mathematical.value+b.lo.mathematical.value := by
  rw[low,sum_math,Signed.value_add]

theorem high_value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : InputI) :
    (high l c a b).mathematical.value=a.hi.mathematical.value+b.hi.mathematical.value := by
  rw[high,sum_math,Signed.value_add]

theorem words100_add (al ah bl bh : Int) (oa : al≤ah) (ob : bl≤bh) :
    words100 (al+bl) (ah+bh) (add_le_add oa ob)=
      IntervalDyadic.add (words100 al ah oa) (words100 bl bh ob) := by
  simp only [words100,IntervalDyadic.add,IntervalDyadic.mk.injEq]
  constructor <;> dsimp [LeanCert.Core.Dyadic.add] <;> simp [LeanCert.Core.Dyadic.shiftLeftInt,LeanCert.Core.Dyadic.pow2Nat]

theorem decoded_result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : InputI)
    (oa : a.lo.mathematical.value≤a.hi.mathematical.value)
    (ob : b.lo.mathematical.value≤b.hi.mathematical.value) :
    interval (after l c a b).state (result l c a b)=some
      (IntervalDyadic.add (words100 a.lo.mathematical.value a.hi.mathematical.value oa)
        (words100 b.lo.mathematical.value b.hi.mathematical.value ob),a.ok&&b.ok) := by
  have hl : (low c a b).Live (after l c a b).state :=
    PoolCursor.preserves (c:=next l (middle l c a b) (SignedAddCalls.magnitude a.hi b.hi))
      (PoolCursor.preserves (c:=middle l c a b) (sum_live l (base c a b) a.lo b.lo))
  have hh : (high l c a b).Live (after l c a b).state := sum_live l (middle l c a b) a.hi b.hi
  have ordered : (low c a b).mathematical.value≤(high l c a b).mathematical.value := by
    rw[low_value,high_value]
    exact add_le_add oa ob
  have h:=decoded_interval (s:=(after l c a b).state) (low c a b) (high l c a b) (a.ok&&b.ok) hl hh ordered
  simp only [low_value,high_value] at h
  exact h.trans (congrArg (fun q => some (q,a.ok&&b.ok))
    (words100_add a.lo.mathematical.value a.hi.mathematical.value
      b.lo.mathematical.value b.hi.mathematical.value oa ob))

/-- Exact original dyadic interval addition and original flag conjunction,
from the complete actual iadd source execution under its physical input/pool
applicability conditions. No numeric output or C call result is assumed. -/
theorem iadd_math (code : List Function) (installed : Generated.f_iadd∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+3<PoolCalls.capacity)
    (a b : InputI) (ha : a.Live c.state) (hb : b.Live c.state)
    (oa : a.lo.mathematical.value≤a.hi.mathematical.value)
    (ob : b.lo.mathematical.value≤b.hi.mathematical.value) :
    SourceCall Header.layout code 6 "iadd" [a.source,b.source] c.state (result l c a b) (after l c a b).state ∧
    interval (after l c a b).state (result l c a b)=some
      (IntervalDyadic.add (words100 a.lo.mathematical.value a.hi.mathematical.value oa)
        (words100 b.lo.mathematical.value b.hi.mathematical.value ob),a.ok&&b.ok) :=
  ⟨iadd_closed code installed lib ctx room a b ha hb,decoded_result l c a b oa ob⟩
end ScopedC.NumericDyadicAddRefinement
