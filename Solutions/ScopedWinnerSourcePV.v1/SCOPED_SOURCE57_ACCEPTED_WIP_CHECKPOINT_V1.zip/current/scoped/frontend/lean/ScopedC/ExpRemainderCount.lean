/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderCeilLocal
import ScopedC.ExpRemainderCeilMath
import ScopedC.UnsignedLiteralControl

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax

def afterC {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) : Cursor :=
  CursorLocals.allocated (afterSmall stage) "unsigned int" "c" (PoolCalls.word stage.endpoint.magnitude)

theorem small_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} (stage : CeilStage code l c a)
    (bound : stage.endpoint.magnitude<2^32)
    (answer : service "small" [.natObject stage.endpoint.slot] (afterCeil stage).state=
      some (PoolCalls.word stage.endpoint.magnitude,(afterSmall stage).state)) :
    Declare Header.layout service [{type:="unsigned int",name:="c",value:=some (.call (.var "small") [.field "." (.var "ceil") "mag"]),arrayExtent:=none}]
      (afterCeil stage).state (afterC stage).state := by
  have expression:=ExpressionTemplates.call_one Header.layout service (ceil_mag_eval service 997 stage) answer
  have cast : castValue Header.layout (afterSmall stage).state 100 "unsigned int"
      (PoolCalls.word stage.endpoint.magnitude)=some (PoolCalls.word stage.endpoint.magnitude) :=
    RationalUnsignedCalls.cast_parameter (afterSmall stage).state stage.endpoint.magnitude bound
  simp only[Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem count_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) :
    LocalBinding.At (afterC stage).state "c" "unsigned int" (PoolCalls.word stage.endpoint.magnitude)
      (afterSmall stage).state.heap.length :=
  LocalBinding.allocate_head _ "c" "unsigned int" _ (by rfl)

theorem afterC_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) (room : c.top+16<PoolCalls.capacity) : Valid l (afterC stage) := by
  have top:=ceil_top stage
  exact CursorLocals.allocated_valid (next_valid 4294967295 (afterCeil_valid stage)
    (by change stage.out.top<PoolCalls.capacity;omega)) "unsigned int" "c" _

theorem afterC_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) : (afterC stage).top ≤ c.top+17 := by
  change stage.out.top+1 ≤ c.top+17
  have top:=ceil_top stage
  omega

theorem afterC_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) {object d : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At (afterC stage).state "depth" object d := by
  have before:=afterR_depth (l:=l) a depth apart
  have next : SourceUnsignedGlobal.At stage.out.state "depth" object d := by
    rw[stage.trace]
    exact SourceUnsignedGlobal.advanced before stage.values apart.1 apart.2.1 apart.2.2
  exact SourceUnsignedGlobal.allocated
    (SourceUnsignedGlobal.advanced (SourceUnsignedGlobal.allocated next "S" "ceil" _) [4294967295]
      apart.1 apart.2.1 apart.2.2) "unsigned int" "c" _

theorem afterC_unshadowed {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) : (afterC stage).state.env.lookup "depth"=none := by
  change (("c",_)::(next l (afterCeil stage) 4294967295).state.env).lookup "depth"=none
  rw[(PoolCursor.shape _ _ _).2]
  change (("c",_)::("ceil",_)::stage.out.state.env).lookup "depth"=none
  rw[stage.trace,(CursorEffects.shape _ _ _).2]
  simpa only[List.lookup,String.reduceBEq] using afterR_unshadowed l c a

theorem ceil_branch (service : Call) {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {a : Pair} (stage : CeilStage code l c a) (positive : a.Positive) :
    Run Header.layout service (.branch (.field "." (.var "ceil") "neg")
      (.eval (.call (.var "fail") [])) .skip) (afterCeil stage).state
      (.continuing (afterCeil stage).state) := by
  apply Loops.StmtRun.branch (show Eval Header.layout service (.field "." (.var "ceil") "neg")
    (afterCeil stage).state (afterCeil stage).state
    (NatWrapperCalls.unsigned32 (SignedNegCalls.bit stage.endpoint.negative)) from ⟨2,ceil_neg_eval service 0 stage⟩)
  rw[ceil_sign stage positive]
  exact Loops.StmtRun.skip _

theorem small_branch (service : Call) {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {a : Pair} (stage : CeilStage code l c a)
    (bound : stage.endpoint.magnitude<4294967295) :
    Run Header.layout service (.branch (.binary "==" (.var "c") (.uint 4294967295))
      (.eval (.call (.var "fail") [])) .skip) (afterC stage).state
      (.continuing (afterC stage).state) := by
  have condition : Eval Header.layout service (.binary "==" (.var "c") (.uint 4294967295))
      (afterC stage).state (afterC stage).state
      (boolean Header.layout (decide (stage.endpoint.magnitude=4294967295))) :=
    ⟨3,ExpressionTemplates.binary Header.layout service (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)
      (LocalBinding.eval service 1 (count_binding stage) (by decide +kernel) (by decide +kernel)
        (by decide +kernel) (by decide +kernel)) (by rfl)
      (UnsignedLiteralControl.binary_eq _ _ _ (by omega) (by decide +kernel))⟩
  apply Loops.StmtRun.branch condition
  simp only[UnsignedLiteralControl.truth_boolean,ne_of_lt bound,decide_false,Bool.false_eq_true,↓reduceIte]
  exact Loops.StmtRun.skip _

end ScopedC.ExpRemainderCalls
