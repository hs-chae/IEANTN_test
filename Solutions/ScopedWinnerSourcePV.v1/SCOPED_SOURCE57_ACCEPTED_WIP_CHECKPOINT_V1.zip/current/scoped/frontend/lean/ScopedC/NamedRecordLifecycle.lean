/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedFrames
import ScopedC.RationalDecimalLiteralService
import ScopedC.RationalUnsignedRatioEffects
namespace ScopedC.NamedRecordLifecycle
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalRecordFields
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def stored (c : Cursor) (slot : Nat) (lo hi : Value) : Cursor :=
  {c with state:=changed c.state slot lo hi}

theorem stored_live {c : Cursor} {slot : Nat} {lo hi : Value}
    (q : RationalPairFrames.Input) (h : q.Live c.state) :
    q.Live (stored c slot lo hi).state := h

theorem stored_scale {c : Cursor} {lo hi : Value} {slot object valueSlot number : Nat}
    (h : At c.state lo hi slot) (scale : SourceFromS.ScaleAt c.state object valueSlot number)
    (newLo newHi : Value) :
    SourceFromS.ScaleAt (stored c slot newLo newHi).state object valueSlot number :=
  scale_store h scale newLo newHi

theorem pop_record {before after : State} {lo hi oldLo oldHi : Value} {slot : Nat}
    (prior : At before oldLo oldHi slot) (final : At after lo hi slot) :
    At (popScope before after) lo hi slot := by
  constructor
  · exact prior.lookup
  · have bound := (List.getElem?_eq_some_iff.mp prior.memory).choose
    simpa only [popScope,List.getElem?_take_of_lt bound] using final.memory

theorem pop_scale {before after : State} {object slot value : Nat}
    (prior : SourceFromS.ScaleAt before object slot value)
    (final : SourceFromS.ScaleAt after object slot value) :
    SourceFromS.ScaleAt (popScope before after) object slot value := by
  have bound := (List.getElem?_eq_some_iff.mp prior.storage).choose
  exact ⟨final.lookup,by
    simpa only [popScope,List.getElem?_take_of_lt bound] using final.storage,final.live⟩

theorem decimal_lo (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    {n d : Nat} (D : RationalDecimalLiteral.Stages code l c n d) (ctx : Valid l c)
    (room : D.numerator.top<capacity) {lo hi : Value} {slot : Nat}
    (h : At c.state lo hi slot)
    (source : evalExpr Header.layout service 1000 c.state
      (RationalDecimalLiteral.initializer n d)=
        some (D.output.source,(RationalDecimalLiteral.after D).state)) :
    evalExpr Header.layout service 1001 c.state
      (.binary "=" (.field "." (.var "r") "lo") (RationalDecimalLiteral.initializer n d))=
      some (D.output.source,(stored (RationalDecimalLiteral.after D) slot D.output.source hi).state) ∧
    Valid l (stored (RationalDecimalLiteral.after D) slot D.output.source hi) ∧
    At (stored (RationalDecimalLiteral.after D) slot D.output.source hi).state D.output.source hi slot := by
  have middle := RationalRecordFields.decimal D ctx room h
  exact ⟨source_lo service 998 source middle (D.output.cast "Q" (by decide +kernel) D.live),
    valid D.valid middle _ _,binding middle _ _⟩

theorem decimal_hi (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    {n d : Nat} (D : RationalDecimalLiteral.Stages code l c n d) (ctx : Valid l c)
    (room : D.numerator.top<capacity) {lo hi : Value} {slot : Nat}
    (h : At c.state lo hi slot)
    (source : evalExpr Header.layout service 1000 c.state
      (RationalDecimalLiteral.initializer n d)=
        some (D.output.source,(RationalDecimalLiteral.after D).state)) :
    evalExpr Header.layout service 1001 c.state
      (.binary "=" (.field "." (.var "r") "hi") (RationalDecimalLiteral.initializer n d))=
      some (D.output.source,(stored (RationalDecimalLiteral.after D) slot lo D.output.source).state) ∧
    Valid l (stored (RationalDecimalLiteral.after D) slot lo D.output.source) ∧
    At (stored (RationalDecimalLiteral.after D) slot lo D.output.source).state lo D.output.source slot := by
  have middle := RationalRecordFields.decimal D ctx room h
  exact ⟨source_hi service 998 source middle (D.output.cast "Q" (by decide +kernel) D.live),
    valid D.valid middle _ _,binding middle _ _⟩

theorem unsigned_lo (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    {n d : Nat} (D : RationalUnsignedRatio.Stages code l c n d) (ctx : Valid l c)
    (room : c.top+18<capacity) {lo hi : Value} {slot : Nat} (h : At c.state lo hi slot)
    (source : evalExpr Header.layout service 1000 c.state
      (RationalUnsignedRatio.initializer n d)=
        some (D.output.source,(RationalUnsignedRatio.after l c n d).state)) :
    evalExpr Header.layout service 1001 c.state
      (.binary "=" (.field "." (.var "r") "lo") (RationalUnsignedRatio.initializer n d))=
      some (D.output.source,(stored (RationalUnsignedRatio.after l c n d) slot D.output.source hi).state) ∧
    Valid l (stored (RationalUnsignedRatio.after l c n d) slot D.output.source hi) ∧
    At (stored (RationalUnsignedRatio.after l c n d) slot D.output.source hi).state D.output.source hi slot := by
  have middle := RationalUnsignedRatio.record ctx n d room h
  exact ⟨source_lo service 998 source middle (D.output.cast "Q" (by decide +kernel) D.live),
    valid D.valid middle _ _,binding middle _ _⟩

theorem unsigned_hi (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    {n d : Nat} (D : RationalUnsignedRatio.Stages code l c n d) (ctx : Valid l c)
    (room : c.top+18<capacity) {lo hi : Value} {slot : Nat} (h : At c.state lo hi slot)
    (source : evalExpr Header.layout service 1000 c.state
      (RationalUnsignedRatio.initializer n d)=
        some (D.output.source,(RationalUnsignedRatio.after l c n d).state)) :
    evalExpr Header.layout service 1001 c.state
      (.binary "=" (.field "." (.var "r") "hi") (RationalUnsignedRatio.initializer n d))=
      some (D.output.source,(stored (RationalUnsignedRatio.after l c n d) slot lo D.output.source).state) ∧
    Valid l (stored (RationalUnsignedRatio.after l c n d) slot lo D.output.source) ∧
    At (stored (RationalUnsignedRatio.after l c n d) slot lo D.output.source).state lo D.output.source slot := by
  have middle := RationalUnsignedRatio.record ctx n d room h
  exact ⟨source_hi service 998 source middle (D.output.cast "Q" (by decide +kernel) D.live),
    valid D.valid middle _ _,binding middle _ _⟩

end ScopedC.NamedRecordLifecycle
