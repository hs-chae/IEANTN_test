/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientLoop

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

/-- Generic source-loop invariant. In final callers P is instantiated only
with physical scale/record storage whose step preservation is separately
proved from the original source effects. No application value is an axiom. -/
theorem coefficient_loop_invariant (code : List Function) (lib : CoeffLibrary code) (n : Nat)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (remaining : f.k+n=d+1)
    (room : f.cursor.top+35*n ≤ PoolCalls.capacity)
    (P : CoeffFrame l object d eb ab→Prop)
    (preserve : ∀start active room,P start → P (coefficientStep start active room))
    (initial : P f) : ∃certificate : CoefficientLoopCertificate code f,P certificate.finish := by
  induction n generalizing f with
  | zero =>
    have stopped : f.k=d+1 := by omega
    refine ⟨{
      finish:=f
      events:=[]
      unique:=by simp
      bounds:=by simp
      nats_le:=Nat.le_refl _
      execution:=?_
      stopped:=stopped
      top:=by omega
      shape:=⟨rfl,rfl⟩ },initial⟩
    intro service _
    exact Loops.WhileRun.done (coefficientCondition_eval service f)
      (by simp [UnsignedLiteralControl.truth_boolean,stopped])
  | succ n ih =>
    have active : f.k ≤ d := by omega
    have oneRoom : f.cursor.top+34<PoolCalls.capacity := by omega
    let next:=coefficientStep f active oneRoom
    have nextK : next.k=f.k+1:=coefficientStep_k f active oneRoom
    have nextRemaining : next.k+n=d+1 := by omega
    have nextRoom : next.cursor.top+35*n ≤ PoolCalls.capacity := by
      have bound:=coefficientStep_top f active oneRoom
      change next.cursor.top ≤ f.cursor.top+35 at bound
      omega
    obtain ⟨tail,tailProperty⟩:=ih next nextRemaining nextRoom
      (preserve f active oneRoom initial)
    let front:=coefficientEvents code lib f active oneRoom
    have nle : f.cursor.state.nats.values.length ≤ next.cursor.state.nats.values.length := by
      have size:=coefficientStep_size f active oneRoom
      change next.cursor.state.nats.values.length=_ at size
      split_ifs at size <;> omega
    have finishLower:=tail.nats_le
    refine ⟨{
      finish:=tail.finish
      events:=front++tail.events
      unique:=?_
      bounds:=?_
      nats_le:=nle.trans tail.nats_le
      execution:=?_
      stopped:=tail.stopped
      top:=?_
      shape:=⟨tail.shape.1.trans (coefficientStep_shape f active oneRoom).1,
        tail.shape.2.trans (coefficientStep_shape f active oneRoom).2⟩ },tailProperty⟩
    · rw[List.map_append,List.nodup_append]
      refine ⟨coefficientEvents_unique code lib f active oneRoom,tail.unique,?_⟩
      intro a ha b hb same
      obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
      obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
      have keyEq:=ka.trans (same.trans kb.symm)
      change ea.before.nats.values.length=eb.before.nats.values.length at keyEq
      have left:=coefficientEvents_bounds code lib f active oneRoom ea hea
      have right:=tail.bounds eb heb
      change f.cursor.state.nats.values.length ≤ ea.before.nats.values.length ∧
        ea.before.nats.values.length<next.cursor.state.nats.values.length at left
      omega
    · intro e member
      rcases List.mem_append.mp member with first|later
      · have h:=coefficientEvents_bounds code lib f active oneRoom e first
        exact ⟨h.1,lt_of_lt_of_le h.2 finishLower⟩
      · have h:=tail.bounds e later
        exact ⟨nle.trans h.1,h.2⟩
    · intro service answers
      have frontAnswers : CoefficientEventAnswers service front:=fun e member=>
        answers e (List.mem_append_left _ member)
      have tailAnswers : CoefficientEventAnswers service tail.events:=fun e member=>
        answers e (List.mem_append_right _ member)
      exact Loops.WhileRun.next (coefficientCondition_eval service f)
        (by simp [UnsignedLiteralControl.truth_boolean,active])
        (coefficientStep_run service f active oneRoom
          (coefficientEvents_answers code lib f active oneRoom service frontAnswers))
        (tail.execution service tailAnswers)
    · have bound:=tail.top
      have topBound : next.cursor.top ≤ f.cursor.top+35:=coefficientStep_top f active oneRoom
      have kp:=f.kPositive
      omega

end ScopedC.PrepareSource
