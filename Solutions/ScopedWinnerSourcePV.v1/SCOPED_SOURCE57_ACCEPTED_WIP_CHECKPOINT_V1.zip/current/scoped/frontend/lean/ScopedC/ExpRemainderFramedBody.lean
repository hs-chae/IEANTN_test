/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderBody
import ScopedC.ExpRemainderCallerOutput

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax errorCursor errorInput outputPair

structure FramedResult (code : List Function) (l : PoolCalls.PoolLayout) (before : Cursor)
    (a : Pair) (d : Nat) (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) where
  out : Cursor
  output : Pair
  execution : SourceCall Header.layout code 10 "expRemainder" [a.source] before.state output.source out.state
  valid : Valid l out
  live : output.Live out.state
  positive : output.Positive
  decoded : NumericRepresentation.interval out.state output.source=some
    (IntervalRat.expRemainderBoundComputable ⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩ d)
  top : out.top ≤ before.top+3000
  globals : out.state.globals=before.state.globals
  env : out.state.env=before.state.env
  heap_length : out.state.heap.length=before.state.heap.length
  preserves : ∀slot value,NatArena.Borrow before.state.nats slot value →
    NatArena.Borrow out.state.nats slot value
  other : ∀slot,slot<before.state.heap.length → slot≠l.pool → slot≠l.top → slot≠l.high →
    out.state.heap[slot]?=before.state.heap[slot]?

/-- Unchanged original expRemainder source and exact old model, now retaining
all arbitrary caller Nat handles and nonpool objects for composed consumers. -/
theorem expRemainder_framed (code : List Function) (installed : Generated.f_expRemainder∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a : Pair) (alive : a.Live c.state) (positive : a.Positive)
    (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) (d object : Nat)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (dBound : d≤64)
    (range : Int.ceil (max |a.lo.mathematical.value| |a.hi.mathematical.value|)<4294967295)
    (room : c.top+3000<PoolCalls.capacity) : Nonempty (FramedResult code l c a d ordered) := by
  obtain ⟨ceil⟩:=ceil_stage code lib.ceiling ctx a alive positive (by omega)
  have countBound:=small_guard_bound ceil positive range
  obtain ⟨f⟩:=factorial_stage code lib.powers ceil object d depth apart dBound (by omega)
  obtain ⟨p⟩:=three_power code lib.qpow lib.powers f countBound room
  obtain ⟨r⟩:=radius_power code lib.qpow lib.powers f p alive positive room
  obtain ⟨service,closed,front,loopAnswers,tail⟩:=outer_service code lib ctx a alive f p r countBound room
  have radiusDecl:=radius_declaration service ctx a alive front.absoluteLow front.absoluteHigh front.maximum
  have ceilingDecl:=ceil_declaration service ceil ctx (by omega) front.ceiling
  have ceilingGuard:=ceil_branch service ceil positive
  have countDecl:=small_declaration service ceil (by omega) front.small
  have countGuard:=small_branch service ceil countBound
  have factDecl:=ExpFactorial.fact_declaration service l (afterC ceil) front.one
  have kDecl:=ExpFactorial.k_declaration service l (afterC ceil)
  have factorialLoop : ExpFactorial.While service (ExpFactorial.initial l (afterC ceil)).state
      (.continuing (BeforeError f).state) := by
    rw[←f.cursor]
    exact f.loop.execution service loopAnswers
  have errorDecl:=error_declaration service ctx f p r countBound room tail.qiThree tail.first
    tail.second tail.multiply tail.divide
  have outDecl:=output_declaration service r room tail.negative
  have returned:=out_return service r
  let bodyExit:=PoolContextPop.unframe (parameters c a).state (afterOut r)
  let out:=PoolContextPop.unframe c.state bodyExit
  have body : Run Header.layout service Generated.f_expRemainder.body (parameters c a).state
      (.returned bodyExit.state (outputPair r).source) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.declare radiusDecl) (Loops.SeqRun.next (Loops.StmtRun.declare ceilingDecl) (Loops.SeqRun.next (ceilingGuard) (Loops.SeqRun.next (Loops.StmtRun.declare countDecl) (Loops.SeqRun.next (countGuard) (Loops.SeqRun.next (Loops.StmtRun.declare factDecl) (Loops.SeqRun.next (Loops.StmtRun.declare kDecl) (Loops.SeqRun.next (Loops.StmtRun.whileLoop factorialLoop) (Loops.SeqRun.next (Loops.StmtRun.declare errorDecl) (Loops.SeqRun.next (Loops.StmtRun.declare outDecl) (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned))))))))))))
    exact ⟨rfl,rfl⟩
  have bodyLive : (outputPair r).Live bodyExit.state:=
    Pair.live_unframe (parameters c a).state (afterOut r) (outputPair r) (output_live r)
  have resultLive : (outputPair r).Live out.state:=Pair.live_unframe c.state bodyExit (outputPair r) bodyLive
  have source : SourceCall Header.layout code 10 "expRemainder" [a.source] c.state
      (outputPair r).source out.state := by
    apply installed_body (cfg:=Header.layout) (code:=code) (f:=Generated.f_expRemainder)
      (rank:=9) (service:=service) (args:=[a.source]) (s:=c.state) (frame:=(parameters c a).state)
      (t:=out.state) (v:=(outputPair r).source) (outcome:=.returned bodyExit.state (outputPair r).source)
      installed closed (bind_parameters c a alive) body
    exact ⟨Pair.cast (s:=bodyExit.state) (a:=outputPair r) bodyLive "static RI" (by decide +kernel),rfl⟩
  have hp:=(List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht:=(List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh:=(List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have paramsLength : (parameters c a).state.heap.length=c.state.heap.length+1 := by
    simp [parameters,OneFrames.frame,allocate]
  have bodyContext : Valid l bodyExit:=PoolContextPop.valid (output_valid r room)
    (by rw[paramsLength];omega) (by rw[paramsLength];omega) (by rw[paramsLength];omega)
  have decoded:=output_model r positive ordered
  have unchanged:=NumericNatsExtensionality.interval (s:=(afterOut r).state) (t:=out.state) rfl (outputPair r).source
  exact ⟨{
    out:=out
    output:=outputPair r
    execution:=source
    valid:=PoolContextPop.valid bodyContext hp ht hh
    live:=resultLive
    positive:=output_positive r
    decoded:=unchanged.symm.trans decoded
    top:=framedOut_top r
    globals:=afterOut_globals r
    env:=(framedOut_shape r).2
    heap_length:=(framedOut_shape r).1
    preserves:=fun _ _ h=>afterOut_borrow r h
    other:=fun slot old hp ht hh=>framedOut_other r slot old hp ht hh }⟩

end ScopedC.ExpRemainderCalls
