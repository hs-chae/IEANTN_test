/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareLn2Store

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

noncomputable def stored_table {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {object : Nat} {old : Option Value}
    (raw : SourceScalarGlobal.At c.state "preparedLn2" "RI" object old)
    {base : Address} {values : List Input} (table : CoefficientTableRead.TableAt c.state base values) :
    CoefficientTableRead.TableAt (afterStore a object).state base values :=
  CoefficientTableRead.scalar_store (product_table ctx room a table)
    (product_scalar ctx room a raw (by decide +kernel)) (product a).source

theorem stored_scale {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {object : Nat} {old : Option Value}
    (raw : SourceScalarGlobal.At c.state "preparedLn2" "RI" object old)
    {scaleObject slot value : Nat} (h : SourceFromS.ScaleAt c.state scaleObject slot value) :
    SourceFromS.ScaleAt (afterStore a object).state scaleObject slot value := by
  have before:=product_scale ctx room a h
  have after:=SourceScalarGlobal.scalar_store
    (show SourceScalarGlobal.At (productCursor a).state "scale100" "N" scaleObject (some (.natObject slot))
      from ⟨before.lookup,before.storage⟩)
    (product_scalar ctx room a raw (by decide +kernel)) (by decide +kernel) (product a).source
  exact ⟨after.lookup,after.storage,before.live⟩

theorem stored_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {object : Nat} {old : Option Value}
    (raw : SourceScalarGlobal.At c.state "preparedLn2" "RI" object old)
    {depthObject n : Nat} (h : SourceUnsignedGlobal.At c.state "depth" depthObject n)
    (apart : depthObject≠l.pool ∧ depthObject≠l.top ∧ depthObject≠l.high) :
    SourceUnsignedGlobal.At (afterStore a object).state "depth" depthObject n := by
  have before:=product_depth a h apart
  have after:=SourceScalarGlobal.scalar_store
    (show SourceScalarGlobal.At (productCursor a).state "depth" "unsigned" depthObject (some (PoolCalls.word n))
      from ⟨before.lookup,before.storage⟩)
    (product_scalar ctx room a raw (by decide +kernel)) (by decide +kernel) (product a).source
  exact ⟨after.lookup,after.storage⟩

theorem stored_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) (object : Nat) :
    (afterStore a object).state.globals=c.state.globals := product_globals a

theorem stored_env {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) (object : Nat) :
    (afterStore a object).state.env=c.state.env := product_env a

theorem stored_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) (object : Nat) :
    (afterStore a object).state.heap.length=c.state.heap.length := by
  change ((productCursor a).state.heap.set object _).length=_
  rw[List.length_set,product_heap]

end ScopedC.PrepareSource.Ln2
