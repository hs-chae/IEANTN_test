/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpFactorialStep
import ScopedC.RationalPowerInitialization

namespace ScopedC.ExpFactorial
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def assignment : Expr := .binary "=" (.var "fact")
  (.call (.var "qt") [.var "fact",.call (.var "qi") [.var "k"]])
def increment : Expr := .binary "=" (.var "k") (.binary "+" (.var "k") (.nat 1))
def loopBody : Stmt := .sequence [.eval assignment,.eval increment]

structure Answers (service : Call) {l : PoolCalls.PoolLayout} {object d : Nat}
    (f : Frame l object d) : Prop where
  qi : service "qi" [PoolCalls.word f.k] f.cursor.state=
    some ((counterInput f).source,(afterQi f).state)
  qt : service "qt" [f.fact.source,(counterInput f).source] (afterQi f).state=
    some ((product f).source,(productCursor f).state)

theorem qi_call (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [PoolCalls.word f.k] f.cursor.state
      (counterInput f).source (afterQi f).state := by
  have kb:=f.kBound
  have db:=f.depthBound
  exact (RationalUnsignedTrace.qi_traced code lib.qi lib.si lib.productLibrary.smake
    lib.productLibrary.nz lib.productLibrary.nu lib.productLibrary.ne lib.productLibrary.keep
    f.context f.k (by omega) (by omega) (PoolCalls.word f.k)
    (RationalUnsignedCalls.cast_parameter f.cursor.state f.k (by omega))).1

theorem qt_call (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qt" [f.fact.source,(counterInput f).source] (afterQi f).state
      (product f).source (productCursor f).state := by
  unfold productCursor product
  exact RationalMultiplyCalls.qt_closed code lib.qt lib.productLibrary (afterQi_valid f room)
    (by change f.cursor.top+3+10<PoolCalls.capacity;omega) f.fact (counterInput f)
    (fact_afterQi_live f) (counter_live f) f.positive (counter_positive f)

theorem assignment_eval (service : Call) {l : PoolCalls.PoolLayout} {object d : Nat}
    (f : Frame l object d) (answers : Answers service f) :
    Eval Header.layout service assignment f.cursor.state (stored f).state (product f).source := by
  have safe:=LocalStorageSeparation.pool f.context f.kAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  have afterK : LocalBinding.At (afterQi f).state "k" "unsigned int" (PoolCalls.word f.k) f.kSlot :=
    LocalBinding.advance f.kAt [f.k,0,1] safe.1 safe.2.1 safe.2.2
  have kEval:=LocalBinding.eval service 1 f.kAt (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have qiEval:=ExpressionTemplates.call_one Header.layout service kEval answers.qi
  have factEval:=LocalBinding.eval service 2 f.factAt (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have qtEval:=ExpressionTemplates.call_two Header.layout service factEval qiEval answers.qt
  exact ⟨5,LocalAssignment.evaluate service 3 qtEval (fact_product_binding f)
    (Input.cast "Q" (by decide +kernel) (product_live f))⟩

theorem stepped_run (service : Call) {l : PoolCalls.PoolLayout} {object d : Nat}
    (f : Frame l object d) (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity)
    (answers : Answers service f) :
    Run Header.layout service loopBody f.cursor.state (.continuing (stepped f active room).cursor.state) := by
  have inc:=UnsignedLocalSteps.increment service (stored_k_binding f)
    (by have h:=f.depthBound;omega) (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.evaluate (assignment_eval service f answers))
    (Loops.SeqRun.next (Loops.StmtRun.evaluate inc) (Loops.SeqRun.nil _)))
  have shape:=CursorEffects.shape l f.cursor
    ([f.k,0,1]++RationalMultiplyTrace.steps l (afterQi f) f.fact (counterInput f))
  have heap : (stepped f active room).cursor.state.heap.length=f.cursor.state.heap.length := by
    change (((productCursor f).state.heap.set f.factSlot _).set f.kSlot _).length=_
    rw[List.length_set,List.length_set,product_trace]
    exact shape.1
  have env : (stepped f active room).cursor.state.env=f.cursor.state.env := by
    change (productCursor f).state.env=_
    rw[product_trace]
    exact shape.2
  exact (PoolCalls.pop_same heap env).symm

end ScopedC.ExpFactorial
