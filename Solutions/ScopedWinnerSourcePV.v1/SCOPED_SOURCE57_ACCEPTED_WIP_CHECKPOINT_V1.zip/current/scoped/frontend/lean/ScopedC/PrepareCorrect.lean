/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareOutputFrames

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

/-- Source-produced physical application globals, connected to the exact old
mathematical Taylor/ln2 algorithms. This is a result, never a platform premise. -/
structure PreparedResult (code : List Function) {state : State} {base : Nat}
    (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) (argument : Value) where
  stage : CompleteStage code ready d bound
  execution : SourceCall Header.layout code 11 "prepare" [argument] state .unit (finished stage).state
  valid : Valid (layout base) (finished stage)
  depth : SourceUnsignedGlobal.At (finished stage).state "depth" (base+3) d
  expTable : CoefficientTableRead.TableAt (finished stage).state (expBase base) stage.coefficient.loop.finish.expCoeffs
  atanhTable : CoefficientTableRead.TableAt (finished stage).state (atanhBase base) stage.coefficient.loop.finish.atanhCoeffs
  expLength : stage.coefficient.loop.finish.expCoeffs.length=d+1
  atanhLength : stage.coefficient.loop.finish.atanhCoeffs.length=d+1
  expValues : TaylorCalls.coefficientValues stage.coefficient.loop.finish.expCoeffs=
    LeanCert.Core.IntervalRat.expTaylorCoeffs d
  atanhValues : TaylorCalls.coefficientValues stage.coefficient.loop.finish.atanhCoeffs=
    LeanCert.Core.IntervalRat.atanhTaylorCoeffs d
  expLookup : (finished stage).state.globals.lookup "expCoeffs"=some (expBase base)
  atanhLookup : (finished stage).state.globals.lookup "atanhCoeffs"=some (atanhBase base)
  scale : SourceFromS.ScaleAt (finished stage).state (base+4)
    (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100)
  ln2Storage : SourceScalarGlobal.At (finished stage).state "preparedLn2" "RI" (base+7)
    (some (Ln2.product stage.atanh).source)
  ln2Live : (Ln2.product stage.atanh).Live (finished stage).state
  ln2Positive : (Ln2.product stage.atanh).Positive
  ln2Model : NumericRepresentation.interval (finished stage).state (Ln2.product stage.atanh).source=
    some (LeanCert.Core.IntervalRat.ln2Computable d)
  globals : (finished stage).state.globals=state.globals
  env : (finished stage).state.env=state.env

/-- Complete original source prepare and all mathematical application outputs.
Only the original input guard d≤64 and actual C argument conversion remain as
entry conditions. All application globals are constructed from actual source
initialization; no numerical output or callee-success premise is used. -/
theorem prepare_correct (code : List Function) (installed : Generated.f_prepare∈code)
    (lib : CompleteLibrary code) {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) (argument : Value)
    (convert : castValue Header.layout {state with env:=[]} 100 "unsigned int" argument=some (PoolCalls.word d)) :
    Nonempty (PreparedResult code ready d bound argument) := by
  obtain ⟨stage,source⟩:=prepare_closed code installed lib ready d bound argument convert
  exact ⟨{
    stage:=stage
    execution:=source
    valid:=finished_valid stage
    depth:=finished_depth stage
    expTable:=finished_exp_table stage
    atanhTable:=finished_atanh_table stage
    expLength:=stage.coefficient.loop.finish.expLength.trans stage.coefficient.loop.stopped
    atanhLength:=stage.coefficient.loop.finish.atanhLength.trans stage.coefficient.loop.stopped
    expValues:=(coefficient_stage_old_math stage.coefficient).1
    atanhValues:=(coefficient_stage_old_math stage.coefficient).2
    expLookup:=finished_exp_lookup stage
    atanhLookup:=finished_atanh_lookup stage
    scale:=finished_scale stage
    ln2Storage:=finished_ln2_storage stage
    ln2Live:=finished_ln2_live stage
    ln2Positive:=Ln2.product_positive stage.atanh
    ln2Model:=finished_ln2_model stage
    globals:=finished_globals stage
    env:=rfl }⟩

/-- Complete actual static+readonly source initialization followed by the
original prepare(24) call used by the unchanged producer. No initialized
application representation is an input to this theorem. -/
theorem initialized_prepare24 (code : List Function) (installed : Generated.f_prepare∈code)
    (lib : CompleteLibrary code) (platform : State) :
    ∃state,DataComplete.initializeProgramGlobals platform=some state ∧
      ∃ready : StaticAt state platform.heap.length,
        Nonempty (PreparedResult code ready 24 (by decide +kernel) (DecimalDigits.integer 24)) := by
  obtain ⟨state,initialized,⟨ready⟩⟩:=complete_initialization platform
  exact ⟨state,initialized,ready,prepare_correct code installed lib ready 24 (by decide +kernel)
    (DecimalDigits.integer 24) (by rfl)⟩

end ScopedC.PrepareSource
