/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerInvariant
import ScopedC.RationalProductApplicability
import ScopedC.LocalStorageSeparation
import ScopedC.NumericUnsignedRefinement

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

/-- Physical loop-state facts to be constructed from source declarations and
maintained by actual source assignments; never a platform initial-state axiom. -/
structure Frame (l : PoolCalls.PoolLayout) where
  cursor : Cursor
  current : Input
  accumulator : Input
  exponent : Nat
  aSlot : Nat
  nSlot : Nat
  rSlot : Nat
  context : Valid l cursor
  aAt : LocalBinding.At cursor.state "a" "Q" current.source aSlot
  nAt : LocalBinding.At cursor.state "n" "unsigned int" (PoolCalls.word exponent) nSlot
  rAt : LocalBinding.At cursor.state "result" "Q" accumulator.source rSlot
  aLive : current.Live cursor.state
  rLive : accumulator.Live cursor.state
  aPositive : 0<current.denominator
  rPositive : 0<accumulator.denominator
  exponentBound : exponent<2^32
  arDistinct : aSlot≠rSlot

def parameters (c : Cursor) (a : Input) (n : Nat) : Cursor :=
  CursorFrames.framed c "Q" "a" a.source "unsigned int" "n" (PoolCalls.word n)
def oneCursor (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := CursorFrames.advance l c [1,0,1]
def oneQ (l : PoolCalls.PoolLayout) (c : Cursor) : Input :=
  ⟨⟨c.state.nats.values.length,1,false⟩,
    (SignedCalls.siResult l c.state c.cells c.top c.high 1).nats.values.length,1⟩
def loopStart (l : PoolCalls.PoolLayout) (c : Cursor) (a : Input) (n : Nat) : Cursor :=
  CursorLocals.allocated (oneCursor l (parameters c a n)) "Q" "result" (oneQ l (parameters c a n)).source

theorem one_state (l : PoolCalls.PoolLayout) (c : Cursor) :
    (oneCursor l c).state=RationalUnsignedCalls.qiResult l c.state c.cells c.top c.high 1 := rfl
theorem one_source (l : PoolCalls.PoolLayout) (c : Cursor) :
    (oneQ l c).source=RecordCasts.rational c.state.nats.values.length 0
      (SignedCalls.siResult l c.state c.cells c.top c.high 1).nats.values.length := rfl
theorem one_live (l : PoolCalls.PoolLayout) (c : Cursor) : (oneQ l c).Live (oneCursor l c).state :=
  ⟨RationalUnsignedCalls.qi_mag_live l c.state c.cells c.top c.high 1,
   RationalUnsignedCalls.qi_den_live l c.state c.cells c.top c.high 1⟩
theorem one_value (l : PoolCalls.PoolLayout) (c : Cursor) : (oneQ l c).mathematical.value=1 := by
  simp [oneQ,Input.mathematical,DyadicRepresentation.Endpoint.mathematical,ScopedNumerical.Rational.value,ScopedNumerical.Signed.value]

theorem bind_parameters (c : Cursor) (a : Input) (n : Nat) (ha : a.Live c.state) (hn : n<2^32) :
    bindArgs Header.layout [("Q","a"),("unsigned int","n")] [a.source,PoolCalls.word n] c.state=
      some (parameters c a n).state :=
  TypedFrames.bind_two Header.layout c.state "Q" "a" "unsigned int" "n"
    a.source (PoolCalls.word n) a.source (PoolCalls.word n)
    (Input.cast "Q" (by decide +kernel) ha) (RationalUnsignedCalls.cast_parameter _ n hn)

theorem parameters_a (c : Cursor) (a : Input) (n : Nat) :
    LocalBinding.At (parameters c a n).state "a" "Q" a.source c.state.heap.length :=
  LocalBinding.allocate_other
    (LocalBinding.allocate_head {c.state with env:=[]} "a" "Q" a.source (RationalProductApplicability.initialized a))
    "n" "unsigned int" (some (PoolCalls.word n)) (by decide +kernel)
theorem parameters_n (c : Cursor) (a : Input) (n : Nat) :
    LocalBinding.At (parameters c a n).state "n" "unsigned int" (PoolCalls.word n) (c.state.heap.length+1) := by
  simpa only[parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.length_append,List.length_singleton] using
    LocalBinding.allocate_head (allocate {c.state with env:=[]} "Q" "a" (some a.source))
      "n" "unsigned int" (PoolCalls.word n) (by rfl)

theorem parameters_length (c : Cursor) (a : Input) (n : Nat) :
    (parameters c a n).state.heap.length=c.state.heap.length+2 := by
  simp [parameters,CursorFrames.framed,TwoFrames.frame,allocate]

theorem loopStart_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) (a : Input) (n : Nat) : Valid l (loopStart l c a n) := by
  apply CursorLocals.allocated_valid
  apply CursorFrames.advance_valid (CursorFrames.framed_valid ctx "Q" "a" a.source "unsigned int" "n" (PoolCalls.word n))
  change c.top+3≤PoolCalls.capacity
  omega

/-- All loop facts are established from the actual parameter frame, qi(1)
allocation effects and fresh Q result local. -/
theorem initial_frame {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) (a : Input) (n : Nat)
    (ha : a.Live c.state) (pa : 0<a.denominator) (hn : n<2^32) :
    ∃f : Frame l,f.cursor=loopStart l c a n ∧ f.current=a ∧
      f.accumulator=oneQ l (parameters c a n) ∧ f.exponent=n := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have aa : LocalBinding.At (oneCursor l (parameters c a n)).state "a" "Q" a.source c.state.heap.length :=
    LocalBinding.advance (parameters_a c a n) _ (by omega) (by omega) (by omega)
  have nn : LocalBinding.At (oneCursor l (parameters c a n)).state "n" "unsigned int" (PoolCalls.word n) (c.state.heap.length+1) :=
    LocalBinding.advance (parameters_n c a n) _ (by omega) (by omega) (by omega)
  have ra : LocalBinding.At (loopStart l c a n).state "result" "Q" (oneQ l (parameters c a n)).source (c.state.heap.length+2) := by
    have h:=LocalBinding.allocate_head (oneCursor l (parameters c a n)).state "result" "Q"
      (oneQ l (parameters c a n)).source (RationalProductApplicability.initialized _)
    simpa only[loopStart,CursorLocals.allocated,oneCursor,
      (CursorEffects.shape l (parameters c a n) [1,0,1]).1,parameters_length] using h
  have alive : a.Live (loopStart l c a n).state :=
    ⟨CursorBorrow.preserves (c:=parameters c a n) [1,0,1] ha.1,
     CursorBorrow.preserves (c:=parameters c a n) [1,0,1] ha.2⟩
  refine ⟨{
    cursor:=loopStart l c a n
    current:=a
    accumulator:=oneQ l (parameters c a n)
    exponent:=n
    aSlot:=c.state.heap.length
    nSlot:=c.state.heap.length+1
    rSlot:=c.state.heap.length+2
    context:=loopStart_valid ctx room a n
    aAt:=LocalBinding.allocate_other aa "result" "Q" _ (by decide +kernel)
    nAt:=LocalBinding.allocate_other nn "result" "Q" _ (by decide +kernel)
    rAt:=ra
    aLive:=alive
    rLive:=one_live l (parameters c a n)
    aPositive:=pa
    rPositive:=by change 0<(1:Nat);omega
    exponentBound:=hn
    arDistinct:=by omega },rfl,rfl,rfl,rfl⟩

end ScopedC.RationalPowerCalls
