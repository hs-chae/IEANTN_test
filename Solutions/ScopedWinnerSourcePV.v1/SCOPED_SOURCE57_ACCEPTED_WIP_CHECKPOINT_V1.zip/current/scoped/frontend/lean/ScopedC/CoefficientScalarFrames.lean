/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientTableWrite
import ScopedC.SourceUnsignedAssignment

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem scalar_separated {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) {slot : Nat} {type : String} {value : Option Value}
    (scalar : s.heap[slot]?=some {type:=type,cells:=[value]}) : base.object≠slot := by
  intro same
  have memory:=table.memory
  rw[same,scalar] at memory
  have flags:=congrArg (fun x : Option Object=>x.map Object.isArray) memory
  change some false=some true at flags
  contradiction

theorem changed_binding {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) (k : Nat) (q : Input)
    {name type : String} {value : Value} {slot : Nat} (binding : LocalBinding.At s name type value slot) :
    LocalBinding.At (changed s base table.cells k q) name type value slot := by
  have separate:=scalar_separated table binding.memory
  exact LocalBinding.memory binding rfl (by simp only[changed,List.getElem?_set_ne separate])

theorem changed_depth {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) (k : Nat) (q : Input) {name : String} {object d : Nat}
    (depth : SourceUnsignedGlobal.At s name object d) :
    SourceUnsignedGlobal.At (changed s base table.cells k q) name object d := by
  have separate:=scalar_separated table depth.storage
  exact ⟨depth.lookup,by simp only[changed,List.getElem?_set_ne separate];exact depth.storage⟩

def after_depth_assignment {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) {name : String} {object old : Nat}
    (depth : SourceUnsignedGlobal.At s name object old) (d : Nat) :
    TableAt (SourceUnsignedGlobal.assigned s object d) base coeffs := by
  have separate:=scalar_separated table depth.storage
  exact memory table (by
    simp only[SourceUnsignedGlobal.assigned,LocalAssignment.changed,PoolCalls.storeObject,
      List.getElem?_set_ne (Ne.symm separate)]) (fun _ _ live=>live)

end ScopedC.CoefficientTableRead
