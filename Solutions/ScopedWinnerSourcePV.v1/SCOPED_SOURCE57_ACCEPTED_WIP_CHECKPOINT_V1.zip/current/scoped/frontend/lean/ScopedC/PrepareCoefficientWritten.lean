/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientAtanhSource
import ScopedC.CoefficientWorkIncrement

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

namespace CoeffWork

noncomputable def atanhWritten {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) : CoeffWork l object d eb ab :=
  if w.k%2=1 then w.oddStored room positive bound else w.evenStored (by omega) bound

theorem atanhWritten_k {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) : (w.atanhWritten room positive bound).k=w.k := by
  unfold atanhWritten
  split <;> rfl

theorem atanhWritten_exp {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) : (w.atanhWritten room positive bound).expCoeffs=w.expCoeffs := by
  unfold atanhWritten
  split <;> rfl

theorem atanhWritten_length {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) :
    (w.atanhWritten room positive bound).atanhCoeffs.length=w.atanhCoeffs.length+1 := by
  unfold atanhWritten
  split <;> change (w.atanhCoeffs++[_]).length=w.atanhCoeffs.length+1 <;> simp

theorem atanhWritten_values {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65)
    (values : TaylorCalls.coefficientValues w.atanhCoeffs=(List.range w.k).map atanhCoefficient) :
    TaylorCalls.coefficientValues (w.atanhWritten room positive bound).atanhCoeffs=
      (List.range (w.k+1)).map atanhCoefficient := by
  unfold atanhWritten
  split
  · rename_i odd
    change TaylorCalls.coefficientValues (w.atanhCoeffs++[w.oddInput room])=_
    exact values_append _ _ _ _ values (by rw[oddInput_value];simp only[atanhCoefficient,odd,↓reduceIte])
  · rename_i even
    change TaylorCalls.coefficientValues (w.atanhCoeffs++[w.qiInput 0])=_
    exact values_append _ _ _ _ values (by
      have value : (w.qiInput 0).mathematical.value=0:=(RationalUnsignedTrace.mathematical l w.cursor 0).1
      rw[value];simp only[atanhCoefficient,even,↓reduceIte])

end CoeffWork

/-- Repackaging proved source storage and value invariants; it contains no
execution assumption and no preinitialized numerical table premise. -/
def frameFromWork {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab)
    (expLength : w.expCoeffs.length=w.k) (atanhLength : w.atanhCoeffs.length=w.k)
    (expValues : TaylorCalls.coefficientValues w.expCoeffs=(List.range w.k).map expCoefficient)
    (atanhValues : TaylorCalls.coefficientValues w.atanhCoeffs=(List.range w.k).map atanhCoefficient)
    (positive : 0<w.k) (bound : w.k ≤ d+1) (depthBound : d ≤ 64) : CoeffFrame l object d eb ab := {
  cursor:=w.cursor
  expCoeffs:=w.expCoeffs
  atanhCoeffs:=w.atanhCoeffs
  k:=w.k
  kSlot:=w.kSlot
  context:=w.context
  expAt:=w.expAt
  atanhAt:=w.atanhAt
  expLength:=expLength
  atanhLength:=atanhLength
  expExtent:=w.expExtent
  atanhExtent:=w.atanhExtent
  expValues:=expValues
  atanhValues:=atanhValues
  expLookup:=w.expLookup
  atanhLookup:=w.atanhLookup
  expUnshadowed:=w.expUnshadowed
  atanhUnshadowed:=w.atanhUnshadowed
  depthAt:=w.depthAt
  depthUnshadowed:=w.depthUnshadowed
  kAt:=w.kAt
  kPositive:=positive
  kBound:=bound
  depthBound:=depthBound
  arraysApart:=w.arraysApart
  depthApart:=w.depthApart }

end ScopedC.PrepareSource
