/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PoolCursor
import ScopedC.CursorBorrow
import ScopedC.ExpressionTemplates

namespace ScopedC.SourceNatLog2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

/-- The runtime allocation precedes the application's actual keep body.  This
state contains no assumed application output or assumed registration effect. -/
def allocated (c : Cursor) (n : Nat) : State :=
  {c.state with nats := (NatArena.allocate c.state.nats n.log2).2}

theorem runtime {c : Cursor} {slot n : Nat}
    (live : NatArena.Borrow c.state.nats slot n) :
    RuntimeCore.call "lean_nat_log2" [.natObject slot] c.state =
      some (.natObject c.state.nats.values.length, allocated c n) := by
  simp [RuntimeCore.call, RuntimeCore.binaryName, NatArena.read_of_borrow live,
    RuntimeCore.result, allocated, NatArena.allocate]

theorem keep_source (code : List Function) (installed : Generated.f_keep ∈ code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (valid : Valid l c)
    (room : c.top < PoolCalls.capacity) (n : Nat) :
    SourceCall Header.layout code 1 "keep" [.natObject c.state.nats.values.length]
      (allocated c n) (.natObject c.state.nats.values.length) (next l c n.log2).state := by
  apply PoolModel.runtimeKeep_closed code installed l
  exact PoolModel.runtimeKeep_keep (PoolCalls.context_nats valid _) room
    (NatArena.allocate_borrow c.state.nats n.log2)

/-- The exact nested source expression used by expPoint and logPoint, retaining
both the generic runtime call and the proved application-owned keep execution. -/
theorem expression (service : Call) {l : PoolCalls.PoolLayout} {c : Cursor}
    {slot n fuel : Nat} {e : Expr}
    (input : evalExpr Header.layout service fuel c.state e = some (.natObject slot,c.state))
    (logAnswer : service "lean_nat_log2" [.natObject slot] c.state =
      some (.natObject c.state.nats.values.length, allocated c n))
    (keepAnswer : service "keep" [.natObject c.state.nats.values.length] (allocated c n) =
      some (.natObject c.state.nats.values.length, (next l c n.log2).state)) :
    evalExpr Header.layout service (fuel+2) c.state
      (.call (.var "keep") [.call (.var "lean_nat_log2") [e]]) =
      some (.natObject c.state.nats.values.length, (next l c n.log2).state) := by
  exact ExpressionTemplates.call_one Header.layout service
    (ExpressionTemplates.call_one Header.layout service input logAnswer) keepAnswer

/-- A fully sound local service for that source expression.  This theorem is a
component execution, not a new whole application function or a numerical leaf. -/
theorem kept_log2 (code : List Function) (installed : Generated.f_keep ∈ code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {slot n : Nat}
    (valid : Valid l c) (room : c.top < PoolCalls.capacity)
    (live : NatArena.Borrow c.state.nats slot n) :
    ∃ service : Call,
      (∀ name args s v t, service name args s = some (v,t) →
        SourceCall Header.layout code 1 name args s v t) ∧
      service "lean_nat_log2" [.natObject slot] c.state =
        some (.natObject c.state.nats.values.length, allocated c n) ∧
      service "keep" [.natObject c.state.nats.values.length] (allocated c n) =
        some (.natObject c.state.nats.values.length, (next l c n.log2).state) := by
  refine ⟨PoolModel.runtimeKeep l, ?_, ?_, ?_⟩
  · intro name args s v t answer
    exact PoolModel.runtimeKeep_closed code installed l answer
  · exact PoolModel.runtimeKeep_primitive (runtime live)
  · exact PoolModel.runtimeKeep_keep (PoolCalls.context_nats valid _) room
      (NatArena.allocate_borrow c.state.nats n.log2)

end ScopedC.SourceNatLog2
