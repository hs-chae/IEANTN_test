/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalProductApplicability
import ScopedC.IntervalPowerCounter
import ScopedC.LocalStorageSeparation

namespace ScopedC.IntervalPowerScan
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure Frame (l : PoolCalls.PoolLayout) (n : Nat) where
  cursor : Cursor
  a : Pair
  result : Pair
  bit : Nat
  aSlot : Nat
  nSlot : Nat
  bitSlot : Nat
  rSlot : Nat
  context : Valid l cursor
  aAt : LocalBinding.At cursor.state "a" "RI" a.source aSlot
  nAt : LocalBinding.At cursor.state "n" "unsigned int" (PoolCalls.word n) nSlot
  bitAt : LocalBinding.At cursor.state "bit" "unsigned int" (PoolCalls.word bit) bitSlot
  rAt : LocalBinding.At cursor.state "result" "RI" result.source rSlot
  aLive : a.Live cursor.state
  rLive : result.Live cursor.state
  aPositive : a.Positive
  rPositive : result.Positive
  aOrder : a.lo.mathematical.value ≤ a.hi.mathematical.value
  rOrder : result.lo.mathematical.value ≤ result.hi.mathematical.value
  exponentBound : n<2^32
  bitBound : bit<2^32
  arDistinct : aSlot≠rSlot
  nbDistinct : nSlot≠bitSlot

def left {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool) : Pair :=
  if fromA then f.a else f.result
def leftName (fromA : Bool) : String := if fromA then "a" else "result"
def product {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool) : Pair :=
  IntervalProductApplicability.output l f.cursor (left f fromA) f.result

theorem left_live {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool) :
    (left f fromA).Live f.cursor.state := by cases fromA <;> first | exact f.rLive | exact f.aLive
theorem left_positive {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool) :
    (left f fromA).Positive := by cases fromA <;> first | exact f.rPositive | exact f.aPositive
theorem left_binding {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool) :
    LocalBinding.At f.cursor.state (leftName fromA) "RI" (left f fromA).source (if fromA then f.aSlot else f.rSlot) := by
  cases fromA <;> first | exact f.rAt | exact f.aAt

def multiplied {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool)
    (room : f.cursor.top+79<PoolCalls.capacity) : Frame l n := by
  have aSafe:=LocalStorageSeparation.pool f.context f.aAt (by decide +kernel : ("RI":String)≠"unsigned")
  have nSafe:=LocalStorageSeparation.pool f.context f.nAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  have bSafe:=LocalStorageSeparation.pool f.context f.bitAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  have rSafe:=LocalStorageSeparation.pool f.context f.rAt (by decide +kernel : ("RI":String)≠"unsigned")
  have atA:=IntervalProductApplicability.binding (left f fromA) f.result f.aAt aSafe.1 aSafe.2.1 aSafe.2.2
  have atN:=IntervalProductApplicability.binding (left f fromA) f.result f.nAt nSafe.1 nSafe.2.1 nSafe.2.2
  have atB:=IntervalProductApplicability.binding (left f fromA) f.result f.bitAt bSafe.1 bSafe.2.1 bSafe.2.2
  have atR:=IntervalProductApplicability.binding (left f fromA) f.result f.rAt rSafe.1 rSafe.2.1 rSafe.2.2
  exact {
    cursor:=LocalAssignment.cursor (IntervalProductApplicability.next l f.cursor (left f fromA) f.result) f.rSlot "RI" (product f fromA).source
    a:=f.a
    result:=product f fromA
    bit:=f.bit
    aSlot:=f.aSlot
    nSlot:=f.nSlot
    bitSlot:=f.bitSlot
    rSlot:=f.rSlot
    context:=LocalAssignment.valid (IntervalProductApplicability.context f.context room (left f fromA) f.result)
      f.rSlot "RI" (product f fromA).source rSafe.1 rSafe.2.1 rSafe.2.2
    aAt:=LocalAssignment.other_binding (changedType:="RI") (value:=(product f fromA).source) atA f.arDistinct
    nAt:=LocalAssignment.other_binding (changedType:="RI") (value:=(product f fromA).source) atN
      (LocalStorageSeparation.typed f.nAt f.rAt (by decide +kernel))
    bitAt:=LocalAssignment.other_binding (changedType:="RI") (value:=(product f fromA).source) atB
      (LocalStorageSeparation.typed f.bitAt f.rAt (by decide +kernel))
    rAt:=LocalAssignment.binding atR (Pair.initialized _)
    aLive:=IntervalProductApplicability.preserves_pair (left f fromA) f.result f.aLive
    rLive:=IntervalProductApplicability.live l f.cursor (left f fromA) f.result
    aPositive:=f.aPositive
    rPositive:=IntervalProductApplicability.positive l f.cursor (left f fromA) f.result (left_positive f fromA) f.rPositive
    aOrder:=f.aOrder
    rOrder:=IntervalProductApplicability.order l f.cursor (left f fromA) f.result (left_positive f fromA) f.rPositive
    exponentBound:=f.exponentBound
    bitBound:=f.bitBound
    arDistinct:=f.arDistinct
    nbDistinct:=f.nbDistinct }

end ScopedC.IntervalPowerScan
