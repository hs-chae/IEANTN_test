/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderEntryEffects
import ScopedC.RationalScopeFraming
import ScopedC.SourceCeilQNormalizedTrace
import ScopedNumerical.BoxSound

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] radius

structure CeilLibrary (code : List Function) : Prop where
  entry : EntryLibrary code
  ceil : Generated.f_ceilQ∈code
  floor : Generated.f_floorQ∈code
  qn : Generated.f_qn∈code
  sn : Generated.f_sn∈code
  floorLibrary : FloorQNegativeCalls.Library code

structure CeilStage (code : List Function) (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) where
  out : Cursor
  endpoint : Endpoint
  execution : SourceCall Header.layout code 7 "ceilQ" [(radius l c a).source]
    (afterR l c a).state endpoint.source out.state
  valid : Valid l out
  live : endpoint.Live out.state
  value : endpoint.mathematical.value=ScopedNumerical.ProofBox.ceilDiv
    (radius l c a).mathematical.num.value (radius l c a).denominator
  values : List Nat
  trace : out=CursorFrames.advance l (afterR l c a) values
  count : values.length ≤ 8
  normalized : endpoint.magnitude=0 → endpoint.negative=false

theorem radius_nonnegative {l : PoolCalls.PoolLayout} {c : Cursor} (a : Pair) (positive : a.Positive) :
    0 ≤ (radius l c a).mathematical.value := by
  rw[radius_value a positive]
  exact le_trans (abs_nonneg _) (le_max_left _ _)

theorem ceil_stage (code : List Function) (lib : CeilLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair)
    (alive : a.Live c.state) (positive : a.Positive) (room : c.top+15<PoolCalls.capacity) :
    Nonempty (CeilStage code l c a) := by
  have rTop:=afterR_top l c a
  have rLive : (radius l c a).Live (afterR l c a).state :=
    Input.live_allocate (afterMax l c a).state (radius l c a) "Q" "r"
      (some (radius l c a).source) (radius_live a alive)
  obtain ⟨out,e,source,valid,live,value,heap,env,top,preserves,trace,normalized⟩:=
    SourceCeilQNormalizedTrace.ceilQ_closed_trace code lib.ceil lib.floor lib.qn lib.sn lib.floorLibrary
      (radius l c a) rLive (radius_positive a positive)
      (afterR_valid ctx a (by omega)) (by rw[rTop];omega)
  obtain ⟨values,count,binding⟩:=trace
  exact ⟨⟨out,e,source,valid,live,value,values,binding,count,normalized⟩⟩

theorem ceil_nonnegative {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) (positive : a.Positive) : 0 ≤ stage.endpoint.mathematical.value := by
  have denPositive:=radius_positive (l:=l) (c:=c) a positive
  have rational:=ScopedNumerical.ProofBox.le_ceilDiv (radius l c a).mathematical.num.value
    ((radius l c a).denominator:Int) (by exact_mod_cast (ne_of_gt denPositive))
  have current:=radius_nonnegative (l:=l) (c:=c) a positive
  rw[Input.value_eq] at current
  rw[stage.value]
  exact_mod_cast le_trans current rational

theorem ceil_sign {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) (positive : a.Positive) : stage.endpoint.negative=false := by
  have nonnegative:=ceil_nonnegative stage positive
  cases negative : stage.endpoint.negative with
  | false => rfl
  | true =>
    have zero : stage.endpoint.magnitude=0 := by
      change 0 ≤ (if stage.endpoint.negative then -(stage.endpoint.magnitude:Int) else stage.endpoint.magnitude) at nonnegative
      simp only[negative,↓reduceIte] at nonnegative
      omega
    simpa only[negative] using stage.normalized zero

end ScopedC.ExpRemainderCalls
