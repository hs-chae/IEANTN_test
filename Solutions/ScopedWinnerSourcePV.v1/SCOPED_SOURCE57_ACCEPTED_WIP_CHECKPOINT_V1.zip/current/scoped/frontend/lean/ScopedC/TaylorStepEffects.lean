/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorStepData

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem sum_binding {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length)
    {name ty : String} {v : Value} {slot : Nat} (h : LocalBinding.At f.cursor.state name ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    LocalBinding.At (sumCursor f hk).state name ty v slot := by
  have first : LocalBinding.At (productCursor f).state name ty v slot := by
    unfold productCursor
    exact IntervalProductApplicability.binding f.result f.a h hp ht hh
  unfold sumCursor
  exact RationalIntervalAddCalls.after_binding (c:=productCursor f) (pointInput f hk) (product f) first hp ht hh

theorem sum_preserves_pair {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) {p : Pair} (live : p.Live f.cursor.state) :
    p.Live (sumCursor f hk).state := by
  have first : p.Live (productCursor f).state := by
    unfold productCursor
    exact IntervalProductApplicability.preserves_pair f.result f.a live
  unfold sumCursor
  exact IntervalAddApplicability.preserves_pair (pointInput f hk) (product f) first

def sum_table {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    CoefficientTableRead.TableAt (sumCursor f hk).state base coeffs := by
  have first : CoefficientTableRead.TableAt (productCursor f).state base coeffs := by
    unfold productCursor IntervalProductApplicability.next
    exact CoefficientTableRead.after_rmul f.context f.table f.result f.a
  unfold sumCursor
  exact CoefficientTableRead.after_radd (product_context f room) first (pointInput f hk) (product f)

theorem sum_shape {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) :
    (sumCursor f hk).state.heap.length=f.cursor.state.heap.length ∧
    (sumCursor f hk).state.env=f.cursor.state.env := by
  have first : (productCursor f).state.heap.length=f.cursor.state.heap.length ∧
      (productCursor f).state.env=f.cursor.state.env := by
    unfold productCursor
    exact IntervalProductApplicability.shape l f.cursor f.result f.a
  unfold sumCursor
  exact ⟨(RationalIntervalAddCalls.after_heap_length l _ _ _).trans first.1,
    (RationalIntervalAddCalls.after_env l _ _ _).trans first.2⟩

theorem product_size {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : (productCursor f).state.nats.values.length=f.cursor.state.nats.values.length+80 := by
  unfold productCursor IntervalProductApplicability.next
  change (RationalIntervalMultiplyCalls.finish l f.cursor f.result f.a).state.nats.values.length=_
  unfold RationalIntervalMultiplyCalls.finish
  rw[RationalSelectionTree.size_finish]
  unfold RationalIntervalMultiplyCalls.middle
  rw[RationalSelectionTree.size_finish,RationalIntervalMultiplyCalls.size4]

theorem sum_size {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) :
    (sumCursor f hk).state.nats.values.length=f.cursor.state.nats.values.length+108 := by
  unfold sumCursor
  rw[RationalIntervalAddCalls.after_size,product_size]

end ScopedC.TaylorCalls
