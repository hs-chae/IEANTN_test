/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareLn2Front

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem two_source (code : List Function) (lib : FrontLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 2] c.state
      (two l c).source (afterTwo l c).state :=
  (RationalUnsignedTrace.qi_traced code lib.coefficients.unsigned.qi lib.coefficients.unsigned.si
    lib.coefficients.unsigned.productLibrary.smake lib.coefficients.unsigned.productLibrary.nz
    lib.coefficients.unsigned.productLibrary.nu lib.coefficients.unsigned.productLibrary.ne
    lib.coefficients.unsigned.productLibrary.keep ctx 2 (by decide +kernel) (by omega)
    (DecimalDigits.integer 2) (by rfl)).1

theorem point_source (code : List Function) (lib : FrontLibrary code)
    (l : PoolCalls.PoolLayout) (c : Cursor) :
    SourceCall Header.layout code 1 "point" [(two l c).source] (afterTwo l c).state
      (pointTwo l c).source (afterTwo l c).state := by
  have live:=RationalUnsignedTrace.live l c 2
  exact RationalPointCalls.point_closed code lib.point live.1 live.2 (SignedNegCalls.bit_bound _)

theorem one_source (code : List Function) (lib : FrontLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1] (afterTwo l c).state
      (one l c).source (afterOne l c).state :=
  (RationalUnsignedTrace.qi_traced code lib.coefficients.unsigned.qi lib.coefficients.unsigned.si
    lib.coefficients.unsigned.productLibrary.smake lib.coefficients.unsigned.productLibrary.nz
    lib.coefficients.unsigned.productLibrary.nu lib.coefficients.unsigned.productLibrary.ne
    lib.coefficients.unsigned.productLibrary.keep
    (afterTwo_valid ctx room)
    1 (by decide +kernel) (by change c.top+3+2<PoolCalls.capacity;omega)
    (DecimalDigits.integer 1) (by rfl)).1

theorem three_source (code : List Function) (lib : FrontLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 3] (afterOne l c).state
      (three l c).source (afterThree l c).state :=
  (RationalUnsignedTrace.qi_traced code lib.coefficients.unsigned.qi lib.coefficients.unsigned.si
    lib.coefficients.unsigned.productLibrary.smake lib.coefficients.unsigned.productLibrary.nz
    lib.coefficients.unsigned.productLibrary.nu lib.coefficients.unsigned.productLibrary.ne
    lib.coefficients.unsigned.productLibrary.keep
    (afterOne_valid ctx room)
    3 (by decide +kernel) (by change c.top+6+2<PoolCalls.capacity;omega)
    (DecimalDigits.integer 3) (by rfl)).1

theorem ratio_source (code : List Function) (lib : FrontLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) :
    SourceCall Header.layout code 7 "qv" [(one l c).source,(three l c).source]
      (afterThree l c).state (ratio l c).source (beforeAtanh l c).state := by
  unfold beforeAtanh
  exact RationalDivideCalls.output_source code lib.coefficients.qv lib.coefficients.division
    (afterThree_valid ctx room) (by change c.top+9+12<PoolCalls.capacity;omega) _ _
    ⟨CursorBorrow.preserves (l:=l) (c:=afterOne l c) [3,0,1] (RationalUnsignedTrace.live l (afterTwo l c) 1).1,
      CursorBorrow.preserves (l:=l) (c:=afterOne l c) [3,0,1] (RationalUnsignedTrace.live l (afterTwo l c) 1).2⟩
    (RationalUnsignedTrace.live l (afterOne l c) 3)
    (by change 0<(1:Nat);decide +kernel) (by change 0<(1:Nat);decide +kernel)

end ScopedC.PrepareSource.Ln2
