/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientExpData
import ScopedC.RationalPointBody
import ScopedC.SourceScalarGlobal

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

structure FrontLibrary (code : List Function) : Prop where
  coefficients : CoeffLibrary code
  point : Generated.f_point∈code

def two (l : PoolCalls.PoolLayout) (c : Cursor) : Input := RationalUnsignedTrace.output l c 2
def afterTwo (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := RationalUnsignedTrace.after l c 2
def pointTwo (l : PoolCalls.PoolLayout) (c : Cursor) : Pair := ⟨two l c,two l c⟩
def one (l : PoolCalls.PoolLayout) (c : Cursor) : Input := RationalUnsignedTrace.output l (afterTwo l c) 1
def afterOne (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := RationalUnsignedTrace.after l (afterTwo l c) 1
def three (l : PoolCalls.PoolLayout) (c : Cursor) : Input := RationalUnsignedTrace.output l (afterOne l c) 3
def afterThree (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := RationalUnsignedTrace.after l (afterOne l c) 3

noncomputable def ratio (l : PoolCalls.PoolLayout) (c : Cursor) : Input :=
  RationalDivideCalls.outputInput l (afterThree l c) (one l c) (three l c)
    (by change 0<(1:Nat);decide +kernel) (by change 0<(1:Nat);decide +kernel)

@[irreducible] def beforeAtanh (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor :=
  RationalDivideCalls.after l (afterThree l c) (one l c) (three l c)

theorem beforeAtanh_nonzero (l : PoolCalls.PoolLayout) (c : Cursor) :
    beforeAtanh l c=RationalDivideCalls.nonzeroAfter l (afterThree l c) (one l c) (three l c) := by
  unfold beforeAtanh RationalDivideCalls.after
  rw[if_neg (show (three l c).numerator.magnitude≠0 from by change (3:Nat)≠0;decide +kernel)]

theorem afterTwo_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) : Valid l (afterTwo l c) :=
  CursorFrames.advance_valid ctx [2,0,1] (by change c.top+3 ≤ PoolCalls.capacity;omega)

theorem afterOne_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) : Valid l (afterOne l c) :=
  CursorFrames.advance_valid (afterTwo_valid ctx room) [1,0,1]
    (by change c.top+3+3 ≤ PoolCalls.capacity;omega)

theorem afterThree_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) : Valid l (afterThree l c) :=
  CursorFrames.advance_valid (afterOne_valid ctx room) [3,0,1]
    (by change c.top+6+3 ≤ PoolCalls.capacity;omega)

theorem beforeAtanh_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) : Valid l (beforeAtanh l c) := by
  unfold beforeAtanh
  exact RationalDivideCalls.after_context (afterThree_valid ctx room)
    (by change c.top+9+12<PoolCalls.capacity;omega) _ _

theorem ratio_live (l : PoolCalls.PoolLayout) (c : Cursor) : (ratio l c).Live (beforeAtanh l c).state := by
  unfold beforeAtanh
  exact (RationalDivideCalls.output_spec l (afterThree l c) (one l c) (three l c)
    (by change 0<(1:Nat);decide +kernel) (by change 0<(1:Nat);decide +kernel)).2.1

theorem ratio_positive (l : PoolCalls.PoolLayout) (c : Cursor) : 0<(ratio l c).denominator :=
  (RationalDivideCalls.output_spec l (afterThree l c) (one l c) (three l c)
    (by change 0<(1:Nat);decide +kernel) (by change 0<(1:Nat);decide +kernel)).2.2.2

theorem ratio_value (l : PoolCalls.PoolLayout) (c : Cursor) : (ratio l c).mathematical.value=(1/3:Rat) := by
  have value : (ratio l c).mathematical.value=(one l c).mathematical.value/(three l c).mathematical.value:=
    (RationalDivideCalls.output_spec l (afterThree l c) (one l c) (three l c)
      (by change 0<(1:Nat);decide +kernel) (by change 0<(1:Nat);decide +kernel)).2.2.1
  have oneValue : (one l c).mathematical.value=1:=(RationalUnsignedTrace.mathematical l (afterTwo l c) 1).1
  have threeValue : (three l c).mathematical.value=3:=(RationalUnsignedTrace.mathematical l (afterOne l c) 3).1
  rw[value,oneValue,threeValue]

theorem pointTwo_live {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) : (pointTwo l c).Live (beforeAtanh l c).state := by
  have first:=(RationalUnsignedTrace.live l c 2)
  have one : (two l c).Live (afterOne l c).state:=
    ⟨CursorBorrow.preserves (l:=l) (c:=afterTwo l c) [1,0,1] first.1,
      CursorBorrow.preserves (l:=l) (c:=afterTwo l c) [1,0,1] first.2⟩
  have second : (two l c).Live (afterThree l c).state:=
    ⟨CursorBorrow.preserves (l:=l) (c:=afterOne l c) [3,0,1] one.1,
      CursorBorrow.preserves (l:=l) (c:=afterOne l c) [3,0,1] one.2⟩
  have kept : (two l c).Live (beforeAtanh l c).state := by
    rw[beforeAtanh_nonzero]
    exact ⟨RationalDivideCalls.nonzero_borrow _ _ second.1,RationalDivideCalls.nonzero_borrow _ _ second.2⟩
  exact ⟨kept,kept⟩

theorem pointTwo_positive (l : PoolCalls.PoolLayout) (c : Cursor) : (pointTwo l c).Positive := by
  change 0<(1:Nat) ∧ 0<(1:Nat)
  exact ⟨by decide +kernel,by decide +kernel⟩

theorem pointTwo_value (l : PoolCalls.PoolLayout) (c : Cursor) :
    (pointTwo l c).lo.mathematical.value=2 ∧ (pointTwo l c).hi.mathematical.value=2 :=
  ⟨(RationalUnsignedTrace.mathematical l c 2).1,(RationalUnsignedTrace.mathematical l c 2).1⟩

end ScopedC.PrepareSource.Ln2
