/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerGuard

namespace ScopedC.UnsignedLocalSteps
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem decrement (service : Call) {s : State} {name : String} {slot n : Nat}
    (atN : LocalBinding.At s name "unsigned int" (word n) slot) (positive : 0<n) (bound : n<2^32)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    Eval Header.layout service (.binary "=" (.var name) (.binary "-" (.var name) (.nat 1))) s
      (LocalAssignment.changed s slot "unsigned int" (word (n-1))) (word (n-1)) := by
  have rhs:=ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 1 atN h0 h1 h2 h3)
    (show evalExpr Header.layout service 2 s (.nat 1)=some (DecimalDigits.integer 1,s) from rfl)
    (binary_sub_one s n positive bound)
  exact ⟨4,LocalAssignment.evaluate service 2 rhs atN
    (RationalUnsignedCalls.cast_parameter s (n-1) (by omega))⟩

theorem increment (service : Call) {s : State} {name : String} {slot n : Nat}
    (atN : LocalBinding.At s name "unsigned int" (word n) slot) (bound : n+1<2^32)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    Eval Header.layout service (.binary "=" (.var name) (.binary "+" (.var name) (.nat 1))) s
      (LocalAssignment.changed s slot "unsigned int" (word (n+1))) (word (n+1)) := by
  have rhs:=ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 1 atN h0 h1 h2 h3)
    (show evalExpr Header.layout service 2 s (.nat 1)=some (DecimalDigits.integer 1,s) from rfl)
    (binary_add_one s n bound)
  exact ⟨4,LocalAssignment.evaluate service 2 rhs atN (RationalUnsignedCalls.cast_parameter s (n+1) bound)⟩

theorem positive_condition (service : Call) {s : State} {name : String} {slot n : Nat}
    (atN : LocalBinding.At s name "unsigned int" (word n) slot) (bound : n<2^32)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    Eval Header.layout service (.binary ">" (.var name) (.nat 0)) s s (boolean Header.layout (decide (0<n))) := by
  exact ⟨3,ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 1 atN h0 h1 h2 h3) (by rfl) (RationalPowerGuard.greater_zero s n bound)⟩

end ScopedC.UnsignedLocalSteps
