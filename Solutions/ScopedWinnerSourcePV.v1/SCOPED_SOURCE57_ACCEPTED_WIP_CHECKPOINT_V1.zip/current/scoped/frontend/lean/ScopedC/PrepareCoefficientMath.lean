/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorStepMathematics
import Lean

namespace ScopedC.PrepareSource
open ScopedC.RationalPairFrames (Input)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 100000

def expCoefficient (k : Nat) : Rat := 1/(k.factorial:Rat)
def atanhCoefficient (k : Nat) : Rat := if k%2=1 then 1/(k:Rat) else 0

theorem exp_zero : expCoefficient 0=1 := by norm_num [expCoefficient]
theorem atanh_zero : atanhCoefficient 0=0 := rfl

/-- The actual source qv update of the previous coefficient by qi(k) is the
unchanged reciprocal-factorial coefficient, with its real k>0 loop domain. -/
theorem exp_step (k : Nat) (positive : 0<k) :
    expCoefficient (k-1)/(k:Rat)=expCoefficient k := by
  have pred : k-1+1=k := by omega
  have factorial : k.factorial=k*(k-1).factorial := by
    simpa only[pred] using Nat.factorial_succ (k-1)
  unfold expCoefficient
  rw[factorial,Nat.cast_mul,div_div,mul_comm]

theorem values_append (coeffs : List Input) (q : Input) (f : Nat→Rat) (k : Nat)
    (before : TaylorCalls.coefficientValues coeffs=(List.range k).map f)
    (next : q.mathematical.value=f k) :
    TaylorCalls.coefficientValues (coeffs++[q])=(List.range (k+1)).map f := by
  change coeffs.map (fun q=>q.mathematical.value)=(List.range k).map f at before
  simp only[TaylorCalls.coefficientValues,List.map_append,List.map_cons,List.map_nil]
  rw[before,next]
  simp only[List.range_succ,List.map_append,List.map_cons,List.map_nil]

theorem old_atanh_values (d : Nat) :
    (List.range (d+1)).map atanhCoefficient=IntervalRat.atanhTaylorCoeffs d := rfl

/-- Reuses the existing kernel-checked coefficient identity in the pinned
original Taylor module, whose compiled private identity is recorded explicitly. -/
theorem old_exp_values (d : Nat) :
    (List.range (d+1)).map expCoefficient=IntervalRat.expTaylorCoeffs d := by
  run_tac
    Lean.Elab.Tactic.withMainContext do
      let decl ← Lean.Meta.getLocalDeclFromUserName `d
      let stem := Lean.Name.num `_private.LeanCert.Core.IntervalRat.Taylor 0
      let name := ["LeanCert","Core","IntervalRat","expTaylorCoeffs_eq_range_map"].foldl Lean.Name.str stem
      let proof := Lean.mkApp (Lean.mkConst name) (Lean.mkFVar decl.fvarId)
      (← Lean.Elab.Tactic.getMainGoal).assign (← Lean.Meta.mkEqSymm proof)
      Lean.Elab.Tactic.replaceMainGoal []

end ScopedC.PrepareSource
