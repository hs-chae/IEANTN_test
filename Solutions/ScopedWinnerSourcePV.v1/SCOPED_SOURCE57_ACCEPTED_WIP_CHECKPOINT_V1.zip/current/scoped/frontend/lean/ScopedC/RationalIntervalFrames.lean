/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalCompleteness
import ScopedC.RationalAddEffects
import ScopedC.LocalBinding
import ScopedC.IntervalCasts
namespace ScopedC.RationalIntervalFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure Pair where
  lo : Input
  hi : Input
namespace Pair
def source (a : Pair) : Value := IntervalCasts.value a.lo.source a.hi.source
def Live (s : State) (a : Pair) : Prop := a.lo.Live s ∧ a.hi.Live s
def Positive (a : Pair) : Prop := 0<a.lo.denominator ∧ 0<a.hi.denominator

theorem initialized (a : Pair) : Machine.initialized 1000 a.source=true := rfl

theorem cast {s : State} {a : Pair} (h : a.Live s) (ty : String) (ht : normalizeType ty="RI") :
    castValue Header.layout s 100 ty a.source=some a.source :=
  IntervalCasts.record s 96 ty ht a.lo.source a.hi.source
    (RecordCasts.rational_record s 96 "Q" (by decide +kernel) h.1.1 h.1.2 (SignedNegCalls.bit_bound _))
    (RecordCasts.rational_record s 96 "Q" (by decide +kernel) h.2.1 h.2.2 (SignedNegCalls.bit_bound _))

theorem live_add {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Input} {p : Pair} (h : p.Live c.state) :
    p.Live (RationalAddCalls.c14 l c a b).state :=
  ⟨⟨RationalAddCalls.preserves h.1.1,RationalAddCalls.preserves h.1.2⟩,
   ⟨RationalAddCalls.preserves h.2.1,RationalAddCalls.preserves h.2.2⟩⟩
end Pair

def frame (s : State) (a b : Pair) : State := TwoFrames.frame s "RI" "a" a.source "RI" "b" b.source
def framed (c : Cursor) (a b : Pair) : Cursor := CursorFrames.framed c "RI" "a" a.source "RI" "b" b.source

theorem bind {s : State} (a b : Pair) (ha : a.Live s) (hb : b.Live s) :
    bindArgs Header.layout [("RI","a"),("RI","b")] [a.source,b.source] s=some (frame s a b) :=
  TypedFrames.bind_two Header.layout s "RI" "a" "RI" "b" a.source b.source a.source b.source
    (Pair.cast (s:={s with env:=[]}) ha "RI" (by decide +kernel)) (Pair.cast (s:=allocate {s with env:=[]} "RI" "a" (some a.source)) hb "RI" (by decide +kernel))

theorem a_at (s : State) (a b : Pair) : LocalBinding.At (frame s a b) "a" "RI" a.source s.heap.length :=
  LocalBinding.allocate_other (LocalBinding.allocate_head {s with env:=[]} "a" "RI" a.source (Pair.initialized a))
    "b" "RI" (some b.source) (by decide +kernel)

theorem b_at (s : State) (a b : Pair) : LocalBinding.At (frame s a b) "b" "RI" b.source (s.heap.length+1) := by
  simpa only [frame,TwoFrames.frame,allocate,List.length_append,List.length_singleton] using
    LocalBinding.allocate_head (allocate {s with env:=[]} "RI" "a" (some a.source)) "b" "RI" b.source (Pair.initialized b)

theorem eval_lo (service : Call) (fuel : Nat) {s : State} {name : String} {p : Pair} {slot : Nat}
    (h : LocalBinding.At s name "RI" p.source slot)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+2) s (.field "." (.var name) "lo")=some (p.lo.source,s) := by
  apply ExpressionTemplates.field Header.layout service (LocalBinding.eval service fuel h h0 h1 h2 h3)
  rfl

theorem eval_hi (service : Call) (fuel : Nat) {s : State} {name : String} {p : Pair} {slot : Nat}
    (h : LocalBinding.At s name "RI" p.source slot)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+2) s (.field "." (.var name) "hi")=some (p.hi.source,s) := by
  apply ExpressionTemplates.field Header.layout service (LocalBinding.eval service fuel h h0 h1 h2 h3)
  rfl
end ScopedC.RationalIntervalFrames
