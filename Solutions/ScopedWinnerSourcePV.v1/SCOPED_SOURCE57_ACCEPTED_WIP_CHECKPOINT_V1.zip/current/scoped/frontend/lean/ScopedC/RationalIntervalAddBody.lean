/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalAddData
import ScopedC.CallEventPairs
namespace ScopedC.RationalIntervalAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

-- Proof-only transparency boundary; the exact source state is unchanged.
attribute [local irreducible] finish

def initializer : Expr := .record [
  .call (.var "qa") [.field "." (.var "a") "lo",.field "." (.var "b") "lo"],
  .call (.var "qa") [.field "." (.var "a") "hi",.field "." (.var "b") "hi"]]

/-- Execute both actual qa bodies and the actual RI initializer/return. The
lower-call service contains only already proved actual SourceCalls. -/
theorem radd_closed (code : List Function) (installed : Generated.f_radd∈code)
    (qaInstalled : Generated.f_qa∈code) (lib : RationalAddCalls.Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+27<PoolCalls.capacity)
    (a b : Pair) (ha : a.Live c.state) (hb : b.Live c.state) (pa : a.Positive) (pb : b.Positive) :
    SourceCall Header.layout code 7 "radd" [a.source,b.source] c.state (result l c a b) (after l c a b).state := by
  have ctx0 : Valid l (base c a b) := CursorFrames.framed_valid ctx "RI" "a" a.source "RI" "b" b.source
  have p1 : SourceCall Header.layout code 6 "qa" [a.lo.source,b.lo.source] (base c a b).state
      (low l c a b) (middle l c a b).state := by
    unfold middle low
    exact RationalAddCalls.qa_closed code qaInstalled lib (c:=base c a b) ctx0 (by change c.top+13<PoolCalls.capacity;omega)
      a.lo b.lo ha.1 hb.1 pa.1 pb.1
  have p2 : SourceCall Header.layout code 6 "qa" [a.hi.source,b.hi.source] (middle l c a b).state
      (high l c a b) (finish l c a b).state := by
    unfold finish high
    exact RationalAddCalls.qa_closed code qaInstalled lib (c:=middle l c a b) (middle_valid ctx room a b)
      (by rw[middle_top];omega) a.hi b.hi (middle_live (a:=a) (b:=b) ha).2 (middle_live (a:=a) (b:=b) hb).2 pa.2 pb.2
  let e1 : CallEvents.Event Header.layout code 6 :=
    ⟨"qa",[a.lo.source,b.lo.source],(base c a b).state,low l c a b,(middle l c a b).state,p1⟩
  let e2 : CallEvents.Event Header.layout code 6 :=
    ⟨"qa",[a.hi.source,b.hi.source],(middle l c a b).state,high l c a b,(finish l c a b).state,p2⟩
  have n : (middle l c a b).state.nats.values.length=(base c a b).state.nats.values.length+14 := by
    unfold middle
    rw[RationalAddCalls.trace,CursorEffects.size]
    rfl
  have distinct : (middle l c a b).state≠(base c a b).state := by
    intro h
    have z:=congrArg (fun s : State=>s.nats.values.length) h
    omega
  obtain ⟨service,h1,h2,closed⟩ := CallEvents.pair_service e1 e2 distinct
  have expression : evalExpr Header.layout service 1000 (base c a b).state initializer=
      some (.aggregate [low l c a b,high l c a b],(finish l c a b).state) :=
    ExpressionTemplates.record_two Header.layout service
      (ExpressionTemplates.call_two Header.layout service
        (RationalIntervalFrames.eval_lo service 996 (s:=(base c a b).state) (p:=a) (RationalIntervalFrames.a_at c.state a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
        (RationalIntervalFrames.eval_lo service 996 (s:=(base c a b).state) (p:=b) (RationalIntervalFrames.b_at c.state a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) h1)
      (ExpressionTemplates.call_two Header.layout service
        (RationalIntervalFrames.eval_hi service 996 (s:=(middle l c a b).state) (p:=a) (middle_a_at ctx a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
        (RationalIntervalFrames.eval_hi service 996 (s:=(middle l c a b).state) (p:=b) (middle_b_at ctx a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) h2)
  obtain ⟨ql,qls,qll,qlm,qlp⟩ := low_input l c a b pa pb
  obtain ⟨qh,qhs,qhl,qhm,qhp⟩ := high_input l c a b pa pb
  have qlf : ql.Live (finish l c a b).state := by
    unfold finish
    exact ⟨RationalAddCalls.preserves (c:=middle l c a b) (a:=a.hi) (b:=b.hi) qll.1,RationalAddCalls.preserves (c:=middle l c a b) (a:=a.hi) (b:=b.hi) qll.2⟩
  have cl : castValue Header.layout (finish l c a b).state 99 "Q" (low l c a b)=some (low l c a b) := by
    rw[←qls]
    exact RecordCasts.rational_record _ 96 "Q" (by decide +kernel) qlf.1 qlf.2 (SignedNegCalls.bit_bound _)
  have ch : castValue Header.layout (finish l c a b).state 99 "Q" (high l c a b)=some (high l c a b) := by
    rw[←qhs]
    exact RecordCasts.rational_record _ 96 "Q" (by decide +kernel) qhl.1 qhl.2 (SignedNegCalls.bit_bound _)
  have cast : castValue Header.layout (finish l c a b).state 100 "RI"
      (.aggregate [low l c a b,high l c a b])=some (result l c a b) :=
    IntervalCasts.aggregate _ 96 _ _ cl ch
  have init : Machine.initialized 1000 (result l c a b)=true := by
    unfold result
    rw[←qls,←qhs]
    rfl
  have shapes : (finish l c a b).state.heap.length=(middle l c a b).state.heap.length ∧
      (finish l c a b).state.env=(middle l c a b).state.env := by
    unfold finish
    exact RationalAddCalls.shape l (middle l c a b) a.hi b.hi
  have shapes0 : (middle l c a b).state.heap.length=(base c a b).state.heap.length ∧
      (middle l c a b).state.env=(base c a b).state.env := by
    unfold middle
    exact RationalAddCalls.shape l (base c a b) a.lo b.lo
  have len : (finish l c a b).state.heap.length=(base c a b).state.heap.length := shapes.1.trans shapes0.1
  have env : (finish l c a b).state.env=(base c a b).state.env := shapes.2.trans shapes0.2
  have body := DeclarationReturn.body Header.layout service "RI" "r" initializer expression cast init
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw[LocalScope.pop_local "RI" "r" (result l c a b) len env] at body
  apply installed_body (f:=Generated.f_radd) (rank:=6) (service:=service) installed
    closed
    (RationalIntervalFrames.bind a b ha hb) body
  exact ⟨IntervalCasts.record _ 96 "static RI" (by decide +kernel) _ _ cl ch,rfl⟩
end ScopedC.RationalIntervalAddCalls
