/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientTableRead
import ScopedC.RationalIntervalMultiplyEffects
import ScopedC.LocalAssignment

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Separation is derived from actual object types and array flags. -/
theorem pool_separated {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {base : Address} {coeffs : List Input} (table : TableAt c.state base coeffs) :
    base.object≠l.pool ∧ base.object≠l.top ∧ base.object≠l.high := by
  have separate : ∀slot ty cells flag,ty≠("Q":String) → c.state.heap[slot]?=some {type:=ty,cells:=cells,isArray:=flag} → base.object≠slot := by
    intro slot ty cells flag different storage same
    have original:=table.memory
    rw[same,storage] at original
    have types:=congrArg (fun x : Option Object=>x.map Object.type) original
    change some ty=some "Q" at types
    exact different (Option.some.inj types)
  exact ⟨separate _ "N" _ true (by decide +kernel) ctx.pool_read,
    separate _ "unsigned" _ false (by decide +kernel) ctx.top_read,
    separate _ "unsigned" _ false (by decide +kernel) ctx.high_read⟩

theorem local_separated {s : State} {base : Address} {coeffs : List Input} (table : TableAt s base coeffs)
    {name ty : String} {value : Value} {slot : Nat} (storage : LocalBinding.At s name ty value slot) :
    base.object≠slot := by
  intro same
  have original:=table.memory
  rw[same,storage.memory] at original
  have flags:=congrArg (fun x : Option Object=>x.map Object.isArray) original
  change some false=some true at flags
  contradiction

def allocated {s : State} {base : Address} {coeffs : List Input} (table : TableAt s base coeffs)
    (type name : String) (value : Option Value) : TableAt (allocate s type name value) base coeffs :=
  memory table (by
      have bound:=(List.getElem?_eq_some_iff.mp table.memory).choose
      exact List.getElem?_append_left bound)
    (fun _ _ h=>h)

def advanced {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {base : Address} {coeffs : List Input} (table : TableAt c.state base coeffs) (values : List Nat) :
    TableAt (CursorFrames.advance l c values).state base coeffs := by
  have safe:=pool_separated ctx table
  exact memory table (CursorSingleFrames.advance_other l c values base.object safe.1 safe.2.1 safe.2.2)
    (fun _ _ h=>CursorBorrow.preserves values h)

def local_store {s : State} {base : Address} {coeffs : List Input} (table : TableAt s base coeffs)
    {name ty : String} {old value : Value} {slot : Nat} (storage : LocalBinding.At s name ty old slot) :
    TableAt (LocalAssignment.changed s slot ty value) base coeffs := by
  have separate:=local_separated table storage
  exact memory table (by simp [LocalAssignment.changed,PoolCalls.storeObject,separate,Ne.symm separate]) (fun _ _ h=>h)

def after_radd {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {base : Address} {coeffs : List Input} (table : TableAt c.state base coeffs) (a b : Pair) :
    TableAt (RationalIntervalAddCalls.after l c a b).state base coeffs := by
  have safe:=pool_separated ctx table
  have bound:=(List.getElem?_eq_some_iff.mp table.memory).choose
  exact memory table (RationalIntervalAddCalls.after_other l c a b base.object bound safe.1 safe.2.1 safe.2.2)
    (fun _ _ h=>RationalIntervalAddCalls.preserves_nat a b h)

def after_rmul {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {base : Address} {coeffs : List Input} (table : TableAt c.state base coeffs) (a b : Pair) :
    TableAt (RationalIntervalMultiplyCalls.after l c a b).state base coeffs := by
  have safe:=pool_separated ctx table
  have bound:=(List.getElem?_eq_some_iff.mp table.memory).choose
  exact memory table (RationalIntervalMultiplyCalls.after_other l c a b base.object bound safe.1 safe.2.1 safe.2.2)
    (fun _ _ h=>RationalIntervalMultiplyCalls.preserves_nat a b h)

end ScopedC.CoefficientTableRead
