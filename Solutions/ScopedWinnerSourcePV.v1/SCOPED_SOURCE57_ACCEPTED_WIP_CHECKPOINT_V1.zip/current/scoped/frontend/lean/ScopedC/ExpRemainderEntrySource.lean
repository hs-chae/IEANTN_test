/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderEntry

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def radiusExpression : Expr := .call (.var "qmax")
  [.call (.var "qabs") [.field "." (.var "a") "lo"],
    .call (.var "qabs") [.field "." (.var "a") "hi"]]

theorem low_call (code : List Function) (lib : EntryLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (alive : a.Live c.state)
    (room : c.top+7<PoolCalls.capacity) :
    SourceCall Header.layout code 5 "qabs" [a.lo.source] (parameters c a).state
      (low a).source (afterLo l c a).state :=
  RationalAbsApplicability.source code lib.absolute (parameters_valid ctx a) a.lo alive.1 (by change c.top<PoolCalls.capacity;omega)

theorem high_call (code : List Function) (lib : EntryLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (alive : a.Live c.state)
    (room : c.top+7<PoolCalls.capacity) :
    SourceCall Header.layout code 5 "qabs" [a.hi.source] (afterLo l c a).state
      (high a).source (afterHi l c a).state :=
  RationalAbsApplicability.source code lib.absolute (afterLo_valid ctx a room) a.hi
    ⟨PoolCursor.preserves (l:=l) (c:=parameters c a) alive.2.1,
      PoolCursor.preserves (l:=l) (c:=parameters c a) alive.2.2⟩ (by change c.top+1<PoolCalls.capacity;omega)

theorem max_call (code : List Function) (lib : EntryLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (alive : a.Live c.state)
    (room : c.top+7<PoolCalls.capacity) :
    SourceCall Header.layout code 7 "qmax" [(low a).source,(high a).source] (afterHi l c a).state
      (radius l c a).source (afterMax l c a).state := by
  have lo : (low a).Live (afterHi l c a).state :=
    ⟨PoolCursor.preserves (RationalAbsApplicability.live (l:=l) (c:=parameters c a) alive.1).1,
      PoolCursor.preserves (RationalAbsApplicability.live (l:=l) (c:=parameters c a) alive.1).2⟩
  have hi : (high a).Live (afterHi l c a).state :=
    RationalAbsApplicability.live (l:=l) (c:=afterLo l c a)
      ⟨PoolCursor.preserves (l:=l) (c:=parameters c a) alive.2.1,
        PoolCursor.preserves (l:=l) (c:=parameters c a) alive.2.2⟩
  exact RationalSelectionTree.chosen_closed code lib.selection true (afterHi_valid ctx a room)
    (by change c.top+1+1+5<PoolCalls.capacity;omega) _ _ lo hi

theorem a_afterLo_binding {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) :
    LocalBinding.At (afterLo l c a).state "a" "RI" a.source c.state.heap.length := by
  have original:=parameters_binding c a
  have safe:=LocalStorageSeparation.pool (parameters_valid ctx a) original (by decide +kernel : ("RI":String)≠"unsigned")
  exact LocalBinding.advance original [0] safe.1 safe.2.1 safe.2.2

theorem radius_declaration (service : Call) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (a : Pair) (alive : a.Live c.state)
    (absLo : service "qabs" [a.lo.source] (parameters c a).state=
      some ((low a).source,(afterLo l c a).state))
    (absHi : service "qabs" [a.hi.source] (afterLo l c a).state=
      some ((high a).source,(afterHi l c a).state))
    (maximum : service "qmax" [(low a).source,(high a).source] (afterHi l c a).state=
      some ((radius l c a).source,(afterMax l c a).state)) :
    Declare Header.layout service [{type:="Q",name:="r",value:=some radiusExpression,arrayExtent:=none}]
      (parameters c a).state (afterR l c a).state := by
  have left:=ExpressionTemplates.call_one Header.layout service
    (RationalIntervalFrames.eval_lo service 996 (parameters_binding c a) (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)) absLo
  have right:=ExpressionTemplates.call_one Header.layout service
    (RationalIntervalFrames.eval_hi service 996 (a_afterLo_binding ctx a) (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)) absHi
  have expression : evalExpr Header.layout service 1000 (parameters c a).state radiusExpression=
      some ((radius l c a).source,(afterMax l c a).state) :=
    ExpressionTemplates.call_two Header.layout service left right maximum
  have cast:=Input.cast "Q" (by decide +kernel) (radius_live (l:=l) a alive)
  simp only[Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem bind_parameters (c : Cursor) (a : Pair) (alive : a.Live c.state) :
    bindArgs Header.layout [("RI","a")] [a.source] c.state=some (parameters c a).state :=
  TypedFrames.bind_one Header.layout c.state "RI" "a" a.source a.source
    (Pair.cast (s:={c.state with env:=[]}) (a:=a) alive "RI" (by decide +kernel))

end ScopedC.ExpRemainderCalls
