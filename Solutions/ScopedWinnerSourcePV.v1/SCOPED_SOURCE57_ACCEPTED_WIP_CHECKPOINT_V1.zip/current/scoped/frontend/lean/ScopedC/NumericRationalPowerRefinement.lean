/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerBody

namespace ScopedC.NumericRationalPowerRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Decode the actual source-produced Q into the same rational mathematical
representation used by the numerical refinement layer. This is exact rational
exponentiation, not a numerical certificate or independent power evaluator. -/
theorem qpow_math (code : List Function) (installed : Generated.f_qpow∈code)
    (lib : RationalPowerCalls.Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+706<PoolCalls.capacity) (a : Input) (n : Nat)
    (ha : a.Live c.state) (pa : 0<a.denominator) (hn : n<2^32) :
    ∃out : Cursor,∃q : Input,
      SourceCall Header.layout code 7 "qpow" [a.source,PoolCalls.word n] c.state q.source out.state ∧
      Valid l out ∧ q.Live out.state ∧
      NumericRepresentation.rational out.state q.source=some q.mathematical ∧
      q.mathematical.value=a.mathematical.value^n ∧ out.top ≤ c.top+707 := by
  obtain ⟨out,q,run,valid,live,positive,value,top⟩:=
    RationalPowerCalls.qpow_closed code installed lib ctx room a n ha pa hn
  exact ⟨out,q,run,valid,live,Input.decoded live positive,value,top⟩

end ScopedC.NumericRationalPowerRefinement
