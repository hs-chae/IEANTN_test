/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhEffects
import ScopedC.RationalSymmetricLocal

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

structure WideLibrary (code : List Function) : Prop where
  guard : GuardLibrary code
  qn : Generated.f_qn∈code
  sn : Generated.f_sn∈code

def wideFirst (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Input :=
  RationalUnsignedTrace.output l (afterGuard l c q) 1000

def wideC1 (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  RationalUnsignedTrace.after l (afterGuard l c q) 1000

def wideC2 (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  next l (wideC1 l c q) 0

def wideSecond (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Input :=
  RationalUnsignedTrace.output l (wideC2 l c q) 1000

def wideFinish (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  RationalUnsignedTrace.after l (wideC2 l c q) 1000

def widePair (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Pair :=
  ⟨RationalSubCalls.negative (wideFirst l c q),wideSecond l c q⟩

theorem wide_first_source (code : List Function) (lib : WideLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input)
    (room : c.top+16<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1000]
      (afterGuard l c q).state (wideFirst l c q).source (wideC1 l c q).state :=
  (RationalUnsignedTrace.qi_traced code lib.guard.powers.qi lib.guard.powers.si
    lib.guard.absolute.smake lib.guard.absolute.nz lib.guard.absolute.nu lib.guard.absolute.ne
    lib.guard.absolute.keep (guard_context ctx q (by omega)) 1000 (by decide +kernel)
    (by rw[guard_top];omega) (DecimalDigits.integer 1000) (by rfl)).1

theorem wideC1_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input)
    (room : c.top+16<PoolCalls.capacity) : Valid l (wideC1 l c q) :=
  CursorFrames.advance_valid (guard_context ctx q (by omega)) [1000,0,1]
    (by rw[guard_top];change c.top+10+3≤PoolCalls.capacity;omega)

theorem wideC1_top (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (wideC1 l c q).top=c.top+13 := by
  change (CursorFrames.advance l (afterGuard l c q) [1000,0,1]).top=_
  rw[CursorFrames.top_advance,guard_top]
  rfl

theorem wideC2_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input)
    (room : c.top+16<PoolCalls.capacity) : Valid l (wideC2 l c q) :=
  next_valid 0 (wideC1_valid ctx q room) (by rw[wideC1_top];omega)

theorem wide_neg_source (code : List Function) (lib : WideLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input)
    (room : c.top+16<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qn" [(wideFirst l c q).source]
      (wideC1 l c q).state (widePair l c q).lo.source (wideC2 l c q).state :=
  RationalSymmetricLocal.source_call code lib.qn lib.sn lib.guard.absolute.smake
    lib.guard.absolute.nz lib.guard.absolute.nu lib.guard.absolute.ne lib.guard.absolute.keep
    (wideC1_valid ctx q room) (by rw[wideC1_top];omega) (wideFirst l c q)
    (RationalUnsignedTrace.live l (afterGuard l c q) 1000) (by change 0<(1:Nat);decide +kernel)

theorem wide_second_source (code : List Function) (lib : WideLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input)
    (room : c.top+16<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1000]
      (wideC2 l c q).state (wideSecond l c q).source (wideFinish l c q).state :=
  (RationalUnsignedTrace.qi_traced code lib.guard.powers.qi lib.guard.powers.si
    lib.guard.absolute.smake lib.guard.absolute.nz lib.guard.absolute.nu lib.guard.absolute.ne
    lib.guard.absolute.keep (wideC2_valid ctx q room) 1000 (by decide +kernel)
    (by change (wideC1 l c q).top+1+2<PoolCalls.capacity;rw[wideC1_top];omega)
    (DecimalDigits.integer 1000) (by rfl)).1

attribute [local irreducible] afterGuard wideC1 wideC2

theorem wide_live (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (widePair l c q).Live (wideFinish l c q).state := by
  have firstRaw : (wideFirst l c q).Live (wideC1 l c q).state := by
    unfold wideC1
    exact RationalUnsignedTrace.live l (afterGuard l c q) 1000
  have first : (RationalSubCalls.negative (wideFirst l c q)).Live (wideC2 l c q).state := by
    unfold wideC2
    exact RationalSubCalls.negative_live
      (Input.live_after (l:=l) (c:=wideC1 l c q) firstRaw)
  exact ⟨⟨CursorBorrow.preserves (l:=l) (c:=wideC2 l c q) [1000,0,1] first.1,
    CursorBorrow.preserves (l:=l) (c:=wideC2 l c q) [1000,0,1] first.2⟩,
    RationalUnsignedTrace.live l (wideC2 l c q) 1000⟩

theorem wide_values (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (widePair l c q).lo.mathematical.value= -1000 ∧
      (widePair l c q).hi.mathematical.value=1000 := by
  constructor
  · change (RationalSubCalls.negative (wideFirst l c q)).mathematical.value=_
    rw[RationalSubCalls.negative_value]
    exact congrArg Neg.neg (RationalUnsignedTrace.mathematical l (afterGuard l c q) 1000).1
  · exact (RationalUnsignedTrace.mathematical l (wideC2 l c q) 1000).1

end ScopedC.AtanhCalls
