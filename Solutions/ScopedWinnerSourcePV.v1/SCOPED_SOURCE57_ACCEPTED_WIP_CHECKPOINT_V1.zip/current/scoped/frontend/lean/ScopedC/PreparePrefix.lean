/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientStage

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  coefficients : CoeffLibrary code
  scale : ScalePrelude.Library code

def preparePrefix : List Stmt := [
  .branch (.binary ">" (.var "d") (.nat 64)) (.eval (.call (.var "fail") [])) .skip,
  .eval (.binary "=" (.var "depth") (.var "d")),
  .eval (.binary "=" (.var "scale100")
    (.call (.var "nl") [.call (.var "nu") [.nat 1],.call (.var "nu") [.nat 100]])),
  .eval (.binary "=" (.index (.var "expCoeffs") (.nat 0)) (.call (.var "qi") [.nat 1])),
  .eval (.binary "=" (.index (.var "atanhCoeffs") (.nat 0)) (.call (.var "qi") [.nat 0])),
  .declare [{type:="unsigned int",name:="k",value:=some (.nat 1),arrayExtent:=none}],
  .whileLoop coefficientCondition coefficientBody]

def ln2Assignment : Expr := .binary "=" (.var "preparedLn2")
  (.call (.var "rmul") [.call (.var "point") [.call (.var "qi") [.nat 2]],
    .call (.var "atanhPoint") [.call (.var "qv")
      [.call (.var "qi") [.nat 1],.call (.var "qi") [.nat 3]]]])

/-- Exact original parsed body; only its final preparedLn2 assignment is
outside the already proved source prefix. -/
theorem prepare_source_prefix : Generated.f_prepare.body=
    .sequence (preparePrefix++[.eval ln2Assignment]) := rfl

structure PrefixAnswers (service : Call) {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) : Prop where
  scale : ScalePrelude.Answers service (layout base) (depthCursor ready d)
  one : service "qi" [DecimalDigits.integer 1] (actualSeed ready d bound).cursor.state=
    some ((initOne (actualSeed ready d bound)).source,(initOneCursor (actualSeed ready d bound)).state)
  zero : service "qi" [DecimalDigits.integer 0] (initExpCursor (actualSeed ready d bound)).state=
    some ((initZero (actualSeed ready d bound)).source,(initZeroCursor (actualSeed ready d bound)).state)
  loop : CoefficientEventAnswers service stage.loop.events

/-- Source sequence through the complete coefficient while. This is SeqRun,
so the original outer prepare scope remains open for its final ln2 assignment. -/
theorem prepare_prefix_run (service : Call) {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) (answers : PrefixAnswers service stage) :
    Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      preparePrefix (parameters (staticCursor ready) d).state
      (.continuing stage.loop.finish.cursor.state) := by
  have guard:=guard_skip service (staticCursor ready) d bound
  have depth:=depth_assignment service (staticCursor ready) d ready.depth bound
  have scale:=ScalePrelude.source_assignment service (depthSeed ready d bound).context
    (depth_scale_raw ready d) (depth_scale_unshadowed ready d) answers.scale
  have one:=initExp_assignment service (actualSeed ready d bound) answers.one
  have zero:=initAtanh_assignment service (actualSeed ready d bound)
    (by rw[actualSeed_top];decide +kernel) answers.zero
  have counter:=initCounter_declaration service (actualSeed ready d bound)
    (by rw[actualSeed_top];decide +kernel)
  exact Loops.SeqRun.next guard (Loops.SeqRun.next (Loops.StmtRun.evaluate depth)
    (Loops.SeqRun.next (Loops.StmtRun.evaluate scale)
      (Loops.SeqRun.next (Loops.StmtRun.evaluate one)
        (Loops.SeqRun.next (Loops.StmtRun.evaluate zero)
          (Loops.SeqRun.next (Loops.StmtRun.declare counter)
            (Loops.SeqRun.next (Loops.StmtRun.whileLoop (stage.loop.execution service answers.loop))
              (Loops.SeqRun.nil _)))))))

end ScopedC.PrepareSource
