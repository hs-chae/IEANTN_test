/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalDecimalLiteralEffects
import ScopedC.LocalBindingSeparation
namespace ScopedC.RationalRecordFields
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def value (lo hi : Value) : Value := .record "RI" [lo,hi]
def object (lo hi : Value) : Object := {type:="RI",cells:=[some (value lo hi)]}
/-- Physical local storage permits the source's not-yet-initialized opposite
field. This predicate does not authorize reading that field or the whole RI. -/
structure At (s : State) (lo hi : Value) (slot : Nat) : Prop where
  lookup : s.env.lookup "r"=some ⟨slot,0,[]⟩
  memory : s.heap[slot]?=some (object lo hi)
def changed (s : State) (slot : Nat) (lo hi : Value) : State :=
  {s with heap:=s.heap.set slot (object lo hi)}

theorem lvalue_lo (service : Call) (fuel : Nat) {s : State} {lo hi : Value} {slot : Nat}
    (h : At s lo hi slot) :
    evalLValue Header.layout service (fuel+2) s (.field "." (.var "r") "lo")=
      some (⟨slot,0,["lo"]⟩,true,s) := by
  simp [evalLValue,getVar,h.lookup,h.memory,object,Header.layout,Header.records,
    Header.typeDeclarations,fieldsOf,typeAt,addressType,normalizeType,stripPrefix,hasPrefix,List.lookup]

theorem lvalue_hi (service : Call) (fuel : Nat) {s : State} {lo hi : Value} {slot : Nat}
    (h : At s lo hi slot) :
    evalLValue Header.layout service (fuel+2) s (.field "." (.var "r") "hi")=
      some (⟨slot,0,["hi"]⟩,true,s) := by
  simp [evalLValue,getVar,h.lookup,h.memory,object,Header.layout,Header.records,
    Header.typeDeclarations,fieldsOf,typeAt,addressType,normalizeType,stripPrefix,hasPrefix,List.lookup]

theorem write_lo {s : State} {lo hi next : Value} {slot : Nat}
    (h : At s lo hi slot)
    (cast : castValue Header.layout s 100 "Q" next=some next) :
    write Header.layout s ⟨slot,0,["lo"]⟩ true next=
      some (next,changed s slot next hi) := by
  have address : addressType Header.layout s ⟨slot,0,["lo"]⟩=some "Q" := by
    have fieldType : typeAt Header.layout "RI" ["lo"]=some "Q" := by decide +kernel
    simpa only [addressType,h.memory,object,List.length_cons,List.length_nil,
      Nat.zero_lt_succ,↓reduceIte,Bind.bind,Option.bind] using fieldType
  have replace : replaceNested Header.layout (value lo hi) ["lo"] next=
      some (value next hi) := by
    have fields : fieldsOf Header.layout "RI"=some [("lo","Q"),("hi","Q")] := by decide +kernel
    have index : ([("lo","Q"),("hi","Q")] : List (String×String)).findIdx?
        (fun x=>x.1=="lo")=some 0 := by decide +kernel
    simp only [value,replaceNested,fields,index,Bind.bind,Option.bind,List.getElem?_cons_zero]
    rfl
  unfold write
  rw [address]
  simp only [Bool.not_true,Bool.false_eq_true,↓reduceIte,Bind.bind,Option.bind]
  rw [cast,h.memory]
  simp only [object,List.getElem?_cons_zero,Bind.bind,Option.bind]
  rw [replace]
  rfl

theorem write_hi {s : State} {lo hi next : Value} {slot : Nat}
    (h : At s lo hi slot)
    (cast : castValue Header.layout s 100 "Q" next=some next) :
    write Header.layout s ⟨slot,0,["hi"]⟩ true next=
      some (next,changed s slot lo next) := by
  have address : addressType Header.layout s ⟨slot,0,["hi"]⟩=some "Q" := by
    have fieldType : typeAt Header.layout "RI" ["hi"]=some "Q" := by decide +kernel
    simpa only [addressType,h.memory,object,List.length_cons,List.length_nil,
      Nat.zero_lt_succ,↓reduceIte,Bind.bind,Option.bind] using fieldType
  have replace : replaceNested Header.layout (value lo hi) ["hi"] next=
      some (value lo next) := by
    have fields : fieldsOf Header.layout "RI"=some [("lo","Q"),("hi","Q")] := by decide +kernel
    have index : ([("lo","Q"),("hi","Q")] : List (String×String)).findIdx?
        (fun x=>x.1=="hi")=some 1 := by decide +kernel
    simp only [value,replaceNested,fields,index,Bind.bind,Option.bind,
      List.getElem?_cons_succ,List.getElem?_cons_zero]
    rfl
  unfold write
  rw [address]
  simp only [Bool.not_true,Bool.false_eq_true,↓reduceIte,Bind.bind,Option.bind]
  rw [cast,h.memory]
  simp only [object,List.getElem?_cons_zero,Bind.bind,Option.bind]
  rw [replace]
  rfl

theorem source_lo (service : Call) (fuel : Nat) {before middle : State}
    {lo hi next : Value} {slot : Nat} {rhs : Syntax.Expr}
    (right : evalExpr Header.layout service (fuel+2) before rhs=some (next,middle))
    (h : At middle lo hi slot)
    (cast : castValue Header.layout middle 100 "Q" next=some next) :
    evalExpr Header.layout service (fuel+3) before
      (.binary "=" (.field "." (.var "r") "lo") rhs)=
      some (next,changed middle slot next hi) := by
  rw [evalExpr,right]
  simp only [Bind.bind,Option.bind]
  rw [lvalue_lo service fuel h]
  exact write_lo h cast

theorem source_hi (service : Call) (fuel : Nat) {before middle : State}
    {lo hi next : Value} {slot : Nat} {rhs : Syntax.Expr}
    (right : evalExpr Header.layout service (fuel+2) before rhs=some (next,middle))
    (h : At middle lo hi slot)
    (cast : castValue Header.layout middle 100 "Q" next=some next) :
    evalExpr Header.layout service (fuel+3) before
      (.binary "=" (.field "." (.var "r") "hi") rhs)=
      some (next,changed middle slot lo next) := by
  rw [evalExpr,right]
  simp only [Bind.bind,Option.bind]
  rw [lvalue_hi service fuel h]
  exact write_hi h cast

theorem binding {s : State} {lo hi : Value} {slot : Nat} (old : At s lo hi slot)
    (newLo newHi : Value) : At (changed s slot newLo newHi) newLo newHi slot := by
  have bound := (List.getElem?_eq_some_iff.mp old.memory).choose
  constructor
  · exact old.lookup
  · simp only [changed,List.getElem?_set_self bound]

theorem separated {l : PoolLayout} {c : Cursor} {lo hi : Value} {slot : Nat}
    (ctx : Valid l c) (h : At c.state lo hi slot) :
    slot≠l.pool ∧ slot≠l.top ∧ slot≠l.high := by
  have hp : slot≠l.pool := by
    intro same
    have memory := h.memory
    rw [same,ctx.pool_read] at memory
    have types := congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "N"=some "RI" at types
    contradiction
  have counter (i n : Nat) (other : c.state.heap[i]?=some (counterObject n)) : slot≠i := by
    intro same
    have memory := h.memory
    rw [same,other] at memory
    have types := congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "unsigned"=some "RI" at types
    contradiction
  exact ⟨hp,counter l.top c.top ctx.top_read,counter l.high c.high ctx.high_read⟩

theorem valid {l : PoolLayout} {c : Cursor} {lo hi : Value} {slot : Nat}
    (ctx : Valid l c) (h : At c.state lo hi slot) (newLo newHi : Value) :
    Valid l {c with state:=changed c.state slot newLo newHi} := by
  have safe := separated ctx h
  constructor
  · exact ctx.global_pool
  · exact ctx.global_top
  · exact ctx.global_high
  · simpa only [changed,List.getElem?_set_ne safe.1] using ctx.pool_read
  · simpa only [changed,List.getElem?_set_ne safe.2.1] using ctx.top_read
  · simpa only [changed,List.getElem?_set_ne safe.2.2] using ctx.high_read
  · exact ctx.extent
  · exact ctx.high_range
  · exact ctx.top_range

end ScopedC.RationalRecordFields
