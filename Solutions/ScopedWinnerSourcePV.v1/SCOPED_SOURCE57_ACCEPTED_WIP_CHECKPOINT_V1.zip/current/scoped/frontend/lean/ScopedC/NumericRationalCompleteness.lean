/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericInputCompleteness
namespace ScopedC.NumericInputCompleteness
open ScopedC.Machine ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

/-- A successfully decoded rational has an actual live source record with a
positive denominator. This is inversion of a checked representation, not an
assumption that an application computation returns a correct output. -/
theorem rational {s : State} {v : Value} {q : Rational}
    (h : NumericRepresentation.rational s v=some q) :
    ∃a : Input,a.source=v ∧ a.Live s ∧ a.mathematical=q ∧ 0<a.denominator := by
  unfold NumericRepresentation.rational at h
  split at h
  · rename_i tag num slot
    by_cases ht : tag="Q"
    · cases hn : NumericRepresentation.signed s num with
      | none => simp [ht,hn] at h
      | some n =>
        cases hd : NatArena.read s.nats slot with
        | none => simp [ht,hn,hd] at h
        | some d =>
          by_cases hp : 0<d
          · have hq : (⟨n,d⟩:Rational)=q := by simpa [ht,hn,hd,hp] using h
            obtain ⟨e,he,hl,hm⟩ := signed hn
            refine ⟨⟨e,slot,d⟩,?_,⟨hl,borrow_of_read hd⟩,?_,hp⟩
            · change Value.record "Q" [e.source,.natObject slot]=_
              rw [he,ht]
            · change (⟨e.mathematical,d⟩:Rational)=q
              rw [hm]
              exact hq
          · simp [ht,hn,hd,hp] at h
    · simp [ht] at h
  · contradiction
end ScopedC.NumericInputCompleteness
