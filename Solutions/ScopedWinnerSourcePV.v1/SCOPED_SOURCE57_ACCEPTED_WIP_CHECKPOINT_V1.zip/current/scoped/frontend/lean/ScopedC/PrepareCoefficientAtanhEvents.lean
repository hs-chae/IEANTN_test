/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientAtanhRun
import ScopedC.PrepareCoefficientEffects
import ScopedC.CallEventTimeline
import ScopedC.SourceRanks

namespace ScopedC.PrepareSource.CoeffWork
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

abbrev AtanhEvent (code : List Function) := CallEvents.Event Header.layout code 7
abbrev AtanhEventAnswers {code : List Function} (service : Call) (events : List (AtanhEvent code)) : Prop :=
  ∀e∈events,service e.name e.args e.before=some (e.value,e.after)

noncomputable def atanhEvents (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity)
    (positive : 0<w.k) (kb : w.k<2^32) : List (AtanhEvent code) :=
  if w.k%2=1 then [
    ⟨"qi",[DecimalDigits.integer 1],w.cursor.state,(w.qiInput 1).source,(w.oddOne room).cursor.state,
      SourceRanks.monotone (by decide +kernel)
        (w.qi_source code lib 1 (by decide +kernel) (by omega) (DecimalDigits.integer 1) (by rfl))⟩,
    ⟨"qi",[PoolCalls.word w.k],(w.oddOne room).cursor.state,((w.oddOne room).qiInput w.k).source,
      (w.oddCounter room).cursor.state,SourceRanks.monotone (by decide +kernel)
        ((w.oddOne room).qi_source code lib w.k kb
          (by change w.cursor.top+3+2<PoolCalls.capacity;omega) (PoolCalls.word w.k)
          (RationalUnsignedCalls.cast_parameter (w.oddOne room).cursor.state w.k kb))⟩,
    ⟨"qv",[(w.qiInput 1).source,((w.oddOne room).qiInput w.k).source],
      (w.oddCounter room).cursor.state,(w.oddInput room).source,(w.oddWork room positive).cursor.state,
      w.oddDivide_source code lib room positive⟩]
  else [⟨"qi",[DecimalDigits.integer 0],w.cursor.state,(w.qiInput 0).source,
    (w.qiWork 0 (by omega)).cursor.state,SourceRanks.monotone (by decide +kernel)
      (w.qi_source code lib 0 (by decide +kernel) (by omega) (DecimalDigits.integer 0) (by rfl))⟩]

theorem atanhEvents_answers (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity)
    (positive : 0<w.k) (kb : w.k<2^32) (service : Call)
    (answers : AtanhEventAnswers service (w.atanhEvents code lib room positive kb)) :
    AtanhAnswers service w room positive := by
  by_cases odd : w.k%2=1
  · simp only[atanhEvents,if_pos odd] at answers
    exact ⟨fun _=>answers _ List.mem_cons_self,
      fun _=>answers _ (List.mem_cons_of_mem _ List.mem_cons_self),
      fun _=>answers _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self)),
      fun even=>False.elim (even odd)⟩
  · simp only[atanhEvents,if_neg odd] at answers
    exact ⟨fun h=>False.elim (odd h),fun h=>False.elim (odd h),fun h=>False.elim (odd h),
      fun _=>answers _ List.mem_cons_self⟩

theorem oddOne_size {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) :
    (w.oddOne room).cursor.state.nats.values.length=w.cursor.state.nats.values.length+3 := by
  change (CursorFrames.advance l w.cursor [1,0,1]).state.nats.values.length=_
  rw[CursorEffects.size]
  rfl

theorem oddCounter_size {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) :
    (w.oddCounter room).cursor.state.nats.values.length=w.cursor.state.nats.values.length+6 := by
  change (CursorFrames.advance l (w.oddOne room).cursor [w.k,0,1]).state.nats.values.length=_
  rw[CursorEffects.size,oddOne_size]
  rfl

theorem atanhEvents_unique (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity)
    (positive : 0<w.k) (kb : w.k<2^32) :
    ((w.atanhEvents code lib room positive kb).map CallEvents.timeKey).Nodup := by
  by_cases odd : w.k%2=1
  · simp only[atanhEvents,if_pos odd]
    change [w.cursor.state.nats.values.length,(w.oddOne room).cursor.state.nats.values.length,
      (w.oddCounter room).cursor.state.nats.values.length].Nodup
    rw[oddOne_size,oddCounter_size]
    simp only[List.nodup_cons,List.mem_cons,List.mem_singleton,List.not_mem_nil,
      not_or,not_false_eq_true,List.nodup_nil,and_true]
    omega
  · simp only[atanhEvents,if_neg odd]
    exact List.nodup_singleton _

theorem atanhEvents_bounds (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity)
    (positive : 0<w.k) (kb : w.k<2^32) (bound : w.atanhCoeffs.length<65)
    (e : AtanhEvent code) (member : e∈w.atanhEvents code lib room positive kb) :
    w.cursor.state.nats.values.length ≤ e.before.nats.values.length ∧
      e.before.nats.values.length<(w.atanhWritten room positive bound).cursor.state.nats.values.length := by
  have finish:=w.atanhWritten_size room positive bound
  have one:=w.oddOne_size room
  have counter:=w.oddCounter_size room
  by_cases odd : w.k%2=1
  · simp only[atanhEvents,if_pos odd,List.mem_cons,List.mem_singleton,List.not_mem_nil,or_false] at member
    rw[if_pos odd] at finish
    rcases member with rfl|rfl|rfl <;> dsimp only <;> omega
  · simp only[atanhEvents,if_neg odd,List.mem_singleton] at member
    rw[if_neg odd] at finish
    subst e
    change w.cursor.state.nats.values.length ≤ w.cursor.state.nats.values.length ∧
      w.cursor.state.nats.values.length<(w.atanhWritten room positive bound).cursor.state.nats.values.length
    omega

end ScopedC.PrepareSource.CoeffWork
