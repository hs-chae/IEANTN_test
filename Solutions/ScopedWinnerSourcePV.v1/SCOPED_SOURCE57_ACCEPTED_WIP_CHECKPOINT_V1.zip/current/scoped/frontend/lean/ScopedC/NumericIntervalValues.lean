/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalFrames

namespace ScopedC.RationalIntervalFrames.Pair
open ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem values_of_decoded {s : State} {pair : RationalIntervalFrames.Pair}
    (live : pair.Live s) (positive : pair.Positive) {value : LeanCert.Core.IntervalRat}
    (decoded : NumericRepresentation.interval s pair.source=some value) :
    pair.lo.mathematical.value=value.lo ∧ pair.hi.mathematical.value=value.hi := by
  have lo:=RationalPairFrames.Input.decoded live.1 positive.1
  have hi:=RationalPairFrames.Input.decoded live.2 positive.2
  simp [NumericRepresentation.interval,source,IntervalCasts.value,lo,hi] at decoded
  obtain ⟨order,same⟩:=decoded
  cases same
  exact ⟨rfl,rfl⟩

end ScopedC.RationalIntervalFrames.Pair
