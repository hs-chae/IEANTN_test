/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerFrame
import ScopedC.RationalPowerGuard

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

def condition : Expr := .binary ">" (.var "n") (.nat 0)
def oddCondition : Expr := .binary "==" (.binary "%" (.var "n") (.nat 2)) (.nat 1)

theorem condition_eval (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l) :
    Eval Header.layout service condition f.cursor.state f.cursor.state
      (boolean Header.layout (decide (0<f.exponent))) :=
  ⟨3,RationalPowerGuard.eval_condition service 0 f.nAt f.exponentBound⟩

theorem odd_eval (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l) :
    Eval Header.layout service oddCondition f.cursor.state f.cursor.state
      (boolean Header.layout (decide (f.exponent%2=1))) := by
  have remainder : evalExpr Header.layout service 3 f.cursor.state (.binary "%" (.var "n") (.nat 2))=
      some (PoolCalls.word (f.exponent%2),f.cursor.state) :=
    ExpressionTemplates.binary Header.layout service
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (LocalBinding.eval service 1 f.nAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
      (by rfl) (RationalPowerCounter.remainder f.cursor.state f.exponent f.exponentBound)
  exact ⟨4,ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    remainder (by rfl) (RationalPowerCounter.parity_one f.cursor.state f.exponent)⟩

end ScopedC.RationalPowerCalls
