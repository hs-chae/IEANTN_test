/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpFactorialFrame

namespace ScopedC.ExpFactorial
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def one (l : PoolCalls.PoolLayout) (c : Cursor) : Input := RationalUnsignedTrace.output l c 1
def afterOne (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := RationalUnsignedTrace.after l c 1
def afterFact (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor :=
  CursorLocals.allocated (afterOne l c) "Q" "fact" (one l c).source

def initial (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor :=
  CursorLocals.allocated (afterFact l c) "unsigned int" "k" (PoolCalls.word 1)

theorem fact_binding (l : PoolCalls.PoolLayout) (c : Cursor) :
    LocalBinding.At (afterFact l c).state "fact" "Q" (one l c).source c.state.heap.length := by
  have h:=LocalBinding.allocate_head (afterOne l c).state "fact" "Q" (one l c).source (by rfl)
  simpa only[afterFact,CursorLocals.allocated,afterOne,RationalUnsignedTrace.after,
    (CursorEffects.shape l c [1,0,1]).1] using h

theorem initial_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) : Valid l (initial l c) := by
  apply CursorLocals.allocated_valid
  apply CursorLocals.allocated_valid
  exact CursorFrames.advance_valid ctx [1,0,1] (by change c.top+3≤PoolCalls.capacity;omega)

theorem initial_frame {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) (object d : Nat)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (unshadowed : c.state.env.lookup "depth"=none)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (dBound : d≤64) :
    ∃f : Frame l object d,f.cursor=initial l c ∧ f.k=1 ∧ f.fact.mathematical.value=1 := by
  let f : Frame l object d := {
    cursor:=initial l c
    fact:=one l c
    k:=1
    factSlot:=c.state.heap.length
    kSlot:=c.state.heap.length+1
    context:=initial_valid ctx room
    factAt:=LocalBinding.allocate_other (fact_binding l c) "k" "unsigned int" _ (by decide +kernel)
    kAt:=by
      have h:=LocalBinding.allocate_head (afterFact l c).state "k" "unsigned int" (PoolCalls.word 1) (by rfl)
      simpa only[initial,afterFact,CursorLocals.allocated,allocate,List.length_append,List.length_singleton,
        afterOne,RationalUnsignedTrace.after,(CursorEffects.shape l c [1,0,1]).1] using h
    depthAt:=SourceUnsignedGlobal.allocated (SourceUnsignedGlobal.allocated
      (SourceUnsignedGlobal.advanced depth [1,0,1] apart.1 apart.2.1 apart.2.2) "Q" "fact" _)
      "unsigned int" "k" _
    depthUnshadowed:=by
      change (("k",_)::("fact",_)::(CursorFrames.advance l c [1,0,1]).state.env).lookup "depth"=none
      rw[(CursorEffects.shape l c [1,0,1]).2]
      simpa only[List.lookup,String.reduceBEq] using unshadowed
    live:=RationalUnsignedTrace.live l c 1
    positive:=by change 0<(1:Nat);decide +kernel
    kPositive:=by decide +kernel
    kBound:=by omega
    depthBound:=dBound
    depthApart:=apart }
  exact ⟨f,rfl,rfl,(RationalUnsignedTrace.mathematical l c 1).1⟩

theorem fact_declaration (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor)
    (answer : service "qi" [DecimalDigits.integer 1] c.state=
      some ((one l c).source,(afterOne l c).state)) :
    Declare Header.layout service [{type:="Q",name:="fact",value:=some (.call (.var "qi") [.nat 1]),arrayExtent:=none}]
      c.state (afterFact l c).state := by
  have expression:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 999 c.state (.nat 1)=some (DecimalDigits.integer 1,c.state) from rfl) answer
  have cast : castValue Header.layout (afterOne l c).state 100 "Q" (one l c).source=some (one l c).source :=
    Input.cast "Q" (by decide +kernel) (RationalUnsignedTrace.live l c 1)
  simp only[Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem k_declaration (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor) :
    Declare Header.layout service [{type:="unsigned int",name:="k",value:=some (.nat 1),arrayExtent:=none}]
      (afterFact l c).state (initial l c).state := by
  simp only[Declare,declarations,List.foldlM,evalExpr]
  have cast : castValue Header.layout (afterFact l c).state 100 "unsigned int" (DecimalDigits.integer 1)=some (PoolCalls.word 1) := rfl
  simp only[Bind.bind,Option.bind,cast]
  rfl

end ScopedC.ExpFactorial
