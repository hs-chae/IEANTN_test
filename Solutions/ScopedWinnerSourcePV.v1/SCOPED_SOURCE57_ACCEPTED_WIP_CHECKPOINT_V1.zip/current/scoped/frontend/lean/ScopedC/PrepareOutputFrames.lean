/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareBodySource
import ScopedC.GlobalPopFrames

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

theorem prepare_parameters_length {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) :
    (parameters (staticCursor ready) d).state.heap.length=state.heap.length+1 := by
  simp [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate,staticCursor]

noncomputable def finished_exp_table {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    CoefficientTableRead.TableAt (finished stage).state (expBase base) stage.coefficient.loop.finish.expCoeffs := by
  have old:=(List.getElem?_eq_some_iff.mp ready.exp.memory).choose
  let stored:=Ln2.stored_table stage.coefficient.loop.finish.context
    (by have room:=coefficient_finish_room stage.coefficient;omega) stage.atanh stage.rawLn2
    stage.coefficient.loop.finish.expAt
  exact CoefficientTableRead.unframe state
    (CoefficientTableRead.unframe (parameters (staticCursor ready) d).state stored
      (by rw[prepare_parameters_length];omega)) old

noncomputable def finished_atanh_table {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    CoefficientTableRead.TableAt (finished stage).state (atanhBase base) stage.coefficient.loop.finish.atanhCoeffs := by
  have old:=(List.getElem?_eq_some_iff.mp ready.atanh.memory).choose
  let stored:=Ln2.stored_table stage.coefficient.loop.finish.context
    (by have room:=coefficient_finish_room stage.coefficient;omega) stage.atanh stage.rawLn2
    stage.coefficient.loop.finish.atanhAt
  exact CoefficientTableRead.unframe state
    (CoefficientTableRead.unframe (parameters (staticCursor ready) d).state stored
      (by rw[prepare_parameters_length];omega)) old

theorem finished_scale {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    SourceFromS.ScaleAt (finished stage).state (base+4)
      (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100) := by
  have old:=(List.getElem?_eq_some_iff.mp ready.scaleMemory).choose
  have stored:=Ln2.stored_scale stage.coefficient.loop.finish.context
    (by have room:=coefficient_finish_room stage.coefficient;omega) stage.atanh stage.rawLn2 stage.scale
  exact (stored.unframe (parameters (staticCursor ready) d).state
    (by rw[prepare_parameters_length];omega)).unframe state old

theorem finished_depth {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    SourceUnsignedGlobal.At (finished stage).state "depth" (base+3) d := by
  have old:=(List.getElem?_eq_some_iff.mp ready.depth.storage).choose
  have stored:=Ln2.stored_depth stage.coefficient.loop.finish.context
    (by have room:=coefficient_finish_room stage.coefficient;omega) stage.atanh stage.rawLn2
    stage.coefficient.loop.finish.depthAt stage.coefficient.loop.finish.depthApart
  exact SourceUnsignedGlobal.unframe state
    (SourceUnsignedGlobal.unframe (parameters (staticCursor ready) d).state stored
      (by rw[prepare_parameters_length];omega)) old

theorem finished_ln2_storage {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    SourceScalarGlobal.At (finished stage).state "preparedLn2" "RI" (base+7) (some (Ln2.product stage.atanh).source) := by
  have old:=(List.getElem?_eq_some_iff.mp ready.ln2Memory).choose
  have stored:=Ln2.stored_at stage.coefficient.loop.finish.context
    (by have room:=coefficient_finish_room stage.coefficient;omega) stage.atanh stage.rawLn2
  exact SourceScalarGlobal.unframe state
    (SourceScalarGlobal.unframe (parameters (staticCursor ready) d).state stored
      (by rw[prepare_parameters_length];omega)) old

theorem finished_ln2_live {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    (Ln2.product stage.atanh).Live (finished stage).state :=
  Ln2.stored_live stage.atanh (base+7)

theorem finished_ln2_model {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    NumericRepresentation.interval (finished stage).state (Ln2.product stage.atanh).source=
      some (LeanCert.Core.IntervalRat.ln2Computable d) := by
  have same:=NumericNatsExtensionality.interval (s:=(Ln2.afterStore stage.atanh (base+7)).state)
    (t:=(finished stage).state) rfl (Ln2.product stage.atanh).source
  exact same.symm.trans (complete_stage_ln2 stage)

theorem finished_globals {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    (finished stage).state.globals=state.globals :=
  (Ln2.stored_globals stage.atanh (base+7)).trans stage.globals

theorem finished_exp_lookup {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    (finished stage).state.globals.lookup "expCoeffs"=some (expBase base) := by
  rw[finished_globals]
  exact ready.expLookup

theorem finished_atanh_lookup {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    (finished stage).state.globals.lookup "atanhCoeffs"=some (atanhBase base) := by
  rw[finished_globals]
  exact ready.atanhLookup

end ScopedC.PrepareSource
