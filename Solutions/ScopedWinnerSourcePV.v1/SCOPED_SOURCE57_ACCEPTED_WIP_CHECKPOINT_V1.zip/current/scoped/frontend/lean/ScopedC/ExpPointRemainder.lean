/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointTaylor

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

abbrev RemainderStage {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    (t : TaylorStage stage positive base coeffs d) :=
  ExpRemainderCalls.FramedResult code l t.out (inputPair stage positive) d
    (input_ordered stage positive)

theorem remainder_stage (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
    {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    (t : TaylorStage stage positive base coeffs d) (object : Nat)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object ≠ l.pool ∧ object ≠ l.top ∧ object ≠ l.high)
    (dBound : d ≤ 64) (room : c.top+16000 < PoolCalls.capacity) :
    Nonempty (RemainderStage t) := by
  have top := taylor_top t
  exact ExpRemainderCalls.expRemainder_framed code lib.expRemainder lib.remainder t.valid
    (inputPair stage positive) (taylor_input_live t) (input_positive stage positive)
    (input_ordered stage positive) d object (taylor_depth t depth apart) apart dBound
    (input_remainder_guard stage positive) (by omega)

theorem remainder_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    {t : TaylorStage stage positive base coeffs d} (r : RemainderStage t) :
    r.out.top ≤ c.top+3032+108*(d+1) := by
  have first := taylor_top t
  have second := r.top
  omega

theorem polynomial_remainder_live {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {q : Input} {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    {t : TaylorStage stage positive base coeffs d} (r : RemainderStage t) :
    t.output.Live r.out.state := r.pair t.live

theorem input_taylor_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    (t : TaylorStage stage positive base coeffs d) (room : c.top+40 < PoolCalls.capacity) :
    LocalBinding.At t.out.state "input" "RI" (inputPair stage positive).source
      (afterReduced stage positive).state.heap.length := by
  have before := input_binding stage positive
  have safe := LocalStorageSeparation.pool (input_valid stage positive room) before
    (by decide +kernel)
  exact LocalBinding.memory before t.env
    (t.other _ (List.getElem?_eq_some_iff.mp before.memory).choose safe.1 safe.2.1 safe.2.2)

end ScopedC.ExpPointCalls
