/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderPowers

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def numerator {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) : Input :=
  RationalProductApplicability.output l r.out p.output r.output

@[irreducible] def numeratorCursor {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) : Cursor :=
  RationalMultiplyCalls.c11 l r.out p.output r.output

theorem radius_power_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    r.out.top ≤ c.top+2347 := by
  have first:=p.top
  have second:=r.top
  change p.out.top ≤ (BeforeError f).top+3+707 at first
  have h:=factorial_top f
  have beforeTop : (BeforeError f).top ≤ c.top+930:=h
  omega

theorem numerator_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (room : c.top+3000<PoolCalls.capacity) : Valid l (numeratorCursor r) := by
  unfold numeratorCursor
  rw[RationalMultiplyTrace.c11_advance]
  apply CursorFrames.advance_valid r.valid
  change r.out.top+11 ≤ PoolCalls.capacity
  have top:=radius_power_top r
  omega

theorem numerator_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (numerator r).Live (numeratorCursor r).state := by
  unfold numeratorCursor
  exact RationalProductApplicability.live l r.out p.output r.output

theorem numerator_positive {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    0<(numerator r).denominator :=
  RationalProductApplicability.positive l r.out p.output r.output p.positive r.positive

theorem numerator_source (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} {f : FactorialStage code l c a object d ceil}
    {p : ThreePower f} (r : RadiusPower p) (room : c.top+3000<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qt" [p.output.source,r.output.source] r.out.state
      (numerator r).source (numeratorCursor r).state := by
  have firstLive : p.output.Live r.out.state:=⟨r.preserves _ _ p.live.1,r.preserves _ _ p.live.2⟩
  unfold numeratorCursor
  exact RationalMultiplyCalls.qt_closed code lib.qt lib.productLibrary r.valid
    (by have h:=radius_power_top r;omega) p.output r.output firstLive r.live p.positive r.positive

theorem numerator_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (positive : a.Positive) :
    (numerator r).mathematical.value=(3:Rat)^(ceil.endpoint.magnitude+1)*
      (max |a.lo.mathematical.value| |a.hi.mathematical.value|)^(d+1) := by
  unfold numerator
  rw[RationalProductApplicability.mathematical l r.out p.output r.output p.positive r.positive,
    three_power_value p,radius_power_value r positive]

end ScopedC.ExpRemainderCalls
