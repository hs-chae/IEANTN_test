/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientFrame
import ScopedC.CoefficientTableShapes
import ScopedC.RationalUnsignedTrace

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

/-- Real owned arrays and depth before the original two initial coefficient
stores. Empty prefixes assume no live rational value in the raw static cells. -/
structure CoeffSeed (l : PoolCalls.PoolLayout) (object d : Nat) (eb ab : Address) where
  cursor : Cursor
  context : Valid l cursor
  expAt : CoefficientTableRead.TableAt cursor.state eb []
  atanhAt : CoefficientTableRead.TableAt cursor.state ab []
  expExtent : expAt.cells.length=65
  atanhExtent : atanhAt.cells.length=65
  expLookup : cursor.state.globals.lookup "expCoeffs"=some eb
  atanhLookup : cursor.state.globals.lookup "atanhCoeffs"=some ab
  expUnshadowed : cursor.state.env.lookup "expCoeffs"=none
  atanhUnshadowed : cursor.state.env.lookup "atanhCoeffs"=none
  depthAt : SourceUnsignedGlobal.At cursor.state "depth" object d
  depthUnshadowed : cursor.state.env.lookup "depth"=none
  depthBound : d ≤ 64
  arraysApart : eb.object≠ab.object
  depthApart : object≠l.pool ∧ object≠l.top ∧ object≠l.high

def initOne {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) : Input := RationalUnsignedTrace.output l s.cursor 1

def initOneCursor {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) : Cursor := RationalUnsignedTrace.after l s.cursor 1

def initExpBefore {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) :
    CoefficientTableRead.TableAt (initOneCursor s).state eb [] :=
  CoefficientTableRead.advanced s.context s.expAt [1,0,1]

def initAtanhBefore {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) :
    CoefficientTableRead.TableAt (initOneCursor s).state ab [] :=
  CoefficientTableRead.advanced s.context s.atanhAt [1,0,1]

@[irreducible] def initExpCursor {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) : Cursor :=
  CoefficientTableRead.cursor (initOneCursor s) eb (initExpBefore s).cells 0 (initOne s)

theorem initOne_valid {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    Valid l (initOneCursor s) :=
  CursorFrames.advance_valid s.context [1,0,1] (by change s.cursor.top+3 ≤ PoolCalls.capacity;omega)

theorem initExp_valid {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    Valid l (initExpCursor s) := by
  unfold initExpCursor
  exact CoefficientTableRead.valid (initOne_valid s room) (initExpBefore s) 0 (initOne s)

def initExpTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) :
    CoefficientTableRead.TableAt (initExpCursor s).state eb [initOne s] := by
  unfold initExpCursor
  exact CoefficientTableRead.append (initExpBefore s) (initOne s) (RationalUnsignedTrace.live l s.cursor 1)
    (by change 0<(1:Nat);decide +kernel) (by
      change 0<(CoefficientTableRead.advanced s.context s.expAt [1,0,1]).cells.length
      rw[CoefficientTableRead.advanced_cells,s.expExtent]
      decide +kernel)

def initExpAtanhTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) :
    CoefficientTableRead.TableAt (initExpCursor s).state ab [] := by
  unfold initExpCursor
  exact CoefficientTableRead.other_table (initExpBefore s) (initAtanhBefore s) s.arraysApart 0 (initOne s)

def initZero {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) : Input := RationalUnsignedTrace.output l (initExpCursor s) 0

def initZeroCursor {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) : Cursor := RationalUnsignedTrace.after l (initExpCursor s) 0

theorem initZero_valid {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    Valid l (initZeroCursor s) := by
  apply CursorFrames.advance_valid (initExp_valid s room) [0,0,1]
  change (initExpCursor s).top+3 ≤ PoolCalls.capacity
  unfold initExpCursor
  change s.cursor.top+3+3 ≤ PoolCalls.capacity
  omega

def initZeroExpTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    CoefficientTableRead.TableAt (initZeroCursor s).state eb [initOne s] :=
  CoefficientTableRead.advanced (initExp_valid s room) (initExpTable s) [0,0,1]

def initZeroAtanhTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    CoefficientTableRead.TableAt (initZeroCursor s).state ab [] :=
  CoefficientTableRead.advanced (initExp_valid s room) (initExpAtanhTable s) [0,0,1]

@[irreducible] def initAtanhCursor {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) : Cursor :=
  CoefficientTableRead.cursor (initZeroCursor s) ab (initZeroAtanhTable s room).cells 0 (initZero s)

end ScopedC.PrepareSource
