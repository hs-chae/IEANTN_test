/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpFactorialEvents
import ScopedC.ExpFactorialCondition
import ScopedC.ExpFactorialEffects

namespace ScopedC.ExpFactorial
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

abbrev While (service : Call) :=
  Loops.WhileRun (Eval Header.layout service) (Declare Header.layout service) truth Scope condition loopBody

structure LoopCertificate (code : List Function) {l : PoolCalls.PoolLayout} {object d : Nat}
    (start : Frame l object d) where
  finish : Frame l object d
  events : List (Event code)
  unique : (events.map CallEvents.timeKey).Nodup
  bounds : ∀e∈events,start.cursor.state.nats.values.length  ≤  e.before.nats.values.length ∧
    e.before.nats.values.length < finish.cursor.state.nats.values.length
  nats_le : start.cursor.state.nats.values.length ≤ finish.cursor.state.nats.values.length
  execution : ∀service,EventAnswers service events → While service start.cursor.state (.continuing finish.cursor.state)
  stopped : finish.k=d+2
  mathematical : finish.fact.mathematical.value=((d+1).factorial:Rat)
  top : finish.cursor.top ≤ start.cursor.top+14*(d+2-start.k)
  shape : finish.cursor.state.heap.length=start.cursor.state.heap.length ∧ finish.cursor.state.env=start.cursor.state.env
  globals : finish.cursor.state.globals=start.cursor.state.globals
  preserves : ∀slot value,NatArena.Borrow start.cursor.state.nats slot value →
    NatArena.Borrow finish.cursor.state.nats slot value
  slots : finish.factSlot=start.factSlot ∧ finish.kSlot=start.kSlot
  other : ∀slot,slot≠start.factSlot → slot≠start.kSlot → slot≠l.pool → slot≠l.top → slot≠l.high →
    finish.cursor.state.heap[slot]?=start.cursor.state.heap[slot]?

/-- Every original factorial iteration executes its actual source qi/qt and
assignments. The stopping counter and exact factorial are proved by induction. -/
theorem loop_certificate (code : List Function) (lib : RationalPowerCalls.Library code) (n : Nat)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (remaining : f.k+n=d+2)
    (invariant : f.fact.mathematical.value=((f.k-1).factorial:Rat))
    (room : f.cursor.top+14*n ≤ PoolCalls.capacity) : Nonempty (LoopCertificate code f) := by
  induction n generalizing f with
  | zero =>
    have stopped : f.k=d+2 := by omega
    refine ⟨{
      finish:=f
      events:=[]
      unique:=by simp
      bounds:=by simp
      nats_le:=Nat.le_refl _
      execution:=?_
      stopped:=stopped
      mathematical:=by rw[stopped,show d+2-1=d+1 by omega] at invariant;exact invariant
      top:=by omega
      shape:=⟨rfl,rfl⟩
      globals:=rfl
      preserves:=fun _ _ live=>live
      slots:=⟨rfl,rfl⟩
      other:=fun _ _ _ _ _ _=>rfl }⟩
    intro service _
    exact Loops.WhileRun.done (condition_eval service f)
      (by simp [UnsignedLiteralControl.truth_boolean,stopped])
  | succ n ih =>
    have active : f.k ≤ d+1 := by omega
    have oneRoom : f.cursor.top+13<PoolCalls.capacity := by omega
    let next:=stepped f active oneRoom
    have nextRemaining : next.k+n=d+2 := by rw[stepped_k];omega
    have nextInvariant : next.fact.mathematical.value=((next.k-1).factorial:Rat) :=
      stepped_factorial f active oneRoom invariant
    have nextRoom : next.cursor.top+14*n ≤ PoolCalls.capacity := by
      rw[stepped_top]
      omega
    obtain ⟨tail⟩:=ih next nextRemaining nextInvariant nextRoom
    let front:=events code lib f oneRoom
    have nle : f.cursor.state.nats.values.length ≤ next.cursor.state.nats.values.length := by
      rw[stepped_size]
      omega
    have finishLower:=tail.nats_le
    refine ⟨{
      finish:=tail.finish
      events:=front++tail.events
      unique:=?_
      bounds:=?_
      nats_le:=nle.trans tail.nats_le
      execution:=?_
      stopped:=tail.stopped
      mathematical:=tail.mathematical
      top:=?_
      shape:=⟨tail.shape.1.trans (stepped_shape f active oneRoom).1,
        tail.shape.2.trans (stepped_shape f active oneRoom).2⟩
      globals:=tail.globals.trans (stepped_globals f active oneRoom)
      preserves:=fun _ _ live=>tail.preserves _ _ (stepped_borrow f active oneRoom live)
      slots:=⟨tail.slots.1.trans (stepped_slots f active oneRoom).1,
        tail.slots.2.trans (stepped_slots f active oneRoom).2⟩
      other:=?_ }⟩
    · rw[List.map_append,List.nodup_append]
      refine ⟨events_unique code lib f oneRoom,tail.unique,?_⟩
      intro a ha b hb same
      obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
      obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
      have keyEq:=ka.trans (same.trans kb.symm)
      change ea.before.nats.values.length=eb.before.nats.values.length at keyEq
      have left:=events_bounds code lib f active oneRoom ea hea
      have right:=tail.bounds eb heb
      change f.cursor.state.nats.values.length ≤ ea.before.nats.values.length ∧
        ea.before.nats.values.length < next.cursor.state.nats.values.length at left
      omega
    · intro e member
      rcases List.mem_append.mp member with first|later
      · have h:=events_bounds code lib f active oneRoom e first
        exact ⟨h.1,lt_of_lt_of_le h.2 finishLower⟩
      · have h:=tail.bounds e later
        exact ⟨nle.trans h.1,h.2⟩
    · intro service answers
      have frontAnswers : EventAnswers service front:=fun e member=>
        answers e (List.mem_append_left _ member)
      have tailAnswers : EventAnswers service tail.events:=fun e member=>
        answers e (List.mem_append_right _ member)
      exact Loops.WhileRun.next (condition_eval service f)
        (by simp [UnsignedLiteralControl.truth_boolean,active])
        (event_run code lib f active oneRoom service frontAnswers) (tail.execution service tailAnswers)
    · have bound:=tail.top
      have topEq : next.cursor.top=f.cursor.top+14:=stepped_top f active oneRoom
      have kEq : next.k=f.k+1:=stepped_k f active oneRoom
      have kp:=f.kPositive
      omega
    · intro slot factApart kApart hp ht hh
      rw[tail.other slot (by change slot≠f.factSlot;exact factApart)
        (by change slot≠f.kSlot;exact kApart) hp ht hh]
      exact stepped_other f active oneRoom slot factApart kApart hp ht hh

end ScopedC.ExpFactorial
