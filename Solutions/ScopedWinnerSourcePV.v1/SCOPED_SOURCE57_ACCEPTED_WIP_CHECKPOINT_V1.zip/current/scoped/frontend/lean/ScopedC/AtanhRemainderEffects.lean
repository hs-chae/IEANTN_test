/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhRemainder
import ScopedC.CoefficientTableGlobal

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

theorem remainder_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (room : c.top+750<PoolCalls.capacity) :
    Valid l (afterRemainder stage positive) := by
  have top:=stage.top
  rw[guard_top] at top
  exact CursorLocals.allocated_valid (next_valid 0 (stored_error_valid stage positive room)
    (by change (errorCursor stage positive).top<PoolCalls.capacity
        rw[error_top _ _ narrow];omega)) "RI" "remainder" _

noncomputable def remainder_table {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) (d : Nat) (stage : PowerStage code l c q d)
    (positive : 0<q.denominator) (narrow : |q.mathematical.value|<1)
    (room : c.top+750<PoolCalls.capacity) {base : Address} {coeffs : List Input}
    (table : CoefficientTableRead.TableAt c.state base coeffs) :
    CoefficientTableRead.TableAt (afterRemainder stage positive).state base coeffs := by
  have before:=power_table ctx q d stage (by omega) table
  have safe:=CoefficientTableRead.pool_separated stage.valid before
  have errorTable : CoefficientTableRead.TableAt (errorCursor stage positive).state base coeffs :=
    CoefficientTableRead.memory before
      (error_other stage positive narrow base.object
        (List.getElem?_eq_some_iff.mp before.memory).choose safe.1 safe.2.1 safe.2.2)
      (fun _ _ h=>error_borrow stage positive narrow h)
  exact CoefficientTableRead.allocated
    (CoefficientTableRead.advanced (stored_error_valid stage positive room)
      (CoefficientTableRead.allocated errorTable "Q" "error" _) [0]) "RI" "remainder" _

theorem remainder_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) {object : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At (afterRemainder stage positive).state "depth" object d := by
  have before:=power_depth q d stage depth apart
  have next : SourceUnsignedGlobal.At (errorCursor stage positive).state "depth" object d :=
    SourceUnsignedGlobal.memory before (error_globals stage positive narrow)
      (error_other stage positive narrow object (List.getElem?_eq_some_iff.mp before.storage).choose
        apart.1 apart.2.1 apart.2.2)
  exact SourceUnsignedGlobal.allocated
    (SourceUnsignedGlobal.advanced (SourceUnsignedGlobal.allocated next "Q" "error" _) [0]
      apart.1 apart.2.1 apart.2.2) "RI" "remainder" _

theorem remainder_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (afterRemainder stage positive).state.globals=c.state.globals := by
  change (next l (storedError stage positive) 0).state.globals=_
  rw[CursorSingleFrames.globals]
  change (errorCursor stage positive).state.globals=_
  rw[error_globals _ _ narrow,stage.globals,guard_trace,CursorSingleFrames.advance_globals]
  change (next l (parameters c q) 0).state.globals=_
  rw[CursorSingleFrames.globals]
  rfl

theorem q_guard_binding {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (room : c.top+9<PoolCalls.capacity) :
    LocalBinding.At (afterGuard l c q).state "q" "Q" q.source c.state.heap.length := by
  have first : LocalBinding.At (parameters c q).state "q" "Q" q.source c.state.heap.length :=
    LocalBinding.allocate_head {c.state with env:=[]} "q" "Q" q.source (by rfl)
  have safe:=LocalStorageSeparation.pool (parameters_context ctx q) first
    (by decide +kernel : ("Q":String)≠"unsigned")
  have afterAbs : LocalBinding.At (AtanhCalls.afterAbs l c q).state "q" "Q" q.source c.state.heap.length :=
    LocalBinding.advance first [0] safe.1 safe.2.1 safe.2.2
  have afterR : LocalBinding.At (AtanhCalls.afterR l c q).state "q" "Q" q.source c.state.heap.length :=
    LocalBinding.allocate_other afterAbs "r" "Q" _ (by decide +kernel)
  rw[guard_trace]
  exact LocalBinding.advance afterR (guardValues l c q) safe.1 safe.2.1 safe.2.2

theorem q_remainder_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) (d : Nat) (stage : PowerStage code l c q d)
    (positive : 0<q.denominator) (narrow : |q.mathematical.value|<1)
    (room : c.top+750<PoolCalls.capacity) :
    LocalBinding.At (afterRemainder stage positive).state "q" "Q" q.source c.state.heap.length := by
  have before:=q_guard_binding ctx q (by omega)
  have safe:=LocalStorageSeparation.pool (guard_context ctx q (by omega)) before
    (by decide +kernel : ("Q":String)≠"unsigned")
  have afterPower : LocalBinding.At stage.out.state "q" "Q" q.source c.state.heap.length :=
    LocalBinding.memory before stage.env
      (stage.other _ (List.getElem?_eq_some_iff.mp before.memory).choose safe.1 safe.2.1 safe.2.2)
  have afterError : LocalBinding.At (errorCursor stage positive).state "q" "Q" q.source c.state.heap.length :=
    LocalBinding.memory afterPower (error_env stage positive narrow)
      (error_other stage positive narrow _ (List.getElem?_eq_some_iff.mp afterPower.memory).choose
        safe.1 safe.2.1 safe.2.2)
  exact LocalBinding.allocate_other
    (LocalBinding.advance (LocalBinding.allocate_other afterError "error" "Q" _ (by decide +kernel))
      [0] safe.1 safe.2.1 safe.2.2) "remainder" "RI" _ (by decide +kernel)

theorem q_remainder_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (alive : q.Live c.state) :
    q.Live (afterRemainder stage positive).state := by
  have before : q.Live (afterGuard l c q).state:=r_guard_live q alive
  have afterPower : q.Live stage.out.state :=
    ⟨stage.preserves _ _ before.1,stage.preserves _ _ before.2⟩
  exact ⟨PoolCursor.preserves (error_borrow stage positive narrow afterPower.1),
    PoolCursor.preserves (error_borrow stage positive narrow afterPower.2)⟩

theorem remainder_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (afterRemainder stage positive).top=stage.out.top+32 := by
  change (errorCursor stage positive).top+1=_
  rw[error_top _ _ narrow]

end ScopedC.AtanhCalls
