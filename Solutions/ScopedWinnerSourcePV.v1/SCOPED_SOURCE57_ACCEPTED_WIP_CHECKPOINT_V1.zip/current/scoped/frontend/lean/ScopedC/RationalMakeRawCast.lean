/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMakeData

namespace ScopedC.RationalMakeRawCast
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 0

theorem result (l : PoolCalls.PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    castValue Header.layout (RationalMakeCalls.c5 l c a d).state 100 "static Q" (RationalMakeCalls.result l c a d)=
      some (RationalMakeCalls.result l c a d) :=
  RecordCasts.rational_record _ 97 "static Q" (by decide +kernel)
    (RationalMakeCalls.numerator_live l c a d) (RationalMakeCalls.denominator_live l c a d)
    (by unfold RationalMakeCalls.sign;split;decide +kernel;exact SignedNegCalls.bit_bound _)

end ScopedC.RationalMakeRawCast
