/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointCount

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def kValue {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Nat := (mValue stage).log2

def afterLog {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor := next l (afterM stage) (kValue stage)

def afterSmall {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor := next l (afterLog stage) 4294967295

def afterK {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor :=
  CursorLocals.allocated (afterSmall stage) "unsigned int" "k" (PoolCalls.word (kValue stage))

theorem k_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    kValue stage = ExpPointReduction.index q.mathematical.value := by
  unfold kValue mValue ExpPointReduction.index
  rw [ceil_magnitude stage positive]

theorem k_bound {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator)
    (bound : Nat.ceil |q.mathematical.value|+1 < 2^32) : kValue stage < 32 := by
  rw [k_value stage positive]
  exact ExpPointReduction.index_lt _ bound

theorem log_source {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    SourceCall Header.layout code 1 "lean_nat_log2" [.natObject (mSlot stage)]
      (afterM stage).state (.natObject (afterM stage).state.nats.values.length)
      (SourceNatLog2.allocated (afterM stage) (mValue stage)) :=
  runtime_leaf (SourceNatLog2.runtime (m_live stage))

theorem keep_source (code : List Function) (lib : CountLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (room : c.top+13 < PoolCalls.capacity) :
    SourceCall Header.layout code 1 "keep" [.natObject (afterM stage).state.nats.values.length]
      (SourceNatLog2.allocated (afterM stage) (mValue stage))
      (.natObject (afterM stage).state.nats.values.length) (afterLog stage).state := by
  have top := ceil_top stage
  exact SourceNatLog2.keep_source code lib.keep (m_valid stage (by omega))
    (by change stage.out.top+2 < PoolCalls.capacity; omega) (mValue stage)

theorem small_source (code : List Function) (lib : CountLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (bound : kValue stage < 32) (room : c.top+13 < PoolCalls.capacity) :
    SourceCall Header.layout code 3 "small" [.natObject (afterM stage).state.nats.values.length]
      (afterLog stage).state (PoolCalls.word (kValue stage)) (afterSmall stage).state := by
  have top := ceil_top stage
  exact NatWrapperCalls.small_call code lib.small lib.nu lib.nle lib.keep
    (next_valid _ (m_valid stage (by omega))
      (by change stage.out.top+2 < PoolCalls.capacity; omega))
    (by change stage.out.top+3 < PoolCalls.capacity; omega)
    (next_borrow l (afterM stage) (kValue stage)) (by omega)

theorem k_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (room : c.top+13 < PoolCalls.capacity) :
    Valid l (afterK stage) := by
  have top := ceil_top stage
  exact CursorLocals.allocated_valid
    (next_valid _ (next_valid _ (m_valid stage (by omega))
      (by change stage.out.top+2 < PoolCalls.capacity; omega))
      (by change stage.out.top+3 < PoolCalls.capacity; omega)) "unsigned int" "k" _

theorem k_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    LocalBinding.At (afterK stage).state "k" "unsigned int" (PoolCalls.word (kValue stage))
      (afterSmall stage).state.heap.length := LocalBinding.allocate_head _ "k" "unsigned int" _ rfl

theorem k_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (bound : kValue stage < 32)
    (logAnswer : service "lean_nat_log2" [.natObject (mSlot stage)] (afterM stage).state =
      some (.natObject (afterM stage).state.nats.values.length,
        SourceNatLog2.allocated (afterM stage) (mValue stage)))
    (keepAnswer : service "keep" [.natObject (afterM stage).state.nats.values.length]
      (SourceNatLog2.allocated (afterM stage) (mValue stage)) =
      some (.natObject (afterM stage).state.nats.values.length,(afterLog stage).state))
    (smallAnswer : service "small" [.natObject (afterM stage).state.nats.values.length]
      (afterLog stage).state = some (PoolCalls.word (kValue stage),(afterSmall stage).state)) :
    Declare Header.layout service
      [{type:="unsigned int",name:="k",value:=(some (.call (.var "small")
          [(.call (.var "keep") [(.call (.var "lean_nat_log2") [(.var "m")])])])),arrayExtent:=none}]
      (afterM stage).state (afterK stage).state := by
  have kept := SourceNatLog2.expression (l:=l) service
    (LocalBinding.eval service 996 (m_binding stage) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel)) logAnswer keepAnswer
  have expression := ExpressionTemplates.call_one Header.layout service kept smallAnswer
  have cast : castValue Header.layout (afterSmall stage).state 100 "unsigned int"
      (PoolCalls.word (kValue stage)) = some (PoolCalls.word (kValue stage)) :=
    RationalUnsignedCalls.cast_parameter (afterSmall stage).state (kValue stage) (by omega)
  simp only [Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem k_branch (service : Call) {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {q : Input} (stage : CeilStage code l c q) (bound : kValue stage < 32) :
    Run Header.layout service (.branch (.binary ">=" (.var "k") (.nat 32))
      (.eval (.call (.var "fail") [])) .skip) (afterK stage).state
      (.continuing (afterK stage).state) := by
  have operation : binaryValue Header.layout (afterK stage).state ">="
      (PoolCalls.word (kValue stage)) (DecimalDigits.integer 32) =
      some (boolean Header.layout false) := by
    change binaryValue Header.layout (afterK stage).state ">="
      (NatWrapperCalls.unsigned32 (kValue stage)) (DecimalDigits.integer 32) = _
    rw [UnsignedLiteralControl.literal_lift _ _ _ _ (by omega) (by decide +kernel)]
    rw [UnsignedLiteralControl.binary_ge _ _ _ (by omega) (by decide +kernel)]
    simp only [show ¬ kValue stage ≥ 32 by omega,decide_false]
  have test : Eval Header.layout service (.binary ">=" (.var "k") (.nat 32))
      (afterK stage).state (afterK stage).state (boolean Header.layout false) :=
    ⟨3,ExpressionTemplates.binary Header.layout service (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)
      (LocalBinding.eval service 1 (k_binding stage) (by decide +kernel)
        (by decide +kernel) (by decide +kernel) (by decide +kernel)) (by rfl) operation⟩
  apply Loops.StmtRun.branch test
  exact Loops.StmtRun.skip _

end ScopedC.ExpPointCalls
