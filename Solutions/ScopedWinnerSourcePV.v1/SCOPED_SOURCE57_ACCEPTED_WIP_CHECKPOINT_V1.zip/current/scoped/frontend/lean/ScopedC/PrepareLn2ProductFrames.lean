/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareLn2Product

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

theorem product_scalar {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {name type : String} {object : Nat} {value : Option Value}
    (h : SourceScalarGlobal.At c.state name type object value) (different : type≠"unsigned") :
    SourceScalarGlobal.At (productCursor a).state name type object value := by
  have before:=beforeAtanh_scalar ctx room h different
  have middle:=a.scalar (beforeAtanh_valid ctx room) before different
  have safe:=SourceScalarGlobal.separated a.valid middle different
  unfold productCursor
  exact SourceScalarGlobal.memory middle (RationalIntervalMultiplyCalls.after_globals _ _ _ _)
    (RationalIntervalMultiplyCalls.after_other l a.out (pointTwo l c) a.output object
      (List.getElem?_eq_some_iff.mp middle.storage).choose safe.1 safe.2.1 safe.2.2)

theorem product_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) {slot value : Nat}
    (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (productCursor a).state.nats slot value := by
  unfold productCursor
  exact RationalIntervalMultiplyCalls.preserves_nat _ _ (a.preserves _ _ (beforeAtanh_borrow h))

noncomputable def product_table {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {base : Address} {values : List Input}
    (h : CoefficientTableRead.TableAt c.state base values) :
    CoefficientTableRead.TableAt (productCursor a).state base values := by
  unfold productCursor
  exact CoefficientTableRead.after_rmul a.valid
    (a.table (beforeAtanh_valid ctx room) (beforeAtanhTable ctx room h)) (pointTwo l c) a.output

theorem product_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) {object n : Nat}
    (h : SourceUnsignedGlobal.At c.state "depth" object n)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At (productCursor a).state "depth" object n := by
  have middle:=a.depth (beforeAtanh_depth h apart) apart
  unfold productCursor
  exact SourceUnsignedGlobal.memory middle (RationalIntervalMultiplyCalls.after_globals _ _ _ _)
    (RationalIntervalMultiplyCalls.after_other l a.out (pointTwo l c) a.output object
      (List.getElem?_eq_some_iff.mp middle.storage).choose apart.1 apart.2.1 apart.2.2)

theorem product_scale {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {object slot value : Nat}
    (h : SourceFromS.ScaleAt c.state object slot value) :
    SourceFromS.ScaleAt (productCursor a).state object slot value := by
  have storage:=product_scalar ctx room a
    (show SourceScalarGlobal.At c.state "scale100" "N" object (some (.natObject slot))
      from ⟨h.lookup,h.storage⟩) (by decide +kernel)
  exact ⟨storage.lookup,storage.storage,product_borrow a h.live⟩

theorem product_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) :
    (productCursor a).state.globals=c.state.globals := by
  unfold productCursor
  rw[RationalIntervalMultiplyCalls.after_globals,a.globals,beforeAtanh_globals]

theorem product_env {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) :
    (productCursor a).state.env=c.state.env := by
  unfold productCursor
  rw[RationalIntervalMultiplyCalls.after_env,a.env,beforeAtanh_env]

theorem product_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) :
    (productCursor a).state.heap.length=c.state.heap.length := by
  unfold productCursor
  rw[RationalIntervalMultiplyCalls.after_heap_length,a.heap_length,beforeAtanh_heap]

theorem product_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) :
    (productCursor a).top ≤ c.top+9102 := by
  have bound:=a.top
  rw[beforeAtanh_top] at bound
  unfold productCursor
  rw[RationalIntervalMultiplyCalls.after_top]
  omega

end ScopedC.PrepareSource.Ln2
