/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderOuterEvents

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax errorCursor errorInput outputPair

structure FrontAnswers (service : Call) {code : List Function} {l : PoolCalls.PoolLayout}
    (c : Cursor) (a : Pair) (ceil : CeilStage code l c a) : Prop where
  absoluteLow : service "qabs" [a.lo.source] (parameters c a).state=some ((low a).source,(afterLo l c a).state)
  absoluteHigh : service "qabs" [a.hi.source] (afterLo l c a).state=some ((high a).source,(afterHi l c a).state)
  maximum : service "qmax" [(low a).source,(high a).source] (afterHi l c a).state=
    some ((radius l c a).source,(afterMax l c a).state)
  ceiling : service "ceilQ" [(radius l c a).source] (afterR l c a).state=some (ceil.endpoint.source,ceil.out.state)
  small : service "small" [.natObject ceil.endpoint.slot] (afterCeil ceil).state=
    some (PoolCalls.word ceil.endpoint.magnitude,(afterSmall ceil).state)
  one : service "qi" [DecimalDigits.integer 1] (afterC ceil).state=
    some ((ExpFactorial.one l (afterC ceil)).source,(ExpFactorial.afterOne l (afterC ceil)).state)

structure TailAnswers (service : Call) {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) (p : ThreePower f) (r : RadiusPower p) : Prop where
  qiThree : service "qi" [DecimalDigits.integer 3] (BeforeError f).state=some ((three f).source,(afterThree f).state)
  first : service "qpow" [(three f).source,PoolCalls.word (ceil.endpoint.magnitude+1)] (afterThree f).state=
    some (p.output.source,p.out.state)
  second : service "qpow" [(radius l c a).source,PoolCalls.word (d+1)] p.out.state=some (r.output.source,r.out.state)
  multiply : service "qt" [p.output.source,r.output.source] r.out.state=
    some ((numerator r).source,(numeratorCursor r).state)
  divide : service "qv" [(numerator r).source,f.loop.finish.fact.source] (numeratorCursor r).state=
    some ((errorInput r).source,(errorCursor r).state)
  negative : service "qn" [(errorInput r).source] (storedError r).state=
    some ((outputPair r).lo.source,(next l (storedError r) 0).state)

/-- Abstract source-backed finite-call composition around the full original
factorial loop. Every answer is checked against full arguments and input state;
all answers require actual lower-rank installed source executions. -/
theorem outer_service (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (alive : a.Live c.state)
    {object d : Nat} {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (p : ThreePower f) (r : RadiusPower p) (countBound : ceil.endpoint.magnitude<4294967295)
    (room : c.top+3000<PoolCalls.capacity) :
    ∃service : Call,
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 9 name args before value after) ∧
      FrontAnswers service c a ceil ∧ ExpFactorial.EventAnswers service f.loop.events ∧
      TailAnswers service f p r := by
  let front:=frontEvents code lib ctx a alive ceil countBound room
  let tail:=tailEvents code lib f p r room
  let frontService:=CallEvents.service front
  let loopService:=CallEvents.service f.loop.events
  let tailService:=CallEvents.service tail
  let service:=CallEvents.append frontService (CallEvents.append loopService tailService)
  have closed : ∀name args before value after,service name args before=some (value,after) →
      SourceCall Header.layout code 9 name args before value after := fun _ _ _ _ _ h=>
    CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.service_closed front h)
      (fun _ _ _ _ _ h=>CallEvents.append_closed
        (fun _ _ _ _ _ h=>SourceRanks.monotone (by decide +kernel) (CallEvents.service_closed f.loop.events h))
        (fun _ _ _ _ _ h=>CallEvents.service_closed tail h) h) h
  have frontAnswers : ∀e∈front,service e.name e.args e.before=some (e.value,e.after) := by
    intro e member
    exact CallEvents.append_left (CallEvents.service_self_keys front
      (front_unique code lib ctx a alive ceil countBound room) e member)
  have loopUnique : (CallEvents.counts f.loop.events).Nodup:=f.loop.unique
  have loopAnswers : ExpFactorial.EventAnswers service f.loop.events := by
    intro e member
    have none : frontService e.name e.args e.before=none := by
      apply CallEvents.service_none_of_size
      intro other inFront
      have left:=front_bounds code lib ctx a alive f countBound room other inFront
      have right:=(f.loop.bounds e member).1
      omega
    exact CallEvents.append_right none (CallEvents.append_left
      (CallEvents.service_self f.loop.events loopUnique e member))
  have tailAnswers : ∀e∈tail,service e.name e.args e.before=some (e.value,e.after) := by
    intro e member
    have lower:=tail_bounds code lib f p r room e member
    have across : f.start.cursor.state.nats.values.length ≤ (BeforeError f).state.nats.values.length:=f.loop.nats_le
    have frontNone : frontService e.name e.args e.before=none := by
      apply CallEvents.service_none_of_size
      intro other inFront
      have upper:=front_bounds code lib ctx a alive f countBound room other inFront
      omega
    have loopNone : loopService e.name e.args e.before=none := by
      apply CallEvents.service_none_of_size
      intro other inLoop
      have upper : other.before.nats.values.length<(BeforeError f).state.nats.values.length:=
        (f.loop.bounds other inLoop).2
      omega
    exact CallEvents.append_right frontNone (CallEvents.append_right loopNone
      (CallEvents.service_self_keys tail (tail_unique code lib f p r room) e member))
  have frontLength : front.length=6 := rfl
  have tailLength : tail.length=6 := rfl
  refine ⟨service,closed,?_,loopAnswers,?_⟩
  · exact ⟨frontAnswers (front[0]'(by rw[frontLength];omega)) (List.getElem_mem (by rw[frontLength];omega)),
      frontAnswers (front[1]'(by rw[frontLength];omega)) (List.getElem_mem (by rw[frontLength];omega)),
      frontAnswers (front[2]'(by rw[frontLength];omega)) (List.getElem_mem (by rw[frontLength];omega)),
      frontAnswers (front[3]'(by rw[frontLength];omega)) (List.getElem_mem (by rw[frontLength];omega)),
      frontAnswers (front[4]'(by rw[frontLength];omega)) (List.getElem_mem (by rw[frontLength];omega)),
      frontAnswers (front[5]'(by rw[frontLength];omega)) (List.getElem_mem (by rw[frontLength];omega))⟩
  · exact ⟨tailAnswers (tail[0]'(by rw[tailLength];omega)) (List.getElem_mem (by rw[tailLength];omega)),
      tailAnswers (tail[1]'(by rw[tailLength];omega)) (List.getElem_mem (by rw[tailLength];omega)),
      tailAnswers (tail[2]'(by rw[tailLength];omega)) (List.getElem_mem (by rw[tailLength];omega)),
      tailAnswers (tail[3]'(by rw[tailLength];omega)) (List.getElem_mem (by rw[tailLength];omega)),
      tailAnswers (tail[4]'(by rw[tailLength];omega)) (List.getElem_mem (by rw[tailLength];omega)),
      tailAnswers (tail[5]'(by rw[tailLength];omega)) (List.getElem_mem (by rw[tailLength];omega))⟩

end ScopedC.ExpRemainderCalls
