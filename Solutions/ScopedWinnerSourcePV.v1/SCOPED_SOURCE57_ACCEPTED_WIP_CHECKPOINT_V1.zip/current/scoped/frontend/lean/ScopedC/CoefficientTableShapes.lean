/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientScalarFrames

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false

theorem memory_cells {s t : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) (stored : t.heap[base.object]?=s.heap[base.object]?)
    (borrow : ∀slot n,NatArena.Borrow s.nats slot n → NatArena.Borrow t.nats slot n) :
    (memory table stored borrow).cells=table.cells := rfl

theorem advanced_cells {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {base : Address} {coeffs : List Input} (table : TableAt c.state base coeffs) (values : List Nat) :
    (advanced ctx table values).cells=table.cells := rfl

theorem allocated_cells {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) (type name : String) (value : Option Value) :
    (allocated table type name value).cells=table.cells := rfl

theorem append_cells {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) (q : Input) (alive : q.Live s) (positive : 0<q.denominator)
    (bound : coeffs.length<table.cells.length) :
    (append table q alive positive bound).cells=table.cells.set coeffs.length (some q.source) := rfl

theorem append_length {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) (q : Input) (alive : q.Live s) (positive : 0<q.denominator)
    (bound : coeffs.length<table.cells.length) :
    (append table q alive positive bound).cells.length=table.cells.length := by
  rw[append_cells,List.length_set]

theorem other_table_cells {s : State} {base other : Address} {coeffs others : List Input}
    (table : TableAt s base coeffs) (retained : TableAt s other others)
    (different : base.object≠other.object) (k : Nat) (q : Input) :
    (other_table table retained different k q).cells=retained.cells := rfl

end ScopedC.CoefficientTableRead
