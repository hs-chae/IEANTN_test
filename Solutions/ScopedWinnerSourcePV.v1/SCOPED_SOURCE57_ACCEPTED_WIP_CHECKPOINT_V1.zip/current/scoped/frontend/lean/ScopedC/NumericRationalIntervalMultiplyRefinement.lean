/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplyBody
import ScopedC.NumericNatsExtensionality

namespace ScopedC.NumericRationalIntervalMultiplyRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalIntervalMultiplyCalls
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000
attribute [local irreducible] finish

theorem low_value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair)
    (pa : a.Positive) (pb : b.Positive) :
    (lowQ l c a b).mathematical.value=
      min (min (a.lo.mathematical.value*b.lo.mathematical.value) (a.lo.mathematical.value*b.hi.mathematical.value))
        (min (a.hi.mathematical.value*b.lo.mathematical.value) (a.hi.mathematical.value*b.hi.mathematical.value)) := by
  have value:=RationalSelectionTree.output_value false l (c4 l c a b) (four l c a b) (four_positive l c a b pa pb)
  have ps:=values l c a b pa pb
  simpa only [lowQ,RationalSelectionTree.combine,Bool.false_eq_true,↓reduceIte,four,ps.1,ps.2.1,ps.2.2.1,ps.2.2.2] using value

theorem high_value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair)
    (pa : a.Positive) (pb : b.Positive) :
    (highQ l c a b).mathematical.value=
      max (max (a.lo.mathematical.value*b.lo.mathematical.value) (a.lo.mathematical.value*b.hi.mathematical.value))
        (max (a.hi.mathematical.value*b.lo.mathematical.value) (a.hi.mathematical.value*b.hi.mathematical.value)) := by
  have value:=RationalSelectionTree.output_value true l (middle l c a b) (four l c a b) (four_positive l c a b pa pb)
  have ps:=values l c a b pa pb
  simpa only [highQ,RationalSelectionTree.combine,↓reduceIte,four,ps.1,ps.2.1,ps.2.2.1,ps.2.2.2] using value

theorem decoded_result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair)
    (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) :
    NumericRepresentation.interval (after l c a b).state (result l c a b)=some
      (IntervalRat.mul ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩) := by
  have live:=after_live l c a b
  have positive:=output_positive l c a b pa pb
  have dl : NumericRepresentation.rational (after l c a b).state (lowQ l c a b).source=
      some (lowQ l c a b).mathematical := Input.decoded live.1 positive.1
  have dh : NumericRepresentation.rational (after l c a b).state (highQ l c a b).source=
      some (highQ l c a b).mathematical := Input.decoded live.2 positive.2
  have lv:=low_value l c a b pa pb
  have hv:=high_value l c a b pa pb
  have order : (lowQ l c a b).mathematical.value ≤ (highQ l c a b).mathematical.value := by
    rw[lv,hv]
    exact le_trans (min_le_of_left_le (min_le_left _ _)) (le_max_of_le_left (le_max_left _ _))
  have inside : NumericRepresentation.interval (after l c a b).state (result l c a b)=some
      (⟨(lowQ l c a b).mathematical.value,(highQ l c a b).mathematical.value,order⟩:IntervalRat) := by
    simp [NumericRepresentation.interval,result,Pair.source,outputPair,IntervalCasts.value,dl,dh,order]
  have endpoints : (⟨(lowQ l c a b).mathematical.value,(highQ l c a b).mathematical.value,order⟩:IntervalRat)=
      IntervalRat.mul ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩ := by
    simp only [IntervalRat.mul,IntervalRat.mk.injEq,IntervalRat.min4,IntervalRat.max4]
    exact ⟨lv,hv⟩
  exact inside.trans (congrArg some endpoints)

/-- The unchanged original four-product interval multiplication, with every
lower computation supplied by the actual parsed C source bodies. -/
theorem rmul_math (code : List Function) (installed : Generated.f_rmul∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair)
    (ha : a.Live c.state) (hb : b.Live c.state) (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) :
    SourceCall Header.layout code 8 "rmul" [a.source,b.source] c.state
      (result l c a b) (after l c a b).state ∧
    NumericRepresentation.interval (after l c a b).state (result l c a b)=some
      (IntervalRat.mul ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩) :=
  ⟨rmul_closed code installed lib ctx room a b ha hb pa pb,decoded_result l c a b pa pb oa ob⟩

end ScopedC.NumericRationalIntervalMultiplyRefinement
