/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerCounter

namespace ScopedC.RationalPowerInvariant
set_option autoImplicit false
set_option maxHeartbeats 100000

def nextAccumulator (r a : Rat) (n : Nat) : Rat := if n%2=1 then r*a else r
def nextBase (a : Rat) (n : Nat) : Rat := if 0<n/2 then a*a else a

/-- Exact binary-power identity for the source's conditional multiplication
and exponent halving. This does not approximate or change its algorithm. -/
theorem power_step (r a : Rat) (n : Nat) :
    nextAccumulator r a n*(a*a)^(n/2)=r*a^n := by
  have splitPower : a^n=a^(n%2)*(a*a)^(n/2) := by
    conv_lhs=>rw[←Nat.mod_add_div n 2]
    rw[pow_add,pow_mul,pow_two]
  rw[splitPower]
  by_cases odd : n%2=1
  · simp [nextAccumulator,odd,mul_assoc]
  · have even : n%2=0 := by have h:=Nat.mod_lt n (by decide : 0<2);omega
    simp [nextAccumulator,odd,even]

/-- The source skips the unused final square when the halved exponent is
zero. That exact control-flow choice preserves the same invariant. -/
theorem source_step (r a : Rat) (n : Nat) :
    nextAccumulator r a n*(nextBase a n)^(n/2)=r*a^n := by
  by_cases remaining : 0<n/2
  · simpa [nextBase,remaining] using power_step r a n
  · have zero : n/2=0 := by omega
    simpa [nextBase,remaining,zero] using power_step r a n

/-- A uint32 exponent needs at most 32 halvings, with a strictly decreasing
bit budget even when its top bit is set. This is only a source proof bound. -/
theorem halve_bits (n k : Nat) (h : n<2^(k+1)) : n/2<2^k := by
  apply (Nat.div_lt_iff_lt_mul (by decide : 0<2)).2
  simpa [pow_succ,Nat.mul_comm] using h

end ScopedC.RationalPowerInvariant
