/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhTail

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard sumCursor

theorem guard_borrow {l : PoolCalls.PoolLayout} {c : Cursor} (q : Input)
    {slot value : Nat} (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (afterGuard l c q).state.nats slot value := by
  rw[guard_trace]
  apply CursorBorrow.preserves
  exact PoolCursor.preserves (c:=parameters c q) h

theorem parameters_length (c : Cursor) (q : Input) :
    (parameters c q).state.heap.length=c.state.heap.length+1 := by
  simp [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate]

theorem afterR_heap (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterR l c q).state.heap.length=c.state.heap.length+2 := by
  change ((next l (parameters c q) 0).state.heap++[_]).length=_
  rw[List.length_append,(PoolCursor.shape l (parameters c q) 0).1,parameters_length]
  rfl

theorem guard_heap (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterGuard l c q).state.heap.length=c.state.heap.length+2 := by
  rw[guard_trace,(CursorEffects.shape l (afterR l c q) (guardValues l c q)).1,afterR_heap]

theorem guard_globals (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterGuard l c q).state.globals=c.state.globals := by
  rw[guard_trace,CursorSingleFrames.advance_globals]
  change (next l (parameters c q) 0).state.globals=_
  rw[CursorSingleFrames.globals]
  rfl

theorem guard_other (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) (slot : Nat)
    (old : slot<c.state.heap.length) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (afterGuard l c q).state.heap[slot]?=c.state.heap[slot]? := by
  rw[guard_trace,CursorSingleFrames.advance_other l (afterR l c q) (guardValues l c q) slot hp ht hh]
  change ((next l (parameters c q) 0).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left (by rw[(PoolCursor.shape l (parameters c q) 0).1,parameters_length];omega)]
  rw[PoolCursor.other l (parameters c q) 0 slot hp ht hh]
  change (c.state.heap++[_])[slot]?=_
  exact List.getElem?_append_left old

theorem remainder_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (afterRemainder stage positive).state.heap.length=stage.out.state.heap.length+2 := by
  change ((next l (storedError stage positive) 0).state.heap++[_]).length=_
  rw[List.length_append,(PoolCursor.shape l (storedError stage positive) 0).1]
  change ((errorCursor stage positive).state.heap++[_]).length+1=_
  rw[List.length_append,error_heap stage positive narrow]
  rfl

theorem sum_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1) :
    (sumCursor t).state.heap.length=c.state.heap.length+4 := by
  unfold sumCursor
  rw[RationalIntervalAddCalls.after_heap_length,t.heap_length,remainder_heap _ _ narrow,
    stage.heap_length,guard_heap]

theorem sum_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1) :
    (sumCursor t).state.globals=c.state.globals := by
  unfold sumCursor
  rw[RationalIntervalAddCalls.after_globals,t.globals,remainder_globals _ _ narrow]

theorem sum_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1)
    {slot value : Nat} (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (sumCursor t).state.nats slot value := by
  unfold sumCursor
  exact RationalIntervalAddCalls.preserves_nat _ _ (t.preserves _ _
    (PoolCursor.preserves (c:=storedError stage positive)
      (error_borrow stage positive narrow (stage.preserves _ _ (guard_borrow q h)))))

theorem sum_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) (narrow : |q.mathematical.value|<1)
    (dBound : d ≤ 64) : (sumCursor t).top ≤ c.top+9000 := by
  have p:=stage.top
  rw[guard_top] at p
  have tail:=t.top
  rw[remainder_top stage positive narrow] at tail
  unfold sumCursor
  rw[RationalIntervalAddCalls.after_top]
  omega

end ScopedC.AtanhCalls
