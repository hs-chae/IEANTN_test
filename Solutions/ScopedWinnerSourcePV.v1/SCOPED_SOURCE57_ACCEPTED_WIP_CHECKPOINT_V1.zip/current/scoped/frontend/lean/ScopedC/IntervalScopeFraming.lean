/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalFrames
import ScopedC.PoolContextPop

namespace ScopedC.RationalIntervalFrames.Pair
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false

/-- Source stack-frame removal retains the underlying owned Nat arena. -/
theorem live_unframe (before : State) (c : Cursor) (pair : RationalIntervalFrames.Pair)
    (live : pair.Live c.state) : pair.Live (PoolContextPop.unframe before c).state := live

end ScopedC.RationalIntervalFrames.Pair
