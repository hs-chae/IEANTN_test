/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalHullData

namespace ScopedC.RationalSelectionTree
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalHullCalls (selected_live selected_positive)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure Four where
  p : Input
  q : Input
  r : Input
  s : Input
def Four.Live (v : Four) (state : State) : Prop :=
  v.p.Live state ∧ v.q.Live state ∧ v.r.Live state ∧ v.s.Live state
def Four.Positive (v : Four) : Prop :=
  0<v.p.denominator ∧ 0<v.q.denominator ∧ 0<v.r.denominator ∧ 0<v.s.denominator

def name (flip : Bool) : String := if flip then "qmax" else "qmin"
def step (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  RationalCompareCalls.final l c a b
def chosen (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Input :=
  RationalSelectCalls.selected flip "<=" l c a b

theorem step_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (step l c a b).top=c.top+6 := rfl
theorem step_size (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (step l c a b).state.nats.values.length=c.state.nats.values.length+6 := by
  rw[step,RationalCompareFraming.final_eq_advance,CursorEffects.size]
  rfl
theorem step_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) : Valid l (step l c a b) :=
  RationalCompareCalls.final_context ctx room a b
theorem preserves_input {l : PoolCalls.PoolLayout} {c : Cursor} {a b p : Input}
    (h : p.Live c.state) : p.Live (step l c a b).state :=
  RationalSelectCalls.input_final h

theorem chosen_closed (code : List Function) (lib : RationalIntervalHullCalls.Library code)
    (flip : Bool) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5<PoolCalls.capacity) (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) :
    SourceCall Header.layout code 7 (name flip) [a.source,b.source] c.state
      (chosen flip l c a b).source (step l c a b).state := by
  cases flip with
  | false =>
    exact RationalSelectCalls.qmin_closed code lib.qmin lib.qc lib.sc lib.sm lib.nm lib.smake
      lib.nz lib.nu lib.ne lib.nlt lib.keep ctx room a b ha hb
  | true =>
    exact RationalSelectCalls.qmax_closed code lib.qmax lib.qc lib.sc lib.sm lib.nm lib.smake
      lib.nz lib.nu lib.ne lib.nlt lib.keep ctx room a b ha hb

def t1 (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : Cursor := step l c v.p v.q
def left (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : Input := chosen flip l c v.p v.q
@[irreducible] def t2 (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : Cursor := step l (t1 l c v) v.r v.s
def right (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : Input := chosen flip l (t1 l c v) v.r v.s
def finish (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : Cursor :=
  step l (t2 l c v) (left flip l c v) (right flip l c v)
def output (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : Input :=
  chosen flip l (t2 l c v) (left flip l c v) (right flip l c v)

theorem top1 (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : (t1 l c v).top=c.top+6 := step_top _ _ _ _
theorem top2 (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : (t2 l c v).top=c.top+12 := by
  unfold t2;rw[step_top,top1]
theorem top_finish (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) :
    (finish flip l c v).top=c.top+18 := by
  unfold finish;rw[step_top,top2]

theorem valid1 {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+17<PoolCalls.capacity) (v : Four) : Valid l (t1 l c v) :=
  step_valid ctx (by omega) v.p v.q
theorem valid2 {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+17<PoolCalls.capacity) (v : Four) : Valid l (t2 l c v) := by
  unfold t2;exact step_valid (valid1 ctx room v) (by rw[top1];omega) v.r v.s
theorem finish_valid (flip : Bool) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+17<PoolCalls.capacity) (v : Four) : Valid l (finish flip l c v) :=
  step_valid (valid2 ctx room v) (by rw[top2];omega) (left flip l c v) (right flip l c v)

theorem left_live (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) (h : v.Live c.state) :
    (left flip l c v).Live (t2 l c v).state := by
  have hl : (left flip l c v).Live (t1 l c v).state := selected_live flip l c v.p v.q h.1 h.2.1
  unfold t2
  exact preserves_input (c:=t1 l c v) (a:=v.r) (b:=v.s) hl
theorem right_live (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) (h : v.Live c.state) :
    (right flip l c v).Live (t2 l c v).state := by
  unfold t2
  exact selected_live flip l (t1 l c v) v.r v.s
    (preserves_input (c:=c) (a:=v.p) (b:=v.q) h.2.2.1)
    (preserves_input (c:=c) (a:=v.p) (b:=v.q) h.2.2.2)
theorem output_live (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) (h : v.Live c.state) :
    (output flip l c v).Live (finish flip l c v).state :=
  selected_live flip l (t2 l c v) (left flip l c v) (right flip l c v)
    (left_live flip l c v h) (right_live flip l c v h)

theorem preserves_four (flip : Bool) {l : PoolCalls.PoolLayout} {c : Cursor} (v : Four) {w : Four}
    (h : w.Live c.state) : w.Live (finish flip l c v).state := by
  have keep {x : Input} (hx : x.Live c.state) : x.Live (finish flip l c v).state := by
    have h1 : x.Live (t1 l c v).state := preserves_input (c:=c) (a:=v.p) (b:=v.q) hx
    have h2 : x.Live (t2 l c v).state := by
      unfold t2;exact preserves_input (c:=t1 l c v) (a:=v.r) (b:=v.s) h1
    exact preserves_input (c:=t2 l c v) (a:=left flip l c v) (b:=right flip l c v) h2
  exact ⟨keep h.1,keep h.2.1,keep h.2.2.1,keep h.2.2.2⟩

theorem positive (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) (h : v.Positive) :
    0<(output flip l c v).denominator :=
  selected_positive flip l (t2 l c v) (left flip l c v) (right flip l c v)
    (selected_positive flip l c v.p v.q h.1 h.2.1)
    (selected_positive flip l (t1 l c v) v.r v.s h.2.2.1 h.2.2.2)

theorem calls (code : List Function) (lib : RationalIntervalHullCalls.Library code)
    (flip : Bool) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+17<PoolCalls.capacity) (v : Four) (h : v.Live c.state) :
    SourceCall Header.layout code 7 (name flip) [v.p.source,v.q.source] c.state
      (left flip l c v).source (t1 l c v).state ∧
    SourceCall Header.layout code 7 (name flip) [v.r.source,v.s.source] (t1 l c v).state
      (right flip l c v).source (t2 l c v).state ∧
    SourceCall Header.layout code 7 (name flip) [(left flip l c v).source,(right flip l c v).source]
      (t2 l c v).state (output flip l c v).source (finish flip l c v).state := by
  refine ⟨chosen_closed code lib flip ctx (by omega) v.p v.q h.1 h.2.1,?_,?_⟩
  · unfold t2
    exact chosen_closed code lib flip (valid1 ctx room v) (by rw[top1];omega) v.r v.s
      (preserves_input (c:=c) (a:=v.p) (b:=v.q) h.2.2.1)
      (preserves_input (c:=c) (a:=v.p) (b:=v.q) h.2.2.2)
  · exact chosen_closed code lib flip (valid2 ctx room v) (by rw[top2];omega)
      (left flip l c v) (right flip l c v) (left_live flip l c v h) (right_live flip l c v h)

end ScopedC.RationalSelectionTree
