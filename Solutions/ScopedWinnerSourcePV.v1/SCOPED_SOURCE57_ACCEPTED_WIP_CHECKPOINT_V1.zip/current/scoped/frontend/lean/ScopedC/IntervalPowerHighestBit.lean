/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerBitFrame

namespace ScopedC.IntervalPowerBits
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 200000

abbrev BitWhile (service : Call) :=
  Loops.WhileRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
    IntervalPowerCounter.bitCondition IntervalPowerCounter.doubleStatement

/-- Full actual source first-loop execution. Its only effects are checked
uint32 stores to the bit local; all other physical objects are retained. -/
structure Certificate {l : PoolLayout} {n : Nat} (start : Frame l n) where
  finish : Frame l n
  execution : ∀service,BitWhile service start.cursor.state (.continuing finish.cursor.state)
  highest : n<finish.bit*2
  nSlot : finish.nSlot=start.nSlot
  bitSlot : finish.bitSlot=start.bitSlot
  shape : finish.cursor.state.heap.length=start.cursor.state.heap.length ∧
    finish.cursor.state.env=start.cursor.state.env ∧ finish.cursor.state.globals=start.cursor.state.globals ∧
    finish.cursor.state.nats=start.cursor.state.nats ∧ finish.cursor.top=start.cursor.top
  other : ∀slot,slot≠start.bitSlot → finish.cursor.state.heap[slot]?=start.cursor.state.heap[slot]?

/-- The increasing power-of-two loop terminates before any uint32 overflow.
Its stopping condition establishes bit ≤ n < 2*bit, as required by the
unchanged subsequent left-to-right interval exponentiation algorithm. -/
theorem highest_bit {l : PoolLayout} {n : Nat} (f : Frame l n) : Nonempty (Certificate f) := by
  suffices ∀m,∀g : Frame l n,n-g.bit=m → Nonempty (Certificate g) from this _ f rfl
  intro m
  induction m using Nat.strong_induction_on with
  | h m ih =>
    intro g metric
    by_cases guard : g.bit ≤ n/2
    · let next:=doubled g guard
      have decrease : n-next.bit < m := by
        change n-g.bit*2 < m
        have positive:=g.positive
        have lower:=g.lower
        omega
      obtain ⟨tail⟩:=ih (n-next.bit) decrease next rfl
      have shape:=doubled_shape g guard
      refine ⟨{
        finish:=tail.finish
        execution:=?_
        highest:=tail.highest
        nSlot:=tail.nSlot
        bitSlot:=tail.bitSlot
        shape:=⟨tail.shape.1.trans shape.1,tail.shape.2.1.trans shape.2.1,
          tail.shape.2.2.1.trans shape.2.2.1,tail.shape.2.2.2.1.trans shape.2.2.2.1,
          tail.shape.2.2.2.2.trans shape.2.2.2.2⟩
        other:=?_
      }⟩
      · intro service
        exact Loops.WhileRun.next
          (IntervalPowerCounter.bit_condition service g.atN g.atBit g.exponentBound
            (lt_of_le_of_lt g.lower g.exponentBound))
          (by simp [UnsignedLiteralControl.truth_boolean,guard])
          (doubled_execution service g guard) (tail.execution service)
      · intro slot different
        exact (tail.other slot different).trans (doubled_other g guard slot different)
    · refine ⟨{
        finish:=g
        execution:=?_
        highest:=by omega
        nSlot:=rfl
        bitSlot:=rfl
        shape:=⟨rfl,rfl,rfl,rfl,rfl⟩
        other:=by intros;rfl
      }⟩
      intro service
      exact Loops.WhileRun.done
        (IntervalPowerCounter.bit_condition service g.atN g.atBit g.exponentBound
          (lt_of_le_of_lt g.lower g.exponentBound))
        (by simp [UnsignedLiteralControl.truth_boolean,guard])

end ScopedC.IntervalPowerBits
