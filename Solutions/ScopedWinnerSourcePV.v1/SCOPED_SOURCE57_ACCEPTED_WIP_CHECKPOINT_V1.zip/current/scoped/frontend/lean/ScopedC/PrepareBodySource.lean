/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareService

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

noncomputable def bodyExit {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) : Cursor :=
  PoolContextPop.unframe (parameters (staticCursor ready) d).state (Ln2.afterStore stage.atanh (base+7))

noncomputable def finished {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) : Cursor :=
  PoolContextPop.unframe state (bodyExit stage)

theorem prepare_body_run (service : Call) {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound)
    (front : PrefixAnswers service stage.coefficient)
    (tail : Ln2.Answers (code:=code) (l:=layout base) (c:=stage.coefficient.loop.finish.cursor)
      (d:=d) (coeffs:=stage.coefficient.loop.finish.atanhCoeffs) service stage.atanh) :
    Run Header.layout service Generated.f_prepare.body (parameters (staticCursor ready) d).state
      (.continuing (bodyExit stage).state) := by
  have guard:=guard_skip service (staticCursor ready) d bound
  have depth:=depth_assignment service (staticCursor ready) d ready.depth bound
  have scale:=ScalePrelude.source_assignment service (depthSeed ready d bound).context
    (depth_scale_raw ready d) (depth_scale_unshadowed ready d) front.scale
  have one:=initExp_assignment service (actualSeed ready d bound) front.one
  have zero:=initAtanh_assignment service (actualSeed ready d bound)
    (by rw[actualSeed_top];decide +kernel) front.zero
  have counter:=initCounter_declaration service (actualSeed ready d bound)
    (by rw[actualSeed_top];decide +kernel)
  have loop:=stage.coefficient.loop.execution service front.loop
  have last:=Ln2.store_eval service stage.coefficient.loop.finish.context
    (by have room:=coefficient_finish_room stage.coefficient;omega) stage.atanh stage.rawLn2
    (coefficient_finish_unshadowed stage.coefficient "preparedLn2" (by decide +kernel) (by decide +kernel)) tail
  apply Loops.StmtRun.sequence (Loops.SeqRun.next guard (Loops.SeqRun.next (Loops.StmtRun.evaluate depth)
    (Loops.SeqRun.next (Loops.StmtRun.evaluate scale)
      (Loops.SeqRun.next (Loops.StmtRun.evaluate one)
        (Loops.SeqRun.next (Loops.StmtRun.evaluate zero)
          (Loops.SeqRun.next (Loops.StmtRun.declare counter)
            (Loops.SeqRun.next (Loops.StmtRun.whileLoop loop)
              (Loops.SeqRun.next (Loops.StmtRun.evaluate last) (Loops.SeqRun.nil _)))))))))
  rfl

theorem finished_valid {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    Valid (layout base) (finished stage) := by
  have stored:=Ln2.stored_valid stage.coefficient.loop.finish.context
    (coefficient_finish_room stage.coefficient) stage.atanh stage.rawLn2
  have hp:=(List.getElem?_eq_some_iff.mp ready.pool.pool_read).choose
  have ht:=(List.getElem?_eq_some_iff.mp ready.pool.top_read).choose
  have hh:=(List.getElem?_eq_some_iff.mp ready.pool.high_read).choose
  have paramLength : (parameters (staticCursor ready) d).state.heap.length=state.heap.length+1 := by
    simp [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate,staticCursor]
  have inner : Valid (layout base) (bodyExit stage):=PoolContextPop.valid stored
    (by rw[paramLength];omega) (by rw[paramLength];omega) (by rw[paramLength];omega)
  exact PoolContextPop.valid inner hp ht hh

/-- Entire unchanged original prepare C function: actual initialization-derived
applicability, all source loop/numerical calls, final typed ln2 store, outer
body/function scope pops, and the real void ABI return. -/
theorem prepare_closed (code : List Function) (installed : Generated.f_prepare∈code)
    (lib : CompleteLibrary code) {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) (argument : Value)
    (convert : castValue Header.layout {state with env:=[]} 100 "unsigned int" argument=some (PoolCalls.word d)) :
    ∃stage : CompleteStage code ready d bound,
      SourceCall Header.layout code 11 "prepare" [argument] state .unit (finished stage).state := by
  obtain ⟨stage⟩:=complete_stage code lib ready d bound
  obtain ⟨service,closed,front,tail⟩:=prepare_service code lib stage
  refine ⟨stage,?_⟩
  apply installed_body (cfg:=Header.layout) (code:=code) (f:=Generated.f_prepare) (rank:=10)
    (service:=service) (args:=[argument]) (s:=state) (frame:=(parameters (staticCursor ready) d).state)
    (t:=(finished stage).state) (v:=.unit) (outcome:=.continuing (bodyExit stage).state)
    installed closed (bind_parameters (staticCursor ready) d argument convert) (prepare_body_run service stage front tail)
  exact ⟨rfl,rfl,rfl⟩

end ScopedC.PrepareSource
