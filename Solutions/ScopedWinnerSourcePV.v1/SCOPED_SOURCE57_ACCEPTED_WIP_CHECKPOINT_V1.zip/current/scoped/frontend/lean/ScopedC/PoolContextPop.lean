/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PoolCursor
namespace ScopedC.PoolContextPop
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0

/-- Removing source stack frames preserves the already-owned global pool when
its three actual objects precede the caller's stack boundary. -/
theorem context {l : PoolLayout} {before after : State} {cells : List (Option Value)} {top high : Nat}
    (h : GenericPoolContext l after cells top high)
    (pool : l.pool<before.heap.length) (topSlot : l.top<before.heap.length) (highSlot : l.high<before.heap.length) :
    GenericPoolContext l (popScope before after) cells top high := by
  constructor
  · exact h.global_pool
  · exact h.global_top
  · exact h.global_high
  · simpa only[popScope,List.getElem?_take_of_lt pool]using h.pool_read
  · simpa only[popScope,List.getElem?_take_of_lt topSlot]using h.top_read
  · simpa only[popScope,List.getElem?_take_of_lt highSlot]using h.high_read
  · exact h.extent
  · exact h.high_range
  · exact h.top_range

def unframe (before : State) (c : Cursor) : Cursor := {c with state:=popScope before c.state}

theorem valid {l : PoolLayout} {before : State} {c : Cursor} (h : Valid l c)
    (pool : l.pool<before.heap.length) (topSlot : l.top<before.heap.length) (highSlot : l.high<before.heap.length) :
    Valid l (unframe before c) := context h pool topSlot highSlot

end ScopedC.PoolContextPop
