/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalFrames
import ScopedC.DyadicIntervalNegBody
namespace ScopedC.DyadicPairFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure InputI where
  lo : Endpoint
  hi : Endpoint
  ok : Bool
namespace InputI
def source (a : InputI) : Value := DyadicCasts.value a.lo.source a.hi.source a.ok
def Live (s : State) (a : InputI) : Prop := a.lo.Live s ∧ a.hi.Live s

theorem initialized (a : InputI) : Machine.initialized 1000 a.source=true := rfl

theorem cast {s : State} {a : InputI} (h : a.Live s) (ty : String) (ht : normalizeType ty="I") :
    castValue Header.layout s 100 ty a.source=some a.source :=
  DyadicCasts.record s 97 ty ht a.lo.source a.hi.source a.ok
    (Endpoint.cast 97 "S" (by decide +kernel) h.1) (Endpoint.cast 97 "S" (by decide +kernel) h.2)
end InputI

def frame (s : State) (a b : InputI) : State := TwoFrames.frame s "I" "a" a.source "I" "b" b.source
def framed (c : Cursor) (a b : InputI) : Cursor := CursorFrames.framed c "I" "a" a.source "I" "b" b.source

theorem bind {s : State} (a b : InputI) (ha : a.Live s) (hb : b.Live s) :
    bindArgs Header.layout [("I","a"),("I","b")] [a.source,b.source] s=some (frame s a b) :=
  TypedFrames.bind_two Header.layout s "I" "a" "I" "b" a.source b.source a.source b.source
    (InputI.cast (s:={s with env:=[]}) ha "I" (by decide +kernel))
    (InputI.cast (s:=allocate {s with env:=[]} "I" "a" (some a.source)) hb "I" (by decide +kernel))

theorem a_at (s : State) (a b : InputI) : LocalBinding.At (frame s a b) "a" "I" a.source s.heap.length :=
  LocalBinding.allocate_other (LocalBinding.allocate_head {s with env:=[]} "a" "I" a.source (InputI.initialized a))
    "b" "I" (some b.source) (by decide +kernel)

theorem b_at (s : State) (a b : InputI) : LocalBinding.At (frame s a b) "b" "I" b.source (s.heap.length+1) := by
  simpa only [frame,TwoFrames.frame,allocate,List.length_append,List.length_singleton] using
    LocalBinding.allocate_head (allocate {s with env:=[]} "I" "a" (some a.source)) "b" "I" b.source (InputI.initialized b)

theorem eval_lo (service : Call) (fuel : Nat) {s : State} {name : String} {p : InputI} {slot : Nat}
    (h : LocalBinding.At s name "I" p.source slot)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+2) s (.field "." (.var name) "lo")=some (p.lo.source,s) := by
  apply ExpressionTemplates.field Header.layout service (LocalBinding.eval service fuel h h0 h1 h2 h3)
  rfl

theorem eval_hi (service : Call) (fuel : Nat) {s : State} {name : String} {p : InputI} {slot : Nat}
    (h : LocalBinding.At s name "I" p.source slot)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+2) s (.field "." (.var name) "hi")=some (p.hi.source,s) := by
  apply ExpressionTemplates.field Header.layout service (LocalBinding.eval service fuel h h0 h1 h2 h3)
  rfl

theorem eval_ok (service : Call) (fuel : Nat) {s : State} {name : String} {p : InputI} {slot : Nat}
    (h : LocalBinding.At s name "I" p.source slot)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+2) s (.field "." (.var name) "ok")=
      some (NatWrapperCalls.unsigned32 (SignedNegCalls.bit p.ok),s) := by
  apply ExpressionTemplates.field Header.layout service (LocalBinding.eval service fuel h h0 h1 h2 h3)
  rfl

theorem logical_and (service : Call) {fuel : Nat} {s : State} {a b : Expr} (x y : Bool)
    (ha : evalExpr Header.layout service fuel s a=some (NatWrapperCalls.unsigned32 (SignedNegCalls.bit x),s))
    (hb : evalExpr Header.layout service fuel s b=some (NatWrapperCalls.unsigned32 (SignedNegCalls.bit y),s)) :
    evalExpr Header.layout service (fuel+1) s (.binary "&&" a b)=some (boolean Header.layout (x&&y),s) := by
  cases x <;> cases y <;> simp [evalExpr,ha,hb,truth,Scalar.truth,NatWrapperCalls.unsigned32,SignedNegCalls.bit]

theorem cast_boolean_unsigned (s : State) (fuel : Nat) (b : Bool) :
    castValue Header.layout s (fuel+1) "unsigned" (boolean Header.layout b)=
      some (NatWrapperCalls.unsigned32 (SignedNegCalls.bit b)) := by
  cases b <;> rfl

theorem aggregate_boolean (s : State) (lo hi : Value) (b : Bool)
    (hl : castValue Header.layout s 99 "S" lo=some lo)
    (hh : castValue Header.layout s 99 "S" hi=some hi) :
    castValue Header.layout s 100 "I" (.aggregate [lo,hi,boolean Header.layout b])=
      some (DyadicCasts.value lo hi b) := by
  apply TypedFrames.cast_aggregate Header.layout s 99 "I" "I"
    [("lo","S"),("hi","S"),("ok","unsigned")]
    [lo,hi,boolean Header.layout b] [lo,hi,NatWrapperCalls.unsigned32 (SignedNegCalls.bit b)]
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by rfl)
  change (do
    let l ← castValue Header.layout s 99 "S" lo
    let h ← castValue Header.layout s 99 "S" hi
    let ok ← castValue Header.layout s 99 "unsigned" (boolean Header.layout b)
    pure [l,h,ok])=some [lo,hi,NatWrapperCalls.unsigned32 (SignedNegCalls.bit b)]
  rw[hl,hh,cast_boolean_unsigned s 98 b]
  rfl
end ScopedC.DyadicPairFrames
