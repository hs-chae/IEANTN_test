/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPairFrames
import ScopedC.PoolContextPop

namespace ScopedC.RationalPairFrames.Input
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false

theorem live_allocate (s : State) (q : RationalPairFrames.Input)
    (type name : String) (value : Option Value) (live : q.Live s) :
    q.Live (allocate s type name value) := live

theorem live_unframe (before : State) (c : Cursor) (q : RationalPairFrames.Input)
    (live : q.Live c.state) : q.Live (PoolContextPop.unframe before c).state := live

theorem value_eq (q : RationalPairFrames.Input) :
    q.mathematical.value=(q.mathematical.num.value:Rat)/(q.denominator:Rat) := rfl

end ScopedC.RationalPairFrames.Input
