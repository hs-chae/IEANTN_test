/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareScalePrelude
import ScopedC.PrepareDepthSeed

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def scaleTable {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {object : Nat} {old : Option Value} (raw : SourceNatGlobal.RawAt c.state "scale100" object old)
    {base : Address} (table : CoefficientTableRead.TableAt c.state base []) :
    CoefficientTableRead.TableAt (ScalePrelude.result l c object).state base [] := by
  let shifted:=CoefficientTableRead.advanced ctx table [1,100,1<<<100]
  have rawShift:=SourceNatGlobal.advanced ctx raw [1,100,1<<<100]
  have apart:=CoefficientTableRead.scalar_separated shifted rawShift.storage
  exact CoefficientTableRead.memory shifted (List.getElem?_set_ne (Ne.symm apart)) (fun _ _ h=>h)

theorem scale_depth_apart {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) {scaleObject : Nat} {old : Option Value}
    (raw : SourceNatGlobal.RawAt s.cursor.state "scale100" scaleObject old) : scaleObject≠object := by
  intro same
  have storage:=raw.storage
  simp only[same,s.depthAt.storage] at storage
  have types:=congrArg (fun x : Option Object=>x.map Object.type) storage
  change some "unsigned"=some "N" at types
  contradiction

/-- The actual scale assignment preserves both raw coefficient arrays and
new depth, yielding the seed used by the actual initial coefficient stores. -/
def scaleSeed {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) {scaleObject : Nat} {old : Option Value}
    (raw : SourceNatGlobal.RawAt s.cursor.state "scale100" scaleObject old)
    (room : s.cursor.top+2<PoolCalls.capacity) : CoeffSeed l object d eb ab := {
  cursor:=ScalePrelude.result l s.cursor scaleObject
  context:=ScalePrelude.result_valid s.context room raw
  expAt:=scaleTable s.context raw s.expAt
  atanhAt:=scaleTable s.context raw s.atanhAt
  expExtent:=s.expExtent
  atanhExtent:=s.atanhExtent
  expLookup:=by
    change (CursorFrames.advance l s.cursor [1,100,1<<<100]).state.globals.lookup "expCoeffs"=some eb
    rw[CursorSingleFrames.advance_globals];exact s.expLookup
  atanhLookup:=by
    change (CursorFrames.advance l s.cursor [1,100,1<<<100]).state.globals.lookup "atanhCoeffs"=some ab
    rw[CursorSingleFrames.advance_globals];exact s.atanhLookup
  expUnshadowed:=by
    change (CursorFrames.advance l s.cursor [1,100,1<<<100]).state.env.lookup "expCoeffs"=none
    rw[(CursorEffects.shape l s.cursor [1,100,1<<<100]).2];exact s.expUnshadowed
  atanhUnshadowed:=by
    change (CursorFrames.advance l s.cursor [1,100,1<<<100]).state.env.lookup "atanhCoeffs"=none
    rw[(CursorEffects.shape l s.cursor [1,100,1<<<100]).2];exact s.atanhUnshadowed
  depthAt:=SourceUnsignedGlobal.memory
    (t:=(ScalePrelude.result l s.cursor scaleObject).state)
    (SourceUnsignedGlobal.advanced s.depthAt [1,100,1<<<100]
      s.depthApart.1 s.depthApart.2.1 s.depthApart.2.2) rfl
    (List.getElem?_set_ne (scale_depth_apart s raw))
  depthUnshadowed:=by
    change (CursorFrames.advance l s.cursor [1,100,1<<<100]).state.env.lookup "depth"=none
    rw[(CursorEffects.shape l s.cursor [1,100,1<<<100]).2];exact s.depthUnshadowed
  depthBound:=s.depthBound
  arraysApart:=s.arraysApart
  depthApart:=s.depthApart }

/-- Concrete full prefix: actual static initialization, parameter frame,
depth store, nu(1), nu(100), nl, and the writable scale100 store. -/
def actualSeed {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    CoeffSeed (layout base) (base+3) d (expBase base) (atanhBase base) :=
  scaleSeed (depthSeed ready d bound) (depth_scale_raw ready d)
    (by change (0:Nat)+2<PoolCalls.capacity;decide +kernel)

theorem actualSeed_scale {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) :
    SourceFromS.ScaleAt (actualSeed ready d bound).cursor.state (base+4)
      (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100) :=
  ScalePrelude.result_scale (depthSeed ready d bound).context (depth_scale_raw ready d)

theorem actualSeed_top {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) : (actualSeed ready d bound).cursor.top=3 := rfl

end ScopedC.PrepareSource
