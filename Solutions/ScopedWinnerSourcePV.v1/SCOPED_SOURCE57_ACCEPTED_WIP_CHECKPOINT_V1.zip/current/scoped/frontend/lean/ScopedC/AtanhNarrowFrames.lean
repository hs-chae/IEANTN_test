/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhNarrowFramedBody
import ScopedC.AtanhMath
import ScopedC.SourceScalarGlobal

namespace ScopedC.AtanhCalls.NarrowFramedResult
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

theorem scalar {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} {coeffs : List Input} (out : NarrowFramedResult code l c q d coeffs)
    (ctx : Valid l c) {name type : String} {object : Nat} {value : Option Value}
    (h : SourceScalarGlobal.At c.state name type object value) (different : type≠"unsigned") :
    SourceScalarGlobal.At out.out.state name type object value := by
  have safe:=SourceScalarGlobal.separated ctx h different
  exact SourceScalarGlobal.memory h out.globals
    (out.other object (List.getElem?_eq_some_iff.mp h.storage).choose safe.1 safe.2.1 safe.2.2)

theorem scale {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} {coeffs : List Input} (out : NarrowFramedResult code l c q d coeffs)
    (ctx : Valid l c) {object slot value : Nat} (h : SourceFromS.ScaleAt c.state object slot value) :
    SourceFromS.ScaleAt out.out.state object slot value := by
  have stored:=out.scalar ctx
    (show SourceScalarGlobal.At c.state "scale100" "N" object (some (.natObject slot))
      from ⟨h.lookup,h.storage⟩) (by decide +kernel)
  exact ⟨stored.lookup,stored.storage,out.preserves _ _ h.live⟩

def table {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} {coeffs : List Input} (out : NarrowFramedResult code l c q d coeffs)
    (ctx : Valid l c) {base : Address} {values : List Input}
    (h : CoefficientTableRead.TableAt c.state base values) :
    CoefficientTableRead.TableAt out.out.state base values := by
  have safe:=CoefficientTableRead.pool_separated ctx h
  exact CoefficientTableRead.memory h
    (out.other base.object (List.getElem?_eq_some_iff.mp h.memory).choose safe.1 safe.2.1 safe.2.2) out.preserves

theorem pair {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} {coeffs : List Input} (out : NarrowFramedResult code l c q d coeffs)
    {p : Pair} (h : p.Live c.state) : p.Live out.out.state :=
  ⟨⟨out.preserves _ _ h.1.1,out.preserves _ _ h.1.2⟩,
    ⟨out.preserves _ _ h.2.1,out.preserves _ _ h.2.2⟩⟩

theorem depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} {coeffs : List Input} (out : NarrowFramedResult code l c q d coeffs)
    {name : String} {object n : Nat} (h : SourceUnsignedGlobal.At c.state name object n)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At out.out.state name object n :=
  SourceUnsignedGlobal.memory h out.globals
    (out.other object (List.getElem?_eq_some_iff.mp h.storage).choose apart.1 apart.2.1 apart.2.2)

theorem model_values {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} {coeffs : List Input} (out : NarrowFramedResult code l c q d coeffs)
    (narrow : |q.mathematical.value|<1) :
    out.output.lo.mathematical.value=(IntervalRat.atanhPointComputableWithCoeffs q.mathematical.value d
      (TaylorCalls.coefficientValues coeffs)).lo ∧
    out.output.hi.mathematical.value=(IntervalRat.atanhPointComputableWithCoeffs q.mathematical.value d
      (TaylorCalls.coefficientValues coeffs)).hi := by
  have values:=old_model_values q.mathematical.value d (TaylorCalls.coefficientValues coeffs)
  have low:=values.1
  have high:=values.2
  simp only[not_le.mpr narrow,↓reduceIte] at low high
  exact ⟨out.lower.trans low.symm,out.upper.trans high.symm⟩

theorem ordered {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} {coeffs : List Input} (out : NarrowFramedResult code l c q d coeffs)
    (narrow : |q.mathematical.value|<1) : out.output.lo.mathematical.value ≤ out.output.hi.mathematical.value := by
  rw[(out.model_values narrow).1,(out.model_values narrow).2]
  exact (IntervalRat.atanhPointComputableWithCoeffs q.mathematical.value d
    (TaylorCalls.coefficientValues coeffs)).le

theorem decoded {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} {coeffs : List Input} (out : NarrowFramedResult code l c q d coeffs)
    (narrow : |q.mathematical.value|<1) : NumericRepresentation.interval out.out.state out.output.source=
      some (IntervalRat.atanhPointComputableWithCoeffs q.mathematical.value d
        (TaylorCalls.coefficientValues coeffs)) := by
  have output:=NumericRationalIntervalAddRefinement.decoded_input out.live out.positive (out.ordered narrow)
  have same : (⟨out.output.lo.mathematical.value,out.output.hi.mathematical.value,out.ordered narrow⟩:IntervalRat)=
      IntervalRat.atanhPointComputableWithCoeffs q.mathematical.value d (TaylorCalls.coefficientValues coeffs) := by
    rw[IntervalRat.mk.injEq]
    exact out.model_values narrow
  exact output.trans (congrArg some same)

end ScopedC.AtanhCalls.NarrowFramedResult
