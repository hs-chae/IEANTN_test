/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyShape
namespace ScopedC.RationalMultiplyCalls
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem top11 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (c11 l c a b).top=c.top+11 := by
  change (c6 l c a b).top+1+1+1+1+1=c.top+11
  rw[top6]

theorem preserves {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Input} {slot n : Nat}
    (live : NatArena.Borrow c.state.nats slot n) : NatArena.Borrow (c11 l c a b).state.nats slot n := by
  have h6 : NatArena.Borrow (c6 l c a b).state.nats slot n := by
    rw[c6]
    exact CursorBorrow.preserves (c:=c) [g a b,h a b,a.numerator.magnitude/g a b,0,b.numerator.magnitude/h a b,0] live
  exact CursorBorrow.preserves (c:=c6 l c a b)
    [productMagnitude l c a b,0,a.denominator/h a b,b.denominator/g a b,den a b] h6

end ScopedC.RationalMultiplyCalls
