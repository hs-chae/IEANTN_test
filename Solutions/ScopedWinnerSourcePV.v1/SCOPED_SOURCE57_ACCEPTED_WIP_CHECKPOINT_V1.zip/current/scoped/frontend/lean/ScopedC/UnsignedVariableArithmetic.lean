/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerCounter
import ScopedC.UnsignedLiteralControl

namespace ScopedC.UnsignedVariableArithmetic
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.RationalPowerCounter
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem divide_scalar (a b : Nat) (ha : a<2^32) (hb : b<2^32) (positive : 0<b) :
    Scalar.binary "/" (scalar a) (scalar b)=some (scalar (a/b)) := by
  have ra:=u32_range a ha
  have rb:=u32_range b hb
  have result:=Scalar.make_exact (u32_range (a/b) (lt_of_le_of_lt (Nat.div_le_self _ _) ha))
  simp only[scalar,Scalar.binary,ra,rb,decide_true,Bool.not_true,Bool.false_or,Bool.false_eq_true,↓reduceIte]
  change (do let x←Scalar.cast ⟨false,32⟩ (scalar a);let y←Scalar.cast ⟨false,32⟩ (scalar b)
             if y.number=0 then none else Scalar.make ⟨false,32⟩ (Int.tdiv x.number y.number))=_
  rw[cast_scalar a ha,cast_scalar b hb]
  simpa [Bind.bind,Option.bind,scalar,show b≠0 by omega,Int.tdiv_eq_ediv_of_nonneg (Int.natCast_nonneg a)] using result

theorem divide (s : State) (a b : Nat) (ha : a<2^32) (hb : b<2^32) (positive : 0<b) :
    binaryValue Header.layout s "/" (word a) (word b)=some (word (a/b)) := by
  change (do let x←Scalar.binary "/" (scalar a) (scalar b);pure (Value.integer x))=_
  rw[divide_scalar a b ha hb positive]
  rfl

theorem eval_half (service : Call) (fuel : Nat) {s : State} {name : String} {slot n : Nat}
    (h : LocalBinding.At s name "unsigned int" (word n) slot) (hn : n<2^32)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+3) s (.binary "/" (.var name) (.nat 2))=some (word (n/2),s) :=
  ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service (fuel+1) h h0 h1 h2 h3) (by rfl) (RationalPowerCounter.divide s n hn)

theorem halve_assignment (service : Call) (fuel : Nat) {s : State} {name : String} {slot n : Nat}
    (h : LocalBinding.At s name "unsigned int" (word n) slot) (hn : n<2^32)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+4) s (.binary "=" (.var name) (.binary "/" (.var name) (.nat 2)))=
      some (word (n/2),LocalAssignment.changed s slot "unsigned int" (word (n/2))) :=
  LocalAssignment.evaluate service (fuel+2) (eval_half service fuel h hn h0 h1 h2 h3) h
    (RationalUnsignedCalls.cast_parameter s (n/2) (RationalPowerCounter.halve_range n hn))

end ScopedC.UnsignedVariableArithmetic
