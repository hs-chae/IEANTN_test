/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalRecordEffects
import ScopedC.RationalUnsignedRatioExpression
import ScopedC.UnsignedLiteralControl
import ScopedC.ReadonlyCallEffects
namespace ScopedC.NamedFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def parameters (s : State) (kind : Nat) : State :=
  OneFrames.frame s "unsigned int" "c" (NatWrapperCalls.unsigned32 kind)
def parameterCursor (c : Cursor) (kind : Nat) : Cursor :=
  {c with state:=parameters c.state kind}
def uninitializedQ : Value := uninitializedValue Header.layout 99 "Q"
def initial (c : Cursor) (kind : Nat) : Cursor :=
  CursorLocals.allocated (parameterCursor c kind) "RI" "r"
    (RationalRecordFields.value uninitializedQ uninitializedQ)

theorem actual_declaration : Generated.f_named.body=
    .sequence [
      .declare [{type:="RI",name:="r",value:=none}],
      .branch (.binary "==" (.var "c") (.nat 0))
        (.sequence [
          .eval (.binary "=" (.field "." (.var "r") "lo")
            (RationalDecimalLiteral.initializer 31415926535897932 10000000000000000)),
          .eval (.binary "=" (.field "." (.var "r") "hi")
            (RationalDecimalLiteral.initializer 31415926535897933 10000000000000000))])
        (.sequence [
          .eval (.binary "=" (.field "." (.var "r") "lo")
            (RationalUnsignedRatio.initializer 5722 10000)),
          .eval (.binary "=" (.field "." (.var "r") "hi")
            (RationalUnsignedRatio.initializer 5823 10000))]),
      .returnStmt (.call (.var "fromRI") [.var "r",.nat 1])] := by
  have loText : toString (31415926535897932 : Nat)="31415926535897932" := by decide +kernel
  have hiText : toString (31415926535897933 : Nat)="31415926535897933" := by decide +kernel
  have denText : toString (10000000000000000 : Nat)="10000000000000000" := by decide +kernel
  simp only [Generated.f_named,RationalDecimalLiteral.initializer,
    RationalUnsignedRatio.initializer,loText,hiText,denText]

theorem initial_valid {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (kind : Nat) :
    Valid l (initial c kind) := by
  have params : Valid l (parameterCursor c kind) :=
    OneFrames.context_frame ctx "unsigned int" "c" (NatWrapperCalls.unsigned32 kind)
  exact CursorLocals.allocated_valid params "RI" "r" _

theorem r_binding (c : Cursor) (kind : Nat) :
    RationalRecordFields.At (initial c kind).state uninitializedQ uninitializedQ
      (parameters c.state kind).heap.length := by
  constructor
  · simp [initial,CursorLocals.allocated,parameterCursor,allocate,List.lookup]
  · simp [initial,CursorLocals.allocated,parameterCursor,allocate,List.getElem?_append,RationalRecordFields.object]

theorem c_binding (c : Cursor) (kind : Nat) :
    LocalBinding.At (initial c kind).state "c" "unsigned int"
      (NatWrapperCalls.unsigned32 kind) c.state.heap.length := by
  have first : LocalBinding.At (parameters c.state kind) "c" "unsigned int"
      (NatWrapperCalls.unsigned32 kind) c.state.heap.length :=
    LocalBinding.allocate_head {c.state with env:=[]} "c" "unsigned int"
      (NatWrapperCalls.unsigned32 kind) (by rfl)
  exact LocalBinding.allocate_other first "r" "RI" _ (by decide +kernel)

theorem declaration (service : Call) (c : Cursor) (kind : Nat) :
    Declare Header.layout service [{type:="RI",name:="r",value:=none}]
      (parameters c.state kind) (initial c kind).state := by
  have shape : uninitializedValue Header.layout 100 "RI"=
      RationalRecordFields.value uninitializedQ uninitializedQ := by
    have fields : fieldsOf Header.layout "RI"=some [("lo","Q"),("hi","Q")] := by decide +kernel
    have normal : normalizeType "RI"="RI" := by decide +kernel
    change (match fieldsOf Header.layout "RI" with
      | none => Value.uninitialized
      | some fs => Value.record (normalizeType "RI")
          (fs.map (fun f : String × String=>uninitializedValue Header.layout 99 f.2))) = _
    rw [fields,normal]
    rfl
  simp only [Declare,declarations,List.foldlM,shape,Bind.bind,Option.bind]
  rfl

theorem condition (service : Call) (c : Cursor) (kind : Nat) (bound : kind<2^32) :
    Eval Header.layout service (.binary "==" (.var "c") (.nat 0))
      (initial c kind).state (initial c kind).state (boolean Header.layout (decide (kind=0))) := by
  refine ⟨1000,?_⟩
  have readKind := LocalBinding.eval service 998 (c_binding c kind)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have zero := RationalUnsignedRatio.literal service (initial c kind).state 998 0 (by decide +kernel)
  have operation := (UnsignedLiteralControl.literal_lift (initial c kind).state "==" kind 0 bound
    (by decide +kernel)).trans (UnsignedLiteralControl.binary_eq _ kind 0 bound (by decide +kernel))
  exact ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    readKind zero operation

theorem scale {c : Cursor} {object slot value : Nat}
    (h : SourceFromS.ScaleAt c.state object slot value) (kind : Nat) :
    SourceFromS.ScaleAt (initial c kind).state object slot value := by
  have params : SourceFromS.ScaleAt (parameterCursor c kind).state object slot value :=
    SourceScaleFrames.framed h "unsigned int" "c" (NatWrapperCalls.unsigned32 kind)
  exact ReadonlyCallEffects.scale_allocate params "RI" "r" _

end ScopedC.NamedFrames
