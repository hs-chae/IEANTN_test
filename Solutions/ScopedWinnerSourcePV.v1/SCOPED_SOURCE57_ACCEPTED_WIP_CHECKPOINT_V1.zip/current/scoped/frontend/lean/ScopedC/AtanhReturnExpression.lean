/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhTail

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

def returnExpression : Expr := .call (.var "radd")
  [.call (.var "taylor") [.var "atanhCoeffs",.call (.var "point") [.var "q"]],.var "remainder"]

theorem remainder_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) :
    LocalBinding.At (afterRemainder stage positive).state "remainder" "RI"
      (remainderPair stage positive).source (next l (storedError stage positive) 0).state.heap.length :=
  LocalBinding.allocate_head _ "remainder" "RI" _ (by rfl)

theorem remainder_taylor_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive)
    (narrow : |q.mathematical.value|<1) (room : c.top+750<PoolCalls.capacity) :
    LocalBinding.At t.out.state "remainder" "RI" (remainderPair stage positive).source
      (next l (storedError stage positive) 0).state.heap.length := by
  have before:=remainder_binding stage positive
  have safe:=LocalStorageSeparation.pool (remainder_valid stage positive narrow room) before
    (by decide +kernel : ("RI":String)≠"unsigned")
  exact LocalBinding.memory before t.env
    (t.other _ (List.getElem?_eq_some_iff.mp before.memory).choose safe.1 safe.2.1 safe.2.2)

theorem return_eval (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {base : Address} {coeffs : List Input} (q : Input) (d : Nat)
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (t : TaylorStage code l c base coeffs q d stage positive)
    (narrow : |q.mathematical.value|<1) (room : c.top+750<PoolCalls.capacity)
    (table : CoefficientTableRead.TableAt c.state base coeffs)
    (lookup : c.state.globals.lookup "atanhCoeffs"=some base)
    (point : service "point" [q.source] (afterRemainder stage positive).state=
      some ((pointPair q).source,(afterRemainder stage positive).state))
    (polynomial : service "taylor" [.pointer base true,(pointPair q).source]
      (afterRemainder stage positive).state=some ((taylorPair t).source,t.out.state))
    (addition : service "radd" [(taylorPair t).source,(remainderPair stage positive).source]
      t.out.state=some ((sumPair t narrow).source,(sumCursor t).state)) :
    Eval Header.layout service returnExpression (afterRemainder stage positive).state
      (sumCursor t).state (sumPair t narrow).source := by
  have qEval:=LocalBinding.eval service 1 (q_remainder_binding ctx q d stage positive narrow room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have pEval:=ExpressionTemplates.call_one Header.layout service qEval point
  have tableAt:=remainder_table ctx q d stage positive narrow room table
  have globalLookup : (afterRemainder stage positive).state.globals.lookup "atanhCoeffs"=some base := by
    rw[remainder_globals stage positive narrow]
    exact lookup
  have arrayEval:=CoefficientTableRead.eval_global service 2 tableAt globalLookup
    (remainder_unshadowed stage positive narrow "atanhCoeffs" (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have tEval:=ExpressionTemplates.call_two Header.layout service arrayEval pEval polynomial
  have rEval:=LocalBinding.eval service 3 (remainder_taylor_binding t narrow room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact ⟨5,ExpressionTemplates.call_two Header.layout service tEval rEval addition⟩

end ScopedC.AtanhCalls
