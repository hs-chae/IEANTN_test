/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhNarrowBody
import ScopedC.AtanhCallerMemory

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard sumPair sumCursor

/-- Actual original narrow atanh source result together with its proved
arbitrary caller resources. No caller initialized value/output is assumed. -/
structure NarrowFramedResult (code : List Function) (l : PoolCalls.PoolLayout) (before : Cursor)
    (q : Input) (d : Nat) (coeffs : List Input) where
  out : Cursor
  output : Pair
  execution : SourceCall Header.layout code 10 "atanhPoint" [q.source] before.state output.source out.state
  valid : Valid l out
  live : output.Live out.state
  positive : output.Positive
  lower : output.lo.mathematical.value=
    (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
      (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).lo-
      |q.mathematical.value|^(d+1)/(1-|q.mathematical.value|)
  upper : output.hi.mathematical.value=
    (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
      (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).hi+
      |q.mathematical.value|^(d+1)/(1-|q.mathematical.value|)
  top : out.top ≤ before.top+9000
  globals : out.state.globals=before.state.globals
  env : out.state.env=before.state.env
  heap_length : out.state.heap.length=before.state.heap.length
  preserves : ∀slot value,NatArena.Borrow before.state.nats slot value →
    NatArena.Borrow out.state.nats slot value
  other : ∀slot,slot<before.state.heap.length → slot≠l.pool → slot≠l.top → slot≠l.high →
    out.state.heap[slot]?=before.state.heap[slot]?

theorem atanh_narrow_framed (code : List Function) (installed : Generated.f_atanhPoint∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (alive : q.Live c.state) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (d object : Nat)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (lookup : c.state.globals.lookup "atanhCoeffs"=some base)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high)
    (dBound : d≤64) (length : coeffs.length=d+1) (room : c.top+9000<PoolCalls.capacity) :
    Nonempty (NarrowFramedResult code l c q d coeffs) := by
  obtain ⟨stage⟩:=power_stage code lib.error.narrow.qpow lib.error.narrow.guard ctx q alive positive
    d dBound (by omega)
  obtain ⟨t⟩:=taylor_stage code lib ctx q d object stage positive narrow alive table depth apart
    dBound length room
  let e0 : CallEvents.Event Header.layout code 9 :=
    ⟨"qabs",[q.source],(parameters c q).state,(absInput q).source,(afterAbs l c q).state,
      SourceRanks.monotone (by decide +kernel)
        (abs_call code lib.error.narrow.guard.absolute ctx q alive (by omega))⟩
  let e1 : CallEvents.Event Header.layout code 9 :=
    ⟨"qi",[DecimalDigits.integer 1],(afterR l c q).state,(oneInput l c q).source,(afterOne l c q).state,
      SourceRanks.monotone (by decide +kernel) (one_call code lib.error.narrow.guard ctx q (by omega))⟩
  let e2 : CallEvents.Event Header.layout code 9 :=
    ⟨"qc",[(absInput q).source,(oneInput l c q).source],(afterOne l c q).state,
      SignedCompareCalls.integer (guardValue q),(afterGuard l c q).state,
      SourceRanks.monotone (by decide +kernel)
        (compare_call code lib.error.narrow.guard ctx q alive positive (by omega))⟩
  let e3 : CallEvents.Event Header.layout code 9 :=
    ⟨"qpow",[(absInput q).source,PoolCalls.word (d+1)],(afterGuard l c q).state,
      stage.output.source,stage.out.state,SourceRanks.monotone (by decide +kernel) stage.execution⟩
  let e4 : CallEvents.Event Header.layout code 9 :=
    ⟨"qi",[DecimalDigits.integer 1],stage.out.state,(denOne stage).source,(denStart stage).state,
      SourceRanks.monotone (by decide +kernel) (den_one_source code lib.error.narrow stage (by omega))⟩
  let e5 : CallEvents.Event Header.layout code 9 :=
    ⟨"qs",[(denOne stage).source,(absInput q).source],(denStart stage).state,
      (denominator stage positive).source,(denCursor stage).state,
      SourceRanks.monotone (by decide +kernel)
        (den_source code lib.error.narrow stage alive positive (by omega))⟩
  let e6 : CallEvents.Event Header.layout code 9 :=
    ⟨"qv",[stage.output.source,(denominator stage positive).source],(denCursor stage).state,
      (errorInput stage positive).source,(errorCursor stage positive).state,
      SourceRanks.monotone (by decide +kernel) (error_source code lib.error stage positive (by omega))⟩
  let e7 : CallEvents.Event Header.layout code 9 :=
    ⟨"qn",[(errorInput stage positive).source],(storedError stage positive).state,
      (remainderPair stage positive).lo.source,(next l (storedError stage positive) 0).state,
      SourceRanks.monotone (by decide +kernel)
        (remainder_call code lib.qn lib.sn lib.error stage positive narrow (by omega))⟩
  let e8 : CallEvents.Event Header.layout code 9 :=
    ⟨"point",[q.source],(afterRemainder stage positive).state,
      (pointPair q).source,(afterRemainder stage positive).state,
      SourceRanks.monotone (by decide +kernel) (point_source code lib stage positive narrow alive)⟩
  let e9 : CallEvents.Event Header.layout code 9 :=
    ⟨"taylor",[.pointer base true,(pointPair q).source],(afterRemainder stage positive).state,
      (taylorPair t).source,t.out.state,by rw[(taylor_pair_spec t).1];exact t.execution⟩
  let e10 : CallEvents.Event Header.layout code 9 :=
    ⟨"radd",[(taylorPair t).source,(remainderPair stage positive).source],t.out.state,
      (sumPair t narrow).source,(sumCursor t).state,
      SourceRanks.monotone (by decide +kernel) (sum_source code lib t narrow dBound room)⟩
  have qiDifferent : (afterR l c q).state.nats.values.length≠stage.out.state.nats.values.length := by
    rw[afterR_size]
    have lower:=power_arena_lower stage
    omega
  have unique : ([e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10].map CallEvents.nameKey).Nodup := by
    change [(c.state.nats.values.length,"qabs"),((afterR l c q).state.nats.values.length,"qi"),
      ((afterOne l c q).state.nats.values.length,"qc"),((afterGuard l c q).state.nats.values.length,"qpow"),
      (stage.out.state.nats.values.length,"qi"),((denStart stage).state.nats.values.length,"qs"),
      ((denCursor stage).state.nats.values.length,"qv"),((storedError stage positive).state.nats.values.length,"qn"),
      ((afterRemainder stage positive).state.nats.values.length,"point"),
      ((afterRemainder stage positive).state.nats.values.length,"taylor"),
      (t.out.state.nats.values.length,"radd")].Nodup
    simp only[List.nodup_cons,List.mem_cons,List.not_mem_nil,not_false_eq_true,List.nodup_nil,
      Prod.mk.injEq,String.reduceEq,not_or,and_false,false_and,and_true,true_and,
      qiDifferent,Ne.symm qiDifferent]
  obtain ⟨service,answers,closed⟩:=CallEvents.nameTimeline_service
    [e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10] unique
  have a0:=answers e0 List.mem_cons_self
  have a1:=answers e1 (List.mem_cons_of_mem e0 List.mem_cons_self)
  have a2:=answers e2 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 List.mem_cons_self))
  have a3:=answers e3 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 List.mem_cons_self)))
  have a4:=answers e4 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 List.mem_cons_self))))
  have a5:=answers e5 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 List.mem_cons_self)))))
  have a6:=answers e6 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 List.mem_cons_self))))))
  have a7:=answers e7 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_of_mem e6 List.mem_cons_self)))))))
  have a8:=answers e8 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_of_mem e6 (List.mem_cons_of_mem e7 List.mem_cons_self))))))))
  have a9:=answers e9 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_of_mem e6 (List.mem_cons_of_mem e7 (List.mem_cons_of_mem e8 List.mem_cons_self)))))))))
  have a10:=answers e10 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_of_mem e6 (List.mem_cons_of_mem e7 (List.mem_cons_of_mem e8 (List.mem_cons_of_mem e9 List.mem_cons_self))))))))))
  trace "events done"
  have rDecl:=r_declaration service l c q alive a0
  trace "r declaration"
  have condition:=guard_eval service l c q a1 a2
  trace "guard expression"
  have errorDecl:=error_declaration service ctx q d object stage positive depth apart dBound (by omega)
    a3 a4 a5 a6
  trace "error declaration"
  have remDecl:=remainder_declaration service stage positive (by omega) a7
  trace "remainder declaration"
  have returned:=return_eval service ctx q d stage positive t narrow (by omega) table lookup a8 a9 a10
  trace "return expression"
  have branch : Run Header.layout service
      (.branch guardExpression
        (.sequence [.declare [{type:="RI",name:="wide",value:=some wideInitializer,arrayExtent:=none}],
          .returnStmt (.var "wide")]) .skip) (afterR l c q).state
      (.continuing (afterGuard l c q).state) := by
    apply Loops.StmtRun.branch condition
    simp only[UnsignedLiteralControl.truth_boolean,guard_truth,not_le.mpr narrow,
      decide_false,Bool.false_eq_true,↓reduceIte]
    exact Loops.StmtRun.skip _
  trace "branch done"
  let bodyExit:=PoolContextPop.unframe (parameters c q).state (sumCursor t)
  let out:=PoolContextPop.unframe c.state bodyExit
  have body : Run Header.layout service Generated.f_atanhPoint.body (parameters c q).state
      (.returned bodyExit.state (sumPair t narrow).source) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.declare rDecl)
      (Loops.SeqRun.next branch (Loops.SeqRun.next (Loops.StmtRun.declare errorDecl)
        (Loops.SeqRun.next (Loops.StmtRun.declare remDecl)
          (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned))))))
    exact ⟨rfl,rfl⟩
  trace "body done"
  have spec:=sum_spec t narrow
  trace "sum spec"
  have bodyLive : (sumPair t narrow).Live bodyExit.state:=
    Pair.live_unframe (parameters c q).state (sumCursor t) (sumPair t narrow) spec.1
  trace "body live"
  have resultLive : (sumPair t narrow).Live out.state:=
    Pair.live_unframe c.state bodyExit (sumPair t narrow) bodyLive
  trace "out live"
  have source : SourceCall Header.layout code 10 "atanhPoint" [q.source] c.state
      (sumPair t narrow).source out.state := by
    trace "source apply"
    apply installed_body (cfg:=Header.layout) (code:=code) (f:=Generated.f_atanhPoint)
      (rank:=9) (service:=service) (args:=[q.source]) (s:=c.state)
      (frame:=(parameters c q).state) (t:=out.state) (v:=(sumPair t narrow).source)
      (outcome:=.returned bodyExit.state (sumPair t narrow).source)
      installed closed (bind_parameters c q alive) body
    trace "source finish"
    exact ⟨Pair.cast (s:=bodyExit.state) (a:=sumPair t narrow) bodyLive "static RI" (by decide +kernel),rfl⟩
  trace "source done"
  have hp:=(List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht:=(List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh:=(List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have paramsLength : (parameters c q).state.heap.length=c.state.heap.length+1 := by
    simp [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate]
  have bodyContext : Valid l bodyExit:=PoolContextPop.valid (sum_valid t narrow dBound room)
    (by rw[paramsLength];omega) (by rw[paramsLength];omega) (by rw[paramsLength];omega)
  exact ⟨{
    out:=out
    output:=sumPair t narrow
    execution:=source
    valid:=PoolContextPop.valid bodyContext hp ht hh
    live:=resultLive
    positive:=spec.2.1
    lower:=spec.2.2.1
    upper:=spec.2.2.2
    top:=sum_top t narrow dBound
    globals:=narrowOut_globals t narrow
    env:=(narrowOut_shape t narrow).2
    heap_length:=(narrowOut_shape t narrow).1
    preserves:=fun _ _ h=>narrowOut_borrow t narrow h
    other:=fun slot old hp ht hh=>narrowOut_other t narrow slot old hp ht hh }⟩

end ScopedC.AtanhCalls
