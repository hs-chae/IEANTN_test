/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPairFrames

namespace ScopedC.NumericInputCompleteness
open ScopedC.Machine ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem borrow_of_read {a : NatArena.Arena} {slot n : Nat} (h : NatArena.read a slot=some n) : NatArena.Borrow a slot n := by
  unfold NatArena.read at h
  split_ifs at h with owner
  · exact ⟨h,owner⟩

/-- Inverting the checked decoder recovers physical live source input fields.
It introduces no source output hypothesis beyond the already proved decoding
of an actual returned value. -/
theorem signed {s : State} {v : Value} {q : Signed} (h : NumericRepresentation.signed s v=some q) :
    ∃e : Endpoint,e.source=v ∧ e.Live s ∧ e.mathematical=q := by
  unfold NumericRepresentation.signed at h
  split at h
  · rename_i tag slot flag
    by_cases ht : tag="S"
    · by_cases hf : flag.type=⟨false,32⟩
      · cases hm : NatArena.read s.nats slot with
        | none => simp [ht,hf,hm] at h
        | some m =>
          have live := borrow_of_read hm
          by_cases hz : flag.number=0
          · have hq : (⟨m,false⟩:Signed)=q := by simpa [ht,hf,hm,hz]using h
            have flagEq : flag=⟨⟨false,32⟩,0⟩ := congrArg₂ Scalar.Value.mk hf hz
            refine ⟨⟨slot,m,false⟩,?_,live,hq⟩
            rw[ht,flagEq]
            rfl
          · by_cases ho : flag.number=1
            · have hq : (⟨m,true⟩:Signed)=q := by simpa [ht,hf,hm,hz,ho]using h
              have flagEq : flag=⟨⟨false,32⟩,1⟩ := congrArg₂ Scalar.Value.mk hf ho
              refine ⟨⟨slot,m,true⟩,?_,live,hq⟩
              rw[ht,flagEq]
              rfl
            · simp [ht,hf,hm,hz,ho] at h
      · simp [ht,hf] at h
    · simp [ht] at h
  · contradiction

end ScopedC.NumericInputCompleteness
