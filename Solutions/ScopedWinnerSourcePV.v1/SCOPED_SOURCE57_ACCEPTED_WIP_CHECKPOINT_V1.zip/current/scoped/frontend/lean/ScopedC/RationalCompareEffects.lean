/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCompareBody
import ScopedC.LocalBinding
import ScopedC.CursorBorrow

namespace ScopedC.RationalCompareCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def values (a b : Input) : List Nat :=
  [0,a.numerator.magnitude*b.denominator,0,0,b.numerator.magnitude*a.denominator,0]

theorem trace (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    final l c a b=CursorFrames.advance l c (values a b) := rfl

theorem final_globals (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (final l c a b).state.globals=c.state.globals := by
  rw[trace]
  exact CursorSingleFrames.advance_globals l c (values a b)

theorem final_other (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (slot : Nat)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (final l c a b).state.heap[slot]?=c.state.heap[slot]? := by
  rw[trace]
  exact CursorSingleFrames.advance_other l c (values a b) slot hp ht hh

theorem final_borrow {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Input)
    {slot value : Nat} (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (final l c a b).state.nats slot value := by
  rw[trace]
  exact CursorBorrow.preserves (values a b) live

theorem final_binding {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Input)
    {name type : String} {value : Value} {slot : Nat}
    (binding : LocalBinding.At c.state name type value slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    LocalBinding.At (final l c a b).state name type value slot := by
  rw[trace]
  exact LocalBinding.advance binding (values a b) hp ht hh

end ScopedC.RationalCompareCalls
