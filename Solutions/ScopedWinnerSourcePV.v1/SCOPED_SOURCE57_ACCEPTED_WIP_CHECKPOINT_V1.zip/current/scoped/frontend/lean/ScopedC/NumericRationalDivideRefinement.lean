/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalDivideBody
import ScopedC.RationalCanonical

namespace ScopedC.NumericRationalDivideRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.RationalDivideCalls
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0

theorem normalized (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (an : a.mathematical.Normalized) (bn : b.mathematical.Normalized) : (output l c a b).Normalized := by
  by_cases hz : b.numerator.magnitude=0
  · simp only[output,if_pos hz]
    change Rational.Normalized ⟨⟨0,false⟩,1⟩
    simpa [Rational.ofRat,Signed.make]using (Rational.ofRat_normalized (0:Rat))
  · simp only[output,if_neg hz]
    exact RationalMultiplyCalls.normalized l (inverseCursor l c a b) a (inverse b) an (inverse_normalized b bn hz)

/-- Both actual source branches, including its explicit zero-divisor return,
match the existing total Rat division convention. Analytic consumers retain
their own nonzero-denominator domains. -/
theorem qv_math (code : List Function) (installed : Generated.f_qv∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 7 "qv" [a.source,b.source] c.state (result l c a b) (after l c a b).state ∧
    Valid l (after l c a b) ∧
    NumericRepresentation.rational (after l c a b).state (result l c a b)=some (output l c a b) ∧
    (output l c a b).value=a.mathematical.value/b.mathematical.value :=
  ⟨qv_closed code installed lib ctx room a b ha hb pa pb,after_context ctx room a b,decoded l c a b pa pb,value l c a b pa pb⟩

theorem qv_canonical_math (code : List Function) (installed : Generated.f_qv∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state)
    (an : a.mathematical.Normalized) (bn : b.mathematical.Normalized) :
    SourceCall Header.layout code 7 "qv" [a.source,b.source] c.state (result l c a b) (after l c a b).state ∧
    Valid l (after l c a b) ∧
    NumericRepresentation.rational (after l c a b).state (result l c a b)=some (output l c a b) ∧
    (output l c a b).Normalized ∧
    (output l c a b).Represents (a.mathematical.value/b.mathematical.value) := by
  have hn := normalized l c a b an bn
  have hr := Rational.normalized_represents_value (output l c a b) hn
  rw[value l c a b an.1 bn.1] at hr
  exact ⟨qv_closed code installed lib ctx room a b ha hb an.1 bn.1,after_context ctx room a b,
    decoded l c a b an.1 bn.1,hn,hr⟩

end ScopedC.NumericRationalDivideRefinement
