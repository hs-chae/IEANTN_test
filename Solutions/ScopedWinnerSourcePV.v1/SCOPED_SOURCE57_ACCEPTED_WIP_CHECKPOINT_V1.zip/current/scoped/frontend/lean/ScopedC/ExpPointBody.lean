/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointSourceService
import ScopedC.ExpPointFinalFrames

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

structure FramedResult (code : List Function) (l : PoolCalls.PoolLayout) (before : Cursor)
    (q : Input) (d : Nat) (coeffs : List Input) where
  out : Cursor
  output : Pair
  execution : SourceCall Header.layout code 11 "expPoint" [q.source] before.state output.source out.state
  valid : Valid l out
  live : output.Live out.state
  positive : output.Positive
  decoded : NumericRepresentation.interval out.state output.source = some
    (IntervalRat.expPointComputableWithCoeffs q.mathematical.value d (TaylorCalls.coefficientValues coeffs))
  top : out.top ≤ before.top+16000
  globals : out.state.globals=before.state.globals
  env : out.state.env=before.state.env
  heap_length : out.state.heap.length=before.state.heap.length
  preserves : ∀ slot value, NatArena.Borrow before.state.nats slot value →
    NatArena.Borrow out.state.nats slot value
  other : ∀ slot, slot < before.state.heap.length → slot ≠ l.pool → slot ≠ l.top → slot ≠ l.high →
    out.state.heap[slot]?=before.state.heap[slot]?

/-- Whole unchanged original expPoint: actual front, finite proved source-call
service, original Taylor-before-remainder evaluation order and exact old model.
The input magnitude guard and all machine applicability are proved, not assumed
successful source effects. Actual prepare discharges the physical table/depth
component prerequisites in the final application. -/
theorem expPoint_framed (code : List Function) (installed : Generated.f_expPoint ∈ code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (alive : q.Live c.state) (positive : 0 < q.denominator) (d object : Nat)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (lookup : c.state.globals.lookup "expCoeffs"=some base)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object ≠ l.pool ∧ object ≠ l.top ∧ object ≠ l.high)
    (dBound : d ≤ 64) (length : coeffs.length=d+1)
    (range : Nat.ceil |q.mathematical.value|+1 < 2^32)
    (room : c.top+16000 < PoolCalls.capacity) : Nonempty (FramedResult code l c q d coeffs) := by
  obtain ⟨stage⟩ := ceil_stage code lib.front.count.ceil ctx q alive positive (by omega)
  have bound := k_bound stage positive range
  obtain ⟨t⟩ := taylor_stage code lib ctx stage positive table d object depth apart dBound length room
  obtain ⟨r⟩ := remainder_stage code lib t object depth apart dBound room
  obtain ⟨p⟩ := power_stage lib r bound dBound room
  obtain ⟨service,closed,answers⟩ := source_service lib ctx alive r p bound dBound room
  have ceilDecl := ceil_declaration service stage answers.absoluteCall answers.ceiling
  have mDecl := m_declaration service stage answers.one answers.addition
  have kDecl := k_declaration service stage bound answers.logarithm answers.registration answers.small
  have guard := k_branch service stage bound
  have powerDecl := power_declaration service stage bound
  have reducedDecl := reduced_declaration service stage ctx positive answers.unsigned answers.division
  have inputDecl := input_declaration service stage positive answers.singleton
  have returned := return_eval service ctx r p (by omega) table lookup answers.polynomial
    answers.error answers.sum answers.power
  let bodyExit := PoolContextPop.unframe (parameters c q).state p.out
  let out := finalCursor p
  have body : Run Header.layout service Generated.f_expPoint.body (parameters c q).state
      (.returned bodyExit.state p.output.source) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.declare ceilDecl)
      (Loops.SeqRun.next (Loops.StmtRun.declare mDecl)
        (Loops.SeqRun.next (Loops.StmtRun.declare kDecl)
          (Loops.SeqRun.next guard
            (Loops.SeqRun.next (Loops.StmtRun.declare powerDecl)
              (Loops.SeqRun.next (Loops.StmtRun.declare reducedDecl)
                (Loops.SeqRun.next (Loops.StmtRun.declare inputDecl)
                  (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned)))))))))
    exact ⟨rfl,rfl⟩
  have bodyLive : p.output.Live bodyExit.state :=
    Pair.live_unframe (parameters c q).state p.out p.output p.live
  have outLive : p.output.Live out.state :=
    Pair.live_unframe c.state bodyExit p.output bodyLive
  have source : SourceCall Header.layout code 11 "expPoint" [q.source] c.state
      p.output.source out.state := by
    apply installed_body (cfg:=Header.layout) (code:=code) (f:=Generated.f_expPoint)
      (rank:=10) (service:=service) (args:=[q.source]) (s:=c.state)
      (frame:=(parameters c q).state) (t:=out.state) (v:=p.output.source)
      (outcome:=.returned bodyExit.state p.output.source) installed closed
      (TypedFrames.bind_one Header.layout c.state "Q" "q" q.source q.source
        (Input.cast (s:={c.state with env:=[]}) "Q" (by decide +kernel) alive)) body
    exact ⟨Pair.cast bodyLive "static RI" (by decide +kernel),rfl⟩
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have bodyValid : Valid l bodyExit := PoolContextPop.valid p.valid
    (by rw [parameter_heap]; omega) (by rw [parameter_heap]; omega)
    (by rw [parameter_heap]; omega)
  have unchanged := NumericNatsExtensionality.interval (s:=p.out.state) (t:=out.state) rfl p.output.source
  have top := final_top p
  exact ⟨{
    out:=out
    output:=p.output
    execution:=source
    valid:=PoolContextPop.valid bodyValid hp ht hh
    live:=outLive
    positive:=p.positive
    decoded:=unchanged.symm.trans (final_model p)
    top:=by change p.out.top ≤ c.top+16000; omega
    globals:=final_globals p
    env:=(final_shape p).2
    heap_length:=(final_shape p).1
    preserves:=fun _ _ live => final_borrow p live
    other:=final_other p
  }⟩

end ScopedC.ExpPointCalls
