/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedUnsignedPair
namespace ScopedC.NamedUnsignedTrace
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem numerator_count (l : PoolLayout) (c : Cursor) (n : Nat) :
    (RationalUnsignedRatio.numerator l c n).state.nats.values.length=c.state.nats.values.length+3 := by
  change (CursorFrames.advance l c [n,0,1]).state.nats.values.length=_
  rw [CursorEffects.size]
  rfl

theorem denominator_count (l : PoolLayout) (c : Cursor) (n d : Nat) :
    (RationalUnsignedRatio.denominator l c n d).state.nats.values.length=c.state.nats.values.length+6 := by
  change (CursorFrames.advance l (RationalUnsignedRatio.numerator l c n) [d,0,1]).state.nats.values.length=_
  rw [CursorEffects.size,numerator_count]
  simp only [List.length_cons,List.length_nil]

theorem output_count_bounds {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (n d : Nat) (room : c.top+18<capacity) :
    c.state.nats.values.length+10≤(RationalUnsignedRatio.after l c n d).state.nats.values.length ∧
    (RationalUnsignedRatio.after l c n d).state.nats.values.length≤c.state.nats.values.length+19 := by
  have mid := RationalUnsignedRatio.den_valid ctx n d (by omega)
  have inside : (RationalUnsignedRatio.denominator l c n d).top+12<capacity := by
    change c.top+3+3+12<capacity
    omega
  have lower : 4≤(RationalDivideTrace.steps l (RationalUnsignedRatio.denominator l c n d)
      (RationalUnsignedRatio.numInput l c n) (RationalUnsignedRatio.denInput l c n d)).length := by
    by_cases zero : (RationalUnsignedRatio.denInput l c n d).numerator.magnitude=0 <;>
      simp [RationalDivideTrace.steps,zero,RationalDivideTrace.productSteps,RationalMultiplyTrace.steps]
  have upper := RationalDivideTrace.length l (RationalUnsignedRatio.denominator l c n d)
    (RationalUnsignedRatio.numInput l c n) (RationalUnsignedRatio.denInput l c n d)
  unfold RationalUnsignedRatio.after
  rw [RationalDivideTrace.after_advance mid inside,CursorEffects.size,denominator_count]
  omega

#print axioms numerator_count
#print axioms denominator_count
#print axioms output_count_bounds
end ScopedC.NamedUnsignedTrace
