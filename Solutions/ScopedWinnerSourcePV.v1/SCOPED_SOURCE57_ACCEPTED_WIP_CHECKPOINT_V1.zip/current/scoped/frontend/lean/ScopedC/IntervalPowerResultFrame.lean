/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerInitialization

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem live_nats {a : Pair} {s t : State} (live : a.Live s) (same : t.nats=s.nats) : a.Live t := by
  simpa only[Pair.Live,RationalPairFrames.Input.Live,DyadicRepresentation.Endpoint.Live,same] using live

def withResult {l : PoolCalls.PoolLayout} {n : Nat} (f : IntervalPowerBits.Frame l n)
    (a : Pair) (aSlot : Nat) (atA : LocalBinding.At f.cursor.state "a" "RI" a.source aSlot)
    (alive : a.Live f.cursor.state) (positive : a.Positive)
    (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) : IntervalPowerScan.Frame l n where
  cursor:=CursorLocals.allocated f.cursor "RI" "result" a.source
  a:=a
  result:=a
  bit:=f.bit
  aSlot:=aSlot
  nSlot:=f.nSlot
  bitSlot:=f.bitSlot
  rSlot:=f.cursor.state.heap.length
  context:=CursorLocals.allocated_valid f.context "RI" "result" a.source
  aAt:=LocalBinding.allocate_other atA "result" "RI" (some a.source) (by decide +kernel)
  nAt:=LocalBinding.allocate_other f.atN "result" "RI" (some a.source) (by decide +kernel)
  bitAt:=LocalBinding.allocate_other f.atBit "result" "RI" (some a.source) (by decide +kernel)
  rAt:=LocalBinding.allocate_head f.cursor.state "result" "RI" a.source (Pair.initialized a)
  aLive:=alive
  rLive:=alive
  aPositive:=positive
  rPositive:=positive
  aOrder:=order
  rOrder:=order
  exponentBound:=f.exponentBound
  bitBound:=lt_of_le_of_lt f.lower f.exponentBound
  arDistinct:=by have h:=(List.getElem?_eq_some_iff.mp atA.memory).choose;omega
  nbDistinct:=f.distinct

theorem result_declaration (service : Call) {l : PoolCalls.PoolLayout} {n : Nat} (f : IntervalPowerBits.Frame l n)
    (a : Pair) (aSlot : Nat) (atA : LocalBinding.At f.cursor.state "a" "RI" a.source aSlot)
    (alive : a.Live f.cursor.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) :
    Declare Header.layout service [{type:="RI",name:="result",value:=some (.var "a"),arrayExtent:=none}]
      f.cursor.state (withResult f a aSlot atA alive positive order).cursor.state := by
  have expression:=LocalBinding.eval service 999 atA (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have convert:=Pair.cast alive "RI" (by decide +kernel)
  simp only[Declare,declarations,List.foldlM,expression,Bind.bind,Option.bind,convert]
  rfl

theorem highest_a {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a : Pair) (n : Nat) (positive : 0<n) (bound : n<2^32)
    (cert : IntervalPowerBits.Certificate (initialBitFrame ctx a n positive bound)) :
    LocalBinding.At cert.finish.cursor.state "a" "RI" a.source c.state.heap.length := by
  apply LocalBinding.memory (bit_a c a n)
  · exact cert.shape.2.1
  · exact cert.other c.state.heap.length (by change c.state.heap.length≠c.state.heap.length+2;omega)

theorem highest_live {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a : Pair) (n : Nat) (positive : 0<n) (bound : n<2^32)
    (cert : IntervalPowerBits.Certificate (initialBitFrame ctx a n positive bound))
    (alive : a.Live c.state) : a.Live cert.finish.cursor.state :=
  live_nats alive cert.shape.2.2.2.1

end ScopedC.IntervalPowerCalls
