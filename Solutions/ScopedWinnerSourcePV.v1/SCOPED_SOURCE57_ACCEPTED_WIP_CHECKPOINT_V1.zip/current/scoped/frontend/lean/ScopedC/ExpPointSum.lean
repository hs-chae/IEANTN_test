/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointRemainder
import ScopedC.IntervalAddApplicability

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

section
variable {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
variable {stage : CeilStage code l c q} {positive : 0 < q.denominator}
variable {base : Address} {coeffs : List Input} {d : Nat}
variable {t : TaylorStage stage positive base coeffs d}

noncomputable def sumPair (r : RemainderStage t) : Pair :=
  IntervalAddApplicability.output l r.out t.output r.output t.positive r.positive
    (taylor_ordered t) r.ordered

noncomputable def sumCursor (r : RemainderStage t) : Cursor :=
  RationalIntervalAddCalls.after l r.out t.output r.output

theorem sum_source (lib : Library code) (r : RemainderStage t)
    (dBound : d ≤ 64) (room : c.top+16000 < PoolCalls.capacity) :
    SourceCall Header.layout code 7 "radd" [t.output.source,r.output.source]
      r.out.state (sumPair r).source (sumCursor r).state := by
  unfold sumPair
  rw [(IntervalAddApplicability.output_spec l r.out t.output r.output
    t.positive r.positive (taylor_ordered t) r.ordered).1]
  have top := remainder_top r
  exact RationalIntervalAddCalls.radd_closed code lib.polynomial.body.radd
    lib.polynomial.body.qa lib.polynomial.body.addLibrary r.valid (by omega) _ _
    (polynomial_remainder_live r) r.live t.positive r.positive

theorem sum_valid (r : RemainderStage t) (dBound : d ≤ 64)
    (room : c.top+16000 < PoolCalls.capacity) : Valid l (sumCursor r) := by
  have top := remainder_top r
  exact RationalIntervalAddCalls.after_valid r.valid (by omega) _ _

theorem sum_live (r : RemainderStage t) : (sumPair r).Live (sumCursor r).state :=
  (IntervalAddApplicability.output_spec l r.out t.output r.output
    t.positive r.positive (taylor_ordered t) r.ordered).2.1

theorem sum_positive (r : RemainderStage t) : (sumPair r).Positive :=
  (IntervalAddApplicability.output_spec l r.out t.output r.output
    t.positive r.positive (taylor_ordered t) r.ordered).2.2.1

theorem sum_ordered (r : RemainderStage t) :
    (sumPair r).lo.mathematical.value ≤ (sumPair r).hi.mathematical.value :=
  IntervalAddApplicability.output_order l r.out t.output r.output
    t.positive r.positive (taylor_ordered t) r.ordered

theorem sum_top (r : RemainderStage t) : (sumCursor r).top ≤ c.top+3060+108*(d+1) := by
  change (RationalIntervalAddCalls.after l r.out t.output r.output).top ≤ _
  rw [RationalIntervalAddCalls.after_top]
  have top := remainder_top r
  omega

abbrev PowerStage (r : RemainderStage t) :=
  IntervalPowerCalls.FramedResult code l (sumCursor r) (sumPair r) (powerValue stage)
    (sum_ordered r)

theorem power_stage (lib : Library code) (r : RemainderStage t)
    (bound : kValue stage < 32) (dBound : d ≤ 64)
    (room : c.top+16000 < PoolCalls.capacity) : Nonempty (PowerStage r) := by
  have top := sum_top r
  exact IntervalPowerCalls.rpow_positive_framed code lib.rpow lib.powers
    (sum_valid r dBound room) (by omega) (sumPair r) (powerValue stage)
    (sum_live r) (sum_positive r) (sum_ordered r)
    (power_bound stage bound).1 (power_bound stage bound).2

theorem final_top {r : RemainderStage t} (p : PowerStage r) :
    p.out.top ≤ c.top+8180+108*(d+1) := by
  have first := sum_top r
  have second := p.top
  omega

end
end ScopedC.ExpPointCalls
