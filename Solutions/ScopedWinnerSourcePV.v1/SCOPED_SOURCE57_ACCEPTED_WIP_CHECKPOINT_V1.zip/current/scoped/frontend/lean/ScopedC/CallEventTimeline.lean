/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEvents

namespace ScopedC.CallEvents
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- A monotone allocation-count key is only a proof lookup device. Every
event still contains an actual lower-rank source execution, and one rechecks
its complete name, arguments and full input state before returning anything. -/
def timeKey {cfg : Layout} {code : List Function} {rank : Nat}
    (e : Event cfg code rank) : Nat := e.before.nats.values.length

theorem find_timeline {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map timeKey).Nodup)
    (e : Event cfg code rank) (member : e∈events) :
    events.find? (fun x => decide (timeKey x=timeKey e))=some e := by
  induction events with
  | nil => simp at member
  | cons first rest ih =>
    have un : timeKey first∉rest.map timeKey ∧ (rest.map timeKey).Nodup := by
      simpa only [List.map_cons,List.nodup_cons] using unique
    rcases List.mem_cons.mp member with same | later
    · subst e
      simp
    · have distinct : timeKey first≠timeKey e := by
        intro same
        apply un.1
        rw[same]
        exact List.mem_map.mpr ⟨e,later,rfl⟩
      simpa only [List.find?_cons,distinct,decide_false,Bool.false_eq_true,↓reduceIte] using ih un.2 later

noncomputable def timeline {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) : Call := fun name args before =>
  match events.find? (fun e=>decide (timeKey e=before.nats.values.length)) with
  | none => none
  | some e => one e name args before

theorem timeline_self {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map timeKey).Nodup)
    (e : Event cfg code rank) (member : e∈events) :
    timeline events e.name e.args e.before=some (e.value,e.after) := by
  have found:=find_timeline events unique e member
  unfold timeline
  rw[show events.find? (fun x=>decide (timeKey x=e.before.nats.values.length))=some e from found]
  exact one_self e

theorem timeline_closed {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) {name : String} {args : List Value} {s t : State} {v : Value}
    (h : timeline events name args s=some (v,t)) : SourceCall cfg code rank name args s v t := by
  unfold timeline at h
  split at h
  · contradiction
  · exact one_closed _ h

/-- Abstracting the service prevents symbolic pool heaps being expanded by
proof elaboration. No event can be constructed without its actual source call. -/
theorem timeline_service {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map timeKey).Nodup) :
    ∃service : Call,
      (∀e∈events,service e.name e.args e.before=some (e.value,e.after)) ∧
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall cfg code rank name args before value after) :=
  ⟨timeline events,timeline_self events unique,fun _ _ _ _ _ h=>timeline_closed events h⟩

end ScopedC.CallEvents
