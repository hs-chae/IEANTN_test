/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEventKeys

namespace ScopedC.CallEvents
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false

/-- A proof service cannot answer at a state outside every actual recorded
callee start. This is a composition fact, never an executable output oracle. -/
theorem service_none_of_size {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (name : String) (args : List Value) (s : State)
    (different : ∀e∈events,s.nats.values.length≠e.before.nats.values.length) :
    service events name args s=none := by
  induction events with
  | nil => rfl
  | cons e es ih =>
    have first:=one_other_size e name args s (different e List.mem_cons_self)
    have rest:=ih (fun e member=>different e (List.mem_cons_of_mem _ member))
    unfold service append
    rw[first]
    exact rest

end ScopedC.CallEvents
