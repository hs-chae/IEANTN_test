/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareLn2FrontSource
import ScopedC.PrepareLn2FrontFrames
import ScopedC.AtanhNarrowFrames

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

abbrev AtanhStage (code : List Function) (l : PoolCalls.PoolLayout) (c : Cursor)
    (d : Nat) (coeffs : List Input) :=
  AtanhCalls.NarrowFramedResult code l (beforeAtanh l c) (ratio l c) d coeffs

theorem ratio_narrow (l : PoolCalls.PoolLayout) (c : Cursor) : |(ratio l c).mathematical.value|<1 := by
  rw[ratio_value]
  norm_num

/-- Concrete atan(1/3) applicability from the actual prepared coefficient
frame, with point(qi2) and arbitrary caller objects retained. -/
theorem atanh_stage (code : List Function) (installed : Generated.f_atanhPoint∈code)
    (lib : AtanhCalls.Library code) {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (stopped : f.k=d+1) (room : f.cursor.top+9022<PoolCalls.capacity) :
    Nonempty (AtanhStage code l f.cursor d f.atanhCoeffs) :=
  AtanhCalls.atanh_narrow_framed code installed lib (beforeAtanh_valid f.context (by omega))
    (ratio l f.cursor) (ratio_live l f.cursor) (ratio_positive l f.cursor) (ratio_narrow l f.cursor) d object
    (beforeAtanhTable f.context (by omega) f.atanhAt)
    (by rw[beforeAtanh_globals];exact f.atanhLookup)
    (beforeAtanh_depth f.depthAt f.depthApart) f.depthApart f.depthBound
    (f.atanhLength.trans stopped) (by rw[beforeAtanh_top];omega)

theorem atanh_decoded {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs)
    (values : TaylorCalls.coefficientValues coeffs=IntervalRat.atanhTaylorCoeffs d) :
    NumericRepresentation.interval a.out.state a.output.source=
      some (IntervalRat.atanhPointComputable (1/3) d) := by
  have result:=a.decoded (ratio_narrow l c)
  rw[ratio_value,values,IntervalRat.atanhPointComputableWithCoeffs_eq] at result
  exact result

theorem atanh_values {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs)
    (values : TaylorCalls.coefficientValues coeffs=IntervalRat.atanhTaylorCoeffs d) :
    a.output.lo.mathematical.value=(IntervalRat.atanhPointComputable (1/3) d).lo ∧
    a.output.hi.mathematical.value=(IntervalRat.atanhPointComputable (1/3) d).hi :=
  RationalIntervalFrames.Pair.values_of_decoded a.live a.positive (atanh_decoded a values)

end ScopedC.PrepareSource.Ln2
