/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderCeil

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 150000
attribute [local irreducible] radius

/-- The source's raw unsigned ceiling magnitude equals the mathematical
ceiling, including normalized zero. This discharges ABI guards from an input
bound rather than assuming a successful small conversion. -/
theorem ceil_magnitude_cast {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {a : Pair} (stage : CeilStage code l c a) (positive : a.Positive) :
    (stage.endpoint.magnitude:Int)=Int.ceil (radius l c a).mathematical.value := by
  have magnitude : (stage.endpoint.magnitude:Int)=stage.endpoint.mathematical.value := by
    simp only[Endpoint.mathematical,ScopedNumerical.Signed.value,ceil_sign stage positive,Bool.false_eq_true,↓reduceIte]
  rw[magnitude,stage.value,ScopedNumerical.ProofBox.ceilDiv_eq_ceil]
  · congr 1
  · have positiveDen:=radius_positive (l:=l) (c:=c) a positive
    exact_mod_cast ne_of_gt positiveDen

theorem small_guard_bound {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {a : Pair} (stage : CeilStage code l c a) (positive : a.Positive)
    (bound : Int.ceil (max |a.lo.mathematical.value| |a.hi.mathematical.value|)<4294967295) :
    stage.endpoint.magnitude<4294967295 := by
  rw[←radius_value (l:=l) (c:=c) a positive,←ceil_magnitude_cast stage positive] at bound
  exact_mod_cast bound

end ScopedC.ExpRemainderCalls
