/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalDecimalLiteral
import ScopedC.ExpressionTemplates
namespace ScopedC.RationalDecimalLiteral
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def initializer (n d : Nat) : Syntax.Expr := .call (.var "qm") [
  .call (.var "smake") [.call (.var "decimal") [.stringLiteral (toString n)],.nat 0],
  .call (.var "decimal") [.stringLiteral (toString d)]]

theorem expression (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    {n d : Nat} (D : Stages code l c n d)
    (numerator : service "decimal" [.pointer ⟨c.state.heap.length,0,[]⟩ false]
      (textCursor c n).state=some (.natObject D.numeratorSlot,D.numerator.state))
    (signed : service "smake" [.natObject D.numeratorSlot,DecimalDigits.integer 0]
      D.numerator.state=some ((endpoint D.numeratorSlot n).source,(next l D.numerator 0).state))
    (denominator : service "decimal"
      [.pointer ⟨(next l D.numerator 0).state.heap.length,0,[]⟩ false]
      (textCursor (next l D.numerator 0) d).state=
        some (.natObject D.denominatorSlot,D.denominator.state))
    (rational : service "qm" [(endpoint D.numeratorSlot n).source,.natObject D.denominatorSlot]
      D.denominator.state=some (D.output.source,(after D).state)) :
    evalExpr Header.layout service 1000 c.state (initializer n d)=
      some (D.output.source,(after D).state) := by
  have ntext : evalExpr Header.layout service 997 c.state (.stringLiteral (toString n))=
      some (.pointer ⟨c.state.heap.length,0,[]⟩ false,(textCursor c n).state) :=
    DecimalText.evaluate_literal service c.state (toString n) (DecimalText.natural_ascii n) 996
  have parsed := ExpressionTemplates.call_one Header.layout service ntext numerator
  have smade : evalExpr Header.layout service 999 c.state
      (.call (.var "smake") [.call (.var "decimal") [.stringLiteral (toString n)],.nat 0])=
      some ((endpoint D.numeratorSlot n).source,(next l D.numerator 0).state) :=
    ExpressionTemplates.call_two Header.layout service parsed (by rfl) signed
  have dtext : evalExpr Header.layout service 998 (next l D.numerator 0).state
      (.stringLiteral (toString d))=
      some (.pointer ⟨(next l D.numerator 0).state.heap.length,0,[]⟩ false,
        (textCursor (next l D.numerator 0) d).state) :=
    DecimalText.evaluate_literal service (next l D.numerator 0).state (toString d)
      (DecimalText.natural_ascii d) 997
  have dparsed := ExpressionTemplates.call_one Header.layout service dtext denominator
  exact ExpressionTemplates.call_two Header.layout service smade dparsed rational

end ScopedC.RationalDecimalLiteral
