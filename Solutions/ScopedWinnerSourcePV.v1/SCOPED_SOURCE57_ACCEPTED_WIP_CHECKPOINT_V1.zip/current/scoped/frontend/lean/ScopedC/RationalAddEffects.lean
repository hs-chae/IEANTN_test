/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAddShape
import ScopedC.CursorBorrow
namespace ScopedC.RationalAddCalls
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem trace (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    c14 l c a b=CursorFrames.advance l c (effects l c a b) := by rfl

theorem top14 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (c14 l c a b).top=c.top+14 := by rw[trace,CursorFrames.top_advance];rfl

theorem preserves {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Input} {slot n : Nat}
    (live : NatArena.Borrow c.state.nats slot n) :
    NatArena.Borrow (c14 l c a b).state.nats slot n := by
  rw[trace]
  exact CursorBorrow.preserves _ live

theorem context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+13<PoolCalls.capacity) (a b : Input) : Valid l (c14 l c a b) := by
  rw[trace]
  apply CursorFrames.advance_valid ctx
  change c.top+14≤PoolCalls.capacity
  omega
end ScopedC.RationalAddCalls
