/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalIntervalAddRefinement
import ScopedC.SourceScaleFrames

namespace ScopedC.RationalIntervalAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000
attribute [local irreducible] finish

theorem finish_shape (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (finish l c a b).state.heap.length=c.state.heap.length+2 ∧
    (finish l c a b).state.env=(base c a b).state.env := by
  have first : (middle l c a b).state.heap.length=(base c a b).state.heap.length ∧
      (middle l c a b).state.env=(base c a b).state.env := by
    unfold middle
    exact RationalAddCalls.shape l (base c a b) a.lo b.lo
  have second : (finish l c a b).state.heap.length=(middle l c a b).state.heap.length ∧
      (finish l c a b).state.env=(middle l c a b).state.env := by
    unfold finish
    exact RationalAddCalls.shape l (middle l c a b) a.hi b.hi
  constructor
  · rw[second.1,first.1]
    simp [base,RationalIntervalFrames.framed,CursorFrames.framed,TwoFrames.frame,allocate]
  · exact second.2.trans first.2

theorem after_heap_length (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (after l c a b).state.heap.length=c.state.heap.length := by
  change ((finish l c a b).state.heap.take c.state.heap.length).length=_
  rw[List.length_take,(finish_shape l c a b).1]
  omega
theorem after_env (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (after l c a b).state.env=c.state.env := rfl
theorem after_globals (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (after l c a b).state.globals=c.state.globals := by
  change (finish l c a b).state.globals=c.state.globals
  unfold finish
  rw[RationalAddCalls.trace,CursorSingleFrames.advance_globals]
  unfold middle
  rw[RationalAddCalls.trace,CursorSingleFrames.advance_globals]
  rfl
theorem after_other (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (slot : Nat)
    (bound : slot < c.state.heap.length) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (after l c a b).state.heap[slot]?=c.state.heap[slot]? := by
  change ((finish l c a b).state.heap.take c.state.heap.length)[slot]?=_
  rw[List.getElem?_take_of_lt bound]
  unfold finish
  rw[RationalAddCalls.trace,CursorSingleFrames.advance_other l _ _ slot hp ht hh]
  unfold middle
  rw[RationalAddCalls.trace,CursorSingleFrames.advance_other l _ _ slot hp ht hh]
  simp [base,RationalIntervalFrames.framed,CursorFrames.framed,TwoFrames.frame,allocate,List.getElem?_append_left bound]

theorem preserves_nat {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Pair) {slot n : Nat}
    (live : NatArena.Borrow c.state.nats slot n) : NatArena.Borrow (after l c a b).state.nats slot n := by
  have first : NatArena.Borrow (middle l c a b).state.nats slot n := by
    unfold middle
    exact RationalAddCalls.preserves (c:=base c a b) (a:=a.lo) (b:=b.lo) live
  change NatArena.Borrow (finish l c a b).state.nats slot n
  unfold finish
  exact RationalAddCalls.preserves (c:=middle l c a b) (a:=a.hi) (b:=b.hi) first

theorem after_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : (after l c a b).top=c.top+28 := by
  change (finish l c a b).top=_
  unfold finish
  rw[RationalAddCalls.top14,middle_top]

theorem after_size (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (after l c a b).state.nats.values.length=c.state.nats.values.length+28 := by
  change (finish l c a b).state.nats.values.length=_
  unfold finish
  rw[RationalAddCalls.trace,CursorEffects.size]
  unfold middle
  rw[RationalAddCalls.trace,CursorEffects.size]
  rfl

theorem after_binding {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Pair)
    {name ty : String} {v : Value} {slot : Nat} (h : LocalBinding.At c.state name ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    LocalBinding.At (after l c a b).state name ty v slot :=
  LocalBinding.memory h (after_env l c a b)
    (after_other l c a b slot (List.getElem?_eq_some_iff.mp h.memory).choose hp ht hh)

theorem preserves_scale {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Pair)
    {object slot d : Nat} (scale : SourceFromS.ScaleAt c.state object slot d) :
    SourceFromS.ScaleAt (after l c a b).state object slot d := by
  have safe:=SourceScaleFrames.separated ctx scale
  have bound:=(List.getElem?_eq_some_iff.mp scale.storage).choose
  exact ⟨by rw[after_globals];exact scale.lookup,
    by rw[after_other l c a b object bound safe.1 safe.2.1 safe.2.2];exact scale.storage,
    preserves_nat a b scale.live⟩

end ScopedC.RationalIntervalAddCalls
