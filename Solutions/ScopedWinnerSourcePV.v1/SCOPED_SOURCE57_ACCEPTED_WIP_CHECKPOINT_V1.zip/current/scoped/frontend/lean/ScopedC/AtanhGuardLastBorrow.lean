/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhWideSizes
import ScopedC.AtanhPower

namespace ScopedC.AtanhCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

/-- The actual guard's last allocation is still owned. This supplies a valid
lower bound on later arena lengths without assuming all old arena slots live. -/
theorem guard_last_borrow (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    NatArena.Borrow (afterGuard l c q).state.nats (c.state.nats.values.length+9) 0 := by
  let before:=CursorFrames.advance l (afterR l c q)
    [1,0,1,0,(absInput q).numerator.magnitude*(oneInput l c q).denominator,
      0,0,(oneInput l c q).numerator.magnitude*(absInput q).denominator]
  have size : before.state.nats.values.length=c.state.nats.values.length+9 := by
    dsimp only [before]
    rw[CursorEffects.size,afterR_size]
    rfl
  have alive:=PoolCursor.next_borrow l before 0
  rw[size] at alive
  rw[guard_trace]
  exact alive

theorem power_arena_lower {code : List Syntax.Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {q : Input} {d : Nat} (stage : PowerStage code l c q d) :
    c.state.nats.values.length + 10 ≤ stage.out.state.nats.values.length := by
  have last:=stage.preserves _ _ (guard_last_borrow l c q)
  have bound:=(List.getElem?_eq_some_iff.mp last.1).choose
  omega

end ScopedC.AtanhCalls
