/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerHighestBit
import ScopedC.IntervalPowerScanLoop

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def parameters (c : Cursor) (a : Pair) (n : Nat) : Cursor :=
  CursorFrames.framed c "RI" "a" a.source "unsigned int" "n" (PoolCalls.word n)
def bitStart (c : Cursor) (a : Pair) (n : Nat) : Cursor :=
  CursorLocals.allocated (parameters c a n) "unsigned int" "bit" (PoolCalls.word 1)

theorem bind_parameters (c : Cursor) (a : Pair) (n : Nat) (ha : a.Live c.state) (hn : n<2^32) :
    bindArgs Header.layout [("RI","a"),("unsigned int","n")] [a.source,PoolCalls.word n] c.state=
      some (parameters c a n).state :=
  TypedFrames.bind_two Header.layout c.state "RI" "a" "unsigned int" "n"
    a.source (PoolCalls.word n) a.source (PoolCalls.word n)
    (Pair.cast (s:={c.state with env:=[]}) ha "RI" (by decide +kernel))
    (RationalUnsignedCalls.cast_parameter (allocate {c.state with env:=[]} "RI" "a" (some a.source)) n hn)

theorem parameters_a (c : Cursor) (a : Pair) (n : Nat) :
    LocalBinding.At (parameters c a n).state "a" "RI" a.source c.state.heap.length :=
  LocalBinding.allocate_other (LocalBinding.allocate_head {c.state with env:=[]} "a" "RI" a.source (Pair.initialized a))
    "n" "unsigned int" (some (PoolCalls.word n)) (by decide +kernel)
theorem parameters_n (c : Cursor) (a : Pair) (n : Nat) :
    LocalBinding.At (parameters c a n).state "n" "unsigned int" (PoolCalls.word n) (c.state.heap.length+1) := by
  simpa only[parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.length_append,List.length_singleton] using
    LocalBinding.allocate_head (allocate {c.state with env:=[]} "RI" "a" (some a.source))
      "n" "unsigned int" (PoolCalls.word n) (by rfl)
theorem parameters_length (c : Cursor) (a : Pair) (n : Nat) :
    (parameters c a n).state.heap.length=c.state.heap.length+2 := by simp [parameters,CursorFrames.framed,TwoFrames.frame,allocate]
theorem bit_a (c : Cursor) (a : Pair) (n : Nat) :
    LocalBinding.At (bitStart c a n).state "a" "RI" a.source c.state.heap.length :=
  LocalBinding.allocate_other (parameters_a c a n) "bit" "unsigned int" (some (PoolCalls.word 1)) (by decide +kernel)

def initialBitFrame {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a : Pair) (n : Nat) (positive : 0<n) (bound : n<2^32) : IntervalPowerBits.Frame l n where
  cursor:=bitStart c a n
  bit:=1
  power:=0
  nSlot:=c.state.heap.length+1
  bitSlot:=c.state.heap.length+2
  context:=CursorLocals.allocated_valid (CursorFrames.framed_valid ctx "RI" "a" a.source "unsigned int" "n" (PoolCalls.word n))
    "unsigned int" "bit" (PoolCalls.word 1)
  atN:=LocalBinding.allocate_other (parameters_n c a n) "bit" "unsigned int" (some (PoolCalls.word 1)) (by decide +kernel)
  atBit:=by
    simpa only[bitStart,CursorLocals.allocated,parameters_length] using
      LocalBinding.allocate_head (parameters c a n).state "bit" "unsigned int" (PoolCalls.word 1) (by rfl)
  distinct:=by omega
  exponentBound:=bound
  positive:=by decide
  lower:=positive
  powerEq:=rfl

theorem bit_declaration (service : Call) (c : Cursor) (a : Pair) (n : Nat) :
    Declare Header.layout service [{type:="unsigned int",name:="bit",value:=some (.nat 1),arrayExtent:=none}]
      (parameters c a n).state (bitStart c a n).state := by
  have convert:=DecimalDigits.cast_digit (parameters c a n).state 1 (by decide : 1<10)
  simp only[Declare,declarations,List.foldlM]
  change (do let v←evalExpr Header.layout service 1000 (parameters c a n).state (.nat 1)
             let value←castValue Header.layout v.2 100 "unsigned int" v.1
             pure (allocate v.2 "unsigned int" "bit" (some value)))=_
  rw[show evalExpr Header.layout service 1000 (parameters c a n).state (.nat 1)=some (DecimalDigits.integer 1,(parameters c a n).state) from rfl]
  simp only[Bind.bind,Option.bind,convert]
  rfl

def zeroCondition : Expr := .binary "==" (.var "n") (.nat 0)
theorem zero_condition (service : Call) (c : Cursor) (a : Pair) (n : Nat) (hn : n<2^32) :
    Eval Header.layout service zeroCondition (parameters c a n).state (parameters c a n).state
      (boolean Header.layout (decide (n=0))) := by
  refine ⟨3,?_⟩
  apply ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 1 (parameters_n c a n) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) (by rfl)
  change binaryValue Header.layout (parameters c a n).state "==" (NatWrapperCalls.unsigned32 n) (DecimalDigits.integer 0)=_
  rw[UnsignedLiteralControl.literal_lift _ "==" n 0 hn (by decide +kernel)]
  exact UnsignedLiteralControl.binary_eq _ n 0 hn (by decide +kernel)

end ScopedC.IntervalPowerCalls
