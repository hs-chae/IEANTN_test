/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerScanEvents

namespace ScopedC.IntervalPowerScan
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

abbrev While (service : Call) :=
  Loops.WhileRun (Eval Header.layout service) (Declare Header.layout service) truth Scope scanCondition loopBody

structure LoopCertificate (code : List Function) {l : PoolCalls.PoolLayout} {n : Nat} (start : Frame l n) (bits : Nat) where
  finish : Frame l n
  events : List (Event code)
  unique : (events.map CallEvents.timeKey).Nodup
  bounds : ∀e∈events,start.cursor.state.nats.values.length ≤ CallEvents.timeKey e ∧
    CallEvents.timeKey e < finish.cursor.state.nats.values.length
  nats_le : start.cursor.state.nats.values.length ≤ finish.cursor.state.nats.values.length
  execution : ∀service,Answers service events → While service start.cursor.state (.continuing finish.cursor.state)
  stopped : finish.bit=0
  original_eq : original finish=original start
  mathematical_eq : mathematical finish=LeanCert.Core.IntervalRat.pow (original start) n
  top_le : finish.cursor.top ≤ start.cursor.top+160*(bits+1)
  shape : finish.cursor.state.heap.length=start.cursor.state.heap.length ∧ finish.cursor.state.env=start.cursor.state.env

theorem loop_certificate (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) (bits : Nat) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (power : f.bit=2^bits) (lower : 2*f.bit ≤ n)
    (prefixValue : mathematical f=LeanCert.Core.IntervalRat.pow (original f) (n/(f.bit*2)))
    (room : f.cursor.top+160*(bits+1) ≤ PoolCalls.capacity) : Nonempty (LoopCertificate code f bits) := by
  induction bits generalizing f with
  | zero =>
    have one : f.bit=1 := by simpa using power
    have positive : 0<f.bit := by omega
    have stepRoom : f.cursor.top+159<PoolCalls.capacity := by omega
    let next:=iteration f stepRoom
    have stopped : next.bit=0 := by rw[iteration_bit,one]
    have value : mathematical next=LeanCert.Core.IntervalRat.pow (original f) n := by
      have result:=iteration_math f stepRoom prefixValue ((Nat.le_div_iff_mul_le positive).2 lower)
      simpa only[one,Nat.div_one] using result
    have nle : f.cursor.state.nats.values.length ≤ next.cursor.state.nats.values.length := by
      dsimp only[next]
      rw[iteration_size]
      omega
    refine ⟨{
      finish:=next
      events:=iterationEvents code installed lib f stepRoom
      unique:=event_unique code installed lib f stepRoom
      bounds:=event_bounds code installed lib f stepRoom
      nats_le:=nle
      execution:=?_
      stopped:=stopped
      original_eq:=iteration_original f stepRoom
      mathematical_eq:=value
      top_le:=iteration_top_le f stepRoom
      shape:=iteration_shape f stepRoom
    }⟩
    intro service answers
    exact Loops.WhileRun.next (condition_eval service f)
      (by simp [UnsignedLiteralControl.truth_boolean,positive])
      (event_run code installed lib f stepRoom positive service answers)
      (Loops.WhileRun.done (condition_eval service next) (by simp [UnsignedLiteralControl.truth_boolean,stopped]))
  | succ bits ih =>
    have positive : 0<f.bit := by rw[power];exact Nat.two_pow_pos _
    have stepRoom : f.cursor.top+159<PoolCalls.capacity := by omega
    let next:=iteration f stepRoom
    have nextPower : next.bit=2^bits := by rw[iteration_bit,power,IntervalPowerMathematics.power_two_half]
    have nextLower : 2*next.bit ≤ n := by
      rw[nextPower]
      rw[power,pow_succ] at lower
      omega
    have nextPrefix : mathematical next=LeanCert.Core.IntervalRat.pow (original next) (n/(next.bit*2)) := by
      have result:=iteration_math f stepRoom prefixValue ((Nat.le_div_iff_mul_le positive).2 lower)
      rw[show original next=original f from iteration_original f stepRoom,nextPower,←pow_succ,←power]
      exact result
    have nextRoom : next.cursor.top+160*(bits+1) ≤ PoolCalls.capacity := by
      have h:=iteration_top_le f stepRoom
      change (iteration f stepRoom).cursor.top+160*(bits+1) ≤ PoolCalls.capacity
      omega
    obtain ⟨tail⟩:=ih next nextPower nextLower nextPrefix nextRoom
    have nle : f.cursor.state.nats.values.length ≤ next.cursor.state.nats.values.length := by
      dsimp only[next]
      rw[iteration_size]
      omega
    let front:=iterationEvents code installed lib f stepRoom
    refine ⟨{
      finish:=tail.finish
      events:=front++tail.events
      unique:=?_
      bounds:=?_
      nats_le:=nle.trans tail.nats_le
      execution:=?_
      stopped:=tail.stopped
      original_eq:=tail.original_eq.trans (iteration_original f stepRoom)
      mathematical_eq:=?_
      top_le:=?_
      shape:=?_
    }⟩
    · rw[List.map_append,List.nodup_append]
      refine ⟨event_unique code installed lib f stepRoom,tail.unique,?_⟩
      intro a ha b hb same
      obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
      obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
      have leftBound:=event_bounds code installed lib f stepRoom ea hea
      have rightBound:=tail.bounds eb heb
      dsimp only[next] at rightBound
      omega
    · intro e member
      rcases List.mem_append.mp member with frontMember | tailMember
      · have h:=event_bounds code installed lib f stepRoom e frontMember
        exact ⟨h.1,Nat.lt_of_lt_of_le h.2 tail.nats_le⟩
      · have h:=tail.bounds e tailMember
        exact ⟨nle.trans h.1,h.2⟩
    · intro service answers
      exact Loops.WhileRun.next (condition_eval service f)
        (by simp [UnsignedLiteralControl.truth_boolean,positive])
        (event_run code installed lib f stepRoom positive service (fun e h=>answers e (List.mem_append_left _ h)))
        (tail.execution service (fun e h=>answers e (List.mem_append_right _ h)))
    · rw[tail.mathematical_eq,show original next=original f from iteration_original f stepRoom]
    · have h:=iteration_top_le f stepRoom
      have t:=tail.top_le
      dsimp only[next] at t
      omega
    · have h:=iteration_shape f stepRoom
      exact ⟨tail.shape.1.trans h.1,tail.shape.2.trans h.2⟩

end ScopedC.IntervalPowerScan
