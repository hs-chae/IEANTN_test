/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareFramedCoefficientStage

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

theorem expWork_globals {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) (active : f.k ≤ d) :
    (expWork f room active).cursor.state.globals=f.cursor.state.globals := by
  change (expStoreCursor f room).state.globals=_
  unfold expStoreCursor
  exact expDivide_globals f

theorem CoeffWork.atanhWritten_globals {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) :
    (w.atanhWritten room positive bound).cursor.state.globals=w.cursor.state.globals := by
  unfold CoeffWork.atanhWritten
  split
  · change (RationalDivideCalls.nonzeroAfter l (w.oddCounter room).cursor (w.qiInput 1)
      ((w.oddOne room).qiInput w.k)).state.globals=_
    rw[RationalDivideCalls.nonzero_globals]
    exact (CursorSingleFrames.advance_globals l (w.oddOne room).cursor [w.k,0,1]).trans
      (CursorSingleFrames.advance_globals l w.cursor [1,0,1])
  · exact CursorSingleFrames.advance_globals l w.cursor [0,0,1]

theorem coefficientStep_globals {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (coefficientStep f active room).cursor.state.globals=f.cursor.state.globals := by
  change (stepWork f active room).cursor.state.globals=_
  unfold stepWork
  exact (CoeffWork.atanhWritten_globals _ _ _ _).trans (expWork_globals f _ active)

theorem actualSeed_globals {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    (actualSeed ready d bound).cursor.state.globals=state.globals := by
  change (CursorFrames.advance (layout base) (depthCursor ready d) [1,100,1<<<100]).state.globals=_
  rw[CursorSingleFrames.advance_globals]
  rfl

theorem coefficientStart_globals {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) : (coefficientStart ready d bound).cursor.state.globals=state.globals := by
  change (initAtanhCursor (actualSeed ready d bound) _).state.globals=_
  rw[initAtanh_globals,actualSeed_globals]

theorem framed_coefficient_stage_globals (code : List Function) (lib : CoeffLibrary code)
    {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    ∃stage : CoefficientStage code ready d bound,
      SourceFromS.ScaleAt stage.loop.finish.cursor.state (base+4)
        (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100) ∧
      SourceScalarGlobal.At stage.loop.finish.cursor.state "preparedLn2" "RI" (base+7)
        (some ScopedIO.ApplicationInit.zeroInterval) ∧
      stage.loop.finish.cursor.state.globals=state.globals := by
  let P : CoeffFrame (layout base) (base+3) d (expBase base) (atanhBase base)→Prop :=
    fun f=>SourceFromS.ScaleAt f.cursor.state (base+4)
      (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100) ∧
      SourceScalarGlobal.At f.cursor.state "preparedLn2" "RI" (base+7)
        (some ScopedIO.ApplicationInit.zeroInterval) ∧ f.cursor.state.globals=state.globals
  have preserve : ∀start active room,P start → P (coefficientStep start active room) := by
    intro start active room properties
    exact ⟨coefficientStep_scale start active room properties.1,
      coefficientStep_scalar start active room properties.2.1 (by decide +kernel) (by decide +kernel),
      (coefficientStep_globals start active room).trans properties.2.2⟩
  obtain ⟨loop,properties⟩:=coefficient_loop_invariant code lib d (coefficientStart ready d bound)
    (by rw[coefficientStart_k];omega)
    (by rw[coefficientStart_top];change 9+35*d ≤ 4000000;omega) P preserve
    ⟨coefficientStart_scale ready d bound,coefficientStart_ln2 ready d bound,coefficientStart_globals ready d bound⟩
  exact ⟨⟨loop⟩,properties⟩

theorem coefficient_finish_unshadowed {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) (name : String) (nk : name≠"k") (nd : name≠"d") :
    stage.loop.finish.cursor.state.env.lookup name=none := by
  rw[stage.loop.shape.2]
  change (("k",_)::(initAtanhCursor (actualSeed ready d bound) _).state.env).lookup name=none
  rw[initAtanh_env]
  change (("k",_)::(CursorFrames.advance (layout base) (depthCursor ready d) [1,100,1<<<100]).state.env).lookup name=none
  rw[(CursorEffects.shape (layout base) (depthCursor ready d) [1,100,1<<<100]).2]
  change (("k",_)::("d",_)::[]).lookup name=none
  simp [List.lookup,beq_eq_false_iff_ne.mpr nk,beq_eq_false_iff_ne.mpr nd]

end ScopedC.PrepareSource
