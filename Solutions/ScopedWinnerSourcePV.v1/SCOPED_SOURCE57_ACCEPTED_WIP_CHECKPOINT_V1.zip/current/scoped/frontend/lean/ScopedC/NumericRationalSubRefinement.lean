/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSubBody
import ScopedC.RationalCanonical

namespace ScopedC.NumericRationalSubRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.RationalSubCalls
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0

def output (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Rational :=
  Rational.normalize (RationalAddCalls.sum l (phase1 l c a b) a (negative b)).mathematical
    (RationalAddCalls.denominator a (negative b))

/-- The actual qn/qa source calls compute canonical subtraction. The final
state is the actual returned callee state with only the qs stack frame popped. -/
theorem qs_math (code : List Function) (installed : Generated.f_qs∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+14<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 7 "qs" [a.source,b.source] c.state (result l c a b) (after l c a b).state ∧
    NumericRepresentation.rational (after l c a b).state (result l c a b)=some (output l c a b) ∧
    (output l c a b).Normalized ∧
    (output l c a b).Represents (a.mathematical.value-b.mathematical.value) ∧
    (output l c a b).value=a.mathematical.value-b.mathematical.value := by
  have hn : (output l c a b).Normalized := Rational.normalize_normalized _ _ (Nat.ne_of_gt (Nat.mul_pos pa pb))
  have hr := Rational.normalized_represents_value (output l c a b) hn
  have hv : (output l c a b).value=a.mathematical.value-b.mathematical.value := value l c a b pa pb
  rw [hv] at hr
  exact ⟨qs_closed code installed lib ctx room a b ha hb pa pb,decoded l c a b pa pb,hn,hr,value l c a b pa pb⟩

end ScopedC.NumericRationalSubRefinement
