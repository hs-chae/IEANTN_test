/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhEffects
import ScopedC.RationalPowerFramedBody

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

abbrev PowerStage (code : List Function) (l : PoolCalls.PoolLayout) (c : Cursor)
    (q : Input) (d : Nat) :=
  RationalPowerCalls.FramedResult code l (afterGuard l c q) (absInput q) (d+1)

theorem power_stage (code : List Function) (installed : Generated.f_qpow∈code)
    (lib : GuardLibrary code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (alive : q.Live c.state) (positive : 0<q.denominator) (d : Nat)
    (dBound : d≤64) (room : c.top+716<PoolCalls.capacity) :
    Nonempty (PowerStage code l c q d) :=
  RationalPowerCalls.qpow_framed code installed lib.powers
    (guard_context ctx q (by omega)) (by rw[guard_top];omega)
    (absInput q) (d+1) (r_guard_live q alive) positive (by omega)

def powerExpression : Expr := .call (.var "qpow")
  [.var "r",.binary "+" (.var "depth") (.nat 1)]

theorem power_eval (service : Call) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) (d object : Nat)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (dBound : d≤64)
    (room : c.top+9<PoolCalls.capacity) {out : Cursor} {result : Input}
    (answer : service "qpow" [(absInput q).source,PoolCalls.word (d+1)]
      (afterGuard l c q).state=some (result.source,out.state)) :
    evalExpr Header.layout service 4 (afterGuard l c q).state powerExpression=
      some (result.source,out.state) := by
  have rEval:=LocalBinding.eval service 2 (r_guard_binding ctx q room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have dEval:=SourceUnsignedGlobal.eval service 1 (guard_depth q depth apart)
    (guard_depth_unshadowed l c q) (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have exponent : evalExpr Header.layout service 3 (afterGuard l c q).state
      (.binary "+" (.var "depth") (.nat 1))=
      some (PoolCalls.word (d+1),(afterGuard l c q).state) :=
    ExpressionTemplates.binary Header.layout service (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) dEval
      (show evalExpr Header.layout service 2 (afterGuard l c q).state (.nat 1)=
        some (DecimalDigits.integer 1,(afterGuard l c q).state) from rfl)
    (PoolCalls.binary_add_one (afterGuard l c q).state d (by omega))
  exact ExpressionTemplates.call_two Header.layout service rEval exponent answer

def power_table {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) (d : Nat) (stage : PowerStage code l c q d)
    (room : c.top+9<PoolCalls.capacity) {base : Address} {coeffs : List Input}
    (table : CoefficientTableRead.TableAt c.state base coeffs) :
    CoefficientTableRead.TableAt stage.out.state base coeffs := by
  have before:=guard_table ctx q room table
  have safe:=CoefficientTableRead.pool_separated (guard_context ctx q room) before
  exact CoefficientTableRead.memory before
    (stage.other base.object (List.getElem?_eq_some_iff.mp before.memory).choose
      safe.1 safe.2.1 safe.2.2) stage.preserves

theorem power_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (q : Input) (d : Nat) (stage : PowerStage code l c q d) {object : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At stage.out.state "depth" object d := by
  have before:=guard_depth q depth apart
  exact SourceUnsignedGlobal.memory before stage.globals
    (stage.other object (List.getElem?_eq_some_iff.mp before.storage).choose
      apart.1 apart.2.1 apart.2.2)

theorem power_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (q : Input) (d : Nat) (stage : PowerStage code l c q d) :
    stage.output.mathematical.value=|q.mathematical.value|^(d+1) := by
  rw[stage.value]
  exact congrArg (fun x:Rat=>x^(d+1)) (RationalAbsApplicability.value q)

end ScopedC.AtanhCalls
