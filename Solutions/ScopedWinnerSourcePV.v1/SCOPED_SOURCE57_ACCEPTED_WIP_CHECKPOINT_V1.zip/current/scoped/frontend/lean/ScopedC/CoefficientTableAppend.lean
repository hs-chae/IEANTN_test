/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientTableFrames

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def changed (s : State) (base : Address) (cells : List (Option Value)) (k : Nat) (q : Input) : State :=
  {s with heap:=s.heap.set base.object {type:="Q",cells:=cells.set k (some q.source),isArray:=true}}

/-- The exact physical coefficient-prefix extension made by the original
prepare assignment. Cells after the prefix retain their actual prior values. -/
def append {s : State} {base : Address} {coeffs : List Input} (table : TableAt s base coeffs)
    (q : Input) (alive : q.Live s) (positive : 0<q.denominator)
    (bound : coeffs.length<table.cells.length) :
    TableAt (changed s base table.cells coeffs.length q) base (coeffs++[q]) := by
  refine ⟨table.cells.set coeffs.length (some q.source),?_,table.zeroIndex,table.emptyFields,?_,?_,?_⟩
  · exact List.getElem?_set_self (List.getElem?_eq_some_iff.mp table.memory).choose
  · intro k hk
    by_cases old : k<coeffs.length
    · have element : (coeffs++[q])[k]'hk=coeffs[k] := by simp [List.getElem_append_left,old]
      rw[List.getElem?_set_ne (ne_of_gt old),element]
      exact table.entries k old
    · have last : k=coeffs.length := by simp only[List.length_append,List.length_singleton] at hk;omega
      subst k
      have element : (coeffs++[q])[coeffs.length]'hk=q := by simp
      rw[List.getElem?_set_self bound,element]
  · intro k hk
    by_cases old : k<coeffs.length
    · have element : (coeffs++[q])[k]'hk=coeffs[k] := by simp [List.getElem_append_left,old]
      rw[element]
      exact table.live k old
    · have last : k=coeffs.length := by simp only[List.length_append,List.length_singleton] at hk;omega
      subst k
      have element : (coeffs++[q])[coeffs.length]'hk=q := by simp
      rw[element]
      exact alive
  · intro k hk
    by_cases old : k<coeffs.length
    · have element : (coeffs++[q])[k]'hk=coeffs[k] := by simp [List.getElem_append_left,old]
      rw[element]
      exact table.positive k old
    · have last : k=coeffs.length := by simp only[List.length_append,List.length_singleton] at hk;omega
      subst k
      have element : (coeffs++[q])[coeffs.length]'hk=q := by simp
      rw[element]
      exact positive

/-- Every real Q array admits the empty prefix, without assuming any live
rational value in the static zero/null cells before prepare writes them. -/
def empty {s : State} {base : Address} {cells : List (Option Value)}
    (memory : s.heap[base.object]?=some {type:="Q",cells:=cells,isArray:=true})
    (zero : base.index=0) (fields : base.fields=[]) : TableAt s base [] :=
  ⟨cells,memory,zero,fields,fun _ h=>False.elim (Nat.not_lt_zero _ h),
    fun _ h=>False.elim (Nat.not_lt_zero _ h),fun _ h=>False.elim (Nat.not_lt_zero _ h)⟩

end ScopedC.CoefficientTableRead
