/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientNext
import ScopedC.PrepareCoefficientEffects

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

theorem coefficientStep_shape {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (coefficientStep f active room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (coefficientStep f active room).cursor.state.env=f.cursor.state.env := by
  change (stepWork f active room).cursor.state.heap.length=_ ∧ (stepWork f active room).cursor.state.env=_
  unfold stepWork
  constructor
  · change ((CoeffWork.atanhWritten _ _ _ _).cursor.state.heap.set _ _).length=_
    rw[List.length_set]
    exact (CoeffWork.atanhWritten_shape _ _ _ _).1.trans (expWork_shape f _ active).1
  · change (CoeffWork.atanhWritten _ _ _ _).cursor.state.env=_
    exact (CoeffWork.atanhWritten_shape _ _ _ _).2.trans (expWork_shape f _ active).2

theorem coefficientStep_top {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (coefficientStep f active room).cursor.top ≤ f.cursor.top+35 := by
  change (stepWork f active room).cursor.top ≤ _
  unfold stepWork
  change (CoeffWork.atanhWritten _ _ _ _).cursor.top ≤ _
  refine (CoeffWork.atanhWritten_top _ _ _ _).trans ?_
  change (expStoreCursor f _).top+19 ≤ f.cursor.top+35
  rw[expStore_top]

theorem coefficientStep_size {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (coefficientStep f active room).cursor.state.nats.values.length=
      f.cursor.state.nats.values.length+(if f.k%2=1 then 35 else 19) := by
  change (stepWork f active room).cursor.state.nats.values.length=_
  unfold stepWork
  change (CoeffWork.atanhWritten _ _ _ _).cursor.state.nats.values.length=_
  apply (CoeffWork.atanhWritten_size _ _ _ _).trans
  have half:=expWork_size f (by omega) active
  change (expWork f _ active).cursor.state.nats.values.length+
    (if f.k%2=1 then 19 else 3)=_
  rw[half]
  split_ifs <;> omega

end ScopedC.PrepareSource
