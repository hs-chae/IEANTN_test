/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceCeilData
import ScopedC.SourceFloorQTrace
import ScopedC.SourceCeilQ
import ScopedC.CallEventNames
namespace ScopedC.SourceCeilQNormalizedTrace
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.DyadicRepresentation ScopedNumerical ScopedC.SourceCeilData ScopedC.SourceCeilQ
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000


/-- Whole actual C ceilQ body: installed qn, all-path source floorQ and installed
sn are composed from their proved executions. The real returned signed integer
is the unchanged exact numerical model's ceilDiv, with all stack, pool, Nat-token,
parameter and return-cast applicability discharged. -/
theorem ceilQ_closed_trace (code : List Function) (installed : Generated.f_ceilQ∈code)
    (floorInstalled : Generated.f_floorQ∈code) (qnInstalled : Generated.f_qn∈code)
    (snInstalled : Generated.f_sn∈code) (lib : FloorQNegativeCalls.Library code)
    {l : PoolLayout} {c : Cursor} (q : Input) (live : q.Live c.state) (positive : 0<q.denominator)
    (valid : Valid l c) (room : c.top+7<capacity) :
    ∃final : Cursor,∃out : Endpoint,
      SourceCall Header.layout code 7 "ceilQ" [q.source] c.state out.source final.state ∧
      Valid l final ∧ out.Live final.state ∧
      out.mathematical.value=ProofBox.ceilDiv q.mathematical.num.value q.denominator ∧
      final.state.heap.length=c.state.heap.length ∧ final.state.env=c.state.env ∧ final.top≤c.top+8 ∧
      (∀slot n,NatArena.Borrow c.state.nats slot n → NatArena.Borrow final.state.nats slot n) ∧
      (∃values : List Nat,values.length≤8 ∧ final=CursorFrames.advance l c values) ∧
      (out.magnitude=0 → out.negative=false) := by
  let p:=framed c q
  let n:=next l p 0
  have vp : Valid l p := OneFrames.context_frame valid "Q" "q" q.source
  have vn : Valid l n := next_valid _ vp (by change c.top<capacity;omega)
  have qn : SourceCall Header.layout code 6 "qn" [q.source] p.state (RationalSubCalls.negative q).source n.state := by
    rw [RationalSubCalls.negative_source]
    exact RationalNegCalls.qn_closed code qnInstalled snInstalled lib.smake lib.nz lib.nu lib.ne lib.keep
      q.numerator.negative vp (by change c.top<capacity;omega) live.1 live.2
  have nl : (RationalSubCalls.negative q).Live n.state :=
    RationalSubCalls.negative_live (Input.live_after (l:=l) (n:=0) live)
  obtain ⟨middle,floored,floorSource,middleValid,floorLive,floorValue,middleHeap,middleEnv,middleTop,middlePreserves,middleTrace⟩ :=
    SourceFloorQTrace.floorQ_closed_trace code floorInstalled lib (RationalSubCalls.negative q) nl positive vn
      (by change c.top+1+5<capacity;omega)
  have snRoom : middle.top<capacity := by
    have bound : middle.top≤c.top+1+6 := middleTop
    omega
  let tail:=next l middle 0
  let out:=negativeEndpoint floored
  let final:=PoolContextPop.unframe c.state tail
  have outLive : out.Live tail.state := preserves floorLive
  have sn : SourceCall Header.layout code 6 "sn" [floored.source] middle.state out.source tail.state := by
    rw [negative_source]
    exact SourceRanks.raise (SignedNegCalls.sn_closed code snInstalled lib.smake lib.nz lib.nu lib.ne lib.keep
      floored.negative middleValid snRoom floorLive)
  have floorRaised := SourceRanks.raise floorSource
  let en : CallEvents.Event Header.layout code 6 := ⟨"qn",[q.source],p.state,(RationalSubCalls.negative q).source,n.state,qn⟩
  let ef : CallEvents.Event Header.layout code 6 := ⟨"floorQ",[(RationalSubCalls.negative q).source],n.state,floored.source,middle.state,floorRaised⟩
  let es : CallEvents.Event Header.layout code 6 := ⟨"sn",[floored.source],middle.state,out.source,tail.state,sn⟩
  let events:=[en,ef,es]
  have unique : (events.map CallEvents.Event.name).Nodup := by
    change (["qn","floorQ","sn"] : List String).Nodup
    decide +kernel
  let service:=CallEvents.service events
  have hn : service "qn" [q.source] p.state=some ((RationalSubCalls.negative q).source,n.state) :=
    CallEvents.service_self_names events unique en (by simp [events])
  have hf : service "floorQ" [(RationalSubCalls.negative q).source] n.state=some (floored.source,middle.state) :=
    CallEvents.service_self_names events unique ef (by simp [events])
  have hs : service "sn" [floored.source] middle.state=some (out.source,tail.state) :=
    CallEvents.service_self_names events unique es (by simp [events])
  have qRead : evalExpr Header.layout service 1 p.state (.var "q")=some (q.source,p.state) :=
    TypedFrames.allocate_eval Header.layout service 0 {c.state with env:=[]} "Q" "q" q.source
      rfl (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have expression : Eval Header.layout service
      (.call (.var "sn") [.call (.var "floorQ") [.call (.var "qn") [.var "q"]]]) p.state tail.state out.source :=
    ⟨4,ExpressionTemplates.call_one Header.layout service
      (ExpressionTemplates.call_one Header.layout service (ExpressionTemplates.call_one Header.layout service qRead hn) hf) hs⟩
  have tailHeap : tail.state.heap.length=p.state.heap.length :=
    (shape l middle 0).1.trans (middleHeap.trans (shape l p 0).1)
  have tailEnv : tail.state.env=p.state.env := (shape l middle 0).2.trans (middleEnv.trans (shape l p 0).2)
  have body : Run Header.layout service Generated.f_ceilQ.body p.state (.returned tail.state out.source) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.returned (Loops.StmtRun.returnValue expression))
    exact ⟨rfl,(pop_same tailHeap tailEnv).symm⟩
  have source : SourceCall Header.layout code 7 "ceilQ" [q.source] c.state out.source final.state := by
    apply installed_body (f:=Generated.f_ceilQ) (rank:=6) (service:=service) installed
      (fun _ _ _ _ _ h=>CallEvents.service_closed events h)
      (TypedFrames.bind_one Header.layout c.state "Q" "q" q.source q.source (Input.cast "Q" (by decide +kernel) live)) body
    exact ⟨Endpoint.cast 98 "static S" (by decide +kernel) outLive,rfl⟩
  have finalValid : Valid l final := PoolContextPop.valid (next_valid 0 middleValid snRoom)
    ((List.getElem?_eq_some_iff.mp valid.pool_read).choose)
    ((List.getElem?_eq_some_iff.mp valid.top_read).choose)
    ((List.getElem?_eq_some_iff.mp valid.high_read).choose)
  refine ⟨final,out,source,finalValid,outLive,?_,?_,?_,?_,?_,?_,?_⟩
  · rw [negative_value,floorValue,negative_num_value]
    rfl
  · change (tail.state.heap.take c.state.heap.length).length=c.state.heap.length
    rw [List.length_take,tailHeap]
    simp [p,framed,OneFrames.frame,allocate]
  · rfl
  · have bound : middle.top≤c.top+1+6 := middleTop
    change middle.top+1≤c.top+8
    omega
  · intro slot value prior
    exact preserves (middlePreserves slot value (preserves (c:=p) prior))
  · obtain ⟨values,length,binding⟩ := middleTrace
    have innerRoom : (next l c 0).top+values.length≤capacity := by
      change c.top+1+values.length≤capacity
      omega
    have innerValid := CursorFrames.advance_valid (next_valid 0 valid (by omega)) values innerRoom
    have first : n=CursorSingleFrames.framed (next l c 0) "Q" "q" q.source :=
      CursorSingleFrames.next_framed valid "Q" "q" q.source 0
    have tailEq : tail=CursorSingleFrames.framed (CursorFrames.advance l c (0::(values++[0]))) "Q" "q" q.source := by
      change next l middle 0=_
      rw [binding,first,CursorSingleFrames.advance_framed (next_valid 0 valid (by omega)) "Q" "q" q.source values innerRoom]
      rw [CursorSingleFrames.next_framed innerValid "Q" "q" q.source 0]
      change CursorSingleFrames.framed (next l (CursorFrames.advance l (next l c 0) values) 0) "Q" "q" q.source=_
      rw [CursorFrames.advance,CursorSingleFrames.advance_append]
      rfl
    refine ⟨0::(values++[0]),?_,?_⟩
    · simp only [List.length_cons,List.length_append,List.length_nil]
      omega
    · change PoolContextPop.unframe c.state tail=_
      rw [tailEq]
      dsimp only [PoolContextPop.unframe,CursorSingleFrames.framed]
      rw [OneFrames.pop_frame "Q" "q" q.source
        (CursorEffects.shape l c (0::(values++[0]))).1 (CursorEffects.shape l c (0::(values++[0]))).2]

  · intro zero
    change (if floored.magnitude=0 then false else !floored.negative)=false
    exact if_pos zero


end ScopedC.SourceCeilQNormalizedTrace
