/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalFrames
import ScopedC.NumericRationalSelectRefinement
import ScopedC.PoolContextPop
import ScopedC.CursorEffects

namespace ScopedC.RationalIntervalHullCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair framed frame)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  qmin : Generated.f_qmin∈code
  qmax : Generated.f_qmax∈code
  qc : Generated.f_qc∈code
  sc : Generated.f_sc∈code
  sm : Generated.f_sm∈code
  nm : Generated.f_nm∈code
  smake : Generated.f_smake∈code
  nz : Generated.f_nz∈code
  nu : Generated.f_nu∈code
  ne : Generated.f_ne∈code
  nlt : Generated.f_nlt∈code
  keep : Generated.f_keep∈code

def base (c : Cursor) (a b : Pair) : Cursor := framed c a b
@[irreducible] def middle (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  RationalCompareCalls.final l (base c a b) a.lo b.lo
def finish (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  RationalCompareCalls.final l (middle l c a b) a.hi b.hi
def after (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  PoolContextPop.unframe c.state (finish l c a b)
def lowQ (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Input :=
  RationalSelectCalls.selected false "<=" l (base c a b) a.lo b.lo
def highQ (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Input :=
  RationalSelectCalls.selected true "<=" l (middle l c a b) a.hi b.hi
def result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Value :=
  IntervalCasts.value (lowQ l c a b).source (highQ l c a b).source

theorem selected_cases (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    RationalSelectCalls.selected flip "<=" l c a b=a ∨
    RationalSelectCalls.selected flip "<=" l c a b=b := by
  unfold RationalSelectCalls.selected
  split <;> split <;> simp

theorem selected_positive (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor)
    (a b : Input) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    0<(RationalSelectCalls.selected flip "<=" l c a b).denominator := by
  rcases selected_cases flip l c a b with h | h <;> simp only [h] <;> assumption

theorem selected_live (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) :
    (RationalSelectCalls.selected flip "<=" l c a b).Live
      (RationalCompareCalls.final l c a b).state := by
  rcases selected_cases flip l c a b with h | h
  · rw[h];exact RationalSelectCalls.input_final ha
  · rw[h];exact RationalSelectCalls.input_final hb

theorem middle_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (middle l c a b).top=c.top+6 := by
  unfold middle
  rw[RationalCompareFraming.final_eq_advance,CursorFrames.top_advance]
  rfl

theorem middle_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+11<PoolCalls.capacity) (a b : Pair) : Valid l (middle l c a b) := by
  unfold middle
  exact RationalCompareCalls.final_context
    (CursorFrames.framed_valid ctx "RI" "a" a.source "RI" "b" b.source) (by change c.top+5<_;omega) a.lo b.lo

theorem finish_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+11<PoolCalls.capacity) (a b : Pair) : Valid l (finish l c a b) := by
  apply RationalCompareCalls.final_context (middle_valid ctx room a b)
  rw[middle_top]
  omega

theorem after_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+11<PoolCalls.capacity) (a b : Pair) : Valid l (after l c a b) :=
  PoolContextPop.valid (finish_valid ctx room a b)
    ((List.getElem?_eq_some_iff.mp ctx.pool_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.top_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.high_read).choose)

theorem middle_live {l : PoolCalls.PoolLayout} {c : Cursor} {a b p : Pair} (h : p.Live c.state) :
    p.Live (middle l c a b).state := by
  unfold middle
  exact ⟨RationalSelectCalls.input_final (c:=base c a b) h.1,
    RationalSelectCalls.input_final (c:=base c a b) h.2⟩

theorem middle_a_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Pair) :
    LocalBinding.At (middle l c a b).state "a" "RI" a.source c.state.heap.length := by
  unfold middle
  rw[RationalCompareFraming.final_eq_advance]
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.advance (c:=base c a b) (RationalIntervalFrames.a_at c.state a b) _
    (by omega) (by omega) (by omega)

theorem middle_b_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Pair) :
    LocalBinding.At (middle l c a b).state "b" "RI" b.source (c.state.heap.length+1) := by
  unfold middle
  rw[RationalCompareFraming.final_eq_advance]
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.advance (c:=base c a b) (RationalIntervalFrames.b_at c.state a b) _
    (by omega) (by omega) (by omega)

theorem low_live {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair}
    (ha : a.Live c.state) (hb : b.Live c.state) :
    (lowQ l c a b).Live (finish l c a b).state := by
  have h : (lowQ l c a b).Live (middle l c a b).state := by
    unfold middle
    exact selected_live false l (base c a b) a.lo b.lo ha.1 hb.1
  exact RationalSelectCalls.input_final (c:=middle l c a b) (a:=a.hi) (b:=b.hi) h

theorem high_live {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair}
    (ha : a.Live c.state) (hb : b.Live c.state) :
    (highQ l c a b).Live (finish l c a b).state :=
  selected_live true l (middle l c a b) a.hi b.hi
    (middle_live (a:=a) (b:=b) ha).2 (middle_live (a:=a) (b:=b) hb).2

end ScopedC.RationalIntervalHullCalls
