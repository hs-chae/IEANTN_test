/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpFactorialEntry
import ScopedC.LocalBindingIdentity

namespace ScopedC.ExpFactorial
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000

theorem initial_fact_binding (l : PoolCalls.PoolLayout) (c : Cursor) :
    LocalBinding.At (initial l c).state "fact" "Q" (one l c).source c.state.heap.length :=
  LocalBinding.allocate_other (fact_binding l c) "k" "unsigned int" _ (by decide +kernel)

theorem initial_k_binding (l : PoolCalls.PoolLayout) (c : Cursor) :
    LocalBinding.At (initial l c).state "k" "unsigned int" (PoolCalls.word 1) (c.state.heap.length+1) := by
  have h:=LocalBinding.allocate_head (afterFact l c).state "k" "unsigned int" (PoolCalls.word 1) (by rfl)
  simpa only[initial,afterFact,CursorLocals.allocated,allocate,List.length_append,List.length_singleton,
    afterOne,RationalUnsignedTrace.after,(CursorEffects.shape l c [1,0,1]).1] using h

theorem initial_slots {l : PoolCalls.PoolLayout} {c : Cursor} {object d : Nat}
    (f : Frame l object d) (cursorEq : f.cursor=initial l c) :
    f.factSlot=c.state.heap.length ∧ f.kSlot=c.state.heap.length+1 := by
  have fact:=f.factAt
  have count:=f.kAt
  rw[cursorEq] at fact count
  exact ⟨LocalBinding.slot_eq fact (initial_fact_binding l c),
    LocalBinding.slot_eq count (initial_k_binding l c)⟩

end ScopedC.ExpFactorial
