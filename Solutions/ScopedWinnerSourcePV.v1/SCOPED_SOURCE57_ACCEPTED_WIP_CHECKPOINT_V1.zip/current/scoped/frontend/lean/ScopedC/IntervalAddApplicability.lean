/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalAddFraming
import ScopedC.NumericIntervalCompleteness

namespace ScopedC.IntervalAddApplicability
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem output_exists (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value) (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) :
    ∃out : Pair,out.source=RationalIntervalAddCalls.result l c a b ∧
      out.Live (RationalIntervalAddCalls.after l c a b).state ∧ out.Positive ∧
      out.lo.mathematical.value=a.lo.mathematical.value+b.lo.mathematical.value ∧
      out.hi.mathematical.value=a.hi.mathematical.value+b.hi.mathematical.value :=
  NumericInputCompleteness.interval (NumericRationalIntervalAddRefinement.decoded_result l c a b pa pb oa ob)

/-- Proof metadata obtained by inverting the already proved decoder for the
actual source-produced RI. It is never an executable numerical service or an
assumption about a program answer. Actual radd calls still use radd_closed. -/
noncomputable def output (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value) (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) : Pair :=
  Classical.choose (output_exists l c a b pa pb oa ob)

theorem output_spec (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value) (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) :
    (output l c a b pa pb oa ob).source=RationalIntervalAddCalls.result l c a b ∧
      (output l c a b pa pb oa ob).Live (RationalIntervalAddCalls.after l c a b).state ∧
      (output l c a b pa pb oa ob).Positive ∧
      (output l c a b pa pb oa ob).lo.mathematical.value=a.lo.mathematical.value+b.lo.mathematical.value ∧
      (output l c a b pa pb oa ob).hi.mathematical.value=a.hi.mathematical.value+b.hi.mathematical.value :=
  Classical.choose_spec (output_exists l c a b pa pb oa ob)

theorem output_order (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value ≤ a.hi.mathematical.value) (ob : b.lo.mathematical.value ≤ b.hi.mathematical.value) :
    (output l c a b pa pb oa ob).lo.mathematical.value ≤ (output l c a b pa pb oa ob).hi.mathematical.value := by
  have spec:=output_spec l c a b pa pb oa ob
  rw[spec.2.2.2.1,spec.2.2.2.2]
  exact add_le_add oa ob

theorem preserves_pair {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Pair) {p : Pair}
    (live : p.Live c.state) : p.Live (RationalIntervalAddCalls.after l c a b).state :=
  ⟨⟨RationalIntervalAddCalls.preserves_nat a b live.1.1,RationalIntervalAddCalls.preserves_nat a b live.1.2⟩,
    ⟨RationalIntervalAddCalls.preserves_nat a b live.2.1,RationalIntervalAddCalls.preserves_nat a b live.2.2⟩⟩

end ScopedC.IntervalAddApplicability
