/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderFramedAccess

namespace ScopedC.ExpPointReduction
set_option autoImplicit false
set_option maxHeartbeats 150000

def index (q : Rat) : Nat := (Nat.ceil |q|+1).log2
def power (q : Rat) : Nat := 2 ^ index q
def reduced (q : Rat) : Rat := q / (power q : Rat)

/-- The original machine guard follows from the input domain; successful C
execution is not a premise of the source proof. -/
theorem index_lt (q : Rat) (bound : Nat.ceil |q|+1 < 2^32) : index q < 32 := by
  exact (Nat.log2_lt (by omega : Nat.ceil |q|+1 ≠ 0)).2 bound

theorem power_positive (q : Rat) : 0 < power q := by
  exact pow_pos (by decide) _

theorem power_range (q : Rat) (bound : Nat.ceil |q|+1 < 2^32) : power q < 2^32 := by
  exact Nat.pow_lt_pow_right (by decide) (index_lt q bound)

/-- Exact original log2 reduction always puts the Taylor argument inside
(-2,2), independently of the eventual numerical input's magnitude. -/
theorem abs_reduced_lt_two (q : Rat) : |reduced q| < 2 := by
  have ceilBound : |q| ≤ (Nat.ceil |q| : Rat) := Nat.le_ceil _
  have logBound : (Nat.ceil |q| : Rat)+1 < (2:Rat)^(index q+1) := by
    exact_mod_cast (Nat.lt_log2_self (n:=Nat.ceil |q|+1))
  have positive : (0:Rat) < (power q : Rat) := by exact_mod_cast power_positive q
  rw [reduced,abs_div,abs_of_pos positive]
  apply (div_lt_iff₀ positive).2
  have powerCast : (power q : Rat) = (2:Rat)^index q := by
    simp only [power,Nat.cast_pow,Nat.cast_ofNat]
  rw [pow_succ,←powerCast] at logBound
  linarith

/-- This is the exact expRemainder ABI/sentinel obligation after the original
expPoint argument reduction; it does not assume the sentinel check succeeds. -/
theorem remainder_guard (q : Rat) : Int.ceil |reduced q| < 4294967295 := by
  have upper : (Int.ceil |reduced q| : Rat) < 3 :=
    lt_trans (Int.ceil_lt_add_one _) (by linarith [abs_reduced_lt_two q])
  have small : Int.ceil |reduced q| < 3 := by exact_mod_cast upper
  omega

end ScopedC.ExpPointReduction
