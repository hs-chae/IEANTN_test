/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientLoopInvariant
import ScopedC.PrepareCoefficientCallerFrames
import ScopedC.PrepareInitialCallerFrames
import ScopedC.PreparePrefixEvents

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

/-- Entire actual prepare source prefix with the caller's real scale and raw
ln2 scalar storage retained for its final ln2 construction/store. -/
theorem framed_coefficient_stage (code : List Function) (lib : CoeffLibrary code)
    {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    ∃stage : CoefficientStage code ready d bound,
      SourceFromS.ScaleAt stage.loop.finish.cursor.state (base+4)
        (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100) ∧
      SourceScalarGlobal.At stage.loop.finish.cursor.state "preparedLn2" "RI" (base+7)
        (some ScopedIO.ApplicationInit.zeroInterval) := by
  let P : CoeffFrame (layout base) (base+3) d (expBase base) (atanhBase base)→Prop :=
    fun f=>SourceFromS.ScaleAt f.cursor.state (base+4)
      (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100) ∧
      SourceScalarGlobal.At f.cursor.state "preparedLn2" "RI" (base+7)
        (some ScopedIO.ApplicationInit.zeroInterval)
  have preserve : ∀start active room,P start → P (coefficientStep start active room) := by
    intro start active room properties
    exact ⟨coefficientStep_scale start active room properties.1,
      coefficientStep_scalar start active room properties.2 (by decide +kernel) (by decide +kernel)⟩
  obtain ⟨loop,properties⟩:=coefficient_loop_invariant code lib d (coefficientStart ready d bound)
    (by rw[coefficientStart_k];omega)
    (by rw[coefficientStart_top];change 9+35*d ≤ 4000000;omega) P preserve
    ⟨coefficientStart_scale ready d bound,coefficientStart_ln2 ready d bound⟩
  exact ⟨⟨loop⟩,properties⟩

theorem framed_prepare_prefix_source (code : List Function) (lib : Library code)
    {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    ∃stage : CoefficientStage code ready d bound,
      SourceFromS.ScaleAt stage.loop.finish.cursor.state (base+4)
        (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100) ∧
      SourceScalarGlobal.At stage.loop.finish.cursor.state "preparedLn2" "RI" (base+7)
        (some ScopedIO.ApplicationInit.zeroInterval) ∧
      ∃service : Call,
        Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
          preparePrefix (parameters (staticCursor ready) d).state (.continuing stage.loop.finish.cursor.state) ∧
        (∀name args before value after,service name args before=some (value,after) →
          SourceCall Header.layout code 7 name args before value after) := by
  obtain ⟨stage,scale,ln2⟩:=framed_coefficient_stage code lib.coefficients ready d bound
  exact ⟨stage,scale,ln2,prepare_prefix_source lib stage⟩

end ScopedC.PrepareSource
