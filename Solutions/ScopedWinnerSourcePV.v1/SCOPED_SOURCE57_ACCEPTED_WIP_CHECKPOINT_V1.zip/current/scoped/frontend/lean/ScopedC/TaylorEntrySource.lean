/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorEntryFrame
import ScopedC.TaylorStepSource

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure EntryLibrary (code : List Function) : Prop where
  body : Library code
  qi : Generated.f_qi∈code
  si : Generated.f_si∈code

theorem zero_call (code : List Function) (lib : EntryLibrary code) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+2<PoolCalls.capacity) (base : Address) (a : Pair) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 0] (parameters c base a).state
      (zeroInput l c base a).source (afterZero l c base a).state :=
  (RationalUnsignedTrace.qi_traced code lib.qi lib.si lib.body.mulLibrary.productLibrary.smake
    lib.body.mulLibrary.productLibrary.nz lib.body.mulLibrary.productLibrary.nu lib.body.mulLibrary.productLibrary.ne
    lib.body.mulLibrary.productLibrary.keep (parameters_valid ctx base a) 0 (by decide +kernel) room
    (DecimalDigits.integer 0) (by rfl)).1

theorem zero_point_call (code : List Function) (lib : EntryLibrary code)
    (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) :
    SourceCall Header.layout code 1 "point" [(zeroInput l c base a).source] (afterZero l c base a).state
      (zeroPair l c base a).source (afterZero l c base a).state := by
  change SourceCall Header.layout code 1 "point"
    [RecordCasts.rational (parameters c base a).state.nats.values.length 0
      (SignedCalls.siResult l (parameters c base a).state (parameters c base a).cells (parameters c base a).top (parameters c base a).high 0).nats.values.length]
    (afterZero l c base a).state (IntervalCasts.value _ _) (afterZero l c base a).state
  exact RationalPointCalls.point_closed code lib.body.point (RationalUnsignedTrace.live l (parameters c base a) 0).1
    (RationalUnsignedTrace.live l (parameters c base a) 0).2 (by decide +kernel : (0:Nat)<2^32)

theorem result_declaration (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair)
    (answerQi : service "qi" [DecimalDigits.integer 0] (parameters c base a).state=
      some ((zeroInput l c base a).source,(afterZero l c base a).state))
    (answerPoint : service "point" [(zeroInput l c base a).source] (afterZero l c base a).state=
      some ((zeroPair l c base a).source,(afterZero l c base a).state)) :
    Declare Header.layout service [{type:="RI",name:="result",value:=some (.call (.var "point") [.call (.var "qi") [.nat 0]]),arrayExtent:=none}]
      (parameters c base a).state (stored l c base a).state := by
  have qiEval:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 998 (parameters c base a).state (.nat 0)=some (DecimalDigits.integer 0,(parameters c base a).state) from rfl) answerQi
  have pointEval:=ExpressionTemplates.call_one Header.layout service qiEval answerPoint
  have convert : castValue Header.layout (afterZero l c base a).state 100 "RI" (zeroPair l c base a).source=
      some (zeroPair l c base a).source:=Pair.cast (zero_live l c base a) "RI" (by decide +kernel)
  simp only[Declare,declarations,List.foldlM,pointEval,Bind.bind,Option.bind,convert]
  rfl

theorem one_start_ne {cfg : Layout} {code : List Function} {rank : Nat} (e : CallEvents.Event cfg code rank)
    (name : String) (args : List Value) (before : State) (different : before≠e.before) :
    CallEvents.one e name args before=none := by
  classical
  unfold CallEvents.one
  split_ifs with matching
  · exact False.elim (different matching.2.2)
  · rfl

end ScopedC.TaylorCalls
