/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CursorSingleFrames

namespace ScopedC.SourceUnsignedGlobal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Actual application scalar storage, not an assumed initialized value. -/
structure At (s : State) (name : String) (object n : Nat) : Prop where
  lookup : s.globals.lookup name=some ⟨object,0,[]⟩
  storage : s.heap[object]?=some {type:="unsigned",cells:=[some (PoolCalls.word n)]}

theorem eval (service : Call) (fuel : Nat) {s : State} {name : String} {object n : Nat}
    (h : At s name object n) (unshadowed : s.env.lookup name=none)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+1) s (.var name)=some (PoolCalls.word n,s) := by
  simp [evalExpr,h0,h1,h2,h3,getVar,unshadowed,h.lookup,h.storage,Machine.read,nested,
    initialized,PoolCalls.word]

theorem memory {s t : State} {name : String} {object n : Nat} (h : At s name object n)
    (globals : t.globals=s.globals) (storage : t.heap[object]?=s.heap[object]?) : At t name object n :=
  ⟨by simpa only[globals] using h.lookup,storage.trans h.storage⟩

theorem allocated {s : State} {name : String} {object n : Nat} (h : At s name object n)
    (type localName : String) (value : Option Value) : At (allocate s type localName value) name object n :=
  memory h rfl (by exact List.getElem?_append_left (List.getElem?_eq_some_iff.mp h.storage).choose)

theorem advanced {l : PoolCalls.PoolLayout} {c : Cursor} {name : String} {object n : Nat}
    (h : At c.state name object n) (values : List Nat)
    (hp : object≠l.pool) (ht : object≠l.top) (hh : object≠l.high) :
    At (CursorFrames.advance l c values).state name object n :=
  memory h (CursorSingleFrames.advance_globals l c values)
    (CursorSingleFrames.advance_other l c values object hp ht hh)

end ScopedC.SourceUnsignedGlobal
