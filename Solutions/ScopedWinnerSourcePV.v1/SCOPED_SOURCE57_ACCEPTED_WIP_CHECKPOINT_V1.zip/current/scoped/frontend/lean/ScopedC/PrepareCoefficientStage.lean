/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientLoop
import ScopedC.PrepareCoefficientInitialization
import ScopedC.PrepareScaleSeed
import ScopedC.PrepareCompleteInitialization

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def coefficientStart {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) : CoeffFrame (layout base) (base+3) d (expBase base) (atanhBase base) :=
  coeffInitialFrame (actualSeed ready d bound)
    (by rw[actualSeed_top];decide +kernel)

theorem coefficientStart_top {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) : (coefficientStart ready d bound).cursor.top=9 := by
  change (initAtanhCursor (actualSeed ready d bound) _).top=9
  unfold initAtanhCursor
  change (initExpCursor (actualSeed ready d bound)).top+3=9
  unfold initExpCursor
  change (actualSeed ready d bound).cursor.top+3+3=9
  rw[actualSeed_top]

theorem coefficientStart_k {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) : (coefficientStart ready d bound).k=1 := rfl

structure CoefficientStage (code : List Function) {state : State} {base : Nat}
    (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) where
  loop : CoefficientLoopCertificate code (coefficientStart ready d bound)

/-- All coefficient-table applicability follows from actual application
statics and prepare, with the original d≤64 guard and real four-million pool.
No initialized coefficient or expected program output premise is present. -/
theorem coefficient_stage (code : List Function) (lib : CoeffLibrary code)
    {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    Nonempty (CoefficientStage code ready d bound) := by
  obtain ⟨loop⟩:=coefficient_loop_certificate code lib d (coefficientStart ready d bound)
    (by rw[coefficientStart_k];omega)
    (by rw[coefficientStart_top];change 9+35*d ≤ 4000000;omega)
  exact ⟨⟨loop⟩⟩

theorem coefficient_stage_old_math {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) :
    TaylorCalls.coefficientValues stage.loop.finish.expCoeffs=LeanCert.Core.IntervalRat.expTaylorCoeffs d ∧
    TaylorCalls.coefficientValues stage.loop.finish.atanhCoeffs=LeanCert.Core.IntervalRat.atanhTaylorCoeffs d :=
  coefficient_loop_old_math stage.loop

/-- Includes the complete actual readonly source declarations, rather than
assuming the mutable arrays were set up by an external initializer. -/
theorem complete_initialized_coefficient_stage (code : List Function) (lib : CoeffLibrary code)
    (platform : State) (d : Nat) (bound : d ≤ 64) :
    ∃state,DataComplete.initializeProgramGlobals platform=some state ∧
      ∃ready : StaticAt state platform.heap.length,Nonempty (CoefficientStage code ready d bound) := by
  obtain ⟨state,initialized,⟨ready⟩⟩:=complete_initialization platform
  exact ⟨state,initialized,ready,coefficient_stage code lib ready d bound⟩

end ScopedC.PrepareSource
