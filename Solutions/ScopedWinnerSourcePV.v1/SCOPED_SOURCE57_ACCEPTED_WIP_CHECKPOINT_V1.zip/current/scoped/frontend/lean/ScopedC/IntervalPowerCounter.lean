/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerGuard

namespace ScopedC.IntervalPowerCounter
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.RationalPowerCounter
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem binary_le (s : State) (a b : Nat) (ha : a<2^32) (hb : b<2^32) :
    binaryValue Header.layout s "<=" (word a) (word b)=some (boolean Header.layout (decide (a ≤ b))) := by
  simp [binaryValue,word,NatWrapperCalls.unsigned32,Scalar.binary,Scalar.common,Scalar.promote,
    scalar_u32_cast a ha,scalar_u32_cast b hb,Scalar.boolean,Scalar.truth,boolean,u32_range a ha,u32_range b hb]
    <;> split_ifs <;> (first | rfl | omega)

theorem multiply_scalar (n : Nat) (hn : n*2<2^32) :
    Scalar.binary "*" (scalar n) intTwo=some (scalar (n*2)) := by
  have hn0 : n<2^32 := by omega
  have ha:=u32_range n hn0
  have hb : Scalar.InRange intTwo.type intTwo.number := by decide +kernel
  have result:=Scalar.make_exact (u32_range (n*2) hn)
  simp only[scalar,intTwo,Scalar.binary,ha,hb,decide_true,Bool.not_true,Bool.false_or,Bool.false_eq_true,↓reduceIte]
  change (do let x←Scalar.cast ⟨false,32⟩ (scalar n);let y←Scalar.cast ⟨false,32⟩ intTwo
             Scalar.make ⟨false,32⟩ (x.number*y.number))=_
  rw[cast_scalar n hn0,cast_two]
  simpa [Bind.bind,Option.bind,scalar] using result

theorem multiply_two (s : State) (n : Nat) (hn : n*2<2^32) :
    binaryValue Header.layout s "*" (word n) (DecimalDigits.integer 2)=some (word (n*2)) := by
  change (do let x←Scalar.binary "*" (scalar n) intTwo;pure (Value.integer x))=_
  rw[multiply_scalar n hn]
  rfl

def bitCondition : Expr := .binary "<=" (.var "bit") (.binary "/" (.var "n") (.nat 2))
def doubleStatement : Stmt := .eval (.binary "=" (.var "bit") (.binary "*" (.var "bit") (.nat 2)))

theorem bit_condition (service : Call) {s : State} {n bit nSlot bitSlot : Nat}
    (atN : LocalBinding.At s "n" "unsigned int" (word n) nSlot)
    (atBit : LocalBinding.At s "bit" "unsigned int" (word bit) bitSlot)
    (hn : n<2^32) (hb : bit<2^32) :
    Eval Header.layout service bitCondition s s (boolean Header.layout (decide (bit ≤ n/2))) := by
  refine ⟨4,?_⟩
  apply ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 2 atBit (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (RationalPowerGuard.eval_half service 0 atN hn)
  exact binary_le s bit (n/2) hb (RationalPowerCounter.halve_range n hn)

theorem double_assignment (service : Call) {s : State} {bit bitSlot : Nat}
    (atBit : LocalBinding.At s "bit" "unsigned int" (word bit) bitSlot)
    (bound : bit*2<2^32) :
    Eval Header.layout service (.binary "=" (.var "bit") (.binary "*" (.var "bit") (.nat 2))) s
      (LocalAssignment.changed s bitSlot "unsigned int" (word (bit*2))) (word (bit*2)) := by
  refine ⟨4,?_⟩
  apply LocalAssignment.evaluate service 2
    (ExpressionTemplates.binary Header.layout service
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (LocalBinding.eval service 1 atBit (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
      (by rfl) (multiply_two s bit bound)) atBit
  exact RationalUnsignedCalls.cast_parameter s (bit*2) bound

end ScopedC.IntervalPowerCounter
