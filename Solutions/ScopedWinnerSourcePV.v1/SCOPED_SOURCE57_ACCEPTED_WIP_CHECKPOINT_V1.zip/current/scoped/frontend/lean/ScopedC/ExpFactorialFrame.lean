/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceUnsignedStore
import ScopedC.RationalProductApplicability
import ScopedC.RationalUnsignedTrace
import ScopedC.UnsignedLocalSteps
import ScopedC.LocalStorageSeparation

namespace ScopedC.ExpFactorial
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

/-- Physical application state of the original expRemainder factorial while.
These facts must be constructed from actual declarations, never trusted as
initial application state or an intended successful output. -/
structure Frame (l : PoolCalls.PoolLayout) (object d : Nat) where
  cursor : Cursor
  fact : Input
  k : Nat
  factSlot : Nat
  kSlot : Nat
  context : Valid l cursor
  factAt : LocalBinding.At cursor.state "fact" "Q" fact.source factSlot
  kAt : LocalBinding.At cursor.state "k" "unsigned int" (PoolCalls.word k) kSlot
  depthAt : SourceUnsignedGlobal.At cursor.state "depth" object d
  depthUnshadowed : cursor.state.env.lookup "depth"=none
  live : fact.Live cursor.state
  positive : 0<fact.denominator
  kPositive : 0<k
  kBound : k≤d+2
  depthBound : d≤64
  depthApart : object≠l.pool ∧ object≠l.top ∧ object≠l.high

def counterInput {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) : Input :=
  RationalUnsignedTrace.output l f.cursor f.k

def afterQi {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) : Cursor :=
  RationalUnsignedTrace.after l f.cursor f.k

def product {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) : Input :=
  RationalProductApplicability.output l (afterQi f) f.fact (counterInput f)

@[irreducible] def productCursor {l : PoolCalls.PoolLayout} {object d : Nat}
    (f : Frame l object d) : Cursor :=
  RationalMultiplyCalls.c11 l (afterQi f) f.fact (counterInput f)

theorem afterQi_valid {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) : Valid l (afterQi f) :=
  CursorFrames.advance_valid f.context [f.k,0,1] (by change f.cursor.top+3≤PoolCalls.capacity;omega)

theorem counter_positive {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    0<(counterInput f).denominator := by change 0<(1:Nat);decide +kernel

theorem counter_live {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    (counterInput f).Live (afterQi f).state := RationalUnsignedTrace.live l f.cursor f.k

theorem fact_afterQi_live {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    f.fact.Live (afterQi f).state :=
  ⟨CursorBorrow.preserves (l:=l) (c:=f.cursor) [f.k,0,1] f.live.1,
    CursorBorrow.preserves (l:=l) (c:=f.cursor) [f.k,0,1] f.live.2⟩

theorem product_live {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    (product f).Live (productCursor f).state := by
  unfold productCursor
  exact RationalProductApplicability.live l (afterQi f) f.fact (counterInput f)

theorem product_positive {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    0<(product f).denominator :=
  RationalProductApplicability.positive l (afterQi f) f.fact (counterInput f) f.positive (counter_positive f)

theorem product_value {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    (product f).mathematical.value=f.fact.mathematical.value*(f.k:Rat) := by
  unfold product
  rw[RationalProductApplicability.mathematical l (afterQi f) f.fact (counterInput f)
    f.positive (counter_positive f)]
  exact congrArg (fun v=>f.fact.mathematical.value*v) (RationalUnsignedTrace.mathematical l f.cursor f.k).1

theorem product_trace {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    productCursor f=CursorFrames.advance l f.cursor
      ([f.k,0,1]++RationalMultiplyTrace.steps l (afterQi f) f.fact (counterInput f)) := by
  unfold productCursor
  rw[RationalMultiplyTrace.c11_advance,CursorSingleFrames.advance_append]
  rfl

theorem product_top {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    (productCursor f).top=f.cursor.top+14 := by
  unfold productCursor
  rw[RationalMultiplyCalls.top11]
  rfl

theorem product_valid {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) : Valid l (productCursor f) := by
  rw[product_trace]
  apply CursorFrames.advance_valid f.context
  change f.cursor.top+14≤PoolCalls.capacity
  omega

theorem product_binding {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    {name ty : String} {value : Value} {slot : Nat}
    (binding : LocalBinding.At f.cursor.state name ty value slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    LocalBinding.At (productCursor f).state name ty value slot := by
  rw[product_trace]
  exact LocalBinding.advance binding _ hp ht hh

end ScopedC.ExpFactorial
