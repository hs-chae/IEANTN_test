/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerFramedReady
import ScopedC.IntervalPowerComposition
import ScopedC.IntervalPowerInitialEffects
import ScopedC.IntervalPowerBody
import ScopedC.CursorSingleFrames

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure FramedResult (code : List Function) (l : PoolCalls.PoolLayout)
    (before : Cursor) (a : Pair) (n : Nat)
    (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) where
  out : Cursor
  output : Pair
  execution : SourceCall Header.layout code 9 "rpow" [a.source,PoolCalls.word n]
    before.state output.source out.state
  valid : Valid l out
  live : output.Live out.state
  positive : output.Positive
  decoded : NumericRepresentation.interval out.state output.source=some
    (LeanCert.Core.IntervalRat.pow ⟨a.lo.mathematical.value,a.hi.mathematical.value,order⟩ n)
  top : out.top ≤ before.top+5120
  globals : out.state.globals=before.state.globals
  env : out.state.env=before.state.env
  heap_length : out.state.heap.length=before.state.heap.length
  preserves : ∀slot value,NatArena.Borrow before.state.nats slot value →
    NatArena.Borrow out.state.nats slot value
  other : ∀slot,slot < before.state.heap.length → slot≠l.pool → slot≠l.top → slot≠l.high →
    out.state.heap[slot]?=before.state.heap[slot]?

theorem rpow_positive_framed (code : List Function) (installed : Generated.f_rpow∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5120 ≤ PoolCalls.capacity) (a : Pair) (n : Nat)
    (alive : a.Live c.state) (positive : a.Positive)
    (order : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (nonzero : 0<n) (bound : n<2^32) : Nonempty (FramedResult code l c a n order) := by
  obtain ⟨high⟩:=IntervalPowerBits.highest_bit (initialBitFrame ctx a n nonzero bound)
  have highTop : high.finish.cursor.top=c.top:=high.shape.2.2.2.2
  obtain ⟨trace⟩:=scan_ready_framed code lib.rmul lib.multiplyLibrary high.finish high.highest
    a c.state.heap.length (highest_a ctx a n nonzero bound high)
    (highest_live ctx a n nonzero bound high alive) positive order (by rw[highTop];exact room)
  change FramedReady code (startFromHigh ctx a n nonzero bound high alive positive order) at trace
  have result:=compose_positive_trace code installed ctx a n alive positive order nonzero bound
    high trace.toReady
  let out:=positiveFinishCursor c a n trace.finish
  refine ⟨{
    out:=out
    output:=trace.finish.result
    execution:=result.1
    valid:=result.2.1
    live:=result.2.2.1
    positive:=result.2.2.2.1
    decoded:=result.2.2.2.2.1
    top:=result.2.2.2.2.2
    globals:=?_
    env:=rfl
    heap_length:=?_
    preserves:=?_
    other:=?_
  }⟩
  · change trace.finish.cursor.state.globals=c.state.globals
    exact trace.globals.trans (start_globals ctx a n nonzero bound high alive positive order)
  · change ((trace.finish.cursor.state.heap.take (parameters c a n).state.heap.length).take
      c.state.heap.length).length=c.state.heap.length
    rw[List.length_take,List.length_take,trace.shape.1]
    change min c.state.heap.length (min (parameters c a n).state.heap.length
      (startFromHigh ctx a n nonzero bound high alive positive order).cursor.state.heap.length)=
        c.state.heap.length
    rw[start_heap_length,parameters_length]
    omega
  · intro slot value live
    change NatArena.Borrow trace.finish.cursor.state.nats slot value
    exact trace.borrows slot value (by rw[start_nats];exact live)
  · intro slot old hp ht hh
    change ((trace.finish.cursor.state.heap.take (parameters c a n).state.heap.length).take
      c.state.heap.length)[slot]?=c.state.heap[slot]?
    rw[List.getElem?_take_of_lt old,
      List.getElem?_take_of_lt (by rw[parameters_length];omega)]
    have slots:=start_slots ctx a n nonzero bound high alive positive order
    have same:=trace.other slot (by rw[start_heap_length];omega)
      (by rw[slots.1];omega) (by rw[slots.2];omega) hp ht hh
    exact same.trans (start_other ctx a n nonzero bound high alive positive order slot old)

end ScopedC.IntervalPowerCalls
