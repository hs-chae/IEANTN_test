/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientDivideFrames

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def counterExpTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) :
    CoefficientTableRead.TableAt (counterQCursor f).state eb f.expCoeffs :=
  CoefficientTableRead.advanced f.context f.expAt [f.k,0,1]

def counterAtanhTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) :
    CoefficientTableRead.TableAt (counterQCursor f).state ab f.atanhCoeffs :=
  CoefficientTableRead.advanced f.context f.atanhAt [f.k,0,1]

noncomputable def dividedExpTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    CoefficientTableRead.TableAt (expDivideCursor f).state eb f.expCoeffs := by
  let table:=counterExpTable f
  have safe:=CoefficientTableRead.pool_separated (counterQ_valid f room) table
  have bound:=(List.getElem?_eq_some_iff.mp table.memory).choose
  exact CoefficientTableRead.memory table
    (by rw[expDivide_nonzero];exact RationalDivideCalls.nonzero_other l (counterQCursor f)
          (previous f) (counterQ f) _ bound safe.1 safe.2.1 safe.2.2)
    (by intro slot n h;rw[expDivide_nonzero];exact RationalDivideCalls.nonzero_borrow _ _ h)

noncomputable def dividedAtanhTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    CoefficientTableRead.TableAt (expDivideCursor f).state ab f.atanhCoeffs := by
  let table:=counterAtanhTable f
  have safe:=CoefficientTableRead.pool_separated (counterQ_valid f room) table
  have bound:=(List.getElem?_eq_some_iff.mp table.memory).choose
  exact CoefficientTableRead.memory table
    (by rw[expDivide_nonzero];exact RationalDivideCalls.nonzero_other l (counterQCursor f)
          (previous f) (counterQ f) _ bound safe.1 safe.2.1 safe.2.2)
    (by intro slot n h;rw[expDivide_nonzero];exact RationalDivideCalls.nonzero_borrow _ _ h)

theorem dividedExp_cells {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    (dividedExpTable f room).cells=f.expAt.cells := by
  unfold dividedExpTable
  rfl

theorem dividedAtanh_cells {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    (dividedAtanhTable f room).cells=f.atanhAt.cells := by
  unfold dividedAtanhTable
  rfl

@[irreducible] noncomputable def expStoreCursor
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) : Cursor :=
  CoefficientTableRead.cursor (expDivideCursor f) eb (dividedExpTable f room).cells f.k (expNext f)

noncomputable def storedExpTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) (active : f.k ≤ d) :
    CoefficientTableRead.TableAt (expStoreCursor f room).state eb (f.expCoeffs++[expNext f]) := by
  unfold expStoreCursor
  rw[← f.expLength]
  exact CoefficientTableRead.append (dividedExpTable f room) (expNext f) (expNext_live f)
    (expNext_positive f) (by rw[dividedExp_cells,f.expExtent,f.expLength];have h:=f.depthBound;omega)

noncomputable def storedExpAtanhTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    CoefficientTableRead.TableAt (expStoreCursor f room).state ab f.atanhCoeffs := by
  unfold expStoreCursor
  exact CoefficientTableRead.other_table (dividedExpTable f room) (dividedAtanhTable f room)
    f.arraysApart f.k (expNext f)

theorem expStore_valid {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    Valid l (expStoreCursor f room) := by
  unfold expStoreCursor
  exact CoefficientTableRead.valid (expDivide_valid f room) (dividedExpTable f room) f.k (expNext f)

theorem expDivide_globals {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) :
    (expDivideCursor f).state.globals=f.cursor.state.globals := by
  rw[expDivide_nonzero,RationalDivideCalls.nonzero_globals]
  exact CursorSingleFrames.advance_globals l f.cursor [f.k,0,1]

theorem expDivide_env {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : (expDivideCursor f).state.env=f.cursor.state.env := by
  rw[expDivide_nonzero,RationalDivideCalls.nonzero_env]
  exact (CursorEffects.shape l f.cursor [f.k,0,1]).2

theorem expDivide_k {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) :
    LocalBinding.At (expDivideCursor f).state "k" "unsigned int" (PoolCalls.word f.k) f.kSlot := by
  have safe:=LocalStorageSeparation.pool f.context f.kAt (by decide +kernel)
  rw[expDivide_nonzero]
  exact LocalBinding.nonzero_division (LocalBinding.advance f.kAt [f.k,0,1]
    safe.1 safe.2.1 safe.2.2) (previous f) (counterQ f) safe

theorem expDivide_depth {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) :
    SourceUnsignedGlobal.At (expDivideCursor f).state "depth" object d := by
  rw[expDivide_nonzero]
  exact SourceUnsignedGlobal.nonzero_division
    (SourceUnsignedGlobal.advanced f.depthAt [f.k,0,1]
      f.depthApart.1 f.depthApart.2.1 f.depthApart.2.2) (previous f) (counterQ f) f.depthApart

theorem expStore_k {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    LocalBinding.At (expStoreCursor f room).state "k" "unsigned int" (PoolCalls.word f.k) f.kSlot := by
  unfold expStoreCursor
  exact CoefficientTableRead.changed_binding (dividedExpTable f room) f.k (expNext f) (expDivide_k f)

theorem expStore_depth {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    SourceUnsignedGlobal.At (expStoreCursor f room).state "depth" object d := by
  unfold expStoreCursor
  exact CoefficientTableRead.changed_depth (dividedExpTable f room) f.k (expNext f) (expDivide_depth f)

end ScopedC.PrepareSource
