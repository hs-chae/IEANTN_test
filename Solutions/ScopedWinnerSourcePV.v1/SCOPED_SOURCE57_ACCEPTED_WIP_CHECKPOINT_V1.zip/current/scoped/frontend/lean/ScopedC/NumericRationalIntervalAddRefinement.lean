/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalAddBody
import ScopedC.NumericNatsExtensionality
namespace ScopedC.NumericRationalIntervalAddRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalIntervalAddCalls
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000
attribute [local irreducible] finish

theorem decoded_input {s : State} {a : Pair} (live : a.Live s) (positive : a.Positive)
    (ordered : a.lo.mathematical.value≤a.hi.mathematical.value) :
    NumericRepresentation.interval s a.source=some (⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩:IntervalRat) := by
  have lo:=Input.decoded live.1 positive.1
  have hi:=Input.decoded live.2 positive.2
  simp [NumericRepresentation.interval,Pair.source,IntervalCasts.value,lo,hi,ordered]

theorem decoded_result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair)
    (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value≤a.hi.mathematical.value)
    (ob : b.lo.mathematical.value≤b.hi.mathematical.value) :
    NumericRepresentation.interval (after l c a b).state (result l c a b)=some
      (IntervalRat.add ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩) := by
  obtain ⟨q,qs,ql,qm,qp⟩ := low_input l c a b pa pb
  have qf : q.Live (finish l c a b).state := by
    unfold finish
    exact ⟨RationalAddCalls.preserves (c:=middle l c a b) (a:=a.hi) (b:=b.hi) ql.1,
      RationalAddCalls.preserves (c:=middle l c a b) (a:=a.hi) (b:=b.hi) ql.2⟩
  have dl:=Input.decoded qf qp
  rw[qs,qm]at dl
  obtain ⟨qh,qhs,qhl,qhm,qhp⟩ := high_input l c a b pa pb
  have dh:=Input.decoded qhl qhp
  rw[qhs,qhm] at dh
  have lv:=RationalAddCalls.mathematical_value l (base c a b) a.lo b.lo pa.1 pb.1
  have hv:=RationalAddCalls.mathematical_value l (middle l c a b) a.hi b.hi pa.2 pb.2
  have order:=add_le_add oa ob
  have inside : NumericRepresentation.interval (finish l c a b).state (result l c a b)=some
      (IntervalRat.add ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩) := by
    simp [NumericRepresentation.interval,result,IntervalCasts.value,dl,dh,lv,hv,order,IntervalRat.add]
  exact (NumericNatsExtensionality.interval (s:=(finish l c a b).state) (t:=(after l c a b).state)
    (by rfl) (result l c a b)).symm.trans inside

/-- Both source computations are actual parsed qa/radd executions; the decoded
result is exactly the original rational-interval addition, with unchanged
input order and positive-denominator assumptions. -/
theorem radd_math (code : List Function) (installed : Generated.f_radd∈code)
    (qaInstalled : Generated.f_qa∈code) (lib : RationalAddCalls.Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+27<PoolCalls.capacity)
    (a b : Pair) (ha : a.Live c.state) (hb : b.Live c.state) (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value≤a.hi.mathematical.value)
    (ob : b.lo.mathematical.value≤b.hi.mathematical.value) :
    SourceCall Header.layout code 7 "radd" [a.source,b.source] c.state (result l c a b) (after l c a b).state ∧
    NumericRepresentation.interval (after l c a b).state (result l c a b)=some
      (IntervalRat.add ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩) :=
  ⟨radd_closed code installed qaInstalled lib ctx room a b ha hb pa pb,decoded_result l c a b pa pb oa ob⟩
end ScopedC.NumericRationalIntervalAddRefinement
