/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericDyadicAddRefinement
import ScopedC.DyadicValueEquivalence

namespace ScopedC.DyadicAddValueEquivalence
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.DyadicValueEquivalence
open ScopedC.DyadicPairFrames (InputI)
open ScopedC.DyadicAddCalls
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- The mathematical operation is independent of the stored endpoint
exponents whenever both endpoint rational values agree. -/
theorem add_same {a oldA b oldB : IntervalDyadic}
    (ha : SameValues a oldA) (hb : SameValues b oldB) :
    SameValues (IntervalDyadic.add a b) (IntervalDyadic.add oldA oldB) := by
  constructor
  · simp only [IntervalDyadic.add,LeanCert.Core.Dyadic.toRat_add,ha.1,hb.1]
  · simp only [IntervalDyadic.add,LeanCert.Core.Dyadic.toRat_add,ha.2,hb.2]

/-- Connect the unchanged actual C addition to the old mathematical
algorithm even when its accumulator stores an equivalent coarser dyadic,
such as the old zero with exponent zero. No structural equality between
those distinct representations is asserted. -/
theorem source_add_rep (code : List Function) (installed : Generated.f_iadd∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+3<PoolCalls.capacity)
    (a b : InputI) (ha : a.Live c.state) (hb : b.Live c.state)
    (oa : a.lo.mathematical.value≤a.hi.mathematical.value)
    (ob : b.lo.mathematical.value≤b.hi.mathematical.value)
    (oldA oldB : IntervalDyadic)
    (sameA : SameValues (words100 a.lo.mathematical.value a.hi.mathematical.value oa) oldA)
    (sameB : SameValues (words100 b.lo.mathematical.value b.hi.mathematical.value ob) oldB) :
    SourceCall Header.layout code 6 "iadd" [a.source,b.source] c.state
      (result l c a b) (after l c a b).state ∧
    Represents (after l c a b).state (result l c a b)
      (IntervalDyadic.add oldA oldB) (a.ok&&b.ok) := by
  have h := NumericDyadicAddRefinement.iadd_math code installed lib ctx room a b ha hb oa ob
  exact ⟨h.1,_,h.2,add_same sameA sameB⟩

end ScopedC.DyadicAddValueEquivalence
