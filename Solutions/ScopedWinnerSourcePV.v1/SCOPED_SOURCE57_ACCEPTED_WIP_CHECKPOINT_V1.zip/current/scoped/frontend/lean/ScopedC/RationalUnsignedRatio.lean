/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalUnsignedTrace
import ScopedC.RationalDivideTrace
import ScopedC.NumericRationalCompleteness
import ScopedC.DecimalDigits
namespace ScopedC.RationalUnsignedRatio
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

def numerator (l : PoolLayout) (c : Cursor) (n : Nat) : Cursor :=
  RationalUnsignedTrace.after l c n
def denominator (l : PoolLayout) (c : Cursor) (n d : Nat) : Cursor :=
  RationalUnsignedTrace.after l (numerator l c n) d
def numInput (l : PoolLayout) (c : Cursor) (n : Nat) : Input :=
  RationalUnsignedTrace.output l c n
def denInput (l : PoolLayout) (c : Cursor) (n d : Nat) : Input :=
  RationalUnsignedTrace.output l (numerator l c n) d
def after (l : PoolLayout) (c : Cursor) (n d : Nat) : Cursor :=
  RationalDivideCalls.after l (denominator l c n d) (numInput l c n) (denInput l c n d)

theorem literal_cast (s : State) (n : Nat) (bound : n<2^32) :
    castValue Header.layout s 100 "unsigned int" (DecimalDigits.integer n)=
      some (NatWrapperCalls.unsigned32 n) := by
  have range : Scalar.InRange ⟨false,32⟩ (n:Int) := by
    simp only [Scalar.InRange,Scalar.lower,Scalar.upper,Scalar.modulus,
      Bool.false_eq_true,↓reduceIte]
    exact ⟨by omega,by exact_mod_cast Nat.zero_le n,by exact_mod_cast bound⟩
  change (do
    let x ← Scalar.cast ⟨false,32⟩ ⟨⟨true,32⟩,(n:Int)⟩
    pure (Value.integer x))=some (NatWrapperCalls.unsigned32 n)
  simp only [Scalar.cast]
  rw [Scalar.make_exact range]
  rfl

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (n d : Nat) where
  numeratorCall : SourceCall Header.layout code 6 "qi" [DecimalDigits.integer n]
    c.state (numInput l c n).source (numerator l c n).state
  denominatorCall : SourceCall Header.layout code 6 "qi" [DecimalDigits.integer d]
    (numerator l c n).state (denInput l c n d).source (denominator l c n d).state
  output : Input
  divideCall : SourceCall Header.layout code 7 "qv"
    [(numInput l c n).source,(denInput l c n d).source]
    (denominator l c n d).state output.source (after l c n d).state
  valid : Valid l (after l c n d)
  live : output.Live (after l c n d).state
  positive : 0<output.denominator
  value : output.mathematical.value=(n:Rat)/(d:Rat)

/-- Actual qi/qi/qv producer used by the original Euler-gamma branch.
The rational result is derived from actual source normalization/division. -/
theorem stages_exist (code : List Function) (qv : Generated.f_qv∈code)
    (lib : RationalDivideCalls.Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (n d : Nat) (nb : n<2^32) (db : d<2^32)
    (room : c.top+18<capacity) : Nonempty (Stages code l c n d) := by
  have first := RationalUnsignedTrace.qi_traced code lib.qi lib.si lib.mul.smake lib.mul.nz
    lib.mul.nu lib.mul.ne lib.mul.keep ctx n nb (by omega) (DecimalDigits.integer n)
    (literal_cast _ n nb)
  have second := RationalUnsignedTrace.qi_traced code lib.qi lib.si lib.mul.smake lib.mul.nz
    lib.mul.nu lib.mul.ne lib.mul.keep first.2.1 d db
    (by change c.top+3+2<capacity;omega) (DecimalDigits.integer d) (literal_cast _ d db)
  have numLive : (numInput l c n).Live (denominator l c n d).state := by
    constructor
    · exact CursorBorrow.preserves [d,0,1] first.2.2.1.1
    · exact CursorBorrow.preserves [d,0,1] first.2.2.1.2
  have denLive : (denInput l c n d).Live (denominator l c n d).state := second.2.2.1
  have divide := NumericRationalDivideRefinement.qv_math code qv lib second.2.1
    (by change c.top+3+3+12<capacity;omega) (numInput l c n) (denInput l c n d)
    numLive denLive (by simp [numInput,RationalUnsignedTrace.output])
    (by simp [denInput,RationalUnsignedTrace.output])
  obtain ⟨output,source,live,mathematical,positive⟩ :=
    NumericInputCompleteness.rational divide.2.2.1
  have call := divide.1
  rw [←source] at call
  have value : output.mathematical.value=(n:Rat)/(d:Rat) := by
    rw [mathematical,divide.2.2.2]
    exact congrArg₂ (fun x y : Rat=>x/y) first.2.2.2.1 second.2.2.2.1
  exact ⟨⟨first.1,second.1,output,call,divide.2.1,live,positive,value⟩⟩

end ScopedC.RationalUnsignedRatio
