/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientEvents

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

abbrev CoefficientWhile (service : Call) :=
  Loops.WhileRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
    coefficientCondition coefficientBody

/-- A finite execution of the original coefficient while. Every selected
callee event contains its actual lower-rank source execution; no success,
prepared table or expected numerical output is a premise. -/
structure CoefficientLoopCertificate (code : List Function) {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} (start : CoeffFrame l object d eb ab) where
  finish : CoeffFrame l object d eb ab
  events : List (CoefficientEvent code)
  unique : (events.map CallEvents.timeKey).Nodup
  bounds : ∀e∈events,start.cursor.state.nats.values.length ≤ e.before.nats.values.length ∧
    e.before.nats.values.length<finish.cursor.state.nats.values.length
  nats_le : start.cursor.state.nats.values.length ≤ finish.cursor.state.nats.values.length
  execution : ∀service,CoefficientEventAnswers service events →
    CoefficientWhile service start.cursor.state (.continuing finish.cursor.state)
  stopped : finish.k=d+1
  top : finish.cursor.top ≤ start.cursor.top+35*(d+1-start.k)
  shape : finish.cursor.state.heap.length=start.cursor.state.heap.length ∧
    finish.cursor.state.env=start.cursor.state.env

theorem coefficient_loop_certificate (code : List Function) (lib : CoeffLibrary code) (n : Nat)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (remaining : f.k+n=d+1)
    (room : f.cursor.top+35*n ≤ PoolCalls.capacity) :
    Nonempty (CoefficientLoopCertificate code f) := by
  induction n generalizing f with
  | zero =>
    have stopped : f.k=d+1 := by omega
    refine ⟨{
      finish:=f
      events:=[]
      unique:=by simp
      bounds:=by simp
      nats_le:=Nat.le_refl _
      execution:=?_
      stopped:=stopped
      top:=by omega
      shape:=⟨rfl,rfl⟩ }⟩
    intro service _
    exact Loops.WhileRun.done (coefficientCondition_eval service f)
      (by simp [UnsignedLiteralControl.truth_boolean,stopped])
  | succ n ih =>
    have active : f.k ≤ d := by omega
    have oneRoom : f.cursor.top+34<PoolCalls.capacity := by omega
    let next:=coefficientStep f active oneRoom
    have nextK : next.k=f.k+1:=coefficientStep_k f active oneRoom
    have nextRemaining : next.k+n=d+1 := by omega
    have nextRoom : next.cursor.top+35*n ≤ PoolCalls.capacity := by
      have bound:=coefficientStep_top f active oneRoom
      change next.cursor.top ≤ f.cursor.top+35 at bound
      omega
    obtain ⟨tail⟩:=ih next nextRemaining nextRoom
    let front:=coefficientEvents code lib f active oneRoom
    have nle : f.cursor.state.nats.values.length ≤ next.cursor.state.nats.values.length := by
      have size:=coefficientStep_size f active oneRoom
      change next.cursor.state.nats.values.length=_ at size
      split_ifs at size <;> omega
    have finishLower:=tail.nats_le
    refine ⟨{
      finish:=tail.finish
      events:=front++tail.events
      unique:=?_
      bounds:=?_
      nats_le:=nle.trans tail.nats_le
      execution:=?_
      stopped:=tail.stopped
      top:=?_
      shape:=⟨tail.shape.1.trans (coefficientStep_shape f active oneRoom).1,
        tail.shape.2.trans (coefficientStep_shape f active oneRoom).2⟩ }⟩
    · rw[List.map_append,List.nodup_append]
      refine ⟨coefficientEvents_unique code lib f active oneRoom,tail.unique,?_⟩
      intro a ha b hb same
      obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
      obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
      have keyEq:=ka.trans (same.trans kb.symm)
      change ea.before.nats.values.length=eb.before.nats.values.length at keyEq
      have left:=coefficientEvents_bounds code lib f active oneRoom ea hea
      have right:=tail.bounds eb heb
      change f.cursor.state.nats.values.length ≤ ea.before.nats.values.length ∧
        ea.before.nats.values.length<next.cursor.state.nats.values.length at left
      omega
    · intro e member
      rcases List.mem_append.mp member with first|later
      · have h:=coefficientEvents_bounds code lib f active oneRoom e first
        exact ⟨h.1,lt_of_lt_of_le h.2 finishLower⟩
      · have h:=tail.bounds e later
        exact ⟨nle.trans h.1,h.2⟩
    · intro service answers
      have frontAnswers : CoefficientEventAnswers service front:=fun e member=>
        answers e (List.mem_append_left _ member)
      have tailAnswers : CoefficientEventAnswers service tail.events:=fun e member=>
        answers e (List.mem_append_right _ member)
      exact Loops.WhileRun.next (coefficientCondition_eval service f)
        (by simp [UnsignedLiteralControl.truth_boolean,active])
        (coefficientStep_run service f active oneRoom
          (coefficientEvents_answers code lib f active oneRoom service frontAnswers))
        (tail.execution service tailAnswers)
    · have bound:=tail.top
      have topBound : next.cursor.top ≤ f.cursor.top+35:=coefficientStep_top f active oneRoom
      have kp:=f.kPositive
      omega

theorem coefficient_loop_old_math {code : List Function} {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} {f : CoeffFrame l object d eb ab}
    (certificate : CoefficientLoopCertificate code f) :
    TaylorCalls.coefficientValues certificate.finish.expCoeffs=LeanCert.Core.IntervalRat.expTaylorCoeffs d ∧
    TaylorCalls.coefficientValues certificate.finish.atanhCoeffs=LeanCert.Core.IntervalRat.atanhTaylorCoeffs d := by
  have exp:=certificate.finish.expValues
  have atanh:=certificate.finish.atanhValues
  rw[certificate.stopped] at exp atanh
  exact ⟨exp.trans (old_exp_values d),atanh.trans (old_atanh_values d)⟩

/-- A sound finite service witnesses the real source while: full name,
arguments and input state are checked before each already-proved source call. -/
theorem coefficient_loop_source {code : List Function} {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} {f : CoeffFrame l object d eb ab}
    (certificate : CoefficientLoopCertificate code f) :
    ∃service : Call,CoefficientWhile service f.cursor.state (.continuing certificate.finish.cursor.state) ∧
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 7 name args before value after) := by
  obtain ⟨service,answers,closed⟩:=CallEvents.timeline_service certificate.events certificate.unique
  exact ⟨service,certificate.execution service answers,closed⟩

end ScopedC.PrepareSource
