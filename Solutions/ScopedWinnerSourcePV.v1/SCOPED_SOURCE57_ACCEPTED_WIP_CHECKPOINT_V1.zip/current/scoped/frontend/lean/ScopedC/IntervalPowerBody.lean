/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerZeroBody

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Complete original rpow: the zero early return and both loops for every
positive uint32 exponent, exactly matching the original interval recursion. -/
theorem rpow_closed (code : List Function) (installed : Generated.f_rpow∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5120 ≤ PoolCalls.capacity) (a : Pair) (n : Nat)
    (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (bound : n<2^32) :
    ∃out : Cursor,∃q : Pair,
      SourceCall Header.layout code 9 "rpow" [a.source,PoolCalls.word n] c.state q.source out.state ∧
      Valid l out ∧ q.Live out.state ∧ q.Positive ∧
      NumericRepresentation.interval out.state q.source=some
        (LeanCert.Core.IntervalRat.pow ⟨a.lo.mathematical.value,a.hi.mathematical.value,order⟩ n) ∧
      out.top ≤ c.top+5120 := by
  by_cases zero : n=0
  · subst n
    simpa only[LeanCert.Core.IntervalRat.pow] using rpow_zero_closed code installed lib ctx room a alive
  · exact rpow_positive_closed code installed lib.rmul lib.multiplyLibrary ctx room a n alive positive order (by omega) bound

end ScopedC.IntervalPowerCalls
