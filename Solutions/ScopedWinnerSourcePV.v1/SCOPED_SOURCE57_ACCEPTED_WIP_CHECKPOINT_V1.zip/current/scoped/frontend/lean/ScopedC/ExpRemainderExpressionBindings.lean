/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderErrorEffects

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax

theorem first_power_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} (p : ThreePower f)
    (room : c.top+3000<PoolCalls.capacity) {name ty : String} {value : Value} {slot : Nat}
    (before : LocalBinding.At (afterThree f).state name ty value slot) (counter : ty≠"unsigned") :
    LocalBinding.At p.out.state name ty value slot := by
  have safe:=LocalStorageSeparation.pool (three_valid f room) before counter
  exact LocalBinding.memory before p.env
    (p.other _ (List.getElem?_eq_some_iff.mp before.memory).choose safe.1 safe.2.1 safe.2.2)

theorem second_power_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    {name ty : String} {value : Value} {slot : Nat}
    (before : LocalBinding.At p.out.state name ty value slot) (counter : ty≠"unsigned") :
    LocalBinding.At r.out.state name ty value slot := by
  have safe:=LocalStorageSeparation.pool p.valid before counter
  exact LocalBinding.memory before r.env
    (r.other _ (List.getElem?_eq_some_iff.mp before.memory).choose safe.1 safe.2.1 safe.2.2)

theorem numerator_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    {name ty : String} {value : Value} {slot : Nat}
    (before : LocalBinding.At r.out.state name ty value slot) (counter : ty≠"unsigned") :
    LocalBinding.At (numeratorCursor r).state name ty value slot := by
  have safe:=LocalStorageSeparation.pool r.valid before counter
  exact LocalBinding.memory before (numerator_env r) (numerator_other r _ safe.1 safe.2.1 safe.2.2)

theorem fact_three_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) :
    LocalBinding.At (afterThree f).state "fact" "Q" f.loop.finish.fact.source f.loop.finish.factSlot := by
  have safe:=LocalStorageSeparation.pool f.loop.finish.context f.loop.finish.factAt
    (by decide +kernel : ("Q":String)≠"unsigned")
  exact LocalBinding.advance f.loop.finish.factAt [3,0,1] safe.1 safe.2.1 safe.2.2

theorem fact_numerator_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (room : c.top+3000<PoolCalls.capacity) :
    LocalBinding.At (numeratorCursor r).state "fact" "Q" f.loop.finish.fact.source f.loop.finish.factSlot :=
  numerator_binding r (second_power_binding r (first_power_binding p room (fact_three_binding f)
    (by decide +kernel)) (by decide +kernel)) (by decide +kernel)

theorem radius_first_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) (p : ThreePower f) (ctx : Valid l c)
    (room : c.top+3000<PoolCalls.capacity) :
    LocalBinding.At p.out.state "r" "Q" (radius l c a).source (afterMax l c a).state.heap.length := by
  have before:=factorial_binding f (by omega) (radius_afterC_binding ceil ctx (by omega))
    (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have safe:=LocalStorageSeparation.pool f.loop.finish.context before (by decide +kernel : ("Q":String)≠"unsigned")
  exact first_power_binding p room (LocalBinding.advance before [3,0,1] safe.1 safe.2.1 safe.2.2)
    (by decide +kernel)

theorem count_three_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) (room : c.top+3000<PoolCalls.capacity) :
    LocalBinding.At (afterThree f).state "c" "unsigned int" (PoolCalls.word ceil.endpoint.magnitude)
      (afterSmall ceil).state.heap.length := by
  have before:=factorial_binding f (by omega) (count_binding ceil)
    (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have safe:=LocalStorageSeparation.pool f.loop.finish.context before
    (by decide +kernel : ("unsigned int":String)≠"unsigned")
  exact LocalBinding.advance before [3,0,1] safe.1 safe.2.1 safe.2.2

theorem first_power_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} (p : ThreePower f) :
    SourceUnsignedGlobal.At p.out.state "depth" object d := by
  have before : SourceUnsignedGlobal.At (afterThree f).state "depth" object d :=
    SourceUnsignedGlobal.advanced f.loop.finish.depthAt [3,0,1]
      f.loop.finish.depthApart.1 f.loop.finish.depthApart.2.1 f.loop.finish.depthApart.2.2
  exact SourceUnsignedGlobal.memory before p.globals
    (p.other _ (List.getElem?_eq_some_iff.mp before.storage).choose
      f.loop.finish.depthApart.1 f.loop.finish.depthApart.2.1 f.loop.finish.depthApart.2.2)

theorem first_power_depth_unshadowed {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} (p : ThreePower f) :
    p.out.state.env.lookup "depth"=none := by
  rw[p.env]
  change (CursorFrames.advance l (BeforeError f) [3,0,1]).state.env.lookup "depth"=none
  rw[(CursorEffects.shape l (BeforeError f) [3,0,1]).2]
  exact f.loop.finish.depthUnshadowed

end ScopedC.ExpRemainderCalls
