/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointModel

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

section
variable {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
variable {stage : CeilStage code l c q} {positive : 0 < q.denominator}
variable {base : Address} {coeffs : List Input} {d : Nat}
variable {t : TaylorStage stage positive base coeffs d} {r : RemainderStage t}

theorem tail_heap (p : PowerStage r) : p.out.state.heap.length = c.state.heap.length+7 := by
  rw [p.heap_length]
  unfold sumCursor
  rw [RationalIntervalAddCalls.after_heap_length,r.heap_length,t.heap_length,
    input_heap stage positive]

theorem tail_globals (p : PowerStage r) : p.out.state.globals = c.state.globals := by
  rw [p.globals]
  unfold sumCursor
  rw [RationalIntervalAddCalls.after_globals,r.globals,t.globals,
    input_globals stage positive]

theorem tail_borrow (p : PowerStage r) {slot value : Nat}
    (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow p.out.state.nats slot value := by
  apply p.preserves
  exact RationalIntervalAddCalls.preserves_nat _ _
    (r.preserves _ _ (t.preserves _ _ (input_borrow stage positive live)))

theorem tail_other (p : PowerStage r) (slot : Nat) (old : slot < c.state.heap.length)
    (hp : slot ≠ l.pool) (ht : slot ≠ l.top) (hh : slot ≠ l.high) :
    p.out.state.heap[slot]? = c.state.heap[slot]? := by
  have inputOld : slot < (afterInput stage positive).state.heap.length := by
    rw [input_heap stage positive]
    omega
  have tOld : slot < t.out.state.heap.length := by rw [t.heap_length]; exact inputOld
  have rOld : slot < r.out.state.heap.length := by rw [r.heap_length]; exact tOld
  have sumOld : slot < (sumCursor r).state.heap.length := by
    change slot < (RationalIntervalAddCalls.after l r.out t.output r.output).state.heap.length
    rw [RationalIntervalAddCalls.after_heap_length]
    exact rOld
  rw [p.other slot sumOld hp ht hh]
  change (RationalIntervalAddCalls.after l r.out t.output r.output).state.heap[slot]? = _
  rw [RationalIntervalAddCalls.after_other l r.out t.output r.output slot rOld hp ht hh,
    r.other slot tOld hp ht hh,t.other slot inputOld hp ht hh]
  exact input_other stage positive slot old hp ht hh

noncomputable def finalCursor (p : PowerStage r) : Cursor :=
  PoolContextPop.unframe c.state (PoolContextPop.unframe (parameters c q).state p.out)

theorem parameter_heap (c : Cursor) (q : Input) :
    (parameters c q).state.heap.length = c.state.heap.length+1 := by
  simp only [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate,
    List.length_append,List.length_singleton]

theorem final_shape (p : PowerStage r) :
    (finalCursor p).state.heap.length=c.state.heap.length ∧
      (finalCursor p).state.env=c.state.env := by
  constructor
  · change ((p.out.state.heap.take (parameters c q).state.heap.length).take c.state.heap.length).length = _
    rw [List.length_take,List.length_take,tail_heap p,parameter_heap]
    omega
  · rfl

theorem final_globals (p : PowerStage r) :
    (finalCursor p).state.globals = c.state.globals := tail_globals p

theorem final_borrow (p : PowerStage r) {slot value : Nat}
    (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (finalCursor p).state.nats slot value := tail_borrow p live

theorem final_other (p : PowerStage r) (slot : Nat) (old : slot < c.state.heap.length)
    (hp : slot ≠ l.pool) (ht : slot ≠ l.top) (hh : slot ≠ l.high) :
    (finalCursor p).state.heap[slot]? = c.state.heap[slot]? := by
  change ((p.out.state.heap.take (parameters c q).state.heap.length).take c.state.heap.length)[slot]? = _
  rw [List.getElem?_take_of_lt old,List.getElem?_take_of_lt
    (by rw [parameter_heap]; omega)]
  exact tail_other p slot old hp ht hh

end
end ScopedC.ExpPointCalls
