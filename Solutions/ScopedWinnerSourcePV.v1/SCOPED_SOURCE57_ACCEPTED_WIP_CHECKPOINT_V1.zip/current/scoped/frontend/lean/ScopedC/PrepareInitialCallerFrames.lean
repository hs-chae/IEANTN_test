/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientStage
import ScopedC.SourceScalarGlobal

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

theorem coefficient_initial_scalar {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity)
    {name type : String} {slot : Nat} {value : Option Value}
    (h : SourceScalarGlobal.At s.cursor.state name type slot value) (different : type≠"unsigned") :
    SourceScalarGlobal.At (coeffInitialFrame s room).cursor.state name type slot value := by
  have first : SourceScalarGlobal.At (initOneCursor s).state name type slot value:=
    SourceScalarGlobal.advanced s.context h different [1,0,1]
  have exp : SourceScalarGlobal.At (initExpCursor s).state name type slot value := by
    unfold initExpCursor
    exact SourceScalarGlobal.coefficient_store first (initExpBefore s) 0 (initOne s)
  have zero : SourceScalarGlobal.At (initZeroCursor s).state name type slot value:=
    SourceScalarGlobal.advanced (initExp_valid s room) exp different [0,0,1]
  have atanh : SourceScalarGlobal.At (initAtanhCursor s room).state name type slot value := by
    unfold initAtanhCursor
    exact SourceScalarGlobal.coefficient_store zero (initZeroAtanhTable s room) 0 (initZero s)
  exact SourceScalarGlobal.allocated atanh "unsigned int" "k" (some (PoolCalls.word 1))

theorem coefficient_initial_borrow {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity)
    {slot value : Nat} (h : NatArena.Borrow s.cursor.state.nats slot value) :
    NatArena.Borrow (coeffInitialFrame s room).cursor.state.nats slot value := by
  change NatArena.Borrow (initAtanhCursor s room).state.nats slot value
  unfold initAtanhCursor
  change NatArena.Borrow (CursorFrames.advance l (initExpCursor s) [0,0,1]).state.nats slot value
  apply CursorBorrow.preserves
  change NatArena.Borrow (initExpCursor s).state.nats slot value
  unfold initExpCursor
  exact CursorBorrow.preserves (l:=l) (c:=s.cursor) [1,0,1] h

theorem coefficient_initial_scale {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity)
    {scaleObject scaleSlot scaleValue : Nat}
    (scale : SourceFromS.ScaleAt s.cursor.state scaleObject scaleSlot scaleValue) :
    SourceFromS.ScaleAt (coeffInitialFrame s room).cursor.state scaleObject scaleSlot scaleValue := by
  have storage:=coefficient_initial_scalar s room
    (show SourceScalarGlobal.At s.cursor.state "scale100" "N" scaleObject (some (.natObject scaleSlot))
      from ⟨scale.lookup,scale.storage⟩) (by decide +kernel)
  exact ⟨storage.lookup,storage.storage,coefficient_initial_borrow s room scale.live⟩

theorem actualSeed_ln2 {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    SourceScalarGlobal.At (actualSeed ready d bound).cursor.state "preparedLn2" "RI" (base+7)
      (some ScopedIO.ApplicationInit.zeroInterval) := by
  have raw : SourceScalarGlobal.At state "preparedLn2" "RI" (base+7)
      (some ScopedIO.ApplicationInit.zeroInterval):=⟨ready.ln2Lookup,ready.ln2Memory⟩
  have parameters : SourceScalarGlobal.At (PrepareSource.parameters (staticCursor ready) d).state
      "preparedLn2" "RI" (base+7) (some ScopedIO.ApplicationInit.zeroInterval):=
    SourceScalarGlobal.allocated (SourceScalarGlobal.memory (t:={state with env:=[]}) raw rfl rfl)
      "unsigned int" "d" (some (PoolCalls.word d))
  have depth : SourceScalarGlobal.At (depthCursor ready d).state "preparedLn2" "RI" (base+7)
      (some ScopedIO.ApplicationInit.zeroInterval):=
    SourceScalarGlobal.memory (t:=(depthCursor ready d).state) parameters rfl
      (List.getElem?_set_ne (show base+3≠base+7 by omega))
  have shifted:=SourceScalarGlobal.advanced (depthSeed ready d bound).context depth
    (by decide +kernel) [1,100,1<<<100]
  exact SourceScalarGlobal.memory (t:=(actualSeed ready d bound).cursor.state) shifted rfl
    (List.getElem?_set_ne (show base+4≠base+7 by omega))

theorem coefficientStart_scale {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) :
    SourceFromS.ScaleAt (coefficientStart ready d bound).cursor.state (base+4)
      (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100) :=
  coefficient_initial_scale (actualSeed ready d bound) _ (actualSeed_scale ready d bound)

theorem coefficientStart_ln2 {state : State} {base : Nat} (ready : StaticAt state base)
    (d : Nat) (bound : d ≤ 64) :
    SourceScalarGlobal.At (coefficientStart ready d bound).cursor.state "preparedLn2" "RI" (base+7)
      (some ScopedIO.ApplicationInit.zeroInterval) :=
  coefficient_initial_scalar (actualSeed ready d bound) _ (actualSeed_ln2 ready d bound) (by decide +kernel)

end ScopedC.PrepareSource
