/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpFactorialStep

namespace ScopedC.ExpFactorial
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

theorem stepped_shape {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) :
    (stepped f active room).cursor.state.heap.length=f.cursor.state.heap.length ∧
      (stepped f active room).cursor.state.env=f.cursor.state.env := by
  have shape:=CursorEffects.shape l f.cursor
    ([f.k,0,1]++RationalMultiplyTrace.steps l (afterQi f) f.fact (counterInput f))
  constructor
  · change (((productCursor f).state.heap.set f.factSlot _).set f.kSlot _).length=_
    rw[List.length_set,List.length_set,product_trace]
    exact shape.1
  · change (productCursor f).state.env=_
    rw[product_trace]
    exact shape.2

theorem stepped_globals {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) :
    (stepped f active room).cursor.state.globals=f.cursor.state.globals := by
  change (productCursor f).state.globals=_
  rw[product_trace]
  exact CursorSingleFrames.advance_globals _ _ _

theorem stepped_borrow {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) {slot value : Nat}
    (live : NatArena.Borrow f.cursor.state.nats slot value) :
    NatArena.Borrow (stepped f active room).cursor.state.nats slot value := by
  change NatArena.Borrow (productCursor f).state.nats slot value
  rw[product_trace]
  exact CursorBorrow.preserves _ live

theorem stepped_other {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) (slot : Nat)
    (factApart : slot≠f.factSlot) (kApart : slot≠f.kSlot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (stepped f active room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  change (((productCursor f).state.heap.set f.factSlot _).set f.kSlot _)[slot]?=_
  rw[List.getElem?_set_ne (Ne.symm kApart),List.getElem?_set_ne (Ne.symm factApart),product_trace]
  exact CursorSingleFrames.advance_other _ _ _ slot hp ht hh

theorem stepped_slots {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) :
    (stepped f active room).factSlot=f.factSlot ∧ (stepped f active room).kSlot=f.kSlot := ⟨rfl,rfl⟩

end ScopedC.ExpFactorial
