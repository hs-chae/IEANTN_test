/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderNumerator
import ScopedC.RationalDivideOutput

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

noncomputable def errorInput {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) : Input :=
  RationalDivideCalls.outputInput l (numeratorCursor r) (numerator r) f.loop.finish.fact
    (numerator_positive r) f.loop.finish.positive

noncomputable def errorCursor {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) : Cursor :=
  RationalDivideCalls.after l (numeratorCursor r) (numerator r) f.loop.finish.fact

theorem factorial_numerator_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    f.loop.finish.fact.Live (numeratorCursor r).state := by
  have first : f.loop.finish.fact.Live (afterThree f).state :=
    ⟨CursorBorrow.preserves (l:=l) (c:=BeforeError f) [3,0,1] f.loop.finish.live.1,
      CursorBorrow.preserves (l:=l) (c:=BeforeError f) [3,0,1] f.loop.finish.live.2⟩
  have second : f.loop.finish.fact.Live p.out.state:=⟨p.preserves _ _ first.1,p.preserves _ _ first.2⟩
  have third : f.loop.finish.fact.Live r.out.state:=⟨r.preserves _ _ second.1,r.preserves _ _ second.2⟩
  unfold numeratorCursor
  exact ⟨RationalMultiplyCalls.preserves third.1,RationalMultiplyCalls.preserves third.2⟩

theorem numerator_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (numeratorCursor r).top=r.out.top+11 := by
  unfold numeratorCursor
  exact RationalMultiplyCalls.top11 l r.out p.output r.output

theorem error_source (code : List Function) (installed : Generated.f_qv∈code)
    (lib : RationalDivideCalls.Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (room : c.top+3000<PoolCalls.capacity) :
    SourceCall Header.layout code 7 "qv" [(numerator r).source,f.loop.finish.fact.source]
      (numeratorCursor r).state (errorInput r).source (errorCursor r).state := by
  have top:=radius_power_top r
  exact RationalDivideCalls.output_source code installed lib (numerator_valid r room)
    (by rw[numerator_top];omega) (numerator r) f.loop.finish.fact (numerator_live r)
    (factorial_numerator_live r) (numerator_positive r) f.loop.finish.positive

theorem error_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (errorInput r).Live (errorCursor r).state :=
  (RationalDivideCalls.output_spec l (numeratorCursor r) (numerator r) f.loop.finish.fact
    (numerator_positive r) f.loop.finish.positive).2.1

theorem error_positive {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    0<(errorInput r).denominator :=
  (RationalDivideCalls.output_spec l (numeratorCursor r) (numerator r) f.loop.finish.fact
    (numerator_positive r) f.loop.finish.positive).2.2.2

theorem error_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (positive : a.Positive) :
    (errorInput r).mathematical.value=(3:Rat)^(ceil.endpoint.magnitude+1)*
      (max |a.lo.mathematical.value| |a.hi.mathematical.value|)^(d+1)/((d+1).factorial:Rat) := by
  have value:=(RationalDivideCalls.output_spec l (numeratorCursor r) (numerator r) f.loop.finish.fact
    (numerator_positive r) f.loop.finish.positive).2.2.1
  change (errorInput r).mathematical.value=_ at value
  rw[value,numerator_value r positive,factorial_value f]

theorem error_nonnegative {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (positive : a.Positive) : 0 ≤ (errorInput r).mathematical.value := by
  rw[error_value r positive]
  exact div_nonneg (mul_nonneg (pow_nonneg (by norm_num) _)
    (pow_nonneg (le_trans (abs_nonneg _) (le_max_left _ _)) _)) (by positivity)

end ScopedC.ExpRemainderCalls
