/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEvents

namespace ScopedC.CallEvents
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Read-only point calls can share an arena count with a following
allocating helper. The actual callee name disambiguates those events. This
index never replaces the full state/name/argument check or source proof. -/
def nameKey {cfg : Layout} {code : List Function} {rank : Nat} (e : Event cfg code rank) : Nat×String :=
  (e.before.nats.values.length,e.name)

theorem find_named {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map nameKey).Nodup)
    (e : Event cfg code rank) (member : e∈events) :
    events.find? (fun x=>decide (nameKey x=nameKey e))=some e := by
  induction events with
  | nil => simp at member
  | cons first rest ih =>
    have un : nameKey first∉rest.map nameKey ∧ (rest.map nameKey).Nodup := by
      simpa only[List.map_cons,List.nodup_cons] using unique
    rcases List.mem_cons.mp member with same | later
    · subst e
      simp
    · have distinct : nameKey first≠nameKey e := by
        intro same
        apply un.1
        rw[same]
        exact List.mem_map.mpr ⟨e,later,rfl⟩
      simpa only[List.find?_cons,distinct,decide_false,Bool.false_eq_true,↓reduceIte] using ih un.2 later

noncomputable def nameTimeline {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) : Call := fun name args before =>
  match events.find? (fun e=>decide (nameKey e=(before.nats.values.length,name))) with
  | none => none
  | some e => one e name args before

theorem nameTimeline_self {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map nameKey).Nodup)
    (e : Event cfg code rank) (member : e∈events) :
    nameTimeline events e.name e.args e.before=some (e.value,e.after) := by
  unfold nameTimeline
  rw[show events.find? (fun x=>decide (nameKey x=(e.before.nats.values.length,e.name)))=some e from find_named events unique e member]
  exact one_self e

theorem nameTimeline_closed {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) {name : String} {args : List Value} {s t : State} {v : Value}
    (h : nameTimeline events name args s=some (v,t)) : SourceCall cfg code rank name args s v t := by
  unfold nameTimeline at h
  split at h
  · contradiction
  · exact one_closed _ h

theorem nameTimeline_service {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (events.map nameKey).Nodup) :
    ∃service : Call,
      (∀e∈events,service e.name e.args e.before=some (e.value,e.after)) ∧
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall cfg code rank name args before value after) :=
  ⟨nameTimeline events,nameTimeline_self events unique,fun _ _ _ _ _ h=>nameTimeline_closed events h⟩

end ScopedC.CallEvents
