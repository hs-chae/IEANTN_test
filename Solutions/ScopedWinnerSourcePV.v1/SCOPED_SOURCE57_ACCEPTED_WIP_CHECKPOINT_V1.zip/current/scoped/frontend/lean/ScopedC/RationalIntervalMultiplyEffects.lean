/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplyStorage
import ScopedC.SourceScaleFrames

namespace ScopedC.RationalIntervalMultiplyCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000
attribute [local irreducible] finish

private theorem saved_globals (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (name : String) :
    (RationalProductApplicability.saved l c a b name).state.globals=c.state.globals :=
  RationalMultiplyTrace.globals l c a b

private theorem saved_other (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (name : String)
    (i : Nat) (bound : i < c.state.heap.length)
    (hp : i≠l.pool) (ht : i≠l.top) (hh : i≠l.high) :
    (RationalProductApplicability.saved l c a b name).state.heap[i]?=c.state.heap[i]? := by
  change ((RationalMultiplyCalls.c11 l c a b).state.heap++[_])[i]?=c.state.heap[i]?
  rw[List.getElem?_append_left (by rw[(RationalMultiplyCalls.shape l c a b).1];exact bound)]
  exact RationalMultiplyTrace.other l c a b i hp ht hh

private theorem base_other (c : Cursor) (a b : Pair) (i : Nat) (bound : i < c.state.heap.length) :
    (base c a b).state.heap[i]?=c.state.heap[i]? := by
  simp only[base,RationalIntervalFrames.framed,CursorFrames.framed,TwoFrames.frame,allocate]
  rw[List.getElem?_append_left (by simp only[List.length_append,List.length_singleton];omega),
    List.getElem?_append_left bound]

theorem products_other (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (i : Nat)
    (bound : i < c.state.heap.length) (hp : i≠l.pool) (ht : i≠l.top) (hh : i≠l.high) :
    (c4 l c a b).state.heap[i]?=c.state.heap[i]? := by
  unfold c4
  rw[saved_other l (c3 l c a b) a.hi b.hi "s" i (by rw[heap3];omega) hp ht hh]
  unfold c3
  rw[saved_other l (c2 l c a b) a.hi b.lo "r" i (by rw[heap2];omega) hp ht hh]
  unfold c2
  rw[saved_other l (c1 l c a b) a.lo b.hi "q" i (by rw[heap1];omega) hp ht hh]
  unfold c1
  rw[saved_other l (base c a b) a.lo b.lo "p" i (by rw[heap0];omega) hp ht hh]
  exact base_other c a b i bound

theorem finish_other (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (i : Nat)
    (bound : i < c.state.heap.length) (hp : i≠l.pool) (ht : i≠l.top) (hh : i≠l.high) :
    (finish l c a b).state.heap[i]?=c.state.heap[i]? := by
  unfold finish
  rw[RationalSelectionTree.finish_advance,CursorSingleFrames.advance_other l _ _ i hp ht hh]
  unfold middle
  rw[RationalSelectionTree.finish_advance,CursorSingleFrames.advance_other l _ _ i hp ht hh]
  exact products_other l c a b i bound hp ht hh

theorem finish_heap_length (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (finish l c a b).state.heap.length=c.state.heap.length+6 := by
  unfold finish
  rw[(RationalSelectionTree.shape true l (middle l c a b) (four l c a b)).1]
  unfold middle
  rw[(RationalSelectionTree.shape false l (c4 l c a b) (four l c a b)).1,heap4]

theorem after_other (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (i : Nat)
    (bound : i < c.state.heap.length) (hp : i≠l.pool) (ht : i≠l.top) (hh : i≠l.high) :
    (after l c a b).state.heap[i]?=c.state.heap[i]? := by
  change ((((finish l c a b).state.heap++[_]).take (base c a b).state.heap.length).take c.state.heap.length)[i]? = _
  rw[List.getElem?_take_of_lt bound,List.getElem?_take_of_lt (by rw[heap0];omega),
    List.getElem?_append_left (by rw[finish_heap_length];omega)]
  exact finish_other l c a b i bound hp ht hh

theorem after_globals (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (after l c a b).state.globals=c.state.globals := by
  change (finish l c a b).state.globals=c.state.globals
  unfold finish
  rw[RationalSelectionTree.finish_advance,CursorSingleFrames.advance_globals]
  unfold middle
  rw[RationalSelectionTree.finish_advance,CursorSingleFrames.advance_globals]
  unfold c4;rw[saved_globals]
  unfold c3;rw[saved_globals]
  unfold c2;rw[saved_globals]
  unfold c1;rw[saved_globals]
  rfl

theorem after_env (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (after l c a b).state.env=c.state.env := rfl

theorem after_heap_length (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (after l c a b).state.heap.length=c.state.heap.length := by
  simp only[after,bodyExit,stored,PoolContextPop.unframe,popScope,CursorLocals.allocated,allocate,
    List.length_take,List.length_append,List.length_singleton,finish_heap_length,heap0]
  omega

theorem preserves_nat {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Pair) {slot n : Nat}
    (h : NatArena.Borrow c.state.nats slot n) : NatArena.Borrow (after l c a b).state.nats slot n := by
  have h1 : NatArena.Borrow (c1 l c a b).state.nats slot n := by
    unfold c1;exact RationalMultiplyCalls.preserves (c:=base c a b) (a:=a.lo) (b:=b.lo) h
  have h2 : NatArena.Borrow (c2 l c a b).state.nats slot n := by
    unfold c2;exact RationalMultiplyCalls.preserves (c:=c1 l c a b) (a:=a.lo) (b:=b.hi) h1
  have h3 : NatArena.Borrow (c3 l c a b).state.nats slot n := by
    unfold c3;exact RationalMultiplyCalls.preserves (c:=c2 l c a b) (a:=a.hi) (b:=b.lo) h2
  have h4 : NatArena.Borrow (c4 l c a b).state.nats slot n := by
    unfold c4;exact RationalMultiplyCalls.preserves (c:=c3 l c a b) (a:=a.hi) (b:=b.hi) h3
  have hm : NatArena.Borrow (middle l c a b).state.nats slot n := by
    unfold middle;exact RationalSelectionTree.preserves_nat false (four l c a b) h4
  change NatArena.Borrow (finish l c a b).state.nats slot n
  unfold finish
  exact RationalSelectionTree.preserves_nat true (four l c a b) hm

/-- The actual prepared scale object and its Nat storage survive the complete
source multiplication; no presumed prepared state or extra separation premise. -/
theorem preserves_scale {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a b : Pair) {object slot d : Nat} (scale : SourceFromS.ScaleAt c.state object slot d) :
    SourceFromS.ScaleAt (after l c a b).state object slot d := by
  have safe:=SourceScaleFrames.separated ctx scale
  have bound:=(List.getElem?_eq_some_iff.mp scale.storage).choose
  constructor
  · rw[after_globals];exact scale.lookup
  · rw[after_other l c a b object bound safe.1 safe.2.1 safe.2.2];exact scale.storage
  · exact preserves_nat a b scale.live

end ScopedC.RationalIntervalMultiplyCalls
