/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAbsApplicability
import ScopedC.RationalSelectionTreeMath
import ScopedC.RationalCompareEffects
import ScopedC.CursorLocals
import ScopedC.LocalStorageSeparation

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def parameters (c : Cursor) (a : Pair) : Cursor :=
  {c with state:=OneFrames.frame c.state "RI" "a" a.source}
def afterLo (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) : Cursor := next l (parameters c a) 0
def afterHi (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) : Cursor := next l (afterLo l c a) 0
def low (a : Pair) : Input := RationalAbsApplicability.output a.lo
def high (a : Pair) : Input := RationalAbsApplicability.output a.hi
def radius (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) : Input :=
  RationalSelectionTree.chosen true l (afterHi l c a) (low a) (high a)
def afterMax (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) : Cursor :=
  RationalSelectionTree.step l (afterHi l c a) (low a) (high a)
def afterR (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) : Cursor :=
  CursorLocals.allocated (afterMax l c a) "Q" "r" (radius l c a).source

structure EntryLibrary (code : List Function) : Prop where
  absolute : RationalAbsApplicability.Library code
  selection : RationalIntervalHullCalls.Library code

theorem parameters_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) :
    Valid l (parameters c a) := OneFrames.context_frame ctx "RI" "a" a.source

theorem parameters_binding (c : Cursor) (a : Pair) :
    LocalBinding.At (parameters c a).state "a" "RI" a.source c.state.heap.length :=
  LocalBinding.allocate_head {c.state with env:=[]} "a" "RI" a.source (Pair.initialized a)

theorem afterLo_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair)
    (room : c.top+7<PoolCalls.capacity) : Valid l (afterLo l c a) :=
  next_valid 0 (parameters_valid ctx a) (by change c.top<PoolCalls.capacity;omega)

theorem afterHi_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair)
    (room : c.top+7<PoolCalls.capacity) : Valid l (afterHi l c a) :=
  next_valid 0 (afterLo_valid ctx a room) (by change c.top+1<PoolCalls.capacity;omega)

theorem afterMax_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair)
    (room : c.top+7<PoolCalls.capacity) : Valid l (afterMax l c a) :=
  RationalSelectionTree.step_valid (afterHi_valid ctx a room) (by change c.top+1+1+5<PoolCalls.capacity;omega) _ _

theorem radius_live {l : PoolCalls.PoolLayout} {c : Cursor} (a : Pair) (alive : a.Live c.state) :
    (radius l c a).Live (afterMax l c a).state := by
  have lo : (low a).Live (afterHi l c a).state :=
    ⟨PoolCursor.preserves (RationalAbsApplicability.live (l:=l) (c:=parameters c a) alive.1).1,
      PoolCursor.preserves (RationalAbsApplicability.live (l:=l) (c:=parameters c a) alive.1).2⟩
  have hi : (high a).Live (afterHi l c a).state :=
    RationalAbsApplicability.live (l:=l) (c:=afterLo l c a)
      ⟨PoolCursor.preserves (l:=l) (c:=parameters c a) alive.2.1,
        PoolCursor.preserves (l:=l) (c:=parameters c a) alive.2.2⟩
  exact RationalIntervalHullCalls.selected_live true l (afterHi l c a) (low a) (high a) lo hi

theorem radius_positive {l : PoolCalls.PoolLayout} {c : Cursor} (a : Pair) (positive : a.Positive) :
    0<(radius l c a).denominator :=
  RationalIntervalHullCalls.selected_positive true l (afterHi l c a) (low a) (high a) positive.1 positive.2

theorem radius_value {l : PoolCalls.PoolLayout} {c : Cursor} (a : Pair) (positive : a.Positive) :
    (radius l c a).mathematical.value=max |a.lo.mathematical.value| |a.hi.mathematical.value| := by
  unfold radius
  rw[RationalSelectionTree.chosen_value true l (afterHi l c a) (low a) (high a) positive.1 positive.2]
  change max (low a).mathematical.value (high a).mathematical.value=_
  unfold low high
  rw[RationalAbsApplicability.value,RationalAbsApplicability.value]

theorem afterR_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair)
    (room : c.top+7<PoolCalls.capacity) : Valid l (afterR l c a) :=
  CursorLocals.allocated_valid (afterMax_valid ctx a room) "Q" "r" _

theorem radius_binding (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    LocalBinding.At (afterR l c a).state "r" "Q" (radius l c a).source
      (afterMax l c a).state.heap.length := LocalBinding.allocate_head _ "r" "Q" _ (by rfl)

end ScopedC.ExpRemainderCalls
