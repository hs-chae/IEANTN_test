/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerScanStep
import ScopedC.CallEventTimeline

namespace ScopedC.IntervalPowerScan
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

abbrev Event (code : List Function) := CallEvents.Event Header.layout code 8
def Answers {code : List Function} (service : Call) (events : List (Event code)) : Prop :=
  ∀e∈events,service e.name e.args e.before=some (e.value,e.after)

def squareEvent (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) : Event code :=
  ⟨"rmul",[(left f false).source,f.result.source],f.cursor.state,(product f false).source,
    (IntervalProductApplicability.next l f.cursor (left f false) f.result).state,
    multiplied_call code installed lib f false (by omega)⟩
def oddEvent (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) : Event code :=
  ⟨"rmul",[(left (squared f room) true).source,(squared f room).result.source],(squared f room).cursor.state,
    (product (squared f room) true).source,
    (IntervalProductApplicability.next l (squared f room).cursor (left (squared f room) true) (squared f room).result).state,
    multiplied_call code installed lib (squared f room) true (by rw[squared_top];omega)⟩
def iterationEvents (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) : List (Event code) :=
  squareEvent code installed lib f room :: (if (n/f.bit)%2=1 then [oddEvent code installed lib f room] else [])

theorem event_run (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) (positive : 0<f.bit)
    (service : Call) (answers : Answers service (iterationEvents code installed lib f room)) :
    Run Header.layout service loopBody f.cursor.state (.continuing (iteration f room).cursor.state) := by
  apply iteration_run service f room positive
  · exact answers (squareEvent code installed lib f room) (List.mem_cons_self)
  · intro odd
    apply answers (oddEvent code installed lib f room)
    apply List.mem_cons_of_mem
    simp only[odd,↓reduceIte,List.mem_singleton]

theorem next_size (l : PoolCalls.PoolLayout) (c : Cursor) (a b : RationalIntervalFrames.Pair) :
    (IntervalProductApplicability.next l c a b).state.nats.values.length=c.state.nats.values.length+80 := by
  unfold IntervalProductApplicability.next
  change (RationalIntervalMultiplyCalls.finish l c a b).state.nats.values.length=_
  unfold RationalIntervalMultiplyCalls.finish
  rw[RationalSelectionTree.size_finish]
  unfold RationalIntervalMultiplyCalls.middle
  rw[RationalSelectionTree.size_finish,RationalIntervalMultiplyCalls.size4]
theorem multiplied_size {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool)
    (room : f.cursor.top+79<PoolCalls.capacity) :
    (multiplied f fromA room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+80 :=
  next_size l f.cursor (left f fromA) f.result
theorem iteration_size {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) :
    (iteration f room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+80+
      (if (n/f.bit)%2=1 then 80 else 0) := by
  change (afterOdd f room).cursor.state.nats.values.length=_
  unfold afterOdd
  split
  · rw[multiplied_size,show (squared f room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+80 from multiplied_size f false _]
  · rw[show (squared f room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+80 from multiplied_size f false _]

theorem event_keys (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) :
    (iterationEvents code installed lib f room).map CallEvents.timeKey=
      f.cursor.state.nats.values.length :: (if (n/f.bit)%2=1 then [f.cursor.state.nats.values.length+80] else []) := by
  unfold iterationEvents
  rw[List.map_cons]
  split <;> simp only[List.map_cons,List.map_nil]
  · change _ :: [(squared f room).cursor.state.nats.values.length]=_
    rw[show (squared f room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+80 from multiplied_size f false _]
    rfl
  · rfl

theorem event_bounds (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) (e : Event code)
    (member : e∈iterationEvents code installed lib f room) :
    f.cursor.state.nats.values.length ≤ CallEvents.timeKey e ∧
      CallEvents.timeKey e < (iteration f room).cursor.state.nats.values.length := by
  have keyMember : CallEvents.timeKey e∈(iterationEvents code installed lib f room).map CallEvents.timeKey := List.mem_map.mpr ⟨e,member,rfl⟩
  rw[event_keys] at keyMember
  have count:=iteration_size f room
  split_ifs at keyMember count <;> simp only[List.mem_cons,List.not_mem_nil,or_false] at keyMember <;> omega

theorem event_unique (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) :
    ((iterationEvents code installed lib f room).map CallEvents.timeKey).Nodup := by
  rw[event_keys]
  split <;> simp

end ScopedC.IntervalPowerScan
