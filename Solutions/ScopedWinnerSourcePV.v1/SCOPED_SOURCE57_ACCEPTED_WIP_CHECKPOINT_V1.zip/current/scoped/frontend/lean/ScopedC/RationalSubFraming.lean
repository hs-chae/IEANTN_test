/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalSubRefinement
import ScopedC.NumericRationalCompleteness
import ScopedC.RationalAddEffects
import ScopedC.CursorSingleFrames

namespace ScopedC.RationalSubCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem after_globals (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (after l c a b).state.globals=c.state.globals := by
  change (interior l c a b).state.globals=_
  unfold interior
  rw[RationalAddCalls.trace,CursorSingleFrames.advance_globals]
  exact CursorSingleFrames.globals l c 0

theorem after_env (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (after l c a b).state.env=c.state.env := rfl

theorem phase1_length (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (phase1 l c a b).state.heap.length=c.state.heap.length+2 := by
  simp only[phase1,c1,CursorFrames.framed,TwoFrames.frame,allocate,List.length_append,
    List.length_singleton]
  rw[(PoolCursor.shape l c 0).1]

theorem after_heap_length (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (after l c a b).state.heap.length=c.state.heap.length := by
  change ((interior l c a b).state.heap.take c.state.heap.length).length=_
  rw[List.length_take]
  unfold interior
  rw[RationalAddCalls.trace,(CursorEffects.shape l (phase1 l c a b)
    (RationalAddCalls.effects l (phase1 l c a b) a (negative b))).1,phase1_length]
  omega

theorem after_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (after l c a b).top=c.top+15 := by
  change (interior l c a b).top=_
  unfold interior
  rw[RationalAddCalls.top14]
  rfl

theorem after_other (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (slot : Nat)
    (old : slot<c.state.heap.length) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (after l c a b).state.heap[slot]?=c.state.heap[slot]? := by
  change ((interior l c a b).state.heap.take c.state.heap.length)[slot]?=_
  rw[List.getElem?_take_of_lt old]
  unfold interior
  rw[RationalAddCalls.trace,CursorSingleFrames.advance_other l (phase1 l c a b)
    (RationalAddCalls.effects l (phase1 l c a b) a (negative b)) slot hp ht hh]
  change (((next l c 0).state.heap++[_])++[_])[slot]?=_
  have before : slot<(next l c 0).state.heap.length := by
    rw[(PoolCursor.shape l c 0).1]
    exact old
  rw[List.getElem?_append_left (by rw[List.length_append,List.length_singleton];omega),
    List.getElem?_append_left before]
  exact PoolCursor.other l c 0 slot hp ht hh

theorem after_borrow {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Input)
    {slot value : Nat} (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (after l c a b).state.nats slot value := by
  change NatArena.Borrow (interior l c a b).state.nats slot value
  unfold interior
  exact RationalAddCalls.preserves (a:=a) (b:=negative b) (PoolCursor.preserves live)

end ScopedC.RationalSubCalls
