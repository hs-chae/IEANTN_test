/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalAddApplicability
import ScopedC.DataReads

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

/-- Application-owned, physically initialized coefficient cells. This is an
explicit component precondition to be established by the actual prepare
source loop; it is never a trusted initial application representation. Cells
beyond the supplied coefficient prefix may remain uninitialized. -/
structure TableAt (s : State) (base : Address) (coeffs : List Input) where
  cells : List (Option Value)
  memory : s.heap[base.object]?=some {type:="Q",cells:=cells,isArray:=true}
  zeroIndex : base.index=0
  emptyFields : base.fields=[]
  entries : ∀k (hk : k<coeffs.length),cells[k]?=some (some coeffs[k].source)
  live : ∀k (hk : k<coeffs.length),coeffs[k].Live s
  positive : ∀k (hk : k<coeffs.length),0<coeffs[k].denominator

theorem read_coefficient {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) (k : Nat) (hk : k<coeffs.length) :
    read Header.layout s {base with index:=base.index+k}=some coeffs[k].source ∧
      addressType Header.layout s {base with index:=base.index+k}=some "Q" := by
  have entry:=table.entries k hk
  have bound : k<table.cells.length := (List.getElem?_eq_some_iff.mp entry).choose
  have init : initialized 1000 coeffs[k].source=true := rfl
  constructor
  · simp only[Machine.read,table.memory,table.zeroIndex,Nat.zero_add,entry,Bind.bind,Option.bind,table.emptyFields,nested,init,↓reduceIte]
  · simp [addressType,table.memory,table.zeroIndex,table.emptyFields,bound,typeAt]

/-- Actual typed pointer-plus-index lvalue/read execution for coeffs[k]. -/
theorem source_index (service : Call) (fuel : Nat) {s : State} {base : Address} {coeffs : List Input}
    {array indexExpr : Expr} (table : TableAt s base coeffs) (k : Nat) (hk : k<coeffs.length)
    (pointer : evalExpr Header.layout service (fuel+1) s array=some (.pointer base false,s))
    (index : evalExpr Header.layout service (fuel+1) s indexExpr=some (unsigned32 k,s)) :
    evalExpr Header.layout service (fuel+3) s (.index array indexExpr)=some (coeffs[k].source,s) := by
  have read:=read_coefficient table k hk
  rw[evalExpr,evalLValue,pointer]
  simp only[Bind.bind,Option.bind,table.emptyFields,List.isEmpty_nil,Bool.not_true,Bool.false_eq_true,↓reduceIte]
  rw[index]
  simp only[table.emptyFields] at read
  simp [asNat,unsigned32,read.1,read.2]

def memory {s t : State} {base : Address} {coeffs : List Input} (table : TableAt s base coeffs)
    (storage : t.heap[base.object]?=s.heap[base.object]?)
    (borrow : ∀slot n,NatArena.Borrow s.nats slot n → NatArena.Borrow t.nats slot n) : TableAt t base coeffs := by
  refine ⟨table.cells,storage.trans table.memory,table.zeroIndex,table.emptyFields,table.entries,?_,table.positive⟩
  intro k hk
  have live:=table.live k hk
  exact ⟨borrow _ _ live.1,borrow _ _ live.2⟩

end ScopedC.CoefficientTableRead
