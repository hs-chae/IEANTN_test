/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalHullBody
import ScopedC.NumericNatsExtensionality

namespace ScopedC.NumericRationalIntervalHullRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalIntervalHullCalls
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000
attribute [local irreducible] finish

theorem decoded_result {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair}
    (ha : a.Live c.state) (hb : b.Live c.state) (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value≤a.hi.mathematical.value)
    (ob : b.lo.mathematical.value≤b.hi.mathematical.value) :
    NumericRepresentation.interval (after l c a b).state (result l c a b)=some
      (IntervalRat.hull ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩) := by
  have pl : 0<(lowQ l c a b).denominator :=
    selected_positive false l (base c a b) a.lo b.lo pa.1 pb.1
  have ph : 0<(highQ l c a b).denominator :=
    selected_positive true l (middle l c a b) a.hi b.hi pa.2 pb.2
  have dl:=Input.decoded (low_live (l:=l) (c:=c) (a:=a) (b:=b) ha hb) pl
  have dh:=Input.decoded (high_live (l:=l) (c:=c) (a:=a) (b:=b) ha hb) ph
  have lv : (lowQ l c a b).mathematical.value=min a.lo.mathematical.value b.lo.mathematical.value :=
    NumericRationalSelectRefinement.minimum_value l (base c a b) a.lo b.lo pa.1 pb.1
  have hv : (highQ l c a b).mathematical.value=max a.hi.mathematical.value b.hi.mathematical.value :=
    NumericRationalSelectRefinement.maximum_value l (middle l c a b) a.hi b.hi pa.2 pb.2
  have order : min a.lo.mathematical.value b.lo.mathematical.value≤
      max a.hi.mathematical.value b.hi.mathematical.value :=
    le_trans (min_le_left _ _) (le_trans oa (le_max_left _ _))
  have inside : NumericRepresentation.interval (finish l c a b).state (result l c a b)=some
      (IntervalRat.hull ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩) := by
    simp [NumericRepresentation.interval,result,IntervalCasts.value,dl,dh,lv,hv,oa,ob,IntervalRat.hull]
  exact (NumericNatsExtensionality.interval (s:=(finish l c a b).state) (t:=(after l c a b).state)
    (by rfl) (result l c a b)).symm.trans inside

/-- Exact original hull, with unchanged live rational inputs, positive
denominators and ordered-interval domain, obtained from the actual source. -/
theorem rhull_math (code : List Function) (installed : Generated.f_rhull∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+11<PoolCalls.capacity)
    (a b : Pair) (ha : a.Live c.state) (hb : b.Live c.state) (pa : a.Positive) (pb : b.Positive)
    (oa : a.lo.mathematical.value≤a.hi.mathematical.value)
    (ob : b.lo.mathematical.value≤b.hi.mathematical.value) :
    SourceCall Header.layout code 8 "rhull" [a.source,b.source] c.state
      (result l c a b) (after l c a b).state ∧
    NumericRepresentation.interval (after l c a b).state (result l c a b)=some
      (IntervalRat.hull ⟨a.lo.mathematical.value,a.hi.mathematical.value,oa⟩
        ⟨b.lo.mathematical.value,b.hi.mathematical.value,ob⟩) :=
  ⟨rhull_closed code installed lib ctx room a b ha hb,decoded_result ha hb pa pb oa ob⟩

end ScopedC.NumericRationalIntervalHullRefinement
