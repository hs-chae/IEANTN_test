/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerSquare
import ScopedC.RationalPowerHalving

namespace ScopedC.RationalPowerCalls
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem accumulate_shape {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (accumulate f room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (accumulate f room).cursor.state.env=f.cursor.state.env := by
  change ((accNext f).state.heap.set f.rSlot {type:="Q",cells:=[some (accProduct f).source]}).length=
      f.cursor.state.heap.length ∧ (accNext f).state.env=f.cursor.state.env
  rw[List.length_set,accNext]
  exact RationalMultiplyCalls.shape l f.cursor f.accumulator f.current

theorem square_shape {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (square f room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (square f room).cursor.state.env=f.cursor.state.env := by
  change ((squareNext f).state.heap.set f.aSlot {type:="Q",cells:=[some (squareProduct f).source]}).length=
      f.cursor.state.heap.length ∧ (squareNext f).state.env=f.cursor.state.env
  rw[List.length_set,squareNext]
  exact RationalMultiplyCalls.shape l f.cursor f.current f.current

theorem accumulate_size {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (accumulate f room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+11 := by
  change (accNext f).state.nats.values.length=_
  rw[accNext,RationalMultiplyTrace.c11_advance,CursorEffects.size]
  rfl
theorem square_size {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (square f room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+11 := by
  change (squareNext f).state.nats.values.length=_
  rw[squareNext,RationalMultiplyTrace.c11_advance,CursorEffects.size]
  rfl

theorem accumulate_current {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (accumulate f room).current=f.current := rfl
theorem accumulate_exponent {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (accumulate f room).exponent=f.exponent := rfl
theorem square_accumulator {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (square f room).accumulator=f.accumulator := rfl
theorem square_exponent {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (square f room).exponent=f.exponent := rfl
theorem half_top {l : PoolCalls.PoolLayout} (f : Frame l) : (half f).cursor.top=f.cursor.top := rfl

end ScopedC.RationalPowerCalls
