/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderCeil
import ScopedC.NatSmallCall

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] radius

def afterCeil {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) : Cursor :=
  CursorLocals.allocated stage.out "S" "ceil" stage.endpoint.source

theorem ceil_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} (stage : CeilStage code l c a)
    (ctx : Valid l c) (room : c.top+7<PoolCalls.capacity)
    (answer : service "ceilQ" [(radius l c a).source] (afterR l c a).state=
      some (stage.endpoint.source,stage.out.state)) :
    Declare Header.layout service [{type:="S",name:="ceil",value:=some (.call (.var "ceilQ") [.var "r"]),arrayExtent:=none}]
      (afterR l c a).state (afterCeil stage).state := by
  have expression:=ExpressionTemplates.call_one Header.layout service
    (LocalBinding.eval service 998 (radius_binding l c a) (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)) answer
  have cast:=Endpoint.cast (s:=stage.out.state) 98 "S" (by decide +kernel) stage.live
  simp only[Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem ceil_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) :
    LocalBinding.At (afterCeil stage).state "ceil" "S" stage.endpoint.source stage.out.state.heap.length :=
  LocalBinding.allocate_head _ "ceil" "S" _ (by rfl)

theorem ceil_neg_eval (service : Call) (fuel : Nat) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} (stage : CeilStage code l c a) :
    evalExpr Header.layout service (fuel+2) (afterCeil stage).state (.field "." (.var "ceil") "neg")=
      some (NatWrapperCalls.unsigned32 (SignedNegCalls.bit stage.endpoint.negative),(afterCeil stage).state) :=
  ExpressionTemplates.field Header.layout service
    (LocalBinding.eval service fuel (ceil_binding stage) (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)) (by rfl)

theorem ceil_mag_eval (service : Call) (fuel : Nat) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} (stage : CeilStage code l c a) :
    evalExpr Header.layout service (fuel+2) (afterCeil stage).state (.field "." (.var "ceil") "mag")=
      some (.natObject stage.endpoint.slot,(afterCeil stage).state) :=
  ExpressionTemplates.field Header.layout service
    (LocalBinding.eval service fuel (ceil_binding stage) (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)) (by rfl)

theorem afterCeil_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) : Valid l (afterCeil stage) :=
  CursorLocals.allocated_valid stage.valid "S" "ceil" _

def afterSmall {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) : Cursor := next l (afterCeil stage) 4294967295

theorem ceil_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (stage : CeilStage code l c a) : stage.out.top ≤ c.top+16 := by
  rw[stage.trace,CursorFrames.top_advance,afterR_top]
  have count:=stage.count
  omega

theorem small_call (code : List Function) (installed : Generated.f_small∈code)
    (nu : Generated.f_nu∈code) (nle : Generated.f_nle∈code) (keep : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} (stage : CeilStage code l c a)
    (bound : stage.endpoint.magnitude<2^32) (room : c.top+16<PoolCalls.capacity) :
    SourceCall Header.layout code 3 "small" [.natObject stage.endpoint.slot] (afterCeil stage).state
      (PoolCalls.word stage.endpoint.magnitude) (afterSmall stage).state :=
  NatWrapperCalls.small_call code installed nu nle keep (afterCeil_valid stage)
    (by change stage.out.top<PoolCalls.capacity;have h:=ceil_top stage;omega) stage.live bound

end ScopedC.ExpRemainderCalls
