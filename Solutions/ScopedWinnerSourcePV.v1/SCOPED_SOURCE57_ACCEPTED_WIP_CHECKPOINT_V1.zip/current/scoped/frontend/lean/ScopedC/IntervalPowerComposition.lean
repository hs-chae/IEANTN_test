/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerPositiveBody

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

def positiveFinishCursor {l : PoolCalls.PoolLayout} (c : Cursor) (a : Pair) (n : Nat) (finish : IntervalPowerScan.Frame l n) : Cursor :=
  PoolContextPop.unframe c.state (PoolContextPop.unframe (parameters c a n).state finish.cursor)

theorem compose_positive_trace (code : List Function) (installed : Generated.f_rpow∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (n : Nat)
    (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (nonzero : 0<n) (bound : n<2^32)
    (high : IntervalPowerBits.Certificate (initialBitFrame ctx a n nonzero bound))
    (trace : Ready code (scanStart high.finish a c.state.heap.length (highest_a ctx a n nonzero bound high)
      (highest_live ctx a n nonzero bound high alive) positive order)) :
    SourceCall Header.layout code 9 "rpow" [a.source,PoolCalls.word n] c.state trace.finish.result.source
      (positiveFinishCursor c a n trace.finish).state ∧
    Valid l (positiveFinishCursor c a n trace.finish) ∧
    trace.finish.result.Live (positiveFinishCursor c a n trace.finish).state ∧ trace.finish.result.Positive ∧
    NumericRepresentation.interval (positiveFinishCursor c a n trace.finish).state trace.finish.result.source=some
      (LeanCert.Core.IntervalRat.pow ⟨a.lo.mathematical.value,a.hi.mathematical.value,order⟩ n) ∧
    (positiveFinishCursor c a n trace.finish).top ≤ c.top+5120 := by
  have atA:=highest_a ctx a n nonzero bound high
  have liveA:=highest_live ctx a n nonzero bound high alive
  let beforeScan:=withResult high.finish a c.state.heap.length atA liveA positive order
  let start:=scanStart high.finish a c.state.heap.length atA liveA positive order
  have highTop : high.finish.cursor.top=c.top:=high.shape.2.2.2.2
  obtain ⟨service,answers,closed⟩:=CallEvents.timeline_service trace.events trace.unique
  have firstGuard : Run Header.layout service
      (.branch zeroCondition (.returnStmt (.call (.var "point") [.call (.var "qi") [.nat 1]])) .skip)
      (parameters c a n).state (.continuing (parameters c a n).state) := by
    apply Loops.StmtRun.branch (zero_condition service c a n bound)
    simp only[UnsignedLiteralControl.truth_boolean,show n≠0 by omega,decide_false,Bool.false_eq_true,↓reduceIte]
    exact Loops.StmtRun.skip _
  have firstLoop : Run Header.layout service
      (.whileLoop IntervalPowerCounter.bitCondition IntervalPowerCounter.doubleStatement)
      (bitStart c a n).state (.continuing high.finish.cursor.state) := Loops.StmtRun.whileLoop (high.execution service)
  have declaration:=result_declaration service high.finish a c.state.heap.length atA liveA positive order
  have halve:=IntervalPowerScan.half_source service beforeScan
  have secondLoop : Run Header.layout service (.whileLoop IntervalPowerScan.scanCondition IntervalPowerScan.loopBody)
      start.cursor.state (.continuing trace.finish.cursor.state) :=
    Loops.StmtRun.whileLoop (trace.execution service answers)
  have returned : Eval Header.layout service (.var "result") trace.finish.cursor.state trace.finish.cursor.state trace.finish.result.source :=
    ⟨2,LocalBinding.eval service 1 trace.finish.rAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)⟩
  let bodyExit:=PoolContextPop.unframe (parameters c a n).state trace.finish.cursor
  let finalCursor:=PoolContextPop.unframe c.state bodyExit
  have bodyLive : trace.finish.result.Live bodyExit.state:=trace.finish.rLive
  have finalLive : trace.finish.result.Live finalCursor.state:=trace.finish.rLive
  have body : Run Header.layout service Generated.f_rpow.body (parameters c a n).state
      (.returned bodyExit.state trace.finish.result.source) := by
    apply Loops.StmtRun.sequence
      (Loops.SeqRun.next firstGuard
        (Loops.SeqRun.next (Loops.StmtRun.declare (bit_declaration service c a n))
          (Loops.SeqRun.next (by simpa only[IntervalPowerCounter.bitCondition,IntervalPowerCounter.doubleStatement] using firstLoop)
            (Loops.SeqRun.next (Loops.StmtRun.declare declaration)
              (Loops.SeqRun.next (Loops.StmtRun.evaluate halve)
                (Loops.SeqRun.next (by simpa only[IntervalPowerScan.scanCondition,IntervalPowerScan.loopBody,
                    IntervalPowerScan.oddStatement,IntervalPowerScan.scanOdd,IntervalPowerScan.multiplyExpression,
                    IntervalPowerScan.leftName,IntervalPowerScan.halfExpression,Bool.false_eq_true,↓reduceIte,
                    start,scanStart,beforeScan] using secondLoop)
                  (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned))))))))
    exact ⟨rfl,rfl⟩
  have execution : SourceCall Header.layout code 9 "rpow" [a.source,PoolCalls.word n] c.state trace.finish.result.source finalCursor.state := by
    apply installed_body (f:=Generated.f_rpow) (rank:=8) (service:=service) installed closed
      (bind_parameters c a n alive bound) body
    exact ⟨Pair.cast bodyLive "static RI" (by decide +kernel),rfl⟩
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have bodyContext : Valid l bodyExit:=PoolContextPop.valid trace.finish.context
    (by rw[parameters_length];omega) (by rw[parameters_length];omega) (by rw[parameters_length];omega)
  have finalContext : Valid l finalCursor:=PoolContextPop.valid bodyContext hp ht hh
  refine ⟨execution,finalContext,finalLive,trace.finish.rPositive,?_,?_⟩
  · exact (pair_decoded trace.finish.result finalLive trace.finish.rPositive trace.finish.rOrder).trans
      (congrArg some trace.mathematical_eq)
  · have h:=trace.top_le
    change trace.finish.cursor.top ≤ c.top+5120
    change trace.finish.cursor.top ≤ high.finish.cursor.top+5120 at h
    omega


end ScopedC.IntervalPowerCalls
