/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareLn2Store
import ScopedC.CallEventNameTimeline

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] ratio product

structure TailLibrary (code : List Function) : Prop where
  front : FrontLibrary code
  rmul : Generated.f_rmul∈code
  multiply : RationalIntervalMultiplyCalls.Library code

abbrev TailEvent (code : List Function) := CallEvents.Event Header.layout code 10
abbrev TailAnswers {code : List Function} (service : Call) (events : List (TailEvent code)) : Prop :=
  ∀e∈events,service e.name e.args e.before=some (e.value,e.after)

noncomputable def tailEvents (code : List Function) (lib : TailLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+9101<PoolCalls.capacity)
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) : List (TailEvent code) := [
  ⟨"qi",[DecimalDigits.integer 2],c.state,(two l c).source,(afterTwo l c).state,
    SourceRanks.monotone (by decide +kernel) (two_source code lib.front (l:=l) (c:=c) ctx (by omega))⟩,
  ⟨"point",[(two l c).source],(afterTwo l c).state,(pointTwo l c).source,(afterTwo l c).state,
    SourceRanks.monotone (by decide +kernel) (point_source code lib.front l c)⟩,
  ⟨"qi",[DecimalDigits.integer 1],(afterTwo l c).state,(one l c).source,(afterOne l c).state,
    SourceRanks.monotone (by decide +kernel) (one_source code lib.front (l:=l) (c:=c) ctx (by omega))⟩,
  ⟨"qi",[DecimalDigits.integer 3],(afterOne l c).state,(three l c).source,(afterThree l c).state,
    SourceRanks.monotone (by decide +kernel) (three_source code lib.front (l:=l) (c:=c) ctx (by omega))⟩,
  ⟨"qv",[(one l c).source,(three l c).source],(afterThree l c).state,(ratio l c).source,(beforeAtanh l c).state,
    SourceRanks.monotone (by decide +kernel) (ratio_source code lib.front (l:=l) (c:=c) ctx (by omega))⟩,
  ⟨"atanhPoint",[(ratio l c).source],(beforeAtanh l c).state,a.output.source,a.out.state,a.execution⟩,
  ⟨"rmul",[(pointTwo l c).source,a.output.source],a.out.state,(product a).source,(productCursor a).state,
    SourceRanks.monotone (by decide +kernel) (product_source code lib.rmul lib.multiply (l:=l) (c:=c) ctx a room)⟩]

section ConcreteTailAnswers
attribute [local irreducible] afterTwo afterOne afterThree two one three pointTwo

theorem tailEvents_answers (code : List Function) (lib : TailLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+9101<PoolCalls.capacity)
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) (service : Call)
    (answers : TailAnswers service (tailEvents code lib ctx room a)) : Answers (code:=code) (l:=l) (c:=c) (d:=d) (coeffs:=coeffs) service a :=
  by
  let events:=tailEvents code lib ctx room a
  have atIndex (i : Nat) (hi : i<events.length) :
      service events[i].name events[i].args events[i].before=some (events[i].value,events[i].after) :=
    answers _ (List.getElem_mem hi)
  refine ⟨?_,?_,?_,?_,?_,?_,?_⟩
  · exact atIndex 0 (by change 0<7;decide +kernel)
  · exact atIndex 1 (by change 1<7;decide +kernel)
  · exact atIndex 2 (by change 2<7;decide +kernel)
  · exact atIndex 3 (by change 3<7;decide +kernel)
  · exact atIndex 4 (by change 4<7;decide +kernel)
  · exact atIndex 5 (by change 5<7;decide +kernel)
  · exact atIndex 6 (by change 6<7;decide +kernel)

end ConcreteTailAnswers

theorem afterTwo_size (l : PoolCalls.PoolLayout) (c : Cursor) :
    (afterTwo l c).state.nats.values.length=c.state.nats.values.length+3 := by
  change (CursorFrames.advance l c [2,0,1]).state.nats.values.length=_
  rw[CursorEffects.size]
  rfl

theorem afterOne_size (l : PoolCalls.PoolLayout) (c : Cursor) :
    (afterOne l c).state.nats.values.length=c.state.nats.values.length+6 := by
  change (CursorFrames.advance l (afterTwo l c) [1,0,1]).state.nats.values.length=_
  rw[CursorEffects.size,afterTwo_size]
  rfl

theorem afterThree_size (l : PoolCalls.PoolLayout) (c : Cursor) :
    (afterThree l c).state.nats.values.length=c.state.nats.values.length+9 := by
  change (CursorFrames.advance l (afterOne l c) [3,0,1]).state.nats.values.length=_
  rw[CursorEffects.size,afterOne_size]
  rfl

theorem tailEvents_unique (code : List Function) (lib : TailLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+9101<PoolCalls.capacity)
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) :
    ((tailEvents code lib ctx room a).map CallEvents.nameKey).Nodup := by
  change [(c.state.nats.values.length,"qi"),((afterTwo l c).state.nats.values.length,"point"),
    ((afterTwo l c).state.nats.values.length,"qi"),((afterOne l c).state.nats.values.length,"qi"),
    ((afterThree l c).state.nats.values.length,"qv"),((beforeAtanh l c).state.nats.values.length,"atanhPoint"),
    (a.out.state.nats.values.length,"rmul")].Nodup
  rw[afterTwo_size,afterOne_size]
  simp only[List.nodup_cons,List.mem_cons,List.not_mem_nil,not_false_eq_true,List.nodup_nil,
    Prod.mk.injEq,String.reduceEq,not_or,and_false,false_and,and_true,true_and]
  omega

theorem beforeAtanh_lower {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) : c.state.nats.values.length ≤ (beforeAtanh l c).state.nats.values.length := by
  have live:=(pointTwo_live ctx room).1.1
  change NatArena.Borrow (beforeAtanh l c).state.nats c.state.nats.values.length 2 at live
  have bound:=(List.getElem?_eq_some_iff.mp live.1).choose
  omega

theorem atanh_lower {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) : c.state.nats.values.length ≤ a.out.state.nats.values.length := by
  have live:=(a.pair (pointTwo_live ctx room)).1.1
  change NatArena.Borrow a.out.state.nats c.state.nats.values.length 2 at live
  have bound:=(List.getElem?_eq_some_iff.mp live.1).choose
  omega

theorem tailEvents_lower (code : List Function) (lib : TailLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+9101<PoolCalls.capacity)
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs)
    (e : TailEvent code) (member : e∈tailEvents code lib ctx room a) :
    c.state.nats.values.length ≤ e.before.nats.values.length := by
  have two:=afterTwo_size l c
  have one:=afterOne_size l c
  have three:=afterThree_size l c
  have before:=beforeAtanh_lower ctx (by omega)
  have after:=atanh_lower ctx (by omega) a
  simp only[tailEvents,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> dsimp only <;> omega

end ScopedC.PrepareSource.Ln2
