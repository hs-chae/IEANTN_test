/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalMultiplyRefinement
import ScopedC.RationalMultiplyPreservation
import ScopedC.RationalMultiplyTrace
import ScopedC.CursorLocals
import ScopedC.LocalBinding

namespace ScopedC.RationalProductApplicability
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

/-- The record shape returned by the already proved actual qt source body. -/
def output (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Input :=
  ⟨RationalMultiplyCalls.top l c a b,
   (RationalMultiplyCalls.c10 l c a b).state.nats.values.length,RationalMultiplyCalls.den a b⟩

theorem source (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (output l c a b).source=RationalMultiplyCalls.result l c a b := rfl

theorem initialized (q : Input) : Machine.initialized 1000 q.source=true := rfl

theorem live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (output l c a b).Live (RationalMultiplyCalls.c11 l c a b).state :=
  RationalMultiplyCalls.result_live l c a b

theorem positive (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) : 0<(output l c a b).denominator :=
  RationalMultiplyCalls.den_pos a b pa pb

theorem mathematical (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) :
    (output l c a b).mathematical.value=a.mathematical.value*b.mathematical.value :=
  RationalMultiplyCalls.value l c a b pa pb

theorem preserves_input {l : PoolCalls.PoolLayout} {c : Cursor} {a b p : Input}
    (h : p.Live c.state) : p.Live (RationalMultiplyCalls.c11 l c a b).state :=
  ⟨RationalMultiplyCalls.preserves h.1,RationalMultiplyCalls.preserves h.2⟩

theorem preserves_binding {l : PoolCalls.PoolLayout} {c : Cursor} {name ty : String}
    {v : Value} {slot : Nat} (a b : Input) (h : LocalBinding.At c.state name ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    LocalBinding.At (RationalMultiplyCalls.c11 l c a b).state name ty v slot := by
  rw[RationalMultiplyTrace.c11_advance]
  exact LocalBinding.advance h _ hp ht hh

def saved (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (name : String) : Cursor :=
  CursorLocals.allocated (RationalMultiplyCalls.c11 l c a b) "Q" name (output l c a b).source

theorem saved_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+10<PoolCalls.capacity) (a b : Input) (name : String) :
    Valid l (saved l c a b name) :=
  CursorLocals.allocated_valid
    (by rw[RationalMultiplyTrace.c11_advance];apply CursorFrames.advance_valid ctx
        ;simp only[RationalMultiplyTrace.steps,List.length_cons,List.length_nil];omega) "Q" name _

theorem saved_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (name : String) :
    (saved l c a b name).top=c.top+11 := RationalMultiplyCalls.top11 l c a b

theorem saved_size (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (name : String) :
    (saved l c a b name).state.nats.values.length=c.state.nats.values.length+11 := by
  change (RationalMultiplyCalls.c11 l c a b).state.nats.values.length=_
  rw[RationalMultiplyTrace.c11_advance,CursorEffects.size]
  rfl

theorem saved_shape (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (name : String) :
    (saved l c a b name).state.heap.length=c.state.heap.length+1 ∧
    (saved l c a b name).state.env=(name,⟨c.state.heap.length,0,[]⟩)::c.state.env := by
  have h:=RationalMultiplyCalls.shape l c a b
  simp [saved,CursorLocals.allocated,allocate,h.1,h.2]

theorem saved_at (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (name : String) :
    LocalBinding.At (saved l c a b name).state name "Q" (output l c a b).source c.state.heap.length := by
  have h:=LocalBinding.allocate_head (RationalMultiplyCalls.c11 l c a b).state name "Q"
    (output l c a b).source (initialized _)
  simpa only[saved,CursorLocals.allocated,(RationalMultiplyCalls.shape l c a b).1] using h

theorem saved_preserves_input {l : PoolCalls.PoolLayout} {c : Cursor} {a b p : Input} {name : String}
    (h : p.Live c.state) : p.Live (saved l c a b name).state :=
  preserves_input h

theorem saved_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (name : String) :
    (output l c a b).Live (saved l c a b name).state := live l c a b

end ScopedC.RationalProductApplicability
