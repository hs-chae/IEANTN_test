/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAbsApplicability
import ScopedC.SourceCeilQNormalizedTrace
import ScopedC.CursorLocals
import ScopedC.LocalStorageSeparation
import ScopedNumerical.BoxSound

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def parameters (c : Cursor) (q : Input) : Cursor :=
  CursorSingleFrames.framed c "Q" "q" q.source
def absolute (q : Input) : Input := RationalAbsApplicability.output q
def afterAbs (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  next l (parameters c q) 0

structure CeilLibrary (code : List Function) : Prop where
  absolute : RationalAbsApplicability.Library code
  ceil : Generated.f_ceilQ ∈ code
  floor : Generated.f_floorQ ∈ code
  qn : Generated.f_qn ∈ code
  sn : Generated.f_sn ∈ code
  floorLibrary : FloorQNegativeCalls.Library code

theorem parameters_valid {l : PoolCalls.PoolLayout} {c : Cursor}
    (valid : Valid l c) (q : Input) : Valid l (parameters c q) :=
  OneFrames.context_frame valid "Q" "q" q.source

theorem parameters_binding (c : Cursor) (q : Input) :
    LocalBinding.At (parameters c q).state "q" "Q" q.source c.state.heap.length :=
  LocalBinding.allocate_head {c.state with env:=[]} "q" "Q" q.source (by rfl)

theorem absolute_source (code : List Function) (lib : CeilLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (valid : Valid l c) (q : Input)
    (live : q.Live c.state) (room : c.top < PoolCalls.capacity) :
    SourceCall Header.layout code 5 "qabs" [q.source] (parameters c q).state
      (absolute q).source (afterAbs l c q).state :=
  RationalAbsApplicability.source code lib.absolute (parameters_valid valid q) q live room

structure CeilStage (code : List Function) (l : PoolCalls.PoolLayout) (c : Cursor)
    (q : Input) where
  out : Cursor
  endpoint : Endpoint
  execution : SourceCall Header.layout code 7 "ceilQ" [(absolute q).source]
    (afterAbs l c q).state endpoint.source out.state
  valid : Valid l out
  live : endpoint.Live out.state
  value : endpoint.mathematical.value = ScopedNumerical.ProofBox.ceilDiv
    (absolute q).mathematical.num.value (absolute q).denominator
  values : List Nat
  trace : out = CursorFrames.advance l (afterAbs l c q) values
  count : values.length ≤ 8
  normalized : endpoint.magnitude=0 → endpoint.negative=false

theorem ceil_stage (code : List Function) (lib : CeilLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (valid : Valid l c) (q : Input)
    (live : q.Live c.state) (positive : 0 < q.denominator)
    (room : c.top+8 < PoolCalls.capacity) : Nonempty (CeilStage code l c q) := by
  have absLive : (absolute q).Live (afterAbs l c q).state :=
    RationalAbsApplicability.live (l:=l) (c:=parameters c q) live
  have absValid : Valid l (afterAbs l c q) :=
    next_valid 0 (parameters_valid valid q) (by change c.top < PoolCalls.capacity; omega)
  obtain ⟨out,e,source,finalValid,finalLive,value,heap,env,top,preserves,trace,normalized⟩ :=
    SourceCeilQNormalizedTrace.ceilQ_closed_trace code lib.ceil lib.floor lib.qn lib.sn
      lib.floorLibrary (absolute q) absLive positive absValid
      (by change c.top+1+7 < PoolCalls.capacity; omega)
  obtain ⟨values,count,binding⟩ := trace
  exact ⟨⟨out,e,source,finalValid,finalLive,value,values,binding,count,normalized⟩⟩

theorem ceil_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    stage.endpoint.mathematical.value = Int.ceil |q.mathematical.value| := by
  rw [stage.value,ScopedNumerical.ProofBox.ceilDiv_eq_ceil]
  · congr 1
    exact RationalAbsApplicability.value q
  · exact_mod_cast ne_of_gt positive

theorem ceil_sign {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    stage.endpoint.negative = false := by
  have nonnegative : 0 ≤ stage.endpoint.mathematical.value := by
    rw [ceil_value stage positive]
    exact Int.ceil_nonneg (abs_nonneg _)
  cases negative : stage.endpoint.negative with
  | false => rfl
  | true =>
    have zero : stage.endpoint.magnitude=0 := by
      change 0 ≤ (if stage.endpoint.negative then -(stage.endpoint.magnitude:Int)
        else stage.endpoint.magnitude) at nonnegative
      simp only [negative,↓reduceIte] at nonnegative
      omega
    simpa only [negative] using stage.normalized zero

theorem ceil_magnitude {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    stage.endpoint.magnitude = Nat.ceil |q.mathematical.value| := by
  have value := ceil_value stage positive
  have magnitude : (stage.endpoint.magnitude:Int) = stage.endpoint.mathematical.value := by
    simp only [Endpoint.mathematical,ScopedNumerical.Signed.value,ceil_sign stage positive,
      Bool.false_eq_true,↓reduceIte]
  have same := Int.natCast_ceil_eq_ceil (abs_nonneg q.mathematical.value)
  omega

end ScopedC.ExpPointCalls
