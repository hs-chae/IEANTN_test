/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointInputFrames
import ScopedC.TaylorFramedBody
import ScopedC.ExpRemainderFramedAccess
import ScopedC.IntervalPowerFramedBody

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  front : ReductionLibrary code
  taylor : Generated.f_taylor ∈ code
  polynomial : TaylorCalls.EntryLibrary code
  expRemainder : Generated.f_expRemainder ∈ code
  remainder : ExpRemainderCalls.Library code
  rpow : Generated.f_rpow ∈ code
  powers : IntervalPowerCalls.Library code

abbrev TaylorStage {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator)
    (base : Address) (coeffs : List Input) (d : Nat) :=
  TaylorCalls.FramedResult code l (afterInput stage positive) base coeffs (inputPair stage positive)
    true (input_ordered stage positive) d

/-- Original expPoint evaluates the Taylor call before its remainder call. The
physical coefficients/depth come from the caller, ultimately actual prepare. -/
theorem taylor_stage (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (valid : Valid l c) {q : Input}
    (stage : CeilStage code l c q) (positive : 0 < q.denominator)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (d object : Nat) (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object ≠ l.pool ∧ object ≠ l.top ∧ object ≠ l.high)
    (dBound : d ≤ 64) (length : coeffs.length=d+1) (room : c.top+16000 < PoolCalls.capacity) :
    Nonempty (TaylorStage stage positive base coeffs d) := by
  have top := input_top stage positive
  exact TaylorCalls.taylor_framed code lib.taylor lib.polynomial
    (input_valid stage positive (by omega)) (input_table stage positive valid table)
    (inputPair stage positive) (input_live stage positive) (input_positive stage positive)
    (input_ordered stage positive) d object (input_depth stage positive depth apart)
    apart dBound length (by omega) true

theorem taylor_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    (t : TaylorStage stage positive base coeffs d) : t.out.top ≤ c.top+32+108*(d+1) := by
  have top := input_top stage positive
  have actual := t.top
  omega

theorem taylor_input_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    (t : TaylorStage stage positive base coeffs d) : (inputPair stage positive).Live t.out.state := by
  have live := input_live stage positive
  exact ⟨⟨t.preserves _ _ live.1.1,t.preserves _ _ live.1.2⟩,
    ⟨t.preserves _ _ live.2.1,t.preserves _ _ live.2.2⟩⟩

theorem taylor_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    (t : TaylorStage stage positive base coeffs d) {object : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object ≠ l.pool ∧ object ≠ l.top ∧ object ≠ l.high) :
    SourceUnsignedGlobal.At t.out.state "depth" object d := by
  have before := input_depth stage positive depth apart
  exact SourceUnsignedGlobal.memory before t.globals
    (t.other object (List.getElem?_eq_some_iff.mp before.storage).choose
      apart.1 apart.2.1 apart.2.2)

theorem taylor_ordered {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {stage : CeilStage code l c q} {positive : 0 < q.denominator}
    {base : Address} {coeffs : List Input} {d : Nat}
    (t : TaylorStage stage positive base coeffs d) :
    t.output.lo.mathematical.value ≤ t.output.hi.mathematical.value := by
  have values := Pair.values_of_decoded t.live t.positive t.decoded
  rw [values.1,values.2]
  exact (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
    ⟨(inputPair stage positive).lo.mathematical.value,
      (inputPair stage positive).hi.mathematical.value,input_ordered stage positive⟩).le

end ScopedC.ExpPointCalls
