/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSelectionTree

namespace ScopedC.RationalSelectionTree
open ScopedC.RationalPairFrames (Input)
open ScopedC.NumericRationalSelectRefinement
open ScopedC.RationalIntervalHullCalls (selected_positive)
open ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

def combine (flip : Bool) (x y : Rat) : Rat := if flip then max x y else min x y

theorem chosen_value (flip : Bool) (l : ScopedC.PoolCalls.PoolLayout) (c : Cursor)
    (a b : Input) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    (chosen flip l c a b).mathematical.value=combine flip a.mathematical.value b.mathematical.value := by
  cases flip with
  | false => exact minimum_value l c a b pa pb
  | true => exact maximum_value l c a b pa pb

theorem output_value (flip : Bool) (l : ScopedC.PoolCalls.PoolLayout) (c : Cursor)
    (v : Four) (h : v.Positive) :
    (output flip l c v).mathematical.value=
      combine flip (combine flip v.p.mathematical.value v.q.mathematical.value)
        (combine flip v.r.mathematical.value v.s.mathematical.value) := by
  unfold output
  rw[chosen_value flip l (t2 l c v) (left flip l c v) (right flip l c v)
    (selected_positive flip l c v.p v.q h.1 h.2.1)
    (selected_positive flip l (t1 l c v) v.r v.s h.2.2.1 h.2.2.2)]
  rw[show (left flip l c v).mathematical.value=combine flip v.p.mathematical.value v.q.mathematical.value
      from chosen_value flip l c v.p v.q h.1 h.2.1,
     show (right flip l c v).mathematical.value=combine flip v.r.mathematical.value v.s.mathematical.value
      from chosen_value flip l (t1 l c v) v.r v.s h.2.2.1 h.2.2.2]

end ScopedC.RationalSelectionTree
