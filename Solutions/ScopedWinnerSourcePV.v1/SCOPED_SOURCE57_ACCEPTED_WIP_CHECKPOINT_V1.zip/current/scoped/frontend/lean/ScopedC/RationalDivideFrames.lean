/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalDivideLower
namespace ScopedC.RationalDivideCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem tested_framed {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) :
    tested l c a b=base (next l c 0) a b := CursorFrames.next_framed ctx "Q" "a" a.source "Q" "b" b.source 0

theorem made_framed {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) :
    made l c a b=base (next l (next l c 0) 0) a b := by
  unfold made
  rw[tested_framed ctx a b]
  exact CursorFrames.next_framed (next_valid 0 ctx (by omega)) "Q" "a" a.source "Q" "b" b.source 0

def inverseFrame (s : State) (a b : Input) : State := allocate (frame s a b) "Q" "inverse" (some (inverse b).source)

theorem inverse_framed {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) :
    (inverseCursor l c a b).state=inverseFrame (next l (next l c 0) 0).state a b := by
  unfold inverseCursor
  rw[made_framed ctx room a b]
  rfl

theorem eval_a_inverse (service : Call) (fuel : Nat) (s : State) (a b : Input) :
    evalExpr Header.layout service (fuel+1) (inverseFrame s a b) (.var "a")=some (a.source,inverseFrame s a b) := by
  simp [evalExpr,getVar,inverseFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_inverse (service : Call) (fuel : Nat) (s : State) (a b : Input) :
    evalExpr Header.layout service (fuel+1) (inverseFrame s a b) (.var "inverse")=some ((inverse b).source,inverseFrame s a b) := by
  simp [evalExpr,getVar,inverseFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem zero_cast (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    castValue Header.layout (zeroEnd l c a b).state 100 "static Q" (zeroInput l c a b).source=some (zeroInput l c a b).source :=
  Input.cast (q:=zeroInput l c a b) "static Q" (by decide +kernel) (live_of_nats (s:=(zeroAfter l c a b).state) rfl (zero_live l c a b))

theorem nonzero_cast (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    castValue Header.layout (bodyEnd l c a b).state 100 "static Q" (nonzeroResult l c a b)=some (nonzeroResult l c a b) :=
  Input.cast (q:=nonzeroInput l c a b) "static Q" (by decide +kernel) (nonzero_live l c a b)

end ScopedC.RationalDivideCalls
