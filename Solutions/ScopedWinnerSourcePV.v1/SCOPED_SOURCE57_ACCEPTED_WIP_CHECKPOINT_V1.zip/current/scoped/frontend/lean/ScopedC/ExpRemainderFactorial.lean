/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderCount
import ScopedC.ExpFactorialLoop
import ScopedC.ExpFactorialEntry

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

structure FactorialStage (code : List Function) (l : PoolCalls.PoolLayout) (c : Cursor)
    (a : Pair) (object d : Nat) (ceil : CeilStage code l c a) where
  start : ExpFactorial.Frame l object d
  cursor : start.cursor=ExpFactorial.initial l (afterC ceil)
  k : start.k=1
  one : start.fact.mathematical.value=1
  loop : ExpFactorial.LoopCertificate code start

theorem factorial_stage (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} (ceil : CeilStage code l c a)
    (object d : Nat) (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (dBound : d≤64)
    (room : c.top+2000<PoolCalls.capacity) : Nonempty (FactorialStage code l c a object d ceil) := by
  obtain ⟨f,fc,fk,fv⟩:=ExpFactorial.initial_frame (afterC_valid ceil (by omega))
    (by have h:=afterC_top ceil;omega) object d (afterC_depth ceil depth apart)
    (afterC_unshadowed ceil) apart dBound
  have top : f.cursor.top ≤ c.top+20 := by
    rw[fc]
    change (afterC ceil).top+3 ≤ c.top+20
    have h:=afterC_top ceil
    omega
  obtain ⟨trace⟩:=ExpFactorial.loop_certificate code lib (d+1) f
    (by rw[fk];omega) (by rw[fv,fk];norm_num) (by omega)
  exact ⟨⟨f,fc,fk,fv,trace⟩⟩

theorem factorial_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (stage : FactorialStage code l c a object d ceil) :
    stage.loop.finish.fact.mathematical.value=((d+1).factorial:Rat) := stage.loop.mathematical

theorem factorial_nonzero {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (stage : FactorialStage code l c a object d ceil) :
    stage.loop.finish.fact.numerator.magnitude≠0 := by
  intro zero
  have value:=factorial_value stage
  have zeroValue : stage.loop.finish.fact.mathematical.value=0 := by
    simp [RationalPairFrames.Input.mathematical,DyadicRepresentation.Endpoint.mathematical,
      ScopedNumerical.Rational.value,ScopedNumerical.Signed.value,zero]
  rw[zeroValue] at value
  have positive : 0<((d+1).factorial:Rat) := by exact_mod_cast Nat.factorial_pos (d+1)
  linarith

end ScopedC.ExpRemainderCalls
