/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhPowerExpression
import ScopedC.AtanhErrorEffects

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

theorem r_power_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) (d : Nat) (stage : PowerStage code l c q d)
    (room : c.top+9<PoolCalls.capacity) :
    LocalBinding.At stage.out.state "r" "Q" (absInput q).source (c.state.heap.length+1) := by
  have before:=r_guard_binding ctx q room
  have safe:=LocalStorageSeparation.pool (guard_context ctx q room) before
    (by decide +kernel : ("Q":String)≠"unsigned")
  exact LocalBinding.memory before stage.env
    (stage.other _ (List.getElem?_eq_some_iff.mp before.memory).choose
      safe.1 safe.2.1 safe.2.2)

theorem r_den_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) (d : Nat) (stage : PowerStage code l c q d)
    (room : c.top+9<PoolCalls.capacity) :
    LocalBinding.At (denStart stage).state "r" "Q" (absInput q).source
      (c.state.heap.length+1) := by
  have before:=r_power_binding ctx q d stage room
  have safe:=LocalStorageSeparation.pool stage.valid before
    (by decide +kernel : ("Q":String)≠"unsigned")
  exact LocalBinding.advance before [1,0,1] safe.1 safe.2.1 safe.2.2

def denExpression : Expr := .call (.var "qs") [.call (.var "qi") [.nat 1],.var "r"]
def errorExpression : Expr := .call (.var "qv") [powerExpression,denExpression]

theorem den_eval_at (service : Call) (fuel : Nat) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input) (d : Nat)
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (room : c.top+9<PoolCalls.capacity)
    (one : service "qi" [DecimalDigits.integer 1] stage.out.state=
      some ((denOne stage).source,(denStart stage).state))
    (subtract : service "qs" [(denOne stage).source,(absInput q).source]
      (denStart stage).state=some ((denominator stage positive).source,(denCursor stage).state)) :
    evalExpr Header.layout service (fuel+3) stage.out.state denExpression=
      some ((denominator stage positive).source,(denCursor stage).state) := by
  have left:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service (fuel+1) stage.out.state (.nat 1)=
      some (DecimalDigits.integer 1,stage.out.state) from rfl) one
  have right:=LocalBinding.eval service (fuel+1) (r_den_binding ctx q d stage room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact ExpressionTemplates.call_two Header.layout service left right subtract

theorem error_eval_at (service : Call) (fuel : Nat) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input) (d object : Nat)
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (dBound : d≤64)
    (room : c.top+9<PoolCalls.capacity)
    (power : service "qpow" [(absInput q).source,PoolCalls.word (d+1)]
      (afterGuard l c q).state=some (stage.output.source,stage.out.state))
    (one : service "qi" [DecimalDigits.integer 1] stage.out.state=
      some ((denOne stage).source,(denStart stage).state))
    (subtract : service "qs" [(denOne stage).source,(absInput q).source]
      (denStart stage).state=some ((denominator stage positive).source,(denCursor stage).state))
    (divide : service "qv" [stage.output.source,(denominator stage positive).source]
      (denCursor stage).state=some ((errorInput stage positive).source,(errorCursor stage positive).state)) :
    evalExpr Header.layout service (fuel+5) (afterGuard l c q).state errorExpression=
      some ((errorInput stage positive).source,(errorCursor stage positive).state) := by
  have left:=power_eval_at service fuel ctx q d object depth apart dBound room power
  have right:=den_eval_at service (fuel+1) ctx q d stage positive room one subtract
  exact ExpressionTemplates.call_two Header.layout service left right divide

noncomputable def storedError {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) : Cursor :=
  CursorLocals.allocated (errorCursor stage positive) "Q" "error" (errorInput stage positive).source

theorem error_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input) (d object : Nat)
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (dBound : d≤64)
    (room : c.top+9<PoolCalls.capacity)
    (power : service "qpow" [(absInput q).source,PoolCalls.word (d+1)]
      (afterGuard l c q).state=some (stage.output.source,stage.out.state))
    (one : service "qi" [DecimalDigits.integer 1] stage.out.state=
      some ((denOne stage).source,(denStart stage).state))
    (subtract : service "qs" [(denOne stage).source,(absInput q).source]
      (denStart stage).state=some ((denominator stage positive).source,(denCursor stage).state))
    (divide : service "qv" [stage.output.source,(denominator stage positive).source]
      (denCursor stage).state=some ((errorInput stage positive).source,(errorCursor stage positive).state)) :
    Declare Header.layout service [{type:="Q",name:="error",value:=some errorExpression,arrayExtent:=none}]
      (afterGuard l c q).state (storedError stage positive).state := by
  have expression:=error_eval_at service 995 ctx q d object stage positive depth apart dBound room
    power one subtract divide
  have cast:=Input.cast (q:=errorInput stage positive) "Q" (by decide +kernel) (error_live stage positive)
  simp only[Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem error_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) :
    LocalBinding.At (storedError stage positive).state "error" "Q" (errorInput stage positive).source
      (errorCursor stage positive).state.heap.length :=
  LocalBinding.allocate_head _ "error" "Q" _ (by rfl)

end ScopedC.AtanhCalls
