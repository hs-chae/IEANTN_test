/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderExpressionBindings
import ScopedC.ExpRemainderOutput

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax

def threePowerExpression : Expr := .call (.var "qpow")
  [.call (.var "qi") [.nat 3],.binary "+" (.var "c") (.nat 1)]
def radiusPowerExpression : Expr := .call (.var "qpow")
  [.var "r",.binary "+" (.var "depth") (.nat 1)]
def errorExpression : Expr := .call (.var "qv")
  [.call (.var "qt") [threePowerExpression,radiusPowerExpression],.var "fact"]

theorem three_power_eval (service : Call) (fuel : Nat) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil) (p : ThreePower f)
    (countBound : ceil.endpoint.magnitude<4294967295) (room : c.top+3000<PoolCalls.capacity)
    (qi : service "qi" [DecimalDigits.integer 3] (BeforeError f).state=
      some ((three f).source,(afterThree f).state))
    (power : service "qpow" [(three f).source,PoolCalls.word (ceil.endpoint.magnitude+1)]
      (afterThree f).state=some (p.output.source,p.out.state)) :
    evalExpr Header.layout service (fuel+4) (BeforeError f).state threePowerExpression=
      some (p.output.source,p.out.state) := by
  have literal : evalExpr Header.layout service (fuel+2) (BeforeError f).state (.nat 3)=
      some (DecimalDigits.integer 3,(BeforeError f).state) := rfl
  have qiEval:=ExpressionTemplates.call_one Header.layout service literal qi
  have countEval:=LocalBinding.eval service (fuel+1) (count_three_binding f room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have exponent:=ExpressionTemplates.binary Header.layout service (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) countEval
    (show evalExpr Header.layout service (fuel+2) (afterThree f).state (.nat 1)=
      some (DecimalDigits.integer 1,(afterThree f).state) from rfl)
    (PoolCalls.binary_add_one (afterThree f).state ceil.endpoint.magnitude (by omega))
  exact ExpressionTemplates.call_two Header.layout service qiEval exponent power

theorem radius_power_eval (service : Call) (fuel : Nat) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (p : ThreePower f) (r : RadiusPower p) (room : c.top+3000<PoolCalls.capacity)
    (power : service "qpow" [(radius l c a).source,PoolCalls.word (d+1)]
      p.out.state=some (r.output.source,r.out.state)) :
    evalExpr Header.layout service (fuel+4) p.out.state radiusPowerExpression=
      some (r.output.source,r.out.state) := by
  have current:=LocalBinding.eval service (fuel+2) (radius_first_binding f p ctx room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have depth:=SourceUnsignedGlobal.eval service (fuel+1) (first_power_depth p)
    (first_power_depth_unshadowed p) (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have dBound:=f.start.depthBound
  have exponent:=ExpressionTemplates.binary Header.layout service (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) depth
    (show evalExpr Header.layout service (fuel+2) p.out.state (.nat 1)=
      some (DecimalDigits.integer 1,p.out.state) from rfl)
    (PoolCalls.binary_add_one p.out.state d (by omega))
  exact ExpressionTemplates.call_two Header.layout service current exponent power

theorem error_eval (service : Call) (fuel : Nat) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (p : ThreePower f) (r : RadiusPower p) (countBound : ceil.endpoint.magnitude<4294967295)
    (room : c.top+3000<PoolCalls.capacity)
    (qi : service "qi" [DecimalDigits.integer 3] (BeforeError f).state=
      some ((three f).source,(afterThree f).state))
    (first : service "qpow" [(three f).source,PoolCalls.word (ceil.endpoint.magnitude+1)]
      (afterThree f).state=some (p.output.source,p.out.state))
    (second : service "qpow" [(radius l c a).source,PoolCalls.word (d+1)]
      p.out.state=some (r.output.source,r.out.state))
    (multiply : service "qt" [p.output.source,r.output.source] r.out.state=
      some ((numerator r).source,(numeratorCursor r).state))
    (divide : service "qv" [(numerator r).source,f.loop.finish.fact.source] (numeratorCursor r).state=
      some ((errorInput r).source,(errorCursor r).state)) :
    evalExpr Header.layout service (fuel+6) (BeforeError f).state errorExpression=
      some ((errorInput r).source,(errorCursor r).state) := by
  have left:=three_power_eval service fuel f p countBound room qi first
  have right:=radius_power_eval service fuel ctx f p r room second
  have multiplied:=ExpressionTemplates.call_two Header.layout service left right multiply
  have fact:=LocalBinding.eval service (fuel+4) (fact_numerator_binding r room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact ExpressionTemplates.call_two Header.layout service multiplied fact divide

theorem error_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (p : ThreePower f) (r : RadiusPower p) (countBound : ceil.endpoint.magnitude<4294967295)
    (room : c.top+3000<PoolCalls.capacity)
    (qi : service "qi" [DecimalDigits.integer 3] (BeforeError f).state=
      some ((three f).source,(afterThree f).state))
    (first : service "qpow" [(three f).source,PoolCalls.word (ceil.endpoint.magnitude+1)]
      (afterThree f).state=some (p.output.source,p.out.state))
    (second : service "qpow" [(radius l c a).source,PoolCalls.word (d+1)]
      p.out.state=some (r.output.source,r.out.state))
    (multiply : service "qt" [p.output.source,r.output.source] r.out.state=
      some ((numerator r).source,(numeratorCursor r).state))
    (divide : service "qv" [(numerator r).source,f.loop.finish.fact.source] (numeratorCursor r).state=
      some ((errorInput r).source,(errorCursor r).state)) :
    Declare Header.layout service [{type:="Q",name:="error",value:=some errorExpression,arrayExtent:=none}]
      (BeforeError f).state (storedError r).state := by
  have expression:=error_eval service 994 ctx f p r countBound room qi first second multiply divide
  have cast : castValue Header.layout (errorCursor r).state 100 "Q" (errorInput r).source=
      some (errorInput r).source:=Input.cast "Q" (by decide +kernel) (error_live r)
  simp only[Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

end ScopedC.ExpRemainderCalls
