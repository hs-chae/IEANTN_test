/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalDivideFrames

namespace ScopedC.RationalDivideCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def bMagExpr : Expr := .field "." (.field "." (.var "b") "num") "mag"
def bNegExpr : Expr := .field "." (.field "." (.var "b") "num") "neg"
def bDenExpr : Expr := .field "." (.var "b") "den"
def testExpr : Expr := .call (.var "nz") [bMagExpr]
def zeroExpr : Expr := .call (.var "qi") [.nat 0]
def inverseInitializer : Expr := .record [.call (.var "smake") [bDenExpr,bNegExpr],bMagExpr]
def productExpr : Expr := .call (.var "qt") [.var "a",.var "inverse"]

theorem truth_u32 (b : Bool) : truth (PrimitiveCalls.u32 b)=b := by cases b <;> rfl

theorem eval_b_mag (service : Call) (fuel : Nat) (c : Cursor) (a b : Input) :
    evalExpr Header.layout service (fuel+3) (base c a b).state bMagExpr=
      some (.natObject b.numerator.slot,(base c a b).state) :=
  ExpressionTemplates.field Header.layout service (RationalPairFrames.eval_b_num service fuel c.state a b) (by rfl)

theorem qv_zero_closed (code : List Function) (installed : Generated.f_qv∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (hz : b.numerator.magnitude=0) :
    SourceCall Header.layout code 7 "qv" [a.source,b.source] c.state (zeroInput l c a b).source (zeroAfter l c a b).state := by
  let p0 := (base c a b).state
  let p1 := (tested l c a b).state
  let final := (zeroEnd l c a b).state
  let out := (zeroInput l c a b).source
  have pn := test_call code lib ctx room a b hb
  have pq := zero_call code lib ctx room a b
  let en : CallEvents.Event Header.layout code 6 :=
    ⟨"nz",[.natObject b.numerator.slot],p0,PrimitiveCalls.u32 (b.numerator.magnitude==0),p1,
      raise_once (raise_once (raise_once pn))⟩
  let eqi : CallEvents.Event Header.layout code 6 := ⟨"qi",[SignedCompareCalls.integer 0],p1,out,final,pq⟩
  let service := CallEvents.append (CallEvents.one en) (CallEvents.one eqi)
  have hn : service "nz" [.natObject b.numerator.slot] p0=some (PrimitiveCalls.u32 (b.numerator.magnitude==0),p1) :=
    CallEvents.append_left (CallEvents.one_self en)
  have hq : service "qi" [SignedCompareCalls.integer 0] p1=some (out,final) :=
    CallEvents.append_right (CallEvents.one_other en (by change ("qi":String)≠"nz";decide +kernel) _ _) (CallEvents.one_self eqi)
  have test : Eval Header.layout service testExpr p0 p1 (PrimitiveCalls.u32 (b.numerator.magnitude==0)) :=
    ⟨5,ExpressionTemplates.call_one Header.layout service (eval_b_mag service 1 c a b) hn⟩
  have ret : Eval Header.layout service zeroExpr p1 final out :=
    ⟨2,ExpressionTemplates.call_one Header.layout service (by rfl) hq⟩
  have branch : Run Header.layout service (.branch testExpr (.returnStmt zeroExpr) .skip) p0 (.returned final out) := by
    apply Loops.StmtRun.branch test
    simp only[truth_u32,hz,beq_self_eq_true,↓reduceIte]
    exact Loops.StmtRun.returnValue ret
  have sh : final.heap.length=p0.heap.length ∧ final.env=p0.env :=
    CursorEffects.shape l (base c a b) [0,0,0,1]
  have body : Run Header.layout service Generated.f_qv.body p0 (.returned final out) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.returned branch)
    exact ⟨rfl,(PoolCalls.pop_same sh.1 sh.2).symm⟩
  have closed : ∀ name args before value after,service name args before=some (value,after) →
      SourceCall Header.layout code 6 name args before value after := by
    intro name args before value after h
    exact CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed en h) (fun _ _ _ _ _ h=>CallEvents.one_closed eqi h) h
  apply installed_body (f:=Generated.f_qv) (rank:=6) (service:=service) installed closed (RationalPairFrames.bind a b ha hb) body
  exact ⟨zero_cast l c a b,rfl⟩

theorem qv_nonzero_closed (code : List Function) (installed : Generated.f_qv∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator)
    (hz : b.numerator.magnitude≠0) :
    SourceCall Header.layout code 7 "qv" [a.source,b.source] c.state (nonzeroResult l c a b) (nonzeroAfter l c a b).state := by
  let p0 := (base c a b).state
  let p1 := (tested l c a b).state
  let p2 := (made l c a b).state
  let invState := (inverseCursor l c a b).state
  let product := (productEnd l c a b).state
  let final := (bodyEnd l c a b).state
  let out := nonzeroResult l c a b
  have pn := test_call code lib ctx room a b hb
  have pm := inverse_call code lib ctx room a b hb pb
  have pt := product_call code lib ctx room a b ha hb pa hz
  let en : CallEvents.Event Header.layout code 6 :=
    ⟨"nz",[.natObject b.numerator.slot],p0,PrimitiveCalls.u32 (b.numerator.magnitude==0),p1,
      raise_once (raise_once (raise_once pn))⟩
  let em : CallEvents.Event Header.layout code 6 :=
    ⟨"smake",[.natObject b.denSlot,unsigned32 (SignedNegCalls.bit b.numerator.negative)],p1,(inverse b).numerator.source,p2,
      raise_once (raise_once pm)⟩
  let et : CallEvents.Event Header.layout code 6 := ⟨"qt",[a.source,(inverse b).source],invState,out,product,pt⟩
  let service := CallEvents.append (CallEvents.one en) (CallEvents.append (CallEvents.one em) (CallEvents.one et))
  have hn : service "nz" [.natObject b.numerator.slot] p0=some (PrimitiveCalls.u32 (b.numerator.magnitude==0),p1) :=
    CallEvents.append_left (CallEvents.one_self en)
  have hm : service "smake" [.natObject b.denSlot,unsigned32 (SignedNegCalls.bit b.numerator.negative)] p1=some ((inverse b).numerator.source,p2) :=
    CallEvents.append_right (CallEvents.one_other en (by change ("smake":String)≠"nz";decide +kernel) _ _)
      (CallEvents.append_left (CallEvents.one_self em))
  have ht : service "qt" [a.source,(inverse b).source] invState=some (out,product) :=
    CallEvents.append_right (CallEvents.one_other en (by change ("qt":String)≠"nz";decide +kernel) _ _)
      (CallEvents.append_right (CallEvents.one_other em (by change ("qt":String)≠"smake";decide +kernel) _ _) (CallEvents.one_self et))
  have test : Eval Header.layout service testExpr p0 p1 (PrimitiveCalls.u32 (b.numerator.magnitude==0)) :=
    ⟨5,ExpressionTemplates.call_one Header.layout service (eval_b_mag service 1 c a b) hn⟩
  have branch : Run Header.layout service (.branch testExpr (.returnStmt zeroExpr) .skip) p0 (.continuing p1) := by
    apply Loops.StmtRun.branch test
    simp only[truth_u32,beq_iff_eq,hz,Bool.false_eq_true,↓reduceIte]
    exact Loops.StmtRun.skip p1
  have readDen : evalExpr Header.layout service 998 p1 bDenExpr=some (.natObject b.denSlot,p1) := by
    change evalExpr Header.layout service 998 (tested l c a b).state bDenExpr=some (.natObject b.denSlot,(tested l c a b).state)
    rw[tested_framed ctx a b]
    exact RationalPairFrames.eval_b_den service 996 (next l c 0).state a b
  have readNeg : evalExpr Header.layout service 998 p1 bNegExpr=some (unsigned32 (SignedNegCalls.bit b.numerator.negative),p1) := by
    change evalExpr Header.layout service 998 (tested l c a b).state bNegExpr=some (_, (tested l c a b).state)
    rw[tested_framed ctx a b]
    exact ExpressionTemplates.field Header.layout service (RationalPairFrames.eval_b_num service 995 (next l c 0).state a b) (by rfl)
  have make : evalExpr Header.layout service 999 p1 (.call (.var "smake") [bDenExpr,bNegExpr])=some ((inverse b).numerator.source,p2) :=
    ExpressionTemplates.call_two Header.layout service readDen readNeg hm
  have readMag : evalExpr Header.layout service 999 p2 bMagExpr=some (.natObject b.numerator.slot,p2) := by
    change evalExpr Header.layout service 999 (made l c a b).state bMagExpr=some (.natObject b.numerator.slot,(made l c a b).state)
    rw[made_framed ctx room a b]
    exact eval_b_mag service 996 (next l (next l c 0) 0) a b
  have init : evalExpr Header.layout service 1000 p1 inverseInitializer=
      some (.aggregate [(inverse b).numerator.source,.natObject b.numerator.slot],p2) :=
    ExpressionTemplates.record_two Header.layout service make readMag
  have bh1 := Input.live_after (l:=l) (c:=base c a b) (n:=0) hb
  have bh2 := Input.live_after (l:=l) (c:=tested l c a b) (n:=0) bh1
  have castInv : castValue Header.layout p2 100 "Q" (.aggregate [(inverse b).numerator.source,.natObject b.numerator.slot])=some (inverse b).source :=
    RecordCasts.rational_aggregate p2 97 bh2.2 bh2.1 (SignedNegCalls.bit_bound _)
  have decl : Declare Header.layout service [{type:="Q",name:="inverse",value:=some inverseInitializer,arrayExtent:=none}] p1 invState := by
    simp only[Declare,declarations,List.foldlM,init,Bind.bind,Option.bind,castInv]
    rfl
  have ra : evalExpr Header.layout service 2 invState (.var "a")=some (a.source,invState) := by
    change evalExpr Header.layout service 2 (inverseCursor l c a b).state (.var "a")=some (a.source,(inverseCursor l c a b).state)
    rw[inverse_framed ctx room a b]
    exact eval_a_inverse service 1 (next l (next l c 0) 0).state a b
  have ri : evalExpr Header.layout service 2 invState (.var "inverse")=some ((inverse b).source,invState) := by
    change evalExpr Header.layout service 2 (inverseCursor l c a b).state (.var "inverse")=some ((inverse b).source,(inverseCursor l c a b).state)
    rw[inverse_framed ctx room a b]
    exact eval_inverse service 1 (next l (next l c 0) 0).state a b
  have expr : Eval Header.layout service productExpr invState product out :=
    ⟨3,ExpressionTemplates.call_two Header.layout service ra ri ht⟩
  have body : Run Header.layout service Generated.f_qv.body p0 (.returned final out) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next branch (Loops.SeqRun.next (Loops.StmtRun.declare decl)
      (Loops.SeqRun.returned (Loops.StmtRun.returnValue expr))))
    exact ⟨rfl,rfl⟩
  have closed : ∀ name args before value after,service name args before=some (value,after) →
      SourceCall Header.layout code 6 name args before value after := by
    intro name args before value after h
    exact CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed en h)
      (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed em h) (fun _ _ _ _ _ h=>CallEvents.one_closed et h) h) h
  apply installed_body (f:=Generated.f_qv) (rank:=6) (service:=service) installed closed (RationalPairFrames.bind a b ha hb) body
  exact ⟨nonzero_cast l c a b,rfl⟩

theorem qv_closed (code : List Function) (installed : Generated.f_qv∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 7 "qv" [a.source,b.source] c.state (result l c a b) (after l c a b).state := by
  by_cases hz : b.numerator.magnitude=0
  · simpa only[result,after,if_pos hz]using qv_zero_closed code installed lib ctx room a b ha hb hz
  · simpa only[result,after,if_neg hz]using qv_nonzero_closed code installed lib ctx room a b ha hb pa pb hz

end ScopedC.RationalDivideCalls
