/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.LocalAssignment
import ScopedC.DecimalDigits

namespace ScopedC.RationalPowerCounter
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
open ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def scalar (n : Nat) : Scalar.Value := ⟨⟨false,32⟩,(n:Int)⟩
def intTwo : Scalar.Value := ⟨⟨true,32⟩,2⟩

theorem cast_two : Scalar.cast ⟨false,32⟩ intTwo=some (scalar 2) := rfl
theorem cast_scalar (n : Nat) (hn : n<2^32) : Scalar.cast ⟨false,32⟩ (scalar n)=some (scalar n) :=
  scalar_u32_cast n hn

theorem divide_scalar (n : Nat) (hn : n<2^32) :
    Scalar.binary "/" (scalar n) intTwo=some (scalar (n/2)) := by
  have ha:=u32_range n hn
  have hb : Scalar.InRange intTwo.type intTwo.number := by decide +kernel
  have hq:=Scalar.make_exact (u32_range (n/2) (lt_of_le_of_lt (Nat.div_le_self _ _) hn))
  simp only [scalar,intTwo,Scalar.binary,ha,hb,decide_true,Bool.not_true,Bool.false_or,Bool.false_eq_true,↓reduceIte]
  change (do let x←Scalar.cast ⟨false,32⟩ (scalar n);let y←Scalar.cast ⟨false,32⟩ intTwo
             if y.number=0 then none else Scalar.make ⟨false,32⟩ (Int.tdiv x.number y.number))=_
  rw[cast_scalar n hn,cast_two]
  simpa [Bind.bind,Option.bind,scalar,Int.tdiv_eq_ediv_of_nonneg (Int.natCast_nonneg n)] using hq

theorem remainder_scalar (n : Nat) (hn : n<2^32) :
    Scalar.binary "%" (scalar n) intTwo=some (scalar (n%2)) := by
  have ha:=u32_range n hn
  have hb : Scalar.InRange intTwo.type intTwo.number := by decide +kernel
  have small : n%2<2^32 := lt_trans (Nat.mod_lt _ (by decide : 0<2)) (by decide +kernel)
  have hr:=Scalar.make_exact (u32_range (n%2) small)
  simp only [scalar,intTwo,Scalar.binary,ha,hb,decide_true,Bool.not_true,Bool.false_or,Bool.false_eq_true,↓reduceIte]
  change (do let x←Scalar.cast ⟨false,32⟩ (scalar n);let y←Scalar.cast ⟨false,32⟩ intTwo
             if y.number=0 then none else Scalar.make ⟨false,32⟩ (Int.tmod x.number y.number))=_
  rw[cast_scalar n hn,cast_two]
  simpa [Bind.bind,Option.bind,scalar,Int.tmod_eq_emod_of_nonneg (Int.natCast_nonneg n)] using hr

theorem divide (s : State) (n : Nat) (hn : n<2^32) :
    binaryValue Header.layout s "/" (word n) (DecimalDigits.integer 2)=some (word (n/2)) := by
  change (do let x←Scalar.binary "/" (scalar n) intTwo;pure (Value.integer x))=_
  rw[divide_scalar n hn]
  rfl
theorem remainder (s : State) (n : Nat) (hn : n<2^32) :
    binaryValue Header.layout s "%" (word n) (DecimalDigits.integer 2)=some (word (n%2)) := by
  change (do let x←Scalar.binary "%" (scalar n) intTwo;pure (Value.integer x))=_
  rw[remainder_scalar n hn]
  rfl

theorem parity_one (s : State) (n : Nat) :
    binaryValue Header.layout s "==" (word (n%2)) (DecimalDigits.integer 1)=
      some (boolean Header.layout (decide (n%2=1))) := by
  have small : n%2<2 := Nat.mod_lt _ (by decide)
  generalize hk : n%2=k at *
  interval_cases k <;> rfl

/-- The exponent counter decreases at each nonzero iteration, and the same
source uint32 bound is preserved. This supports a finite source-loop proof. -/
theorem halve_lt (n : Nat) (positive : 0<n) : n/2<n := Nat.div_lt_self positive (by decide)
theorem halve_range (n : Nat) (hn : n<2^32) : n/2<2^32 :=
  lt_of_le_of_lt (Nat.div_le_self _ _) hn

end ScopedC.RationalPowerCounter
