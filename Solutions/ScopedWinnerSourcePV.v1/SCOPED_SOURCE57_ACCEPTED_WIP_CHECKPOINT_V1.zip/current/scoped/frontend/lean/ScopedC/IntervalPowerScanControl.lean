/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerScanMultiply
import ScopedC.UnsignedVariableArithmetic

namespace ScopedC.IntervalPowerScan
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def scanCondition : Expr := .binary ">" (.var "bit") (.nat 0)
def scanOdd : Expr := .binary "==" (.binary "%" (.binary "/" (.var "n") (.var "bit")) (.nat 2)) (.nat 1)
def halfExpression : Expr := .binary "=" (.var "bit") (.binary "/" (.var "bit") (.nat 2))

theorem condition_eval (service : Call) {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) :
    Eval Header.layout service scanCondition f.cursor.state f.cursor.state (boolean Header.layout (decide (0<f.bit))) := by
  refine ⟨3,?_⟩
  apply ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 1 f.bitAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) (by rfl)
  exact RationalPowerGuard.greater_zero f.cursor.state f.bit f.bitBound

theorem odd_eval (service : Call) {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (positive : 0<f.bit) :
    Eval Header.layout service scanOdd f.cursor.state f.cursor.state
      (boolean Header.layout (decide ((n/f.bit)%2=1))) := by
  have quotient:=ExpressionTemplates.binary Header.layout service
    (op:="/") (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 1 f.nAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (LocalBinding.eval service 1 f.bitAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (UnsignedVariableArithmetic.divide f.cursor.state n f.bit f.exponentBound f.bitBound positive)
  have remainder:=ExpressionTemplates.binary Header.layout service
    (op:="%") (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    quotient (show evalExpr Header.layout service 3 f.cursor.state (.nat 2)=some (DecimalDigits.integer 2,f.cursor.state) from rfl)
    (RationalPowerCounter.remainder f.cursor.state (n/f.bit) (lt_of_le_of_lt (Nat.div_le_self _ _) f.exponentBound))
  exact ⟨5,ExpressionTemplates.binary Header.layout service
    (op:="==") (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    remainder (by rfl) (RationalPowerCounter.parity_one f.cursor.state (n/f.bit))⟩

def halved {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) : Frame l n := by
  have safe:=LocalStorageSeparation.pool f.context f.bitAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  exact {
    cursor:=LocalAssignment.cursor f.cursor f.bitSlot "unsigned int" (PoolCalls.word (f.bit/2))
    a:=f.a
    result:=f.result
    bit:=f.bit/2
    aSlot:=f.aSlot
    nSlot:=f.nSlot
    bitSlot:=f.bitSlot
    rSlot:=f.rSlot
    context:=LocalAssignment.valid f.context f.bitSlot "unsigned int" (PoolCalls.word (f.bit/2)) safe.1 safe.2.1 safe.2.2
    aAt:=LocalAssignment.other_binding (changedType:="unsigned int") (value:=PoolCalls.word (f.bit/2)) f.aAt
      (LocalStorageSeparation.typed f.aAt f.bitAt (by decide +kernel))
    nAt:=LocalAssignment.other_binding (changedType:="unsigned int") (value:=PoolCalls.word (f.bit/2)) f.nAt f.nbDistinct
    bitAt:=LocalAssignment.binding f.bitAt (by rfl)
    rAt:=LocalAssignment.other_binding (changedType:="unsigned int") (value:=PoolCalls.word (f.bit/2)) f.rAt
      (LocalStorageSeparation.typed f.rAt f.bitAt (by decide +kernel))
    aLive:=f.aLive
    rLive:=f.rLive
    aPositive:=f.aPositive
    rPositive:=f.rPositive
    aOrder:=f.aOrder
    rOrder:=f.rOrder
    exponentBound:=f.exponentBound
    bitBound:=lt_of_le_of_lt (Nat.div_le_self _ _) f.bitBound
    arDistinct:=f.arDistinct
    nbDistinct:=f.nbDistinct }

theorem half_source (service : Call) {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) :
    Eval Header.layout service halfExpression f.cursor.state (halved f).cursor.state (PoolCalls.word (f.bit/2)) :=
  ⟨4,UnsignedVariableArithmetic.halve_assignment service 0 f.bitAt f.bitBound
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)⟩

theorem half_shape {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) :
    (halved f).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (halved f).cursor.state.env=f.cursor.state.env ∧
    (halved f).cursor.state.nats=f.cursor.state.nats ∧ (halved f).cursor.top=f.cursor.top := by
  change (f.cursor.state.heap.set f.bitSlot _).length=f.cursor.state.heap.length ∧ _
  exact ⟨List.length_set,rfl,rfl,rfl⟩

end ScopedC.IntervalPowerScan
