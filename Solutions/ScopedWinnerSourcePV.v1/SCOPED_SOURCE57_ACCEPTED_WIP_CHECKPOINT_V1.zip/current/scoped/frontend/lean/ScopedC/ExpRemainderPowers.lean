/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderFactorialFrames
import ScopedC.RationalPowerAllocated

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax

abbrev BeforeError {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) := f.loop.finish.cursor

def three {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) : Input := RationalUnsignedTrace.output l (BeforeError f) 3

def afterThree {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) : Cursor := RationalUnsignedTrace.after l (BeforeError f) 3

abbrev ThreePower {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) :=
  RationalPowerCalls.AllocatedResult code l (afterThree f) (three f) (ceil.endpoint.magnitude+1)

abbrev RadiusPower {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} (p : ThreePower f) :=
  RationalPowerCalls.AllocatedResult code l p.out (radius l c a) (d+1)

theorem three_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) (room : c.top+3000<PoolCalls.capacity) :
    Valid l (afterThree f) :=
  CursorFrames.advance_valid f.loop.finish.context [3,0,1]
    (by change (BeforeError f).top+3 ≤ PoolCalls.capacity;have h:=factorial_top f;have beforeTop : (BeforeError f).top ≤ c.top+930:=h;omega)

theorem three_source (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (room : c.top+3000<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 3] (BeforeError f).state
      (three f).source (afterThree f).state :=
  (RationalUnsignedTrace.qi_traced code lib.qi lib.si lib.productLibrary.smake lib.productLibrary.nz
    lib.productLibrary.nu lib.productLibrary.ne lib.productLibrary.keep f.loop.finish.context 3
    (by decide +kernel) (by have h:=factorial_top f;have beforeTop : (BeforeError f).top ≤ c.top+930:=h;omega) (DecimalDigits.integer 3) (by rfl)).1

theorem three_power (code : List Function) (installed : Generated.f_qpow∈code)
    (lib : RationalPowerCalls.Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) (countBound : ceil.endpoint.magnitude<4294967295)
    (room : c.top+3000<PoolCalls.capacity) : Nonempty (ThreePower f) :=
  RationalPowerCalls.qpow_allocated code installed lib (three_valid f room)
    (by change (BeforeError f).top+3+706<PoolCalls.capacity;have h:=factorial_top f;have beforeTop : (BeforeError f).top ≤ c.top+930:=h;omega)
    (three f) (ceil.endpoint.magnitude+1) (RationalUnsignedTrace.live l (BeforeError f) 3)
    (by change 0<(1:Nat);decide +kernel) (by omega)

theorem radius_power (code : List Function) (installed : Generated.f_qpow∈code)
    (lib : RationalPowerCalls.Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) (p : ThreePower f)
    (alive : a.Live c.state) (positive : a.Positive) (room : c.top+3000<PoolCalls.capacity) :
    Nonempty (RadiusPower p) := by
  have first:=factorial_radius_live f alive
  have afterThree : (radius l c a).Live (ExpRemainderCalls.afterThree f).state :=
    ⟨CursorBorrow.preserves (l:=l) (c:=BeforeError f) [3,0,1] first.1,
      CursorBorrow.preserves (l:=l) (c:=BeforeError f) [3,0,1] first.2⟩
  have live : (radius l c a).Live p.out.state:=⟨p.preserves _ _ afterThree.1,p.preserves _ _ afterThree.2⟩
  have top:=p.top
  change p.out.top ≤ (BeforeError f).top+3+707 at top
  have h:=factorial_top f
  have beforeTop : (BeforeError f).top ≤ c.top+930:=h
  have dBound:=f.start.depthBound
  exact RationalPowerCalls.qpow_allocated code installed lib p.valid (by omega) (radius l c a) (d+1)
    live (radius_positive a positive) (by omega)

theorem three_power_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} (p : ThreePower f) :
    p.output.mathematical.value=(3:Rat)^(ceil.endpoint.magnitude+1) := by
  rw[p.value]
  exact congrArg (fun x : Rat=>x^(ceil.endpoint.magnitude+1))
    (RationalUnsignedTrace.mathematical l (BeforeError f) 3).1

theorem radius_power_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (positive : a.Positive) : r.output.mathematical.value=
      (max |a.lo.mathematical.value| |a.hi.mathematical.value|)^(d+1) := by
  rw[r.value,radius_value a positive]

end ScopedC.ExpRemainderCalls
