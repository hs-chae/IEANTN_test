/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointModel
import ScopedC.ExpPointSourceBindings
import ScopedC.CoefficientTableGlobal

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

section
variable {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
variable {stage : CeilStage code l c q} {positive : 0 < q.denominator}
variable {base : Address} {coeffs : List Input} {d : Nat}
variable {t : TaylorStage stage positive base coeffs d}

theorem sum_power_binding (r : RemainderStage t) (room : c.top+40 < PoolCalls.capacity) :
    LocalBinding.At (sumCursor r).state "power" "unsigned int"
      (PoolCalls.word (powerValue stage)) (afterK stage).state.heap.length := by
  have before := input_power_binding stage positive room
  have safe := LocalStorageSeparation.pool (input_valid stage positive room) before
    (by decide +kernel)
  have polynomial : LocalBinding.At t.out.state "power" "unsigned int"
      (PoolCalls.word (powerValue stage)) (afterK stage).state.heap.length :=
    LocalBinding.memory before t.env
      (t.other _ (List.getElem?_eq_some_iff.mp before.memory).choose safe.1 safe.2.1 safe.2.2)
  have remainder : LocalBinding.At r.out.state "power" "unsigned int"
      (PoolCalls.word (powerValue stage)) (afterK stage).state.heap.length :=
    LocalBinding.memory polynomial r.env
      (r.other _ (List.getElem?_eq_some_iff.mp polynomial.memory).choose safe.1 safe.2.1 safe.2.2)
  exact RationalIntervalAddCalls.after_binding _ _ remainder safe.1 safe.2.1 safe.2.2

def returnExpression : Expr := .call (.var "rpow")
  [.call (.var "radd") [.call (.var "taylor") [.var "expCoeffs",.var "input"],
    .call (.var "expRemainder") [.var "input"]],.var "power"]

theorem return_eval (service : Call) (valid : Valid l c) (r : RemainderStage t)
    (p : PowerStage r) (room : c.top+40 < PoolCalls.capacity)
    (table : CoefficientTableRead.TableAt c.state base coeffs)
    (lookup : c.state.globals.lookup "expCoeffs"=some base)
    (polynomial : service "taylor" [.pointer base true,(inputPair stage positive).source]
      (afterInput stage positive).state = some (t.output.source,t.out.state))
    (remainder : service "expRemainder" [(inputPair stage positive).source] t.out.state =
      some (r.output.source,r.out.state))
    (addition : service "radd" [t.output.source,r.output.source] r.out.state =
      some ((sumPair r).source,(sumCursor r).state))
    (power : service "rpow" [(sumPair r).source,PoolCalls.word (powerValue stage)]
      (sumCursor r).state = some (p.output.source,p.out.state)) :
    Eval Header.layout service returnExpression (afterInput stage positive).state
      p.out.state p.output.source := by
  have tableAt := input_table stage positive valid table
  have globalLookup : (afterInput stage positive).state.globals.lookup "expCoeffs"=some base := by
    rw [input_globals stage positive]
    exact lookup
  have arrayEval := CoefficientTableRead.eval_global service 1 tableAt globalLookup
    (input_unshadowed stage positive "expCoeffs" (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (by decide +kernel)) (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)
  have firstInput := LocalBinding.eval service 1 (input_binding stage positive)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have first := ExpressionTemplates.call_two Header.layout service arrayEval firstInput polynomial
  have secondInput := LocalBinding.eval service 1 (input_taylor_binding t room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have second := ExpressionTemplates.call_one Header.layout service secondInput remainder
  have sum := ExpressionTemplates.call_two Header.layout service first second addition
  have powerRead := LocalBinding.eval service 3 (sum_power_binding r room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact ⟨5,ExpressionTemplates.call_two Header.layout service sum powerRead power⟩

end
end ScopedC.ExpPointCalls
