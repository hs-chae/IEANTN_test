/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplyProducts
import ScopedC.RationalSelectionTreeEffects
import ScopedC.RationalSelectionTreeMath

namespace ScopedC.RationalIntervalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def four (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : RationalSelectionTree.Four :=
  ⟨p l c a b,q l c a b,r l c a b,s l c a b⟩
def lowQ (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Input :=
  RationalSelectionTree.output false l (c4 l c a b) (four l c a b)
@[irreducible] def middle (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  RationalSelectionTree.finish false l (c4 l c a b) (four l c a b)
def highQ (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Input :=
  RationalSelectionTree.output true l (middle l c a b) (four l c a b)
def finish (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  RationalSelectionTree.finish true l (middle l c a b) (four l c a b)
def outputPair (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Pair :=
  ⟨lowQ l c a b,highQ l c a b⟩

theorem four_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (four l c a b).Live (c4 l c a b).state :=
  ⟨p_live l c a b,q_live l c a b,r_live l c a b,s_live l c a b⟩
theorem four_positive (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair)
    (pa : a.Positive) (pb : b.Positive) : (four l c a b).Positive := positives l c a b pa pb

theorem middle_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (middle l c a b).top=c.top+62 := by
  unfold middle;rw[RationalSelectionTree.top_finish,top4]
theorem finish_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (finish l c a b).top=c.top+80 := by
  unfold finish;rw[RationalSelectionTree.top_finish,middle_top]
theorem middle_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (middle l c a b) := by
  unfold middle
  exact RationalSelectionTree.finish_valid false (ctx4 ctx room a b) (by rw[top4];omega) (four l c a b)
theorem finish_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (finish l c a b) :=
  RationalSelectionTree.finish_valid true (middle_valid ctx room a b) (by rw[middle_top];omega) (four l c a b)

theorem four_middle_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (four l c a b).Live (middle l c a b).state := by
  unfold middle
  exact RationalSelectionTree.preserves_four false (four l c a b) (four_live l c a b)

theorem output_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (outputPair l c a b).Live (finish l c a b).state := by
  have low : (lowQ l c a b).Live (middle l c a b).state := by
    unfold middle
    exact RationalSelectionTree.output_live false l (c4 l c a b) (four l c a b) (four_live l c a b)
  have lowFinal : (lowQ l c a b).Live (finish l c a b).state :=
    ⟨RationalSelectionTree.preserves_nat true (four l c a b) low.1,
     RationalSelectionTree.preserves_nat true (four l c a b) low.2⟩
  exact ⟨lowFinal,RationalSelectionTree.output_live true l (middle l c a b) (four l c a b) (four_middle_live l c a b)⟩

theorem output_positive (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair)
    (pa : a.Positive) (pb : b.Positive) : (outputPair l c a b).Positive :=
  ⟨RationalSelectionTree.positive false l (c4 l c a b) (four l c a b) (four_positive l c a b pa pb),
   RationalSelectionTree.positive true l (middle l c a b) (four l c a b) (four_positive l c a b pa pb)⟩

theorem selected_calls (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) :
    let v:=four l c a b
    let c0:=c4 l c a b
    let cm:=middle l c a b
    (SourceCall Header.layout code 7 "qmin" [v.p.source,v.q.source] c0.state
      (RationalSelectionTree.left false l c0 v).source (RationalSelectionTree.t1 l c0 v).state ∧
     SourceCall Header.layout code 7 "qmin" [v.r.source,v.s.source] (RationalSelectionTree.t1 l c0 v).state
      (RationalSelectionTree.right false l c0 v).source (RationalSelectionTree.t2 l c0 v).state ∧
     SourceCall Header.layout code 7 "qmin" [(RationalSelectionTree.left false l c0 v).source,(RationalSelectionTree.right false l c0 v).source]
      (RationalSelectionTree.t2 l c0 v).state (lowQ l c a b).source cm.state) ∧
    (SourceCall Header.layout code 7 "qmax" [v.p.source,v.q.source] cm.state
      (RationalSelectionTree.left true l cm v).source (RationalSelectionTree.t1 l cm v).state ∧
     SourceCall Header.layout code 7 "qmax" [v.r.source,v.s.source] (RationalSelectionTree.t1 l cm v).state
      (RationalSelectionTree.right true l cm v).source (RationalSelectionTree.t2 l cm v).state ∧
     SourceCall Header.layout code 7 "qmax" [(RationalSelectionTree.left true l cm v).source,(RationalSelectionTree.right true l cm v).source]
      (RationalSelectionTree.t2 l cm v).state (highQ l c a b).source (finish l c a b).state) := by
  constructor
  · unfold middle
    exact RationalSelectionTree.calls code lib.selectLibrary false (ctx4 ctx room a b)
      (by rw[top4];omega) (four l c a b) (four_live l c a b)
  · exact RationalSelectionTree.calls code lib.selectLibrary true (middle_valid ctx room a b)
      (by rw[middle_top];omega) (four l c a b) (four_middle_live l c a b)

end ScopedC.RationalIntervalMultiplyCalls
