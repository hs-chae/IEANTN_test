/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhTaylor
import ScopedC.IntervalAddApplicability

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

theorem remainder_taylor_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) :
    (remainderPair stage positive).Live t.out.state := by
  have before:=remainder_live stage positive
  exact ⟨⟨t.preserves _ _ before.1.1,t.preserves _ _ before.1.2⟩,
    ⟨t.preserves _ _ before.2.1,t.preserves _ _ before.2.2⟩⟩

noncomputable def sumPair {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive)
    (narrow : |q.mathematical.value|<1) : Pair :=
  IntervalAddApplicability.output l t.out (taylorPair t) (remainderPair stage positive)
    (taylor_pair_spec t).2.2.1 (remainder_positive stage positive)
    (taylor_pair_order t) (remainder_order stage positive narrow)

noncomputable def sumCursor {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) : Cursor :=
  RationalIntervalAddCalls.after l t.out (taylorPair t) (remainderPair stage positive)

theorem tail_room {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive)
    (narrow : |q.mathematical.value|<1) (dBound : d≤64)
    (room : c.top+9000<PoolCalls.capacity) : t.out.top+27<PoolCalls.capacity := by
  have p:=stage.top
  rw[guard_top] at p
  have ht:=t.top
  rw[remainder_top stage positive narrow] at ht
  omega

theorem sum_source (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {base : Address} {coeffs : List Input}
    {q : Input} {d : Nat} {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive)
    (narrow : |q.mathematical.value|<1) (dBound : d≤64)
    (room : c.top+9000<PoolCalls.capacity) :
    SourceCall Header.layout code 7 "radd" [(taylorPair t).source,(remainderPair stage positive).source]
      t.out.state (sumPair t narrow).source (sumCursor t).state := by
  unfold sumPair
  rw[(IntervalAddApplicability.output_spec l t.out (taylorPair t) (remainderPair stage positive)
    (taylor_pair_spec t).2.2.1 (remainder_positive stage positive)
    (taylor_pair_order t) (remainder_order stage positive narrow)).1]
  exact RationalIntervalAddCalls.radd_closed code lib.polynomial.body.radd
    lib.polynomial.body.qa lib.polynomial.body.addLibrary t.valid
    (tail_room t narrow dBound room) _ _ (taylor_pair_spec t).2.1
    (remainder_taylor_live t) (taylor_pair_spec t).2.2.1 (remainder_positive stage positive)

theorem sum_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive)
    (narrow : |q.mathematical.value|<1) (dBound : d≤64)
    (room : c.top+9000<PoolCalls.capacity) : Valid l (sumCursor t) :=
  RationalIntervalAddCalls.after_valid t.valid (tail_room t narrow dBound room) _ _

theorem sum_spec {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive)
    (narrow : |q.mathematical.value|<1) :
    (sumPair t narrow).Live (sumCursor t).state ∧ (sumPair t narrow).Positive ∧
      (sumPair t narrow).lo.mathematical.value=
        (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
          (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).lo-
            |q.mathematical.value|^(d+1)/(1-|q.mathematical.value|) ∧
      (sumPair t narrow).hi.mathematical.value=
        (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
          (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).hi+
            |q.mathematical.value|^(d+1)/(1-|q.mathematical.value|) := by
  have spec:=IntervalAddApplicability.output_spec l t.out (taylorPair t) (remainderPair stage positive)
    (taylor_pair_spec t).2.2.1 (remainder_positive stage positive)
    (taylor_pair_order t) (remainder_order stage positive narrow)
  unfold sumPair
  refine ⟨spec.2.1,spec.2.2.1,?_,?_⟩
  · rw[spec.2.2.2.1,(taylor_pair_spec t).2.2.2.1]
    change _+(RationalSubCalls.negative (errorInput stage positive)).mathematical.value=_
    rw[RationalSubCalls.negative_value,error_value stage positive]
    exact (sub_eq_add_neg _ _).symm
  · rw[spec.2.2.2.2,(taylor_pair_spec t).2.2.2.2]
    change _+(errorInput stage positive).mathematical.value=_
    rw[error_value stage positive]

end ScopedC.AtanhCalls
