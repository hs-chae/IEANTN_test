/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorStepEffects

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

noncomputable def stepped {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) : Frame l base coeffs := by
  have cSafe:=LocalStorageSeparation.pool f.context f.coeffAt (by decide +kernel : ("const Q*":String)≠"unsigned")
  have aSafe:=LocalStorageSeparation.pool f.context f.aAt (by decide +kernel : ("RI":String)≠"unsigned")
  have kSafe:=LocalStorageSeparation.pool f.context f.kAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  have rSafe:=LocalStorageSeparation.pool f.context f.rAt (by decide +kernel : ("RI":String)≠"unsigned")
  have atC:=sum_binding f hk f.coeffAt cSafe.1 cSafe.2.1 cSafe.2.2
  have atA:=sum_binding f hk f.aAt aSafe.1 aSafe.2.1 aSafe.2.2
  have atK:=sum_binding f hk f.kAt kSafe.1 kSafe.2.1 kSafe.2.2
  have atR:=sum_binding f hk f.rAt rSafe.1 rSafe.2.1 rSafe.2.2
  exact {
    cursor:=LocalAssignment.cursor (sumCursor f hk) f.rSlot "RI" (sum f hk).source
    a:=f.a
    result:=sum f hk
    k:=f.k
    coeffSlot:=f.coeffSlot
    aSlot:=f.aSlot
    kSlot:=f.kSlot
    rSlot:=f.rSlot
    context:=LocalAssignment.valid (sum_context f hk room) f.rSlot "RI" (sum f hk).source rSafe.1 rSafe.2.1 rSafe.2.2
    coeffAt:=LocalAssignment.other_binding (changedType:="RI") (value:=(sum f hk).source) atC
      (LocalStorageSeparation.typed f.coeffAt f.rAt (by decide +kernel))
    aAt:=LocalAssignment.other_binding (changedType:="RI") (value:=(sum f hk).source) atA f.arDistinct
    kAt:=LocalAssignment.other_binding (changedType:="RI") (value:=(sum f hk).source) atK
      (LocalStorageSeparation.typed f.kAt f.rAt (by decide +kernel))
    rAt:=LocalAssignment.binding atR (Pair.initialized _)
    table:=CoefficientTableRead.local_store (sum_table f hk room) atR
    aLive:=sum_preserves_pair f hk f.aLive
    rLive:=sum_live f hk
    aPositive:=f.aPositive
    rPositive:=sum_positive f hk
    aOrder:=f.aOrder
    rOrder:=sum_order f hk
    kLength:=f.kLength
    kBound:=f.kBound
    arDistinct:=f.arDistinct }

theorem stepped_top {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    (stepped f hk room).cursor.top=f.cursor.top+108 := sum_top f hk
theorem stepped_k {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    (stepped f hk room).k=f.k := rfl
theorem stepped_original {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    original (stepped f hk room)=original f := rfl
theorem stepped_size {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    (stepped f hk room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+108 := sum_size f hk
theorem stepped_shape {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    (stepped f hk room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (stepped f hk room).cursor.state.env=f.cursor.state.env := by
  change ((sumCursor f hk).state.heap.set f.rSlot _).length=_ ∧ _
  rw[List.length_set]
  exact sum_shape f hk

end ScopedC.TaylorCalls
