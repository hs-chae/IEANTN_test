/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderErrorEffects
import ScopedC.RationalSymmetricLocal

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

noncomputable def storedError {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) : Cursor :=
  CursorLocals.allocated (errorCursor r) "Q" "error" (errorInput r).source

noncomputable def outputPair {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) : Pair :=
  RationalSymmetricLocal.output (errorInput r)

noncomputable def afterOut {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) : Cursor :=
  CursorLocals.allocated (next l (storedError r) 0) "RI" "out" (outputPair r).source

def outputExpression : Expr := .record [.call (.var "qn") [.var "error"],.var "error"]

theorem stored_error_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (room : c.top+3000<PoolCalls.capacity) : Valid l (storedError r) :=
  CursorLocals.allocated_valid (error_valid r room) "Q" "error" _

theorem error_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    LocalBinding.At (storedError r).state "error" "Q" (errorInput r).source (errorCursor r).state.heap.length :=
  LocalBinding.allocate_head _ "error" "Q" _ (by rfl)

theorem output_call (code : List Function) (qn : Generated.f_qn∈code) (sn : Generated.f_sn∈code)
    (lib : RationalAbsApplicability.Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (room : c.top+3000<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qn" [(errorInput r).source] (storedError r).state
      (outputPair r).lo.source (next l (storedError r) 0).state := by
  have bound:=radius_power_top r
  exact RationalSymmetricLocal.source_call code qn sn lib.smake lib.nz lib.nu lib.ne lib.keep
    (stored_error_valid r room) (by change (errorCursor r).top<PoolCalls.capacity;rw[error_top];omega)
    (errorInput r) (error_live r) (error_positive r)

theorem output_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} {f : FactorialStage code l c a object d ceil} {p : ThreePower f}
    (r : RadiusPower p) (room : c.top+3000<PoolCalls.capacity)
    (answer : service "qn" [(errorInput r).source] (storedError r).state=
      some ((outputPair r).lo.source,(next l (storedError r) 0).state)) :
    Declare Header.layout service [{type:="RI",name:="out",value:=some outputExpression,arrayExtent:=none}]
      (storedError r).state (afterOut r).state := by
  have before:=error_binding r
  have safe:=LocalStorageSeparation.pool (stored_error_valid r room) before (by decide +kernel : ("Q":String)≠"unsigned")
  have afterBinding : LocalBinding.At (next l (storedError r) 0).state "error" "Q" (errorInput r).source
      (errorCursor r).state.heap.length:=LocalBinding.advance before [0] safe.1 safe.2.1 safe.2.2
  have left:=ExpressionTemplates.call_one Header.layout service
    (LocalBinding.eval service 998 before (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)) answer
  have right:=LocalBinding.eval service 998 afterBinding (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have expression : evalExpr Header.layout service 1000 (storedError r).state outputExpression=
      some (.aggregate [(outputPair r).lo.source,(outputPair r).hi.source],(next l (storedError r) 0).state) :=
    ExpressionTemplates.record_two Header.layout service left right
  have live:=RationalSymmetricLocal.live (l:=l) (c:=storedError r) (error_live r)
  have low : castValue Header.layout (next l (storedError r) 0).state 99 "Q" (outputPair r).lo.source=
      some (outputPair r).lo.source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) live.1.1 live.1.2 (SignedNegCalls.bit_bound _)
  have high : castValue Header.layout (next l (storedError r) 0).state 99 "Q" (outputPair r).hi.source=
      some (outputPair r).hi.source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) live.2.1 live.2.2 (SignedNegCalls.bit_bound _)
  have cast:=IntervalCasts.aggregate _ 96 _ _ low high
  simp only[Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem output_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (outputPair r).Live (afterOut r).state :=
  RationalSymmetricLocal.live (l:=l) (c:=storedError r) (error_live r)

theorem output_positive {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (outputPair r).Positive:=⟨error_positive r,error_positive r⟩

theorem output_order {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (positive : a.Positive) :
    (outputPair r).lo.mathematical.value ≤ (outputPair r).hi.mathematical.value := by
  change (RationalSubCalls.negative (errorInput r)).mathematical.value ≤ (errorInput r).mathematical.value
  rw[RationalSubCalls.negative_value]
  have nonnegative:=error_nonnegative r positive
  linarith

end ScopedC.ExpRemainderCalls
