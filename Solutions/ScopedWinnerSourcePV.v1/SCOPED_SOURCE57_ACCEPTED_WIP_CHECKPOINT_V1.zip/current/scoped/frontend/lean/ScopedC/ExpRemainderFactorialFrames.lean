/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderFactorial
import ScopedC.ExpFactorialInitialData

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax

theorem afterMax_heap (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    (afterMax l c a).state.heap.length=c.state.heap.length+1 := by
  rw[afterMax_trace,(CursorEffects.shape _ _ _).1]
  simp [parameters,OneFrames.frame,allocate]

theorem afterC_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (ceil : CeilStage code l c a) : (afterC ceil).state.heap.length=c.state.heap.length+4 := by
  have before : ceil.out.state.heap.length=c.state.heap.length+2 := by
    rw[ceil.trace,(CursorEffects.shape _ _ _).1,afterR_heap]
  change ((next l (afterCeil ceil) 4294967295).state.heap++[_]).length=_
  rw[List.length_append,List.length_singleton,(PoolCursor.shape _ _ _).1]
  change (ceil.out.state.heap++[_]).length+1=_
  rw[List.length_append,List.length_singleton,before]

theorem radius_afterC_binding {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {a : Pair} (ceil : CeilStage code l c a) (ctx : Valid l c)
    (room : c.top+7<PoolCalls.capacity) :
    LocalBinding.At (afterC ceil).state "r" "Q" (radius l c a).source
      (afterMax l c a).state.heap.length := by
  have original:=radius_binding l c a
  have safe:=LocalStorageSeparation.pool (afterR_valid ctx a room) original
    (by decide +kernel : ("Q":String)≠"unsigned")
  have afterCeiling : LocalBinding.At ceil.out.state "r" "Q" (radius l c a).source
      (afterMax l c a).state.heap.length := by
    rw[ceil.trace]
    exact LocalBinding.advance original ceil.values safe.1 safe.2.1 safe.2.2
  exact LocalBinding.allocate_other
    (LocalBinding.advance (LocalBinding.allocate_other afterCeiling "ceil" "S" _ (by decide +kernel))
      [4294967295] safe.1 safe.2.1 safe.2.2) "c" "unsigned int" _ (by decide +kernel)

theorem factorial_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (stage : FactorialStage code l c a object d ceil) : stage.loop.finish.cursor.top ≤ c.top+930 := by
  have top:=stage.loop.top
  have depth:=stage.start.depthBound
  rw[stage.k] at top
  have startTop : stage.start.cursor.top ≤ c.top+20 := by
    rw[stage.cursor]
    change (afterC ceil).top+3 ≤ c.top+20
    have initialTop:=afterC_top ceil
    omega
  omega

theorem factorial_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (stage : FactorialStage code l c a object d ceil) (room : c.top+16<PoolCalls.capacity)
    {name ty : String} {value : Value} {slot : Nat}
    (before : LocalBinding.At (afterC ceil).state name ty value slot)
    (notCounter : ty≠"unsigned") (notFact : name≠"fact") (notK : name≠"k") :
    LocalBinding.At stage.loop.finish.cursor.state name ty value slot := by
  have safe:=LocalStorageSeparation.pool (afterC_valid ceil room) before notCounter
  have first:=LocalBinding.advance before [1,0,1] safe.1 safe.2.1 safe.2.2
  have initial : LocalBinding.At (ExpFactorial.initial l (afterC ceil)).state name ty value slot :=
    LocalBinding.allocate_other
      (LocalBinding.allocate_other first "fact" "Q" _ (Ne.symm notFact))
      "k" "unsigned int" _ (Ne.symm notK)
  have atStart : LocalBinding.At stage.start.cursor.state name ty value slot := by
    rw[stage.cursor]
    exact initial
  have bound:=(List.getElem?_eq_some_iff.mp before.memory).choose
  have slots:=ExpFactorial.initial_slots stage.start stage.cursor
  exact LocalBinding.memory atStart stage.loop.shape.2
    (stage.loop.other slot (by rw[slots.1];omega) (by rw[slots.2];omega) safe.1 safe.2.1 safe.2.2)

theorem factorial_radius_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (stage : FactorialStage code l c a object d ceil) (alive : a.Live c.state) :
    (radius l c a).Live stage.loop.finish.cursor.state := by
  have before : (radius l c a).Live (afterR l c a).state :=
    Input.live_allocate (afterMax l c a).state (radius l c a) "Q" "r" _ (radius_live a alive)
  have afterCeil : (radius l c a).Live ceil.out.state := by
    rw[ceil.trace]
    exact ⟨CursorBorrow.preserves ceil.values before.1,CursorBorrow.preserves ceil.values before.2⟩
  have countLive : (radius l c a).Live (afterC ceil).state :=
    ⟨PoolCursor.preserves afterCeil.1,PoolCursor.preserves afterCeil.2⟩
  have startLive : (radius l c a).Live stage.start.cursor.state := by
    rw[stage.cursor]
    exact ⟨CursorBorrow.preserves (l:=l) (c:=afterC ceil) [1,0,1] countLive.1,
      CursorBorrow.preserves (l:=l) (c:=afterC ceil) [1,0,1] countLive.2⟩
  exact ⟨stage.loop.preserves _ _ startLive.1,stage.loop.preserves _ _ startLive.2⟩

end ScopedC.ExpRemainderCalls
