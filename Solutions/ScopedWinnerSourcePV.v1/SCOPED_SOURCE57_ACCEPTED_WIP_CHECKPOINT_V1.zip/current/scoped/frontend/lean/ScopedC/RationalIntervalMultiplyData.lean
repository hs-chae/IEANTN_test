/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalProductApplicability
import ScopedC.RationalIntervalFrames
import ScopedC.RationalIntervalHullData

namespace ScopedC.RationalIntervalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalProductApplicability
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def base (c : Cursor) (a b : Pair) : Cursor := RationalIntervalFrames.framed c a b
def p (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Input := output l (base c a b) a.lo b.lo
@[irreducible] def c1 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor := saved l (base c a b) a.lo b.lo "p"
def q (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Input := output l (c1 l c a b) a.lo b.hi
@[irreducible] def c2 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor := saved l (c1 l c a b) a.lo b.hi "q"
def r (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Input := output l (c2 l c a b) a.hi b.lo
@[irreducible] def c3 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor := saved l (c2 l c a b) a.hi b.lo "r"
def s (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Input := output l (c3 l c a b) a.hi b.hi
@[irreducible] def c4 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor := saved l (c3 l c a b) a.hi b.hi "s"

theorem top1 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : (c1 l c a b).top=c.top+11 := by
  unfold c1;exact saved_top l (base c a b) a.lo b.lo "p"
theorem top2 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : (c2 l c a b).top=c.top+22 := by
  unfold c2;rw[saved_top,top1]
theorem top3 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : (c3 l c a b).top=c.top+33 := by
  unfold c3;rw[saved_top,top2]
theorem top4 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : (c4 l c a b).top=c.top+44 := by
  unfold c4;rw[saved_top,top3]

theorem ctx1 {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (c1 l c a b) := by
  unfold c1
  exact saved_valid (CursorFrames.framed_valid ctx "RI" "a" a.source "RI" "b" b.source)
    (by change c.top+10<_;omega) a.lo b.lo "p"
theorem ctx2 {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (c2 l c a b) := by
  unfold c2
  exact saved_valid (ctx1 ctx room a b) (by rw[top1];omega) a.lo b.hi "q"
theorem ctx3 {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (c3 l c a b) := by
  unfold c3
  exact saved_valid (ctx2 ctx room a b) (by rw[top2];omega) a.hi b.lo "r"
theorem ctx4 {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (c4 l c a b) := by
  unfold c4
  exact saved_valid (ctx3 ctx room a b) (by rw[top3];omega) a.hi b.hi "s"

theorem input1 {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair} {v : Input}
    (h : v.Live c.state) : v.Live (c1 l c a b).state := by
  unfold c1
  exact saved_preserves_input (c:=base c a b) (a:=a.lo) (b:=b.lo) h
theorem input2 {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair} {v : Input}
    (h : v.Live c.state) : v.Live (c2 l c a b).state := by
  unfold c2
  exact saved_preserves_input (c:=c1 l c a b) (a:=a.lo) (b:=b.hi) (input1 h)
theorem input3 {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair} {v : Input}
    (h : v.Live c.state) : v.Live (c3 l c a b).state := by
  unfold c3
  exact saved_preserves_input (c:=c2 l c a b) (a:=a.hi) (b:=b.lo) (input2 h)
theorem input4 {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair} {v : Input}
    (h : v.Live c.state) : v.Live (c4 l c a b).state := by
  unfold c4
  exact saved_preserves_input (c:=c3 l c a b) (a:=a.hi) (b:=b.hi) (input3 h)

theorem p_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (p l c a b).Live (c4 l c a b).state := by
  have h : (p l c a b).Live (c1 l c a b).state := by
    unfold c1
    exact saved_live l (base c a b) a.lo b.lo "p"
  have h2 : (p l c a b).Live (c2 l c a b).state := by
    unfold c2;exact saved_preserves_input (c:=c1 l c a b) (a:=a.lo) (b:=b.hi) h
  have h3 : (p l c a b).Live (c3 l c a b).state := by
    unfold c3;exact saved_preserves_input (c:=c2 l c a b) (a:=a.hi) (b:=b.lo) h2
  unfold c4;exact saved_preserves_input (c:=c3 l c a b) (a:=a.hi) (b:=b.hi) h3
theorem q_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (q l c a b).Live (c4 l c a b).state := by
  have h2 : (q l c a b).Live (c2 l c a b).state := by
    unfold c2;exact saved_live l (c1 l c a b) a.lo b.hi "q"
  have h3 : (q l c a b).Live (c3 l c a b).state := by
    unfold c3;exact saved_preserves_input (c:=c2 l c a b) (a:=a.hi) (b:=b.lo) h2
  unfold c4;exact saved_preserves_input (c:=c3 l c a b) (a:=a.hi) (b:=b.hi) h3
theorem r_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (r l c a b).Live (c4 l c a b).state := by
  have h3 : (r l c a b).Live (c3 l c a b).state := by
    unfold c3;exact saved_live l (c2 l c a b) a.hi b.lo "r"
  unfold c4;exact saved_preserves_input (c:=c3 l c a b) (a:=a.hi) (b:=b.hi) h3
theorem s_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (s l c a b).Live (c4 l c a b).state := by
  unfold c4;exact saved_live l (c3 l c a b) a.hi b.hi "s"

theorem positives (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair)
    (pa : a.Positive) (pb : b.Positive) :
    0<(p l c a b).denominator ∧ 0<(q l c a b).denominator ∧
    0<(r l c a b).denominator ∧ 0<(s l c a b).denominator :=
  ⟨positive l (base c a b) a.lo b.lo pa.1 pb.1,
   positive l (c1 l c a b) a.lo b.hi pa.1 pb.2,
   positive l (c2 l c a b) a.hi b.lo pa.2 pb.1,
   positive l (c3 l c a b) a.hi b.hi pa.2 pb.2⟩

theorem values (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair)
    (pa : a.Positive) (pb : b.Positive) :
    (p l c a b).mathematical.value=a.lo.mathematical.value*b.lo.mathematical.value ∧
    (q l c a b).mathematical.value=a.lo.mathematical.value*b.hi.mathematical.value ∧
    (r l c a b).mathematical.value=a.hi.mathematical.value*b.lo.mathematical.value ∧
    (s l c a b).mathematical.value=a.hi.mathematical.value*b.hi.mathematical.value :=
  ⟨mathematical l (base c a b) a.lo b.lo pa.1 pb.1,
   mathematical l (c1 l c a b) a.lo b.hi pa.1 pb.2,
   mathematical l (c2 l c a b) a.hi b.lo pa.2 pb.1,
   mathematical l (c3 l c a b) a.hi b.hi pa.2 pb.2⟩

end ScopedC.RationalIntervalMultiplyCalls
