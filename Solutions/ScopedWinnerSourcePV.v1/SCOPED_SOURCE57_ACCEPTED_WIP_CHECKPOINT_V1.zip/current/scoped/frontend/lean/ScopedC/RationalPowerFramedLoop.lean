/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerLoop
import ScopedC.RationalPowerPhysicalEffects

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Additional derived physical effects of the same actual source loop.
This extends, and does not alter, the accepted original loop certificate. -/
structure FramedLoopCertificate (code : List Function) {l : PoolCalls.PoolLayout} (start : Frame l) (bits : Nat)
    extends LoopCertificate code start bits where
  borrows : ∀slot n,NatArena.Borrow start.cursor.state.nats slot n → NatArena.Borrow finish.cursor.state.nats slot n
  globals : finish.cursor.state.globals=start.cursor.state.globals
  slots : finish.aSlot=start.aSlot ∧ finish.nSlot=start.nSlot ∧ finish.rSlot=start.rSlot
  other : ∀slot,slot≠start.aSlot → slot≠start.nSlot → slot≠start.rSlot →
    slot≠l.pool → slot≠l.top → slot≠l.high → finish.cursor.state.heap[slot]?=start.cursor.state.heap[slot]?

def stoppedFramedCertificate (code : List Function) {l : PoolCalls.PoolLayout} (f : Frame l) (bits : Nat)
    (stop : f.exponent=0) : FramedLoopCertificate code f bits where
  toLoopCertificate:=stoppedCertificate code f bits stop
  borrows:=fun _ _ live=>live
  globals:=rfl
  slots:=⟨rfl,rfl,rfl⟩
  other:=by intros;rfl

/-- uint32 halving terminates in at most 32 iterations. The arena bound is
an intentionally conservative proof resource bound for the existing source. -/
theorem loop_framed_certificate (code : List Function) (lib : Library code) (bits : Nat)
    {l : PoolCalls.PoolLayout} (f : Frame l) (bound : f.exponent<2^bits)
    (room : f.cursor.top+22*bits ≤ PoolCalls.capacity) :
    Nonempty (FramedLoopCertificate code f bits) := by
  induction bits generalizing f with
  | zero =>
    exact ⟨stoppedFramedCertificate code f 0 (by simpa using bound)⟩
  | succ bits ih =>
    by_cases stop : f.exponent=0
    · exact ⟨stoppedFramedCertificate code f (bits+1) stop⟩
    · have stepRoom : f.cursor.top+21<PoolCalls.capacity := by omega
      let next:=iteration f stepRoom
      have nextBound : next.exponent<2^bits := by
        rw[show next.exponent=f.exponent/2 from iteration_exponent f stepRoom]
        exact RationalPowerInvariant.halve_bits f.exponent bits bound
      have nextRoom : next.cursor.top+22*bits ≤ PoolCalls.capacity := by
        have h:=iteration_top_le f stepRoom
        change (iteration f stepRoom).cursor.top+22*bits ≤ PoolCalls.capacity
        omega
      obtain ⟨tail⟩:=ih next nextBound nextRoom
      let front:=iterationEvents code lib f stepRoom
      have nle:=iteration_nats_le f stepRoom
      refine ⟨{
        finish:=tail.finish
        events:=front++tail.events
        unique:=?_
        bounds:=?_
        nats_le:=nle.trans tail.nats_le
        execution:=?_
        stopped:=tail.stopped
        value:=tail.value.trans (iteration_value f stepRoom)
        top_le:=?_
        shape:=?_
        borrows:=?_
        globals:=tail.globals.trans (iteration_globals f stepRoom)
        slots:=?_
        other:=?_
      }⟩
      · rw[List.map_append,List.nodup_append]
        refine ⟨iteration_event_unique code lib f stepRoom,tail.unique,?_⟩
        intro a ha b hb same
        obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
        obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
        have left:=iteration_event_bounds code lib f stepRoom ea hea
        have right:=tail.bounds eb heb
        dsimp only[next] at right
        omega
      · intro e member
        rcases List.mem_append.mp member with left | right
        · have h:=iteration_event_bounds code lib f stepRoom e left
          exact ⟨h.1,Nat.lt_of_lt_of_le h.2 tail.nats_le⟩
        · have h:=tail.bounds e right
          exact ⟨nle.trans h.1,h.2⟩
      · intro service answers
        apply Loops.WhileRun.next (condition_eval service f)
          (by simp [UnsignedLiteralControl.truth_boolean];omega)
          (iteration_event_run code lib f stepRoom service (fun e h=>answers e (List.mem_append_left _ h)))
        exact tail.execution service (fun e h=>answers e (List.mem_append_right _ h))
      · have h:=iteration_top_le f stepRoom
        have t:=tail.top_le
        dsimp only[next] at t
        change tail.finish.cursor.top ≤ f.cursor.top+22*(bits+1)
        omega
      · have h:=iteration_shape f stepRoom
        exact ⟨tail.shape.1.trans h.1,tail.shape.2.trans h.2⟩
      · intro slot n live
        exact tail.borrows slot n (iteration_preserves_nat f stepRoom live)
      · have step:=iteration_slots f stepRoom
        exact ⟨tail.slots.1.trans step.1,tail.slots.2.1.trans step.2.1,tail.slots.2.2.trans step.2.2⟩
      · intro slot pa pn pr hp ht hh
        have step:=iteration_slots f stepRoom
        have preserved:=tail.other slot (by rw[step.1];exact pa) (by rw[step.2.1];exact pn)
          (by rw[step.2.2];exact pr) hp ht hh
        exact preserved.trans (iteration_other f stepRoom slot pa pn pr hp ht hh)

end ScopedC.RationalPowerCalls
