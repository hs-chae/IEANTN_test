/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientAtanhData
import ScopedC.RationalPowerCounter

namespace ScopedC.PrepareSource.CoeffWork
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] oddInput

def atanhRhs : Expr := .conditional (.binary "==" (.binary "%" (.var "k") (.nat 2)) (.nat 1))
  (.call (.var "qv") [.call (.var "qi") [.nat 1],.call (.var "qi") [.var "k"]])
  (.call (.var "qi") [.nat 0])
def atanhAssignment : Expr := .binary "=" (.index (.var "atanhCoeffs") (.var "k")) atanhRhs

theorem parity_source (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (bound : w.k<2^32) :
    evalExpr Header.layout service 5 w.cursor.state
      (.binary "==" (.binary "%" (.var "k") (.nat 2)) (.nat 1))=
      some (boolean Header.layout (decide (w.k%2=1)),w.cursor.state) :=
  ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (ExpressionTemplates.binary Header.layout service
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (LocalBinding.eval service 2 w.kAt (by decide +kernel) (by decide +kernel)
        (by decide +kernel) (by decide +kernel)) (by rfl)
      (RationalPowerCounter.remainder w.cursor.state w.k bound)) (by rfl)
    (RationalPowerCounter.parity_one w.cursor.state w.k)

noncomputable def oddStored {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) : CoeffWork l object d eb ab :=
  (w.oddWork room positive).storeAtanh (w.oddInput room) (w.oddInput_live room positive)
    (w.oddInput_positive room) bound

noncomputable def evenStored {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+2<PoolCalls.capacity)
    (bound : w.atanhCoeffs.length<65) : CoeffWork l object d eb ab :=
  (w.qiWork 0 room).storeAtanh (w.qiInput 0) (RationalUnsignedTrace.live l w.cursor 0)
    (by change 0<(1:Nat);decide +kernel) bound

theorem atanh_store_source (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (before : State) (rhs : Expr)
    (q : RationalPairFrames.Input) (alive : q.Live w.cursor.state) (positive : 0<q.denominator)
    (length : w.atanhCoeffs.length=w.k) (bound : w.atanhCoeffs.length<65)
    (right : evalExpr Header.layout service 6 before rhs=some (q.source,w.cursor.state)) :
    Eval Header.layout service (.binary "=" (.index (.var "atanhCoeffs") (.var "k")) rhs)
      before (w.storeAtanh q alive positive bound).cursor.state q.source := by
  refine ⟨7,?_⟩
  exact CoefficientTableRead.source_assignment service 4 w.atanhAt q right
    (CoefficientTableRead.eval_global service 4 w.atanhAt w.atanhLookup w.atanhUnshadowed
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (LocalBinding.eval service 4 w.kAt
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (by change some w.k=some w.atanhCoeffs.length;rw[length])
    (by rw[w.atanhExtent];exact bound) alive

theorem odd_assignment (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (length : w.atanhCoeffs.length=w.k) (bound : w.atanhCoeffs.length<65) (kb : w.k<2^32)
    (odd : w.k%2=1)
    (one : service "qi" [DecimalDigits.integer 1] w.cursor.state=
      some ((w.qiInput 1).source,(w.oddOne room).cursor.state))
    (counter : service "qi" [PoolCalls.word w.k] (w.oddOne room).cursor.state=
      some (((w.oddOne room).qiInput w.k).source,(w.oddCounter room).cursor.state))
    (divide : service "qv" [(w.qiInput 1).source,((w.oddOne room).qiInput w.k).source]
      (w.oddCounter room).cursor.state=
      some ((w.oddInput room).source,(w.oddWork room positive).cursor.state)) :
    Eval Header.layout service atanhAssignment w.cursor.state
      (w.oddStored room positive bound).cursor.state (w.oddInput room).source := by
  have rhs : evalExpr Header.layout service 6 w.cursor.state atanhRhs=
      some ((w.oddInput room).source,(w.oddWork room positive).cursor.state) := by
    apply ExpressionTemplates.conditional Header.layout service (parity_source service w kb)
    simpa only[UnsignedLiteralControl.truth_boolean,odd,decide_true,↓reduceIte] using
      (ExpressionTemplates.call_two Header.layout service
        (ExpressionTemplates.call_one Header.layout service
          (show evalExpr Header.layout service 3 w.cursor.state (.nat 1)=
            some (DecimalDigits.integer 1,w.cursor.state) from rfl) one)
        (ExpressionTemplates.call_one Header.layout service
          (LocalBinding.eval service 2 (w.oddOne room).kAt (by decide +kernel)
            (by decide +kernel) (by decide +kernel) (by decide +kernel)) counter) divide)
  have execution:=atanh_store_source service (w.oddWork room positive) w.cursor.state atanhRhs
    (w.oddInput room) (w.oddInput_live room positive) (w.oddInput_positive room) length bound rhs
  simpa only[atanhAssignment,oddStored] using execution

theorem even_assignment (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+2<PoolCalls.capacity)
    (length : w.atanhCoeffs.length=w.k) (bound : w.atanhCoeffs.length<65) (kb : w.k<2^32)
    (even : w.k%2≠1)
    (zero : service "qi" [DecimalDigits.integer 0] w.cursor.state=
      some ((w.qiInput 0).source,(w.qiWork 0 room).cursor.state)) :
    Eval Header.layout service atanhAssignment w.cursor.state
      (w.evenStored room bound).cursor.state (w.qiInput 0).source := by
  have rhs : evalExpr Header.layout service 6 w.cursor.state atanhRhs=
      some ((w.qiInput 0).source,(w.qiWork 0 room).cursor.state) := by
    apply ExpressionTemplates.conditional Header.layout service (parity_source service w kb)
    simpa only[UnsignedLiteralControl.truth_boolean,even,decide_false,Bool.false_eq_true,↓reduceIte] using
      (ExpressionTemplates.call_one Header.layout service
        (show evalExpr Header.layout service 4 w.cursor.state (.nat 0)=
          some (DecimalDigits.integer 0,w.cursor.state) from rfl) zero)
  exact atanh_store_source service (w.qiWork 0 room) w.cursor.state atanhRhs (w.qiInput 0)
    (RationalUnsignedTrace.live l w.cursor 0) (by change 0<(1:Nat);decide +kernel) length bound rhs

end ScopedC.PrepareSource.CoeffWork
