/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhWideExpression

namespace ScopedC.AtanhCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard wideC1 wideC2 wideFinish

theorem afterR_size (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterR l c q).state.nats.values.length=c.state.nats.values.length+1 := by
  change (next l (parameters c q) 0).state.nats.values.length=_
  rw[PoolCursor.size]
  rfl

theorem guard_size (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterGuard l c q).state.nats.values.length=c.state.nats.values.length+10 := by
  rw[guard_trace,CursorEffects.size,afterR_size]
  rfl

theorem wideC1_size (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (wideC1 l c q).state.nats.values.length=c.state.nats.values.length+13 := by
  unfold wideC1
  change (CursorFrames.advance l (afterGuard l c q) [1000,0,1]).state.nats.values.length=_
  rw[CursorEffects.size,guard_size]
  rfl

theorem wideC2_size (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (wideC2 l c q).state.nats.values.length=c.state.nats.values.length+14 := by
  unfold wideC2
  rw[PoolCursor.size,wideC1_size]

theorem wideFinish_size (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (wideFinish l c q).state.nats.values.length=c.state.nats.values.length+17 := by
  unfold wideFinish
  change (CursorFrames.advance l (wideC2 l c q) [1000,0,1]).state.nats.values.length=_
  rw[CursorEffects.size,wideC2_size]
  rfl

theorem afterR_heap (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterR l c q).state.heap.length=c.state.heap.length+2 := by
  change ((afterAbs l c q).state.heap++[_]).length=_
  rw[List.length_append,List.length_singleton]
  have before : (afterAbs l c q).state.heap.length=c.state.heap.length+1 :=
    (PoolCursor.shape l (parameters c q) 0).1.trans (by
      simp [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate])
  rw[before]

theorem guard_heap (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterGuard l c q).state.heap.length=c.state.heap.length+2 := by
  rw[guard_trace,(CursorEffects.shape l (afterR l c q) (guardValues l c q)).1,afterR_heap]

theorem wideFinish_heap (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (wideFinish l c q).state.heap.length=c.state.heap.length+2 := by
  unfold wideFinish
  change (CursorFrames.advance l (wideC2 l c q) [1000,0,1]).state.heap.length=_
  rw[(CursorEffects.shape l (wideC2 l c q) [1000,0,1]).1]
  unfold wideC2
  rw[(PoolCursor.shape l (wideC1 l c q) 0).1]
  unfold wideC1
  change (CursorFrames.advance l (afterGuard l c q) [1000,0,1]).state.heap.length=_
  rw[(CursorEffects.shape l (afterGuard l c q) [1000,0,1]).1,guard_heap]

end ScopedC.AtanhCalls
