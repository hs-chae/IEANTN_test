/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSubFraming

namespace ScopedC.RationalSubCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem output_exists (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) :
    ∃q : Input,q.source=result l c a b ∧ q.Live (after l c a b).state ∧
      q.mathematical.value=a.mathematical.value-b.mathematical.value ∧ 0<q.denominator := by
  obtain ⟨q,source,live,mathematical,positive⟩:=
    NumericInputCompleteness.rational (decoded l c a b pa pb)
  refine ⟨q,source,live,?_,positive⟩
  rw[mathematical]
  exact value l c a b pa pb

/-- Proof metadata for the actual source-produced and decoded rational record. -/
noncomputable def outputInput (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) : Input :=
  Classical.choose (output_exists l c a b pa pb)

theorem output_spec (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) :
    (outputInput l c a b pa pb).source=result l c a b ∧
      (outputInput l c a b pa pb).Live (after l c a b).state ∧
      (outputInput l c a b pa pb).mathematical.value=a.mathematical.value-b.mathematical.value ∧
      0<(outputInput l c a b pa pb).denominator :=
  Classical.choose_spec (output_exists l c a b pa pb)

theorem output_source (code : List Function) (installed : Generated.f_qs∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+14<PoolCalls.capacity) (a b : Input)
    (alive : a.Live c.state) (blive : b.Live c.state)
    (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 7 "qs" [a.source,b.source] c.state
      (outputInput l c a b pa pb).source (after l c a b).state := by
  rw[(output_spec l c a b pa pb).1]
  exact qs_closed code installed lib ctx room a b alive blive pa pb

end ScopedC.RationalSubCalls
