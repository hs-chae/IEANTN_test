/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceScalarGlobal
import ScopedC.SourceScaleFrames

namespace ScopedC.SourceScalarGlobal
open ScopedC.Machine
set_option autoImplicit false

theorem unframe {s : State} (before : State) {name type : String} {object : Nat} {value : Option Value}
    (h : At s name type object value) (old : object<before.heap.length) :
    At (popScope before s) name type object value :=
  memory h rfl (List.getElem?_take_of_lt old)

end ScopedC.SourceScalarGlobal
namespace ScopedC.SourceUnsignedGlobal
open ScopedC.Machine
set_option autoImplicit false

theorem unframe {s : State} (before : State) {name : String} {object n : Nat}
    (h : At s name object n) (old : object<before.heap.length) : At (popScope before s) name object n :=
  memory h rfl (List.getElem?_take_of_lt old)

end ScopedC.SourceUnsignedGlobal
namespace ScopedC.CoefficientTableRead
open ScopedC.Machine
set_option autoImplicit false

def unframe {s : State} (before : State) {base : Address} {coeffs : List RationalPairFrames.Input}
    (table : TableAt s base coeffs) (old : base.object<before.heap.length) :
    TableAt (popScope before s) base coeffs :=
  memory table (List.getElem?_take_of_lt old) (fun _ _ h=>h)

end ScopedC.CoefficientTableRead
namespace ScopedC.SourceFromS.ScaleAt
open ScopedC.Machine
set_option autoImplicit false

theorem unframe {s : State} (before : State) {object slot value : Nat}
    (h : SourceFromS.ScaleAt s object slot value) (old : object<before.heap.length) :
    SourceFromS.ScaleAt (popScope before s) object slot value :=
  ⟨h.lookup,(List.getElem?_take_of_lt old).trans h.storage,h.live⟩

end ScopedC.SourceFromS.ScaleAt
