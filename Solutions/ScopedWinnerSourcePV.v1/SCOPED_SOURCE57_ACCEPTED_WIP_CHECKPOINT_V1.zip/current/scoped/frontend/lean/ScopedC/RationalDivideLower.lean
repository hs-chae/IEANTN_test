/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalDivideData

namespace ScopedC.RationalDivideCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  mul : RationalMultiplyCalls.Library code
  qt : Generated.f_qt∈code
  qi : Generated.f_qi∈code
  si : Generated.f_si∈code

theorem test_call (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) (hb : b.Live c.state) :
    SourceCall Header.layout code 3 "nz" [.natObject b.numerator.slot] (base c a b).state
      (PrimitiveCalls.u32 (b.numerator.magnitude==0)) (tested l c a b).state :=
  NatWrapperCalls.nz_call code lib.mul.nz lib.mul.nu lib.mul.ne lib.mul.keep
    (base_context ctx a b) (by change c.top<PoolCalls.capacity;omega) hb.1

theorem zero_call (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) :
    SourceCall Header.layout code 6 "qi" [SignedCompareCalls.integer 0] (tested l c a b).state
      (zeroInput l c a b).source (zeroEnd l c a b).state := by
  exact RationalUnsignedCalls.qi_call code lib.qi lib.si lib.mul.smake lib.mul.nz lib.mul.nu lib.mul.ne lib.mul.keep
    (tested_context ctx room a b) (by change c.top+1+2<PoolCalls.capacity;omega) (by decide +kernel) (by rfl)

theorem inverse_call (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) (hb : b.Live c.state) (pb : 0<b.denominator) :
    SourceCall Header.layout code 4 "smake" [.natObject b.denSlot,unsigned32 (SignedNegCalls.bit b.numerator.negative)]
      (tested l c a b).state (inverse b).numerator.source (made l c a b).state := by
  have h := ArithmeticCursorCalls.smake code lib.mul.smake lib.mul.nz lib.mul.nu lib.mul.ne lib.mul.keep
    (tested_context ctx room a b) (by change c.top+1<PoolCalls.capacity;omega) b.numerator.negative
    (PoolCursor.preserves (l:=l) (c:=base c a b) (n:=0) hb.2)
  simpa only[ArithmeticCursorCalls.normal,inverse,made,if_neg (Nat.ne_of_gt pb)]using h

theorem product_call (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator)
    (nonzero : b.numerator.magnitude≠0) :
    SourceCall Header.layout code 6 "qt" [a.source,(inverse b).source] (inverseCursor l c a b).state
      (nonzeroResult l c a b) (productEnd l c a b).state := by
  have ah1 := Input.live_after (l:=l) (c:=base c a b) (n:=0) ha
  have ah2 := Input.live_after (l:=l) (c:=tested l c a b) (n:=0) ah1
  have bh1 := Input.live_after (l:=l) (c:=base c a b) (n:=0) hb
  have bh2 := Input.live_after (l:=l) (c:=tested l c a b) (n:=0) bh1
  rw[productEnd]
  exact RationalMultiplyCalls.qt_closed code lib.qt lib.mul (inverse_context ctx room a b)
    (by change c.top+1+1+10<PoolCalls.capacity;omega) a (inverse b) ah2 (inverse_live bh2) pa (Nat.pos_of_ne_zero nonzero)

def nonzeroInput (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Input :=
  ⟨RationalMultiplyCalls.top l (inverseCursor l c a b) a (inverse b),
   (RationalMultiplyCalls.c10 l (inverseCursor l c a b) a (inverse b)).state.nats.values.length,
   RationalMultiplyCalls.den a (inverse b)⟩

theorem live_of_nats {s t : State} {q : Input} (h : s.nats=t.nats) (hq : q.Live s) : q.Live t := by
  cases s
  cases t
  cases h
  exact hq

theorem nonzero_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (nonzeroInput l c a b).Live (bodyEnd l c a b).state := by
  apply live_of_nats (s:=(RationalMultiplyCalls.c11 l (inverseCursor l c a b) a (inverse b)).state)
  · unfold bodyEnd PoolContextPop.unframe productEnd
    rfl
  · exact RationalMultiplyCalls.result_live l (inverseCursor l c a b) a (inverse b)

end ScopedC.RationalDivideCalls
