/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientSeed

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

theorem initExp_cells {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) :
    (initExpTable s).cells=s.expAt.cells.set 0 (some (initOne s).source) := rfl

theorem initExp_extent {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) : (initExpTable s).cells.length=65 := by
  rw[initExp_cells,List.length_set,s.expExtent]

theorem initZeroExp_extent {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    (initZeroExpTable s room).cells.length=65 := by
  unfold initZeroExpTable
  rw[CoefficientTableRead.advanced_cells,initExp_extent]

theorem initZeroAtanh_extent {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    (initZeroAtanhTable s room).cells.length=65 := by
  change s.atanhAt.cells.length=65
  exact s.atanhExtent

def initAtanhTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    CoefficientTableRead.TableAt (initAtanhCursor s room).state ab [initZero s] := by
  unfold initAtanhCursor
  exact CoefficientTableRead.append (initZeroAtanhTable s room) (initZero s)
    (RationalUnsignedTrace.live l (initExpCursor s) 0) (by change 0<(1:Nat);decide +kernel)
    (by rw[initZeroAtanh_extent];decide +kernel)

def initAtanhExpTable {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    CoefficientTableRead.TableAt (initAtanhCursor s room).state eb [initOne s] := by
  unfold initAtanhCursor
  exact CoefficientTableRead.other_table (initZeroAtanhTable s room) (initZeroExpTable s room)
    (Ne.symm s.arraysApart) 0 (initZero s)

theorem initAtanh_valid {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    Valid l (initAtanhCursor s room) := by
  unfold initAtanhCursor
  exact CoefficientTableRead.valid (initZero_valid s room) (initZeroAtanhTable s room) 0 (initZero s)

theorem initAtanh_exp_extent {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    (initAtanhExpTable s room).cells.length=65 := by
  change (s.expAt.cells.set 0 (some (initOne s).source)).length=65
  rw[List.length_set,s.expExtent]

theorem initAtanh_atanh_extent {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    (initAtanhTable s room).cells.length=65 := by
  change (s.atanhAt.cells.set 0 (some (initZero s).source)).length=65
  rw[List.length_set,s.atanhExtent]

theorem initAtanh_globals {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    (initAtanhCursor s room).state.globals=s.cursor.state.globals := by
  unfold initAtanhCursor
  change (CursorFrames.advance l (initExpCursor s) [0,0,1]).state.globals=s.cursor.state.globals
  rw[CursorSingleFrames.advance_globals]
  unfold initExpCursor
  change (initOneCursor s).state.globals=_
  exact CursorSingleFrames.advance_globals l s.cursor [1,0,1]

theorem initAtanh_env {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    (initAtanhCursor s room).state.env=s.cursor.state.env := by
  unfold initAtanhCursor
  change (CursorFrames.advance l (initExpCursor s) [0,0,1]).state.env=s.cursor.state.env
  rw[(CursorEffects.shape l (initExpCursor s) [0,0,1]).2]
  unfold initExpCursor
  change (initOneCursor s).state.env=_
  exact (CursorEffects.shape l s.cursor [1,0,1]).2

theorem initAtanh_depth {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    SourceUnsignedGlobal.At (initAtanhCursor s room).state "depth" object d := by
  have first : SourceUnsignedGlobal.At (initOneCursor s).state "depth" object d :=
    SourceUnsignedGlobal.advanced s.depthAt [1,0,1] s.depthApart.1 s.depthApart.2.1 s.depthApart.2.2
  have stored : SourceUnsignedGlobal.At (initExpCursor s).state "depth" object d := by
    unfold initExpCursor
    exact CoefficientTableRead.changed_depth (initExpBefore s) 0 (initOne s) first
  have zero : SourceUnsignedGlobal.At (initZeroCursor s).state "depth" object d :=
    SourceUnsignedGlobal.advanced stored [0,0,1] s.depthApart.1 s.depthApart.2.1 s.depthApart.2.2
  unfold initAtanhCursor
  exact CoefficientTableRead.changed_depth (initZeroAtanhTable s room) 0 (initZero s) zero

end ScopedC.PrepareSource
