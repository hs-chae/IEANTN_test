/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerBody

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def finishCursor {l : PoolCalls.PoolLayout} (c : Cursor) (a : Input) (n : Nat) (finish : Frame l) : Cursor :=
  PoolContextPop.unframe c.state (PoolContextPop.unframe (parameters c a n).state finish.cursor)

/-- The same complete source composition, with the exact output cursor
exposed so additional physical loop properties can be exported without
altering the accepted original qpow body/value theorem. -/
theorem compose_trace (code : List Function) (installed : Generated.f_qpow∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+2<PoolCalls.capacity)
    (a : Input) (n : Nat) (ha : a.Live c.state) (hn : n<2^32)
    (f : Frame l) (fc : f.cursor=loopStart l c a n) (fa : f.current=a)
    (fr : f.accumulator=oneQ l (parameters c a n)) (fn : f.exponent=n)
    (trace : LoopCertificate code f 32) :
    SourceCall Header.layout code 7 "qpow" [a.source,PoolCalls.word n] c.state
      trace.finish.accumulator.source (finishCursor c a n trace.finish).state ∧
    Valid l (finishCursor c a n trace.finish) ∧
    trace.finish.accumulator.Live (finishCursor c a n trace.finish).state ∧
    0<trace.finish.accumulator.denominator ∧
    trace.finish.accumulator.mathematical.value=a.mathematical.value^n ∧
    (finishCursor c a n trace.finish).top ≤ c.top+707 := by
  let e0 : Event code:=⟨"qi",[DecimalDigits.integer 1],(parameters c a n).state,
    (oneQ l (parameters c a n)).source,(oneCursor l (parameters c a n)).state,
    initialization_call code lib ctx (by omega) a n⟩
  have initialSize : f.cursor.state.nats.values.length=c.state.nats.values.length+3 := by rw[fc,loopStart_size]
  have unique : ((e0::trace.events).map CallEvents.timeKey).Nodup := by
    rw[List.map_cons,List.nodup_cons]
    refine ⟨?_,trace.unique⟩
    intro member
    obtain ⟨e,he,key⟩:=List.mem_map.mp member
    have h:=trace.bounds e he
    have first : CallEvents.timeKey e0=c.state.nats.values.length := rfl
    omega
  obtain ⟨service,answers,closed⟩:=CallEvents.timeline_service (e0::trace.events) unique
  have initialization:=initialization_declaration service l c a n (answers e0 (List.mem_cons_self))
  have loop : While service f.cursor.state (.continuing trace.finish.cursor.state) :=
    trace.execution service (fun e h=>answers e (List.mem_cons_of_mem e0 h))
  have returned : Eval Header.layout service (.var "result") trace.finish.cursor.state trace.finish.cursor.state
      trace.finish.accumulator.source :=
    ⟨2,LocalBinding.eval service 1 trace.finish.rAt (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)⟩
  let bodyExit:=PoolContextPop.unframe (parameters c a n).state trace.finish.cursor
  let finalCursor:=PoolContextPop.unframe c.state bodyExit
  have bodyLive : trace.finish.accumulator.Live bodyExit.state := trace.finish.rLive
  have finalLive : trace.finish.accumulator.Live finalCursor.state := trace.finish.rLive
  have body : Run Header.layout service Generated.f_qpow.body (parameters c a n).state
      (.returned bodyExit.state trace.finish.accumulator.source) := by
    apply Loops.StmtRun.sequence
      (Loops.SeqRun.next (Loops.StmtRun.declare initialization)
        (Loops.SeqRun.next (Loops.StmtRun.whileLoop (by simpa only[fc,While,condition,loopBody,oddStatement,remainingStatement,accumulatorStatement,halfStatement,squareStatement,oddCondition] using loop))
          (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned))))
    exact ⟨rfl,rfl⟩
  have execution : SourceCall Header.layout code 7 "qpow" [a.source,PoolCalls.word n] c.state
      trace.finish.accumulator.source finalCursor.state := by
    apply installed_body (f:=Generated.f_qpow) (rank:=6) (service:=service) installed closed
      (bind_parameters c a n ha hn) body
    exact ⟨Input.cast "static Q" (by decide +kernel) bodyLive,rfl⟩
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have bodyContext : Valid l bodyExit :=
    PoolContextPop.valid trace.finish.context (by rw[parameters_length];omega)
      (by rw[parameters_length];omega) (by rw[parameters_length];omega)
  have finalContext : Valid l finalCursor:=PoolContextPop.valid bodyContext hp ht hh
  refine ⟨execution,finalContext,finalLive,trace.finish.rPositive,?_,?_⟩
  · have value:=trace.value
    rw[trace.stopped,pow_zero,mul_one,fr,fa,fn,one_value,one_mul] at value
    exact value
  · have h:=trace.top_le
    rw[fc,loopStart_top] at h
    change trace.finish.cursor.top ≤ c.top+707
    omega


end ScopedC.RationalPowerCalls
