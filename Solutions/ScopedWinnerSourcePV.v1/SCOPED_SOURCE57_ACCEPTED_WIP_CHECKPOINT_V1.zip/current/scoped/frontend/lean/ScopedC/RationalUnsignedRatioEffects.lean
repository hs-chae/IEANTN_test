/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalRecordEffects
import ScopedC.RationalUnsignedRatio
namespace ScopedC.RationalUnsignedRatio
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem num_valid {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (n : Nat) (room : c.top+3≤capacity) : Valid l (numerator l c n) :=
  CursorFrames.advance_valid ctx [n,0,1] room

theorem den_valid {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (n d : Nat) (room : c.top+6≤capacity) : Valid l (denominator l c n d) := by
  apply CursorFrames.advance_valid (num_valid ctx n (by omega)) [d,0,1]
  change c.top+3+3≤capacity
  omega

theorem record {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (n d : Nat) (room : c.top+18<capacity)
    {lo hi : Value} {slot : Nat} (h : RationalRecordFields.At c.state lo hi slot) :
    RationalRecordFields.At (after l c n d).state lo hi slot := by
  have first := RationalRecordFields.advance ctx h [n,0,1]
  change RationalRecordFields.At (numerator l c n).state lo hi slot at first
  have second := RationalRecordFields.advance (num_valid ctx n (by omega)) first [d,0,1]
  change RationalRecordFields.At (denominator l c n d).state lo hi slot at second
  unfold after
  rw [RationalDivideTrace.after_advance (den_valid ctx n d (by omega))
    (by change c.top+3+3+12<capacity;omega)]
  exact RationalRecordFields.advance (den_valid ctx n d (by omega)) second _

theorem preserves_nat {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (n d : Nat) (room : c.top+18<capacity) {slot value : Nat}
    (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (after l c n d).state.nats slot value := by
  have first := CursorBorrow.preserves (l:=l) [n,0,1] h
  have second := CursorBorrow.preserves (l:=l) [d,0,1] first
  exact RationalDivideTrace.preserves_nat (den_valid ctx n d (by omega))
    (by change c.top+3+3+12<capacity;omega) _ _ second

theorem scale {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (n d : Nat) (room : c.top+18<capacity) {object slot value : Nat}
    (h : SourceFromS.ScaleAt c.state object slot value) :
    SourceFromS.ScaleAt (after l c n d).state object slot value := by
  have first := SourceScaleFrames.advance ctx h [n,0,1]
  have second := SourceScaleFrames.advance (num_valid ctx n (by omega)) first [d,0,1]
  unfold after
  rw [RationalDivideTrace.after_advance (den_valid ctx n d (by omega))
    (by change c.top+3+3+12<capacity;omega)]
  exact SourceScaleFrames.advance (den_valid ctx n d (by omega)) second _

theorem top_bound {l : PoolLayout} {c : Cursor} (ctx : Valid l c)
    (n d : Nat) (room : c.top+18<capacity) : (after l c n d).top≤c.top+19 := by
  unfold after
  rw [RationalDivideTrace.after_advance (den_valid ctx n d (by omega))
    (by change c.top+3+3+12<capacity;omega),CursorFrames.top_advance]
  have length := RationalDivideTrace.length l (denominator l c n d)
    (numInput l c n) (denInput l c n d)
  change c.top+3+3+_≤c.top+19
  omega

end ScopedC.RationalUnsignedRatio
