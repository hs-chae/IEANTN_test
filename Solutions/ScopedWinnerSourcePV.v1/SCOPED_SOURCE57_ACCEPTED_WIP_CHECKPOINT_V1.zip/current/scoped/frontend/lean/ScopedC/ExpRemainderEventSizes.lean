/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderErrorEffects

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax

theorem afterLo_size (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    (afterLo l c a).state.nats.values.length=c.state.nats.values.length+1 := by
  change (next l (parameters c a) 0).state.nats.values.length=_
  rw[PoolCursor.size]
  rfl

theorem afterHi_size (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    (afterHi l c a).state.nats.values.length=c.state.nats.values.length+2 := by
  change (next l (afterLo l c a) 0).state.nats.values.length=_
  rw[PoolCursor.size,afterLo_size]

theorem afterR_size (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    (afterR l c a).state.nats.values.length=c.state.nats.values.length+8 := by
  change (afterMax l c a).state.nats.values.length=_
  rw[afterMax_trace,CursorEffects.size]
  rfl

theorem ceil_size {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (ceil : CeilStage code l c a) :
    ceil.out.state.nats.values.length=c.state.nats.values.length+8+ceil.values.length := by
  rw[ceil.trace,CursorEffects.size,afterR_size]

theorem afterC_size {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (ceil : CeilStage code l c a) :
    (afterC ceil).state.nats.values.length=ceil.out.state.nats.values.length+1 := by
  change (next l (afterCeil ceil) 4294967295).state.nats.values.length=_
  rw[PoolCursor.size]
  rfl

theorem factorial_start_size {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) :
    f.start.cursor.state.nats.values.length=ceil.out.state.nats.values.length+4 := by
  rw[f.cursor]
  change (CursorFrames.advance l (afterC ceil) [1,0,1]).state.nats.values.length=_
  rw[CursorEffects.size,afterC_size]
  rfl

theorem afterThree_size {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) :
    (afterThree f).state.nats.values.length=(BeforeError f).state.nats.values.length+3 := by
  change (CursorFrames.advance l (BeforeError f) [3,0,1]).state.nats.values.length=_
  rw[CursorEffects.size]
  rfl

theorem numerator_size {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (numeratorCursor r).state.nats.values.length=r.out.state.nats.values.length+11 := by
  unfold numeratorCursor
  rw[RationalMultiplyTrace.c11_advance,CursorEffects.size]
  rfl

theorem error_arena_lower {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (BeforeError f).state.nats.values.length ≤ (errorCursor r).state.nats.values.length := by
  have den : NatArena.Borrow (afterThree f).state.nats (three f).denSlot 1 :=
    (RationalUnsignedTrace.live l (BeforeError f) 3).2
  have slot : (three f).denSlot=(BeforeError f).state.nats.values.length+2 := by
    change (next l (next l (BeforeError f) 3) 0).state.nats.values.length=_
    rw[PoolCursor.size,PoolCursor.size]
  rw[slot] at den
  have kept:=error_borrow r (r.preserves _ _ (p.preserves _ _ den))
  have bound:=(List.getElem?_eq_some_iff.mp kept.1).choose
  omega

end ScopedC.ExpRemainderCalls
