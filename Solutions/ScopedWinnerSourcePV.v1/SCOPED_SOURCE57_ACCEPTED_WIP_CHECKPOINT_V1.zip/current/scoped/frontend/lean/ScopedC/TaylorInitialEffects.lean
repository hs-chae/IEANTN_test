/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorEntryFrame
import ScopedC.CursorSingleFrames

namespace ScopedC.TaylorCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem initial_globals (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address)
    (a : Pair) (d : Nat) : (loopStart l c base a d).state.globals=c.state.globals := by
  change (CursorFrames.advance l (parameters c base a) [0,0,1]).state.globals=_
  rw[CursorSingleFrames.advance_globals]
  rfl

theorem initial_borrow (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address)
    (a : Pair) (d : Nat) {slot value : Nat} (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (loopStart l c base a d).state.nats slot value :=
  CursorBorrow.preserves (l:=l) (c:=parameters c base a) [0,0,1] live

theorem initial_other (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address)
    (a : Pair) (d slot : Nat) (old : slot<c.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (loopStart l c base a d).state.heap[slot]?=c.state.heap[slot]? := by
  change (((afterZero l c base a).state.heap++[_])++[_])[slot]?=_
  rw[List.getElem?_append_left (by rw[List.length_append,List.length_singleton,
    (zero_shape l c base a).1,parameters_length];omega),
    List.getElem?_append_left (by rw[(zero_shape l c base a).1,parameters_length];omega)]
  change (CursorFrames.advance l (parameters c base a) [0,0,1]).state.heap[slot]?=_
  rw[CursorSingleFrames.advance_other l (parameters c base a) [0,0,1] slot hp ht hh]
  simp [parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.getElem?_append_left old]

theorem initial_lookups (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address)
    (a : Pair) (d : Nat) :
    (loopStart l c base a d).state.env.lookup "k"=some ⟨c.state.heap.length+3,0,[]⟩ ∧
      (loopStart l c base a d).state.env.lookup "result"=some ⟨c.state.heap.length+2,0,[]⟩ := by
  constructor
  · simp only[loopStart,CursorLocals.allocated,allocate,List.lookup]
    rw[stored_length]
    rfl
  · simp only[loopStart,stored,CursorLocals.allocated,allocate,List.lookup]
    rw[(zero_shape l c base a).1,parameters_length]
    rfl

theorem initial_slots {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (c : Cursor) (a : Pair) (d : Nat) (f : Frame l base coeffs)
    (fc : f.cursor=loopStart l c base a d) :
    f.kSlot=c.state.heap.length+3 ∧ f.rSlot=c.state.heap.length+2 := by
  have actual:=initial_lookups l c base a d
  have k:=f.kAt.lookup
  have r:=f.rAt.lookup
  rw[fc] at k r
  exact ⟨congrArg Address.object (Option.some.inj (k.symm.trans actual.1)),
    congrArg Address.object (Option.some.inj (r.symm.trans actual.2))⟩

end ScopedC.TaylorCalls
