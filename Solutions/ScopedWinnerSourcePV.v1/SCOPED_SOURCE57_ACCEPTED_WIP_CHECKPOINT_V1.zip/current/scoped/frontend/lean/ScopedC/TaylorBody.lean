/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorLoop
import ScopedC.TaylorEntrySource

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

/-- Complete unchanged source Taylor evaluator. The initialized coefficient
table and real depth global are explicit application-state obligations; the
actual prepare source must establish them before a final producer claim.
Every numerical call here is discharged by its actual source-body proof. -/
theorem taylor_closed (code : List Function) (installed : Generated.f_taylor∈code) (lib : EntryLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {base : Address} {coeffs : List Input}
    (ctx : Valid l c) (table : CoefficientTableRead.TableAt c.state base coeffs)
    (a : Pair) (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (d object : Nat) (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (depthBound : d ≤ 64) (length : coeffs.length=d+1)
    (room : c.top+3+108*(d+1) ≤ PoolCalls.capacity) :
    ∃out : Cursor,∃q : Pair,
      SourceCall Header.layout code 9 "taylor" [.pointer base false,a.source] c.state q.source out.state ∧
      Valid l out ∧ q.Live out.state ∧ q.Positive ∧
      NumericRepresentation.interval out.state q.source=some
        (LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues coeffs) ⟨a.lo.mathematical.value,a.hi.mathematical.value,order⟩) ∧
      out.top ≤ c.top+3+108*(d+1) := by
  have bound : d+1<2^32 := by omega
  have room3 : c.top+2<PoolCalls.capacity := by omega
  obtain ⟨f,fc,fa,fr,fk⟩:=initial_frame ctx room3 table a alive positive order d length bound
  have invariant : mathematical f=LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop f.k)) (original f) := by
    have all : f.k=coeffs.length:=fk.trans length.symm
    rw[all,List.drop_length]
    change (⟨f.result.lo.mathematical.value,f.result.hi.mathematical.value,f.rOrder⟩:LeanCert.Core.IntervalRat)=⟨0,0,le_refl 0⟩
    rw[LeanCert.Core.IntervalRat.mk.injEq]
    constructor <;> simpa only[fr,zeroPair] using zero_value l c base a
  have loopRoom : f.cursor.top+108*(d+1) ≤ PoolCalls.capacity := by rw[fc,loop_top];exact room
  obtain ⟨trace⟩:=loop_certificate code lib.body (d+1) f fk invariant loopRoom
  let e0 : Event code:=⟨"qi",[DecimalDigits.integer 0],(parameters c base a).state,
    (zeroInput l c base a).source,(afterZero l c base a).state,
    raise_once (raise_once (zero_call code lib ctx room3 base a))⟩
  let e1 : Event code:=⟨"point",[(zeroInput l c base a).source],(afterZero l c base a).state,
    (zeroPair l c base a).source,(afterZero l c base a).state,
    raise_once (raise_once (raise_once (raise_once (raise_once (raise_once (raise_once (zero_point_call code lib l c base a)))))))⟩
  let initService:=CallEvents.append (CallEvents.one e0) (CallEvents.one e1)
  let loopService:=CallEvents.nameTimeline trace.events
  let service:=CallEvents.append initService loopService
  have closedInit : ∀name args before value after,initService name args before=some (value,after) →
      SourceCall Header.layout code 8 name args before value after := fun _ _ _ _ _ h=>
    CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e0 h)
      (fun _ _ _ _ _ h=>CallEvents.one_closed e1 h) h
  have closed : ∀name args before value after,service name args before=some (value,after) →
      SourceCall Header.layout code 8 name args before value after := fun _ _ _ _ _ h=>
    CallEvents.append_closed closedInit (fun _ _ _ _ _ h=>CallEvents.nameTimeline_closed trace.events h) h
  have answerQi : service "qi" [DecimalDigits.integer 0] (parameters c base a).state=
      some ((zeroInput l c base a).source,(afterZero l c base a).state) :=
    CallEvents.append_left (CallEvents.append_left (CallEvents.one_self e0))
  have answerPoint : service "point" [(zeroInput l c base a).source] (afterZero l c base a).state=
      some ((zeroPair l c base a).source,(afterZero l c base a).state) :=
    CallEvents.append_left (CallEvents.append_right (CallEvents.one_other e0 (by change ("point":String)≠"qi";decide +kernel) _ _) (CallEvents.one_self e1))
  have loopAnswers : EventAnswers service trace.events := by
    intro e member
    have shape:=trace.event_shape e member
    have loopLength : e.before.heap.length=c.state.heap.length+4 := shape.1.trans (by rw[fc,loop_length])
    have firstLength : e0.before.heap.length=c.state.heap.length+2:=parameters_length c base a
    have secondLength : e1.before.heap.length=c.state.heap.length+2:=
      (zero_shape l c base a).1.trans (parameters_length c base a)
    have firstDifferent : e.before≠e0.before := by
      intro same
      have h:=congrArg (fun s : State=>s.heap.length) same
      omega
    have secondDifferent : e.before≠e1.before := by
      intro same
      have h:=congrArg (fun s : State=>s.heap.length) same
      omega
    have firstNone:=one_start_ne e0 e.name e.args e.before firstDifferent
    have secondNone:=one_start_ne e1 e.name e.args e.before secondDifferent
    have initNone : initService e.name e.args e.before=none := by
      change CallEvents.append (CallEvents.one e0) (CallEvents.one e1) e.name e.args e.before=none
      unfold CallEvents.append
      rw[firstNone]
      exact secondNone
    exact CallEvents.append_right initNone (CallEvents.nameTimeline_self trace.events trace.unique e member)
  have declaration:=result_declaration service l c base a answerQi answerPoint
  have counter:=k_declaration service depth base a apart bound
  have loop : While service f.cursor.state (.continuing trace.finish.cursor.state):=trace.execution service loopAnswers
  have returned : Eval Header.layout service (.var "result") trace.finish.cursor.state trace.finish.cursor.state trace.finish.result.source :=
    ⟨2,LocalBinding.eval service 1 trace.finish.rAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)⟩
  let bodyExit:=PoolContextPop.unframe (parameters c base a).state trace.finish.cursor
  let finalCursor:=PoolContextPop.unframe c.state bodyExit
  have bodyLive : trace.finish.result.Live bodyExit.state:=trace.finish.rLive
  have finalLive : trace.finish.result.Live finalCursor.state:=trace.finish.rLive
  have body : Run Header.layout service Generated.f_taylor.body (parameters c base a).state (.returned bodyExit.state trace.finish.result.source) := by
    apply Loops.StmtRun.sequence
      (Loops.SeqRun.next (Loops.StmtRun.declare declaration)
        (Loops.SeqRun.next (Loops.StmtRun.declare counter)
          (Loops.SeqRun.next (Loops.StmtRun.whileLoop (by simpa only[fc,While,condition,loopBody,stepExpression] using loop))
            (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned)))))
    exact ⟨rfl,rfl⟩
  have execution : SourceCall Header.layout code 9 "taylor" [.pointer base false,a.source] c.state trace.finish.result.source finalCursor.state := by
    apply installed_body (f:=Generated.f_taylor) (rank:=8) (service:=service) installed closed
      (bind_parameters table (by rw[length];omega) a alive) body
    exact ⟨Pair.cast bodyLive "static RI" (by decide +kernel),rfl⟩
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have bodyContext : Valid l bodyExit:=PoolContextPop.valid trace.finish.context
    (by rw[parameters_length];omega) (by rw[parameters_length];omega) (by rw[parameters_length];omega)
  have finalContext : Valid l finalCursor:=PoolContextPop.valid bodyContext hp ht hh
  refine ⟨finalCursor,trace.finish.result,execution,finalContext,finalLive,trace.finish.rPositive,?_,?_⟩
  · have decoded:=NumericRationalIntervalAddRefinement.decoded_input finalLive trace.finish.rPositive trace.finish.rOrder
    have result:=decoded.trans (congrArg some trace.mathematical_eq)
    simpa only[original,fa] using result
  · have h:=trace.top_le
    rw[fc,loop_top,fk] at h
    exact h

end ScopedC.TaylorCalls
