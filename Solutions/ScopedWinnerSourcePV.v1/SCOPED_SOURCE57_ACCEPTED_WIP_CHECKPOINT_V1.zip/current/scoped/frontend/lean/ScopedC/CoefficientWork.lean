/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientExpTables

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

/-- Physical source resources during one coefficient iteration. Prefix lengths
and values are proved separately; no initialized output is assumed. -/
structure CoeffWork (l : PoolCalls.PoolLayout) (object d : Nat) (eb ab : Address) where
  cursor : Cursor
  expCoeffs : List Input
  atanhCoeffs : List Input
  k : Nat
  kSlot : Nat
  context : Valid l cursor
  expAt : CoefficientTableRead.TableAt cursor.state eb expCoeffs
  atanhAt : CoefficientTableRead.TableAt cursor.state ab atanhCoeffs
  expExtent : expAt.cells.length=65
  atanhExtent : atanhAt.cells.length=65
  expLookup : cursor.state.globals.lookup "expCoeffs"=some eb
  atanhLookup : cursor.state.globals.lookup "atanhCoeffs"=some ab
  expUnshadowed : cursor.state.env.lookup "expCoeffs"=none
  atanhUnshadowed : cursor.state.env.lookup "atanhCoeffs"=none
  depthAt : SourceUnsignedGlobal.At cursor.state "depth" object d
  depthUnshadowed : cursor.state.env.lookup "depth"=none
  kAt : LocalBinding.At cursor.state "k" "unsigned int" (PoolCalls.word k) kSlot
  arraysApart : eb.object≠ab.object
  depthApart : object≠l.pool ∧ object≠l.top ∧ object≠l.high

noncomputable def expWork {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) (active : f.k ≤ d) :
    CoeffWork l object d eb ab := {
  cursor:=expStoreCursor f room
  expCoeffs:=f.expCoeffs++[expNext f]
  atanhCoeffs:=f.atanhCoeffs
  k:=f.k
  kSlot:=f.kSlot
  context:=expStore_valid f room
  expAt:=storedExpTable f room active
  atanhAt:=storedExpAtanhTable f room
  expExtent:=by
    have original:=(storedExpTable f room active).memory
    have actual : (expStoreCursor f room).state.heap[eb.object]?=
        some {type:="Q",cells:=(dividedExpTable f room).cells.set f.k (some (expNext f).source),isArray:=true} := by
      unfold expStoreCursor
      exact List.getElem?_set_self (List.getElem?_eq_some_iff.mp (dividedExpTable f room).memory).choose
    rw[actual] at original
    have cells:=congrArg (fun x : Option Object=>x.map Object.cells) original
    change some ((dividedExpTable f room).cells.set f.k (some (expNext f).source))=
      some (storedExpTable f room active).cells at cells
    rw[← Option.some.inj cells,List.length_set,dividedExp_cells,f.expExtent]
  atanhExtent:=by
    change (dividedAtanhTable f room).cells.length=65
    rw[dividedAtanh_cells,f.atanhExtent]
  expLookup:=by
    unfold expStoreCursor
    change (expDivideCursor f).state.globals.lookup "expCoeffs"=some eb
    rw[expDivide_globals];exact f.expLookup
  atanhLookup:=by
    unfold expStoreCursor
    change (expDivideCursor f).state.globals.lookup "atanhCoeffs"=some ab
    rw[expDivide_globals];exact f.atanhLookup
  expUnshadowed:=by
    unfold expStoreCursor
    change (expDivideCursor f).state.env.lookup "expCoeffs"=none
    rw[expDivide_env];exact f.expUnshadowed
  atanhUnshadowed:=by
    unfold expStoreCursor
    change (expDivideCursor f).state.env.lookup "atanhCoeffs"=none
    rw[expDivide_env];exact f.atanhUnshadowed
  depthAt:=expStore_depth f room
  depthUnshadowed:=by
    unfold expStoreCursor
    change (expDivideCursor f).state.env.lookup "depth"=none
    rw[expDivide_env];exact f.depthUnshadowed
  kAt:=expStore_k f room
  arraysApart:=f.arraysApart
  depthApart:=f.depthApart }

namespace CoeffWork

def advance {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (values : List Nat)
    (room : w.cursor.top+values.length ≤ PoolCalls.capacity) : CoeffWork l object d eb ab := by
  have safe:=LocalStorageSeparation.pool w.context w.kAt (by decide +kernel)
  exact {
    cursor:=CursorFrames.advance l w.cursor values
    expCoeffs:=w.expCoeffs
    atanhCoeffs:=w.atanhCoeffs
    k:=w.k
    kSlot:=w.kSlot
    context:=CursorFrames.advance_valid w.context values room
    expAt:=CoefficientTableRead.advanced w.context w.expAt values
    atanhAt:=CoefficientTableRead.advanced w.context w.atanhAt values
    expExtent:=w.expExtent
    atanhExtent:=w.atanhExtent
    expLookup:=by rw[CursorSingleFrames.advance_globals];exact w.expLookup
    atanhLookup:=by rw[CursorSingleFrames.advance_globals];exact w.atanhLookup
    expUnshadowed:=by rw[(CursorEffects.shape l w.cursor values).2];exact w.expUnshadowed
    atanhUnshadowed:=by rw[(CursorEffects.shape l w.cursor values).2];exact w.atanhUnshadowed
    depthAt:=SourceUnsignedGlobal.advanced w.depthAt values
      w.depthApart.1 w.depthApart.2.1 w.depthApart.2.2
    depthUnshadowed:=by rw[(CursorEffects.shape l w.cursor values).2];exact w.depthUnshadowed
    kAt:=LocalBinding.advance w.kAt values safe.1 safe.2.1 safe.2.2
    arraysApart:=w.arraysApart
    depthApart:=w.depthApart }

noncomputable def nonzeroDivide {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (a b : Input) (nonzero : b.numerator.magnitude≠0)
    (room : w.cursor.top+12<PoolCalls.capacity) : CoeffWork l object d eb ab := by
  have same : RationalDivideCalls.after l w.cursor a b=RationalDivideCalls.nonzeroAfter l w.cursor a b := by
    unfold RationalDivideCalls.after
    rw[if_neg nonzero]
  have ctx:=RationalDivideCalls.after_context w.context room a b
  rw[same] at ctx
  have safe:=LocalStorageSeparation.pool w.context w.kAt (by decide +kernel)
  exact {
    cursor:=RationalDivideCalls.nonzeroAfter l w.cursor a b
    expCoeffs:=w.expCoeffs
    atanhCoeffs:=w.atanhCoeffs
    k:=w.k
    kSlot:=w.kSlot
    context:=ctx
    expAt:=CoefficientTableRead.after_nonzero_division w.context w.expAt a b
    atanhAt:=CoefficientTableRead.after_nonzero_division w.context w.atanhAt a b
    expExtent:=w.expExtent
    atanhExtent:=w.atanhExtent
    expLookup:=by rw[RationalDivideCalls.nonzero_globals];exact w.expLookup
    atanhLookup:=by rw[RationalDivideCalls.nonzero_globals];exact w.atanhLookup
    expUnshadowed:=by rw[RationalDivideCalls.nonzero_env];exact w.expUnshadowed
    atanhUnshadowed:=by rw[RationalDivideCalls.nonzero_env];exact w.atanhUnshadowed
    depthAt:=SourceUnsignedGlobal.nonzero_division w.depthAt a b w.depthApart
    depthUnshadowed:=by rw[RationalDivideCalls.nonzero_env];exact w.depthUnshadowed
    kAt:=LocalBinding.nonzero_division w.kAt a b safe
    arraysApart:=w.arraysApart
    depthApart:=w.depthApart }

noncomputable def storeAtanh {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (q : Input) (alive : q.Live w.cursor.state)
    (positive : 0<q.denominator) (bound : w.atanhCoeffs.length<65) : CoeffWork l object d eb ab := {
  cursor:=CoefficientTableRead.cursor w.cursor ab w.atanhAt.cells w.atanhCoeffs.length q
  expCoeffs:=w.expCoeffs
  atanhCoeffs:=w.atanhCoeffs++[q]
  k:=w.k
  kSlot:=w.kSlot
  context:=CoefficientTableRead.valid w.context w.atanhAt w.atanhCoeffs.length q
  expAt:=CoefficientTableRead.other_table w.atanhAt w.expAt (Ne.symm w.arraysApart) w.atanhCoeffs.length q
  atanhAt:=CoefficientTableRead.append w.atanhAt q alive positive (by rw[w.atanhExtent];exact bound)
  expExtent:=w.expExtent
  atanhExtent:=by rw[CoefficientTableRead.append_length,w.atanhExtent]
  expLookup:=w.expLookup
  atanhLookup:=w.atanhLookup
  expUnshadowed:=w.expUnshadowed
  atanhUnshadowed:=w.atanhUnshadowed
  depthAt:=CoefficientTableRead.changed_depth w.atanhAt w.atanhCoeffs.length q w.depthAt
  depthUnshadowed:=w.depthUnshadowed
  kAt:=CoefficientTableRead.changed_binding w.atanhAt w.atanhCoeffs.length q w.kAt
  arraysApart:=w.arraysApart
  depthApart:=w.depthApart }

end CoeffWork
end ScopedC.PrepareSource
