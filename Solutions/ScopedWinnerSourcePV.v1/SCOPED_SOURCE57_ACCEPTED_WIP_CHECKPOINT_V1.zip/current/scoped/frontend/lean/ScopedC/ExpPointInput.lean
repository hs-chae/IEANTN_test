/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointReduced
import ScopedC.NumericIntervalValues

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

noncomputable def afterReduced {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) : Cursor :=
  CursorLocals.allocated (reductionCursor stage) "Q" "reduced" (reduction stage positive).source

noncomputable def inputPair {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) : Pair :=
  ⟨reduction stage positive,reduction stage positive⟩

noncomputable def afterInput {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) : Cursor :=
  CursorLocals.allocated (afterReduced stage positive) "RI" "input" (inputPair stage positive).source

theorem reduced_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (valid : Valid l c) (positive : 0 < q.denominator)
    (qiAnswer : service "qi" [PoolCalls.word (powerValue stage)] (afterPower stage).state =
      some ((qiPower stage).source,(afterQiPower stage).state))
    (qvAnswer : service "qv" [q.source,(qiPower stage).source] (afterQiPower stage).state =
      some ((reduction stage positive).source,(reductionCursor stage).state)) :
    Declare Header.layout service
      [{type:="Q",name:="reduced",value:=(some (.call (.var "qv")
          [.var "q",.call (.var "qi") [.var "power"]])),arrayExtent:=none}]
      (afterPower stage).state (afterReduced stage positive).state := by
  have expression := ExpressionTemplates.call_two Header.layout service
    (LocalBinding.eval service 998 (power_q_binding stage valid) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (ExpressionTemplates.call_one Header.layout service
      (LocalBinding.eval service 997 (power_binding stage) (by decide +kernel)
        (by decide +kernel) (by decide +kernel) (by decide +kernel)) qiAnswer) qvAnswer
  have cast := Input.cast (s:=(reductionCursor stage).state) "Q" (by decide +kernel)
    (reduction_live stage positive)
  simp only [Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem reduced_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    LocalBinding.At (afterReduced stage positive).state "reduced" "Q"
      (reduction stage positive).source (reductionCursor stage).state.heap.length :=
  LocalBinding.allocate_head _ "reduced" "Q" _ (by rfl)

theorem input_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    (inputPair stage positive).Live (afterInput stage positive).state :=
  ⟨reduction_live stage positive,reduction_live stage positive⟩

theorem input_positive {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    (inputPair stage positive).Positive :=
  ⟨reduction_positive stage positive,reduction_positive stage positive⟩

theorem input_ordered {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    (inputPair stage positive).lo.mathematical.value ≤ (inputPair stage positive).hi.mathematical.value :=
  le_refl _

theorem point_source (code : List Function) (lib : ReductionLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (positive : 0 < q.denominator) :
    SourceCall Header.layout code 1 "point" [(reduction stage positive).source]
      (afterReduced stage positive).state (inputPair stage positive).source
      (afterReduced stage positive).state :=
  RationalPointCalls.point_closed code lib.point (reduction_live stage positive).1
    (reduction_live stage positive).2 (SignedNegCalls.bit_bound _)

theorem input_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (positive : 0 < q.denominator)
    (answer : service "point" [(reduction stage positive).source]
      (afterReduced stage positive).state =
      some ((inputPair stage positive).source,(afterReduced stage positive).state)) :
    Declare Header.layout service
      [{type:="RI",name:="input",value:=(some (.call (.var "point") [.var "reduced"])),arrayExtent:=none}]
      (afterReduced stage positive).state (afterInput stage positive).state := by
  have expression := ExpressionTemplates.call_one Header.layout service
    (LocalBinding.eval service 998 (reduced_binding stage positive) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel)) answer
  have cast := Pair.cast (s:=(afterReduced stage positive).state)
    (input_live stage positive) "RI" (by decide +kernel)
  simp only [Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem input_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    LocalBinding.At (afterInput stage positive).state "input" "RI" (inputPair stage positive).source
      (afterReduced stage positive).state.heap.length :=
  LocalBinding.allocate_head _ "input" "RI" _ (by rfl)

theorem input_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator)
    (room : c.top+40 < PoolCalls.capacity) : Valid l (afterInput stage positive) :=
  CursorLocals.allocated_valid
    (CursorLocals.allocated_valid (reduction_valid stage room) "Q" "reduced" _)
    "RI" "input" _

theorem input_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    (afterInput stage positive).top ≤ c.top+29 := by
  change (reductionCursor stage).top ≤ c.top+29
  rw [reduction_nonzero,RationalDivideCalls.nonzero_top]
  change (afterPower stage).top+3+13 ≤ c.top+29
  have top := power_top stage
  omega

theorem input_remainder_guard {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    Int.ceil (max |(inputPair stage positive).lo.mathematical.value|
      |(inputPair stage positive).hi.mathematical.value|) < 4294967295 := by
  change Int.ceil (max |(reduction stage positive).mathematical.value|
    |(reduction stage positive).mathematical.value|) < _
  rw [max_self,reduction_value stage positive]
  exact ExpPointReduction.remainder_guard _

end ScopedC.ExpPointCalls
