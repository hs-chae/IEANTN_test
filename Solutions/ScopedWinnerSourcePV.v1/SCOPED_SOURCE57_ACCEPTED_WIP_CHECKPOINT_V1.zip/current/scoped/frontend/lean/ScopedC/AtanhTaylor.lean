/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhUnshadowed
import ScopedC.NumericIntervalCompleteness

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

def pointPair (q : Input) : Pair := ⟨q,q⟩

abbrev TaylorStage (code : List Function) (l : PoolCalls.PoolLayout) (c : Cursor)
    (base : Address) (coeffs : List Input) (q : Input) (d : Nat)
    (stage : PowerStage code l c q d) (positive : 0<q.denominator) :=
  TaylorCalls.FramedResult code l (afterRemainder stage positive) base coeffs
    (pointPair q) true (le_refl q.mathematical.value) d

structure Library (code : List Function) : Prop where
  error : ErrorLibrary code
  qn : Generated.f_qn∈code
  sn : Generated.f_sn∈code
  taylor : Generated.f_taylor∈code
  polynomial : TaylorCalls.EntryLibrary code

theorem point_source (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} {d : Nat}
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (alive : q.Live c.state) :
    SourceCall Header.layout code 1 "point" [q.source] (afterRemainder stage positive).state
      (pointPair q).source (afterRemainder stage positive).state := by
  have live:=q_remainder_live stage positive narrow alive
  change SourceCall Header.layout code 1 "point"
    [RecordCasts.rational q.numerator.slot (SignedNegCalls.bit q.numerator.negative) q.denSlot]
    (afterRemainder stage positive).state (IntervalCasts.value _ _) (afterRemainder stage positive).state
  exact RationalPointCalls.point_closed code lib.polynomial.body.point live.1 live.2
    (SignedNegCalls.bit_bound _)

theorem taylor_stage (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input) (d object : Nat)
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (alive : q.Live c.state)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high)
    (dBound : d≤64) (length : coeffs.length=d+1) (room : c.top+9000<PoolCalls.capacity) :
    Nonempty (TaylorStage code l c base coeffs q d stage positive) := by
  have top:=stage.top
  rw[guard_top] at top
  exact TaylorCalls.taylor_framed code lib.taylor lib.polynomial
    (remainder_valid stage positive narrow (by omega))
    (remainder_table ctx q d stage positive narrow (by omega) table) (pointPair q)
    ⟨q_remainder_live stage positive narrow alive,q_remainder_live stage positive narrow alive⟩
    ⟨positive,positive⟩ (le_refl _) d object (remainder_depth stage positive narrow depth apart)
    apart dBound length (by rw[remainder_top _ _ narrow];omega) true

/-- Metadata inverts the actual verified Taylor source decoder. Its source
record remains exactly the actual program output, with no output premise. -/
noncomputable def taylorPair {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) : Pair :=
  Classical.choose (NumericInputCompleteness.interval t.decoded)

theorem taylor_pair_spec {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) :
    (taylorPair t).source=t.output.source ∧ (taylorPair t).Live t.out.state ∧
      (taylorPair t).Positive ∧
      (taylorPair t).lo.mathematical.value=
        (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
          (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).lo ∧
      (taylorPair t).hi.mathematical.value=
        (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
          (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).hi :=
  Classical.choose_spec (NumericInputCompleteness.interval t.decoded)

theorem taylor_pair_order {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {base : Address} {coeffs : List Input} {q : Input} {d : Nat}
    {stage : PowerStage code l c q d} {positive : 0<q.denominator}
    (t : TaylorStage code l c base coeffs q d stage positive) :
    (taylorPair t).lo.mathematical.value≤(taylorPair t).hi.mathematical.value := by
  rw[(taylor_pair_spec t).2.2.2.1,(taylor_pair_spec t).2.2.2.2]
  exact (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
    (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).le

end ScopedC.AtanhCalls
