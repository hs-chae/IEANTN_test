/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhDenominator
import ScopedC.RationalDivideOutput

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

structure ErrorLibrary (code : List Function) : Prop where
  narrow : NarrowLibrary code
  qv : Generated.f_qv∈code
  division : RationalDivideCalls.Library code

noncomputable def errorInput {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
    {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) : Input :=
  RationalDivideCalls.outputInput l (denCursor stage) stage.output (denominator stage positive)
    stage.positive (RationalSubCalls.output_spec l (denStart stage) (denOne stage) (absInput q)
      (by change 0<(1:Nat);decide +kernel) positive).2.2.2

noncomputable def errorCursor {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
    {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) : Cursor :=
  RationalDivideCalls.after l (denCursor stage) stage.output (denominator stage positive)

theorem den_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d)
    (room : c.top+750<PoolCalls.capacity) : Valid l (denCursor stage) := by
  have top:=stage.top
  rw[guard_top] at top
  exact RationalSubCalls.after_context (den_start_valid stage room)
    (by change stage.out.top+3+14<PoolCalls.capacity;omega) _ _

theorem den_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) :
    (denCursor stage).top=stage.out.top+18 := by
  unfold denCursor
  rw[RationalSubCalls.after_top]
  rfl

theorem error_source (code : List Function) (lib : ErrorLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} {d : Nat}
    (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (room : c.top+750<PoolCalls.capacity) :
    SourceCall Header.layout code 7 "qv" [stage.output.source,(denominator stage positive).source]
      (denCursor stage).state (errorInput stage positive).source (errorCursor stage positive).state := by
  have numeratorAfterOne : stage.output.Live (denStart stage).state :=
    ⟨CursorBorrow.preserves (l:=l) (c:=stage.out) [1,0,1] stage.live.1,
      CursorBorrow.preserves (l:=l) (c:=stage.out) [1,0,1] stage.live.2⟩
  have numerator : stage.output.Live (denCursor stage).state :=
    ⟨RationalSubCalls.after_borrow (denOne stage) (absInput q) numeratorAfterOne.1,
      RationalSubCalls.after_borrow (denOne stage) (absInput q) numeratorAfterOne.2⟩
  have denominatorSpec:=RationalSubCalls.output_spec l (denStart stage) (denOne stage)
    (absInput q) (by change 0<(1:Nat);decide +kernel) positive
  have top:=stage.top
  rw[guard_top] at top
  exact RationalDivideCalls.output_source code lib.qv lib.division (den_valid stage room)
    (by rw[den_top];omega) stage.output (denominator stage positive) numerator denominatorSpec.2.1
    stage.positive denominatorSpec.2.2.2

theorem error_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) :
    (errorInput stage positive).Live (errorCursor stage positive).state :=
  (RationalDivideCalls.output_spec l (denCursor stage) stage.output (denominator stage positive)
    stage.positive (RationalSubCalls.output_spec l (denStart stage) (denOne stage) (absInput q)
      (by change 0<(1:Nat);decide +kernel) positive).2.2.2).2.1

theorem error_den_positive {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) :
    0<(errorInput stage positive).denominator :=
  (RationalDivideCalls.output_spec l (denCursor stage) stage.output (denominator stage positive)
    stage.positive (RationalSubCalls.output_spec l (denStart stage) (denOne stage) (absInput q)
      (by change 0<(1:Nat);decide +kernel) positive).2.2.2).2.2.2

theorem error_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) :
    (errorInput stage positive).mathematical.value=
      |q.mathematical.value|^(d+1)/(1-|q.mathematical.value|) := by
  have value:=(RationalDivideCalls.output_spec l (denCursor stage) stage.output
    (denominator stage positive) stage.positive
    (RationalSubCalls.output_spec l (denStart stage) (denOne stage) (absInput q)
      (by change 0<(1:Nat);decide +kernel) positive).2.2.2).2.2.1
  exact value.trans (by rw[power_value,denominator_value])

theorem error_nonnegative {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    0≤(errorInput stage positive).mathematical.value := by
  rw[error_value]
  exact div_nonneg (pow_nonneg (abs_nonneg _) _) (by linarith)

end ScopedC.AtanhCalls
