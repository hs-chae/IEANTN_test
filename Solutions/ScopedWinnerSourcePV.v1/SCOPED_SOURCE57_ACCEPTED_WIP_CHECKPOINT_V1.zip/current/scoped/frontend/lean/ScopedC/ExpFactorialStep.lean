/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpFactorialFrame

namespace ScopedC.ExpFactorial
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def stored {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) : Cursor :=
  LocalAssignment.cursor (productCursor f) f.factSlot "Q" (product f).source

theorem fact_product_binding {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    LocalBinding.At (productCursor f).state "fact" "Q" f.fact.source f.factSlot := by
  have safe:=LocalStorageSeparation.pool f.context f.factAt (by decide +kernel : ("Q":String)≠"unsigned")
  exact product_binding f f.factAt safe.1 safe.2.1 safe.2.2

theorem k_product_binding {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    LocalBinding.At (productCursor f).state "k" "unsigned int" (PoolCalls.word f.k) f.kSlot := by
  have safe:=LocalStorageSeparation.pool f.context f.kAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  exact product_binding f f.kAt safe.1 safe.2.1 safe.2.2

theorem stored_valid {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) : Valid l (stored f) := by
  have safe:=LocalStorageSeparation.pool f.context f.factAt (by decide +kernel : ("Q":String)≠"unsigned")
  exact LocalAssignment.valid (product_valid f room) f.factSlot "Q" (product f).source safe.1 safe.2.1 safe.2.2

theorem stored_fact_binding {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    LocalBinding.At (stored f).state "fact" "Q" (product f).source f.factSlot :=
  LocalAssignment.binding (fact_product_binding f) (by rfl)

theorem stored_k_binding {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    LocalBinding.At (stored f).state "k" "unsigned int" (PoolCalls.word f.k) f.kSlot :=
  LocalAssignment.other_binding (changedType:="Q") (value:=(product f).source) (k_product_binding f)
    (LocalStorageSeparation.typed f.kAt f.factAt (by decide +kernel))

theorem product_depth {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d) :
    SourceUnsignedGlobal.At (productCursor f).state "depth" object d := by
  rw[product_trace]
  exact SourceUnsignedGlobal.advanced f.depthAt _ f.depthApart.1 f.depthApart.2.1 f.depthApart.2.2

def stepped {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) : Frame l object d := by
  have kSafe:=LocalStorageSeparation.pool f.context f.kAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  exact {
    cursor:=LocalAssignment.cursor (stored f) f.kSlot "unsigned int" (PoolCalls.word (f.k+1))
    fact:=product f
    k:=f.k+1
    factSlot:=f.factSlot
    kSlot:=f.kSlot
    context:=LocalAssignment.valid (stored_valid f room) f.kSlot "unsigned int" (PoolCalls.word (f.k+1))
      kSafe.1 kSafe.2.1 kSafe.2.2
    factAt:=LocalAssignment.other_binding (changedType:="unsigned int") (value:=PoolCalls.word (f.k+1))
      (stored_fact_binding f) (LocalStorageSeparation.typed f.factAt f.kAt (by decide +kernel))
    kAt:=LocalAssignment.binding (stored_k_binding f) (by rfl)
    depthAt:=SourceUnsignedGlobal.local_store
      (SourceUnsignedGlobal.local_store (product_depth f) (fact_product_binding f) (by decide +kernel))
      (stored_k_binding f) (by decide +kernel)
    depthUnshadowed:=by
      change (productCursor f).state.env.lookup "depth"=none
      rw[product_trace,(CursorEffects.shape _ _ _).2]
      exact f.depthUnshadowed
    live:=product_live f
    positive:=product_positive f
    kPositive:=by omega
    kBound:=by omega
    depthBound:=f.depthBound
    depthApart:=f.depthApart }

theorem stepped_k {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) :
    (stepped f active room).k=f.k+1 := rfl

theorem stepped_fact {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) :
    (stepped f active room).fact.mathematical.value=f.fact.mathematical.value*(f.k:Rat) := product_value f

theorem stepped_top {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) :
    (stepped f active room).cursor.top=f.cursor.top+14 := product_top f

theorem stepped_size {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity) :
    (stepped f active room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+14 := by
  change (productCursor f).state.nats.values.length=_
  rw[product_trace,CursorEffects.size]
  rfl

end ScopedC.ExpFactorial
