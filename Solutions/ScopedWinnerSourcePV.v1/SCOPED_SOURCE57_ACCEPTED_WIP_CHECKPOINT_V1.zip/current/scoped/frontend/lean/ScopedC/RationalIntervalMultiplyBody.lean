/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplyEvents
import ScopedC.RationalIntervalMultiplyStorage
import ScopedC.RationalSelectionTreeExpression

namespace ScopedC.RationalIntervalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] finish

def productInitializer (left right : String) : Expr :=
  .call (.var "qt") [.field "." (.var "a") left,.field "." (.var "b") right]
def finalInitializer : Expr := .record [RationalSelectionTree.expression "qmin",RationalSelectionTree.expression "qmax"]

/-- All ten actual source calls, the four intermediate Q declarations,
actual nested min/max initializer, typed RI return, and both stack scopes. -/
theorem rmul_closed (code : List Function) (installed : Generated.f_rmul∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair)
    (ha : a.Live c.state) (hb : b.Live c.state) (pa : a.Positive) (pb : b.Positive) :
    SourceCall Header.layout code 8 "rmul" [a.source,b.source] c.state
      (result l c a b) (after l c a b).state := by
  obtain ⟨service,ans,closed⟩:=answers_exist code lib ctx room a b ha hb pa pb
  have aa:=input_a ctx a b
  have bb:=input_b ctx a b
  have declP : Declare Header.layout service [{type:="Q",name:="p",value:=some (productInitializer "lo" "lo"),arrayExtent:=none}]
      (base c a b).state (c1 l c a b).state := by
    unfold c1
    apply product_declaration service l (base c a b) a.lo b.lo
    · exact RationalIntervalFrames.eval_lo service 997 (RationalIntervalFrames.a_at c.state a b)
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    · exact RationalIntervalFrames.eval_lo service 997 (RationalIntervalFrames.b_at c.state a b)
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    · exact ans.qt1
  have declQ : Declare Header.layout service [{type:="Q",name:="q",value:=some (productInitializer "lo" "hi"),arrayExtent:=none}]
      (c1 l c a b).state (c2 l c a b).state := by
    unfold c2
    apply product_declaration service l (c1 l c a b) a.lo b.hi
    · exact RationalIntervalFrames.eval_lo service 997 aa.1
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    · exact RationalIntervalFrames.eval_hi service 997 bb.1
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    · exact ans.qt2
  have declR : Declare Header.layout service [{type:="Q",name:="r",value:=some (productInitializer "hi" "lo"),arrayExtent:=none}]
      (c2 l c a b).state (c3 l c a b).state := by
    unfold c3
    apply product_declaration service l (c2 l c a b) a.hi b.lo
    · exact RationalIntervalFrames.eval_hi service 997 aa.2.1
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    · exact RationalIntervalFrames.eval_lo service 997 bb.2.1
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    · exact ans.qt3
  have declS : Declare Header.layout service [{type:="Q",name:="s",value:=some (productInitializer "hi" "hi"),arrayExtent:=none}]
      (c3 l c a b).state (c4 l c a b).state := by
    unfold c4
    apply product_declaration service l (c3 l c a b) a.hi b.hi
    · exact RationalIntervalFrames.eval_hi service 997 aa.2.2
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    · exact RationalIntervalFrames.eval_hi service 997 bb.2.2
        (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    · exact ans.qt4
  have productBindings:=products_at ctx a b
  have sp:=stack_safe ctx (slot:=c.state.heap.length+2) (by omega)
  have sq:=stack_safe ctx (slot:=c.state.heap.length+3) (by omega)
  have sr:=stack_safe ctx (slot:=c.state.heap.length+4) (by omega)
  have ss:=stack_safe ctx (slot:=c.state.heap.length+5) (by omega)
  have lowEval : evalExpr Header.layout service 999 (c4 l c a b).state (RationalSelectionTree.expression "qmin")=
      some ((lowQ l c a b).source,(middle l c a b).state) := by
    unfold middle lowQ
    exact RationalSelectionTree.evaluate service 996 false l (c4 l c a b) (four l c a b)
      productBindings.1 productBindings.2.1 productBindings.2.2.1 productBindings.2.2.2 sr.1 sr.2.1 sr.2.2 ss.1 ss.2.1 ss.2.2
      ans.min1 ans.min2 (by simpa only[RationalSelectionTree.name,Bool.false_eq_true,↓reduceIte,middle,lowQ] using ans.min3)
  have mp : LocalBinding.At (middle l c a b).state "p" "Q" (p l c a b).source (c.state.heap.length+2) := by
    unfold middle;exact RationalSelectionTree.binding false (four l c a b) productBindings.1 sp.1 sp.2.1 sp.2.2
  have mq : LocalBinding.At (middle l c a b).state "q" "Q" (q l c a b).source (c.state.heap.length+3) := by
    unfold middle;exact RationalSelectionTree.binding false (four l c a b) productBindings.2.1 sq.1 sq.2.1 sq.2.2
  have mr : LocalBinding.At (middle l c a b).state "r" "Q" (r l c a b).source (c.state.heap.length+4) := by
    unfold middle;exact RationalSelectionTree.binding false (four l c a b) productBindings.2.2.1 sr.1 sr.2.1 sr.2.2
  have ms : LocalBinding.At (middle l c a b).state "s" "Q" (s l c a b).source (c.state.heap.length+5) := by
    unfold middle;exact RationalSelectionTree.binding false (four l c a b) productBindings.2.2.2 ss.1 ss.2.1 ss.2.2
  have highEval : evalExpr Header.layout service 999 (middle l c a b).state (RationalSelectionTree.expression "qmax")=
      some ((highQ l c a b).source,(finish l c a b).state) := by
    unfold finish highQ
    exact RationalSelectionTree.evaluate service 996 true l (middle l c a b) (four l c a b)
      mp mq mr ms sr.1 sr.2.1 sr.2.2 ss.1 ss.2.1 ss.2.2 ans.max1 ans.max2
      (by simpa only[RationalSelectionTree.name,↓reduceIte,finish,highQ] using ans.max3)
  have expr : evalExpr Header.layout service 1000 (c4 l c a b).state finalInitializer=
      some (.aggregate [(lowQ l c a b).source,(highQ l c a b).source],(finish l c a b).state) :=
    ExpressionTemplates.record_two Header.layout service lowEval highEval
  have live:=output_live l c a b
  have cl : castValue Header.layout (finish l c a b).state 99 "Q" (lowQ l c a b).source=some (lowQ l c a b).source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) live.1.1 live.1.2 (SignedNegCalls.bit_bound _)
  have ch : castValue Header.layout (finish l c a b).state 99 "Q" (highQ l c a b).source=some (highQ l c a b).source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) live.2.1 live.2.2 (SignedNegCalls.bit_bound _)
  have cast : castValue Header.layout (finish l c a b).state 100 "RI"
      (.aggregate [(lowQ l c a b).source,(highQ l c a b).source])=some (result l c a b) :=
    IntervalCasts.aggregate _ 96 _ _ cl ch
  have declOut : Declare Header.layout service [{type:="RI",name:="out",value:=some finalInitializer,arrayExtent:=none}]
      (c4 l c a b).state (stored l c a b).state := by
    simp only[Declare,declarations,List.foldlM,expr,bind,Option.bind,cast]
    rfl
  have returned : Eval Header.layout service (.var "out") (stored l c a b).state
      (stored l c a b).state (result l c a b) :=
    ⟨2,TypedFrames.allocate_eval Header.layout service 1 (finish l c a b).state "RI" "out" (result l c a b)
      (Pair.initialized _) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)⟩
  have body : Run Header.layout service Generated.f_rmul.body (base c a b).state
      (.returned (bodyExit l c a b).state (result l c a b)) := by
    apply Loops.StmtRun.sequence
      (Loops.SeqRun.next (Loops.StmtRun.declare declP)
        (Loops.SeqRun.next (Loops.StmtRun.declare declQ)
          (Loops.SeqRun.next (Loops.StmtRun.declare declR)
            (Loops.SeqRun.next (Loops.StmtRun.declare declS)
              (Loops.SeqRun.next (Loops.StmtRun.declare declOut)
                (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned)))))))
    exact ⟨rfl,rfl⟩
  apply installed_body (f:=Generated.f_rmul) (rank:=7) (service:=service) installed closed
    (RationalIntervalFrames.bind a b ha hb) body
  exact ⟨Pair.cast (scoped_live l c a b) "static RI" (by decide +kernel),rfl⟩

end ScopedC.RationalIntervalMultiplyCalls
