/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientDivideFrames

namespace ScopedC.SourceScalarGlobal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

/-- An actual application-owned typed scalar object, including raw static
records before they are overwritten. No live numerical old value is assumed. -/
structure At (s : State) (name type : String) (object : Nat) (value : Option Value) : Prop where
  lookup : s.globals.lookup name=some ⟨object,0,[]⟩
  storage : s.heap[object]?=some {type:=type,cells:=[value]}

theorem memory {s t : State} {name type : String} {object : Nat} {value : Option Value}
    (h : At s name type object value) (globals : t.globals=s.globals)
    (stored : t.heap[object]?=s.heap[object]?) : At t name type object value :=
  ⟨by simpa only[globals] using h.lookup,stored.trans h.storage⟩

theorem separated {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {name type : String} {object : Nat} {value : Option Value} (h : At c.state name type object value)
    (different : type≠"unsigned") : object≠l.pool ∧ object≠l.top ∧ object≠l.high := by
  have hp : object≠l.pool := by
    intro same
    have storage:=h.storage
    simp only[same,ctx.pool_read] at storage
    have flags:=congrArg (fun x : Option Object=>x.map Object.isArray) storage
    change some true=some false at flags
    contradiction
  have counters : ∀slot n,c.state.heap[slot]?=some {type:="unsigned",cells:=[some (PoolCalls.word n)]} →
      object≠slot := by
    intro slot n stored same
    have storage:=h.storage
    simp only[same,stored] at storage
    have types:=congrArg (fun x : Option Object=>x.map Object.type) storage
    change some "unsigned"=some type at types
    exact different (Option.some.inj types).symm
  exact ⟨hp,counters l.top c.top ctx.top_read,counters l.high c.high ctx.high_read⟩

theorem advanced {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {name type : String} {object : Nat} {value : Option Value} (h : At c.state name type object value)
    (different : type≠"unsigned") (values : List Nat) :
    At (CursorFrames.advance l c values).state name type object value := by
  have safe:=separated ctx h different
  exact memory h (CursorSingleFrames.advance_globals l c values)
    (CursorSingleFrames.advance_other l c values object safe.1 safe.2.1 safe.2.2)

theorem nonzero_division {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {name type : String} {object : Nat} {value : Option Value} (h : At c.state name type object value)
    (different : type≠"unsigned") (a b : RationalPairFrames.Input) :
    At (RationalDivideCalls.nonzeroAfter l c a b).state name type object value := by
  have safe:=separated ctx h different
  exact memory h (RationalDivideCalls.nonzero_globals l c a b)
    (RationalDivideCalls.nonzero_other l c a b object
      (List.getElem?_eq_some_iff.mp h.storage).choose safe.1 safe.2.1 safe.2.2)

theorem coefficient_store {s : State} {name type : String} {object : Nat} {value : Option Value}
    (h : At s name type object value) {base : Address} {coeffs : List RationalPairFrames.Input}
    (table : CoefficientTableRead.TableAt s base coeffs) (k : Nat) (q : RationalPairFrames.Input) :
    At (CoefficientTableRead.changed s base table.cells k q) name type object value := by
  have safe:=CoefficientTableRead.scalar_separated table h.storage
  exact memory h rfl (List.getElem?_set_ne safe)

theorem local_store {s : State} {name type : String} {object : Nat} {value : Option Value}
    (h : At s name type object value) {localName localType : String} {slot : Nat} {old new : Value}
    (binding : LocalBinding.At s localName localType old slot) (different : type≠localType) :
    At (LocalAssignment.changed s slot localType new) name type object value := by
  have safe : object≠slot := by
    intro same
    have storage:=h.storage
    simp only[same,binding.memory] at storage
    have types:=congrArg (fun x : Option Object=>x.map Object.type) storage
    change some localType=some type at types
    exact different (Option.some.inj types).symm
  exact memory h rfl (List.getElem?_set_ne (Ne.symm safe))

theorem allocated {s : State} {name type : String} {object : Nat} {value : Option Value}
    (h : At s name type object value) (localType localName : String) (localValue : Option Value) :
    At (allocate s localType localName localValue) name type object value :=
  memory h rfl (List.getElem?_append_left (List.getElem?_eq_some_iff.mp h.storage).choose)

end ScopedC.SourceScalarGlobal
