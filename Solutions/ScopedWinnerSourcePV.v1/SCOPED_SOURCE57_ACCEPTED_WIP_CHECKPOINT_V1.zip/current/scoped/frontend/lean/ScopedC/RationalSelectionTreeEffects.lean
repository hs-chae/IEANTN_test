/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSelectionTree

namespace ScopedC.RationalSelectionTree
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def steps (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) : List Nat :=
  RationalCompareFraming.steps v.p v.q ++ RationalCompareFraming.steps v.r v.s ++
  RationalCompareFraming.steps (left flip l c v) (right flip l c v)

theorem finish_advance (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) :
    finish flip l c v=CursorFrames.advance l c (steps flip l c v) := by
  unfold finish
  rw[step,RationalCompareFraming.final_eq_advance]
  unfold t2
  rw[step,RationalCompareFraming.final_eq_advance]
  unfold t1
  rw[step,RationalCompareFraming.final_eq_advance]
  rw[steps,CursorSingleFrames.advance_append,CursorSingleFrames.advance_append]

theorem steps_length (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) :
    (steps flip l c v).length=18 := by
  simp only[steps,List.length_append,RationalCompareFraming.steps,List.length_cons,List.length_nil]

theorem size_finish (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) :
    (finish flip l c v).state.nats.values.length=c.state.nats.values.length+18 := by
  rw[finish_advance,CursorEffects.size,steps_length]

theorem shape (flip : Bool) (l : PoolCalls.PoolLayout) (c : Cursor) (v : Four) :
    (finish flip l c v).state.heap.length=c.state.heap.length ∧
    (finish flip l c v).state.env=c.state.env := by
  rw[finish_advance]
  exact CursorEffects.shape l c _

theorem preserves_nat (flip : Bool) {l : PoolCalls.PoolLayout} {c : Cursor}
    (v : Four) {slot n : Nat} (h : ScopedC.NatArena.Borrow c.state.nats slot n) :
    ScopedC.NatArena.Borrow (finish flip l c v).state.nats slot n := by
  rw[finish_advance]
  exact CursorBorrow.preserves _ h

theorem binding (flip : Bool) {l : PoolCalls.PoolLayout} {c : Cursor} (v : Four)
    {name ty : String} {value : Value} {slot : Nat} (h : ScopedC.LocalBinding.At c.state name ty value slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    ScopedC.LocalBinding.At (finish flip l c v).state name ty value slot := by
  rw[finish_advance]
  exact ScopedC.LocalBinding.advance h _ hp ht hh

end ScopedC.RationalSelectionTree
