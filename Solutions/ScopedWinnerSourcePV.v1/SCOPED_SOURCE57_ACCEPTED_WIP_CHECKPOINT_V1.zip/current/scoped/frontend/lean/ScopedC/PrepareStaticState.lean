/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientTableAppend
import ScopedC.SourceUnsignedGlobal
import ScopedC.DataComplete

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def layout (base : Nat) : PoolLayout :=
  ⟨base,base+1,base+2,by omega,by omega,by omega⟩
def expBase (base : Nat) : Address := ⟨base+5,0,[]⟩
def atanhBase (base : Nat) : Address := ⟨base+6,0,[]⟩
def mutableNames : List String :=
  ["pool","poolTop","poolHigh","depth","scale100","expCoeffs","atanhCoeffs","preparedLn2"]

/-- Actual static initialization readiness, not prepared numerical data. Q
array cells are real C static zero records containing null Nat pointers; only
the empty coefficient prefixes are asserted before actual prepare writes. -/
structure StaticAt (s : State) (base : Nat) where
  pool : GenericPoolContext (layout base) s ScopedIO.ApplicationInit.poolCells 0 0
  depth : SourceUnsignedGlobal.At s "depth" (base+3) 24
  exp : CoefficientTableRead.TableAt s (expBase base) []
  atanh : CoefficientTableRead.TableAt s (atanhBase base) []
  expLength : exp.cells.length=65
  atanhLength : atanh.cells.length=65
  expLookup : s.globals.lookup "expCoeffs"=some (expBase base)
  atanhLookup : s.globals.lookup "atanhCoeffs"=some (atanhBase base)
  scaleLookup : s.globals.lookup "scale100"=some ⟨base+4,0,[]⟩
  scaleMemory : s.heap[base+4]?=some {type:="N",cells:=[some .null]}
  ln2Lookup : s.globals.lookup "preparedLn2"=some ⟨base+7,0,[]⟩
  ln2Memory : s.heap[base+7]?=some {type:="RI",cells:=[some ScopedIO.ApplicationInit.zeroInterval]}

def initial_static (platform : State) : StaticAt (ScopedIO.ApplicationInit.after platform) platform.heap.length := by
  have expMemory : (ScopedIO.ApplicationInit.after platform).heap[platform.heap.length+5]?=
      some {type:="Q",cells:=List.replicate 65 (some ScopedIO.ApplicationInit.zeroRational),isArray:=true} := by
    simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationObjects,List.getElem?_append]
  have atanhMemory : (ScopedIO.ApplicationInit.after platform).heap[platform.heap.length+6]?=
      some {type:="Q",cells:=List.replicate 65 (some ScopedIO.ApplicationInit.zeroRational),isArray:=true} := by
    simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationObjects,List.getElem?_append]
  exact {
    pool:=ScopedIO.ApplicationInit.initial_pool_context platform
    depth:=⟨by simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationNames,List.lookup],
      by simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationObjects,List.getElem?_append,counterObject]⟩
    exp:=CoefficientTableRead.empty expMemory rfl rfl
    atanh:=CoefficientTableRead.empty atanhMemory rfl rfl
    expLength:=by simp [CoefficientTableRead.empty]
    atanhLength:=by simp [CoefficientTableRead.empty]
    expLookup:=by simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationNames,List.lookup,expBase]
    atanhLookup:=by simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationNames,List.lookup,atanhBase]
    scaleLookup:=by simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationNames,List.lookup]
    scaleMemory:=by simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationObjects,List.getElem?_append]
    ln2Lookup:=by simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationNames,List.lookup]
    ln2Memory:=by simp [ScopedIO.ApplicationInit.after,ScopedIO.ApplicationInit.applicationObjects,List.getElem?_append] }

/-- Readonly source-declaration extension preserves all actual mutable objects
and addresses; it supplies no prepared value or application execution premise. -/
def transport {s t : State} {base : Nat} (ready : StaticAt s base) (objects : List Object)
    (heap : t.heap=s.heap++objects) (nats : t.nats=s.nats)
    (stable : ∀key∈mutableNames,t.globals.lookup key=s.globals.lookup key) : StaticAt t base := by
  have stored {slot : Nat} {value : Object} (read : s.heap[slot]?=some value) : t.heap[slot]?=s.heap[slot]? := by
    rw[heap,List.getElem?_append_left (List.getElem?_eq_some_iff.mp read).choose]
  let exp:=CoefficientTableRead.memory ready.exp (stored ready.exp.memory)
    (fun _ _ live=>by rw[nats];exact live)
  let atanh:=CoefficientTableRead.memory ready.atanh (stored ready.atanh.memory)
    (fun _ _ live=>by rw[nats];exact live)
  exact {
    pool:=DataGlobals.pool_from_prefix ready.pool objects heap
      (stable "pool" (by simp [mutableNames])) (stable "poolTop" (by simp [mutableNames]))
      (stable "poolHigh" (by simp [mutableNames]))
    depth:=⟨(stable "depth" (by simp [mutableNames])).trans ready.depth.lookup,
      (stored ready.depth.storage).trans ready.depth.storage⟩
    exp:=exp
    atanh:=atanh
    expLength:=by simpa only[exp,CoefficientTableRead.memory] using ready.expLength
    atanhLength:=by simpa only[atanh,CoefficientTableRead.memory] using ready.atanhLength
    expLookup:=(stable "expCoeffs" (by simp [mutableNames])).trans ready.expLookup
    atanhLookup:=(stable "atanhCoeffs" (by simp [mutableNames])).trans ready.atanhLookup
    scaleLookup:=(stable "scale100" (by simp [mutableNames])).trans ready.scaleLookup
    scaleMemory:=(stored ready.scaleMemory).trans ready.scaleMemory
    ln2Lookup:=(stable "preparedLn2" (by simp [mutableNames])).trans ready.ln2Lookup
    ln2Memory:=(stored ready.ln2Memory).trans ready.ln2Memory }

end ScopedC.PrepareSource
