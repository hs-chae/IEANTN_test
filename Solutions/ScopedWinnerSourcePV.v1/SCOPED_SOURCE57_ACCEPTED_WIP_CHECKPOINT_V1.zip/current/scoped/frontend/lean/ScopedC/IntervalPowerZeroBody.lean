/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerPositiveBody
import ScopedC.RationalPowerInitialization
import ScopedC.RationalPointBody

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  rmul : Generated.f_rmul∈code
  multiplyLibrary : RationalIntervalMultiplyCalls.Library code
  qi : Generated.f_qi∈code
  si : Generated.f_si∈code
  point : Generated.f_point∈code

theorem rpow_zero_closed (code : List Function) (installed : Generated.f_rpow∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5120 ≤ PoolCalls.capacity) (a : Pair) (alive : a.Live c.state) :
    ∃out : Cursor,∃q : Pair,
      SourceCall Header.layout code 9 "rpow" [a.source,PoolCalls.word 0] c.state q.source out.state ∧
      Valid l out ∧ q.Live out.state ∧ q.Positive ∧
      NumericRepresentation.interval out.state q.source=some (LeanCert.Core.IntervalRat.singleton 1) ∧
      out.top ≤ c.top+5120 := by
  let p:=parameters c a 0
  let q:=RationalPowerCalls.oneQ l p
  let afterQi:=RationalPowerCalls.oneCursor l p
  let result : Pair:=⟨q,q⟩
  have parameterContext : Valid l p:=CursorFrames.framed_valid ctx "RI" "a" a.source "unsigned int" "n" (PoolCalls.word 0)
  have qiCall : SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1] p.state q.source afterQi.state := by
    have proof:=RationalUnsignedCalls.qi_call (input:=DecimalDigits.integer 1) (n:=1)
      code lib.qi lib.si lib.multiplyLibrary.productLibrary.smake lib.multiplyLibrary.productLibrary.nz
      lib.multiplyLibrary.productLibrary.nu lib.multiplyLibrary.productLibrary.ne lib.multiplyLibrary.productLibrary.keep
      parameterContext (by change c.top+2<PoolCalls.capacity;omega) (by decide +kernel) (by rfl)
    simpa only[q,afterQi,RationalPowerCalls.one_source,RationalPowerCalls.one_state] using proof
  have qLive : q.Live afterQi.state:=RationalPowerCalls.one_live l p
  have pointCall : SourceCall Header.layout code 1 "point" [q.source] afterQi.state result.source afterQi.state := by
    change SourceCall Header.layout code 1 "point" [q.source] afterQi.state (IntervalCasts.value q.source q.source) afterQi.state
    rw[show q.source=RecordCasts.rational p.state.nats.values.length 0
      (SignedCalls.siResult l p.state p.cells p.top p.high 1).nats.values.length from RationalPowerCalls.one_source l p]
    exact RationalPointCalls.point_closed code lib.point qLive.1 qLive.2 (by decide +kernel : (0:Nat)<2^32)
  let e0 : CallEvents.Event Header.layout code 8:=
    ⟨"qi",[DecimalDigits.integer 1],p.state,q.source,afterQi.state,raise_once (raise_once qiCall)⟩
  let e1 : CallEvents.Event Header.layout code 8:=
    ⟨"point",[q.source],afterQi.state,result.source,afterQi.state,
      raise_once (raise_once (raise_once (raise_once (raise_once (raise_once (raise_once pointCall))))))⟩
  have size : afterQi.state.nats.values.length=p.state.nats.values.length+3 := by
    change (CursorFrames.advance l p [1,0,1]).state.nats.values.length=_
    rw[CursorEffects.size]
    rfl
  have unique : ([e0,e1].map CallEvents.timeKey).Nodup := by
    change [p.state.nats.values.length,afterQi.state.nats.values.length].Nodup
    simp only[List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,and_true,List.nodup_nil]
    constructor
    · omega
    · simp
  obtain ⟨service,answers,closed⟩:=CallEvents.timeline_service [e0,e1] unique
  have qiExpression : evalExpr Header.layout service 2 p.state (.call (.var "qi") [.nat 1])=some (q.source,afterQi.state):=
    ExpressionTemplates.call_one Header.layout service (by rfl) (answers e0 (List.mem_cons_self))
  have pointExpression : Eval Header.layout service (.call (.var "point") [.call (.var "qi") [.nat 1]]) p.state afterQi.state result.source :=
    ⟨3,ExpressionTemplates.call_one Header.layout service qiExpression
      (answers e1 (List.mem_cons_of_mem e0 (List.mem_cons_self)))⟩
  have branch : Run Header.layout service
      (.branch zeroCondition (.returnStmt (.call (.var "point") [.call (.var "qi") [.nat 1]])) .skip)
      p.state (.returned afterQi.state result.source) := by
    apply Loops.StmtRun.branch (zero_condition service c a 0 (by decide +kernel))
    simp only[UnsignedLiteralControl.truth_boolean,decide_true,↓reduceIte]
    exact Loops.StmtRun.returnValue pointExpression
  let bodyExit:=PoolContextPop.unframe p.state afterQi
  let finalCursor:=PoolContextPop.unframe c.state bodyExit
  have body : Run Header.layout service Generated.f_rpow.body p.state (.returned bodyExit.state result.source) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.returned branch)
    exact ⟨rfl,rfl⟩
  have finalLive : result.Live finalCursor.state:=⟨qLive,qLive⟩
  have bodyLive : result.Live bodyExit.state:=⟨qLive,qLive⟩
  have execution : SourceCall Header.layout code 9 "rpow" [a.source,PoolCalls.word 0] c.state result.source finalCursor.state := by
    apply installed_body (f:=Generated.f_rpow) (rank:=8) (service:=service) installed closed
      (bind_parameters c a 0 alive (by decide +kernel)) body
    exact ⟨Pair.cast bodyLive "static RI" (by decide +kernel),rfl⟩
  have qiContext : Valid l afterQi:=CursorFrames.advance_valid parameterContext [1,0,1] (by change c.top+3 ≤ PoolCalls.capacity;omega)
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have bodyContext : Valid l bodyExit:=PoolContextPop.valid qiContext
    (by change l.pool<(parameters c a 0).state.heap.length;rw[parameters_length];omega)
    (by change l.top<(parameters c a 0).state.heap.length;rw[parameters_length];omega)
    (by change l.high<(parameters c a 0).state.heap.length;rw[parameters_length];omega)
  have finalContext : Valid l finalCursor:=PoolContextPop.valid bodyContext hp ht hh
  have resultPositive : result.Positive:=⟨by change 0<(1:Nat);decide,by change 0<(1:Nat);decide⟩
  have value : q.mathematical.value=1:=RationalPowerCalls.one_value l p
  refine ⟨finalCursor,result,execution,finalContext,finalLive,resultPositive,?_,?_⟩
  · have decoded:=pair_decoded result finalLive resultPositive (le_refl _)
    simpa only[result,value,LeanCert.Core.IntervalRat.singleton] using decoded
  · change c.top+3 ≤ c.top+5120
    omega

end ScopedC.IntervalPowerCalls
