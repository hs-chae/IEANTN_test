/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerCounter
import ScopedC.LocalStorageSeparation

namespace ScopedC.IntervalPowerBits
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Physical facts for the actual first rpow loop. The exponent n is fixed;
the only written cell is the typed local bit. -/
structure Frame (l : PoolLayout) (n : Nat) where
  cursor : Cursor
  bit : Nat
  power : Nat
  nSlot : Nat
  bitSlot : Nat
  context : Valid l cursor
  atN : LocalBinding.At cursor.state "n" "unsigned int" (word n) nSlot
  atBit : LocalBinding.At cursor.state "bit" "unsigned int" (word bit) bitSlot
  distinct : nSlot≠bitSlot
  exponentBound : n<2^32
  positive : 0<bit
  lower : bit ≤ n
  powerEq : bit=2^power

def doubled {l : PoolLayout} {n : Nat} (f : Frame l n) (guard : f.bit ≤ n/2) : Frame l n := by
  have safe:=LocalStorageSeparation.pool f.context f.atBit (by decide +kernel : ("unsigned int":String)≠"unsigned")
  exact {
    cursor:=LocalAssignment.cursor f.cursor f.bitSlot "unsigned int" (word (f.bit*2))
    bit:=f.bit*2
    power:=f.power+1
    nSlot:=f.nSlot
    bitSlot:=f.bitSlot
    context:=LocalAssignment.valid f.context f.bitSlot "unsigned int" (word (f.bit*2)) safe.1 safe.2.1 safe.2.2
    atN:=LocalAssignment.other_binding (changedType:="unsigned int") (value:=word (f.bit*2)) f.atN f.distinct
    atBit:=LocalAssignment.binding f.atBit (by rfl)
    distinct:=f.distinct
    exponentBound:=f.exponentBound
    positive:=by have h:=f.positive;omega
    lower:=by omega
    powerEq:=by rw[f.powerEq,pow_succ] }

theorem doubled_execution (service : Call) {l : PoolLayout} {n : Nat} (f : Frame l n)
    (guard : f.bit ≤ n/2) : Run Header.layout service IntervalPowerCounter.doubleStatement
      f.cursor.state (.continuing (doubled f guard).cursor.state) := by
  apply Loops.StmtRun.evaluate
  exact IntervalPowerCounter.double_assignment service f.atBit (by have h:=f.exponentBound;omega)

theorem doubled_shape {l : PoolLayout} {n : Nat} (f : Frame l n) (guard : f.bit ≤ n/2) :
    (doubled f guard).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (doubled f guard).cursor.state.env=f.cursor.state.env ∧
    (doubled f guard).cursor.state.globals=f.cursor.state.globals ∧
    (doubled f guard).cursor.state.nats=f.cursor.state.nats ∧
    (doubled f guard).cursor.top=f.cursor.top := by
  change (f.cursor.state.heap.set f.bitSlot _).length=f.cursor.state.heap.length ∧ _
  exact ⟨List.length_set, rfl,rfl,rfl,rfl⟩

theorem doubled_other {l : PoolLayout} {n : Nat} (f : Frame l n) (guard : f.bit ≤ n/2)
    (slot : Nat) (different : slot≠f.bitSlot) :
    (doubled f guard).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  change (f.cursor.state.heap.set f.bitSlot _)[slot]?=_
  simp [different,Ne.symm different]

end ScopedC.IntervalPowerBits
