/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointInput
import ScopedC.ExpPointFrontMemory

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

theorem reduction_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    (reductionCursor stage).state.heap.length = c.state.heap.length+5 := by
  rw [reduction_nonzero,RationalDivideCalls.nonzero_heap_length]
  exact ((CursorEffects.shape l (afterPower stage) [powerValue stage,0,1]).1).trans
    (power_heap stage)

theorem input_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    (afterInput stage positive).state.heap.length = c.state.heap.length+7 := by
  change (((reductionCursor stage).state.heap++[_])++[_]).length = _
  rw [List.length_append,List.length_append,List.length_singleton,reduction_heap stage]
  rfl

theorem input_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    (afterInput stage positive).state.globals = c.state.globals := by
  change (reductionCursor stage).state.globals = _
  rw [reduction_nonzero,RationalDivideCalls.nonzero_globals]
  exact (CursorSingleFrames.advance_globals l (afterPower stage) [powerValue stage,0,1]).trans
    (power_globals stage)

theorem input_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator)
    {slot value : Nat} (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (afterInput stage positive).state.nats slot value := by
  change NatArena.Borrow (reductionCursor stage).state.nats slot value
  rw [reduction_nonzero]
  exact RationalDivideCalls.nonzero_borrow _ _
    (CursorBorrow.preserves (l:=l) (c:=afterPower stage) [powerValue stage,0,1]
      (power_borrow stage live))

theorem input_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator)
    (slot : Nat) (old : slot < c.state.heap.length)
    (hp : slot ≠ l.pool) (ht : slot ≠ l.top) (hh : slot ≠ l.high) :
    (afterInput stage positive).state.heap[slot]? = c.state.heap[slot]? := by
  have reductionLen := reduction_heap stage
  have reducedLen : (afterReduced stage positive).state.heap.length = c.state.heap.length+6 := by
    change ((reductionCursor stage).state.heap++[_]).length = _
    rw [List.length_append,List.length_singleton,reductionLen]
  have iOther : (afterInput stage positive).state.heap[slot]? =
      (afterReduced stage positive).state.heap[slot]? :=
    allocated_other _ _ _ _ slot (by omega)
  have rOther : (afterReduced stage positive).state.heap[slot]? =
      (reductionCursor stage).state.heap[slot]? :=
    allocated_other _ _ _ _ slot (by omega)
  rw [iOther,rOther,reduction_nonzero]
  rw [RationalDivideCalls.nonzero_other l (afterQiPower stage) q (qiPower stage) slot
    (by
      have h := (CursorEffects.shape l (afterPower stage) [powerValue stage,0,1]).1
      have p := power_heap stage
      change slot < (CursorFrames.advance l (afterPower stage) [powerValue stage,0,1]).state.heap.length
      rw [h,p]
      omega) hp ht hh]
  change (CursorFrames.advance l (afterPower stage) [powerValue stage,0,1]).state.heap[slot]? = _
  rw [CursorSingleFrames.advance_other l (afterPower stage) [powerValue stage,0,1] slot hp ht hh]
  exact power_other stage slot old hp ht hh

noncomputable def input_table {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) (valid : Valid l c)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs) :
    CoefficientTableRead.TableAt (afterInput stage positive).state base coeffs := by
  have safe := CoefficientTableRead.pool_separated valid table
  exact CoefficientTableRead.memory table
    (input_other stage positive base.object (List.getElem?_eq_some_iff.mp table.memory).choose
      safe.1 safe.2.1 safe.2.2) (fun _ _ h => input_borrow stage positive h)

theorem input_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator)
    {name : String} {object d : Nat} (depth : SourceUnsignedGlobal.At c.state name object d)
    (apart : object ≠ l.pool ∧ object ≠ l.top ∧ object ≠ l.high) :
    SourceUnsignedGlobal.At (afterInput stage positive).state name object d :=
  SourceUnsignedGlobal.memory depth (input_globals stage positive)
    (input_other stage positive object (List.getElem?_eq_some_iff.mp depth.storage).choose
      apart.1 apart.2.1 apart.2.2)

end ScopedC.ExpPointCalls
