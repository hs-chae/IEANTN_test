/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientExpTables
import ScopedC.UnsignedLocalSteps

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

theorem previous_source (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) :
    evalExpr Header.layout service 5 f.cursor.state
      (.index (.var "expCoeffs") (.binary "-" (.var "k") (.nat 1)))=
      some ((previous f).source,f.cursor.state) := by
  have bound : f.k<2^32 := by have h:=f.kBound;have h':=f.depthBound;omega
  exact CoefficientTableRead.source_index_writable service 2 f.expAt (f.k-1)
    (by have h:=f.expLength;have h':=f.kPositive;omega)
    (CoefficientTableRead.eval_global service 2 f.expAt f.expLookup f.expUnshadowed
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (ExpressionTemplates.binary Header.layout service
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (LocalBinding.eval service 1 f.kAt (by decide +kernel) (by decide +kernel)
        (by decide +kernel) (by decide +kernel)) (by rfl)
      (PoolCalls.binary_sub_one f.cursor.state f.k f.kPositive bound))

theorem expUpdate_assignment (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) (active : f.k ≤ d)
    (qiAnswer : service "qi" [PoolCalls.word f.k] f.cursor.state=
      some ((counterQ f).source,(counterQCursor f).state))
    (divideAnswer : service "qv" [(previous f).source,(counterQ f).source] (counterQCursor f).state=
      some ((expNext f).source,(expDivideCursor f).state)) :
    Eval Header.layout service
      (.binary "=" (.index (.var "expCoeffs") (.var "k"))
        (.call (.var "qv") [.index (.var "expCoeffs") (.binary "-" (.var "k") (.nat 1)),
          .call (.var "qi") [.var "k"]]))
      f.cursor.state (expStoreCursor f room).state (expNext f).source := by
  refine ⟨7,?_⟩
  unfold expStoreCursor
  exact CoefficientTableRead.source_assignment service 4 (dividedExpTable f room) (expNext f)
    (ExpressionTemplates.call_two Header.layout service (previous_source service f)
      (ExpressionTemplates.call_one Header.layout service
        (LocalBinding.eval service 3 f.kAt (by decide +kernel) (by decide +kernel)
          (by decide +kernel) (by decide +kernel)) qiAnswer) divideAnswer)
    (CoefficientTableRead.eval_global service 4 (dividedExpTable f room)
      (by rw[expDivide_globals];exact f.expLookup)
      (by rw[expDivide_env];exact f.expUnshadowed)
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (LocalBinding.eval service 4 (expDivide_k f) (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel))
    (by rfl) (by rw[dividedExp_cells,f.expExtent];have h:=f.depthBound;omega) (expNext_live f)

end ScopedC.PrepareSource
