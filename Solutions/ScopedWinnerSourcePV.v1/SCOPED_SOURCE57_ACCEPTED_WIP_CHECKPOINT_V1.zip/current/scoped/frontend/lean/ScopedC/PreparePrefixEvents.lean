/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PreparePrefix

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

noncomputable def prefixCalls (code : List Function) (lib : Library code)
    {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    List (CoefficientEvent code) := [
  ⟨"nu",[DecimalDigits.integer 1],(depthCursor ready d).state,
    .natObject (depthCursor ready d).state.nats.values.length,
    (ScalePrelude.afterOne (layout base) (depthCursor ready d)).state,
    SourceRanks.monotone (by decide +kernel)
      (ScalePrelude.one_source code lib.scale (l:=layout base) (c:=depthCursor ready d)
        (depthSeed ready d bound).context (by change (0:Nat)+2<PoolCalls.capacity;decide +kernel))⟩,
  ⟨"nu",[DecimalDigits.integer 100],(ScalePrelude.afterOne (layout base) (depthCursor ready d)).state,
    .natObject (ScalePrelude.afterOne (layout base) (depthCursor ready d)).state.nats.values.length,
    (ScalePrelude.afterHundred (layout base) (depthCursor ready d)).state,
    SourceRanks.monotone (by decide +kernel)
      (ScalePrelude.hundred_source code lib.scale (l:=layout base) (c:=depthCursor ready d)
        (depthSeed ready d bound).context (by change (0:Nat)+2<PoolCalls.capacity;decide +kernel))⟩,
  ⟨"nl",[.natObject (depthCursor ready d).state.nats.values.length,
      .natObject (ScalePrelude.afterOne (layout base) (depthCursor ready d)).state.nats.values.length],
    (ScalePrelude.afterHundred (layout base) (depthCursor ready d)).state,
    .natObject (ScalePrelude.slot (layout base) (depthCursor ready d)),
    (ScalePrelude.shifted (layout base) (depthCursor ready d)).state,
    SourceRanks.monotone (by decide +kernel)
      (ScalePrelude.shift_source code lib.scale (l:=layout base) (c:=depthCursor ready d)
        (depthSeed ready d bound).context (by change (0:Nat)+2<PoolCalls.capacity;decide +kernel))⟩,
  ⟨"qi",[DecimalDigits.integer 1],(actualSeed ready d bound).cursor.state,
    (initOne (actualSeed ready d bound)).source,(initOneCursor (actualSeed ready d bound)).state,
    SourceRanks.monotone (by decide +kernel)
      (initOne_source code lib.coefficients (actualSeed ready d bound)
        (by rw[actualSeed_top];decide +kernel))⟩,
  ⟨"qi",[DecimalDigits.integer 0],(initExpCursor (actualSeed ready d bound)).state,
    (initZero (actualSeed ready d bound)).source,(initZeroCursor (actualSeed ready d bound)).state,
    SourceRanks.monotone (by decide +kernel)
      (initZero_source code lib.coefficients (actualSeed ready d bound)
        (by rw[actualSeed_top];decide +kernel))⟩]

theorem prefix_one_size {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) :
    (ScalePrelude.afterOne (layout base) (depthCursor ready d)).state.nats.values.length=
      state.nats.values.length+1 := by
  rw[ScalePrelude.afterOne,PoolCursor.size]
  rfl

theorem prefix_hundred_size {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) :
    (ScalePrelude.afterHundred (layout base) (depthCursor ready d)).state.nats.values.length=
      state.nats.values.length+2 := by
  rw[ScalePrelude.afterHundred,PoolCursor.size,prefix_one_size]

theorem prefix_seed_size {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat)
    (bound : d ≤ 64) :
    (actualSeed ready d bound).cursor.state.nats.values.length=state.nats.values.length+3 := by
  change (CursorFrames.advance (layout base) (depthCursor ready d) [1,100,1<<<100]).state.nats.values.length=_
  rw[CursorEffects.size]
  rfl

theorem prefix_exp_size {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat)
    (bound : d ≤ 64) :
    (initExpCursor (actualSeed ready d bound)).state.nats.values.length=state.nats.values.length+6 := by
  unfold initExpCursor
  change (CursorFrames.advance (layout base) (actualSeed ready d bound).cursor [1,0,1]).state.nats.values.length=_
  rw[CursorEffects.size,prefix_seed_size]
  rfl

theorem prefix_start_size {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat)
    (bound : d ≤ 64) :
    (coefficientStart ready d bound).cursor.state.nats.values.length=state.nats.values.length+9 := by
  change (initAtanhCursor (actualSeed ready d bound) _).state.nats.values.length=_
  unfold initAtanhCursor
  change (CursorFrames.advance (layout base) (initExpCursor (actualSeed ready d bound)) [0,0,1]).state.nats.values.length=_
  rw[CursorEffects.size,prefix_exp_size]
  rfl

theorem prefixCalls_unique (code : List Function) (lib : Library code)
    {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    ((prefixCalls code lib ready d bound).map CallEvents.timeKey).Nodup := by
  change [(depthCursor ready d).state.nats.values.length,
    (ScalePrelude.afterOne (layout base) (depthCursor ready d)).state.nats.values.length,
    (ScalePrelude.afterHundred (layout base) (depthCursor ready d)).state.nats.values.length,
    (actualSeed ready d bound).cursor.state.nats.values.length,
    (initExpCursor (actualSeed ready d bound)).state.nats.values.length].Nodup
  rw[prefix_one_size,prefix_hundred_size,prefix_seed_size,prefix_exp_size]
  change [state.nats.values.length,state.nats.values.length+1,state.nats.values.length+2,
    state.nats.values.length+3,state.nats.values.length+6].Nodup
  simp only[List.nodup_cons,List.mem_cons,List.not_mem_nil,not_or,
    not_false_eq_true,List.nodup_nil,and_true]
  omega

theorem prefixCalls_bounds (code : List Function) (lib : Library code)
    {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64)
    (e : CoefficientEvent code) (member : e∈prefixCalls code lib ready d bound) :
    e.before.nats.values.length<(coefficientStart ready d bound).cursor.state.nats.values.length := by
  have one:=prefix_one_size ready d
  have hundred:=prefix_hundred_size ready d
  have seed:=prefix_seed_size ready d bound
  have exp:=prefix_exp_size ready d bound
  have finish:=prefix_start_size ready d bound
  simp only[prefixCalls,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl|rfl|rfl|rfl|rfl <;> dsimp only <;>
    first | omega | (change state.nats.values.length<_ ;omega)

noncomputable def prepareEvents {code : List Function} (lib : Library code) {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) : List (CoefficientEvent code) :=
  prefixCalls code lib ready d bound++stage.loop.events

theorem prepareEvents_unique {code : List Function} (lib : Library code) {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) :
    ((prepareEvents lib stage).map CallEvents.timeKey).Nodup := by
  rw[prepareEvents,List.map_append,List.nodup_append]
  refine ⟨prefixCalls_unique code lib ready d bound,stage.loop.unique,?_⟩
  intro a ha b hb same
  obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
  obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
  have left:=prefixCalls_bounds code lib ready d bound ea hea
  have right:=stage.loop.bounds eb heb
  have keyEq:=ka.trans (same.trans kb.symm)
  change ea.before.nats.values.length=eb.before.nats.values.length at keyEq
  omega

theorem prepareEvents_answers {code : List Function} (lib : Library code) {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) (service : Call)
    (answers : CoefficientEventAnswers service (prepareEvents lib stage)) : PrefixAnswers service stage := by
  have front : CoefficientEventAnswers service (prefixCalls code lib ready d bound):=
    fun e member=>answers e (List.mem_append_left _ member)
  refine ⟨⟨front _ List.mem_cons_self,
    front _ (List.mem_cons_of_mem _ List.mem_cons_self),
    front _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))⟩,
    front _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ List.mem_cons_self))),
    front _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_of_mem _
      (List.mem_cons_of_mem _ List.mem_cons_self)))),?_⟩
  exact fun e member=>answers e (List.mem_append_right _ member)

theorem prepare_prefix_source {code : List Function} (lib : Library code) {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) :
    ∃service : Call,
      Loops.SeqRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
        preparePrefix (parameters (staticCursor ready) d).state
        (.continuing stage.loop.finish.cursor.state) ∧
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 7 name args before value after) := by
  obtain ⟨service,answers,closed⟩:=CallEvents.timeline_service (prepareEvents lib stage) (prepareEvents_unique lib stage)
  exact ⟨service,prepare_prefix_run service stage (prepareEvents_answers lib stage service answers),closed⟩

end ScopedC.PrepareSource
