/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEventDistinct
namespace ScopedC.CallEvents
open ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false
set_option maxHeartbeats 100000
/-- A compositional lookup adapter. Both events already contain complete actual
lower-rank SourceCall proofs; the adapter cannot introduce an output oracle. -/
theorem pair_second {cfg : Layout} {code : List ScopedC.Syntax.Function} {rank : Nat}
    (first second : Event cfg code rank) (different : second.before≠first.before) :
    append (one first) (one second) second.name second.args second.before=some (second.value,second.after) :=
  append_right (one_before_other first different) (one_self second)

/-- Expose an opaque compositional service with both actual source-call proofs.
Keeping the service abstract prevents proof elaboration from normalizing
large symbolic application heaps inside the finite event lookup. -/
theorem pair_service {cfg : Layout} {code : List ScopedC.Syntax.Function} {rank : Nat}
    (first second : Event cfg code rank) (different : second.before≠first.before) :
    ∃service : Call,
      service first.name first.args first.before=some (first.value,first.after) ∧
      service second.name second.args second.before=some (second.value,second.after) ∧
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall cfg code rank name args before value after) := by
  refine ⟨append (one first) (one second),append_left (one_self first),pair_second first second different,?_⟩
  intro name args before value after h
  exact append_closed (fun _ _ _ _ _ h=>one_closed first h) (fun _ _ _ _ _ h=>one_closed second h) h
end ScopedC.CallEvents
