/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointReturn
import ScopedC.CallEventNames

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] reduction inputPair afterInput afterReduced
  qiPower afterQiPower sumPair sumCursor afterPower afterK afterSmall afterLog afterM
  afterAdd afterOne afterCeil mValue kValue powerValue

section
variable {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
variable {stage : CeilStage code l c q} {positive : 0 < q.denominator}
variable {base : Address} {coeffs : List Input} {d : Nat}
variable {t : TaylorStage stage positive base coeffs d}

/-- Only finite, already proved calls from the original source, in its actual
argument-evaluation order. The service has no assumed successful effect. -/
structure Answers (service : Call) (r : RemainderStage t) (p : PowerStage r) : Prop where
  absoluteCall : service "qabs" [q.source] (parameters c q).state =
    some ((absolute q).source,(afterAbs l c q).state)
  ceiling : service "ceilQ" [(absolute q).source] (afterAbs l c q).state =
    some (stage.endpoint.source,stage.out.state)
  one : service "nu" [DecimalDigits.integer 1] (afterCeil stage).state =
    some ((.natObject (afterCeil stage).state.nats.values.length),(afterOne stage).state)
  addition : service "na" [.natObject stage.endpoint.slot,.natObject (afterCeil stage).state.nats.values.length] (afterOne stage).state =
    some ((.natObject (mSlot stage)),(afterAdd stage).state)
  logarithm : service "lean_nat_log2" [.natObject (mSlot stage)] (afterM stage).state =
    some ((.natObject (afterM stage).state.nats.values.length),(SourceNatLog2.allocated (afterM stage) (mValue stage)))
  registration : service "keep" [.natObject (afterM stage).state.nats.values.length] (SourceNatLog2.allocated (afterM stage) (mValue stage)) =
    some ((.natObject (afterM stage).state.nats.values.length),(afterLog stage).state)
  small : service "small" [.natObject (afterM stage).state.nats.values.length] (afterLog stage).state =
    some ((PoolCalls.word (kValue stage)),(afterSmall stage).state)
  unsigned : service "qi" [PoolCalls.word (powerValue stage)] (afterPower stage).state =
    some ((qiPower stage).source,(afterQiPower stage).state)
  division : service "qv" [q.source,(qiPower stage).source] (afterQiPower stage).state =
    some ((reduction stage positive).source,(reductionCursor stage).state)
  singleton : service "point" [(reduction stage positive).source] (afterReduced stage positive).state =
    some ((inputPair stage positive).source,(afterReduced stage positive).state)
  polynomial : service "taylor" [.pointer base true,(inputPair stage positive).source] (afterInput stage positive).state =
    some (t.output.source,t.out.state)
  error : service "expRemainder" [(inputPair stage positive).source] t.out.state =
    some (r.output.source,r.out.state)
  sum : service "radd" [t.output.source,r.output.source] r.out.state =
    some ((sumPair r).source,(sumCursor r).state)
  power : service "rpow" [(sumPair r).source,PoolCalls.word (powerValue stage)] (sumCursor r).state =
    some (p.output.source,p.out.state)

theorem source_service (lib : Library code) (valid : Valid l c) (live : q.Live c.state)
    (r : RemainderStage t) (p : PowerStage r) (bound : kValue stage < 32)
    (dBound : d ≤ 64) (room : c.top+16000 < PoolCalls.capacity) :
    ∃ service : Call,
      (∀ name args s v out, service name args s=some (v,out) →
        SourceCall Header.layout code 10 name args s v out) ∧ Answers service r p := by
  let e0 : CallEvents.Event Header.layout code 10 :=
    ⟨"qabs",[q.source],(parameters c q).state,(absolute q).source,(afterAbs l c q).state,
      SourceRanks.monotone (by decide +kernel) (absolute_source code lib.front.count.ceil valid q live (by omega))⟩
  let e1 : CallEvents.Event Header.layout code 10 :=
    ⟨"ceilQ",[(absolute q).source],(afterAbs l c q).state,stage.endpoint.source,stage.out.state,
      SourceRanks.monotone (by decide +kernel) (stage.execution)⟩
  let e2 : CallEvents.Event Header.layout code 10 :=
    ⟨"nu",[DecimalDigits.integer 1],(afterCeil stage).state,(.natObject (afterCeil stage).state.nats.values.length),(afterOne stage).state,
      SourceRanks.monotone (by decide +kernel) (one_source code lib.front.count stage (by omega))⟩
  let e3 : CallEvents.Event Header.layout code 10 :=
    ⟨"na",[.natObject stage.endpoint.slot,.natObject (afterCeil stage).state.nats.values.length],(afterOne stage).state,(.natObject (mSlot stage)),(afterAdd stage).state,
      SourceRanks.monotone (by decide +kernel) (add_source code lib.front.count stage (by omega))⟩
  let e4 : CallEvents.Event Header.layout code 10 :=
    ⟨"lean_nat_log2",[.natObject (mSlot stage)],(afterM stage).state,(.natObject (afterM stage).state.nats.values.length),(SourceNatLog2.allocated (afterM stage) (mValue stage)),
      SourceRanks.monotone (by decide +kernel) (log_source stage)⟩
  let e5 : CallEvents.Event Header.layout code 10 :=
    ⟨"keep",[.natObject (afterM stage).state.nats.values.length],(SourceNatLog2.allocated (afterM stage) (mValue stage)),(.natObject (afterM stage).state.nats.values.length),(afterLog stage).state,
      SourceRanks.monotone (by decide +kernel) (keep_source code lib.front.count stage (by omega))⟩
  let e6 : CallEvents.Event Header.layout code 10 :=
    ⟨"small",[.natObject (afterM stage).state.nats.values.length],(afterLog stage).state,(PoolCalls.word (kValue stage)),(afterSmall stage).state,
      SourceRanks.monotone (by decide +kernel) (small_source code lib.front.count stage bound (by omega))⟩
  let e7 : CallEvents.Event Header.layout code 10 :=
    ⟨"qi",[PoolCalls.word (powerValue stage)],(afterPower stage).state,(qiPower stage).source,(afterQiPower stage).state,
      SourceRanks.monotone (by decide +kernel) (qi_power_source code lib.front stage bound (by omega))⟩
  let e8 : CallEvents.Event Header.layout code 10 :=
    ⟨"qv",[q.source,(qiPower stage).source],(afterQiPower stage).state,(reduction stage positive).source,(reductionCursor stage).state,
      SourceRanks.monotone (by decide +kernel) (reduction_source code lib.front stage live positive (by omega))⟩
  let e9 : CallEvents.Event Header.layout code 10 :=
    ⟨"point",[(reduction stage positive).source],(afterReduced stage positive).state,(inputPair stage positive).source,(afterReduced stage positive).state,
      SourceRanks.monotone (by decide +kernel) (point_source code lib.front stage positive)⟩
  let e10 : CallEvents.Event Header.layout code 10 :=
    ⟨"taylor",[.pointer base true,(inputPair stage positive).source],(afterInput stage positive).state,t.output.source,t.out.state,
      SourceRanks.monotone (by decide +kernel) (t.execution)⟩
  let e11 : CallEvents.Event Header.layout code 10 :=
    ⟨"expRemainder",[(inputPair stage positive).source],t.out.state,r.output.source,r.out.state,
      SourceRanks.monotone (by decide +kernel) (r.execution)⟩
  let e12 : CallEvents.Event Header.layout code 10 :=
    ⟨"radd",[t.output.source,r.output.source],r.out.state,(sumPair r).source,(sumCursor r).state,
      SourceRanks.monotone (by decide +kernel) (sum_source lib r dBound room)⟩
  let e13 : CallEvents.Event Header.layout code 10 :=
    ⟨"rpow",[(sumPair r).source,PoolCalls.word (powerValue stage)],(sumCursor r).state,p.output.source,p.out.state,
      SourceRanks.monotone (by decide +kernel) (p.execution)⟩
  let events := [e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10,e11,e12,e13]
  have unique : (events.map CallEvents.Event.name).Nodup := by
    change (["qabs", "ceilQ", "nu", "na", "lean_nat_log2", "keep", "small", "qi", "qv", "point", "taylor", "expRemainder", "radd", "rpow"] : List String).Nodup
    decide +kernel
  let service := CallEvents.service events
  refine ⟨service, (fun _ _ _ _ _ answer => CallEvents.service_closed events answer), ?_⟩
  constructor
  · exact CallEvents.service_self_names events unique e0 (List.Mem.head _)
  · exact CallEvents.service_self_names events unique e1 (List.Mem.tail _ (List.Mem.head _))
  · exact CallEvents.service_self_names events unique e2 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))
  · exact CallEvents.service_self_names events unique e3 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))))
  · exact CallEvents.service_self_names events unique e4 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))))
  · exact CallEvents.service_self_names events unique e5 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))))))
  · exact CallEvents.service_self_names events unique e6 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))))))
  · exact CallEvents.service_self_names events unique e7 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))))))))
  · exact CallEvents.service_self_names events unique e8 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))))))))
  · exact CallEvents.service_self_names events unique e9 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))))))))))
  · exact CallEvents.service_self_names events unique e10 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))))))))))
  · exact CallEvents.service_self_names events unique e11 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))))))))))))
  · exact CallEvents.service_self_names events unique e12 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))))))))))))
  · exact CallEvents.service_self_names events unique e13 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))))))))))))))

end
end ScopedC.ExpPointCalls
