/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhRemainderEffects

namespace ScopedC.AtanhCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

theorem guard_unshadowed (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input)
    (name : String) (nq : name≠"q") (nr : name≠"r") :
    (afterGuard l c q).state.env.lookup name=none := by
  rw[guard_trace,(CursorEffects.shape l (afterR l c q) (guardValues l c q)).2]
  change (("r",_)::(next l (parameters c q) 0).state.env).lookup name=none
  rw[(PoolCursor.shape l (parameters c q) 0).2]
  have bq : (name=="q")=false:=beq_eq_false_iff_ne.mpr nq
  have br : (name=="r")=false:=beq_eq_false_iff_ne.mpr nr
  simp [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate,List.lookup,bq,br]

theorem remainder_unshadowed {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (name : String)
    (nq : name≠"q") (nr : name≠"r") (ne : name≠"error") (nm : name≠"remainder") :
    (afterRemainder stage positive).state.env.lookup name=none := by
  have before : (errorCursor stage positive).state.env.lookup name=none := by
    rw[error_env _ _ narrow,stage.env]
    exact guard_unshadowed l c q name nq nr
  change (("remainder",_)::(next l (storedError stage positive) 0).state.env).lookup name=none
  rw[(PoolCursor.shape l (storedError stage positive) 0).2]
  change (("remainder",_)::("error",_)::(errorCursor stage positive).state.env).lookup name=none
  have be : (name=="error")=false:=beq_eq_false_iff_ne.mpr ne
  have bm : (name=="remainder")=false:=beq_eq_false_iff_ne.mpr nm
  simp [List.lookup,be,bm,before]

end ScopedC.AtanhCalls
