/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorEntryData

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem loop_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) (base : Address) (a : Pair) (d : Nat) : Valid l (loopStart l c base a d) :=
  CursorLocals.allocated_valid (CursorLocals.allocated_valid
    (CursorFrames.advance_valid (parameters_valid ctx base a) [0,0,1] (by change c.top+3 ≤ PoolCalls.capacity;omega))
    "RI" "result" (zeroPair l c base a).source) "unsigned int" "k" (PoolCalls.word (d+1))

def loop_table {l : PoolCalls.PoolLayout} {c : Cursor} {base : Address} {coeffs : List Input}
    (ctx : Valid l c) (table : CoefficientTableRead.TableAt c.state base coeffs) (a : Pair) (d : Nat) :
    CoefficientTableRead.TableAt (loopStart l c base a d).state base coeffs :=
  CoefficientTableRead.allocated (CoefficientTableRead.allocated
    (CoefficientTableRead.advanced (parameters_valid ctx base a) (parameters_table table a) [0,0,1])
    "RI" "result" (some (zeroPair l c base a).source)) "unsigned int" "k" (some (PoolCalls.word (d+1)))

theorem stored_depth {l : PoolCalls.PoolLayout} {c : Cursor} {object d : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object d) (base : Address) (a : Pair)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At (stored l c base a).state "depth" object d :=
  SourceUnsignedGlobal.allocated (SourceUnsignedGlobal.advanced (parameters_depth depth base a) [0,0,1] apart.1 apart.2.1 apart.2.2)
    "RI" "result" (some (zeroPair l c base a).source)

theorem depth_unshadowed (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) :
    (stored l c base a).state.env.lookup "depth"=none := by
  change (("result",⟨(afterZero l c base a).state.heap.length,0,[]⟩)::(afterZero l c base a).state.env).lookup "depth"=none
  rw[(zero_shape l c base a).2]
  simp [parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.lookup]

/-- Actual depth+1 global read, addition and typed k declaration. The
physical global and its separation from mutated pool objects are caller
application obligations, supplied from the real source global layout. -/
theorem k_declaration (service : Call) {l : PoolCalls.PoolLayout} {c : Cursor} {object d : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object d) (base : Address) (a : Pair)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (bound : d+1<2^32) :
    Declare Header.layout service [{type:="unsigned int",name:="k",value:=some (.binary "+" (.var "depth") (.nat 1)),arrayExtent:=none}]
      (stored l c base a).state (loopStart l c base a d).state := by
  have readDepth:=SourceUnsignedGlobal.eval service 998 (stored_depth depth base a apart) (depth_unshadowed l c base a)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have expression:=ExpressionTemplates.binary Header.layout service
    (op:="+") (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    readDepth (show evalExpr Header.layout service 999 (stored l c base a).state (.nat 1)=some (DecimalDigits.integer 1,(stored l c base a).state) from rfl)
    (PoolCalls.binary_add_one (stored l c base a).state d bound)
  have convert : castValue Header.layout (stored l c base a).state 100 "unsigned int" (PoolCalls.word (d+1))=some (PoolCalls.word (d+1)) :=
    RationalUnsignedCalls.cast_parameter (stored l c base a).state (d+1) bound
  simp only[Declare,declarations,List.foldlM,expression,Bind.bind,Option.bind,convert]
  rfl

theorem initial_frame {l : PoolCalls.PoolLayout} {c : Cursor} {base : Address} {coeffs : List Input}
    (ctx : Valid l c) (room : c.top+2<PoolCalls.capacity) (table : CoefficientTableRead.TableAt c.state base coeffs)
    (a : Pair) (alive : a.Live c.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (d : Nat) (length : coeffs.length=d+1) (bound : d+1<2^32) :
    ∃f : Frame l base coeffs,f.cursor=loopStart l c base a d ∧ f.a=a ∧ f.result=zeroPair l c base a ∧ f.k=d+1 := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have coeffAt : LocalBinding.At (afterZero l c base a).state "coeffs" "const Q*" (.pointer base false) c.state.heap.length :=
    LocalBinding.advance (parameters_coeff c base a) [0,0,1] (by omega) (by omega) (by omega)
  have aAt : LocalBinding.At (afterZero l c base a).state "a" "RI" a.source (c.state.heap.length+1) :=
    LocalBinding.advance (parameters_a c base a) [0,0,1] (by omega) (by omega) (by omega)
  have resultAt : LocalBinding.At (stored l c base a).state "result" "RI" (zeroPair l c base a).source (c.state.heap.length+2) := by
    simpa only[stored,CursorLocals.allocated,(zero_shape l c base a).1,parameters_length] using
      LocalBinding.allocate_head (afterZero l c base a).state "result" "RI" (zeroPair l c base a).source (Pair.initialized _)
  have kAt : LocalBinding.At (loopStart l c base a d).state "k" "unsigned int" (PoolCalls.word (d+1)) (c.state.heap.length+3) := by
    simpa only[loopStart,CursorLocals.allocated,stored_length] using
      LocalBinding.allocate_head (stored l c base a).state "k" "unsigned int" (PoolCalls.word (d+1)) (by rfl)
  have aLive : a.Live (afterZero l c base a).state :=
    ⟨⟨CursorBorrow.preserves [0,0,1] alive.1.1,CursorBorrow.preserves [0,0,1] alive.1.2⟩,
      ⟨CursorBorrow.preserves [0,0,1] alive.2.1,CursorBorrow.preserves [0,0,1] alive.2.2⟩⟩
  refine ⟨{
    cursor:=loopStart l c base a d
    a:=a
    result:=zeroPair l c base a
    k:=d+1
    coeffSlot:=c.state.heap.length
    aSlot:=c.state.heap.length+1
    kSlot:=c.state.heap.length+3
    rSlot:=c.state.heap.length+2
    context:=loop_valid ctx room base a d
    coeffAt:=LocalBinding.allocate_other (LocalBinding.allocate_other coeffAt "result" "RI" _ (by decide +kernel)) "k" "unsigned int" _ (by decide +kernel)
    aAt:=LocalBinding.allocate_other (LocalBinding.allocate_other aAt "result" "RI" _ (by decide +kernel)) "k" "unsigned int" _ (by decide +kernel)
    kAt:=kAt
    rAt:=LocalBinding.allocate_other resultAt "k" "unsigned int" _ (by decide +kernel)
    table:=loop_table ctx table a d
    aLive:=aLive
    rLive:=zero_live l c base a
    aPositive:=positive
    rPositive:=⟨by change 0<(1:Nat);omega,by change 0<(1:Nat);omega⟩
    aOrder:=order
    rOrder:=le_refl _
    kLength:=by rw[length]
    kBound:=bound
    arDistinct:=by omega
  },rfl,rfl,rfl,rfl⟩

end ScopedC.TaylorCalls
