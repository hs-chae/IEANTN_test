/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareStaticState

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

theorem mutable_names_fresh : ∀key∈mutableNames,key∉DataInputs.families.map Prod.fst := by
  intro key member
  simp only[mutableNames,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel

def install_static {s : State} {base : Nat} (ready : StaticAt s base)
    (type name : String) (values : List Value) (fresh : name∉mutableNames) :
    StaticAt (DataInit.installArray s type name values) base := by
  apply transport (t:=DataInit.installArray s type name values) ready [DataInit.arrayObject type values] rfl rfl
  intro key member
  have different : key≠name := by intro same;exact fresh (same ▸ member)
  simp only[DataInit.installArray,List.lookup_cons,beq_eq_false_iff_ne.mpr different]

/-- All actual source globals initialize before prepare. The coefficient tables
are still only empty valid prefixes of real static Q arrays, and scale/ln2 still
contain their actual null-pointer zeros. No prepared application state is assumed. -/
theorem complete_initialization (platform : State) :
    ∃final : State,DataComplete.initializeProgramGlobals platform=some final ∧
      Nonempty (StaticAt final platform.heap.length) := by
  obtain ⟨inputs,inputRun,inputContext,inputEnv,inputNats,stable,inputObjects,inputHeap⟩:=
    DataInputs.actual_input_initialization (ScopedIO.ApplicationInit.after platform)
  let inputReady : StaticAt inputs platform.heap.length:=transport (initial_static platform)
    inputObjects inputHeap inputNats (fun key member=>stable key (mutable_names_fresh key member))
  obtain ⟨rows,rowRun,rowContext⟩:=DataRows.actual_rows_initialization inputs inputContext inputEnv
  let rowState:=DataInit.installArray inputs "Row" "allRows" rows
  let depths:=DataDepths.originalDepths.map NatWrapperCalls.unsigned32
  let final:=DataInit.installArray rowState "unsigned" "allDepths" depths
  have rowReady : StaticAt rowState platform.heap.length:=
    install_static inputReady "Row" "allRows" rows (by simp [mutableNames])
  have finalReady : StaticAt final platform.heap.length:=
    install_static rowReady "unsigned" "allDepths" depths (by simp [mutableNames])
  refine ⟨final,?_,⟨finalReady⟩⟩
  rw[DataComplete.initialization_stages,ScopedIO.ApplicationInit.actual_global_initialization]
  simp only[Bind.bind,Option.bind,inputRun,rowRun,DataDepths.actual_depth_initialization,pure]
  rfl

end ScopedC.PrepareSource
