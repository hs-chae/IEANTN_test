/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerInitialization

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def accProduct {l : PoolCalls.PoolLayout} (f : Frame l) : Input :=
  RationalProductApplicability.output l f.cursor f.accumulator f.current

theorem product_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+10<PoolCalls.capacity) (a b : Input) : Valid l (RationalMultiplyCalls.c11 l c a b) := by
  rw[RationalMultiplyTrace.c11_advance]
  apply CursorFrames.advance_valid ctx
  change c.top+11≤PoolCalls.capacity
  omega

@[irreducible] def accNext {l : PoolCalls.PoolLayout} (f : Frame l) : Cursor :=
  RationalMultiplyCalls.c11 l f.cursor f.accumulator f.current

theorem accNext_context {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    Valid l (accNext f) := by
  unfold accNext
  exact product_context f.context room f.accumulator f.current

theorem accNext_aLive {l : PoolCalls.PoolLayout} (f : Frame l) : f.current.Live (accNext f).state := by
  unfold accNext
  exact RationalProductApplicability.preserves_input (l:=l) (c:=f.cursor) (a:=f.accumulator) (b:=f.current) f.aLive

theorem accNext_rLive {l : PoolCalls.PoolLayout} (f : Frame l) : (accProduct f).Live (accNext f).state := by
  unfold accNext accProduct
  exact RationalProductApplicability.live l f.cursor f.accumulator f.current

theorem accNext_binding {l : PoolCalls.PoolLayout} (f : Frame l)
    {name ty : String} {value : Value} {slot : Nat}
    (h : LocalBinding.At f.cursor.state name ty value slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    LocalBinding.At (accNext f).state name ty value slot := by
  unfold accNext
  exact RationalProductApplicability.preserves_binding (l:=l) (c:=f.cursor) f.accumulator f.current h hp ht hh

/-- The new metadata is the actual qt effects followed by the actual typed
store to the result cell. Every other physical loop invariant is rederived. -/
def accumulate {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) : Frame l := by
  have aSafe:=LocalStorageSeparation.pool (l:=l) (c:=f.cursor) f.context f.aAt (by decide +kernel : ("Q":String)≠"unsigned")
  have nSafe:=LocalStorageSeparation.pool (l:=l) (c:=f.cursor) f.context f.nAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  have rSafe:=LocalStorageSeparation.pool (l:=l) (c:=f.cursor) f.context f.rAt (by decide +kernel : ("Q":String)≠"unsigned")
  have atA:=accNext_binding f f.aAt aSafe.1 aSafe.2.1 aSafe.2.2
  have atN:=accNext_binding f f.nAt nSafe.1 nSafe.2.1 nSafe.2.2
  have atR:=accNext_binding f f.rAt rSafe.1 rSafe.2.1 rSafe.2.2
  exact {
    cursor:=LocalAssignment.cursor (accNext f) f.rSlot "Q" (accProduct f).source
    current:=f.current
    accumulator:=accProduct f
    exponent:=f.exponent
    aSlot:=f.aSlot
    nSlot:=f.nSlot
    rSlot:=f.rSlot
    context:=LocalAssignment.valid (l:=l) (c:=accNext f) (accNext_context f room)
      f.rSlot "Q" (accProduct f).source rSafe.1 rSafe.2.1 rSafe.2.2
    aAt:=LocalAssignment.other_binding (changedType:="Q") (value:=(accProduct f).source) atA f.arDistinct
    nAt:=LocalAssignment.other_binding (changedType:="Q") (value:=(accProduct f).source) atN
      (LocalStorageSeparation.typed f.nAt f.rAt (by decide +kernel))
    rAt:=LocalAssignment.binding (value:=(accProduct f).source) atR (RationalProductApplicability.initialized (accProduct f))
    aLive:=by change f.current.Live (accNext f).state;exact accNext_aLive f
    rLive:=by change (accProduct f).Live (accNext f).state;exact accNext_rLive f
    aPositive:=f.aPositive
    rPositive:=RationalProductApplicability.positive l f.cursor f.accumulator f.current f.rPositive f.aPositive
    exponentBound:=f.exponentBound
    arDistinct:=f.arDistinct }

theorem accumulate_call (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout}
    (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qt" [f.accumulator.source,f.current.source] f.cursor.state
      (accProduct f).source (RationalMultiplyCalls.c11 l f.cursor f.accumulator f.current).state :=
  RationalMultiplyCalls.qt_closed code lib.qt lib.productLibrary f.context room
    f.accumulator f.current f.rLive f.aLive f.rPositive f.aPositive

theorem accumulate_source (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+10<PoolCalls.capacity)
    (answer : service "qt" [f.accumulator.source,f.current.source] f.cursor.state=
      some ((accProduct f).source,(RationalMultiplyCalls.c11 l f.cursor f.accumulator f.current).state)) :
    Eval Header.layout service (.binary "=" (.var "result") (.call (.var "qt") [.var "result",.var "a"]))
      f.cursor.state (accumulate f room).cursor.state (accProduct f).source := by
  have rhs:=ExpressionTemplates.call_two Header.layout service
    (LocalBinding.eval service 1 f.rAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (LocalBinding.eval service 1 f.aAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) answer
  have safe:=LocalStorageSeparation.pool (l:=l) (c:=f.cursor) f.context f.rAt (by decide +kernel : ("Q":String)≠"unsigned")
  have middle:=RationalProductApplicability.preserves_binding (l:=l) (c:=f.cursor) f.accumulator f.current f.rAt safe.1 safe.2.1 safe.2.2
  refine ⟨4,?_⟩
  change evalExpr Header.layout service 4 f.cursor.state _=
    some ((accProduct f).source,LocalAssignment.changed (accNext f).state f.rSlot "Q" (accProduct f).source)
  rw[accNext]
  exact LocalAssignment.evaluate service 2 rhs middle
    (Input.cast "Q" (by decide +kernel) (RationalProductApplicability.live l f.cursor f.accumulator f.current))

theorem accumulate_value {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (accumulate f room).accumulator.mathematical.value=f.accumulator.mathematical.value*f.current.mathematical.value :=
  RationalProductApplicability.mathematical l f.cursor f.accumulator f.current f.rPositive f.aPositive

theorem accumulate_top {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (accumulate f room).cursor.top=f.cursor.top+11 := by
  change (accNext f).top=f.cursor.top+11
  rw[accNext]
  exact RationalMultiplyCalls.top11 l f.cursor f.accumulator f.current

end ScopedC.RationalPowerCalls
