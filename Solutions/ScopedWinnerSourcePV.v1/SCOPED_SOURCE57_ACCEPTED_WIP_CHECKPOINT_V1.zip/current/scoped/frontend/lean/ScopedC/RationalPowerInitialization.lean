/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerFrame

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  qi : Generated.f_qi∈code
  si : Generated.f_si∈code
  qt : Generated.f_qt∈code
  productLibrary : RationalMultiplyCalls.Library code

/-- The actual qi(1) source execution, including signed-literal argument
conversion and its three allocation/keep effects, at the real qpow frame. -/
theorem initialization_call (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) (a : Input) (n : Nat) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1] (parameters c a n).state
      (oneQ l (parameters c a n)).source (oneCursor l (parameters c a n)).state := by
  have execution:=RationalUnsignedCalls.qi_call (input:=DecimalDigits.integer 1) (n:=1)
    code lib.qi lib.si lib.productLibrary.smake lib.productLibrary.nz lib.productLibrary.nu
    lib.productLibrary.ne lib.productLibrary.keep
    (CursorFrames.framed_valid ctx "Q" "a" a.source "unsigned int" "n" (PoolCalls.word n))
    room (by decide +kernel) (by rfl)
  simpa only[one_source,one_state,parameters] using execution

/-- Exact first declaration Q result=qi(1). The answer premise is supplied
by initialization_call in the final complete source-call composition. -/
theorem initialization_declaration (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor)
    (a : Input) (n : Nat)
    (answer : service "qi" [DecimalDigits.integer 1] (parameters c a n).state=
      some ((oneQ l (parameters c a n)).source,(oneCursor l (parameters c a n)).state)) :
    Declare Header.layout service [{type:="Q",name:="result",value:=some (.call (.var "qi") [.nat 1]),arrayExtent:=none}]
      (parameters c a n).state (loopStart l c a n).state := by
  have expression:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 999 (parameters c a n).state (.nat 1)=
      some (DecimalDigits.integer 1,(parameters c a n).state) from rfl) answer
  have cast : castValue Header.layout (oneCursor l (parameters c a n)).state 100 "Q"
      (oneQ l (parameters c a n)).source=some (oneQ l (parameters c a n)).source :=
    Input.cast "Q" (by decide +kernel) (one_live l (parameters c a n))
  simp only[Declare,declarations,List.foldlM,expression,Bind.bind,Option.bind,cast]
  rfl

end ScopedC.RationalPowerCalls
