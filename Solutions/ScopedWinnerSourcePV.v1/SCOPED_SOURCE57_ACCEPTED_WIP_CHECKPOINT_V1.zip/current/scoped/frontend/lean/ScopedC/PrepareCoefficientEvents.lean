/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientStepSource
import ScopedC.PrepareCoefficientAtanhEvents

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

abbrev CoefficientEvent (code : List Function) := CallEvents.Event Header.layout code 7
abbrev CoefficientEventAnswers {code : List Function} (service : Call)
    (events : List (CoefficientEvent code)) : Prop :=
  ∀e∈events,service e.name e.args e.before=some (e.value,e.after)

noncomputable def expEvents (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+34<PoolCalls.capacity) :
    List (CoefficientEvent code) := [
  ⟨"qi",[PoolCalls.word f.k],f.cursor.state,(counterQ f).source,(counterQCursor f).state,
    SourceRanks.monotone (by decide +kernel) (counterQ_source code lib f (by omega))⟩,
  ⟨"qv",[(previous f).source,(counterQ f).source],(counterQCursor f).state,(expNext f).source,
    (expDivideCursor f).state,expDivide_source code lib f (by omega)⟩]

noncomputable def coefficientEvents (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    List (CoefficientEvent code) :=
  expEvents code lib f room++(expStage f active room).atanhEvents code lib
    (expStage_room f active room) f.kPositive (by change f.k<2^32;have h:=f.depthBound;omega)

theorem counterQ_size {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) :
    (counterQCursor f).state.nats.values.length=f.cursor.state.nats.values.length+3 := by
  change (CursorFrames.advance l f.cursor [f.k,0,1]).state.nats.values.length=_
  rw[CursorEffects.size]
  rfl

theorem expEvents_unique (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+34<PoolCalls.capacity) :
    ((expEvents code lib f room).map CallEvents.timeKey).Nodup := by
  change [f.cursor.state.nats.values.length,(counterQCursor f).state.nats.values.length].Nodup
  rw[counterQ_size]
  simp only[List.nodup_cons,List.mem_singleton,List.not_mem_nil,not_false_eq_true,
    List.nodup_nil,and_true]
  omega

theorem expEvents_bounds (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity)
    (e : CoefficientEvent code) (member : e∈expEvents code lib f room) :
    f.cursor.state.nats.values.length ≤ e.before.nats.values.length ∧
    e.before.nats.values.length<(expStage f active room).cursor.state.nats.values.length := by
  have small:=counterQ_size f
  have finish : (expStage f active room).cursor.state.nats.values.length=
      f.cursor.state.nats.values.length+16:=expWork_size f (by omega) active
  simp only[expEvents,List.mem_cons,List.mem_singleton,List.not_mem_nil,or_false] at member
  rcases member with rfl|rfl <;> dsimp only <;> omega

theorem coefficientEvents_answers (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity)
    (service : Call) (answers : CoefficientEventAnswers service (coefficientEvents code lib f active room)) :
    CoefficientAnswers service f active room := by
  refine ⟨answers _ (List.mem_append_left _ List.mem_cons_self),
    answers _ (List.mem_append_left _ (List.mem_cons_of_mem _ List.mem_cons_self)),?_⟩
  exact CoeffWork.atanhEvents_answers code lib (expStage f active room) (expStage_room f active room)
    f.kPositive _ service (fun e member=>answers e (List.mem_append_right _ member))

theorem coefficientEvents_unique (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    ((coefficientEvents code lib f active room).map CallEvents.timeKey).Nodup := by
  rw[coefficientEvents,List.map_append,List.nodup_append]
  refine ⟨expEvents_unique code lib f room,
    CoeffWork.atanhEvents_unique code lib (expStage f active room) (expStage_room f active room) f.kPositive _,?_⟩
  intro a ha b hb same
  obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
  obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
  have left:=expEvents_bounds code lib f active room ea hea
  have right:=CoeffWork.atanhEvents_bounds code lib (expStage f active room) (expStage_room f active room)
    f.kPositive _ (expStage_bound f active room) eb heb
  have keyEq:=ka.trans (same.trans kb.symm)
  change ea.before.nats.values.length=eb.before.nats.values.length at keyEq
  omega

theorem coefficientEvents_bounds (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity)
    (e : CoefficientEvent code) (member : e∈coefficientEvents code lib f active room) :
    f.cursor.state.nats.values.length ≤ e.before.nats.values.length ∧
    e.before.nats.values.length<(coefficientStep f active room).cursor.state.nats.values.length := by
  have half:=expWork_size f (by omega) active
  have finish:=coefficientStep_size f active room
  have halfDef : (expStage f active room).cursor.state.nats.values.length=
      f.cursor.state.nats.values.length+16:=half
  rcases List.mem_append.mp member with front|later
  · have left:=expEvents_bounds code lib f active room e front
    split_ifs at finish <;> omega
  · have right:=CoeffWork.atanhEvents_bounds code lib (expStage f active room) (expStage_room f active room)
      f.kPositive _ (expStage_bound f active room) e later
    have same : ((expStage f active room).atanhWritten (expStage_room f active room) f.kPositive
        (expStage_bound f active room)).cursor.state.nats.values.length=
      (coefficientStep f active room).cursor.state.nats.values.length := rfl
    rw[same] at right
    omega

end ScopedC.PrepareSource
