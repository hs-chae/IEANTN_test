/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientWork
import ScopedC.UnsignedLocalSteps

namespace ScopedC.PrepareSource.CoeffWork
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem depth_counter_apart {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) : object≠w.kSlot := by
  intro same
  have storage:=w.depthAt.storage
  simp only[same,w.kAt.memory] at storage
  have types:=congrArg (fun x : Option Object=>x.map Object.type) storage
  change some "unsigned int"=some "unsigned" at types
  contradiction

noncomputable def increment {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) : CoeffWork l object d eb ab := by
  have safe:=LocalStorageSeparation.pool w.context w.kAt (by decide +kernel)
  exact {
    cursor:=LocalAssignment.cursor w.cursor w.kSlot "unsigned int" (PoolCalls.word (w.k+1))
    expCoeffs:=w.expCoeffs
    atanhCoeffs:=w.atanhCoeffs
    k:=w.k+1
    kSlot:=w.kSlot
    context:=LocalAssignment.valid w.context w.kSlot "unsigned int" _ safe.1 safe.2.1 safe.2.2
    expAt:=CoefficientTableRead.local_store w.expAt w.kAt
    atanhAt:=CoefficientTableRead.local_store w.atanhAt w.kAt
    expExtent:=w.expExtent
    atanhExtent:=w.atanhExtent
    expLookup:=w.expLookup
    atanhLookup:=w.atanhLookup
    expUnshadowed:=w.expUnshadowed
    atanhUnshadowed:=w.atanhUnshadowed
    depthAt:=SourceUnsignedGlobal.memory
      (t:=LocalAssignment.changed w.cursor.state w.kSlot "unsigned int" (PoolCalls.word (w.k+1)))
      w.depthAt rfl (by
        exact List.getElem?_set_ne (Ne.symm (depth_counter_apart w)))
    depthUnshadowed:=w.depthUnshadowed
    kAt:=LocalAssignment.binding w.kAt (by rfl)
    arraysApart:=w.arraysApart
    depthApart:=w.depthApart }

theorem increment_source (service : Call) {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} (w : CoeffWork l object d eb ab) (bound : w.k+1<2^32) :
    Eval Header.layout service (.binary "=" (.var "k") (.binary "+" (.var "k") (.nat 1)))
      w.cursor.state w.increment.cursor.state (PoolCalls.word (w.k+1)) :=
  UnsignedLocalSteps.increment service w.kAt bound (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)

end ScopedC.PrepareSource.CoeffWork
