/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceUnsignedGlobal
import ScopedC.LocalAssignment

namespace ScopedC.SourceUnsignedGlobal
open ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem local_separated {s : State} {name : String} {object n : Nat}
    (global : At s name object n) {localName ty : String} {old : Value} {slot : Nat}
    (binding : LocalBinding.At s localName ty old slot) (different : ty≠"unsigned") : object≠slot := by
  intro same
  have storage:=global.storage
  rw[same,binding.memory] at storage
  have types:=congrArg (fun x : Option Object=>x.map Object.type) storage
  change some ty=some "unsigned" at types
  exact different (Option.some.inj types)

theorem local_store {s : State} {name : String} {object n : Nat}
    (global : At s name object n) {localName ty : String} {old value : Value} {slot : Nat}
    (binding : LocalBinding.At s localName ty old slot) (different : ty≠"unsigned") :
    At (LocalAssignment.changed s slot ty value) name object n := by
  have separate:=local_separated global binding different
  exact memory global rfl (by
    simp [LocalAssignment.changed,PoolCalls.storeObject,separate,Ne.symm separate])

end ScopedC.SourceUnsignedGlobal
