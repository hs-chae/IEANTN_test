/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientTableFrames
import ScopedC.UnsignedLocalSteps
import ScopedC.IntervalProductApplicability
import ScopedC.LocalStorageSeparation

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure Frame (l : PoolCalls.PoolLayout) (base : Address) (coeffs : List Input) where
  cursor : Cursor
  a : Pair
  result : Pair
  k : Nat
  coeffSlot : Nat
  aSlot : Nat
  kSlot : Nat
  rSlot : Nat
  context : Valid l cursor
  coeffAt : LocalBinding.At cursor.state "coeffs" "const Q*" (.pointer base false) coeffSlot
  aAt : LocalBinding.At cursor.state "a" "RI" a.source aSlot
  kAt : LocalBinding.At cursor.state "k" "unsigned int" (PoolCalls.word k) kSlot
  rAt : LocalBinding.At cursor.state "result" "RI" result.source rSlot
  table : CoefficientTableRead.TableAt cursor.state base coeffs
  aLive : a.Live cursor.state
  rLive : result.Live cursor.state
  aPositive : a.Positive
  rPositive : result.Positive
  aOrder : a.lo.mathematical.value ≤ a.hi.mathematical.value
  rOrder : result.lo.mathematical.value ≤ result.hi.mathematical.value
  kLength : k ≤ coeffs.length
  kBound : k<2^32
  arDistinct : aSlot≠rSlot

def mathematical {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input} (f : Frame l base coeffs) : LeanCert.Core.IntervalRat :=
  ⟨f.result.lo.mathematical.value,f.result.hi.mathematical.value,f.rOrder⟩
def original {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input} (f : Frame l base coeffs) : LeanCert.Core.IntervalRat :=
  ⟨f.a.lo.mathematical.value,f.a.hi.mathematical.value,f.aOrder⟩

def decremented {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input} (f : Frame l base coeffs) : Frame l base coeffs := by
  have safe:=LocalStorageSeparation.pool f.context f.kAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  exact {
    cursor:=LocalAssignment.cursor f.cursor f.kSlot "unsigned int" (PoolCalls.word (f.k-1))
    a:=f.a
    result:=f.result
    k:=f.k-1
    coeffSlot:=f.coeffSlot
    aSlot:=f.aSlot
    kSlot:=f.kSlot
    rSlot:=f.rSlot
    context:=LocalAssignment.valid f.context f.kSlot "unsigned int" (PoolCalls.word (f.k-1)) safe.1 safe.2.1 safe.2.2
    coeffAt:=LocalAssignment.other_binding (changedType:="unsigned int") (value:=PoolCalls.word (f.k-1)) f.coeffAt
      (LocalStorageSeparation.typed f.coeffAt f.kAt (by decide +kernel))
    aAt:=LocalAssignment.other_binding (changedType:="unsigned int") (value:=PoolCalls.word (f.k-1)) f.aAt
      (LocalStorageSeparation.typed f.aAt f.kAt (by decide +kernel))
    kAt:=LocalAssignment.binding f.kAt (by rfl)
    rAt:=LocalAssignment.other_binding (changedType:="unsigned int") (value:=PoolCalls.word (f.k-1)) f.rAt
      (LocalStorageSeparation.typed f.rAt f.kAt (by decide +kernel))
    table:=CoefficientTableRead.local_store f.table f.kAt
    aLive:=f.aLive
    rLive:=f.rLive
    aPositive:=f.aPositive
    rPositive:=f.rPositive
    aOrder:=f.aOrder
    rOrder:=f.rOrder
    kLength:=by have h:=f.kLength;omega
    kBound:=by have h:=f.kBound;omega
    arDistinct:=f.arDistinct }

theorem decrement_source (service : Call) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) :
    Eval Header.layout service (.binary "=" (.var "k") (.binary "-" (.var "k") (.nat 1))) f.cursor.state
      (decremented f).cursor.state (PoolCalls.word (f.k-1)) :=
  UnsignedLocalSteps.decrement service f.kAt positive f.kBound
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem coefficient_source (service : Call) (fuel : Nat) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (inRange : f.k<coeffs.length) :
    evalExpr Header.layout service (fuel+3) f.cursor.state (.index (.var "coeffs") (.var "k"))=some (coeffs[f.k].source,f.cursor.state) :=
  CoefficientTableRead.source_index service fuel f.table f.k inRange
    (LocalBinding.eval service fuel f.coeffAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (LocalBinding.eval service fuel f.kAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))

end ScopedC.TaylorCalls
