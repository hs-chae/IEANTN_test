/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerIterationBody
import ScopedC.RationalPowerInitialization
import ScopedC.CallEventTimeline

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

abbrev Event (code : List Function) := CallEvents.Event Header.layout code 6
def Answers {code : List Function} (service : Call) (events : List (Event code)) : Prop :=
  ∀e∈events,service e.name e.args e.before=some (e.value,e.after)

def accumulatorEvent (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) : Event code :=
  ⟨"qt",[f.accumulator.source,f.current.source],f.cursor.state,(accProduct f).source,
    (RationalMultiplyCalls.c11 l f.cursor f.accumulator f.current).state,
    accumulate_call code lib f (by omega)⟩

def squareEvent (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) : Event code :=
  ⟨"qt",[(halved f room).current.source,(halved f room).current.source],(halved f room).cursor.state,
    (squareProduct (halved f room)).source,
    (RationalMultiplyCalls.c11 l (halved f room).cursor (halved f room).current (halved f room).current).state,
    square_call code lib (halved f room) (by have h:=halved_top_le f room;omega)⟩

def iterationEvents (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) : List (Event code) :=
  (if f.exponent%2=1 then [accumulatorEvent code lib f room] else []) ++
  (if 0<(halved f room).exponent then [squareEvent code lib f room] else [])

theorem iteration_event_run (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity)
    (service : Call) (answers : Answers service (iterationEvents code lib f room)) :
    Run Header.layout service loopBody f.cursor.state (.continuing (iteration f room).cursor.state) := by
  apply iteration_run service f room
  · intro odd
    exact answers (accumulatorEvent code lib f room) (by
      apply List.mem_append_left
      simp only[odd,↓reduceIte,List.mem_singleton])
  · intro remaining
    exact answers (squareEvent code lib f room) (by
      apply List.mem_append_right
      simp only[remaining,↓reduceIte,List.mem_singleton])

theorem halved_size {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (halved f room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+
      (if f.exponent%2=1 then 11 else 0) := by
  change (afterOdd f room).cursor.state.nats.values.length=_
  unfold afterOdd
  split
  · exact accumulate_size _ _
  · simp

theorem iteration_size {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (iteration f room).cursor.state.nats.values.length=(halved f room).cursor.state.nats.values.length+
      (if 0<(halved f room).exponent then 11 else 0) := by
  unfold iteration
  split
  · exact square_size _ _
  · simp

theorem iteration_nats_le {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    f.cursor.state.nats.values.length ≤ (iteration f room).cursor.state.nats.values.length := by
  rw[iteration_size,halved_size]
  omega

theorem iteration_event_keys (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (iterationEvents code lib f room).map CallEvents.timeKey=
      (if f.exponent%2=1 then [f.cursor.state.nats.values.length] else []) ++
      (if 0<(halved f room).exponent then [(halved f room).cursor.state.nats.values.length] else []) := by
  unfold iterationEvents
  rw[List.map_append]
  congr 1 <;> split <;> rfl

/-- All recorded calls lie in the actual arena-allocation interval of this
iteration. The key is only a collision-free lookup index; the event contains
the complete actual source execution, state and arguments. -/
theorem iteration_event_bounds (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity)
    (e : Event code) (member : e∈iterationEvents code lib f room) :
    f.cursor.state.nats.values.length ≤ CallEvents.timeKey e ∧
      CallEvents.timeKey e < (iteration f room).cursor.state.nats.values.length := by
  have keyMember : CallEvents.timeKey e∈(iterationEvents code lib f room).map CallEvents.timeKey := List.mem_map.mpr ⟨e,member,rfl⟩
  rw[iteration_event_keys] at keyMember
  have h:=halved_size f room
  have i:=iteration_size f room
  split_ifs at keyMember h i <;> simp only[List.append_nil,List.nil_append,List.cons_append,List.mem_cons,List.not_mem_nil,or_false] at keyMember <;> omega

theorem iteration_event_unique (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    ((iterationEvents code lib f room).map CallEvents.timeKey).Nodup := by
  rw[iteration_event_keys]
  have h:=halved_size f room
  by_cases odd : f.exponent%2=1
  · rw[if_pos odd] at h
    by_cases more : 0<(halved f room).exponent
    · simp only[odd,more,↓reduceIte,List.cons_append,List.nil_append,List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,and_true,List.nodup_nil]
      constructor
      · omega
      · simp
    · simp [odd,more]
  · by_cases more : 0<(halved f room).exponent <;> simp [odd,more]

end ScopedC.RationalPowerCalls
