/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderOutput
import ScopedC.IntervalScopeFraming

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] errorInput errorCursor outputPair

theorem output_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (room : c.top+3000<PoolCalls.capacity) : Valid l (afterOut r) := by
  have bound:=radius_power_top r
  exact CursorLocals.allocated_valid (next_valid 0 (stored_error_valid r room)
    (by change (errorCursor r).top<PoolCalls.capacity;rw[error_top];omega)) "RI" "out" _

theorem out_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    LocalBinding.At (afterOut r).state "out" "RI" (outputPair r).source
      (next l (storedError r) 0).state.heap.length :=
  LocalBinding.allocate_head _ "out" "RI" _ (Pair.initialized _)

theorem out_return (service : Call) {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    Eval Header.layout service (.var "out") (afterOut r).state (afterOut r).state (outputPair r).source :=
  ⟨2,LocalBinding.eval service 1 (out_binding r) (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)⟩

end ScopedC.ExpRemainderCalls
