/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointIndex

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- The real unsigned C shift has its required shift-count and result domains
proved. No modular wrap is used to obtain the mathematical reduction power. -/
theorem shift_one (s : State) (k : Nat) (bound : k < 32) :
    binaryValue Header.layout s "<<" (NatWrapperCalls.unsigned32 1)
      (NatWrapperCalls.unsigned32 k) = some (PoolCalls.word (2^k)) := by
  have kRange : k < 2^32 := by omega
  have powerRange : 2^k < 2^32 := Nat.pow_lt_pow_right (by decide) bound
  have asInt : (k:Int) < 32 := by exact_mod_cast bound
  have oneRange : Scalar.InRange ⟨false,32⟩ (1:Int) := by decide +kernel
  have oneCast := Scalar.make_exact oneRange
  have kCast := Scalar.make_exact (PoolCalls.u32_range k kRange)
  have output : Scalar.make ⟨false,32⟩ ((2:Int)^k) =
      some ⟨⟨false,32⟩,(2:Int)^k⟩ := by
    simpa only [Nat.cast_pow,Nat.cast_ofNat] using
      Scalar.make_exact (PoolCalls.u32_range (2^k) powerRange)
  simp [binaryValue,NatWrapperCalls.unsigned32,Scalar.binary,Scalar.common,Scalar.promote,
    Scalar.cast,oneRange,oneCast,kCast,
    PoolCalls.u32_range k kRange,asInt,output,PoolCalls.word]

def powerValue {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Nat := 2 ^ kValue stage

def afterPower {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor :=
  CursorLocals.allocated (afterK stage) "unsigned int" "power" (PoolCalls.word (powerValue stage))

theorem power_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    powerValue stage = ExpPointReduction.power q.mathematical.value := by
  unfold powerValue ExpPointReduction.power
  rw [k_value stage positive]

theorem power_bound {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (bound : kValue stage < 32) :
    0 < powerValue stage ∧ powerValue stage < 2^32 :=
  ⟨pow_pos (by decide) _,Nat.pow_lt_pow_right (by decide) bound⟩

theorem power_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (room : c.top+13 < PoolCalls.capacity) :
    Valid l (afterPower stage) :=
  CursorLocals.allocated_valid (k_valid stage room) "unsigned int" "power" _

theorem power_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    LocalBinding.At (afterPower stage).state "power" "unsigned int"
      (PoolCalls.word (powerValue stage)) (afterK stage).state.heap.length :=
  LocalBinding.allocate_head _ "power" "unsigned int" _ rfl

theorem power_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (bound : kValue stage < 32) :
    Declare Header.layout service [{type:="unsigned int",name:="power",value:=(some
      (.binary "<<" (.uint 1) (.var "k"))),arrayExtent:=none}]
      (afterK stage).state (afterPower stage).state := by
  have expression := ExpressionTemplates.binary Header.layout service (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (show evalExpr Header.layout service 999 (afterK stage).state (.uint 1) =
      some (NatWrapperCalls.unsigned32 1,(afterK stage).state) from rfl)
    (LocalBinding.eval service 998 (k_binding stage) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (shift_one (afterK stage).state (kValue stage) bound)
  have cast : castValue Header.layout (afterK stage).state 100 "unsigned int"
      (PoolCalls.word (powerValue stage)) = some (PoolCalls.word (powerValue stage)) :=
    RationalUnsignedCalls.cast_parameter (afterK stage).state
      (powerValue stage) (power_bound stage bound).2
  simp only [powerValue] at cast
  simp only [Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

end ScopedC.ExpPointCalls
