/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerEffects

namespace ScopedC.RationalPowerCalls
open ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def afterOdd {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) : Frame l :=
  if f.exponent%2=1 then accumulate f (by omega) else f
def halved {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) : Frame l :=
  half (afterOdd f room)

theorem afterOdd_top_le {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (afterOdd f room).cursor.top ≤ f.cursor.top+11 := by
  unfold afterOdd
  split
  · rw[accumulate_top]
  · omega
theorem halved_top_le {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (halved f room).cursor.top ≤ f.cursor.top+11 := by
  unfold halved
  rw[half_top]
  exact afterOdd_top_le f room

def iteration {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) : Frame l :=
  if 0<(halved f room).exponent then square (halved f room) (by have h:=halved_top_le f room;omega)
  else halved f room

theorem afterOdd_exponent {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (afterOdd f room).exponent=f.exponent := by
  unfold afterOdd
  split
  · exact accumulate_exponent _ _
  · rfl
theorem halved_exponent {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (halved f room).exponent=f.exponent/2 := by
  change (afterOdd f room).exponent/2=f.exponent/2
  rw[afterOdd_exponent]
theorem iteration_exponent {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (iteration f room).exponent=f.exponent/2 := by
  unfold iteration
  split
  · rw[square_exponent,halved_exponent]
  · exact halved_exponent f room

theorem iteration_top_le {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (iteration f room).cursor.top ≤ f.cursor.top+22 := by
  have h:=halved_top_le f room
  unfold iteration
  split
  · rw[square_top];omega
  · omega

theorem afterOdd_current {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (afterOdd f room).current=f.current := by
  unfold afterOdd
  split
  · exact accumulate_current _ _
  · rfl
theorem afterOdd_accumulator_value {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (afterOdd f room).accumulator.mathematical.value=
      RationalPowerInvariant.nextAccumulator f.accumulator.mathematical.value f.current.mathematical.value f.exponent := by
  unfold afterOdd RationalPowerInvariant.nextAccumulator
  split
  · exact accumulate_value _ _
  · rfl

/-- The exact source control-flow transition preserves the binary-power
invariant; no replacement summation/power algorithm is used. -/
theorem iteration_value {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (iteration f room).accumulator.mathematical.value*
      (iteration f room).current.mathematical.value^(iteration f room).exponent=
      f.accumulator.mathematical.value*f.current.mathematical.value^f.exponent := by
  have acc : (halved f room).accumulator.mathematical.value=
      RationalPowerInvariant.nextAccumulator f.accumulator.mathematical.value f.current.mathematical.value f.exponent :=
    afterOdd_accumulator_value f room
  have current : (halved f room).current=f.current := afterOdd_current f room
  unfold iteration
  split
  · rw[square_accumulator,square_value,square_exponent,acc,current,halved_exponent]
    exact RationalPowerInvariant.power_step _ _ _
  · rw[acc,current,halved_exponent]
    rename_i stop
    have zero : f.exponent/2=0 := by rw[halved_exponent] at stop;omega
    have value:=RationalPowerInvariant.power_step f.accumulator.mathematical.value f.current.mathematical.value f.exponent
    simpa only[zero,pow_zero,mul_one] using value

end ScopedC.RationalPowerCalls
