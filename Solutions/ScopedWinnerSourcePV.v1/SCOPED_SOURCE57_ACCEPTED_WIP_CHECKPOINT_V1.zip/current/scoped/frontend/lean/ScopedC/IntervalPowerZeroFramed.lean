/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerFramedBody

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem rpow_zero_framed (code : List Function) (installed : Generated.f_rpow∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5120 ≤ PoolCalls.capacity) (a : Pair) (alive : a.Live c.state)
    (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) :
    Nonempty (FramedResult code l c a 0 order) := by
  let p:=parameters c a 0
  let q:=RationalPowerCalls.oneQ l p
  let afterQi:=RationalPowerCalls.oneCursor l p
  let result : Pair:=⟨q,q⟩
  have parameterContext : Valid l p:=CursorFrames.framed_valid ctx "RI" "a" a.source "unsigned int" "n" (PoolCalls.word 0)
  have qiCall : SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1] p.state q.source afterQi.state := by
    have proof:=RationalUnsignedCalls.qi_call (input:=DecimalDigits.integer 1) (n:=1)
      code lib.qi lib.si lib.multiplyLibrary.productLibrary.smake lib.multiplyLibrary.productLibrary.nz
      lib.multiplyLibrary.productLibrary.nu lib.multiplyLibrary.productLibrary.ne lib.multiplyLibrary.productLibrary.keep
      parameterContext (by change c.top+2<PoolCalls.capacity;omega) (by decide +kernel) (by rfl)
    simpa only[q,afterQi,RationalPowerCalls.one_source,RationalPowerCalls.one_state] using proof
  have qLive : q.Live afterQi.state:=RationalPowerCalls.one_live l p
  have pointCall : SourceCall Header.layout code 1 "point" [q.source] afterQi.state result.source afterQi.state := by
    change SourceCall Header.layout code 1 "point" [q.source] afterQi.state (IntervalCasts.value q.source q.source) afterQi.state
    rw[show q.source=RecordCasts.rational p.state.nats.values.length 0
      (SignedCalls.siResult l p.state p.cells p.top p.high 1).nats.values.length from RationalPowerCalls.one_source l p]
    exact RationalPointCalls.point_closed code lib.point qLive.1 qLive.2 (by decide +kernel : (0:Nat)<2^32)
  let e0 : CallEvents.Event Header.layout code 8:=
    ⟨"qi",[DecimalDigits.integer 1],p.state,q.source,afterQi.state,raise_once (raise_once qiCall)⟩
  let e1 : CallEvents.Event Header.layout code 8:=
    ⟨"point",[q.source],afterQi.state,result.source,afterQi.state,
      raise_once (raise_once (raise_once (raise_once (raise_once (raise_once (raise_once pointCall))))))⟩
  have size : afterQi.state.nats.values.length=p.state.nats.values.length+3 := by
    change (CursorFrames.advance l p [1,0,1]).state.nats.values.length=_
    rw[CursorEffects.size]
    rfl
  have unique : ([e0,e1].map CallEvents.timeKey).Nodup := by
    change [p.state.nats.values.length,afterQi.state.nats.values.length].Nodup
    simp only[List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,and_true,List.nodup_nil]
    constructor
    · omega
    · simp
  obtain ⟨service,answers,closed⟩:=CallEvents.timeline_service [e0,e1] unique
  have qiExpression : evalExpr Header.layout service 2 p.state (.call (.var "qi") [.nat 1])=some (q.source,afterQi.state):=
    ExpressionTemplates.call_one Header.layout service (by rfl) (answers e0 (List.mem_cons_self))
  have pointExpression : Eval Header.layout service (.call (.var "point") [.call (.var "qi") [.nat 1]]) p.state afterQi.state result.source :=
    ⟨3,ExpressionTemplates.call_one Header.layout service qiExpression
      (answers e1 (List.mem_cons_of_mem e0 (List.mem_cons_self)))⟩
  have branch : Run Header.layout service
      (.branch zeroCondition (.returnStmt (.call (.var "point") [.call (.var "qi") [.nat 1]])) .skip)
      p.state (.returned afterQi.state result.source) := by
    apply Loops.StmtRun.branch (zero_condition service c a 0 (by decide +kernel))
    simp only[UnsignedLiteralControl.truth_boolean,decide_true,↓reduceIte]
    exact Loops.StmtRun.returnValue pointExpression
  let bodyExit:=PoolContextPop.unframe p.state afterQi
  let finalCursor:=PoolContextPop.unframe c.state bodyExit
  have body : Run Header.layout service Generated.f_rpow.body p.state (.returned bodyExit.state result.source) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.returned branch)
    exact ⟨rfl,rfl⟩
  have finalLive : result.Live finalCursor.state:=⟨qLive,qLive⟩
  have bodyLive : result.Live bodyExit.state:=⟨qLive,qLive⟩
  have execution : SourceCall Header.layout code 9 "rpow" [a.source,PoolCalls.word 0] c.state result.source finalCursor.state := by
    apply installed_body (f:=Generated.f_rpow) (rank:=8) (service:=service) installed closed
      (bind_parameters c a 0 alive (by decide +kernel)) body
    exact ⟨Pair.cast bodyLive "static RI" (by decide +kernel),rfl⟩
  have qiContext : Valid l afterQi:=CursorFrames.advance_valid parameterContext [1,0,1] (by change c.top+3 ≤ PoolCalls.capacity;omega)
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have bodyContext : Valid l bodyExit:=PoolContextPop.valid qiContext
    (by change l.pool<(parameters c a 0).state.heap.length;rw[parameters_length];omega)
    (by change l.top<(parameters c a 0).state.heap.length;rw[parameters_length];omega)
    (by change l.high<(parameters c a 0).state.heap.length;rw[parameters_length];omega)
  have finalContext : Valid l finalCursor:=PoolContextPop.valid bodyContext hp ht hh
  have resultPositive : result.Positive:=⟨by change 0<(1:Nat);decide,by change 0<(1:Nat);decide⟩
  have value : q.mathematical.value=1:=RationalPowerCalls.one_value l p
  have decoded : NumericRepresentation.interval finalCursor.state result.source=some
      (LeanCert.Core.IntervalRat.pow
        ⟨a.lo.mathematical.value,a.hi.mathematical.value,order⟩ 0) := by
    have decoded:=pair_decoded result finalLive resultPositive (le_refl _)
    simpa only[result,value,LeanCert.Core.IntervalRat.singleton,LeanCert.Core.IntervalRat.pow]
      using decoded
  refine ⟨{
    out:=finalCursor
    output:=result
    execution:=execution
    valid:=finalContext
    live:=finalLive
    positive:=resultPositive
    decoded:=decoded
    top:=by change c.top+3 ≤ c.top+5120;omega
    globals:=?_
    env:=rfl
    heap_length:=?_
    preserves:=?_
    other:=?_
  }⟩
  · change (CursorFrames.advance l p [1,0,1]).state.globals=c.state.globals
    rw[CursorSingleFrames.advance_globals]
    rfl
  · change ((afterQi.state.heap.take p.state.heap.length).take c.state.heap.length).length=
      c.state.heap.length
    have sameLength : afterQi.state.heap.length=p.state.heap.length := by
      change (CursorFrames.advance l p [1,0,1]).state.heap.length=p.state.heap.length
      exact (CursorEffects.shape l p [1,0,1]).1
    rw[List.length_take,List.length_take,sameLength]
    change min c.state.heap.length (min (parameters c a 0).state.heap.length
      (parameters c a 0).state.heap.length)=c.state.heap.length
    rw[parameters_length]
    omega
  · intro slot value live
    change NatArena.Borrow (CursorFrames.advance l p [1,0,1]).state.nats slot value
    exact CursorBorrow.preserves (l:=l) (c:=p) [1,0,1] live
  · intro slot old hp ht hh
    change ((afterQi.state.heap.take p.state.heap.length).take c.state.heap.length)[slot]?=
      c.state.heap[slot]?
    rw[List.getElem?_take_of_lt old,
      List.getElem?_take_of_lt (by change slot<(parameters c a 0).state.heap.length;rw[parameters_length];omega)]
    change (CursorFrames.advance l p [1,0,1]).state.heap[slot]?=c.state.heap[slot]?
    rw[CursorSingleFrames.advance_other l p [1,0,1] slot hp ht hh]
    simp [p,parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.getElem?_append_left old]

theorem rpow_framed (code : List Function) (installed : Generated.f_rpow∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+5120 ≤ PoolCalls.capacity) (a : Pair) (n : Nat)
    (alive : a.Live c.state) (positive : a.Positive)
    (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) (bound : n<2^32) :
    Nonempty (FramedResult code l c a n order) := by
  by_cases zero : n=0
  · subst n
    exact rpow_zero_framed code installed lib ctx room a alive order
  · exact rpow_positive_framed code installed lib ctx room a n alive positive order (by omega) bound

end ScopedC.IntervalPowerCalls
