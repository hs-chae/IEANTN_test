/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalHullData
import ScopedC.CallEventPairs

namespace ScopedC.RationalIntervalHullCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000
attribute [local irreducible] finish

def initializer : Expr := .record [
  .call (.var "qmin") [.field "." (.var "a") "lo",.field "." (.var "b") "lo"],
  .call (.var "qmax") [.field "." (.var "a") "hi",.field "." (.var "b") "hi"]]

/-- The actual rhull initializer, its two complete source selection calls,
typed local RI record, return conversion and caller scope restoration. -/
theorem rhull_closed (code : List Function) (installed : Generated.f_rhull∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+11<PoolCalls.capacity)
    (a b : Pair) (ha : a.Live c.state) (hb : b.Live c.state) :
    SourceCall Header.layout code 8 "rhull" [a.source,b.source] c.state
      (result l c a b) (after l c a b).state := by
  have ctx0 : Valid l (base c a b) := CursorFrames.framed_valid ctx "RI" "a" a.source "RI" "b" b.source
  have p1 : SourceCall Header.layout code 7 "qmin" [a.lo.source,b.lo.source] (base c a b).state
      (lowQ l c a b).source (middle l c a b).state := by
    unfold middle lowQ
    exact RationalSelectCalls.qmin_closed code lib.qmin lib.qc lib.sc lib.sm lib.nm lib.smake
      lib.nz lib.nu lib.ne lib.nlt lib.keep (c:=base c a b) ctx0
      (by change c.top+5<PoolCalls.capacity;omega) a.lo b.lo ha.1 hb.1
  have p2 : SourceCall Header.layout code 7 "qmax" [a.hi.source,b.hi.source] (middle l c a b).state
      (highQ l c a b).source (finish l c a b).state := by
    unfold finish highQ
    exact RationalSelectCalls.qmax_closed code lib.qmax lib.qc lib.sc lib.sm lib.nm lib.smake
      lib.nz lib.nu lib.ne lib.nlt lib.keep (c:=middle l c a b) (middle_valid ctx room a b)
      (by rw[middle_top];omega) a.hi b.hi
      (middle_live (a:=a) (b:=b) ha).2 (middle_live (a:=a) (b:=b) hb).2
  let e1 : CallEvents.Event Header.layout code 7 :=
    ⟨"qmin",[a.lo.source,b.lo.source],(base c a b).state,(lowQ l c a b).source,(middle l c a b).state,p1⟩
  let e2 : CallEvents.Event Header.layout code 7 :=
    ⟨"qmax",[a.hi.source,b.hi.source],(middle l c a b).state,(highQ l c a b).source,(finish l c a b).state,p2⟩
  have n : (middle l c a b).state.nats.values.length=(base c a b).state.nats.values.length+6 := by
    unfold middle
    rw[RationalCompareFraming.final_eq_advance,CursorEffects.size]
    rfl
  have distinct : (middle l c a b).state≠(base c a b).state := by
    intro h
    have z:=congrArg (fun s : State=>s.nats.values.length) h
    omega
  obtain ⟨service,h1,h2,closed⟩ := CallEvents.pair_service e1 e2 distinct
  have expression : evalExpr Header.layout service 1000 (base c a b).state initializer=
      some (.aggregate [(lowQ l c a b).source,(highQ l c a b).source],(finish l c a b).state) :=
    ExpressionTemplates.record_two Header.layout service
      (ExpressionTemplates.call_two Header.layout service
        (RationalIntervalFrames.eval_lo service 996 (s:=(base c a b).state) (p:=a) (RationalIntervalFrames.a_at c.state a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
        (RationalIntervalFrames.eval_lo service 996 (s:=(base c a b).state) (p:=b) (RationalIntervalFrames.b_at c.state a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) h1)
      (ExpressionTemplates.call_two Header.layout service
        (RationalIntervalFrames.eval_hi service 996 (s:=(middle l c a b).state) (p:=a) (middle_a_at ctx a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
        (RationalIntervalFrames.eval_hi service 996 (s:=(middle l c a b).state) (p:=b) (middle_b_at ctx a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) h2)
  have qlf := low_live (l:=l) (c:=c) (a:=a) (b:=b) ha hb
  have qhf := high_live (l:=l) (c:=c) (a:=a) (b:=b) ha hb
  have cl : castValue Header.layout (finish l c a b).state 99 "Q" (lowQ l c a b).source=some (lowQ l c a b).source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) qlf.1 qlf.2 (SignedNegCalls.bit_bound _)
  have ch : castValue Header.layout (finish l c a b).state 99 "Q" (highQ l c a b).source=some (highQ l c a b).source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel) qhf.1 qhf.2 (SignedNegCalls.bit_bound _)
  have cast : castValue Header.layout (finish l c a b).state 100 "RI"
      (.aggregate [(lowQ l c a b).source,(highQ l c a b).source])=some (result l c a b) :=
    IntervalCasts.aggregate _ 96 _ _ cl ch
  have init : Machine.initialized 1000 (result l c a b)=true := rfl
  have shapes : (finish l c a b).state.heap.length=(middle l c a b).state.heap.length ∧
      (finish l c a b).state.env=(middle l c a b).state.env := by
    unfold finish
    exact RationalCompareCalls.shape l (middle l c a b) a.hi b.hi
  have shapes0 : (middle l c a b).state.heap.length=(base c a b).state.heap.length ∧
      (middle l c a b).state.env=(base c a b).state.env := by
    unfold middle
    exact RationalCompareCalls.shape l (base c a b) a.lo b.lo
  have len : (finish l c a b).state.heap.length=(base c a b).state.heap.length := shapes.1.trans shapes0.1
  have env : (finish l c a b).state.env=(base c a b).state.env := shapes.2.trans shapes0.2
  have body := DeclarationReturn.body Header.layout service "RI" "r" initializer expression cast init
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw[LocalScope.pop_local "RI" "r" (result l c a b) len env] at body
  apply installed_body (f:=Generated.f_rhull) (rank:=7) (service:=service) installed closed
    (RationalIntervalFrames.bind a b ha hb) body
  exact ⟨IntervalCasts.record _ 96 "static RI" (by decide +kernel) _ _ cl ch,rfl⟩

end ScopedC.RationalIntervalHullCalls
