/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalDecimalLiteralExpression
namespace ScopedC.RationalDecimalLiteral
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DecimalText (digits)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem after_advance {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : Stages code l c n d) :
    after D=CursorFrames.advance l D.denominator (SourceFromSTrace.steps (endpoint D.numeratorSlot n) d) :=
  SourceFromSTrace.c5_advance l D.denominator (endpoint D.numeratorSlot n) d

theorem top {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : Stages code l c n d) :
    (after D).top=c.top+8+4*(digits n).length+4*(digits d).length := by
  rw [after_advance,CursorFrames.top_advance,D.denominatorTop]
  simp only [SourceFromSTrace.steps,List.length_cons,List.length_nil]
  omega

theorem preserves_nat {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : Stages code l c n d) {slot value : Nat}
    (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (after D).state.nats slot value := by
  have numStart : NatArena.Borrow (textCursor c n).state.nats slot value := live
  have num : NatArena.Borrow D.numerator.state.nats slot value := by
    rw [D.numeratorTrace]
    exact CursorBorrow.preserves _ numStart
  have signed : NatArena.Borrow (next l D.numerator 0).state.nats slot value :=
    PoolCursor.preserves num
  have denStart : NatArena.Borrow (textCursor (next l D.numerator 0) d).state.nats slot value := signed
  have den : NatArena.Borrow D.denominator.state.nats slot value := by
    rw [D.denominatorTrace]
    exact CursorBorrow.preserves _ denStart
  rw [after_advance]
  exact CursorBorrow.preserves _ den

theorem scale {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : Stages code l c n d) (ctx : Valid l c)
    (signedRoom : D.numerator.top<capacity) {object slot value : Nat}
    (h : SourceFromS.ScaleAt c.state object slot value) :
    SourceFromS.ScaleAt (after D).state object slot value := by
  have ns : SourceFromS.ScaleAt (textCursor c n).state object slot value :=
    LiteralAllocationEffects.scale h _
  have num : SourceFromS.ScaleAt D.numerator.state object slot value := by
    rw [D.numeratorTrace]
    exact SourceScaleFrames.advance (DecimalInitialized.input_valid ctx _) ns _
  have sig : SourceFromS.ScaleAt (next l D.numerator 0).state object slot value :=
    SourceScaleFrames.advance D.numeratorValid num [0]
  have ds : SourceFromS.ScaleAt (textCursor (next l D.numerator 0) d).state object slot value :=
    LiteralAllocationEffects.scale sig _
  have den : SourceFromS.ScaleAt D.denominator.state object slot value := by
    rw [D.denominatorTrace]
    exact SourceScaleFrames.advance
      (DecimalInitialized.input_valid (next_valid 0 D.numeratorValid signedRoom) _) ds _
  rw [after_advance]
  exact SourceScaleFrames.advance D.denominatorValid den _

end ScopedC.RationalDecimalLiteral
