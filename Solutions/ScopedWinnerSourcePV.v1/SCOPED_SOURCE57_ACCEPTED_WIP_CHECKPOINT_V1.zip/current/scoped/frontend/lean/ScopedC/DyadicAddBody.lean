/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicAddData
import ScopedC.CallEventPairs
namespace ScopedC.DyadicAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DyadicPairFrames (InputI)
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

def initializer : Expr := .record [
  .call (.var "sa") [.field "." (.var "a") "lo",.field "." (.var "b") "lo"],
  .call (.var "sa") [.field "." (.var "a") "hi",.field "." (.var "b") "hi"],
  .binary "&&" (.field "." (.var "a") "ok") (.field "." (.var "b") "ok")]

/-- Actual iadd: two closed source sa executions, real C short-circuit flag
expression, typed aggregate/local/return and source scope effects. -/
theorem iadd_closed (code : List Function) (installed : Generated.f_iadd∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+3<PoolCalls.capacity)
    (a b : InputI) (ha : a.Live c.state) (hb : b.Live c.state) :
    SourceCall Header.layout code 6 "iadd" [a.source,b.source] c.state (result l c a b) (after l c a b).state := by
  have ctx0 : Valid l (base c a b) := CursorFrames.framed_valid ctx "I" "a" a.source "I" "b" b.source
  have p1 : SourceCall Header.layout code 5 "sa" [a.lo.source,b.lo.source] (base c a b).state
      (low c a b).source (middle l c a b).state :=
    sum_call code lib (c:=base c a b) ctx0 (by change c.top+1<PoolCalls.capacity;omega) a.lo b.lo ha.1 hb.1
  have ah : a.hi.Live (middle l c a b).state :=
    PoolCursor.preserves (c:=next l (base c a b) (SignedAddCalls.magnitude a.lo b.lo)) (PoolCursor.preserves (c:=base c a b) ha.2)
  have bh : b.hi.Live (middle l c a b).state :=
    PoolCursor.preserves (c:=next l (base c a b) (SignedAddCalls.magnitude a.lo b.lo)) (PoolCursor.preserves (c:=base c a b) hb.2)
  have p2 : SourceCall Header.layout code 5 "sa" [a.hi.source,b.hi.source] (middle l c a b).state
      (high l c a b).source (finish l c a b).state :=
    sum_call code lib (c:=middle l c a b) (middle_valid ctx room a b)
      (by change c.top+2+1<PoolCalls.capacity;omega) a.hi b.hi ah bh
  let e1 : CallEvents.Event Header.layout code 5 :=
    ⟨"sa",[a.lo.source,b.lo.source],(base c a b).state,(low c a b).source,(middle l c a b).state,p1⟩
  let e2 : CallEvents.Event Header.layout code 5 :=
    ⟨"sa",[a.hi.source,b.hi.source],(middle l c a b).state,(high l c a b).source,(finish l c a b).state,p2⟩
  have size : (middle l c a b).state.nats.values.length=(base c a b).state.nats.values.length+2 := by
    change (CursorFrames.advance l (base c a b) [SignedAddCalls.magnitude a.lo b.lo,0]).state.nats.values.length=_
    rw[CursorEffects.size]
    rfl
  have distinct : (middle l c a b).state≠(base c a b).state := by
    intro h
    have e:=congrArg (fun s : State=>s.nats.values.length) h
    omega
  obtain ⟨service,h1,h2,closed⟩ := CallEvents.pair_service e1 e2 distinct
  have expr : evalExpr Header.layout service 1000 (base c a b).state initializer=
      some (.aggregate [(low c a b).source,(high l c a b).source,boolean Header.layout (a.ok&&b.ok)],(finish l c a b).state) :=
    DyadicIntervalNegCalls.record_three Header.layout service
      (ExpressionTemplates.call_two Header.layout service
        (DyadicPairFrames.eval_lo service 996 (s:=(base c a b).state) (p:=a) (DyadicPairFrames.a_at c.state a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
        (DyadicPairFrames.eval_lo service 996 (s:=(base c a b).state) (p:=b) (DyadicPairFrames.b_at c.state a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) h1)
      (ExpressionTemplates.call_two Header.layout service
        (DyadicPairFrames.eval_hi service 996 (s:=(middle l c a b).state) (p:=a) (middle_a_at ctx a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
        (DyadicPairFrames.eval_hi service 996 (s:=(middle l c a b).state) (p:=b) (middle_b_at ctx a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) h2)
      (DyadicPairFrames.logical_and service a.ok b.ok
        (DyadicPairFrames.eval_ok service 996 (s:=(finish l c a b).state) (p:=a) (final_a_at ctx a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
        (DyadicPairFrames.eval_ok service 996 (s:=(finish l c a b).state) (p:=b) (final_b_at ctx a b)
          (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  have lowLive : (low c a b).Live (finish l c a b).state :=
    PoolCursor.preserves (c:=next l (middle l c a b) (SignedAddCalls.magnitude a.hi b.hi))
      (PoolCursor.preserves (c:=middle l c a b) (sum_live l (base c a b) a.lo b.lo))
  have highLive : (high l c a b).Live (finish l c a b).state := sum_live l (middle l c a b) a.hi b.hi
  have cl : castValue Header.layout (finish l c a b).state 99 "S" (low c a b).source=some (low c a b).source :=
    Endpoint.cast 97 "S" (by decide +kernel) lowLive
  have ch : castValue Header.layout (finish l c a b).state 99 "S" (high l c a b).source=some (high l c a b).source :=
    Endpoint.cast 97 "S" (by decide +kernel) highLive
  have cast : castValue Header.layout (finish l c a b).state 100 "I"
      (.aggregate [(low c a b).source,(high l c a b).source,boolean Header.layout (a.ok&&b.ok)])=some (result l c a b) :=
    DyadicPairFrames.aggregate_boolean _ _ _ _ cl ch
  have shape : (finish l c a b).state.heap.length=(base c a b).state.heap.length ∧
      (finish l c a b).state.env=(base c a b).state.env :=
    CursorEffects.shape l (base c a b) [SignedAddCalls.magnitude a.lo b.lo,0,SignedAddCalls.magnitude a.hi b.hi,0]
  have body := DeclarationReturn.body Header.layout service "I" "r" initializer expr cast (by rfl)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  rw[LocalScope.pop_local "I" "r" (result l c a b) shape.1 shape.2] at body
  apply installed_body (f:=Generated.f_iadd) (rank:=5) (service:=service) installed closed (DyadicPairFrames.bind a b ha hb) body
  exact ⟨DyadicCasts.record _ 97 "static I" (by decide +kernel) _ _ _ cl ch,rfl⟩
end ScopedC.DyadicAddCalls
