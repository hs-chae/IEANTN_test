/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedDecimalBranch
namespace ScopedC.NamedDecimalCompletion
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.NamedDecimalPair ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Syntactic installation of the actual already-verified source callees.
These fields contain no execution-result or mathematical-output assumptions. -/
structure Library (code : List Function) : Prop where
  fromRI : Generated.f_fromRI∈code
  qt : Generated.f_qt∈code
  floorQ : Generated.f_floorQ∈code
  ceilQ : Generated.f_ceilQ∈code
  qn : Generated.f_qn∈code
  sn : Generated.f_sn∈code
  multiply : RationalMultiplyCalls.Library code
  round : FloorQNegativeCalls.Library code

/-- Both original decimal endpoint source expressions, their physical stores,
branch-scope exit and the actual final fromRI call share one closed service.
The output is exactly the original -100 dyadic rounding. -/
theorem complete (code : List Function) (lib : Library code)
    {l : PoolLayout} {c : Cursor} {nl nh den slot object valueSlot : Nat}
    {oldLo oldHi : Value} (D : Stages code l c nl nh den slot oldHi)
    (ctx : Valid l c) (record : RationalRecordFields.At c.state oldLo oldHi slot)
    (scale : SourceFromS.ScaleAt c.state object valueSlot (2^100)) (ascending : nl≤nh)
    (room : c.top+60+4*(DecimalText.digits nl).length+4*(DecimalText.digits nh).length+
      8*(DecimalText.digits den).length<capacity) :
    ∃service : Call, ∃out : Cursor, ∃lo hi : Endpoint,
      (∀name args before value after, service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      Run Header.layout service (.sequence (NamedDecimalBranch.statements nl nh den)) c.state
        (.continuing (NamedDecimalBranch.after D).state) ∧
      evalExpr Header.layout service 1000 (NamedDecimalBranch.after D).state
        (.call (.var "fromRI") [.var "r",.nat 1])=
        some (DyadicCasts.value lo.source hi.source true,out.state) ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (LeanCert.Core.IntervalDyadic.ofIntervalRat
          ⟨(input D).lo.mathematical.value,(input D).hi.mathematical.value,
            NamedDecimalBranch.ordered D ascending⟩ (-100),true) := by
  have lowRoom : D.low.numerator.top<capacity := by rw [D.low.numeratorTop];omega
  have midTop : (middle D).top=c.top+8+4*(DecimalText.digits nl).length+
      4*(DecimalText.digits den).length := RationalDecimalLiteral.top D.low
  have highRoom : D.high.numerator.top<capacity := by
    rw [D.high.numeratorTop]
    change (middle D).top+1+4*(DecimalText.digits nh).length<capacity
    rw [midTop]
    omega
  have physical := NamedDecimalBranch.result D ctx record lowRoom highRoom
  have sourceScale := NamedDecimalBranch.scale D ctx record lowRoom highRoom scale
  have fromRoom : (NamedDecimalBranch.after D).top+37<capacity := by
    change (finish D).top+37<capacity
    rw [NamedDecimalPair.top]
    omega
  obtain ⟨out,lo,hi,fromCall,outValid,loLive,hiLive,decoded⟩ :=
    SourceFromRIArguments.literal_one_math code lib.fromRI lib.qt lib.floorQ lib.ceilQ
      lib.qn lib.sn lib.multiply lib.round physical.1 (input D) sourceScale physical.2.2
      D.low.positive D.high.positive (NamedDecimalBranch.ordered D ascending) fromRoom
  let last : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[(input D).source,DecimalDigits.integer 1],(NamedDecimalBranch.after D).state,
      DyadicCasts.value lo.source hi.source true,out.state,fromCall⟩
  obtain ⟨service,closed,lowExpr,highExpr,answer⟩ :=
    NamedDecimalService.source_expressions D last rfl rfl
  have branch := NamedDecimalBranch.run service D ctx record lowRoom highRoom lowExpr highExpr
  have readR := RationalRecordFields.read_ri service 998 (input D) physical.2.1
  have literal := RationalUnsignedRatio.literal service (NamedDecimalBranch.after D).state 998 1
    (by decide +kernel)
  have returnExpr := ExpressionTemplates.call_two Header.layout service readR literal answer
  exact ⟨service,out,lo,hi,closed,branch,returnExpr,outValid,loLive,hiLive,decoded⟩

#print axioms complete
end ScopedC.NamedDecimalCompletion
