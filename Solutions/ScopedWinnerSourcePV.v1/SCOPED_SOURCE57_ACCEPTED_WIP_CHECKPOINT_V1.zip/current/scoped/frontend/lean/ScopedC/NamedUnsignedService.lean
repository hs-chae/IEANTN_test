/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedUnsignedTrace
import ScopedC.SourceFromRIArguments
namespace ScopedC.NamedUnsignedService
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.NamedUnsignedPair
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Generalize both physical input cursors before constructing source expression
proofs; this keeps symbolic division-state computation out of elaboration. -/
theorem two_sources {code : List Function} {l : PoolLayout} {c second : Cursor}
    {nl nh den : Nat} (low : RationalUnsignedRatio.Stages code l c nl den)
    (high : RationalUnsignedRatio.Stages code l second nh den)
    (progress : c.state.nats.values.length+10 ≤ second.state.nats.values.length)
    (nlo : nl<2^31) (nhi : nh<2^31) (db : den<2^31)
    (last : CallEvents.Event Header.layout code 8)
    (lastProgress : second.state.nats.values.length+10 ≤ last.before.nats.values.length) :
    ∃service : Call,
      (∀name args before value after, service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      evalExpr Header.layout service 1000 c.state (RationalUnsignedRatio.initializer nl den)=
        some (low.output.source,(RationalUnsignedRatio.after l c nl den).state) ∧
      evalExpr Header.layout service 1000 second.state (RationalUnsignedRatio.initializer nh den)=
        some (high.output.source,(RationalUnsignedRatio.after l second nh den).state) ∧
      service last.name last.args last.before=some (last.value,last.after) := by
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer nl],c.state,(RationalUnsignedRatio.numInput l c nl).source,
      (RationalUnsignedRatio.numerator l c nl).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) low.numeratorCall⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer den],(RationalUnsignedRatio.numerator l c nl).state,
      (RationalUnsignedRatio.denInput l c nl den).source,(RationalUnsignedRatio.denominator l c nl den).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) low.denominatorCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"qv",[(RationalUnsignedRatio.numInput l c nl).source,(RationalUnsignedRatio.denInput l c nl den).source],
      (RationalUnsignedRatio.denominator l c nl den).state,low.output.source,
      (RationalUnsignedRatio.after l c nl den).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) low.divideCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer nh],second.state,(RationalUnsignedRatio.numInput l second nh).source,
      (RationalUnsignedRatio.numerator l second nh).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) high.numeratorCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"qi",[DecimalDigits.integer den],(RationalUnsignedRatio.numerator l second nh).state,
      (RationalUnsignedRatio.denInput l second nh den).source,
      (RationalUnsignedRatio.denominator l second nh den).state,
      SourceRanks.monotone (by omega : 6 ≤ 8) high.denominatorCall⟩
  let e5 : CallEvents.Event Header.layout code 8 :=
    ⟨"qv",[(RationalUnsignedRatio.numInput l second nh).source,
      (RationalUnsignedRatio.denInput l second nh den).source],
      (RationalUnsignedRatio.denominator l second nh den).state,high.output.source,
      (RationalUnsignedRatio.after l second nh den).state,
      SourceRanks.monotone (by omega : 7 ≤ 8) high.divideCall⟩
  let events := [e0,e1,e2,e3,e4,e5,last]
  have ln := NamedUnsignedTrace.numerator_count l c nl
  have ld := NamedUnsignedTrace.denominator_count l c nl den
  have hn := NamedUnsignedTrace.numerator_count l second nh
  have hd := NamedUnsignedTrace.denominator_count l second nh den
  have unique : (CallEvents.counts events).Nodup := by
    change [c.state.nats.values.length,(RationalUnsignedRatio.numerator l c nl).state.nats.values.length,
      (RationalUnsignedRatio.denominator l c nl den).state.nats.values.length,
      second.state.nats.values.length,(RationalUnsignedRatio.numerator l second nh).state.nats.values.length,
      (RationalUnsignedRatio.denominator l second nh den).state.nats.values.length,
      last.before.nats.values.length].Nodup
    simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,not_false_eq_true,
      List.nodup_nil,and_true,not_or]
    repeat' constructor <;> omega
  let service := CallEvents.service events
  have answers := CallEvents.service_self events unique
  refine ⟨service,fun _ _ _ _ _ h=>CallEvents.service_closed events h,?_,?_,?_⟩
  · exact RationalUnsignedRatio.expression (code:=code) (l:=l) (c:=c) (n:=nl) (d:=den) service low nlo db
      (answers e0 (List.Mem.head _)) (answers e1 (List.Mem.tail _ (List.Mem.head _))) (answers e2 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))))
  · exact RationalUnsignedRatio.expression (code:=code) (l:=l) (c:=second) (n:=nh) (d:=den) service high nhi db
      (answers e3 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))))) (answers e4 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))))) (answers e5 (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))))))
  · exact answers last (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _)))))))


theorem source_expressions {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : RationalRecordFields.At c.state oldLo oldHi slot) (room : c.top+90<capacity)
    (nlo : nl<2^31) (nhi : nh<2^31) (db : den<2^31)
    (last : CallEvents.Event Header.layout code 8)
    (lastCount : last.before.nats.values.length=(finish D).state.nats.values.length) :
    ∃service : Call,
      (∀name args before value after, service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      evalExpr Header.layout service 1000 c.state (RationalUnsignedRatio.initializer nl den)=
        some (D.low.output.source,(RationalUnsignedRatio.after l c nl den).state) ∧
      evalExpr Header.layout service 1000 (middle D).state (RationalUnsignedRatio.initializer nh den)=
        some (D.high.output.source,(RationalUnsignedRatio.after l (middle D) nh den).state) ∧
      service last.name last.args last.before=some (last.value,last.after) := by
  have lowRoom : c.top+18<capacity := by omega
  have mid := middle_valid D ctx record lowRoom
  have lowTop := RationalUnsignedRatio.top_bound ctx nl den lowRoom
  have highRoom : (middle D).top+18<capacity := by
    change (RationalUnsignedRatio.after l c nl den).top+18<capacity
    omega
  have lowGrowth := NamedUnsignedTrace.output_count_bounds ctx nl den lowRoom
  have highGrowth := NamedUnsignedTrace.output_count_bounds mid.1 nh den highRoom
  have progress : c.state.nats.values.length+10 ≤ (middle D).state.nats.values.length := lowGrowth.1
  have lastProgress : (middle D).state.nats.values.length+10 ≤ last.before.nats.values.length := by
    rw [lastCount]
    exact highGrowth.1
  exact two_sources (c:=c) (second:=middle D) D.low D.high progress nlo nhi db last lastProgress

#print axioms two_sources
#print axioms source_expressions
end ScopedC.NamedUnsignedService
