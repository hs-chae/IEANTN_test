/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalAddRefinement
import ScopedC.NumericNegationRefinement
import ScopedC.PoolContextPop
import ScopedC.NumericNatsExtensionality

namespace ScopedC.RationalSubCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def negative (b : Input) : Input :=
  ⟨⟨b.numerator.slot,b.numerator.magnitude,if b.numerator.magnitude=0 then false else !b.numerator.negative⟩,b.denSlot,b.denominator⟩
def c1 (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := next l c 0
def phase1 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  CursorFrames.framed (c1 l c) "Q" "a" a.source "Q" "b" b.source
@[irreducible] def interior (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  RationalAddCalls.c14 l (phase1 l c a b) a (negative b)
def result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Value :=
  RationalAddCalls.result l (phase1 l c a b) a (negative b)
def after (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  PoolContextPop.unframe c.state (interior l c a b)

theorem negative_source (b : Input) : (negative b).source=
    RationalNegCalls.value b.numerator.slot
      (if b.numerator.magnitude==0 then 0 else SignedNegCalls.bit (!b.numerator.negative)) b.denSlot := by
  by_cases hz : b.numerator.magnitude=0 <;>
    simp [negative,Input.source,Endpoint.source,SignedValues.value,RationalNegCalls.value,SignedNegCalls.value,SignedNegCalls.bit,hz]

theorem negative_live {s : State} {b : Input} (h : b.Live s) : (negative b).Live s := h

theorem negative_value (b : Input) : (negative b).mathematical.value= -b.mathematical.value :=
  NumericNegationRefinement.rational_negation b.numerator.mathematical b.denominator

theorem phase1_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+14<PoolCalls.capacity) (a b : Input) : Valid l (phase1 l c a b) :=
  CursorFrames.framed_valid (next_valid 0 ctx (by omega)) "Q" "a" a.source "Q" "b" b.source

theorem interior_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+14<PoolCalls.capacity) (a b : Input) : Valid l (interior l c a b) := by
  have ctxp := phase1_context ctx room a b
  have cap : (phase1 l c a b).top+13<PoolCalls.capacity := by change c.top+1+13<PoolCalls.capacity;omega
  have ctx9 := RationalAddCalls.c9_context ctxp cap a (negative b)
  rw [interior]
  exact (RationalMakeCalls.contexts (RationalAddCalls.sum l (phase1 l c a b) a (negative b))
    (RationalAddCalls.denominator a (negative b)) ctx9
    (by rw[RationalAddCalls.c9_top];omega)).2.2.2.2

theorem after_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+14<PoolCalls.capacity) (a b : Input) : Valid l (after l c a b) :=
  PoolContextPop.valid (interior_context ctx room a b)
    ((List.getElem?_eq_some_iff.mp ctx.pool_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.top_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.high_read).choose)

theorem decoded (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) :
    NumericRepresentation.rational (after l c a b).state (result l c a b)=
      some (Rational.normalize (RationalAddCalls.sum l (phase1 l c a b) a (negative b)).mathematical
        (RationalAddCalls.denominator a (negative b))) := by
  rw [NumericNatsExtensionality.rational (s:=(after l c a b).state) (t:=(interior l c a b).state) rfl (result l c a b)]
  unfold interior
  exact RationalAddCalls.result_decoded l (phase1 l c a b) a (negative b) pa pb

theorem value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) :
    (Rational.normalize (RationalAddCalls.sum l (phase1 l c a b) a (negative b)).mathematical
        (RationalAddCalls.denominator a (negative b))).value=a.mathematical.value-b.mathematical.value := by
  rw [RationalAddCalls.mathematical_value l (phase1 l c a b) a (negative b) pa pb,negative_value,sub_eq_add_neg]

end ScopedC.RationalSubCalls
