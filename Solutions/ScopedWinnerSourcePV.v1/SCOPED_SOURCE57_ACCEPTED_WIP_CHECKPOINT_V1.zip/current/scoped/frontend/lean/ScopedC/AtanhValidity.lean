/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhMath

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 150000

/-- Real analytic validity of the actual original C atanhPoint result, with
exactly the existing Taylor coefficients and analytic domain. Application
prepare must establish the physical table and these coefficient values. -/
theorem atanhPoint_valid (code : List Function) (installed : Generated.f_atanhPoint∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (alive : q.Live c.state) (positive : 0<q.denominator) (d object : Nat)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (lookup : c.state.globals.lookup "atanhCoeffs"=some base)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high)
    (dBound : d≤64) (length : coeffs.length=d+1) (room : c.top+9000<PoolCalls.capacity)
    (coefficients : TaylorCalls.coefficientValues coeffs=IntervalRat.atanhTaylorCoeffs d)
    (domain : |(q.mathematical.value:Real)|<1) :
    ∃out : Cursor,∃pair : Pair,
      SourceCall Header.layout code 10 "atanhPoint" [q.source] c.state pair.source out.state ∧
      Valid l out ∧ pair.Live out.state ∧ pair.Positive ∧
      ((pair.lo.mathematical.value:Real)≤Real.atanh (q.mathematical.value:Real) ∧
        Real.atanh (q.mathematical.value:Real)≤(pair.hi.mathematical.value:Real)) := by
  obtain ⟨out,pair,execution,valid,live,positivePair,decoded⟩:=atanhPoint_math code installed lib ctx q
    alive positive d object table lookup depth apart dBound length room
  rw[coefficients,IntervalRat.atanhPointComputableWithCoeffs_eq] at decoded
  have values:=Pair.values_of_decoded live positivePair decoded
  have enclosed:=IntervalRat.mem_atanhPointComputable q.mathematical.value d domain
  refine ⟨out,pair,execution,valid,live,positivePair,?_⟩
  rw[values.1,values.2]
  exact enclosed

end ScopedC.AtanhCalls
