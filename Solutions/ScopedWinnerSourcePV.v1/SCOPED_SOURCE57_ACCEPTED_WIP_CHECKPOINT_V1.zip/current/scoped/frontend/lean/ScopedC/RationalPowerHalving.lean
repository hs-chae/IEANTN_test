/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerFrame
import ScopedC.RationalPowerGuard

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

def half {l : PoolCalls.PoolLayout} (f : Frame l) : Frame l := {
  cursor:=LocalAssignment.cursor f.cursor f.nSlot "unsigned int" (PoolCalls.word (f.exponent/2))
  current:=f.current
  accumulator:=f.accumulator
  exponent:=f.exponent/2
  aSlot:=f.aSlot
  nSlot:=f.nSlot
  rSlot:=f.rSlot
  context:=by
    have safe:=LocalStorageSeparation.pool f.context f.nAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
    exact LocalAssignment.valid f.context _ _ _ safe.1 safe.2.1 safe.2.2
  aAt:=LocalAssignment.other_binding f.aAt
    (LocalStorageSeparation.typed f.aAt f.nAt (by decide +kernel))
  nAt:=LocalAssignment.binding f.nAt (by rfl)
  rAt:=LocalAssignment.other_binding f.rAt
    (LocalStorageSeparation.typed f.rAt f.nAt (by decide +kernel))
  aLive:=f.aLive
  rLive:=f.rLive
  aPositive:=f.aPositive
  rPositive:=f.rPositive
  exponentBound:=RationalPowerCounter.halve_range f.exponent f.exponentBound
  arDistinct:=f.arDistinct }

/-- The formal frame update is the actual source n=n/2 expression, not a
standalone exponent algorithm. All local memory/word facts are carried. -/
theorem half_source (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l) :
    Eval Header.layout service (.binary "=" (.var "n") (.binary "/" (.var "n") (.nat 2)))
      f.cursor.state (half f).cursor.state (PoolCalls.word (f.exponent/2)) :=
  ⟨4,RationalPowerGuard.halve_assignment service 0 f.nAt f.exponentBound⟩

theorem half_shape {l : PoolCalls.PoolLayout} (f : Frame l) :
    (half f).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (half f).cursor.state.env=f.cursor.state.env ∧
    (half f).cursor.state.nats=f.cursor.state.nats := by
  simp [half,LocalAssignment.cursor,LocalAssignment.changed,PoolCalls.storeObject]

end ScopedC.RationalPowerCalls
