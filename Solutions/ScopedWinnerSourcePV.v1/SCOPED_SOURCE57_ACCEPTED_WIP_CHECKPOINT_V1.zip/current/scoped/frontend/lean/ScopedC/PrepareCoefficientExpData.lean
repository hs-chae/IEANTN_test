/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientFrame
import ScopedC.RationalPowerInitialization
import ScopedC.RationalDivideOutput
import ScopedC.RationalUnsignedTrace

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

structure CoeffLibrary (code : List Function) : Prop where
  unsigned : RationalPowerCalls.Library code
  qv : Generated.f_qv∈code
  division : RationalDivideCalls.Library code

def counterQ {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : Input := RationalUnsignedTrace.output l f.cursor f.k

def counterQCursor {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : Cursor := RationalUnsignedTrace.after l f.cursor f.k

noncomputable def expNext {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : Input :=
  RationalDivideCalls.outputInput l (counterQCursor f) (previous f) (counterQ f)
    (previous_positive f) (by change 0<(1:Nat);decide +kernel)

@[irreducible] def expDivideCursor {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : Cursor :=
  RationalDivideCalls.after l (counterQCursor f) (previous f) (counterQ f)

theorem counterQ_valid {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    Valid l (counterQCursor f) :=
  CursorFrames.advance_valid f.context [f.k,0,1] (by change f.cursor.top+3 ≤ PoolCalls.capacity;omega)

theorem counterQ_source (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [PoolCalls.word f.k] f.cursor.state
      (counterQ f).source (counterQCursor f).state := by
  have kb:=f.kBound
  have db:=f.depthBound
  exact (RationalUnsignedTrace.qi_traced code lib.unsigned.qi lib.unsigned.si
    lib.unsigned.productLibrary.smake lib.unsigned.productLibrary.nz lib.unsigned.productLibrary.nu
    lib.unsigned.productLibrary.ne lib.unsigned.productLibrary.keep f.context f.k (by omega)
    (by omega) (PoolCalls.word f.k) (RationalUnsignedCalls.cast_parameter f.cursor.state f.k (by omega))).1

theorem expDivide_source (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    SourceCall Header.layout code 7 "qv" [(previous f).source,(counterQ f).source] (counterQCursor f).state
      (expNext f).source (expDivideCursor f).state := by
  unfold expDivideCursor
  exact RationalDivideCalls.output_source code lib.qv lib.division (counterQ_valid f room)
    (by change f.cursor.top+3+12<PoolCalls.capacity;omega) (previous f) (counterQ f)
    ⟨CursorBorrow.preserves (l:=l) (c:=f.cursor) [f.k,0,1] (previous_live f).1,
      CursorBorrow.preserves (l:=l) (c:=f.cursor) [f.k,0,1] (previous_live f).2⟩
    (RationalUnsignedTrace.live l f.cursor f.k) (previous_positive f)
    (by change 0<(1:Nat);decide +kernel)

theorem expNext_live {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : (expNext f).Live (expDivideCursor f).state := by
  unfold expDivideCursor
  exact (RationalDivideCalls.output_spec l (counterQCursor f) (previous f) (counterQ f)
    (previous_positive f) (by change 0<(1:Nat);decide +kernel)).2.1

theorem expNext_positive {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : 0<(expNext f).denominator :=
  (RationalDivideCalls.output_spec l (counterQCursor f) (previous f) (counterQ f)
    (previous_positive f) (by change 0<(1:Nat);decide +kernel)).2.2.2

theorem expNext_value {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : (expNext f).mathematical.value=expCoefficient f.k := by
  have result : (expNext f).mathematical.value=(previous f).mathematical.value/(counterQ f).mathematical.value :=
    (RationalDivideCalls.output_spec l (counterQCursor f) (previous f) (counterQ f)
      (previous_positive f) (by change 0<(1:Nat);decide +kernel)).2.2.1
  rw[result,previous_value]
  have value : (counterQ f).mathematical.value=(f.k:Rat):=(RationalUnsignedTrace.mathematical l f.cursor f.k).1
  rw[value]
  exact exp_step f.k f.kPositive

theorem expDivide_nonzero {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) :
    expDivideCursor f=RationalDivideCalls.nonzeroAfter l (counterQCursor f) (previous f) (counterQ f) := by
  unfold expDivideCursor RationalDivideCalls.after
  rw[if_neg (show (counterQ f).numerator.magnitude≠0 from by
    change f.k≠0
    exact ne_of_gt f.kPositive)]

theorem expDivide_valid {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    Valid l (expDivideCursor f) := by
  unfold expDivideCursor
  exact RationalDivideCalls.after_context (counterQ_valid f room)
    (by change f.cursor.top+3+12<PoolCalls.capacity;omega) _ _

end ScopedC.PrepareSource
