/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointInputFrames

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

theorem power_unshadowed {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (name : String)
    (np : name ≠ "power") (nk : name ≠ "k") (nm : name ≠ "m")
    (nc : name ≠ "ceil") (nq : name ≠ "q") :
    (afterPower stage).state.env.lookup name = none := by
  have bp : (name=="power")=false := beq_eq_false_iff_ne.mpr np
  have bk : (name=="k")=false := beq_eq_false_iff_ne.mpr nk
  have bm : (name=="m")=false := beq_eq_false_iff_ne.mpr nm
  have bc : (name=="ceil")=false := beq_eq_false_iff_ne.mpr nc
  have bq : (name=="q")=false := beq_eq_false_iff_ne.mpr nq
  change (("power",_)::("k",_)::(afterSmall stage).state.env).lookup name = none
  simp only [List.lookup,bp,bk]
  dsimp only [afterSmall]
  rw [(PoolCursor.shape l (afterLog stage) 4294967295).2]
  dsimp only [afterLog]
  rw [(PoolCursor.shape l (afterM stage) (kValue stage)).2]
  change (("m",_)::(afterAdd stage).state.env).lookup name = none
  simp only [List.lookup,bm]
  dsimp only [afterAdd]
  rw [(PoolCursor.shape l (afterOne stage) (mValue stage)).2]
  dsimp only [afterOne]
  rw [(PoolCursor.shape l (afterCeil stage) 1).2]
  change (("ceil",_)::stage.out.state.env).lookup name = none
  simp only [List.lookup,bc]
  rw [stage.trace,(CursorEffects.shape l (afterAbs l c q) stage.values).2]
  dsimp only [afterAbs]
  rw [(PoolCursor.shape l (parameters c q) 0).2]
  simp only [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate,List.lookup,bq]

theorem input_unshadowed {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) (name : String)
    (ni : name ≠ "input") (nr : name ≠ "reduced") (np : name ≠ "power")
    (nk : name ≠ "k") (nm : name ≠ "m") (nc : name ≠ "ceil") (nq : name ≠ "q") :
    (afterInput stage positive).state.env.lookup name = none := by
  have bi : (name=="input")=false := beq_eq_false_iff_ne.mpr ni
  have br : (name=="reduced")=false := beq_eq_false_iff_ne.mpr nr
  change (("input",_)::("reduced",_)::(reductionCursor stage).state.env).lookup name = none
  simp only [List.lookup,bi,br]
  rw [reduction_nonzero,RationalDivideCalls.nonzero_env]
  change (CursorFrames.advance l (afterPower stage) [powerValue stage,0,1]).state.env.lookup name = none
  rw [(CursorEffects.shape l (afterPower stage) [powerValue stage,0,1]).2]
  exact power_unshadowed stage name np nk nm nc nq

theorem input_power_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator)
    (room : c.top+40 < PoolCalls.capacity) :
    LocalBinding.At (afterInput stage positive).state "power" "unsigned int"
      (PoolCalls.word (powerValue stage)) (afterK stage).state.heap.length := by
  have before := power_binding stage
  have safe := LocalStorageSeparation.pool (power_valid stage (by omega)) before
    (by decide +kernel)
  have first : LocalBinding.At (afterQiPower stage).state "power" "unsigned int"
      (PoolCalls.word (powerValue stage)) (afterK stage).state.heap.length :=
    LocalBinding.advance before [powerValue stage,0,1] safe.1 safe.2.1 safe.2.2
  have second : LocalBinding.At (reductionCursor stage).state "power" "unsigned int"
      (PoolCalls.word (powerValue stage)) (afterK stage).state.heap.length := by
    rw [reduction_nonzero]
    exact LocalBinding.memory first (RationalDivideCalls.nonzero_env _ _ _ _)
      (RationalDivideCalls.nonzero_other _ _ _ _ _
        (List.getElem?_eq_some_iff.mp first.memory).choose safe.1 safe.2.1 safe.2.2)
  exact LocalBinding.allocate_other
    (LocalBinding.allocate_other second "reduced" "Q" _ (by decide +kernel))
    "input" "RI" _ (by decide +kernel)

end ScopedC.ExpPointCalls
