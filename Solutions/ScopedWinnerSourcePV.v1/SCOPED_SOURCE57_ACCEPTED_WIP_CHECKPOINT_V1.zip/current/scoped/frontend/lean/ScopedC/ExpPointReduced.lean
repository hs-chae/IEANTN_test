/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointFrontFrames
import ScopedC.RationalUnsignedTrace
import ScopedC.RationalDivideOutput
import ScopedC.RationalPointBody

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

structure ReductionLibrary (code : List Function) : Prop where
  count : CountLibrary code
  divide : RationalDivideCalls.Library code
  qv : Generated.f_qv ∈ code
  point : Generated.f_point ∈ code

def qiPower {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Input :=
  RationalUnsignedTrace.output l (afterPower stage) (powerValue stage)

def afterQiPower {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor :=
  RationalUnsignedTrace.after l (afterPower stage) (powerValue stage)

@[irreducible] def reductionCursor {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {q : Input} (stage : CeilStage code l c q) : Cursor :=
  RationalDivideCalls.after l (afterQiPower stage) q (qiPower stage)

/-- Decoder inversion of the actual source-produced Q, never an executable
replacement for the source division. -/
noncomputable def reduction {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) : Input :=
  RationalDivideCalls.outputInput l (afterQiPower stage) q (qiPower stage) positive
    (by change 0 < (1:Nat); decide +kernel)

theorem afterQiPower_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (room : c.top+40 < PoolCalls.capacity) :
    Valid l (afterQiPower stage) := by
  have top := power_top stage
  exact CursorFrames.advance_valid (power_valid stage (by omega)) [powerValue stage,0,1]
    (by change (afterPower stage).top+3 ≤ PoolCalls.capacity; omega)

theorem qi_power_source (code : List Function) (lib : ReductionLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (bound : kValue stage < 32) (room : c.top+40 < PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [PoolCalls.word (powerValue stage)]
      (afterPower stage).state (qiPower stage).source (afterQiPower stage).state := by
  have top := power_top stage
  exact (RationalUnsignedTrace.qi_traced code lib.divide.qi lib.divide.si lib.divide.mul.smake
    lib.divide.mul.nz lib.divide.mul.nu lib.divide.mul.ne lib.divide.mul.keep
    (power_valid stage (by omega)) (powerValue stage) (power_bound stage bound).2
    (by omega) (PoolCalls.word (powerValue stage))
    (RationalUnsignedCalls.cast_parameter _ _ (power_bound stage bound).2)).1

theorem reduction_nonzero {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    reductionCursor stage = RationalDivideCalls.nonzeroAfter l (afterQiPower stage) q (qiPower stage) := by
  unfold reductionCursor RationalDivideCalls.after
  rw [if_neg (show (qiPower stage).numerator.magnitude ≠ 0 from
    Nat.ne_of_gt (pow_pos (by decide) _))]

theorem reduction_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (room : c.top+40 < PoolCalls.capacity) :
    Valid l (reductionCursor stage) := by
  unfold reductionCursor
  have top := power_top stage
  exact RationalDivideCalls.after_context (afterQiPower_valid stage room)
    (by change (afterPower stage).top+3+12 < PoolCalls.capacity; omega) _ _

theorem reduction_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    (reduction stage positive).Live (reductionCursor stage).state := by
  unfold reductionCursor
  exact (RationalDivideCalls.output_spec l (afterQiPower stage) q (qiPower stage) positive
    (by change 0 < (1:Nat); decide +kernel)).2.1

theorem reduction_positive {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    0 < (reduction stage positive).denominator :=
  (RationalDivideCalls.output_spec l (afterQiPower stage) q (qiPower stage) positive
    (by change 0 < (1:Nat); decide +kernel)).2.2.2

theorem reduction_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (positive : 0 < q.denominator) :
    (reduction stage positive).mathematical.value = ExpPointReduction.reduced q.mathematical.value := by
  have result := (RationalDivideCalls.output_spec l (afterQiPower stage) q (qiPower stage) positive
    (by change 0 < (1:Nat); decide +kernel)).2.2.1
  have divisor := (RationalUnsignedTrace.mathematical l (afterPower stage) (powerValue stage)).1
  change (reduction stage positive).mathematical.value = q.mathematical.value /
    (qiPower stage).mathematical.value at result
  change (qiPower stage).mathematical.value = (powerValue stage : Rat) at divisor
  rw [result,divisor,power_value stage positive]
  rfl

theorem reduction_source (code : List Function) (lib : ReductionLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (live : q.Live c.state) (positive : 0 < q.denominator)
    (room : c.top+40 < PoolCalls.capacity) :
    SourceCall Header.layout code 7 "qv" [q.source,(qiPower stage).source]
      (afterQiPower stage).state (reduction stage positive).source (reductionCursor stage).state := by
  have top := power_top stage
  have qLive : q.Live (afterQiPower stage).state :=
    ⟨CursorBorrow.preserves (l:=l) (c:=afterPower stage) [powerValue stage,0,1]
        (power_q_live stage live).1,
      CursorBorrow.preserves (l:=l) (c:=afterPower stage) [powerValue stage,0,1]
        (power_q_live stage live).2⟩
  unfold reductionCursor
  exact RationalDivideCalls.output_source code lib.qv lib.divide (afterQiPower_valid stage room)
    (by change (afterPower stage).top+3+12 < PoolCalls.capacity; omega) _ _ qLive
    (RationalUnsignedTrace.live l (afterPower stage) (powerValue stage)) positive
    (by change 0 < (1:Nat); decide +kernel)

end ScopedC.ExpPointCalls
