/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhWideSizes
import ScopedC.SourceRanks

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard wideC1 wideC2 wideFinish

/-- Entire actual atanhPoint source on its wide early-return branch. The second
qi(1000) is executed separately; no hardcoded interval replaces the C calls.
The complementary |q|<1 branch remains a separate source obligation. -/
theorem atanh_wide_closed (code : List Function) (installed : Generated.f_atanhPoint∈code)
    (lib : WideLibrary code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (alive : q.Live c.state) (positive : 0<q.denominator)
    (wide : 1≤|q.mathematical.value|) (room : c.top+16<PoolCalls.capacity) :
    ∃out : Cursor,∃pair : Pair,
      SourceCall Header.layout code 10 "atanhPoint" [q.source] c.state pair.source out.state ∧
      Valid l out ∧ pair.Live out.state ∧ pair.Positive ∧
      NumericRepresentation.interval out.state pair.source=
        some (⟨-1000,1000,by norm_num⟩ : LeanCert.Core.IntervalRat) := by
  let e0 : CallEvents.Event Header.layout code 9 :=
    ⟨"qabs",[q.source],(parameters c q).state,(absInput q).source,(afterAbs l c q).state,
      SourceRanks.monotone (by decide +kernel) (abs_call code lib.guard.absolute ctx q alive (by omega))⟩
  let e1 : CallEvents.Event Header.layout code 9 :=
    ⟨"qi",[DecimalDigits.integer 1],(afterR l c q).state,
      (oneInput l c q).source,(afterOne l c q).state,
      SourceRanks.monotone (by decide +kernel) (one_call code lib.guard ctx q (by omega))⟩
  let e2 : CallEvents.Event Header.layout code 9 :=
    ⟨"qc",[(absInput q).source,(oneInput l c q).source],(afterOne l c q).state,
      SignedCompareCalls.integer (guardValue q),(afterGuard l c q).state,
      SourceRanks.monotone (by decide +kernel) (compare_call code lib.guard ctx q alive positive (by omega))⟩
  let e3 : CallEvents.Event Header.layout code 9 :=
    ⟨"qi",[DecimalDigits.integer 1000],(afterGuard l c q).state,
      (wideFirst l c q).source,(wideC1 l c q).state,
      SourceRanks.monotone (by decide +kernel) (wide_first_source code lib ctx q room)⟩
  let e4 : CallEvents.Event Header.layout code 9 :=
    ⟨"qn",[(wideFirst l c q).source],(wideC1 l c q).state,
      (widePair l c q).lo.source,(wideC2 l c q).state,
      SourceRanks.monotone (by decide +kernel) (wide_neg_source code lib ctx q room)⟩
  let e5 : CallEvents.Event Header.layout code 9 :=
    ⟨"qi",[DecimalDigits.integer 1000],(wideC2 l c q).state,
      (wideSecond l c q).source,(wideFinish l c q).state,
      SourceRanks.monotone (by decide +kernel) (wide_second_source code lib ctx q room)⟩
  have oneSize : (afterOne l c q).state.nats.values.length=c.state.nats.values.length+4 := by
    change (CursorFrames.advance l (afterR l c q) [1,0,1]).state.nats.values.length=_
    rw[CursorEffects.size,afterR_size]
    rfl
  have unique : ([e0,e1,e2,e3,e4,e5].map CallEvents.timeKey).Nodup := by
    change [c.state.nats.values.length,(afterR l c q).state.nats.values.length,
      (afterOne l c q).state.nats.values.length,(afterGuard l c q).state.nats.values.length,
      (wideC1 l c q).state.nats.values.length,(wideC2 l c q).state.nats.values.length].Nodup
    rw[afterR_size,oneSize,guard_size,wideC1_size,wideC2_size]
    change ([0,1,4,10,13,14].map (fun k=>c.state.nats.values.length+k)).Nodup
    exact (by decide +kernel : ([0,1,4,10,13,14]:List Nat).Nodup).map
      (fun _ _ same=>Nat.add_left_cancel same)
  obtain ⟨service,answers,closed⟩:=CallEvents.timeline_service [e0,e1,e2,e3,e4,e5] unique
  have a0:=answers e0 List.mem_cons_self
  have a1:=answers e1 (List.mem_cons_of_mem e0 List.mem_cons_self)
  have a2:=answers e2 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1 List.mem_cons_self))
  have a3:=answers e3 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1
    (List.mem_cons_of_mem e2 List.mem_cons_self)))
  have a4:=answers e4 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1
    (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 List.mem_cons_self))))
  have a5:=answers e5 (List.mem_cons_of_mem e0 (List.mem_cons_of_mem e1
    (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 List.mem_cons_self)))))
  have rDecl:=r_declaration service l c q alive a0
  have condition:=guard_eval service l c q a1 a2
  have wideDecl:=wide_declaration service l c q a3 a4 a5
  have returned : Eval Header.layout service (.var "wide") (afterWide l c q).state
      (afterWide l c q).state (widePair l c q).source :=
    ⟨2,LocalBinding.eval service 1 (wide_binding l c q) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel)⟩
  let innerExit:=PoolContextPop.unframe (afterGuard l c q).state (afterWide l c q)
  let bodyExit:=PoolContextPop.unframe (parameters c q).state innerExit
  let out:=PoolContextPop.unframe c.state bodyExit
  have inner : Run Header.layout service
      (.sequence [.declare [{type:="RI",name:="wide",value:=some wideInitializer,arrayExtent:=none}],
        .returnStmt (.var "wide")]) (afterGuard l c q).state
      (.returned innerExit.state (widePair l c q).source) := by
    apply Loops.StmtRun.sequence
      (Loops.SeqRun.next (Loops.StmtRun.declare wideDecl)
        (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned)))
    exact ⟨rfl,rfl⟩
  have branch : Run Header.layout service
      (.branch guardExpression
        (.sequence [.declare [{type:="RI",name:="wide",value:=some wideInitializer,arrayExtent:=none}],
          .returnStmt (.var "wide")]) .skip) (afterR l c q).state
      (.returned innerExit.state (widePair l c q).source) := by
    apply Loops.StmtRun.branch condition
    simp only[UnsignedLiteralControl.truth_boolean,guard_truth,wide,decide_true,↓reduceIte]
    exact inner
  have body : Run Header.layout service Generated.f_atanhPoint.body (parameters c q).state
      (.returned bodyExit.state (widePair l c q).source) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.declare rDecl)
      (Loops.SeqRun.returned branch))
    exact ⟨rfl,rfl⟩
  have resultLive : (widePair l c q).Live out.state:=wide_live l c q
  have bodyLive : (widePair l c q).Live bodyExit.state:=wide_live l c q
  have source : SourceCall Header.layout code 10 "atanhPoint" [q.source] c.state
      (widePair l c q).source out.state := by
    apply installed_body (f:=Generated.f_atanhPoint) (rank:=9) (service:=service)
      installed closed (bind_parameters c q alive) body
    exact ⟨Pair.cast bodyLive "static RI" (by decide +kernel),rfl⟩
  have finishContext : Valid l (wideFinish l c q) := by
    unfold wideFinish
    exact CursorFrames.advance_valid (wideC2_valid ctx q room) [1000,0,1]
      (by unfold wideC2;change (wideC1 l c q).top+1+3≤PoolCalls.capacity
          rw[wideC1_top];omega)
  have localContext : Valid l (afterWide l c q):=
    CursorLocals.allocated_valid finishContext "RI" "wide" _
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have innerContext : Valid l innerExit:=PoolContextPop.valid localContext
    (by rw[guard_heap];omega) (by rw[guard_heap];omega) (by rw[guard_heap];omega)
  have paramsLength : (parameters c q).state.heap.length=c.state.heap.length+1 := by
    simp [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate]
  have bodyContext : Valid l bodyExit:=PoolContextPop.valid innerContext
    (by rw[paramsLength];omega) (by rw[paramsLength];omega) (by rw[paramsLength];omega)
  have outContext : Valid l out:=PoolContextPop.valid bodyContext hp ht hh
  refine ⟨out,widePair l c q,source,outContext,resultLive,wide_positive l c q,?_⟩
  have decoded:=NumericRationalIntervalAddRefinement.decoded_input resultLive
    (wide_positive l c q) (wide_order l c q)
  have same : (⟨(widePair l c q).lo.mathematical.value,(widePair l c q).hi.mathematical.value,
      wide_order l c q⟩:LeanCert.Core.IntervalRat)=(⟨-1000,1000,by norm_num⟩:LeanCert.Core.IntervalRat) := by
    rw[LeanCert.Core.IntervalRat.mk.injEq]
    exact wide_values l c q
  exact decoded.trans (congrArg some same)

end ScopedC.AtanhCalls
