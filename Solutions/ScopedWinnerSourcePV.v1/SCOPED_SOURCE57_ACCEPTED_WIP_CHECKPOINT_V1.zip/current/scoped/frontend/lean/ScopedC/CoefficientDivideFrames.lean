/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientExpData
import ScopedC.CoefficientTableShapes

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def after_nonzero_division {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) {base : Address} {coeffs : List Input}
    (table : TableAt c.state base coeffs) (a b : Input) :
    TableAt (RationalDivideCalls.nonzeroAfter l c a b).state base coeffs := by
  have safe:=pool_separated ctx table
  have bound:=(List.getElem?_eq_some_iff.mp table.memory).choose
  exact memory table (RationalDivideCalls.nonzero_other l c a b base.object bound
    safe.1 safe.2.1 safe.2.2) (fun _ _ h=>RationalDivideCalls.nonzero_borrow a b h)

theorem nonzero_division_cells {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) {base : Address} {coeffs : List Input}
    (table : TableAt c.state base coeffs) (a b : Input) :
    (after_nonzero_division ctx table a b).cells=table.cells := rfl

end ScopedC.CoefficientTableRead
namespace ScopedC.LocalBinding
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false

theorem nonzero_division {l : PoolCalls.PoolLayout} {c : Cursor}
    {name type : String} {value : Value} {slot : Nat}
    (binding : At c.state name type value slot) (a b : Input)
    (safe : slot≠l.pool ∧ slot≠l.top ∧ slot≠l.high) :
    At (RationalDivideCalls.nonzeroAfter l c a b).state name type value slot :=
  memory binding (RationalDivideCalls.nonzero_env l c a b)
    (RationalDivideCalls.nonzero_other l c a b slot
      (List.getElem?_eq_some_iff.mp binding.memory).choose safe.1 safe.2.1 safe.2.2)

end ScopedC.LocalBinding
namespace ScopedC.SourceUnsignedGlobal
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false

theorem nonzero_division {l : PoolCalls.PoolLayout} {c : Cursor}
    {name : String} {object n : Nat} (depth : At c.state name object n) (a b : Input)
    (safe : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    At (RationalDivideCalls.nonzeroAfter l c a b).state name object n :=
  memory depth (RationalDivideCalls.nonzero_globals l c a b)
    (RationalDivideCalls.nonzero_other l c a b object
      (List.getElem?_eq_some_iff.mp depth.storage).choose safe.1 safe.2.1 safe.2.2)

end ScopedC.SourceUnsignedGlobal
