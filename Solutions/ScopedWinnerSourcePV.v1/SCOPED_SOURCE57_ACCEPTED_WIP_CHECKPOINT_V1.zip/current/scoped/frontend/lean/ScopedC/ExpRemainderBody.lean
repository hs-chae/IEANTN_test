/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderOuterService
import ScopedC.ExpRemainderOutputFrame
import ScopedC.ExpRemainderModel
import ScopedC.NumericNatsExtensionality

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax errorCursor errorInput outputPair

/-- Whole original expRemainder C function. Its actual source calls, original
factorial while, both guards, arithmetic error, RI initializer, return casts and
scope pops are proved. The decoded result is the unchanged original model. -/
theorem expRemainder_closed (code : List Function) (installed : Generated.f_expRemainder∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a : Pair) (alive : a.Live c.state) (positive : a.Positive)
    (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) (d object : Nat)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (dBound : d≤64)
    (range : Int.ceil (max |a.lo.mathematical.value| |a.hi.mathematical.value|)<4294967295)
    (room : c.top+3000<PoolCalls.capacity) :
    ∃out : Cursor,∃pair : Pair,
      SourceCall Header.layout code 10 "expRemainder" [a.source] c.state pair.source out.state ∧
      Valid l out ∧ pair.Live out.state ∧ pair.Positive ∧
      NumericRepresentation.interval out.state pair.source=some
        (IntervalRat.expRemainderBoundComputable ⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩ d) := by
  obtain ⟨ceil⟩:=ceil_stage code lib.ceiling ctx a alive positive (by omega)
  have countBound:=small_guard_bound ceil positive range
  obtain ⟨f⟩:=factorial_stage code lib.powers ceil object d depth apart dBound (by omega)
  obtain ⟨p⟩:=three_power code lib.qpow lib.powers f countBound room
  obtain ⟨r⟩:=radius_power code lib.qpow lib.powers f p alive positive room
  obtain ⟨service,closed,front,loopAnswers,tail⟩:=outer_service code lib ctx a alive f p r countBound room
  have radiusDecl:=radius_declaration service ctx a alive front.absoluteLow front.absoluteHigh front.maximum
  have ceilingDecl:=ceil_declaration service ceil ctx (by omega) front.ceiling
  have ceilingGuard:=ceil_branch service ceil positive
  have countDecl:=small_declaration service ceil (by omega) front.small
  have countGuard:=small_branch service ceil countBound
  have factDecl:=ExpFactorial.fact_declaration service l (afterC ceil) front.one
  have kDecl:=ExpFactorial.k_declaration service l (afterC ceil)
  have factorialLoop : ExpFactorial.While service (ExpFactorial.initial l (afterC ceil)).state
      (.continuing (BeforeError f).state) := by
    rw[←f.cursor]
    exact f.loop.execution service loopAnswers
  have errorDecl:=error_declaration service ctx f p r countBound room tail.qiThree tail.first
    tail.second tail.multiply tail.divide
  have outDecl:=output_declaration service r room tail.negative
  have returned:=out_return service r
  let bodyExit:=PoolContextPop.unframe (parameters c a).state (afterOut r)
  let out:=PoolContextPop.unframe c.state bodyExit
  have body : Run Header.layout service Generated.f_expRemainder.body (parameters c a).state
      (.returned bodyExit.state (outputPair r).source) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.declare radiusDecl) (Loops.SeqRun.next (Loops.StmtRun.declare ceilingDecl) (Loops.SeqRun.next (ceilingGuard) (Loops.SeqRun.next (Loops.StmtRun.declare countDecl) (Loops.SeqRun.next (countGuard) (Loops.SeqRun.next (Loops.StmtRun.declare factDecl) (Loops.SeqRun.next (Loops.StmtRun.declare kDecl) (Loops.SeqRun.next (Loops.StmtRun.whileLoop factorialLoop) (Loops.SeqRun.next (Loops.StmtRun.declare errorDecl) (Loops.SeqRun.next (Loops.StmtRun.declare outDecl) (Loops.SeqRun.returned (Loops.StmtRun.returnValue returned))))))))))))
    exact ⟨rfl,rfl⟩
  have bodyLive : (outputPair r).Live bodyExit.state:=
    Pair.live_unframe (parameters c a).state (afterOut r) (outputPair r) (output_live r)
  have resultLive : (outputPair r).Live out.state:=Pair.live_unframe c.state bodyExit (outputPair r) bodyLive
  have source : SourceCall Header.layout code 10 "expRemainder" [a.source] c.state
      (outputPair r).source out.state := by
    apply installed_body (cfg:=Header.layout) (code:=code) (f:=Generated.f_expRemainder)
      (rank:=9) (service:=service) (args:=[a.source]) (s:=c.state) (frame:=(parameters c a).state)
      (t:=out.state) (v:=(outputPair r).source) (outcome:=.returned bodyExit.state (outputPair r).source)
      installed closed (bind_parameters c a alive) body
    exact ⟨Pair.cast (s:=bodyExit.state) (a:=outputPair r) bodyLive "static RI" (by decide +kernel),rfl⟩
  have hp:=(List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht:=(List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh:=(List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have paramsLength : (parameters c a).state.heap.length=c.state.heap.length+1 := by
    simp [parameters,OneFrames.frame,allocate]
  have bodyContext : Valid l bodyExit:=PoolContextPop.valid (output_valid r room)
    (by rw[paramsLength];omega) (by rw[paramsLength];omega) (by rw[paramsLength];omega)
  refine ⟨out,outputPair r,source,PoolContextPop.valid bodyContext hp ht hh,resultLive,output_positive r,?_⟩
  have decoded:=output_model r positive ordered
  exact (NumericNatsExtensionality.interval (s:=(afterOut r).state) (t:=out.state) rfl (outputPair r).source).symm.trans decoded

end ScopedC.ExpRemainderCalls
