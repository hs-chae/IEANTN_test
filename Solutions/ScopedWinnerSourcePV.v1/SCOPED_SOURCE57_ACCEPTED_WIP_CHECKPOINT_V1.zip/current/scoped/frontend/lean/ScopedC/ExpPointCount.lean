/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointCeil
import ScopedC.SourceNatLog2
import ScopedC.NatSmallCall
import ScopedC.ExpPointReduction
import ScopedC.UnsignedLiteralControl

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure CountLibrary (code : List Function) : Prop where
  ceil : CeilLibrary code
  nu : Generated.f_nu ∈ code
  na : Generated.f_na ∈ code
  small : Generated.f_small ∈ code
  nle : Generated.f_nle ∈ code
  keep : Generated.f_keep ∈ code

def afterCeil {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor :=
  CursorLocals.allocated stage.out "S" "ceil" stage.endpoint.source

def mValue {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Nat := stage.endpoint.magnitude+1

def afterOne {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor := next l (afterCeil stage) 1

def afterAdd {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor := next l (afterOne stage) (mValue stage)

def mSlot {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Nat := (afterOne stage).state.nats.values.length

def afterM {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : Cursor :=
  CursorLocals.allocated (afterAdd stage) "N" "m" (.natObject (mSlot stage))

theorem ceil_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : stage.out.top ≤ c.top+9 := by
  rw [stage.trace,CursorFrames.top_advance]
  change c.top+1+stage.values.length ≤ c.top+9
  have count := stage.count
  omega

theorem ceil_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    LocalBinding.At (afterCeil stage).state "ceil" "S" stage.endpoint.source
      stage.out.state.heap.length := LocalBinding.allocate_head _ "ceil" "S" _ (by rfl)

theorem ceil_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (absAnswer : service "qabs" [q.source] (parameters c q).state =
      some ((absolute q).source,(afterAbs l c q).state))
    (ceilAnswer : service "ceilQ" [(absolute q).source] (afterAbs l c q).state =
      some (stage.endpoint.source,stage.out.state)) :
    Declare Header.layout service [{type:="S",name:="ceil",value:=(some
      (.call (.var "ceilQ") [.call (.var "qabs") [.var "q"]])),arrayExtent:=none}]
      (parameters c q).state (afterCeil stage).state := by
  have expression := ExpressionTemplates.call_one Header.layout service
    (ExpressionTemplates.call_one Header.layout service
      (LocalBinding.eval service 997 (parameters_binding c q) (by decide +kernel)
        (by decide +kernel) (by decide +kernel) (by decide +kernel)) absAnswer) ceilAnswer
  have cast := Endpoint.cast (s:=stage.out.state) 98 "S" (by decide +kernel) stage.live
  simp only [Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

theorem m_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (room : c.top+11 < PoolCalls.capacity) :
    Valid l (afterM stage) := by
  have top := ceil_top stage
  exact CursorLocals.allocated_valid
    (next_valid _ (next_valid _ (CursorLocals.allocated_valid stage.valid "S" "ceil" _)
      (by change stage.out.top < PoolCalls.capacity; omega))
      (by change stage.out.top+1 < PoolCalls.capacity; omega)) "N" "m" _

theorem m_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    NatArena.Borrow (afterM stage).state.nats (mSlot stage) (mValue stage) :=
  next_borrow l (afterOne stage) (mValue stage)

theorem one_source (code : List Function) (lib : CountLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (room : c.top+11 < PoolCalls.capacity) :
    SourceCall Header.layout code 2 "nu" [DecimalDigits.integer 1] (afterCeil stage).state
      (.natObject (afterCeil stage).state.nats.values.length) (afterOne stage).state := by
  have top := ceil_top stage
  exact NatWrapperCalls.nu_call code lib.nu lib.keep
    (CursorLocals.allocated_valid stage.valid "S" "ceil" _)
    (by change stage.out.top < PoolCalls.capacity; omega) (by decide +kernel) rfl

theorem add_source (code : List Function) (lib : CountLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (room : c.top+11 < PoolCalls.capacity) :
    SourceCall Header.layout code 2 "na"
      [.natObject stage.endpoint.slot,.natObject (afterCeil stage).state.nats.values.length]
      (afterOne stage).state (.natObject (mSlot stage)) (afterAdd stage).state := by
  have top := ceil_top stage
  exact NatWrapperCalls.na_call code lib.na lib.keep
    (next_valid _ (CursorLocals.allocated_valid stage.valid "S" "ceil" _)
      (by change stage.out.top < PoolCalls.capacity; omega))
    (by change stage.out.top+1 < PoolCalls.capacity; omega)
    (preserves (c:=afterCeil stage) stage.live) (next_borrow l (afterCeil stage) 1)

theorem m_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    LocalBinding.At (afterM stage).state "m" "N" (.natObject (mSlot stage))
      (afterAdd stage).state.heap.length := LocalBinding.allocate_head _ "m" "N" _ (by rfl)

theorem m_declaration (service : Call) {code : List Function}
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} (stage : CeilStage code l c q)
    (oneAnswer : service "nu" [DecimalDigits.integer 1] (afterCeil stage).state =
      some (.natObject (afterCeil stage).state.nats.values.length,(afterOne stage).state))
    (addAnswer : service "na"
      [.natObject stage.endpoint.slot,.natObject (afterCeil stage).state.nats.values.length]
      (afterOne stage).state = some (.natObject (mSlot stage),(afterAdd stage).state)) :
    Declare Header.layout service [{type:="N",name:="m",value:=some (.call (.var "na")
      [.field "." (.var "ceil") "mag",.call (.var "nu") [.nat 1]]),arrayExtent:=none}]
      (afterCeil stage).state (afterM stage).state := by
  have mag : evalExpr Header.layout service 999 (afterCeil stage).state
      (.field "." (.var "ceil") "mag") =
      some (.natObject stage.endpoint.slot,(afterCeil stage).state) :=
    ExpressionTemplates.field Header.layout service
    (LocalBinding.eval service 997 (ceil_binding stage) (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel)) (by rfl)
  have one := ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 998 (afterCeil stage).state (.nat 1) =
      some (DecimalDigits.integer 1,(afterCeil stage).state) from rfl) oneAnswer
  have expression := ExpressionTemplates.call_two Header.layout service mag one addAnswer
  have cast := PrimitiveCalls.cast_N (s:=(afterAdd stage).state) (m_live stage)
  simp only [Declare,declarations,List.foldlM,expression,cast,Bind.bind,Option.bind]
  rfl

end ScopedC.ExpPointCalls
