/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRepresentation
namespace ScopedC.NumericNatsExtensionality
open ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0

theorem signed {s t : State} (h : s.nats=t.nats) (v : Value) :
    NumericRepresentation.signed s v=NumericRepresentation.signed t v := by
  cases s
  cases t
  cases h
  rfl

theorem rational {s t : State} (h : s.nats=t.nats) (v : Value) :
    NumericRepresentation.rational s v=NumericRepresentation.rational t v := by
  cases s
  cases t
  cases h
  rfl

theorem interval {s t : State} (h : s.nats=t.nats) (v : Value) :
    NumericRepresentation.interval s v=NumericRepresentation.interval t v := by
  cases s
  cases t
  cases h
  rfl

end ScopedC.NumericNatsExtensionality
