/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareLn2ProductFrames
import ScopedC.SourceScalarStoreFrames
import ScopedC.PreparePrefix

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

noncomputable def afterStore {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) (object : Nat) : Cursor :=
  SourceIntervalGlobal.stored (productCursor a) object (product a)

structure Answers (service : Call) {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) : Prop where
  qiTwo : service "qi" [DecimalDigits.integer 2] c.state=some ((two l c).source,(afterTwo l c).state)
  pointCall : service "point" [(two l c).source] (afterTwo l c).state=
    some ((pointTwo l c).source,(afterTwo l c).state)
  qiOne : service "qi" [DecimalDigits.integer 1] (afterTwo l c).state=
    some ((one l c).source,(afterOne l c).state)
  qiThree : service "qi" [DecimalDigits.integer 3] (afterOne l c).state=
    some ((three l c).source,(afterThree l c).state)
  ratioCall : service "qv" [(one l c).source,(three l c).source] (afterThree l c).state=
    some ((ratio l c).source,(beforeAtanh l c).state)
  atanhCall : service "atanhPoint" [(ratio l c).source] (beforeAtanh l c).state=
    some (a.output.source,a.out.state)
  multiplyCall : service "rmul" [(pointTwo l c).source,a.output.source] a.out.state=
    some ((product a).source,(productCursor a).state)

theorem store_eval (service : Call) {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {object : Nat} {old : Option Value}
    (raw : SourceScalarGlobal.At c.state "preparedLn2" "RI" object old)
    (unshadowed : c.state.env.lookup "preparedLn2"=none) (answers : Answers service a) :
    Eval Header.layout service ln2Assignment c.state (afterStore a object).state (product a).source := by
  have twoEval:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 2 c.state (.nat 2)=some (DecimalDigits.integer 2,c.state) from rfl)
    answers.qiTwo
  have left:=ExpressionTemplates.call_one Header.layout service twoEval answers.pointCall
  have oneEval:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 1 (afterTwo l c).state (.nat 1)=
      some (DecimalDigits.integer 1,(afterTwo l c).state) from rfl) answers.qiOne
  have threeEval:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 1 (afterOne l c).state (.nat 3)=
      some (DecimalDigits.integer 3,(afterOne l c).state) from rfl) answers.qiThree
  have quotient:=ExpressionTemplates.call_two Header.layout service oneEval threeEval answers.ratioCall
  have atanh:=ExpressionTemplates.call_one Header.layout service quotient answers.atanhCall
  have right:=ExpressionTemplates.call_two Header.layout service left atanh answers.multiplyCall
  exact ⟨6,SourceIntervalGlobal.source_assignment service 4
    (product_scalar ctx room a raw (by decide +kernel))
    (by rw[product_env];exact unshadowed) (product a) (product_live a) right⟩

theorem stored_at {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+21<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {object : Nat} {old : Option Value}
    (raw : SourceScalarGlobal.At c.state "preparedLn2" "RI" object old) :
    SourceScalarGlobal.At (afterStore a object).state "preparedLn2" "RI" object (some (product a).source) :=
  SourceIntervalGlobal.stored_at (product_scalar ctx room a raw (by decide +kernel)) (product a)

theorem stored_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+9101<PoolCalls.capacity) {d : Nat} {coeffs : List Input}
    (a : AtanhStage code l c d coeffs) {object : Nat} {old : Option Value}
    (raw : SourceScalarGlobal.At c.state "preparedLn2" "RI" object old) : Valid l (afterStore a object) := by
  have valid:=product_valid a room
  have scalar:=product_scalar ctx (by omega) a raw (by decide +kernel)
  have safe:=SourceScalarGlobal.separated valid scalar (by decide +kernel)
  exact LocalAssignment.valid valid object "RI" (product a).source safe.1 safe.2.1 safe.2.2

theorem stored_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) (object : Nat) :
    (product a).Live (afterStore a object).state := product_live a

theorem stored_model {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) (object : Nat)
    (values : TaylorCalls.coefficientValues coeffs=LeanCert.Core.IntervalRat.atanhTaylorCoeffs d) :
    NumericRepresentation.interval (afterStore a object).state (product a).source=
      some (LeanCert.Core.IntervalRat.ln2Computable d) := by
  have same:=NumericNatsExtensionality.interval (s:=(productCursor a).state)
    (t:=(afterStore a object).state) rfl (product a).source
  exact same.trans (product_model a values)

end ScopedC.PrepareSource.Ln2
