/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCompleteStage
import ScopedC.CallEventAbsent

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

theorem prepareEvents_key_unique {code : List Function} (lib : Library code) {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) :
    ((prepareEvents lib stage).map CallEvents.key).Nodup := by
  have timeline:=prepareEvents_unique lib stage
  have mapped : ((prepareEvents lib stage).map CallEvents.key).map Prod.snd=
      (prepareEvents lib stage).map CallEvents.timeKey := by
    simp only[List.map_map,Function.comp_def,CallEvents.key]
    rfl
  rw[← mapped] at timeline
  exact List.Nodup.of_map Prod.snd timeline

theorem prepareEvents_before {code : List Function} (lib : Library code) {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) (e : CoefficientEvent code)
    (member : e∈prepareEvents lib stage) :
    e.before.nats.values.length<stage.loop.finish.cursor.state.nats.values.length := by
  rcases List.mem_append.mp member with first|later
  · exact lt_of_lt_of_le (prefixCalls_bounds code lib ready d bound e first) stage.loop.nats_le
  · exact (stage.loop.bounds e later).2

/-- Prefix and tail services are disjoint by actual allocation bounds. Both
perform full source-state/name/argument checks, and every returned value has
its lower-rank actual C-body proof. This is a proof service, never a numerical
execution oracle or a trusted success/output contract. -/
theorem prepare_service (code : List Function) (lib : CompleteLibrary code)
    {state : State} {base : Nat} {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CompleteStage code ready d bound) :
    ∃service : Call,
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 10 name args before value after) ∧
      PrefixAnswers service stage.coefficient ∧
      Ln2.Answers (code:=code) (l:=layout base) (c:=stage.coefficient.loop.finish.cursor)
        (d:=d) (coeffs:=stage.coefficient.loop.finish.atanhCoeffs) service stage.atanh := by
  let frontEvents:=prepareEvents lib.prefixLibrary stage.coefficient
  let endEvents:=Ln2.tailEvents code lib.tailLibrary stage.coefficient.loop.finish.context
    (coefficient_finish_room stage.coefficient) stage.atanh
  let first:=CallEvents.service frontEvents
  let last:=CallEvents.nameTimeline endEvents
  let service:=CallEvents.append first last
  have closedFirst : ∀name args before value after,first name args before=some (value,after) →
      SourceCall Header.layout code 10 name args before value after := by
    intro name args before value after h
    exact SourceRanks.monotone (by decide +kernel) (CallEvents.service_closed frontEvents h)
  have closedLast : ∀name args before value after,last name args before=some (value,after) →
      SourceCall Header.layout code 10 name args before value after := by
    intro name args before value after h
    exact CallEvents.nameTimeline_closed endEvents h
  refine ⟨service,fun _ _ _ _ _ h=>CallEvents.append_closed closedFirst closedLast h,?_,?_⟩
  · apply prepareEvents_answers lib.prefixLibrary stage.coefficient service
    intro e member
    exact CallEvents.append_left
      (CallEvents.service_self_keys frontEvents (prepareEvents_key_unique lib.prefixLibrary stage.coefficient) e member)
  · apply Ln2.tailEvents_answers code lib.tailLibrary stage.coefficient.loop.finish.context
      (coefficient_finish_room stage.coefficient) stage.atanh service
    intro e member
    apply CallEvents.append_right
      (CallEvents.service_none_of_size frontEvents e.name e.args e.before ?_)
      (CallEvents.nameTimeline_self endEvents
        (Ln2.tailEvents_unique code lib.tailLibrary stage.coefficient.loop.finish.context
          (coefficient_finish_room stage.coefficient) stage.atanh) e member)
    intro earlier oldMember
    have left:=prepareEvents_before lib.prefixLibrary stage.coefficient earlier oldMember
    have right:=Ln2.tailEvents_lower code lib.tailLibrary stage.coefficient.loop.finish.context
      (coefficient_finish_room stage.coefficient) stage.atanh e member
    omega

end ScopedC.PrepareSource
