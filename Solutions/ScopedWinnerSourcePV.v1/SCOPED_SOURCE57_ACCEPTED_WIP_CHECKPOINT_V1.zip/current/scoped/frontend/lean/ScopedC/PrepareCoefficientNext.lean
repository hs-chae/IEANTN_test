/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientWritten

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

theorem expStore_top {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) :
    (expStoreCursor f room).top=f.cursor.top+16 := by
  unfold expStoreCursor
  change (expDivideCursor f).top=_
  rw[expDivide_nonzero,RationalDivideCalls.nonzero_top]
  rfl

noncomputable def stepWork {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    CoeffWork l object d eb ab := by
  have expRoom : f.cursor.top+15<PoolCalls.capacity := by omega
  let half:=expWork f expRoom active
  have tailRoom : half.cursor.top+18<PoolCalls.capacity := by
    change (expStoreCursor f expRoom).top+18<PoolCalls.capacity
    rw[expStore_top];omega
  have bound : half.atanhCoeffs.length<65 := by
    change f.atanhCoeffs.length<65
    rw[f.atanhLength];have h:=f.depthBound;omega
  exact (half.atanhWritten tailRoom f.kPositive bound).increment

theorem stepWork_k {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (stepWork f active room).k=f.k+1 := by
  unfold stepWork
  change (CoeffWork.atanhWritten _ _ _ _).k+1=f.k+1
  exact congrArg (fun n=>n+1) (CoeffWork.atanhWritten_k _ _ _ _)

theorem stepWork_exp {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (stepWork f active room).expCoeffs=f.expCoeffs++[expNext f] := by
  unfold stepWork
  change (CoeffWork.atanhWritten _ _ _ _).expCoeffs=_
  exact CoeffWork.atanhWritten_exp _ _ _ _

theorem stepWork_exp_length {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (stepWork f active room).expCoeffs.length=(stepWork f active room).k := by
  rw[stepWork_exp,stepWork_k,List.length_append,List.length_singleton,f.expLength]

theorem stepWork_atanh_length {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (stepWork f active room).atanhCoeffs.length=(stepWork f active room).k := by
  rw[stepWork_k]
  unfold stepWork
  change (CoeffWork.atanhWritten _ _ _ _).atanhCoeffs.length=f.k+1
  exact (CoeffWork.atanhWritten_length _ _ _ _).trans (congrArg (fun n=>n+1) f.atanhLength)

theorem stepWork_exp_values {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    TaylorCalls.coefficientValues (stepWork f active room).expCoeffs=
      (List.range (stepWork f active room).k).map expCoefficient := by
  rw[stepWork_exp,stepWork_k]
  exact values_append _ _ _ _ f.expValues (expNext_value f)

theorem stepWork_atanh_values {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    TaylorCalls.coefficientValues (stepWork f active room).atanhCoeffs=
      (List.range (stepWork f active room).k).map atanhCoefficient := by
  rw[stepWork_k]
  unfold stepWork
  change TaylorCalls.coefficientValues (CoeffWork.atanhWritten _ _ _ _).atanhCoeffs=_
  exact CoeffWork.atanhWritten_values _ _ _ _ f.atanhValues

noncomputable def coefficientStep {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    CoeffFrame l object d eb ab :=
  frameFromWork (stepWork f active room) (stepWork_exp_length f active room)
    (stepWork_atanh_length f active room) (stepWork_exp_values f active room)
    (stepWork_atanh_values f active room)
    (by rw[stepWork_k];have h:=f.kPositive;omega) (by rw[stepWork_k];omega) f.depthBound

theorem coefficientStep_k {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (coefficientStep f active room).k=f.k+1 := stepWork_k f active room

end ScopedC.PrepareSource
