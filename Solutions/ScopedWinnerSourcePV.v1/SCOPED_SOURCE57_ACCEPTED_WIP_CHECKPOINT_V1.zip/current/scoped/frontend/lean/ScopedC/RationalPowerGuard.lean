/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerCounter
import ScopedC.UnsignedLiteralControl

namespace ScopedC.RationalPowerGuard
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem greater_zero (s : State) (n : Nat) (hn : n<2^32) :
    binaryValue Header.layout s ">" (word n) (DecimalDigits.integer 0)=
      some (boolean Header.layout (decide (0<n))) := by
  change binaryValue Header.layout s ">" (NatWrapperCalls.unsigned32 n) (DecimalDigits.integer 0)=_
  rw[UnsignedLiteralControl.literal_lift s ">" n 0 hn (by decide +kernel)]
  exact binary_gt s n 0 hn (by decide +kernel)

theorem eval_condition (service : Call) (fuel : Nat) {s : State} {slot n : Nat}
    (atN : LocalBinding.At s "n" "unsigned int" (word n) slot) (hn : n<2^32) :
    evalExpr Header.layout service (fuel+3) s (.binary ">" (.var "n") (.nat 0))=
      some (boolean Header.layout (decide (0<n)),s) :=
  ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service (fuel+1) atN (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (by rfl) (greater_zero s n hn)

theorem eval_half (service : Call) (fuel : Nat) {s : State} {slot n : Nat}
    (atN : LocalBinding.At s "n" "unsigned int" (word n) slot) (hn : n<2^32) :
    evalExpr Header.layout service (fuel+3) s (.binary "/" (.var "n") (.nat 2))=some (word (n/2),s) :=
  ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service (fuel+1) atN (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (by rfl) (RationalPowerCounter.divide s n hn)

/-- Exact source n=n/2 assignment, preserving the actual unsigned type. -/
theorem halve_assignment (service : Call) (fuel : Nat) {s : State} {slot n : Nat}
    (atN : LocalBinding.At s "n" "unsigned int" (word n) slot) (hn : n<2^32) :
    evalExpr Header.layout service (fuel+4) s (.binary "=" (.var "n") (.binary "/" (.var "n") (.nat 2)))=
      some (word (n/2),LocalAssignment.changed s slot "unsigned int" (word (n/2))) :=
  LocalAssignment.evaluate service (fuel+2) (eval_half service fuel atN hn) atN
    (RationalUnsignedCalls.cast_parameter s (n/2) (RationalPowerCounter.halve_range n hn))

end ScopedC.RationalPowerGuard
