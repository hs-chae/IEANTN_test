/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericNegationRefinement
import ScopedC.RationalPairFrames
import ScopedC.CursorBorrow
import ScopedC.CursorEffects

namespace ScopedC.RationalAbsApplicability
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def after (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := next l c 0

def output (a : Input) : Input :=
  ⟨⟨a.numerator.slot,a.numerator.magnitude,false⟩,a.denSlot,a.denominator⟩

theorem live {l : PoolCalls.PoolLayout} {c : Cursor} {a : Input} (alive : a.Live c.state) :
    (output a).Live (after l c).state := ⟨PoolCursor.preserves alive.1,PoolCursor.preserves alive.2⟩

theorem value (a : Input) : (output a).mathematical.value=|a.mathematical.value| :=
  NumericNegationRefinement.rational_absolute a.numerator.magnitude a.denominator a.numerator.negative

structure Library (code : List Function) : Prop where
  qabs : Generated.f_qabs∈code
  smake : Generated.f_smake∈code
  nz : Generated.f_nz∈code
  nu : Generated.f_nu∈code
  ne : Generated.f_ne∈code
  keep : Generated.f_keep∈code

theorem source (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout}
    {c : Cursor} (ctx : Valid l c) (a : Input) (alive : a.Live c.state)
    (room : c.top<PoolCalls.capacity) :
    SourceCall Header.layout code 5 "qabs" [a.source] c.state (output a).source (after l c).state :=
  RationalAbsCalls.qabs_closed code lib.qabs lib.smake lib.nz lib.nu lib.ne lib.keep
    a.numerator.negative ctx room alive.1 alive.2

end ScopedC.RationalAbsApplicability
