/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerReady
import ScopedC.IntervalPowerScanFramedLoop

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure FramedReady (code : List Function) {l : PoolCalls.PoolLayout} {n : Nat} (start : IntervalPowerScan.Frame l n)
    extends Ready code start where
  borrows : ∀slot value,NatArena.Borrow start.cursor.state.nats slot value → NatArena.Borrow finish.cursor.state.nats slot value
  globals : finish.cursor.state.globals=start.cursor.state.globals
  shape : finish.cursor.state.heap.length=start.cursor.state.heap.length ∧ finish.cursor.state.env=start.cursor.state.env
  slots : finish.bitSlot=start.bitSlot ∧ finish.rSlot=start.rSlot
  other : ∀slot,slot < start.cursor.state.heap.length → slot≠start.bitSlot → slot≠start.rSlot →
    slot≠l.pool → slot≠l.top → slot≠l.high → finish.cursor.state.heap[slot]?=start.cursor.state.heap[slot]?

theorem scan_ready_framed (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : IntervalPowerBits.Frame l n) (highest : n<f.bit*2)
    (a : Pair) (aSlot : Nat) (atA : LocalBinding.At f.cursor.state "a" "RI" a.source aSlot)
    (alive : a.Live f.cursor.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (room : f.cursor.top+5120 ≤ PoolCalls.capacity) :
    Nonempty (FramedReady code (scanStart f a aSlot atA alive positive order)) := by
  let start:=scanStart f a aSlot atA alive positive order
  have bitEq : start.bit=f.bit/2 := rfl
  have initialValue : IntervalPowerScan.mathematical start=IntervalPowerScan.original start := rfl
  have prefixOne : n/f.bit=1:=IntervalPowerMathematics.highest_prefix n f.bit f.lower highest
  have pBound : f.power<32 := by
    have h : 2^f.power<2^32 := f.powerEq ▸ lt_of_le_of_lt f.lower f.exponentBound
    exact (Nat.pow_lt_pow_iff_right (by decide : 1<2)).1 h
  cases hp : f.power with
  | zero =>
    have one : f.bit=1:=by rw[f.powerEq,hp];rfl
    have exponent : n=1 := by have h:=f.lower;omega
    have stopped : start.bit=0:=by rw[bitEq,one]
    refine ⟨{
      finish:=start
      events:=[]
      unique:=by simp
      execution:=?_
      mathematical_eq:=?_
      top_le:=by
        change start.cursor.top ≤ start.cursor.top+5120
        omega
      borrows:=fun _ _ live=>live
      globals:=rfl
      shape:=⟨rfl,rfl⟩
      slots:=⟨rfl,rfl⟩
      other:=by intros;rfl
    }⟩
    · intro service _
      exact Loops.WhileRun.done (IntervalPowerScan.condition_eval service start)
        (by simp [UnsignedLiteralControl.truth_boolean,stopped])
    · have powerEq : LeanCert.Core.IntervalRat.pow (IntervalPowerScan.original start) n=IntervalPowerScan.original start :=
        (congrArg (LeanCert.Core.IntervalRat.pow (IntervalPowerScan.original start)) exponent).trans (by rw[LeanCert.Core.IntervalRat.pow])
      exact initialValue.trans powerEq.symm
  | succ k =>
    have startPower : start.bit=2^k := by rw[bitEq,f.powerEq,hp,IntervalPowerMathematics.power_two_half]
    have doubleEq : start.bit*2=f.bit := by rw[startPower,f.powerEq,hp,pow_succ]
    have lower : 2*start.bit ≤ n := by rw[Nat.mul_comm,doubleEq];exact f.lower
    have prefixValue : IntervalPowerScan.mathematical start=
        LeanCert.Core.IntervalRat.pow (IntervalPowerScan.original start) (n/(start.bit*2)) := by
      rw[doubleEq,prefixOne,LeanCert.Core.IntervalRat.pow]
      exact initialValue
    have startRoom : start.cursor.top+160*(k+1) ≤ PoolCalls.capacity := by
      have kBound : k+1<32 := by simpa only[hp] using pBound
      change f.cursor.top+160*(k+1) ≤ PoolCalls.capacity
      omega
    obtain ⟨trace⟩:=IntervalPowerScan.loop_framed_certificate code installed lib k start startPower lower prefixValue startRoom
    exact ⟨{
      finish:=trace.finish
      events:=trace.events
      unique:=trace.unique
      execution:=trace.execution
      mathematical_eq:=trace.mathematical_eq
      top_le:=by
        have h:=trace.top_le
        have kBound : k+1<32:=by simpa only[hp] using pBound
        change trace.finish.cursor.top ≤ start.cursor.top+5120
        omega
      borrows:=trace.borrows
      globals:=trace.globals
      shape:=trace.shape
      slots:=trace.slots
      other:=trace.other
    }⟩

end ScopedC.IntervalPowerCalls
