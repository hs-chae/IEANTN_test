/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerAccumulate

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def squareProduct {l : PoolCalls.PoolLayout} (f : Frame l) : Input :=
  RationalProductApplicability.output l f.cursor f.current f.current

@[irreducible] def squareNext {l : PoolCalls.PoolLayout} (f : Frame l) : Cursor :=
  RationalMultiplyCalls.c11 l f.cursor f.current f.current

theorem squareNext_context {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    Valid l (squareNext f) := by
  unfold squareNext
  exact product_context f.context room f.current f.current

theorem squareNext_aLive {l : PoolCalls.PoolLayout} (f : Frame l) : (squareProduct f).Live (squareNext f).state := by
  unfold squareNext squareProduct
  exact RationalProductApplicability.live l f.cursor f.current f.current

theorem squareNext_rLive {l : PoolCalls.PoolLayout} (f : Frame l) : f.accumulator.Live (squareNext f).state := by
  unfold squareNext
  exact RationalProductApplicability.preserves_input (l:=l) (c:=f.cursor) (a:=f.current) (b:=f.current) f.rLive

theorem squareNext_binding {l : PoolCalls.PoolLayout} (f : Frame l)
    {name ty : String} {value : Value} {slot : Nat}
    (h : LocalBinding.At f.cursor.state name ty value slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    LocalBinding.At (squareNext f).state name ty value slot := by
  unfold squareNext
  exact RationalProductApplicability.preserves_binding (l:=l) (c:=f.cursor) f.current f.current h hp ht hh

def square {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) : Frame l := by
  have aSafe:=LocalStorageSeparation.pool (l:=l) (c:=f.cursor) f.context f.aAt (by decide +kernel : ("Q":String)≠"unsigned")
  have nSafe:=LocalStorageSeparation.pool (l:=l) (c:=f.cursor) f.context f.nAt (by decide +kernel : ("unsigned int":String)≠"unsigned")
  have rSafe:=LocalStorageSeparation.pool (l:=l) (c:=f.cursor) f.context f.rAt (by decide +kernel : ("Q":String)≠"unsigned")
  have atA:=squareNext_binding f f.aAt aSafe.1 aSafe.2.1 aSafe.2.2
  have atN:=squareNext_binding f f.nAt nSafe.1 nSafe.2.1 nSafe.2.2
  have atR:=squareNext_binding f f.rAt rSafe.1 rSafe.2.1 rSafe.2.2
  exact {
    cursor:=LocalAssignment.cursor (squareNext f) f.aSlot "Q" (squareProduct f).source
    current:=squareProduct f
    accumulator:=f.accumulator
    exponent:=f.exponent
    aSlot:=f.aSlot
    nSlot:=f.nSlot
    rSlot:=f.rSlot
    context:=LocalAssignment.valid (l:=l) (c:=squareNext f) (squareNext_context f room)
      f.aSlot "Q" (squareProduct f).source aSafe.1 aSafe.2.1 aSafe.2.2
    aAt:=LocalAssignment.binding (value:=(squareProduct f).source) atA (RationalProductApplicability.initialized (squareProduct f))
    nAt:=LocalAssignment.other_binding (changedType:="Q") (value:=(squareProduct f).source) atN
      (LocalStorageSeparation.typed f.nAt f.aAt (by decide +kernel))
    rAt:=LocalAssignment.other_binding (changedType:="Q") (value:=(squareProduct f).source) atR (Ne.symm f.arDistinct)
    aLive:=by change (squareProduct f).Live (squareNext f).state;exact squareNext_aLive f
    rLive:=by change f.accumulator.Live (squareNext f).state;exact squareNext_rLive f
    aPositive:=RationalProductApplicability.positive l f.cursor f.current f.current f.aPositive f.aPositive
    rPositive:=f.rPositive
    exponentBound:=f.exponentBound
    arDistinct:=f.arDistinct }

theorem square_call (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout}
    (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qt" [f.current.source,f.current.source] f.cursor.state
      (squareProduct f).source (RationalMultiplyCalls.c11 l f.cursor f.current f.current).state :=
  RationalMultiplyCalls.qt_closed code lib.qt lib.productLibrary f.context room
    f.current f.current f.aLive f.aLive f.aPositive f.aPositive

theorem square_source (service : Call) {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+10<PoolCalls.capacity)
    (answer : service "qt" [f.current.source,f.current.source] f.cursor.state=
      some ((squareProduct f).source,(RationalMultiplyCalls.c11 l f.cursor f.current f.current).state)) :
    Eval Header.layout service (.binary "=" (.var "a") (.call (.var "qt") [.var "a",.var "a"]))
      f.cursor.state (square f room).cursor.state (squareProduct f).source := by
  have rhs:=ExpressionTemplates.call_two Header.layout service
    (LocalBinding.eval service 1 f.aAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (LocalBinding.eval service 1 f.aAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) answer
  have safe:=LocalStorageSeparation.pool (l:=l) (c:=f.cursor) f.context f.aAt (by decide +kernel : ("Q":String)≠"unsigned")
  have middle:=RationalProductApplicability.preserves_binding (l:=l) (c:=f.cursor) f.current f.current f.aAt safe.1 safe.2.1 safe.2.2
  refine ⟨4,?_⟩
  change evalExpr Header.layout service 4 f.cursor.state _=
    some ((squareProduct f).source,LocalAssignment.changed (squareNext f).state f.aSlot "Q" (squareProduct f).source)
  rw[squareNext]
  exact LocalAssignment.evaluate service 2 rhs middle
    (Input.cast "Q" (by decide +kernel) (RationalProductApplicability.live l f.cursor f.current f.current))

theorem square_value {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (square f room).current.mathematical.value=f.current.mathematical.value*f.current.mathematical.value :=
  RationalProductApplicability.mathematical l f.cursor f.current f.current f.aPositive f.aPositive

theorem square_top {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (square f room).cursor.top=f.cursor.top+11 := by
  change (squareNext f).top=f.cursor.top+11
  rw[squareNext]
  exact RationalMultiplyCalls.top11 l f.cursor f.current f.current

end ScopedC.RationalPowerCalls
