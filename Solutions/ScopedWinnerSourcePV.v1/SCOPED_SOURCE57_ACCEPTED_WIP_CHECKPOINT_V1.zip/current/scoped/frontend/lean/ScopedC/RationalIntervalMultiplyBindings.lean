/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplyData

namespace ScopedC.RationalIntervalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalProductApplicability
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem saved_binding {l : PoolCalls.PoolLayout} {c : Cursor} {old ty : String} {v : Value} {slot : Nat}
    (a b : Input) (name : String) (h : LocalBinding.At c.state old ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) (distinct : name≠old) :
    LocalBinding.At (saved l c a b name).state old ty v slot :=
  LocalBinding.allocate_other (preserves_binding a b h hp ht hh) name "Q" _ distinct

theorem stack_safe {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {slot : Nat} (bound : c.state.heap.length ≤ slot) : slot≠l.pool ∧ slot≠l.top ∧ slot≠l.high := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact ⟨by omega,by omega,by omega⟩

theorem binding1 {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair} {old ty : String} {v : Value} {slot : Nat}
    (h : LocalBinding.At (base c a b).state old ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) (different : "p"≠old) :
    LocalBinding.At (c1 l c a b).state old ty v slot := by
  unfold c1;exact saved_binding a.lo b.lo "p" h hp ht hh different
theorem binding2 {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair} {old ty : String} {v : Value} {slot : Nat}
    (h : LocalBinding.At (c1 l c a b).state old ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) (different : "q"≠old) :
    LocalBinding.At (c2 l c a b).state old ty v slot := by
  unfold c2;exact saved_binding a.lo b.hi "q" h hp ht hh different
theorem binding3 {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair} {old ty : String} {v : Value} {slot : Nat}
    (h : LocalBinding.At (c2 l c a b).state old ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) (different : "r"≠old) :
    LocalBinding.At (c3 l c a b).state old ty v slot := by
  unfold c3;exact saved_binding a.hi b.lo "r" h hp ht hh different
theorem binding4 {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Pair} {old ty : String} {v : Value} {slot : Nat}
    (h : LocalBinding.At (c3 l c a b).state old ty v slot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) (different : "s"≠old) :
    LocalBinding.At (c4 l c a b).state old ty v slot := by
  unfold c4;exact saved_binding a.hi b.hi "s" h hp ht hh different

theorem input_a {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Pair) :
    LocalBinding.At (c1 l c a b).state "a" "RI" a.source c.state.heap.length ∧
    LocalBinding.At (c2 l c a b).state "a" "RI" a.source c.state.heap.length ∧
    LocalBinding.At (c3 l c a b).state "a" "RI" a.source c.state.heap.length := by
  have sep:=stack_safe ctx (slot:=c.state.heap.length) (by omega)
  have h1:=binding1 (l:=l) (a:=a) (b:=b) (RationalIntervalFrames.a_at c.state a b) sep.1 sep.2.1 sep.2.2 (by decide +kernel)
  have h2:=binding2 (a:=a) (b:=b) h1 sep.1 sep.2.1 sep.2.2 (by decide +kernel)
  have h3:=binding3 (a:=a) (b:=b) h2 sep.1 sep.2.1 sep.2.2 (by decide +kernel)
  exact ⟨h1,h2,h3⟩
theorem input_b {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Pair) :
    LocalBinding.At (c1 l c a b).state "b" "RI" b.source (c.state.heap.length+1) ∧
    LocalBinding.At (c2 l c a b).state "b" "RI" b.source (c.state.heap.length+1) ∧
    LocalBinding.At (c3 l c a b).state "b" "RI" b.source (c.state.heap.length+1) := by
  have sep:=stack_safe ctx (slot:=c.state.heap.length+1) (by omega)
  have h1:=binding1 (l:=l) (a:=a) (b:=b) (RationalIntervalFrames.b_at c.state a b) sep.1 sep.2.1 sep.2.2 (by decide +kernel)
  have h2:=binding2 (a:=a) (b:=b) h1 sep.1 sep.2.1 sep.2.2 (by decide +kernel)
  have h3:=binding3 (a:=a) (b:=b) h2 sep.1 sep.2.1 sep.2.2 (by decide +kernel)
  exact ⟨h1,h2,h3⟩

theorem size1 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (c1 l c a b).state.nats.values.length=c.state.nats.values.length+11 := by
  unfold c1;exact saved_size l (base c a b) a.lo b.lo "p"
theorem size2 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (c2 l c a b).state.nats.values.length=c.state.nats.values.length+22 := by
  unfold c2;rw[saved_size,size1]
theorem size3 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (c3 l c a b).state.nats.values.length=c.state.nats.values.length+33 := by
  unfold c3;rw[saved_size,size2]
theorem size4 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (c4 l c a b).state.nats.values.length=c.state.nats.values.length+44 := by
  unfold c4;rw[saved_size,size3]

theorem heap0 (c : Cursor) (a b : Pair) :
    (base c a b).state.heap.length=c.state.heap.length+2 := by
  simp [base,RationalIntervalFrames.framed,CursorFrames.framed,TwoFrames.frame,allocate]

theorem heap1 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (c1 l c a b).state.heap.length=c.state.heap.length+3 := by
  unfold c1;rw[(saved_shape l (base c a b) a.lo b.lo "p").1,heap0]
theorem heap2 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (c2 l c a b).state.heap.length=c.state.heap.length+4 := by
  unfold c2;rw[(saved_shape l (c1 l c a b) a.lo b.hi "q").1,heap1]
theorem heap3 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (c3 l c a b).state.heap.length=c.state.heap.length+5 := by
  unfold c3;rw[(saved_shape l (c2 l c a b) a.hi b.lo "r").1,heap2]
theorem heap4 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (c4 l c a b).state.heap.length=c.state.heap.length+6 := by
  unfold c4;rw[(saved_shape l (c3 l c a b) a.hi b.hi "s").1,heap3]

theorem products_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Pair) :
    LocalBinding.At (c4 l c a b).state "p" "Q" (p l c a b).source (c.state.heap.length+2) ∧
    LocalBinding.At (c4 l c a b).state "q" "Q" (q l c a b).source (c.state.heap.length+3) ∧
    LocalBinding.At (c4 l c a b).state "r" "Q" (r l c a b).source (c.state.heap.length+4) ∧
    LocalBinding.At (c4 l c a b).state "s" "Q" (s l c a b).source (c.state.heap.length+5) := by
  have ps:=stack_safe ctx (slot:=c.state.heap.length+2) (by omega)
  have qs:=stack_safe ctx (slot:=c.state.heap.length+3) (by omega)
  have rs:=stack_safe ctx (slot:=c.state.heap.length+4) (by omega)
  have p1 : LocalBinding.At (c1 l c a b).state "p" "Q" (p l c a b).source (c.state.heap.length+2) := by
    unfold c1;simpa only[heap0,p] using saved_at l (base c a b) a.lo b.lo "p"
  have q2 : LocalBinding.At (c2 l c a b).state "q" "Q" (q l c a b).source (c.state.heap.length+3) := by
    unfold c2;simpa only[heap1,q] using saved_at l (c1 l c a b) a.lo b.hi "q"
  have r3 : LocalBinding.At (c3 l c a b).state "r" "Q" (r l c a b).source (c.state.heap.length+4) := by
    unfold c3;simpa only[heap2,r] using saved_at l (c2 l c a b) a.hi b.lo "r"
  have s4 : LocalBinding.At (c4 l c a b).state "s" "Q" (s l c a b).source (c.state.heap.length+5) := by
    unfold c4;simpa only[heap3,s] using saved_at l (c3 l c a b) a.hi b.hi "s"
  have p2:=binding2 (a:=a) (b:=b) p1 ps.1 ps.2.1 ps.2.2 (by decide +kernel)
  have p3:=binding3 (a:=a) (b:=b) p2 ps.1 ps.2.1 ps.2.2 (by decide +kernel)
  have p4:=binding4 (a:=a) (b:=b) p3 ps.1 ps.2.1 ps.2.2 (by decide +kernel)
  have q3:=binding3 (a:=a) (b:=b) q2 qs.1 qs.2.1 qs.2.2 (by decide +kernel)
  have q4:=binding4 (a:=a) (b:=b) q3 qs.1 qs.2.1 qs.2.2 (by decide +kernel)
  have r4:=binding4 (a:=a) (b:=b) r3 rs.1 rs.2.1 rs.2.2 (by decide +kernel)
  exact ⟨p4,q4,r4,s4⟩

end ScopedC.RationalIntervalMultiplyCalls
