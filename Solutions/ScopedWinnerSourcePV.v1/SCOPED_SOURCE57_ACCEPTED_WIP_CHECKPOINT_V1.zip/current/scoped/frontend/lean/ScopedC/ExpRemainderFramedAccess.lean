/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderFramedBody
import ScopedC.SourceScalarGlobal
import ScopedC.NumericIntervalValues

namespace ScopedC.ExpRemainderCalls.FramedResult
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

theorem scalar {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    {d : Nat} {ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value}
    (out : FramedResult code l c a d ordered) (ctx : Valid l c)
    {name type : String} {object : Nat} {value : Option Value}
    (h : SourceScalarGlobal.At c.state name type object value) (different : type≠"unsigned") :
    SourceScalarGlobal.At out.out.state name type object value := by
  have safe:=SourceScalarGlobal.separated ctx h different
  exact SourceScalarGlobal.memory h out.globals
    (out.other object (List.getElem?_eq_some_iff.mp h.storage).choose safe.1 safe.2.1 safe.2.2)

def table {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    {d : Nat} {ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value}
    (out : FramedResult code l c a d ordered) (ctx : Valid l c)
    {base : Address} {values : List RationalPairFrames.Input}
    (h : CoefficientTableRead.TableAt c.state base values) :
    CoefficientTableRead.TableAt out.out.state base values := by
  have safe:=CoefficientTableRead.pool_separated ctx h
  exact CoefficientTableRead.memory h
    (out.other base.object (List.getElem?_eq_some_iff.mp h.memory).choose safe.1 safe.2.1 safe.2.2) out.preserves

theorem pair {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    {d : Nat} {ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value}
    (out : FramedResult code l c a d ordered) {p : Pair} (h : p.Live c.state) : p.Live out.out.state :=
  ⟨⟨out.preserves _ _ h.1.1,out.preserves _ _ h.1.2⟩,
    ⟨out.preserves _ _ h.2.1,out.preserves _ _ h.2.2⟩⟩

theorem scale {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    {d : Nat} {ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value}
    (out : FramedResult code l c a d ordered) (ctx : Valid l c)
    {object slot value : Nat} (h : SourceFromS.ScaleAt c.state object slot value) :
    SourceFromS.ScaleAt out.out.state object slot value := by
  have stored:=out.scalar ctx
    (show SourceScalarGlobal.At c.state "scale100" "N" object (some (.natObject slot))
      from ⟨h.lookup,h.storage⟩) (by decide +kernel)
  exact ⟨stored.lookup,stored.storage,out.preserves _ _ h.live⟩

theorem depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    {d : Nat} {ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value}
    (out : FramedResult code l c a d ordered) {name : String} {object n : Nat}
    (h : SourceUnsignedGlobal.At c.state name object n)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At out.out.state name object n :=
  SourceUnsignedGlobal.memory h out.globals
    (out.other object (List.getElem?_eq_some_iff.mp h.storage).choose apart.1 apart.2.1 apart.2.2)

theorem ordered {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    {d : Nat} {inputOrder : a.lo.mathematical.value ≤ a.hi.mathematical.value}
    (out : FramedResult code l c a d inputOrder) :
    out.output.lo.mathematical.value ≤ out.output.hi.mathematical.value := by
  have values:=Pair.values_of_decoded out.live out.positive out.decoded
  rw[values.1,values.2]
  exact (LeanCert.Core.IntervalRat.expRemainderBoundComputable
    ⟨a.lo.mathematical.value,a.hi.mathematical.value,inputOrder⟩ d).le

end ScopedC.ExpRemainderCalls.FramedResult
