/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientGlobals
import ScopedC.PrepareLn2StoreFrames
import ScopedC.PrepareLn2Events

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

structure CompleteLibrary (code : List Function) : Prop where
  prefixLibrary : Library code
  tailLibrary : Ln2.TailLibrary code
  atanhInstalled : Generated.f_atanhPoint∈code
  atanhLibrary : AtanhCalls.Library code

structure CompleteStage (code : List Function) {state : State} {base : Nat}
    (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) where
  coefficient : CoefficientStage code ready d bound
  scale : SourceFromS.ScaleAt coefficient.loop.finish.cursor.state (base+4)
    (ScalePrelude.slot (layout base) (depthCursor ready d)) (2^100)
  rawLn2 : SourceScalarGlobal.At coefficient.loop.finish.cursor.state "preparedLn2" "RI" (base+7)
    (some ScopedIO.ApplicationInit.zeroInterval)
  globals : coefficient.loop.finish.cursor.state.globals=state.globals
  atanh : Ln2.AtanhStage code (layout base) coefficient.loop.finish.cursor d coefficient.loop.finish.atanhCoeffs

theorem coefficient_finish_room {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64}
    (stage : CoefficientStage code ready d bound) :
    stage.loop.finish.cursor.top+9101<PoolCalls.capacity := by
  have top:=stage.loop.top
  rw[coefficientStart_top,coefficientStart_k] at top
  simp only[Nat.add_sub_cancel] at top
  change stage.loop.finish.cursor.top+9101<4000000
  omega

/-- Every original prepare numerical stage is constructed from actual
initialization and source execution; no prepared value or successful output
is an input contract. Full body/service/scope assembly is a separate root. -/
theorem complete_stage (code : List Function) (lib : CompleteLibrary code)
    {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    Nonempty (CompleteStage code ready d bound) := by
  obtain ⟨coefficient,scale,raw,globals⟩:=framed_coefficient_stage_globals code lib.prefixLibrary.coefficients ready d bound
  obtain ⟨atanh⟩:=Ln2.atanh_stage code lib.atanhInstalled lib.atanhLibrary coefficient.loop.finish
    coefficient.loop.stopped (by have room:=coefficient_finish_room coefficient;omega)
  exact ⟨⟨coefficient,scale,raw,globals,atanh⟩⟩

theorem complete_stage_ln2 {code : List Function} {state : State} {base : Nat}
    {ready : StaticAt state base} {d : Nat} {bound : d ≤ 64} (stage : CompleteStage code ready d bound) :
    NumericRepresentation.interval (Ln2.afterStore stage.atanh (base+7)).state (Ln2.product stage.atanh).source=
      some (LeanCert.Core.IntervalRat.ln2Computable d) :=
  Ln2.stored_model stage.atanh (base+7) (coefficient_stage_old_math stage.coefficient).2

end ScopedC.PrepareSource
