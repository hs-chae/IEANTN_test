/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhGuard
import ScopedC.RationalCompareEffects

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def guardValues (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : List Nat :=
  [1,0,1]++RationalCompareCalls.values (absInput q) (oneInput l c q)

theorem guard_trace (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    afterGuard l c q=CursorFrames.advance l (afterR l c q) (guardValues l c q) := rfl

theorem guard_top (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterGuard l c q).top=c.top+10 := by
  rw[guard_trace,CursorFrames.top_advance]
  rfl

theorem r_guard_binding {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (room : c.top+9<PoolCalls.capacity) :
    LocalBinding.At (afterGuard l c q).state "r" "Q" (absInput q).source
      (c.state.heap.length+1) := by
  have binding:=r_binding l c q
  have safe:=LocalStorageSeparation.pool (afterR_context ctx q (by omega)) binding
    (by decide +kernel : ("Q":String)≠"unsigned")
  rw[guard_trace]
  exact LocalBinding.advance binding (guardValues l c q) safe.1 safe.2.1 safe.2.2

theorem r_guard_live {l : PoolCalls.PoolLayout} {c : Cursor} (q : Input)
    (live : q.Live c.state) : (absInput q).Live (afterGuard l c q).state := by
  have before : (absInput q).Live (afterR l c q).state:=RationalAbsApplicability.live live
  rw[guard_trace]
  exact ⟨CursorBorrow.preserves (guardValues l c q) before.1,
    CursorBorrow.preserves (guardValues l c q) before.2⟩

def afterR_table {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) {base : Address} {coeffs : List Input}
    (table : CoefficientTableRead.TableAt c.state base coeffs) :
    CoefficientTableRead.TableAt (afterR l c q).state base coeffs := by
  have first : CoefficientTableRead.TableAt (parameters c q).state base coeffs :=
    CoefficientTableRead.allocated (CoefficientTableRead.memory (t:={c.state with env:=[]})
      table rfl (fun _ _ h=>h)) "Q" "q" (some q.source)
  exact CoefficientTableRead.allocated
    (CoefficientTableRead.advanced (parameters_context ctx q) first [0]) "Q" "r" _

def guard_table {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (room : c.top+9<PoolCalls.capacity) {base : Address} {coeffs : List Input}
    (table : CoefficientTableRead.TableAt c.state base coeffs) :
    CoefficientTableRead.TableAt (afterGuard l c q).state base coeffs := by
  rw[guard_trace]
  exact CoefficientTableRead.advanced (afterR_context ctx q (by omega))
    (afterR_table ctx q table) (guardValues l c q)

theorem guard_depth {l : PoolCalls.PoolLayout} {c : Cursor} (q : Input)
    {object d : Nat} (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At (afterGuard l c q).state "depth" object d := by
  have first : SourceUnsignedGlobal.At (parameters c q).state "depth" object d :=
    SourceUnsignedGlobal.allocated
      (SourceUnsignedGlobal.memory (t:={c.state with env:=[]}) depth rfl rfl) "Q" "q" _
  have second : SourceUnsignedGlobal.At (afterR l c q).state "depth" object d :=
    SourceUnsignedGlobal.allocated (SourceUnsignedGlobal.advanced first [0]
      apart.1 apart.2.1 apart.2.2) "Q" "r" _
  rw[guard_trace]
  exact SourceUnsignedGlobal.advanced second (guardValues l c q) apart.1 apart.2.1 apart.2.2

theorem guard_depth_unshadowed (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (afterGuard l c q).state.env.lookup "depth"=none := by
  rw[guard_trace,(CursorEffects.shape l (afterR l c q) (guardValues l c q)).2]
  change (("r",_)::(afterAbs l c q).state.env).lookup "depth"=none
  change (("r",_)::(next l (parameters c q) 0).state.env).lookup "depth"=none
  rw[(PoolCursor.shape l (parameters c q) 0).2]
  rfl

end ScopedC.AtanhCalls
