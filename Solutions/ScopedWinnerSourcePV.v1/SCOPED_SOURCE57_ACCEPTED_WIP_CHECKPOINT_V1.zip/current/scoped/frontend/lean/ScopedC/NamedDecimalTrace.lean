/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedDecimalPair
namespace ScopedC.NamedDecimalTrace
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DecimalText (digits)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem allocation_length (acc : Nat) (text : List Nat) :
    (DecimalExpressions.allocationSteps acc text).length=4*text.length := by
  induction text generalizing acc with
  | nil => rfl
  | cons digit rest ih =>
    rw [DecimalExpressions.allocationSteps,List.length_append,ih]
    simp only [List.length_cons,List.length_nil]
    omega

theorem numerator_count {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : RationalDecimalLiteral.Stages code l c n d) :
    D.numerator.state.nats.values.length=c.state.nats.values.length+1+4*(digits n).length := by
  rw [D.numeratorTrace,CursorEffects.size]
  change c.state.nats.values.length+(0::DecimalExpressions.allocationSteps 0 (digits n)).length=_
  rw [List.length_cons,allocation_length]
  omega

theorem denominator_count {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : RationalDecimalLiteral.Stages code l c n d) :
    D.denominator.state.nats.values.length=
      c.state.nats.values.length+3+4*(digits n).length+4*(digits d).length := by
  rw [D.denominatorTrace,CursorEffects.size]
  change (next l D.numerator 0).state.nats.values.length+
    (0::DecimalExpressions.allocationSteps 0 (digits d)).length=_
  rw [PoolCursor.size,numerator_count,List.length_cons,allocation_length]
  omega

theorem output_count {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : RationalDecimalLiteral.Stages code l c n d) :
    (RationalDecimalLiteral.after D).state.nats.values.length=
      c.state.nats.values.length+8+4*(digits n).length+4*(digits d).length := by
  rw [RationalDecimalLiteral.after_advance,CursorEffects.size,denominator_count]
  simp only [SourceFromSTrace.steps,List.length_cons,List.length_nil]
  omega

#print axioms allocation_length
#print axioms numerator_count
#print axioms denominator_count
#print axioms output_count
end ScopedC.NamedDecimalTrace
