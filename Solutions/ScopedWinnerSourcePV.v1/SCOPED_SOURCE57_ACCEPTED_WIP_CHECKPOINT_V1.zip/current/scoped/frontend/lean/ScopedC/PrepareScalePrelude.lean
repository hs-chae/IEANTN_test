/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceNatGlobal
import ScopedC.SourceFromS
import ScopedC.NatWrapperCalls
import ScopedC.NatUnsignedCall

namespace ScopedC.PrepareSource.ScalePrelude
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  nu : Generated.f_nu∈code
  nl : Generated.f_nl∈code
  keep : Generated.f_keep∈code

def afterOne (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := next l c 1
def afterHundred (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor := next l (afterOne l c) 100
def shifted (l : PoolCalls.PoolLayout) (c : Cursor) : Cursor :=
  next l (afterHundred l c) (1<<<100)
def slot (l : PoolCalls.PoolLayout) (c : Cursor) : Nat := (afterHundred l c).state.nats.values.length

def result (l : PoolCalls.PoolLayout) (c : Cursor) (object : Nat) : Cursor :=
  LocalAssignment.cursor (shifted l c) object "N" (.natObject (slot l c))

theorem shift_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) : Valid l (shifted l c) :=
  CursorFrames.advance_valid ctx [1,100,1<<<100] (by change c.top+3 ≤ PoolCalls.capacity;omega)

theorem shift_live (l : PoolCalls.PoolLayout) (c : Cursor) :
    NatArena.Borrow (shifted l c).state.nats (slot l c) (1<<<100) :=
  PoolCursor.next_borrow l (afterHundred l c) (1<<<100)

theorem one_source (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+2<PoolCalls.capacity) :
    SourceCall Header.layout code 2 "nu" [DecimalDigits.integer 1] c.state
      (.natObject c.state.nats.values.length) (afterOne l c).state :=
  NatWrapperCalls.nu_call code lib.nu lib.keep ctx (by omega) (by decide +kernel) (by rfl)

theorem hundred_source (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+2<PoolCalls.capacity) :
    SourceCall Header.layout code 2 "nu" [DecimalDigits.integer 100] (afterOne l c).state
      (.natObject (afterOne l c).state.nats.values.length) (afterHundred l c).state :=
  NatWrapperCalls.nu_call code lib.nu lib.keep (next_valid 1 ctx (by omega))
    (by change c.top+1<PoolCalls.capacity;omega) (by decide +kernel) (by rfl)

theorem shift_source (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+2<PoolCalls.capacity) :
    SourceCall Header.layout code 2 "nl"
      [.natObject c.state.nats.values.length,.natObject (afterOne l c).state.nats.values.length]
      (afterHundred l c).state (.natObject (slot l c)) (shifted l c).state :=
  NatWrapperCalls.nl_call code lib.nl lib.keep
    (next_valid 100 (next_valid 1 ctx (by omega)) (by change c.top+1<PoolCalls.capacity;omega))
    (by change c.top+2<PoolCalls.capacity;exact room)
    (PoolCursor.preserves (c:=afterOne l c) (PoolCursor.next_borrow l c 1))
    (PoolCursor.next_borrow l (afterOne l c) 100)

theorem result_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) {object : Nat} {old : Option Value}
    (raw : SourceNatGlobal.RawAt c.state "scale100" object old) : Valid l (result l c object) := by
  have safe:=SourceNatGlobal.separated ctx raw
  exact LocalAssignment.valid (shift_valid ctx room) object "N" _ safe.1 safe.2.1 safe.2.2

theorem result_scale {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {object : Nat} {old : Option Value} (raw : SourceNatGlobal.RawAt c.state "scale100" object old) :
    SourceFromS.ScaleAt (result l c object).state object (slot l c) (2^100) := by
  have stored:=SourceNatGlobal.advanced ctx raw [1,100,1<<<100]
  constructor
  · change (shifted l c).state.globals.lookup "scale100"=some ⟨object,0,[]⟩
    exact stored.lookup
  · exact List.getElem?_set_self (List.getElem?_eq_some_iff.mp stored.storage).choose
  · change NatArena.Borrow (shifted l c).state.nats (slot l c) (2^100)
    simpa only[Nat.shiftLeft_eq,one_mul] using shift_live l c

structure Answers (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor) : Prop where
  one : service "nu" [DecimalDigits.integer 1] c.state=
    some (.natObject c.state.nats.values.length,(afterOne l c).state)
  hundred : service "nu" [DecimalDigits.integer 100] (afterOne l c).state=
    some (.natObject (afterOne l c).state.nats.values.length,(afterHundred l c).state)
  shift : service "nl"
    [.natObject c.state.nats.values.length,.natObject (afterOne l c).state.nats.values.length]
    (afterHundred l c).state=some (.natObject (slot l c),(shifted l c).state)

theorem source_assignment (service : Call) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) {object : Nat} {old : Option Value}
    (raw : SourceNatGlobal.RawAt c.state "scale100" object old)
    (unshadowed : c.state.env.lookup "scale100"=none) (answers : Answers service l c) :
    Eval Header.layout service (.binary "=" (.var "scale100")
      (.call (.var "nl") [.call (.var "nu") [.nat 1],.call (.var "nu") [.nat 100]]))
      c.state (result l c object).state (.natObject (slot l c)) := by
  have right:=ExpressionTemplates.call_two Header.layout service
    (ExpressionTemplates.call_one Header.layout service
      (show evalExpr Header.layout service 1 c.state (.nat 1)=
        some (DecimalDigits.integer 1,c.state) from rfl) answers.one)
    (ExpressionTemplates.call_one Header.layout service
      (show evalExpr Header.layout service 1 (afterOne l c).state (.nat 100)=
        some (DecimalDigits.integer 100,(afterOne l c).state) from rfl) answers.hundred) answers.shift
  exact ⟨4,SourceNatGlobal.source_assignment service 2
    (SourceNatGlobal.advanced ctx raw [1,100,1<<<100])
    (by change (CursorFrames.advance l c [1,100,1<<<100]).state.env.lookup "scale100"=none
        rw[(CursorEffects.shape l c [1,100,1<<<100]).2];exact unshadowed)
    (shift_live l c) right⟩

end ScopedC.PrepareSource.ScalePrelude
