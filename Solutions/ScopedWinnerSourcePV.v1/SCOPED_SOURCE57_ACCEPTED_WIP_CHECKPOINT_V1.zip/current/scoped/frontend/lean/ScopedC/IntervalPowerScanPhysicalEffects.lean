/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerScanStep
import ScopedC.RationalIntervalMultiplyEffects

namespace ScopedC.IntervalPowerScan
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem multiplied_preserves_nat {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool)
    (room : f.cursor.top+79<PoolCalls.capacity) {slot value : Nat} (live : NatArena.Borrow f.cursor.state.nats slot value) :
    NatArena.Borrow (multiplied f fromA room).cursor.state.nats slot value := by
  change NatArena.Borrow (IntervalProductApplicability.next l f.cursor (left f fromA) f.result).state.nats slot value
  unfold IntervalProductApplicability.next
  exact RationalIntervalMultiplyCalls.preserves_nat (left f fromA) f.result live
theorem multiplied_globals {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool)
    (room : f.cursor.top+79<PoolCalls.capacity) : (multiplied f fromA room).cursor.state.globals=f.cursor.state.globals := by
  change (IntervalProductApplicability.next l f.cursor (left f fromA) f.result).state.globals=_
  unfold IntervalProductApplicability.next
  exact RationalIntervalMultiplyCalls.after_globals l f.cursor (left f fromA) f.result
theorem multiplied_other {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool)
    (room : f.cursor.top+79<PoolCalls.capacity) (slot : Nat) (bound : slot < f.cursor.state.heap.length)
    (localApart : slot≠f.rSlot) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (multiplied f fromA room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  change ((IntervalProductApplicability.next l f.cursor (left f fromA) f.result).state.heap.set f.rSlot _)[slot]?=_
  rw[List.getElem?_set_ne (Ne.symm localApart)]
  unfold IntervalProductApplicability.next
  exact RationalIntervalMultiplyCalls.after_other l f.cursor (left f fromA) f.result slot bound hp ht hh
theorem halved_other {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (slot : Nat) (apart : slot≠f.bitSlot) :
    (halved f).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  change (f.cursor.state.heap.set f.bitSlot _)[slot]?=_
  exact List.getElem?_set_ne (Ne.symm apart)

theorem afterOdd_slots {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) :
    (afterOdd f room).bitSlot=f.bitSlot ∧ (afterOdd f room).rSlot=f.rSlot := by
  unfold afterOdd
  split <;> exact ⟨rfl,rfl⟩
theorem iteration_slots {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) :
    (iteration f room).bitSlot=f.bitSlot ∧ (iteration f room).rSlot=f.rSlot := afterOdd_slots f room

theorem iteration_preserves_nat {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) {slot value : Nat} (live : NatArena.Borrow f.cursor.state.nats slot value) :
    NatArena.Borrow (iteration f room).cursor.state.nats slot value := by
  have first : NatArena.Borrow (squared f room).cursor.state.nats slot value:=multiplied_preserves_nat f false (by omega) live
  change NatArena.Borrow (afterOdd f room).cursor.state.nats slot value
  unfold afterOdd
  split
  · exact multiplied_preserves_nat (squared f room) true (by rw[squared_top];omega) first
  · exact first

theorem iteration_globals {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) :
    (iteration f room).cursor.state.globals=f.cursor.state.globals := by
  have first : (squared f room).cursor.state.globals=f.cursor.state.globals:=multiplied_globals f false (by omega)
  change (afterOdd f room).cursor.state.globals=f.cursor.state.globals
  unfold afterOdd
  split
  · exact (multiplied_globals (squared f room) true (by rw[squared_top];omega)).trans first
  · exact first

theorem afterOdd_shape {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (room : f.cursor.top+159<PoolCalls.capacity) :
    (afterOdd f room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (afterOdd f room).cursor.state.env=f.cursor.state.env := by
  have first:=multiplied_shape f false (by omega)
  unfold afterOdd
  split
  · have second:=multiplied_shape (squared f room) true (by rw[squared_top];omega)
    exact ⟨second.1.trans first.1,second.2.trans first.2⟩
  · exact first

theorem iteration_other {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) (slot : Nat) (bound : slot < f.cursor.state.heap.length)
    (pb : slot≠f.bitSlot) (pr : slot≠f.rSlot) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (iteration f room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  have first : (squared f room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? :=
    multiplied_other f false (by omega) slot bound pr hp ht hh
  have squaredBound : slot < (squared f room).cursor.state.heap.length := by
    change slot < (multiplied f false (by omega)).cursor.state.heap.length
    rw[(multiplied_shape f false (by omega)).1]
    exact bound
  have oddOther : (afterOdd f room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
    unfold afterOdd
    split
    · exact (multiplied_other (squared f room) true (by rw[squared_top];omega) slot squaredBound pr hp ht hh).trans first
    · exact first
  exact (halved_other (afterOdd f room) slot (by rw[(afterOdd_slots f room).1];exact pb)).trans oddOther

end ScopedC.IntervalPowerScan
