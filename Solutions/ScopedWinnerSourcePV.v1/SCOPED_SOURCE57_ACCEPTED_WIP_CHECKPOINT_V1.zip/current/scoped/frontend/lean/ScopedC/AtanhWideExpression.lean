/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhWideData

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard wideC1 wideC2 wideFinish

def wideInitializer : Expr := .record [
  .call (.var "qn") [.call (.var "qi") [.nat 1000]],.call (.var "qi") [.nat 1000]]

def afterWide (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  CursorLocals.allocated (wideFinish l c q) "RI" "wide" (widePair l c q).source

theorem wide_expression (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input)
    (first : service "qi" [DecimalDigits.integer 1000] (afterGuard l c q).state=
      some ((wideFirst l c q).source,(wideC1 l c q).state))
    (negative : service "qn" [(wideFirst l c q).source] (wideC1 l c q).state=
      some ((widePair l c q).lo.source,(wideC2 l c q).state))
    (second : service "qi" [DecimalDigits.integer 1000] (wideC2 l c q).state=
      some ((wideSecond l c q).source,(wideFinish l c q).state)) :
    evalExpr Header.layout service 1000 (afterGuard l c q).state wideInitializer=
      some (.aggregate [(widePair l c q).lo.source,(widePair l c q).hi.source],
        (wideFinish l c q).state) := by
  have qi:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 997 (afterGuard l c q).state (.nat 1000)=
      some (DecimalDigits.integer 1000,(afterGuard l c q).state) from rfl) first
  have left:=ExpressionTemplates.call_one Header.layout service qi negative
  have right:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 998 (wideC2 l c q).state (.nat 1000)=
      some (DecimalDigits.integer 1000,(wideC2 l c q).state) from rfl) second
  exact ExpressionTemplates.record_two Header.layout service left right

theorem wide_cast (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    castValue Header.layout (wideFinish l c q).state 100 "RI"
      (.aggregate [(widePair l c q).lo.source,(widePair l c q).hi.source])=
      some (widePair l c q).source := by
  have live:=wide_live l c q
  have low : castValue Header.layout (wideFinish l c q).state 99 "Q"
      (widePair l c q).lo.source=some (widePair l c q).lo.source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel)
      live.1.1 live.1.2 (SignedNegCalls.bit_bound _)
  have high : castValue Header.layout (wideFinish l c q).state 99 "Q"
      (widePair l c q).hi.source=some (widePair l c q).hi.source :=
    RecordCasts.rational_record _ 96 "Q" (by decide +kernel)
      live.2.1 live.2.2 (SignedNegCalls.bit_bound _)
  exact IntervalCasts.aggregate _ 96 _ _ low high

theorem wide_declaration (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input)
    (first : service "qi" [DecimalDigits.integer 1000] (afterGuard l c q).state=
      some ((wideFirst l c q).source,(wideC1 l c q).state))
    (negative : service "qn" [(wideFirst l c q).source] (wideC1 l c q).state=
      some ((widePair l c q).lo.source,(wideC2 l c q).state))
    (second : service "qi" [DecimalDigits.integer 1000] (wideC2 l c q).state=
      some ((wideSecond l c q).source,(wideFinish l c q).state)) :
    Declare Header.layout service
      [{type:="RI",name:="wide",value:=some wideInitializer,arrayExtent:=none}]
      (afterGuard l c q).state (afterWide l c q).state := by
  have expression:=wide_expression service l c q first negative second
  simp only[Declare,declarations,List.foldlM,expression,wide_cast,Bind.bind,Option.bind]
  rfl

theorem wide_binding (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    LocalBinding.At (afterWide l c q).state "wide" "RI" (widePair l c q).source
      (wideFinish l c q).state.heap.length :=
  LocalBinding.allocate_head _ "wide" "RI" _ (by rfl)

theorem wide_positive (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (widePair l c q).Positive := by
  change 0<(1:Nat) ∧ 0<(1:Nat)
  decide +kernel

theorem wide_order (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    (widePair l c q).lo.mathematical.value≤(widePair l c q).hi.mathematical.value := by
  rw[(wide_values l c q).1,(wide_values l c q).2]
  norm_num

end ScopedC.AtanhCalls
