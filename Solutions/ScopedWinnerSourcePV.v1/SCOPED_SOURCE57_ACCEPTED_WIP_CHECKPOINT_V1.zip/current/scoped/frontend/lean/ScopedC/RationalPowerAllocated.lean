/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerFramedBody

namespace ScopedC.RationalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure AllocatedResult (code : List Function) (l : PoolCalls.PoolLayout) (before : Cursor)
    (a : Input) (n : Nat) extends FramedResult code l before a n where
  arena_lower : before.state.nats.values.length+3 ≤ out.state.nats.values.length

/-- Existing exact qpow source/caller contract, additionally exposing the real
three initial qi(1) allocations needed to distinguish repeated caller events. -/
theorem qpow_allocated (code : List Function) (installed : Generated.f_qpow∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+706<PoolCalls.capacity)
    (a : Input) (n : Nat) (alive : a.Live c.state) (positive : 0<a.denominator) (bound : n<2^32) :
    Nonempty (AllocatedResult code l c a n) := by
  obtain ⟨f,fc,fa,fr,fn⟩:=initial_frame ctx (by omega) a n alive positive bound
  have loopBound : f.exponent<2^32 := by rw[fn];exact bound
  have loopRoom : f.cursor.top+22*32 ≤ PoolCalls.capacity := by rw[fc,loopStart_top];omega
  obtain ⟨trace⟩:=loop_framed_certificate code lib 32 f loopBound loopRoom
  have result:=compose_trace code installed lib ctx (by omega) a n alive bound f fc fa fr fn trace.toLoopCertificate
  let out:=finishCursor c a n trace.finish
  refine ⟨{
    out:=out
    output:=trace.finish.accumulator
    execution:=result.1
    valid:=result.2.1
    live:=result.2.2.1
    positive:=result.2.2.2.1
    decoded:=Input.decoded result.2.2.1 result.2.2.2.1
    value:=result.2.2.2.2.1
    top:=result.2.2.2.2.2
    globals:=?_
    env:=rfl
    heap_length:=?_
    preserves:=?_
    other:=?_
    arena_lower:=?_
  }⟩
  · change trace.finish.cursor.state.globals=c.state.globals
    exact trace.globals.trans (by rw[fc,initial_globals])
  · change ((trace.finish.cursor.state.heap.take (parameters c a n).state.heap.length).take c.state.heap.length).length=c.state.heap.length
    rw[List.length_take,List.length_take,trace.shape.1,fc,initial_heap_length,parameters_length]
    omega
  · intro slot value live
    change NatArena.Borrow trace.finish.cursor.state.nats slot value
    exact trace.borrows slot value (by rw[fc];exact initial_borrow l c a n live)
  · intro slot old hp ht hh
    change ((trace.finish.cursor.state.heap.take (parameters c a n).state.heap.length).take c.state.heap.length)[slot]?=c.state.heap[slot]?
    rw[List.getElem?_take_of_lt old,List.getElem?_take_of_lt (by rw[parameters_length];omega)]
    have slots:=initial_slots c a n f fc
    have preserved:=trace.other slot (by rw[slots.1];omega) (by rw[slots.2.1];omega)
      (by rw[slots.2.2];omega) hp ht hh
    exact preserved.trans (by rw[fc];exact initial_other l c a n slot old hp ht hh)

  · change c.state.nats.values.length+3 ≤ trace.finish.cursor.state.nats.values.length
    have lower:=trace.nats_le
    rw[fc,loopStart_size] at lower
    exact lower

end ScopedC.RationalPowerCalls
