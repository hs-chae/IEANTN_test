/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientTableAppend
import ScopedC.CoefficientTableGlobal

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def cursor (c : Cursor) (base : Address) (cells : List (Option Value)) (k : Nat) (q : Input) : Cursor :=
  {c with state:=changed c.state base cells k q}

theorem write_cell {s : State} {base : Address} {coeffs : List Input} (table : TableAt s base coeffs)
    (k : Nat) (bound : k<table.cells.length) (q : Input) (alive : q.Live s) :
    write Header.layout s ⟨base.object,k,[]⟩ true q.source=
      some (q.source,changed s base table.cells k q) := by
  have convert:=Input.cast (s:=s) (q:=q) "Q" (by decide +kernel) alive
  simp [write,addressType,table.memory,bound,typeAt,convert,
    List.getElem?_eq_getElem bound,changed]

theorem lvalue (service : Call) (fuel : Nat) {s : State} {base : Address} {coeffs : List Input}
    (table : TableAt s base coeffs) {array index : Expr} {value : Value} {k : Nat}
    (pointer : evalExpr Header.layout service (fuel+1) s array=some (.pointer base true,s))
    (counter : evalExpr Header.layout service (fuel+1) s index=some (value,s))
    (natural : asNat value=some k) (bound : k<table.cells.length) :
    evalLValue Header.layout service (fuel+2) s (.index array index)=some (⟨base.object,k,[]⟩,true,s) := by
  rw[evalLValue,pointer]
  simp only[table.emptyFields,List.isEmpty_nil,Bool.not_true,Bool.false_eq_true,↓reduceIte,Bind.bind,Option.bind]
  rw[counter]
  simp [natural,table.zeroIndex,table.emptyFields,addressType,table.memory,bound,typeAt]

/-- RHS source calls finish before the actual global-array lvalue and checked
Q store, following the original C expression order without reading raw zero
coefficient cells. -/
theorem source_assignment (service : Call) (fuel : Nat) {s middle : State}
    {base : Address} {coeffs : List Input} (table : TableAt middle base coeffs)
    {array index rhs : Expr} {value : Value} {k : Nat} (q : Input)
    (right : evalExpr Header.layout service (fuel+2) s rhs=some (q.source,middle))
    (pointer : evalExpr Header.layout service (fuel+1) middle array=some (.pointer base true,middle))
    (counter : evalExpr Header.layout service (fuel+1) middle index=some (value,middle))
    (natural : asNat value=some k) (bound : k<table.cells.length) (alive : q.Live middle) :
    evalExpr Header.layout service (fuel+3) s (.binary "=" (.index array index) rhs)=
      some (q.source,changed middle base table.cells k q) := by
  rw[evalExpr,right]
  simp only[Bind.bind,Option.bind]
  rw[lvalue service fuel table pointer counter natural bound]
  exact write_cell table k bound q alive

theorem valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {base : Address} {coeffs : List Input} (table : TableAt c.state base coeffs) (k : Nat) (q : Input) :
    Valid l (cursor c base table.cells k q) := by
  have safe:=pool_separated ctx table
  constructor
  · exact ctx.global_pool
  · exact ctx.global_top
  · exact ctx.global_high
  · simpa only[cursor,changed,List.getElem?_set_ne safe.1] using ctx.pool_read
  · simpa only[cursor,changed,List.getElem?_set_ne safe.2.1] using ctx.top_read
  · simpa only[cursor,changed,List.getElem?_set_ne safe.2.2] using ctx.high_read
  · exact ctx.extent
  · exact ctx.high_range
  · exact ctx.top_range

def other_table {s : State} {base other : Address} {coeffs others : List Input}
    (table : TableAt s base coeffs) (retained : TableAt s other others)
    (different : base.object≠other.object) (k : Nat) (q : Input) :
    TableAt (changed s base table.cells k q) other others :=
  memory retained (by simp only[changed,List.getElem?_set_ne different]) (fun _ _ h=>h)

end ScopedC.CoefficientTableRead
