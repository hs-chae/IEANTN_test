/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhBody

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

theorem old_model_values (q : Rat) (d : Nat) (coeffs : List Rat) :
    (IntervalRat.atanhPointComputableWithCoeffs q d coeffs).lo=
      (if 1≤|q| then -1000 else
        (IntervalRat.evalTaylorSeries coeffs (IntervalRat.singleton q)).lo-|q|^(d+1)/(1-|q|)) ∧
    (IntervalRat.atanhPointComputableWithCoeffs q d coeffs).hi=
      (if 1≤|q| then 1000 else
        (IntervalRat.evalTaylorSeries coeffs (IntervalRat.singleton q)).hi+|q|^(d+1)/(1-|q|)) := by
  by_cases wide : 1≤|q|
  · simp [IntervalRat.atanhPointComputableWithCoeffs,wide]
  · simp [IntervalRat.atanhPointComputableWithCoeffs,IntervalRat.atanhRemainderBoundComputable,
      IntervalRat.add,wide,abs_abs,sub_eq_add_neg]

/-- Actual original C atanhPoint execution decodes exactly to the existing
original rational interval algorithm. No application output is assumed. -/
theorem atanhPoint_math (code : List Function) (installed : Generated.f_atanhPoint∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (alive : q.Live c.state) (positive : 0<q.denominator) (d object : Nat)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (lookup : c.state.globals.lookup "atanhCoeffs"=some base)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high)
    (dBound : d≤64) (length : coeffs.length=d+1) (room : c.top+9000<PoolCalls.capacity) :
    ∃out : Cursor,∃pair : Pair,
      SourceCall Header.layout code 10 "atanhPoint" [q.source] c.state pair.source out.state ∧
      Valid l out ∧ pair.Live out.state ∧ pair.Positive ∧
      NumericRepresentation.interval out.state pair.source=some
        (IntervalRat.atanhPointComputableWithCoeffs q.mathematical.value d
          (TaylorCalls.coefficientValues coeffs)) := by
  obtain ⟨out,pair,execution,valid,live,positivePair,lo,hi⟩:=atanhPoint_closed code installed lib ctx q
    alive positive d object table lookup depth apart dBound length room
  have model:=old_model_values q.mathematical.value d (TaylorCalls.coefficientValues coeffs)
  have low : pair.lo.mathematical.value=(IntervalRat.atanhPointComputableWithCoeffs
      q.mathematical.value d (TaylorCalls.coefficientValues coeffs)).lo:=lo.trans model.1.symm
  have high : pair.hi.mathematical.value=(IntervalRat.atanhPointComputableWithCoeffs
      q.mathematical.value d (TaylorCalls.coefficientValues coeffs)).hi:=hi.trans model.2.symm
  have ordered : pair.lo.mathematical.value≤pair.hi.mathematical.value := by
    rw[low,high]
    exact (IntervalRat.atanhPointComputableWithCoeffs q.mathematical.value d
      (TaylorCalls.coefficientValues coeffs)).le
  have decoded:=NumericRationalIntervalAddRefinement.decoded_input live positivePair ordered
  have same : (⟨pair.lo.mathematical.value,pair.hi.mathematical.value,ordered⟩:IntervalRat)=
      IntervalRat.atanhPointComputableWithCoeffs q.mathematical.value d
        (TaylorCalls.coefficientValues coeffs) := by
    rw[IntervalRat.mk.injEq]
    exact ⟨low,high⟩
  exact ⟨out,pair,execution,valid,live,positivePair,decoded.trans (congrArg some same)⟩

end ScopedC.AtanhCalls
