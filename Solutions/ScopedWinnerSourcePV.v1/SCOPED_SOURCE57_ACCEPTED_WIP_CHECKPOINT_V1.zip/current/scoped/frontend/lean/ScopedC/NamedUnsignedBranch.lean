/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedUnsignedService
namespace ScopedC.NamedUnsignedBranch
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.NamedUnsignedPair ScopedC.RationalRecordFields
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def statements (nl nh den : Nat) : List Stmt := [
  .eval (.binary "=" (.field "." (.var "r") "lo") (RationalUnsignedRatio.initializer nl den)),
  .eval (.binary "=" (.field "." (.var "r") "hi") (RationalUnsignedRatio.initializer nh den))]

def after {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldHi : Value} (D : Stages code l c nl nh den slot oldHi) : Cursor :=
  PoolContextPop.unframe c.state (finish D)

theorem run (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot)
    (lowRoom : c.top+18<capacity) (highRoom : (middle D).top+18<capacity)
    (lowSource : evalExpr Header.layout service 1000 c.state
      (RationalUnsignedRatio.initializer nl den)=some (D.low.output.source,(RationalUnsignedRatio.after l c nl den).state))
    (highSource : evalExpr Header.layout service 1000 (middle D).state
      (RationalUnsignedRatio.initializer nh den)=some (D.high.output.source,(RationalUnsignedRatio.after l (middle D) nh den).state)) :
    Run Header.layout service (.sequence (statements nl nh den)) c.state
      (.continuing (after D).state) := by
  have lo := NamedRecordLifecycle.unsigned_lo service D.low ctx lowRoom record lowSource
  have hi := NamedRecordLifecycle.unsigned_hi service D.high lo.2.1 highRoom lo.2.2 highSource
  exact Loops.StmtRun.sequence
    (Loops.SeqRun.next (Loops.StmtRun.evaluate ⟨1001,lo.1⟩)
      (Loops.SeqRun.next (Loops.StmtRun.evaluate ⟨1001,hi.1⟩) (Loops.SeqRun.nil _))) rfl

theorem result {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot)
    (lowRoom : c.top+18<capacity) (highRoom : (middle D).top+18<capacity) :
    Valid l (after D) ∧ At (after D).state D.low.output.source D.high.output.source slot ∧
      (input D).Live (after D).state := by
  have h := stored_result D ctx record lowRoom highRoom
  exact ⟨PoolContextPop.valid h.1 (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
    (List.getElem?_eq_some_iff.mp ctx.top_read).choose
    (List.getElem?_eq_some_iff.mp ctx.high_read).choose,
    NamedRecordLifecycle.pop_record record h.2.1,h.2.2⟩

theorem scale {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot object valueSlot number : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot)
    (lowRoom : c.top+18<capacity) (highRoom : (middle D).top+18<capacity)
    (h : SourceFromS.ScaleAt c.state object valueSlot number) :
    SourceFromS.ScaleAt (after D).state object valueSlot number :=
  NamedRecordLifecycle.pop_scale h (NamedUnsignedPair.scale D ctx record lowRoom highRoom h)

theorem ordered {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldHi : Value} (D : Stages code l c nl nh den slot oldHi)
    (ascending : nl≤nh) : (input D).lo.mathematical.value≤(input D).hi.mathematical.value := by
  change D.low.output.mathematical.value≤D.high.output.mathematical.value
  rw [D.low.value,D.high.value]
  exact div_le_div_of_nonneg_right (by exact_mod_cast ascending) (by positivity)

#print axioms run
#print axioms result
#print axioms scale
#print axioms ordered
end ScopedC.NamedUnsignedBranch
