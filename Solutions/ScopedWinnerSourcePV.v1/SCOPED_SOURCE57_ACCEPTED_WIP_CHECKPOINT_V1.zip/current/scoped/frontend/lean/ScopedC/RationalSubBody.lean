/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSubData
import ScopedC.RationalMakeRawCast

namespace ScopedC.RationalSubCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  qa : Generated.f_qa∈code
  qn : Generated.f_qn∈code
  sn : Generated.f_sn∈code
  add : RationalAddCalls.Library code

theorem negation_call (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) (hb : b.Live c.state) :
    SourceCall Header.layout code 6 "qn" [b.source] (frame c.state a b) (negative b).source (frame (c1 l c).state a b) := by
  have h := RationalNegCalls.qn_closed code lib.qn lib.sn lib.add.smake lib.add.nz lib.add.nu lib.add.ne lib.add.keep
    (s:=frame c.state a b) (l:=l) (cells:=c.cells) (top:=c.top) (high:=c.high) b.numerator.negative
    (TwoFrames.context_frame ctx "Q" "a" a.source "Q" "b" b.source) room hb.1 hb.2
  have move : binaryResult l (frame c.state a b) c.cells c.top c.high 0=frame (c1 l c).state a b :=
    binary_result_two_frame ctx "Q" "a" a.source "Q" "b" b.source
  rw [move] at h
  rw [negative_source]
  exact h

theorem qs_closed (code : List Function) (installed : Generated.f_qs∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+14<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 7 "qs" [a.source,b.source] c.state (result l c a b) (after l c a b).state := by
  let p0 := frame c.state a b
  let p1 := frame (c1 l c).state a b
  let final := (interior l c a b).state
  let out := result l c a b
  have ctxp := phase1_context ctx room a b
  have cap : (phase1 l c a b).top+13<PoolCalls.capacity := by change c.top+1+13<PoolCalls.capacity;omega
  have pn := negation_call code lib ctx (by omega) a b hb
  have ps : SourceCall Header.layout code 6 "qa" [a.source,(negative b).source] p1 out final := by
    unfold final interior
    exact RationalAddCalls.qa_closed code lib.qa lib.add ctxp cap a (negative b)
      (Input.live_after ha) (negative_live (Input.live_after hb)) pa pb
  let en : CallEvents.Event Header.layout code 6 := ⟨"qn",[b.source],p0,(negative b).source,p1,pn⟩
  let es : CallEvents.Event Header.layout code 6 := ⟨"qa",[a.source,(negative b).source],p1,out,final,ps⟩
  let service := CallEvents.append (CallEvents.one en) (CallEvents.one es)
  have hn : service "qn" [b.source] p0=some ((negative b).source,p1) := CallEvents.append_left (CallEvents.one_self en)
  have hs : service "qa" [a.source,(negative b).source] p1=some (out,final) :=
    CallEvents.append_right (CallEvents.one_other en (by change ("qa":String)≠"qn";decide +kernel) _ _) (CallEvents.one_self es)
  have expr : Eval Header.layout service (.call (.var "qa") [.var "a",.call (.var "qn") [.var "b"]]) p0 final out :=
    ⟨4,ExpressionTemplates.call_two Header.layout service (RationalPairFrames.eval_a service 2 c.state a b)
      (ExpressionTemplates.call_one Header.layout service (RationalPairFrames.eval_b service 1 c.state a b) hn) hs⟩
  have shp := PoolCursor.shape l c 0
  have shi := RationalAddCalls.shape l (phase1 l c a b) a (negative b)
  have len : final.heap.length=p0.heap.length := by
    change (interior l c a b).state.heap.length=p0.heap.length
    rw [interior,shi.1]
    simp only[phase1,CursorFrames.framed,c1,p0,frame,TwoFrames.frame,allocate,List.length_append,List.length_singleton,shp.1]
  have env : final.env=p0.env := by
    change (interior l c a b).state.env=p0.env
    rw [interior,shi.2]
    simp only[phase1,CursorFrames.framed,c1,p0,frame,TwoFrames.frame,allocate,List.length_append,List.length_singleton,shp.1]
  have body : Run Header.layout service Generated.f_qs.body p0 (.returned final out) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.returned (Loops.StmtRun.returnValue expr))
    exact ⟨rfl,(PoolCalls.pop_same len env).symm⟩
  have closed : ∀ name args before value after,service name args before=some (value,after) →
      SourceCall Header.layout code 6 name args before value after := by
    intro name args before value after h
    exact CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed en h) (fun _ _ _ _ _ h=>CallEvents.one_closed es h) h
  apply installed_body (f:=Generated.f_qs) (rank:=6) (service:=service) installed closed (RationalPairFrames.bind a b ha hb) body
  constructor
  · unfold final interior
    exact RationalMakeRawCast.result l
      (RationalAddCalls.c9 l (phase1 l c a b) a (negative b))
      (RationalAddCalls.sum l (phase1 l c a b) a (negative b)) (RationalAddCalls.denominator a (negative b))
  · rfl

end ScopedC.RationalSubCalls
