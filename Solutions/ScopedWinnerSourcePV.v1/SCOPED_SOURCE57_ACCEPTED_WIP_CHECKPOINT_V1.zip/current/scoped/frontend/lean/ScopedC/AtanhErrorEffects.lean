/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhError

namespace ScopedC.AtanhCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

theorem den_heap {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) :
    (denCursor stage).state.heap.length=stage.out.state.heap.length := by
  unfold denCursor
  rw[RationalSubCalls.after_heap_length]
  exact (CursorEffects.shape l stage.out [1,0,1]).1

theorem den_globals {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) :
    (denCursor stage).state.globals=stage.out.state.globals := by
  unfold denCursor
  rw[RationalSubCalls.after_globals]
  exact CursorSingleFrames.advance_globals l stage.out [1,0,1]

theorem den_env {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) :
    (denCursor stage).state.env=stage.out.state.env := by
  unfold denCursor
  rw[RationalSubCalls.after_env]
  exact (CursorEffects.shape l stage.out [1,0,1]).2

theorem den_other {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (slot : Nat)
    (old : slot<stage.out.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (denCursor stage).state.heap[slot]?=stage.out.state.heap[slot]? := by
  unfold denCursor
  rw[RationalSubCalls.after_other l (denStart stage) (denOne stage) (absInput q) slot
    (by change slot<(CursorFrames.advance l stage.out [1,0,1]).state.heap.length
        rw[(CursorEffects.shape l stage.out [1,0,1]).1];exact old) hp ht hh]
  exact CursorSingleFrames.advance_other l stage.out [1,0,1] slot hp ht hh

theorem den_borrow {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) {slot value : Nat}
    (live : NatArena.Borrow stage.out.state.nats slot value) :
    NatArena.Borrow (denCursor stage).state.nats slot value :=
  RationalSubCalls.after_borrow (denOne stage) (absInput q)
    (CursorBorrow.preserves (l:=l) (c:=stage.out) [1,0,1] live)

theorem error_valid {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (room : c.top+750<PoolCalls.capacity) : Valid l (errorCursor stage positive) := by
  have top:=stage.top
  rw[guard_top] at top
  exact RationalDivideCalls.after_context (den_valid stage room) (by rw[den_top];omega) _ _

theorem error_nonzero_cursor {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    errorCursor stage positive=RationalDivideCalls.nonzeroAfter l (denCursor stage)
      stage.output (denominator stage positive) := by
  unfold errorCursor RationalDivideCalls.after
  rw[if_neg (denominator_nonzero stage positive narrow)]

theorem error_globals {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (errorCursor stage positive).state.globals=stage.out.state.globals := by
  rw[error_nonzero_cursor _ _ narrow,RationalDivideCalls.nonzero_globals,den_globals]

theorem error_env {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (errorCursor stage positive).state.env=stage.out.state.env := by
  rw[error_nonzero_cursor _ _ narrow,RationalDivideCalls.nonzero_env,den_env]

theorem error_heap {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (errorCursor stage positive).state.heap.length=stage.out.state.heap.length := by
  rw[error_nonzero_cursor _ _ narrow,RationalDivideCalls.nonzero_heap_length,den_heap]

theorem error_top {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (errorCursor stage positive).top=stage.out.top+31 := by
  rw[error_nonzero_cursor _ _ narrow,RationalDivideCalls.nonzero_top,den_top]

theorem error_borrow {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) {slot value : Nat}
    (live : NatArena.Borrow stage.out.state.nats slot value) :
    NatArena.Borrow (errorCursor stage positive).state.nats slot value := by
  rw[error_nonzero_cursor _ _ narrow]
  exact RationalDivideCalls.nonzero_borrow _ _ (den_borrow stage live)

theorem error_other {code : List Syntax.Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) (slot : Nat) (old : slot<stage.out.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (errorCursor stage positive).state.heap[slot]?=stage.out.state.heap[slot]? := by
  rw[error_nonzero_cursor _ _ narrow]
  rw[RationalDivideCalls.nonzero_other l (denCursor stage) stage.output
    (denominator stage positive) slot (by rw[den_heap];exact old) hp ht hh]
  exact den_other stage slot old hp ht hh

end ScopedC.AtanhCalls
