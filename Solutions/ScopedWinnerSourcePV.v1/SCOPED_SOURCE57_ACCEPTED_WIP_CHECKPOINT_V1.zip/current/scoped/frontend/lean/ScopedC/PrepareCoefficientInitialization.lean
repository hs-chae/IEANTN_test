/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientInitialFrame
import ScopedC.PrepareCoefficientExpData

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

theorem initOne_source (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1] s.cursor.state
      (initOne s).source (initOneCursor s).state :=
  (RationalUnsignedTrace.qi_traced code lib.unsigned.qi lib.unsigned.si
    lib.unsigned.productLibrary.smake lib.unsigned.productLibrary.nz lib.unsigned.productLibrary.nu
    lib.unsigned.productLibrary.ne lib.unsigned.productLibrary.keep s.context 1 (by decide +kernel)
    (by omega) (DecimalDigits.integer 1) (by rfl)).1

theorem initZero_source (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 0] (initExpCursor s).state
      (initZero s).source (initZeroCursor s).state := by
  apply (RationalUnsignedTrace.qi_traced code lib.unsigned.qi lib.unsigned.si
    lib.unsigned.productLibrary.smake lib.unsigned.productLibrary.nz lib.unsigned.productLibrary.nu
    lib.unsigned.productLibrary.ne lib.unsigned.productLibrary.keep (initExp_valid s room) 0
    (by decide +kernel) ?_ (DecimalDigits.integer 0) (by rfl)).1
  unfold initExpCursor
  change s.cursor.top+3+2<PoolCalls.capacity
  omega

theorem initExp_assignment (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab)
    (answer : service "qi" [DecimalDigits.integer 1] s.cursor.state=
      some ((initOne s).source,(initOneCursor s).state)) :
    Eval Header.layout service (.binary "=" (.index (.var "expCoeffs") (.nat 0))
      (.call (.var "qi") [.nat 1])) s.cursor.state (initExpCursor s).state (initOne s).source := by
  refine ⟨3,?_⟩
  unfold initExpCursor
  exact CoefficientTableRead.source_assignment service 0 (initExpBefore s) (initOne s)
    (ExpressionTemplates.call_one Header.layout service (by rfl) answer)
    (CoefficientTableRead.eval_global service 0 (initExpBefore s)
      (by simpa only[initOneCursor,RationalUnsignedTrace.after,CursorSingleFrames.advance_globals] using s.expLookup)
      (by simpa only[initOneCursor,RationalUnsignedTrace.after,CursorEffects.shape] using s.expUnshadowed)
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (by rfl) (by rfl)
    (by change 0<(CoefficientTableRead.advanced s.context s.expAt [1,0,1]).cells.length
        rw[CoefficientTableRead.advanced_cells,s.expExtent];decide +kernel)
    (RationalUnsignedTrace.live l s.cursor 1)

theorem initAtanh_assignment (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity)
    (answer : service "qi" [DecimalDigits.integer 0] (initExpCursor s).state=
      some ((initZero s).source,(initZeroCursor s).state)) :
    Eval Header.layout service (.binary "=" (.index (.var "atanhCoeffs") (.nat 0))
      (.call (.var "qi") [.nat 0])) (initExpCursor s).state
      (initAtanhCursor s room).state (initZero s).source := by
  have globals : (initZeroCursor s).state.globals=s.cursor.state.globals := by
    change (CursorFrames.advance l (initExpCursor s) [0,0,1]).state.globals=_
    rw[CursorSingleFrames.advance_globals]
    unfold initExpCursor
    exact CursorSingleFrames.advance_globals l s.cursor [1,0,1]
  have env : (initZeroCursor s).state.env=s.cursor.state.env := by
    change (CursorFrames.advance l (initExpCursor s) [0,0,1]).state.env=_
    rw[(CursorEffects.shape l (initExpCursor s) [0,0,1]).2]
    unfold initExpCursor
    exact (CursorEffects.shape l s.cursor [1,0,1]).2
  refine ⟨3,?_⟩
  unfold initAtanhCursor
  exact CoefficientTableRead.source_assignment service 0 (initZeroAtanhTable s room) (initZero s)
    (ExpressionTemplates.call_one Header.layout service (by rfl) answer)
    (CoefficientTableRead.eval_global service 0 (initZeroAtanhTable s room)
      (by rw[globals];exact s.atanhLookup) (by rw[env];exact s.atanhUnshadowed)
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (by rfl) (by rfl) (by rw[initZeroAtanh_extent];decide +kernel)
    (RationalUnsignedTrace.live l (initExpCursor s) 0)

theorem initCounter_declaration (service : Call)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (s : CoeffSeed l object d eb ab) (room : s.cursor.top+5<PoolCalls.capacity) :
    Declare Header.layout service
      [{type:="unsigned int",name:="k",value:=some (.nat 1),arrayExtent:=none}]
      (initAtanhCursor s room).state (coeffInitialFrame s room).cursor.state := by
  have cast : castValue Header.layout (initAtanhCursor s room).state 100 "unsigned int"
      (DecimalDigits.integer 1)=some (PoolCalls.word 1) := by rfl
  simp only[Declare,declarations,List.foldlM,evalExpr,Bind.bind,Option.bind,cast]
  rfl

end ScopedC.PrepareSource
