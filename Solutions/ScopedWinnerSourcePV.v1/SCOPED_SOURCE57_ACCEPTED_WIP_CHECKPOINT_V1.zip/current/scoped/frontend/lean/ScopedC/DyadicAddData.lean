/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DyadicPairFrames
import ScopedC.NumericSignedAddRefinement
import ScopedC.CursorBorrow
import ScopedC.PoolContextPop
namespace ScopedC.DyadicAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.DyadicPairFrames (InputI)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  sa : Generated.f_sa∈code
  na : Generated.f_na∈code
  ns : Generated.f_ns∈code
  nle : Generated.f_nle∈code
  smake : Generated.f_smake∈code
  nz : Generated.f_nz∈code
  nu : Generated.f_nu∈code
  ne : Generated.f_ne∈code
  keep : Generated.f_keep∈code

def step (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Endpoint) : Cursor :=
  next l (next l c (SignedAddCalls.magnitude a b)) 0

def sumOutput (c : Cursor) (a b : Endpoint) : Endpoint :=
  ⟨c.state.nats.values.length,SignedAddCalls.magnitude a b,
    if SignedAddCalls.magnitude a b=0 then false else SignedAddCalls.negative a b⟩

theorem sum_source (c : Cursor) (a b : Endpoint) :
    (sumOutput c a b).source=SignedAddCalls.result c.state a b := by
  by_cases hz : SignedAddCalls.magnitude a b=0 <;>
    simp [sumOutput,Endpoint.source,SignedAddCalls.result,SignedAddCalls.resultSign,hz,SignedNegCalls.bit]

theorem sum_math (c : Cursor) (a b : Endpoint) :
    (sumOutput c a b).mathematical=Signed.add a.mathematical b.mathematical := by
  have h : (sumOutput c a b).mathematical=Signed.make (SignedAddCalls.magnitude a b) (SignedAddCalls.negative a b) := rfl
  exact h.trans (SignedAddCalls.mathematical a b)

theorem sum_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Endpoint) :
    (sumOutput c a b).Live (step l c a b).state :=
  PoolCursor.preserves (PoolCursor.next_borrow l c (SignedAddCalls.magnitude a b))

theorem sum_call (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+1<PoolCalls.capacity)
    (a b : Endpoint) (ha : a.Live c.state) (hb : b.Live c.state) :
    SourceCall Header.layout code 5 "sa" [a.source,b.source] c.state
      (sumOutput c a b).source (step l c a b).state := by
  rw[sum_source]
  exact SignedAddCalls.sa_closed code lib.sa lib.na lib.ns lib.nle lib.smake lib.nz lib.nu lib.ne lib.keep a b ha hb ctx room

def base (c : Cursor) (a b : InputI) : Cursor := DyadicPairFrames.framed c a b
def middle (l : PoolCalls.PoolLayout) (c : Cursor) (a b : InputI) : Cursor := step l (base c a b) a.lo b.lo
def finish (l : PoolCalls.PoolLayout) (c : Cursor) (a b : InputI) : Cursor := step l (middle l c a b) a.hi b.hi
def after (l : PoolCalls.PoolLayout) (c : Cursor) (a b : InputI) : Cursor := PoolContextPop.unframe c.state (finish l c a b)
def low (c : Cursor) (a b : InputI) : Endpoint := sumOutput (base c a b) a.lo b.lo
def high (l : PoolCalls.PoolLayout) (c : Cursor) (a b : InputI) : Endpoint := sumOutput (middle l c a b) a.hi b.hi
def result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : InputI) : Value :=
  DyadicCasts.value (low c a b).source (high l c a b).source (a.ok&&b.ok)

theorem middle_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+3<PoolCalls.capacity) (a b : InputI) : Valid l (middle l c a b) :=
  next_valid 0 (next_valid _ (CursorFrames.framed_valid ctx "I" "a" a.source "I" "b" b.source) (by change c.top<PoolCalls.capacity;omega))
    (by change c.top+1<PoolCalls.capacity;omega)

theorem finish_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+3<PoolCalls.capacity) (a b : InputI) : Valid l (finish l c a b) :=
  next_valid 0 (next_valid _ (middle_valid ctx room a b) (by change c.top+2<PoolCalls.capacity;omega))
    (by change c.top+3<PoolCalls.capacity;omega)

theorem after_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+3<PoolCalls.capacity) (a b : InputI) : Valid l (after l c a b) :=
  PoolContextPop.valid (finish_valid ctx room a b)
    ((List.getElem?_eq_some_iff.mp ctx.pool_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.top_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.high_read).choose)

theorem middle_a_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : InputI) :
    LocalBinding.At (middle l c a b).state "a" "I" a.source c.state.heap.length := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.advance (c:=base c a b) (DyadicPairFrames.a_at c.state a b)
    [SignedAddCalls.magnitude a.lo b.lo,0] (by omega) (by omega) (by omega)

theorem middle_b_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : InputI) :
    LocalBinding.At (middle l c a b).state "b" "I" b.source (c.state.heap.length+1) := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.advance (c:=base c a b) (DyadicPairFrames.b_at c.state a b)
    [SignedAddCalls.magnitude a.lo b.lo,0] (by omega) (by omega) (by omega)

theorem final_a_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : InputI) :
    LocalBinding.At (finish l c a b).state "a" "I" a.source c.state.heap.length := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.advance (c:=base c a b) (DyadicPairFrames.a_at c.state a b)
    [SignedAddCalls.magnitude a.lo b.lo,0,SignedAddCalls.magnitude a.hi b.hi,0] (by omega) (by omega) (by omega)

theorem final_b_at {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : InputI) :
    LocalBinding.At (finish l c a b).state "b" "I" b.source (c.state.heap.length+1) := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  exact LocalBinding.advance (c:=base c a b) (DyadicPairFrames.b_at c.state a b)
    [SignedAddCalls.magnitude a.lo b.lo,0,SignedAddCalls.magnitude a.hi b.hi,0] (by omega) (by omega) (by omega)
end ScopedC.DyadicAddCalls
