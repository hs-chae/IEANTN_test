/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedDecimalCompletion
namespace ScopedC.NamedPiBody
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def rational : LeanCert.Core.IntervalRat :=
  ⟨31415926535897932/10000000000000000,31415926535897933/10000000000000000,by norm_num⟩

/-- Actual unchanged named(0) source body, with both decimal parsers, both qm
normalizers, field writes, branch scopes and final directed rounding closed. -/
theorem named_pi_closed (code : List Function) (installed : Generated.f_named∈code)
    (decimal : RationalDecimalLiteral.Library code) (lib : NamedDecimalCompletion.Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) {object valueSlot : Nat}
    (scale : SourceFromS.ScaleAt c.state object valueSlot (2^100))
    (room : c.top+400<capacity) :
    ∃out : Cursor, ∃lo hi : Endpoint,
      SourceCall Header.layout code 9 "named" [NatWrapperCalls.unsigned32 0]
        c.state (DyadicCasts.value lo.source hi.source true) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (LeanCert.Core.IntervalDyadic.ofIntervalRat rational (-100),true) := by
  let start := NamedFrames.initial c 0
  have startValid : Valid l start := NamedFrames.initial_valid ctx 0
  have record := NamedFrames.r_binding c 0
  have sourceScale : SourceFromS.ScaleAt start.state object valueSlot (2^100) := NamedFrames.scale scale 0
  have nlLength : (DecimalText.digits 31415926535897932).length=17 := by decide +kernel
  have nhLength : (DecimalText.digits 31415926535897933).length=17 := by decide +kernel
  have denLength : (DecimalText.digits 10000000000000000).length=17 := by decide +kernel
  have initialRoom : start.top+60+4*(DecimalText.digits 31415926535897932).length+
      4*(DecimalText.digits 31415926535897933).length+
      8*(DecimalText.digits 10000000000000000).length<capacity := by
    rw [nlLength,nhLength,denLength]
    change c.top+60+4*17+4*17+8*17<capacity
    omega
  obtain ⟨D⟩ := NamedDecimalPair.stages_exist code decimal startValid record
    31415926535897932 31415926535897933 10000000000000000 (by decide +kernel) initialRoom
  obtain ⟨service,raw,lo,hi,closed,branch,returnExpr,rawValid,loLive,hiLive,decoded⟩ :=
    NamedDecimalCompletion.complete code lib D startValid record sourceScale (by decide +kernel) initialRoom
  have test := NamedFrames.condition service c 0 (by decide +kernel)
  have piBranch : Run Header.layout service
      (.branch (.binary "==" (.var "c") (.nat 0))
        (.sequence (NamedDecimalBranch.statements 31415926535897932 31415926535897933 10000000000000000))
        (.sequence [
          .eval (.binary "=" (.field "." (.var "r") "lo") (RationalUnsignedRatio.initializer 5722 10000)),
          .eval (.binary "=" (.field "." (.var "r") "hi") (RationalUnsignedRatio.initializer 5823 10000))]))
      start.state (.continuing (NamedDecimalBranch.after D).state) := by
    apply Loops.StmtRun.branch test
    change Run Header.layout service
      (.sequence (NamedDecimalBranch.statements 31415926535897932 31415926535897933 10000000000000000))
      start.state (.continuing (NamedDecimalBranch.after D).state)
    exact branch
  have body : Run Header.layout service Generated.f_named.body (NamedFrames.parameters c.state 0)
      (.returned (popScope (NamedFrames.parameters c.state 0) raw.state)
        (DyadicCasts.value lo.source hi.source true)) := by
    rw [NamedFrames.actual_declaration]
    exact Loops.StmtRun.sequence
      (Loops.SeqRun.next (Loops.StmtRun.declare (NamedFrames.declaration service c 0))
        (Loops.SeqRun.next piBranch
          (Loops.SeqRun.returned (Loops.StmtRun.returnValue ⟨1000,returnExpr⟩)))) ⟨rfl,rfl⟩
  have arguments : bindArgs Header.layout Generated.f_named.parameters [NatWrapperCalls.unsigned32 0] c.state=
      some (NamedFrames.parameters c.state 0) :=
    TypedFrames.bind_one Header.layout c.state "unsigned int" "c" _ _
      (PositiveCasts.cast_unsigned {c.state with env:=[]} 99 0 (by decide +kernel))
  let out := PoolContextPop.unframe c.state raw
  have source : SourceCall Header.layout code 9 "named" [NatWrapperCalls.unsigned32 0]
      c.state (DyadicCasts.value lo.source hi.source true) out.state := by
    apply installed_body (f:=Generated.f_named) (rank:=8) (service:=service) installed closed arguments body
    constructor
    · exact DyadicCasts.record _ 97 "static I" (by decide +kernel) lo.source hi.source true
        (Endpoint.cast 97 "S" (by decide +kernel) loLive)
        (Endpoint.cast 97 "S" (by decide +kernel) hiLive)
    · change popScope c.state raw.state=popScope c.state
        (popScope (NamedFrames.parameters c.state 0) raw.state)
      rw [SourceFromS.scope_twice c.state (NamedFrames.parameters c.state 0) raw.state
        (by simp [NamedFrames.parameters,OneFrames.frame,allocate])]
  have outValid : Valid l out := PoolContextPop.valid rawValid
    (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
    (List.getElem?_eq_some_iff.mp ctx.top_read).choose
    (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  refine ⟨out,lo,hi,source,outValid,loLive,hiLive,?_⟩
  change DyadicRepresentation.interval raw.state (DyadicCasts.value lo.source hi.source true)=_
  simpa only [NamedDecimalPair.input,rational,D.low.value,D.high.value,Nat.cast_ofNat] using decoded

#print axioms named_pi_closed
end ScopedC.NamedPiBody
