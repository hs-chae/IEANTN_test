/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedUnsignedBranch
import ScopedC.NamedDecimalCompletion
namespace ScopedC.NamedUnsignedCompletion
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.NamedUnsignedPair ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

abbrev Library := NamedDecimalCompletion.Library

/-- Sequential actual qi/qi/qv endpoint producers, physical stores, source
branch-scope exit and literal-one fromRI return, with exact old rounding. -/
theorem complete (code : List Function) (lib : Library code)
    {l : PoolLayout} {c : Cursor} {nl nh den slot object valueSlot : Nat}
    {oldLo oldHi : Value} (D : Stages code l c nl nh den slot oldHi)
    (ctx : Valid l c) (record : RationalRecordFields.At c.state oldLo oldHi slot)
    (scale : SourceFromS.ScaleAt c.state object valueSlot (2^100)) (ascending : nl ≤ nh)
    (nlo : nl<2^31) (nhi : nh<2^31) (db : den<2^31) (room : c.top+90<capacity) :
    ∃service : Call, ∃out : Cursor, ∃lo hi : Endpoint,
      (∀name args before value after, service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      Run Header.layout service (.sequence (NamedUnsignedBranch.statements nl nh den)) c.state
        (.continuing (NamedUnsignedBranch.after D).state) ∧
      evalExpr Header.layout service 1000 (NamedUnsignedBranch.after D).state
        (.call (.var "fromRI") [.var "r",.nat 1])=
        some (DyadicCasts.value lo.source hi.source true,out.state) ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (LeanCert.Core.IntervalDyadic.ofIntervalRat
          ⟨(input D).lo.mathematical.value,(input D).hi.mathematical.value,
            NamedUnsignedBranch.ordered D ascending⟩ (-100),true) := by
  have lowRoom : c.top+18<capacity := by omega
  have lowTop := RationalUnsignedRatio.top_bound ctx nl den lowRoom
  have highRoom : (middle D).top+18<capacity := by
    change (RationalUnsignedRatio.after l c nl den).top+18<capacity
    omega
  have physical := NamedUnsignedBranch.result D ctx record lowRoom highRoom
  have sourceScale := NamedUnsignedBranch.scale D ctx record lowRoom highRoom scale
  have finalTop := NamedUnsignedPair.top_bound D ctx record room
  have fromRoom : (NamedUnsignedBranch.after D).top+37<capacity := by
    change (finish D).top+37<capacity
    omega
  obtain ⟨out,lo,hi,fromCall,outValid,loLive,hiLive,decoded⟩ :=
    SourceFromRIArguments.literal_one_math (l:=l) (c:=NamedUnsignedBranch.after D)
      code lib.fromRI lib.qt lib.floorQ lib.ceilQ lib.qn lib.sn lib.multiply lib.round
      physical.1 (input D) sourceScale physical.2.2 D.low.positive D.high.positive
      (NamedUnsignedBranch.ordered D ascending) fromRoom
  let last : CallEvents.Event Header.layout code 8 :=
    ⟨"fromRI",[(input D).source,DecimalDigits.integer 1],(NamedUnsignedBranch.after D).state,
      DyadicCasts.value lo.source hi.source true,out.state,fromCall⟩
  obtain ⟨service,closed,lowExpr,highExpr,answer⟩ :=
    NamedUnsignedService.source_expressions D ctx record room nlo nhi db last rfl
  have branch := NamedUnsignedBranch.run service D ctx record lowRoom highRoom lowExpr highExpr
  have readR := RationalRecordFields.read_ri service 998 (input D) physical.2.1
  have literal := RationalUnsignedRatio.literal service (NamedUnsignedBranch.after D).state 998 1
    (by decide +kernel)
  have returnExpr := ExpressionTemplates.call_two Header.layout service readR literal answer
  exact ⟨service,out,lo,hi,closed,branch,returnExpr,outValid,loLive,hiLive,decoded⟩

#print axioms complete
end ScopedC.NamedUnsignedCompletion
