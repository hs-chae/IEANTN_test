/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalUnsignedRatio
import ScopedC.ExpressionTemplates
import ScopedC.CallEventService
import ScopedC.SourceRanks
namespace ScopedC.RationalUnsignedRatio
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def initializer (n d : Nat) : Syntax.Expr :=
  .call (.var "qv") [.call (.var "qi") [.nat n],.call (.var "qi") [.nat d]]

theorem literal (service : Call) (s : State) (fuel n : Nat) (bound : n<2^31) :
    evalExpr Header.layout service (fuel+1) s (.nat n)=some (DecimalDigits.integer n,s) := by
  have range : Scalar.InRange ⟨true,32⟩ (n:Int) := by
    simp only [Scalar.InRange,Scalar.lower,Scalar.upper,Scalar.modulus,
      Bool.true_eq_false,↓reduceIte]
    norm_num
    exact bound
  simp [evalExpr,Scalar.checked,range,DecimalDigits.integer]

theorem expression (service : Call) {code : List Function} {l : PoolLayout} {c : Cursor}
    {n d : Nat} (D : Stages code l c n d) (nb : n<2^31) (db : d<2^31)
    (num : service "qi" [DecimalDigits.integer n] c.state=
      some ((numInput l c n).source,(numerator l c n).state))
    (den : service "qi" [DecimalDigits.integer d] (numerator l c n).state=
      some ((denInput l c n d).source,(denominator l c n d).state))
    (div : service "qv" [(numInput l c n).source,(denInput l c n d).source]
      (denominator l c n d).state=some (D.output.source,(after l c n d).state)) :
    evalExpr Header.layout service 1000 c.state (initializer n d)=
      some (D.output.source,(after l c n d).state) := by
  have first := ExpressionTemplates.call_one Header.layout service
    (literal service c.state 997 n nb) num
  have second := ExpressionTemplates.call_one Header.layout service
    (literal service (numerator l c n).state 997 d db) den
  exact ExpressionTemplates.call_two Header.layout service first second div

theorem source_expression {code : List Function} {l : PoolLayout} {c : Cursor}
    {n d : Nat} (D : Stages code l c n d) (nb : n<2^31) (db : d<2^31) :
    ∃service : Call,
      (∀name args before result final, service name args before=some (result,final) →
        SourceCall Header.layout code 7 name args before result final) ∧
      evalExpr Header.layout service 1000 c.state (initializer n d)=
        some (D.output.source,(after l c n d).state) := by
  let e0 : CallEvents.Event Header.layout code 7 :=
    ⟨"qi",[DecimalDigits.integer n],c.state,(numInput l c n).source,(numerator l c n).state,
      SourceRanks.monotone (by omega : 6≤7) D.numeratorCall⟩
  let e1 : CallEvents.Event Header.layout code 7 :=
    ⟨"qi",[DecimalDigits.integer d],(numerator l c n).state,
      (denInput l c n d).source,(denominator l c n d).state,
      SourceRanks.monotone (by omega : 6≤7) D.denominatorCall⟩
  let e2 : CallEvents.Event Header.layout code 7 :=
    ⟨"qv",[(numInput l c n).source,(denInput l c n d).source],
      (denominator l c n d).state,D.output.source,(after l c n d).state,D.divideCall⟩
  let events := [e0,e1,e2]
  have unique : (CallEvents.counts events).Nodup := by
    change [c.state.nats.values.length,(numerator l c n).state.nats.values.length,
      (denominator l c n d).state.nats.values.length].Nodup
    simp only [numerator,denominator,RationalUnsignedTrace.after,
      CursorFrames.advance,PoolCursor.size]
    simp only [List.nodup_cons,List.mem_cons,List.mem_singleton,List.not_mem_nil,
      not_false_eq_true,List.nodup_nil,and_true]
    constructor
    · rintro (same | same | impossible) <;> omega
    · rintro (same | impossible) <;> omega
  let service := CallEvents.service events
  refine ⟨service,fun _ _ _ _ _ h=>CallEvents.service_closed events h,?_⟩
  apply expression service D nb db
  · exact CallEvents.service_self events unique e0 (by simp [events])
  · exact CallEvents.service_self events unique e1 (by simp [events])
  · exact CallEvents.service_self events unique e2 (by simp [events])

end ScopedC.RationalUnsignedRatio
