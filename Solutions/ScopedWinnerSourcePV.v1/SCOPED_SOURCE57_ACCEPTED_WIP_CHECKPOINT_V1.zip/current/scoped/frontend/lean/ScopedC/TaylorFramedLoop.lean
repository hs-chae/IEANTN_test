/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorPhysicalEffects
namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure FramedLoopCertificate (code : List Function) {l : PoolCalls.PoolLayout}
    {base : Address} {coeffs : List Input} (start : Frame l base coeffs)
    extends LoopCertificate code start where
  borrows : ∀slot value,NatArena.Borrow start.cursor.state.nats slot value →
    NatArena.Borrow finish.cursor.state.nats slot value
  globals : finish.cursor.state.globals=start.cursor.state.globals
  slots : finish.kSlot=start.kSlot ∧ finish.rSlot=start.rSlot
  other : ∀slot,slot<start.cursor.state.heap.length → slot≠start.kSlot → slot≠start.rSlot →
    slot≠l.pool → slot≠l.top → slot≠l.high →
    finish.cursor.state.heap[slot]?=start.cursor.state.heap[slot]?

/-- Complete source Horner while-loop, with the existing exact rational
interval fold as its invariant and actual source executions at every call. -/
theorem loop_framed_certificate (code : List Function) (lib : Library code) (k : Nat)
    {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input} (f : Frame l base coeffs)
    (counterEq : f.k=k)
    (invariant : mathematical f=LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop f.k)) (original f))
    (room : f.cursor.top+108*k ≤ PoolCalls.capacity) : Nonempty (FramedLoopCertificate code f) := by
  induction k generalizing f with
  | zero =>
    refine ⟨{
      finish:=f
      events:=[]
      unique:=by simp
      bounds:=by simp
      event_shape:=by simp
      nats_le:=Nat.le_refl _
      execution:=?_
      stopped:=counterEq
      original_eq:=rfl
      mathematical_eq:=by simpa only[counterEq,List.drop_zero] using invariant
      top_le:=by omega
      shape:=⟨rfl,rfl⟩
      borrows:=fun _ _ h=>h
      globals:=rfl
      slots:=⟨rfl,rfl⟩
      other:=by intros;rfl
    }⟩
    intro service _
    exact Loops.WhileRun.done (condition_eval service f)
      (by simp [UnsignedLiteralControl.truth_boolean,counterEq])
  | succ k ih =>
    have positive : 0<f.k := by omega
    have stepRoom : f.cursor.top+107<PoolCalls.capacity := by omega
    let next:=iteration f positive stepRoom
    have nextK : next.k=k := by rw[iteration_k,counterEq];omega
    have nextInvariant : mathematical next=LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop next.k)) (original next) := by
      rw[show next.k=f.k-1 from iteration_k f positive stepRoom,
        show original next=original f from iteration_original f positive stepRoom]
      exact iteration_math f positive stepRoom invariant
    have nextRoom : next.cursor.top+108*k ≤ PoolCalls.capacity := by
      change (iteration f positive stepRoom).cursor.top+108*k ≤ PoolCalls.capacity
      rw[iteration_top]
      omega
    obtain ⟨tail⟩:=ih next nextK nextInvariant nextRoom
    have nle : f.cursor.state.nats.values.length ≤ next.cursor.state.nats.values.length := by
      dsimp only[next]
      rw[iteration_size]
      omega
    let front:=iterationEvents code lib f positive stepRoom
    refine ⟨{
      finish:=tail.finish
      events:=front++tail.events
      unique:=?_
      bounds:=?_
      event_shape:=?_
      nats_le:=nle.trans tail.nats_le
      execution:=?_
      stopped:=tail.stopped
      original_eq:=tail.original_eq.trans (iteration_original f positive stepRoom)
      mathematical_eq:=?_
      top_le:=?_
      shape:=?_
      borrows:=?_
      globals:=?_
      slots:=?_
      other:=?_
    }⟩
    · rw[List.map_append,List.nodup_append]
      refine ⟨iteration_unique code lib f positive stepRoom,tail.unique,?_⟩
      intro a ha b hb same
      obtain ⟨ea,hea,ka⟩:=List.mem_map.mp ha
      obtain ⟨eb,heb,kb⟩:=List.mem_map.mp hb
      have keyEq:=congrArg Prod.fst (ka.trans (same.trans kb.symm))
      change ea.before.nats.values.length=eb.before.nats.values.length at keyEq
      have leftBound:=iteration_bounds code lib f positive stepRoom ea hea
      have rightBound:=tail.bounds eb heb
      dsimp only[next] at rightBound
      omega
    · intro e member
      rcases List.mem_append.mp member with frontMember | tailMember
      · have h:=iteration_bounds code lib f positive stepRoom e frontMember
        exact ⟨h.1,Nat.lt_of_lt_of_le h.2 tail.nats_le⟩
      · have h:=tail.bounds e tailMember
        exact ⟨nle.trans h.1,h.2⟩
    · intro e member
      rcases List.mem_append.mp member with frontMember | tailMember
      · exact iteration_event_shape code lib f positive stepRoom e frontMember
      · have h:=tail.event_shape e tailMember
        have shape:=iteration_shape f positive stepRoom
        exact ⟨h.1.trans shape.1,h.2.trans shape.2⟩
    · intro service answers
      exact Loops.WhileRun.next (condition_eval service f)
        (by simp [UnsignedLiteralControl.truth_boolean,positive])
        (iteration_run code lib f positive stepRoom service (fun e h=>answers e (List.mem_append_left _ h)))
        (tail.execution service (fun e h=>answers e (List.mem_append_right _ h)))
    · rw[tail.mathematical_eq,show original next=original f from iteration_original f positive stepRoom]
    · have h:=tail.top_le
      change tail.finish.cursor.top ≤ next.cursor.top+108*next.k at h
      rw[nextK,show next.cursor.top=f.cursor.top+108 from iteration_top f positive stepRoom] at h
      rw[counterEq]
      omega
    · have h:=iteration_shape f positive stepRoom
      exact ⟨tail.shape.1.trans h.1,tail.shape.2.trans h.2⟩

    · intro slot value live
      exact tail.borrows slot value (iteration_borrow f positive stepRoom live)
    · exact tail.globals.trans (iteration_globals f positive stepRoom)
    · have slots:=iteration_slots f positive stepRoom
      exact ⟨tail.slots.1.trans slots.1,tail.slots.2.trans slots.2⟩
    · intro slot bound kApart rApart hp ht hh
      have nextBound : slot<next.cursor.state.heap.length := by
        rw[(iteration_shape f positive stepRoom).1]
        exact bound
      have slots:=iteration_slots f positive stepRoom
      have after:=tail.other slot nextBound (by rw[slots.1];exact kApart)
        (by rw[slots.2];exact rApart) hp ht hh
      exact after.trans (iteration_other f positive stepRoom slot bound kApart rApart hp ht hh)

end ScopedC.TaylorCalls
