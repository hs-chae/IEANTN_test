/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhPower
import ScopedC.RationalSubOutput

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

structure NarrowLibrary (code : List Function) : Prop where
  guard : GuardLibrary code
  qpow : Generated.f_qpow∈code
  qs : Generated.f_qs∈code
  subtraction : RationalSubCalls.Library code

def denOne {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
    {d : Nat} (stage : PowerStage code l c q d) : Input :=
  RationalUnsignedTrace.output l stage.out 1

def denStart {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
    {d : Nat} (stage : PowerStage code l c q d) : Cursor :=
  RationalUnsignedTrace.after l stage.out 1

noncomputable def denominator {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
    {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) : Input :=
  RationalSubCalls.outputInput l (denStart stage) (denOne stage) (absInput q)
    (by change 0<(1:Nat);decide +kernel) positive

def denCursor {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input}
    {d : Nat} (stage : PowerStage code l c q d) : Cursor :=
  RationalSubCalls.after l (denStart stage) (denOne stage) (absInput q)

theorem den_start_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d)
    (room : c.top+750<PoolCalls.capacity) : Valid l (denStart stage) := by
  apply CursorFrames.advance_valid stage.valid [1,0,1]
  have top:=stage.top
  rw[guard_top] at top
  change stage.out.top+3≤PoolCalls.capacity
  omega

theorem den_one_source (code : List Function) (lib : NarrowLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} {d : Nat}
    (stage : PowerStage code l c q d) (room : c.top+750<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1] stage.out.state
      (denOne stage).source (denStart stage).state := by
  have top:=stage.top
  rw[guard_top] at top
  exact (RationalUnsignedTrace.qi_traced code lib.guard.powers.qi lib.guard.powers.si
    lib.guard.absolute.smake lib.guard.absolute.nz lib.guard.absolute.nu lib.guard.absolute.ne
    lib.guard.absolute.keep stage.valid 1 (by decide +kernel) (by omega)
    (DecimalDigits.integer 1) (by rfl)).1

theorem den_source (code : List Function) (lib : NarrowLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {q : Input} {d : Nat}
    (stage : PowerStage code l c q d) (alive : q.Live c.state)
    (positive : 0<q.denominator) (room : c.top+750<PoolCalls.capacity) :
    SourceCall Header.layout code 7 "qs" [(denOne stage).source,(absInput q).source]
      (denStart stage).state (denominator stage positive).source (denCursor stage).state := by
  have rBefore:=r_guard_live (l:=l) q alive
  have rAfter : (absInput q).Live stage.out.state :=
    ⟨stage.preserves _ _ rBefore.1,stage.preserves _ _ rBefore.2⟩
  have rLive : (absInput q).Live (denStart stage).state :=
    ⟨CursorBorrow.preserves (l:=l) (c:=stage.out) [1,0,1] rAfter.1,
      CursorBorrow.preserves (l:=l) (c:=stage.out) [1,0,1] rAfter.2⟩
  have top:=stage.top
  rw[guard_top] at top
  exact RationalSubCalls.output_source code lib.qs lib.subtraction (den_start_valid stage room)
    (by change stage.out.top+3+14<PoolCalls.capacity;omega) (denOne stage) (absInput q)
    (RationalUnsignedTrace.live l stage.out 1) rLive
    (by change 0<(1:Nat);decide +kernel) positive

theorem denominator_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator) :
    (denominator stage positive).mathematical.value=1-|q.mathematical.value| := by
  have raw:=(RationalSubCalls.output_spec l (denStart stage) (denOne stage) (absInput q)
    (by change 0<(1:Nat);decide +kernel) positive).2.2.1
  have one : (denOne stage).mathematical.value=(1:Rat):=
    (RationalUnsignedTrace.mathematical l stage.out 1).1
  exact raw.trans (by
    rw[one]
    exact congrArg (fun x:Rat=>1-x) (RationalAbsApplicability.value q))

theorem denominator_nonzero {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} {d : Nat} (stage : PowerStage code l c q d) (positive : 0<q.denominator)
    (narrow : |q.mathematical.value|<1) :
    (denominator stage positive).numerator.magnitude≠0 := by
  intro zero
  have value:=denominator_value stage positive
  have nil : (denominator stage positive).mathematical.value=0 := by
    simp [Input.mathematical,DyadicRepresentation.Endpoint.mathematical,
      ScopedNumerical.Rational.value,ScopedNumerical.Signed.value,zero]
  rw[nil] at value
  linarith

end ScopedC.AtanhCalls
