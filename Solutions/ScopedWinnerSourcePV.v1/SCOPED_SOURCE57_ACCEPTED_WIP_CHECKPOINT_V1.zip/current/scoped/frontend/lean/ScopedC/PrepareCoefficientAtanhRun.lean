/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientWritten

namespace ScopedC.PrepareSource.CoeffWork
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

/-- Only source calls actually selected by the original parity conditional
are required. Later finite events supply every selected answer from a proved
lower-rank actual source execution. -/
structure AtanhAnswers (service : Call) {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} (w : CoeffWork l object d eb ab)
    (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k) : Prop where
  one : w.k%2=1 → service "qi" [DecimalDigits.integer 1] w.cursor.state=
    some ((w.qiInput 1).source,(w.oddOne room).cursor.state)
  counter : w.k%2=1 → service "qi" [PoolCalls.word w.k] (w.oddOne room).cursor.state=
    some (((w.oddOne room).qiInput w.k).source,(w.oddCounter room).cursor.state)
  divide : w.k%2=1 → service "qv" [(w.qiInput 1).source,((w.oddOne room).qiInput w.k).source]
    (w.oddCounter room).cursor.state=
    some ((w.oddInput room).source,(w.oddWork room positive).cursor.state)
  zero : w.k%2≠1 → service "qi" [DecimalDigits.integer 0] w.cursor.state=
    some ((w.qiInput 0).source,(w.qiWork 0 (by omega)).cursor.state)

theorem atanhWritten_eval (service : Call) {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} (w : CoeffWork l object d eb ab)
    (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (length : w.atanhCoeffs.length=w.k) (bound : w.atanhCoeffs.length<65) (kb : w.k<2^32)
    (answers : AtanhAnswers service w room positive) :
    ∃v,Eval Header.layout service atanhAssignment w.cursor.state
      (w.atanhWritten room positive bound).cursor.state v := by
  unfold atanhWritten
  split
  · rename_i odd
    exact ⟨_,odd_assignment service w room positive length bound kb odd
      (answers.one odd) (answers.counter odd) (answers.divide odd)⟩
  · rename_i even
    exact ⟨_,even_assignment service w _ length bound kb even (answers.zero even)⟩

end ScopedC.PrepareSource.CoeffWork
