/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceIntervalGlobal

namespace ScopedC.SourceScalarGlobal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem different_objects {s : State} {name type targetName targetType : String}
    {object target : Nat} {value old : Option Value} (h : At s name type object value)
    (written : At s targetName targetType target old) (different : type≠targetType) : object≠target := by
  intro same
  have storage:=h.storage
  simp only[same,written.storage] at storage
  have types:=congrArg (fun x : Option Object=>x.map Object.type) storage
  change some targetType=some type at types
  exact different (Option.some.inj types).symm

theorem scalar_store {s : State} {name type targetName targetType : String}
    {object target : Nat} {value old : Option Value} (h : At s name type object value)
    (written : At s targetName targetType target old) (different : type≠targetType) (new : Value) :
    At (LocalAssignment.changed s target targetType new) name type object value :=
  memory h rfl (List.getElem?_set_ne (Ne.symm (different_objects h written different)))

end ScopedC.SourceScalarGlobal
namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false

def scalar_store {s : State} {base : Address} {coeffs : List RationalPairFrames.Input}
    (table : TableAt s base coeffs) {name type : String} {object : Nat} {old : Option Value}
    (written : SourceScalarGlobal.At s name type object old) (new : Value) :
    TableAt (LocalAssignment.changed s object type new) base coeffs := by
  have different:=scalar_separated table written.storage
  exact memory table (List.getElem?_set_ne (Ne.symm different)) (fun _ _ h=>h)

end ScopedC.CoefficientTableRead
