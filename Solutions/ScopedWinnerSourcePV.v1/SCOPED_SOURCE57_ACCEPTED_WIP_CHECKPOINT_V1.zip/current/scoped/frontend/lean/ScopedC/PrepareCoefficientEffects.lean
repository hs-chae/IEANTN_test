/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientWritten
import ScopedC.RationalDivideTrace

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

theorem nonzeroDivision_size {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (room : c.top+12<PoolCalls.capacity) (a b : Input) :
    (RationalDivideCalls.nonzeroAfter l c a b).state.nats.values.length=c.state.nats.values.length+13 := by
  rw[RationalDivideTrace.nonzero_advance ctx room,CursorEffects.size]
  rfl

theorem expWork_shape {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) (active : f.k ≤ d) :
    (expWork f room active).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (expWork f room active).cursor.state.env=f.cursor.state.env := by
  change (expStoreCursor f room).state.heap.length=_ ∧ (expStoreCursor f room).state.env=_
  unfold expStoreCursor
  constructor
  · change ((expDivideCursor f).state.heap.set eb.object _).length=_
    rw[List.length_set,expDivide_nonzero,RationalDivideCalls.nonzero_heap_length]
    exact (CursorEffects.shape l f.cursor [f.k,0,1]).1
  · exact expDivide_env f

theorem expWork_size {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) (active : f.k ≤ d) :
    (expWork f room active).cursor.state.nats.values.length=f.cursor.state.nats.values.length+16 := by
  change (expStoreCursor f room).state.nats.values.length=_
  unfold expStoreCursor
  change (expDivideCursor f).state.nats.values.length=_
  rw[expDivide_nonzero,nonzeroDivision_size (counterQ_valid f room)
    (by change f.cursor.top+3+12<PoolCalls.capacity;omega)]
  change (CursorFrames.advance l f.cursor [f.k,0,1]).state.nats.values.length+13=_
  rw[CursorEffects.size]
  rfl

namespace CoeffWork

theorem oddStored_shape {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) :
    (w.oddStored room positive bound).cursor.state.heap.length=w.cursor.state.heap.length ∧
    (w.oddStored room positive bound).cursor.state.env=w.cursor.state.env := by
  constructor
  · change ((RationalDivideCalls.nonzeroAfter l (w.oddCounter room).cursor (w.qiInput 1)
      ((w.oddOne room).qiInput w.k)).state.heap.set ab.object _).length=_
    rw[List.length_set,RationalDivideCalls.nonzero_heap_length]
    exact ((CursorEffects.shape l (w.oddOne room).cursor [w.k,0,1]).1).trans
      (CursorEffects.shape l w.cursor [1,0,1]).1
  · change (RationalDivideCalls.nonzeroAfter l (w.oddCounter room).cursor (w.qiInput 1)
      ((w.oddOne room).qiInput w.k)).state.env=_
    rw[RationalDivideCalls.nonzero_env]
    exact ((CursorEffects.shape l (w.oddOne room).cursor [w.k,0,1]).2).trans
      (CursorEffects.shape l w.cursor [1,0,1]).2

theorem evenStored_shape {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+2<PoolCalls.capacity)
    (bound : w.atanhCoeffs.length<65) :
    (w.evenStored room bound).cursor.state.heap.length=w.cursor.state.heap.length ∧
    (w.evenStored room bound).cursor.state.env=w.cursor.state.env := by
  constructor
  · change ((w.qiWork 0 room).cursor.state.heap.set ab.object _).length=_
    rw[List.length_set]
    exact (CursorEffects.shape l w.cursor [0,0,1]).1
  · exact (CursorEffects.shape l w.cursor [0,0,1]).2

theorem atanhWritten_shape {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) :
    (w.atanhWritten room positive bound).cursor.state.heap.length=w.cursor.state.heap.length ∧
    (w.atanhWritten room positive bound).cursor.state.env=w.cursor.state.env := by
  unfold atanhWritten
  split
  · exact oddStored_shape w room positive bound
  · exact evenStored_shape w _ bound

theorem atanhWritten_top {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) :
    (w.atanhWritten room positive bound).cursor.top ≤ w.cursor.top+19 := by
  unfold atanhWritten
  split
  · change (RationalDivideCalls.nonzeroAfter l (w.oddCounter room).cursor (w.qiInput 1)
      ((w.oddOne room).qiInput w.k)).top ≤ w.cursor.top+19
    rw[RationalDivideCalls.nonzero_top]
    change w.cursor.top+6+13 ≤ w.cursor.top+19
    omega
  · change w.cursor.top+3 ≤ w.cursor.top+19
    omega

theorem atanhWritten_size {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) :
    (w.atanhWritten room positive bound).cursor.state.nats.values.length=
      w.cursor.state.nats.values.length+(if w.k%2=1 then 19 else 3) := by
  unfold atanhWritten
  split
  · rename_i odd
    change (RationalDivideCalls.nonzeroAfter l (w.oddCounter room).cursor (w.qiInput 1)
      ((w.oddOne room).qiInput w.k)).state.nats.values.length=_
    rw[nonzeroDivision_size (w.oddCounter room).context
      (by change w.cursor.top+6+12<PoolCalls.capacity;omega)]
    change (CursorFrames.advance l (w.oddOne room).cursor [w.k,0,1]).state.nats.values.length+13=_
    rw[CursorEffects.size]
    change (CursorFrames.advance l w.cursor [1,0,1]).state.nats.values.length+3+13=_
    rw[CursorEffects.size]
    rfl
  · rename_i even
    change (CursorFrames.advance l w.cursor [0,0,1]).state.nats.values.length=_
    rw[CursorEffects.size]
    rfl

end CoeffWork
end ScopedC.PrepareSource
