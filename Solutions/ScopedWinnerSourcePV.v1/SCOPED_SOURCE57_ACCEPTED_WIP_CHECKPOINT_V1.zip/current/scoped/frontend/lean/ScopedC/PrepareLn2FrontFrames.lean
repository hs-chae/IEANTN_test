/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareLn2Front

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

def afterThreeTable {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) {base : Address} {coeffs : List RationalPairFrames.Input}
    (table : CoefficientTableRead.TableAt c.state base coeffs) :
    CoefficientTableRead.TableAt (afterThree l c).state base coeffs :=
  CoefficientTableRead.advanced (afterOne_valid ctx room)
    (CoefficientTableRead.advanced (afterTwo_valid ctx room)
      (CoefficientTableRead.advanced ctx table [2,0,1]) [1,0,1]) [3,0,1]

def beforeAtanhTable {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) {base : Address} {coeffs : List RationalPairFrames.Input}
    (table : CoefficientTableRead.TableAt c.state base coeffs) :
    CoefficientTableRead.TableAt (beforeAtanh l c).state base coeffs := by
  let first:=afterThreeTable ctx room table
  have safe:=CoefficientTableRead.pool_separated (afterThree_valid ctx room) first
  exact CoefficientTableRead.memory (t:=(beforeAtanh l c).state) first
    (by
      rw[beforeAtanh_nonzero]
      exact RationalDivideCalls.nonzero_other l (afterThree l c) (one l c) (three l c) base.object
        (List.getElem?_eq_some_iff.mp first.memory).choose safe.1 safe.2.1 safe.2.2)
    (by intro slot n h;rw[beforeAtanh_nonzero];exact RationalDivideCalls.nonzero_borrow _ _ h)

theorem beforeAtanh_borrow {l : PoolCalls.PoolLayout} {c : Cursor}
    {slot value : Nat} (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (beforeAtanh l c).state.nats slot value := by
  rw[beforeAtanh_nonzero]
  exact RationalDivideCalls.nonzero_borrow _ _
    (CursorBorrow.preserves (l:=l) (c:=afterOne l c) [3,0,1]
      (CursorBorrow.preserves (l:=l) (c:=afterTwo l c) [1,0,1]
        (CursorBorrow.preserves (l:=l) (c:=c) [2,0,1] h)))

theorem beforeAtanh_scalar {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) {name type : String} {object : Nat} {value : Option Value}
    (h : SourceScalarGlobal.At c.state name type object value) (different : type≠"unsigned") :
    SourceScalarGlobal.At (beforeAtanh l c).state name type object value := by
  have first : SourceScalarGlobal.At (afterTwo l c).state name type object value:=
    SourceScalarGlobal.advanced ctx h different [2,0,1]
  have second : SourceScalarGlobal.At (afterOne l c).state name type object value:=
    SourceScalarGlobal.advanced (afterTwo_valid ctx room) first different [1,0,1]
  have third : SourceScalarGlobal.At (afterThree l c).state name type object value:=
    SourceScalarGlobal.advanced (afterOne_valid ctx room) second different [3,0,1]
  rw[beforeAtanh_nonzero]
  exact SourceScalarGlobal.nonzero_division (afterThree_valid ctx room) third different _ _

theorem beforeAtanh_scale {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+21<PoolCalls.capacity) {object slot value : Nat}
    (h : SourceFromS.ScaleAt c.state object slot value) :
    SourceFromS.ScaleAt (beforeAtanh l c).state object slot value := by
  have stored:=beforeAtanh_scalar ctx room
    (show SourceScalarGlobal.At c.state "scale100" "N" object (some (.natObject slot))
      from ⟨h.lookup,h.storage⟩) (by decide +kernel)
  exact ⟨stored.lookup,stored.storage,beforeAtanh_borrow h.live⟩

theorem beforeAtanh_globals (l : PoolCalls.PoolLayout) (c : Cursor) :
    (beforeAtanh l c).state.globals=c.state.globals := by
  rw[beforeAtanh_nonzero,RationalDivideCalls.nonzero_globals]
  exact (CursorSingleFrames.advance_globals l (afterOne l c) [3,0,1]).trans
    ((CursorSingleFrames.advance_globals l (afterTwo l c) [1,0,1]).trans
      (CursorSingleFrames.advance_globals l c [2,0,1]))

theorem beforeAtanh_env (l : PoolCalls.PoolLayout) (c : Cursor) :
    (beforeAtanh l c).state.env=c.state.env := by
  rw[beforeAtanh_nonzero,RationalDivideCalls.nonzero_env]
  exact (CursorEffects.shape l (afterOne l c) [3,0,1]).2.trans
    ((CursorEffects.shape l (afterTwo l c) [1,0,1]).2.trans
      (CursorEffects.shape l c [2,0,1]).2)

theorem beforeAtanh_heap (l : PoolCalls.PoolLayout) (c : Cursor) :
    (beforeAtanh l c).state.heap.length=c.state.heap.length := by
  rw[beforeAtanh_nonzero,RationalDivideCalls.nonzero_heap_length]
  exact (CursorEffects.shape l (afterOne l c) [3,0,1]).1.trans
    ((CursorEffects.shape l (afterTwo l c) [1,0,1]).1.trans
      (CursorEffects.shape l c [2,0,1]).1)

theorem beforeAtanh_top (l : PoolCalls.PoolLayout) (c : Cursor) : (beforeAtanh l c).top=c.top+22 := by
  rw[beforeAtanh_nonzero,RationalDivideCalls.nonzero_top]
  rfl

theorem beforeAtanh_depth {l : PoolCalls.PoolLayout} {c : Cursor} {object d : Nat}
    (h : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At (beforeAtanh l c).state "depth" object d := by
  have first : SourceUnsignedGlobal.At (afterTwo l c).state "depth" object d:=
    SourceUnsignedGlobal.advanced (l:=l) (c:=c) h [2,0,1] apart.1 apart.2.1 apart.2.2
  have second : SourceUnsignedGlobal.At (afterOne l c).state "depth" object d:=
    SourceUnsignedGlobal.advanced (l:=l) (c:=afterTwo l c) first [1,0,1] apart.1 apart.2.1 apart.2.2
  have third : SourceUnsignedGlobal.At (afterThree l c).state "depth" object d:=
    SourceUnsignedGlobal.advanced (l:=l) (c:=afterOne l c) second [3,0,1] apart.1 apart.2.1 apart.2.2
  rw[beforeAtanh_nonzero]
  exact SourceUnsignedGlobal.nonzero_division (l:=l) (c:=afterThree l c) third _ _ apart

end ScopedC.PrepareSource.Ln2
