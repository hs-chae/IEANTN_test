/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorStepEvents
import ScopedC.TaylorStepMathematics

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def condition : Expr := .binary ">" (.var "k") (.nat 0)
def loopBody : Stmt := .sequence [
  .eval (.binary "=" (.var "k") (.binary "-" (.var "k") (.nat 1))),.eval stepExpression]

theorem condition_eval (service : Call) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) :
    Eval Header.layout service condition f.cursor.state f.cursor.state (boolean Header.layout (decide (0<f.k))) :=
  UnsignedLocalSteps.positive_condition service f.kAt f.kBound
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem decremented_top {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : (decremented f).cursor.top=f.cursor.top := rfl
theorem decremented_shape {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : (decremented f).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (decremented f).cursor.state.env=f.cursor.state.env := by
  change (f.cursor.state.heap.set f.kSlot _).length=_ ∧ _
  exact ⟨List.length_set,rfl⟩
theorem decrement_index {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) : (decremented f).k<coeffs.length := by
  change f.k-1<coeffs.length
  have h:=f.kLength
  omega

noncomputable def iteration {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity) : Frame l base coeffs :=
  stepped (decremented f) (decrement_index f positive) room

noncomputable def iterationEvents (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity) : List (Event code) :=
  stepEvents code lib (decremented f) (decrement_index f positive) room

theorem iteration_k {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity) : (iteration f positive room).k=f.k-1 := rfl
theorem iteration_top {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity) :
    (iteration f positive room).cursor.top=f.cursor.top+108 := stepped_top _ _ _
theorem iteration_size {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity) :
    (iteration f positive room).cursor.state.nats.values.length=f.cursor.state.nats.values.length+108 := stepped_size _ _ _
theorem iteration_original {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity) :
    original (iteration f positive room)=original f := rfl
theorem iteration_shape {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity) :
    (iteration f positive room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (iteration f positive room).cursor.state.env=f.cursor.state.env := by
  have first:=decremented_shape f
  have second:=stepped_shape (decremented f) (decrement_index f positive) room
  exact ⟨second.1.trans first.1,second.2.trans first.2⟩

theorem iteration_run (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity)
    (service : Call) (answers : EventAnswers service (iterationEvents code lib f positive room)) :
    Run Header.layout service loopBody f.cursor.state (.continuing (iteration f positive room).cursor.state) := by
  apply Loops.StmtRun.sequence
    (Loops.SeqRun.next (Loops.StmtRun.evaluate (decrement_source service f positive))
      (Loops.SeqRun.next (Loops.StmtRun.evaluate
        (step_event_run code lib (decremented f) (decrement_index f positive) room service answers)) (Loops.SeqRun.nil _)))
  have shape:=iteration_shape f positive room
  exact (PoolCalls.pop_same shape.1 shape.2).symm

theorem iteration_math {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity)
    (invariant : mathematical f=LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop f.k)) (original f)) :
    mathematical (iteration f positive room)=
      LeanCert.Core.IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop (f.k-1))) (original f) := by
  have step:=stepped_math (decremented f) (decrement_index f positive) room
  change mathematical (stepped (decremented f) (decrement_index f positive) room)=_
  rw[step]
  have indexBound : f.k-1<coeffs.length := decrement_index f positive
  change LeanCert.Core.IntervalRat.add (LeanCert.Core.IntervalRat.singleton coeffs[f.k-1].mathematical.value)
    (LeanCert.Core.IntervalRat.mul (mathematical f) (original f))=_
  rw[invariant]
  have suffix:=fold_suffix coeffs (f.k-1) (decrement_index f positive) (original f)
  rw[show f.k-1+1=f.k by omega] at suffix
  exact suffix.symm

theorem iteration_unique (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity) :
    ((iterationEvents code lib f positive room).map CallEvents.nameKey).Nodup :=
  step_unique code lib (decremented f) (decrement_index f positive) room

theorem iteration_bounds (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity)
    (e : Event code) (member : e∈iterationEvents code lib f positive room) :
    f.cursor.state.nats.values.length ≤ e.before.nats.values.length ∧
      e.before.nats.values.length < (iteration f positive room).cursor.state.nats.values.length :=
  step_bounds code lib (decremented f) (decrement_index f positive) room e member

end ScopedC.TaylorCalls
