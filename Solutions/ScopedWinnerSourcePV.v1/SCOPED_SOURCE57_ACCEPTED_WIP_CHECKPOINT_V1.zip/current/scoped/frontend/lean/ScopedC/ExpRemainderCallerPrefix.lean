/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderFactorialFrames
import ScopedC.ExpRemainderPowers

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax

theorem afterC_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (ceil : CeilStage code l c a) : (afterC ceil).state.globals=c.state.globals := by
  change (next l (afterCeil ceil) 4294967295).state.globals=_
  rw[CursorSingleFrames.globals]
  change ceil.out.state.globals=_
  rw[ceil.trace,CursorSingleFrames.advance_globals,afterR_globals]

theorem afterC_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (ceil : CeilStage code l c a) {slot value : Nat} (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (afterC ceil).state.nats slot value := by
  change NatArena.Borrow (next l (afterCeil ceil) 4294967295).state.nats slot value
  apply PoolCursor.preserves
  change NatArena.Borrow ceil.out.state.nats slot value
  rw[ceil.trace]
  exact CursorBorrow.preserves ceil.values (afterR_borrow a h)

theorem afterC_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair}
    (ceil : CeilStage code l c a) (slot : Nat) (old : slot<c.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (afterC ceil).state.heap[slot]?=c.state.heap[slot]? := by
  have ceilLength : ceil.out.state.heap.length=c.state.heap.length+2 := by
    rw[ceil.trace,(CursorEffects.shape _ _ _).1,afterR_heap]
  have localLength : (afterCeil ceil).state.heap.length=c.state.heap.length+3 := by
    change (ceil.out.state.heap++[_]).length=_
    rw[List.length_append,List.length_singleton,ceilLength]
  change ((next l (afterCeil ceil) 4294967295).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left (by rw[(PoolCursor.shape l (afterCeil ceil) 4294967295).1,localLength];omega)]
  rw[PoolCursor.other l (afterCeil ceil) 4294967295 slot hp ht hh]
  change (ceil.out.state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left (by omega),ceil.trace,
    CursorSingleFrames.advance_other l (afterR l c a) ceil.values slot hp ht hh]
  exact afterR_other l c a slot old hp ht hh

theorem factorial_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) : (BeforeError f).state.heap.length=c.state.heap.length+6 := by
  rw[f.loop.shape.1,f.cursor]
  change (((CursorFrames.advance l (afterC ceil) [1,0,1]).state.heap++[_])++[_]).length=_
  rw[List.length_append,List.length_append,List.length_singleton,
    (CursorEffects.shape l (afterC ceil) [1,0,1]).1,afterC_heap]
  rfl

theorem factorial_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) : (BeforeError f).state.globals=c.state.globals := by
  rw[f.loop.globals,f.cursor]
  change (CursorFrames.advance l (afterC ceil) [1,0,1]).state.globals=_
  rw[CursorSingleFrames.advance_globals,afterC_globals]

theorem factorial_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) {slot value : Nat}
    (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (BeforeError f).state.nats slot value := by
  apply f.loop.preserves
  rw[f.cursor]
  exact CursorBorrow.preserves (l:=l) (c:=afterC ceil) [1,0,1] (afterC_borrow ceil h)

theorem factorial_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    (f : FactorialStage code l c a object d ceil) (slot : Nat) (old : slot<c.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (BeforeError f).state.heap[slot]?=c.state.heap[slot]? := by
  have slots:=ExpFactorial.initial_slots f.start f.cursor
  have factApart : slot≠f.start.factSlot := by rw[slots.1,afterC_heap];omega
  have kApart : slot≠f.start.kSlot := by rw[slots.2,afterC_heap];omega
  rw[f.loop.other slot factApart kApart hp ht hh,f.cursor]
  have advancedLength : (CursorFrames.advance l (afterC ceil) [1,0,1]).state.heap.length=c.state.heap.length+4 := by
    rw[(CursorEffects.shape l (afterC ceil) [1,0,1]).1,afterC_heap]
  change (((CursorFrames.advance l (afterC ceil) [1,0,1]).state.heap++[_])++[_])[slot]?=_
  rw[List.getElem?_append_left (by rw[List.length_append,List.length_singleton,advancedLength];omega),
    List.getElem?_append_left (by omega),CursorSingleFrames.advance_other l (afterC ceil) [1,0,1] slot hp ht hh]
  exact afterC_other ceil slot old hp ht hh

end ScopedC.ExpRemainderCalls
