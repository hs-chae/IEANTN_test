/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalSelectionTreeEffects

namespace ScopedC.RationalSelectionTree
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def expression (name : String) : Expr := .call (.var name) [
  .call (.var name) [.var "p",.var "q"],.call (.var name) [.var "r",.var "s"]]

/-- Evaluate the actual nested source expression. The four caller locals are
read from their actual memory cells, including r/s after the first selection's
six allocations; all answers are supplied by the separately proved source calls. -/
theorem evaluate (service : Call) (fuel : Nat) (flip : Bool)
    (l : ScopedC.PoolCalls.PoolLayout) (c : Cursor) (v : Four)
    {sp sq sr ss : Nat}
    (hp : ScopedC.LocalBinding.At c.state "p" "Q" v.p.source sp)
    (hq : ScopedC.LocalBinding.At c.state "q" "Q" v.q.source sq)
    (hr : ScopedC.LocalBinding.At c.state "r" "Q" v.r.source sr)
    (hs : ScopedC.LocalBinding.At c.state "s" "Q" v.s.source ss)
    (rp : sr≠l.pool) (rt : sr≠l.top) (rh : sr≠l.high)
    (ssp : ss≠l.pool) (sst : ss≠l.top) (ssh : ss≠l.high)
    (first : service (name flip) [v.p.source,v.q.source] c.state=
      some ((left flip l c v).source,(t1 l c v).state))
    (second : service (name flip) [v.r.source,v.s.source] (t1 l c v).state=
      some ((right flip l c v).source,(t2 l c v).state))
    (third : service (name flip) [(left flip l c v).source,(right flip l c v).source] (t2 l c v).state=
      some ((output flip l c v).source,(finish flip l c v).state)) :
    evalExpr ScopedC.Header.layout service (fuel+3) c.state (expression (name flip))=
      some ((output flip l c v).source,(finish flip l c v).state) := by
  have rr : ScopedC.LocalBinding.At (t1 l c v).state "r" "Q" v.r.source sr := by
    rw[t1,step,ScopedC.RationalCompareFraming.final_eq_advance]
    exact ScopedC.LocalBinding.advance hr _ rp rt rh
  have srRead : ScopedC.LocalBinding.At (t1 l c v).state "s" "Q" v.s.source ss := by
    rw[t1,step,ScopedC.RationalCompareFraming.final_eq_advance]
    exact ScopedC.LocalBinding.advance hs _ ssp sst ssh
  apply ScopedC.ExpressionTemplates.call_two ScopedC.Header.layout service
  · exact ScopedC.ExpressionTemplates.call_two ScopedC.Header.layout service
      (ScopedC.LocalBinding.eval service fuel hp (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
      (ScopedC.LocalBinding.eval service fuel hq (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) first
  · exact ScopedC.ExpressionTemplates.call_two ScopedC.Header.layout service
      (ScopedC.LocalBinding.eval service fuel rr (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
      (ScopedC.LocalBinding.eval service fuel srRead (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) second
  · exact third

end ScopedC.RationalSelectionTree
