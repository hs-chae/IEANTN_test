/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderOutput
import LeanCert.Core.IntervalRat.Taylor
import ScopedC.NumericRationalIntervalAddRefinement

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

theorem ceil_magnitude {code : List Function} {l : PoolCalls.PoolLayout}
    {c : Cursor} {a : Pair} (ceil : CeilStage code l c a) (positive : a.Positive) :
    ceil.endpoint.magnitude=Nat.ceil (max |a.lo.mathematical.value| |a.hi.mathematical.value|) := by
  have first:=ceil_magnitude_cast ceil positive
  rw[radius_value a positive] at first
  have second:=Int.natCast_ceil_eq_ceil (le_trans (abs_nonneg a.lo.mathematical.value)
    (le_max_left |a.lo.mathematical.value| |a.hi.mathematical.value|))
  have same : (ceil.endpoint.magnitude:Int)=
      (Nat.ceil (max |a.lo.mathematical.value| |a.hi.mathematical.value|):Int):=first.trans second.symm
  exact_mod_cast same

theorem error_model_value {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (positive : a.Positive) (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) :
    (errorInput r).mathematical.value=(IntervalRat.expRemainderBoundComputable
      ⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩ d).hi := by
  rw[error_value r positive,ceil_magnitude ceil positive]
  rfl

/-- Actual source-produced qi/qpow/qt/qv/qn outputs decode to the unchanged
original rational exponential remainder interval. The full enclosing C
expRemainder function body is a separate outer-controller obligation. -/
theorem output_model {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (positive : a.Positive) (ordered : a.lo.mathematical.value ≤ a.hi.mathematical.value) :
    NumericRepresentation.interval (afterOut r).state (outputPair r).source=some
      (IntervalRat.expRemainderBoundComputable ⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩ d) := by
  have decoded:=NumericRationalIntervalAddRefinement.decoded_input (output_live r)
    (output_positive r) (output_order r positive)
  have same : (⟨(outputPair r).lo.mathematical.value,(outputPair r).hi.mathematical.value,
      output_order r positive⟩:IntervalRat)=IntervalRat.expRemainderBoundComputable
        ⟨a.lo.mathematical.value,a.hi.mathematical.value,ordered⟩ d := by
    rw[IntervalRat.mk.injEq]
    constructor
    · change (RationalSubCalls.negative (errorInput r)).mathematical.value=_
      rw[RationalSubCalls.negative_value,error_model_value r positive ordered]
      rfl
    · exact error_model_value r positive ordered
  exact decoded.trans (congrArg some same)

end ScopedC.ExpRemainderCalls
