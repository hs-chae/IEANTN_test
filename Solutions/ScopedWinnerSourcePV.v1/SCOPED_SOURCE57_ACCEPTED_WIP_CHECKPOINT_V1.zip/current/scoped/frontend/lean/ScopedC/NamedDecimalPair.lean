/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedRecordLifecycle
namespace ScopedC.NamedDecimalPair
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalRecordFields ScopedC.NamedRecordLifecycle
open ScopedC.DecimalText (digits)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- Actual sequential decimal producers, including the first physical RI field
store before the second producer executes. This is proof metadata, not an
executable output oracle. -/
structure Stages (code : List Function) (l : PoolLayout) (c : Cursor)
    (lowNumerator highNumerator denominator slot : Nat) (oldHi : Value) where
  low : RationalDecimalLiteral.Stages code l c lowNumerator denominator
  high : RationalDecimalLiteral.Stages code l
    (stored (RationalDecimalLiteral.after low) slot low.output.source oldHi)
    highNumerator denominator

def middle {code : List Function} {l : PoolLayout} {c : Cursor} {nl nh den slot : Nat}
    {oldHi : Value} (D : Stages code l c nl nh den slot oldHi) : Cursor :=
  stored (RationalDecimalLiteral.after D.low) slot D.low.output.source oldHi

def finish {code : List Function} {l : PoolLayout} {c : Cursor} {nl nh den slot : Nat}
    {oldHi : Value} (D : Stages code l c nl nh den slot oldHi) : Cursor :=
  stored (RationalDecimalLiteral.after D.high) slot D.low.output.source D.high.output.source

def input {code : List Function} {l : PoolLayout} {c : Cursor} {nl nh den slot : Nat}
    {oldHi : Value} (D : Stages code l c nl nh den slot oldHi) : FromRIFrames.InputRI :=
  ⟨D.low.output,D.high.output⟩

theorem stages_exist (code : List Function) (lib : RationalDecimalLiteral.Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) {oldLo oldHi : Value} {slot : Nat}
    (record : At c.state oldLo oldHi slot) (nl nh den : Nat) (positive : 0<den)
    (room : c.top+60+4*(digits nl).length+4*(digits nh).length+8*(digits den).length<capacity) :
    Nonempty (Stages code l c nl nh den slot oldHi) := by
  obtain ⟨lo⟩ := RationalDecimalLiteral.stages_exist code lib ctx nl den positive (by omega)
  have firstRoom : lo.numerator.top<capacity := by rw [lo.numeratorTop];omega
  have atLow := RationalRecordFields.decimal lo ctx firstRoom record
  have middleValid : Valid l (stored (RationalDecimalLiteral.after lo) slot lo.output.source oldHi) :=
    RationalRecordFields.valid lo.valid atLow _ _
  have highRoom : (stored (RationalDecimalLiteral.after lo) slot lo.output.source oldHi).top+
      7+4*(digits nh).length+4*(digits den).length<capacity := by
    change (RationalDecimalLiteral.after lo).top+7+4*(digits nh).length+4*(digits den).length<capacity
    rw [RationalDecimalLiteral.top]
    omega
  obtain ⟨hi⟩ := RationalDecimalLiteral.stages_exist code lib middleValid nh den positive highRoom
  exact ⟨⟨lo,hi⟩⟩

theorem stored_result {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot)
    (lowRoom : D.low.numerator.top<capacity) (highRoom : D.high.numerator.top<capacity) :
    Valid l (finish D) ∧
    At (finish D).state D.low.output.source D.high.output.source slot ∧
    (input D).Live (finish D).state := by
  have lowAt := RationalRecordFields.decimal D.low ctx lowRoom record
  have midValid : Valid l (middle D) := RationalRecordFields.valid D.low.valid lowAt _ _
  have midAt : At (middle D).state D.low.output.source oldHi slot := binding lowAt _ _
  have highAt := RationalRecordFields.decimal D.high midValid highRoom midAt
  have lowLive : D.low.output.Live (RationalDecimalLiteral.after D.high).state :=
    ⟨RationalDecimalLiteral.preserves_nat D.high D.low.live.1,
     RationalDecimalLiteral.preserves_nat D.high D.low.live.2⟩
  exact ⟨RationalRecordFields.valid D.high.valid highAt _ _,binding highAt _ _,
    lowLive,D.high.live⟩

theorem top {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldHi : Value} (D : Stages code l c nl nh den slot oldHi) :
    (finish D).top=c.top+16+4*(digits nl).length+4*(digits nh).length+8*(digits den).length := by
  change (RationalDecimalLiteral.after D.high).top=_
  rw [RationalDecimalLiteral.top]
  change (RationalDecimalLiteral.after D.low).top+8+4*(digits nh).length+4*(digits den).length=_
  rw [RationalDecimalLiteral.top]
  omega

theorem scale {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot object valueSlot number : Nat} {oldLo oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi) (ctx : Valid l c)
    (record : At c.state oldLo oldHi slot)
    (lowRoom : D.low.numerator.top<capacity) (highRoom : D.high.numerator.top<capacity)
    (h : SourceFromS.ScaleAt c.state object valueSlot number) :
    SourceFromS.ScaleAt (finish D).state object valueSlot number := by
  have lowAt := RationalRecordFields.decimal D.low ctx lowRoom record
  have lowScale := RationalDecimalLiteral.scale D.low ctx lowRoom h
  have midValid : Valid l (middle D) := RationalRecordFields.valid D.low.valid lowAt _ _
  have midAt : At (middle D).state D.low.output.source oldHi slot := binding lowAt _ _
  have midScale : SourceFromS.ScaleAt (middle D).state object valueSlot number :=
    RationalRecordFields.scale_store lowAt lowScale _ _
  have highAt := RationalRecordFields.decimal D.high midValid highRoom midAt
  exact RationalRecordFields.scale_store highAt
    (RationalDecimalLiteral.scale D.high midValid highRoom midScale) _ _

#print axioms stages_exist
#print axioms stored_result
#print axioms top
#print axioms scale
end ScopedC.NamedDecimalPair
