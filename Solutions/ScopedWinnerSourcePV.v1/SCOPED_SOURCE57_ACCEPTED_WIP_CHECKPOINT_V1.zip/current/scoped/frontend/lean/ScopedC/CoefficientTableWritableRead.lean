/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientTableRead

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem source_index_writable (service : Call) (fuel : Nat) {s : State} {base : Address}
    {coeffs : List Input} {array index : Expr} (table : TableAt s base coeffs) (k : Nat)
    (bound : k<coeffs.length)
    (pointer : evalExpr Header.layout service (fuel+1) s array=some (.pointer base true,s))
    (counter : evalExpr Header.layout service (fuel+1) s index=some (unsigned32 k,s)) :
    evalExpr Header.layout service (fuel+3) s (.index array index)=some (coeffs[k].source,s) := by
  have read:=read_coefficient table k bound
  rw[evalExpr,evalLValue,pointer]
  simp only[table.emptyFields,List.isEmpty_nil,Bool.not_true,Bool.false_eq_true,↓reduceIte,Bind.bind,Option.bind]
  rw[counter]
  simp only[table.emptyFields] at read
  simp [asNat,unsigned32,read.1,read.2]

end ScopedC.CoefficientTableRead
