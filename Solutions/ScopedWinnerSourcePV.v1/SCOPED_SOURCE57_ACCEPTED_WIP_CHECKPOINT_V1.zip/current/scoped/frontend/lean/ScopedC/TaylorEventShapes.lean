/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorIteration

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem step_event_shape (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input} (f : Frame l base coeffs)
    (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity)
    (e : Event code) (member : e∈stepEvents code lib f hk room) :
    e.before.heap.length=f.cursor.state.heap.length ∧ e.before.env=f.cursor.state.env := by
  simp only[stepEvents,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact ⟨rfl,rfl⟩
  · exact ⟨rfl,rfl⟩
  · change (productCursor f).state.heap.length=f.cursor.state.heap.length ∧
      (productCursor f).state.env=f.cursor.state.env
    unfold productCursor
    exact IntervalProductApplicability.shape l f.cursor f.result f.a

theorem iteration_event_shape (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input} (f : Frame l base coeffs)
    (positive : 0<f.k) (room : f.cursor.top+107<PoolCalls.capacity)
    (e : Event code) (member : e∈iterationEvents code lib f positive room) :
    e.before.heap.length=f.cursor.state.heap.length ∧ e.before.env=f.cursor.state.env := by
  have h:=step_event_shape code lib (decremented f) (decrement_index f positive) room e member
  have shape:=decremented_shape f
  exact ⟨h.1.trans shape.1,h.2.trans shape.2⟩

end ScopedC.TaylorCalls
