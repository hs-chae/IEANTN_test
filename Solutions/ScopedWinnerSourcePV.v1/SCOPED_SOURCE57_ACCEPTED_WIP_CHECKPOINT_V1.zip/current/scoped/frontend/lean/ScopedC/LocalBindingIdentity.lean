/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.LocalBinding

namespace ScopedC.LocalBinding
open ScopedC.Machine
set_option autoImplicit false

theorem slot_eq {s : State} {name ta tb : String} {va vb : Value} {sa sb : Nat}
    (a : At s name ta va sa) (b : At s name tb vb sb) : sa=sb := by
  have address:=Option.some.inj (a.lookup.symm.trans b.lookup)
  exact congrArg Address.object address

end ScopedC.LocalBinding
