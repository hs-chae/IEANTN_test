/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderErrorExpression
import ScopedC.ExpRemainderEventSizes
import ScopedC.CallEventAbsent
import ScopedC.SourceRanks

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000
attribute [local irreducible] radius afterMax errorCursor errorInput outputPair

structure Library (code : List Function) : Prop where
  ceiling : CeilLibrary code
  powers : RationalPowerCalls.Library code
  qpow : Generated.f_qpow∈code
  qv : Generated.f_qv∈code
  division : RationalDivideCalls.Library code
  small : Generated.f_small∈code
  nle : Generated.f_nle∈code

abbrev OuterEvent (code : List Function) := CallEvents.Event Header.layout code 9

def frontEvents (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (alive : a.Live c.state)
    (ceil : CeilStage code l c a) (countBound : ceil.endpoint.magnitude<4294967295)
    (room : c.top+3000<PoolCalls.capacity) : List (OuterEvent code) := [
  ⟨"qabs",[a.lo.source],(parameters c a).state,(low a).source,(afterLo l c a).state,
    SourceRanks.monotone (by decide +kernel) (low_call code lib.ceiling.entry ctx a alive (by omega))⟩,
  ⟨"qabs",[a.hi.source],(afterLo l c a).state,(high a).source,(afterHi l c a).state,
    SourceRanks.monotone (by decide +kernel) (high_call code lib.ceiling.entry ctx a alive (by omega))⟩,
  ⟨"qmax",[(low a).source,(high a).source],(afterHi l c a).state,(radius l c a).source,(afterMax l c a).state,
    SourceRanks.monotone (by decide +kernel) (max_call code lib.ceiling.entry ctx a alive (by omega))⟩,
  ⟨"ceilQ",[(radius l c a).source],(afterR l c a).state,ceil.endpoint.source,ceil.out.state,
    SourceRanks.monotone (by decide +kernel) ceil.execution⟩,
  ⟨"small",[.natObject ceil.endpoint.slot],(afterCeil ceil).state,PoolCalls.word ceil.endpoint.magnitude,
    (afterSmall ceil).state,SourceRanks.monotone (by decide +kernel)
      (small_call code lib.small lib.powers.productLibrary.nu lib.nle lib.powers.productLibrary.keep
        ceil (by omega) (by omega))⟩,
  ⟨"qi",[DecimalDigits.integer 1],(afterC ceil).state,(ExpFactorial.one l (afterC ceil)).source,
    (ExpFactorial.afterOne l (afterC ceil)).state,SourceRanks.monotone (by decide +kernel)
      (RationalUnsignedTrace.qi_traced code lib.powers.qi lib.powers.si lib.powers.productLibrary.smake
        lib.powers.productLibrary.nz lib.powers.productLibrary.nu lib.powers.productLibrary.ne
        lib.powers.productLibrary.keep (afterC_valid ceil (by omega)) 1 (by decide +kernel)
        (by have h:=afterC_top ceil;omega) (DecimalDigits.integer 1) (by rfl)).1⟩]

noncomputable def tailEvents (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (p : ThreePower f) (r : RadiusPower p) (room : c.top+3000<PoolCalls.capacity) : List (OuterEvent code) := [
  ⟨"qi",[DecimalDigits.integer 3],(BeforeError f).state,(three f).source,(afterThree f).state,
    SourceRanks.monotone (by decide +kernel) (three_source code lib.powers f room)⟩,
  ⟨"qpow",[(three f).source,PoolCalls.word (ceil.endpoint.magnitude+1)],(afterThree f).state,
    p.output.source,p.out.state,SourceRanks.monotone (by decide +kernel) p.execution⟩,
  ⟨"qpow",[(radius l c a).source,PoolCalls.word (d+1)],p.out.state,
    r.output.source,r.out.state,SourceRanks.monotone (by decide +kernel) r.execution⟩,
  ⟨"qt",[p.output.source,r.output.source],r.out.state,(numerator r).source,(numeratorCursor r).state,
    SourceRanks.monotone (by decide +kernel) (numerator_source code lib.powers r room)⟩,
  ⟨"qv",[(numerator r).source,f.loop.finish.fact.source],(numeratorCursor r).state,
    (errorInput r).source,(errorCursor r).state,
    SourceRanks.monotone (by decide +kernel) (error_source code lib.qv lib.division r room)⟩,
  ⟨"qn",[(errorInput r).source],(storedError r).state,(outputPair r).lo.source,
    (next l (storedError r) 0).state,SourceRanks.monotone (by decide +kernel)
      (output_call code lib.ceiling.qn lib.ceiling.sn lib.ceiling.entry.absolute r room)⟩]

theorem front_unique (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (alive : a.Live c.state)
    (ceil : CeilStage code l c a) (countBound : ceil.endpoint.magnitude<4294967295)
    (room : c.top+3000<PoolCalls.capacity) :
    ((frontEvents code lib ctx a alive ceil countBound room).map CallEvents.key).Nodup := by
  have different : c.state.nats.values.length≠(afterLo l c a).state.nats.values.length := by
    rw[afterLo_size]
    omega
  change [("qabs",c.state.nats.values.length),("qabs",(afterLo l c a).state.nats.values.length),
    ("qmax",(afterHi l c a).state.nats.values.length),("ceilQ",(afterR l c a).state.nats.values.length),
    ("small",(afterCeil ceil).state.nats.values.length),("qi",(afterC ceil).state.nats.values.length)].Nodup
  simp only[List.nodup_cons,List.mem_cons,List.not_mem_nil,not_false_eq_true,List.nodup_nil,
    Prod.mk.injEq,String.reduceEq,not_or,and_false,false_and,and_true,true_and,different]

theorem tail_unique (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (p : ThreePower f) (r : RadiusPower p) (room : c.top+3000<PoolCalls.capacity) :
    ((tailEvents code lib f p r room).map CallEvents.key).Nodup := by
  have different : (afterThree f).state.nats.values.length≠p.out.state.nats.values.length := by
    have lower:=p.arena_lower
    omega
  change [("qi",(BeforeError f).state.nats.values.length),("qpow",(afterThree f).state.nats.values.length),
    ("qpow",p.out.state.nats.values.length),("qt",r.out.state.nats.values.length),
    ("qv",(numeratorCursor r).state.nats.values.length),("qn",(storedError r).state.nats.values.length)].Nodup
  simp only[List.nodup_cons,List.mem_cons,List.not_mem_nil,not_false_eq_true,List.nodup_nil,
    Prod.mk.injEq,String.reduceEq,not_or,and_false,false_and,and_true,true_and,different]

theorem front_bounds (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a : Pair) (alive : a.Live c.state)
    {object d : Nat} {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (countBound : ceil.endpoint.magnitude<4294967295) (room : c.top+3000<PoolCalls.capacity)
    (e : OuterEvent code) (member : e∈frontEvents code lib ctx a alive ceil countBound room) :
    e.before.nats.values.length<f.start.cursor.state.nats.values.length := by
  have mapped : e.before.nats.values.length∈(frontEvents code lib ctx a alive ceil countBound room).map
      (fun e : OuterEvent code=>e.before.nats.values.length) := List.mem_map.mpr ⟨e,member,rfl⟩
  change e.before.nats.values.length∈[c.state.nats.values.length,(afterLo l c a).state.nats.values.length,
    (afterHi l c a).state.nats.values.length,(afterR l c a).state.nats.values.length,
    ceil.out.state.nats.values.length,(afterC ceil).state.nats.values.length] at mapped
  have lo:=afterLo_size l c a
  have hi:=afterHi_size l c a
  have rr:=afterR_size l c a
  have cc:=ceil_size ceil
  have small:=afterC_size ceil
  have start:=factorial_start_size f
  simp only[List.mem_cons,List.not_mem_nil,or_false] at mapped
  rcases mapped with same|same|same|same|same|same <;> rw[same] <;> omega

theorem tail_bounds (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} {a : Pair} {object d : Nat}
    {ceil : CeilStage code l c a} (f : FactorialStage code l c a object d ceil)
    (p : ThreePower f) (r : RadiusPower p) (room : c.top+3000<PoolCalls.capacity)
    (e : OuterEvent code) (member : e∈tailEvents code lib f p r room) :
    (BeforeError f).state.nats.values.length ≤ e.before.nats.values.length := by
  have mapped : e.before.nats.values.length∈(tailEvents code lib f p r room).map
      (fun e : OuterEvent code=>e.before.nats.values.length) := List.mem_map.mpr ⟨e,member,rfl⟩
  change e.before.nats.values.length∈[(BeforeError f).state.nats.values.length,
    (afterThree f).state.nats.values.length,p.out.state.nats.values.length,r.out.state.nats.values.length,
    (numeratorCursor r).state.nats.values.length,(errorCursor r).state.nats.values.length] at mapped
  have three:=afterThree_size f
  have first:=p.arena_lower
  have second:=r.arena_lower
  have num:=numerator_size r
  have err:=error_arena_lower r
  simp only[List.mem_cons,List.not_mem_nil,or_false] at mapped
  rcases mapped with same|same|same|same|same|same <;> rw[same] <;> omega

end ScopedC.ExpRemainderCalls
