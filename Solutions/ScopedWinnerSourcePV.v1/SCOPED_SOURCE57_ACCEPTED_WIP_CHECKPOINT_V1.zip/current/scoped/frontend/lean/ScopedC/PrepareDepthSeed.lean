/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareStaticState
import ScopedC.PrepareEntry
import ScopedC.PrepareCoefficientSeed
import ScopedC.SourceNatGlobal

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def staticCursor {state : State} {base : Nat} (_ready : StaticAt state base) : Cursor :=
  ⟨state,ScopedIO.ApplicationInit.poolCells,0,0⟩

def depthCursor {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) : Cursor :=
  afterDepth (staticCursor ready) d (base+3)

def depthExpTable {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) :
    CoefficientTableRead.TableAt (depthCursor ready d).state (expBase base) [] :=
  CoefficientTableRead.after_depth_assignment
    (CoefficientTableRead.allocated
      (CoefficientTableRead.memory (t:={state with env:=[]}) ready.exp rfl (fun _ _ h=>h))
      "unsigned int" "d" (some (PoolCalls.word d)))
    (parameters_depth (c:=staticCursor ready) d ready.depth) d

def depthAtanhTable {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) :
    CoefficientTableRead.TableAt (depthCursor ready d).state (atanhBase base) [] :=
  CoefficientTableRead.after_depth_assignment
    (CoefficientTableRead.allocated
      (CoefficientTableRead.memory (t:={state with env:=[]}) ready.atanh rfl (fun _ _ h=>h))
      "unsigned int" "d" (some (PoolCalls.word d)))
    (parameters_depth (c:=staticCursor ready) d ready.depth) d

/-- The coefficient seed BEFORE the immediately following scale100 store,
from actual statics, actual parameter binding and actual depth assignment. -/
def depthSeed {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) (bound : d ≤ 64) :
    CoeffSeed (layout base) (base+3) d (expBase base) (atanhBase base) := {
  cursor:=depthCursor ready d
  context:=afterDepth_valid (l:=layout base) (c:=staticCursor ready) ready.pool d (base+3) (by simp only[layout];exact ⟨by omega,by omega,by omega⟩)
  expAt:=depthExpTable ready d
  atanhAt:=depthAtanhTable ready d
  expExtent:=ready.expLength
  atanhExtent:=ready.atanhLength
  expLookup:=ready.expLookup
  atanhLookup:=ready.atanhLookup
  expUnshadowed:=rfl
  atanhUnshadowed:=rfl
  depthAt:=afterDepth_at (c:=staticCursor ready) d ready.depth
  depthUnshadowed:=rfl
  depthBound:=bound
  arraysApart:=by simp only[expBase,atanhBase];omega
  depthApart:=by simp only[layout];exact ⟨by omega,by omega,by omega⟩ }

theorem depth_scale_raw {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) :
    SourceNatGlobal.RawAt (depthCursor ready d).state "scale100" (base+4) (some .null) := by
  have raw : SourceNatGlobal.RawAt state "scale100" (base+4) (some .null):=
    ⟨ready.scaleLookup,ready.scaleMemory⟩
  have frame:=SourceNatGlobal.allocated
    (SourceNatGlobal.memory (t:={state with env:=[]}) raw rfl rfl) "unsigned int" "d" (some (PoolCalls.word d))
  exact SourceNatGlobal.memory
    (t:=(depthCursor ready d).state) frame rfl
    (List.getElem?_set_ne (show base+3≠base+4 by omega))

theorem depth_scale_unshadowed {state : State} {base : Nat} (ready : StaticAt state base) (d : Nat) :
    (depthCursor ready d).state.env.lookup "scale100"=none := rfl

end ScopedC.PrepareSource
