/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointPower
import ScopedC.SourceScalarGlobal

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 300000
set_option maxRecDepth 100000

theorem ceil_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    stage.out.state.heap.length = c.state.heap.length+1 := by
  rw [stage.trace,(CursorEffects.shape _ _ _).1]
  change (next l (parameters c q) 0).state.heap.length = _
  rw [(PoolCursor.shape _ _ _).1]
  simp only [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate,
    List.length_append,List.length_singleton]

theorem power_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    (afterPower stage).state.heap.length = c.state.heap.length+5 := by
  have ceilLen : (afterCeil stage).state.heap.length = stage.out.state.heap.length+1 := by
    simp only [afterCeil,CursorLocals.allocated,allocate,List.length_append,List.length_singleton]
  have addLen : (afterAdd stage).state.heap.length = (afterCeil stage).state.heap.length :=
    (PoolCursor.shape l (afterOne stage) (mValue stage)).1.trans
      (PoolCursor.shape l (afterCeil stage) 1).1
  have mLen : (afterM stage).state.heap.length = (afterAdd stage).state.heap.length+1 := by
    simp only [afterM,CursorLocals.allocated,allocate,List.length_append,List.length_singleton]
  have smallLen : (afterSmall stage).state.heap.length = (afterM stage).state.heap.length :=
    (PoolCursor.shape l (afterLog stage) 4294967295).1.trans
      (PoolCursor.shape l (afterM stage) (kValue stage)).1
  have kLen : (afterK stage).state.heap.length = (afterSmall stage).state.heap.length+1 := by
    simp only [afterK,CursorLocals.allocated,allocate,List.length_append,List.length_singleton]
  change ((afterK stage).state.heap++[_]).length = _
  rw [List.length_append,List.length_singleton,kLen,smallLen,mLen,addLen,ceilLen,ceil_heap stage]

theorem power_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) : (afterPower stage).top ≤ c.top+13 := by
  change stage.out.top+1+1+1+1 ≤ c.top+13
  have top := ceil_top stage
  omega

theorem power_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) :
    (afterPower stage).state.globals = c.state.globals := by
  change (next l (afterLog stage) 4294967295).state.globals = _
  rw [CursorSingleFrames.globals]
  change (next l (afterM stage) (kValue stage)).state.globals = _
  rw [CursorSingleFrames.globals]
  change (next l (afterOne stage) (mValue stage)).state.globals = _
  rw [CursorSingleFrames.globals]
  change (next l (afterCeil stage) 1).state.globals = _
  rw [CursorSingleFrames.globals]
  change stage.out.state.globals = _
  rw [stage.trace,CursorSingleFrames.advance_globals]
  change (next l (parameters c q) 0).state.globals = _
  rw [CursorSingleFrames.globals]
  rfl

theorem power_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) {slot value : Nat}
    (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (afterPower stage).state.nats slot value := by
  have ceilLive : NatArena.Borrow stage.out.state.nats slot value := by
    rw [stage.trace]
    exact CursorBorrow.preserves stage.values (PoolCursor.preserves (c:=parameters c q) live)
  exact PoolCursor.preserves (c:=afterLog stage)
    (PoolCursor.preserves (c:=afterM stage)
      (PoolCursor.preserves (c:=afterOne stage)
        (PoolCursor.preserves (c:=afterCeil stage) ceilLive)))

theorem power_q_binding {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (valid : Valid l c) :
    LocalBinding.At (afterPower stage).state "q" "Q" q.source c.state.heap.length := by
  have safe := LocalStorageSeparation.pool (parameters_valid valid q)
    (parameters_binding c q) (by decide +kernel)
  have first : LocalBinding.At stage.out.state "q" "Q" q.source c.state.heap.length := by
    rw [stage.trace]
    exact LocalBinding.advance
      (LocalBinding.advance (parameters_binding c q) [0] safe.1 safe.2.1 safe.2.2)
      stage.values safe.1 safe.2.1 safe.2.2
  have second : LocalBinding.At (afterM stage).state "q" "Q" q.source c.state.heap.length :=
    LocalBinding.allocate_other
      (LocalBinding.advance
        (LocalBinding.allocate_other first "ceil" "S" _ (by decide +kernel))
        [1,mValue stage] safe.1 safe.2.1 safe.2.2)
      "m" "N" _ (by decide +kernel)
  exact LocalBinding.allocate_other
    (LocalBinding.allocate_other
      (LocalBinding.advance second [kValue stage,4294967295] safe.1 safe.2.1 safe.2.2)
      "k" "unsigned int" _ (by decide +kernel)) "power" "unsigned int" _ (by decide +kernel)

theorem power_q_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (live : q.Live c.state) :
    q.Live (afterPower stage).state := ⟨power_borrow stage live.1,power_borrow stage live.2⟩

end ScopedC.ExpPointCalls
