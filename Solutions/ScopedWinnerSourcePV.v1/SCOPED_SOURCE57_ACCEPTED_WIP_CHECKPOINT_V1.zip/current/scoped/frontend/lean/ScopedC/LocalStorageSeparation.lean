/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.LocalAssignment

namespace ScopedC.LocalStorageSeparation
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Distinct physical object types cannot occupy the same source stack cell. -/
theorem typed {s : State} {a b ta tb : String} {va vb : Value} {sa sb : Nat}
    (ha : LocalBinding.At s a ta va sa) (hb : LocalBinding.At s b tb vb sb) (different : ta≠tb) : sa≠sb := by
  intro same
  have memory:=ha.memory
  rw[same,hb.memory] at memory
  have types:=congrArg (fun x : Option Object=>x.map Object.type) memory
  change some tb=some ta at types
  exact different (Option.some.inj types).symm

/-- A real scalar local of a type different from the unsigned pool counter
cannot alias any of the three pool-mutated objects. All separation follows
from actual storage and the existing pool invariant. -/
theorem pool {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {name type : String} {value : Value} {slot : Nat}
    (storage : LocalBinding.At c.state name type value slot) (counterType : type≠"unsigned") :
    slot≠l.pool ∧ slot≠l.top ∧ slot≠l.high := by
  have hp : slot≠l.pool := by
    intro same
    have memory:=storage.memory
    rw[same,ctx.pool_read] at memory
    have flags:=congrArg (fun x : Option Object=>x.map Object.isArray) memory
    change some true=some false at flags
    contradiction
  have ht : slot≠l.top := by
    intro same
    have memory:=storage.memory
    rw[same,ctx.top_read] at memory
    have types:=congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "unsigned"=some type at types
    exact counterType (Option.some.inj types).symm
  have hh : slot≠l.high := by
    intro same
    have memory:=storage.memory
    rw[same,ctx.high_read] at memory
    have types:=congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "unsigned"=some type at types
    exact counterType (Option.some.inj types).symm
  exact ⟨hp,ht,hh⟩

end ScopedC.LocalStorageSeparation
