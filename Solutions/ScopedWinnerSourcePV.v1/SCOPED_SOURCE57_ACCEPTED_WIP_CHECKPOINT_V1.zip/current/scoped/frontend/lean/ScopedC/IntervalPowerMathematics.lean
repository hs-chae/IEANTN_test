/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalIntervalMultiplyRefinement
import LeanCert.Core.IntervalRat.Taylor

namespace ScopedC.IntervalPowerMathematics
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- The exact recursive interval-power contract already used by the original
consumer, written in the same parity order as the actual C program. -/
theorem power_step (a : IntervalRat) (q : Nat) (lower : 2 ≤ q) :
    IntervalRat.pow a q=
      if q%2=1 then IntervalRat.mul a (IntervalRat.mul (IntervalRat.pow a (q/2)) (IntervalRat.pow a (q/2)))
      else IntervalRat.mul (IntervalRat.pow a (q/2)) (IntervalRat.pow a (q/2)) := by
  cases q with
  | zero => omega
  | succ q =>
    cases q with
    | zero => omega
    | succ q =>
      rw[IntervalRat.pow]
      have half : (q+1+1)/2=q/2+1 := by omega
      by_cases odd : (q+2)%2=1
      · have even : (q+2)%2≠0 := by omega
        simp [odd,even,half]
      · have even : (q+2)%2=0 := by have h:=Nat.mod_lt (q+2) (by decide : 0<2);omega
        simp [odd,even,half]

/-- Exact mathematical step of the actual left-to-right source loop, with
the quotient-prefix invariant; no associativity or alternative power
algorithm is substituted for the original interval recursion. -/
theorem quotient_step (a : IntervalRat) (n bit : Nat) (lower : 2 ≤ n/bit) :
    (if (n/bit)%2=1 then
      IntervalRat.mul a (IntervalRat.mul (IntervalRat.pow a (n/(bit*2))) (IntervalRat.pow a (n/(bit*2))))
     else IntervalRat.mul (IntervalRat.pow a (n/(bit*2))) (IntervalRat.pow a (n/(bit*2))))=
      IntervalRat.pow a (n/bit) := by
  rw[←Nat.div_div_eq_div_mul]
  exact (power_step a (n/bit) lower).symm

theorem highest_prefix (n bit : Nat) (lower : bit ≤ n) (upper : n < bit*2) : n/bit=1 := by
  apply Nat.div_eq_of_lt_le
  · simpa using lower
  · simpa only[show (1:Nat)+1=2 from rfl,Nat.mul_comm] using upper

theorem power_two_half (k : Nat) : (2^(k+1))/2=2^k := by
  rw[pow_succ,Nat.mul_div_cancel]
  decide

theorem power_two_prefix (n k : Nat) : n/(2^k*2)=n/(2^(k+1)) := by rw[pow_succ]

end ScopedC.IntervalPowerMathematics
