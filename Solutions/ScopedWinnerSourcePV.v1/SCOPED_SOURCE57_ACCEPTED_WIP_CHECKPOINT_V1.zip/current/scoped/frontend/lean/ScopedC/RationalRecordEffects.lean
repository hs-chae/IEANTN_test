/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalRecordFields
import ScopedC.FromRIFrames
namespace ScopedC.RationalRecordFields
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalDecimalLiteral
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem advance {l : PoolLayout} {c : Cursor} {lo hi : Value} {slot : Nat}
    (ctx : Valid l c) (h : At c.state lo hi slot) (trace : List Nat) :
    At (CursorFrames.advance l c trace).state lo hi slot := by
  have safe := separated ctx h
  constructor
  · rw [(CursorEffects.shape l c trace).2]
    exact h.lookup
  · rw [CursorSingleFrames.advance_other l c trace slot safe.1 safe.2.1 safe.2.2]
    exact h.memory

theorem literal {c : Cursor} {lo hi : Value} {slot : Nat}
    (h : At c.state lo hi slot) (text : String) :
    At (DecimalInitialized.inputCursor c text).state lo hi slot := by
  have bound := (List.getElem?_eq_some_iff.mp h.memory).choose
  constructor
  · exact h.lookup
  · simpa only [DecimalInitialized.inputCursor,DecimalText.appendLiteral,
      List.getElem?_append_left bound] using h.memory

theorem decimal {code : List Syntax.Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : Stages code l c n d) (ctx : Valid l c) (signedRoom : D.numerator.top<capacity)
    {lo hi : Value} {slot : Nat} (h : At c.state lo hi slot) :
    At (after D).state lo hi slot := by
  have ns : At (textCursor c n).state lo hi slot := literal h _
  have num : At D.numerator.state lo hi slot := by
    rw [D.numeratorTrace]
    exact advance (DecimalInitialized.input_valid ctx _) ns _
  have sig : At (next l D.numerator 0).state lo hi slot := advance D.numeratorValid num [0]
  have ds : At (textCursor (next l D.numerator 0) d).state lo hi slot := literal sig _
  have den : At D.denominator.state lo hi slot := by
    rw [D.denominatorTrace]
    exact advance (DecimalInitialized.input_valid
      (next_valid 0 D.numeratorValid signedRoom) _) ds _
  rw [after_advance]
  exact advance D.denominatorValid den _

theorem scale_store {c : Cursor} {lo hi : Value} {slot object valueSlot number : Nat}
    (h : At c.state lo hi slot) (scale : SourceFromS.ScaleAt c.state object valueSlot number)
    (newLo newHi : Value) :
    SourceFromS.ScaleAt (changed c.state slot newLo newHi) object valueSlot number := by
  have distinct : slot≠object := by
    intro same
    have memory := h.memory
    rw [same,scale.storage] at memory
    have types := congrArg (fun x : Option Object=>x.map Object.type) memory
    change some "N"=some "RI" at types
    contradiction
  constructor
  · exact scale.lookup
  · simpa only [changed,List.getElem?_set_ne distinct] using scale.storage
  · exact scale.live

theorem read_ri (service : Call) (fuel : Nat) {s : State}
    (a : FromRIFrames.InputRI) {slot : Nat}
    (h : At s a.lo.source a.hi.source slot) :
    evalExpr Header.layout service (fuel+1) s (.var "r")=some (a.source,s) := by
  have initialized : Machine.initialized 1000 (.record "RI" [a.lo.source,a.hi.source])=true := by
    simp [Machine.initialized,value,FromRIFrames.InputRI.source,IntervalCasts.value,
      RationalPairFrames.Input.source,DyadicRepresentation.Endpoint.source,SignedValues.value,
      NatWrapperCalls.unsigned32]
  simp [evalExpr,getVar,h.lookup,h.memory,object,Machine.read,nested,initialized,
    value,FromRIFrames.InputRI.source,IntervalCasts.value]

end ScopedC.RationalRecordFields
