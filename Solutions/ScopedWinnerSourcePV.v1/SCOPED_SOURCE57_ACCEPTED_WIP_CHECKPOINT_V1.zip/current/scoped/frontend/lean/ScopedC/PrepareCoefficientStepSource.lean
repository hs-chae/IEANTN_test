/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientAtanhRun
import ScopedC.PrepareCoefficientStepEffects
import ScopedC.PrepareCoefficientExpSource
import ScopedC.ExpFactorialCondition

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

noncomputable def expStage {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    CoeffWork l object d eb ab := expWork f (by omega) active

theorem expStage_room {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (expStage f active room).cursor.top+18<PoolCalls.capacity := by
  change (expStoreCursor f _).top+18<PoolCalls.capacity
  rw[expStore_top];omega

theorem expStage_bound {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    (expStage f active room).atanhCoeffs.length<65 := by
  change f.atanhCoeffs.length<65
  rw[f.atanhLength];have h:=f.depthBound;omega

noncomputable def writtenStage {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) :
    CoeffWork l object d eb ab :=
  (expStage f active room).atanhWritten (expStage_room f active room) f.kPositive
    (expStage_bound f active room)

structure CoefficientAnswers (service : Call) {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} (f : CoeffFrame l object d eb ab)
    (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity) : Prop where
  qi : service "qi" [PoolCalls.word f.k] f.cursor.state=
    some ((counterQ f).source,(counterQCursor f).state)
  divide : service "qv" [(previous f).source,(counterQ f).source] (counterQCursor f).state=
    some ((expNext f).source,(expDivideCursor f).state)
  atanh : CoeffWork.AtanhAnswers service (expStage f active room) (expStage_room f active room) f.kPositive

def coefficientAssignment : Expr := .binary "=" (.index (.var "expCoeffs") (.var "k"))
  (.call (.var "qv") [.index (.var "expCoeffs") (.binary "-" (.var "k") (.nat 1)),
    .call (.var "qi") [.var "k"]])
def coefficientIncrement : Expr := .binary "=" (.var "k") (.binary "+" (.var "k") (.nat 1))
def coefficientBody : Stmt :=
  .sequence [.eval coefficientAssignment,.eval CoeffWork.atanhAssignment,.eval coefficientIncrement]
def coefficientCondition : Expr := .binary "<=" (.var "k") (.var "depth")

theorem coefficientStep_run (service : Call) {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} (f : CoeffFrame l object d eb ab)
    (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity)
    (answers : CoefficientAnswers service f active room) :
    Run Header.layout service coefficientBody f.cursor.state
      (.continuing (coefficientStep f active room).cursor.state) := by
  have first:=expUpdate_assignment service f (by omega) active answers.qi answers.divide
  obtain ⟨v,second⟩:=CoeffWork.atanhWritten_eval service (expStage f active room)
    (expStage_room f active room) f.kPositive f.atanhLength (expStage_bound f active room)
    (by change f.k<2^32;have h:=f.depthBound;omega) answers.atanh
  have third:=CoeffWork.increment_source service (writtenStage f active room)
    (by change (CoeffWork.atanhWritten _ _ _ _).k+1<2^32
        have key:=CoeffWork.atanhWritten_k (expStage f active room) (expStage_room f active room)
          f.kPositive (expStage_bound f active room)
        change (writtenStage f active room).k+1<2^32
        have k : (writtenStage f active room).k=f.k:=key
        rw[k];have h:=f.depthBound;omega)
  apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.evaluate first)
    (Loops.SeqRun.next (Loops.StmtRun.evaluate second)
      (Loops.SeqRun.next (Loops.StmtRun.evaluate third) (Loops.SeqRun.nil _))))
  exact (PoolCalls.pop_same (coefficientStep_shape f active room).1
    (coefficientStep_shape f active room).2).symm

theorem coefficientCondition_eval (service : Call) {l : PoolCalls.PoolLayout}
    {object d : Nat} {eb ab : Address} (f : CoeffFrame l object d eb ab) :
    Eval Header.layout service coefficientCondition f.cursor.state f.cursor.state
      (boolean Header.layout (decide (f.k ≤ d))) := by
  have db:=f.depthBound
  have kb:=f.kBound
  exact ⟨3,ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (LocalBinding.eval service 1 f.kAt (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel))
    (SourceUnsignedGlobal.eval service 1 f.depthAt f.depthUnshadowed (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (ExpFactorial.binary_le f.cursor.state f.k d (by omega) (by omega))⟩

end ScopedC.PrepareSource
