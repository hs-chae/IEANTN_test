/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareLn2Atanh
import ScopedC.IntervalProductApplicability

namespace ScopedC.PrepareSource.Ln2
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000

@[irreducible] def productCursor {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) : Cursor :=
  RationalIntervalMultiplyCalls.after l a.out (pointTwo l c) a.output

def product {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) : RationalIntervalFrames.Pair :=
  RationalIntervalMultiplyCalls.outputPair l a.out (pointTwo l c) a.output

theorem product_source (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs)
    (room : c.top+9101<PoolCalls.capacity) :
    SourceCall Header.layout code 8 "rmul" [(pointTwo l c).source,a.output.source]
      a.out.state (product a).source (productCursor a).state := by
  unfold productCursor
  exact RationalIntervalMultiplyCalls.rmul_closed code installed lib a.valid
    (by have bound:=a.top;rw[beforeAtanh_top] at bound;omega) _ _
    (a.pair (pointTwo_live ctx (by omega))) a.live (pointTwo_positive l c) a.positive

theorem product_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs)
    (room : c.top+9101<PoolCalls.capacity) : Valid l (productCursor a) := by
  unfold productCursor
  exact RationalIntervalMultiplyCalls.after_valid a.valid
    (by have bound:=a.top;rw[beforeAtanh_top] at bound;omega) _ _

theorem product_live {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) :
    (product a).Live (productCursor a).state := by
  unfold productCursor
  exact RationalIntervalMultiplyCalls.after_live _ _ _ _

theorem product_positive {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs) : (product a).Positive :=
  RationalIntervalMultiplyCalls.output_positive l a.out (pointTwo l c) a.output (pointTwo_positive l c) a.positive

theorem mul_two (I : IntervalRat) : IntervalRat.mul (IntervalRat.singleton 2) I=IntervalRat.scale 2 I := by
  have order : (2:Rat)*I.lo ≤ 2*I.hi:=mul_le_mul_of_nonneg_left I.le (by norm_num)
  simp [IntervalRat.mul,IntervalRat.singleton,IntervalRat.min4,IntervalRat.max4,
    IntervalRat.scale,min_eq_left order,max_eq_right order]

theorem product_model {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {d : Nat} {coeffs : List Input} (a : AtanhStage code l c d coeffs)
    (values : TaylorCalls.coefficientValues coeffs=IntervalRat.atanhTaylorCoeffs d) :
    NumericRepresentation.interval (productCursor a).state (product a).source=
      some (IntervalRat.ln2Computable d) := by
  have twoValues:=pointTwo_value l c
  have atanValues:=atanh_values a values
  have twoOrder : (pointTwo l c).lo.mathematical.value ≤ (pointTwo l c).hi.mathematical.value := le_refl _
  have atanOrder:=a.ordered (ratio_narrow l c)
  have result:=NumericRationalIntervalMultiplyRefinement.decoded_result l a.out
    (pointTwo l c) a.output (pointTwo_positive l c) a.positive twoOrder atanOrder
  have left : (⟨(pointTwo l c).lo.mathematical.value,(pointTwo l c).hi.mathematical.value,twoOrder⟩:IntervalRat)=
      IntervalRat.singleton 2 := by
    rw[IntervalRat.mk.injEq]
    exact twoValues
  have right : (⟨a.output.lo.mathematical.value,a.output.hi.mathematical.value,atanOrder⟩:IntervalRat)=
      IntervalRat.atanhPointComputable (1/3) d := by
    rw[IntervalRat.mk.injEq]
    exact atanValues
  rw[left,right,mul_two] at result
  unfold productCursor
  exact result

end ScopedC.PrepareSource.Ln2
