/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalDivideRefinement
import ScopedC.RationalMultiplyTrace
import ScopedC.RationalMultiplyPreservation

namespace ScopedC.RationalDivideCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem base_length (c : Cursor) (a b : Input) :
    (base c a b).state.heap.length=c.state.heap.length+2 := by
  simp [base,CursorFrames.framed,TwoFrames.frame,allocate]

theorem made_length (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (made l c a b).state.heap.length=(base c a b).state.heap.length :=
  (PoolCursor.shape l (tested l c a b) 0).1.trans (PoolCursor.shape l (base c a b) 0).1

theorem inverse_length (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (inverseCursor l c a b).state.heap.length=c.state.heap.length+3 := by
  simp only[inverseCursor,CursorLocals.allocated,allocate,List.length_append,List.length_singleton]
  rw[made_length,base_length]

theorem nonzero_globals (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (nonzeroAfter l c a b).state.globals=c.state.globals := by
  change (productEnd l c a b).state.globals=_
  unfold productEnd
  rw[RationalMultiplyTrace.globals]
  exact (CursorSingleFrames.globals l (tested l c a b) 0).trans
    (CursorSingleFrames.globals l (base c a b) 0)

theorem nonzero_env (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (nonzeroAfter l c a b).state.env=c.state.env := rfl

theorem nonzero_heap_length (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (nonzeroAfter l c a b).state.heap.length=c.state.heap.length := by
  change (((productEnd l c a b).state.heap.take (base c a b).state.heap.length).take
    c.state.heap.length).length=c.state.heap.length
  rw[List.length_take,List.length_take]
  unfold productEnd
  rw[(RationalMultiplyCalls.shape l (inverseCursor l c a b) a (inverse b)).1,
    inverse_length,base_length]
  omega

theorem nonzero_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (nonzeroAfter l c a b).top=c.top+13 := by
  change (productEnd l c a b).top=_
  unfold productEnd
  rw[RationalMultiplyCalls.top11]
  rfl

theorem nonzero_borrow {l : PoolCalls.PoolLayout} {c : Cursor} (a b : Input)
    {slot value : Nat} (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (nonzeroAfter l c a b).state.nats slot value := by
  have first : NatArena.Borrow (tested l c a b).state.nats slot value :=
    PoolCursor.preserves (c:=base c a b) live
  have second : NatArena.Borrow (made l c a b).state.nats slot value :=
    PoolCursor.preserves (c:=tested l c a b) first
  change NatArena.Borrow (productEnd l c a b).state.nats slot value
  unfold productEnd
  exact RationalMultiplyCalls.preserves (c:=inverseCursor l c a b) (a:=a) (b:=inverse b) second

theorem nonzero_other (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (slot : Nat)
    (old : slot<c.state.heap.length) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (nonzeroAfter l c a b).state.heap[slot]?=c.state.heap[slot]? := by
  change (((productEnd l c a b).state.heap.take (base c a b).state.heap.length).take
    c.state.heap.length)[slot]?=c.state.heap[slot]?
  rw[List.getElem?_take_of_lt old,List.getElem?_take_of_lt (by rw[base_length];omega)]
  unfold productEnd
  rw[RationalMultiplyTrace.other l (inverseCursor l c a b) a (inverse b) slot hp ht hh]
  change ((made l c a b).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left (by rw[made_length,base_length];omega)]
  change (next l (tested l c a b) 0).state.heap[slot]?=_
  rw[PoolCursor.other l (tested l c a b) 0 slot hp ht hh]
  change (next l (base c a b) 0).state.heap[slot]?=_
  rw[PoolCursor.other l (base c a b) 0 slot hp ht hh]
  simp [base,CursorFrames.framed,TwoFrames.frame,allocate,List.getElem?_append_left old]

end ScopedC.RationalDivideCalls
