/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalMultiplyRefinement
import ScopedC.NumericRationalSubRefinement
import ScopedC.PoolContextPop
import ScopedC.NumericNatsExtensionality

namespace ScopedC.RationalDivideCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def base (c : Cursor) (a b : Input) : Cursor := CursorFrames.framed c "Q" "a" a.source "Q" "b" b.source
def tested (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (base c a b) 0
def made (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (tested l c a b) 0

def zeroEnd (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  CursorFrames.advance l (tested l c a b) [0,0,1]
def zeroInput (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Input :=
  ⟨⟨(tested l c a b).state.nats.values.length,0,false⟩,
    (next l (next l (tested l c a b) 0) 0).state.nats.values.length,1⟩
def zeroAfter (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  PoolContextPop.unframe c.state (zeroEnd l c a b)

def inverse (b : Input) : Input := ⟨⟨b.denSlot,b.denominator,b.numerator.negative⟩,b.numerator.slot,b.numerator.magnitude⟩
def inverseCursor (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  CursorLocals.allocated (made l c a b) "Q" "inverse" (inverse b).source
@[irreducible] def productEnd (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  RationalMultiplyCalls.c11 l (inverseCursor l c a b) a (inverse b)
def bodyEnd (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  PoolContextPop.unframe (base c a b).state (productEnd l c a b)
def nonzeroAfter (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  PoolContextPop.unframe c.state (bodyEnd l c a b)
def nonzeroResult (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Value :=
  RationalMultiplyCalls.result l (inverseCursor l c a b) a (inverse b)
def nonzeroModel (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Rational :=
  ⟨(RationalMultiplyCalls.top l (inverseCursor l c a b) a (inverse b)).mathematical,RationalMultiplyCalls.den a (inverse b)⟩

def result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Value :=
  if b.numerator.magnitude=0 then (zeroInput l c a b).source else nonzeroResult l c a b
def after (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  if b.numerator.magnitude=0 then zeroAfter l c a b else nonzeroAfter l c a b
def output (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Rational :=
  if b.numerator.magnitude=0 then ⟨⟨0,false⟩,1⟩ else nonzeroModel l c a b

theorem inverse_live {s : State} {b : Input} (hb : b.Live s) : (inverse b).Live s := ⟨hb.2,hb.1⟩

theorem inverse_value (b : Input) : (inverse b).mathematical.value=b.mathematical.value⁻¹ := by
  cases hn : b.numerator.negative <;>
    simp [inverse,Input.mathematical,Endpoint.mathematical,Rational.value,Signed.value,hn,inv_div,neg_div]

theorem inverse_normalized (b : Input) (hb : b.mathematical.Normalized) (nonzero : b.numerator.magnitude≠0) :
    (inverse b).mathematical.Normalized := by
  refine ⟨Nat.pos_of_ne_zero nonzero,hb.2.1.symm,?_⟩
  intro hz
  exact False.elim ((Nat.ne_of_gt hb.1) hz)

theorem base_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) : Valid l (base c a b) :=
  CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source

theorem tested_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) : Valid l (tested l c a b) :=
  next_valid 0 (base_context ctx a b) (by change c.top<PoolCalls.capacity;omega)

theorem made_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) : Valid l (made l c a b) :=
  next_valid 0 (tested_context ctx room a b) (by change c.top+1<PoolCalls.capacity;omega)

theorem inverse_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) : Valid l (inverseCursor l c a b) :=
  CursorLocals.allocated_valid (made_context ctx room a b) "Q" "inverse" (inverse b).source

theorem product_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) : Valid l (productEnd l c a b) := by
  rw[productEnd]
  exact (RationalMultiplyCalls.contexts (inverse_context ctx room a b)
    (by change c.top+1+1+10<PoolCalls.capacity;omega) a (inverse b)).2.2.2.2.2.2.2.2.2.2

theorem zero_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) : Valid l (zeroAfter l c a b) :=
  PoolContextPop.valid (CursorFrames.advance_valid (tested_context ctx room a b) [0,0,1] (by change c.top+1+3≤PoolCalls.capacity;omega))
    ((List.getElem?_eq_some_iff.mp ctx.pool_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.top_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.high_read).choose)

theorem nonzero_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) : Valid l (nonzeroAfter l c a b) := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  have inner : Valid l (bodyEnd l c a b) := PoolContextPop.valid (product_context ctx room a b)
    (by simp only[base,CursorFrames.framed,TwoFrames.frame,allocate,List.length_append,List.length_singleton];omega)
    (by simp only[base,CursorFrames.framed,TwoFrames.frame,allocate,List.length_append,List.length_singleton];omega)
    (by simp only[base,CursorFrames.framed,TwoFrames.frame,allocate,List.length_append,List.length_singleton];omega)
  exact PoolContextPop.valid inner hp ht hh

theorem after_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+12<PoolCalls.capacity) (a b : Input) : Valid l (after l c a b) := by
  unfold after
  split
  · exact zero_context ctx room a b
  · exact nonzero_context ctx room a b

theorem zero_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (zeroInput l c a b).Live (zeroAfter l c a b).state := by
  exact ⟨PoolCursor.preserves (PoolCursor.preserves (PoolCursor.next_borrow l (tested l c a b) 0)),
    PoolCursor.next_borrow l (next l (next l (tested l c a b) 0) 0) 1⟩

theorem decoded (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) :
    NumericRepresentation.rational (after l c a b).state (result l c a b)=some (output l c a b) := by
  by_cases hz : b.numerator.magnitude=0
  · simp only[after,result,output,if_pos hz]
    exact Input.decoded (zero_live l c a b) (by change 0<1;decide +kernel)
  · simp only[after,result,output,if_neg hz]
    rw [NumericNatsExtensionality.rational (s:=(nonzeroAfter l c a b).state) (t:=(productEnd l c a b).state) rfl]
    unfold productEnd
    exact RationalMultiplyCalls.decoded l (inverseCursor l c a b) a (inverse b) pa (Nat.pos_of_ne_zero hz)

theorem value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (pa : 0<a.denominator) (pb : 0<b.denominator) :
    (output l c a b).value=a.mathematical.value/b.mathematical.value := by
  by_cases hz : b.numerator.magnitude=0
  · simp [output,hz,Input.mathematical,Endpoint.mathematical,Rational.value,Signed.value]
  · simp only[output,if_neg hz]
    unfold nonzeroModel
    rw [RationalMultiplyCalls.value l (inverseCursor l c a b) a (inverse b) pa (Nat.pos_of_ne_zero hz),inverse_value,div_eq_mul_inv]

end ScopedC.RationalDivideCalls
