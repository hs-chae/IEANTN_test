/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhEntry
import ScopedC.RationalPowerFramedBody
import ScopedC.NumericRationalCompareRefinement

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure GuardLibrary (code : List Function) : Prop where
  absolute : RationalAbsApplicability.Library code
  powers : RationalPowerCalls.Library code
  qc : Generated.f_qc∈code
  sc : Generated.f_sc∈code
  sm : Generated.f_sm∈code
  nm : Generated.f_nm∈code
  nlt : Generated.f_nlt∈code

def oneInput (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Input :=
  RationalUnsignedTrace.output l (afterR l c q) 1

def afterOne (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  RationalUnsignedTrace.after l (afterR l c q) 1

def afterGuard (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  RationalCompareCalls.final l (afterOne l c q) (absInput q) (oneInput l c q)

def guardValue (q : Input) : Int :=
  NumericRationalCompareRefinement.compareRat (absInput q).mathematical.value 1

def guardExpression : Expr := .binary ">="
  (.call (.var "qc") [.var "r",.call (.var "qi") [.nat 1]]) (.nat 0)

theorem guard_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (room : c.top+9<PoolCalls.capacity) : Valid l (afterGuard l c q) :=
  RationalCompareCalls.final_context
    (CursorFrames.advance_valid (afterR_context ctx q (by omega)) [1,0,1] (by
      change c.top+1+3≤PoolCalls.capacity;omega))
    (by change c.top+1+3+5<PoolCalls.capacity;omega) _ _

theorem one_call (code : List Function) (lib : GuardLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (room : c.top+9<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qi" [DecimalDigits.integer 1] (afterR l c q).state
      (oneInput l c q).source (afterOne l c q).state :=
  (RationalUnsignedTrace.qi_traced code lib.powers.qi lib.powers.si lib.absolute.smake
    lib.absolute.nz lib.absolute.nu lib.absolute.ne lib.absolute.keep
    (afterR_context ctx q (by omega)) 1 (by decide +kernel)
    (by change c.top+1+2<PoolCalls.capacity;omega) (DecimalDigits.integer 1) (by rfl)).1

theorem compare_call (code : List Function) (lib : GuardLibrary code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (live : q.Live c.state) (positive : 0<q.denominator)
    (room : c.top+9<PoolCalls.capacity) :
    SourceCall Header.layout code 6 "qc" [(absInput q).source,(oneInput l c q).source]
      (afterOne l c q).state (SignedCompareCalls.integer (guardValue q))
      (afterGuard l c q).state := by
  have rLive : (absInput q).Live (afterR l c q).state:=RationalAbsApplicability.live live
  have rAfter : (absInput q).Live (afterOne l c q).state:=
    ⟨CursorBorrow.preserves [1,0,1] rLive.1,CursorBorrow.preserves [1,0,1] rLive.2⟩
  have oneLive:=(RationalUnsignedTrace.live l (afterR l c q) 1)
  have raw:=NumericRationalCompareRefinement.qc_math code lib.qc lib.sc lib.sm lib.nm
    lib.absolute.smake lib.absolute.nz lib.absolute.nu lib.absolute.ne lib.nlt lib.absolute.keep
    (CursorFrames.advance_valid (afterR_context ctx q (by omega)) [1,0,1] (by
      change c.top+1+3≤PoolCalls.capacity;omega))
    (by change c.top+1+3+5<PoolCalls.capacity;omega)
    (absInput q) (oneInput l c q) rAfter oneLive positive (by change 0<(1:Nat);decide +kernel)
  have oneValue : (oneInput l c q).mathematical.value=(1:Rat):=
    (RationalUnsignedTrace.mathematical l (afterR l c q) 1).1
  simpa only[oneValue,guardValue,afterGuard,afterOne,RationalUnsignedTrace.after] using raw.1

theorem guard_comparison (s : State) (x : Int) (bound : x= -1 ∨ x=0 ∨ x=1) :
    binaryValue Header.layout s ">=" (SignedCompareCalls.integer x)
      (SignedCompareCalls.integer 0)=some (boolean Header.layout (decide (0≤x))) := by
  rcases bound with rfl | rfl | rfl <;> rfl

theorem guard_range (q : Input) : guardValue q= -1 ∨ guardValue q=0 ∨ guardValue q=1 := by
  unfold guardValue NumericRationalCompareRefinement.compareRat
  split_ifs <;> simp

theorem guard_eval (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input)
    (oneAnswer : service "qi" [DecimalDigits.integer 1] (afterR l c q).state=
      some ((oneInput l c q).source,(afterOne l c q).state))
    (compareAnswer : service "qc" [(absInput q).source,(oneInput l c q).source]
      (afterOne l c q).state=some (SignedCompareCalls.integer (guardValue q),(afterGuard l c q).state)) :
    Eval Header.layout service guardExpression (afterR l c q).state (afterGuard l c q).state
      (boolean Header.layout (decide (0≤guardValue q))) := by
  have rEval:=LocalBinding.eval service 3 (r_binding l c q)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have oneEval:=ExpressionTemplates.call_one Header.layout service
    (show evalExpr Header.layout service 3 (afterR l c q).state (.nat 1)=
      some (DecimalDigits.integer 1,(afterR l c q).state) from rfl) oneAnswer
  have compareEval:=ExpressionTemplates.call_two Header.layout service rEval oneEval compareAnswer
  refine ⟨6,ExpressionTemplates.binary Header.layout service (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) compareEval (by rfl)
    (guard_comparison _ _ (guard_range q))⟩

theorem guard_truth (q : Input) :
    decide (0≤guardValue q)=decide (1≤|q.mathematical.value|) := by
  rw[←RationalAbsApplicability.value q]
  unfold guardValue absInput NumericRationalCompareRefinement.compareRat
  split_ifs <;> simp_all <;> linarith

end ScopedC.AtanhCalls
