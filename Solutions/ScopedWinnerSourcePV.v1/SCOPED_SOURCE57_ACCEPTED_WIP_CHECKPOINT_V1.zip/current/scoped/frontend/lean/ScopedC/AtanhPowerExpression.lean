/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhPower
namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterGuard

theorem power_eval_at (service : Call) (fuel : Nat) {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) (d object : Nat)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) (dBound : d≤64)
    (room : c.top+9<PoolCalls.capacity) {out : Cursor} {result : Input}
    (answer : service "qpow" [(absInput q).source,PoolCalls.word (d+1)]
      (afterGuard l c q).state=some (result.source,out.state)) :
    evalExpr Header.layout service (fuel+4) (afterGuard l c q).state powerExpression=
      some (result.source,out.state) := by
  have rEval:=LocalBinding.eval service (fuel+2) (r_guard_binding ctx q room)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have dEval:=SourceUnsignedGlobal.eval service (fuel+1) (guard_depth q depth apart)
    (guard_depth_unshadowed l c q) (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have exponent : evalExpr Header.layout service (fuel+3) (afterGuard l c q).state
      (.binary "+" (.var "depth") (.nat 1))=
      some (PoolCalls.word (d+1),(afterGuard l c q).state) :=
    ExpressionTemplates.binary Header.layout service (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) dEval
      (show evalExpr Header.layout service (fuel+2) (afterGuard l c q).state (.nat 1)=
        some (DecimalDigits.integer 1,(afterGuard l c q).state) from rfl)
    (PoolCalls.binary_add_one (afterGuard l c q).state d (by omega))
  exact ExpressionTemplates.call_two Header.layout service rEval exponent answer

end ScopedC.AtanhCalls
