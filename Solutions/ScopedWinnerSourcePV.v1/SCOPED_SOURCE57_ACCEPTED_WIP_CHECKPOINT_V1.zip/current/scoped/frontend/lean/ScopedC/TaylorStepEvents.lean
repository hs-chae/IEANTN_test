/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorStepSource
import ScopedC.CallEventNameTimeline

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

abbrev Event (code : List Function) := CallEvents.Event Header.layout code 8
def EventAnswers {code : List Function} (service : Call) (events : List (Event code)) : Prop :=
  ∀e∈events,service e.name e.args e.before=some (e.value,e.after)

def pointEvent (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : Event code :=
  ⟨"point",[coeffs[f.k].source],f.cursor.state,(pointInput f hk).source,f.cursor.state,
    raise_once (raise_once (raise_once (raise_once (raise_once (raise_once (raise_once (point_call code lib f hk)))))))⟩
def productEvent (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (room : f.cursor.top+107<PoolCalls.capacity) : Event code :=
  ⟨"rmul",[f.result.source,f.a.source],f.cursor.state,(product f).source,(productCursor f).state,product_call code lib f room⟩
noncomputable def sumEvent (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) : Event code :=
  ⟨"radd",[(pointInput f hk).source,(product f).source],(productCursor f).state,(sum f hk).source,(sumCursor f hk).state,
    raise_once (sum_call code lib f hk room)⟩
noncomputable def stepEvents (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) : List (Event code) :=
  [pointEvent code lib f hk,productEvent code lib f room,sumEvent code lib f hk room]

theorem step_event_run (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity)
    (service : Call) (answers : EventAnswers service (stepEvents code lib f hk room)) :
    Eval Header.layout service stepExpression f.cursor.state (stepped f hk room).cursor.state (sum f hk).source := by
  apply stepped_source service f hk room
  exact ⟨answers (pointEvent code lib f hk) (List.mem_cons_self),
    answers (productEvent code lib f room) (List.mem_cons_of_mem _ (List.mem_cons_self)),
    answers (sumEvent code lib f hk room) (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_cons_self)))⟩

theorem step_keys (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    (stepEvents code lib f hk room).map CallEvents.nameKey=
      [(f.cursor.state.nats.values.length,"point"),(f.cursor.state.nats.values.length,"rmul"),
        (f.cursor.state.nats.values.length+80,"radd")] := by
  change [_,_,((productCursor f).state.nats.values.length,"radd")]=_
  rw[product_size]
  rfl

theorem step_unique (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    ((stepEvents code lib f hk room).map CallEvents.nameKey).Nodup := by
  rw[step_keys]
  simp

theorem step_bounds (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity)
    (e : Event code) (member : e∈stepEvents code lib f hk room) :
    f.cursor.state.nats.values.length ≤ e.before.nats.values.length ∧
      e.before.nats.values.length < (stepped f hk room).cursor.state.nats.values.length := by
  have keyMember : CallEvents.nameKey e∈(stepEvents code lib f hk room).map CallEvents.nameKey := List.mem_map.mpr ⟨e,member,rfl⟩
  rw[step_keys] at keyMember
  simp only[List.mem_cons,List.not_mem_nil,or_false] at keyMember
  rcases keyMember with key | key | key
  all_goals
    have count:=congrArg Prod.fst key
    change e.before.nats.values.length=_ at count
    rw[stepped_size]
    omega

end ScopedC.TaylorCalls
