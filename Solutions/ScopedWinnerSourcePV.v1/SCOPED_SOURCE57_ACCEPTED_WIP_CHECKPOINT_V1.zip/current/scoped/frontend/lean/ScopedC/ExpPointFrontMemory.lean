/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpPointFrontFrames

namespace ScopedC.ExpPointCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 250000
set_option maxRecDepth 100000

theorem allocated_other (c : Cursor) (type name : String) (value : Value)
    (slot : Nat) (old : slot < c.state.heap.length) :
    (CursorLocals.allocated c type name value).state.heap[slot]? = c.state.heap[slot]? :=
  List.getElem?_append_left old

theorem ceil_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (slot : Nat) (old : slot < c.state.heap.length)
    (hp : slot ≠ l.pool) (ht : slot ≠ l.top) (hh : slot ≠ l.high) :
    stage.out.state.heap[slot]? = c.state.heap[slot]? := by
  rw [stage.trace,CursorSingleFrames.advance_other]
  change (next l (parameters c q) 0).state.heap[slot]? = _
  rw [PoolCursor.other l (parameters c q) 0 slot hp ht hh]
  exact List.getElem?_append_left old
  all_goals assumption

theorem power_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (slot : Nat) (old : slot < c.state.heap.length)
    (hp : slot ≠ l.pool) (ht : slot ≠ l.top) (hh : slot ≠ l.high) :
    (afterPower stage).state.heap[slot]? = c.state.heap[slot]? := by
  have ceilLen := ceil_heap stage
  have ceilLocalLen : (afterCeil stage).state.heap.length = c.state.heap.length+2 := by
    change (stage.out.state.heap++[_]).length = _
    rw [List.length_append,List.length_singleton,ceilLen]
  have addLen : (afterAdd stage).state.heap.length = c.state.heap.length+2 :=
    ((PoolCursor.shape l (afterOne stage) (mValue stage)).1.trans
      (PoolCursor.shape l (afterCeil stage) 1).1).trans ceilLocalLen
  have mLen : (afterM stage).state.heap.length = c.state.heap.length+3 := by
    change ((afterAdd stage).state.heap++[_]).length = _
    rw [List.length_append,List.length_singleton,addLen]
  have smallLen : (afterSmall stage).state.heap.length = c.state.heap.length+3 :=
    ((PoolCursor.shape l (afterLog stage) 4294967295).1.trans
      (PoolCursor.shape l (afterM stage) (kValue stage)).1).trans mLen
  have kLen : (afterK stage).state.heap.length = c.state.heap.length+4 := by
    change ((afterSmall stage).state.heap++[_]).length = _
    rw [List.length_append,List.length_singleton,smallLen]
  have pOther : (afterPower stage).state.heap[slot]? = (afterK stage).state.heap[slot]? :=
    allocated_other _ _ _ _ slot (by rw [kLen]; omega)
  have kOther : (afterK stage).state.heap[slot]? = (afterSmall stage).state.heap[slot]? :=
    allocated_other _ _ _ _ slot (by rw [smallLen]; omega)
  have sOther : (afterSmall stage).state.heap[slot]? = (afterM stage).state.heap[slot]? :=
    (PoolCursor.other l (afterLog stage) 4294967295 slot hp ht hh).trans
      (PoolCursor.other l (afterM stage) (kValue stage) slot hp ht hh)
  have mOther : (afterM stage).state.heap[slot]? = (afterAdd stage).state.heap[slot]? :=
    allocated_other _ _ _ _ slot (by rw [addLen]; omega)
  have aOther : (afterAdd stage).state.heap[slot]? = (afterCeil stage).state.heap[slot]? :=
    (PoolCursor.other l (afterOne stage) (mValue stage) slot hp ht hh).trans
      (PoolCursor.other l (afterCeil stage) 1 slot hp ht hh)
  have cOther : (afterCeil stage).state.heap[slot]? = stage.out.state.heap[slot]? :=
    allocated_other _ _ _ _ slot (by omega)
  exact pOther.trans (kOther.trans (sOther.trans (mOther.trans (aOther.trans
    (cOther.trans (ceil_other stage slot old hp ht hh))))))

def power_table {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (valid : Valid l c)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs) :
    CoefficientTableRead.TableAt (afterPower stage).state base coeffs := by
  have safe := CoefficientTableRead.pool_separated valid table
  exact CoefficientTableRead.memory table
    (power_other stage base.object (List.getElem?_eq_some_iff.mp table.memory).choose
      safe.1 safe.2.1 safe.2.2) (fun _ _ h => power_borrow stage h)

theorem power_depth {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) {name : String} {object d : Nat}
    (depth : SourceUnsignedGlobal.At c.state name object d)
    (apart : object ≠ l.pool ∧ object ≠ l.top ∧ object ≠ l.high) :
    SourceUnsignedGlobal.At (afterPower stage).state name object d :=
  SourceUnsignedGlobal.memory depth (power_globals stage)
    (power_other stage object (List.getElem?_eq_some_iff.mp depth.storage).choose
      apart.1 apart.2.1 apart.2.2)

theorem power_scalar {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {q : Input} (stage : CeilStage code l c q) (valid : Valid l c)
    {name type : String} {object : Nat} {value : Option Value}
    (stored : SourceScalarGlobal.At c.state name type object value) (different : type ≠ "unsigned") :
    SourceScalarGlobal.At (afterPower stage).state name type object value := by
  have safe := SourceScalarGlobal.separated valid stored different
  exact SourceScalarGlobal.memory stored (power_globals stage)
    (power_other stage object (List.getElem?_eq_some_iff.mp stored.storage).choose
      safe.1 safe.2.1 safe.2.2)

end ScopedC.ExpPointCalls
