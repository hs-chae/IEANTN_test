/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderError

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

theorem error_valid {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (room : c.top+3000<PoolCalls.capacity) : Valid l (errorCursor r) := by
  have h:=radius_power_top r
  exact RationalDivideCalls.after_context (numerator_valid r room)
    (by rw[numerator_top];omega) _ _

theorem error_nonzero_cursor {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    errorCursor r=RationalDivideCalls.nonzeroAfter l (numeratorCursor r) (numerator r) f.loop.finish.fact := by
  unfold errorCursor RationalDivideCalls.after
  rw[if_neg (factorial_nonzero f)]

theorem error_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (errorCursor r).top=r.out.top+24 := by
  rw[error_nonzero_cursor,RationalDivideCalls.nonzero_top,numerator_top]

theorem error_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    {slot value : Nat} (live : NatArena.Borrow r.out.state.nats slot value) :
    NatArena.Borrow (errorCursor r).state.nats slot value := by
  rw[error_nonzero_cursor]
  have first : NatArena.Borrow (numeratorCursor r).state.nats slot value := by
    unfold numeratorCursor
    exact RationalMultiplyCalls.preserves live
  exact RationalDivideCalls.nonzero_borrow _ _ first

theorem numerator_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (numeratorCursor r).state.globals=r.out.state.globals := by
  unfold numeratorCursor
  exact RationalMultiplyTrace.globals l r.out p.output r.output

theorem numerator_env {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (numeratorCursor r).state.env=r.out.state.env := by
  unfold numeratorCursor
  exact (RationalMultiplyCalls.shape l r.out p.output r.output).2

theorem numerator_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (numeratorCursor r).state.heap.length=r.out.state.heap.length := by
  unfold numeratorCursor
  exact (RationalMultiplyCalls.shape l r.out p.output r.output).1

theorem numerator_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (slot : Nat) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (numeratorCursor r).state.heap[slot]?=r.out.state.heap[slot]? := by
  unfold numeratorCursor
  exact RationalMultiplyTrace.other l r.out p.output r.output slot hp ht hh

theorem error_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (errorCursor r).state.globals=r.out.state.globals := by
  rw[error_nonzero_cursor,RationalDivideCalls.nonzero_globals,numerator_globals]

theorem error_env {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (errorCursor r).state.env=r.out.state.env := by
  rw[error_nonzero_cursor,RationalDivideCalls.nonzero_env,numerator_env]

theorem error_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (errorCursor r).state.heap.length=r.out.state.heap.length := by
  rw[error_nonzero_cursor,RationalDivideCalls.nonzero_heap_length,numerator_heap]

theorem error_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (slot : Nat) (old : slot<r.out.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (errorCursor r).state.heap[slot]?=r.out.state.heap[slot]? := by
  rw[error_nonzero_cursor,RationalDivideCalls.nonzero_other l (numeratorCursor r)
    (numerator r) f.loop.finish.fact slot (by rw[numerator_heap];exact old) hp ht hh]
  exact numerator_other r slot hp ht hh

end ScopedC.ExpRemainderCalls
