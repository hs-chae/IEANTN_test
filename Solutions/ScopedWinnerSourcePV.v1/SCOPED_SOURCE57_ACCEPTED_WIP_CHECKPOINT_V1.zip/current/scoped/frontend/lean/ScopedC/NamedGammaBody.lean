/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedUnsignedCompletion
namespace ScopedC.NamedGammaBody
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def rational : LeanCert.Core.IntervalRat := ⟨5722/10000,5823/10000,by norm_num⟩

/-- Actual original nonzero named branch, including source qi/qi/qv calls,
both RI field writes and fromRI with its signed literal-one argument. -/
theorem named_gamma_closed (code : List Function) (installed : Generated.f_named∈code)
    (qv : Generated.f_qv∈code) (divide : RationalDivideCalls.Library code)
    (lib : NamedUnsignedCompletion.Library code) (kind : Nat)
    (kindBound : kind<2^32) (nonzero : kind≠0)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) {object valueSlot : Nat}
    (scale : SourceFromS.ScaleAt c.state object valueSlot (2^100)) (room : c.top+400<capacity) :
    ∃out : Cursor, ∃lo hi : Endpoint,
      SourceCall Header.layout code 9 "named" [NatWrapperCalls.unsigned32 kind]
        c.state (DyadicCasts.value lo.source hi.source true) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (LeanCert.Core.IntervalDyadic.ofIntervalRat rational (-100),true) := by
  let start := NamedFrames.initial c kind
  have startValid : Valid l start := NamedFrames.initial_valid ctx kind
  have record := NamedFrames.r_binding c kind
  have sourceScale : SourceFromS.ScaleAt start.state object valueSlot (2^100) := NamedFrames.scale scale kind
  have initialRoom : start.top+90<capacity := by
    change c.top+90<capacity
    omega
  obtain ⟨D⟩ := NamedUnsignedPair.stages_exist code qv divide startValid record
    5722 5823 10000 (by decide +kernel) (by decide +kernel) (by decide +kernel) initialRoom
  obtain ⟨service,raw,lo,hi,closed,branch,returnExpr,rawValid,loLive,hiLive,decoded⟩ :=
    NamedUnsignedCompletion.complete code lib D startValid record sourceScale
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) initialRoom
  have test := NamedFrames.condition service c kind kindBound
  have gammaBranch : Run Header.layout service
      (.branch (.binary "==" (.var "c") (.nat 0))
        (.sequence [
          .eval (.binary "=" (.field "." (.var "r") "lo")
            (RationalDecimalLiteral.initializer 31415926535897932 10000000000000000)),
          .eval (.binary "=" (.field "." (.var "r") "hi")
            (RationalDecimalLiteral.initializer 31415926535897933 10000000000000000))])
        (.sequence (NamedUnsignedBranch.statements 5722 5823 10000)))
      start.state (.continuing (NamedUnsignedBranch.after D).state) := by
    have flag : truth (boolean Header.layout (decide (kind=0)))=false := by
      rw [show decide (kind=0)=false by simp [nonzero]]
      rfl
    apply Loops.StmtRun.branch test
    rw [flag]
    exact branch
  have body : Run Header.layout service Generated.f_named.body (NamedFrames.parameters c.state kind)
      (.returned (popScope (NamedFrames.parameters c.state kind) raw.state)
        (DyadicCasts.value lo.source hi.source true)) := by
    rw [NamedFrames.actual_declaration]
    exact Loops.StmtRun.sequence
      (Loops.SeqRun.next (Loops.StmtRun.declare (NamedFrames.declaration service c kind))
        (Loops.SeqRun.next gammaBranch
          (Loops.SeqRun.returned (Loops.StmtRun.returnValue ⟨1000,returnExpr⟩)))) ⟨rfl,rfl⟩
  have arguments : bindArgs Header.layout Generated.f_named.parameters [NatWrapperCalls.unsigned32 kind] c.state=
      some (NamedFrames.parameters c.state kind) :=
    TypedFrames.bind_one Header.layout c.state "unsigned int" "c" _ _
      (PositiveCasts.cast_unsigned {c.state with env:=[]} 99 kind kindBound)
  let out := PoolContextPop.unframe c.state raw
  have source : SourceCall Header.layout code 9 "named" [NatWrapperCalls.unsigned32 kind]
      c.state (DyadicCasts.value lo.source hi.source true) out.state := by
    apply installed_body (f:=Generated.f_named) (rank:=8) (service:=service) installed closed arguments body
    constructor
    · exact DyadicCasts.record _ 97 "static I" (by decide +kernel) lo.source hi.source true
        (Endpoint.cast 97 "S" (by decide +kernel) loLive)
        (Endpoint.cast 97 "S" (by decide +kernel) hiLive)
    · change popScope c.state raw.state=popScope c.state
        (popScope (NamedFrames.parameters c.state kind) raw.state)
      rw [SourceFromS.scope_twice c.state (NamedFrames.parameters c.state kind) raw.state
        (by simp [NamedFrames.parameters,OneFrames.frame,allocate])]
  have outValid : Valid l out := PoolContextPop.valid rawValid
    (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
    (List.getElem?_eq_some_iff.mp ctx.top_read).choose
    (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  refine ⟨out,lo,hi,source,outValid,loLive,hiLive,?_⟩
  change DyadicRepresentation.interval raw.state (DyadicCasts.value lo.source hi.source true)=_
  simpa only [NamedUnsignedPair.input,rational,D.low.value,D.high.value,Nat.cast_ofNat] using decoded

#print axioms named_gamma_closed
end ScopedC.NamedGammaBody
