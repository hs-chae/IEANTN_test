/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceScalarGlobal
import ScopedC.PrepareCoefficientStepSource

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

theorem expWork_scalar {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) (active : f.k ≤ d)
    {name type : String} {slot : Nat} {value : Option Value}
    (h : SourceScalarGlobal.At f.cursor.state name type slot value) (different : type≠"unsigned") :
    SourceScalarGlobal.At (expWork f room active).cursor.state name type slot value := by
  have first:=SourceScalarGlobal.advanced f.context h different [f.k,0,1]
  have divided : SourceScalarGlobal.At (expDivideCursor f).state name type slot value := by
    rw[expDivide_nonzero]
    exact SourceScalarGlobal.nonzero_division (counterQ_valid f room) first different (previous f) (counterQ f)
  change SourceScalarGlobal.At (expStoreCursor f room).state name type slot value
  unfold expStoreCursor
  exact SourceScalarGlobal.coefficient_store divided (dividedExpTable f room) f.k (expNext f)

theorem expWork_borrow {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (room : f.cursor.top+15<PoolCalls.capacity) (active : f.k ≤ d)
    {slot value : Nat} (h : NatArena.Borrow f.cursor.state.nats slot value) :
    NatArena.Borrow (expWork f room active).cursor.state.nats slot value := by
  change NatArena.Borrow (expStoreCursor f room).state.nats slot value
  unfold expStoreCursor
  change NatArena.Borrow (expDivideCursor f).state.nats slot value
  rw[expDivide_nonzero]
  exact RationalDivideCalls.nonzero_borrow (previous f) (counterQ f)
    (CursorBorrow.preserves (l:=l) (c:=f.cursor) [f.k,0,1] h)

namespace CoeffWork

theorem atanhWritten_scalar {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) {name type : String} {slot : Nat} {value : Option Value}
    (h : SourceScalarGlobal.At w.cursor.state name type slot value) (different : type≠"unsigned") :
    SourceScalarGlobal.At (w.atanhWritten room positive bound).cursor.state name type slot value := by
  unfold atanhWritten
  split
  · have first : SourceScalarGlobal.At (w.oddOne room).cursor.state name type slot value:=
      SourceScalarGlobal.advanced w.context h different [1,0,1]
    have second : SourceScalarGlobal.At (w.oddCounter room).cursor.state name type slot value:=
      SourceScalarGlobal.advanced (w.oddOne room).context first different [w.k,0,1]
    have divided : SourceScalarGlobal.At (w.oddWork room positive).cursor.state name type slot value:=
      SourceScalarGlobal.nonzero_division (w.oddCounter room).context second different
        (w.qiInput 1) ((w.oddOne room).qiInput w.k)
    exact SourceScalarGlobal.coefficient_store divided (w.oddWork room positive).atanhAt _ (w.oddInput room)
  · have first : SourceScalarGlobal.At (w.qiWork 0 (by omega)).cursor.state name type slot value:=
      SourceScalarGlobal.advanced w.context h different [0,0,1]
    exact SourceScalarGlobal.coefficient_store first (w.qiWork 0 (by omega)).atanhAt _ (w.qiInput 0)

theorem atanhWritten_borrow {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k)
    (bound : w.atanhCoeffs.length<65) {slot value : Nat} (h : NatArena.Borrow w.cursor.state.nats slot value) :
    NatArena.Borrow (w.atanhWritten room positive bound).cursor.state.nats slot value := by
  unfold atanhWritten
  split
  · change NatArena.Borrow (RationalDivideCalls.nonzeroAfter l (w.oddCounter room).cursor
      (w.qiInput 1) ((w.oddOne room).qiInput w.k)).state.nats slot value
    exact RationalDivideCalls.nonzero_borrow _ _
      (CursorBorrow.preserves (l:=l) (c:=(w.oddOne room).cursor) [w.k,0,1]
        (CursorBorrow.preserves (l:=l) (c:=w.cursor) [1,0,1] h))
  · exact CursorBorrow.preserves (l:=l) (c:=w.cursor) [0,0,1] h

end CoeffWork

theorem coefficientStep_scalar {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity)
    {name type : String} {slot : Nat} {value : Option Value}
    (h : SourceScalarGlobal.At f.cursor.state name type slot value)
    (poolType : type≠"unsigned") (counterType : type≠"unsigned int") :
    SourceScalarGlobal.At (coefficientStep f active room).cursor.state name type slot value := by
  change SourceScalarGlobal.At (stepWork f active room).cursor.state name type slot value
  unfold stepWork
  apply SourceScalarGlobal.local_store
    (CoeffWork.atanhWritten_scalar _ _ _ _ (expWork_scalar f _ active h poolType) poolType)
    (CoeffWork.atanhWritten _ _ _ _).kAt counterType

theorem coefficientStep_borrow {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity)
    {slot value : Nat} (h : NatArena.Borrow f.cursor.state.nats slot value) :
    NatArena.Borrow (coefficientStep f active room).cursor.state.nats slot value := by
  change NatArena.Borrow (stepWork f active room).cursor.state.nats slot value
  unfold stepWork
  exact CoeffWork.atanhWritten_borrow _ _ _ _ (expWork_borrow f _ active h)

theorem coefficientStep_scale {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) (active : f.k ≤ d) (room : f.cursor.top+34<PoolCalls.capacity)
    {scaleObject scaleSlot scaleValue : Nat}
    (scale : SourceFromS.ScaleAt f.cursor.state scaleObject scaleSlot scaleValue) :
    SourceFromS.ScaleAt (coefficientStep f active room).cursor.state scaleObject scaleSlot scaleValue := by
  have storage:=coefficientStep_scalar f active room
    (show SourceScalarGlobal.At f.cursor.state "scale100" "N" scaleObject (some (.natObject scaleSlot))
      from ⟨scale.lookup,scale.storage⟩) (by decide +kernel) (by decide +kernel)
  exact ⟨storage.lookup,storage.storage,coefficientStep_borrow f active room scale.live⟩

end ScopedC.PrepareSource
