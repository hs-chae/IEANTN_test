/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientWork

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

namespace CoeffWork

def qiInput {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (n : Nat) : Input :=
  RationalUnsignedTrace.output l w.cursor n

def qiWork {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (n : Nat) (room : w.cursor.top+2<PoolCalls.capacity) :
    CoeffWork l object d eb ab := w.advance [n,0,1] (by change w.cursor.top+3 ≤ PoolCalls.capacity;omega)

theorem qi_source (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (n : Nat) (bound : n<2^32)
    (room : w.cursor.top+2<PoolCalls.capacity) (input : Value)
    (parameter : castValue Header.layout {w.cursor.state with env:=[]} 100 "unsigned int" input=
      some (NatWrapperCalls.unsigned32 n)) :
    SourceCall Header.layout code 6 "qi" [input] w.cursor.state
      (w.qiInput n).source (w.qiWork n room).cursor.state :=
  (RationalUnsignedTrace.qi_traced code lib.unsigned.qi lib.unsigned.si
    lib.unsigned.productLibrary.smake lib.unsigned.productLibrary.nz lib.unsigned.productLibrary.nu
    lib.unsigned.productLibrary.ne lib.unsigned.productLibrary.keep w.context n bound room input parameter).1

def oddOne {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) :
    CoeffWork l object d eb ab := w.qiWork 1 (by omega)

def oddCounter {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) :
    CoeffWork l object d eb ab :=
  (w.oddOne room).qiWork w.k (by change w.cursor.top+3+2<PoolCalls.capacity;omega)

noncomputable def oddInput {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) : Input :=
  RationalDivideCalls.outputInput l (w.oddCounter room).cursor (w.qiInput 1) ((w.oddOne room).qiInput w.k)
    (by change 0<(1:Nat);decide +kernel) (by change 0<(1:Nat);decide +kernel)

noncomputable def oddWork {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k) :
    CoeffWork l object d eb ab :=
  (w.oddCounter room).nonzeroDivide (w.qiInput 1) ((w.oddOne room).qiInput w.k)
    (by change w.k≠0;omega) (by change w.cursor.top+6+12<PoolCalls.capacity;omega)

theorem odd_work_after {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k) :
    (w.oddWork room positive).cursor=
      RationalDivideCalls.after l (w.oddCounter room).cursor (w.qiInput 1) ((w.oddOne room).qiInput w.k) := by
  change RationalDivideCalls.nonzeroAfter l _ _ _=RationalDivideCalls.after l _ _ _
  unfold RationalDivideCalls.after
  rw[if_neg (show ((w.oddOne room).qiInput w.k).numerator.magnitude≠0 from by change w.k≠0;omega)]

theorem oddInput_live {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k) :
    (w.oddInput room).Live (w.oddWork room positive).cursor.state := by
  rw[odd_work_after]
  exact (RationalDivideCalls.output_spec l (w.oddCounter room).cursor (w.qiInput 1)
    ((w.oddOne room).qiInput w.k) (by change 0<(1:Nat);decide +kernel)
    (by change 0<(1:Nat);decide +kernel)).2.1

theorem oddInput_positive {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) :
    0<(w.oddInput room).denominator :=
  (RationalDivideCalls.output_spec l (w.oddCounter room).cursor (w.qiInput 1)
    ((w.oddOne room).qiInput w.k) (by change 0<(1:Nat);decide +kernel)
    (by change 0<(1:Nat);decide +kernel)).2.2.2

theorem oddInput_value {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) :
    (w.oddInput room).mathematical.value=1/(w.k:Rat) := by
  have result:=(RationalDivideCalls.output_spec l (w.oddCounter room).cursor (w.qiInput 1)
    ((w.oddOne room).qiInput w.k) (by change 0<(1:Nat);decide +kernel)
    (by change 0<(1:Nat);decide +kernel)).2.2.1
  change (RationalDivideCalls.outputInput l (w.oddCounter room).cursor (w.qiInput 1)
    ((w.oddOne room).qiInput w.k) _ _).mathematical.value=1/(w.k:Rat)
  rw[result]
  have one : (w.qiInput 1).mathematical.value=(1:Rat):=
    (RationalUnsignedTrace.mathematical l w.cursor 1).1
  have counter : ((w.oddOne room).qiInput w.k).mathematical.value=(w.k:Rat):=
    (RationalUnsignedTrace.mathematical l (w.oddOne room).cursor w.k).1
  rw[one,counter]

theorem oddDivide_source (code : List Function) (lib : CoeffLibrary code)
    {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (w : CoeffWork l object d eb ab) (room : w.cursor.top+18<PoolCalls.capacity) (positive : 0<w.k) :
    SourceCall Header.layout code 7 "qv" [(w.qiInput 1).source,((w.oddOne room).qiInput w.k).source]
      (w.oddCounter room).cursor.state (w.oddInput room).source (w.oddWork room positive).cursor.state := by
  rw[odd_work_after]
  apply RationalDivideCalls.output_source code lib.qv lib.division (w.oddCounter room).context
    (by change w.cursor.top+6+12<PoolCalls.capacity;omega)
    (w.qiInput 1) ((w.oddOne room).qiInput w.k)
  · exact ⟨CursorBorrow.preserves (l:=l) (c:=(w.oddOne room).cursor) [w.k,0,1]
      (RationalUnsignedTrace.live l w.cursor 1).1,
      CursorBorrow.preserves (l:=l) (c:=(w.oddOne room).cursor) [w.k,0,1]
      (RationalUnsignedTrace.live l w.cursor 1).2⟩
  · exact RationalUnsignedTrace.live l (w.oddOne room).cursor w.k

end CoeffWork
end ScopedC.PrepareSource
