/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedPiBody
import ScopedC.NamedGammaBody
import LeanCert.Engine.Eval.Core
namespace ScopedC.NamedBody
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  named : Generated.f_named∈code
  decimal : RationalDecimalLiteral.Library code
  qv : Generated.f_qv∈code
  divide : RationalDivideCalls.Library code
  round : NamedDecimalCompletion.Library code

def constant (kind : Nat) : LeanCert.Core.MathConst :=
  if kind=0 then .pi else .eulerMascheroni

theorem pi_interval_exact : NamedPiBody.rational=LeanCert.Engine.piInterval := rfl
theorem gamma_interval_exact : NamedGammaBody.rational=LeanCert.Engine.eulerMascheroniInterval := rfl

/-- Complete original named function for every representable unsigned input,
with unchanged source constants and exact original LeanCert dyadic output. -/
theorem named_closed (code : List Function) (lib : Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (kind : Nat) (bound : kind<2^32)
    {object valueSlot : Nat} (scale : SourceFromS.ScaleAt c.state object valueSlot (2^100))
    (room : c.top+400<capacity) :
    ∃out : Cursor, ∃lo hi : Endpoint,
      SourceCall Header.layout code 9 "named" [NatWrapperCalls.unsigned32 kind]
        c.state (DyadicCasts.value lo.source hi.source true) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=
        some (LeanCert.Core.IntervalDyadic.ofIntervalRat (constant kind).interval (-100),true) := by
  by_cases zero : kind=0
  · subst kind
    exact NamedPiBody.named_pi_closed code lib.named lib.decimal lib.round ctx scale room
  · simpa only [constant,if_neg zero,LeanCert.Core.MathConst.interval,←gamma_interval_exact] using
      NamedGammaBody.named_gamma_closed code lib.named lib.qv lib.divide lib.round kind bound zero ctx scale room

theorem model_contains (kind : Nat) : (constant kind).toReal ∈
    LeanCert.Core.IntervalDyadic.ofIntervalRat (constant kind).interval (-100) :=
  LeanCert.Core.IntervalDyadic.mem_ofIntervalRat (LeanCert.Core.MathConst.mem_interval (constant kind))
    (-100) (by norm_num)

/-- The source-verified original output encloses the actual named real value;
the pre-existing LeanCert constant theorems remain the mathematical consumer. -/
theorem named_closed_math (code : List Function) (lib : Library code)
    {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (kind : Nat) (bound : kind<2^32)
    {object valueSlot : Nat} (scale : SourceFromS.ScaleAt c.state object valueSlot (2^100))
    (room : c.top+400<capacity) :
    ∃out : Cursor, ∃lo hi : Endpoint, ∃model : LeanCert.Core.IntervalDyadic,
      SourceCall Header.layout code 9 "named" [NatWrapperCalls.unsigned32 kind]
        c.state (DyadicCasts.value lo.source hi.source true) out.state ∧
      Valid l out ∧ lo.Live out.state ∧ hi.Live out.state ∧
      DyadicRepresentation.interval out.state (DyadicCasts.value lo.source hi.source true)=some (model,true) ∧
      model=LeanCert.Core.IntervalDyadic.ofIntervalRat (constant kind).interval (-100) ∧
      (constant kind).toReal ∈ model := by
  obtain ⟨out,lo,hi,source,valid,low,high,decoded⟩ := named_closed code lib ctx kind bound scale room
  exact ⟨out,lo,hi,_,source,valid,low,high,decoded,rfl,model_contains kind⟩

#print axioms pi_interval_exact
#print axioms gamma_interval_exact
#print axioms named_closed
#print axioms model_contains
#print axioms named_closed_math
end ScopedC.NamedBody
