/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderEntrySource
import ScopedC.SourceUnsignedGlobal

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000
attribute [local irreducible] afterMax radius

def radiusValues (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) : List Nat :=
  [0,0]++RationalCompareCalls.values (low a) (high a)

theorem afterMax_trace (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    afterMax l c a=CursorFrames.advance l (parameters c a) (radiusValues l c a) := by
  unfold afterMax RationalSelectionTree.step
  rw[RationalCompareCalls.trace]
  unfold radiusValues
  rw[CursorSingleFrames.advance_append]
  rfl

theorem afterR_top (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    (afterR l c a).top=c.top+8 := by
  change (afterMax l c a).top=_
  rw[afterMax_trace,CursorFrames.top_advance]
  rfl

theorem afterR_heap (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    (afterR l c a).state.heap.length=c.state.heap.length+2 := by
  change ((afterMax l c a).state.heap++[_]).length=_
  rw[List.length_append,List.length_singleton,afterMax_trace,(CursorEffects.shape _ _ _).1]
  simp [parameters,OneFrames.frame,allocate]

theorem afterR_globals (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    (afterR l c a).state.globals=c.state.globals := by
  change (afterMax l c a).state.globals=c.state.globals
  rw[afterMax_trace,CursorSingleFrames.advance_globals]
  rfl

theorem afterR_borrow {l : PoolCalls.PoolLayout} {c : Cursor} (a : Pair) {slot value : Nat}
    (live : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (afterR l c a).state.nats slot value := by
  change NatArena.Borrow (afterMax l c a).state.nats slot value
  rw[afterMax_trace]
  exact CursorBorrow.preserves _ live

theorem afterR_other (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) (slot : Nat)
    (bound : slot<c.state.heap.length) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (afterR l c a).state.heap[slot]?=c.state.heap[slot]? := by
  have paramsLength : (parameters c a).state.heap.length=c.state.heap.length+1 := by
    simp [parameters,OneFrames.frame,allocate]
  have beforeLength : (afterMax l c a).state.heap.length=c.state.heap.length+1 := by
    rw[afterMax_trace,(CursorEffects.shape _ _ _).1]
    exact paramsLength
  change ((afterMax l c a).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left (by omega),afterMax_trace,
    CursorSingleFrames.advance_other l (parameters c a) (radiusValues l c a) slot hp ht hh]
  change (c.state.heap++[_])[slot]?=_
  exact List.getElem?_append_left bound

theorem afterR_depth {l : PoolCalls.PoolLayout} {c : Cursor} (a : Pair) {object d : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) :
    SourceUnsignedGlobal.At (afterR l c a).state "depth" object d := by
  have inParameters : SourceUnsignedGlobal.At (parameters c a).state "depth" object d :=
    SourceUnsignedGlobal.allocated (SourceUnsignedGlobal.memory (t:={c.state with env:=[]}) depth rfl rfl)
      "RI" "a" _
  have inMaximum : SourceUnsignedGlobal.At (afterMax l c a).state "depth" object d := by
    rw[afterMax_trace]
    exact SourceUnsignedGlobal.advanced inParameters _ apart.1 apart.2.1 apart.2.2
  exact SourceUnsignedGlobal.allocated inMaximum "Q" "r" _

theorem afterR_unshadowed (l : PoolCalls.PoolLayout) (c : Cursor) (a : Pair) :
    (afterR l c a).state.env.lookup "depth"=none := by
  change (("r",_)::(afterMax l c a).state.env).lookup "depth"=none
  rw[afterMax_trace,(CursorEffects.shape _ _ _).2]
  rfl

end ScopedC.ExpRemainderCalls
