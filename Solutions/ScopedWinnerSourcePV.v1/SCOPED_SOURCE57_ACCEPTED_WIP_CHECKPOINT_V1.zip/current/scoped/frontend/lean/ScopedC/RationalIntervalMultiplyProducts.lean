/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplyData

namespace ScopedC.RationalIntervalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
open ScopedC.RationalProductApplicability
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  qt : Generated.f_qt∈code
  productLibrary : RationalMultiplyCalls.Library code
  selectLibrary : RationalIntervalHullCalls.Library code

/-- All four real cross-cancelled rational products, at the actual caller
states including each preceding Q local declaration. -/
theorem products (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair)
    (ha : a.Live c.state) (hb : b.Live c.state) (pa : a.Positive) (pb : b.Positive) :
    SourceCall Header.layout code 6 "qt" [a.lo.source,b.lo.source] (base c a b).state
      (p l c a b).source (RationalMultiplyCalls.c11 l (base c a b) a.lo b.lo).state ∧
    SourceCall Header.layout code 6 "qt" [a.lo.source,b.hi.source] (c1 l c a b).state
      (q l c a b).source (RationalMultiplyCalls.c11 l (c1 l c a b) a.lo b.hi).state ∧
    SourceCall Header.layout code 6 "qt" [a.hi.source,b.lo.source] (c2 l c a b).state
      (r l c a b).source (RationalMultiplyCalls.c11 l (c2 l c a b) a.hi b.lo).state ∧
    SourceCall Header.layout code 6 "qt" [a.hi.source,b.hi.source] (c3 l c a b).state
      (s l c a b).source (RationalMultiplyCalls.c11 l (c3 l c a b) a.hi b.hi).state := by
  have h0 : Valid l (base c a b) := CursorFrames.framed_valid ctx "RI" "a" a.source "RI" "b" b.source
  have h1:=RationalMultiplyCalls.qt_closed code lib.qt lib.productLibrary h0
    (by change c.top+10<PoolCalls.capacity;omega) a.lo b.lo ha.1 hb.1 pa.1 pb.1
  have h2:=RationalMultiplyCalls.qt_closed code lib.qt lib.productLibrary (ctx1 ctx room a b)
    (by rw[top1];omega) a.lo b.hi (input1 (a:=a) (b:=b) ha.1) (input1 (a:=a) (b:=b) hb.2) pa.1 pb.2
  have h3:=RationalMultiplyCalls.qt_closed code lib.qt lib.productLibrary (ctx2 ctx room a b)
    (by rw[top2];omega) a.hi b.lo (input2 (a:=a) (b:=b) ha.2) (input2 (a:=a) (b:=b) hb.1) pa.2 pb.1
  have h4:=RationalMultiplyCalls.qt_closed code lib.qt lib.productLibrary (ctx3 ctx room a b)
    (by rw[top3];omega) a.hi b.hi (input3 (a:=a) (b:=b) ha.2) (input3 (a:=a) (b:=b) hb.2) pa.2 pb.2
  exact ⟨h1,h2,h3,h4⟩

/-- An actual source declaration evaluates the real qt call before its
checked Q conversion and fresh caller-local allocation. -/
theorem product_declaration (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor)
    (a b : Input) (ea eb : Expr) (name : String)
    (left : evalExpr Header.layout service 999 c.state ea=some (a.source,c.state))
    (right : evalExpr Header.layout service 999 c.state eb=some (b.source,c.state))
    (answer : service "qt" [a.source,b.source] c.state=
      some ((output l c a b).source,(RationalMultiplyCalls.c11 l c a b).state)) :
    Declare Header.layout service [{type:="Q",name:=name,value:=some (.call (.var "qt") [ea,eb]),arrayExtent:=none}]
      c.state (saved l c a b name).state := by
  have expression:=ExpressionTemplates.call_two Header.layout service left right answer
  have cast : castValue Header.layout (RationalMultiplyCalls.c11 l c a b).state 100 "Q"
      (output l c a b).source=some (output l c a b).source :=
    Input.cast "Q" (by decide +kernel) (live l c a b)
  simp only [Declare,declarations,List.foldlM,expression,bind,Option.bind,cast]
  rfl

end ScopedC.RationalIntervalMultiplyCalls
