/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAbsApplicability
import ScopedC.TaylorFramedBody

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def parameters (c : Cursor) (q : Input) : Cursor :=
  CursorSingleFrames.framed c "Q" "q" q.source

def afterAbs (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  RationalAbsApplicability.after l (parameters c q)

def absInput (q : Input) : Input := RationalAbsApplicability.output q

def afterR (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) : Cursor :=
  CursorLocals.allocated (afterAbs l c q) "Q" "r" (absInput q).source

theorem parameters_context {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) : Valid l (parameters c q) :=
  OneFrames.context_frame ctx "Q" "q" q.source

theorem bind_parameters (c : Cursor) (q : Input) (live : q.Live c.state) :
    bindArgs Header.layout Generated.f_atanhPoint.parameters [q.source] c.state=
      some (parameters c q).state :=
  TypedFrames.bind_one Header.layout c.state "Q" "q" q.source q.source
    (Input.cast "Q" (by decide +kernel) live)

theorem eval_q (service : Call) (fuel : Nat) (c : Cursor) (q : Input) :
    evalExpr Header.layout service (fuel+1) (parameters c q).state (.var "q")=
      some (q.source,(parameters c q).state) :=
  TypedFrames.allocate_eval Header.layout service fuel {c.state with env:=[]}
    "Q" "q" q.source (by rfl) (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel)

theorem abs_call (code : List Function) (lib : RationalAbsApplicability.Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (q : Input)
    (live : q.Live c.state) (room : c.top<PoolCalls.capacity) :
    SourceCall Header.layout code 5 "qabs" [q.source] (parameters c q).state
      (absInput q).source (afterAbs l c q).state :=
  RationalAbsApplicability.source code lib (parameters_context ctx q) q live room

theorem r_declaration (service : Call) (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input)
    (live : q.Live c.state)
    (answer : service "qabs" [q.source] (parameters c q).state=
      some ((absInput q).source,(afterAbs l c q).state)) :
    Declare Header.layout service
      [{type:="Q",name:="r",value:=some (.call (.var "qabs") [.var "q"]),arrayExtent:=none}]
      (parameters c q).state (afterR l c q).state := by
  have expression:=ExpressionTemplates.call_one Header.layout service
    (eval_q service 998 c q) answer
  have cast : castValue Header.layout (afterAbs l c q).state 100 "Q" (absInput q).source=
      some (absInput q).source :=
    Input.cast "Q" (by decide +kernel) (RationalAbsApplicability.live live)
  simp only[Declare,declarations,List.foldlM,expression,Bind.bind,Option.bind,cast]
  rfl

theorem r_binding (l : PoolCalls.PoolLayout) (c : Cursor) (q : Input) :
    LocalBinding.At (afterR l c q).state "r" "Q" (absInput q).source
      (c.state.heap.length+1) := by
  have len : (afterAbs l c q).state.heap.length=c.state.heap.length+1 := by
    exact (PoolCursor.shape l (parameters c q) 0).1.trans (by
      simp [parameters,CursorSingleFrames.framed,OneFrames.frame,allocate])
  simpa only[afterR,CursorLocals.allocated,len] using
    LocalBinding.allocate_head (afterAbs l c q).state "r" "Q" (absInput q).source (by rfl)

theorem afterR_context {l : PoolCalls.PoolLayout} {c : Cursor}
    (ctx : Valid l c) (q : Input) (room : c.top<PoolCalls.capacity) :
    Valid l (afterR l c q) :=
  CursorLocals.allocated_valid (next_valid 0 (parameters_context ctx q) room) "Q" "r" _

end ScopedC.AtanhCalls
