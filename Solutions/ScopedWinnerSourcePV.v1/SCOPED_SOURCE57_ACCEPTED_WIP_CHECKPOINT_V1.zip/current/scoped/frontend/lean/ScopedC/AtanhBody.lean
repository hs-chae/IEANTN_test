/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.AtanhNarrowBody
import ScopedC.AtanhWideBody
import ScopedC.NumericIntervalValues

namespace ScopedC.AtanhCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000

/-- Whole original atanhPoint C source, both guard outcomes, with its exact
original rational interval algorithm and physical application preconditions.
The real atanh theorem only applies on its analytic input domain. -/
theorem atanhPoint_closed (code : List Function) (installed : Generated.f_atanhPoint∈code)
    (lib : Library code) {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (q : Input) (alive : q.Live c.state) (positive : 0<q.denominator) (d object : Nat)
    {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (lookup : c.state.globals.lookup "atanhCoeffs"=some base)
    (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high)
    (dBound : d≤64) (length : coeffs.length=d+1) (room : c.top+9000<PoolCalls.capacity) :
    ∃out : Cursor,∃pair : Pair,
      SourceCall Header.layout code 10 "atanhPoint" [q.source] c.state pair.source out.state ∧
      Valid l out ∧ pair.Live out.state ∧ pair.Positive ∧
      pair.lo.mathematical.value=(if 1≤|q.mathematical.value| then -1000 else
        (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
          (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).lo-
            |q.mathematical.value|^(d+1)/(1-|q.mathematical.value|)) ∧
      pair.hi.mathematical.value=(if 1≤|q.mathematical.value| then 1000 else
        (LeanCert.Core.IntervalRat.evalTaylorSeries (TaylorCalls.coefficientValues coeffs)
          (LeanCert.Core.IntervalRat.singleton q.mathematical.value)).hi+
            |q.mathematical.value|^(d+1)/(1-|q.mathematical.value|)) := by
  by_cases wide : 1≤|q.mathematical.value|
  · obtain ⟨out,pair,execution,valid,live,positivePair,decoded⟩:=
      atanh_wide_closed code installed ⟨lib.error.narrow.guard,lib.qn,lib.sn⟩ ctx q alive positive
        wide (by omega)
    obtain ⟨lo,hi⟩:=Pair.values_of_decoded live positivePair decoded
    exact ⟨out,pair,execution,valid,live,positivePair,by simpa only[wide,↓reduceIte] using lo,
      by simpa only[wide,↓reduceIte] using hi⟩
  · obtain ⟨out,pair,execution,valid,live,positivePair,lo,hi⟩:=
      atanh_narrow_closed code installed lib ctx q alive positive (lt_of_not_ge wide) d object
        table lookup depth apart dBound length room
    exact ⟨out,pair,execution,valid,live,positivePair,by simpa only[wide,↓reduceIte] using lo,
      by simpa only[wide,↓reduceIte] using hi⟩

end ScopedC.AtanhCalls
