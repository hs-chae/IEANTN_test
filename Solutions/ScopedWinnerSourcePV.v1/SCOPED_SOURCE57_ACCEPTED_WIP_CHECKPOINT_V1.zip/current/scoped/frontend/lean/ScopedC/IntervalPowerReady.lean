/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerResultFrame

namespace ScopedC.IntervalPowerCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def scanStart {l : PoolCalls.PoolLayout} {n : Nat} (f : IntervalPowerBits.Frame l n)
    (a : Pair) (aSlot : Nat) (atA : LocalBinding.At f.cursor.state "a" "RI" a.source aSlot)
    (alive : a.Live f.cursor.state) (positive : a.Positive)
    (order : a.lo.mathematical.value ≤ a.hi.mathematical.value) : IntervalPowerScan.Frame l n :=
  IntervalPowerScan.halved (withResult f a aSlot atA alive positive order)

structure Ready (code : List Function) {l : PoolCalls.PoolLayout} {n : Nat} (start : IntervalPowerScan.Frame l n) where
  finish : IntervalPowerScan.Frame l n
  events : List (IntervalPowerScan.Event code)
  unique : (events.map CallEvents.timeKey).Nodup
  execution : ∀service,IntervalPowerScan.Answers service events →
    IntervalPowerScan.While service start.cursor.state (.continuing finish.cursor.state)
  mathematical_eq : IntervalPowerScan.mathematical finish=LeanCert.Core.IntervalRat.pow (IntervalPowerScan.original start) n
  top_le : finish.cursor.top ≤ start.cursor.top+5120

theorem scan_ready (code : List Function) (installed : Generated.f_rmul∈code)
    (lib : RationalIntervalMultiplyCalls.Library code) {l : PoolCalls.PoolLayout} {n : Nat}
    (f : IntervalPowerBits.Frame l n) (highest : n<f.bit*2)
    (a : Pair) (aSlot : Nat) (atA : LocalBinding.At f.cursor.state "a" "RI" a.source aSlot)
    (alive : a.Live f.cursor.state) (positive : a.Positive) (order : a.lo.mathematical.value ≤ a.hi.mathematical.value)
    (room : f.cursor.top+5120 ≤ PoolCalls.capacity) :
    Nonempty (Ready code (scanStart f a aSlot atA alive positive order)) := by
  let start:=scanStart f a aSlot atA alive positive order
  have bitEq : start.bit=f.bit/2 := rfl
  have initialValue : IntervalPowerScan.mathematical start=IntervalPowerScan.original start := rfl
  have prefixOne : n/f.bit=1:=IntervalPowerMathematics.highest_prefix n f.bit f.lower highest
  have pBound : f.power<32 := by
    have h : 2^f.power<2^32 := f.powerEq ▸ lt_of_le_of_lt f.lower f.exponentBound
    exact (Nat.pow_lt_pow_iff_right (by decide : 1<2)).1 h
  cases hp : f.power with
  | zero =>
    have one : f.bit=1:=by rw[f.powerEq,hp];rfl
    have exponent : n=1 := by have h:=f.lower;omega
    have stopped : start.bit=0:=by rw[bitEq,one]
    refine ⟨{
      finish:=start
      events:=[]
      unique:=by simp
      execution:=?_
      mathematical_eq:=?_
      top_le:=by
        change start.cursor.top ≤ start.cursor.top+5120
        omega
    }⟩
    · intro service _
      exact Loops.WhileRun.done (IntervalPowerScan.condition_eval service start)
        (by simp [UnsignedLiteralControl.truth_boolean,stopped])
    · have powerEq : LeanCert.Core.IntervalRat.pow (IntervalPowerScan.original start) n=IntervalPowerScan.original start :=
        (congrArg (LeanCert.Core.IntervalRat.pow (IntervalPowerScan.original start)) exponent).trans (by rw[LeanCert.Core.IntervalRat.pow])
      exact initialValue.trans powerEq.symm
  | succ k =>
    have startPower : start.bit=2^k := by rw[bitEq,f.powerEq,hp,IntervalPowerMathematics.power_two_half]
    have doubleEq : start.bit*2=f.bit := by rw[startPower,f.powerEq,hp,pow_succ]
    have lower : 2*start.bit ≤ n := by rw[Nat.mul_comm,doubleEq];exact f.lower
    have prefixValue : IntervalPowerScan.mathematical start=
        LeanCert.Core.IntervalRat.pow (IntervalPowerScan.original start) (n/(start.bit*2)) := by
      rw[doubleEq,prefixOne,LeanCert.Core.IntervalRat.pow]
      exact initialValue
    have startRoom : start.cursor.top+160*(k+1) ≤ PoolCalls.capacity := by
      have kBound : k+1<32 := by simpa only[hp] using pBound
      change f.cursor.top+160*(k+1) ≤ PoolCalls.capacity
      omega
    obtain ⟨trace⟩:=IntervalPowerScan.loop_certificate code installed lib k start startPower lower prefixValue startRoom
    exact ⟨{
      finish:=trace.finish
      events:=trace.events
      unique:=trace.unique
      execution:=trace.execution
      mathematical_eq:=trace.mathematical_eq
      top_le:=by
        have h:=trace.top_le
        have kBound : k+1<32:=by simpa only[hp] using pBound
        change trace.finish.cursor.top ≤ start.cursor.top+5120
        omega
    }⟩

end ScopedC.IntervalPowerCalls
