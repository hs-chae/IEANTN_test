/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NamedDecimalTrace
import ScopedC.SourceFromRIArguments
namespace ScopedC.NamedDecimalService
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.NamedDecimalPair
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

/-- One service for BOTH actual decimal endpoint executions and the final
actual fromRI execution. All answers are backed by source-body proofs. -/
theorem source_expressions {code : List Function} {l : PoolLayout} {c : Cursor}
    {nl nh den slot : Nat} {oldHi : Value}
    (D : Stages code l c nl nh den slot oldHi)
    (last : CallEvents.Event Header.layout code 8) (lastName : last.name="fromRI")
    (lastCount : last.before.nats.values.length=(finish D).state.nats.values.length) :
    ∃service : Call,
      (∀name args before value after, service name args before=some (value,after) →
        SourceCall Header.layout code 8 name args before value after) ∧
      evalExpr Header.layout service 1000 c.state (RationalDecimalLiteral.initializer nl den)=
        some (D.low.output.source,(RationalDecimalLiteral.after D.low).state) ∧
      evalExpr Header.layout service 1000 (middle D).state
        (RationalDecimalLiteral.initializer nh den)=
        some (D.high.output.source,(RationalDecimalLiteral.after D.high).state) ∧
      service last.name last.args last.before=some (last.value,last.after) := by
  let e0 : CallEvents.Event Header.layout code 8 :=
    ⟨"decimal",[.pointer ⟨c.state.heap.length,0,[]⟩ false],
      (RationalDecimalLiteral.textCursor c nl).state,.natObject D.low.numeratorSlot,
      D.low.numerator.state,SourceRanks.monotone (by omega : 3≤8) D.low.numeratorCall⟩
  let e1 : CallEvents.Event Header.layout code 8 :=
    ⟨"smake",[.natObject D.low.numeratorSlot,DecimalDigits.integer 0],D.low.numerator.state,
      (RationalDecimalLiteral.endpoint D.low.numeratorSlot nl).source,
      (next l D.low.numerator 0).state,SourceRanks.monotone (by omega : 4≤8) D.low.signedCall⟩
  let e2 : CallEvents.Event Header.layout code 8 :=
    ⟨"decimal",[.pointer ⟨(next l D.low.numerator 0).state.heap.length,0,[]⟩ false],
      (RationalDecimalLiteral.textCursor (next l D.low.numerator 0) den).state,
      .natObject D.low.denominatorSlot,D.low.denominator.state,
      SourceRanks.monotone (by omega : 3≤8) D.low.denominatorCall⟩
  let e3 : CallEvents.Event Header.layout code 8 :=
    ⟨"qm",[(RationalDecimalLiteral.endpoint D.low.numeratorSlot nl).source,.natObject D.low.denominatorSlot],
      D.low.denominator.state,D.low.output.source,(RationalDecimalLiteral.after D.low).state,
      SourceRanks.monotone (by omega : 5≤8) D.low.rationalCall⟩
  let e4 : CallEvents.Event Header.layout code 8 :=
    ⟨"decimal",[.pointer ⟨(middle D).state.heap.length,0,[]⟩ false],
      (RationalDecimalLiteral.textCursor (middle D) nh).state,.natObject D.high.numeratorSlot,
      D.high.numerator.state,SourceRanks.monotone (by omega : 3≤8) D.high.numeratorCall⟩
  let e5 : CallEvents.Event Header.layout code 8 :=
    ⟨"smake",[.natObject D.high.numeratorSlot,DecimalDigits.integer 0],D.high.numerator.state,
      (RationalDecimalLiteral.endpoint D.high.numeratorSlot nh).source,
      (next l D.high.numerator 0).state,SourceRanks.monotone (by omega : 4≤8) D.high.signedCall⟩
  let e6 : CallEvents.Event Header.layout code 8 :=
    ⟨"decimal",[.pointer ⟨(next l D.high.numerator 0).state.heap.length,0,[]⟩ false],
      (RationalDecimalLiteral.textCursor (next l D.high.numerator 0) den).state,
      .natObject D.high.denominatorSlot,D.high.denominator.state,
      SourceRanks.monotone (by omega : 3≤8) D.high.denominatorCall⟩
  let e7 : CallEvents.Event Header.layout code 8 :=
    ⟨"qm",[(RationalDecimalLiteral.endpoint D.high.numeratorSlot nh).source,.natObject D.high.denominatorSlot],
      D.high.denominator.state,D.high.output.source,(RationalDecimalLiteral.after D.high).state,
      SourceRanks.monotone (by omega : 5≤8) D.high.rationalCall⟩
  let events := [e0,e1,e2,e3,e4,e5,e6,e7,last]
  have ln := NamedDecimalTrace.numerator_count D.low
  have ld := NamedDecimalTrace.denominator_count D.low
  have la := NamedDecimalTrace.output_count D.low
  have hn := NamedDecimalTrace.numerator_count D.high
  have hd := NamedDecimalTrace.denominator_count D.high
  have ha := NamedDecimalTrace.output_count D.high
  change D.high.numerator.state.nats.values.length=
    (middle D).state.nats.values.length+1+4*(DecimalText.digits nh).length at hn
  change D.high.denominator.state.nats.values.length=
    (middle D).state.nats.values.length+3+4*(DecimalText.digits nh).length+4*(DecimalText.digits den).length at hd
  change (RationalDecimalLiteral.after D.high).state.nats.values.length=
    (middle D).state.nats.values.length+8+4*(DecimalText.digits nh).length+4*(DecimalText.digits den).length at ha
  have ls := PoolCursor.size l D.low.numerator 0
  have hs := PoolCursor.size l D.high.numerator 0
  have middleCount : (middle D).state.nats.values.length=
      (RationalDecimalLiteral.after D.low).state.nats.values.length := rfl
  have finalCount : (finish D).state.nats.values.length=
      (RationalDecimalLiteral.after D.high).state.nats.values.length := rfl
  have unique : (CallEvents.counts events).Nodup := by
    change [c.state.nats.values.length,D.low.numerator.state.nats.values.length,
      (next l D.low.numerator 0).state.nats.values.length,D.low.denominator.state.nats.values.length,
      (middle D).state.nats.values.length,D.high.numerator.state.nats.values.length,
      (next l D.high.numerator 0).state.nats.values.length,D.high.denominator.state.nats.values.length,
      last.before.nats.values.length].Nodup
    simp only [List.nodup_cons,List.mem_cons,List.mem_singleton,List.not_mem_nil,
      not_false_eq_true,List.nodup_nil,and_true,not_or]
    repeat' constructor <;> omega
  let service := CallEvents.service events
  have answers := CallEvents.service_self events unique
  refine ⟨service,fun _ _ _ _ _ h=>CallEvents.service_closed events h,?_,?_,?_⟩
  · exact RationalDecimalLiteral.expression service D.low
      (answers e0 (by simp [events])) (answers e1 (by simp [events]))
      (answers e2 (by simp [events])) (answers e3 (by simp [events]))
  · exact RationalDecimalLiteral.expression service D.high
      (answers e4 (by simp [events])) (answers e5 (by simp [events]))
      (answers e6 (by simp [events])) (answers e7 (by simp [events]))
  · exact answers last (by simp [events])

#print axioms source_expressions
end ScopedC.NamedDecimalService
