/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerIterationBody
import ScopedC.CursorSingleFrames

namespace ScopedC.RationalPowerCalls
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem accumulate_preserves_nat {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+10<PoolCalls.capacity) {slot n : Nat} (live : NatArena.Borrow f.cursor.state.nats slot n) :
    NatArena.Borrow (accumulate f room).cursor.state.nats slot n := by
  change NatArena.Borrow (accNext f).state.nats slot n
  unfold accNext
  exact RationalMultiplyCalls.preserves (c:=f.cursor) (a:=f.accumulator) (b:=f.current) live
theorem square_preserves_nat {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+10<PoolCalls.capacity) {slot n : Nat} (live : NatArena.Borrow f.cursor.state.nats slot n) :
    NatArena.Borrow (square f room).cursor.state.nats slot n := by
  change NatArena.Borrow (squareNext f).state.nats slot n
  unfold squareNext
  exact RationalMultiplyCalls.preserves (c:=f.cursor) (a:=f.current) (b:=f.current) live
theorem accumulate_globals {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (accumulate f room).cursor.state.globals=f.cursor.state.globals := by
  change (accNext f).state.globals=_
  rw[accNext,RationalMultiplyTrace.c11_advance,CursorSingleFrames.advance_globals]
theorem square_globals {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity) :
    (square f room).cursor.state.globals=f.cursor.state.globals := by
  change (squareNext f).state.globals=_
  rw[squareNext,RationalMultiplyTrace.c11_advance,CursorSingleFrames.advance_globals]

theorem accumulate_other {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity)
    (slot : Nat) (localApart : slot≠f.rSlot) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (accumulate f room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  change ((accNext f).state.heap.set f.rSlot _)[slot]?=_
  rw[List.getElem?_set_ne (Ne.symm localApart),accNext,RationalMultiplyTrace.c11_advance]
  exact CursorSingleFrames.advance_other l f.cursor _ slot hp ht hh
theorem square_other {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+10<PoolCalls.capacity)
    (slot : Nat) (localApart : slot≠f.aSlot) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (square f room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  change ((squareNext f).state.heap.set f.aSlot _)[slot]?=_
  rw[List.getElem?_set_ne (Ne.symm localApart),squareNext,RationalMultiplyTrace.c11_advance]
  exact CursorSingleFrames.advance_other l f.cursor _ slot hp ht hh
theorem half_other {l : PoolCalls.PoolLayout} (f : Frame l) (slot : Nat) (localApart : slot≠f.nSlot) :
    (half f).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  change (f.cursor.state.heap.set f.nSlot _)[slot]?=_
  exact List.getElem?_set_ne (Ne.symm localApart)

theorem afterOdd_slots {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (afterOdd f room).aSlot=f.aSlot ∧ (afterOdd f room).nSlot=f.nSlot ∧ (afterOdd f room).rSlot=f.rSlot := by
  unfold afterOdd
  split <;> exact ⟨rfl,rfl,rfl⟩
theorem iteration_slots {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (iteration f room).aSlot=f.aSlot ∧ (iteration f room).nSlot=f.nSlot ∧ (iteration f room).rSlot=f.rSlot := by
  unfold iteration
  split <;> exact afterOdd_slots f room

theorem iteration_preserves_nat {l : PoolCalls.PoolLayout} (f : Frame l)
    (room : f.cursor.top+21<PoolCalls.capacity) {slot n : Nat} (live : NatArena.Borrow f.cursor.state.nats slot n) :
    NatArena.Borrow (iteration f room).cursor.state.nats slot n := by
  have oddLive : NatArena.Borrow (afterOdd f room).cursor.state.nats slot n := by
    unfold afterOdd
    split
    · exact accumulate_preserves_nat f (by omega) live
    · exact live
  have halfLive : NatArena.Borrow (halved f room).cursor.state.nats slot n:=oddLive
  unfold iteration
  split
  · exact square_preserves_nat (halved f room) (by have h:=halved_top_le f room;omega) halfLive
  · exact halfLive

theorem iteration_globals {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity) :
    (iteration f room).cursor.state.globals=f.cursor.state.globals := by
  have oddGlobals : (afterOdd f room).cursor.state.globals=f.cursor.state.globals := by
    unfold afterOdd
    split
    · exact accumulate_globals f (by omega)
    · rfl
  have halfGlobals : (halved f room).cursor.state.globals=f.cursor.state.globals:=oddGlobals
  unfold iteration
  split
  · exact (square_globals (halved f room) (by have h:=halved_top_le f room;omega)).trans halfGlobals
  · exact halfGlobals

/-- Only the actual three local cells and owned pool objects are mutable.
All other memory is derived unchanged from the complete source steps. -/
theorem iteration_other {l : PoolCalls.PoolLayout} (f : Frame l) (room : f.cursor.top+21<PoolCalls.capacity)
    (slot : Nat) (pa : slot≠f.aSlot) (pn : slot≠f.nSlot) (pr : slot≠f.rSlot)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (iteration f room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  have oddOther : (afterOdd f room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
    unfold afterOdd
    split
    · exact accumulate_other f (by omega) slot pr hp ht hh
    · rfl
  have halfOther : (halved f room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? :=
    (half_other (afterOdd f room) slot (by rw[(afterOdd_slots f room).2.1];exact pn)).trans oddOther
  unfold iteration
  split
  · exact (square_other (halved f room) (by have h:=halved_top_le f room;omega) slot
      (by change slot≠(afterOdd f room).aSlot;rw[(afterOdd_slots f room).1];exact pa) hp ht hh).trans halfOther
  · exact halfOther

end ScopedC.RationalPowerCalls
