/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplySelection
import ScopedC.RationalIntervalMultiplyBindings
import ScopedC.CallEventTimeline

namespace ScopedC.RationalIntervalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 100000

structure Answers (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) (service : Call) : Prop where
  qt1 : service "qt" [a.lo.source,b.lo.source] (base c a b).state=
    some ((p l c a b).source,(RationalMultiplyCalls.c11 l (base c a b) a.lo b.lo).state)
  qt2 : service "qt" [a.lo.source,b.hi.source] (c1 l c a b).state=
    some ((q l c a b).source,(RationalMultiplyCalls.c11 l (c1 l c a b) a.lo b.hi).state)
  qt3 : service "qt" [a.hi.source,b.lo.source] (c2 l c a b).state=
    some ((r l c a b).source,(RationalMultiplyCalls.c11 l (c2 l c a b) a.hi b.lo).state)
  qt4 : service "qt" [a.hi.source,b.hi.source] (c3 l c a b).state=
    some ((s l c a b).source,(RationalMultiplyCalls.c11 l (c3 l c a b) a.hi b.hi).state)
  min1 : service "qmin" [(p l c a b).source,(q l c a b).source] (c4 l c a b).state=
    some ((RationalSelectionTree.left false l (c4 l c a b) (four l c a b)).source,
      (RationalSelectionTree.t1 l (c4 l c a b) (four l c a b)).state)
  min2 : service "qmin" [(r l c a b).source,(s l c a b).source]
    (RationalSelectionTree.t1 l (c4 l c a b) (four l c a b)).state=
    some ((RationalSelectionTree.right false l (c4 l c a b) (four l c a b)).source,
      (RationalSelectionTree.t2 l (c4 l c a b) (four l c a b)).state)
  min3 : service "qmin" [(RationalSelectionTree.left false l (c4 l c a b) (four l c a b)).source,
    (RationalSelectionTree.right false l (c4 l c a b) (four l c a b)).source]
    (RationalSelectionTree.t2 l (c4 l c a b) (four l c a b)).state=
    some ((lowQ l c a b).source,(middle l c a b).state)
  max1 : service "qmax" [(p l c a b).source,(q l c a b).source] (middle l c a b).state=
    some ((RationalSelectionTree.left true l (middle l c a b) (four l c a b)).source,
      (RationalSelectionTree.t1 l (middle l c a b) (four l c a b)).state)
  max2 : service "qmax" [(r l c a b).source,(s l c a b).source]
    (RationalSelectionTree.t1 l (middle l c a b) (four l c a b)).state=
    some ((RationalSelectionTree.right true l (middle l c a b) (four l c a b)).source,
      (RationalSelectionTree.t2 l (middle l c a b) (four l c a b)).state)
  max3 : service "qmax" [(RationalSelectionTree.left true l (middle l c a b) (four l c a b)).source,
    (RationalSelectionTree.right true l (middle l c a b) (four l c a b)).source]
    (RationalSelectionTree.t2 l (middle l c a b) (four l c a b)).state=
    some ((highQ l c a b).source,(finish l c a b).state)

private theorem tree_size2 (l : PoolCalls.PoolLayout) (c : Cursor) (v : RationalSelectionTree.Four) :
    (RationalSelectionTree.t2 l c v).state.nats.values.length=c.state.nats.values.length+12 := by
  unfold RationalSelectionTree.t2
  rw[RationalSelectionTree.step_size,RationalSelectionTree.t1,RationalSelectionTree.step_size]

private theorem middle_size (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (middle l c a b).state.nats.values.length=c.state.nats.values.length+62 := by
  unfold middle
  rw[RationalSelectionTree.size_finish,size4]

/-- Every answer in this service is backed by one of the ten already proved
actual source executions. The allocation-count timeline only avoids expensive
symbolic full-heap lookup normalization; complete input states are still checked. -/
theorem answers_exist (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair)
    (ha : a.Live c.state) (hb : b.Live c.state) (pa : a.Positive) (pb : b.Positive) :
    ∃service : Call,Answers l c a b service ∧
      (∀name args before value after,service name args before=some (value,after) →
        SourceCall Header.layout code 7 name args before value after) := by
  have ps:=products code lib ctx room a b ha hb pa pb
  have ss:=selected_calls code lib ctx room a b
  let v:=four l c a b
  let start:=c4 l c a b
  let mid:=middle l c a b
  let e1 : CallEvents.Event Header.layout code 7 :=
    ⟨"qt",[a.lo.source,b.lo.source],(base c a b).state,(p l c a b).source,
      (RationalMultiplyCalls.c11 l (base c a b) a.lo b.lo).state,raise_once ps.1⟩
  let e2 : CallEvents.Event Header.layout code 7 :=
    ⟨"qt",[a.lo.source,b.hi.source],(c1 l c a b).state,(q l c a b).source,
      (RationalMultiplyCalls.c11 l (c1 l c a b) a.lo b.hi).state,raise_once ps.2.1⟩
  let e3 : CallEvents.Event Header.layout code 7 :=
    ⟨"qt",[a.hi.source,b.lo.source],(c2 l c a b).state,(r l c a b).source,
      (RationalMultiplyCalls.c11 l (c2 l c a b) a.hi b.lo).state,raise_once ps.2.2.1⟩
  let e4 : CallEvents.Event Header.layout code 7 :=
    ⟨"qt",[a.hi.source,b.hi.source],(c3 l c a b).state,(s l c a b).source,
      (RationalMultiplyCalls.c11 l (c3 l c a b) a.hi b.hi).state,raise_once ps.2.2.2⟩
  let e5 : CallEvents.Event Header.layout code 7 :=
    ⟨"qmin",[v.p.source,v.q.source],start.state,(RationalSelectionTree.left false l start v).source,
      (RationalSelectionTree.t1 l start v).state,ss.1.1⟩
  let e6 : CallEvents.Event Header.layout code 7 :=
    ⟨"qmin",[v.r.source,v.s.source],(RationalSelectionTree.t1 l start v).state,
      (RationalSelectionTree.right false l start v).source,(RationalSelectionTree.t2 l start v).state,ss.1.2.1⟩
  let e7 : CallEvents.Event Header.layout code 7 :=
    ⟨"qmin",[(RationalSelectionTree.left false l start v).source,(RationalSelectionTree.right false l start v).source],
      (RationalSelectionTree.t2 l start v).state,(lowQ l c a b).source,mid.state,ss.1.2.2⟩
  let e8 : CallEvents.Event Header.layout code 7 :=
    ⟨"qmax",[v.p.source,v.q.source],mid.state,(RationalSelectionTree.left true l mid v).source,
      (RationalSelectionTree.t1 l mid v).state,ss.2.1⟩
  let e9 : CallEvents.Event Header.layout code 7 :=
    ⟨"qmax",[v.r.source,v.s.source],(RationalSelectionTree.t1 l mid v).state,
      (RationalSelectionTree.right true l mid v).source,(RationalSelectionTree.t2 l mid v).state,ss.2.2.1⟩
  let e10 : CallEvents.Event Header.layout code 7 :=
    ⟨"qmax",[(RationalSelectionTree.left true l mid v).source,(RationalSelectionTree.right true l mid v).source],
      (RationalSelectionTree.t2 l mid v).state,(highQ l c a b).source,(finish l c a b).state,ss.2.2.2⟩
  let es:=[e1,e2,e3,e4,e5,e6,e7,e8,e9,e10]
  let n:=c.state.nats.values.length
  have keys : es.map CallEvents.timeKey=[n,n+11,n+22,n+33,n+44,n+50,n+56,n+62,n+68,n+74] := by
    dsimp only[es,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10,List.map,CallEvents.timeKey,start,mid,n]
    simp only[size1,size2,size3,size4,RationalSelectionTree.t1,RationalSelectionTree.step_size,tree_size2,middle_size]
    rfl
  have unique : (es.map CallEvents.timeKey).Nodup := by
    rw[keys]
    simp [List.nodup_cons] <;> omega
  obtain ⟨service,answer,closed⟩:=CallEvents.timeline_service es unique
  refine ⟨service,?_,closed⟩
  exact ⟨answer e1 (by exact List.mem_cons_self),
    answer e2 (by exact List.mem_cons_of_mem e1 (List.mem_cons_self)),
    answer e3 (by exact List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_self))),
    answer e4 (by exact List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_self)))),
    answer e5 (by exact List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_self))))),
    answer e6 (by exact List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_self)))))),
    answer e7 (by exact List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_of_mem e6 (List.mem_cons_self))))))),
    answer e8 (by exact List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_of_mem e6 (List.mem_cons_of_mem e7 (List.mem_cons_self)))))))),
    answer e9 (by exact List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_of_mem e6 (List.mem_cons_of_mem e7 (List.mem_cons_of_mem e8 (List.mem_cons_self))))))))),
    answer e10 (by exact List.mem_cons_of_mem e1 (List.mem_cons_of_mem e2 (List.mem_cons_of_mem e3 (List.mem_cons_of_mem e4 (List.mem_cons_of_mem e5 (List.mem_cons_of_mem e6 (List.mem_cons_of_mem e7 (List.mem_cons_of_mem e8 (List.mem_cons_of_mem e9 (List.mem_cons_self))))))))))⟩

end ScopedC.RationalIntervalMultiplyCalls
