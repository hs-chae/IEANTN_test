/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientScalarFrames
import ScopedC.PositiveCasts

namespace ScopedC.SourceNatGlobal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

/-- Existing physical N scalar storage, possibly the actual static null.
The old cell is not presumed to contain a live numerical value. -/
structure RawAt (s : State) (name : String) (object : Nat) (value : Option Value) : Prop where
  lookup : s.globals.lookup name=some ⟨object,0,[]⟩
  storage : s.heap[object]?=some {type:="N",cells:=[value]}

theorem memory {s t : State} {name : String} {object : Nat} {value : Option Value}
    (h : RawAt s name object value) (globals : t.globals=s.globals)
    (stored : t.heap[object]?=s.heap[object]?) : RawAt t name object value :=
  ⟨by simpa only[globals] using h.lookup,stored.trans h.storage⟩

theorem separated {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {name : String} {object : Nat} {value : Option Value} (h : RawAt c.state name object value) :
    object≠l.pool ∧ object≠l.top ∧ object≠l.high := by
  have hp : object≠l.pool := by
    intro same
    have storage:=h.storage
    simp only[same,ctx.pool_read] at storage
    have flags:=congrArg (fun x : Option Object=>x.map Object.isArray) storage
    change some true=some false at flags
    contradiction
  have counter : ∀slot, c.state.heap[slot]?=some {type:="unsigned",cells:=[some (PoolCalls.word c.top)]} →
      object≠slot := by
    intro slot stored same
    have storage:=h.storage
    simp only[same,stored] at storage
    have types:=congrArg (fun x : Option Object=>x.map Object.type) storage
    change some "unsigned"=some "N" at types
    contradiction
  have ht : object≠l.top :=counter l.top ctx.top_read
  have hh : object≠l.high := by
    intro same
    have storage:=h.storage
    simp only[same,ctx.high_read] at storage
    have types:=congrArg (fun x : Option Object=>x.map Object.type) storage
    change some "unsigned"=some "N" at types
    contradiction
  exact ⟨hp,ht,hh⟩

theorem advanced {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    {name : String} {object : Nat} {value : Option Value} (h : RawAt c.state name object value)
    (values : List Nat) : RawAt (CursorFrames.advance l c values).state name object value := by
  have safe:=separated ctx h
  exact memory h (CursorSingleFrames.advance_globals l c values)
    (CursorSingleFrames.advance_other l c values object safe.1 safe.2.1 safe.2.2)

theorem allocated {s : State} {name : String} {object : Nat} {old : Option Value}
    (h : RawAt s name object old) (type localName : String) (value : Option Value) :
    RawAt (allocate s type localName value) name object old :=
  memory h rfl (List.getElem?_append_left (List.getElem?_eq_some_iff.mp h.storage).choose)

theorem lvalue (service : Call) (fuel : Nat) {s : State} {name : String} {object : Nat}
    {old : Option Value} (h : RawAt s name object old) (unshadowed : s.env.lookup name=none) :
    evalLValue Header.layout service (fuel+1) s (.var name)=some (⟨object,0,[]⟩,true,s) := by
  simp [evalLValue,getVar,unshadowed,h.lookup,h.storage]

theorem write_global {s : State} {name : String} {object slot n : Nat} {old : Option Value}
    (h : RawAt s name object old) (live : NatArena.Borrow s.nats slot n) :
    write Header.layout s ⟨object,0,[]⟩ true (.natObject slot)=
      some (.natObject slot,LocalAssignment.changed s object "N" (.natObject slot)) := by
  have cast:=PositiveCasts.cast_N Header.layout s 99 slot n live
  simp [write,addressType,typeAt,h.storage,cast,LocalAssignment.changed,PoolCalls.storeObject]

theorem source_assignment (service : Call) (fuel : Nat) {s middle : State} {name : String}
    {object slot n : Nat} {old : Option Value} {rhs : Expr} (h : RawAt middle name object old)
    (unshadowed : middle.env.lookup name=none) (live : NatArena.Borrow middle.nats slot n)
    (right : evalExpr Header.layout service (fuel+1) s rhs=some (.natObject slot,middle)) :
    evalExpr Header.layout service (fuel+2) s (.binary "=" (.var name) rhs)=
      some (.natObject slot,LocalAssignment.changed middle object "N" (.natObject slot)) := by
  rw[evalExpr,right]
  simp only[Bind.bind,Option.bind]
  rw[lvalue service fuel h unshadowed]
  exact write_global h live

end ScopedC.SourceNatGlobal
