/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorStepFrame

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  point : Generated.f_point∈code
  rmul : Generated.f_rmul∈code
  mulLibrary : RationalIntervalMultiplyCalls.Library code
  radd : Generated.f_radd∈code
  qa : Generated.f_qa∈code
  addLibrary : RationalAddCalls.Library code

theorem point_call (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) :
    SourceCall Header.layout code 1 "point" [coeffs[f.k].source] f.cursor.state (pointInput f hk).source f.cursor.state := by
  change SourceCall Header.layout code 1 "point"
    [RecordCasts.rational coeffs[f.k].numerator.slot (SignedNegCalls.bit coeffs[f.k].numerator.negative) coeffs[f.k].denSlot]
    f.cursor.state (IntervalCasts.value _ _) f.cursor.state
  exact RationalPointCalls.point_closed code lib.point (f.table.live f.k hk).1 (f.table.live f.k hk).2
    (SignedNegCalls.bit_bound _)

theorem product_call (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (room : f.cursor.top+107<PoolCalls.capacity) :
    SourceCall Header.layout code 8 "rmul" [f.result.source,f.a.source] f.cursor.state (product f).source (productCursor f).state := by
  unfold productCursor IntervalProductApplicability.next
  exact RationalIntervalMultiplyCalls.rmul_closed code lib.rmul lib.mulLibrary f.context (by omega)
    f.result f.a f.rLive f.aLive f.rPositive f.aPositive

theorem sum_call (code : List Function) (lib : Library code) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) :
    SourceCall Header.layout code 7 "radd" [(pointInput f hk).source,(product f).source] (productCursor f).state
      (sum f hk).source (sumCursor f hk).state := by
  rw[sum_source]
  unfold sumCursor
  exact RationalIntervalAddCalls.radd_closed code lib.radd lib.qa lib.addLibrary (product_context f room)
    (by rw[product_top];omega) (pointInput f hk) (product f) (point_live f hk) (product_live f) (point_positive f hk) (product_positive f)

structure Answers (service : Call) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : Prop where
  callPoint : service "point" [coeffs[f.k].source] f.cursor.state=some ((pointInput f hk).source,f.cursor.state)
  callProduct : service "rmul" [f.result.source,f.a.source] f.cursor.state=some ((product f).source,(productCursor f).state)
  callSum : service "radd" [(pointInput f hk).source,(product f).source] (productCursor f).state=
    some ((sum f hk).source,(sumCursor f hk).state)

def stepExpression : Expr := .binary "=" (.var "result") (.call (.var "radd") [
  .call (.var "point") [.index (.var "coeffs") (.var "k")],
  .call (.var "rmul") [.var "result",.var "a"]])

/-- Complete actual source coefficient load, point call, multiplication,
addition, checked RI cast and final assignment. Every answer is supplied by
the corresponding actual SourceCall theorem above in the final loop. -/
theorem stepped_source (service : Call) {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity)
    (answers : Answers service f hk) :
    Eval Header.layout service stepExpression f.cursor.state (stepped f hk room).cursor.state (sum f hk).source := by
  have pointEval:=ExpressionTemplates.call_one Header.layout service (coefficient_source service 1 f hk) answers.callPoint
  have productEval:=ExpressionTemplates.call_two Header.layout service
    (LocalBinding.eval service 3 f.rAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel))
    (LocalBinding.eval service 3 f.aAt (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) answers.callProduct
  have sumEval:=ExpressionTemplates.call_two Header.layout service pointEval productEval answers.callSum
  have safe:=LocalStorageSeparation.pool f.context f.rAt (by decide +kernel : ("RI":String)≠"unsigned")
  have atR:=sum_binding f hk f.rAt safe.1 safe.2.1 safe.2.2
  exact ⟨7,LocalAssignment.evaluate service 5 sumEval atR (Pair.cast (sum_live f hk) "RI" (by decide +kernel))⟩

end ScopedC.TaylorCalls
