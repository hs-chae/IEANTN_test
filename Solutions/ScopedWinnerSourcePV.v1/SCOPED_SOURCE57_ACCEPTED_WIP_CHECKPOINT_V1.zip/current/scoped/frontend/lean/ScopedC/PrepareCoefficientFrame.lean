/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PrepareCoefficientMath
import ScopedC.CoefficientTableWrite
import ScopedC.CoefficientTableWritableRead
import ScopedC.SourceUnsignedGlobal
import ScopedC.LocalStorageSeparation

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

/-- Physical state of the actual prepare coefficient while. It is constructed
from actual initial qi stores and maintained by actual source qv/parity/stores;
it is not an assumed prepared numerical state. -/
structure CoeffFrame (l : PoolCalls.PoolLayout) (object d : Nat) (eb ab : Address) where
  cursor : Cursor
  expCoeffs : List Input
  atanhCoeffs : List Input
  k : Nat
  kSlot : Nat
  context : Valid l cursor
  expAt : CoefficientTableRead.TableAt cursor.state eb expCoeffs
  atanhAt : CoefficientTableRead.TableAt cursor.state ab atanhCoeffs
  expLength : expCoeffs.length=k
  atanhLength : atanhCoeffs.length=k
  expExtent : expAt.cells.length=65
  atanhExtent : atanhAt.cells.length=65
  expValues : TaylorCalls.coefficientValues expCoeffs=(List.range k).map expCoefficient
  atanhValues : TaylorCalls.coefficientValues atanhCoeffs=(List.range k).map atanhCoefficient
  expLookup : cursor.state.globals.lookup "expCoeffs"=some eb
  atanhLookup : cursor.state.globals.lookup "atanhCoeffs"=some ab
  expUnshadowed : cursor.state.env.lookup "expCoeffs"=none
  atanhUnshadowed : cursor.state.env.lookup "atanhCoeffs"=none
  depthAt : SourceUnsignedGlobal.At cursor.state "depth" object d
  depthUnshadowed : cursor.state.env.lookup "depth"=none
  kAt : LocalBinding.At cursor.state "k" "unsigned int" (PoolCalls.word k) kSlot
  kPositive : 0<k
  kBound : k ≤ d+1
  depthBound : d ≤ 64
  arraysApart : eb.object≠ab.object
  depthApart : object≠l.pool ∧ object≠l.top ∧ object≠l.high

theorem value_at (coeffs : List Input) (f : Nat→Rat) (k i : Nat)
    (length : coeffs.length=k) (values : TaylorCalls.coefficientValues coeffs=(List.range k).map f)
    (index : i<k) : (coeffs[i]'(by omega)).mathematical.value=f i := by
  have left : (TaylorCalls.coefficientValues coeffs)[i]?=some ((coeffs[i]'(by omega)).mathematical.value) := by
    simp [TaylorCalls.coefficientValues,List.getElem?_map,List.getElem?_eq_getElem (by omega : i<coeffs.length)]
  have right : ((List.range k).map f)[i]?=some (f i) := by
    have bound : i<(List.range k).length := by simpa using index
    simp [List.getElem?_map,List.getElem?_eq_getElem bound]
  have same:=congrArg (fun xs : List Rat=>xs[i]?) values
  rw[left,right] at same
  exact Option.some.inj same

def previous {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : Input :=
  f.expCoeffs[f.k-1]'(by have len:=f.expLength;have pos:=f.kPositive;omega)

theorem previous_value {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : (previous f).mathematical.value=expCoefficient (f.k-1) :=
  value_at f.expCoeffs expCoefficient f.k (f.k-1) f.expLength f.expValues (by have h:=f.kPositive;omega)

theorem previous_live {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : (previous f).Live f.cursor.state :=
  f.expAt.live (f.k-1) (by have len:=f.expLength;have pos:=f.kPositive;omega)

theorem previous_positive {l : PoolCalls.PoolLayout} {object d : Nat} {eb ab : Address}
    (f : CoeffFrame l object d eb ab) : 0<(previous f).denominator :=
  f.expAt.positive (f.k-1) (by have len:=f.expLength;have pos:=f.kPositive;omega)

end ScopedC.PrepareSource
