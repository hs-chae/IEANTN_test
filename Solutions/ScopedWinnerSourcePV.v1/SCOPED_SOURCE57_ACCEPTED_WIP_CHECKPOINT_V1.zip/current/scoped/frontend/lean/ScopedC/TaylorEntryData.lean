/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorFrame
import ScopedC.SourceUnsignedGlobal
import ScopedC.RationalUnsignedTrace

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def parameters (c : Cursor) (base : Address) (a : Pair) : Cursor :=
  CursorFrames.framed c "const Q*" "coeffs" (.pointer base false) "RI" "a" a.source
def afterZero (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) : Cursor :=
  RationalUnsignedTrace.after l (parameters c base a) 0
def zeroInput (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) : Input :=
  RationalUnsignedTrace.output l (parameters c base a) 0
def zeroPair (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) : Pair :=
  ⟨zeroInput l c base a,zeroInput l c base a⟩
def stored (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) : Cursor :=
  CursorLocals.allocated (afterZero l c base a) "RI" "result" (zeroPair l c base a).source
def loopStart (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) (d : Nat) : Cursor :=
  CursorLocals.allocated (stored l c base a) "unsigned int" "k" (PoolCalls.word (d+1))

theorem pointer_cast (s : State) (base : Address) (address : addressType Header.layout s base=some "Q") :
    castValue Header.layout s 100 "const Q*" (.pointer base false)=some (.pointer base false) := by
  change (do let target←addressType Header.layout s base
             if normalizeType target != "Q" || (!(hasPrefix "const " "const Q*") && !false) then none
             else pure (Value.pointer base (false && !(hasPrefix "const " "const Q*"))))=_
  rw[address]
  rfl

theorem bind_parameters {c : Cursor} {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (nonempty : 0<coeffs.length) (a : Pair) (alive : a.Live c.state) :
    bindArgs Header.layout [("const Q*","coeffs"),("RI","a")] [.pointer base false,a.source] c.state=
      some (parameters c base a).state := by
  have address : addressType Header.layout {c.state with env:=[]} base=some "Q" := by
    simpa only[addressType,Nat.add_zero] using (CoefficientTableRead.read_coefficient table 0 nonempty).2
  exact TypedFrames.bind_two Header.layout c.state "const Q*" "coeffs" "RI" "a"
    (.pointer base false) a.source (.pointer base false) a.source (pointer_cast _ base address)
    (Pair.cast (s:=allocate {c.state with env:=[]} "const Q*" "coeffs" (some (.pointer base false))) alive "RI" (by decide +kernel))

theorem parameters_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (base : Address) (a : Pair) :
    Valid l (parameters c base a) := CursorFrames.framed_valid ctx "const Q*" "coeffs" (.pointer base false) "RI" "a" a.source

def parameters_table {c : Cursor} {base : Address} {coeffs : List Input} (table : CoefficientTableRead.TableAt c.state base coeffs)
    (a : Pair) : CoefficientTableRead.TableAt (parameters c base a).state base coeffs :=
  CoefficientTableRead.allocated (CoefficientTableRead.allocated
    (CoefficientTableRead.memory (t:={c.state with env:=[]}) table rfl (fun _ _ h=>h))
    "const Q*" "coeffs" (some (.pointer base false))) "RI" "a" (some a.source)

theorem parameters_depth {c : Cursor} {object d : Nat} (depth : SourceUnsignedGlobal.At c.state "depth" object d)
    (base : Address) (a : Pair) : SourceUnsignedGlobal.At (parameters c base a).state "depth" object d :=
  SourceUnsignedGlobal.allocated (SourceUnsignedGlobal.allocated
    (SourceUnsignedGlobal.memory (t:={c.state with env:=[]}) depth rfl rfl)
    "const Q*" "coeffs" (some (.pointer base false))) "RI" "a" (some a.source)

theorem parameters_coeff (c : Cursor) (base : Address) (a : Pair) :
    LocalBinding.At (parameters c base a).state "coeffs" "const Q*" (.pointer base false) c.state.heap.length :=
  LocalBinding.allocate_other (LocalBinding.allocate_head {c.state with env:=[]} "coeffs" "const Q*" (.pointer base false) (by rfl))
    "a" "RI" (some a.source) (by decide +kernel)
theorem parameters_a (c : Cursor) (base : Address) (a : Pair) :
    LocalBinding.At (parameters c base a).state "a" "RI" a.source (c.state.heap.length+1) := by
  simpa only[parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.length_append,List.length_singleton] using
    LocalBinding.allocate_head (allocate {c.state with env:=[]} "const Q*" "coeffs" (some (.pointer base false))) "a" "RI" a.source (Pair.initialized a)
theorem parameters_length (c : Cursor) (base : Address) (a : Pair) :
    (parameters c base a).state.heap.length=c.state.heap.length+2 := by
  simp [parameters,CursorFrames.framed,TwoFrames.frame,allocate]

theorem zero_shape (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) :
    (afterZero l c base a).state.heap.length=(parameters c base a).state.heap.length ∧
    (afterZero l c base a).state.env=(parameters c base a).state.env :=
  CursorEffects.shape l (parameters c base a) [0,0,1]
theorem stored_length (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) :
    (stored l c base a).state.heap.length=c.state.heap.length+3 := by
  simp only[stored,CursorLocals.allocated,allocate,List.length_append,List.length_singleton,(zero_shape l c base a).1,parameters_length]
theorem loop_length (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) (d : Nat) :
    (loopStart l c base a d).state.heap.length=c.state.heap.length+4 := by
  simp only[loopStart,CursorLocals.allocated,allocate,List.length_append,List.length_singleton,stored_length]
theorem loop_top (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) (d : Nat) :
    (loopStart l c base a d).top=c.top+3 := rfl

theorem zero_live (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) :
    (zeroPair l c base a).Live (afterZero l c base a).state :=
  ⟨RationalUnsignedTrace.live l (parameters c base a) 0,RationalUnsignedTrace.live l (parameters c base a) 0⟩
theorem zero_value (l : PoolCalls.PoolLayout) (c : Cursor) (base : Address) (a : Pair) :
    (zeroInput l c base a).mathematical.value=0 := (RationalUnsignedTrace.mathematical l (parameters c base a) 0).1

end ScopedC.TaylorCalls
