/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalIntervalMultiplySelection
import ScopedC.RationalIntervalMultiplyBindings

namespace ScopedC.RationalIntervalMultiplyCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000
attribute [local irreducible] finish

def result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Value := (outputPair l c a b).source
def stored (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  CursorLocals.allocated (finish l c a b) "RI" "out" (result l c a b)
def bodyExit (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  PoolContextPop.unframe (base c a b).state (stored l c a b)
def after (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) : Cursor :=
  PoolContextPop.unframe c.state (bodyExit l c a b)

theorem stored_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (stored l c a b) :=
  CursorLocals.allocated_valid (finish_valid ctx room a b) "RI" "out" _

theorem scoped_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (bodyExit l c a b) := by
  have hp := (List.getElem?_eq_some_iff.mp ctx.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp ctx.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp ctx.high_read).choose
  apply PoolContextPop.valid (stored_valid ctx room a b)
  all_goals rw[heap0];omega

theorem after_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+79<PoolCalls.capacity) (a b : Pair) : Valid l (after l c a b) :=
  PoolContextPop.valid (scoped_valid ctx room a b)
    ((List.getElem?_eq_some_iff.mp ctx.pool_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.top_read).choose)
    ((List.getElem?_eq_some_iff.mp ctx.high_read).choose)

theorem after_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (after l c a b).top=c.top+80 := finish_top l c a b

theorem scoped_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (outputPair l c a b).Live (bodyExit l c a b).state := output_live l c a b
theorem after_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Pair) :
    (outputPair l c a b).Live (after l c a b).state := output_live l c a b

end ScopedC.RationalIntervalMultiplyCalls
