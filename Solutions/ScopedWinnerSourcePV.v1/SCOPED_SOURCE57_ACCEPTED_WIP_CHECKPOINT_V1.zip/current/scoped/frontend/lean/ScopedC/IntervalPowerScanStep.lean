/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.IntervalPowerScanControl
import ScopedC.IntervalPowerMathematics

namespace ScopedC.IntervalPowerScan
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

theorem multiplied_bit {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool)
    (room : f.cursor.top+79<PoolCalls.capacity) : (multiplied f fromA room).bit=f.bit := rfl
theorem multiplied_original {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) (fromA : Bool)
    (room : f.cursor.top+79<PoolCalls.capacity) : original (multiplied f fromA room)=original f := rfl
theorem halved_original {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) : original (halved f)=original f := rfl
theorem halved_mathematical {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) : mathematical (halved f)=mathematical f := rfl

def squared {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : Frame l n := multiplied f false (by omega)
theorem squared_top {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : (squared f room).cursor.top=f.cursor.top+80 := multiplied_top _ _ _

def afterOdd {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : Frame l n :=
  if (n/f.bit)%2=1 then multiplied (squared f room) true (by rw[squared_top];omega) else squared f room
def iteration {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : Frame l n := halved (afterOdd f room)

theorem afterOdd_bit {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : (afterOdd f room).bit=f.bit := by
  unfold afterOdd
  split <;> rfl
theorem iteration_bit {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : (iteration f room).bit=f.bit/2 := by
  change (afterOdd f room).bit/2=f.bit/2
  rw[afterOdd_bit]
theorem iteration_original {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : original (iteration f room)=original f := by
  unfold iteration
  rw[halved_original]
  unfold afterOdd
  split <;> rfl
theorem iteration_top_le {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : (iteration f room).cursor.top ≤ f.cursor.top+160 := by
  change (afterOdd f room).cursor.top ≤ _
  unfold afterOdd
  split
  · rw[multiplied_top,squared_top]
  · rw[squared_top];omega

def oddStatement : Stmt := .branch scanOdd (.eval (multiplyExpression true)) .skip
def loopBody : Stmt := .sequence [.eval (multiplyExpression false),oddStatement,.eval halfExpression]

def SquareAnswer (service : Call) {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n) : Prop :=
  service "rmul" [(left f false).source,f.result.source] f.cursor.state=
    some ((product f false).source,(IntervalProductApplicability.next l f.cursor (left f false) f.result).state)
def OddAnswer (service : Call) {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) : Prop :=
  (n/f.bit)%2=1 → service "rmul" [(left (squared f room) true).source,(squared f room).result.source] (squared f room).cursor.state=
    some ((product (squared f room) true).source,
      (IntervalProductApplicability.next l (squared f room).cursor (left (squared f room) true) (squared f room).result).state)

theorem iteration_shape {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) :
    (iteration f room).cursor.state.heap.length=f.cursor.state.heap.length ∧
    (iteration f room).cursor.state.env=f.cursor.state.env := by
  have first:=multiplied_shape f false (by omega)
  have second : (afterOdd f room).cursor.state.heap.length=f.cursor.state.heap.length ∧
      (afterOdd f room).cursor.state.env=f.cursor.state.env := by
    unfold afterOdd
    split
    · have step:=multiplied_shape (squared f room) true (by rw[squared_top];omega)
      exact ⟨step.1.trans first.1,step.2.trans first.2⟩
    · exact first
  have third:=half_shape (afterOdd f room)
  exact ⟨third.1.trans second.1,third.2.1.trans second.2⟩

theorem odd_run (service : Call) {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) (positive : 0<f.bit) (answer : OddAnswer service f room) :
    Run Header.layout service oddStatement (squared f room).cursor.state (.continuing (afterOdd f room).cursor.state) := by
  by_cases odd : (n/f.bit)%2=1
  · rw[afterOdd,if_pos odd]
    apply Loops.StmtRun.branch (odd_eval service (squared f room) positive)
    simp only[UnsignedLiteralControl.truth_boolean,show (squared f room).bit=f.bit from rfl,odd,decide_true,↓reduceIte]
    exact Loops.StmtRun.evaluate (multiplied_source service (squared f room) true (by rw[squared_top];omega) (answer odd))
  · rw[afterOdd,if_neg odd]
    apply Loops.StmtRun.branch (odd_eval service (squared f room) positive)
    simp only[UnsignedLiteralControl.truth_boolean,show (squared f room).bit=f.bit from rfl,odd,decide_false,Bool.false_eq_true,↓reduceIte]
    exact Loops.StmtRun.skip _

theorem iteration_run (service : Call) {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity) (positive : 0<f.bit)
    (squareAnswer : SquareAnswer service f) (oddAnswer : OddAnswer service f room) :
    Run Header.layout service loopBody f.cursor.state (.continuing (iteration f room).cursor.state) := by
  apply Loops.StmtRun.sequence
    (Loops.SeqRun.next (Loops.StmtRun.evaluate (multiplied_source service f false (by omega) squareAnswer))
      (Loops.SeqRun.next (odd_run service f room positive oddAnswer)
        (Loops.SeqRun.next (Loops.StmtRun.evaluate (half_source service (afterOdd f room))) (Loops.SeqRun.nil _))))
  have shape:=iteration_shape f room
  exact (PoolCalls.pop_same shape.1 shape.2).symm

theorem iteration_math {l : PoolCalls.PoolLayout} {n : Nat} (f : Frame l n)
    (room : f.cursor.top+159<PoolCalls.capacity)
    (prefixValue : mathematical f=LeanCert.Core.IntervalRat.pow (original f) (n/(f.bit*2)))
    (lower : 2 ≤ n/f.bit) :
    mathematical (iteration f room)=LeanCert.Core.IntervalRat.pow (original f) (n/f.bit) := by
  unfold iteration
  rw[halved_mathematical]
  unfold afterOdd
  split
  · rw[multiplied_math]
    change LeanCert.Core.IntervalRat.mul (original f) (mathematical (squared f room))=_
    rw[show mathematical (squared f room)=LeanCert.Core.IntervalRat.mul (mathematical f) (mathematical f) from multiplied_math f false _,prefixValue]
    exact (by simpa only[if_pos (by assumption)] using IntervalPowerMathematics.quotient_step (original f) n f.bit lower)
  · rw[show mathematical (squared f room)=LeanCert.Core.IntervalRat.mul (mathematical f) (mathematical f) from multiplied_math f false _,prefixValue]
    exact (by simpa only[if_neg (by assumption)] using IntervalPowerMathematics.quotient_step (original f) n f.bit lower)

end ScopedC.IntervalPowerScan
