/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorStepFrame
import LeanCert.Core.IntervalRat.Taylor

namespace ScopedC.TaylorCalls
open ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem stepped_math {l : ScopedC.PoolCalls.PoolLayout} {base : ScopedC.Machine.Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<ScopedC.PoolCalls.capacity) :
    mathematical (stepped f hk room)=
      IntervalRat.add (IntervalRat.singleton coeffs[f.k].mathematical.value) (IntervalRat.mul (mathematical f) (original f)) := by
  have spec:=ScopedC.IntervalAddApplicability.output_spec l (productCursor f) (pointInput f hk) (product f)
    (point_positive f hk) (product_positive f) (le_refl _) (product_order f)
  have low : (sum f hk).lo.mathematical.value=coeffs[f.k].mathematical.value+(product f).lo.mathematical.value := spec.2.2.2.1
  have high : (sum f hk).hi.mathematical.value=coeffs[f.k].mathematical.value+(product f).hi.mathematical.value := spec.2.2.2.2
  have productLow:=ScopedC.NumericRationalIntervalMultiplyRefinement.low_value l f.cursor f.result f.a f.rPositive f.aPositive
  have productHigh:=ScopedC.NumericRationalIntervalMultiplyRefinement.high_value l f.cursor f.result f.a f.rPositive f.aPositive
  change (⟨(sum f hk).lo.mathematical.value,(sum f hk).hi.mathematical.value,sum_order f hk⟩:IntervalRat)=_
  simp only[IntervalRat.add,IntervalRat.singleton,IntervalRat.mul,mathematical,original,IntervalRat.min4,IntervalRat.max4,IntervalRat.mk.injEq]
  exact ⟨low.trans (congrArg (fun v=>coeffs[f.k].mathematical.value+v) productLow),
    high.trans (congrArg (fun v=>coeffs[f.k].mathematical.value+v) productHigh)⟩

def coefficientValues (coeffs : List Input) : List Rat := coeffs.map (fun q=>q.mathematical.value)

/-- Original Horner fold for a suffix of the actual coefficient table. -/
theorem fold_suffix (coeffs : List Input) (k : Nat) (hk : k<coeffs.length) (a : IntervalRat) :
    IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop k)) a=
      IntervalRat.add (IntervalRat.singleton coeffs[k].mathematical.value)
        (IntervalRat.mul (IntervalRat.evalTaylorSeries (coefficientValues (coeffs.drop (k+1))) a) a) := by
  rw[List.drop_eq_getElem_cons hk]
  rfl

end ScopedC.TaylorCalls
