/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceUnsignedStore
import ScopedC.PositiveCasts

namespace ScopedC.SourceUnsignedGlobal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def assigned (s : State) (object n : Nat) : State :=
  LocalAssignment.changed s object "unsigned" (PoolCalls.word n)

theorem lvalue (service : Call) (fuel : Nat) {s : State} {name : String} {object old : Nat}
    (global : At s name object old) (unshadowed : s.env.lookup name=none) :
    evalLValue Header.layout service (fuel+1) s (.var name)=some (⟨object,0,[]⟩,true,s) := by
  simp [evalLValue,getVar,unshadowed,global.lookup,global.storage]

theorem write_global {s : State} {name : String} {object old : Nat}
    (global : At s name object old) (n : Nat) (bound : n<2^32) :
    write Header.layout s ⟨object,0,[]⟩ true (PoolCalls.word n)=
      some (PoolCalls.word n,assigned s object n) := by
  have cast : castValue Header.layout s 100 "unsigned" (PoolCalls.word n)=some (PoolCalls.word n) :=
    PositiveCasts.cast_unsigned s 99 n bound
  simp [write,addressType,typeAt,global.storage,cast,assigned,LocalAssignment.changed,PoolCalls.storeObject]

theorem source_assignment (service : Call) (fuel : Nat) {s middle : State}
    {name : String} {object old n : Nat} {rhs : Expr} (global : At middle name object old)
    (unshadowed : middle.env.lookup name=none) (bound : n<2^32)
    (right : evalExpr Header.layout service (fuel+1) s rhs=some (PoolCalls.word n,middle)) :
    evalExpr Header.layout service (fuel+2) s (.binary "=" (.var name) rhs)=
      some (PoolCalls.word n,assigned middle object n) := by
  rw[evalExpr,right]
  simp only[Bind.bind,Option.bind]
  rw[lvalue service fuel global unshadowed]
  exact write_global global n bound

theorem assigned_at {s : State} {name : String} {object old : Nat}
    (global : At s name object old) (n : Nat) : At (assigned s object n) name object n := by
  constructor
  · exact global.lookup
  · exact List.getElem?_set_self (List.getElem?_eq_some_iff.mp global.storage).choose

end ScopedC.SourceUnsignedGlobal
