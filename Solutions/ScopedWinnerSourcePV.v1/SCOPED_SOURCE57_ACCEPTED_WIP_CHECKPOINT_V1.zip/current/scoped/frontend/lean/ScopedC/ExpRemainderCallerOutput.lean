/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpRemainderCallerPowers
import ScopedC.ExpRemainderOutputFrame

namespace ScopedC.ExpRemainderCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 500000
set_option maxRecDepth 100000
attribute [local irreducible] errorInput errorCursor outputPair

theorem afterOut_heap {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (afterOut r).state.heap.length=c.state.heap.length+8 := by
  change ((next l (storedError r) 0).state.heap++[_]).length=_
  rw[List.length_append,List.length_singleton,(PoolCursor.shape l (storedError r) 0).1]
  change ((errorCursor r).state.heap++[_]).length+1=_
  rw[List.length_append,List.length_singleton,error_heap,radius_heap]

theorem afterOut_globals {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (afterOut r).state.globals=c.state.globals := by
  change (next l (storedError r) 0).state.globals=_
  rw[CursorSingleFrames.globals]
  change (errorCursor r).state.globals=_
  rw[error_globals,radius_globals]

theorem afterOut_borrow {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    {slot value : Nat} (h : NatArena.Borrow c.state.nats slot value) :
    NatArena.Borrow (afterOut r).state.nats slot value :=
  PoolCursor.preserves (c:=storedError r) (error_borrow r (radius_borrow r h))

theorem afterOut_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (slot : Nat) (old : slot<c.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (afterOut r).state.heap[slot]?=c.state.heap[slot]? := by
  have errorOld : slot<(errorCursor r).state.heap.length := by rw[error_heap,radius_heap];omega
  have storedOld : slot<(storedError r).state.heap.length := by
    change slot<((errorCursor r).state.heap++[_]).length
    rw[List.length_append,List.length_singleton];omega
  change ((next l (storedError r) 0).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left (by rw[(PoolCursor.shape l (storedError r) 0).1];exact storedOld),
    PoolCursor.other l (storedError r) 0 slot hp ht hh]
  change ((errorCursor r).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left errorOld,error_other r slot (by rw[radius_heap];omega) hp ht hh]
  exact radius_other r slot old hp ht hh

noncomputable def framedOut {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) : Cursor :=
  PoolContextPop.unframe c.state (PoolContextPop.unframe (parameters c a).state (afterOut r))

theorem framedOut_shape {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (framedOut r).state.heap.length=c.state.heap.length ∧ (framedOut r).state.env=c.state.env := by
  have paramsLength : (parameters c a).state.heap.length=c.state.heap.length+1 := by
    simp [parameters,OneFrames.frame,allocate]
  constructor
  · change (((afterOut r).state.heap.take (parameters c a).state.heap.length).take c.state.heap.length).length=_
    rw[List.length_take,List.length_take,paramsLength,afterOut_heap]
    omega
  · rfl

theorem framedOut_other {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p)
    (slot : Nat) (old : slot<c.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (framedOut r).state.heap[slot]?=c.state.heap[slot]? := by
  have paramsLength : (parameters c a).state.heap.length=c.state.heap.length+1 := by
    simp [parameters,OneFrames.frame,allocate]
  change (((afterOut r).state.heap.take (parameters c a).state.heap.length).take c.state.heap.length)[slot]?=_
  rw[List.getElem?_take_of_lt old,List.getElem?_take_of_lt (by rw[paramsLength];omega)]
  exact afterOut_other r slot old hp ht hh

theorem framedOut_top {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor}
    {a : Pair} {object d : Nat} {ceil : CeilStage code l c a}
    {f : FactorialStage code l c a object d ceil} {p : ThreePower f} (r : RadiusPower p) :
    (framedOut r).top ≤ c.top+3000 := by
  have radiusBound:=radius_power_top r
  change (errorCursor r).top+1 ≤ c.top+3000
  rw[error_top]
  omega

end ScopedC.ExpRemainderCalls
