/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalNaturalLiteralEffects
namespace ScopedC.RationalDecimalLiteral
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
open ScopedC.DecimalText (digits)
set_option autoImplicit false
set_option maxHeartbeats 400000
set_option maxRecDepth 100000

abbrev Library := RationalNaturalLiteral.Library
def textCursor (c : Cursor) (n : Nat) : Cursor := DecimalInitialized.inputCursor c (toString n)
def endpoint (slot n : Nat) : Endpoint := ⟨slot,n,false⟩

/-- Both decimal parsers and rational normalization execute the actual C source.
The numerator and denominator are source text inputs, not trusted answers. -/
structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (n d : Nat) where
  numerator : Cursor
  numeratorSlot : Nat
  numeratorValid : Valid l numerator
  numeratorLive : NatArena.Borrow numerator.state.nats numeratorSlot n
  numeratorCall : SourceCall Header.layout code 3 "decimal"
    [.pointer ⟨c.state.heap.length,0,[]⟩ false]
    (textCursor c n).state (.natObject numeratorSlot) numerator.state
  numeratorTrace : numerator=CursorFrames.advance l (textCursor c n)
    (0::DecimalExpressions.allocationSteps 0 (digits n))
  numeratorTop : numerator.top=c.top+1+4*(digits n).length
  signedCall : SourceCall Header.layout code 4 "smake"
    [.natObject numeratorSlot,DecimalDigits.integer 0] numerator.state
    (endpoint numeratorSlot n).source (next l numerator 0).state
  denominator : Cursor
  denominatorSlot : Nat
  denominatorValid : Valid l denominator
  denominatorLive : NatArena.Borrow denominator.state.nats denominatorSlot d
  magnitudeLive : (endpoint numeratorSlot n).Live denominator.state
  denominatorCall : SourceCall Header.layout code 3 "decimal"
    [.pointer ⟨(next l numerator 0).state.heap.length,0,[]⟩ false]
    (textCursor (next l numerator 0) d).state (.natObject denominatorSlot) denominator.state
  denominatorTrace : denominator=CursorFrames.advance l (textCursor (next l numerator 0) d)
    (0::DecimalExpressions.allocationSteps 0 (digits d))
  denominatorTop : denominator.top=c.top+3+4*(digits n).length+4*(digits d).length
  output : Input
  rationalCall : SourceCall Header.layout code 5 "qm"
    [(endpoint numeratorSlot n).source,.natObject denominatorSlot]
    denominator.state output.source (RationalMakeCalls.c5 l denominator (endpoint numeratorSlot n) d).state
  valid : Valid l (RationalMakeCalls.c5 l denominator (endpoint numeratorSlot n) d)
  live : output.Live (RationalMakeCalls.c5 l denominator (endpoint numeratorSlot n) d).state
  positive : 0<output.denominator
  value : output.mathematical.value=(n:Rat)/(d:Rat)

def after {code : List Function} {l : PoolLayout} {c : Cursor} {n d : Nat}
    (D : Stages code l c n d) : Cursor :=
  RationalMakeCalls.c5 l D.denominator (endpoint D.numeratorSlot n) d

theorem stages_exist (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (ctx : Valid l c) (n d : Nat) (positive : 0<d)
    (room : c.top+7+4*(digits n).length+4*(digits d).length < capacity) :
    Nonempty (Stages code l c n d) := by
  have textValid : Valid l (textCursor c n) := DecimalInitialized.input_valid ctx _
  obtain ⟨num,numSlot,numCall,numLive,numValid,numBuffer,numTop,numHeap,numEnv,numSize,
      numOther,numTrace,numPreserved⟩ :=
    DecimalSource.decimal_traced code lib.decimal lib.nu lib.nm lib.na lib.keep textValid
      (DecimalText.natural_window c.state n) (DecimalText.digits_valid n)
      (by change c.top+4*(digits n).length<capacity;omega)
  have magnitude : NatArena.Borrow num.state.nats numSlot n := by
    simpa only [DecimalText.digits_value] using numLive
  change num.top=c.top+1+4*(digits n).length at numTop
  have signedRoom : num.top<capacity := by rw [numTop];omega
  have signed : SourceCall Header.layout code 4 "smake" [.natObject numSlot,DecimalDigits.integer 0]
      num.state (endpoint numSlot n).source (next l num 0).state := by
    have actual := SignedCalls.smake_call (neg:=0) (input:=DecimalDigits.integer 0)
      code lib.smake lib.nz lib.nu lib.ne lib.keep numValid signedRoom magnitude
      (by decide +kernel) (by rfl)
    have zero : (if n==0 then 0 else 0)=0 := by split <;> rfl
    simpa only [zero,endpoint,Endpoint.source,SignedNegCalls.bit,Bool.false_eq_true,
      ite_false,PoolCursor.next] using actual
  have signedValid : Valid l (next l num 0) := next_valid 0 numValid signedRoom
  have denominatorStart : Valid l (textCursor (next l num 0) d) :=
    DecimalInitialized.input_valid signedValid _
  obtain ⟨den,denSlot,denCall,denLive,denValid,denBuffer,denTop,denHeap,denEnv,denSize,
      denOther,denTrace,denPreserved⟩ :=
    DecimalSource.decimal_traced code lib.decimal lib.nu lib.nm lib.na lib.keep denominatorStart
      (DecimalText.natural_window (next l num 0).state d) (DecimalText.digits_valid d)
      (by change num.top+1+4*(digits d).length<capacity;rw [numTop];omega)
  have denominator : NatArena.Borrow den.state.nats denSlot d := by
    simpa only [DecimalText.digits_value] using denLive
  have priorMagnitude : NatArena.Borrow (textCursor (next l num 0) d).state.nats numSlot n :=
    PoolCursor.preserves magnitude
  have magFinal : (endpoint numSlot n).Live den.state :=
    denPreserved numSlot n priorMagnitude
  have denTopExact : den.top=c.top+3+4*(digits n).length+4*(digits d).length := by
    change den.top=num.top+1+1+4*(digits d).length at denTop
    rw [numTop] at denTop
    omega
  have qmRoom : den.top+4<capacity := by rw [denTopExact];omega
  have rational := NumericRationalMakeRefinement.qm_math code lib.qm lib.nz lib.ng lib.nd
    lib.smake lib.nu lib.ne lib.keep (endpoint numSlot n) magFinal denominator positive denValid qmRoom
  obtain ⟨output,source,outputLive,mathematical,outputPositive⟩ :=
    NumericInputCompleteness.rational rational.2.1
  have rationalCall := rational.1
  rw [←source] at rationalCall
  have outValid : Valid l (RationalMakeCalls.c5 l den (endpoint numSlot n) d) :=
    (RationalMakeCalls.contexts (endpoint numSlot n) d denValid qmRoom).2.2.2.2
  have value : output.mathematical.value=(n:Rat)/(d:Rat) := by
    rw [mathematical,rational.2.2.2.2.1]
    simp [endpoint,Endpoint.mathematical,ScopedNumerical.Signed.value]
  exact ⟨⟨num,numSlot,numValid,magnitude,numCall,numTrace,numTop,signed,
    den,denSlot,denValid,denominator,magFinal,denCall,denTrace,denTopExact,
    output,rationalCall,outValid,outputLive,outputPositive,value⟩⟩

end ScopedC.RationalDecimalLiteral
