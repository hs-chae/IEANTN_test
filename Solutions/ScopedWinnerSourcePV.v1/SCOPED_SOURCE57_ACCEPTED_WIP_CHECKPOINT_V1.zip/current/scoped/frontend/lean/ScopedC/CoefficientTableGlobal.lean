/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CoefficientTableRead
import ScopedC.SourceCalls

namespace ScopedC.CoefficientTableRead
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

/-- The actual writable application array expression. The const-qualified
callee formal subsequently removes writability through the proved ABI cast. -/
theorem eval_global (service : Call) (fuel : Nat) {s : State} {base : Address}
    {coeffs : List Input} {name : String} (table : TableAt s base coeffs)
    (lookup : s.globals.lookup name=some base) (unshadowed : s.env.lookup name=none)
    (h0 : name≠"true") (h1 : name≠"false") (h2 : name≠"nullptr") (h3 : name≠"NULL") :
    evalExpr Header.layout service (fuel+1) s (.var name)=some (.pointer base true,s) := by
  simp [evalExpr,h0,h1,h2,h3,getVar,unshadowed,lookup,table.memory,table.emptyFields]

end ScopedC.CoefficientTableRead
