/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceUnsignedAssignment
import ScopedC.UnsignedLiteralControl
import ScopedC.RationalUnsignedTrace
import ScopedC.CoefficientScalarFrames

namespace ScopedC.PrepareSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.PoolCalls ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

def parameters (c : Cursor) (d : Nat) : Cursor := CursorSingleFrames.framed c "unsigned int" "d" (word d)

def afterDepth (c : Cursor) (d object : Nat) : Cursor :=
  LocalAssignment.cursor (parameters c d) object "unsigned" (word d)

theorem parameters_valid {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (d : Nat) :
    Valid l (parameters c d) := OneFrames.context_frame ctx "unsigned int" "d" (word d)

theorem bind_parameters (c : Cursor) (d : Nat) (argument : Value)
    (convert : castValue Header.layout {c.state with env:=[]} 100 "unsigned int" argument=some (word d)) :
    bindArgs Header.layout Generated.f_prepare.parameters [argument] c.state=some (parameters c d).state :=
  TypedFrames.bind_one Header.layout c.state "unsigned int" "d" argument (word d) convert

theorem d_binding (c : Cursor) (d : Nat) :
    LocalBinding.At (parameters c d).state "d" "unsigned int" (word d) c.state.heap.length :=
  LocalBinding.allocate_head {c.state with env:=[]} "d" "unsigned int" (word d) (by rfl)

theorem parameters_depth {c : Cursor} (d : Nat) {object old : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object old) :
    SourceUnsignedGlobal.At (parameters c d).state "depth" object old :=
  SourceUnsignedGlobal.allocated (SourceUnsignedGlobal.memory (t:={c.state with env:=[]}) depth rfl rfl)
    "unsigned int" "d" _

theorem depth_unshadowed (c : Cursor) (d : Nat) :
    (parameters c d).state.env.lookup "depth"=none := rfl

theorem unsigned_gt (s : State) (n k : Nat) (hn : n<2^32) (hk : k<2^32) :
    binaryValue Header.layout s ">" (unsigned32 n) (unsigned32 k)=
      some (boolean Header.layout (decide (k<n))) := by
  simp [binaryValue,unsigned32,Scalar.binary,Scalar.common,Scalar.promote,scalar_u32_cast n hn,
    scalar_u32_cast k hk,Scalar.boolean,Scalar.truth,boolean,u32_range n hn,u32_range k hk]
    <;> split_ifs <;> (first | rfl | omega)

theorem guard_skip (service : Call) (c : Cursor) (d : Nat) (bound : d ≤ 64) :
    Run Header.layout service (.branch (.binary ">" (.var "d") (.nat 64))
      (.eval (.call (.var "fail") [])) .skip) (parameters c d).state
      (.continuing (parameters c d).state) := by
  have compared : binaryValue Header.layout (parameters c d).state ">" (word d) (DecimalDigits.integer 64)=
      some (boolean Header.layout (decide (64<d))) := by
    change binaryValue Header.layout (parameters c d).state ">" (unsigned32 d) (DecimalDigits.integer 64)=_
    rw[UnsignedLiteralControl.literal_lift _ ">" d 64 (by omega) (by decide +kernel)]
    exact unsigned_gt _ _ _ (by omega) (by decide +kernel)
  have tested : Eval Header.layout service (.binary ">" (.var "d") (.nat 64)) (parameters c d).state
      (parameters c d).state (boolean Header.layout (decide (64<d))) :=
    ⟨3,ExpressionTemplates.binary Header.layout service (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel)
      (LocalBinding.eval service 1 (d_binding c d) (by decide +kernel) (by decide +kernel)
        (by decide +kernel) (by decide +kernel)) (by rfl) compared⟩
  apply Loops.StmtRun.branch tested
  simp only[UnsignedLiteralControl.truth_boolean,not_lt.mpr bound,decide_false,Bool.false_eq_true,↓reduceIte]
  exact Loops.StmtRun.skip _

theorem depth_assignment (service : Call) (c : Cursor) (d : Nat) {object old : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object old) (bound : d ≤ 64) :
    Eval Header.layout service (.binary "=" (.var "depth") (.var "d")) (parameters c d).state
      (afterDepth c d object).state (word d) :=
  ⟨3,SourceUnsignedGlobal.source_assignment service 1 (parameters_depth d depth) (depth_unshadowed c d)
    (by omega) (LocalBinding.eval service 1 (d_binding c d) (by decide +kernel) (by decide +kernel)
      (by decide +kernel) (by decide +kernel))⟩

theorem afterDepth_valid {l : PoolLayout} {c : Cursor} (ctx : Valid l c) (d object : Nat)
    (apart : object≠l.pool ∧ object≠l.top ∧ object≠l.high) : Valid l (afterDepth c d object) :=
  LocalAssignment.valid (parameters_valid ctx d) object "unsigned" (word d) apart.1 apart.2.1 apart.2.2

theorem afterDepth_at {c : Cursor} (d : Nat) {object old : Nat}
    (depth : SourceUnsignedGlobal.At c.state "depth" object old) :
    SourceUnsignedGlobal.At (afterDepth c d object).state "depth" object d :=
  SourceUnsignedGlobal.assigned_at (parameters_depth d depth) d

end ScopedC.PrepareSource
