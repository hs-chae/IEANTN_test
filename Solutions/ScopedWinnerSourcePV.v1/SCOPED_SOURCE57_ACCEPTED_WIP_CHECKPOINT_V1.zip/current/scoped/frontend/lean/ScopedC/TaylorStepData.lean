/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorFrame
import ScopedC.RationalPointBody

namespace ScopedC.TaylorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def pointInput {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : Pair := ⟨coeffs[f.k],coeffs[f.k]⟩
def product {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : Pair := IntervalProductApplicability.output l f.cursor f.result f.a
@[irreducible] def productCursor {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : Cursor := IntervalProductApplicability.next l f.cursor f.result f.a

theorem point_positive {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : (pointInput f hk).Positive :=
  ⟨f.table.positive f.k hk,f.table.positive f.k hk⟩
theorem point_live {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : (pointInput f hk).Live (productCursor f).state := by
  unfold productCursor
  exact IntervalProductApplicability.preserves_pair f.result f.a ⟨f.table.live f.k hk,f.table.live f.k hk⟩
theorem product_live {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : (product f).Live (productCursor f).state := by
  unfold productCursor
  exact IntervalProductApplicability.live l f.cursor f.result f.a
theorem product_positive {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : (product f).Positive :=
  IntervalProductApplicability.positive l f.cursor f.result f.a f.rPositive f.aPositive
theorem product_order {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : (product f).lo.mathematical.value ≤ (product f).hi.mathematical.value :=
  IntervalProductApplicability.order l f.cursor f.result f.a f.rPositive f.aPositive
theorem product_context {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (room : f.cursor.top+107<PoolCalls.capacity) : Valid l (productCursor f) := by
  unfold productCursor
  exact IntervalProductApplicability.context f.context (by omega) f.result f.a
theorem product_top {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) : (productCursor f).top=f.cursor.top+80 := by
  unfold productCursor
  exact IntervalProductApplicability.top l f.cursor f.result f.a

/-- Proof-only physical view of the source radd result. It is derived from
the actual source decoder, never supplied as an executable output oracle. -/
noncomputable def sum {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : Pair :=
  IntervalAddApplicability.output l (productCursor f) (pointInput f hk) (product f)
    (point_positive f hk) (product_positive f) (le_refl _) (product_order f)
@[irreducible] def sumCursor {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : Cursor :=
  RationalIntervalAddCalls.after l (productCursor f) (pointInput f hk) (product f)

theorem sum_source {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) :
    (sum f hk).source=RationalIntervalAddCalls.result l (productCursor f) (pointInput f hk) (product f) :=
  (IntervalAddApplicability.output_spec l (productCursor f) (pointInput f hk) (product f)
    (point_positive f hk) (product_positive f) (le_refl _) (product_order f)).1
theorem sum_live {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : (sum f hk).Live (sumCursor f hk).state := by
  unfold sumCursor
  exact (IntervalAddApplicability.output_spec l (productCursor f) (pointInput f hk) (product f)
    (point_positive f hk) (product_positive f) (le_refl _) (product_order f)).2.1
theorem sum_positive {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : (sum f hk).Positive :=
  (IntervalAddApplicability.output_spec l (productCursor f) (pointInput f hk) (product f)
    (point_positive f hk) (product_positive f) (le_refl _) (product_order f)).2.2.1
theorem sum_order {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : (sum f hk).lo.mathematical.value ≤ (sum f hk).hi.mathematical.value :=
  IntervalAddApplicability.output_order l (productCursor f) (pointInput f hk) (product f)
    (point_positive f hk) (product_positive f) (le_refl _) (product_order f)
theorem sum_context {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (room : f.cursor.top+107<PoolCalls.capacity) : Valid l (sumCursor f hk) := by
  unfold sumCursor
  exact RationalIntervalAddCalls.after_valid (product_context f room) (by rw[product_top];omega) (pointInput f hk) (product f)
theorem sum_top {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) : (sumCursor f hk).top=f.cursor.top+108 := by
  unfold sumCursor
  rw[RationalIntervalAddCalls.after_top,product_top]

end ScopedC.TaylorCalls
