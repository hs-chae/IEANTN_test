/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalPowerFrame
import ScopedC.CursorSingleFrames

namespace ScopedC.RationalPowerCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000

theorem initial_heap_length (l : PoolCalls.PoolLayout) (c : Cursor) (a : Input) (n : Nat) :
    (loopStart l c a n).state.heap.length=c.state.heap.length+3 := by
  simp only[loopStart,CursorLocals.allocated,allocate,List.length_append,List.length_singleton]
  rw[oneCursor,(CursorEffects.shape l (parameters c a n) [1,0,1]).1,parameters_length]

theorem initial_globals (l : PoolCalls.PoolLayout) (c : Cursor) (a : Input) (n : Nat) :
    (loopStart l c a n).state.globals=c.state.globals := by
  change (oneCursor l (parameters c a n)).state.globals=_
  rw[oneCursor,CursorSingleFrames.advance_globals]
  rfl

theorem initial_borrow (l : PoolCalls.PoolLayout) (c : Cursor) (a : Input) (n : Nat) {slot value : Nat}
    (live : NatArena.Borrow c.state.nats slot value) : NatArena.Borrow (loopStart l c a n).state.nats slot value :=
  CursorBorrow.preserves (l:=l) (c:=parameters c a n) [1,0,1] live

theorem initial_other (l : PoolCalls.PoolLayout) (c : Cursor) (a : Input) (n slot : Nat)
    (bound : slot < c.state.heap.length) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (loopStart l c a n).state.heap[slot]?=c.state.heap[slot]? := by
  change ((oneCursor l (parameters c a n)).state.heap++[_])[slot]?=_
  rw[List.getElem?_append_left (by rw[oneCursor,(CursorEffects.shape l (parameters c a n) [1,0,1]).1,parameters_length];omega)]
  rw[oneCursor,CursorSingleFrames.advance_other l _ _ slot hp ht hh]
  simp [parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.getElem?_append_left bound]

theorem initial_lookups (l : PoolCalls.PoolLayout) (c : Cursor) (a : Input) (n : Nat) :
    (loopStart l c a n).state.env.lookup "a"=some ⟨c.state.heap.length,0,[]⟩ ∧
    (loopStart l c a n).state.env.lookup "n"=some ⟨c.state.heap.length+1,0,[]⟩ ∧
    (loopStart l c a n).state.env.lookup "result"=some ⟨c.state.heap.length+2,0,[]⟩ := by
  constructor
  · simp only[loopStart,CursorLocals.allocated,allocate,List.lookup]
    rw[oneCursor,(CursorEffects.shape l (parameters c a n) [1,0,1]).2]
    simp [parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.lookup]
  constructor
  · simp only[loopStart,CursorLocals.allocated,allocate,List.lookup]
    rw[oneCursor,(CursorEffects.shape l (parameters c a n) [1,0,1]).2]
    simp [parameters,CursorFrames.framed,TwoFrames.frame,allocate,List.lookup]
  · simp only[loopStart,CursorLocals.allocated,allocate,List.lookup]
    rw[oneCursor,(CursorEffects.shape l (parameters c a n) [1,0,1]).1,parameters_length]
    simp

theorem initial_slots {l : PoolCalls.PoolLayout} (c : Cursor) (a : Input) (n : Nat) (f : Frame l)
    (fc : f.cursor=loopStart l c a n) :
    f.aSlot=c.state.heap.length ∧ f.nSlot=c.state.heap.length+1 ∧ f.rSlot=c.state.heap.length+2 := by
  have actual:=initial_lookups l c a n
  have la:=f.aAt.lookup
  have ln:=f.nAt.lookup
  have lr:=f.rAt.lookup
  rw[fc] at la ln lr
  exact ⟨congrArg Address.object (Option.some.inj (la.symm.trans actual.1)),
    congrArg Address.object (Option.some.inj (ln.symm.trans actual.2.1)),
    congrArg Address.object (Option.some.inj (lr.symm.trans actual.2.2))⟩

end ScopedC.RationalPowerCalls
