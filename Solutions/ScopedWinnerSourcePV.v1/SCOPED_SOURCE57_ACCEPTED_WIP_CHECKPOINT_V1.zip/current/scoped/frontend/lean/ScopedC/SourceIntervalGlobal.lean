/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceScalarGlobal
import ScopedC.IntervalScopeFraming

namespace ScopedC.SourceIntervalGlobal
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.RationalIntervalFrames (Pair)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def stored (c : Cursor) (object : Nat) (p : Pair) : Cursor :=
  LocalAssignment.cursor c object "RI" p.source

theorem lvalue (service : Call) (fuel : Nat) {s : State} {name : String} {object : Nat}
    {old : Option Value} (h : SourceScalarGlobal.At s name "RI" object old)
    (unshadowed : s.env.lookup name=none) :
    evalLValue Header.layout service (fuel+1) s (.var name)=some (⟨object,0,[]⟩,true,s) := by
  simp [evalLValue,getVar,unshadowed,h.lookup,h.storage]

theorem write_global {s : State} {name : String} {object : Nat} {old : Option Value}
    (h : SourceScalarGlobal.At s name "RI" object old) (p : Pair) (live : p.Live s) :
    write Header.layout s ⟨object,0,[]⟩ true p.source=
      some (p.source,LocalAssignment.changed s object "RI" p.source) := by
  have cast:=Pair.cast (s:=s) (a:=p) live "RI" (by decide +kernel)
  simp [write,addressType,typeAt,h.storage,cast,LocalAssignment.changed,PoolCalls.storeObject]

theorem source_assignment (service : Call) (fuel : Nat) {s middle : State} {name : String}
    {object : Nat} {old : Option Value} {rhs : Expr}
    (h : SourceScalarGlobal.At middle name "RI" object old) (unshadowed : middle.env.lookup name=none)
    (p : Pair) (live : p.Live middle)
    (right : evalExpr Header.layout service (fuel+1) s rhs=some (p.source,middle)) :
    evalExpr Header.layout service (fuel+2) s (.binary "=" (.var name) rhs)=
      some (p.source,LocalAssignment.changed middle object "RI" p.source) := by
  rw[evalExpr,right]
  simp only[Bind.bind,Option.bind]
  rw[lvalue service fuel h unshadowed]
  exact write_global h p live

theorem stored_at {c : Cursor} {name : String} {object : Nat} {old : Option Value}
    (h : SourceScalarGlobal.At c.state name "RI" object old) (p : Pair) :
    SourceScalarGlobal.At (stored c object p).state name "RI" object (some p.source) :=
  ⟨h.lookup,List.getElem?_set_self (List.getElem?_eq_some_iff.mp h.storage).choose⟩

end ScopedC.SourceIntervalGlobal
