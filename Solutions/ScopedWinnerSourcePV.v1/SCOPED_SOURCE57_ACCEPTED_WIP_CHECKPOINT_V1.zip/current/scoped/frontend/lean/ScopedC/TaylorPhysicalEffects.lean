/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.TaylorLoop
import ScopedC.RationalIntervalMultiplyEffects
import ScopedC.RationalIntervalAddFraming

namespace ScopedC.TaylorCalls
open ScopedC.Machine ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem sum_borrow {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) {slot value : Nat}
    (live : NatArena.Borrow f.cursor.state.nats slot value) :
    NatArena.Borrow (sumCursor f hk).state.nats slot value := by
  have first : NatArena.Borrow (productCursor f).state.nats slot value := by
    unfold productCursor IntervalProductApplicability.next
    exact RationalIntervalMultiplyCalls.preserves_nat f.result f.a live
  unfold sumCursor
  exact RationalIntervalAddCalls.preserves_nat (pointInput f hk) (product f) first

theorem sum_globals {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) :
    (sumCursor f hk).state.globals=f.cursor.state.globals := by
  unfold sumCursor
  rw[RationalIntervalAddCalls.after_globals]
  unfold productCursor IntervalProductApplicability.next
  exact RationalIntervalMultiplyCalls.after_globals l f.cursor f.result f.a

theorem sum_other {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (hk : f.k<coeffs.length) (slot : Nat)
    (bound : slot<f.cursor.state.heap.length)
    (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (sumCursor f hk).state.heap[slot]?=f.cursor.state.heap[slot]? := by
  have productBound : slot<(productCursor f).state.heap.length := by
    unfold productCursor
    rw[(IntervalProductApplicability.shape l f.cursor f.result f.a).1]
    exact bound
  unfold sumCursor
  rw[RationalIntervalAddCalls.after_other l (productCursor f) (pointInput f hk)
    (product f) slot productBound hp ht hh]
  unfold productCursor IntervalProductApplicability.next
  exact RationalIntervalMultiplyCalls.after_other l f.cursor f.result f.a slot bound hp ht hh

theorem iteration_borrow {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k)
    (room : f.cursor.top+107<PoolCalls.capacity) {slot value : Nat}
    (live : NatArena.Borrow f.cursor.state.nats slot value) :
    NatArena.Borrow (iteration f positive room).cursor.state.nats slot value :=
  sum_borrow (decremented f) (decrement_index f positive) live

theorem iteration_globals {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k)
    (room : f.cursor.top+107<PoolCalls.capacity) :
    (iteration f positive room).cursor.state.globals=f.cursor.state.globals :=
  sum_globals (decremented f) (decrement_index f positive)

theorem iteration_slots {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k)
    (room : f.cursor.top+107<PoolCalls.capacity) :
    (iteration f positive room).kSlot=f.kSlot ∧
      (iteration f positive room).rSlot=f.rSlot := ⟨rfl,rfl⟩

theorem iteration_other {l : PoolCalls.PoolLayout} {base : Address} {coeffs : List Input}
    (f : Frame l base coeffs) (positive : 0<f.k)
    (room : f.cursor.top+107<PoolCalls.capacity) (slot : Nat)
    (bound : slot<f.cursor.state.heap.length) (kApart : slot≠f.kSlot)
    (rApart : slot≠f.rSlot) (hp : slot≠l.pool) (ht : slot≠l.top) (hh : slot≠l.high) :
    (iteration f positive room).cursor.state.heap[slot]?=f.cursor.state.heap[slot]? := by
  change ((sumCursor (decremented f) (decrement_index f positive)).state.heap.set
    f.rSlot _)[slot]?=_
  rw[List.getElem?_set_ne (Ne.symm rApart)]
  have after:=sum_other (decremented f) (decrement_index f positive) slot
    (by rw[(decremented_shape f).1];exact bound) hp ht hh
  change (sumCursor (decremented f) (decrement_index f positive)).state.heap[slot]?=_
  rw[after]
  change (f.cursor.state.heap.set f.kSlot _)[slot]?=_
  exact List.getElem?_set_ne (Ne.symm kApart)

end ScopedC.TaylorCalls
