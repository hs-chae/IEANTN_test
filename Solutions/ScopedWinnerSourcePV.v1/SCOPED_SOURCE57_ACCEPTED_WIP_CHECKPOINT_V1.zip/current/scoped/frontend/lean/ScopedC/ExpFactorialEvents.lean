/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ExpFactorialSource
import ScopedC.CallEventTimeline

namespace ScopedC.ExpFactorial
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 150000
set_option maxRecDepth 100000

abbrev Event (code : List Function) := CallEvents.Event Header.layout code 6
abbrev EventAnswers {code : List Function} (service : Call) (events : List (Event code)) : Prop :=
  ∀e∈events,service e.name e.args e.before=some (e.value,e.after)

def qiEvent (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) : Event code :=
  ⟨"qi",[PoolCalls.word f.k],f.cursor.state,(counterInput f).source,(afterQi f).state,
    qi_call code lib f room⟩

def qtEvent (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) : Event code :=
  ⟨"qt",[f.fact.source,(counterInput f).source],(afterQi f).state,(product f).source,
    (productCursor f).state,qt_call code lib f room⟩

def events (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) : List (Event code) :=
  [qiEvent code lib f room,qtEvent code lib f room]

theorem events_unique (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (room : f.cursor.top+13<PoolCalls.capacity) :
    ((events code lib f room).map CallEvents.timeKey).Nodup := by
  change [f.cursor.state.nats.values.length,(afterQi f).state.nats.values.length].Nodup
  have size : (afterQi f).state.nats.values.length=f.cursor.state.nats.values.length+3 := by
    change (CursorFrames.advance l f.cursor [f.k,0,1]).state.nats.values.length=_
    rw[CursorEffects.size]
    rfl
  rw[size]
  rw[List.nodup_cons]
  refine ⟨?_,by simp⟩
  simp only[List.mem_singleton]
  omega

theorem events_bounds (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity)
    (e : Event code) (member : e∈events code lib f room) :
    f.cursor.state.nats.values.length≤e.before.nats.values.length ∧
      e.before.nats.values.length<(stepped f active room).cursor.state.nats.values.length := by
  have finish:=stepped_size f active room
  have size : (afterQi f).state.nats.values.length=f.cursor.state.nats.values.length+3 := by
    change (CursorFrames.advance l f.cursor [f.k,0,1]).state.nats.values.length=_
    rw[CursorEffects.size]
    rfl
  rcases (show e=qiEvent code lib f room ∨ e=qtEvent code lib f room from by
    simpa only[events,List.mem_cons,List.mem_singleton,List.not_mem_nil,or_false] using member) with rfl|rfl
  · change f.cursor.state.nats.values.length≤f.cursor.state.nats.values.length ∧
      f.cursor.state.nats.values.length<(stepped f active room).cursor.state.nats.values.length
    omega
  · change f.cursor.state.nats.values.length≤(afterQi f).state.nats.values.length ∧
      (afterQi f).state.nats.values.length<(stepped f active room).cursor.state.nats.values.length
    omega

theorem event_run (code : List Function) (lib : RationalPowerCalls.Library code)
    {l : PoolCalls.PoolLayout} {object d : Nat} (f : Frame l object d)
    (active : f.k≤d+1) (room : f.cursor.top+13<PoolCalls.capacity)
    (service : Call) (answers : EventAnswers service (events code lib f room)) :
    Run Header.layout service loopBody f.cursor.state (.continuing (stepped f active room).cursor.state) :=
  stepped_run service f active room ⟨answers _ List.mem_cons_self,
    answers _ (List.mem_cons_of_mem _ List.mem_cons_self)⟩

end ScopedC.ExpFactorial
