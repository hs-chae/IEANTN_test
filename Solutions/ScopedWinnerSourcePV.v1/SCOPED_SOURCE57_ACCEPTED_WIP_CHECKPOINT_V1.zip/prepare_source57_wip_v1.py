"""Freeze only indexed accepted source57 components; never a fresh57 proof claim."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

R = Path(__file__).resolve().parents[2]

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    out = R / 'scoped/SCOPED_SOURCE57_ACCEPTED_WIP_CHECKPOINT_V1.zip'
    need(not out.exists(), 'immutable new source57 checkpoint')
    files = {}
    def add(path, target):
        p = R / path
        need(p.is_file() and not p.is_symlink(), 'actual regular input: ' + str(path))
        data = p.read_bytes()
        need(target not in files or files[target] == data, 'unique archive input: ' + target)
        files[target] = data
    numeric = Path('scoped/frontend/proof/SOURCE_HELPER_SUPPORT_INDEX_V42.json')
    named = Path('scoped/frontend/proof/NAMED_CONSTRUCTOR_PROGRESS_RESUME_V4.json')
    n, d = [json.loads((R / p).read_text()) for p in [numeric, named]]
    need(len(n['files']) == 356 and len(n['concrete_functions']) == 30
         and len(d['modules']) == 24 and d['whole_named_body_complete'] is True,
         'exact frozen356 numerical modules/24 named modules')
    modules, receipts, roots = {}, set(), {}
    for row in n['files'] + d['modules']:
        source, receipt = Path(row['source']), Path(row['receipt'])
        need(sha(R / source) == row['source_sha256'] and sha(R / receipt) == row['receipt_sha256'],
             'accepted source/receipt identity: ' + row['module'])
        record = json.loads((R / receipt).read_text())
        need(record['status'] == 'PASS_HOST_DEVELOPMENT_COMPILE' and record['exit_code'] == 0
             and record['source_unchanged'] is True and bool(record['audit']), 'actual accepted compile')
        for audit in record['audit']:
            need(set(audit['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}, 'full standard closure')
            roots[audit['name']] = audit['axioms']
        need(row['module'] not in modules or modules[row['module']] == row['source_sha256'], 'source module identity')
        modules[row['module']] = row['source_sha256']
        add(source, 'current/' + str(source))
        add(receipt, 'current/' + str(receipt))
        receipts.add(str(receipt))
        for rel in re.findall(r'include_(?:str|bytes)\s+"([^"\n]+)"', (R / source).read_text()):
            p = (R / source.parent / rel).resolve()
            need(p.is_relative_to(R), 'experiment-owned source payload')
            add(p.relative_to(R), 'current/' + str(p.relative_to(R)))
    for p in [numeric, named,
              Path('scoped/evaluate-source-v1/CURRENT_CONTROLS_BODY_AND_MATH_INDEX_V12.json'),
              Path('scoped/evaluate-source-v1/current_controls_index_v12.py'),
              Path('scoped/evaluate-source-v1/CURRENT57_INVENTORY_OPTIMIZATION_CONTROLS_V1.json'),
              Path('scoped/evaluate-source-v1/CURRENT_CONTROLS_BODY_AND_MATH_INDEX_V10.json'),
              Path('scoped/audit/CONSTRUCTOR_BODY_PROGRESS_V3.json'),
              Path('scoped/build/current52-source-cold-resume-v2/verification/RECEIPT.json'),
              Path('scoped/build/CURRENT52_SOURCE_COLD_FINAL_READBACK_V2.json'),
              Path('scoped/build/CURRENT52_POSTREPLAY_QUALIFICATION_ERRATUM_V1.json')]:
        add(p, 'current/' + str(p))
    # Fixed inherited syntax/source variants are provenance, not newly accepted bodies.
    for name in ['Generated.lean', 'GeneratedAll.lean', 'Header.lean', 'Grammar.lean', 'Restricted.lean', 'Machine.lean']:
        p = Path('scoped/frontend/lean/ScopedC') / name
        add(p, 'current/' + str(p))
    variants = []
    for p in [Path('scoped/frontend/generated-epoch2/scoped_eval_verified.cpp'),
              Path('scoped/frontend/generated-epoch2/height_input.inc'),
              Path('scoped/frontend/canonical-fast-v1/scoped_all_verified.cpp'),
              Path('scoped/frontend/canonical-fast-v1/all50_input.inc'),
              Path('scoped/frontend/canonical-fast-v1/header.inc'),
              Path('scoped/source-bundle/source/function_67_main.inc')]:
        add(p, 'current/' + str(p))
        variants.append(dict(path=str(p), bytes=(R / p).stat().st_size, sha256=sha(R / p)))
    for p in sorted((R / 'scoped/frontend/generated-epoch2').glob('*.cpp.inc')):
        add(p.relative_to(R), 'current/' + str(p.relative_to(R)))
    base = Path('scoped/body52-supplement-v1/SCOPED_CURRENT52_SOURCE_COMPONENTS_V1.zip')
    add(base, 'historical-fixed52-source-input.zip')
    add(Path(__file__).relative_to(R), 'prepare_source57_wip_v1.py')
    files['SOURCE_VARIANTS.json'] = (json.dumps(dict(
        status='PRESERVED_DISTINCT_MAIN_VARIANTS_NOT_ACCEPTED_MAIN_EXECUTION', sources=variants,
        shared_functions='Original first67 function bodies are shared; main is distinct.',
        four_height='Generated.functions/old SourceBinding: prepare24/four heightRows.',
        original_full_experiment='GeneratedAll/FastAssembly/canonical-fast/source-bundle main:52allRows/allDepths; required for39comparators and8192/16384 experiment.',
        four_height_main_proved=False, original52_main_proved=False,
        full_original_experiment_source_PV_complete=False), indent=2) + '\n').encode()
    files['README.md'] = b'''# Accepted source57 work-in-progress checkpoint

This freezes27 controls plus30 numerical whole-function body contracts from68
actual application functions. NumericsV42 contributes356 accepted modules and
NamedV4 contributes24 distinct accepted modules. All380 source/receipt identities
and912 exact selected standard-axiom closures were checked. The old26 control
roots are also in the completed fixed52 replay (644modules/767roots).

This is an accepted development checkpoint, not fresh57 verification, namespace
isolation or completion of the original experiment. No application object or
unaccepted draft is included. No C algorithm, mathematical input,39 comparator
identity,8192/16384 cell count or analytic premise was changed.

The new named body handles both branches/every uint32 input, actual parsers,
qi/qv/qm, typed stores/scopes and fromRI. Its output equals the pre-existing
LeanCert MathConst interval rounded to-100, with real constant membership
actually consumed. Prepare and expPoint are also complete components. Each
theorem retains its explicit physical pool/borrow/range/capacity/scale and
coefficient applicability conditions. Generic pinned compiler/kernel/core
runtime/OS/ABI/hardware contracts remain disclosed, not proved compilers.

current/ mirrors only explicit accepted index sources, actual receipts and
required payloads, plus fixed inherited syntax and C provenance. Receipts retain
commands, exact source/object hashes, mathematical statements and complete axiom
audits. The three authoritative indices are SOURCE_HELPER_SUPPORT_INDEX_V42,
NAMED_CONSTRUCTOR_PROGRESS_RESUME_V4 and CURRENT_CONTROLS_BODY_AND_MATH_INDEX_V12.
The inventory CLI has actually passed normal,-O,-OO modes with identical output
and rejected pre-existing outputs in every mode. After extracting, run:

    python3 -OO current/scoped/evaluate-source-v1/current_controls_index_v12.py \\
      --out /absolute/new/source57-inventory.json

This checks source/receipt identities, not new Lean proof compilation. The
embedded historical-fixed52-source-input.zip preserves the previous source-only
clean builder; its completed replay/erratum evidence remains under current/.
It must stay labeled52. Full source-cold/isolated57 and final original-program
reproduction are pending. Preserve receipts and accepted objects in the working
experiment; no accepted object or original source was deleted.

SOURCE_VARIANTS.json preserves two distinct mains. Generated/old SourceBinding
uses four heightRows at depth24. GeneratedAll/FastAssembly/canonical-fast and
source-bundle main use52allRows/allDepths, required for the original39-comparator
experiment. Neither main is proved here. Four-height closure cannot count as
full original-experiment closure. Remaining11 source functions are enumerated
in the exact inventory; final49 numerical leaves/output-to-ANT and full original
experiment source-first PV remain open. Kernel-only proofs are a separate tier.

Unaccepted NamedConcrete/SourceBinding drafts are excluded. Existing full
source-correspondence compilation exceeded8GiB. A separately accepted factored
renderer has three Std3 roots, but its lexical actual-source correspondence is
still pending and is outside this frozen checkpoint. Per-function generated
renderer certificates and all pinned C sources remain preserved. No full
source-binding completion or universally successful host I/O is asserted.

All these computations are deterministic; no random seed applies. Exact
parameters, source versions, commands, dependencies and statement evidence remain
in the source/receipts and prior clean builder. This partial checkpoint is not a
completed experiment or substitute for the pending clean end-to-end pipeline.
'''
    need(len(modules) == 380 and len(roots) == 912, 'exact accepted source/root checkpoint')
    manifest = dict(status='ACCEPTED_DEVELOPMENT57_NOT_FRESH57_OR_FULL_EXPERIMENT_PV',
        body_count=57, original_body_population=68, controls=27, numerics=30,
        indexed_current_sources=len(modules), indexed_receipts=len(receipts),
        selected_current_roots=len(roots), application_objects_included=[], drafts_included=[],
        fresh57_replay=False, namespace_isolated=False,
        numerics_index_sha256=sha(R / numeric), named_index_sha256=sha(R / named),
        files=[dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
               for name, data in sorted(files.items())])
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(files.items()):
            z.writestr(name, data)
        z.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(out) as z:
        need(z.testzip() is None and set(z.namelist()) == set(files) | {'MANIFEST.json'}, 'CRC/exact archive population')
        for row in manifest['files']:
            data = z.read(row['path'])
            need(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], 'member identity')
    receipt = dict(status='PASS_ACCEPTED_SOURCE57_WIP_CRC_ALLMEMBER_HASH_READBACK',
        path=str(out.relative_to(R)), bytes=out.stat().st_size, sha256=sha(out), members=len(files)+1,
        body_count=57, indexed_current_sources=380, selected_current_roots=912,
        fresh57_replay=False, namespace_isolated=False)
    out.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))

if __name__ == '__main__':
    main()
