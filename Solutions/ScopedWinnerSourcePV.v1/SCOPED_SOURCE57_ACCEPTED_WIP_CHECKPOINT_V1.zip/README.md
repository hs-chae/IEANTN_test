# Accepted source57 work-in-progress checkpoint

This freezes27 controls plus30 numerical whole-function body contracts from68
actual application functions. NumericsV42 contributes356 accepted modules and
NamedV4 contributes24 distinct accepted modules. All380 source/receipt identities
and912 exact selected standard-axiom closures were checked. The old26 control
roots are also in the completed fixed52 replay (644modules/767roots).

This is an accepted development checkpoint, not fresh57 verification, namespace
isolation or completion of the original experiment. No application object or
unaccepted draft is included. No C algorithm, mathematical input,39 comparator
identity,8192/16384 cell count or analytic premise was changed.

The new named body handles both branches/every uint32 input, actual parsers,
qi/qv/qm, typed stores/scopes and fromRI. Its output equals the pre-existing
LeanCert MathConst interval rounded to-100, with real constant membership
actually consumed. Prepare and expPoint are also complete components. Each
theorem retains its explicit physical pool/borrow/range/capacity/scale and
coefficient applicability conditions. Generic pinned compiler/kernel/core
runtime/OS/ABI/hardware contracts remain disclosed, not proved compilers.

current/ mirrors only explicit accepted index sources, actual receipts and
required payloads, plus fixed inherited syntax and C provenance. Receipts retain
commands, exact source/object hashes, mathematical statements and complete axiom
audits. The three authoritative indices are SOURCE_HELPER_SUPPORT_INDEX_V42,
NAMED_CONSTRUCTOR_PROGRESS_RESUME_V4 and CURRENT_CONTROLS_BODY_AND_MATH_INDEX_V12.
The inventory CLI has actually passed normal,-O,-OO modes with identical output
and rejected pre-existing outputs in every mode. After extracting, run:

    python3 -OO current/scoped/evaluate-source-v1/current_controls_index_v12.py \
      --out /absolute/new/source57-inventory.json

This checks source/receipt identities, not new Lean proof compilation. The
embedded historical-fixed52-source-input.zip preserves the previous source-only
clean builder; its completed replay/erratum evidence remains under current/.
It must stay labeled52. Full source-cold/isolated57 and final original-program
reproduction are pending. Preserve receipts and accepted objects in the working
experiment; no accepted object or original source was deleted.

SOURCE_VARIANTS.json preserves two distinct mains. Generated/old SourceBinding
uses four heightRows at depth24. GeneratedAll/FastAssembly/canonical-fast and
source-bundle main use52allRows/allDepths, required for the original39-comparator
experiment. Neither main is proved here. Four-height closure cannot count as
full original-experiment closure. Remaining11 source functions are enumerated
in the exact inventory; final49 numerical leaves/output-to-ANT and full original
experiment source-first PV remain open. Kernel-only proofs are a separate tier.

Unaccepted NamedConcrete/SourceBinding drafts are excluded. Existing full
source-correspondence compilation exceeded8GiB. A separately accepted factored
renderer has three Std3 roots, but its lexical actual-source correspondence is
still pending and is outside this frozen checkpoint. Per-function generated
renderer certificates and all pinned C sources remain preserved. No full
source-binding completion or universally successful host I/O is asserted.

All these computations are deterministic; no random seed applies. Exact
parameters, source versions, commands, dependencies and statement evidence remain
in the source/receipts and prior clean builder. This partial checkpoint is not a
completed experiment or substitute for the pending clean end-to-end pipeline.
