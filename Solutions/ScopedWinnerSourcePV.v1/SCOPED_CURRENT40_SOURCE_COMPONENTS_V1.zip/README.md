# Current40 actual-source helper and mathematical proof supplement

This source-only supplement freezes the current **40 of68 old C helper bodies**:21 controls-owned and19 numerics-owned. It contains480 application Lean sources,885 byte-exact include payloads,165 accepted individual host module receipts,373 selected source/body/math/init roots, and the preserved older343-source60-root cold receipt. The older387-source archive remains unchanged and does not contain the later complete floorQ/ceilQ work.

**This480-source snapshot has not received a fresh full source-cold replay. Whole-program source-first PV remains incomplete.** Original numerical/experimental outcomes are unchanged. The separate all51 numerical-leaf migration is kernel-only until the actual producer/source/output-to-ANT chain consumes it; this component does not relabel it PV.

The new complete actual-source helpers are:

- decimal: actual byte guards/loop/typed stores and exact decimal value, including the interior magnitude suffix of signed input.
- fromS: real scale100 global read, complete actual qm, typed S/Q values and both stack pops; its physical prepared scale/live/positive precondition remains explicit.
- floorQ: all nonnegative, negative integral and negative nonintegral C paths, including nr/nz tests, optional nu/na increment store, typed return and scopes; exact original floorDiv output.
- ceilQ: actual qn/floorQ/sn with exact original ceilDiv, typed return, scopes and allocation/liveness/frame applicability.

The snapshot additionally contains complete computed initialization of all66 old globals, actual evaluator Node/string reads, count/while guards and literal magnitude prefix, exact qt-to-floor/ceil compositions, and proved fromRI factor/scaled endpoint/initializer-expression stages. The complete fromRI statement/return assembly, iconst, remaining opcode/prepare/loop/I/O/main and actual source-linked numerical outputs consumed by the ANT theorem remain unfinished. Prefix proofs are not counted as completed helpers. The new ArrayLegacyLift component is deliberately separate.

## Clean proof reproduction

Install the exact pinned Lean toolchain and public libraries listed in `capsule-v1/SOURCE_LOCK.json`, including their commits, and build their generic objects. No application object bank is an allowed input. Then run:

```
python capsule-v1/prepare_environment.py --toolchain /path/to/lean-toolchain --mathlib /path/to/pinned/mathlib --out /tmp/current40-public-env.json
python capsule-v1/reproduce.py --environment /tmp/current40-public-env.json --out /tmp/current40-clean-replay --jobs 2
```

Use the approved resource guard. The reproducer rebuilds all480 actual application sources into a fresh object directory and checks every one of the373 complete selected theorem closures for only propext, Classical.choice and Quot.sound. It checks every source/include/runtime/compiler pin before and after execution, rejects sorry, and publishes a fresh receipt only after the entire run succeeds. No C executable run or namespace isolation is claimed by this recipe.

The source snapshot was prepared without launching another Lean process while the256GiB final-consumer and32GiB mathematical replay were active. A strict import-header parser removed nested comments/string contents and checked401 unchanged source rows against their previous actual compiler-discovered imports. The79 additional source headers were not separately queried by Lean. This discovery method is explicitly recorded; **the clean rebuild is the final acceptance gate**, and it has not been run for this480-source capsule.

`prepare_snapshot.py` regenerates the exact source/evidence inventory from the research checkout and validates current source/receipt hashes for all165 individual host modules. `make_capsule.py` ports only include_str path literals, copying payloads byte-for-byte. `package.py` preserves source/receipt identities and performs full archive membership/CRC/byte readback. `SOURCE_SUPPORT_INDEX_V1.json` distinguishes body counts from mathematical-bridge root counts: the numerics index names22 bridge roots, while the four new controls functions have exact mathematical outputs. These different populations are not added as a theorem count.

## Boundaries

The actual parsed helper body must be installed; caller Nat records, typed pool/memory, ranges and capacity must satisfy the proved physical applicability conditions. These are not assumed successful numerical outputs or assumed initialized application globals. Complete source/global initialization proofs are consumed where connected. Generic pinned Nat ABI/compiler/runtime and OS/hardware contracts remain disclosed external boundaries, including fixed execution-order applicability for the defined expression model. Unsupported operations fail closed.

Actual source-to-AST associations and raw source payloads are preserved through the existing infrastructure. Imported unused numerical native declarations are not selected acceptance roots. A source lock, earlier cold receipt, or independent numerical result is not a successful fresh replay or whole-program PV result.
