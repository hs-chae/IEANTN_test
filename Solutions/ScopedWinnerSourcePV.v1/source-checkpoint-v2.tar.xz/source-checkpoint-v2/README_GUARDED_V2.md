# Source bundle: current reproduction entrypoint

This component binds the actual 734-file C++ include bundle to its ordered typed source AST and all 52 exact input DAGs. Its five source/entry roots were freshly compiled from 142 application/backend sources using only public generic dependencies. The same fresh run compiled and executed the actual C++ bundle and checked every numerical output against its original bound.

The accepted full run is `scoped/build/source-bundle-fresh-v1/RECEIPT.json`: 1,760.70 seconds total, including a 1,320.40-second C++ execution. It used no prior application objects. This was a **host** source-cold replay, not a namespace-isolated run. It does not finish the 68 function-body proofs, native-fact migration, or mathematical consumer closure; those are separate gates.

From this directory, with the pinned Lean 4.34.0-rc2 installation and the pinned public Mathlib/dependency checkout already prepared, run:

```sh
python3 reproduce_guarded_v2.py \
  --toolchain /absolute/lean-4.34.0-rc2-linux \
  --mathlib /absolute/mathlib \
  --out /absolute/fresh-proof-and-c-run \
  --jobs 4 \
  --receipt /absolute/fresh-guarded-receipt.json
```

The wrapper checks the exact Lean version, all five shared runtime/kernel libraries, standard-library sentinels, Clang, Lean headers, and the 168 transitive platform headers used by the actual translation unit. It then executes the original immutable capsule recipe and repeats the runtime/header checks. The platform is the recorded Linux/GNU C++11 setup; a different platform requires a separately reviewed pin set, not a silent substitution. The generic compiler, preprocessor, runtime and physical platform remain explicit trust boundaries.

For a short prerequisite check, omit `--out` and use `--check-only`. This produces a **preflight-only** receipt and repeats no mathematical proof or numerical run. The actual normal, `-O`, and `-OO` prerequisite checks passed, and nine copied wrong-kernel/stdlib/header fixtures were rejected despite retaining identical thin `bin/lean` launcher bytes. See `scoped/build/source-bundle-runtime-guard-controls-v2/RECEIPT.json`.

The V1 capsule, source lock, full-run evidence, and original entrypoint remain unchanged. The V2 guarded full command is the current clean recipe; only its preflight/control portion has been rerun so far. The accepted V1 full replay must not be relabeled as a V2 full run.
