#!/usr/bin/env python3
"""Additive exact-kernel/runtime guard around immutable capsule-v1 recipe."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
B=Path(__file__).resolve().parent
PINS_SHA256='340609ad86ddd1f9914093333369a70ab12d7ba601ea2484e5f04ea0ad029ecd'
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(),parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def atomic(p,d):
 need(not p.exists(),'fresh receipt required');p.parent.mkdir(parents=True,exist_ok=True)
 temp=p.with_name(p.name+'.tmp');need(not temp.exists(),'stale temporary receipt')
 temp.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');os.replace(temp,p)
def verify(tool,pins):
 rows=[]
 for group,prefix in [('toolchain_files',tool),('platform_headers',None)]:
  for item in pins[group]:
   p=(prefix/item['path'])if prefix else Path(item['path'])
   need(p.is_file(),'missing runtime/header '+str(p))
   need(p.stat().st_size==item['bytes']and sha(p)==item['sha256'],'runtime/header hash mismatch '+str(p))
   rows.append({'group':group,'path':item['path'],'bytes':item['bytes'],'sha256':item['sha256']})
 q=subprocess.run([str(tool/'bin/lean'),'--version'],capture_output=True,text=True)
 need(q.returncode==0 and q.stdout.strip()==pins['lean_version'],'Lean kernel version mismatch')
 need(sha(B/'capsule-v1/SOURCE_LOCK.json')==pins['original_capsule_source_lock_sha256'],'immutable source lock mismatch')
 need(sha(B/'capsule-v1/reproduce.py')==pins['original_reproducer_sha256'],'immutable original recipe mismatch')
 return rows
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--toolchain',type=Path,required=True);ap.add_argument('--mathlib',type=Path);ap.add_argument('--out',type=Path);ap.add_argument('--jobs',type=int,choices=range(1,9),default=4);ap.add_argument('--receipt',type=Path,required=True);ap.add_argument('--check-only',action='store_true');a=ap.parse_args()
 need(not a.receipt.exists(),'fresh receipt required')
 need((a.out is None)if a.check_only else(a.out is not None and a.mathlib is not None),'check-only requires no --out; full reproduction requires --out and --mathlib')
 need(a.out is None or not a.out.exists(),'fresh reproduction output required')
 pinsPath=B/'RUNTIME_PINS_V2.json';need(sha(pinsPath)==PINS_SHA256,'runtime pin manifest changed');pins=load(pinsPath);need(pins['schema']=='SCOPED_SOURCE_BUNDLE_RUNTIME_PINS_V2','pin schema')
 tool=a.toolchain.resolve();start=time.monotonic();rows=verify(tool,pins);command=None;child=None
 if not a.check_only:
  command=[sys.executable,'-I','-B',str(B/'capsule-v1/reproduce.py'),'--toolchain',str(tool),'--mathlib',str(a.mathlib.resolve()),'--out',str(a.out.resolve()),'--jobs',str(a.jobs)]
  q=subprocess.run(command);need(q.returncode==0,'original full reproduction failed')
  childPath=a.out/'RECEIPT.json';child=load(childPath)
  need(child['status']=='PASS_FRESH_GENERIC_ONLY_SOURCE_PROOF_AND_ALL52_C_RUN','full child status')
  need(child['source_modules']==142 and child['source_files']==734 and len(child['actual_output_rows'])==52 and child['application_object_inputs']==[],'full child population')
  child={'path':str(childPath.resolve()),'sha256':sha(childPath),'status':child['status']}
 need(verify(tool,pins)==rows,'post-run runtime/header drift')
 atomic(a.receipt,{'schema':'SCOPED_SOURCE_BUNDLE_GUARDED_REPRODUCTION_V2','status':'PASS_RUNTIME_KERNEL_HEADER_PREFLIGHT_ONLY'if a.check_only else'PASS_GUARDED_FULL_SOURCE_COLD_AND_ALL52_C_REPRODUCTION','runtime_pins_sha256':PINS_SHA256,'guard_sha256':sha(Path(__file__)),'lean_version':pins['lean_version'],'checked_runtime_files':len(pins['toolchain_files']),'checked_platform_headers':len(pins['platform_headers']),'command':command,'full_child':child,'seconds':time.monotonic()-start,'qualification':'Additive guarded recipe; preflight-only does not repeat any Lean proof/C numerical execution. Full recipe remains HOST source-cold, not namespace isolation or full68 body correctness.'})
if __name__=='__main__':
 try:main()
 except Exception as e:print(type(e).__name__+': '+str(e),file=sys.stderr);raise SystemExit(1)
