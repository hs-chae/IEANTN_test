/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ScopedC.SourceBundle.Whole
import Lean

open Lean
/- Metadata export only. No theorem, axiom or acceptance bit is created by
 this IO command; the source-association validator checks its exact population
 against actual source files. Mathematical source bindings are separate proofs. -/
#eval IO.println ("BOUND_FILES_JSON " ++ (toJson
  (ScopedC.SourceBundle.Whole.actualFiles.map
    (fun f => Json.mkObj [("name",toJson f.name),("text",toJson f.text)]))).compress)
