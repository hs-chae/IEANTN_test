# Copyright (c) 2026 IEANTN contributors. All rights reserved.
# Released under Apache 2.0 license as described in the file LICENSE.
# Authors: OpenAI (Codex)
"""Fresh source-only include-bundle replay, using public generic libraries."""
import argparse,concurrent.futures,hashlib,json,os,re,subprocess,time
from pathlib import Path
from fractions import Fraction
B=Path(__file__).resolve().parent
STD3={'propext','Classical.choice','Quot.sound'}
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--toolchain',type=Path,required=True);ap.add_argument('--mathlib',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--jobs',type=int,default=4);ap.add_argument('--proof-only',action='store_true');a=ap.parse_args();need(1<=a.jobs<=8,'jobs1..8');need(not a.out.exists(),'fresh output required');a.out.mkdir(parents=True);out=a.out.resolve();objects=out/'objects';objects.mkdir();logs=out/'logs';logs.mkdir()
 lock=json.loads((B/'SOURCE_LOCK.json').read_text());tool=a.toolchain.resolve();compiler=tool/'bin/lean';need(sha(compiler)==lock['compiler_sha256'],'compiler pin');need(sha(B/'inputs.json')==lock['inputs_sha256'],'numerical input pin');generic=[]
 for d in lock['generic_dependency_pins']:
  root=a.mathlib.resolve()if d['name']=='mathlib'else a.mathlib.resolve()/'.lake/packages'/d['name'];q=subprocess.run(['git','-C',str(root),'rev-parse','HEAD'],capture_output=True,text=True,check=True);need(q.stdout.strip()==d['commit'],'generic dependency commit '+d['name']);lib=root/'.lake/build/lib/lean';need(lib.is_dir(),'public generic library missing '+d['name']);generic.append(str(lib))
 for row in lock['sources']:need(sha(B/row['path'])==row['sha256'],'proof source pin '+row['module'])
 for row in lock['c_sources']:
  p=B/row['path'];need(p.stat().st_size==row['bytes']and sha(p)==row['sha256'],'actual C source pin')
 env=os.environ.copy();env['LEAN_PATH']=':'.join([str(objects)]+generic);env['LEAN_NUM_THREADS']='1';records=[];start=time.monotonic()
 def execute(name,cmd):
  name=name.replace('/','_');so=logs/(name+'.stdout');se=logs/(name+'.stderr');tm=logs/(name+'.time');t=time.monotonic()
  with so.open('w')as f,se.open('w')as g:q=subprocess.run(['/usr/bin/time','-v','-o',str(tm)]+cmd,cwd=B,env=env,stdout=f,stderr=g)
  row=dict(name=name,command=cmd,exit_code=q.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(so),stderr_sha256=sha(se),time_sha256=sha(tm));need(q.returncode==0,'failed '+name);need("declaration uses 'sorry'"not in so.read_text()+se.read_text(),'admitted source '+name);return row
 def compile(row):
  obj=objects/Path(row['module'].replace('.','/')).with_suffix('.olean');obj.parent.mkdir(parents=True,exist_ok=True);r=execute(row['module'],[str(compiler),'-j1','-R',str(B/'lean'),str(B/row['path']),'-o',str(obj)]);r['object_sha256']=sha(obj);return r
 pending={r['module']:r for r in lock['sources']};done=set();running={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs)as ex:
  while pending or running:
   ready=[n for n,r in pending.items()if set(r['imports'])<=done]
   for n in ready[:a.jobs-len(running)]:running[ex.submit(compile,pending.pop(n))]=n
   need(bool(running),'dependency cycle/missing source')
   finished,_=concurrent.futures.wait(running,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in finished:
    n=running.pop(f);records.append(f.result());done.add(n);(out/'PROGRESS.json').write_text(json.dumps(dict(completed=len(done),total=len(lock['sources'])))+'\n')
 roots=['ScopedC.SourceBundle.Whole.'+x for x in ['bound','functions_exact','globals_exact','types_exact','entry_exact']]
 audit=out/'Audit.lean';audit.write_text('import ScopedC.SourceBundle.Whole\nimport Lean.Util.CollectAxioms\nopen Lean Elab\nset_option maxHeartbeats 0\nrun_elab do\n for n in (['+','.join('`'+n for n in roots)+'] : List Name) do\n  let ax ← Lean.collectAxioms n\n  logInfo m!"AUDIT_JSON {(Json.mkObj [("name",toJson n.toString),("axioms",toJson (ax.toList.map Name.toString))]).compress}"\n')
 records.append(execute('audit',[str(compiler),'-j1','-R',str(out),str(audit)]));rows=[json.loads(x.split('AUDIT_JSON ',1)[1])for x in(logs/'audit.stdout').read_text().splitlines()if'AUDIT_JSON 'in x];need([r['name']for r in rows]==roots,'exact audit population');need(all(set(r['axioms'])<=STD3 for r in rows),'nonstandard axiom')
 exp=[x.split('BOUND_FILES_JSON ',1)[1]for x in(logs/'ScopedC.SourceBundle.FileExport.stdout').read_text().splitlines()if x.startswith('BOUND_FILES_JSON ')];need(len(exp)==1,'file export');files=json.loads(exp[0]);need(len(files)==734 and len({x['name']for x in files})==734,'exact file734 population')
 expected={Path(x['path']).name for x in lock['c_sources']};need({x['name']for x in files}==expected,'file population')
 for row in files:need((B/'source'/row['name']).read_bytes()==row['text'].encode(),'compiled file text association')
 raw=[]
 if not a.proof_only:
  binary=out/'scoped_all';cmd=[str(tool/'bin/clang'),'-std=c++17','-O2','-I'+str(tool/'include'),'-isystem','/usr/include/c++/11','-isystem','/usr/include/x86_64-linux-gnu/c++/11','-isystem','/usr/lib/gcc/x86_64-linux-gnu/11/include',str(B/'source/scoped_all_bundle.cpp'),'-L'+str(tool/'lib/lean'),'-lleanshared','-Wl,-rpath,'+str(tool/'lib/lean'),'-o',str(binary)]
  records.append(execute('cpp_build',cmd));binary_hash=sha(binary);records.append(execute('cpp_run',[str(binary)]));need(sha(binary)==binary_hash,'executable drift')
  lines=(logs/'cpp_run.stdout').read_text().splitlines();inputs=json.loads((B/'inputs.json').read_text())['records'];need(len(lines)==len(inputs)==52,'actual output52')
  for line,rec in zip(lines,inputs):
   fs=line.split(',');need(len(fs)==5 and all(re.fullmatch(r'-?(0|[1-9][0-9]*)',x)for x in fs),'integer output shape');lo,le,hi,he,ok=map(int,fs);need(le==he==-100 and ok==1 and lo<=hi,'output domain');bound=Fraction(*map(int,rec['bound']));need(Fraction(hi,2**100)<=bound if rec['direction']=='upper'else bound<=Fraction(lo,2**100),'actual numerical bound');raw.append(dict(name=rec['name'],lo=str(lo),hi=str(hi),exponent=-100,domain=ok))
 for row in lock['sources']:need(sha(B/row['path'])==row['sha256'],'proof source drift')
 for row in lock['c_sources']:need(sha(B/row['path'])==row['sha256'],'C source drift')
 result=dict(status='PASS_FRESH_GENERIC_ONLY_SOURCE_PROOF_AND_ALL52_C_RUN'if not a.proof_only else'PASS_FRESH_GENERIC_ONLY_SOURCE_PROOF_RAW_RUN_NOT_REPEATED',source_lock_sha256=sha(B/'SOURCE_LOCK.json'),reproducer_sha256=sha(Path(__file__)),source_modules=len(lock['sources']),source_files=734,audits=rows,records=records,actual_output_rows=raw,elapsed_seconds=time.monotonic()-start,application_object_inputs=[],namespace_isolated=False,qualification='Host source-cold/actual C replay. Pinned compiler/preprocessor/Nat runtime trusted; full68 body correctness, original49/50 numerical Native migration and mathematical consumer remain separate.')
 temp=out/'RECEIPT.pending';temp.write_text(json.dumps(result,indent=2)+'\n');temp.replace(out/'RECEIPT.json');print(json.dumps({k:result[k]for k in ['status','source_modules','source_files','elapsed_seconds']}))
if __name__=='__main__':main()
