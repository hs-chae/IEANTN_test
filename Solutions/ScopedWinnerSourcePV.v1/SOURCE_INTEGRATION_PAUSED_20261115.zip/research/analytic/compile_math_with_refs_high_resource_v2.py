from pathlib import Path
import argparse,json,subprocess,hashlib,os,time,resource,signal,types
P=Path(__file__).resolve().parent;W=P.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--reference-objects',type=Path,action='append',default=[]);a.add_argument('--wall-seconds',type=int,default=2400);a.add_argument('--module',required=True);a.add_argument('--attempt',required=True);o=a.parse_args();env=json.loads((W/'ieantn-lcm-source-pv-20261112/adaptive/component-environment-controls-v1/adaptive-normal.json').read_text());src=P/'lean'/Path(*o.module.split('.')).with_suffix('.lean');out=P/'work'/o.attempt;out.mkdir(parents=True,exist_ok=False);objects=P/'objects';dest=out/'module.olean';before=sha(src);(out/'source.lean').write_bytes(src.read_bytes());e=dict(os.environ,LEAN_PATH=':'.join([str(objects)]+[str(r.resolve())for r in o.reference_objects]+[r['library']for r in env['generic_dependencies']]),LEAN_NUM_THREADS='1');cmd=['/usr/bin/time','-v',env['compiler'],'-j1','-R',str(P/'lean'),str(src),'-o',str(dest)];t=time.monotonic()
 proc=subprocess.Popen(cmd,env=e,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 timed_out=False
 try:
  stdout,stderr=proc.communicate(timeout=o.wall_seconds)
 except subprocess.TimeoutExpired:
  timed_out=True
  try:os.killpg(proc.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:stdout,stderr=proc.communicate(timeout=10)
  except subprocess.TimeoutExpired:
   try:os.killpg(proc.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   stdout,stderr=proc.communicate()
 q=types.SimpleNamespace(stdout=stdout,stderr=stderr,returncode=124 if timed_out else proc.returncode)
 (out/'stdout.txt').write_text(q.stdout);(out/'stderr.txt').write_text(q.stderr);rec={'module':o.module,'source_sha256':before,'source_unchanged':sha(src)==before,'exit_code':q.returncode,'seconds':time.monotonic()-t,'command':cmd,'tier':'ordinary Lean kernel proof; warm explicit application banks, not source-cold or source-firstPV','reference_objects':[str(r.resolve())for r in o.reference_objects],'resource_enforcement':'Outer resource_scope cgroup; no hidden64GiB virtual-memory cap; timeout drains owned compiler process group','timed_out':timed_out,'wall_seconds':o.wall_seconds,'builder_sha256':sha(Path(__file__))}
 if q.returncode==0 and rec['source_unchanged']:
  if 'sorryAx'in q.stdout or'Lean.ofReduceBool'in q.stdout:raise ValueError('unacceptedaxiom')
  target=objects/Path(*o.module.split('.')).with_suffix('.olean');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(dest.read_bytes());rec['object_sha256']=sha(dest)
 (out/'RECEIPT.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec));print(q.stdout[-4000:]);raise SystemExit(q.returncode)
if __name__=='__main__':main()
