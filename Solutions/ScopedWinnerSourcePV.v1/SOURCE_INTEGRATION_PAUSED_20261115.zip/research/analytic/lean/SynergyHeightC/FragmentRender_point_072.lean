import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt72 : renderStmt 999 FragmentData.pointStmt72=some "((values[127])=mul((values[126]),(values[58])));" := by decide +kernel
theorem render_pointStmt73 : renderStmt 999 FragmentData.pointStmt73=some "((values[128])=divI(unit(),(values[127])));" := by decide +kernel
theorem render_pointStmt74 : renderStmt 999 FragmentData.pointStmt74=some "((values[129])=mul((values[51]),(values[128])));" := by decide +kernel
theorem render_pointStmt75 : renderStmt 999 FragmentData.pointStmt75=some "((values[130])=mul((values[1]),(values[64])));" := by decide +kernel
theorem render_pointStmt76 : renderStmt 999 FragmentData.pointStmt76=some "((values[131])=mul((values[130]),(values[53])));" := by decide +kernel
theorem render_pointStmt77 : renderStmt 999 FragmentData.pointStmt77=some "((values[132])=mul((values[54]),(values[83])));" := by decide +kernel
theorem render_pointStmt78 : renderStmt 999 FragmentData.pointStmt78=some "((values[133])=add((values[52]),(values[131])));" := by decide +kernel
theorem render_pointStmt79 : renderStmt 999 FragmentData.pointStmt79=some "((values[134])=add((values[133]),(values[132])));" := by decide +kernel
#print axioms render_pointStmt72
#print axioms render_pointStmt73
#print axioms render_pointStmt74
#print axioms render_pointStmt75
#print axioms render_pointStmt76
#print axioms render_pointStmt77
#print axioms render_pointStmt78
#print axioms render_pointStmt79
end SynergyHeightC
