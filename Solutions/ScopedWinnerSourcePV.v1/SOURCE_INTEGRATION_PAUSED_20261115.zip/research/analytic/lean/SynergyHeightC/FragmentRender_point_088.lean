import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt88 : renderStmt 999 FragmentData.pointStmt88=some "((values[143])=add((values[0]),(values[142])));" := by decide +kernel
theorem render_pointStmt89 : renderStmt 999 FragmentData.pointStmt89=some "((values[144])=mul((values[129]),(values[129])));" := by decide +kernel
theorem render_pointStmt90 : renderStmt 999 FragmentData.pointStmt90=some "((values[145])=mul((values[143]),(values[144])));" := by decide +kernel
theorem render_pointStmt91 : renderStmt 999 FragmentData.pointStmt91=some "((values[146])=mul((values[145]),(values[139])));" := by decide +kernel
theorem render_pointStmt92 : renderStmt 999 FragmentData.pointStmt92=some "((values[147])=add((values[141]),(values[146])));" := by decide +kernel
theorem render_pointStmt93 : renderStmt 999 FragmentData.pointStmt93=some "((values[148])=add((values[0]),(values[47])));" := by decide +kernel
theorem render_pointStmt94 : renderStmt 999 FragmentData.pointStmt94=some "((values[149])=mul((values[127]),(values[127])));" := by decide +kernel
theorem render_pointStmt95 : renderStmt 999 FragmentData.pointStmt95=some "((values[150])=mul((values[148]),(values[149])));" := by decide +kernel
#print axioms render_pointStmt88
#print axioms render_pointStmt89
#print axioms render_pointStmt90
#print axioms render_pointStmt91
#print axioms render_pointStmt92
#print axioms render_pointStmt93
#print axioms render_pointStmt94
#print axioms render_pointStmt95
end SynergyHeightC
