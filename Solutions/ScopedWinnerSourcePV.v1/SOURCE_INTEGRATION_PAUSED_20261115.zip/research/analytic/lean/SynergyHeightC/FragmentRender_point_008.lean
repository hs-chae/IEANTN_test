import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt8 : renderStmt 999 FragmentData.pointStmt8=some "((values[63])=mul((values[61]),(values[62])));" := by decide +kernel
theorem render_pointStmt9 : renderStmt 999 FragmentData.pointStmt9=some "((values[64])=divI(unit(),(values[58])));" := by decide +kernel
theorem render_pointStmt10 : renderStmt 999 FragmentData.pointStmt10=some "((values[65])=mul((values[38]),(values[64])));" := by decide +kernel
theorem render_pointStmt11 : renderStmt 999 FragmentData.pointStmt11=some "((values[66])=add((values[0]),(values[65])));" := by decide +kernel
theorem render_pointStmt12 : renderStmt 999 FragmentData.pointStmt12=some "((values[67])=mul((values[66]),(values[66])));" := by decide +kernel
theorem render_pointStmt13 : renderStmt 999 FragmentData.pointStmt13=some "((values[68])=mul((values[38]),(values[41])));" := by decide +kernel
theorem render_pointStmt14 : renderStmt 999 FragmentData.pointStmt14=some "((values[69])=mul((values[68]),(values[64])));" := by decide +kernel
theorem render_pointStmt15 : renderStmt 999 FragmentData.pointStmt15=some "((values[70])=expPositiveRaw((values[69])));" := by decide +kernel
#print axioms render_pointStmt8
#print axioms render_pointStmt9
#print axioms render_pointStmt10
#print axioms render_pointStmt11
#print axioms render_pointStmt12
#print axioms render_pointStmt13
#print axioms render_pointStmt14
#print axioms render_pointStmt15
end SynergyHeightC
