/- Same C program, source-verified11function composition at endpoint768. -/
import SynergyHeightC.FullContractPointExecute
import SynergyAnalytic.HeightPointLogGridDefs
import SynergyHeightC.InitCacheProposal
namespace SynergyHeightC.FullContractPointPilot767
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def input : ProofBox := (SynergyAnalytic.HeightPoint.logCell 768).getD ⟨0,0⟩
theorem checked : FullContractPointExecute.checkedModel
 (InitCacheProposal.postState NatArena.empty) input=true := by decide +kernel
theorem source_outputs : ∃ c d, PointExecuteAPI.modelOutputs input=some (c,d) ∧
 PointExecuteAPI.SourcePointOutputs (InitCacheProposal.postState NatArena.empty) input c d :=
 FullContractPointExecute.source_outputs_of_checkedModel checked
#print axioms checked
#print axioms source_outputs
end SynergyHeightC.FullContractPointPilot767
