import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt40 : renderStmt 999 FragmentData.pointStmt40=some "((values[95])=mul((values[44]),(values[2])));" := by decide +kernel
theorem render_pointStmt41 : renderStmt 999 FragmentData.pointStmt41=some "((values[96])=divI(unit(),(values[95])));" := by decide +kernel
theorem render_pointStmt42 : renderStmt 999 FragmentData.pointStmt42=some "((values[97])=mul((values[94]),(values[96])));" := by decide +kernel
theorem render_pointStmt43 : renderStmt 999 FragmentData.pointStmt43=some "((values[98])=mul((values[85]),(values[25])));" := by decide +kernel
theorem render_pointStmt44 : renderStmt 999 FragmentData.pointStmt44=some "((values[99])=mul((values[45]),(values[2])));" := by decide +kernel
theorem render_pointStmt45 : renderStmt 999 FragmentData.pointStmt45=some "((values[100])=mul((values[99]),(values[27])));" := by decide +kernel
theorem render_pointStmt46 : renderStmt 999 FragmentData.pointStmt46=some "((values[101])=divI(unit(),(values[100])));" := by decide +kernel
theorem render_pointStmt47 : renderStmt 999 FragmentData.pointStmt47=some "((values[102])=mul((values[98]),(values[101])));" := by decide +kernel
#print axioms render_pointStmt40
#print axioms render_pointStmt41
#print axioms render_pointStmt42
#print axioms render_pointStmt43
#print axioms render_pointStmt44
#print axioms render_pointStmt45
#print axioms render_pointStmt46
#print axioms render_pointStmt47
end SynergyHeightC
