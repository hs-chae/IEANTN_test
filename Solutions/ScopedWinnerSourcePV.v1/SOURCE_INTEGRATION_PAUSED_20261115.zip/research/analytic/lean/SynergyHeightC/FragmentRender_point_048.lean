import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt48 : renderStmt 999 FragmentData.pointStmt48=some "((values[103])=add((values[97]),(values[102])));" := by decide +kernel
theorem render_pointStmt49 : renderStmt 999 FragmentData.pointStmt49=some "((values[104])=mul((values[99]),(values[90])));" := by decide +kernel
theorem render_pointStmt50 : renderStmt 999 FragmentData.pointStmt50=some "((values[105])=mul((values[104]),(values[103])));" := by decide +kernel
theorem render_pointStmt51 : renderStmt 999 FragmentData.pointStmt51=some "((values[106])=mul((values[105]),(values[82])));" := by decide +kernel
theorem render_pointStmt52 : renderStmt 999 FragmentData.pointStmt52=some "((values[107])=mul((values[5]),(values[5])));" := by decide +kernel
theorem render_pointStmt53 : renderStmt 999 FragmentData.pointStmt53=some "((values[108])=divI(unit(),(values[107])));" := by decide +kernel
theorem render_pointStmt54 : renderStmt 999 FragmentData.pointStmt54=some "((values[109])=mul((values[18]),(values[108])));" := by decide +kernel
theorem render_pointStmt55 : renderStmt 999 FragmentData.pointStmt55=some "((values[110])=mul((values[49]),(values[64])));" := by decide +kernel
#print axioms render_pointStmt48
#print axioms render_pointStmt49
#print axioms render_pointStmt50
#print axioms render_pointStmt51
#print axioms render_pointStmt52
#print axioms render_pointStmt53
#print axioms render_pointStmt54
#print axioms render_pointStmt55
end SynergyHeightC
