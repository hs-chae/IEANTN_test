import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt120 : renderStmt 999 FragmentData.pointStmt120=some "((values[175])=mul((values[174]),(values[166])));" := by decide +kernel
theorem render_pointStmt121 : renderStmt 999 FragmentData.pointStmt121=some "((values[176])=add((values[173]),(values[175])));" := by decide +kernel
theorem render_pointStmt122 : renderStmt 999 FragmentData.pointStmt122=some "((values[177])=mul((values[35]),(values[36])));" := by decide +kernel
theorem render_pointStmt123 : renderStmt 999 FragmentData.pointStmt123=some "((values[178])=mul((values[177]),(values[58])));" := by decide +kernel
theorem render_pointStmt124 : renderStmt 999 FragmentData.pointStmt124=some "((values[179])=mul((values[1]),(values[5])));" := by decide +kernel
theorem render_pointStmt125 : renderStmt 999 FragmentData.pointStmt125=some "((values[180])=mul((values[179]),(values[3])));" := by decide +kernel
theorem render_pointStmt126 : renderStmt 999 FragmentData.pointStmt126=some "((values[181])=divI(unit(),(values[180])));" := by decide +kernel
theorem render_pointStmt127 : renderStmt 999 FragmentData.pointStmt127=some "((values[182])=mul((values[178]),(values[181])));" := by decide +kernel
#print axioms render_pointStmt120
#print axioms render_pointStmt121
#print axioms render_pointStmt122
#print axioms render_pointStmt123
#print axioms render_pointStmt124
#print axioms render_pointStmt125
#print axioms render_pointStmt126
#print axioms render_pointStmt127
end SynergyHeightC
