/- These kernel checks execute the actual installed C AST bodies.
   All remain conditional components until source initialization/main sequencing joins. -/
import SynergyHeightC.MainPrefix

namespace SynergyHeightC.MainPrefix
open ScopedC ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem span_checked (arena : NatArena.Arena) :
    checked arena "positiveSub" [SynergyC.SourceIntervalMath.represented sixtyInput,
      SynergyC.SourceIntervalMath.represented SynergyAnalytic.HeightPoint.hValue]
      spanValue = true := by
  rfl

theorem source_span (arena : NatArena.Arena) :
    ∃ after, ArraySourceCalls.SourceCall SynergyC.Header.layout Bundle.code 12
      "positiveSub" [SynergyC.SourceIntervalMath.represented sixtyInput,
        SynergyC.SourceIntervalMath.represented SynergyAnalytic.HeightPoint.hValue]
      (InitCacheProposal.postState arena)
      (SynergyC.SourceIntervalMath.represented spanValue) after ∧
      after = InitCacheProposal.postState after.nats :=
  source_of_checked (span_checked arena)

#print axioms span_checked
#print axioms source_span
end SynergyHeightC.MainPrefix
