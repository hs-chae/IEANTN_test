import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt64 : renderStmt 999 FragmentData.pointStmt64=some "((values[119])=mul((values[59]),(values[58])));" := by decide +kernel
theorem render_pointStmt65 : renderStmt 999 FragmentData.pointStmt65=some "((values[120])=divI(unit(),(values[119])));" := by decide +kernel
theorem render_pointStmt66 : renderStmt 999 FragmentData.pointStmt66=some "((values[121])=mul((values[118]),(values[120])));" := by decide +kernel
theorem render_pointStmt67 : renderStmt 999 FragmentData.pointStmt67=some "((values[122])=add((values[113]),(values[117])));" := by decide +kernel
theorem render_pointStmt68 : renderStmt 999 FragmentData.pointStmt68=some "((values[123])=add((values[122]),(values[121])));" := by decide +kernel
theorem render_pointStmt69 : renderStmt 999 FragmentData.pointStmt69=some "((values[124])=mul((values[58]),(values[22])));" := by decide +kernel
theorem render_pointStmt70 : renderStmt 999 FragmentData.pointStmt70=some "((values[125])=expPositiveRaw((values[124])));" := by decide +kernel
theorem render_pointStmt71 : renderStmt 999 FragmentData.pointStmt71=some "((values[126])=mul((values[46]),(values[125])));" := by decide +kernel
#print axioms render_pointStmt64
#print axioms render_pointStmt65
#print axioms render_pointStmt66
#print axioms render_pointStmt67
#print axioms render_pointStmt68
#print axioms render_pointStmt69
#print axioms render_pointStmt70
#print axioms render_pointStmt71
end SynergyHeightC
