/- Actual first initializer statement, before any proposed computed cache is used. -/
import ScopedC.ArrayStages
import ScopedC.ArraySourceCallExecute
import SynergyHeightC.InitStageProposals
import SynergyHeightC.BoundInitialization

namespace SynergyHeightC.InitLn2Stage
open ScopedC ScopedC.Syntax ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

def statements : List Stmt :=
  match Generated.f_initializePointConstants.body with
  | .sequence ss => ss
  | _ => []
def first : Stmt := statements[0]?.getD .skip

theorem actual_body : Generated.f_initializePointConstants.body =
    .sequence (first::statements.drop 1) := by rfl

theorem static_proposal_matches_source :
    InitStageProposals.state000 NatArena.empty = Initialization.state := by rfl

def service : Call :=
  ArraySourceCallExecute.execute SynergyC.Header.layout Generated.functions 128 2048 15

theorem checked (arena : NatArena.Arena) :
    ArrayStages.hasNext
      (ArraySourceExecute.statement SynergyC.Header.layout service 128 2048 first
        (ArrayStages.withArena (InitStageProposals.state000 NatArena.empty) arena))
      (InitStageProposals.state001 NatArena.empty) = true := by
  rfl

theorem actual_source_statement : ArrayStages.ShapeRun SynergyC.Header.layout service first
    (InitStageProposals.state000 NatArena.empty)
    (InitStageProposals.state001 NatArena.empty) :=
  ArrayStages.statement_of_checked checked

theorem actual_callees_closed {name : String} {args : List Value}
    {before after : State} {v : Value} (h : service name args before = some (v,after)) :
    ArraySourceCalls.SourceCall SynergyC.Header.layout Generated.functions 15
      name args before v after :=
  ArraySourceCallExecute.execute_sound h

#print axioms actual_body
#print axioms static_proposal_matches_source
#print axioms checked
#print axioms actual_source_statement
#print axioms actual_callees_closed
end SynergyHeightC.InitLn2Stage
