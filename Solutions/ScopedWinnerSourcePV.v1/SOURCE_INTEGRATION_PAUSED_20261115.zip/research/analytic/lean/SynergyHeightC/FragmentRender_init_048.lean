import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_initStmt48 : renderStmt 999 FragmentData.initStmt48=some "((constantNodes[46])=rat(((((U)0)*((U)1000000000))+((U)611)),((((U)0)*((U)1000000000))+((U)1000))));" := by decide +kernel
theorem render_initStmt49 : renderStmt 999 FragmentData.initStmt49=some "((constantNodes[47])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)10000))));" := by decide +kernel
theorem render_initStmt50 : renderStmt 999 FragmentData.initStmt50=some "((constantNodes[48])=rat(((((U)0)*((U)1000000000))+((U)7)),((((U)0)*((U)1000000000))+((U)10000))));" := by decide +kernel
theorem render_initStmt51 : renderStmt 999 FragmentData.initStmt51=some "((constantNodes[49])=rat(((((U)0)*((U)1000000000))+((U)131)),((((U)0)*((U)1000000000))+((U)125))));" := by decide +kernel
theorem render_initStmt52 : renderStmt 999 FragmentData.initStmt52=some "((constantNodes[50])=rat(((((U)0)*((U)1000000000))+((U)31)),((((U)0)*((U)1000000000))+((U)50))));" := by decide +kernel
theorem render_initStmt53 : renderStmt 999 FragmentData.initStmt53=some "((constantNodes[51])=rat(((((U)0)*((U)1000000000))+((U)1461)),((((U)0)*((U)1000000000))+((U)1000))));" := by decide +kernel
theorem render_initStmt54 : renderStmt 999 FragmentData.initStmt54=some "((constantNodes[52])=rat(((((U)0)*((U)1000000000))+((U)373)),((((U)0)*((U)1000000000))+((U)200))));" := by decide +kernel
theorem render_initStmt55 : renderStmt 999 FragmentData.initStmt55=some "((constantNodes[53])=rat(((((U)0)*((U)1000000000))+((U)1273)),((((U)0)*((U)1000000000))+((U)2000))));" := by decide +kernel
#print axioms render_initStmt48
#print axioms render_initStmt49
#print axioms render_initStmt50
#print axioms render_initStmt51
#print axioms render_initStmt52
#print axioms render_initStmt53
#print axioms render_initStmt54
#print axioms render_initStmt55
end SynergyHeightC
