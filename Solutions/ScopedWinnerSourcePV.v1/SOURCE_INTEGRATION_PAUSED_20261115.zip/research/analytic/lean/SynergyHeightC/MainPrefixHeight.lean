/- These kernel checks execute the actual installed C AST bodies.
   All remain conditional components until source initialization/main sequencing joins. -/
import SynergyHeightC.MainPrefix

namespace SynergyHeightC.MainPrefix
open ScopedC ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem height_checked (arena : NatArena.Arena) :
    checked arena "logTight" [SynergyC.SourceIntervalMath.represented heightInput]
      SynergyAnalytic.HeightPoint.hValue = true := by
  rfl

theorem source_height (arena : NatArena.Arena) :
    ∃ after, ArraySourceCalls.SourceCall SynergyC.Header.layout Bundle.code 12
      "logTight" [SynergyC.SourceIntervalMath.represented heightInput]
      (InitCacheProposal.postState arena)
      (SynergyC.SourceIntervalMath.represented SynergyAnalytic.HeightPoint.hValue) after ∧
      after = InitCacheProposal.postState after.nats :=
  source_of_checked (height_checked arena)

#print axioms height_checked
#print axioms source_height
end SynergyHeightC.MainPrefix
