import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt32 : renderStmt 999 FragmentData.pointStmt32=some "((values[87])=mul((values[78]),(values[86])));" := by decide +kernel
theorem render_pointStmt33 : renderStmt 999 FragmentData.pointStmt33=some "((values[88])=mul((values[87]),(values[87])));" := by decide +kernel
theorem render_pointStmt34 : renderStmt 999 FragmentData.pointStmt34=some "((values[89])=mul((values[26]),(values[88])));" := by decide +kernel
theorem render_pointStmt35 : renderStmt 999 FragmentData.pointStmt35=some "((values[90])=expPositiveRaw((values[89])));" := by decide +kernel
theorem render_pointStmt36 : renderStmt 999 FragmentData.pointStmt36=some "((values[91])=mul((values[85]),(values[5])));" := by decide +kernel
theorem render_pointStmt37 : renderStmt 999 FragmentData.pointStmt37=some "((values[92])=mul((values[91]),(values[11])));" := by decide +kernel
theorem render_pointStmt38 : renderStmt 999 FragmentData.pointStmt38=some "((values[93])=mul((values[92]),(values[86])));" := by decide +kernel
theorem render_pointStmt39 : renderStmt 999 FragmentData.pointStmt39=some "((values[94])=add((values[72]),(values[93])));" := by decide +kernel
#print axioms render_pointStmt32
#print axioms render_pointStmt33
#print axioms render_pointStmt34
#print axioms render_pointStmt35
#print axioms render_pointStmt36
#print axioms render_pointStmt37
#print axioms render_pointStmt38
#print axioms render_pointStmt39
end SynergyHeightC
