import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt128 : renderStmt 999 FragmentData.pointStmt128=some "((values[183])=expPositiveRaw((values[176])));" := by decide +kernel
theorem render_pointStmt129 : renderStmt 999 FragmentData.pointStmt129=some "((values[184])=mul((values[182]),(values[183])));" := by decide +kernel
theorem render_pointStmt130 : renderStmt 999 FragmentData.pointStmt130=some "((values[185])=subExact((values[165]),(values[166])));" := by decide +kernel
theorem render_pointStmt131 : renderStmt 999 FragmentData.pointStmt131=some "((values[186])=mul((values[185]),(values[171])));" := by decide +kernel
theorem render_pointStmt132 : renderStmt 999 FragmentData.pointStmt132=some "((*outC)=(values[184]));" := by decide +kernel
theorem render_pointStmt133 : renderStmt 999 FragmentData.pointStmt133=some "((*outD)=(values[186]));" := by decide +kernel
#print axioms render_pointStmt128
#print axioms render_pointStmt129
#print axioms render_pointStmt130
#print axioms render_pointStmt131
#print axioms render_pointStmt132
#print axioms render_pointStmt133
end SynergyHeightC
