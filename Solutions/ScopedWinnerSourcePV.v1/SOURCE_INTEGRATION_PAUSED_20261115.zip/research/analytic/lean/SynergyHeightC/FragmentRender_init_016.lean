import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_initStmt16 : renderStmt 999 FragmentData.initStmt16=some "((constantNodes[14])=mul((constantNodes[5]),(constantNodes[13])));" := by decide +kernel
theorem render_initStmt17 : renderStmt 999 FragmentData.initStmt17=some "((constantNodes[15])=sqrtMatch((constantNodes[14])));" := by decide +kernel
theorem render_initStmt18 : renderStmt 999 FragmentData.initStmt18=some "((constantNodes[16])=divI(unit(),(constantNodes[1])));" := by decide +kernel
theorem render_initStmt19 : renderStmt 999 FragmentData.initStmt19=some "((constantNodes[17])=mul((constantNodes[15]),(constantNodes[16])));" := by decide +kernel
theorem render_initStmt20 : renderStmt 999 FragmentData.initStmt20=some "((constantNodes[18])=rat(((((U)0)*((U)1000000000))+((U)6)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
theorem render_initStmt21 : renderStmt 999 FragmentData.initStmt21=some "((constantNodes[19])=mul((constantNodes[18]),(constantNodes[12])));" := by decide +kernel
theorem render_initStmt22 : renderStmt 999 FragmentData.initStmt22=some "((constantNodes[20])=logPos((constantNodes[19])));" := by decide +kernel
theorem render_initStmt23 : renderStmt 999 FragmentData.initStmt23=some "((constantNodes[21])=add((constantNodes[0]),(constantNodes[20])));" := by decide +kernel
#print axioms render_initStmt16
#print axioms render_initStmt17
#print axioms render_initStmt18
#print axioms render_initStmt19
#print axioms render_initStmt20
#print axioms render_initStmt21
#print axioms render_initStmt22
#print axioms render_initStmt23
end SynergyHeightC
