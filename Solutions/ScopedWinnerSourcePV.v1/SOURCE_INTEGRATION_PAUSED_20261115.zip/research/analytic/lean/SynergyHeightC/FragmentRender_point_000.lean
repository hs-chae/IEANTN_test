import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt0 : renderStmt 999 FragmentData.pointStmt0=some "I values[187];" := by decide +kernel
theorem render_pointStmt1 : renderStmt 999 FragmentData.pointStmt1=some "unsigned int j=0;" := by decide +kernel
theorem render_pointStmt2 : renderStmt 999 FragmentData.pointStmt2=some "while((j<58)){((values[j])=(constantNodes[j]));\n(j=(j+1));}" := by decide +kernel
theorem render_pointStmt3 : renderStmt 999 FragmentData.pointStmt3=some "((values[58])=t);" := by decide +kernel
theorem render_pointStmt4 : renderStmt 999 FragmentData.pointStmt4=some "((values[59])=expPositiveRaw((values[58])));" := by decide +kernel
theorem render_pointStmt5 : renderStmt 999 FragmentData.pointStmt5=some "((values[60])=mul((values[5]),(values[11])));" := by decide +kernel
theorem render_pointStmt6 : renderStmt 999 FragmentData.pointStmt6=some "((values[61])=mul((values[60]),(values[40])));" := by decide +kernel
theorem render_pointStmt7 : renderStmt 999 FragmentData.pointStmt7=some "((values[62])=divI(unit(),(values[38])));" := by decide +kernel
#print axioms render_pointStmt0
#print axioms render_pointStmt1
#print axioms render_pointStmt2
#print axioms render_pointStmt3
#print axioms render_pointStmt4
#print axioms render_pointStmt5
#print axioms render_pointStmt6
#print axioms render_pointStmt7
end SynergyHeightC
