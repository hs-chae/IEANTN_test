import ScopedC.Grammar
namespace SynergyHeightC
open ScopedC.Syntax
set_option autoImplicit false
set_option maxHeartbeats 0
set_option Elab.async false

theorem render_sequence_of_map {n:Nat} {body:List Stmt} {texts:List String}
    (h:body.mapM (renderStmt n)=some texts) :
    renderStmt (n+1) (.sequence body)=some ("{"++String.intercalate "\n" texts++"}") := by
  simp only [renderStmt,h,Bind.bind,Option.bind,Pure.pure]

theorem render_function_of_body {f:Function} {body:String}
    (h:renderStmt 1000 f.body=some body) :
    renderFunction f=some (f.returnType++" "++f.name++"("++
      join (f.parameters.map (fun (t,n)=>t++" "++n))++")"++body++"\n") := by
  simp only [renderFunction,h,Bind.bind,Option.bind,Pure.pure]

#print axioms render_sequence_of_map
#print axioms render_function_of_body
end SynergyHeightC
