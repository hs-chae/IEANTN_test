import SynergyHeightC.Definitions
namespace SynergyHeightC.Generated
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_main : renderFunction f_main = some "int main(){initializePointConstants();\nconst unsigned int cells=768;\nI h=logTight(rat(((((((U)0)*((U)1000000000))+((U)3000))*((U)1000000000))+((U)0)),1));\nI span=positiveSub(rat(60,1),h);\nI total=zero();\nunsigned int i=0;\nwhile((i<cells)){I left=pointEdge(h,span,i,cells);\nI right=pointEdge(h,span,(i+1),cells);\nI c;\nI D;\npointHeight(right,(&c),(&D));\n(c=add(c,rat(21600,1)));\nI fc={(c.hi),(c.hi)};\nI fd={(D.hi),(D.hi)};\nI w=positiveSub(expNeg(left),expNeg(right));\n(total=add(total,mul(mul(rat(2,1),mul(w,fc)),paired(fd,330))));\nemitU((c.hi));\nemitU((D.hi));\n(i=(i+1));}\nemitI(total);\nif((fflush(stdout)!=0))fail();else ;\nreturn 0;}\n" := by decide +kernel
#print axioms render_main
end SynergyHeightC.Generated
