/- The SAME numerical C program and first point, evaluated through proved
actual scalar C subroutine contracts. This changes proof evaluation only. -/
import SynergyHeightC.FastPointExecute
import SynergyAnalytic.HeightPointLogGridDefs
import SynergyHeightC.InitCacheProposal

namespace SynergyHeightC.FastPointPilot0
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def input : ProofBox := (SynergyAnalytic.HeightPoint.logCell 1).getD ⟨0,0⟩

theorem checked_point0 :
    FastPointExecute.checkedModel (InitCacheProposal.postState NatArena.empty) input = true := by
  decide +kernel

#print axioms checked_point0
end SynergyHeightC.FastPointPilot0
