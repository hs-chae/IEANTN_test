/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import SynergyHeightC.PointExecuteDefinitions
import SynergyAnalytic.HeightPointLogGridDefs

namespace SynergyHeightC.PointExecutePilot0
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- First actual right endpoint; the grid-presence identity is independent
of the default value and is checked explicitly. -/
def input : ProofBox := (SynergyAnalytic.HeightPoint.logCell 1).getD ⟨0,0⟩

theorem input_is_right_endpoint : SynergyAnalytic.HeightPoint.logCell 1 = some input := by
  decide +kernel

/-- Concrete source-library component. Initial application cache words are
source-verified separately. Whole-main argument construction and the arena
connection are additional obligations, not assumed by this computation. -/
theorem checked_point0 :
    PointExecuteAPI.checkedModel (InitCacheProposal.postState NatArena.empty) input = true := by
  decide +kernel

#print axioms input_is_right_endpoint
#print axioms checked_point0
end SynergyHeightC.PointExecutePilot0
