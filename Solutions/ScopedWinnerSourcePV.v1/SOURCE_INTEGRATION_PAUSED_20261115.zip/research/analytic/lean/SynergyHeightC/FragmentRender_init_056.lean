import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_initStmt56 : renderStmt 999 FragmentData.initStmt56=some "((constantNodes[54])=rat(((((U)0)*((U)1000000000))+((U)129)),((((U)0)*((U)1000000000))+((U)250))));" := by decide +kernel
theorem render_initStmt57 : renderStmt 999 FragmentData.initStmt57=some "((constantNodes[55])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)8))));" := by decide +kernel
theorem render_initStmt58 : renderStmt 999 FragmentData.initStmt58=some "((constantNodes[56])=rat(((((U)0)*((U)1000000000))+((U)726)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
theorem render_initStmt59 : renderStmt 999 FragmentData.initStmt59=some "((constantNodes[57])=rat(((((U)0)*((U)1000000000))+((U)330)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
#print axioms render_initStmt56
#print axioms render_initStmt57
#print axioms render_initStmt58
#print axioms render_initStmt59
end SynergyHeightC
