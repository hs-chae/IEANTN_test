/- Actual fixed prefix instances; each is accepted in its own receipt. -/
import SynergyHeightC.MainPrefixRat
import SynergyHeightC.MainPrefixHeight
import SynergyHeightC.MainPrefixSpan
