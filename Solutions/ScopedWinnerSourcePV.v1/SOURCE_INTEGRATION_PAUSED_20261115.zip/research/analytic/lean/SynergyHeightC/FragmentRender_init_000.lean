import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_initStmt0 : renderStmt 999 FragmentData.initStmt0=some "(ln2=atanh2(rat(1,3)));" := by decide +kernel
theorem render_initStmt1 : renderStmt 999 FragmentData.initStmt1=some "initializeConstants();" := by decide +kernel
theorem render_initStmt2 : renderStmt 999 FragmentData.initStmt2=some "((constantNodes[0])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
theorem render_initStmt3 : renderStmt 999 FragmentData.initStmt3=some "((constantNodes[1])=rat(((((U)0)*((U)1000000000))+((U)2)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
theorem render_initStmt4 : renderStmt 999 FragmentData.initStmt4=some "((constantNodes[2])=rat(((((U)0)*((U)1000000000))+((U)601)),((((U)0)*((U)1000000000))+((U)5000))));" := by decide +kernel
theorem render_initStmt5 : renderStmt 999 FragmentData.initStmt5=some "((constantNodes[3])=rat(((((U)0)*((U)1000000000))+((U)3681)),((((U)0)*((U)1000000000))+((U)10000))));" := by decide +kernel
theorem render_initStmt6 : renderStmt 999 FragmentData.initStmt6=some "((constantNodes[4])=rat(((((U)0)*((U)1000000000))+((U)3599)),((((U)0)*((U)1000000000))+((U)10000))));" := by decide +kernel
theorem render_initStmt7 : renderStmt 999 FragmentData.initStmt7=some "((constantNodes[5])=piBox);" := by decide +kernel
#print axioms render_initStmt0
#print axioms render_initStmt1
#print axioms render_initStmt2
#print axioms render_initStmt3
#print axioms render_initStmt4
#print axioms render_initStmt5
#print axioms render_initStmt6
#print axioms render_initStmt7
end SynergyHeightC
