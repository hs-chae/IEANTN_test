/- Source-execution replay in the actual21-object caller frame, for every
   untouched accumulated total. The expected state is only a checked proposal:
   this theorem must reduce the actual C-source execution to that entire state. -/
import SynergyHeightC.FullMainFrame
import SynergyHeightC.FullContractPointExecute
open Lean Meta Elab Tactic
namespace SynergyHeightC.FramedPointParametric0Kernel
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def input : ProofBox := FullMainEdge.right
def outputs : ProofBox × ProofBox :=
  (PointExecuteAPI.modelOutputs input).getD (⟨0,0⟩,⟨0,0⟩)

theorem actual_parametric_execution (total : ProofBox) :
    FullContractPointExecute.run (FullMainFrame.base total 0) input =
      some (.unit,PointExecuteAPI.filled (FullMainFrame.base total 0) outputs.1 outputs.2) := by
  unfold FullContractPointExecute.run
  run_tac do
    let goal ← getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size == 3 do
      throwError "expected source execution equality"
    let proof ← mkEqRefl args[1]!
    goal.assign proof
    logInfo "KERNEL_REFLEXIVITY_GOAL_ASSIGNED; declaration kernel check is mandatory"

#print axioms actual_parametric_execution
end SynergyHeightC.FramedPointParametric0Kernel
