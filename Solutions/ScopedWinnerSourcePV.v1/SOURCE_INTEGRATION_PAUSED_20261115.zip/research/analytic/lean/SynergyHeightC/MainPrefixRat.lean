/- These kernel checks execute the actual installed C AST bodies.
   All remain conditional components until source initialization/main sequencing joins. -/
import SynergyHeightC.MainPrefix

namespace SynergyHeightC.MainPrefix
open ScopedC ScopedC.Machine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem rat_height_checked (arena : NatArena.Arena) :
    checked arena "rat" [SynergyC.Word512.value 3000000000000,SynergyC.Word512.value 1]
      heightInput = true := by
  rfl

theorem sixty_checked (arena : NatArena.Arena) :
    checked arena "rat" [SynergyC.Word512.value 60,SynergyC.Word512.value 1]
      sixtyInput = true := by
  rfl

#print axioms rat_height_checked
#print axioms sixty_checked
end SynergyHeightC.MainPrefix
