import SynergyHeightC.Definitions
import SynergyHeightC.RenderParts
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
def initStmt0 : Stmt := (.eval (.binary "=" (.var "ln2") (.call (.var "atanh2") [(.call (.var "rat") [(.nat 1),(.nat 3)])])))
theorem initRender0 : renderStmt 999 initStmt0=some "(ln2=atanh2(rat(1,3)));" := by decide +kernel
def initStmt1 : Stmt := (.eval (.call (.var "initializeConstants") []))
theorem initRender1 : renderStmt 999 initStmt1=some "initializeConstants();" := by decide +kernel
def initStmt2 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 0)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender2 : renderStmt 999 initStmt2=some "((constantNodes[0])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStmt3 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 1)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 2))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender3 : renderStmt 999 initStmt3=some "((constantNodes[1])=rat(((((U)0)*((U)1000000000))+((U)2)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStmt4 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 2)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 601))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 5000)))])))
theorem initRender4 : renderStmt 999 initStmt4=some "((constantNodes[2])=rat(((((U)0)*((U)1000000000))+((U)601)),((((U)0)*((U)1000000000))+((U)5000))));" := by decide +kernel
def initStmt5 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 3)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 3681))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 10000)))])))
theorem initRender5 : renderStmt 999 initStmt5=some "((constantNodes[3])=rat(((((U)0)*((U)1000000000))+((U)3681)),((((U)0)*((U)1000000000))+((U)10000))));" := by decide +kernel
def initStmt6 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 4)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 3599))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 10000)))])))
theorem initRender6 : renderStmt 999 initStmt6=some "((constantNodes[4])=rat(((((U)0)*((U)1000000000))+((U)3599)),((((U)0)*((U)1000000000))+((U)10000))));" := by decide +kernel
def initStmt7 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 5)) (.var "piBox")))
theorem initRender7 : renderStmt 999 initStmt7=some "((constantNodes[5])=piBox);" := by decide +kernel
def initStmt8 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 6)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 2))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 3)))])))
theorem initRender8 : renderStmt 999 initStmt8=some "((constantNodes[6])=rat(((((U)0)*((U)1000000000))+((U)2)),((((U)0)*((U)1000000000))+((U)3))));" := by decide +kernel
def initStmt9 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 7)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 6))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 5)))])))
theorem initRender9 : renderStmt 999 initStmt9=some "((constantNodes[7])=rat(((((U)0)*((U)1000000000))+((U)6)),((((U)0)*((U)1000000000))+((U)5))));" := by decide +kernel
def initStmt10 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 8)) (.call (.var "sqrtMatch") [(.index (.var "constantNodes") (.nat 7))])))
theorem initRender10 : renderStmt 999 initStmt10=some "((constantNodes[8])=sqrtMatch((constantNodes[7])));" := by decide +kernel
def initStmt11 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 9)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 6)),(.index (.var "constantNodes") (.nat 8))])))
theorem initRender11 : renderStmt 999 initStmt11=some "((constantNodes[9])=mul((constantNodes[6]),(constantNodes[8])));" := by decide +kernel
def initStmt12 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 10)) (.call (.var "add") [(.index (.var "constantNodes") (.nat 0)),(.index (.var "constantNodes") (.nat 9))])))
theorem initRender12 : renderStmt 999 initStmt12=some "((constantNodes[10])=add((constantNodes[0]),(constantNodes[9])));" := by decide +kernel
def initStmt13 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 11)) (.call (.var "sqrtMatch") [(.index (.var "constantNodes") (.nat 10))])))
theorem initRender13 : renderStmt 999 initStmt13=some "((constantNodes[11])=sqrtMatch((constantNodes[10])));" := by decide +kernel
def initStmt14 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 12)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 601))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 2500)))])))
theorem initRender14 : renderStmt 999 initStmt14=some "((constantNodes[12])=rat(((((U)0)*((U)1000000000))+((U)601)),((((U)0)*((U)1000000000))+((U)2500))));" := by decide +kernel
def initStmt15 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 13)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "constantNodes") (.nat 12))])))
theorem initRender15 : renderStmt 999 initStmt15=some "((constantNodes[13])=divI(unit(),(constantNodes[12])));" := by decide +kernel
def initStmt16 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 14)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 5)),(.index (.var "constantNodes") (.nat 13))])))
theorem initRender16 : renderStmt 999 initStmt16=some "((constantNodes[14])=mul((constantNodes[5]),(constantNodes[13])));" := by decide +kernel
def initStmt17 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 15)) (.call (.var "sqrtMatch") [(.index (.var "constantNodes") (.nat 14))])))
theorem initRender17 : renderStmt 999 initStmt17=some "((constantNodes[15])=sqrtMatch((constantNodes[14])));" := by decide +kernel
def initStmt18 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 16)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "constantNodes") (.nat 1))])))
theorem initRender18 : renderStmt 999 initStmt18=some "((constantNodes[16])=divI(unit(),(constantNodes[1])));" := by decide +kernel
def initStmt19 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 17)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 15)),(.index (.var "constantNodes") (.nat 16))])))
theorem initRender19 : renderStmt 999 initStmt19=some "((constantNodes[17])=mul((constantNodes[15]),(constantNodes[16])));" := by decide +kernel
def initStmt20 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 18)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 6))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender20 : renderStmt 999 initStmt20=some "((constantNodes[18])=rat(((((U)0)*((U)1000000000))+((U)6)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStmt21 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 19)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 18)),(.index (.var "constantNodes") (.nat 12))])))
theorem initRender21 : renderStmt 999 initStmt21=some "((constantNodes[19])=mul((constantNodes[18]),(constantNodes[12])));" := by decide +kernel
def initStmt22 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 20)) (.call (.var "logPos") [(.index (.var "constantNodes") (.nat 19))])))
theorem initRender22 : renderStmt 999 initStmt22=some "((constantNodes[20])=logPos((constantNodes[19])));" := by decide +kernel
def initStmt23 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 21)) (.call (.var "add") [(.index (.var "constantNodes") (.nat 0)),(.index (.var "constantNodes") (.nat 20))])))
theorem initRender23 : renderStmt 999 initStmt23=some "((constantNodes[21])=add((constantNodes[0]),(constantNodes[20])));" := by decide +kernel
def initStmt24 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 22)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "constantNodes") (.nat 18))])))
theorem initRender24 : renderStmt 999 initStmt24=some "((constantNodes[22])=divI(unit(),(constantNodes[18])));" := by decide +kernel
def initStmt25 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 23)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 21)),(.index (.var "constantNodes") (.nat 22))])))
theorem initRender25 : renderStmt 999 initStmt25=some "((constantNodes[23])=mul((constantNodes[21]),(constantNodes[22])));" := by decide +kernel
def initStmt26 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 24)) (.call (.var "expNeg") [(.index (.var "constantNodes") (.nat 23))])))
theorem initRender26 : renderStmt 999 initStmt26=some "((constantNodes[24])=expNeg((constantNodes[23])));" := by decide +kernel
def initStmt27 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 25)) (.call (.var "sqrtMatch") [(.index (.var "constantNodes") (.nat 5))])))
theorem initRender27 : renderStmt 999 initStmt27=some "((constantNodes[25])=sqrtMatch((constantNodes[5])));" := by decide +kernel
def initStmt28 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 26)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 1)),(.index (.var "constantNodes") (.nat 2))])))
theorem initRender28 : renderStmt 999 initStmt28=some "((constantNodes[26])=mul((constantNodes[1]),(constantNodes[2])));" := by decide +kernel
def initStmt29 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 27)) (.call (.var "sqrtMatch") [(.index (.var "constantNodes") (.nat 26))])))
theorem initRender29 : renderStmt 999 initStmt29=some "((constantNodes[27])=sqrtMatch((constantNodes[26])));" := by decide +kernel
def initStmt30 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 28)) (.call (.var "rat") [(.binary "+" (.binary "*" (.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 3000))) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 0))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender30 : renderStmt 999 initStmt30=some "((constantNodes[28])=rat(((((((U)0)*((U)1000000000))+((U)3000))*((U)1000000000))+((U)0)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStmt31 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 29)) (.call (.var "subExact") [(.index (.var "constantNodes") (.nat 28)),(.index (.var "constantNodes") (.nat 0))])))
theorem initRender31 : renderStmt 999 initStmt31=some "((constantNodes[29])=subExact((constantNodes[28]),(constantNodes[0])));" := by decide +kernel
def initStmt32 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 30)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 2)))])))
theorem initRender32 : renderStmt 999 initStmt32=some "((constantNodes[30])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)2))));" := by decide +kernel
def initStmt33 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 31)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "constantNodes") (.nat 29))])))
theorem initRender33 : renderStmt 999 initStmt33=some "((constantNodes[31])=divI(unit(),(constantNodes[29])));" := by decide +kernel
def initStmt34 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 32)) (.call (.var "subExact") [(.index (.var "constantNodes") (.nat 0)),(.index (.var "constantNodes") (.nat 31))])))
theorem initRender34 : renderStmt 999 initStmt34=some "((constantNodes[32])=subExact((constantNodes[0]),(constantNodes[31])));" := by decide +kernel
def initStmt35 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 33)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 32)),(.index (.var "constantNodes") (.nat 32))])))
theorem initRender35 : renderStmt 999 initStmt35=some "((constantNodes[33])=mul((constantNodes[32]),(constantNodes[32])));" := by decide +kernel
def initStmt36 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 34)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "constantNodes") (.nat 33))])))
theorem initRender36 : renderStmt 999 initStmt36=some "((constantNodes[34])=divI(unit(),(constantNodes[33])));" := by decide +kernel
def initStmt37 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 35)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 30)),(.index (.var "constantNodes") (.nat 34))])))
theorem initRender37 : renderStmt 999 initStmt37=some "((constantNodes[35])=mul((constantNodes[30]),(constantNodes[34])));" := by decide +kernel
def initStmt38 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 36)) (.call (.var "expPositiveRaw") [(.index (.var "constantNodes") (.nat 26))])))
theorem initRender38 : renderStmt 999 initStmt38=some "((constantNodes[36])=expPositiveRaw((constantNodes[26])));" := by decide +kernel
def initStmt39 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 37)) (.call (.var "expPositiveRaw") [(.index (.var "constantNodes") (.nat 4))])))
theorem initRender39 : renderStmt 999 initStmt39=some "((constantNodes[37])=expPositiveRaw((constantNodes[4])));" := by decide +kernel
def initStmt40 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 38)) (.call (.var "mul") [(.index (.var "constantNodes") (.nat 1)),(.index (.var "constantNodes") (.nat 4))])))
theorem initRender40 : renderStmt 999 initStmt40=some "((constantNodes[38])=mul((constantNodes[1]),(constantNodes[4])));" := by decide +kernel
def initStmt41 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 39)) (.call (.var "expNeg") [(.index (.var "constantNodes") (.nat 38))])))
theorem initRender41 : renderStmt 999 initStmt41=some "((constantNodes[39])=expNeg((constantNodes[38])));" := by decide +kernel
def initStmt42 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 40)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 529))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1000)))])))
theorem initRender42 : renderStmt 999 initStmt42=some "((constantNodes[40])=rat(((((U)0)*((U)1000000000))+((U)529)),((((U)0)*((U)1000000000))+((U)1000))));" := by decide +kernel
def initStmt43 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 41)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 289))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 500)))])))
theorem initRender43 : renderStmt 999 initStmt43=some "((constantNodes[41])=rat(((((U)0)*((U)1000000000))+((U)289)),((((U)0)*((U)1000000000))+((U)500))));" := by decide +kernel
def initStmt44 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 42)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 5))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender44 : renderStmt 999 initStmt44=some "((constantNodes[42])=rat(((((U)0)*((U)1000000000))+((U)5)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStmt45 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 43)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 121))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 200)))])))
theorem initRender45 : renderStmt 999 initStmt45=some "((constantNodes[43])=rat(((((U)0)*((U)1000000000))+((U)121)),((((U)0)*((U)1000000000))+((U)200))));" := by decide +kernel
def initStmt46 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 44)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 4))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender46 : renderStmt 999 initStmt46=some "((constantNodes[44])=rat(((((U)0)*((U)1000000000))+((U)4)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStmt47 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 45)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 8))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender47 : renderStmt 999 initStmt47=some "((constantNodes[45])=rat(((((U)0)*((U)1000000000))+((U)8)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStmt48 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 46)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 611))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1000)))])))
theorem initRender48 : renderStmt 999 initStmt48=some "((constantNodes[46])=rat(((((U)0)*((U)1000000000))+((U)611)),((((U)0)*((U)1000000000))+((U)1000))));" := by decide +kernel
def initStmt49 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 47)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 10000)))])))
theorem initRender49 : renderStmt 999 initStmt49=some "((constantNodes[47])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)10000))));" := by decide +kernel
def initStmt50 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 48)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 7))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 10000)))])))
theorem initRender50 : renderStmt 999 initStmt50=some "((constantNodes[48])=rat(((((U)0)*((U)1000000000))+((U)7)),((((U)0)*((U)1000000000))+((U)10000))));" := by decide +kernel
def initStmt51 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 49)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 131))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 125)))])))
theorem initRender51 : renderStmt 999 initStmt51=some "((constantNodes[49])=rat(((((U)0)*((U)1000000000))+((U)131)),((((U)0)*((U)1000000000))+((U)125))));" := by decide +kernel
def initStmt52 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 50)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 31))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 50)))])))
theorem initRender52 : renderStmt 999 initStmt52=some "((constantNodes[50])=rat(((((U)0)*((U)1000000000))+((U)31)),((((U)0)*((U)1000000000))+((U)50))));" := by decide +kernel
def initStmt53 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 51)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1461))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1000)))])))
theorem initRender53 : renderStmt 999 initStmt53=some "((constantNodes[51])=rat(((((U)0)*((U)1000000000))+((U)1461)),((((U)0)*((U)1000000000))+((U)1000))));" := by decide +kernel
def initStmt54 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 52)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 373))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 200)))])))
theorem initRender54 : renderStmt 999 initStmt54=some "((constantNodes[52])=rat(((((U)0)*((U)1000000000))+((U)373)),((((U)0)*((U)1000000000))+((U)200))));" := by decide +kernel
def initStmt55 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 53)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1273))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 2000)))])))
theorem initRender55 : renderStmt 999 initStmt55=some "((constantNodes[53])=rat(((((U)0)*((U)1000000000))+((U)1273)),((((U)0)*((U)1000000000))+((U)2000))));" := by decide +kernel
def initStmt56 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 54)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 129))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 250)))])))
theorem initRender56 : renderStmt 999 initStmt56=some "((constantNodes[54])=rat(((((U)0)*((U)1000000000))+((U)129)),((((U)0)*((U)1000000000))+((U)250))));" := by decide +kernel
def initStmt57 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 55)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 8)))])))
theorem initRender57 : renderStmt 999 initStmt57=some "((constantNodes[55])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)8))));" := by decide +kernel
def initStmt58 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 56)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 726))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender58 : renderStmt 999 initStmt58=some "((constantNodes[56])=rat(((((U)0)*((U)1000000000))+((U)726)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStmt59 : Stmt := (.eval (.binary "=" (.index (.var "constantNodes") (.nat 57)) (.call (.var "rat") [(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 330))),(.binary "+" (.binary "*" (.cast "U" (.nat 0)) (.cast "U" (.nat 1000000000))) (.cast "U" (.nat 1)))])))
theorem initRender59 : renderStmt 999 initStmt59=some "((constantNodes[57])=rat(((((U)0)*((U)1000000000))+((U)330)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
def initStatements : List Stmt := [initStmt0,initStmt1,initStmt2,initStmt3,initStmt4,initStmt5,initStmt6,initStmt7,initStmt8,initStmt9,initStmt10,initStmt11,initStmt12,initStmt13,initStmt14,initStmt15,initStmt16,initStmt17,initStmt18,initStmt19,initStmt20,initStmt21,initStmt22,initStmt23,initStmt24,initStmt25,initStmt26,initStmt27,initStmt28,initStmt29,initStmt30,initStmt31,initStmt32,initStmt33,initStmt34,initStmt35,initStmt36,initStmt37,initStmt38,initStmt39,initStmt40,initStmt41,initStmt42,initStmt43,initStmt44,initStmt45,initStmt46,initStmt47,initStmt48,initStmt49,initStmt50,initStmt51,initStmt52,initStmt53,initStmt54,initStmt55,initStmt56,initStmt57,initStmt58,initStmt59]
def initTexts : List String := ["(ln2=atanh2(rat(1,3)));","initializeConstants();","((constantNodes[0])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)1))));","((constantNodes[1])=rat(((((U)0)*((U)1000000000))+((U)2)),((((U)0)*((U)1000000000))+((U)1))));","((constantNodes[2])=rat(((((U)0)*((U)1000000000))+((U)601)),((((U)0)*((U)1000000000))+((U)5000))));","((constantNodes[3])=rat(((((U)0)*((U)1000000000))+((U)3681)),((((U)0)*((U)1000000000))+((U)10000))));","((constantNodes[4])=rat(((((U)0)*((U)1000000000))+((U)3599)),((((U)0)*((U)1000000000))+((U)10000))));","((constantNodes[5])=piBox);","((constantNodes[6])=rat(((((U)0)*((U)1000000000))+((U)2)),((((U)0)*((U)1000000000))+((U)3))));","((constantNodes[7])=rat(((((U)0)*((U)1000000000))+((U)6)),((((U)0)*((U)1000000000))+((U)5))));","((constantNodes[8])=sqrtMatch((constantNodes[7])));","((constantNodes[9])=mul((constantNodes[6]),(constantNodes[8])));","((constantNodes[10])=add((constantNodes[0]),(constantNodes[9])));","((constantNodes[11])=sqrtMatch((constantNodes[10])));","((constantNodes[12])=rat(((((U)0)*((U)1000000000))+((U)601)),((((U)0)*((U)1000000000))+((U)2500))));","((constantNodes[13])=divI(unit(),(constantNodes[12])));","((constantNodes[14])=mul((constantNodes[5]),(constantNodes[13])));","((constantNodes[15])=sqrtMatch((constantNodes[14])));","((constantNodes[16])=divI(unit(),(constantNodes[1])));","((constantNodes[17])=mul((constantNodes[15]),(constantNodes[16])));","((constantNodes[18])=rat(((((U)0)*((U)1000000000))+((U)6)),((((U)0)*((U)1000000000))+((U)1))));","((constantNodes[19])=mul((constantNodes[18]),(constantNodes[12])));","((constantNodes[20])=logPos((constantNodes[19])));","((constantNodes[21])=add((constantNodes[0]),(constantNodes[20])));","((constantNodes[22])=divI(unit(),(constantNodes[18])));","((constantNodes[23])=mul((constantNodes[21]),(constantNodes[22])));","((constantNodes[24])=expNeg((constantNodes[23])));","((constantNodes[25])=sqrtMatch((constantNodes[5])));","((constantNodes[26])=mul((constantNodes[1]),(constantNodes[2])));","((constantNodes[27])=sqrtMatch((constantNodes[26])));","((constantNodes[28])=rat(((((((U)0)*((U)1000000000))+((U)3000))*((U)1000000000))+((U)0)),((((U)0)*((U)1000000000))+((U)1))));","((constantNodes[29])=subExact((constantNodes[28]),(constantNodes[0])));","((constantNodes[30])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)2))));","((constantNodes[31])=divI(unit(),(constantNodes[29])));","((constantNodes[32])=subExact((constantNodes[0]),(constantNodes[31])));","((constantNodes[33])=mul((constantNodes[32]),(constantNodes[32])));","((constantNodes[34])=divI(unit(),(constantNodes[33])));","((constantNodes[35])=mul((constantNodes[30]),(constantNodes[34])));","((constantNodes[36])=expPositiveRaw((constantNodes[26])));","((constantNodes[37])=expPositiveRaw((constantNodes[4])));","((constantNodes[38])=mul((constantNodes[1]),(constantNodes[4])));","((constantNodes[39])=expNeg((constantNodes[38])));","((constantNodes[40])=rat(((((U)0)*((U)1000000000))+((U)529)),((((U)0)*((U)1000000000))+((U)1000))));","((constantNodes[41])=rat(((((U)0)*((U)1000000000))+((U)289)),((((U)0)*((U)1000000000))+((U)500))));","((constantNodes[42])=rat(((((U)0)*((U)1000000000))+((U)5)),((((U)0)*((U)1000000000))+((U)1))));","((constantNodes[43])=rat(((((U)0)*((U)1000000000))+((U)121)),((((U)0)*((U)1000000000))+((U)200))));","((constantNodes[44])=rat(((((U)0)*((U)1000000000))+((U)4)),((((U)0)*((U)1000000000))+((U)1))));","((constantNodes[45])=rat(((((U)0)*((U)1000000000))+((U)8)),((((U)0)*((U)1000000000))+((U)1))));","((constantNodes[46])=rat(((((U)0)*((U)1000000000))+((U)611)),((((U)0)*((U)1000000000))+((U)1000))));","((constantNodes[47])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)10000))));","((constantNodes[48])=rat(((((U)0)*((U)1000000000))+((U)7)),((((U)0)*((U)1000000000))+((U)10000))));","((constantNodes[49])=rat(((((U)0)*((U)1000000000))+((U)131)),((((U)0)*((U)1000000000))+((U)125))));","((constantNodes[50])=rat(((((U)0)*((U)1000000000))+((U)31)),((((U)0)*((U)1000000000))+((U)50))));","((constantNodes[51])=rat(((((U)0)*((U)1000000000))+((U)1461)),((((U)0)*((U)1000000000))+((U)1000))));","((constantNodes[52])=rat(((((U)0)*((U)1000000000))+((U)373)),((((U)0)*((U)1000000000))+((U)200))));","((constantNodes[53])=rat(((((U)0)*((U)1000000000))+((U)1273)),((((U)0)*((U)1000000000))+((U)2000))));","((constantNodes[54])=rat(((((U)0)*((U)1000000000))+((U)129)),((((U)0)*((U)1000000000))+((U)250))));","((constantNodes[55])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)8))));","((constantNodes[56])=rat(((((U)0)*((U)1000000000))+((U)726)),((((U)0)*((U)1000000000))+((U)1))));","((constantNodes[57])=rat(((((U)0)*((U)1000000000))+((U)330)),((((U)0)*((U)1000000000))+((U)1))));"]
theorem initBody_exact : Generated.f_initializePointConstants.body=.sequence initStatements := by rfl

#print axioms initRender0
#print axioms initRender1
#print axioms initRender2
#print axioms initRender3
#print axioms initRender4
#print axioms initRender5
#print axioms initRender6
#print axioms initRender7
#print axioms initRender8
#print axioms initRender9
#print axioms initRender10
#print axioms initRender11
#print axioms initRender12
#print axioms initRender13
#print axioms initRender14
#print axioms initRender15
#print axioms initRender16
#print axioms initRender17
#print axioms initRender18
#print axioms initRender19
#print axioms initRender20
#print axioms initRender21
#print axioms initRender22
#print axioms initRender23
#print axioms initRender24
#print axioms initRender25
#print axioms initRender26
#print axioms initRender27
#print axioms initRender28
#print axioms initRender29
#print axioms initRender30
#print axioms initRender31
#print axioms initRender32
#print axioms initRender33
#print axioms initRender34
#print axioms initRender35
#print axioms initRender36
#print axioms initRender37
#print axioms initRender38
#print axioms initRender39
#print axioms initRender40
#print axioms initRender41
#print axioms initRender42
#print axioms initRender43
#print axioms initRender44
#print axioms initRender45
#print axioms initRender46
#print axioms initRender47
#print axioms initRender48
#print axioms initRender49
#print axioms initRender50
#print axioms initRender51
#print axioms initRender52
#print axioms initRender53
#print axioms initRender54
#print axioms initRender55
#print axioms initRender56
#print axioms initRender57
#print axioms initRender58
#print axioms initRender59
end SynergyHeightC
