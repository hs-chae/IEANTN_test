import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt96 : renderStmt 999 FragmentData.pointStmt96=some "((values[151])=mul((values[150]),(values[119])));" := by decide +kernel
theorem render_pointStmt97 : renderStmt 999 FragmentData.pointStmt97=some "((values[152])=mul((values[151]),(values[147])));" := by decide +kernel
theorem render_pointStmt98 : renderStmt 999 FragmentData.pointStmt98=some "((values[153])=divI(unit(),(values[47])));" := by decide +kernel
theorem render_pointStmt99 : renderStmt 999 FragmentData.pointStmt99=some "((values[154])=add((values[0]),(values[153])));" := by decide +kernel
theorem render_pointStmt100 : renderStmt 999 FragmentData.pointStmt100=some "((values[155])=mul((values[154]),(values[59])));" := by decide +kernel
theorem render_pointStmt101 : renderStmt 999 FragmentData.pointStmt101=some "((values[156])=mul((values[155]),(values[17])));" := by decide +kernel
theorem render_pointStmt102 : renderStmt 999 FragmentData.pointStmt102=some "((values[157])=mul((values[59]),(values[59])));" := by decide +kernel
theorem render_pointStmt103 : renderStmt 999 FragmentData.pointStmt103=some "((values[158])=mul((values[1]),(values[157])));" := by decide +kernel
#print axioms render_pointStmt96
#print axioms render_pointStmt97
#print axioms render_pointStmt98
#print axioms render_pointStmt99
#print axioms render_pointStmt100
#print axioms render_pointStmt101
#print axioms render_pointStmt102
#print axioms render_pointStmt103
end SynergyHeightC
