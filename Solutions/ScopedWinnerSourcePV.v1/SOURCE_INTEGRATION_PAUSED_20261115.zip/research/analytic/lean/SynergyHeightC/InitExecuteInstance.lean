/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import SynergyHeightC.InitExecute

namespace SynergyHeightC.InitExecute
open ScopedC ScopedC.Machine ScopedC.ArraySourceCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Ordinary-kernel execution of the complete actual constant initializer.
The proposed words are accepted only after every source operation succeeds
and complete application-state equality is checked. -/
theorem checked_init : checked = true := by decide +kernel

theorem actual_source_init :
    ∃ arena, SourceCall SynergyC.Header.layout Bundle.code 16 "initializePointConstants" []
      Initialization.state .unit (InitCacheProposal.postState arena) :=
  bound_source_of_checked checked_init

#print axioms checked_init
#print axioms actual_source_init
end SynergyHeightC.InitExecute
