import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_initStmt40 : renderStmt 999 FragmentData.initStmt40=some "((constantNodes[38])=mul((constantNodes[1]),(constantNodes[4])));" := by decide +kernel
theorem render_initStmt41 : renderStmt 999 FragmentData.initStmt41=some "((constantNodes[39])=expNeg((constantNodes[38])));" := by decide +kernel
theorem render_initStmt42 : renderStmt 999 FragmentData.initStmt42=some "((constantNodes[40])=rat(((((U)0)*((U)1000000000))+((U)529)),((((U)0)*((U)1000000000))+((U)1000))));" := by decide +kernel
theorem render_initStmt43 : renderStmt 999 FragmentData.initStmt43=some "((constantNodes[41])=rat(((((U)0)*((U)1000000000))+((U)289)),((((U)0)*((U)1000000000))+((U)500))));" := by decide +kernel
theorem render_initStmt44 : renderStmt 999 FragmentData.initStmt44=some "((constantNodes[42])=rat(((((U)0)*((U)1000000000))+((U)5)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
theorem render_initStmt45 : renderStmt 999 FragmentData.initStmt45=some "((constantNodes[43])=rat(((((U)0)*((U)1000000000))+((U)121)),((((U)0)*((U)1000000000))+((U)200))));" := by decide +kernel
theorem render_initStmt46 : renderStmt 999 FragmentData.initStmt46=some "((constantNodes[44])=rat(((((U)0)*((U)1000000000))+((U)4)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
theorem render_initStmt47 : renderStmt 999 FragmentData.initStmt47=some "((constantNodes[45])=rat(((((U)0)*((U)1000000000))+((U)8)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
#print axioms render_initStmt40
#print axioms render_initStmt41
#print axioms render_initStmt42
#print axioms render_initStmt43
#print axioms render_initStmt44
#print axioms render_initStmt45
#print axioms render_initStmt46
#print axioms render_initStmt47
end SynergyHeightC
