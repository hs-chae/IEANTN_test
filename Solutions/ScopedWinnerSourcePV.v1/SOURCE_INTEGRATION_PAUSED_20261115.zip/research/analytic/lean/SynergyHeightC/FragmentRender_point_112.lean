import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt112 : renderStmt 999 FragmentData.pointStmt112=some "((values[167])=add((values[30]),(values[77])));" := by decide +kernel
theorem render_pointStmt113 : renderStmt 999 FragmentData.pointStmt113=some "((values[168])=add((values[3]),(values[4])));" := by decide +kernel
theorem render_pointStmt114 : renderStmt 999 FragmentData.pointStmt114=some "((values[169])=mul((values[168]),(values[64])));" := by decide +kernel
theorem render_pointStmt115 : renderStmt 999 FragmentData.pointStmt115=some "((values[170])=add((values[55]),(values[169])));" := by decide +kernel
theorem render_pointStmt116 : renderStmt 999 FragmentData.pointStmt116=some "((values[171])=divI(unit(),(values[167])));" := by decide +kernel
theorem render_pointStmt117 : renderStmt 999 FragmentData.pointStmt117=some "((values[172])=mul((values[170]),(values[171])));" := by decide +kernel
theorem render_pointStmt118 : renderStmt 999 FragmentData.pointStmt118=some "((values[173])=mul((values[172]),(values[165])));" := by decide +kernel
theorem render_pointStmt119 : renderStmt 999 FragmentData.pointStmt119=some "((values[174])=subExact((values[0]),(values[172])));" := by decide +kernel
#print axioms render_pointStmt112
#print axioms render_pointStmt113
#print axioms render_pointStmt114
#print axioms render_pointStmt115
#print axioms render_pointStmt116
#print axioms render_pointStmt117
#print axioms render_pointStmt118
#print axioms render_pointStmt119
end SynergyHeightC
