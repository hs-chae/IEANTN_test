import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_initStmt32 : renderStmt 999 FragmentData.initStmt32=some "((constantNodes[30])=rat(((((U)0)*((U)1000000000))+((U)1)),((((U)0)*((U)1000000000))+((U)2))));" := by decide +kernel
theorem render_initStmt33 : renderStmt 999 FragmentData.initStmt33=some "((constantNodes[31])=divI(unit(),(constantNodes[29])));" := by decide +kernel
theorem render_initStmt34 : renderStmt 999 FragmentData.initStmt34=some "((constantNodes[32])=subExact((constantNodes[0]),(constantNodes[31])));" := by decide +kernel
theorem render_initStmt35 : renderStmt 999 FragmentData.initStmt35=some "((constantNodes[33])=mul((constantNodes[32]),(constantNodes[32])));" := by decide +kernel
theorem render_initStmt36 : renderStmt 999 FragmentData.initStmt36=some "((constantNodes[34])=divI(unit(),(constantNodes[33])));" := by decide +kernel
theorem render_initStmt37 : renderStmt 999 FragmentData.initStmt37=some "((constantNodes[35])=mul((constantNodes[30]),(constantNodes[34])));" := by decide +kernel
theorem render_initStmt38 : renderStmt 999 FragmentData.initStmt38=some "((constantNodes[36])=expPositiveRaw((constantNodes[26])));" := by decide +kernel
theorem render_initStmt39 : renderStmt 999 FragmentData.initStmt39=some "((constantNodes[37])=expPositiveRaw((constantNodes[4])));" := by decide +kernel
#print axioms render_initStmt32
#print axioms render_initStmt33
#print axioms render_initStmt34
#print axioms render_initStmt35
#print axioms render_initStmt36
#print axioms render_initStmt37
#print axioms render_initStmt38
#print axioms render_initStmt39
end SynergyHeightC
