import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt16 : renderStmt 999 FragmentData.pointStmt16=some "((values[71])=mul((values[63]),(values[67])));" := by decide +kernel
theorem render_pointStmt17 : renderStmt 999 FragmentData.pointStmt17=some "((values[72])=mul((values[71]),(values[70])));" := by decide +kernel
theorem render_pointStmt18 : renderStmt 999 FragmentData.pointStmt18=some "((values[73])=mul((values[42]),(values[4])));" := by decide +kernel
theorem render_pointStmt19 : renderStmt 999 FragmentData.pointStmt19=some "((values[74])=mul((values[73]),(values[37])));" := by decide +kernel
theorem render_pointStmt20 : renderStmt 999 FragmentData.pointStmt20=some "((values[75])=divI(unit(),(values[74])));" := by decide +kernel
theorem render_pointStmt21 : renderStmt 999 FragmentData.pointStmt21=some "((values[76])=mul((values[40]),(values[75])));" := by decide +kernel
theorem render_pointStmt22 : renderStmt 999 FragmentData.pointStmt22=some "((values[77])=mul((values[4]),(values[64])));" := by decide +kernel
theorem render_pointStmt23 : renderStmt 999 FragmentData.pointStmt23=some "((values[78])=add((values[0]),(values[77])));" := by decide +kernel
#print axioms render_pointStmt16
#print axioms render_pointStmt17
#print axioms render_pointStmt18
#print axioms render_pointStmt19
#print axioms render_pointStmt20
#print axioms render_pointStmt21
#print axioms render_pointStmt22
#print axioms render_pointStmt23
end SynergyHeightC
