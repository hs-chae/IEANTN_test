import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_initStmt8 : renderStmt 999 FragmentData.initStmt8=some "((constantNodes[6])=rat(((((U)0)*((U)1000000000))+((U)2)),((((U)0)*((U)1000000000))+((U)3))));" := by decide +kernel
theorem render_initStmt9 : renderStmt 999 FragmentData.initStmt9=some "((constantNodes[7])=rat(((((U)0)*((U)1000000000))+((U)6)),((((U)0)*((U)1000000000))+((U)5))));" := by decide +kernel
theorem render_initStmt10 : renderStmt 999 FragmentData.initStmt10=some "((constantNodes[8])=sqrtMatch((constantNodes[7])));" := by decide +kernel
theorem render_initStmt11 : renderStmt 999 FragmentData.initStmt11=some "((constantNodes[9])=mul((constantNodes[6]),(constantNodes[8])));" := by decide +kernel
theorem render_initStmt12 : renderStmt 999 FragmentData.initStmt12=some "((constantNodes[10])=add((constantNodes[0]),(constantNodes[9])));" := by decide +kernel
theorem render_initStmt13 : renderStmt 999 FragmentData.initStmt13=some "((constantNodes[11])=sqrtMatch((constantNodes[10])));" := by decide +kernel
theorem render_initStmt14 : renderStmt 999 FragmentData.initStmt14=some "((constantNodes[12])=rat(((((U)0)*((U)1000000000))+((U)601)),((((U)0)*((U)1000000000))+((U)2500))));" := by decide +kernel
theorem render_initStmt15 : renderStmt 999 FragmentData.initStmt15=some "((constantNodes[13])=divI(unit(),(constantNodes[12])));" := by decide +kernel
#print axioms render_initStmt8
#print axioms render_initStmt9
#print axioms render_initStmt10
#print axioms render_initStmt11
#print axioms render_initStmt12
#print axioms render_initStmt13
#print axioms render_initStmt14
#print axioms render_initStmt15
end SynergyHeightC
