/- Same actual C numerical function at right endpoint 768/768. -/
import SynergyHeightC.FastPointExecute
import SynergyAnalytic.HeightPointLogGridDefs
import SynergyHeightC.InitCacheProposal
namespace SynergyHeightC.FastPointPilot767
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def input : ProofBox := (SynergyAnalytic.HeightPoint.logCell 768).getD ⟨0,0⟩
theorem checked_point : FastPointExecute.checkedModel
    (InitCacheProposal.postState NatArena.empty) input = true := by decide +kernel
#print axioms checked_point
end SynergyHeightC.FastPointPilot767
