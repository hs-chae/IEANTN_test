import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_initStmt24 : renderStmt 999 FragmentData.initStmt24=some "((constantNodes[22])=divI(unit(),(constantNodes[18])));" := by decide +kernel
theorem render_initStmt25 : renderStmt 999 FragmentData.initStmt25=some "((constantNodes[23])=mul((constantNodes[21]),(constantNodes[22])));" := by decide +kernel
theorem render_initStmt26 : renderStmt 999 FragmentData.initStmt26=some "((constantNodes[24])=expNeg((constantNodes[23])));" := by decide +kernel
theorem render_initStmt27 : renderStmt 999 FragmentData.initStmt27=some "((constantNodes[25])=sqrtMatch((constantNodes[5])));" := by decide +kernel
theorem render_initStmt28 : renderStmt 999 FragmentData.initStmt28=some "((constantNodes[26])=mul((constantNodes[1]),(constantNodes[2])));" := by decide +kernel
theorem render_initStmt29 : renderStmt 999 FragmentData.initStmt29=some "((constantNodes[27])=sqrtMatch((constantNodes[26])));" := by decide +kernel
theorem render_initStmt30 : renderStmt 999 FragmentData.initStmt30=some "((constantNodes[28])=rat(((((((U)0)*((U)1000000000))+((U)3000))*((U)1000000000))+((U)0)),((((U)0)*((U)1000000000))+((U)1))));" := by decide +kernel
theorem render_initStmt31 : renderStmt 999 FragmentData.initStmt31=some "((constantNodes[29])=subExact((constantNodes[28]),(constantNodes[0])));" := by decide +kernel
#print axioms render_initStmt24
#print axioms render_initStmt25
#print axioms render_initStmt26
#print axioms render_initStmt27
#print axioms render_initStmt28
#print axioms render_initStmt29
#print axioms render_initStmt30
#print axioms render_initStmt31
end SynergyHeightC
