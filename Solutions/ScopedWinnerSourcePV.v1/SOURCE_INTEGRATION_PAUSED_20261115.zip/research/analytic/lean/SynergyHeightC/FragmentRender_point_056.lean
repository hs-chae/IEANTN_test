import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt56 : renderStmt 999 FragmentData.pointStmt56=some "((values[111])=add((values[109]),(values[110])));" := by decide +kernel
theorem render_pointStmt57 : renderStmt 999 FragmentData.pointStmt57=some "((values[112])=mul((values[60]),(values[50])));" := by decide +kernel
theorem render_pointStmt58 : renderStmt 999 FragmentData.pointStmt58=some "((values[113])=mul((values[112]),(values[64])));" := by decide +kernel
theorem render_pointStmt59 : renderStmt 999 FragmentData.pointStmt59=some "((values[114])=mul((values[18]),(values[11])));" := by decide +kernel
theorem render_pointStmt60 : renderStmt 999 FragmentData.pointStmt60=some "((values[115])=mul((values[5]),(values[59])));" := by decide +kernel
theorem render_pointStmt61 : renderStmt 999 FragmentData.pointStmt61=some "((values[116])=divI(unit(),(values[115])));" := by decide +kernel
theorem render_pointStmt62 : renderStmt 999 FragmentData.pointStmt62=some "((values[117])=mul((values[114]),(values[116])));" := by decide +kernel
theorem render_pointStmt63 : renderStmt 999 FragmentData.pointStmt63=some "((values[118])=mul((values[60]),(values[49])));" := by decide +kernel
#print axioms render_pointStmt56
#print axioms render_pointStmt57
#print axioms render_pointStmt58
#print axioms render_pointStmt59
#print axioms render_pointStmt60
#print axioms render_pointStmt61
#print axioms render_pointStmt62
#print axioms render_pointStmt63
end SynergyHeightC
