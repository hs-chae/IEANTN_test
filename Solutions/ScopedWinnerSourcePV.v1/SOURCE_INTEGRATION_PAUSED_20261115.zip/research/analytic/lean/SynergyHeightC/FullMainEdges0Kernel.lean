/- The actual two pointEdge input declarations, for every accumulated total.
The proof term is reflexivity; Lean's kernel must validate the whole actual
source execution equality. No skipped kernel check, output oracle or axiom. -/
import SynergyHeightC.FullMainEdges
open Lean Meta Elab Tactic
namespace SynergyHeightC.FullMainEdges0Kernel
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem actual_parametric_edges (total : ProofBox) :
    FullMainEdges.run total 0=some (.continuing (FullMainFrame.base total 0)) := by
  unfold FullMainEdges.run
  run_tac do
    let goal ← getMainGoal
    let target ← goal.getType
    let args := target.getAppArgs
    unless target.getAppFn.isConstOf ``Eq && args.size==3 do
      throwError "expected actual source endpoint execution equality"
    let proof ← mkEqRefl args[1]!
    goal.assign proof
    logInfo "KERNEL_REFLEXIVITY_GOAL_ASSIGNED; declaration kernel check is mandatory"

theorem actual_source_edges (total : ProofBox) :
    Loops.SeqRun (ArraySourceCalls.Eval SynergyC.Header.layout FullMainPrefix.service)
      (ArraySourceCalls.Declare SynergyC.Header.layout FullMainPrefix.service) truth ArraySourceCalls.Scope
      FullMainEdge.statements (FullMainEdges.loopState total 0)
        (.continuing (FullMainFrame.base total 0)) :=
  FullMainEdges.actual_source_edges actual_parametric_edges total

#print axioms actual_parametric_edges
#print axioms actual_source_edges
end SynergyHeightC.FullMainEdges0Kernel
