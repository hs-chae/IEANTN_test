/- Unwrap actual source output data without coupling the provider to one
numerical execution backend. All source calls have already proved closures. -/
import SynergyHeightC.FastPointExecute

namespace SynergyHeightC.FastPointExecute
open ScopedC ScopedC.Machine ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0

 theorem source_outputs_of_checkedModel {base : State} {input : ProofBox}
    (h : checkedModel base input = true) :
    ∃ c d, PointExecuteAPI.modelOutputs input = some (c,d) ∧
      PointExecuteAPI.SourcePointOutputs base input c d := by
  cases hm : PointExecuteAPI.modelOutputs input with
  | none => simp [checkedModel,hm] at h
  | some pair =>
    rcases pair with ⟨c,d⟩
    have hc : checked base input c d = true := by simpa only [checkedModel,hm] using h
    exact ⟨c,d,rfl,source_outputs_of_checked hc⟩

#print axioms source_outputs_of_checkedModel
end SynergyHeightC.FastPointExecute
