import SynergyHeightC.Definitions
import SynergyHeightC.RenderParts
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
def pointStmt0 : Stmt := (.declare [{type:="I",name:="values",value:=none,arrayExtent:=(some 187)}])
theorem pointRender0 : renderStmt 999 pointStmt0=some "I values[187];" := by decide +kernel
def pointStmt1 : Stmt := (.declare [{type:="unsigned int",name:="j",value:=(some (.nat 0)),arrayExtent:=none}])
theorem pointRender1 : renderStmt 999 pointStmt1=some "unsigned int j=0;" := by decide +kernel
def pointStmt2 : Stmt := (.whileLoop (.binary "<" (.var "j") (.nat 58)) (.sequence [(.eval (.binary "=" (.index (.var "values") (.var "j")) (.index (.var "constantNodes") (.var "j")))),(.eval (.binary "=" (.var "j") (.binary "+" (.var "j") (.nat 1))))]))
theorem pointRender2 : renderStmt 999 pointStmt2=some "while((j<58)){((values[j])=(constantNodes[j]));\n(j=(j+1));}" := by decide +kernel
def pointStmt3 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 58)) (.var "t")))
theorem pointRender3 : renderStmt 999 pointStmt3=some "((values[58])=t);" := by decide +kernel
def pointStmt4 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 59)) (.call (.var "expPositiveRaw") [(.index (.var "values") (.nat 58))])))
theorem pointRender4 : renderStmt 999 pointStmt4=some "((values[59])=expPositiveRaw((values[58])));" := by decide +kernel
def pointStmt5 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 60)) (.call (.var "mul") [(.index (.var "values") (.nat 5)),(.index (.var "values") (.nat 11))])))
theorem pointRender5 : renderStmt 999 pointStmt5=some "((values[60])=mul((values[5]),(values[11])));" := by decide +kernel
def pointStmt6 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 61)) (.call (.var "mul") [(.index (.var "values") (.nat 60)),(.index (.var "values") (.nat 40))])))
theorem pointRender6 : renderStmt 999 pointStmt6=some "((values[61])=mul((values[60]),(values[40])));" := by decide +kernel
def pointStmt7 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 62)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 38))])))
theorem pointRender7 : renderStmt 999 pointStmt7=some "((values[62])=divI(unit(),(values[38])));" := by decide +kernel
def pointStmt8 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 63)) (.call (.var "mul") [(.index (.var "values") (.nat 61)),(.index (.var "values") (.nat 62))])))
theorem pointRender8 : renderStmt 999 pointStmt8=some "((values[63])=mul((values[61]),(values[62])));" := by decide +kernel
def pointStmt9 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 64)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 58))])))
theorem pointRender9 : renderStmt 999 pointStmt9=some "((values[64])=divI(unit(),(values[58])));" := by decide +kernel
def pointStmt10 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 65)) (.call (.var "mul") [(.index (.var "values") (.nat 38)),(.index (.var "values") (.nat 64))])))
theorem pointRender10 : renderStmt 999 pointStmt10=some "((values[65])=mul((values[38]),(values[64])));" := by decide +kernel
def pointStmt11 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 66)) (.call (.var "add") [(.index (.var "values") (.nat 0)),(.index (.var "values") (.nat 65))])))
theorem pointRender11 : renderStmt 999 pointStmt11=some "((values[66])=add((values[0]),(values[65])));" := by decide +kernel
def pointStmt12 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 67)) (.call (.var "mul") [(.index (.var "values") (.nat 66)),(.index (.var "values") (.nat 66))])))
theorem pointRender12 : renderStmt 999 pointStmt12=some "((values[67])=mul((values[66]),(values[66])));" := by decide +kernel
def pointStmt13 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 68)) (.call (.var "mul") [(.index (.var "values") (.nat 38)),(.index (.var "values") (.nat 41))])))
theorem pointRender13 : renderStmt 999 pointStmt13=some "((values[68])=mul((values[38]),(values[41])));" := by decide +kernel
def pointStmt14 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 69)) (.call (.var "mul") [(.index (.var "values") (.nat 68)),(.index (.var "values") (.nat 64))])))
theorem pointRender14 : renderStmt 999 pointStmt14=some "((values[69])=mul((values[68]),(values[64])));" := by decide +kernel
def pointStmt15 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 70)) (.call (.var "expPositiveRaw") [(.index (.var "values") (.nat 69))])))
theorem pointRender15 : renderStmt 999 pointStmt15=some "((values[70])=expPositiveRaw((values[69])));" := by decide +kernel
def pointStmt16 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 71)) (.call (.var "mul") [(.index (.var "values") (.nat 63)),(.index (.var "values") (.nat 67))])))
theorem pointRender16 : renderStmt 999 pointStmt16=some "((values[71])=mul((values[63]),(values[67])));" := by decide +kernel
def pointStmt17 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 72)) (.call (.var "mul") [(.index (.var "values") (.nat 71)),(.index (.var "values") (.nat 70))])))
theorem pointRender17 : renderStmt 999 pointStmt17=some "((values[72])=mul((values[71]),(values[70])));" := by decide +kernel
def pointStmt18 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 73)) (.call (.var "mul") [(.index (.var "values") (.nat 42)),(.index (.var "values") (.nat 4))])))
theorem pointRender18 : renderStmt 999 pointStmt18=some "((values[73])=mul((values[42]),(values[4])));" := by decide +kernel
def pointStmt19 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 74)) (.call (.var "mul") [(.index (.var "values") (.nat 73)),(.index (.var "values") (.nat 37))])))
theorem pointRender19 : renderStmt 999 pointStmt19=some "((values[74])=mul((values[73]),(values[37])));" := by decide +kernel
def pointStmt20 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 75)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 74))])))
theorem pointRender20 : renderStmt 999 pointStmt20=some "((values[75])=divI(unit(),(values[74])));" := by decide +kernel
def pointStmt21 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 76)) (.call (.var "mul") [(.index (.var "values") (.nat 40)),(.index (.var "values") (.nat 75))])))
theorem pointRender21 : renderStmt 999 pointStmt21=some "((values[76])=mul((values[40]),(values[75])));" := by decide +kernel
def pointStmt22 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 77)) (.call (.var "mul") [(.index (.var "values") (.nat 4)),(.index (.var "values") (.nat 64))])))
theorem pointRender22 : renderStmt 999 pointStmt22=some "((values[77])=mul((values[4]),(values[64])));" := by decide +kernel
def pointStmt23 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 78)) (.call (.var "add") [(.index (.var "values") (.nat 0)),(.index (.var "values") (.nat 77))])))
theorem pointRender23 : renderStmt 999 pointStmt23=some "((values[78])=add((values[0]),(values[77])));" := by decide +kernel
def pointStmt24 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 79)) (.call (.var "mul") [(.index (.var "values") (.nat 78)),(.index (.var "values") (.nat 78))])))
theorem pointRender24 : renderStmt 999 pointStmt24=some "((values[79])=mul((values[78]),(values[78])));" := by decide +kernel
def pointStmt25 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 80)) (.call (.var "mul") [(.index (.var "values") (.nat 76)),(.index (.var "values") (.nat 79))])))
theorem pointRender25 : renderStmt 999 pointStmt25=some "((values[80])=mul((values[76]),(values[79])));" := by decide +kernel
def pointStmt26 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 81)) (.call (.var "mul") [(.index (.var "values") (.nat 43)),(.index (.var "values") (.nat 39))])))
theorem pointRender26 : renderStmt 999 pointStmt26=some "((values[81])=mul((values[43]),(values[39])));" := by decide +kernel
def pointStmt27 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 82)) (.call (.var "mul") [(.index (.var "values") (.nat 58)),(.index (.var "values") (.nat 58))])))
theorem pointRender27 : renderStmt 999 pointStmt27=some "((values[82])=mul((values[58]),(values[58])));" := by decide +kernel
def pointStmt28 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 83)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 82))])))
theorem pointRender28 : renderStmt 999 pointStmt28=some "((values[83])=divI(unit(),(values[82])));" := by decide +kernel
def pointStmt29 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 84)) (.call (.var "mul") [(.index (.var "values") (.nat 81)),(.index (.var "values") (.nat 83))])))
theorem pointRender29 : renderStmt 999 pointStmt29=some "((values[84])=mul((values[81]),(values[83])));" := by decide +kernel
def pointStmt30 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 85)) (.call (.var "add") [(.index (.var "values") (.nat 80)),(.index (.var "values") (.nat 84))])))
theorem pointRender30 : renderStmt 999 pointStmt30=some "((values[85])=add((values[80]),(values[84])));" := by decide +kernel
def pointStmt31 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 86)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 59))])))
theorem pointRender31 : renderStmt 999 pointStmt31=some "((values[86])=divI(unit(),(values[59])));" := by decide +kernel
def pointStmt32 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 87)) (.call (.var "mul") [(.index (.var "values") (.nat 78)),(.index (.var "values") (.nat 86))])))
theorem pointRender32 : renderStmt 999 pointStmt32=some "((values[87])=mul((values[78]),(values[86])));" := by decide +kernel
def pointStmt33 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 88)) (.call (.var "mul") [(.index (.var "values") (.nat 87)),(.index (.var "values") (.nat 87))])))
theorem pointRender33 : renderStmt 999 pointStmt33=some "((values[88])=mul((values[87]),(values[87])));" := by decide +kernel
def pointStmt34 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 89)) (.call (.var "mul") [(.index (.var "values") (.nat 26)),(.index (.var "values") (.nat 88))])))
theorem pointRender34 : renderStmt 999 pointStmt34=some "((values[89])=mul((values[26]),(values[88])));" := by decide +kernel
def pointStmt35 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 90)) (.call (.var "expPositiveRaw") [(.index (.var "values") (.nat 89))])))
theorem pointRender35 : renderStmt 999 pointStmt35=some "((values[90])=expPositiveRaw((values[89])));" := by decide +kernel
def pointStmt36 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 91)) (.call (.var "mul") [(.index (.var "values") (.nat 85)),(.index (.var "values") (.nat 5))])))
theorem pointRender36 : renderStmt 999 pointStmt36=some "((values[91])=mul((values[85]),(values[5])));" := by decide +kernel
def pointStmt37 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 92)) (.call (.var "mul") [(.index (.var "values") (.nat 91)),(.index (.var "values") (.nat 11))])))
theorem pointRender37 : renderStmt 999 pointStmt37=some "((values[92])=mul((values[91]),(values[11])));" := by decide +kernel
def pointStmt38 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 93)) (.call (.var "mul") [(.index (.var "values") (.nat 92)),(.index (.var "values") (.nat 86))])))
theorem pointRender38 : renderStmt 999 pointStmt38=some "((values[93])=mul((values[92]),(values[86])));" := by decide +kernel
def pointStmt39 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 94)) (.call (.var "add") [(.index (.var "values") (.nat 72)),(.index (.var "values") (.nat 93))])))
theorem pointRender39 : renderStmt 999 pointStmt39=some "((values[94])=add((values[72]),(values[93])));" := by decide +kernel
def pointStmt40 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 95)) (.call (.var "mul") [(.index (.var "values") (.nat 44)),(.index (.var "values") (.nat 2))])))
theorem pointRender40 : renderStmt 999 pointStmt40=some "((values[95])=mul((values[44]),(values[2])));" := by decide +kernel
def pointStmt41 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 96)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 95))])))
theorem pointRender41 : renderStmt 999 pointStmt41=some "((values[96])=divI(unit(),(values[95])));" := by decide +kernel
def pointStmt42 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 97)) (.call (.var "mul") [(.index (.var "values") (.nat 94)),(.index (.var "values") (.nat 96))])))
theorem pointRender42 : renderStmt 999 pointStmt42=some "((values[97])=mul((values[94]),(values[96])));" := by decide +kernel
def pointStmt43 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 98)) (.call (.var "mul") [(.index (.var "values") (.nat 85)),(.index (.var "values") (.nat 25))])))
theorem pointRender43 : renderStmt 999 pointStmt43=some "((values[98])=mul((values[85]),(values[25])));" := by decide +kernel
def pointStmt44 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 99)) (.call (.var "mul") [(.index (.var "values") (.nat 45)),(.index (.var "values") (.nat 2))])))
theorem pointRender44 : renderStmt 999 pointStmt44=some "((values[99])=mul((values[45]),(values[2])));" := by decide +kernel
def pointStmt45 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 100)) (.call (.var "mul") [(.index (.var "values") (.nat 99)),(.index (.var "values") (.nat 27))])))
theorem pointRender45 : renderStmt 999 pointStmt45=some "((values[100])=mul((values[99]),(values[27])));" := by decide +kernel
def pointStmt46 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 101)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 100))])))
theorem pointRender46 : renderStmt 999 pointStmt46=some "((values[101])=divI(unit(),(values[100])));" := by decide +kernel
def pointStmt47 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 102)) (.call (.var "mul") [(.index (.var "values") (.nat 98)),(.index (.var "values") (.nat 101))])))
theorem pointRender47 : renderStmt 999 pointStmt47=some "((values[102])=mul((values[98]),(values[101])));" := by decide +kernel
def pointStmt48 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 103)) (.call (.var "add") [(.index (.var "values") (.nat 97)),(.index (.var "values") (.nat 102))])))
theorem pointRender48 : renderStmt 999 pointStmt48=some "((values[103])=add((values[97]),(values[102])));" := by decide +kernel
def pointStmt49 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 104)) (.call (.var "mul") [(.index (.var "values") (.nat 99)),(.index (.var "values") (.nat 90))])))
theorem pointRender49 : renderStmt 999 pointStmt49=some "((values[104])=mul((values[99]),(values[90])));" := by decide +kernel
def pointStmt50 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 105)) (.call (.var "mul") [(.index (.var "values") (.nat 104)),(.index (.var "values") (.nat 103))])))
theorem pointRender50 : renderStmt 999 pointStmt50=some "((values[105])=mul((values[104]),(values[103])));" := by decide +kernel
def pointStmt51 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 106)) (.call (.var "mul") [(.index (.var "values") (.nat 105)),(.index (.var "values") (.nat 82))])))
theorem pointRender51 : renderStmt 999 pointStmt51=some "((values[106])=mul((values[105]),(values[82])));" := by decide +kernel
def pointStmt52 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 107)) (.call (.var "mul") [(.index (.var "values") (.nat 5)),(.index (.var "values") (.nat 5))])))
theorem pointRender52 : renderStmt 999 pointStmt52=some "((values[107])=mul((values[5]),(values[5])));" := by decide +kernel
def pointStmt53 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 108)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 107))])))
theorem pointRender53 : renderStmt 999 pointStmt53=some "((values[108])=divI(unit(),(values[107])));" := by decide +kernel
def pointStmt54 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 109)) (.call (.var "mul") [(.index (.var "values") (.nat 18)),(.index (.var "values") (.nat 108))])))
theorem pointRender54 : renderStmt 999 pointStmt54=some "((values[109])=mul((values[18]),(values[108])));" := by decide +kernel
def pointStmt55 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 110)) (.call (.var "mul") [(.index (.var "values") (.nat 49)),(.index (.var "values") (.nat 64))])))
theorem pointRender55 : renderStmt 999 pointStmt55=some "((values[110])=mul((values[49]),(values[64])));" := by decide +kernel
def pointStmt56 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 111)) (.call (.var "add") [(.index (.var "values") (.nat 109)),(.index (.var "values") (.nat 110))])))
theorem pointRender56 : renderStmt 999 pointStmt56=some "((values[111])=add((values[109]),(values[110])));" := by decide +kernel
def pointStmt57 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 112)) (.call (.var "mul") [(.index (.var "values") (.nat 60)),(.index (.var "values") (.nat 50))])))
theorem pointRender57 : renderStmt 999 pointStmt57=some "((values[112])=mul((values[60]),(values[50])));" := by decide +kernel
def pointStmt58 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 113)) (.call (.var "mul") [(.index (.var "values") (.nat 112)),(.index (.var "values") (.nat 64))])))
theorem pointRender58 : renderStmt 999 pointStmt58=some "((values[113])=mul((values[112]),(values[64])));" := by decide +kernel
def pointStmt59 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 114)) (.call (.var "mul") [(.index (.var "values") (.nat 18)),(.index (.var "values") (.nat 11))])))
theorem pointRender59 : renderStmt 999 pointStmt59=some "((values[114])=mul((values[18]),(values[11])));" := by decide +kernel
def pointStmt60 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 115)) (.call (.var "mul") [(.index (.var "values") (.nat 5)),(.index (.var "values") (.nat 59))])))
theorem pointRender60 : renderStmt 999 pointStmt60=some "((values[115])=mul((values[5]),(values[59])));" := by decide +kernel
def pointStmt61 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 116)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 115))])))
theorem pointRender61 : renderStmt 999 pointStmt61=some "((values[116])=divI(unit(),(values[115])));" := by decide +kernel
def pointStmt62 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 117)) (.call (.var "mul") [(.index (.var "values") (.nat 114)),(.index (.var "values") (.nat 116))])))
theorem pointRender62 : renderStmt 999 pointStmt62=some "((values[117])=mul((values[114]),(values[116])));" := by decide +kernel
def pointStmt63 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 118)) (.call (.var "mul") [(.index (.var "values") (.nat 60)),(.index (.var "values") (.nat 49))])))
theorem pointRender63 : renderStmt 999 pointStmt63=some "((values[118])=mul((values[60]),(values[49])));" := by decide +kernel
def pointStmt64 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 119)) (.call (.var "mul") [(.index (.var "values") (.nat 59)),(.index (.var "values") (.nat 58))])))
theorem pointRender64 : renderStmt 999 pointStmt64=some "((values[119])=mul((values[59]),(values[58])));" := by decide +kernel
def pointStmt65 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 120)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 119))])))
theorem pointRender65 : renderStmt 999 pointStmt65=some "((values[120])=divI(unit(),(values[119])));" := by decide +kernel
def pointStmt66 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 121)) (.call (.var "mul") [(.index (.var "values") (.nat 118)),(.index (.var "values") (.nat 120))])))
theorem pointRender66 : renderStmt 999 pointStmt66=some "((values[121])=mul((values[118]),(values[120])));" := by decide +kernel
def pointStmt67 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 122)) (.call (.var "add") [(.index (.var "values") (.nat 113)),(.index (.var "values") (.nat 117))])))
theorem pointRender67 : renderStmt 999 pointStmt67=some "((values[122])=add((values[113]),(values[117])));" := by decide +kernel
def pointStmt68 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 123)) (.call (.var "add") [(.index (.var "values") (.nat 122)),(.index (.var "values") (.nat 121))])))
theorem pointRender68 : renderStmt 999 pointStmt68=some "((values[123])=add((values[122]),(values[121])));" := by decide +kernel
def pointStmt69 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 124)) (.call (.var "mul") [(.index (.var "values") (.nat 58)),(.index (.var "values") (.nat 22))])))
theorem pointRender69 : renderStmt 999 pointStmt69=some "((values[124])=mul((values[58]),(values[22])));" := by decide +kernel
def pointStmt70 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 125)) (.call (.var "expPositiveRaw") [(.index (.var "values") (.nat 124))])))
theorem pointRender70 : renderStmt 999 pointStmt70=some "((values[125])=expPositiveRaw((values[124])));" := by decide +kernel
def pointStmt71 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 126)) (.call (.var "mul") [(.index (.var "values") (.nat 46)),(.index (.var "values") (.nat 125))])))
theorem pointRender71 : renderStmt 999 pointStmt71=some "((values[126])=mul((values[46]),(values[125])));" := by decide +kernel
def pointStmt72 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 127)) (.call (.var "mul") [(.index (.var "values") (.nat 126)),(.index (.var "values") (.nat 58))])))
theorem pointRender72 : renderStmt 999 pointStmt72=some "((values[127])=mul((values[126]),(values[58])));" := by decide +kernel
def pointStmt73 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 128)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 127))])))
theorem pointRender73 : renderStmt 999 pointStmt73=some "((values[128])=divI(unit(),(values[127])));" := by decide +kernel
def pointStmt74 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 129)) (.call (.var "mul") [(.index (.var "values") (.nat 51)),(.index (.var "values") (.nat 128))])))
theorem pointRender74 : renderStmt 999 pointStmt74=some "((values[129])=mul((values[51]),(values[128])));" := by decide +kernel
def pointStmt75 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 130)) (.call (.var "mul") [(.index (.var "values") (.nat 1)),(.index (.var "values") (.nat 64))])))
theorem pointRender75 : renderStmt 999 pointStmt75=some "((values[130])=mul((values[1]),(values[64])));" := by decide +kernel
def pointStmt76 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 131)) (.call (.var "mul") [(.index (.var "values") (.nat 130)),(.index (.var "values") (.nat 53))])))
theorem pointRender76 : renderStmt 999 pointStmt76=some "((values[131])=mul((values[130]),(values[53])));" := by decide +kernel
def pointStmt77 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 132)) (.call (.var "mul") [(.index (.var "values") (.nat 54)),(.index (.var "values") (.nat 83))])))
theorem pointRender77 : renderStmt 999 pointStmt77=some "((values[132])=mul((values[54]),(values[83])));" := by decide +kernel
def pointStmt78 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 133)) (.call (.var "add") [(.index (.var "values") (.nat 52)),(.index (.var "values") (.nat 131))])))
theorem pointRender78 : renderStmt 999 pointStmt78=some "((values[133])=add((values[52]),(values[131])));" := by decide +kernel
def pointStmt79 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 134)) (.call (.var "add") [(.index (.var "values") (.nat 133)),(.index (.var "values") (.nat 132))])))
theorem pointRender79 : renderStmt 999 pointStmt79=some "((values[134])=add((values[133]),(values[132])));" := by decide +kernel
def pointStmt80 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 135)) (.call (.var "mul") [(.index (.var "values") (.nat 111)),(.index (.var "values") (.nat 134))])))
theorem pointRender80 : renderStmt 999 pointStmt80=some "((values[135])=mul((values[111]),(values[134])));" := by decide +kernel
def pointStmt81 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 136)) (.call (.var "mul") [(.index (.var "values") (.nat 123)),(.index (.var "values") (.nat 24))])))
theorem pointRender81 : renderStmt 999 pointStmt81=some "((values[136])=mul((values[123]),(values[24])));" := by decide +kernel
def pointStmt82 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 137)) (.call (.var "add") [(.index (.var "values") (.nat 135)),(.index (.var "values") (.nat 136))])))
theorem pointRender82 : renderStmt 999 pointStmt82=some "((values[137])=add((values[135]),(values[136])));" := by decide +kernel
def pointStmt83 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 138)) (.call (.var "mul") [(.index (.var "values") (.nat 111)),(.index (.var "values") (.nat 17))])))
theorem pointRender83 : renderStmt 999 pointStmt83=some "((values[138])=mul((values[111]),(values[17])));" := by decide +kernel
def pointStmt84 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 139)) (.call (.var "add") [(.index (.var "values") (.nat 138)),(.index (.var "values") (.nat 123))])))
theorem pointRender84 : renderStmt 999 pointStmt84=some "((values[139])=add((values[138]),(values[123])));" := by decide +kernel
def pointStmt85 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 140)) (.call (.var "add") [(.index (.var "values") (.nat 0)),(.index (.var "values") (.nat 48))])))
theorem pointRender85 : renderStmt 999 pointStmt85=some "((values[140])=add((values[0]),(values[48])));" := by decide +kernel
def pointStmt86 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 141)) (.call (.var "mul") [(.index (.var "values") (.nat 140)),(.index (.var "values") (.nat 137))])))
theorem pointRender86 : renderStmt 999 pointStmt86=some "((values[141])=mul((values[140]),(values[137])));" := by decide +kernel
def pointStmt87 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 142)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 48))])))
theorem pointRender87 : renderStmt 999 pointStmt87=some "((values[142])=divI(unit(),(values[48])));" := by decide +kernel
def pointStmt88 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 143)) (.call (.var "add") [(.index (.var "values") (.nat 0)),(.index (.var "values") (.nat 142))])))
theorem pointRender88 : renderStmt 999 pointStmt88=some "((values[143])=add((values[0]),(values[142])));" := by decide +kernel
def pointStmt89 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 144)) (.call (.var "mul") [(.index (.var "values") (.nat 129)),(.index (.var "values") (.nat 129))])))
theorem pointRender89 : renderStmt 999 pointStmt89=some "((values[144])=mul((values[129]),(values[129])));" := by decide +kernel
def pointStmt90 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 145)) (.call (.var "mul") [(.index (.var "values") (.nat 143)),(.index (.var "values") (.nat 144))])))
theorem pointRender90 : renderStmt 999 pointStmt90=some "((values[145])=mul((values[143]),(values[144])));" := by decide +kernel
def pointStmt91 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 146)) (.call (.var "mul") [(.index (.var "values") (.nat 145)),(.index (.var "values") (.nat 139))])))
theorem pointRender91 : renderStmt 999 pointStmt91=some "((values[146])=mul((values[145]),(values[139])));" := by decide +kernel
def pointStmt92 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 147)) (.call (.var "add") [(.index (.var "values") (.nat 141)),(.index (.var "values") (.nat 146))])))
theorem pointRender92 : renderStmt 999 pointStmt92=some "((values[147])=add((values[141]),(values[146])));" := by decide +kernel
def pointStmt93 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 148)) (.call (.var "add") [(.index (.var "values") (.nat 0)),(.index (.var "values") (.nat 47))])))
theorem pointRender93 : renderStmt 999 pointStmt93=some "((values[148])=add((values[0]),(values[47])));" := by decide +kernel
def pointStmt94 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 149)) (.call (.var "mul") [(.index (.var "values") (.nat 127)),(.index (.var "values") (.nat 127))])))
theorem pointRender94 : renderStmt 999 pointStmt94=some "((values[149])=mul((values[127]),(values[127])));" := by decide +kernel
def pointStmt95 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 150)) (.call (.var "mul") [(.index (.var "values") (.nat 148)),(.index (.var "values") (.nat 149))])))
theorem pointRender95 : renderStmt 999 pointStmt95=some "((values[150])=mul((values[148]),(values[149])));" := by decide +kernel
def pointStmt96 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 151)) (.call (.var "mul") [(.index (.var "values") (.nat 150)),(.index (.var "values") (.nat 119))])))
theorem pointRender96 : renderStmt 999 pointStmt96=some "((values[151])=mul((values[150]),(values[119])));" := by decide +kernel
def pointStmt97 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 152)) (.call (.var "mul") [(.index (.var "values") (.nat 151)),(.index (.var "values") (.nat 147))])))
theorem pointRender97 : renderStmt 999 pointStmt97=some "((values[152])=mul((values[151]),(values[147])));" := by decide +kernel
def pointStmt98 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 153)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 47))])))
theorem pointRender98 : renderStmt 999 pointStmt98=some "((values[153])=divI(unit(),(values[47])));" := by decide +kernel
def pointStmt99 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 154)) (.call (.var "add") [(.index (.var "values") (.nat 0)),(.index (.var "values") (.nat 153))])))
theorem pointRender99 : renderStmt 999 pointStmt99=some "((values[154])=add((values[0]),(values[153])));" := by decide +kernel
def pointStmt100 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 155)) (.call (.var "mul") [(.index (.var "values") (.nat 154)),(.index (.var "values") (.nat 59))])))
theorem pointRender100 : renderStmt 999 pointStmt100=some "((values[155])=mul((values[154]),(values[59])));" := by decide +kernel
def pointStmt101 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 156)) (.call (.var "mul") [(.index (.var "values") (.nat 155)),(.index (.var "values") (.nat 17))])))
theorem pointRender101 : renderStmt 999 pointStmt101=some "((values[156])=mul((values[155]),(values[17])));" := by decide +kernel
def pointStmt102 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 157)) (.call (.var "mul") [(.index (.var "values") (.nat 59)),(.index (.var "values") (.nat 59))])))
theorem pointRender102 : renderStmt 999 pointStmt102=some "((values[157])=mul((values[59]),(values[59])));" := by decide +kernel
def pointStmt103 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 158)) (.call (.var "mul") [(.index (.var "values") (.nat 1)),(.index (.var "values") (.nat 157))])))
theorem pointRender103 : renderStmt 999 pointStmt103=some "((values[158])=mul((values[1]),(values[157])));" := by decide +kernel
def pointStmt104 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 159)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 158))])))
theorem pointRender104 : renderStmt 999 pointStmt104=some "((values[159])=divI(unit(),(values[158])));" := by decide +kernel
def pointStmt105 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 160)) (.call (.var "mul") [(.index (.var "values") (.nat 2)),(.index (.var "values") (.nat 159))])))
theorem pointRender105 : renderStmt 999 pointStmt105=some "((values[160])=mul((values[2]),(values[159])));" := by decide +kernel
def pointStmt106 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 161)) (.call (.var "expPositiveRaw") [(.index (.var "values") (.nat 160))])))
theorem pointRender106 : renderStmt 999 pointStmt106=some "((values[161])=expPositiveRaw((values[160])));" := by decide +kernel
def pointStmt107 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 162)) (.call (.var "add") [(.index (.var "values") (.nat 152)),(.index (.var "values") (.nat 156))])))
theorem pointRender107 : renderStmt 999 pointStmt107=some "((values[162])=add((values[152]),(values[156])));" := by decide +kernel
def pointStmt108 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 163)) (.call (.var "mul") [(.index (.var "values") (.nat 1)),(.index (.var "values") (.nat 161))])))
theorem pointRender108 : renderStmt 999 pointStmt108=some "((values[163])=mul((values[1]),(values[161])));" := by decide +kernel
def pointStmt109 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 164)) (.call (.var "mul") [(.index (.var "values") (.nat 163)),(.index (.var "values") (.nat 162))])))
theorem pointRender109 : renderStmt 999 pointStmt109=some "((values[164])=mul((values[163]),(values[162])));" := by decide +kernel
def pointStmt110 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 165)) (.call (.var "logPos") [(.index (.var "values") (.nat 164))])))
theorem pointRender110 : renderStmt 999 pointStmt110=some "((values[165])=logPos((values[164])));" := by decide +kernel
def pointStmt111 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 166)) (.call (.var "logPos") [(.index (.var "values") (.nat 106))])))
theorem pointRender111 : renderStmt 999 pointStmt111=some "((values[166])=logPos((values[106])));" := by decide +kernel
def pointStmt112 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 167)) (.call (.var "add") [(.index (.var "values") (.nat 30)),(.index (.var "values") (.nat 77))])))
theorem pointRender112 : renderStmt 999 pointStmt112=some "((values[167])=add((values[30]),(values[77])));" := by decide +kernel
def pointStmt113 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 168)) (.call (.var "add") [(.index (.var "values") (.nat 3)),(.index (.var "values") (.nat 4))])))
theorem pointRender113 : renderStmt 999 pointStmt113=some "((values[168])=add((values[3]),(values[4])));" := by decide +kernel
def pointStmt114 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 169)) (.call (.var "mul") [(.index (.var "values") (.nat 168)),(.index (.var "values") (.nat 64))])))
theorem pointRender114 : renderStmt 999 pointStmt114=some "((values[169])=mul((values[168]),(values[64])));" := by decide +kernel
def pointStmt115 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 170)) (.call (.var "add") [(.index (.var "values") (.nat 55)),(.index (.var "values") (.nat 169))])))
theorem pointRender115 : renderStmt 999 pointStmt115=some "((values[170])=add((values[55]),(values[169])));" := by decide +kernel
def pointStmt116 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 171)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 167))])))
theorem pointRender116 : renderStmt 999 pointStmt116=some "((values[171])=divI(unit(),(values[167])));" := by decide +kernel
def pointStmt117 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 172)) (.call (.var "mul") [(.index (.var "values") (.nat 170)),(.index (.var "values") (.nat 171))])))
theorem pointRender117 : renderStmt 999 pointStmt117=some "((values[172])=mul((values[170]),(values[171])));" := by decide +kernel
def pointStmt118 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 173)) (.call (.var "mul") [(.index (.var "values") (.nat 172)),(.index (.var "values") (.nat 165))])))
theorem pointRender118 : renderStmt 999 pointStmt118=some "((values[173])=mul((values[172]),(values[165])));" := by decide +kernel
def pointStmt119 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 174)) (.call (.var "subExact") [(.index (.var "values") (.nat 0)),(.index (.var "values") (.nat 172))])))
theorem pointRender119 : renderStmt 999 pointStmt119=some "((values[174])=subExact((values[0]),(values[172])));" := by decide +kernel
def pointStmt120 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 175)) (.call (.var "mul") [(.index (.var "values") (.nat 174)),(.index (.var "values") (.nat 166))])))
theorem pointRender120 : renderStmt 999 pointStmt120=some "((values[175])=mul((values[174]),(values[166])));" := by decide +kernel
def pointStmt121 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 176)) (.call (.var "add") [(.index (.var "values") (.nat 173)),(.index (.var "values") (.nat 175))])))
theorem pointRender121 : renderStmt 999 pointStmt121=some "((values[176])=add((values[173]),(values[175])));" := by decide +kernel
def pointStmt122 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 177)) (.call (.var "mul") [(.index (.var "values") (.nat 35)),(.index (.var "values") (.nat 36))])))
theorem pointRender122 : renderStmt 999 pointStmt122=some "((values[177])=mul((values[35]),(values[36])));" := by decide +kernel
def pointStmt123 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 178)) (.call (.var "mul") [(.index (.var "values") (.nat 177)),(.index (.var "values") (.nat 58))])))
theorem pointRender123 : renderStmt 999 pointStmt123=some "((values[178])=mul((values[177]),(values[58])));" := by decide +kernel
def pointStmt124 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 179)) (.call (.var "mul") [(.index (.var "values") (.nat 1)),(.index (.var "values") (.nat 5))])))
theorem pointRender124 : renderStmt 999 pointStmt124=some "((values[179])=mul((values[1]),(values[5])));" := by decide +kernel
def pointStmt125 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 180)) (.call (.var "mul") [(.index (.var "values") (.nat 179)),(.index (.var "values") (.nat 3))])))
theorem pointRender125 : renderStmt 999 pointStmt125=some "((values[180])=mul((values[179]),(values[3])));" := by decide +kernel
def pointStmt126 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 181)) (.call (.var "divI") [(.call (.var "unit") []),(.index (.var "values") (.nat 180))])))
theorem pointRender126 : renderStmt 999 pointStmt126=some "((values[181])=divI(unit(),(values[180])));" := by decide +kernel
def pointStmt127 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 182)) (.call (.var "mul") [(.index (.var "values") (.nat 178)),(.index (.var "values") (.nat 181))])))
theorem pointRender127 : renderStmt 999 pointStmt127=some "((values[182])=mul((values[178]),(values[181])));" := by decide +kernel
def pointStmt128 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 183)) (.call (.var "expPositiveRaw") [(.index (.var "values") (.nat 176))])))
theorem pointRender128 : renderStmt 999 pointStmt128=some "((values[183])=expPositiveRaw((values[176])));" := by decide +kernel
def pointStmt129 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 184)) (.call (.var "mul") [(.index (.var "values") (.nat 182)),(.index (.var "values") (.nat 183))])))
theorem pointRender129 : renderStmt 999 pointStmt129=some "((values[184])=mul((values[182]),(values[183])));" := by decide +kernel
def pointStmt130 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 185)) (.call (.var "subExact") [(.index (.var "values") (.nat 165)),(.index (.var "values") (.nat 166))])))
theorem pointRender130 : renderStmt 999 pointStmt130=some "((values[185])=subExact((values[165]),(values[166])));" := by decide +kernel
def pointStmt131 : Stmt := (.eval (.binary "=" (.index (.var "values") (.nat 186)) (.call (.var "mul") [(.index (.var "values") (.nat 185)),(.index (.var "values") (.nat 171))])))
theorem pointRender131 : renderStmt 999 pointStmt131=some "((values[186])=mul((values[185]),(values[171])));" := by decide +kernel
def pointStmt132 : Stmt := (.eval (.binary "=" (.unary "*" (.var "outC")) (.index (.var "values") (.nat 184))))
theorem pointRender132 : renderStmt 999 pointStmt132=some "((*outC)=(values[184]));" := by decide +kernel
def pointStmt133 : Stmt := (.eval (.binary "=" (.unary "*" (.var "outD")) (.index (.var "values") (.nat 186))))
theorem pointRender133 : renderStmt 999 pointStmt133=some "((*outD)=(values[186]));" := by decide +kernel
def pointStatements : List Stmt := [pointStmt0,pointStmt1,pointStmt2,pointStmt3,pointStmt4,pointStmt5,pointStmt6,pointStmt7,pointStmt8,pointStmt9,pointStmt10,pointStmt11,pointStmt12,pointStmt13,pointStmt14,pointStmt15,pointStmt16,pointStmt17,pointStmt18,pointStmt19,pointStmt20,pointStmt21,pointStmt22,pointStmt23,pointStmt24,pointStmt25,pointStmt26,pointStmt27,pointStmt28,pointStmt29,pointStmt30,pointStmt31,pointStmt32,pointStmt33,pointStmt34,pointStmt35,pointStmt36,pointStmt37,pointStmt38,pointStmt39,pointStmt40,pointStmt41,pointStmt42,pointStmt43,pointStmt44,pointStmt45,pointStmt46,pointStmt47,pointStmt48,pointStmt49,pointStmt50,pointStmt51,pointStmt52,pointStmt53,pointStmt54,pointStmt55,pointStmt56,pointStmt57,pointStmt58,pointStmt59,pointStmt60,pointStmt61,pointStmt62,pointStmt63,pointStmt64,pointStmt65,pointStmt66,pointStmt67,pointStmt68,pointStmt69,pointStmt70,pointStmt71,pointStmt72,pointStmt73,pointStmt74,pointStmt75,pointStmt76,pointStmt77,pointStmt78,pointStmt79,pointStmt80,pointStmt81,pointStmt82,pointStmt83,pointStmt84,pointStmt85,pointStmt86,pointStmt87,pointStmt88,pointStmt89,pointStmt90,pointStmt91,pointStmt92,pointStmt93,pointStmt94,pointStmt95,pointStmt96,pointStmt97,pointStmt98,pointStmt99,pointStmt100,pointStmt101,pointStmt102,pointStmt103,pointStmt104,pointStmt105,pointStmt106,pointStmt107,pointStmt108,pointStmt109,pointStmt110,pointStmt111,pointStmt112,pointStmt113,pointStmt114,pointStmt115,pointStmt116,pointStmt117,pointStmt118,pointStmt119,pointStmt120,pointStmt121,pointStmt122,pointStmt123,pointStmt124,pointStmt125,pointStmt126,pointStmt127,pointStmt128,pointStmt129,pointStmt130,pointStmt131,pointStmt132,pointStmt133]
def pointTexts : List String := ["I values[187];","unsigned int j=0;","while((j<58)){((values[j])=(constantNodes[j]));\n(j=(j+1));}","((values[58])=t);","((values[59])=expPositiveRaw((values[58])));","((values[60])=mul((values[5]),(values[11])));","((values[61])=mul((values[60]),(values[40])));","((values[62])=divI(unit(),(values[38])));","((values[63])=mul((values[61]),(values[62])));","((values[64])=divI(unit(),(values[58])));","((values[65])=mul((values[38]),(values[64])));","((values[66])=add((values[0]),(values[65])));","((values[67])=mul((values[66]),(values[66])));","((values[68])=mul((values[38]),(values[41])));","((values[69])=mul((values[68]),(values[64])));","((values[70])=expPositiveRaw((values[69])));","((values[71])=mul((values[63]),(values[67])));","((values[72])=mul((values[71]),(values[70])));","((values[73])=mul((values[42]),(values[4])));","((values[74])=mul((values[73]),(values[37])));","((values[75])=divI(unit(),(values[74])));","((values[76])=mul((values[40]),(values[75])));","((values[77])=mul((values[4]),(values[64])));","((values[78])=add((values[0]),(values[77])));","((values[79])=mul((values[78]),(values[78])));","((values[80])=mul((values[76]),(values[79])));","((values[81])=mul((values[43]),(values[39])));","((values[82])=mul((values[58]),(values[58])));","((values[83])=divI(unit(),(values[82])));","((values[84])=mul((values[81]),(values[83])));","((values[85])=add((values[80]),(values[84])));","((values[86])=divI(unit(),(values[59])));","((values[87])=mul((values[78]),(values[86])));","((values[88])=mul((values[87]),(values[87])));","((values[89])=mul((values[26]),(values[88])));","((values[90])=expPositiveRaw((values[89])));","((values[91])=mul((values[85]),(values[5])));","((values[92])=mul((values[91]),(values[11])));","((values[93])=mul((values[92]),(values[86])));","((values[94])=add((values[72]),(values[93])));","((values[95])=mul((values[44]),(values[2])));","((values[96])=divI(unit(),(values[95])));","((values[97])=mul((values[94]),(values[96])));","((values[98])=mul((values[85]),(values[25])));","((values[99])=mul((values[45]),(values[2])));","((values[100])=mul((values[99]),(values[27])));","((values[101])=divI(unit(),(values[100])));","((values[102])=mul((values[98]),(values[101])));","((values[103])=add((values[97]),(values[102])));","((values[104])=mul((values[99]),(values[90])));","((values[105])=mul((values[104]),(values[103])));","((values[106])=mul((values[105]),(values[82])));","((values[107])=mul((values[5]),(values[5])));","((values[108])=divI(unit(),(values[107])));","((values[109])=mul((values[18]),(values[108])));","((values[110])=mul((values[49]),(values[64])));","((values[111])=add((values[109]),(values[110])));","((values[112])=mul((values[60]),(values[50])));","((values[113])=mul((values[112]),(values[64])));","((values[114])=mul((values[18]),(values[11])));","((values[115])=mul((values[5]),(values[59])));","((values[116])=divI(unit(),(values[115])));","((values[117])=mul((values[114]),(values[116])));","((values[118])=mul((values[60]),(values[49])));","((values[119])=mul((values[59]),(values[58])));","((values[120])=divI(unit(),(values[119])));","((values[121])=mul((values[118]),(values[120])));","((values[122])=add((values[113]),(values[117])));","((values[123])=add((values[122]),(values[121])));","((values[124])=mul((values[58]),(values[22])));","((values[125])=expPositiveRaw((values[124])));","((values[126])=mul((values[46]),(values[125])));","((values[127])=mul((values[126]),(values[58])));","((values[128])=divI(unit(),(values[127])));","((values[129])=mul((values[51]),(values[128])));","((values[130])=mul((values[1]),(values[64])));","((values[131])=mul((values[130]),(values[53])));","((values[132])=mul((values[54]),(values[83])));","((values[133])=add((values[52]),(values[131])));","((values[134])=add((values[133]),(values[132])));","((values[135])=mul((values[111]),(values[134])));","((values[136])=mul((values[123]),(values[24])));","((values[137])=add((values[135]),(values[136])));","((values[138])=mul((values[111]),(values[17])));","((values[139])=add((values[138]),(values[123])));","((values[140])=add((values[0]),(values[48])));","((values[141])=mul((values[140]),(values[137])));","((values[142])=divI(unit(),(values[48])));","((values[143])=add((values[0]),(values[142])));","((values[144])=mul((values[129]),(values[129])));","((values[145])=mul((values[143]),(values[144])));","((values[146])=mul((values[145]),(values[139])));","((values[147])=add((values[141]),(values[146])));","((values[148])=add((values[0]),(values[47])));","((values[149])=mul((values[127]),(values[127])));","((values[150])=mul((values[148]),(values[149])));","((values[151])=mul((values[150]),(values[119])));","((values[152])=mul((values[151]),(values[147])));","((values[153])=divI(unit(),(values[47])));","((values[154])=add((values[0]),(values[153])));","((values[155])=mul((values[154]),(values[59])));","((values[156])=mul((values[155]),(values[17])));","((values[157])=mul((values[59]),(values[59])));","((values[158])=mul((values[1]),(values[157])));","((values[159])=divI(unit(),(values[158])));","((values[160])=mul((values[2]),(values[159])));","((values[161])=expPositiveRaw((values[160])));","((values[162])=add((values[152]),(values[156])));","((values[163])=mul((values[1]),(values[161])));","((values[164])=mul((values[163]),(values[162])));","((values[165])=logPos((values[164])));","((values[166])=logPos((values[106])));","((values[167])=add((values[30]),(values[77])));","((values[168])=add((values[3]),(values[4])));","((values[169])=mul((values[168]),(values[64])));","((values[170])=add((values[55]),(values[169])));","((values[171])=divI(unit(),(values[167])));","((values[172])=mul((values[170]),(values[171])));","((values[173])=mul((values[172]),(values[165])));","((values[174])=subExact((values[0]),(values[172])));","((values[175])=mul((values[174]),(values[166])));","((values[176])=add((values[173]),(values[175])));","((values[177])=mul((values[35]),(values[36])));","((values[178])=mul((values[177]),(values[58])));","((values[179])=mul((values[1]),(values[5])));","((values[180])=mul((values[179]),(values[3])));","((values[181])=divI(unit(),(values[180])));","((values[182])=mul((values[178]),(values[181])));","((values[183])=expPositiveRaw((values[176])));","((values[184])=mul((values[182]),(values[183])));","((values[185])=subExact((values[165]),(values[166])));","((values[186])=mul((values[185]),(values[171])));","((*outC)=(values[184]));","((*outD)=(values[186]));"]
theorem pointBody_exact : Generated.f_pointHeight.body=.sequence pointStatements := by rfl
theorem pointMap : pointStatements.mapM (renderStmt 999)=some pointTexts := by
  simp only [pointStatements,pointTexts,List.mapM_cons,List.mapM_nil,pointRender0,pointRender1,pointRender2,pointRender3,pointRender4,pointRender5,pointRender6,pointRender7,pointRender8,pointRender9,pointRender10,pointRender11,pointRender12,pointRender13,pointRender14,pointRender15,pointRender16,pointRender17,pointRender18,pointRender19,pointRender20,pointRender21,pointRender22,pointRender23,pointRender24,pointRender25,pointRender26,pointRender27,pointRender28,pointRender29,pointRender30,pointRender31,pointRender32,pointRender33,pointRender34,pointRender35,pointRender36,pointRender37,pointRender38,pointRender39,pointRender40,pointRender41,pointRender42,pointRender43,pointRender44,pointRender45,pointRender46,pointRender47,pointRender48,pointRender49,pointRender50,pointRender51,pointRender52,pointRender53,pointRender54,pointRender55,pointRender56,pointRender57,pointRender58,pointRender59,pointRender60,pointRender61,pointRender62,pointRender63,pointRender64,pointRender65,pointRender66,pointRender67,pointRender68,pointRender69,pointRender70,pointRender71,pointRender72,pointRender73,pointRender74,pointRender75,pointRender76,pointRender77,pointRender78,pointRender79,pointRender80,pointRender81,pointRender82,pointRender83,pointRender84,pointRender85,pointRender86,pointRender87,pointRender88,pointRender89,pointRender90,pointRender91,pointRender92,pointRender93,pointRender94,pointRender95,pointRender96,pointRender97,pointRender98,pointRender99,pointRender100,pointRender101,pointRender102,pointRender103,pointRender104,pointRender105,pointRender106,pointRender107,pointRender108,pointRender109,pointRender110,pointRender111,pointRender112,pointRender113,pointRender114,pointRender115,pointRender116,pointRender117,pointRender118,pointRender119,pointRender120,pointRender121,pointRender122,pointRender123,pointRender124,pointRender125,pointRender126,pointRender127,pointRender128,pointRender129,pointRender130,pointRender131,pointRender132,pointRender133,Bind.bind,Option.bind,Pure.pure]
theorem compositional_render_pointHeight : renderFunction Generated.f_pointHeight=some "static void pointHeight(I t,I* outC,I* outD){I values[187];\nunsigned int j=0;\nwhile((j<58)){((values[j])=(constantNodes[j]));\n(j=(j+1));}\n((values[58])=t);\n((values[59])=expPositiveRaw((values[58])));\n((values[60])=mul((values[5]),(values[11])));\n((values[61])=mul((values[60]),(values[40])));\n((values[62])=divI(unit(),(values[38])));\n((values[63])=mul((values[61]),(values[62])));\n((values[64])=divI(unit(),(values[58])));\n((values[65])=mul((values[38]),(values[64])));\n((values[66])=add((values[0]),(values[65])));\n((values[67])=mul((values[66]),(values[66])));\n((values[68])=mul((values[38]),(values[41])));\n((values[69])=mul((values[68]),(values[64])));\n((values[70])=expPositiveRaw((values[69])));\n((values[71])=mul((values[63]),(values[67])));\n((values[72])=mul((values[71]),(values[70])));\n((values[73])=mul((values[42]),(values[4])));\n((values[74])=mul((values[73]),(values[37])));\n((values[75])=divI(unit(),(values[74])));\n((values[76])=mul((values[40]),(values[75])));\n((values[77])=mul((values[4]),(values[64])));\n((values[78])=add((values[0]),(values[77])));\n((values[79])=mul((values[78]),(values[78])));\n((values[80])=mul((values[76]),(values[79])));\n((values[81])=mul((values[43]),(values[39])));\n((values[82])=mul((values[58]),(values[58])));\n((values[83])=divI(unit(),(values[82])));\n((values[84])=mul((values[81]),(values[83])));\n((values[85])=add((values[80]),(values[84])));\n((values[86])=divI(unit(),(values[59])));\n((values[87])=mul((values[78]),(values[86])));\n((values[88])=mul((values[87]),(values[87])));\n((values[89])=mul((values[26]),(values[88])));\n((values[90])=expPositiveRaw((values[89])));\n((values[91])=mul((values[85]),(values[5])));\n((values[92])=mul((values[91]),(values[11])));\n((values[93])=mul((values[92]),(values[86])));\n((values[94])=add((values[72]),(values[93])));\n((values[95])=mul((values[44]),(values[2])));\n((values[96])=divI(unit(),(values[95])));\n((values[97])=mul((values[94]),(values[96])));\n((values[98])=mul((values[85]),(values[25])));\n((values[99])=mul((values[45]),(values[2])));\n((values[100])=mul((values[99]),(values[27])));\n((values[101])=divI(unit(),(values[100])));\n((values[102])=mul((values[98]),(values[101])));\n((values[103])=add((values[97]),(values[102])));\n((values[104])=mul((values[99]),(values[90])));\n((values[105])=mul((values[104]),(values[103])));\n((values[106])=mul((values[105]),(values[82])));\n((values[107])=mul((values[5]),(values[5])));\n((values[108])=divI(unit(),(values[107])));\n((values[109])=mul((values[18]),(values[108])));\n((values[110])=mul((values[49]),(values[64])));\n((values[111])=add((values[109]),(values[110])));\n((values[112])=mul((values[60]),(values[50])));\n((values[113])=mul((values[112]),(values[64])));\n((values[114])=mul((values[18]),(values[11])));\n((values[115])=mul((values[5]),(values[59])));\n((values[116])=divI(unit(),(values[115])));\n((values[117])=mul((values[114]),(values[116])));\n((values[118])=mul((values[60]),(values[49])));\n((values[119])=mul((values[59]),(values[58])));\n((values[120])=divI(unit(),(values[119])));\n((values[121])=mul((values[118]),(values[120])));\n((values[122])=add((values[113]),(values[117])));\n((values[123])=add((values[122]),(values[121])));\n((values[124])=mul((values[58]),(values[22])));\n((values[125])=expPositiveRaw((values[124])));\n((values[126])=mul((values[46]),(values[125])));\n((values[127])=mul((values[126]),(values[58])));\n((values[128])=divI(unit(),(values[127])));\n((values[129])=mul((values[51]),(values[128])));\n((values[130])=mul((values[1]),(values[64])));\n((values[131])=mul((values[130]),(values[53])));\n((values[132])=mul((values[54]),(values[83])));\n((values[133])=add((values[52]),(values[131])));\n((values[134])=add((values[133]),(values[132])));\n((values[135])=mul((values[111]),(values[134])));\n((values[136])=mul((values[123]),(values[24])));\n((values[137])=add((values[135]),(values[136])));\n((values[138])=mul((values[111]),(values[17])));\n((values[139])=add((values[138]),(values[123])));\n((values[140])=add((values[0]),(values[48])));\n((values[141])=mul((values[140]),(values[137])));\n((values[142])=divI(unit(),(values[48])));\n((values[143])=add((values[0]),(values[142])));\n((values[144])=mul((values[129]),(values[129])));\n((values[145])=mul((values[143]),(values[144])));\n((values[146])=mul((values[145]),(values[139])));\n((values[147])=add((values[141]),(values[146])));\n((values[148])=add((values[0]),(values[47])));\n((values[149])=mul((values[127]),(values[127])));\n((values[150])=mul((values[148]),(values[149])));\n((values[151])=mul((values[150]),(values[119])));\n((values[152])=mul((values[151]),(values[147])));\n((values[153])=divI(unit(),(values[47])));\n((values[154])=add((values[0]),(values[153])));\n((values[155])=mul((values[154]),(values[59])));\n((values[156])=mul((values[155]),(values[17])));\n((values[157])=mul((values[59]),(values[59])));\n((values[158])=mul((values[1]),(values[157])));\n((values[159])=divI(unit(),(values[158])));\n((values[160])=mul((values[2]),(values[159])));\n((values[161])=expPositiveRaw((values[160])));\n((values[162])=add((values[152]),(values[156])));\n((values[163])=mul((values[1]),(values[161])));\n((values[164])=mul((values[163]),(values[162])));\n((values[165])=logPos((values[164])));\n((values[166])=logPos((values[106])));\n((values[167])=add((values[30]),(values[77])));\n((values[168])=add((values[3]),(values[4])));\n((values[169])=mul((values[168]),(values[64])));\n((values[170])=add((values[55]),(values[169])));\n((values[171])=divI(unit(),(values[167])));\n((values[172])=mul((values[170]),(values[171])));\n((values[173])=mul((values[172]),(values[165])));\n((values[174])=subExact((values[0]),(values[172])));\n((values[175])=mul((values[174]),(values[166])));\n((values[176])=add((values[173]),(values[175])));\n((values[177])=mul((values[35]),(values[36])));\n((values[178])=mul((values[177]),(values[58])));\n((values[179])=mul((values[1]),(values[5])));\n((values[180])=mul((values[179]),(values[3])));\n((values[181])=divI(unit(),(values[180])));\n((values[182])=mul((values[178]),(values[181])));\n((values[183])=expPositiveRaw((values[176])));\n((values[184])=mul((values[182]),(values[183])));\n((values[185])=subExact((values[165]),(values[166])));\n((values[186])=mul((values[185]),(values[171])));\n((*outC)=(values[184]));\n((*outD)=(values[186]));}\n" := by
  have hb:=render_sequence_of_map pointMap
  rw [←pointBody_exact] at hb
  have hf:=render_function_of_body hb
  convert hf using 1
  decide +kernel
#print axioms compositional_render_pointHeight
end SynergyHeightC
