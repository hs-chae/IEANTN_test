import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt80 : renderStmt 999 FragmentData.pointStmt80=some "((values[135])=mul((values[111]),(values[134])));" := by decide +kernel
theorem render_pointStmt81 : renderStmt 999 FragmentData.pointStmt81=some "((values[136])=mul((values[123]),(values[24])));" := by decide +kernel
theorem render_pointStmt82 : renderStmt 999 FragmentData.pointStmt82=some "((values[137])=add((values[135]),(values[136])));" := by decide +kernel
theorem render_pointStmt83 : renderStmt 999 FragmentData.pointStmt83=some "((values[138])=mul((values[111]),(values[17])));" := by decide +kernel
theorem render_pointStmt84 : renderStmt 999 FragmentData.pointStmt84=some "((values[139])=add((values[138]),(values[123])));" := by decide +kernel
theorem render_pointStmt85 : renderStmt 999 FragmentData.pointStmt85=some "((values[140])=add((values[0]),(values[48])));" := by decide +kernel
theorem render_pointStmt86 : renderStmt 999 FragmentData.pointStmt86=some "((values[141])=mul((values[140]),(values[137])));" := by decide +kernel
theorem render_pointStmt87 : renderStmt 999 FragmentData.pointStmt87=some "((values[142])=divI(unit(),(values[48])));" := by decide +kernel
#print axioms render_pointStmt80
#print axioms render_pointStmt81
#print axioms render_pointStmt82
#print axioms render_pointStmt83
#print axioms render_pointStmt84
#print axioms render_pointStmt85
#print axioms render_pointStmt86
#print axioms render_pointStmt87
end SynergyHeightC
