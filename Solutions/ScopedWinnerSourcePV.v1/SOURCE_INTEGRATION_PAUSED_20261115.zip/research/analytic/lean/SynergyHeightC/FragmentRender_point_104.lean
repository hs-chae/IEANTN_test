import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt104 : renderStmt 999 FragmentData.pointStmt104=some "((values[159])=divI(unit(),(values[158])));" := by decide +kernel
theorem render_pointStmt105 : renderStmt 999 FragmentData.pointStmt105=some "((values[160])=mul((values[2]),(values[159])));" := by decide +kernel
theorem render_pointStmt106 : renderStmt 999 FragmentData.pointStmt106=some "((values[161])=expPositiveRaw((values[160])));" := by decide +kernel
theorem render_pointStmt107 : renderStmt 999 FragmentData.pointStmt107=some "((values[162])=add((values[152]),(values[156])));" := by decide +kernel
theorem render_pointStmt108 : renderStmt 999 FragmentData.pointStmt108=some "((values[163])=mul((values[1]),(values[161])));" := by decide +kernel
theorem render_pointStmt109 : renderStmt 999 FragmentData.pointStmt109=some "((values[164])=mul((values[163]),(values[162])));" := by decide +kernel
theorem render_pointStmt110 : renderStmt 999 FragmentData.pointStmt110=some "((values[165])=logPos((values[164])));" := by decide +kernel
theorem render_pointStmt111 : renderStmt 999 FragmentData.pointStmt111=some "((values[166])=logPos((values[106])));" := by decide +kernel
#print axioms render_pointStmt104
#print axioms render_pointStmt105
#print axioms render_pointStmt106
#print axioms render_pointStmt107
#print axioms render_pointStmt108
#print axioms render_pointStmt109
#print axioms render_pointStmt110
#print axioms render_pointStmt111
end SynergyHeightC
