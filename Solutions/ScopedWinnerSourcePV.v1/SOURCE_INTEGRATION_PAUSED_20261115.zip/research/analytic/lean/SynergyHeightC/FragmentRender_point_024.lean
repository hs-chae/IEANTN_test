import SynergyHeightC.FragmentData
namespace SynergyHeightC
open ScopedC.Syntax
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem render_pointStmt24 : renderStmt 999 FragmentData.pointStmt24=some "((values[79])=mul((values[78]),(values[78])));" := by decide +kernel
theorem render_pointStmt25 : renderStmt 999 FragmentData.pointStmt25=some "((values[80])=mul((values[76]),(values[79])));" := by decide +kernel
theorem render_pointStmt26 : renderStmt 999 FragmentData.pointStmt26=some "((values[81])=mul((values[43]),(values[39])));" := by decide +kernel
theorem render_pointStmt27 : renderStmt 999 FragmentData.pointStmt27=some "((values[82])=mul((values[58]),(values[58])));" := by decide +kernel
theorem render_pointStmt28 : renderStmt 999 FragmentData.pointStmt28=some "((values[83])=divI(unit(),(values[82])));" := by decide +kernel
theorem render_pointStmt29 : renderStmt 999 FragmentData.pointStmt29=some "((values[84])=mul((values[81]),(values[83])));" := by decide +kernel
theorem render_pointStmt30 : renderStmt 999 FragmentData.pointStmt30=some "((values[85])=add((values[80]),(values[84])));" := by decide +kernel
theorem render_pointStmt31 : renderStmt 999 FragmentData.pointStmt31=some "((values[86])=divI(unit(),(values[59])));" := by decide +kernel
#print axioms render_pointStmt24
#print axioms render_pointStmt25
#print axioms render_pointStmt26
#print axioms render_pointStmt27
#print axioms render_pointStmt28
#print axioms render_pointStmt29
#print axioms render_pointStmt30
#print axioms render_pointStmt31
end SynergyHeightC
