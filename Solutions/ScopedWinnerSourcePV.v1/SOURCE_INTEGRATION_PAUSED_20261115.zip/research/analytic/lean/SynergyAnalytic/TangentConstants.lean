import SynergyBasis.PositiveLog
namespace SynergyAnalytic.BoxModel
open ScopedNumerical ScopedNumerical.ProofBox SynergyBasis.Positive
/-- A computed initialization value, not a supplied numerical constant. -/
def ln2Computed : ProofBox := atanh2 (literal p 1 3)
-- Host evaluation is a proposal only; the following separate kernel replay
-- must certify its exact value before a numeric proof may reuse it.
#eval ln2Computed
end SynergyAnalytic.BoxModel
