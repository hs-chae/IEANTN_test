import SynergyAnalytic.LogPosModel
namespace SynergyAnalytic.BoxModel
open ScopedNumerical ScopedNumerical.ProofBox SynergyBasis.Positive
set_option autoImplicit false
set_option maxHeartbeats 0
/-- Exact source counter applicability: an accepted reduction with fuel384
never reaches the failing k>384 guard or wraps the unsigned counter. -/
theorem reduceLog_count_le (fuel:Nat) {a b:ProofBox} {k:Nat}
    (hr:reduceLog fuel a=some (b,k)) : k ≤ fuel := by
  induction fuel generalizing a b k with
  | zero =>
    by_cases hc:2*scale p < a.lo
    · simp [reduceLog,hc] at hr
    · simp only [reduceLog,hc,ite_false,Option.some.injEq,Prod.mk.injEq] at hr
      rcases hr with ⟨rfl,rfl⟩
      exact le_rfl
  | succ fuel ih =>
    by_cases hc:2*scale p < a.lo
    · cases hm:reduceLog fuel (divN a 2) with
      | none => simp [reduceLog,hc,hm] at hr
      | some pair =>
        rcases pair with ⟨m,j⟩
        simp only [reduceLog,hc,ite_true,hm,Option.bind_eq_bind,Option.bind_some,
          Option.pure_def,Option.some.injEq,Prod.mk.injEq] at hr
        rcases hr with ⟨rfl,rfl⟩
        exact Nat.succ_le_succ (ih hm)
    · simp only [reduceLog,hc,ite_false,Option.some.injEq,Prod.mk.injEq] at hr
      rcases hr with ⟨rfl,rfl⟩
      exact Nat.zero_le _
#print axioms reduceLog_count_le
end SynergyAnalytic.BoxModel
