import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem kernel_height_chunk11 : (List.range 64).all (fun j => cellCheck (j+704))=true := by decide +kernel
#print axioms kernel_height_chunk11
end SynergyAnalytic.HeightPoint
