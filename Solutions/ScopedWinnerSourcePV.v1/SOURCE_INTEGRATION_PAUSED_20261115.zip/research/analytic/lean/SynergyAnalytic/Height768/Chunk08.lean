import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem kernel_height_chunk08 : (List.range 64).all (fun j => cellCheck (j+512))=true := by decide +kernel
#print axioms kernel_height_chunk08
end SynergyAnalytic.HeightPoint
