import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem kernel_height_v3_chunk10 : (List.range 8).all (fun j => cellCheck (j+80))=true := by decide +kernel
#print axioms kernel_height_v3_chunk10
end SynergyAnalytic.HeightPoint
