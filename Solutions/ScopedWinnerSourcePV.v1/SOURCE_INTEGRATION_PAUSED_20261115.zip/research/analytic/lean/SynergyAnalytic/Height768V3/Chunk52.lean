import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem kernel_height_v3_chunk52 : (List.range 8).all (fun j => cellCheck (j+416))=true := by decide +kernel
#print axioms kernel_height_v3_chunk52
end SynergyAnalytic.HeightPoint
