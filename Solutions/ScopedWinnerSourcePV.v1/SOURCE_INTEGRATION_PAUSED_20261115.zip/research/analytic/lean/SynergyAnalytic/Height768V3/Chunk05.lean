import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem kernel_height_v3_chunk05 : (List.range 8).all (fun j => cellCheck (j+40))=true := by decide +kernel
#print axioms kernel_height_v3_chunk05
end SynergyAnalytic.HeightPoint
