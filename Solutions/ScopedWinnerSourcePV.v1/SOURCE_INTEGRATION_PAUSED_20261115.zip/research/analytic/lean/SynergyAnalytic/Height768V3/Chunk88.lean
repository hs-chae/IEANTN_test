import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem kernel_height_v3_chunk88 : (List.range 8).all (fun j => cellCheck (j+704))=true := by decide +kernel
#print axioms kernel_height_v3_chunk88
end SynergyAnalytic.HeightPoint
