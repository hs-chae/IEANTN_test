import SynergyAnalytic.TangentCompute
namespace SynergyAnalytic.BoxModel
open ScopedNumerical
set_option maxHeartbeats 0
set_option maxRecDepth 200000
/-- Exact one-cell mathematical model execution. The proposed words were
independently obtained from the actual instrumented C++ probe. This theorem
is ordinary kernel reduction, not C-source correspondence or a full J bound. -/
theorem one_cell_kernel_execution : sourceCell (rat 1 1) (rat 15 256) true =
    some (⟨15612252827742053649381042823221441126,
            15612252827742053649381042823221442792⟩,
          ⟨456760000209594070618427289453533713,
            456760000209594070618427289453541152⟩,
          ⟨17829998436654386643107959485841686,
            17829998436654386643107959485895915⟩) := by decide
#print axioms one_cell_kernel_execution
end SynergyAnalytic.BoxModel
