import SynergyAnalytic.HeightPointChecks
import SynergyAnalytic.PointCheckDecode
set_option pp.all true
#print SynergyAnalytic.HeightPoint.cellCheck
#print SynergyAnalytic.HeightPoint.genericPointCheck
#print SynergyAnalytic.HeightPoint.cellCheck.match_1
#print SynergyAnalytic.HeightPoint.genericPointCheck.match_1
