import SynergyAnalytic.ProfileMonotone
import SynergyAnalytic.CanonicalGrid
namespace SynergyAnalytic
open Real IEANTN WinnerOriginalScalars WinnerNewHeightSource WinnerDirectKernel
set_option maxHeartbeats 0

/-- Full propagation of the new varying PNT profile into an actual lower
count of primes in an interval, with no new analytic hypothesis. -/
theorem source_prime_rich_profile {a c D:ℕ→ℝ} {n:ℕ} {x:ℝ}
    (ha:Monotone a) (ha0:a 0=WinnerOriginalScalars.height) (han:a n=Real.exp 60)
    (hc:∀i<n,0 ≤ c i) (hD:∀i<n,0 ≤ D i)
    (h:PrimaryInputs (3681/10000) (3599/10000))
    (hcaps:UniversalBasisCaps (373/200) (1273/2000) (129/250)) (hcells:HeightCellCaps a c D n)
    (hCHJ:OriginalCHJSource) (hrvm:ZeroCount.v1.rvm_error_bound)
    (hsmall:ZeroCount.v1.rvm_error_small) (hlow:LowZeroes.v1.no_zeroes_below_first_ordinate)
    (hRH:RiemannHypothesisUpTo WinnerOriginalScalars.height) (hQRH:ZetaZeroFreeHalfPlane (7/8))
    (hx:Real.exp 330 ≤ x) :
    ((9/500:ℝ)/(1000001/1000000)-rayCoefficient a c D n (Real.log x)*(5001/5000+1))*
      x^((7:ℝ)/8)/Real.log x ≤ primeCounting (x+(9/500:ℝ)*x^((7:ℝ)/8))-primeCounting x := by
  have hA : 0<a 0 := by rw [ha0];norm_num [WinnerOriginalScalars.height]
  apply prime_rich_profile (rayCoefficient a c D n)
    (fun L hL=>rayCoefficient_nonneg ha hA hc hD L)
    (fun L hL K hK hLK=>rayCoefficient_antitone ha hA hc hD hLK) _ hx
  intro z hz
  simpa only [show (7/8:ℝ)-1= -1/8 by norm_num] using
    source_pi_profile_point ha ha0 han h hcaps hcells hCHJ hrvm hsmall hlow hRH hQRH hz

/-- A readable consequence of a completed0.00845 instance. This is a
conditional corollary, not a new numerical acceptance receipt. -/
theorem prime_rich_00845 (hp:HasPowerLogBound Eπ (169/20000) 0 (7/8) (Real.exp 330))
    {x:ℝ} (hx:Real.exp 330 ≤ x) :
    (109/100000:ℝ)*x^((7:ℝ)/8)/Real.log x ≤
      primeCounting (x+(9/500:ℝ)*x^((7:ℝ)/8))-primeCounting x := by
  have hx0 : 0<x := (Real.exp_pos 330).trans_le hx
  have hx1 : 1<x := (Real.one_lt_exp_iff.mpr (by norm_num : (0:ℝ)<330)).trans_le hx
  have hl : 0<Real.log x := Real.log_pos hx1
  have hh := prime_rich_parameter (by norm_num : (0:ℝ) ≤ 169/20000) hp hx hx
  have hc : (109/100000:ℝ) ≤ (9/500:ℝ)/(1000001/1000000)-(169/20000:ℝ)*(5001/5000+1) := by norm_num
  have hm := mul_le_mul_of_nonneg_right hc (show 0 ≤ x^((7:ℝ)/8)/Real.log x by positivity)
  apply LE.le.trans _ hh
  simpa only [mul_div_assoc] using hm

#print axioms source_prime_rich_profile
#print axioms prime_rich_00845
end SynergyAnalytic
