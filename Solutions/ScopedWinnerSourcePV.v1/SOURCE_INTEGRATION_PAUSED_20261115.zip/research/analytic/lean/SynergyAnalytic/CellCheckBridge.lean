import SynergyAnalytic.CellCheckMatchers
namespace SynergyAnalytic.HeightPoint
open ScopedNumerical
set_option maxHeartbeats 0
set_option maxRecDepth 20000
set_option linter.auxLemma false

def cellBody (seed:Option ProofBox) (evaluate:ProofBox→Option (List ProofBox))
    (cw dw:Option Int) (mi di:Nat) : Bool :=
  cellCheck.match_6 (fun _=>Bool) seed (fun _=>false) (fun t=>
    cellCheck.match_4 (fun _=>Bool) (evaluate t) (fun _=>false) (fun values=>
      cellCheck.match_1 (fun _ _ _ _=>Bool) values[mi]? values[di]? cw dw
        (fun c D cword dword=>decide (c.hi ≤ cword ∧ D.hi ≤ dword ∧ 0 ≤ dword))
        (fun _ _ _ _=>false)))

theorem cellBody_generic (seed:Option ProofBox) (evaluate:ProofBox→Option (List ProofBox))
    (cw dw:Option Int) (mi di:Nat) : cellBody seed evaluate cw dw mi di=genericPointCheck seed evaluate cw dw mi di := by
  unfold cellBody genericPointCheck
  rw [cellMatcher6_eq,cellMatcher4_eq,cellMatcher1_eq]

theorem cellCheck_body (i:Nat) : cellCheck i=
    cellBody (logCell (i+1)) (point constantValues) (cWords[i]?) (DWords[i]?) mainIndex slopeIndex := by rfl

theorem cellCheck_generic (i:Nat) : cellCheck i=
    genericPointCheck (logCell (i+1)) (point constantValues) (cWords[i]?) (DWords[i]?) mainIndex slopeIndex :=
  (cellCheck_body i).trans (cellBody_generic _ _ _ _ _ _)

#print axioms cellCheck_generic
end SynergyAnalytic.HeightPoint
