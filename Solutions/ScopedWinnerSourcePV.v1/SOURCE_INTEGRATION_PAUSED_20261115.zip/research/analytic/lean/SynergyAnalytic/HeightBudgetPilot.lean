import SynergyAnalytic.HeightBudgetBlocks
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem kernel_budget_block0 : blockCheck 0=true := by decide +kernel
#print axioms kernel_budget_block0
end SynergyAnalytic.HeightPoint
