import Mathlib
namespace SynergyAnalytic
open Real Set
set_option maxHeartbeats 0

noncomputable def expTwo (a u : ℝ) : ℝ := 1+a*u+a^2*u^2/2
noncomputable def logExpTwo (a u : ℝ) : ℝ := Real.log (expTwo a u)
noncomputable def logExpTwoD (a u : ℝ) : ℝ := (a+a^2*u)/(expTwo a u)

theorem expTwo_pos {a u : ℝ} (ha : 0 ≤ a) (hu : 0 ≤ u) : 0 < expTwo a u := by
  unfold expTwo
  positivity

theorem logExpTwo_hasDerivAt {a u : ℝ} (ha : 0 ≤ a) (hu : 0 ≤ u) :
    HasDerivAt (logExpTwo a) (logExpTwoD a u) u := by
  have hp : HasDerivAt (expTwo a) (a+a^2*u) u := by
    convert (((hasDerivAt_const u (1:ℝ)).add ((hasDerivAt_id u).const_mul a)).add
      ((((hasDerivAt_id u).pow 2).const_mul (a^2)).div_const 2)) using 1 <;>
      first | rfl | (norm_num [expTwo];ring)
  have hl := (Real.hasDerivAt_log (expTwo_pos ha hu).ne').comp u hp
  change HasDerivAt (fun x => Real.log (expTwo a x)) _ u
  convert hl using 1 <;> first | rfl | (simp only [logExpTwoD];ring)

theorem logExpTwoD_antitone {a : ℝ} (ha : 0 ≤ a) :
    AntitoneOn (logExpTwoD a) (Ici 0) := by
  intro u hu v hv huv
  unfold logExpTwoD
  apply (div_le_div_iff₀ (expTwo_pos ha hv) (expTwo_pos ha hu)).mpr
  have hu' : 0 ≤ u := hu
  have hv' : 0 ≤ v := hv
  have hd : 0 ≤ v-u := sub_nonneg.mpr huv
  have hn : 0 ≤ a^3/2*(v-u)*(u+v+a*u*v) := by positivity
  have hi : (a+a^2*u)*expTwo a v-(a+a^2*v)*expTwo a u =
      a^3/2*(v-u)*(u+v+a*u*v) := by unfold expTwo;ring
  linarith

theorem logExpTwo_concave {a : ℝ} (ha : 0 ≤ a) :
    ConcaveOn ℝ (Ici 0) (logExpTwo a) := by
  apply AntitoneOn.concaveOn_of_deriv (convex_Ici 0)
  · intro u hu
    exact (logExpTwo_hasDerivAt ha hu).continuousAt.continuousWithinAt
  · intro u hu
    exact (logExpTwo_hasDerivAt ha (interior_subset hu)).differentiableAt.differentiableWithinAt
  · intro u hu v hv huv
    rw [(logExpTwo_hasDerivAt ha (interior_subset hu)).deriv,
      (logExpTwo_hasDerivAt ha (interior_subset hv)).deriv]
    exact logExpTwoD_antitone ha (interior_subset hu) (interior_subset hv) huv

/-- A structural flattening inequality for a new polynomial-Gaussian kernel.
It does not assert the still-open new-window zeta L2 interpolation theorem. -/
theorem quadratic_window_log_lower {a u : ℝ} (ha : 0 ≤ a) (hu : 0 ≤ u) (hu1 : u ≤ 1) :
    u*Real.log (expTwo a 1) ≤ Real.log (expTwo a u) := by
  have hc := logExpTwo_concave ha
  have hh := hc.2 (show (0:ℝ) ∈ Ici 0 by norm_num) (show (1:ℝ) ∈ Ici 0 by norm_num)
    (show 0≤1-u by linarith) hu (by ring : (1-u)+u=1)
  simpa [smul_eq_mul,logExpTwo,expTwo] using hh

theorem quadratic_window_lower {a u : ℝ} (ha : 0 ≤ a) (hu : 0 ≤ u) (hu1 : u ≤ 1) :
    1 ≤ expTwo a u*Real.exp (-u*Real.log (expTwo a 1)) := by
  have hl := quadratic_window_log_lower ha hu hu1
  have he : 1 ≤ Real.exp (Real.log (expTwo a u)-u*Real.log (expTwo a 1)) :=
    Real.one_le_exp_iff.mpr (sub_nonneg.mpr hl)
  rw [Real.exp_sub,Real.exp_log (expTwo_pos ha hu)] at he
  simpa only [neg_mul,Real.exp_neg,div_eq_mul_inv] using he

#print axioms quadratic_window_lower
end SynergyAnalytic
