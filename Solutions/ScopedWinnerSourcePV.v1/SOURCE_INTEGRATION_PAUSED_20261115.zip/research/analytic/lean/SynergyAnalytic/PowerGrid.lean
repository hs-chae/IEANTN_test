import SynergyAnalytic.CanonicalGrid
namespace SynergyAnalytic
open Real WinnerOriginalScalars
set_option maxHeartbeats 0

/-- Nonuniform partition with a rational power index. The source casts i/n
to512-bit unsigned words BEFORE the products; the real mathematical grid is
unchanged by those checked representations. -/
noncomputable def powerHeightEdge (p n i:ℕ) : ℝ :=
  Real.exp (Real.log height+(60-Real.log height)*(i:ℝ)^p/(n:ℝ)^p)

theorem powerHeightEdge_monotone (p n:ℕ) : Monotone (powerHeightEdge p n) := by
  intro i j hij
  have hspan : 0 ≤ 60-Real.log height := by linarith [source_log_le32]
  unfold powerHeightEdge
  apply Real.exp_le_exp.mpr
  gcongr

theorem powerHeightEdge_zero {p:ℕ} (hp:0<p) (n:ℕ) : powerHeightEdge p n 0=height := by
  simp only [powerHeightEdge,Nat.cast_zero,zero_pow hp.ne',mul_zero,zero_div,add_zero]
  exact Real.exp_log (by norm_num [height])

theorem powerHeightEdge_last {p n:ℕ} (hn:0<n) : powerHeightEdge p n n=Real.exp 60 := by
  have hn0 : (n:ℝ)≠0 := by exact_mod_cast hn.ne'
  simp [powerHeightEdge,hn0]

theorem power_index_word_bound {i n p:ℕ} (hin:i ≤ n) (hn:n ≤ 65536) (hp:p ≤ 4) :
    i^p ≤ 2^64 := by
  calc
    i^p ≤ 65536^p := by gcongr;omega
    _ ≤ 65536^4 := Nat.pow_le_pow_right (by decide) hp
    _ = 2^64 := by norm_num

#print axioms powerHeightEdge_last
#print axioms power_index_word_bound
end SynergyAnalytic
