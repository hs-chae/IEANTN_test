import SynergyAnalytic.CanonicalGrid
namespace SynergyAnalytic
open Real WinnerOriginalScalars
set_option maxHeartbeats 0

/-- A reciprocal-mass allocation. The min extends the finite partition
constantly beyond its last index, so it satisfies the global monotonicity ABI. -/
noncomputable def logGridEnd : ℝ := Real.exp (-(60-Real.log height)/3)
noncomputable def logGridFraction (n i : ℕ) : ℝ := (min i n : ℕ)/(n:ℝ)
noncomputable def logGridSurvival (n i : ℕ) : ℝ :=
  1-logGridFraction n i*(1-logGridEnd)
noncomputable def logHeightEdge (n i : ℕ) : ℝ :=
  Real.exp (Real.log height-3*Real.log (logGridSurvival n i))

theorem logGridEnd_pos : 0 < logGridEnd := Real.exp_pos _
theorem logGridEnd_le_one : logGridEnd ≤ 1 := by
  unfold logGridEnd
  apply Real.exp_le_one_iff.mpr
  linarith [source_log_le32]

theorem logGridFraction_bounds (n i : ℕ) (hn : 0 < n) :
    0 ≤ logGridFraction n i ∧ logGridFraction n i ≤ 1 := by
  have hn0 : (0:ℝ) < n := by exact_mod_cast hn
  constructor
  · unfold logGridFraction;positivity
  · unfold logGridFraction
    apply (div_le_one hn0).mpr
    exact_mod_cast Nat.min_le_right i n

theorem logGridSurvival_bounds (n i : ℕ) (hn : 0 < n) :
    logGridEnd ≤ logGridSurvival n i ∧ logGridSurvival n i ≤ 1 := by
  have hf := logGridFraction_bounds n i hn
  have he := logGridEnd_le_one
  have hp := logGridEnd_pos
  unfold logGridSurvival
  constructor <;> nlinarith

theorem logHeightEdge_monotone (n : ℕ) (hn : 0 < n) :
    Monotone (logHeightEdge n) := by
  intro i j hij
  have hn0 : (0:ℝ) < n := by exact_mod_cast hn
  have hf : logGridFraction n i ≤ logGridFraction n j := by
    unfold logGridFraction
    apply div_le_div_of_nonneg_right _ hn0.le
    exact_mod_cast min_le_min_right n hij
  have hs : logGridSurvival n j ≤ logGridSurvival n i := by
    unfold logGridSurvival
    have he := logGridEnd_le_one
    nlinarith
  have hp : 0 < logGridSurvival n j :=
    logGridEnd_pos.trans_le (logGridSurvival_bounds n j hn).1
  have hl := Real.log_le_log hp hs
  unfold logHeightEdge
  apply Real.exp_le_exp.mpr
  linarith

theorem logHeightEdge_zero (n : ℕ) : logHeightEdge n 0 = height := by
  have hh : 0 < height := by norm_num [height]
  simp [logHeightEdge,logGridSurvival,logGridFraction,Real.exp_log hh]

theorem logHeightEdge_last (n : ℕ) (hn : 0 < n) :
    logHeightEdge n n = Real.exp 60 := by
  have hn0 : (n:ℝ) ≠ 0 := by exact_mod_cast hn.ne'
  have hs : logGridSurvival n n = logGridEnd := by
    simp [logGridSurvival,logGridFraction,hn0]
  rw [logHeightEdge,hs]
  unfold logGridEnd
  rw [Real.log_exp]
  congr 1
  ring

/-- The concrete source calls i<=n, where the clamp has no effect. Its
positive log(1/s) expression is exactly the same mathematical ordinate. -/
theorem logHeightEdge_source (n i : ℕ) (hin : i ≤ n) (hn : 0 < n) :
    logHeightEdge n i = Real.exp (Real.log height+
      3*Real.log ((1-(i:ℝ)/(n:ℝ)*(1-logGridEnd))⁻¹)) := by
  unfold logHeightEdge logGridSurvival logGridFraction
  rw [Nat.min_eq_left hin,Real.log_inv]
  congr 1
  ring

#print axioms logHeightEdge_monotone
#print axioms logHeightEdge_source
end SynergyAnalytic
