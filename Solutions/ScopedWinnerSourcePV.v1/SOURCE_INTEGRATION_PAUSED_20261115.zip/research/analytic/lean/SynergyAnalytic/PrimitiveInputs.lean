import Mathlib
namespace SynergyAnalytic
open Real
set_option maxHeartbeats 0

theorem pi_literal_input : (3141592653589793238/1000000000000000000:ℝ) ≤ Real.pi ∧
    Real.pi ≤ (3141592653589793239/1000000000000000000:ℝ) := by
  constructor <;> linarith [Real.pi_gt_d20,Real.pi_lt_d20]

/-- Endpoint tightening used by the new client. The input interval and endpoint
function enclosures must be supplied by actual verified program calls. -/
theorem exp_endpoint_enclosure {a b x lo hi:ℝ} (hax:a≤x) (hxb:x≤b)
    (hl:lo≤Real.exp a) (hh:Real.exp b≤hi) : lo≤Real.exp x ∧Real.exp x≤hi :=
  ⟨hl.trans (Real.exp_le_exp.mpr hax),(Real.exp_le_exp.mpr hxb).trans hh⟩

theorem log_endpoint_enclosure {a b x lo hi:ℝ} (ha:0<a) (hax:a≤x) (hxb:x≤b)
    (hl:lo≤Real.log a) (hh:Real.log b≤hi) : lo≤Real.log x ∧Real.log x≤hi :=
  ⟨hl.trans (Real.log_le_log ha hax),(Real.log_le_log (ha.trans_le hax) hxb).trans hh⟩

theorem sqrt_endpoint_of_squares {x lo hi:ℝ} (hx:0≤x) (hl:0≤lo) (hh:0≤hi)
    (hlo:lo^2≤x) (hhi:x≤hi^2) : lo≤Real.sqrt x ∧Real.sqrt x≤hi :=
  ⟨(Real.le_sqrt hl hx).2 hlo,(Real.sqrt_le_iff).2 ⟨hh,hhi⟩⟩

theorem cuberoot_endpoint_of_cubes {x lo hi:ℝ} (hx:0≤x) (hl:0≤lo) (hh:0≤hi)
    (hlo:lo^3≤x) (hhi:x≤hi^3) : lo≤x^((1:ℝ)/3) ∧x^((1:ℝ)/3)≤hi := by
  have he (y:ℝ) (hy:0≤y) : (y^3)^((1:ℝ)/3)=y := by
    rw [←Real.rpow_natCast_mul hy]
    norm_num
  have h1 := Real.rpow_le_rpow (pow_nonneg hl 3) hlo (by norm_num : (0:ℝ)≤1/3)
  have h2 := Real.rpow_le_rpow hx hhi (by norm_num : (0:ℝ)≤1/3)
  exact ⟨by simpa only [he lo hl] using h1,by simpa only [he hi hh] using h2⟩

#print axioms pi_literal_input
#print axioms log_endpoint_enclosure
#print axioms cuberoot_endpoint_of_cubes
end SynergyAnalytic
