import SynergyAnalytic.SourceCellMatchers
namespace SynergyAnalytic.HeightPoint
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.auxLemma false

theorem source_cell_decode {i:Nat} (h:cellCheck i=true) :
    ∃t values c D cword dword,
      logCell (i+1)=some t ∧ point constantValues t=some values ∧
      values[mainIndex]?=some c ∧ values[slopeIndex]?=some D ∧
      cWords[i]?=some cword ∧ DWords[i]?=some dword ∧
      c.hi ≤ cword ∧ D.hi ≤ dword ∧ 0 ≤ dword := by
  have houter := source_outer_decode (seed:=logCell (i+1))
    (f:=fun t=>cellCheck.match_4 (fun _=>Bool) (point constantValues t) (fun _=>false)
      (fun values=>cellCheck.match_1 (fun _ _ _ _=>Bool) values[mainIndex]? values[slopeIndex]? (cWords[i]?) (DWords[i]?)
        (fun c D cword dword=>decide (c.hi ≤ cword ∧ D.hi ≤ dword ∧ 0 ≤ dword))
        (fun _ _ _ _=>false))) h
  obtain ⟨t,ht,hm⟩:=houter
  have hmiddle := source_middle_decode (seed:=point constantValues t)
    (f:=fun values=>cellCheck.match_1 (fun _ _ _ _=>Bool) values[mainIndex]? values[slopeIndex]? (cWords[i]?) (DWords[i]?)
        (fun c D cword dword=>decide (c.hi ≤ cword ∧ D.hi ≤ dword ∧ 0 ≤ dword))
        (fun _ _ _ _=>false)) hm
  obtain ⟨vs,hv,hi⟩:=hmiddle
  obtain ⟨c,D,cw,dw,hc,hd,hcw,hdw,hineq⟩:=source_inner_decode
    (cm:=vs[mainIndex]?) (dm:=vs[slopeIndex]?) (cw:=cWords[i]?) (dw:=DWords[i]?) hi
  exact ⟨t,vs,c,D,cw,dw,ht,hv,hc,hd,hcw,hdw,hineq⟩

#print axioms source_cell_decode
end SynergyAnalytic.HeightPoint
