import SynergyAnalytic.HeightPointChecks
import SynergyAnalytic.PointCheckDecode
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 20000
set_option linter.auxLemma false

theorem cellMatcher6_eq : @cellCheck.match_6.{1} = @genericPointCheck.match_6.{1} := by rfl
theorem cellMatcher4_eq : @cellCheck.match_4.{1} = @genericPointCheck.match_4.{1} := by rfl
theorem cellMatcher1_eq : @cellCheck.match_1.{1} = @genericPointCheck.match_1.{1} := by rfl

#print axioms cellMatcher6_eq
#print axioms cellMatcher4_eq
#print axioms cellMatcher1_eq
end SynergyAnalytic.HeightPoint
