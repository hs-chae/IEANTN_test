import SynergyAnalytic.SourceReciprocal
import SynergyAnalytic.HeightEnvelope
import SynergyAnalytic.CoarseTwoThousand
namespace SynergyAnalytic
open Real Set MeasureTheory WinnerOriginalScalars WinnerNewHeightSource
set_option maxHeartbeats 0

/-- The output contract of the NEW whole-cell numerical constructor. Every
real height in each actual cell must satisfy both inequalities. These are
point-function residuals, not new analytic/density/moment premises. -/
def HeightCellCapsJ (j0 j1 j2 : ℝ) (a c D : ℕ→ℝ) (n : ℕ) : Prop := ∀i<n,∀T∈Icc (a i) (a (i+1)),
  continuousMain (3681/10000) (3599/10000) j0 j1 j2 (7/8) T ≤ c i ∧
    continuousSlope (3599/10000) j0 j1 j2 T ≤ D i

theorem universalBasisCaps_mono {a b c A B C:ℝ}
    (h:UniversalBasisCaps a b c) (ha:a ≤ A) (hb:b ≤ B) (hc:c ≤ C) :
    UniversalBasisCaps A B C := by
  intro x hx
  exact ⟨(h x hx).1.trans ha,(h x hx).2.1.trans hb,(h x hx).2.2.trans hc⟩

/-- Complete actual reciprocal-zero bound from the original8 source relations,
original RH height, three universal Jcaps, and certified whole-cell outputs.
The infinite height tail and source6log² boundary are discharged internally. -/
theorem source_reciprocal_profile_jflex {j0 j1 j2:ℝ} {a c D : ℕ→ℝ} {n : ℕ} {sigma T : ℝ}
    (ha : Monotone a) (ha0 : a 0=height) (han : a n=Real.exp 60)
    (h : PrimaryInputs (3681/10000) (3599/10000))
    (hcaps : UniversalBasisCaps j0 j1 j2)
    (h0:0 ≤ j0) (h1:0 ≤ j1) (h2:0 ≤ j2)
    (hj0:j0 ≤ 373/200) (hj1:j1 ≤ 1273/2000) (hj2:j2 ≤ 129/250)
    (hcells : HeightCellCapsJ j0 j1 j2 a c D n) (hRH : IEANTN.RiemannHypothesisUpTo height)
    (hs : (3/4:ℝ) ≤ sigma) (hs' : sigma ≤ 7/8) (hT : height ≤ T) :
    IEANTN.zetaZeroesSum (Ioo sigma 1) (Ioc 0 T) (fun rho=>1/rho.im) ≤
      reciprocalProfile a c D n sigma := by
  have hcell : ∀i<n,∀u∈Icc (a i) (a (i+1)),
      IEANTN.zetaZeroesSum (Ioo sigma 1) (Ioc 0 u) (fun _=>(1:ℝ)) ≤
        (c i*Real.exp (D i*((7/8)-sigma)))+6*Real.log u^2 := by
    intro i hin u hu
    have huH : height ≤ u := by rw [←ha0];exact (ha (Nat.zero_le i)).trans hu.1
    exact height_cell_actual_count h hcaps h0 h1 h2
      (by norm_num) (by norm_num) (by norm_num) hRH hs hs' huH
      (hcells i hin u hu).1 (hcells i hin u hu).2
  have h60 : height ≤ Real.exp (60:ℝ) := by
    calc
      height = Real.exp (Real.log height) := (Real.exp_log (by norm_num [height] : (0:ℝ)<height)).symm
      _ ≤ Real.exp 60 := Real.exp_le_exp.mpr (source_log_le32.trans (by norm_num))
  have hcoarse : ∀u,Real.exp 60 ≤ u →
      IEANTN.zetaZeroesSum (Ioo sigma 1) (Ioc 0 u) (fun _=>(1:ℝ)) ≤
        (2000:ℝ)*u^(8*(1-sigma)/3)*Real.log u^(5-2*sigma)+6*Real.log u^2 := by
    intro u hu
    exact source_coarse_density_closed h (universalBasisCaps_mono hcaps hj0 hj1 hj2) hRH hs hs' (h60.trans hu)
  have hh := actual_reciprocal_from_count_caps ha ha0 han (by norm_num : (0:ℝ) ≤ 2000)
    hRH hs hs' hT hcell hcoarse
  convert hh using 1
  unfold reciprocalProfile
  congr 2
  · apply Finset.sum_congr rfl
    intro i hin
    ring
  · norm_num

#print axioms source_reciprocal_profile_jflex
end SynergyAnalytic
