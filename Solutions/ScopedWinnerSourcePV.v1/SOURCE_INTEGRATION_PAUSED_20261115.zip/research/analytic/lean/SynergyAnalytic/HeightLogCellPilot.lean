import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem kernel_log_points : [0,1,400,767].all cellCheck=true := by decide +kernel
#print axioms kernel_log_points
end SynergyAnalytic.HeightPoint
