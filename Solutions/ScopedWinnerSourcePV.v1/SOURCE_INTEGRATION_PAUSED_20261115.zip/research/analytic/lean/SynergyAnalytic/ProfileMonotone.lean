import SynergyAnalytic.HeightProfile
import SynergyAnalytic.PrimeRich
namespace SynergyAnalytic
open Real Set MeasureTheory Finset IEANTN WinnerOriginalScalars WinnerNewHeightSource WinnerDirectKernel
set_option maxHeartbeats 0

theorem cell_weight_nonneg {a:ℕ→ℝ} (ha:Monotone a) (hA:0<a 0) (i:ℕ) :
    0 ≤ 1/a i-1/a (i+1) := by
  exact sub_nonneg.mpr (one_div_le_one_div_of_le (hA.trans_le (ha (Nat.zero_le i))) (ha (Nat.le_succ i)))

theorem profileCoefficient_antitone {a c D:ℕ→ℝ} {n:ℕ}
    (ha:Monotone a) (hA:0<a 0) (hc:∀i<n,0 ≤ c i) (hD:∀i<n,0 ≤ D i) :
    Antitone (profileCoefficient a c D n) := by
  intro L K hLK
  have hsum := finite_profile_antitone (Finset.range n) (fun i=>(1/a i-1/a (i+1))*c i) D
    (by norm_num : (0:ℝ) ≤ 1/8)
    (fun i hi=>mul_nonneg (cell_weight_nonneg ha hA i) (hc i (Finset.mem_range.mp hi)))
    (fun i hi=>hD i (Finset.mem_range.mp hi)) hLK
  have ht := pairedFactor_antitone (by norm_num : (0:ℝ) ≤ 160) (by norm_num : (0:ℝ) ≤ 1/8) hLK
  have hcount := pairedFactor_antitone (by norm_num : (0:ℝ) ≤ 880/3) (by norm_num : (0:ℝ) ≤ 1/8) hLK
  unfold profileCoefficient
  nlinarith

theorem rayCoefficient_antitone {a c D:ℕ→ℝ} {n:ℕ}
    (ha:Monotone a) (hA:0<a 0) (hc:∀i<n,0 ≤ c i) (hD:∀i<n,0 ≤ D i) :
    Antitone (rayCoefficient a c D n) := by
  intro L K hLK
  have hh := profileCoefficient_antitone ha hA hc hD hLK
  unfold rayCoefficient
  nlinarith

theorem rayCoefficient_nonneg {a c D:ℕ→ℝ} {n:ℕ}
    (ha:Monotone a) (hA:0<a 0) (hc:∀i<n,0 ≤ c i) (hD:∀i<n,0 ≤ D i) (L:ℝ) :
    0 ≤ rayCoefficient a c D n L := by
  have hs : 0 ≤ ∑i∈Finset.range n,((1/a i-1/a (i+1))*c i)*pairedFactor (D i) (1/8) L := by
    apply Finset.sum_nonneg
    intro i hi
    exact mul_nonneg (mul_nonneg (cell_weight_nonneg ha hA i) (hc i (Finset.mem_range.mp hi)))
      ((by norm_num : (0:ℝ) ≤ 1).trans (pairedFactor_ge_one (hD i (Finset.mem_range.mp hi)) (by norm_num)))
  have ht := pairedFactor_ge_one (D:=160) (L:=L) (by norm_num) (by norm_num : (0:ℝ) ≤ 1/8)
  have hcount := pairedFactor_ge_one (D:=880/3) (L:=L) (by norm_num) (by norm_num : (0:ℝ) ≤ 1/8)
  have hbase : 0 ≤ spectralBase 330 110 := by unfold spectralBase;positivity
  unfold rayCoefficient profileCoefficient
  nlinarith

#print axioms rayCoefficient_antitone
#print axioms rayCoefficient_nonneg
end SynergyAnalytic
