import SynergyAnalytic.BasisCertificate
namespace SynergyAnalytic
open Real Set
set_option maxHeartbeats 0

/-- A whole-real-cell upper bound, using the Gaussian at the left endpoint
and the increasing cube root at the right endpoint. This does not infer
monotonicity of their product or rely on samples. -/
theorem basis_zero_cell {left right x : ℝ}
    (hl : 0 ≤ left) (hx : x ∈ Icc left right) :
    baseWeight x ≤ Real.exp (-(601/2500:ℝ)*left^2)*right^((1:ℝ)/3) := by
  have hx0 : 0 ≤ x := hl.trans hx.1
  have hr0 : 0 ≤ right := hx0.trans hx.2
  have hg : Real.exp (-(601/2500:ℝ)*x^2) ≤ Real.exp (-(601/2500:ℝ)*left^2) :=
    Real.exp_le_exp.mpr (by nlinarith [sq_le_sq₀ hl hx0 |>.2 hx.1])
  have hp : x^((1:ℝ)/3) ≤ right^((1:ℝ)/3) :=
    Real.rpow_le_rpow hx0 hx.2 (by norm_num)
  exact mul_le_mul hg hp (by positivity) (Real.exp_pos _).le

theorem basis_one_cell {left right x : ℝ}
    (hl : 1 ≤ left) (hx : x ∈ Icc left right) :
    baseWeight x*Real.log x ≤
      (Real.exp (-(601/2500:ℝ)*left^2)*right^((1:ℝ)/3))*Real.log right := by
  have hx1 : 1 ≤ x := hl.trans hx.1
  have hr1 : 1 ≤ right := hx1.trans hx.2
  have hb := basis_zero_cell (by linarith) hx
  exact mul_le_mul hb (Real.log_le_log (by linarith) hx.2)
    (Real.log_nonneg hx1) (by positivity)

theorem basis_two_cell {left right x : ℝ}
    (hl : 1 ≤ left) (hx : x ∈ Icc left right) :
    baseWeight x*(Real.log x)^2 ≤
      (Real.exp (-(601/2500:ℝ)*left^2)*right^((1:ℝ)/3))*(Real.log right)^2 := by
  have hx1 : 1 ≤ x := hl.trans hx.1
  have hr1 : 1 ≤ right := hx1.trans hx.2
  have hb := basis_zero_cell (by linarith) hx
  have hlog : Real.log x ≤ Real.log right := Real.log_le_log (by linarith) hx.2
  exact mul_le_mul hb (pow_le_pow_left₀ (Real.log_nonneg hx1) hlog 2)
    (sq_nonneg _) (by positivity)

#print axioms basis_zero_cell
#print axioms basis_one_cell
#print axioms basis_two_cell
end SynergyAnalytic
