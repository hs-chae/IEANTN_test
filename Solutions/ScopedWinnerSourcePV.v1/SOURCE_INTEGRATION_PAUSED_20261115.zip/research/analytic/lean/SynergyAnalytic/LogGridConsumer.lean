import SynergyAnalytic.LogGrid
import SynergyAnalytic.SourcePrimeRich
namespace SynergyAnalytic
open Real IEANTN WinnerOriginalScalars WinnerNewHeightSource WinnerDirectKernel
set_option maxHeartbeats 0

/-- Exact output interpretation: unsigned512 words with scale2^128. No
computed vector or numerical acceptance is hidden in this definition. -/
noncomputable def logWordCoefficient (cWords dWords:ℕ→ℕ) (L:ℝ) : ℝ :=
  rayCoefficient (logHeightEdge 4096) (fun i=>wordValue (cWords i))
    (fun i=>wordValue (dWords i)) 4096 L

theorem logWordCoefficient_antitone (cWords dWords:ℕ→ℕ) :
    Antitone (logWordCoefficient cWords dWords) := by
  apply rayCoefficient_antitone (logHeightEdge_monotone 4096 (by norm_num))
    (by rw [logHeightEdge_zero];norm_num [height])
  · intro i hi;exact wordValue_nonneg _
  · intro i hi;exact wordValue_nonneg _

/-- The actual client-to-ANT contract. To obtain a numerical theorem, the
source-linked producer must prove hcaps and ALL4096 whole-cell inequalities.
Those proof obligations are explicit, not new source assumptions. -/
theorem log_grid_source_pi_profile (cWords dWords:ℕ→ℕ)
    (h:PrimaryInputs (3681/10000) (3599/10000))
    (hcaps:UniversalBasisCaps (373/200) (1273/2000) (129/250))
    (hcells:HeightCellCaps (logHeightEdge 4096) (fun i=>wordValue (cWords i))
      (fun i=>wordValue (dWords i)) 4096)
    (hCHJ:OriginalCHJSource) (hrvm:ZeroCount.v1.rvm_error_bound)
    (hsmall:ZeroCount.v1.rvm_error_small) (hlow:LowZeroes.v1.no_zeroes_below_first_ordinate)
    (hRH:RiemannHypothesisUpTo height) (hQRH:ZetaZeroFreeHalfPlane (7/8))
    {L:ℝ} (hL:330 ≤ L) :
    HasPowerLogBound Eπ (logWordCoefficient cWords dWords L) 0 (7/8) (Real.exp L) := by
  exact source_pi_profile_ray (logHeightEdge_monotone 4096 (by norm_num))
    (logHeightEdge_zero 4096) (logHeightEdge_last 4096 (by norm_num))
    h hcaps hcells hCHJ hrvm hsmall hlow hRH hQRH hL

/-- A new readable target supported by the unrestricted raw quadratic/log
scouts. It is conditional on an accepted0.00843 instance, not such an instance. -/
theorem prime_rich_00843 (hp:HasPowerLogBound Eπ (843/100000) 0 (7/8) (Real.exp 330))
    {x:ℝ} (hx:Real.exp 330 ≤ x) :
    (113/100000:ℝ)*x^((7:ℝ)/8)/Real.log x ≤
      primeCounting (x+(9/500:ℝ)*x^((7:ℝ)/8))-primeCounting x := by
  have hx0 : 0<x := (Real.exp_pos 330).trans_le hx
  have hx1 : 1<x := (Real.one_lt_exp_iff.mpr (by norm_num : (0:ℝ)<330)).trans_le hx
  have hl : 0<Real.log x := Real.log_pos hx1
  have hh := prime_rich_parameter (by norm_num : (0:ℝ) ≤ 843/100000) hp hx hx
  have hc : (113/100000:ℝ) ≤ (9/500:ℝ)/(1000001/1000000)-(843/100000:ℝ)*(5001/5000+1) := by norm_num
  have hm := mul_le_mul_of_nonneg_right hc (show 0 ≤ x^((7:ℝ)/8)/Real.log x by positivity)
  apply LE.le.trans _ hh
  simpa only [mul_div_assoc] using hm

#print axioms logWordCoefficient_antitone
#print axioms log_grid_source_pi_profile
#print axioms prime_rich_00843
end SynergyAnalytic
