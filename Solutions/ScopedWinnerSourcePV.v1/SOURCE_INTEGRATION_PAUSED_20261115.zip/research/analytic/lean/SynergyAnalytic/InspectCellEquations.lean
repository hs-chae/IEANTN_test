import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
#check cellCheck.eq_def
#check cellCheck.eq_1
#check cellCheck.eq_unfold
#check cellCheck.match_6.eq_1
#check cellCheck.match_6.eq_2
end SynergyAnalytic.HeightPoint
