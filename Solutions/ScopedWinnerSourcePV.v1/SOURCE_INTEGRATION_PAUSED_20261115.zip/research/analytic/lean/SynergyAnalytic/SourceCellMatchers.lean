import SynergyAnalytic.HeightPointChecks
namespace SynergyAnalytic.HeightPoint
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 20000
set_option linter.auxLemma false

theorem source_outer_decode {seed:Option ProofBox} {f:ProofBox→Bool}
    (h:cellCheck.match_6 (fun _=>Bool) seed (fun _=>false) f=true) :
    ∃t,seed=some t ∧ f t=true := by
  cases seed with
  | none => cases h
  | some t => exact ⟨t,rfl,h⟩

theorem source_middle_decode {seed:Option (List ProofBox)} {f:List ProofBox→Bool}
    (h:cellCheck.match_4 (fun _=>Bool) seed (fun _=>false) f=true) :
    ∃vs,seed=some vs ∧ f vs=true := by
  cases seed with
  | none => cases h
  | some vs => exact ⟨vs,rfl,h⟩

theorem source_inner_decode {cm dm:Option ProofBox} {cw dw:Option Int}
    (h:cellCheck.match_1 (fun _ _ _ _=>Bool) cm dm cw dw
      (fun c D cword dword=>decide (c.hi ≤ cword ∧ D.hi ≤ dword ∧ 0 ≤ dword))
      (fun _ _ _ _=>false)=true) :
    ∃c D cword dword,cm=some c ∧ dm=some D ∧ cw=some cword ∧ dw=some dword ∧
      c.hi ≤ cword ∧ D.hi ≤ dword ∧ 0 ≤ dword := by
  cases cm <;> cases dm <;> cases cw <;> cases dw <;>
    simp_all [cellCheck.match_1,cellCheck._sparseCasesOn_1,decide_eq_true_eq]

#print axioms source_outer_decode
#print axioms source_middle_decode
#print axioms source_inner_decode
end SynergyAnalytic.HeightPoint
