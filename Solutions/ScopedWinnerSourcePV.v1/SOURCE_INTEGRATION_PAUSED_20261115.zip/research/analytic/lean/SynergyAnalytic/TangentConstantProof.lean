import SynergyAnalytic.TangentConstants
namespace SynergyAnalytic.BoxModel
open ScopedNumerical ScopedNumerical.ProofBox SynergyBasis.Positive
set_option maxHeartbeats 0
set_option maxRecDepth 200000
/-- Kernel replay of the actual model initialization, not a numerical axiom
or a supplied implementation output. Reusable proof caching only. -/
theorem ln2_computed_exact : ln2Computed =
    ⟨235865763225513294137944142764154484360,
     235865763225513294137944142764154484523⟩ := by decide
#print axioms ln2_computed_exact
end SynergyAnalytic.BoxModel
