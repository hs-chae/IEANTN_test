import SynergyAnalytic.HeightPointGrid
namespace SynergyAnalytic.HeightPoint
open ScopedNumerical ScopedNumerical.ProofBox
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def firstCheck : Bool := match point constantValues (logGrid 1) with
  | none => false
  | some values => match values[mainIndex]?,values[slopeIndex]? with
    | some c,some D => decide (c.hi ≤ 1810165736314982604989661072062651985030433824466 ∧ D.hi ≤ 26330197984938616689333223591274632485115 ∧ 0 ≤ D.lo)
    | _,_ => false

theorem kernel_first_point : firstCheck=true := by decide +kernel
#print axioms kernel_first_point
end SynergyAnalytic.HeightPoint
