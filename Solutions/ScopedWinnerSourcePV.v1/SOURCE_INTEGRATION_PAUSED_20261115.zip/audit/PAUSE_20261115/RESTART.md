# Paused at the owner's request — 2026-11-15

This is a saved work checkpoint, not a completed research campaign or full source-first program-verification claim. Do not resume jobs until the owner asks.

## Completed

- Frozen Scoped Winner mathematical migration:106 compiled modules,42 selected unchanged theorem types, complete native-free closures;39 comparator identities and original8192/16384-cell algorithms/results preserved. This is kernel verification, separate from complete C PV.
- All768 bare C point executions are proved and consumed by SourceHeightPointsV2.PNT.source_pi_008441646 and source_prime_rich_017. The finite source-provider premise is discharged; the original eight PrimaryInputs fields and six separate analytic hypotheses remain.
- All768 C input-edge construction proofs passed, with3072 closure audits.
- All768 parametric C point executions in the canonical actual-main frame passed, for every accumulated total. SourceMainFramesV1.AllExecution.executions exports the exact same input/pair and full filled-state equality. SourceMainFramesV1.PNT.source_pi_008441646 and source_prime_rich_017 compiled through their actual source family in normal/-O/-OO CLI runs; all full closures are native-free.
- Frame campaign4246.228s payload/4247.584s scope, sampled charged peak159547240448B (a lower bound), maximum individual compiler RSS18350276608B, zero OOM. Original actual C and numerical algorithms unchanged.
- C390 source-cold component completed2024.409s under16GiB.52/68 original source bodies have accepted source-associated proofs. Source52 supplement is saved; its full fresh replay was interrupted at the owner's pause and is not complete.
- MainWeightModel compiled. An instrumented C reporting driver produced all768 weight terms and exactly reproduced the frozen original C total, but those proposals are explicitly untrusted until independent kernel checks and actual-main source linkage close.

## Stopped exactly here

- MainWeightFold v3 did not compile: block_add still has two normalization/rewrite goals. fold_shift and domain_of_block printed standard closures, but the module as a whole is FAILED; no object was installed. Preserve work/main-weight-fold-v1/v2/v3 and their source preimages. Do not consume compiler-generated sorryAx placeholders from these failures.
- Main-weight block00 numerical canary was interrupted after189.485s, LAUNCHER_SIGNAL_15, before any accepted block receipt. Last sampled charged memory17044103168B; recorded OOM counters0. It is an interrupted proof check, not numerical failure or OOM. No remaining23-block batch was started.
- New main input/point composition is accepted as a generic component; analytic's final all-edge wrapper failed on tactic indentation after all24 edge blocks passed. No fix was started after pause.
- The source-only composition capsule was being finalized; check its exact final receipt and helper-agent handoff. Prepared clean-source graphs are not executed clean replays.

## Resume order

1. Read current project memory/private restart handoff and the helper handoffs; poll directives. Inspect actual processes/cgroups, not old progress flags. Recheck separate RAM/disk capacities and aggregate300GiB reservation policy.
2. Correct the small all-edge aggregation wrapper and instantiate the accepted exact execution family in MainInputPointComposition; prove actual loop reachability/scoped state restoration, not merely a canonical frame shape.
3. Repair block_add by changing BOTH sides to the addCell fold before case analysis; the right-side anonymous fold currently prevents rewriting the saved fold equation. Finish block_eq_chunked, then independently kernel-check24 main-weight blocks/domains and derive the complete exact sum using those blocks. Preserve frozen-v1 and failed/interrupted receipts.
4. Close actual source guards, integer ranges, real C exponential weights/paired calculation, accumulation and main-loop/I/O. Actual C divI uses direct division (Positive.divI), not separately rounded multiplication by inverse. Do not assume bitwise equality with the earlier survival-to-sixth-power budget.
5. Resume fresh52 proof checking from verified source identities or run a fresh deterministic reproduction; finish the combined source-fresh source→ANT pipeline and final isolated verification. Current accepted host compositions are not namespace-isolated results.
6. Complete the remaining16 original bodies and actual preparation/evaluator/quadrature/main/printing path. Taylor's writable-to-readonly const-pointer call-site bridge was being completed; check the numerics handoff.
7. Complete the confirmatory matched exposure experiment, challengers, final campaign analysis/paper/evidence. Historical67/192 primary outcomes and eight exploratory outcomes remain unchanged; no causal discovery/PV-necessity conclusion is established. The stronger bound also has a kernel-only route.

All new work is supplemental. No optimality/best-known claim. The collaborator's Derivation material is untouched. Missing main (8).tex and skeleton.tex were not read or edited. Original research sources, locked inputs and accepted artifacts are preserved.
