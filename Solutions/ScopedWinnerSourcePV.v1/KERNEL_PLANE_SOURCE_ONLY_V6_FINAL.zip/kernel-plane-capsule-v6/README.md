# Complete fixed-grid numerical kernel plane

This source-only capsule preserves the original Scoped Winner numerical inputs and conclusions, including the 39 comparator identities, the original/evolved8192/16384 integration grids and the coefficient improvement0.009474458010474448→0.009471462010471452. It contains433 written application/library modules, exact input/parameter records and actual C proposal sources. All3840 numerical proof modules are regenerated, rather than stored as gigabytes of numerical arrays. Randomness is absent.

The host study actually completed all3840 chunk-closure audits and all10 unchanged whole-row predicates, covering122880cells. Every mathematical closure has only propext, Classical.choice and Quot.sound; no native execution axiom remains on this numerical plane. Acceptance of all3840 is identical in actual Python normal/-O/-OO runs. Essential receipts, source/claim identities, hashes and timing evidence are under evidence/.

This is **kernel-only mathematical verification**, not source-first PV. The C executable is an untrusted numerical proposer. Its exact outputs are checked by the subsequent Lean proofs; this does not prove the original C program's complete execution model/mathematical correspondence. The complete old C source-first chain remains unfinished. Its separately dated source-body supplement records the current accepted components and exact mathematical joins; these are not a whole-program/output-to-ANT claim. No optimality or best-known-result claim is made.

## Clean reproduction

Linux x86-64 requires Python3.10+, Git, tar/zstd, GCC11 system headers, user systemd/cgroups and bubblewrap. The pinned Lean4.34.0-rc2 release and eight public generic package commits are in environment-bootstrap/ENVIRONMENT.lock.json and SOURCE_LOCK.json. Compiler/kernel/shared-runtime/stdlib/header hashes are checked, rather than identifying Lean by its launcher alone.

1. Bootstrap only the public compiler/library dependencies into a fresh directory:

```
python3 environment-bootstrap/scripts/bootstrap.py --work /absolute/fresh/public-environment --receipt /absolute/fresh/PUBLIC_ENVIRONMENT.json
```

The bootstrap downloads the exact official580281129-byte Lean archive and verifies SHA-2563d011041203acacf300d343a39673f7d233743397993797c941346ae9e5df1a8, fetches the exact public Mathlib/dependency commits and obtains their public generic caches. It imports no old application object. A pre-existing approved public environment can instead be checked with prepare_environment.py.

2. Run a read-only source/environment preflight:

```
python3 reproduce.py --environment /absolute/fresh/PUBLIC_ENVIRONMENT.json --out /absolute/fresh/run
```

3. Check actual host RAM and free disk separately. The supplied resource launcher enforces the same300GiB aggregate study budget and host reserves. A full replay uses a256GiB memory scope, no swap and24CPUs; its conservative chunk scheduler admits at most14 jobs. Keep other admitted study scopes within the remaining44GiB. The example keeps generated run artifacts under this capsule's runs/ directory so the shared resource launcher measures that scratch usage; public dependency preparation is separately recorded. The launcher fails closed if host headroom or disk allowance is insufficient.

```
python3 scripts/resource_scope.py --family root_generic --memory-gib 256 --cpus 24 --wall 86400 --out resources/MY_FRESH_RESOURCE_RECEIPT -- python3 isolated_replay.py --environment /absolute/fresh/PUBLIC_ENVIRONMENT.json --out runs/MY_FRESH_ISOLATED_RUN --jobs 14 --run
```

When resuming inside the parent study, use the parent's shared resource launcher/registry, so other ongoing study runs are counted. The isolated launcher exposes only immutable capsule sources, pinned public generic dependencies and one fresh writable output. Earlier application objects and network access are absent. If namespace isolation is unavailable it stops; it never silently falls back.

The pipeline compiles the actual frozen C proposal programs, regenerates all numerical words, checks their original hashes, streams them into all3840 exact original Lean sources, compares every source hash, builds the full written dependency closure using only public generic objects, executes every kernel proof, audits all3840 chunk closures and all10 whole rows, compiles all remaining consumer modules and separately audits the comparison theorem. It compares all42 original consumer declaration types with their actual frozen baseline types. The final mathematical assumptions, constants, algorithms, nodes, depths and threshold interval e³³⁰≤x≤e³³¹ remain fixed.

4. Require both run/RECEIPT.json with PASS_FRESH_SOURCE_KERNEL_ALL3840_ALL10_FINAL_CONSUMERS_NATIVE0 and ISOLATION_RECEIPT.json with PASS_NAMESPACE_ISOLATED_FRESH_KERNEL_REPLAY. Partial progress and failures are preserved. The full fresh replay of this newly packaged capsule has **not yet been executed** merely because the historical host study passed.

## Storage and trust

After a complete accepted replay, preview `python3 cleanup.py --run-directory /absolute/fresh/isolated-run/run`, then add --apply to remove only verified-regenerable raw C traces/binaries. All input/source, generated Lean proof source, accepted proof objects, receipts, hashes and final consumer evidence remain. Cleanup refuses incomplete runs and unrelated targets. No cleanup is performed on another workspace.

The compiler, Lean kernel/public generic library objects, core Nat runtime used by the untrusted proposer, operating system/API and hardware remain explicit trust boundaries. Pure kernel validation does not establish source-first C execution correctness. The separate compiler-order canary is bounded implementation-contract evidence, not a compiler theorem. Source-first program migration, final source-cold replay acceptance and experimental exposure conclusions have separate completion gates.
