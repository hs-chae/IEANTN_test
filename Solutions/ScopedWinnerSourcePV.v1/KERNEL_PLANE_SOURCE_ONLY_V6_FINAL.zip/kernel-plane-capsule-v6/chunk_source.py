def word(lo,hi,ok):return f'(Fast.words100 ({lo}) ({hi}) (by decide),{str(bool(ok)).lower()})'

def source(record,start,cells,upper,module):
 typ=f'InputData.Fact{record["fact_index"]}Row{record["row_index"]}'
 lines=['/- Exact fixed-input node transcripts; generated proposals are kernel checked. -/',
 'import ScopedNumerical.PointPrimitive','import ScopedNumerical.PrimitiveChunks',
 'import ScopedNumerical.GridMemo','import ScopedNumerical.WordInterval','import ScopedNumerical.'+typ,
 'namespace '+module,'open LeanCert.Core LeanCert.Engine',
 'set_option maxRecDepth 200000','set_option maxHeartbeats 0']
 for k,values in enumerate(cells):
  literals=[word(*v)for v in values]
  lines += [f'def cell{k} : List LocalTranscript.Record := [']
  for i,n in enumerate(record['instructions']):
   aa=literals[n[1]]if n[1]<i else word(0,0,1);bb=literals[n[2]]if n[2]<i else word(0,0,1)
   lines.append(f' ⟨{aa},{bb},{literals[i]}⟩'+(','if i+1<len(values)else''))
  lines += [']',f'theorem cell{k}_checked : PrimitiveTranscript.checkRun RefinementCache.ctx24',
   '    (PointFast.primitive RefinementCache.ctx24 GridMemo.entries)',
   f'    (sumBodyEnvSimple {start+k} (-100)) {typ}.nodes cell{k}=true := by',
   '  decide +kernel']
 lines += ['def cells : List (List LocalTranscript.Record) := ['+','.join('cell'+str(k)for k in range(len(cells)))+']',
 f'theorem checked : Dag.checkUpper {typ}.nodes {start} {start+len(cells)-1}',
 f'    (mkRat ({upper}) (2^100)) {typ}.cfg=true := by',
 '  have hc := Refinement.prepare_sound (Or.inl rfl : 24=24∨24=32) RefinementCache.prepared24_exact',
 '  have hp := PointFast.primitive_sound hc.1 GridMemo.entries_valid',
 '  apply PrimitiveTranscript.checkChunk_sound hp (cells := cells) (by simp [cells])',
 '  apply Bool.and_eq_true_iff.mpr','  constructor',
 '  · simp only [PrimitiveTranscript.checkTerms,cells]\n    norm_num only\n    simp only ['+','.join('cell'+str(k)+'_checked'for k in range(len(cells)))+',Bool.true_and]',
 '  · decide +kernel','end '+module]
 return '\n'.join(lines)+'\n'
