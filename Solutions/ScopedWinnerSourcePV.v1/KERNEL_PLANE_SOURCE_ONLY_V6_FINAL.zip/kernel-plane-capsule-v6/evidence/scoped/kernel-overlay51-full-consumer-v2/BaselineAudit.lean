import ScopedWinnerA
import ScopedWinnerA.Sensitivity
import Main
import ScopedWinnerA.Assembly
import ScopedWinnerA.Certificate
import ScopedWinnerA.Comparison
import ScopedWinnerA.Coverage
import ScopedWinnerA.Envelope
import ScopedWinnerA.Mapped
import ScopedWinnerA.Registered
import ScopedWinnerA.Result
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxHeartbeats 0
run_elab do
 let env ← getEnv
 for n in ([`ScopedWinnerA.pi_00947147,`ScopedWinnerA.pi_refined_exact,`WinnerDensityA.HeightRHFinal.source_pi_refined_exact,`ScopedWinnerA.incumbent_valid,`ScopedWinnerA.subnetwork_snapshot_winner,`ScopedWinnerA.Coverage.winner,`ScopedWinnerA.Comparison.scoped_strict,`ScopedWinnerA.Comparison.registered_output_restriction,`ScopedWinnerA.Coverage.envelope_exact,`ScopedWinnerA.Sensitivity.coefficient_bound,`main,`ScopedWinnerA.every_old_valid,`ScopedWinnerA.Certificate.bounds,`ScopedWinnerA.Certificate.program,`ScopedWinnerA.Certificate.checked,`ScopedWinnerA.Certificate.coefficient300,`ScopedWinnerA.Comparison.oldExact,`ScopedWinnerA.Comparison.newCap,`ScopedWinnerA.Comparison.scale,`ScopedWinnerA.Comparison.domain,`ScopedWinnerA.Comparison.logs,`ScopedWinnerA.Comparison.scale_eq,`ScopedWinnerA.Comparison.standard_curve,`ScopedWinnerA.Comparison.classical3,`ScopedWinnerA.Comparison.numeric_tiny,`ScopedWinnerA.Comparison.power_floor,`ScopedWinnerA.Comparison.strict_increment,`ScopedWinnerA.Comparison.log2_power,`ScopedWinnerA.Coverage.slot,`ScopedWinnerA.Coverage.allowance,`ScopedWinnerA.Coverage.envelope,`ScopedWinnerA.Coverage.alias_values,`ScopedWinnerA.Comparison.incumbent,`ScopedWinnerA.Comparison.oldEnvelope,`ScopedWinnerA.Comparison.incumbent_lower,`ScopedWinnerA.Comparison.old_envelope_exact,`ScopedWinnerA.mapped_snapshot_winner,`ScopedWinnerA.Comparison.registeredContract,`ScopedWinnerA.Comparison.absolute_to_normalized,`ScopedWinnerA.Sensitivity.scenarios,`ScopedWinnerA.Sensitivity.accepted,`ScopedWinnerA.Sensitivity.checked] : List Name) do
  let some ci := env.find? n | throwError "missing {n}"
  let ax ← Lean.collectAxioms n
  logInfo m!"FULL51_AUDIT {(Json.mkObj [("name",toJson n.toString),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"
