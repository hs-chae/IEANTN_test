#!/usr/bin/env python3
"""Remove only checked regeneration-selftest duplicates; protect original proofs."""
from pathlib import Path
import argparse,hashlib,json,os
R=Path(__file__).resolve().parents[2]
BASE=R/'scoped/numerical/kernel-capsule-regeneration-selftest-v5'
def need(x,m):
 if not x:raise ValueError(m)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--apply',action='store_true');a=ap.parse_args();planpath=R/'scoped/numerical/KERNEL_CAPSULE_SELFTEST_CLEANUP_PLAN_V5.json';plan=json.loads(planpath.read_text());receipt=BASE/'RECEIPT.json';need(sha(receipt)==plan['selftest_receipt_sha256']and json.loads(receipt.read_text())['status']=='PASS_FRESH_C_ALL10_ALL3840_SOURCE_REGEN_NORMAL_O_OO','complete checked selftest')
 original=json.loads((R/'scoped/numerical/grid-node-all3840-v1/PLAN.json').read_text())['plans'];originals={str(Path(x['module'].replace('.','/')).with_suffix('.lean')):x for x in original};need(len(originals)==3840,'original sources protected')
 for r in plan['targets']:
  p=R/r['path'];need(p.resolve()==p and p.is_file()and not p.is_symlink()and BASE in p.parents,'owned ordinary selftest target');need(p.stat().st_size==r['bytes']and sha(p)==r['sha256'],'target unchanged')
  rel=p.relative_to(BASE);parts=rel.parts
  if parts[0].startswith('generated-'):
   need(parts[0]in ['generated-normal','generated-optimized','generated-docstripped']and parts[1]=='source','generated duplicate only');key=str(Path(*parts[2:]));need(key in originals,'known exact generated source');old=Path(originals[key]['source']);need(sha(old)==r['sha256']==originals[key]['source_sha256'],'retained original accepted source')
  else:need(parts[0]=='numerical-data'and len(parts)==3 and parts[2]in ['proposal','run.stdout'],'known C proposer temporary')
 print('VERIFIED_TARGETS',len(plan['targets']),'BYTES',plan['bytes'])
 if not a.apply:return
 out=R/'scoped/numerical/KERNEL_CAPSULE_SELFTEST_CLEANUP_RECEIPT_V5.json';need(not out.exists(),'fresh cleanup receipt')
 for r in plan['targets']:
  p=R/r['path'];need(p.stat().st_size==r['bytes']and sha(p)==r['sha256'],'no deletion race');p.unlink()
 for mode in ['normal','optimized','docstripped']:
  root=BASE/('generated-'+mode)/'source'
  for p in sorted(root.rglob('*'),key=lambda p:len(p.parts),reverse=True):
   if p.is_dir():p.rmdir()
  root.rmdir()
 data={'status':'PASS_VERIFIED_REGENERABLE_SELFTEST_DUPLICATES_REMOVED','targets':len(plan['targets']),'bytes_removed':plan['bytes'],'plan_sha256':sha(planpath),'selftest_receipt_sha256':sha(receipt),'retained':'All original sources, original locked data, accepted proof artifacts, self-contained regeneration scripts, exact source/trace hashes, numerical/kernel/consumer receipts and selftest logs/timings.'};tmp=out.with_suffix('.pending');tmp.write_text(json.dumps(data,indent=2)+'\n');os.replace(tmp,out);print(data['status'])
if __name__=='__main__':main()
