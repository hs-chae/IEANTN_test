import ScopedNumerical.GridChunks.Fact6Row0.Chunk0105
import ScopedNumerical.GridChunks.Fact7Row0.Chunk0105
import ScopedNumerical.GridChunks.Fact8Row0.Chunk0105
import ScopedNumerical.GridChunks.Fact9Row0.Chunk0105
import ScopedNumerical.GridChunks.Fact0Row1.Chunk0106
import ScopedNumerical.GridChunks.Fact10Row0.Chunk0106
import ScopedNumerical.GridChunks.Fact1Row1.Chunk0106
import ScopedNumerical.GridChunks.Fact3Row0.Chunk0106
import ScopedNumerical.GridChunks.Fact4Row0.Chunk0106
import ScopedNumerical.GridChunks.Fact5Row0.Chunk0106
import ScopedNumerical.GridChunks.Fact6Row0.Chunk0106
import ScopedNumerical.GridChunks.Fact7Row0.Chunk0106
import ScopedNumerical.GridChunks.Fact8Row0.Chunk0106
import ScopedNumerical.GridChunks.Fact9Row0.Chunk0106
import ScopedNumerical.GridChunks.Fact0Row1.Chunk0107
import ScopedNumerical.GridChunks.Fact10Row0.Chunk0107
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxHeartbeats 0
run_elab do
 let env ← getEnv
 for n in ([`ScopedNumerical.GridChunks.Fact6Row0.Chunk0105.checked,`ScopedNumerical.GridChunks.Fact7Row0.Chunk0105.checked,`ScopedNumerical.GridChunks.Fact8Row0.Chunk0105.checked,`ScopedNumerical.GridChunks.Fact9Row0.Chunk0105.checked,`ScopedNumerical.GridChunks.Fact0Row1.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact10Row0.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact1Row1.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact3Row0.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact4Row0.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact5Row0.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact6Row0.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact7Row0.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact8Row0.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact9Row0.Chunk0106.checked,`ScopedNumerical.GridChunks.Fact0Row1.Chunk0107.checked,`ScopedNumerical.GridChunks.Fact10Row0.Chunk0107.checked] : List Name) do
  let some ci := env.find? n | throwError "missing checked target {n}"
  let axioms ← Lean.collectAxioms n
  logInfo m!"GRID_CLOSURE {(Json.mkObj [("name",toJson n.toString),("type_repr",toJson (reprStr ci.type)),("top_forall",toJson ci.type.isForall),("axioms",toJson (axioms.toList.map Name.toString))]).compress}"
