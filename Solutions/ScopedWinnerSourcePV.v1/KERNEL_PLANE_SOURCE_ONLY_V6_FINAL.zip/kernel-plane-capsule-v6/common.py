from pathlib import Path
import hashlib,json,math,os,tempfile
B=Path(__file__).resolve().parent
STD3={'propext','Classical.choice','Quot.sound'}
def need(p,m):
 if not p:raise ValueError(m)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def load(p):
 def pairs(xs):
  d={}
  for k,v in xs:need(k not in d,'duplicate JSON key');d[k]=v
  return d
 def finite(s):
  v=float(s);need(math.isfinite(v),'nonfinite JSON');return v
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_float=finite,parse_constant=lambda s:(_ for _ in()).throw(ValueError(s)))
def atomic(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);fd,n=tempfile.mkstemp(prefix='.'+p.name+'.',dir=p.parent)
 try:
  with os.fdopen(fd,'w')as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n')
  os.replace(n,p)
 finally:
  if Path(n).exists():Path(n).unlink()
def source_check():
 manifest=load(B/'HASHES.json')
 for r in manifest['files']:
  p=B/r['path'];need(p.is_file()and not p.is_symlink()and p.stat().st_size==r['bytes']and sha(p)==r['sha256'],'capsule file drift '+r['path'])
 return load(B/'SOURCE_LOCK.json')
