#!/usr/bin/env python3
"""Preview/remove only regenerated C-proposer binaries/traces after full acceptance."""
from pathlib import Path
import argparse
from common import B,need,load,sha,atomic,source_check

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--run-directory',type=Path,required=True);ap.add_argument('--apply',action='store_true');a=ap.parse_args();source_check();r=a.run_directory.resolve();need(r.is_dir()and not r.is_symlink(),'actual experiment run directory');marker=load(r/'OWNED_NUMERICAL_KERNEL_REPLAY.json');need(marker['capsule_sha256']==sha(B/'SOURCE_LOCK.json'),'owned exact-capsule replay');rec=load(r/'RECEIPT.json');need(rec['status']=='PASS_FRESH_SOURCE_KERNEL_ALL3840_ALL10_FINAL_CONSUMERS_NATIVE0','complete accepted replay required');need(load(r/'generated-chunks/RECEIPT.json')['status']=='PASS_ALL3840_REGENERATED_ORIGINAL_SOURCE_HASHES','checked regeneration required')
 targets=[]
 for p in (r/'numerical-data').iterdir():
  if not p.is_dir():continue
  for n in ['proposal','run.stdout']:
   f=p/n
   if f.exists():need(f.is_file()and not f.is_symlink()and f.resolve().is_relative_to(r/'numerical-data'),'owned ordinary temporary file');targets.append({'path':str(f.relative_to(r)),'bytes':f.stat().st_size,'sha256':sha(f)})
 report={'status':'PREVIEW_ONLY'if not a.apply else'APPLIED_VERIFIED_REGENERABLE_C_PROPOSER_TEMPORARIES_ONLY','targets':targets,'bytes':sum(x['bytes']for x in targets),'retained':'All original inputs/source, generated Lean proof source, accepted proof objects, numerical/proof/verification receipts, hashes, timings, final consumers and essential evidence.'}
 if a.apply:
  need(not(r/'CLEANUP_RECEIPT.json').exists(),'fresh cleanup receipt')
  for x in targets:
   f=r/x['path'];need(f.stat().st_size==x['bytes']and sha(f)==x['sha256'],'cleanup target changed');f.unlink()
  atomic(r/'CLEANUP_RECEIPT.json',report)
 else:print(report)
if __name__=='__main__':main()
