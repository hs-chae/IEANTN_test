# Actual C evaluator-prefix and source-helper proof component

This freezes 46 accepted controls-side source modules with 115 selected complete Std3 theorem closures, including the earlier actual decimal parser and all66 computed global initializers, the complete actual fromS body, and actual evaluator count/while guards, readonly Node memory reads and typed declaration, leading-byte sign test, bounded num+negative pointer, complete decimal source execution and real magnitude declaration.

The 387-source capsule contains every actual application import and all885 byte-exact include_str payloads needed to rebuild those selected statements. Its existence is **not** acceptance of a new full source-cold replay. All46 individual host module builds passed. The earlier33-module capsule and every historical result remain unchanged.

The actual evaluate AST is decomposed by kernel-checked rfl equalities. Its proved literal prefix consumes actual initialized source bytes and closes every parser service call through the complete installed C decimal body. No desired evaluator result, parser-success flag, initial application representation or application-name runtime oracle is a premise. The pool, source buffer and stack applicability are explicit and proved through actual initialization/framing where connected.

This is **not completed whole-program source-first PV**. The remaining literal qm/iconst/table write, other opcodes, full loop, preparation of scale/coefficient globals, full I/O and source-linked numerical-output-to-ANT consumption remain unfinished. fromS's physical prepared scale/global/live/positive precondition remains an application obligation: actual static initialization starts with null scale100. The separate full51 kernel-only numerical migration must not be relabeled PV.

## Clean reproduction

1. Unpack the component. Install the exact pinned Lean toolchain and clone/build the generic public libraries at the commits in capsule-v1/SOURCE_LOCK.json. No prebuilt application objects are allowed as proof inputs.
2. Prepare a public-only environment:

```
python capsule-v1/prepare_environment.py --toolchain /path/to/lean-toolchain --mathlib /path/to/pinned/mathlib --out /tmp/evaluator-public-env.json
```

3. Rebuild all387 actual application sources and audit all115 selected theorem closures:

```
python capsule-v1/reproduce.py --environment /tmp/evaluator-public-env.json --out /tmp/evaluator-fresh-replay --jobs 2
```

Use the approved resource guard around the command. A fresh replay receipt is issued only after all sources, outputs, toolchain pins and theorem closures pass. This prepared component has **not yet run this full387-source replay**. Public-environment setup and actual negative/optimization CLI controls are recorded separately and do not establish proof replay.

`SOURCE_SUPPORT_INDEX_V1.json` preserves exact accepted individual source/receipt identities. Source and payload locks retain original and ported hashes; only include_str path literals are changed for portability. `freeze_index.py`, `collect_source_dependencies_v1.py` and `make_capsule_v1.py` regenerate the source snapshot from the research checkout. The archive manifest checks every included byte. Actual C execution is not rerun by this proof component.

## Trust boundary

Ordinary Lean kernel plus standard propext/Classical.choice/Quot.sound; pinned generic Nat compiler/runtime ABI contracts; precise generic C scalar/typed memory and source-call semantics. Compiler/runtime/OS/hardware/source-build-run association remains explicit in the surrounding experiment. Unsupported operations fail closed. No new axiom, sorry, native execution fact or assumed successful application output is introduced in the selected proof closures. This component's replay is host generic-only source-cold when run; namespace isolation is not claimed.
