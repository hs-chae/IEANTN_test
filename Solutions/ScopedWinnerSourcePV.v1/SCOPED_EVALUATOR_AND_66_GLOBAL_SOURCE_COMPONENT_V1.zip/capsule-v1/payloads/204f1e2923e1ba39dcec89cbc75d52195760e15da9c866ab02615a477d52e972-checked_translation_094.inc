#include "function_23_qm.inc"
#include "function_24_qi.inc"
