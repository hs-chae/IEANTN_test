#include "function_34_qpow.inc"
#include "function_35_floorQ.inc"
