#include "function_32_qmin.inc"
#include "function_33_qmax.inc"
