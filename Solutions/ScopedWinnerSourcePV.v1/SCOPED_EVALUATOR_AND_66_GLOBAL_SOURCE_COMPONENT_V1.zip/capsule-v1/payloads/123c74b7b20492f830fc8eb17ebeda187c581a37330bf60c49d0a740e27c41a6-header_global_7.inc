static RI preparedLn2;
