static void printI(I a){printS((a.lo));
if((printf(",-100,")<0))fail();else ;
printS((a.hi));
if((printf(",-100,%u\n",(a.ok))<0))fail();else ;}
