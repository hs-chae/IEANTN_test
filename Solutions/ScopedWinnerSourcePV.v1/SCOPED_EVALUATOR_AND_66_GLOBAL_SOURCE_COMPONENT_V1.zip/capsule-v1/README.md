Source component frozen; see top-level README for actual proof status and clean reproduction.
