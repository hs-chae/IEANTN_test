# Sixteen actual helper-body contracts

Run `python3 reproduce.py --environment /absolute/PUBLIC_GENERIC_ENV.json --out /absolute/fresh-proof` after preparing the pinned public Lean/Mathlib dependencies. The environment schema is the existing compiler+generic_dependencies interface: each dependency has name,commit,url,source,objects. Prior application-object paths are ignored. Exact kernel libraries,stdlibsentinels,headers,Clang and Leanversion are checked before and after.

All46applicationmodule sources are rebuilt; all16full theoremtypes and transitiveaxioms are reflected. Shared Generic/Machine/Header/Generated source hashes match the separatelyaccepted734file source-bundle component. This component alone supplies conditionalbodycontracts, notinitialmemory, wholemain/output or mathematicalconsumercompletion. Actualsource-coldrun is HOST, notnamespaceisolation. No originalexperimentoutcomeis changed.
