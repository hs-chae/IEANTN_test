import ScopedC.SignedUnsignedCall
import ScopedC.NatWrapperCalls
import ScopedC.HelperCodeAdapters
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxHeartbeats 0
run_elab do
 let env ← getEnv
 for n in ([`ScopedC.HelperCodeAdapters.ne_for_code,`ScopedC.HelperCodeAdapters.nle_for_code,`ScopedC.HelperCodeAdapters.nlt_for_code,`ScopedC.HelperCodeAdapters.keep_for_code,`ScopedC.HelperCodeAdapters.clear_for_code,`ScopedC.NatWrapperCalls.na_call,`ScopedC.NatWrapperCalls.ns_call,`ScopedC.NatWrapperCalls.nm_call,`ScopedC.NatWrapperCalls.nd_call,`ScopedC.NatWrapperCalls.nr_call,`ScopedC.NatWrapperCalls.ng_call,`ScopedC.NatWrapperCalls.nl_call,`ScopedC.NatWrapperCalls.nu_call,`ScopedC.NatWrapperCalls.nz_call,`ScopedC.SignedCalls.smake_call,`ScopedC.SignedCalls.si_call] : List Name) do
  let some ci := env.find? n | throwError "missing {n}"
  let ax ← Lean.collectAxioms n
  logInfo m!"BODY_AUDIT {(Json.mkObj [("name",toJson n.toString),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"
