# Accepted35-body host source supplement

This source-only capsule freezes35 of the original68 actual C function body
contracts and19 additional named source-to-mathematics roots. Every indexed
own development build and requested axiom audit passed with only propext,
Classical.choice and Quot.sound. New qa and qt proofs consume the actual AST,
all lower source calls, typed locals, memory/ownership and scope semantics.
qt also proves canonical product numerator/denominator for normalized inputs.
Decimal consumes the actual byte/pointer while loop and proves its value.

This is HOST development evidence. The combined35-body source-cold recipe
below has NOT been executed for this supplement. Historical16-body and later
parent cold components retain their separate actual narrower receipts.
No whole68-function producer, final numerical/PNT consumer or final isolated
source-cold acceptance is claimed. Original outcomes remain unchanged.

## Clean source proof replay

Use Linux x86-64, pinned Lean4.34.0-rc2 and public library commits from
SOURCE_LOCK.json. Prepare PUBLIC_GENERIC_ENV.json with compiler and
 generic_dependencies(name,url,commit,source,objects). The recipe checks source
Git commits, compiler/kernel/runtime/stdlib/header sentinel hashes and Lean
version. It ignores historical application-object inputs, builds every frozen
written application module into an empty object directory, then audits exactly
the54 named body/math roots and rejects nonstandard axioms.

python3 reproduce.py --environment /absolute/PUBLIC_GENERIC_ENV.json --out /fresh/outside-capsule

The generic compiler/core Nat runtime/preprocessor/ABI/OS and hardware contracts
remain explicit trust boundaries; their implementations are not reverified.
Caller input liveness, pool capacity and representation predicates are proved
component domains, not assumptions of a desired output. Full caller
applicability and remaining source functions are still open.

actual-c preserves original executable arithmetic/input sources. Algorithms,
52originalrows,8192/16384grids and all numerical constants stay unchanged.
The parentC56 source-binding/compile/run artifacts are separate; this proof
recipe does not rerun those programs or assert new numerical results.
Numerical randomness is absent. evidence preserves actual successful warm
receipts/logs; SOURCE_LOCK and HASHES pin the portable source/evidence bytes.
The study progress and exact source obligations are documented separately in
scoped/numerical/SOURCE_QA_QT_PROGRESS_V10.md in the parent repository.
