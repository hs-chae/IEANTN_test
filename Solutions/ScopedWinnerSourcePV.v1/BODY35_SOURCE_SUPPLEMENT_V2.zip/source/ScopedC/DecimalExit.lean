/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalLoop

namespace ScopedC.DecimalFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem pop_body {s t : State} (buf : Address) (slot k : Nat)
    (length : t.heap.length=s.heap.length) :
    popScope (parameter s buf) (loop t buf slot k)=parameter t buf := by
  cases t
  simp_all [popScope,loop,parameter,allocate,List.append_assoc,List.take_append]

theorem declare_a (service : Call) {l : PoolLayout} {c : PoolCursor.Cursor} (buf : Address)
    (answer : service "nu" [DecimalDigits.integer 0] (parameter c.state buf)=
      some (.natObject c.state.nats.values.length,parameter (PoolCursor.next l c 0).state buf)) :
    Declare Header.layout service
      [{type:="N",name:="a",value:=some (.call (.var "nu") [.nat 0])}]
      (parameter c.state buf)
      (allocate (parameter (PoolCursor.next l c 0).state buf) "N" "a" (some (.natObject c.state.nats.values.length))) := by
  have call : evalExpr Header.layout service 1000 (parameter c.state buf) (.call (.var "nu") [.nat 0])=
      some (.natObject c.state.nats.values.length,parameter (PoolCursor.next l c 0).state buf) :=
    ExpressionTemplates.call_one Header.layout service (by rfl) answer
  have live : NatArena.Borrow (parameter (PoolCursor.next l c 0).state buf).nats c.state.nats.values.length 0 :=
    PoolCursor.next_borrow l c 0
  have cast := PrimitiveCalls.cast_N live
  simp [Declare,declarations,List.foldlM,call,cast]


theorem declare_k (service : Call) (s : State) (buf : Address) (slot : Nat) :
    Declare Header.layout service [{type:="unsigned int",name:="k",value:=some (.nat 0)}]
      (allocate (parameter s buf) "N" "a" (some (.natObject slot))) (loop s buf slot 0) := by
  rfl

end ScopedC.DecimalFrames
