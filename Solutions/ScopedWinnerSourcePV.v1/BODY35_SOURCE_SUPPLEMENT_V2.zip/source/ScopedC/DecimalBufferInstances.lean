/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalBuffer

namespace ScopedC.DecimalBuffer
open ScopedC.Machine ScopedC.PoolCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def array (padding : List (Option Value)) (digits : List Nat) : Object := {
  type:="char",cells:=padding++digits.map (fun d=>some (DecimalDigits.digit d))++[some (DecimalDigits.char 0)],
  isArray:=true,writable:=false }

/-- Establish the window from actual char-array storage. Arbitrary padding
    includes the leading minus byte of negative numerator literals. -/
theorem of_array {s : State} {base : Address} {digits : List Nat} (padding : List (Option Value))
    (h : s.heap[base.object]?=some (array padding digits))
    (offset : base.index=padding.length) (fields : base.fields=[]) : At s base digits := by
  refine ⟨(List.getElem?_eq_some_iff.mp h).choose,fields,?_,?_⟩
  · intro k hk
    have bound : base.index+k<(array padding digits).cells.length := by
      simp only [array,List.length_append,List.length_map,List.length_singleton,offset]
      omega
    simp [addressType,h,bound,fields,array,typeAt,Bind.bind,Option.bind,offset]
    omega
  · intro k hk
    have cell : (array padding digits).cells[base.index+k]?=
        some (some (if hi : k<digits.length then DecimalDigits.digit digits[k] else DecimalDigits.char 0)) := by
      change ((padding++digits.map (fun d=>some (DecimalDigits.digit d)))++[some (DecimalDigits.char 0)])[base.index+k]?=_
      rw [offset,List.append_assoc,List.getElem?_append_right (by omega)]
      simp only [Nat.add_sub_cancel_left]
      by_cases hi : k<digits.length
      · rw [List.getElem?_append_left (by simpa using hi)]
        simp [List.getElem?_eq_getElem hi,hi]
      · have equal : k=digits.length := by omega
        subst k
        simp [List.getElem?_append]
    simp only [Machine.read,h,Bind.bind,Option.bind,cell,fields]
    split_ifs <;> rfl

/-- Heap object types already force separation from the owned Nat pool and
    counters; callers need not assume an arbitrary disjointness fact. -/
theorem separate {s : State} {base : Address} {digits : List Nat}
    {l : PoolLayout} {cells : List (Option Value)} {top high : Nat}
    (h : At s base digits) (context : GenericPoolContext l s cells top high) :
    base.object≠l.pool ∧ base.object≠l.top ∧ base.object≠l.high := by
  have typ := h.address 0 (Nat.zero_le _)
  constructor
  · intro equal
    simp [addressType,equal,context.pool_read,poolObject,typeAt,h.fields,Bind.bind,Option.bind] at typ
  · constructor
    · intro equal
      simp [addressType,equal,context.top_read,counterObject,typeAt,h.fields,Bind.bind,Option.bind] at typ
    · intro equal
      simp [addressType,equal,context.high_read,counterObject,typeAt,h.fields,Bind.bind,Option.bind] at typ

end ScopedC.DecimalBuffer
