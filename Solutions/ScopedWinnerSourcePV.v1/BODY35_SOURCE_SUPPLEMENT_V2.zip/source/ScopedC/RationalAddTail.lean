/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAddCursor

namespace ScopedC.RationalAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 0

set_option maxRecDepth 100000

/-- Merely membership of actual installed source AST bodies, never an assumed
execution, mathematical result, or application-output contract. -/
structure Library (code : List Function) : Prop where
  sm : Generated.f_sm∈code
  sa : Generated.f_sa∈code
  nm : Generated.f_nm∈code
  na : Generated.f_na∈code
  ns : Generated.f_ns∈code
  nle : Generated.f_nle∈code
  qm : Generated.f_qm∈code
  nz : Generated.f_nz∈code
  ng : Generated.f_ng∈code
  nd : Generated.f_nd∈code
  smake : Generated.f_smake∈code
  nu : Generated.f_nu∈code
  ne : Generated.f_ne∈code
  keep : Generated.f_keep∈code

theorem context6 {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+13<PoolCalls.capacity) (a b : Input) : Valid l (c6 l c a b) :=
  RationalCompareCalls.final_context ctx (by omega) a b

theorem context8 {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+13<PoolCalls.capacity) (a b : Input) : Valid l (c8 l c a b) :=
  CursorFrames.advance_valid ctx
    [0,a.numerator.magnitude*b.denominator,0,0,b.numerator.magnitude*a.denominator,0,magnitude l c a b,0]
    (by simp;omega)

theorem input8 {l : PoolCalls.PoolLayout} {c : Cursor} {a b q : Input} (h : q.Live c.state) :
    q.Live (c8 l c a b).state :=
  Input.live_after (Input.live_after (Input.live_after (Input.live_after (Input.live_after
    (RationalCompareCalls.input_middle h)))))

theorem tail_calls (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+13<PoolCalls.capacity)
    (a b : Input) (aLive : a.Live c.state) (bLive : b.Live c.state)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    SourceCall Header.layout code 5 "sa" [(x l c a b).source,(y l c a b).source]
      (RationalLocalFrames.both (c6 l c a b).state a b (x l c a b) (y l c a b)) (sum l c a b).source
      (RationalLocalFrames.both (c8 l c a b).state a b (x l c a b) (y l c a b)) ∧
    SourceCall Header.layout code 2 "nm" [.natObject a.denSlot,.natObject b.denSlot]
      (RationalLocalFrames.both (c8 l c a b).state a b (x l c a b) (y l c a b)) (.natObject (c8 l c a b).state.nats.values.length)
      (RationalLocalFrames.both (c9 l c a b).state a b (x l c a b) (y l c a b)) ∧
    SourceCall Header.layout code 5 "qm" [(sum l c a b).source,.natObject (c8 l c a b).state.nats.values.length]
      (RationalLocalFrames.both (c9 l c a b).state a b (x l c a b) (y l c a b)) (result l c a b)
      (RationalLocalFrames.both (c14 l c a b).state a b (x l c a b) (y l c a b)) := by
  have ctx6 := context6 ctx room a b
  have ctx8 := context8 ctx room a b
  have ctx9 := c9_context ctx room a b
  have pAdd := SignedAddCursor.sa_both code lib.sa lib.na lib.ns lib.nle lib.smake lib.nz lib.nu lib.ne lib.keep
    (c:=c6 l c a b) ctx6 (by change c.top+6+1<PoolCalls.capacity;omega) a b (x l c a b) (y l c a b)
    (RationalCompareCalls.left_final l c a b) (RationalCompareCalls.right_final l c a b)
  rw [←sum_source] at pAdd
  have pMul := RationalAddCursor.nm_both code lib.nm lib.keep (c:=c8 l c a b) ctx8
    (by change c.top+8<PoolCalls.capacity;omega) a b (x l c a b) (y l c a b)
    (input8 (l:=l) (c:=c) (a:=a) (b:=b) aLive) (input8 (l:=l) (c:=c) (a:=a) (b:=b) bLive)
  have pMake := RationalAddCursor.qm_both code lib.qm lib.nz lib.ng lib.nd lib.smake lib.nu lib.ne lib.keep
    (c:=c9 l c a b) ctx9 (by rw[c9_top];omega) a b (x l c a b) (y l c a b) (sum l c a b)
    (PoolCursor.preserves (sum_live l c a b)) (next_borrow l (c8 l c a b) (denominator a b)) (Nat.mul_pos ha hb)
  exact ⟨pAdd,pMul,pMake⟩

end ScopedC.RationalAddCalls
