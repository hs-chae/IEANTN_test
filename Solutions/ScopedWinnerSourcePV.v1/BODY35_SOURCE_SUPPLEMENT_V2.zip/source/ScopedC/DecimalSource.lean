/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalExit
import ScopedC.DecimalBufferInstances

namespace ScopedC.DecimalSource
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls ScopedC.PoolCursor ScopedC.DecimalExpressions
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- The actual complete decimal C body: one initial zero, four allocations
    per byte, actual byte guards/while/stores/return/scope, and exact decimal
    value. Interior pointers cover signed literal suffixes. Input memory and
    pool capacity are concrete caller obligations, not desired-output facts. -/
theorem decimal_closed (code : List Function) (installed : Generated.f_decimal∈code)
    (nuInstalled : Generated.f_nu∈code) (nmInstalled : Generated.f_nm∈code)
    (naInstalled : Generated.f_na∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolLayout} {c : Cursor} {buf : Address} {digits : List Nat}
    (valid : Valid l c) (hbuf : DecimalBuffer.At c.state buf digits)
    (good : ∀ d∈digits,d<10) (room : c.top+4*digits.length<capacity) :
    ∃ final : Cursor,∃ slot : Nat,
      SourceCall Header.layout code 3 "decimal" [.pointer buf false] c.state (.natObject slot) final.state ∧
      NatArena.Borrow final.state.nats slot (value digits 0) ∧ Valid l final ∧
      DecimalBuffer.At final.state buf digits ∧
      final.top=c.top+1+4*digits.length ∧
      final.state.heap.length=c.state.heap.length ∧ final.state.env=c.state.env ∧
      final.state.nats.values.length=c.state.nats.values.length+1+4*digits.length ∧
      (∀ i,i≠l.pool → i≠l.top → i≠l.high → final.state.heap[i]?=c.state.heap[i]?) := by
  have length : digits.length<2^32 := by unfold capacity at room;omega
  have sep := DecimalBuffer.separate hbuf valid
  have r0 : c.top<capacity := by omega
  let first := next l c 0
  let zeroSlot := c.state.nats.values.length
  have firstValid : Valid l first := next_valid 0 valid r0
  have firstLive : NatArena.Borrow first.state.nats zeroSlot 0 := next_borrow l c 0
  have firstBuffer : DecimalBuffer.At first.state buf digits := next_buffer hbuf 0 sep.1 sep.2.1 sep.2.2
  have firstRoom : first.top+4*digits.length≤capacity := by change c.top+1+4*digits.length≤capacity;omega
  obtain ⟨final,slot,events,post⟩ := loop_exists code nuInstalled nmInstalled naInstalled keepInstalled
    digits good length (consumed:=[]) (remaining:=digits) rfl firstLive firstValid firstRoom firstBuffer
    sep.1 sep.2.1 sep.2.2
  have initialShape := shape l c 0
  have finalHeap : final.state.heap.length=c.state.heap.length := post.heap.trans initialShape.1
  have finalEnv : final.state.env=c.state.env := post.environment.trans initialShape.2
  have nuZero : SourceCall Header.layout code 2 "nu" [DecimalDigits.integer 0]
      (DecimalFrames.parameter c.state buf) (.natObject zeroSlot) (DecimalFrames.parameter first.state buf) := by
    have ctx : GenericPoolContext l (DecimalFrames.parameter c.state buf) c.cells c.top c.high :=
      OneFrames.context_frame valid "const char*" "s" (.pointer buf false)
    have move := binary_result_one_frame (result:=0) valid "const char*" "s" (.pointer buf false)
    have h := nu_call (n:=0) (input:=DecimalDigits.integer 0) code nuInstalled keepInstalled ctx r0 (by decide +kernel) rfl
    change binaryResult l (DecimalFrames.parameter c.state buf) c.cells c.top c.high 0 =
      DecimalFrames.parameter (binaryResult l c.state c.cells c.top c.high 0) buf at move
    rw [move] at h
    exact h
  let initial : CallEvents.Event Header.layout code 2 := ⟨"nu",[DecimalDigits.integer 0],
    DecimalFrames.parameter c.state buf,.natObject zeroSlot,DecimalFrames.parameter first.state buf,nuZero⟩
  have unique : (CallEvents.counts (initial::events)).Nodup := by
    change (c.state.nats.values.length::CallEvents.counts events).Nodup
    rw [post.counts]
    have nextSize : first.state.nats.values.length=c.state.nats.values.length+1 := size l c 0
    rw [nextSize]
    change (List.range' c.state.nats.values.length (4*digits.length+1)).Nodup
    exact List.nodup_range'
  let service := CallEvents.service (initial::events)
  have initialAnswer : service "nu" [DecimalDigits.integer 0] (DecimalFrames.parameter c.state buf)=
      some (.natObject zeroSlot,DecimalFrames.parameter first.state buf) :=
    CallEvents.service_self (initial::events) unique initial (by simp)
  have answers : Answers service events := fun e he =>
    CallEvents.service_self (initial::events) unique e (List.mem_cons_of_mem initial he)
  have loopRun := post.source service answers
  have returning : Eval Header.layout service (.var "a")
      (DecimalFrames.loop final.state buf slot digits.length)
      (DecimalFrames.loop final.state buf slot digits.length) (.natObject slot) :=
    ⟨2,DecimalFrames.eval_a service 1 final.state buf slot digits.length⟩
  have bodyRun : Run Header.layout service Generated.f_decimal.body (DecimalFrames.parameter c.state buf)
      (.returned (DecimalFrames.parameter final.state buf) (.natObject slot)) := by
    rw [←body_exact]
    apply Loops.StmtRun.sequence
    · exact Loops.SeqRun.next (Loops.StmtRun.declare (DecimalFrames.declare_a service buf initialAnswer))
        (Loops.SeqRun.next (Loops.StmtRun.declare (DecimalFrames.declare_k service first.state buf zeroSlot))
          (Loops.SeqRun.next (Loops.StmtRun.whileLoop loopRun)
            (Loops.SeqRun.returned (Loops.StmtRun.returnValue returning))))
    · exact ⟨rfl,(DecimalFrames.pop_body buf slot digits.length finalHeap).symm⟩
  have finished : Finish Header.layout Generated.f_decimal c.state
      (.returned (DecimalFrames.parameter final.state buf) (.natObject slot)) (.natObject slot) final.state := by
    change castValue Header.layout (DecimalFrames.parameter final.state buf) 100 "static N" (.natObject slot)=some (.natObject slot) ∧
      final.state=popScope c.state (DecimalFrames.parameter final.state buf)
    exact ⟨PrimitiveCalls.cast_N post.live,(OneFrames.pop_frame "const char*" "s" (.pointer buf false) finalHeap finalEnv).symm⟩
  refine ⟨final,slot,?_,post.live,post.valid,post.buffer,?_,finalHeap,finalEnv,?_,?_⟩
  · exact installed_body (rank:=2) (service:=service) installed
      (fun _ _ _ _ _ h => CallEvents.service_closed (initial::events) h)
      (DecimalFrames.bind hbuf) bodyRun finished
  · simpa only [first,next] using post.top
  · rw [post.size]
    have nextSize : first.state.nats.values.length=c.state.nats.values.length+1 := size l c 0
    rw [nextSize]
  · intro i hp ht hh
    exact (post.other i hp ht hh).trans (other l c 0 i hp ht hh)

end ScopedC.DecimalSource
