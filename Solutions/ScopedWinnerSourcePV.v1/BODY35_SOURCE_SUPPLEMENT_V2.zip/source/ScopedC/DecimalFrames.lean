/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalBuffer

namespace ScopedC.DecimalFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def parameter (s : State) (buf : Address) : State :=
  allocate {s with env:=[]} "const char*" "s" (some (.pointer buf false))

def loop (s : State) (buf : Address) (slot k : Nat) : State :=
  allocate (allocate (parameter s buf) "N" "a" (some (.natObject slot)))
    "unsigned int" "k" (some (unsigned32 k))

theorem context {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high : Nat}
    (h : GenericPoolContext l s cells top high) (buf : Address) (slot k : Nat) :
    GenericPoolContext l (loop s buf slot k) cells top high := by
  apply AllocatedFrames.context_allocate
  apply AllocatedFrames.context_allocate
  apply AllocatedFrames.context_allocate
  exact context_env h []

theorem buffer {s : State} {buf : Address} {digits : List Nat} (h : DecimalBuffer.At s buf digits)
    (slot k : Nat) : DecimalBuffer.At (loop s buf slot k) buf digits := by
  have hp : DecimalBuffer.At {s with env:=[]} buf digits := DecimalBuffer.memory_eq h rfl
  exact DecimalBuffer.allocate (DecimalBuffer.allocate (DecimalBuffer.allocate hp "const char*" "s" (some (.pointer buf false))) "N" "a" (some (.natObject slot))) "unsigned int" "k" (some (unsigned32 k))

theorem parameter_buffer {s : State} {buf : Address} {digits : List Nat} (h : DecimalBuffer.At s buf digits) :
    DecimalBuffer.At (parameter s buf) buf digits := DecimalBuffer.allocate (s:={s with env:=[]}) (DecimalBuffer.memory_eq h rfl) "const char*" "s" (some (.pointer buf false))

theorem bind {s : State} {buf : Address} {digits : List Nat} (h : DecimalBuffer.At s buf digits) :
    bindArgs Header.layout Generated.f_decimal.parameters [.pointer buf false] s =
      some (parameter s buf) := by
  have ht : addressType Header.layout {s with env:=[]} buf = some "char" :=
    by simpa only [addressType,Nat.add_zero] using DecimalBuffer.address_type (k:=0) h (Nat.zero_le _)
  apply TypedFrames.bind_one
  change (do let target ← addressType Header.layout {s with env:=[]} buf
             if normalizeType target != "char" || false then none
             else pure (Value.pointer buf false)) = _
  rw [ht]
  rfl

theorem eval_s (service : Call) (fuel : Nat) (s : State) (buf : Address) (slot k : Nat) :
    evalExpr Header.layout service (fuel+1) (loop s buf slot k) (.var "s") =
      some (.pointer buf false,loop s buf slot k) := by
  simp [evalExpr,getVar,loop,parameter,allocate,List.lookup,Machine.read,List.getElem?_append,nested,initialized]

theorem eval_a (service : Call) (fuel : Nat) (s : State) (buf : Address) (slot k : Nat) :
    evalExpr Header.layout service (fuel+1) (loop s buf slot k) (.var "a") =
      some (.natObject slot,loop s buf slot k) := by
  simp [evalExpr,getVar,loop,parameter,allocate,List.lookup,Machine.read,List.getElem?_append,nested,initialized]

theorem eval_k (service : Call) (fuel : Nat) (s : State) (buf : Address) (slot k : Nat) :
    evalExpr Header.layout service (fuel+1) (loop s buf slot k) (.var "k") =
      some (unsigned32 k,loop s buf slot k) := by
  exact TypedFrames.allocate_eval Header.layout service fuel
    (allocate (parameter s buf) "N" "a" (some (.natObject slot))) "unsigned int" "k" (unsigned32 k)
    rfl (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem result_loop {l : PoolLayout} {s : State} {cells : List (Option Value)} {top high n : Nat}
    (h : GenericPoolContext l s cells top high) (buf : Address) (slot k : Nat) :
    binaryResult l (loop s buf slot k) cells top high n =
      loop (binaryResult l s cells top high n) buf slot k := by
  unfold loop parameter
  rw [AllocatedFrames.binary_allocate (AllocatedFrames.context_allocate
    (AllocatedFrames.context_allocate (context_env h []) _ _ _) _ _ _)]
  rw [AllocatedFrames.binary_allocate (AllocatedFrames.context_allocate (context_env h []) _ _ _)]
  rw [AllocatedFrames.binary_allocate (context_env h [])]
  simp only [binaryResult,keepResult,keepStepped,keepStored,storeHigh,storeTop,storePool,storeObject]
  split <;> rfl

theorem nats (s : State) (buf : Address) (slot k : Nat) : (loop s buf slot k).nats = s.nats := rfl

theorem pop {s t : State} (buf : Address) (slot k : Nat)
    (length : t.heap.length=s.heap.length) (env : t.env=s.env) :
    popScope s (loop t buf slot k) = t := by
  cases t
  simp_all [popScope,loop,parameter,allocate,List.append_assoc]

end ScopedC.DecimalFrames
