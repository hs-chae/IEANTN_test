/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CursorFrames

namespace ScopedC.CursorEffects
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem shape (l : PoolCalls.PoolLayout) (c : Cursor) (ns : List Nat) :
    (CursorFrames.advance l c ns).state.heap.length=c.state.heap.length ∧
    (CursorFrames.advance l c ns).state.env=c.state.env := by
  induction ns generalizing c with
  | nil => exact ⟨rfl,rfl⟩
  | cons n ns ih =>
    have h := PoolCursor.shape l c n
    have t := ih (next l c n)
    exact ⟨t.1.trans h.1,t.2.trans h.2⟩

theorem size (l : PoolCalls.PoolLayout) (c : Cursor) (ns : List Nat) :
    (CursorFrames.advance l c ns).state.nats.values.length=c.state.nats.values.length+ns.length := by
  induction ns generalizing c with
  | nil => exact Nat.add_zero _ |>.symm
  | cons n ns ih =>
    rw [CursorFrames.advance,ih,PoolCursor.size,List.length_cons]
    omega

end ScopedC.CursorEffects
