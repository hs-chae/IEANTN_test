/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyEvents
import ScopedC.RationalMultiplyCasts

namespace ScopedC.RationalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
open ScopedC.RationalMultiplyFrames (gFrame ghFrame topFrame)
set_option autoImplicit false
set_option maxHeartbeats 200000
set_option maxRecDepth 100000

def aMagExpr : Expr := .field "." (.field "." (.var "a") "num") "mag"
def bMagExpr : Expr := .field "." (.field "." (.var "b") "num") "mag"
def aNegExpr : Expr := .field "." (.field "." (.var "a") "num") "neg"
def bNegExpr : Expr := .field "." (.field "." (.var "b") "num") "neg"
def aDenExpr : Expr := .field "." (.var "a") "den"
def bDenExpr : Expr := .field "." (.var "b") "den"
def gInitializer : Expr := .call (.var "ng") [aMagExpr,bDenExpr]
def hInitializer : Expr := .call (.var "ng") [bMagExpr,aDenExpr]
def leftInitializer : Expr := .call (.var "smake") [.call (.var "nd") [aMagExpr,.var "g"],aNegExpr]
def rightInitializer : Expr := .call (.var "smake") [.call (.var "nd") [bMagExpr,.var "h"],bNegExpr]
def topInitializer : Expr := .call (.var "sm") [leftInitializer,rightInitializer]
def denAExpr : Expr := .call (.var "nd") [aDenExpr,.var "h"]
def denBExpr : Expr := .call (.var "nd") [bDenExpr,.var "g"]
def rInitializer : Expr := .record [.var "top",.call (.var "nm") [denAExpr,denBExpr]]

/-- All ten actual lower calls, both gcds, four divisions, signed
normalizations/product, denominator product, four typed locals and scopes. -/
theorem qt_closed (code : List Function) (installed : Generated.f_qt∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+10<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 6 "qt" [a.source,b.source] c.state (result l c a b) (c11 l c a b).state := by
  let gs := c.state.nats.values.length
  let hs := (c1 l c a b).state.nats.values.length
  let p0 := frame c.state a b
  let p1 := frame (c1 l c a b).state a b
  let s1 := gFrame (c1 l c a b).state a b gs
  let s2 := gFrame (c2 l c a b).state a b gs
  let t2 := ghFrame (c2 l c a b).state a b gs hs
  let t3 := ghFrame (c3 l c a b).state a b gs hs
  let t4 := ghFrame (c4 l c a b).state a b gs hs
  let t5 := ghFrame (c5 l c a b).state a b gs hs
  let t6 := ghFrame (c6 l c a b).state a b gs hs
  let t8 := ghFrame (c8 l c a b).state a b gs hs
  let u8 := topFrame (c8 l c a b).state a b gs hs (top l c a b)
  let u9 := topFrame (c9 l c a b).state a b gs hs (top l c a b)
  let u10 := topFrame (c10 l c a b).state a b gs hs (top l c a b)
  let u11 := topFrame (c11 l c a b).state a b gs hs (top l c a b)
  let p11 := frame (c11 l c a b).state a b
  let out := result l c a b
  have low := lower_calls code lib ctx room a b ha hb pa pb
  let service := Events.calls low
  have a1 := Events.answer1 low
  have a2 := Events.answer2 low
  have a3 := Events.answer3 low
  have a4 := Events.answer4 low
  have a5 := Events.answer5 low
  have a6 := Events.answer6 low
  have a7 := Events.answer7 low
  have a8 := Events.answer8 low
  have a9 := Events.answer9 low
  have a10 := Events.answer10 low
  have readAMag : evalExpr Header.layout service 999 p0 aMagExpr=some (.natObject a.numerator.slot,p0) :=
    ExpressionTemplates.field Header.layout service (RationalPairFrames.eval_a_num service 996 c.state a b) (by rfl)
  have evalG : evalExpr Header.layout service 1000 p0 gInitializer=some (.natObject gs,p1) :=
    ExpressionTemplates.call_two Header.layout service readAMag (RationalPairFrames.eval_b_den service 997 c.state a b) a1
  have castG : castValue Header.layout p1 100 "N" (.natObject gs)=some (.natObject gs) :=
    PositiveCasts.cast_N Header.layout p1 99 gs (g a b) (next_borrow l c (g a b))
  have declG : Declare Header.layout service [{type:="N",name:="g",value:=some gInitializer,arrayExtent:=none}] p0 s1 := by
    simp only[Declare,declarations,List.foldlM,evalG,bind,Option.bind,castG];rfl
  have evalH : evalExpr Header.layout service 1000 s1 hInitializer=some (.natObject hs,s2) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalMultiplyFrames.eval_b_mag_g service 996 (c1 l c a b).state a b gs)
      (RationalMultiplyFrames.eval_a_den_g service 997 (c1 l c a b).state a b gs) a2
  have castH : castValue Header.layout s2 100 "N" (.natObject hs)=some (.natObject hs) :=
    PositiveCasts.cast_N Header.layout s2 99 hs (h a b) (h_live2 l c a b)
  have declH : Declare Header.layout service [{type:="N",name:="h",value:=some hInitializer,arrayExtent:=none}] s1 t2 := by
    simp only[Declare,declarations,List.foldlM,evalH,bind,Option.bind,castH];rfl
  have divA : evalExpr Header.layout service 998 t2 (.call (.var "nd") [aMagExpr,.var "g"])=
      some (.natObject (c2 l c a b).state.nats.values.length,t3) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalMultiplyFrames.eval_a_mag service 994 (c2 l c a b).state a b gs hs)
      (RationalMultiplyFrames.eval_g service 996 (c2 l c a b).state a b gs hs) a3
  have makeA : evalExpr Header.layout service 999 t2 leftInitializer=some ((left l c a b).source,t4) :=
    ExpressionTemplates.call_two Header.layout service divA
      (RationalMultiplyFrames.eval_a_neg service 995 (c3 l c a b).state a b gs hs) a4
  have divB : evalExpr Header.layout service 998 t4 (.call (.var "nd") [bMagExpr,.var "h"])=
      some (.natObject (c4 l c a b).state.nats.values.length,t5) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalMultiplyFrames.eval_b_mag service 994 (c4 l c a b).state a b gs hs)
      (RationalMultiplyFrames.eval_h service 996 (c4 l c a b).state a b gs hs) a5
  have makeB : evalExpr Header.layout service 999 t4 rightInitializer=some ((right l c a b).source,t6) :=
    ExpressionTemplates.call_two Header.layout service divB
      (RationalMultiplyFrames.eval_b_neg service 995 (c5 l c a b).state a b gs hs) a6
  have evalTop : evalExpr Header.layout service 1000 t2 topInitializer=some ((top l c a b).source,t8) :=
    ExpressionTemplates.call_two Header.layout service makeA makeB a7
  have liveTop8 : (top l c a b).Live (c8 l c a b).state :=
    preserves (next_borrow l (c6 l c a b) (productMagnitude l c a b))
  have castTop : castValue Header.layout t8 100 "S" (top l c a b).source=some (top l c a b).source :=
    Endpoint.cast 98 "S" (by decide +kernel) liveTop8
  have declTop : Declare Header.layout service [{type:="S",name:="top",value:=some topInitializer,arrayExtent:=none}] t2 u8 := by
    simp only[Declare,declarations,List.foldlM,evalTop,bind,Option.bind,castTop];rfl
  have evalDenA : evalExpr Header.layout service 998 u8 denAExpr=some (.natObject (c8 l c a b).state.nats.values.length,u9) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalMultiplyFrames.eval_a_den_top service 995 (c8 l c a b).state a b gs hs (top l c a b))
      (RationalMultiplyFrames.eval_h_top service 996 (c8 l c a b).state a b gs hs (top l c a b)) a8
  have evalDenB : evalExpr Header.layout service 998 u9 denBExpr=some (.natObject (c9 l c a b).state.nats.values.length,u10) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalMultiplyFrames.eval_b_den_top service 995 (c9 l c a b).state a b gs hs (top l c a b))
      (RationalMultiplyFrames.eval_g_top service 996 (c9 l c a b).state a b gs hs (top l c a b)) a9
  have evalDen : evalExpr Header.layout service 999 u8 (.call (.var "nm") [denAExpr,denBExpr])=
      some (.natObject (c10 l c a b).state.nats.values.length,u11) :=
    ExpressionTemplates.call_two Header.layout service evalDenA evalDenB a10
  have evalR : evalExpr Header.layout service 1000 u8 rInitializer=
      some (.aggregate [(top l c a b).source,.natObject (c10 l c a b).state.nats.values.length],u11) :=
    ExpressionTemplates.record_two Header.layout service
      (RationalMultiplyFrames.eval_top_top service 998 (c8 l c a b).state a b gs hs (top l c a b)) evalDen
  have castR : castValue Header.layout u11 100 "Q"
      (.aggregate [(top l c a b).source,.natObject (c10 l c a b).state.nats.values.length])=some out :=
    RationalMultiplyCasts.aggregate (c11 l c a b).state a b gs hs (top l c a b)
      (top_live l c a b) (next_borrow l (c10 l c a b) (den a b))
  have declR : Declare Header.layout service [{type:="Q",name:="r",value:=some rInitializer,arrayExtent:=none}] u8 (allocate u11 "Q" "r" (some out)) := by
    simp only[Declare,declarations,List.foldlM,evalR,bind,Option.bind,castR];rfl
  have ret : Eval Header.layout service (.var "r") (allocate u11 "Q" "r" (some out)) (allocate u11 "Q" "r" (some out)) out :=
    ⟨2,TypedFrames.allocate_eval Header.layout service 1 u11 "Q" "r" out rfl (by decide) (by decide) (by decide) (by decide)⟩
  have sh := frame_shape l c a b
  have body : Run Header.layout service Generated.f_qt.body p0 (.returned p11 out) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.declare declG)
      (Loops.SeqRun.next (Loops.StmtRun.declare declH) (Loops.SeqRun.next (Loops.StmtRun.declare declTop)
        (Loops.SeqRun.next (Loops.StmtRun.declare declR) (Loops.SeqRun.returned (Loops.StmtRun.returnValue ret))))))
    exact ⟨rfl,(RationalMultiplyFrames.pop_four gs hs (top l c a b) out sh.1 sh.2).symm⟩
  apply installed_body (f:=Generated.f_qt) (rank:=5) (service:=service) installed (Events.closed low)
    (RationalPairFrames.bind a b ha hb) body
  exact ⟨RationalMultiplyCasts.result (c11 l c a b).state a b (top l c a b)
    (top_live l c a b) (next_borrow l (c10 l c a b) (den a b)),
    (TwoFrames.pop_frame "Q" "a" a.source "Q" "b" b.source (shape l c a b).1 (shape l c a b).2).symm⟩

end ScopedC.RationalMultiplyCalls
