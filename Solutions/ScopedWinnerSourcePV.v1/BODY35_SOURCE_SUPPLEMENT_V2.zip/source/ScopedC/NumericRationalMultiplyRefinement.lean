/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyBody
import ScopedC.RationalMultiplyCanonical

namespace ScopedC.NumericRationalMultiplyRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.RationalMultiplyCalls
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0

theorem qt_math (code : List Function) (installed : Generated.f_qt∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+10<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 6 "qt" [a.source,b.source] c.state (result l c a b) (c11 l c a b).state ∧
    NumericRepresentation.rational (c11 l c a b).state (result l c a b)=some ⟨(top l c a b).mathematical,den a b⟩ ∧
    Rational.value ⟨(top l c a b).mathematical,den a b⟩=a.mathematical.value*b.mathematical.value :=
  ⟨qt_closed code installed lib ctx room a b ha hb pa pb,decoded l c a b pa pb,value l c a b pa pb⟩

/-- Canonical numerator/denominator are preserved by the actual two-gcd
cross-cancelled source algorithm. This field-level join supports log2 steps
which inspect numerator and denominator separately. -/
theorem qt_canonical_math (code : List Function) (installed : Generated.f_qt∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+10<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state)
    (an : a.mathematical.Normalized) (bn : b.mathematical.Normalized) :
    SourceCall Header.layout code 6 "qt" [a.source,b.source] c.state (result l c a b) (c11 l c a b).state ∧
    NumericRepresentation.rational (c11 l c a b).state (result l c a b)=some ⟨(top l c a b).mathematical,den a b⟩ ∧
    Rational.Normalized ⟨(top l c a b).mathematical,den a b⟩ ∧
    Rational.Represents ⟨(top l c a b).mathematical,den a b⟩ (a.mathematical.value*b.mathematical.value) ∧
    (top l c a b).magnitude=(a.mathematical.value*b.mathematical.value).num.natAbs ∧
    den a b=(a.mathematical.value*b.mathematical.value).den := by
  have h := represents l c a b an bn
  refine ⟨qt_closed code installed lib ctx room a b ha hb an.1 bn.1,decoded l c a b an.1 bn.1,
    normalized l c a b an bn,h,?_,h.2⟩
  rw [←h.1]
  exact (Signed.natAbs_value (top l c a b).mathematical).symm

end ScopedC.NumericRationalMultiplyRefinement
