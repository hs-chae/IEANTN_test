/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyFrames

namespace ScopedC.RationalMultiplyFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor ScopedC.DyadicRepresentation ScopedC.NatWrapperCalls
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def gCursor (c : Cursor) (a b : Input) (g : Nat) : Cursor :=
  CursorLocals.allocated (CursorFrames.framed c "Q" "a" a.source "Q" "b" b.source) "N" "g" (.natObject g)
def topFrame (s : State) (a b : Input) (g h : Nat) (top : Endpoint) : State :=
  allocate (ghFrame s a b g h) "S" "top" (some top.source)
def withTop (c : Cursor) (a b : Input) (g h : Nat) (top : Endpoint) : Cursor :=
  CursorLocals.allocated (gh c a b g h) "S" "top" top.source

theorem g_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (g : Nat) : Valid l (gCursor c a b g) :=
  CursorLocals.allocated_valid (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source) "N" "g" (.natObject g)
theorem next_g {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (g n : Nat) :
    next l (gCursor c a b g) n=gCursor (next l c n) a b g := by
  unfold gCursor
  rw [CursorLocals.next_allocated (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source),
    CursorFrames.next_framed ctx "Q" "a" a.source "Q" "b" b.source n]
theorem top_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (g h : Nat) (top : Endpoint) : Valid l (withTop c a b g h top) :=
  CursorLocals.allocated_valid (gh_valid ctx a b g h) "S" "top" top.source
theorem next_top {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (g h n : Nat) (top : Endpoint) :
    next l (withTop c a b g h top) n=withTop (next l c n) a b g h top := by
  unfold withTop
  rw [CursorLocals.next_allocated (gh_valid ctx a b g h),next_gh ctx a b g h n]

theorem eval_a_g (call : Call) (fuel : Nat) (s : State) (a b : Input) (g : Nat) :
    evalExpr Header.layout call (fuel+1) (gFrame s a b g) (.var "a")=some (a.source,gFrame s a b g) := by
  simp [evalExpr,getVar,topFrame,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_b_g (call : Call) (fuel : Nat) (s : State) (a b : Input) (g : Nat) :
    evalExpr Header.layout call (fuel+1) (gFrame s a b g) (.var "b")=some (b.source,gFrame s a b g) := by
  simp [evalExpr,getVar,topFrame,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_a_top (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) (top : Endpoint) :
    evalExpr Header.layout call (fuel+1) (topFrame s a b g h top) (.var "a")=some (a.source,topFrame s a b g h top) := by
  simp [evalExpr,getVar,topFrame,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_b_top (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) (top : Endpoint) :
    evalExpr Header.layout call (fuel+1) (topFrame s a b g h top) (.var "b")=some (b.source,topFrame s a b g h top) := by
  simp [evalExpr,getVar,topFrame,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_g_top (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) (top : Endpoint) :
    evalExpr Header.layout call (fuel+1) (topFrame s a b g h top) (.var "g")=some (.natObject g,topFrame s a b g h top) := by
  simp [evalExpr,getVar,topFrame,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_h_top (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) (top : Endpoint) :
    evalExpr Header.layout call (fuel+1) (topFrame s a b g h top) (.var "h")=some (.natObject h,topFrame s a b g h top) := by
  simp [evalExpr,getVar,topFrame,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_top_top (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) (top : Endpoint) :
    evalExpr Header.layout call (fuel+1) (topFrame s a b g h top) (.var "top")=some (top.source,topFrame s a b g h top) := by
  simp [evalExpr,getVar,topFrame,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_a_den_top (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) (top : Endpoint) :
    evalExpr Header.layout call (fuel+2) (topFrame s a b g h top) (.field "." (.var "a") "den")=some (.natObject a.denSlot,topFrame s a b g h top) := by
  apply ExpressionTemplates.field Header.layout call (eval_a_top call fuel s a b g h top);rfl
theorem eval_b_den_top (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) (top : Endpoint) :
    evalExpr Header.layout call (fuel+2) (topFrame s a b g h top) (.field "." (.var "b") "den")=some (.natObject b.denSlot,topFrame s a b g h top) := by
  apply ExpressionTemplates.field Header.layout call (eval_b_top call fuel s a b g h top);rfl
theorem eval_b_mag_g (call : Call) (fuel : Nat) (s : State) (a b : Input) (g : Nat) :
    evalExpr Header.layout call (fuel+3) (gFrame s a b g) (.field "." (.field "." (.var "b") "num") "mag")=some (.natObject b.numerator.slot,gFrame s a b g) := by
  apply ExpressionTemplates.field Header.layout call
    (ExpressionTemplates.field Header.layout call (eval_b_g call fuel s a b g) (by rfl));rfl
theorem eval_a_den_g (call : Call) (fuel : Nat) (s : State) (a b : Input) (g : Nat) :
    evalExpr Header.layout call (fuel+2) (gFrame s a b g) (.field "." (.var "a") "den")=some (.natObject a.denSlot,gFrame s a b g) := by
  apply ExpressionTemplates.field Header.layout call (eval_a_g call fuel s a b g);rfl

theorem pop_four {s t : State} (g h : Nat) (top : Endpoint) (r : Value)
    (length : t.heap.length=s.heap.length) (env : t.env=s.env) :
    popScope s (allocate (allocate (allocate (allocate t "N" "g" (some (.natObject g))) "N" "h" (some (.natObject h)))
      "S" "top" (some top.source)) "Q" "r" (some r))=t := by
  cases t
  simp_all [popScope,allocate,List.append_assoc]

end ScopedC.RationalMultiplyFrames
