/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAddPrefix
import ScopedC.RationalMakeEffects

namespace ScopedC.RationalAddCalls
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def effects (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : List Nat :=
  [0,a.numerator.magnitude*b.denominator,0,0,b.numerator.magnitude*a.denominator,0,
   magnitude l c a b,0,denominator a b,0,RationalMakeCalls.divisor (sum l c a b) (denominator a b),
   (sum l c a b).magnitude/RationalMakeCalls.divisor (sum l c a b) (denominator a b),0,
   denominator a b/RationalMakeCalls.divisor (sum l c a b) (denominator a b)]

theorem shape (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (c14 l c a b).state.heap.length=c.state.heap.length ∧ (c14 l c a b).state.env=c.state.env :=
  by
  have h6 := RationalCompareCalls.shape l c a b
  have h7 := PoolCursor.shape l (c6 l c a b) (magnitude l c a b)
  have h8 := PoolCursor.shape l (c7 l c a b) 0
  have h9 := PoolCursor.shape l (c8 l c a b) (denominator a b)
  have h14 := RationalMakeEffects.shape l (c9 l c a b) (sum l c a b) (denominator a b)
  exact ⟨h14.1.trans (h9.1.trans (h8.1.trans (h7.1.trans h6.1))),
    h14.2.trans (h9.2.trans (h8.2.trans (h7.2.trans h6.2)))⟩

theorem frame_shape (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (frame (c14 l c a b).state a b).heap.length=(frame c.state a b).heap.length ∧
    (frame (c14 l c a b).state a b).env=(frame c.state a b).env := by
  have h := shape l c a b
  constructor
  · simpa only [frame,TwoFrames.frame,allocate,List.length_append,List.length_singleton] using congrArg (fun n=>n+1+1) h.1
  · simp only [frame,TwoFrames.frame,allocate,List.length_append,List.length_singleton,h.1]

theorem cast_result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    castValue Header.layout (frame (c14 l c a b).state a b) 100 "static Q" (result l c a b)=some (result l c a b) := by
  exact RationalMakeEffects.cast_result l (c9 l c a b) (sum l c a b) (denominator a b) a.source b.source

end ScopedC.RationalAddCalls
