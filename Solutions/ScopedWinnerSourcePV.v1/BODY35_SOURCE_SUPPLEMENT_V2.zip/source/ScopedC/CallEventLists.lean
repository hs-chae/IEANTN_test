/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CallEvents

namespace ScopedC.CallEvents
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Proof-only composition of already proved lower-rank installed-AST calls.
    This is not an execution primitive and has no correctness/output axiom. -/
noncomputable def service {cfg : Layout} {code : List Function} {rank : Nat} :
    List (Event cfg code rank) → Call
  | [] => fun _ _ _ => none
  | e::es => append (one e) (service es)

def counts {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) : List Nat :=
  events.map (fun e => e.before.nats.values.length)

theorem one_other_size {cfg : Layout} {code : List Function} {rank : Nat}
    (e : Event cfg code rank) (name : String) (args : List Value) (s : State)
    (different : s.nats.values.length ≠ e.before.nats.values.length) :
    one e name args s = none := by
  unfold one
  split_ifs with same
  · exact False.elim (different (congrArg (fun s : State => s.nats.values.length) same.2.2))
  · rfl

theorem service_closed {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) {name : String} {args : List Value} {s t : State} {v : Value}
    (h : service events name args s = some (v,t)) :
    SourceCall cfg code rank name args s v t := by
  induction events generalizing name args s v t with
  | nil => contradiction
  | cons e es ih =>
    exact append_closed (fun _ _ _ _ _ h => one_closed e h)
      (fun _ _ _ _ _ h => ih h) h

theorem service_self {cfg : Layout} {code : List Function} {rank : Nat}
    (events : List (Event cfg code rank)) (unique : (counts events).Nodup)
    (e : Event cfg code rank) (member : e∈events) :
    service events e.name e.args e.before = some (e.value,e.after) := by
  induction events with
  | nil => contradiction
  | cons first rest ih =>
    rcases List.mem_cons.mp member with equal|member
    · subst e
      exact append_left (one_self first)
    · have hn : first.before.nats.values.length ∉ counts rest := (List.nodup_cons.mp unique).1
      have hm : e.before.nats.values.length ∈ counts rest := List.mem_map.mpr ⟨e,member,rfl⟩
      have different : e.before.nats.values.length ≠ first.before.nats.values.length := by
        intro equal
        exact hn (equal ▸ hm)
      exact append_right (one_other_size first _ _ _ different)
        (ih (List.nodup_cons.mp unique).2 member)

end ScopedC.CallEvents
