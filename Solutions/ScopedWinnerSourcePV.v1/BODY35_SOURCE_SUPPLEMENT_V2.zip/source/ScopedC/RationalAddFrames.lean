/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAddData

namespace ScopedC.RationalAddFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.RationalAddCalls
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def parameters (c : Cursor) (a b : Input) : Cursor := CursorFrames.framed c "Q" "a" a.source "Q" "b" b.source
def first (c : Cursor) (a b : Input) (an : Endpoint) : Cursor := CursorLocals.allocated (parameters c a b) "S" "an" an.source
def both (c : Cursor) (a b : Input) (an bn : Endpoint) : Cursor := CursorLocals.allocated (first c a b an) "S" "bn" bn.source

theorem first_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (an : Endpoint) :
    Valid l (first c a b an) := CursorLocals.allocated_valid (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source) "S" "an" an.source

theorem both_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (an bn : Endpoint) :
    Valid l (both c a b an bn) := CursorLocals.allocated_valid (first_valid ctx a b an) "S" "bn" bn.source

theorem next_first {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (an : Endpoint) (n : Nat) :
    next l (first c a b an) n=first (next l c n) a b an := by
  unfold first parameters
  rw [CursorLocals.next_allocated (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source),
    CursorFrames.next_framed ctx "Q" "a" a.source "Q" "b" b.source n]

theorem next_both {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (an bn : Endpoint) (n : Nat) :
    next l (both c a b an bn) n=both (next l c n) a b an bn := by
  unfold both
  rw [CursorLocals.next_allocated (first_valid ctx a b an),next_first ctx a b an n]

theorem advance_first {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (ns : List Nat)
    (room : c.top+ns.length≤PoolCalls.capacity) (a b : Input) (an : Endpoint) :
    CursorFrames.advance l (first c a b an) ns=first (CursorFrames.advance l c ns) a b an := by
  unfold first parameters
  rw [CursorLocals.advance_allocated (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source) ns room]
  rw [CursorFrames.advance_framed ctx ns room "Q" "a" a.source "Q" "b" b.source]

theorem advance_both {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (ns : List Nat)
    (room : c.top+ns.length≤PoolCalls.capacity) (a b : Input) (an bn : Endpoint) :
    CursorFrames.advance l (both c a b an bn) ns=both (CursorFrames.advance l c ns) a b an bn := by
  unfold both
  rw [CursorLocals.advance_allocated (first_valid ctx a b an) ns room,advance_first ctx ns room a b an]

theorem cross_first {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) (a b : Input) (an n : Endpoint) (d : Nat) :
    RationalCrossCalls.c3 l (first c a b an) n d=first (RationalCrossCalls.c3 l c n d) a b an := by
  exact advance_first ctx [0,n.magnitude*d,0] (by simp;omega) a b an

theorem cross_result_first {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (a b : Input) (an n : Endpoint) (d : Nat) :
    RationalCrossCalls.result l (first c a b an) n d=RationalCrossCalls.result l c n d := by
  unfold RationalCrossCalls.result RationalCrossCalls.c1
  rw [next_first ctx a b an 0]
  rfl

theorem make_both {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+4<PoolCalls.capacity) (a b : Input) (an bn n : Endpoint) (d : Nat) :
    RationalMakeCalls.c5 l (both c a b an bn) n d=both (RationalMakeCalls.c5 l c n d) a b an bn := by
  exact advance_both ctx [0,RationalMakeCalls.divisor n d,n.magnitude/RationalMakeCalls.divisor n d,0,d/RationalMakeCalls.divisor n d]
    (by simp;omega) a b an bn

theorem make_result_both {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+4<PoolCalls.capacity) (a b : Input) (an bn n : Endpoint) (d : Nat) :
    RationalMakeCalls.result l (both c a b an bn) n d=RationalMakeCalls.result l c n d := by
  have two := advance_both ctx [0,RationalMakeCalls.divisor n d] (by simp;omega) a b an bn
  have four := advance_both ctx [0,RationalMakeCalls.divisor n d,n.magnitude/RationalMakeCalls.divisor n d,0] (by simp;omega) a b an bn
  change RationalMakeCalls.c2 l (both c a b an bn) n d=both (RationalMakeCalls.c2 l c n d) a b an bn at two
  change RationalMakeCalls.c4 l (both c a b an bn) n d=both (RationalMakeCalls.c4 l c n d) a b an bn at four
  unfold RationalMakeCalls.result RationalMakeCalls.numSlot RationalMakeCalls.denSlot
  rw [two,four]
  rfl

end ScopedC.RationalAddFrames
