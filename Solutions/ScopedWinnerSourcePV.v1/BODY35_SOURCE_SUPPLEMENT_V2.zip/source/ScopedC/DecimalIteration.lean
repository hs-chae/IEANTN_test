/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalExpressions

namespace ScopedC.DecimalExpressions
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem four_shape (l : PoolLayout) (c : Cursor) (a d : Nat) :
    (DecimalCalls.c4 l c a d).state.heap.length=c.state.heap.length ∧
    (DecimalCalls.c4 l c a d).state.env=c.state.env := by
  have h1 := shape l c 10
  have h2 := shape l (DecimalCalls.c1 l c) (a*10)
  have h3 := shape l (DecimalCalls.c2 l c a) d
  have h4 := shape l (DecimalCalls.c3 l c a d) (a*10+d)
  exact ⟨h4.1.trans (h3.1.trans (h2.1.trans h1.1)),h4.2.trans (h3.2.trans (h2.2.trans h1.2))⟩

/-- One actual C while-body, using the independently derived nested-call
    expression execution. Full-loop/call closure is a separate obligation. -/
theorem source_iteration (service : Call) {l : PoolLayout} {c : Cursor}
    {buf : Address} {slot k a : Nat} {digits : List Nat}
    (hbuf : DecimalBuffer.At c.state buf digits) (hk : k<digits.length)
    (hd : digits[k]<10) (length : digits.length<2^32)
    (rhs : evalExpr Header.layout service 8 (DecimalFrames.loop c.state buf slot k) accumulator =
      some (.natObject (DecimalCalls.resultSlot l c a digits[k]),
        DecimalFrames.loop (DecimalCalls.c4 l c a digits[k]).state buf slot k)) :
    Run Header.layout service iteration (DecimalFrames.loop c.state buf slot k)
      (.continuing (DecimalFrames.loop (DecimalCalls.c4 l c a digits[k]).state buf
        (DecimalCalls.resultSlot l c a digits[k]) (k+1))) := by
  let fresh := DecimalCalls.resultSlot l c a digits[k]
  let final := (DecimalCalls.c4 l c a digits[k]).state
  have freshLive : NatArena.Borrow final.nats fresh (a*10+digits[k]) :=
    next_borrow l (DecimalCalls.c3 l c a digits[k]) (a*10+digits[k])
  have setA : Eval Header.layout service (.binary "=" (.var "a") accumulator)
      (DecimalFrames.loop c.state buf slot k) (DecimalFrames.loop final buf fresh k) (.natObject fresh) := by
    refine ⟨9,?_⟩
    rw [evalExpr,rhs]
    simp only [Bind.bind,Option.bind]
    rw [DecimalFrames.lvalue_a]
    exact DecimalFrames.write_a freshLive
  have increment : evalExpr Header.layout service 4 (DecimalFrames.loop final buf fresh k)
      (.binary "+" (.var "k") (.nat 1)) =
      some (unsigned32 (k+1),DecimalFrames.loop final buf fresh k) :=
    ExpressionTemplates.binary Header.layout service
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (DecimalFrames.eval_k service 2 final buf fresh k)
      (show evalExpr Header.layout service 3 (DecimalFrames.loop final buf fresh k) (.nat 1) =
        some (.integer ⟨⟨true,32⟩,1⟩,DecimalFrames.loop final buf fresh k) from rfl)
      (binary_add_one _ _ (by omega))
  have setK : Eval Header.layout service (.binary "=" (.var "k") (.binary "+" (.var "k") (.nat 1)))
      (DecimalFrames.loop final buf fresh k) (DecimalFrames.loop final buf fresh (k+1)) (unsigned32 (k+1)) := by
    refine ⟨5,?_⟩
    rw [evalExpr,increment]
    simp only [Bind.bind,Option.bind]
    rw [DecimalFrames.lvalue_k]
    exact DecimalFrames.write_k _ _ _ _ _ (by omega)
  have guard : Run Header.layout service (.branch invalid (.eval (.call (.var "fail") [])) .skip)
      (DecimalFrames.loop c.state buf slot k) (.continuing (DecimalFrames.loop c.state buf slot k)) := by
    apply Loops.StmtRun.branch (source_guard service hbuf hk hd)
    exact Loops.StmtRun.skip _
  have shape := four_shape l c a digits[k]
  have heap : (DecimalFrames.loop final buf fresh (k+1)).heap.length =
      (DecimalFrames.loop c.state buf slot k).heap.length := by
    simp [DecimalFrames.loop,DecimalFrames.parameter,allocate,final,shape.1]
  have env : (DecimalFrames.loop final buf fresh (k+1)).env =
      (DecimalFrames.loop c.state buf slot k).env := by
    simp [DecimalFrames.loop,DecimalFrames.parameter,allocate,final,shape.1]
  apply Loops.StmtRun.sequence
  · exact Loops.SeqRun.next guard
      (Loops.SeqRun.next (Loops.StmtRun.evaluate setA)
        (Loops.SeqRun.next (Loops.StmtRun.evaluate setK) (Loops.SeqRun.nil _)))
  · exact (pop_same heap env).symm

end ScopedC.DecimalExpressions
