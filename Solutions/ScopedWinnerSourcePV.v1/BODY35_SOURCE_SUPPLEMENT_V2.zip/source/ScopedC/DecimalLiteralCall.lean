/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalCalls

namespace ScopedC.DecimalCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- The source's literal10 has signed-int type before the callee's verified
    unsigned parameter conversion. No caller-side cast is silently inserted. -/
theorem source_literal_ten (code : List Function)
    (nuInstalled : Generated.f_nu∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolLayout} {c : Cursor} (buf : Address) (slot k : Nat)
    (h : Valid l c) (room : c.top<capacity) :
    SourceCall Header.layout code 2 "nu" [DecimalDigits.integer 10]
      (DecimalFrames.loop c.state buf slot k)
      (.natObject (tenSlot c)) (DecimalFrames.loop (c1 l c).state buf slot k) := by
  have move := DecimalFrames.result_loop (n:=10) h buf slot k
  have first := nu_call (n:=10) (input:=DecimalDigits.integer 10) code nuInstalled keepInstalled
    (DecimalFrames.context h buf slot k) room (by decide +kernel) rfl
  simpa only [tenSlot,DecimalFrames.nats,move,c1,next] using first

end ScopedC.DecimalCalls
