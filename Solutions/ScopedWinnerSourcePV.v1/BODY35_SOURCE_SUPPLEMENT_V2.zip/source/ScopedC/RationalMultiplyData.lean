/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalAddRefinement
import ScopedC.CursorBorrow

namespace ScopedC.RationalMultiplyCalls
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

def g (a b : Input) : Nat := a.numerator.magnitude.gcd b.denominator
def h (a b : Input) : Nat := b.numerator.magnitude.gcd a.denominator
def c1 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l c (g a b)
def c2 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c1 l c a b) (h a b)
def c3 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c2 l c a b) (a.numerator.magnitude/g a b)
def c4 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c3 l c a b) 0
def left (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Endpoint :=
  ⟨(c2 l c a b).state.nats.values.length,a.numerator.magnitude/g a b,
    if a.numerator.magnitude/g a b=0 then false else a.numerator.negative⟩
def c5 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c4 l c a b) (b.numerator.magnitude/h a b)
@[irreducible] def c6 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c5 l c a b) 0
def right (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Endpoint :=
  ⟨(c4 l c a b).state.nats.values.length,b.numerator.magnitude/h a b,
    if b.numerator.magnitude/h a b=0 then false else b.numerator.negative⟩
def productMagnitude (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Nat :=
  (left l c a b).magnitude*(right l c a b).magnitude
def c7 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c6 l c a b) (productMagnitude l c a b)
def c8 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c7 l c a b) 0
def top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Endpoint :=
  ⟨(c6 l c a b).state.nats.values.length,productMagnitude l c a b,
    if productMagnitude l c a b=0 then false else (left l c a b).negative != (right l c a b).negative⟩
def c9 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c8 l c a b) (a.denominator/h a b)
def c10 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c9 l c a b) (b.denominator/g a b)
def den (a b : Input) : Nat := (a.denominator/h a b)*(b.denominator/g a b)
def c11 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c10 l c a b) (den a b)
def result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Value :=
  Input.source ⟨top l c a b,(c10 l c a b).state.nats.values.length,den a b⟩

theorem g_pos (a b : Input) (hb : 0<b.denominator) : 0<g a b := Nat.gcd_pos_of_pos_right _ hb
theorem h_pos (a b : Input) (ha : 0<a.denominator) : 0<h a b := Nat.gcd_pos_of_pos_right _ ha

theorem left_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (left l c a b).Live (c4 l c a b).state := preserves (next_borrow l (c2 l c a b) _)
theorem right_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (right l c a b).Live (c6 l c a b).state := by
  unfold c6
  exact preserves (next_borrow l (c4 l c a b) _)
theorem top_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (top l c a b).Live (c11 l c a b).state :=
  CursorBorrow.preserves (c:=c7 l c a b) [0,a.denominator/h a b,b.denominator/g a b,den a b]
    (next_borrow l (c6 l c a b) (productMagnitude l c a b))

theorem den_pos (a b : Input) (ha : 0<a.denominator) (hb : 0<b.denominator) : 0<den a b :=
  Nat.mul_pos (Nat.div_pos (Nat.le_of_dvd ha (Nat.gcd_dvd_right _ _)) (h_pos a b ha))
    (Nat.div_pos (Nat.le_of_dvd hb (Nat.gcd_dvd_right _ _)) (g_pos a b hb))

theorem decoded (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (ha : 0<a.denominator) (hb : 0<b.denominator) :
    NumericRepresentation.rational (c11 l c a b).state (result l c a b)=some ⟨(top l c a b).mathematical,den a b⟩ :=
  Input.decoded (s:=(c11 l c a b).state) (q:=⟨top l c a b,(c10 l c a b).state.nats.values.length,den a b⟩)
    ⟨top_live l c a b,next_borrow l (c10 l c a b) (den a b)⟩ (den_pos a b ha hb)

end ScopedC.RationalMultiplyCalls
