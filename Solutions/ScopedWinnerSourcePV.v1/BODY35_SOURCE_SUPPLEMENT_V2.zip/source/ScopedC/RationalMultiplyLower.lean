/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyFrameCalls
import ScopedC.RationalMultiplyInvariants

namespace ScopedC.RationalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
open ScopedC.RationalMultiplyFrames (gFrame ghFrame topFrame)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

/-- A derived package of ten actual lower source executions. Every field is
proved below; this package is never an application/runtime contract. -/
structure Lower (code : List Function) (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Prop where
  gCall : SourceCall Header.layout code 2 "ng" [.natObject a.numerator.slot,.natObject b.denSlot]
    (frame c.state a b) (.natObject c.state.nats.values.length) (frame (c1 l c a b).state a b)
  hCall : SourceCall Header.layout code 2 "ng" [.natObject b.numerator.slot,.natObject a.denSlot]
    (gFrame (c1 l c a b).state a b c.state.nats.values.length) (.natObject (c1 l c a b).state.nats.values.length)
    (gFrame (c2 l c a b).state a b c.state.nats.values.length)
  aDiv : SourceCall Header.layout code 2 "nd" [.natObject a.numerator.slot,.natObject c.state.nats.values.length]
    (ghFrame (c2 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length)
    (.natObject (c2 l c a b).state.nats.values.length)
    (ghFrame (c3 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length)
  aMake : SourceCall Header.layout code 4 "smake" [.natObject (c2 l c a b).state.nats.values.length,unsigned32 (SignedNegCalls.bit a.numerator.negative)]
    (ghFrame (c3 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length) (left l c a b).source
    (ghFrame (c4 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length)
  bDiv : SourceCall Header.layout code 2 "nd" [.natObject b.numerator.slot,.natObject (c1 l c a b).state.nats.values.length]
    (ghFrame (c4 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length)
    (.natObject (c4 l c a b).state.nats.values.length)
    (ghFrame (c5 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length)
  bMake : SourceCall Header.layout code 4 "smake" [.natObject (c4 l c a b).state.nats.values.length,unsigned32 (SignedNegCalls.bit b.numerator.negative)]
    (ghFrame (c5 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length) (right l c a b).source
    (ghFrame (c6 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length)
  topCall : SourceCall Header.layout code 5 "sm" [(left l c a b).source,(right l c a b).source]
    (ghFrame (c6 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length) (top l c a b).source
    (ghFrame (c8 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length)
  aDen : SourceCall Header.layout code 2 "nd" [.natObject a.denSlot,.natObject (c1 l c a b).state.nats.values.length]
    (topFrame (c8 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b))
    (.natObject (c8 l c a b).state.nats.values.length)
    (topFrame (c9 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b))
  bDen : SourceCall Header.layout code 2 "nd" [.natObject b.denSlot,.natObject c.state.nats.values.length]
    (topFrame (c9 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b))
    (.natObject (c9 l c a b).state.nats.values.length)
    (topFrame (c10 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b))
  denCall : SourceCall Header.layout code 2 "nm" [.natObject (c8 l c a b).state.nats.values.length,.natObject (c9 l c a b).state.nats.values.length]
    (topFrame (c10 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b))
    (.natObject (c10 l c a b).state.nats.values.length)
    (topFrame (c11 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b))

theorem lower_calls (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+10<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    Lower code l c a b := by
  obtain ⟨ctx1,ctx2,ctx3,ctx4,ctx5,ctx6,ctx7,ctx8,ctx9,ctx10,ctx11⟩ := contexts ctx room a b
  have ah2 := input2 (l:=l) (c:=c) (a:=a) (b:=b) ha
  have bh4 := input4 (l:=l) (c:=c) (a:=a) (b:=b) hb
  have ah6 := input6 (l:=l) (c:=c) (a:=a) (b:=b) ha
  have bh6 := input6 (l:=l) (c:=c) (a:=a) (b:=b) hb
  have ah7 := Input.live_after (l:=l) (c:=c6 l c a b) (n:=productMagnitude l c a b) ah6
  have ah8 := Input.live_after (l:=l) (c:=c7 l c a b) (n:=0) ah7
  have bh7 := Input.live_after (l:=l) (c:=c6 l c a b) (n:=productMagnitude l c a b) bh6
  have bh8 := Input.live_after (l:=l) (c:=c7 l c a b) (n:=0) bh7
  have bh9 := Input.live_after (l:=l) (c:=c8 l c a b) (n:=a.denominator/h a b) bh8
  have gh7 := preserves (l:=l) (c:=c6 l c a b) (n:=productMagnitude l c a b) (g_live6 l c a b)
  have gh8 := preserves (l:=l) (c:=c7 l c a b) (n:=0) gh7
  have gh9 := preserves (l:=l) (c:=c8 l c a b) (n:=a.denominator/h a b) gh8
  have hh7 := preserves (l:=l) (c:=c6 l c a b) (n:=productMagnitude l c a b) (h_live6 l c a b)
  have hh8 := preserves (l:=l) (c:=c7 l c a b) (n:=0) hh7
  refine ⟨ng_parameters code lib ctx (by omega) a b ha.1 hb.2,
    ng_g code lib ctx1 (by change c.top+1<PoolCalls.capacity;omega) a b c.state.nats.values.length
      (Input.live_after hb).1 (Input.live_after ha).2,
    nd_gh code lib ctx2 (by change c.top+2<PoolCalls.capacity;omega) a b c.state.nats.values.length (c1 l c a b).state.nats.values.length
      ah2.1 (g_live2 l c a b) (Nat.ne_of_gt (g_pos a b pb)),
    smake_gh code lib ctx3 (by change c.top+3<PoolCalls.capacity;omega) a b c.state.nats.values.length (c1 l c a b).state.nats.values.length
      a.numerator.negative (next_borrow l (c2 l c a b) (a.numerator.magnitude/g a b)),
    nd_gh code lib ctx4 (by change c.top+4<PoolCalls.capacity;omega) a b c.state.nats.values.length (c1 l c a b).state.nats.values.length
      bh4.1 (h_live4 l c a b) (Nat.ne_of_gt (h_pos a b pa)),?_,?_,
    nd_top code lib ctx8 (by change (c6 l c a b).top+2<PoolCalls.capacity;rw[top6];omega) a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)
      ah8.2 hh8 (Nat.ne_of_gt (h_pos a b pa)),
    nd_top code lib ctx9 (by change (c6 l c a b).top+3<PoolCalls.capacity;rw[top6];omega) a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)
      bh9.2 gh9 (Nat.ne_of_gt (g_pos a b pb)),
    nm_top code lib ctx10 (by change (c6 l c a b).top+4<PoolCalls.capacity;rw[top6];omega) a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)
      (preserves (next_borrow l (c8 l c a b) (a.denominator/h a b)))
      (next_borrow l (c9 l c a b) (b.denominator/g a b))⟩
  · simpa only[c6,right,ArithmeticCursorCalls.normal]using
      smake_gh code lib ctx5 (by change c.top+5<PoolCalls.capacity;omega) a b c.state.nats.values.length (c1 l c a b).state.nats.values.length
        b.numerator.negative (next_borrow l (c4 l c a b) (b.numerator.magnitude/h a b))
  · exact sm_gh code lib ctx6 (by rw[top6];omega) a b c.state.nats.values.length (c1 l c a b).state.nats.values.length
      (left l c a b) (right l c a b) (left_live6 l c a b) (right_live l c a b)

end ScopedC.RationalMultiplyCalls
