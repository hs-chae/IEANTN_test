/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCrossCursor

namespace ScopedC.RationalLocalFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def first (s : State) (a b : Input) (an : Endpoint) : State :=
  allocate (frame s a b) "S" "an" (some an.source)
def both (s : State) (a b : Input) (an bn : Endpoint) : State :=
  allocate (first s a b an) "S" "bn" (some bn.source)

theorem eval_a_first (call : Call) (fuel : Nat) (s : State) (a b : Input) (an : Endpoint) :
    evalExpr Header.layout call (fuel+1) (first s a b an) (.var "a")=some (a.source,first s a b an) := by
  simp [evalExpr,getVar,first,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_b_first (call : Call) (fuel : Nat) (s : State) (a b : Input) (an : Endpoint) :
    evalExpr Header.layout call (fuel+1) (first s a b an) (.var "b")=some (b.source,first s a b an) := by
  simp [evalExpr,getVar,first,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_a_both (call : Call) (fuel : Nat) (s : State) (a b : Input) (an bn : Endpoint) :
    evalExpr Header.layout call (fuel+1) (both s a b an bn) (.var "a")=some (a.source,both s a b an bn) := by
  simp [evalExpr,getVar,both,first,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_b_both (call : Call) (fuel : Nat) (s : State) (a b : Input) (an bn : Endpoint) :
    evalExpr Header.layout call (fuel+1) (both s a b an bn) (.var "b")=some (b.source,both s a b an bn) := by
  simp [evalExpr,getVar,both,first,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_an_both (call : Call) (fuel : Nat) (s : State) (a b : Input) (an bn : Endpoint) :
    evalExpr Header.layout call (fuel+1) (both s a b an bn) (.var "an")=some (an.source,both s a b an bn) := by
  simp [evalExpr,getVar,both,first,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_bn_both (call : Call) (fuel : Nat) (s : State) (a b : Input) (an bn : Endpoint) :
    evalExpr Header.layout call (fuel+1) (both s a b an bn) (.var "bn")=some (bn.source,both s a b an bn) := by
  simp [evalExpr,getVar,both,first,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]

theorem eval_b_num_first (call : Call) (fuel : Nat) (s : State) (a b : Input) (an : Endpoint) :
    evalExpr Header.layout call (fuel+2) (first s a b an) (.field "." (.var "b") "num")=
      some (b.numerator.source,first s a b an) := by
  apply ExpressionTemplates.field Header.layout call (eval_b_first call fuel s a b an)
  rfl

theorem eval_a_den_first (call : Call) (fuel : Nat) (s : State) (a b : Input) (an : Endpoint) :
    evalExpr Header.layout call (fuel+2) (first s a b an) (.field "." (.var "a") "den")=
      some (.natObject a.denSlot,first s a b an) := by
  apply ExpressionTemplates.field Header.layout call (eval_a_first call fuel s a b an)
  rfl

theorem eval_a_den_both (call : Call) (fuel : Nat) (s : State) (a b : Input) (an bn : Endpoint) :
    evalExpr Header.layout call (fuel+2) (both s a b an bn) (.field "." (.var "a") "den")=
      some (.natObject a.denSlot,both s a b an bn) := by
  apply ExpressionTemplates.field Header.layout call (eval_a_both call fuel s a b an bn)
  rfl

theorem eval_b_den_both (call : Call) (fuel : Nat) (s : State) (a b : Input) (an bn : Endpoint) :
    evalExpr Header.layout call (fuel+2) (both s a b an bn) (.field "." (.var "b") "den")=
      some (.natObject b.denSlot,both s a b an bn) := by
  apply ExpressionTemplates.field Header.layout call (eval_b_both call fuel s a b an bn)
  rfl

end ScopedC.RationalLocalFrames
