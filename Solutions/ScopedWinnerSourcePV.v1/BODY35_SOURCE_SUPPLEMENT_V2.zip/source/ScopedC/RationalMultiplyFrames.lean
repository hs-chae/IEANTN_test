/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyMath

namespace ScopedC.RationalMultiplyFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor ScopedC.DyadicRepresentation ScopedC.NatWrapperCalls
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def gFrame (s : State) (a b : Input) (g : Nat) : State := allocate (frame s a b) "N" "g" (some (.natObject g))
def ghFrame (s : State) (a b : Input) (g h : Nat) : State := allocate (gFrame s a b g) "N" "h" (some (.natObject h))
def gh (c : Cursor) (a b : Input) (g h : Nat) : Cursor :=
  CursorLocals.allocated (CursorLocals.allocated (CursorFrames.framed c "Q" "a" a.source "Q" "b" b.source) "N" "g" (.natObject g)) "N" "h" (.natObject h)

theorem gh_valid {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (g h : Nat) :
    Valid l (gh c a b g h) :=
  CursorLocals.allocated_valid (CursorLocals.allocated_valid
    (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source) "N" "g" (.natObject g)) "N" "h" (.natObject h)

theorem next_gh {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (a b : Input) (g h n : Nat) :
    next l (gh c a b g h) n=gh (next l c n) a b g h := by
  unfold gh
  rw [CursorLocals.next_allocated (CursorLocals.allocated_valid
      (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source) "N" "g" (.natObject g)),
    CursorLocals.next_allocated (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source),
    CursorFrames.next_framed ctx "Q" "a" a.source "Q" "b" b.source n]

theorem eval_a (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+1) (ghFrame s a b g h) (.var "a")=some (a.source,ghFrame s a b g h) := by
  simp [evalExpr,getVar,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]
theorem eval_b (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+1) (ghFrame s a b g h) (.var "b")=some (b.source,ghFrame s a b g h) := by
  simp [evalExpr,getVar,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized,Input.source,Endpoint.source,SignedValues.value,unsigned32]
theorem eval_g (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+1) (ghFrame s a b g h) (.var "g")=some (.natObject g,ghFrame s a b g h) := by
  simp [evalExpr,getVar,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized]
theorem eval_h (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+1) (ghFrame s a b g h) (.var "h")=some (.natObject h,ghFrame s a b g h) := by
  simp [evalExpr,getVar,ghFrame,gFrame,frame,TwoFrames.frame,allocate,List.lookup,List.getElem?_append,
    Machine.read,nested,initialized]

theorem eval_a_num (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+2) (ghFrame s a b g h) (.field "." (.var "a") "num")=some (a.numerator.source,ghFrame s a b g h) := by
  apply ExpressionTemplates.field Header.layout call (eval_a call fuel s a b g h);rfl
theorem eval_b_num (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+2) (ghFrame s a b g h) (.field "." (.var "b") "num")=some (b.numerator.source,ghFrame s a b g h) := by
  apply ExpressionTemplates.field Header.layout call (eval_b call fuel s a b g h);rfl

theorem eval_a_mag (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+3) (ghFrame s a b g h) (.field "." (.field "." (.var "a") "num") "mag")=some (.natObject a.numerator.slot,ghFrame s a b g h) := by
  apply ExpressionTemplates.field Header.layout call (eval_a_num call fuel s a b g h);rfl
theorem eval_b_mag (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+3) (ghFrame s a b g h) (.field "." (.field "." (.var "b") "num") "mag")=some (.natObject b.numerator.slot,ghFrame s a b g h) := by
  apply ExpressionTemplates.field Header.layout call (eval_b_num call fuel s a b g h);rfl
theorem eval_a_neg (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+3) (ghFrame s a b g h) (.field "." (.field "." (.var "a") "num") "neg")=some (unsigned32 (SignedNegCalls.bit a.numerator.negative),ghFrame s a b g h) := by
  apply ExpressionTemplates.field Header.layout call (eval_a_num call fuel s a b g h);rfl
theorem eval_b_neg (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+3) (ghFrame s a b g h) (.field "." (.field "." (.var "b") "num") "neg")=some (unsigned32 (SignedNegCalls.bit b.numerator.negative),ghFrame s a b g h) := by
  apply ExpressionTemplates.field Header.layout call (eval_b_num call fuel s a b g h);rfl

theorem eval_a_den (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+2) (ghFrame s a b g h) (.field "." (.var "a") "den")=some (.natObject a.denSlot,ghFrame s a b g h) := by
  apply ExpressionTemplates.field Header.layout call (eval_a call fuel s a b g h);rfl
theorem eval_b_den (call : Call) (fuel : Nat) (s : State) (a b : Input) (g h : Nat) :
    evalExpr Header.layout call (fuel+2) (ghFrame s a b g h) (.field "." (.var "b") "den")=some (.natObject b.denSlot,ghFrame s a b g h) := by
  apply ExpressionTemplates.field Header.layout call (eval_b call fuel s a b g h);rfl

end ScopedC.RationalMultiplyFrames
