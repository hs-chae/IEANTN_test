/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalAddRefinement

namespace ScopedNumerical.Rational
set_option autoImplicit false
set_option maxHeartbeats 0

theorem normalize_eq_self (q : Rational) (hq : q.Normalized) : normalize q.num q.den=q := by
  rcases q with ⟨⟨m,neg⟩,d⟩
  rcases hq with ⟨hd,hcop,hzero⟩
  have hg : m.gcd d=1 := hcop.gcd_eq_one
  change (⟨Signed.make (m/(m.gcd d)) neg,d/(m.gcd d)⟩:Rational)=⟨⟨m,neg⟩,d⟩
  rw[hg,Nat.div_one,Nat.div_one]
  by_cases hz : m=0
  · have hn : neg=false := hzero hz
    simp only[Signed.make,hz,↓reduceIte,hn]
  · simp only[Signed.make,hz,↓reduceIte]

theorem normalized_represents_value (q : Rational) (hq : q.Normalized) : q.Represents q.value := by
  have h := normalize_represents q.num q.den (Nat.ne_of_gt hq.1)
  rw [normalize_eq_self q hq] at h
  have hv := h.value_eq
  rw [←hv] at h
  exact h

end ScopedNumerical.Rational
