/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NatSmallCall
import ScopedC.ExpressionBinary

namespace ScopedC.DecimalDigits
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Actual signed-char representation of a decimal input digit. -/
def digit (d : Nat) : Value := .integer ⟨⟨true,8⟩,48+(d:Int)⟩
def char (n : Nat) : Value := .integer ⟨⟨true,8⟩,(n:Int)⟩
def integer (n : Nat) : Value := .integer ⟨⟨true,32⟩,(n:Int)⟩

theorem digit_initialized (d : Nat) : initialized 1000 (digit d) = true := rfl

/-- Both signed chars undergo the actual integer promotions before subtraction. -/
theorem subtract_zero (s : State) (d : Nat) (hd : d < 10) :
    binaryValue Header.layout s "-" (digit d) (char 48) = some (integer d) := by
  interval_cases d <;> rfl

theorem lower_guard (s : State) (d : Nat) (hd : d < 10) :
    binaryValue Header.layout s "<" (digit d) (char 48) = some (boolean Header.layout false) := by
  interval_cases d <;> rfl

theorem upper_guard (s : State) (d : Nat) (hd : d < 10) :
    binaryValue Header.layout s ">" (digit d) (char 57) = some (boolean Header.layout false) := by
  interval_cases d <;> rfl

theorem digit_nonzero (s : State) (d : Nat) (hd : d < 10) :
    binaryValue Header.layout s "!=" (digit d) (integer 0) = some (boolean Header.layout true) := by
  interval_cases d <;> rfl

theorem terminator_zero (s : State) :
    binaryValue Header.layout s "!=" (char 0) (integer 0) = some (boolean Header.layout false) := by
  rfl

theorem cast_digit (s : State) (d : Nat) (hd : d < 10) :
    castValue Header.layout s 100 "unsigned int" (integer d) = some (unsigned32 d) := by
  interval_cases d <;> rfl

end ScopedC.DecimalDigits
