/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyFramesExtra
import ScopedC.ArithmeticCursorCalls

namespace ScopedC.RationalMultiplyCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

structure Library (code : List Function) : Prop where
  ng : Generated.f_ng∈code
  nd : Generated.f_nd∈code
  nm : Generated.f_nm∈code
  sm : Generated.f_sm∈code
  smake : Generated.f_smake∈code
  nz : Generated.f_nz∈code
  nu : Generated.f_nu∈code
  ne : Generated.f_ne∈code
  keep : Generated.f_keep∈code

theorem ng_parameters (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) {aslot bslot an bn : Nat}
    (ha : NatArena.Borrow c.state.nats aslot an) (hb : NatArena.Borrow c.state.nats bslot bn) :
    SourceCall Header.layout code 2 "ng" [.natObject aslot,.natObject bslot] (frame c.state a b)
      (.natObject c.state.nats.values.length) (frame (next l c (an.gcd bn)).state a b) := by
  have p := ArithmeticCursorCalls.ng code lib.ng lib.keep
    (c:=CursorFrames.framed c "Q" "a" a.source "Q" "b" b.source)
    (CursorFrames.framed_valid ctx "Q" "a" a.source "Q" "b" b.source) room ha hb
  rw [CursorFrames.next_framed ctx "Q" "a" a.source "Q" "b" b.source (an.gcd bn)] at p
  exact p

theorem ng_g (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) (g : Nat) {aslot bslot an bn : Nat}
    (ha : NatArena.Borrow c.state.nats aslot an) (hb : NatArena.Borrow c.state.nats bslot bn) :
    SourceCall Header.layout code 2 "ng" [.natObject aslot,.natObject bslot] (RationalMultiplyFrames.gFrame c.state a b g)
      (.natObject c.state.nats.values.length) (RationalMultiplyFrames.gFrame (next l c (an.gcd bn)).state a b g) := by
  have p := ArithmeticCursorCalls.ng code lib.ng lib.keep
    (c:=RationalMultiplyFrames.gCursor c a b g) (RationalMultiplyFrames.g_valid ctx a b g) room ha hb
  rw [RationalMultiplyFrames.next_g ctx a b g (an.gcd bn)] at p
  exact p

theorem nd_gh (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) (g h : Nat) {aslot bslot an bn : Nat}
    (ha : NatArena.Borrow c.state.nats aslot an) (hb : NatArena.Borrow c.state.nats bslot bn) (nz : bn≠0) :
    SourceCall Header.layout code 2 "nd" [.natObject aslot,.natObject bslot] (RationalMultiplyFrames.ghFrame c.state a b g h)
      (.natObject c.state.nats.values.length) (RationalMultiplyFrames.ghFrame (next l c (an/bn)).state a b g h) := by
  have p := ArithmeticCursorCalls.nd code lib.nd lib.keep
    (c:=RationalMultiplyFrames.gh c a b g h) (RationalMultiplyFrames.gh_valid ctx a b g h) room ha hb nz
  rw [RationalMultiplyFrames.next_gh ctx a b g h (an/bn)] at p
  exact p

theorem smake_gh (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) (g h : Nat) {slot n : Nat} (sign : Bool) (hn : NatArena.Borrow c.state.nats slot n) :
    SourceCall Header.layout code 4 "smake" [.natObject slot,unsigned32 (SignedNegCalls.bit sign)]
      (RationalMultiplyFrames.ghFrame c.state a b g h) (ArithmeticCursorCalls.normal slot n sign).source
      (RationalMultiplyFrames.ghFrame (next l c 0).state a b g h) := by
  have p := ArithmeticCursorCalls.smake code lib.smake lib.nz lib.nu lib.ne lib.keep
    (c:=RationalMultiplyFrames.gh c a b g h) (RationalMultiplyFrames.gh_valid ctx a b g h) room sign hn
  rw [RationalMultiplyFrames.next_gh ctx a b g h 0] at p
  exact p

theorem sm_gh (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+1<PoolCalls.capacity)
    (a b : Input) (g h : Nat) (x y : Endpoint) (hx : x.Live c.state) (hy : y.Live c.state) :
    SourceCall Header.layout code 5 "sm" [x.source,y.source]
      (RationalMultiplyFrames.ghFrame c.state a b g h)
      (ArithmeticCursorCalls.normal c.state.nats.values.length (x.magnitude*y.magnitude) (x.negative != y.negative)).source
      (RationalMultiplyFrames.ghFrame (next l (next l c (x.magnitude*y.magnitude)) 0).state a b g h) := by
  have p := ArithmeticCursorCalls.sm code lib.sm lib.nm lib.smake lib.nz lib.nu lib.ne lib.keep
    (c:=RationalMultiplyFrames.gh c a b g h) (RationalMultiplyFrames.gh_valid ctx a b g h) room x y hx hy
  rw [RationalMultiplyFrames.next_gh ctx a b g h (x.magnitude*y.magnitude),
    RationalMultiplyFrames.next_gh (next_valid (x.magnitude*y.magnitude) ctx (by omega)) a b g h 0] at p
  exact p

theorem nd_top (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) (g h : Nat) (top : Endpoint) {aslot bslot an bn : Nat}
    (ha : NatArena.Borrow c.state.nats aslot an) (hb : NatArena.Borrow c.state.nats bslot bn) (nz : bn≠0) :
    SourceCall Header.layout code 2 "nd" [.natObject aslot,.natObject bslot]
      (RationalMultiplyFrames.topFrame c.state a b g h top) (.natObject c.state.nats.values.length)
      (RationalMultiplyFrames.topFrame (next l c (an/bn)).state a b g h top) := by
  have p := ArithmeticCursorCalls.nd code lib.nd lib.keep
    (c:=RationalMultiplyFrames.withTop c a b g h top) (RationalMultiplyFrames.top_valid ctx a b g h top) room ha hb nz
  rw [RationalMultiplyFrames.next_top ctx a b g h (an/bn) top] at p
  exact p

theorem nm_top (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) (g h : Nat) (top : Endpoint) {aslot bslot an bn : Nat}
    (ha : NatArena.Borrow c.state.nats aslot an) (hb : NatArena.Borrow c.state.nats bslot bn) :
    SourceCall Header.layout code 2 "nm" [.natObject aslot,.natObject bslot]
      (RationalMultiplyFrames.topFrame c.state a b g h top) (.natObject c.state.nats.values.length)
      (RationalMultiplyFrames.topFrame (next l c (an*bn)).state a b g h top) := by
  have p := ArithmeticCursorCalls.nm code lib.nm lib.keep
    (c:=RationalMultiplyFrames.withTop c a b g h top) (RationalMultiplyFrames.top_valid ctx a b g h top) room ha hb
  rw [RationalMultiplyFrames.next_top ctx a b g h (an*bn) top] at p
  exact p

end ScopedC.RationalMultiplyCalls
