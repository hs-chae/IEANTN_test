/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.NumericRationalAddRefinement

namespace ScopedC.ArithmeticCursorCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def normal (slot n : Nat) (sign : Bool) : Endpoint := ⟨slot,n,if n=0 then false else sign⟩

theorem ng (code : List Function) (installed : Generated.f_ng∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    {aslot bslot an bn : Nat} (ha : NatArena.Borrow c.state.nats aslot an) (hb : NatArena.Borrow c.state.nats bslot bn) :
    SourceCall Header.layout code 2 "ng" [.natObject aslot,.natObject bslot] c.state
      (.natObject c.state.nats.values.length) (next l c (an.gcd bn)).state :=
  ng_call code installed keepInstalled ctx room ha hb

theorem nd (code : List Function) (installed : Generated.f_nd∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    {aslot bslot an bn : Nat} (ha : NatArena.Borrow c.state.nats aslot an) (hb : NatArena.Borrow c.state.nats bslot bn)
    (nonzero : bn≠0) :
    SourceCall Header.layout code 2 "nd" [.natObject aslot,.natObject bslot] c.state
      (.natObject c.state.nats.values.length) (next l c (an/bn)).state :=
  nd_call code installed keepInstalled ctx room ha hb nonzero

theorem nm (code : List Function) (installed : Generated.f_nm∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    {aslot bslot an bn : Nat} (ha : NatArena.Borrow c.state.nats aslot an) (hb : NatArena.Borrow c.state.nats bslot bn) :
    SourceCall Header.layout code 2 "nm" [.natObject aslot,.natObject bslot] c.state
      (.natObject c.state.nats.values.length) (next l c (an*bn)).state :=
  nm_call code installed keepInstalled ctx room ha hb

theorem smake (code : List Function) (installed : Generated.f_smake∈code)
    (nzInstalled : Generated.f_nz∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    {slot n : Nat} (sign : Bool) (live : NatArena.Borrow c.state.nats slot n) :
    SourceCall Header.layout code 4 "smake" [.natObject slot,unsigned32 (SignedNegCalls.bit sign)]
      c.state (normal slot n sign).source (next l c 0).state := by
  have p := SignedCalls.smake_call (input:=unsigned32 (SignedNegCalls.bit sign)) code installed nzInstalled nuInstalled neInstalled keepInstalled
    ctx room live (SignedNegCalls.bit_bound sign)
    (RationalUnsignedCalls.cast_parameter
      (allocate {c.state with env:=[]} "N" "mag" (some (.natObject slot))) (SignedNegCalls.bit sign) (SignedNegCalls.bit_bound sign))
  by_cases hn : n=0 <;>
    simpa [normal,Endpoint.source,hn,SignedNegCalls.bit,next]using p

theorem sm (code : List Function) (installed : Generated.f_sm∈code) (nmInstalled : Generated.f_nm∈code)
    (smakeInstalled : Generated.f_smake∈code) (nzInstalled : Generated.f_nz∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+1<PoolCalls.capacity)
    (a b : Endpoint) (ha : a.Live c.state) (hb : b.Live c.state) :
    SourceCall Header.layout code 5 "sm" [a.source,b.source] c.state
      (normal c.state.nats.values.length (a.magnitude*b.magnitude) (a.negative != b.negative)).source
      (next l (next l c (a.magnitude*b.magnitude)) 0).state := by
  have p := SignedMultiplyCalls.sm_closed code installed nmInstalled smakeInstalled nzInstalled nuInstalled neInstalled keepInstalled
    (s:=c.state) (l:=l) (cells:=c.cells) (top:=c.top) (high:=c.high) a b ha hb ctx room
  by_cases hn : a.magnitude*b.magnitude=0 <;>
    simpa [normal,Endpoint.source,SignedMultiplyCalls.result,SignedMultiplyCalls.resultSign,
      hn,SignedNegCalls.bit,next,SignedMultiplyCalls.smResult,SignedCalls.siResult]using p

end ScopedC.ArithmeticCursorCalls
