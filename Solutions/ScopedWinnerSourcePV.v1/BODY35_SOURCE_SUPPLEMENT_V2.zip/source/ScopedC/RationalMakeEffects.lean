/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMakeBody
import ScopedC.CursorEffects

namespace ScopedC.RationalMakeEffects
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem shape (l : PoolCalls.PoolLayout) (c : Cursor) (n : Endpoint) (d : Nat) :
    (RationalMakeCalls.c5 l c n d).state.heap.length=c.state.heap.length ∧
    (RationalMakeCalls.c5 l c n d).state.env=c.state.env :=
  CursorEffects.shape l c [0,RationalMakeCalls.divisor n d,n.magnitude/RationalMakeCalls.divisor n d,0,d/RationalMakeCalls.divisor n d]

theorem cast_result (l : PoolCalls.PoolLayout) (c : Cursor) (n : Endpoint) (d : Nat)
    (a b : Value) :
    castValue Header.layout (TwoFrames.frame (RationalMakeCalls.c5 l c n d).state "Q" "a" a "Q" "b" b)
      100 "static Q" (RationalMakeCalls.result l c n d)=some (RationalMakeCalls.result l c n d) := by
  exact RecordCasts.rational_record _ 97 "static Q" (by decide +kernel)
    (RationalMakeCalls.numerator_live l c n d) (RationalMakeCalls.denominator_live l c n d)
    (by unfold RationalMakeCalls.sign;split;decide +kernel;exact SignedNegCalls.bit_bound _)

end ScopedC.RationalMakeEffects
