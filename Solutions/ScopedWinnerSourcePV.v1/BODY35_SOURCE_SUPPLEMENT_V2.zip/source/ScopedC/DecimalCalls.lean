/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalStores
import ScopedC.NatWrapperCalls

namespace ScopedC.DecimalCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c1 (l : PoolLayout) (c : Cursor) : Cursor := next l c 10
def c2 (l : PoolLayout) (c : Cursor) (a : Nat) : Cursor := next l (c1 l c) (a*10)
def c3 (l : PoolLayout) (c : Cursor) (a d : Nat) : Cursor := next l (c2 l c a) d
def c4 (l : PoolLayout) (c : Cursor) (a d : Nat) : Cursor := next l (c3 l c a d) (a*10+d)

def tenSlot (c : Cursor) : Nat := c.state.nats.values.length
def productSlot (l : PoolLayout) (c : Cursor) : Nat := (c1 l c).state.nats.values.length
def digitSlot (l : PoolLayout) (c : Cursor) (a : Nat) : Nat := (c2 l c a).state.nats.values.length
def resultSlot (l : PoolLayout) (c : Cursor) (a d : Nat) : Nat := (c3 l c a d).state.nats.values.length

theorem contexts {l : PoolLayout} {c : Cursor} (a d : Nat) (h : Valid l c)
    (room : c.top+3<capacity) :
    Valid l (c1 l c) ∧ Valid l (c2 l c a) ∧ Valid l (c3 l c a d) ∧ Valid l (c4 l c a d) := by
  have h1 : Valid l (c1 l c) := next_valid 10 h (by omega)
  have h2 : Valid l (c2 l c a) := next_valid (a*10) h1 (by change c.top+1<capacity;omega)
  have h3 : Valid l (c3 l c a d) := next_valid d h2 (by change c.top+1+1<capacity;omega)
  exact ⟨h1,h2,h3,next_valid (a*10+d) h3 (by change c.top+1+1+1<capacity;omega)⟩

/-- All four actual lower-rank calls in the parser's nested accumulator
    expression, including their concrete pool/ownership effects. -/
theorem lower_calls (code : List Function)
    (nuInstalled : Generated.f_nu∈code) (nmInstalled : Generated.f_nm∈code)
    (naInstalled : Generated.f_na∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolLayout} {c : Cursor} {slot a d : Nat} (buf : Address) (k : Nat)
    (live : NatArena.Borrow c.state.nats slot a) (digit : d<10)
    (h : Valid l c) (room : c.top+3<capacity) :
    SourceCall Header.layout code 2 "nu" [unsigned32 10] (DecimalFrames.loop c.state buf slot k)
      (.natObject (tenSlot c)) (DecimalFrames.loop (c1 l c).state buf slot k) ∧
    SourceCall Header.layout code 2 "nm" [.natObject slot,.natObject (tenSlot c)]
      (DecimalFrames.loop (c1 l c).state buf slot k)
      (.natObject (productSlot l c)) (DecimalFrames.loop (c2 l c a).state buf slot k) ∧
    SourceCall Header.layout code 2 "nu" [unsigned32 d] (DecimalFrames.loop (c2 l c a).state buf slot k)
      (.natObject (digitSlot l c a)) (DecimalFrames.loop (c3 l c a d).state buf slot k) ∧
    SourceCall Header.layout code 2 "na" [.natObject (productSlot l c),.natObject (digitSlot l c a)]
      (DecimalFrames.loop (c3 l c a d).state buf slot k)
      (.natObject (resultSlot l c a d)) (DecimalFrames.loop (c4 l c a d).state buf slot k) := by
  have hs := contexts a d h room
  have h1 := hs.1
  have h2 := hs.2.1
  have h3 := hs.2.2.1
  have r0 : c.top<capacity := by omega
  have r1 : (c1 l c).top<capacity := by change c.top+1<capacity;omega
  have r2 : (c2 l c a).top<capacity := by change c.top+1+1<capacity;omega
  have r3 : (c3 l c a d).top<capacity := by change c.top+1+1+1<capacity;omega
  have move1 := DecimalFrames.result_loop (n:=10) h buf slot k
  have move2 := DecimalFrames.result_loop (n:=a*10) h1 buf slot k
  have move3 := DecimalFrames.result_loop (n:=d) h2 buf slot k
  have move4 := DecimalFrames.result_loop (n:=a*10+d) h3 buf slot k
  have live1 : NatArena.Borrow (c1 l c).state.nats slot a := preserves live
  have ten : NatArena.Borrow (c1 l c).state.nats (tenSlot c) 10 := next_borrow l c 10
  have product : NatArena.Borrow (c2 l c a).state.nats (productSlot l c) (a*10) := next_borrow l (c1 l c) (a*10)
  have product3 : NatArena.Borrow (c3 l c a d).state.nats (productSlot l c) (a*10) := preserves product
  have digit3 : NatArena.Borrow (c3 l c a d).state.nats (digitSlot l c a) d := next_borrow l (c2 l c a) d
  have first := nu_call (n:=10) (input:=unsigned32 10) code nuInstalled keepInstalled
    (DecimalFrames.context h buf slot k) r0 (by decide +kernel) rfl
  have second := nm_call code nmInstalled keepInstalled (DecimalFrames.context h1 buf slot k) r1 live1 ten
  have third := nu_call (n:=d) (input:=unsigned32 d) code nuInstalled keepInstalled
    (DecimalFrames.context h2 buf slot k) r2 (by omega)
    (PositiveCasts.cast_unsigned {DecimalFrames.loop (c2 l c a).state buf slot k with env:=[]} 99 d (by omega))
  have fourth := na_call code naInstalled keepInstalled (DecimalFrames.context h3 buf slot k) r3 product3 digit3
  refine ⟨?_,?_,?_,?_⟩
  · simpa only [tenSlot,DecimalFrames.nats,move1,c1,next] using first
  · simpa only [productSlot,DecimalFrames.nats,move2,c2,next] using second
  · simpa only [digitSlot,DecimalFrames.nats,move3,c3,next] using third
  · simpa only [resultSlot,DecimalFrames.nats,move4,c4,next] using fourth

end ScopedC.DecimalCalls
