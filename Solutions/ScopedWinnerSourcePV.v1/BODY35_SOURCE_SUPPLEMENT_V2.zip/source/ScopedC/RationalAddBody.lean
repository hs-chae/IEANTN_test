/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAddShape

namespace ScopedC.RationalAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def leftExpr : Expr := .call (.var "sm") [.field "." (.var "a") "num",
  .call (.var "smake") [.field "." (.var "b") "den",.nat 0]]
def rightExpr : Expr := .call (.var "sm") [.field "." (.var "b") "num",
  .call (.var "smake") [.field "." (.var "a") "den",.nat 0]]
def addExpr : Expr := .call (.var "sa") [.var "an",.var "bn"]
def denExpr : Expr := .call (.var "nm") [.field "." (.var "a") "den",.field "." (.var "b") "den"]

theorem qa_closed (code : List Function) (installed : Generated.f_qa∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+13<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 6 "qa" [a.source,b.source] c.state (result l c a b) (c14 l c a b).state := by
  let m := RationalCompareCalls.middle l c a b
  let x := x l c a b
  let y := y l c a b
  let p0 := frame c.state a b
  let p1 := frame (RationalCrossCalls.c1 l c).state a b
  let p3 := frame m.state a b
  let s3 := RationalLocalFrames.first m.state a b x
  let s4 := RationalLocalFrames.first (RationalCrossCalls.c1 l m).state a b x
  let s6 := RationalLocalFrames.first (c6 l c a b).state a b x
  let t6 := RationalLocalFrames.both (c6 l c a b).state a b x y
  let t8 := RationalLocalFrames.both (c8 l c a b).state a b x y
  let t9 := RationalLocalFrames.both (c9 l c a b).state a b x y
  let t14 := RationalLocalFrames.both (c14 l c a b).state a b x y
  let p14 := frame (c14 l c a b).state a b
  have preCalls := prefix_calls code lib ctx room a b ha hb
  have tail := tail_calls code lib ctx room a b ha hb pa pb
  let e1 : CallEvents.Event Header.layout code 5 :=
    ⟨"smake",[.natObject b.denSlot,SignedCompareCalls.integer 0],p0,
      (RationalCrossCalls.positive b.denSlot b.denominator).source,p1,raise_once preCalls.1⟩
  let e2 : CallEvents.Event Header.layout code 5 :=
    ⟨"sm",[a.numerator.source,(RationalCrossCalls.positive b.denSlot b.denominator).source],p1,x.source,p3,preCalls.2.1⟩
  let e3 : CallEvents.Event Header.layout code 5 :=
    ⟨"smake",[.natObject a.denSlot,SignedCompareCalls.integer 0],s3,
      (RationalCrossCalls.positive a.denSlot a.denominator).source,s4,raise_once preCalls.2.2.1⟩
  let e4 : CallEvents.Event Header.layout code 5 :=
    ⟨"sm",[b.numerator.source,(RationalCrossCalls.positive a.denSlot a.denominator).source],s4,y.source,s6,preCalls.2.2.2⟩
  let e5 : CallEvents.Event Header.layout code 5 :=
    ⟨"sa",[x.source,y.source],t6,(sum l c a b).source,t8,tail.1⟩
  let e6 : CallEvents.Event Header.layout code 5 :=
    ⟨"nm",[.natObject a.denSlot,.natObject b.denSlot],t8,.natObject (c8 l c a b).state.nats.values.length,t9,
      raise_once (raise_once (raise_once tail.2.1))⟩
  let e7 : CallEvents.Event Header.layout code 5 :=
    ⟨"qm",[(sum l c a b).source,.natObject (c8 l c a b).state.nats.values.length],t9,result l c a b,t14,tail.2.2⟩
  let service := CallEvents.append (CallEvents.one e1) (CallEvents.append (CallEvents.one e2) (CallEvents.append (CallEvents.one e3) (CallEvents.append (CallEvents.one e4) (CallEvents.append (CallEvents.one e5) (CallEvents.append (CallEvents.one e6) (CallEvents.one e7))))))
  have different31 : s3≠p0 := by
    intro eq
    have h := congrArg (fun s : State=>s.nats.values.length) eq
    change m.state.nats.values.length=c.state.nats.values.length at h
    have h3 := RationalCompareCalls.middle_size l c a b
    change m.state.nats.values.length=c.state.nats.values.length+3 at h3
    omega
  have different42 : s4≠p1 := by
    intro eq
    have h := congrArg (fun s : State=>s.nats.values.length) eq
    change (next l m 0).state.nats.values.length=(next l c 0).state.nats.values.length at h
    rw [PoolCursor.size,PoolCursor.size] at h
    have h3 := RationalCompareCalls.middle_size l c a b
    change m.state.nats.values.length=c.state.nats.values.length+3 at h3
    omega
  have a1 : service e1.name e1.args e1.before=some (e1.value,e1.after) :=
    CallEvents.append_left (CallEvents.one_self e1)
  have a2 : service e2.name e2.args e2.before=some (e2.value,e2.after) :=
    CallEvents.append_right (CallEvents.one_other e1 (by change ("sm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self e2))
  have a3 : service e3.name e3.args e3.before=some (e3.value,e3.after) :=
    CallEvents.append_right (CallEvents.one_before_other e1 different31) (CallEvents.append_right (CallEvents.one_other e2 (by change ("smake":String)≠"sm";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self e3)))
  have a4 : service e4.name e4.args e4.before=some (e4.value,e4.after) :=
    CallEvents.append_right (CallEvents.one_other e1 (by change ("sm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_before_other e2 different42) (CallEvents.append_right (CallEvents.one_other e3 (by change ("sm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self e4))))
  have a5 : service e5.name e5.args e5.before=some (e5.value,e5.after) :=
    CallEvents.append_right (CallEvents.one_other e1 (by change ("sa":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e2 (by change ("sa":String)≠"sm";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e3 (by change ("sa":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e4 (by change ("sa":String)≠"sm";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self e5)))))
  have a6 : service e6.name e6.args e6.before=some (e6.value,e6.after) :=
    CallEvents.append_right (CallEvents.one_other e1 (by change ("nm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e2 (by change ("nm":String)≠"sm";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e3 (by change ("nm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e4 (by change ("nm":String)≠"sm";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e5 (by change ("nm":String)≠"sa";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self e6))))))
  have a7 : service e7.name e7.args e7.before=some (e7.value,e7.after) :=
    CallEvents.append_right (CallEvents.one_other e1 (by change ("qm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e2 (by change ("qm":String)≠"sm";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e3 (by change ("qm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e4 (by change ("qm":String)≠"sm";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e5 (by change ("qm":String)≠"sa";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other e6 (by change ("qm":String)≠"nm";decide +kernel) _ _) (CallEvents.one_self e7))))))
  have leftEval : evalExpr Header.layout service 1000 p0 leftExpr=some (x.source,p3) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalPairFrames.eval_a_num service 997 c.state a b)
      (ExpressionTemplates.call_two Header.layout service (RationalPairFrames.eval_b_den service 996 c.state a b) (by rfl) a1) a2
  have rightEval : evalExpr Header.layout service 1000 s3 rightExpr=some (y.source,s6) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalLocalFrames.eval_b_num_first service 997 m.state a b x)
      (ExpressionTemplates.call_two Header.layout service (RationalLocalFrames.eval_a_den_first service 996 m.state a b x) (by rfl) a3) a4
  have castX : castValue Header.layout p3 100 "S" x.source=some x.source :=
    Endpoint.cast 98 "S" (by decide +kernel) (RationalCrossCalls.result_live l c a.numerator b.denominator)
  have castY : castValue Header.layout s6 100 "S" y.source=some y.source :=
    Endpoint.cast 98 "S" (by decide +kernel) (RationalCompareCalls.right_final l c a b)
  have declX : Declare Header.layout service [{type:="S",name:="an",value:=some leftExpr,arrayExtent:=none}] p0 s3 := by
    simp only [Declare,declarations,List.foldlM,leftEval,bind,Option.bind,castX]
    rfl
  have declY : Declare Header.layout service [{type:="S",name:="bn",value:=some rightExpr,arrayExtent:=none}] s3 t6 := by
    simp only [Declare,declarations,List.foldlM,rightEval,bind,Option.bind,castY]
    rfl
  have addEval : evalExpr Header.layout service 5 t6 addExpr=some ((sum l c a b).source,t8) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalLocalFrames.eval_an_both service 2 (c6 l c a b).state a b x y)
      (RationalLocalFrames.eval_bn_both service 2 (c6 l c a b).state a b x y) a5
  have denEval : evalExpr Header.layout service 5 t8 denExpr=some (.natObject (c8 l c a b).state.nats.values.length,t9) :=
    ExpressionTemplates.call_two Header.layout service
      (RationalLocalFrames.eval_a_den_both service 1 (c8 l c a b).state a b x y)
      (RationalLocalFrames.eval_b_den_both service 1 (c8 l c a b).state a b x y) a6
  have expr : Eval Header.layout service (.call (.var "qm") [addExpr,denExpr]) t6 t14 (result l c a b) :=
    ⟨6,ExpressionTemplates.call_two Header.layout service addEval denEval a7⟩
  have fshape := frame_shape l c a b
  have body : Run Header.layout service Generated.f_qa.body p0 (.returned p14 (result l c a b)) := by
    apply Loops.StmtRun.sequence (Loops.SeqRun.next (Loops.StmtRun.declare declX)
      (Loops.SeqRun.next (Loops.StmtRun.declare declY) (Loops.SeqRun.returned (Loops.StmtRun.returnValue expr))))
    exact ⟨rfl,(AllocatedFrames.pop_two "S" "an" x.source "S" "bn" y.source fshape.1 fshape.2).symm⟩
  have closed : ∀ name args before value after,service name args before=some (value,after) →
      SourceCall Header.layout code 5 name args before value after := by
    intro name args before value after h
    exact CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e1 h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e2 h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e3 h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e4 h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e5 h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed e6 h) (fun _ _ _ _ _ h=>CallEvents.one_closed e7 h) h) h) h) h) h) h
  apply installed_body (f:=Generated.f_qa) (rank:=5) (service:=service) installed closed
    (RationalPairFrames.bind a b ha hb) body
  exact ⟨cast_result l c a b,(TwoFrames.pop_frame "Q" "a" a.source "Q" "b" b.source
    (shape l c a b).1 (shape l c a b).2).symm⟩

end ScopedC.RationalAddCalls
