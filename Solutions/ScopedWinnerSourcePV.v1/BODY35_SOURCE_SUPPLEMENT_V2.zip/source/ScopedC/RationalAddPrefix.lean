/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAddTail
import ScopedC.RationalCrossCursor

namespace ScopedC.RationalAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem make_first (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) (an : Endpoint) {slot d : Nat} (hd : NatArena.Borrow c.state.nats slot d) :
    SourceCall Header.layout code 4 "smake" [.natObject slot,SignedCompareCalls.integer 0]
      (RationalLocalFrames.first c.state a b an) (RationalCrossCalls.positive slot d).source
      (RationalLocalFrames.first (RationalCrossCalls.c1 l c).state a b an) := by
  have p := RationalCrossCalls.make_on_cursor code lib.smake lib.nz lib.nu lib.ne lib.keep
    (c:=RationalAddFrames.first c a b an) (RationalAddFrames.first_valid ctx a b an) room hd
  change SourceCall Header.layout code 4 "smake" [.natObject slot,SignedCompareCalls.integer 0]
    (RationalLocalFrames.first c.state a b an) (RationalCrossCalls.positive slot d).source
    (next l (RationalAddFrames.first c a b an) 0).state at p
  rw [RationalAddFrames.next_first ctx a b an 0] at p
  exact p

theorem multiply_first (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+2<PoolCalls.capacity)
    (a b : Input) (an n : Endpoint) {slot d : Nat}
    (hn : n.Live c.state) (hd : NatArena.Borrow c.state.nats slot d) :
    SourceCall Header.layout code 5 "sm" [n.source,(RationalCrossCalls.positive slot d).source]
      (RationalLocalFrames.first (RationalCrossCalls.c1 l c).state a b an) (RationalCrossCalls.result l c n d).source
      (RationalLocalFrames.first (RationalCrossCalls.c3 l c n d).state a b an) := by
  have p := RationalCrossCalls.multiply_on_cursor code lib.sm lib.nm lib.smake lib.nz lib.nu lib.ne lib.keep
    (c:=RationalAddFrames.first c a b an) (RationalAddFrames.first_valid ctx a b an) room n hn hd
  rw [RationalAddFrames.cross_first ctx room a b an n d,
    RationalAddFrames.cross_result_first ctx a b an n d] at p
  change SourceCall Header.layout code 5 "sm" [n.source,(RationalCrossCalls.positive slot d).source]
    (next l (RationalAddFrames.first c a b an) 0).state (RationalCrossCalls.result l c n d).source
    (RationalLocalFrames.first (RationalCrossCalls.c3 l c n d).state a b an) at p
  rw [RationalAddFrames.next_first ctx a b an 0] at p
  exact p

theorem prefix_calls (code : List Function) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+13<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) :
    SourceCall Header.layout code 4 "smake" [.natObject b.denSlot,SignedCompareCalls.integer 0]
      (frame c.state a b) (RationalCrossCalls.positive b.denSlot b.denominator).source
      (frame (RationalCrossCalls.c1 l c).state a b) ∧
    SourceCall Header.layout code 5 "sm" [a.numerator.source,(RationalCrossCalls.positive b.denSlot b.denominator).source]
      (frame (RationalCrossCalls.c1 l c).state a b) (x l c a b).source
      (frame (RationalCompareCalls.middle l c a b).state a b) ∧
    SourceCall Header.layout code 4 "smake" [.natObject a.denSlot,SignedCompareCalls.integer 0]
      (RationalLocalFrames.first (RationalCompareCalls.middle l c a b).state a b (x l c a b))
      (RationalCrossCalls.positive a.denSlot a.denominator).source
      (RationalLocalFrames.first (RationalCrossCalls.c1 l (RationalCompareCalls.middle l c a b)).state a b (x l c a b)) ∧
    SourceCall Header.layout code 5 "sm" [b.numerator.source,(RationalCrossCalls.positive a.denSlot a.denominator).source]
      (RationalLocalFrames.first (RationalCrossCalls.c1 l (RationalCompareCalls.middle l c a b)).state a b (x l c a b))
      (y l c a b).source (RationalLocalFrames.first (c6 l c a b).state a b (x l c a b)) := by
  have mc := RationalCompareCalls.middle_context ctx (by omega) a b
  have am := RationalCompareCalls.input_middle (l:=l) (a:=a) (b:=b) ha
  have bm := RationalCompareCalls.input_middle (l:=l) (a:=a) (b:=b) hb
  exact ⟨RationalCrossCalls.make_on_frame code lib.smake lib.nz lib.nu lib.ne lib.keep ctx (by omega) a b hb.2,
    RationalCrossCalls.multiply_on_frame code lib.sm lib.nm lib.smake lib.nz lib.nu lib.ne lib.keep ctx (by omega) a b a.numerator ha.1 hb.2,
    make_first code lib mc (by rw[RationalCompareCalls.top_middle];omega) a b (x l c a b) am.2,
    multiply_first code lib mc (by rw[RationalCompareCalls.top_middle];omega) a b (x l c a b) b.numerator bm.1 am.2⟩

end ScopedC.RationalAddCalls
