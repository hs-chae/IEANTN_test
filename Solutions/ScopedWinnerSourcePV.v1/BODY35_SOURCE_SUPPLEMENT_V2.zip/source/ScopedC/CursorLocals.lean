/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CursorFrames
import ScopedC.AllocatedFrames

namespace ScopedC.CursorLocals
open ScopedC.Syntax ScopedC.Machine ScopedC.PoolCursor
open ScopedC.CursorFrames
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def allocated (c : Cursor) (type name : String) (value : Value) : Cursor :=
  ⟨allocate c.state type name (some value),c.cells,c.top,c.high⟩

theorem allocated_valid {l : PoolCalls.PoolLayout} {c : Cursor} (h : Valid l c)
    (type name : String) (value : Value) : Valid l (allocated c type name value) :=
  AllocatedFrames.context_allocate h type name value

theorem next_allocated {l : PoolCalls.PoolLayout} {c : Cursor} (h : Valid l c)
    (type name : String) (value : Value) (n : Nat) :
    next l (allocated c type name value) n=allocated (next l c n) type name value := by
  unfold next allocated
  dsimp only
  rw [AllocatedFrames.binary_allocate h type name value]
  rfl

theorem advance_allocated {l : PoolCalls.PoolLayout} {c : Cursor} (h : Valid l c) (ns : List Nat)
    (room : c.top+ns.length≤PoolCalls.capacity) (type name : String) (value : Value) :
    advance l (allocated c type name value) ns=allocated (advance l c ns) type name value := by
  induction ns generalizing c with
  | nil => rfl
  | cons n ns ih =>
    rw [advance,advance,next_allocated h type name value n]
    apply ih (next_valid n h (by simp only [List.length_cons] at room;omega))
    change c.top+1+ns.length≤PoolCalls.capacity
    simp only [List.length_cons] at room
    omega

theorem getVar_other (s : State) (type name : String) (value : Option Value)
    (old : String) (different : old ≠ name) :
    getVar (allocate s type name value) old=getVar s old := by
  have hn : (old==name)=false := beq_eq_false_iff_ne.mpr different
  simp [getVar,allocate,List.lookup,hn]

theorem read_before (cfg : Layout) (s : State) (type name : String) (value : Option Value)
    (address : Address) (before : address.object<s.heap.length) :
    read cfg (allocate s type name value) address=read cfg s address := by
  simp only [Machine.read,allocate,List.getElem?_append_left before]

theorem eval_old_var (cfg : Layout) (call : Call) (fuel : Nat) (s : State)
    (type name : String) (value : Option Value) (old : String) (address : Address) (object : Object) (out : Value)
    (different : old ≠ name) (notTrue : old ≠ "true") (notFalse : old ≠ "false")
    (notNull : old ≠ "nullptr") (notNULL : old ≠ "NULL")
    (located : getVar s old=some address) (bounded : address.object<s.heap.length)
    (heap : s.heap[address.object]?=some object) (scalar : object.isArray=false)
    (contents : read cfg s address=some out) :
    evalExpr cfg call (fuel+1) (allocate s type name value) (.var old)=
      some (out,allocate s type name value) := by
  have ht : (old=="true")=false := beq_eq_false_iff_ne.mpr notTrue
  have hf : (old=="false")=false := beq_eq_false_iff_ne.mpr notFalse
  have hn : (old=="nullptr")=false := beq_eq_false_iff_ne.mpr notNull
  have hz : (old=="NULL")=false := beq_eq_false_iff_ne.mpr notNULL
  have oldHeap : (allocate s type name value).heap[address.object]?=some object := by
    simp only [allocate,List.getElem?_append_left bounded]
    exact heap
  have oldRead := read_before cfg s type name value address bounded
  rw [contents] at oldRead
  rw [evalExpr]
  simp only [ht,hf,hn,hz,Bool.false_or,Bool.false_eq_true,↓reduceIte,
    getVar_other s type name value old different,located,bind,Option.bind,oldHeap,
    scalar,Bool.false_and,oldRead]
  rfl

end ScopedC.CursorLocals
