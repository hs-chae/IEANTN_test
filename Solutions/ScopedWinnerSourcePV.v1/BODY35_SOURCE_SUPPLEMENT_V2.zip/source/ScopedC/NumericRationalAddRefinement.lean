/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAddBody

namespace ScopedC.NumericRationalAddRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor
open ScopedC.DyadicRepresentation ScopedC.RationalAddCalls
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Actual qa source execution, exact field-level normalized output and its
mathematical sum. The signed cross-products and final gcd are executed by their
proved actual source bodies rather than accepted as an output certificate. -/
theorem qa_math (code : List Function) (installed : Generated.f_qa∈code) (lib : Library code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+13<PoolCalls.capacity)
    (a b : Input) (ha : a.Live c.state) (hb : b.Live c.state) (pa : 0<a.denominator) (pb : 0<b.denominator) :
    SourceCall Header.layout code 6 "qa" [a.source,b.source] c.state (result l c a b) (c14 l c a b).state ∧
    NumericRepresentation.rational (c14 l c a b).state (result l c a b)=
      some (Rational.normalize (sum l c a b).mathematical (denominator a b)) ∧
    (Rational.normalize (sum l c a b).mathematical (denominator a b)).Normalized ∧
    (Rational.normalize (sum l c a b).mathematical (denominator a b)).value=a.mathematical.value+b.mathematical.value := by
  exact ⟨qa_closed code installed lib ctx room a b ha hb pa pb,result_decoded l c a b pa pb,
    Rational.normalize_normalized _ _ (Nat.ne_of_gt (Nat.mul_pos pa pb)),mathematical_value l c a b pa pb⟩

end ScopedC.NumericRationalAddRefinement
