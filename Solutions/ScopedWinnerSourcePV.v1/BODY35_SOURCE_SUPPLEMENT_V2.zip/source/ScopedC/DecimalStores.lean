/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalFrames

namespace ScopedC.DecimalFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem lvalue_a (service : Call) (fuel : Nat) (s : State) (buf : Address) (slot k : Nat) :
    evalLValue Header.layout service (fuel+1) (loop s buf slot k) (.var "a") =
      some (⟨s.heap.length+1,0,[]⟩,true,loop s buf slot k) := by
  simp [evalLValue,getVar,loop,parameter,allocate,List.lookup,List.getElem?_append]

theorem lvalue_k (service : Call) (fuel : Nat) (s : State) (buf : Address) (slot k : Nat) :
    evalLValue Header.layout service (fuel+1) (loop s buf slot k) (.var "k") =
      some (⟨s.heap.length+2,0,[]⟩,true,loop s buf slot k) := by
  simp [evalLValue,getVar,loop,parameter,allocate,List.lookup,List.getElem?_append]

theorem write_a {s : State} {buf : Address} {slot k fresh n : Nat}
    (live : NatArena.Borrow s.nats fresh n) :
    write Header.layout (loop s buf slot k) ⟨s.heap.length+1,0,[]⟩ true (.natObject fresh) =
      some (.natObject fresh,loop s buf fresh k) := by
  have cv : castValue Header.layout (loop s buf slot k) 100 "N" (.natObject fresh) =
      some (.natObject fresh) := PrimitiveCalls.cast_N live
  have ty : addressType Header.layout (loop s buf slot k) ⟨s.heap.length+1,0,[]⟩ = some "N" := by
    simp [addressType,typeAt,loop,parameter,allocate,List.getElem?_append]
  simp only [write,Bool.not_true,Bool.false_eq_true,↓reduceIte,ty,Bind.bind,Option.bind,cv]
  simp [loop,parameter,allocate,List.getElem?_append,List.set_append]

theorem write_k (s : State) (buf : Address) (slot k fresh : Nat) (bound : fresh < 2^32) :
    write Header.layout (loop s buf slot k) ⟨s.heap.length+2,0,[]⟩ true (unsigned32 fresh) =
      some (unsigned32 fresh,loop s buf slot fresh) := by
  have cv : castValue Header.layout (loop s buf slot k) 100 "unsigned int" (unsigned32 fresh) =
      some (unsigned32 fresh) := PositiveCasts.cast_unsigned (loop s buf slot k) 99 fresh bound
  have ty : addressType Header.layout (loop s buf slot k) ⟨s.heap.length+2,0,[]⟩ = some "unsigned int" := by
    simp [addressType,typeAt,loop,parameter,allocate,List.getElem?_append]
  simp only [write,Bool.not_true,Bool.false_eq_true,↓reduceIte,ty,Bind.bind,Option.bind,cv]
  simp [loop,parameter,allocate,List.getElem?_append,List.set_append]

end ScopedC.DecimalFrames
