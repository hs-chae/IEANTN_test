/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.CursorEffects
namespace ScopedC.CursorBorrow
open ScopedC.Machine ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0

theorem preserves {l : PoolCalls.PoolLayout} {c : Cursor} {slot n : Nat}
    (ns : List Nat) (h : NatArena.Borrow c.state.nats slot n) :
    NatArena.Borrow (CursorFrames.advance l c ns).state.nats slot n := by
  induction ns generalizing c with
  | nil => exact h
  | cons v vs ih => exact ih (c:=next l c v) (PoolCursor.preserves (c:=c) h)
end ScopedC.CursorBorrow
