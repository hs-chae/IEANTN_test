/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalLiteralCall

namespace ScopedC.DecimalExpressions
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def character : Expr := .index (.var "s") (.var "k")
def condition : Expr := .binary "!=" character (.nat 0)
def invalid : Expr := .binary "||" (.binary "<" character (.character 48))
  (.binary ">" character (.character 57))
def convertedDigit : Expr := .cast "unsigned int" (.binary "-" character (.character 48))
def accumulator : Expr := .call (.var "na")
  [.call (.var "nm") [.var "a",.call (.var "nu") [.nat 10]],
   .call (.var "nu") [convertedDigit]]
def iteration : Stmt := .sequence [
  .branch invalid (.eval (.call (.var "fail") [])) .skip,
  .eval (.binary "=" (.var "a") accumulator),
  .eval (.binary "=" (.var "k") (.binary "+" (.var "k") (.nat 1)))]
def body : Stmt := .sequence [
  .declare [{type:="N",name:="a",value:=some (.call (.var "nu") [.nat 0])}],
  .declare [{type:="unsigned int",name:="k",value:=some (.nat 0)}],
  .whileLoop condition iteration,.returnStmt (.var "a")]

/-- These expressions are the actual bound C function's statement tree. -/
theorem body_exact : body = Generated.f_decimal.body := rfl

theorem read_character (service : Call) (fuel : Nat) {s : State} {buf : Address} {slot k : Nat} {digits : List Nat}
    (h : DecimalBuffer.At s buf digits) (hk : k<digits.length) :
    evalExpr Header.layout service (fuel+3) (DecimalFrames.loop s buf slot k) character =
      some (DecimalDigits.digit digits[k],DecimalFrames.loop s buf slot k) :=
  DecimalBuffer.index service fuel (DecimalFrames.buffer h slot k)
    (DecimalFrames.eval_s service fuel s buf slot k) (DecimalFrames.eval_k service fuel s buf slot k) hk

theorem source_condition (service : Call) {s : State} {buf : Address} {slot k : Nat} {digits : List Nat}
    (h : DecimalBuffer.At s buf digits) (hk : k<digits.length) (hd : digits[k]<10) :
    Eval Header.layout service condition (DecimalFrames.loop s buf slot k) (DecimalFrames.loop s buf slot k)
      (boolean Header.layout true) := by
  refine ⟨4,?_⟩
  exact ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (read_character service 0 h hk)
    (show evalExpr Header.layout service 3 (DecimalFrames.loop s buf slot k) (.nat 0) =
      some (DecimalDigits.integer 0,DecimalFrames.loop s buf slot k) from rfl)
    (DecimalDigits.digit_nonzero _ _ hd)

theorem source_terminator (service : Call) {s : State} {buf : Address} {slot : Nat} {digits : List Nat}
    (h : DecimalBuffer.At s buf digits) :
    Eval Header.layout service condition (DecimalFrames.loop s buf slot digits.length)
      (DecimalFrames.loop s buf slot digits.length) (boolean Header.layout false) := by
  refine ⟨4,?_⟩
  exact ExpressionTemplates.binary Header.layout service
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    (DecimalBuffer.index_terminator service 0 (DecimalFrames.buffer h slot digits.length)
      (DecimalFrames.eval_s service 0 s buf slot digits.length)
      (DecimalFrames.eval_k service 0 s buf slot digits.length))
    (show evalExpr Header.layout service 3 (DecimalFrames.loop s buf slot digits.length) (.nat 0) =
      some (DecimalDigits.integer 0,DecimalFrames.loop s buf slot digits.length) from rfl)
    (DecimalDigits.terminator_zero _)

theorem source_guard (service : Call) {s : State} {buf : Address} {slot k : Nat} {digits : List Nat}
    (h : DecimalBuffer.At s buf digits) (hk : k<digits.length) (hd : digits[k]<10) :
    Eval Header.layout service invalid (DecimalFrames.loop s buf slot k) (DecimalFrames.loop s buf slot k)
      (boolean Header.layout false) := by
  have low : evalExpr Header.layout service 4 (DecimalFrames.loop s buf slot k)
      (.binary "<" character (.character 48)) =
      some (boolean Header.layout false,DecimalFrames.loop s buf slot k) :=
    ExpressionTemplates.binary Header.layout service
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (read_character service 0 h hk) (by rfl) (DecimalDigits.lower_guard _ _ hd)
  have high : evalExpr Header.layout service 4 (DecimalFrames.loop s buf slot k)
      (.binary ">" character (.character 57)) =
      some (boolean Header.layout false,DecimalFrames.loop s buf slot k) :=
    ExpressionTemplates.binary Header.layout service
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (read_character service 0 h hk) (by rfl) (DecimalDigits.upper_guard _ _ hd)
  refine ⟨5,?_⟩
  rw [invalid,evalExpr,low]
  simp [Bind.bind,Option.bind,Machine.truth,Machine.boolean,Scalar.truth,Scalar.boolean,high]

/-- Evaluation of the actual nested accumulator expression. The four service
    answers must later be instantiated by closed lower source-call executions. -/
theorem source_accumulator (service : Call) {l : PoolLayout} {c : Cursor}
    {buf : Address} {slot k a : Nat} {digits : List Nat}
    (hbuf : DecimalBuffer.At (DecimalCalls.c2 l c a).state buf digits)
    (hk : k<digits.length) (hd : digits[k]<10)
    (nuTen : service "nu" [DecimalDigits.integer 10] (DecimalFrames.loop c.state buf slot k) =
      some (.natObject (DecimalCalls.tenSlot c),DecimalFrames.loop (DecimalCalls.c1 l c).state buf slot k))
    (mul : service "nm" [.natObject slot,.natObject (DecimalCalls.tenSlot c)]
      (DecimalFrames.loop (DecimalCalls.c1 l c).state buf slot k) =
      some (.natObject (DecimalCalls.productSlot l c),DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k))
    (nuDigit : service "nu" [unsigned32 digits[k]] (DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k) =
      some (.natObject (DecimalCalls.digitSlot l c a),DecimalFrames.loop (DecimalCalls.c3 l c a digits[k]).state buf slot k))
    (add : service "na" [.natObject (DecimalCalls.productSlot l c),.natObject (DecimalCalls.digitSlot l c a)]
      (DecimalFrames.loop (DecimalCalls.c3 l c a digits[k]).state buf slot k) =
      some (.natObject (DecimalCalls.resultSlot l c a digits[k]),DecimalFrames.loop (DecimalCalls.c4 l c a digits[k]).state buf slot k)) :
    evalExpr Header.layout service 8 (DecimalFrames.loop c.state buf slot k) accumulator =
      some (.natObject (DecimalCalls.resultSlot l c a digits[k]),DecimalFrames.loop (DecimalCalls.c4 l c a digits[k]).state buf slot k) := by
  have ten : evalExpr Header.layout service 6 (DecimalFrames.loop c.state buf slot k)
      (.call (.var "nu") [.nat 10]) =
      some (.natObject (DecimalCalls.tenSlot c),DecimalFrames.loop (DecimalCalls.c1 l c).state buf slot k) :=
    ExpressionTemplates.call_one Header.layout service (by rfl) nuTen
  have product : evalExpr Header.layout service 7 (DecimalFrames.loop c.state buf slot k)
      (.call (.var "nm") [.var "a",.call (.var "nu") [.nat 10]]) =
      some (.natObject (DecimalCalls.productSlot l c),DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k) :=
    ExpressionTemplates.call_two Header.layout service (DecimalFrames.eval_a service 5 c.state buf slot k) ten mul
  have sub : evalExpr Header.layout service 5 (DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k)
      (.binary "-" character (.character 48)) =
      some (DecimalDigits.integer digits[k],DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k) :=
    ExpressionTemplates.binary Header.layout service
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
      (read_character service 1 hbuf hk) (by rfl) (DecimalDigits.subtract_zero _ _ hd)
  have converted : evalExpr Header.layout service 6 (DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k)
      convertedDigit = some (unsigned32 digits[k],DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k) :=
    ExpressionTemplates.cast Header.layout service sub (DecimalDigits.cast_digit _ _ hd)
  have digit : evalExpr Header.layout service 7 (DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k)
      (.call (.var "nu") [convertedDigit]) =
      some (.natObject (DecimalCalls.digitSlot l c a),DecimalFrames.loop (DecimalCalls.c3 l c a digits[k]).state buf slot k) :=
    ExpressionTemplates.call_one Header.layout service converted nuDigit
  exact ExpressionTemplates.call_two Header.layout service product digit add

end ScopedC.DecimalExpressions
