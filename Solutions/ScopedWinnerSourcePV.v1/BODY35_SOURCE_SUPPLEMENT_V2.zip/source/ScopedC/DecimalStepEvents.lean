/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalIteration
import ScopedC.CallEventLists

namespace ScopedC.DecimalExpressions
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def Answers (service : Call) {code : List Function} (events : List (CallEvents.Event Header.layout code 2)) : Prop :=
  ∀ e∈events,service e.name e.args e.before = some (e.value,e.after)

theorem next_buffer {l : PoolLayout} {c : Cursor} {buf : Address} {digits : List Nat}
    (hbuf : DecimalBuffer.At c.state buf digits) (n : Nat)
    (hp : buf.object≠l.pool) (ht : buf.object≠l.top) (hh : buf.object≠l.high) :
    DecimalBuffer.At (next l c n).state buf digits :=
  DecimalBuffer.binary_result l c.cells c.top c.high n hbuf hp ht hh

/-- Four call events are proof witnesses backed by already closed actual
    lower AST bodies. Their values are not a trusted runtime/output service. -/
theorem step_events (code : List Function)
    (nuInstalled : Generated.f_nu∈code) (nmInstalled : Generated.f_nm∈code)
    (naInstalled : Generated.f_na∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolLayout} {c : Cursor} {buf : Address} {slot k a : Nat} {digits : List Nat}
    (live : NatArena.Borrow c.state.nats slot a) (valid : Valid l c) (room : c.top+3<capacity)
    (hbuf : DecimalBuffer.At c.state buf digits) (hk : k<digits.length)
    (hd : digits[k]<10) (length : digits.length<2^32)
    (hp : buf.object≠l.pool) (ht : buf.object≠l.top) (hh : buf.object≠l.high) :
    ∃ events : List (CallEvents.Event Header.layout code 2),
      CallEvents.counts events = [c.state.nats.values.length,c.state.nats.values.length+1,
        c.state.nats.values.length+2,c.state.nats.values.length+3] ∧
      ∀ service,Answers service events →
        Run Header.layout service iteration (DecimalFrames.loop c.state buf slot k)
          (.continuing (DecimalFrames.loop (DecimalCalls.c4 l c a digits[k]).state buf
            (DecimalCalls.resultSlot l c a digits[k]) (k+1))) := by
  let d:=digits[k]
  have lower := DecimalCalls.lower_calls code nuInstalled nmInstalled naInstalled keepInstalled
    buf k live hd valid room
  let e0 : CallEvents.Event Header.layout code 2 := ⟨"nu",[DecimalDigits.integer 10],
    DecimalFrames.loop c.state buf slot k,.natObject (DecimalCalls.tenSlot c),
    DecimalFrames.loop (DecimalCalls.c1 l c).state buf slot k,
    DecimalCalls.source_literal_ten code nuInstalled keepInstalled buf slot k valid (by omega)⟩
  let e1 : CallEvents.Event Header.layout code 2 := ⟨"nm",[.natObject slot,.natObject (DecimalCalls.tenSlot c)],
    DecimalFrames.loop (DecimalCalls.c1 l c).state buf slot k,.natObject (DecimalCalls.productSlot l c),
    DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k,lower.2.1⟩
  let e2 : CallEvents.Event Header.layout code 2 := ⟨"nu",[unsigned32 d],
    DecimalFrames.loop (DecimalCalls.c2 l c a).state buf slot k,.natObject (DecimalCalls.digitSlot l c a),
    DecimalFrames.loop (DecimalCalls.c3 l c a d).state buf slot k,lower.2.2.1⟩
  let e3 : CallEvents.Event Header.layout code 2 := ⟨"na",[.natObject (DecimalCalls.productSlot l c),.natObject (DecimalCalls.digitSlot l c a)],
    DecimalFrames.loop (DecimalCalls.c3 l c a d).state buf slot k,.natObject (DecimalCalls.resultSlot l c a d),
    DecimalFrames.loop (DecimalCalls.c4 l c a d).state buf slot k,lower.2.2.2⟩
  refine ⟨[e0,e1,e2,e3],?_,?_⟩
  · have s1 := size l c 10
    have s2 := size l (DecimalCalls.c1 l c) (a*10)
    have s3 := size l (DecimalCalls.c2 l c a) d
    change [c.state.nats.values.length,(DecimalCalls.c1 l c).state.nats.values.length,
      (DecimalCalls.c2 l c a).state.nats.values.length,(DecimalCalls.c3 l c a d).state.nats.values.length] = _
    change (DecimalCalls.c1 l c).state.nats.values.length=c.state.nats.values.length+1 at s1
    change (DecimalCalls.c2 l c a).state.nats.values.length=(DecimalCalls.c1 l c).state.nats.values.length+1 at s2
    change (DecimalCalls.c3 l c a d).state.nats.values.length=(DecimalCalls.c2 l c a).state.nats.values.length+1 at s3
    rw [s3,s2,s1]
  · intro service answers
    have a0 := answers e0 (by simp)
    have a1 := answers e1 (by simp)
    have a2 := answers e2 (by simp)
    have a3 := answers e3 (by simp)
    have b1 : DecimalBuffer.At (DecimalCalls.c1 l c).state buf digits := next_buffer hbuf 10 hp ht hh
    have b2 : DecimalBuffer.At (DecimalCalls.c2 l c a).state buf digits := next_buffer b1 (a*10) hp ht hh
    exact source_iteration service hbuf hk hd length
      (source_accumulator service b2 hk hd a0 a1 a2 a3)

end ScopedC.DecimalExpressions
