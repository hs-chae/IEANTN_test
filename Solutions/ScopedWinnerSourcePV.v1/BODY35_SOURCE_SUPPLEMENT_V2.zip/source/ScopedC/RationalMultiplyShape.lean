/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyInvariants
import ScopedC.RationalMultiplyFramesExtra

namespace ScopedC.RationalMultiplyCalls
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem size1 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c1 l c a b).state.nats.values.length=c.state.nats.values.length+1 := PoolCursor.size _ _ _
theorem size2 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c2 l c a b).state.nats.values.length=c.state.nats.values.length+2 := by rw[c2,PoolCursor.size,size1]
theorem size3 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c3 l c a b).state.nats.values.length=c.state.nats.values.length+3 := by rw[c3,PoolCursor.size,size2]
theorem size4 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c4 l c a b).state.nats.values.length=c.state.nats.values.length+4 := by rw[c4,PoolCursor.size,size3]
theorem size5 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c5 l c a b).state.nats.values.length=c.state.nats.values.length+5 := by rw[c5,PoolCursor.size,size4]
theorem size6 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c6 l c a b).state.nats.values.length=c.state.nats.values.length+6 := by rw[c6,PoolCursor.size,size5]
theorem size7 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c7 l c a b).state.nats.values.length=c.state.nats.values.length+7 := by rw[c7,PoolCursor.size,size6]
theorem size8 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c8 l c a b).state.nats.values.length=c.state.nats.values.length+8 := by rw[c8,PoolCursor.size,size7]
theorem size9 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c9 l c a b).state.nats.values.length=c.state.nats.values.length+9 := by rw[c9,PoolCursor.size,size8]
theorem size10 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : (c10 l c a b).state.nats.values.length=c.state.nats.values.length+10 := by rw[c10,PoolCursor.size,size9]

theorem shape6 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (c6 l c a b).state.heap.length=c.state.heap.length ∧ (c6 l c a b).state.env=c.state.env := by
  rw[c6]
  exact CursorEffects.shape l c [g a b,h a b,a.numerator.magnitude/g a b,0,b.numerator.magnitude/h a b,0]

theorem shape (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (c11 l c a b).state.heap.length=c.state.heap.length ∧ (c11 l c a b).state.env=c.state.env := by
  have h6 := shape6 l c a b
  have h11 := CursorEffects.shape l (c6 l c a b)
    [productMagnitude l c a b,0,a.denominator/h a b,b.denominator/g a b,den a b]
  exact ⟨h11.1.trans h6.1,h11.2.trans h6.2⟩

theorem frame_shape (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (frame (c11 l c a b).state a b).heap.length=(frame c.state a b).heap.length ∧
    (frame (c11 l c a b).state a b).env=(frame c.state a b).env := by
  have h := shape l c a b
  constructor
  · simpa only[frame,TwoFrames.frame,allocate,List.length_append,List.length_singleton]using congrArg (fun n=>n+1+1) h.1
  · simp only[frame,TwoFrames.frame,allocate,List.length_append,List.length_singleton,h.1]

theorem result_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    Input.Live (c11 l c a b).state ⟨top l c a b,(c10 l c a b).state.nats.values.length,den a b⟩ :=
  ⟨top_live l c a b,PoolCursor.next_borrow l (c10 l c a b) (den a b)⟩

end ScopedC.RationalMultiplyCalls
