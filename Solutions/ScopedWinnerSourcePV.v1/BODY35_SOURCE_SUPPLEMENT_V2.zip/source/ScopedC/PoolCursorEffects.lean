/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.PoolCursor

namespace ScopedC.PoolCursor
open ScopedC.Machine ScopedC.PoolCalls ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 0

theorem other (l : PoolLayout) (c : Cursor) (n i : Nat)
    (hp : i≠l.pool) (ht : i≠l.top) (hh : i≠l.high) :
    (next l c n).state.heap[i]?=c.state.heap[i]? := by
  unfold next binaryResult keepResult
  split <;> simp [keepStepped,keepStored,storeHigh,storeTop,storePool,storeObject,
    List.getElem?_set,hp,ht,hh,Ne.symm hp,Ne.symm ht,Ne.symm hh]

end ScopedC.PoolCursor
