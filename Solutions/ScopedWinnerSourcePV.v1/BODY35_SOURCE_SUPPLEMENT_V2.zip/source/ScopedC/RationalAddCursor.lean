/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SignedAddCursor

namespace ScopedC.RationalAddCursor
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem nm_both (code : List Function)
    (nmInstalled : Generated.f_nm∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top<PoolCalls.capacity)
    (a b : Input) (x y : Endpoint) (ha : a.Live c.state) (hb : b.Live c.state) :
    SourceCall Header.layout code 2 "nm" [.natObject a.denSlot,.natObject b.denSlot]
      (RationalLocalFrames.both c.state a b x y) (.natObject c.state.nats.values.length)
      (RationalLocalFrames.both (next l c (a.denominator*b.denominator)).state a b x y) := by
  have p := nm_call code nmInstalled keepInstalled
    (s:=(RationalAddFrames.both c a b x y).state) (l:=l) (cells:=c.cells) (top:=c.top) (high:=c.high)
    (RationalAddFrames.both_valid ctx a b x y) room ha.2 hb.2
  have framed := congrArg Cursor.state (RationalAddFrames.next_both ctx a b x y (a.denominator*b.denominator))
  change SourceCall Header.layout code 2 "nm" [.natObject a.denSlot,.natObject b.denSlot]
    (RationalLocalFrames.both c.state a b x y) (.natObject c.state.nats.values.length)
    (next l (RationalAddFrames.both c a b x y) (a.denominator*b.denominator)).state at p
  rw [framed] at p
  exact p

theorem qm_both (code : List Function)
    (qmInstalled : Generated.f_qm∈code) (nzInstalled : Generated.f_nz∈code)
    (ngInstalled : Generated.f_ng∈code) (ndInstalled : Generated.f_nd∈code)
    (smakeInstalled : Generated.f_smake∈code) (nuInstalled : Generated.f_nu∈code)
    (neInstalled : Generated.f_ne∈code) (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c) (room : c.top+4<PoolCalls.capacity)
    (a b : Input) (x y n : Endpoint) {slot d : Nat}
    (hn : n.Live c.state) (hd : NatArena.Borrow c.state.nats slot d) (positive : 0<d) :
    SourceCall Header.layout code 5 "qm" [n.source,.natObject slot]
      (RationalLocalFrames.both c.state a b x y) (RationalMakeCalls.result l c n d)
      (RationalLocalFrames.both (RationalMakeCalls.c5 l c n d).state a b x y) := by
  have p := RationalMakeCalls.qm_closed code qmInstalled nzInstalled ngInstalled ndInstalled smakeInstalled
    nuInstalled neInstalled keepInstalled (c:=RationalAddFrames.both c a b x y)
    n hn hd positive (RationalAddFrames.both_valid ctx a b x y) room
  rw [RationalAddFrames.make_both ctx room a b x y,RationalAddFrames.make_result_both ctx room a b x y] at p
  exact p

end ScopedC.RationalAddCursor
