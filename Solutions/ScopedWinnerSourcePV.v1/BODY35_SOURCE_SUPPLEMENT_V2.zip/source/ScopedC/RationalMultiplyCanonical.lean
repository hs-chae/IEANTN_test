/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCanonical
import ScopedC.RationalMultiplyMath

namespace ScopedC.RationalMultiplyCalls
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0

theorem normalized (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (ha : a.mathematical.Normalized) (hb : b.mathematical.Normalized) :
    Rational.Normalized ⟨(top l c a b).mathematical,den a b⟩ := by
  refine ⟨den_pos a b ha.1 hb.1,?_,?_⟩
  · change ((a.numerator.magnitude/g a b)*(b.numerator.magnitude/h a b)).Coprime
      ((a.denominator/h a b)*(b.denominator/g a b))
    apply Nat.coprime_mul_iff_left.mpr
    refine ⟨Nat.coprime_mul_iff_right.mpr ⟨?_,?_⟩,Nat.coprime_mul_iff_right.mpr ⟨?_,?_⟩⟩
    · exact ha.2.1.coprime_div_left (Nat.gcd_dvd_left _ _)
        |>.coprime_div_right (Nat.gcd_dvd_right _ _)
    · exact Nat.coprime_div_gcd_div_gcd (g_pos a b hb.1)
    · exact Nat.coprime_div_gcd_div_gcd (h_pos a b ha.1)
    · exact hb.2.1.coprime_div_left (Nat.gcd_dvd_left _ _)
        |>.coprime_div_right (Nat.gcd_dvd_right _ _)
  · intro hz
    change (if productMagnitude l c a b=0 then false else _)=false
    exact if_pos hz

theorem represents (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (ha : a.mathematical.Normalized) (hb : b.mathematical.Normalized) :
    Rational.Represents ⟨(top l c a b).mathematical,den a b⟩ (a.mathematical.value*b.mathematical.value) := by
  have h := Rational.normalized_represents_value ⟨(top l c a b).mathematical,den a b⟩ (normalized l c a b ha hb)
  rw [value l c a b ha.1 hb.1] at h
  exact h

end ScopedC.RationalMultiplyCalls
