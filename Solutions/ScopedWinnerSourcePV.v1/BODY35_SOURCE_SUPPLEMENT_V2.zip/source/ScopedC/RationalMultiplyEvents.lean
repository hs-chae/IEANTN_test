/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyLower
import ScopedC.RationalMultiplyShape

namespace ScopedC.RationalMultiplyCalls.Events
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
open ScopedC.RationalMultiplyFrames (gFrame ghFrame topFrame)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000
variable {code : List Function} {l : PoolCalls.PoolLayout} {c : Cursor} {a b : Input}

def e1 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"ng",[.natObject a.numerator.slot,.natObject b.denSlot],(frame c.state a b),.natObject c.state.nats.values.length,(frame (c1 l c a b).state a b),raise_once (raise_once (raise_once (low.gCall)))⟩

def e2 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"ng",[.natObject b.numerator.slot,.natObject a.denSlot],(gFrame (c1 l c a b).state a b c.state.nats.values.length),.natObject (c1 l c a b).state.nats.values.length,(gFrame (c2 l c a b).state a b c.state.nats.values.length),raise_once (raise_once (raise_once (low.hCall)))⟩

def e3 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"nd",[.natObject a.numerator.slot,.natObject c.state.nats.values.length],(ghFrame (c2 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),.natObject (c2 l c a b).state.nats.values.length,(ghFrame (c3 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),raise_once (raise_once (raise_once (low.aDiv)))⟩

def e4 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"smake",[.natObject (c2 l c a b).state.nats.values.length,unsigned32 (SignedNegCalls.bit a.numerator.negative)],(ghFrame (c3 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),(left l c a b).source,(ghFrame (c4 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),raise_once (low.aMake)⟩

def e5 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"nd",[.natObject b.numerator.slot,.natObject (c1 l c a b).state.nats.values.length],(ghFrame (c4 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),.natObject (c4 l c a b).state.nats.values.length,(ghFrame (c5 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),raise_once (raise_once (raise_once (low.bDiv)))⟩

def e6 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"smake",[.natObject (c4 l c a b).state.nats.values.length,unsigned32 (SignedNegCalls.bit b.numerator.negative)],(ghFrame (c5 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),(right l c a b).source,(ghFrame (c6 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),raise_once (low.bMake)⟩

def e7 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"sm",[(left l c a b).source,(right l c a b).source],(ghFrame (c6 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),(top l c a b).source,(ghFrame (c8 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length),low.topCall⟩

def e8 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"nd",[.natObject a.denSlot,.natObject (c1 l c a b).state.nats.values.length],(topFrame (c8 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)),.natObject (c8 l c a b).state.nats.values.length,(topFrame (c9 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)),raise_once (raise_once (raise_once (low.aDen)))⟩

def e9 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"nd",[.natObject b.denSlot,.natObject c.state.nats.values.length],(topFrame (c9 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)),.natObject (c9 l c a b).state.nats.values.length,(topFrame (c10 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)),raise_once (raise_once (raise_once (low.bDen)))⟩

def e10 (low : Lower code l c a b) : CallEvents.Event Header.layout code 5 :=
  ⟨"nm",[.natObject (c8 l c a b).state.nats.values.length,.natObject (c9 l c a b).state.nats.values.length],(topFrame (c10 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)),.natObject (c10 l c a b).state.nats.values.length,(topFrame (c11 l c a b).state a b c.state.nats.values.length (c1 l c a b).state.nats.values.length (top l c a b)),raise_once (raise_once (raise_once (low.denCall)))⟩

noncomputable def calls (low : Lower code l c a b) : Call :=
  CallEvents.append (CallEvents.one (e1 low)) (CallEvents.append (CallEvents.one (e2 low)) (CallEvents.append (CallEvents.one (e3 low)) (CallEvents.append (CallEvents.one (e4 low)) (CallEvents.append (CallEvents.one (e5 low)) (CallEvents.append (CallEvents.one (e6 low)) (CallEvents.append (CallEvents.one (e7 low)) (CallEvents.append (CallEvents.one (e8 low)) (CallEvents.append (CallEvents.one (e9 low)) (CallEvents.one (e10 low))))))))))

theorem different2_1 (low : Lower code l c a b) : (e2 low).before≠(e1 low).before := by
  intro eq
  have h := congrArg (fun s : State=>s.nats.values.length) eq
  change (c1 l c a b).state.nats.values.length=c.state.nats.values.length at h
  rw[size1] at h
  omega

theorem different5_3 (low : Lower code l c a b) : (e5 low).before≠(e3 low).before := by
  intro eq
  have h := congrArg (fun s : State=>s.nats.values.length) eq
  change (c4 l c a b).state.nats.values.length=(c2 l c a b).state.nats.values.length at h
  rw[size4,size2] at h
  omega

theorem different6_4 (low : Lower code l c a b) : (e6 low).before≠(e4 low).before := by
  intro eq
  have h := congrArg (fun s : State=>s.nats.values.length) eq
  change (c5 l c a b).state.nats.values.length=(c3 l c a b).state.nats.values.length at h
  rw[size5,size3] at h
  omega

theorem different8_3 (low : Lower code l c a b) : (e8 low).before≠(e3 low).before := by
  intro eq
  have h := congrArg (fun s : State=>s.nats.values.length) eq
  change (c8 l c a b).state.nats.values.length=(c2 l c a b).state.nats.values.length at h
  rw[size8,size2] at h
  omega

theorem different8_5 (low : Lower code l c a b) : (e8 low).before≠(e5 low).before := by
  intro eq
  have h := congrArg (fun s : State=>s.nats.values.length) eq
  change (c8 l c a b).state.nats.values.length=(c4 l c a b).state.nats.values.length at h
  rw[size8,size4] at h
  omega

theorem different9_3 (low : Lower code l c a b) : (e9 low).before≠(e3 low).before := by
  intro eq
  have h := congrArg (fun s : State=>s.nats.values.length) eq
  change (c9 l c a b).state.nats.values.length=(c2 l c a b).state.nats.values.length at h
  rw[size9,size2] at h
  omega

theorem different9_5 (low : Lower code l c a b) : (e9 low).before≠(e5 low).before := by
  intro eq
  have h := congrArg (fun s : State=>s.nats.values.length) eq
  change (c9 l c a b).state.nats.values.length=(c4 l c a b).state.nats.values.length at h
  rw[size9,size4] at h
  omega

theorem different9_8 (low : Lower code l c a b) : (e9 low).before≠(e8 low).before := by
  intro eq
  have h := congrArg (fun s : State=>s.nats.values.length) eq
  change (c9 l c a b).state.nats.values.length=(c8 l c a b).state.nats.values.length at h
  rw[size9,size8] at h
  omega

theorem answer1 (low : Lower code l c a b) : calls low (e1 low).name (e1 low).args (e1 low).before=some ((e1 low).value,(e1 low).after) :=
  CallEvents.append_left (CallEvents.one_self (e1 low))

theorem answer2 (low : Lower code l c a b) : calls low (e2 low).name (e2 low).args (e2 low).before=some ((e2 low).value,(e2 low).after) :=
  CallEvents.append_right (CallEvents.one_before_other (e1 low) (different2_1 low)) (CallEvents.append_left (CallEvents.one_self (e2 low)))

theorem answer3 (low : Lower code l c a b) : calls low (e3 low).name (e3 low).args (e3 low).before=some ((e3 low).value,(e3 low).after) :=
  CallEvents.append_right (CallEvents.one_other (e1 low) (by change ("nd":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e2 low) (by change ("nd":String)≠"ng";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self (e3 low))))

theorem answer4 (low : Lower code l c a b) : calls low (e4 low).name (e4 low).args (e4 low).before=some ((e4 low).value,(e4 low).after) :=
  CallEvents.append_right (CallEvents.one_other (e1 low) (by change ("smake":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e2 low) (by change ("smake":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e3 low) (by change ("smake":String)≠"nd";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self (e4 low)))))

theorem answer5 (low : Lower code l c a b) : calls low (e5 low).name (e5 low).args (e5 low).before=some ((e5 low).value,(e5 low).after) :=
  CallEvents.append_right (CallEvents.one_other (e1 low) (by change ("nd":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e2 low) (by change ("nd":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_before_other (e3 low) (different5_3 low)) (CallEvents.append_right (CallEvents.one_other (e4 low) (by change ("nd":String)≠"smake";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self (e5 low))))))

theorem answer6 (low : Lower code l c a b) : calls low (e6 low).name (e6 low).args (e6 low).before=some ((e6 low).value,(e6 low).after) :=
  CallEvents.append_right (CallEvents.one_other (e1 low) (by change ("smake":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e2 low) (by change ("smake":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e3 low) (by change ("smake":String)≠"nd";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_before_other (e4 low) (different6_4 low)) (CallEvents.append_right (CallEvents.one_other (e5 low) (by change ("smake":String)≠"nd";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self (e6 low)))))))

theorem answer7 (low : Lower code l c a b) : calls low (e7 low).name (e7 low).args (e7 low).before=some ((e7 low).value,(e7 low).after) :=
  CallEvents.append_right (CallEvents.one_other (e1 low) (by change ("sm":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e2 low) (by change ("sm":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e3 low) (by change ("sm":String)≠"nd";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e4 low) (by change ("sm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e5 low) (by change ("sm":String)≠"nd";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e6 low) (by change ("sm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self (e7 low))))))))

theorem answer8 (low : Lower code l c a b) : calls low (e8 low).name (e8 low).args (e8 low).before=some ((e8 low).value,(e8 low).after) :=
  CallEvents.append_right (CallEvents.one_other (e1 low) (by change ("nd":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e2 low) (by change ("nd":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_before_other (e3 low) (different8_3 low)) (CallEvents.append_right (CallEvents.one_other (e4 low) (by change ("nd":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_before_other (e5 low) (different8_5 low)) (CallEvents.append_right (CallEvents.one_other (e6 low) (by change ("nd":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e7 low) (by change ("nd":String)≠"sm";decide +kernel) _ _) (CallEvents.append_left (CallEvents.one_self (e8 low)))))))))

theorem answer9 (low : Lower code l c a b) : calls low (e9 low).name (e9 low).args (e9 low).before=some ((e9 low).value,(e9 low).after) :=
  CallEvents.append_right (CallEvents.one_other (e1 low) (by change ("nd":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e2 low) (by change ("nd":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_before_other (e3 low) (different9_3 low)) (CallEvents.append_right (CallEvents.one_other (e4 low) (by change ("nd":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_before_other (e5 low) (different9_5 low)) (CallEvents.append_right (CallEvents.one_other (e6 low) (by change ("nd":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e7 low) (by change ("nd":String)≠"sm";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_before_other (e8 low) (different9_8 low)) (CallEvents.append_left (CallEvents.one_self (e9 low))))))))))

theorem answer10 (low : Lower code l c a b) : calls low (e10 low).name (e10 low).args (e10 low).before=some ((e10 low).value,(e10 low).after) :=
  CallEvents.append_right (CallEvents.one_other (e1 low) (by change ("nm":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e2 low) (by change ("nm":String)≠"ng";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e3 low) (by change ("nm":String)≠"nd";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e4 low) (by change ("nm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e5 low) (by change ("nm":String)≠"nd";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e6 low) (by change ("nm":String)≠"smake";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e7 low) (by change ("nm":String)≠"sm";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e8 low) (by change ("nm":String)≠"nd";decide +kernel) _ _) (CallEvents.append_right (CallEvents.one_other (e9 low) (by change ("nm":String)≠"nd";decide +kernel) _ _) (CallEvents.one_self (e10 low))))))))))

theorem closed (low : Lower code l c a b) : ∀ name args before value after,
    calls low name args before=some (value,after) → SourceCall Header.layout code 5 name args before value after := by
  intro name args before value after h
  exact CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e1 low) h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e2 low) h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e3 low) h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e4 low) h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e5 low) h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e6 low) h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e7 low) h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e8 low) h) (fun _ _ _ _ _ h=>CallEvents.append_closed (fun _ _ _ _ _ h=>CallEvents.one_closed (e9 low) h) (fun _ _ _ _ _ h=>CallEvents.one_closed (e10 low) h) h) h) h) h) h) h) h) h) h
end ScopedC.RationalMultiplyCalls.Events
