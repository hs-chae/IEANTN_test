/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalStepEvents
import ScopedC.PoolCursorEffects

namespace ScopedC.DecimalExpressions
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def value (digits : List Nat) (acc : Nat) : Nat := digits.foldl (fun a d => a*10+d) acc

structure LoopPost (code : List Function) (l : PoolLayout) (start final : Cursor)
    (buf : Address) (inputSlot outputSlot acc : Nat) (digits consumed remaining : List Nat)
    (events : List (CallEvents.Event Header.layout code 2)) : Prop where
  valid : Valid l final
  live : NatArena.Borrow final.state.nats outputSlot (value remaining acc)
  buffer : DecimalBuffer.At final.state buf digits
  top : final.top=start.top+4*remaining.length
  heap : final.state.heap.length=start.state.heap.length
  environment : final.state.env=start.state.env
  size : final.state.nats.values.length=start.state.nats.values.length+4*remaining.length
  counts : CallEvents.counts events=List.range' start.state.nats.values.length (4*remaining.length)
  other : ∀ i,i≠l.pool → i≠l.top → i≠l.high → final.state.heap[i]?=start.state.heap[i]?
  source : ∀ service,Answers service events →
    Loops.WhileRun (Eval Header.layout service) (Declare Header.layout service) truth Scope
      condition iteration (DecimalFrames.loop start.state buf inputSlot consumed.length)
      (.continuing (DecimalFrames.loop final.state buf outputSlot digits.length))

theorem four_size (l : PoolLayout) (c : Cursor) (a d : Nat) :
    (DecimalCalls.c4 l c a d).state.nats.values.length=c.state.nats.values.length+4 := by
  have h1 := size l c 10
  have h2 := size l (DecimalCalls.c1 l c) (a*10)
  have h3 := size l (DecimalCalls.c2 l c a) d
  have h4 := size l (DecimalCalls.c3 l c a d) (a*10+d)
  change (DecimalCalls.c1 l c).state.nats.values.length=c.state.nats.values.length+1 at h1
  change (DecimalCalls.c2 l c a).state.nats.values.length=(DecimalCalls.c1 l c).state.nats.values.length+1 at h2
  change (DecimalCalls.c3 l c a d).state.nats.values.length=(DecimalCalls.c2 l c a).state.nats.values.length+1 at h3
  change (DecimalCalls.c4 l c a d).state.nats.values.length=(DecimalCalls.c3 l c a d).state.nats.values.length+1 at h4
  rw [h4,h3,h2,h1]

theorem four_other (l : PoolLayout) (c : Cursor) (a d i : Nat)
    (hp : i≠l.pool) (ht : i≠l.top) (hh : i≠l.high) :
    (DecimalCalls.c4 l c a d).state.heap[i]?=c.state.heap[i]? := by
  unfold DecimalCalls.c4
  rw [other l (DecimalCalls.c3 l c a d) (a*10+d) i hp ht hh]
  unfold DecimalCalls.c3
  rw [other l (DecimalCalls.c2 l c a) d i hp ht hh]
  unfold DecimalCalls.c2
  rw [other l (DecimalCalls.c1 l c) (a*10) i hp ht hh]
  exact other l c 10 i hp ht hh


theorem loop_exists (code : List Function)
    (nuInstalled : Generated.f_nu∈code) (nmInstalled : Generated.f_nm∈code)
    (naInstalled : Generated.f_na∈code) (keepInstalled : Generated.f_keep∈code)
    (digits : List Nat) (good : ∀ d∈digits,d<10) (length : digits.length<2^32)
    {remaining consumed : List Nat} {l : PoolLayout} {c : Cursor} {buf : Address} {slot acc : Nat}
    (input : digits=consumed++remaining)
    (live : NatArena.Borrow c.state.nats slot acc) (valid : Valid l c)
    (room : c.top+4*remaining.length≤capacity) (hbuf : DecimalBuffer.At c.state buf digits)
    (hp : buf.object≠l.pool) (ht : buf.object≠l.top) (hh : buf.object≠l.high) :
    ∃ final outputSlot events,LoopPost code l c final buf slot outputSlot acc digits consumed remaining events := by
  induction remaining generalizing consumed c slot acc with
  | nil =>
    have endIndex : consumed.length=digits.length := by simp [input]
    refine ⟨c,slot,[],valid,live,hbuf,?_,rfl,rfl,?_,?_,?_,?_⟩
    · simp
    · simp
    · rfl
    · intro i hi ht hh
      rfl
    · intro service answers
      rw [endIndex]
      exact Loops.WhileRun.done (source_terminator service hbuf) rfl
  | cons d rest ih =>
    have hk : consumed.length<digits.length := by simp [input]
    have digitAt : digits[consumed.length]=d := by simp [input,List.getElem_append_right]
    have hd : digits[consumed.length]<10 := good _ (List.getElem_mem hk)
    have hd' : d<10 := by simpa only [digitAt] using hd
    have rstep : c.top+3<capacity := by simp only [List.length_cons] at room;omega
    obtain ⟨headEvents,headCounts,headSource⟩ := step_events code nuInstalled nmInstalled naInstalled keepInstalled
      live valid rstep hbuf hk hd length hp ht hh
    rw [digitAt] at headSource
    let nextCursor := DecimalCalls.c4 l c acc d
    let nextSlot := DecimalCalls.resultSlot l c acc d
    have nextValid : Valid l nextCursor := (DecimalCalls.contexts acc d valid rstep).2.2.2
    have nextLive : NatArena.Borrow nextCursor.state.nats nextSlot (acc*10+d) :=
      next_borrow l (DecimalCalls.c3 l c acc d) (acc*10+d)
    have b1 : DecimalBuffer.At (DecimalCalls.c1 l c).state buf digits := next_buffer hbuf 10 hp ht hh
    have b2 : DecimalBuffer.At (DecimalCalls.c2 l c acc).state buf digits := next_buffer b1 (acc*10) hp ht hh
    have b3 : DecimalBuffer.At (DecimalCalls.c3 l c acc d).state buf digits := next_buffer b2 d hp ht hh
    have nextBuffer : DecimalBuffer.At nextCursor.state buf digits := next_buffer b3 (acc*10+d) hp ht hh
    have nextInput : digits=(consumed++[d])++rest := by simpa [List.append_assoc] using input
    have nextRoom : nextCursor.top+4*rest.length≤capacity := by
      change c.top+1+1+1+1+4*rest.length≤capacity
      simp only [List.length_cons] at room
      omega
    obtain ⟨final,outSlot,tailEvents,post⟩ := ih nextInput nextLive nextValid nextRoom nextBuffer
    have hs := four_shape l c acc d
    have hn := four_size l c acc d
    refine ⟨final,outSlot,headEvents++tailEvents,post.valid,?_,post.buffer,?_,
      post.heap.trans hs.1,post.environment.trans hs.2,?_,?_,?_,?_⟩
    · exact post.live
    · have htop := post.top
      change final.top=(c.top+1+1+1+1)+4*rest.length at htop
      simp only [List.length_cons]
      omega
    · rw [post.size,hn]
      simp only [List.length_cons]
      omega
    · simp only [CallEvents.counts,List.map_append]
      change CallEvents.counts headEvents++CallEvents.counts tailEvents=_
      rw [headCounts,post.counts,hn]
      change List.range' c.state.nats.values.length 4++
        List.range' (c.state.nats.values.length+4) (4*rest.length)=_
      rw [List.range'_append_1]
      congr 1
      simp only [List.length_cons]
      omega
    · intro i hi hit hih
      exact (post.other i hi hit hih).trans (four_other l c acc d i hi hit hih)
    · intro service answers
      have headAnswers : Answers service headEvents := fun e he => answers e (List.mem_append_left _ he)
      have tailAnswers : Answers service tailEvents := fun e he => answers e (List.mem_append_right _ he)
      have headRun := headSource service headAnswers
      have tailRun := post.source service tailAnswers
      have nextIndex : (consumed++[d]).length=consumed.length+1 := by simp
      rw [nextIndex] at tailRun
      exact Loops.WhileRun.next (source_condition service hbuf hk hd) rfl headRun tailRun

end ScopedC.DecimalExpressions
