/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyData
import ScopedC.ArithmeticCursorCalls

namespace ScopedC.RationalMultiplyCalls
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option maxRecDepth 100000

theorem top6 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (c6 l c a b).top=c.top+6 := by unfold c6;rfl

theorem contexts {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+10<PoolCalls.capacity) (a b : Input) :
    Valid l (c1 l c a b) ∧ Valid l (c2 l c a b) ∧ Valid l (c3 l c a b) ∧
    Valid l (c4 l c a b) ∧ Valid l (c5 l c a b) ∧ Valid l (c6 l c a b) ∧
    Valid l (c7 l c a b) ∧ Valid l (c8 l c a b) ∧ Valid l (c9 l c a b) ∧
    Valid l (c10 l c a b) ∧ Valid l (c11 l c a b) := by
  have h1 := next_valid (g a b) ctx (by omega)
  have h2 := next_valid (h a b) h1 (by change c.top+1<PoolCalls.capacity;omega)
  have h3 := next_valid (a.numerator.magnitude/g a b) h2 (by change c.top+2<PoolCalls.capacity;omega)
  have h4 := next_valid 0 h3 (by change c.top+3<PoolCalls.capacity;omega)
  have h5 := next_valid (b.numerator.magnitude/h a b) h4 (by change c.top+4<PoolCalls.capacity;omega)
  have h6 : Valid l (c6 l c a b) := by unfold c6;exact next_valid 0 h5 (by change c.top+5<PoolCalls.capacity;omega)
  have h7 := next_valid (productMagnitude l c a b) h6 (by rw[top6];omega)
  have h8 := next_valid 0 h7 (by change (c6 l c a b).top+1<PoolCalls.capacity;rw[top6];omega)
  have h9 := next_valid (a.denominator/h a b) h8 (by change (c6 l c a b).top+2<PoolCalls.capacity;rw[top6];omega)
  have h10 := next_valid (b.denominator/g a b) h9 (by change (c6 l c a b).top+3<PoolCalls.capacity;rw[top6];omega)
  have h11 := next_valid (den a b) h10 (by change (c6 l c a b).top+4<PoolCalls.capacity;rw[top6];omega)
  exact ⟨h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11⟩

theorem input2 {l : PoolCalls.PoolLayout} {c : Cursor} {a b q : Input} (hq : q.Live c.state) :
    q.Live (c2 l c a b).state := Input.live_after (Input.live_after hq)

theorem input4 {l : PoolCalls.PoolLayout} {c : Cursor} {a b q : Input} (hq : q.Live c.state) :
    q.Live (c4 l c a b).state := Input.live_after (Input.live_after (input2 hq))

theorem input6 {l : PoolCalls.PoolLayout} {c : Cursor} {a b q : Input} (hq : q.Live c.state) :
    q.Live (c6 l c a b).state := by
  unfold c6
  exact Input.live_after (Input.live_after (input4 hq))

theorem g_live2 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    NatArena.Borrow (c2 l c a b).state.nats c.state.nats.values.length (g a b) :=
  preserves (next_borrow l c (g a b))

theorem h_live2 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    NatArena.Borrow (c2 l c a b).state.nats (c1 l c a b).state.nats.values.length (h a b) :=
  next_borrow l (c1 l c a b) (h a b)

theorem g_live6 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    NatArena.Borrow (c6 l c a b).state.nats c.state.nats.values.length (g a b) := by
  unfold c6
  exact CursorBorrow.preserves (c:=c2 l c a b) [a.numerator.magnitude/g a b,0,b.numerator.magnitude/h a b,0]
    (g_live2 l c a b)

theorem h_live4 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    NatArena.Borrow (c4 l c a b).state.nats (c1 l c a b).state.nats.values.length (h a b) :=
  preserves (preserves (h_live2 l c a b))

theorem h_live6 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    NatArena.Borrow (c6 l c a b).state.nats (c1 l c a b).state.nats.values.length (h a b) := by
  unfold c6
  exact preserves (preserves (h_live4 l c a b))

theorem left_live6 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (left l c a b).Live (c6 l c a b).state := by
  unfold c6
  exact preserves (preserves (left_live l c a b))

end ScopedC.RationalMultiplyCalls
