/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalLocalFrames
import ScopedC.RationalCompareData
import ScopedC.NumericSignedAddRefinement
import ScopedC.NumericRationalMakeRefinement

namespace ScopedC.RationalAddCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor ScopedNumerical
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c6 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := RationalCompareCalls.final l c a b
def x (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Endpoint := RationalCompareCalls.left l c a b
def y (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Endpoint := RationalCompareCalls.right l c a b
def magnitude (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Nat := SignedAddCalls.magnitude (x l c a b) (y l c a b)
def sign (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Bool := SignedAddCalls.negative (x l c a b) (y l c a b)
def c7 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c6 l c a b) (magnitude l c a b)
def c8 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c7 l c a b) 0
def sum (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Endpoint :=
  ⟨(c6 l c a b).state.nats.values.length,magnitude l c a b,if magnitude l c a b=0 then false else sign l c a b⟩
def denominator (a b : Input) : Nat := a.denominator*b.denominator
def c9 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor := next l (c8 l c a b) (denominator a b)
def c14 (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Cursor :=
  RationalMakeCalls.c5 l (c9 l c a b) (sum l c a b) (denominator a b)
def result (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) : Value :=
  RationalMakeCalls.result l (c9 l c a b) (sum l c a b) (denominator a b)

theorem sum_source (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (sum l c a b).source=SignedAddCalls.result (c6 l c a b).state (x l c a b) (y l c a b) := by
  by_cases hz : SignedAddCalls.magnitude (x l c a b) (y l c a b)=0 <;>
    simp [sum,Endpoint.source,SignedAddCalls.result,SignedAddCalls.resultSign,hz,magnitude,sign,SignedNegCalls.bit]

theorem sum_live (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (sum l c a b).Live (c8 l c a b).state := PoolCursor.preserves (PoolCursor.next_borrow l (c6 l c a b) (magnitude l c a b))

theorem sum_value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (sum l c a b).mathematical.value =
      a.numerator.mathematical.value*(b.denominator:Int)+b.numerator.mathematical.value*(a.denominator:Int) := by
  have hs : (sum l c a b).mathematical=Signed.make (magnitude l c a b) (sign l c a b) := rfl
  rw [hs]
  unfold magnitude sign
  rw [SignedAddCalls.mathematical,Signed.value_add]
  exact congrArg₂ (·+·) (RationalCrossCalls.value l c a.numerator b.denominator)
    (RationalCrossCalls.value l (RationalCompareCalls.middle l c a b) b.numerator a.denominator)

theorem c9_top (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    (c9 l c a b).top=c.top+9 := rfl

theorem c9_context {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+13<PoolCalls.capacity) (a b : Input) : Valid l (c9 l c a b) := by
  exact CursorFrames.advance_valid ctx
    [0,a.numerator.magnitude*b.denominator,0,0,b.numerator.magnitude*a.denominator,0,magnitude l c a b,0,denominator a b]
    (by simp;omega)

theorem result_decoded (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    NumericRepresentation.rational (c14 l c a b).state (result l c a b)=
      some (Rational.normalize (sum l c a b).mathematical (denominator a b)) :=
  RationalMakeCalls.decoded_result l (c9 l c a b) (sum l c a b) (Nat.mul_pos ha hb)

theorem mathematical_value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input)
    (ha : 0<a.denominator) (hb : 0<b.denominator) :
    (Rational.normalize (sum l c a b).mathematical (denominator a b)).value = a.mathematical.value+b.mathematical.value := by
  rw [Rational.normalize_value (sum l c a b).mathematical (denominator a b) (by exact Nat.ne_of_gt (Nat.mul_pos ha hb))]
  rw [Rat.normalize_eq_mkRat,Rat.mkRat_eq_divInt,Rat.divInt_eq_div,Int.cast_natCast]
  rw [sum_value]
  unfold Input.mathematical Rational.value denominator
  have ha' : (a.denominator:Rat)≠0 := by exact_mod_cast Nat.ne_of_gt ha
  have hb' : (b.denominator:Rat)≠0 := by exact_mod_cast Nat.ne_of_gt hb
  push_cast
  field_simp

end ScopedC.RationalAddCalls
