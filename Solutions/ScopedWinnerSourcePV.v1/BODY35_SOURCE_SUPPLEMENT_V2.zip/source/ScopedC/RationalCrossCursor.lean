/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalCrossCalls
import ScopedC.CursorLocals

namespace ScopedC.RationalCrossCalls
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.NatWrapperCalls
open ScopedC.DyadicRepresentation ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem make_on_cursor (code : List Function)
    (smakeInstalled : Generated.f_smake∈code) (nzInstalled : Generated.f_nz∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top<PoolCalls.capacity) {slot d : Nat}
    (live : NatArena.Borrow c.state.nats slot d) :
    SourceCall Header.layout code 4 "smake" [.natObject slot,SignedCompareCalls.integer 0]
      c.state (positive slot d).source (c1 l c).state := by
  have h := SignedCalls.smake_call (input:=SignedCompareCalls.integer 0) code smakeInstalled nzInstalled nuInstalled
    neInstalled keepInstalled ctx room live (n:=d) (neg:=0) (by decide +kernel) (by rfl)
  change SourceCall Header.layout code 4 "smake" [.natObject slot,SignedCompareCalls.integer 0]
    c.state (SignedValues.value slot 0) (c1 l c).state
  simpa only [ite_self,c1,next] using h

theorem multiply_on_cursor (code : List Function)
    (smInstalled : Generated.f_sm∈code) (nmInstalled : Generated.f_nm∈code)
    (smakeInstalled : Generated.f_smake∈code) (nzInstalled : Generated.f_nz∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+2<PoolCalls.capacity) (n : Endpoint) {slot d : Nat}
    (nLive : n.Live c.state) (dLive : NatArena.Borrow c.state.nats slot d) :
    SourceCall Header.layout code 5 "sm" [n.source,(positive slot d).source]
      (c1 l c).state (result l c n d).source (c3 l c n d).state := by
  have h := SignedMultiplyCalls.sm_closed code smInstalled nmInstalled smakeInstalled nzInstalled nuInstalled
    neInstalled keepInstalled (s:=(c1 l c).state) (l:=l) (cells:=(c1 l c).cells)
    (top:=(c1 l c).top) (high:=(c1 l c).high) n (positive slot d)
    (PoolCursor.preserves nLive) (PoolCursor.preserves dLive) (contexts ctx room n d).1
    (by simpa only [c1,next] using room)
  rw [source_result l c n slot d]
  exact h

end ScopedC.RationalCrossCalls
