/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyData

namespace ScopedC.RationalMultiplyCalls
open ScopedC.Machine ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
open ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem signed_quotient (s : Signed) (d : Nat) (hd : d∣s.mag) :
    ((Signed.make (s.mag/d) s.neg).value:Rat)=(s.value:Rat)/(d:Rat) := by
  rw [Signed.value_div s d hd,Int.cast_div_charZero (Int.natCast_dvd.mpr (by simpa only[Signed.natAbs_value]using hd)),Int.cast_natCast]

theorem top_value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) :
    ((top l c a b).mathematical.value:Rat)=
      ((a.numerator.mathematical.value:Rat)/(g a b:Rat))*((b.numerator.mathematical.value:Rat)/(h a b:Rat)) := by
  have ht : (top l c a b).mathematical=Signed.mul (left l c a b).mathematical (right l c a b).mathematical := rfl
  have hl : (left l c a b).mathematical=Signed.make (a.numerator.magnitude/g a b) a.numerator.negative := rfl
  have hr : (right l c a b).mathematical=Signed.make (b.numerator.magnitude/h a b) b.numerator.negative := rfl
  rw [ht,Signed.value_mul,Int.cast_mul,hl,hr]
  exact congrArg₂ (fun u v : Rat=>u*v)
    (signed_quotient a.numerator.mathematical (g a b) (Nat.gcd_dvd_left _ _))
    (signed_quotient b.numerator.mathematical (h a b) (Nat.gcd_dvd_left _ _))

theorem value (l : PoolCalls.PoolLayout) (c : Cursor) (a b : Input) (ha : 0<a.denominator) (hb : 0<b.denominator) :
    Rational.value ⟨(top l c a b).mathematical,den a b⟩=a.mathematical.value*b.mathematical.value := by
  change ((top l c a b).mathematical.value:Rat)/(den a b:Rat)=_
  rw [top_value]
  have hg : (g a b:Rat)≠0 := by exact_mod_cast Nat.ne_of_gt (g_pos a b hb)
  have hh : (h a b:Rat)≠0 := by exact_mod_cast Nat.ne_of_gt (h_pos a b ha)
  have ha' : (a.denominator:Rat)≠0 := by exact_mod_cast Nat.ne_of_gt ha
  have hb' : (b.denominator:Rat)≠0 := by exact_mod_cast Nat.ne_of_gt hb
  unfold den Input.mathematical Rational.value
  have dah : h a b∣a.denominator := Nat.gcd_dvd_right _ _
  have dbg : g a b∣b.denominator := Nat.gcd_dvd_right _ _
  rw [Nat.cast_mul,Nat.cast_div_charZero dah,Nat.cast_div_charZero dbg]
  field_simp

end ScopedC.RationalMultiplyCalls
