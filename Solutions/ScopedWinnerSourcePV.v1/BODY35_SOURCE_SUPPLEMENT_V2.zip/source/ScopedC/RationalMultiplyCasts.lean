/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalMultiplyFramesExtra

namespace ScopedC.RationalMultiplyCasts
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input frame)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem aggregate (s : State) (a b : Input) (gs hs : Nat) (top : Endpoint) {slot d : Nat}
    (ht : top.Live s) (hd : NatArena.Borrow s.nats slot d) :
    castValue Header.layout (RationalMultiplyFrames.topFrame s a b gs hs top) 100 "Q"
      (.aggregate [top.source,.natObject slot])=some (Input.source ⟨top,slot,d⟩) :=
  RecordCasts.rational_aggregate _ 97 ht hd (SignedNegCalls.bit_bound _)

theorem result (s : State) (a b : Input) (top : Endpoint) {slot d : Nat}
    (ht : top.Live s) (hd : NatArena.Borrow s.nats slot d) :
    castValue Header.layout (frame s a b) 100 "static Q" (Input.source ⟨top,slot,d⟩)=some (Input.source ⟨top,slot,d⟩) :=
  Input.cast (q:=⟨top,slot,d⟩) "static Q" (by decide +kernel) ⟨ht,hd⟩

end ScopedC.RationalMultiplyCasts
