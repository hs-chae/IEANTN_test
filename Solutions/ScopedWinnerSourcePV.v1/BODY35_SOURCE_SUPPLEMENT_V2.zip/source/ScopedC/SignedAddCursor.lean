/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.RationalAddFrames

namespace ScopedC.SignedAddCursor
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCursor ScopedC.DyadicRepresentation
open ScopedC.RationalPairFrames (Input)
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem sa_both (code : List Function)
    (saInstalled : Generated.f_sa∈code) (naInstalled : Generated.f_na∈code)
    (nsInstalled : Generated.f_ns∈code) (nleInstalled : Generated.f_nle∈code)
    (smakeInstalled : Generated.f_smake∈code) (nzInstalled : Generated.f_nz∈code)
    (nuInstalled : Generated.f_nu∈code) (neInstalled : Generated.f_ne∈code)
    (keepInstalled : Generated.f_keep∈code)
    {l : PoolCalls.PoolLayout} {c : Cursor} (ctx : Valid l c)
    (room : c.top+1<PoolCalls.capacity) (a b : Input) (x y : Endpoint)
    (hx : x.Live c.state) (hy : y.Live c.state) :
    SourceCall Header.layout code 5 "sa" [x.source,y.source]
      (RationalLocalFrames.both c.state a b x y) (SignedAddCalls.result c.state x y)
      (RationalLocalFrames.both (next l (next l c (SignedAddCalls.magnitude x y)) 0).state a b x y) := by
  have ctx1 := next_valid (SignedAddCalls.magnitude x y) ctx (by omega)
  have p := SignedAddCalls.sa_closed code saInstalled naInstalled nsInstalled nleInstalled
    smakeInstalled nzInstalled nuInstalled neInstalled keepInstalled
    (s:=(RationalAddFrames.both c a b x y).state) (l:=l) (cells:=c.cells) (top:=c.top) (high:=c.high)
    x y hx hy (RationalAddFrames.both_valid ctx a b x y) room
  have framed := congrArg Cursor.state
    (RationalAddFrames.next_both ctx1 a b x y 0)
  have frame0 := RationalAddFrames.next_both ctx a b x y (SignedAddCalls.magnitude x y)
  change SourceCall Header.layout code 5 "sa" [x.source,y.source]
    (RationalLocalFrames.both c.state a b x y) (SignedAddCalls.result c.state x y)
    (next l (next l (RationalAddFrames.both c a b x y) (SignedAddCalls.magnitude x y)) 0).state at p
  rw [frame0] at p
  rw [framed] at p
  exact p

end ScopedC.SignedAddCursor
