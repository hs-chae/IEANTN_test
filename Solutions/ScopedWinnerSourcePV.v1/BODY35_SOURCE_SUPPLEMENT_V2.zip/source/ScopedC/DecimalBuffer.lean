/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.DecimalDigits
import ScopedC.AllocatedFrames
namespace ScopedC.DecimalBuffer
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls
open ScopedC.NatWrapperCalls
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-- A concrete readable zero-terminated byte window. Interior pointers cover
num+negative in evaluate. These are memory equations, not parse-success facts. -/
structure At (s : State) (base : Address) (digits : List Nat) : Prop where
  allocated : base.object<s.heap.length
  fields : base.fields=[]
  address : ∀ k,k≤digits.length → addressType Header.layout s {base with index:=base.index+k}=some "char"
  contents : ∀ k,k≤digits.length → read Header.layout s {base with index:=base.index+k}=
    some (if hk : k<digits.length then DecimalDigits.digit digits[k] else DecimalDigits.char 0)
theorem read_digit {s : State} {base : Address} {k : Nat} {digits : List Nat}
    (h : At s base digits) (hk : k<digits.length) :
    read Header.layout s {base with index:=base.index+k}=some (DecimalDigits.digit digits[k]) := by
  simpa [hk] using h.contents k hk.le
theorem read_terminator {s : State} {base : Address} {digits : List Nat} (h : At s base digits) :
    read Header.layout s {base with index:=base.index+digits.length}=some (DecimalDigits.char 0) := by
  simpa using h.contents digits.length (Nat.le_refl _)
theorem address_type {s : State} {base : Address} {k : Nat} {digits : List Nat}
    (h : At s base digits) (hk : k≤digits.length) :
    addressType Header.layout s {base with index:=base.index+k}=some "char" := h.address k hk
theorem memory_eq {s t : State} {base : Address} {digits : List Nat}
    (h : At s base digits) (heap : t.heap=s.heap) : At t base digits := by
  refine ⟨?_,h.fields,?_,?_⟩
  · simpa [heap] using h.allocated
  · intro k hk
    simpa [addressType,heap] using h.address k hk
  · intro k hk
    simpa [Machine.read,heap] using h.contents k hk
theorem allocate {s : State} {base : Address} {digits : List Nat} (h : At s base digits)
    (type name : String) (v : Option Value) : At (Machine.allocate s type name v) base digits := by
  refine ⟨?_,h.fields,?_,?_⟩
  · simpa [Machine.allocate] using Nat.lt.step h.allocated
  · intro k hk
    simpa [addressType,Machine.allocate,List.getElem?_append_left h.allocated] using h.address k hk
  · intro k hk
    simpa [Machine.read,Machine.allocate,List.getElem?_append_left h.allocated] using h.contents k hk
theorem stored_other {s : State} {base : Address} {i : Nat} {digits : List Nat}
    (h : At s base digits) (o : Object) (different : base.object≠i) : At (storeObject s i o) base digits := by
  refine ⟨?_,h.fields,?_,?_⟩
  · simpa [storeObject] using h.allocated
  · intro k hk
    simpa [addressType,storeObject,List.getElem?_set,different,Ne.symm different] using h.address k hk
  · intro k hk
    simpa [Machine.read,storeObject,List.getElem?_set,different,Ne.symm different] using h.contents k hk
theorem binary_result {s : State} {base : Address} {digits : List Nat}
    (l : PoolLayout) (cells : List (Option Value)) (top high n : Nat)
    (h : At s base digits) (hp : base.object≠l.pool) (ht : base.object≠l.top) (hh : base.object≠l.high) :
    At (binaryResult l s cells top high n) base digits := by
  have hn : At {s with nats:=(NatArena.allocate s.nats n).2} base digits := memory_eq h rfl
  unfold binaryResult keepResult
  split
  · apply stored_other _ _ hh
    apply stored_other _ _ ht
    exact stored_other hn _ hp
  · apply stored_other _ _ ht
    exact stored_other hn _ hp
theorem index (service : Call) (fuel : Nat) {s : State} {base : Address} {k : Nat} {digits : List Nat}
    {array idx : Expr} (h : At s base digits)
    (hp : evalExpr Header.layout service (fuel+1) s array=some (.pointer base false,s))
    (hk : evalExpr Header.layout service (fuel+1) s idx=some (unsigned32 k,s)) (ki : k<digits.length) :
    evalExpr Header.layout service (fuel+3) s (.index array idx)=some (DecimalDigits.digit digits[k],s) := by
  rw [evalExpr,evalLValue,hp]
  simp only [Bind.bind,Option.bind,h.fields,List.isEmpty_nil,Bool.not_true,Bool.false_eq_true,↓reduceIte]
  rw [hk]
  simp only [Bind.bind,Option.bind]
  have ha := h.address k ki.le
  have hr := read_digit h ki
  simp only [h.fields] at ha hr
  simp [Bind.bind,Option.bind,asNat,unsigned32,ha,hr]
theorem index_terminator (service : Call) (fuel : Nat) {s : State} {base : Address} {digits : List Nat}
    {array idx : Expr} (h : At s base digits)
    (hp : evalExpr Header.layout service (fuel+1) s array=some (.pointer base false,s))
    (hk : evalExpr Header.layout service (fuel+1) s idx=some (unsigned32 digits.length,s)) :
    evalExpr Header.layout service (fuel+3) s (.index array idx)=some (DecimalDigits.char 0,s) := by
  rw [evalExpr,evalLValue,hp]
  simp only [Bind.bind,Option.bind,h.fields,List.isEmpty_nil,Bool.not_true,Bool.false_eq_true,↓reduceIte]
  rw [hk]
  simp only [Bind.bind,Option.bind]
  have ha := h.address digits.length (Nat.le_refl _)
  have hr := read_terminator h
  simp only [h.fields] at ha hr
  simp [Bind.bind,Option.bind,asNat,unsigned32,ha,hr]
end ScopedC.DecimalBuffer
