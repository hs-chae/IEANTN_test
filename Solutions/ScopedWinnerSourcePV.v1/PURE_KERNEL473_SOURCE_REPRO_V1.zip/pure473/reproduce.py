"""Two-source pure-kernel continuation after a fully validated fresh471-source graph.
No historical warm objects are accepted; no coefficient/exposure causality is inferred.
"""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time
B=Path(__file__).resolve().parent
STD3={'propext','Classical.choice','Quot.sound'}
def need(x,m):
    if not x:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(text):
    def pairs(rows):
        d={}
        for k,v in rows:
            need(k not in d,'duplicate JSON key');d[k]=v
        return d
    def invalid(v):raise ValueError('nonfiniteJSON '+v)
    return json.loads(text,object_pairs_hook=pairs,parse_constant=invalid)
def inputs():
    lock=strict((B/'SOURCE_LOCK.json').read_text());old=strict((B/'base/SOURCE_LOCK.json').read_text())
    need(sha(B/'base/SOURCE_LOCK.json')==lock['base_source_lock_sha256'],'exact frozen471parent')
    need(len(old['sources'])==471 and len(old['roots'])==49 and len(lock['sources'])==2 and len(lock['roots'])==11,'fixed471+2population')
    for directory,d in [(B,lock),(B/'base',old)]:
        for row in d['sources']:
            p=directory/row['path'];need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'source identity '+row['path'])
    names={r['module'] for r in old['sources']+lock['sources']}
    need(len(names)==473 and all(set(r['imports'])<=names for r in old['sources']+lock['sources']),'pure473 complete import closure')
    need(not any(n.startswith(('ScopedC.','ScopedIO.','SynergyHeightC.','SourceMainFrames','SourceMainBudget')) for n in names),'no C proof namespace')
    pins=strict((B/'INPUT_FILES_V1.json').read_text())
    for row in pins['files']:
        p=B/row['path'];need(p.is_file() and not p.is_symlink() and sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],'reproduction identity '+row['path'])
    return lock,old

def validated_base(run,old):
    # Portable wrapper receipts are followed only after their exact association is checked.
    p=run/'RECEIPT.json';r=strict(p.read_text())
    if r['status']=='PASS_FULL_NUMERICAL_REGENERATION_AND471_KERNEL_RATIONAL_PROFILE':
        need(sha(run/'mathematics/RECEIPT.json')==r['mathematical_receipt_sha256'],'full numerical/base association')
        run=run/'mathematics';r=strict((run/'RECEIPT.json').read_text())
    if r['status']=='PASS471_PURE_KERNEL_RATIONAL_PROFILE_SOURCE_COLD':
        need(sha(run/'proofs/RECEIPT.json')==r['proof_receipt_sha256'],'471wrapper/proof association')
        run=run/'proofs';r=strict((run/'RECEIPT.json').read_text())
    need(r['status']=='PASS_KERNEL_ONLY_HEIGHT_PNT_SOURCE_COLD' and r['source_modules']==471 and
        r['theorem_roots']==49 and r['application_object_inputs']==[] and
        r['source_lock_sha256']==sha(B/'base/SOURCE_LOCK.json') and
        r['reproducer_sha256']==sha(B/'base/reproduce_kernel_graph.py'),'actual fresh471parent')
    expected={x['module'] for x in old['sources']};records=r['records']
    need(len(records)==472 and {x['name'] for x in records}==expected|{'audit'},'all471actualcompiles and audit')
    byname={x['name']:x for x in records};objects=[]
    for row in old['sources']:
        name=row['module'];record=byname[name];cmd=record['command'];obj=run/'objects'/Path(name.replace('.','/')).with_suffix('.olean')
        need(record['exit_code']==0 and len(cmd)==7 and cmd[1:3]==['-j1','-R'] and cmd[5]=='-o' and
            sha(Path(cmd[0]))==old['compiler_sha256'] and sha(Path(cmd[4]))==row['sha256'] and
            Path(cmd[4]).resolve()==(Path(cmd[3])/Path(name.replace('.','/')).with_suffix('.lean')).resolve() and
            Path(cmd[6]).resolve()==obj.resolve() and not obj.is_symlink() and sha(obj)==record['object_sha256'],'parent source/command/object '+name)
        objects.append(dict(module=name,source_sha256=row['sha256'],object_sha256=sha(obj)))
    for record in records:
        for suffix,field in [('.stdout','stdout_sha256'),('.stderr','stderr_sha256'),('.time','time_sha256')]:
            need(sha(run/'logs'/(record['name']+suffix))==record[field],'parent log '+record['name'])
    audits=[strict(x.split('BODY_AUDIT ',1)[1]) for x in (run/'logs/audit.stdout').read_text().splitlines() if 'BODY_AUDIT ' in x]
    need(audits==r['audits'] and [x['name'] for x in audits]==old['roots'] and all(set(x['axioms'])<=STD3 for x in audits),'exact49parentkernelclosures')
    need({str(p.relative_to(run/'objects')) for p in (run/'objects').rglob('*.olean')}==
        {str(Path(x['module'].replace('.','/')).with_suffix('.olean')) for x in objects},'exact471source-built object population')
    return run,dict(status='VALIDATED_FRESH471_SOURCE_PURE_PARENT',receipt_sha256=sha(run/'RECEIPT.json'),objects=objects)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--environment',type=Path);ap.add_argument('--base-run',type=Path)
    ap.add_argument('--out',type=Path,required=True);ap.add_argument('--check-inputs-only',action='store_true');a=ap.parse_args()
    lock,old=inputs();out=a.out.resolve();need(not out.exists() and B not in out.parents,'fresh external output')
    if a.check_inputs_only:
        out.mkdir(parents=True);(out/'RECEIPT.json').write_text(json.dumps(dict(status='PASS473_INPUT_IDENTITIES_ONLY_NOT_REPLAY',source_lock_sha256=sha(B/'SOURCE_LOCK.json'),proof_replay=False),indent=2)+'\n');return
    need(a.environment and a.base_run and a.environment.is_file(),'pinned public environment and completed fresh471run required')
    environment=strict(a.environment.read_text());compiler=Path(environment['compiler'])
    need(sha(compiler)==lock['compiler_sha256'] and [{k:d[k] for k in ['name','commit','url']} for d in environment['generic_dependencies']]==lock['generic_dependencies'],'public environment identity')
    for row in lock['runtime_pins']['toolchain_files']:
        p=compiler.parent.parent/row['path'];need(p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'pinned runtime '+row['path'])
    for d in environment['generic_dependencies']:
        q=subprocess.run(['git','-C',d['source'],'rev-parse','HEAD'],capture_output=True,text=True)
        need(q.returncode==0 and q.stdout.strip()==d['commit'] and Path(d['objects']).is_dir(),'exact public library '+d['name'])
    parent,association=validated_base(a.base_run.resolve(),old)
    out.mkdir(parents=True);bank=out/'objects';bank.mkdir();logs=out/'logs';logs.mkdir()
    (out/'BASE_ASSOCIATION.json').write_text(json.dumps(association,indent=2)+'\n')
    for row in association['objects']:
        rel=Path(row['module'].replace('.','/')).with_suffix('.olean');target=bank/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(parent/'objects'/rel,target);need(sha(target)==row['object_sha256'],'fresh parent seeding')
    env=os.environ.copy();env['LEAN_PATH']=':'.join([str(bank)]+[x['objects'] for x in environment['generic_dependencies']]);env['LEAN_NUM_THREADS']='1'
    records=[];start=time.monotonic()
    def execute(name,source,obj=None):
        command=[str(compiler),'-j1','-R',str(B/'source' if obj else out),str(source)]
        if obj:command+=['-o',str(obj)]
        with (logs/(name+'.stdout')).open('w') as f,(logs/(name+'.stderr')).open('w') as g:
            q=subprocess.run(['/usr/bin/time','-v','-o',str(logs/(name+'.time')),*command],stdout=f,stderr=g,cwd=B,env=env)
        need(q.returncode==0,'failed extension '+name)
        text=(logs/(name+'.stdout')).read_text()+(logs/(name+'.stderr')).read_text()
        need(not any(x in text for x in ['sorryAx','Lean.ofReduceBool',"declaration uses 'sorry'",'declaration uses `sorry`']),'admitted/native diagnostic '+name)
        row=dict(module=name,command=command,exit_code=q.returncode,source_sha256=sha(source),stdout_sha256=sha(logs/(name+'.stdout')),stderr_sha256=sha(logs/(name+'.stderr')),time_sha256=sha(logs/(name+'.time')))
        if obj:row['object_sha256']=sha(obj)
        records.append(row)
    for row in lock['sources']:
        obj=bank/Path(row['module'].replace('.','/')).with_suffix('.olean');obj.parent.mkdir(parents=True,exist_ok=True)
        execute(row['module'],B/row['path'],obj)
    roots=old['roots']+lock['roots'];modules=old['root_modules']+lock['root_modules'];audit=out/'Audit.lean'
    audit.write_text(''.join('import '+x+'\n' for x in modules)+'import Lean.Util.CollectAxioms\nopen Lean Elab\nset_option maxHeartbeats 0\nset_option maxRecDepth 100000\nrun_elab do\n for root in (['+','.join('`'+x for x in roots)+'] : List Name) do\n  let ax ← Lean.collectAxioms root\n  logInfo m!"CONTINUOUS_AUDIT {(Json.mkObj [("name",toJson root.toString),("axioms",toJson (ax.toList.map Name.toString))]).compress}"\n')
    execute('audit',audit)
    audits=[strict(x.split('CONTINUOUS_AUDIT ',1)[1]) for x in (logs/'audit.stdout').read_text().splitlines() if 'CONTINUOUS_AUDIT ' in x]
    need([x['name'] for x in audits]==roots and len(audits)==60 and all(set(x['axioms'])<=STD3 for x in audits),'exact60completekernelclosures')
    inputs();validated_base(a.base_run.resolve(),old)
    result=dict(status='PASS_FRESH471_PLUS_TWO_PURE_CONTINUOUS_CONSUMERS_SOURCE_COLD_CHAIN',source_modules=473,theorem_roots=60,
        seconds=time.monotonic()-start,records=records,audits=audits,source_lock_sha256=sha(B/'SOURCE_LOCK.json'),reproducer_sha256=sha(Path(__file__)),base_association_sha256=sha(out/'BASE_ASSOCIATION.json'),
        same_pipeline_source_built_inputs=471,outside_application_object_inputs=[],source_first_PV=False,namespace_isolated=False,
        qualification='Strengthened posthoc kernel-only473-source chain. The471-source campaign numerical checkpoint was freshly compiled from emptybank; only those validated same-pipeline objects seed2new math consumers. Local refinement, not original frozen-evidence analytic-only cell or exposure causality.')
    temporary=out/'RECEIPT.pending';temporary.write_text(json.dumps(result,indent=2)+'\n');os.replace(temporary,out/'RECEIPT.json');print(result['status'])
if __name__=='__main__':main()
