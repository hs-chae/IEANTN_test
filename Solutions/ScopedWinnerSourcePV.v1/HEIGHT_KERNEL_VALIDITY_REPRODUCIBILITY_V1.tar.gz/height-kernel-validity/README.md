# Accepted fresh replay: later evidence

All463 application sources and9 exact theorem roots actually passed the fresh
host source-cold replay. See evidence/fresh-replay/SUMMARY.json and complete
axiom logs. Source-only checkpoint status files below are historical snapshots;
the immutable earlier ZIP is preserved. This accepted mathematical bundle
remains kernel-only, with full C source-first PV unfinished.

# Native-free mathematical validity of the new height PNT bound

The selected result is `SynergyAnalytic.HeightPoint.source_pi_008441646`:
under its original analytic hypotheses, the normalized prime-counting error is
at most **0.008441646 × x^(−1/8)** for **x ≥ exp(330)**. The companion theorem
proves at least **0.000114 × x^(7/8)/log(x)** primes in
**(x, x + 0.017 × x^(7/8)]**. Exact statements and hypotheses are in
`source/SynergyAnalytic/HeightPNTInstance.lean` and
`source/SynergyAnalytic/HeightPrimeRichInstance.lean`.

This is **ordinary Lean-kernel mathematical verification**. It is **not
source-first C program verification**. The actual C programs regenerate the
same numerical proposals, and the Lean kernel independently verifies the
numerical leaves and full mathematical consumers. The remaining C execution
and output-to-theorem correspondence obligations are not assumed by this
capsule and are not claimed complete.

`SOURCE_LOCK.json` freezes 463 application source modules, nine audit roots,
the compiler/runtime hashes and eight public library commits. The proof replay
starts with an empty application object directory. It accepts only
`propext`, `Classical.choice` and `Quot.sound` in every selected theorem closure.
Original mathematical hypotheses and historical experiments are preserved;
this is a supplemental research result, not a retroactive experimental success.

## Public environment

Use Linux x86-64 with Python 3, Git, tar with zstd support and ordinary C build
headers. The supplied `environment-bootstrap` directory reuses the pinned
public bootstrap from the existing project; it downloads the exact Lean
4.34.0-rc2 archive and exact public Mathlib/dependency commits. No previous
application objects are inputs.

```sh
python environment-bootstrap/scripts/bootstrap.py \
  --work /absolute/new/public-environment \
  --receipt /absolute/new/public-environment-receipt.json

python prepare_environment.py \
  --toolchain /absolute/new/public-environment/lean-4.34.0-rc2-linux \
  --mathlib /absolute/new/public-environment/mathlib \
  --out /absolute/new/height-public-environment.json
```

Alternatively, point `prepare_environment.py` at an existing *public-only*
pinned compiler/Mathlib installation. It verifies the exact compiler/runtime
bytes and all eight library commits. Application caches are not accepted as
generic dependencies.

## Complete reproduction

Choose a fresh output path outside this source capsule. Admit the command
under the host's normal resource policy; 32–64 GiB and two to four workers are
reasonable starting points for this workload. The large kernel evaluations
must not receive the obsolete 4 GiB limit. Inspect actual free RAM and disk
separately, retain host headroom, and reduce concurrency when appropriate.

```sh
python reproduce_all.py \
  --environment /absolute/new/height-public-environment.json \
  --out /absolute/new/height-validity-replay \
  --jobs 2
```

The pipeline compiles five actual C++ providers, regenerates all 58 constant
boxes, the log-height/survival boxes, 768 coefficient/slope pairs and 24 budget
blocks, checks their exact correspondence with the Lean proposal words, then
rebuilds all 463 application modules and audits the final theorem closures.
All computations are deterministic; no random seeds are used. The C providers
use 128 fractional bits in unsigned 512-bit storage, 768 logarithmically
allocated height cells, log scale 6 and endpoint allowance 21,600. Mathematical
parameters and source hashes are pinned in the numerical manifest and lock.

For only the mathematical source replay, run `reproduce.py` with the same
arguments. `PROGRESS.json` is an execution log, not a success certificate.
Only `RECEIPT.json` after all modules and exact audit roots pass is acceptance.
Compiler commands, source/object/log hashes, elapsed times and `/usr/bin/time`
peak-memory records are preserved in the output. Namespace isolation is not
claimed: this is a host source-cold replay with public generic dependencies.

## Storage and trust

The numerical CLI deletes only the five newly generated binaries after exact
output-hash checks; small regenerated outputs and receipts remain under
`numerics/regeneration/`. Original sources, locked proposals and accepted proof
artifacts are retained. Generic caches and fresh proof objects can be
regenerated; remove only experiment-owned temporary directories after checking
and preserving their receipts.

The mathematical theorem trusts the pinned Lean kernel and public library
proofs. It does not trust the raw C output for numerical truth. The raw execution
receipts additionally rely on the pinned compiler and documented runtime,
OS/API and hardware behavior. Source-first verification of the C application's
initialization, bodies, arithmetic execution, output stream and final ANT
consumer remains a separately tracked project stage.

## Evidence and independent review

`MATHEMATICAL_CLAIM.json` links the exact statements and copied accepted warm
kernel receipts using paths relative to this capsule. `evidence/INDEX.json`
hashes the original small receipts and complete axiom logs. Their original
absolute command lines are historical execution evidence; the portable commands
above perform the new replay from the frozen relative source tree.

The bounded independent mathematical review is available at
`evidence/independent-review/repository/research/analytic/independent-review-controls-v1/REPORT.html`.
It checks the stated original hypotheses, complete height/budget indexing,
endpoint allowance, tails, real J consumption, Li normalization and downstream
comparison. It found no mathematical defect in this named path. It does not
claim exhaustive primary-paper attribution coverage or completed C PV. Its
small exact replay input snapshot reproduces identical finite/hash/rational
checks under Python normal, `-O` and `-OO`:

```sh
python evidence/independent-review/repository/research/analytic/independent-review-controls-v1/reproduce_review.py \
  --out /absolute/new/independent-review-replay
```

The supplemental `evidence/source-binding` receipts record complete actual
C source/AST grammar correspondence (39 functions, 14 globals, 208 short
statement leaves, 524 physical files) and executable output association.
These receipts do not establish the still-open actual C execution and final
source-output-to-ANT join; no PV completion is claimed by the math capsule.

## Immutable source checkpoint status

This source ZIP records the complete warm kernel-accepted mathematical result.
The fresh 463-source/nine-root host replay is still pending at packaging;
`SOURCE_CHECKPOINT_STATUS_V1.json` records its actual saved progress.
A later accepted replay receipt will be published additively. No source-first
C PV completion or namespace isolation is claimed.
