import SynergyAnalytic.HeightPNTInstance
import SynergyAnalytic.HeightPrimeRichInstance
import SynergyAnalytic.HeightComparison
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxHeartbeats 0
run_elab do
 let env ← getEnv
 for n in ([`SynergyAnalytic.tangent256_universal_basis_caps,`SynergyAnalytic.HeightPoint.kernel_generic_height_all,`SynergyAnalytic.HeightPoint.finite_height_budget_tight,`SynergyAnalytic.HeightPoint.final_height_budget_tight,`SynergyAnalytic.HeightPoint.actual_height_cells,`SynergyAnalytic.HeightPoint.source_pi_008442,`SynergyAnalytic.HeightPoint.source_pi_008441646,`SynergyAnalytic.HeightPoint.source_prime_rich_017,`SynergyAnalytic.HeightPoint.height_bound_strict_on_original_interval] : List Name) do
  let some ci := env.find? n | throwError "missing {n}"
  let ax ← Lean.collectAxioms n
  logInfo m!"BODY_AUDIT {(Json.mkObj [("name",toJson n.toString),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"
