#!/usr/bin/env python3
"""Current accepted body/output boundary; distinct from the frozen387 capsule."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent;R=B.parents[1]
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 baseline=R/'scoped/audit/CONSTRUCTOR_BODY_PROGRESS_V3.json';old=json.loads(baseline.read_text())
 numeric=R/'scoped/frontend/proof/SOURCE_HELPER_SUPPORT_INDEX_V13.json';n=json.loads(numeric.read_text())
 funcs=dict(old['owned_concrete_functions']);new={
 'decimal':('decimal-source-v3','ScopedC.DecimalSource.decimal_closed','Exact decimal fold; actual initialized-text bridges prove original input magnitude.'),
 'fromS':('evaluate-support-batch-v2/SourceFromS','ScopedC.SourceFromS.fromS_closed','Exact Rational.normalize numerator / physical prepared scale; explicit ScaleAt/positive applicability.'),
 'floorQ':('source-floorq-all-v1/SourceFloorQAll','ScopedC.SourceFloorQAll.floorQ_closed','All actual2/4/6-call paths; exact original ProofBox.floorDiv output.'),
 'ceilQ':('source-ceilq-v1/SourceCeilQ','ScopedC.SourceCeilQ.ceilQ_closed','Actual qn/floorQ/sn; exact original ProofBox.ceilDiv output.'),
 'fromRI':('source-fromri-complete-v2/SourceFromRI','ScopedC.SourceFromRI.fromRI_closed','Actual six helper calls, typed I local/return and both scopes; exact floor/ceil of scaled endpoint Rat values, physical ScaleAt/pool/live/capacity prerequisites. Full old-IntervalDyadic decoder/equivalence join is separately accepted in NumericFromRIRefinement.fromRI_math.'),
 'iconst':('source-iconst-v1/SourceIconst','ScopedC.SourceIconst.iconst_closed','Actual point/fromRI, actual signed literal1 to uint32 binding, typed return/scopes; exact old IntervalDyadic.ofIntervalRat singleton at -100.'),
 'toRI':('source-tori-v6/SourceToRI','ScopedC.SourceToRI.toRI_closed','Actual two fromS calls and source I field rereads, typed RI local/return/scopes; exact signed-word/scaled-rational endpoints, positive output denominators and exact10allocation caller trace.')}
 records=[]
 for name,(folder,theorem,meaning) in new.items():
  p=R/'scoped/frontend/proof'/folder/'RECEIPT.json';j=json.loads(p.read_text());s=Path(j['source']);need(j['exit_code']==0 and j['source_unchanged'] and sha(s)==j['source_sha256'],'accepted current source '+name)
  roots=[x for x in j['audit']if x['name']==theorem];need(len(roots)==1 and set(roots[0]['axioms'])<={'propext','Classical.choice','Quot.sound'},'complete Std3 closure '+name)
  row=dict(function=name,theorem=theorem,source=str(s.relative_to(R)),source_sha256=sha(s),receipt=str(p.relative_to(R)),receipt_sha256=sha(p),axioms=roots[0]['axioms'],mathematical_output=meaning)
  records.append(row);need(name not in funcs,'duplicate owned function');funcs[name]=row
 union=dict(funcs)
 for name,row in n['concrete_functions'].items():need(name not in union,'duplicate body name');union[name]=row
 need(len(funcs)==24 and len(union)==44,'expected current actual body population')
 output=dict(status='ACCEPTED_ACTUAL_OLD_SOURCE_HELPER_BODY_PROGRESS_NOT_FULL_PROGRAM_PV',actual_old_C_function_population=68,controls_actual_whole_bodies=24,numerics_actual_whole_bodies=len(n['concrete_functions']),aggregate_actual_whole_bodies=len(union),controls_functions=funcs,aggregate_functions=union,new_controls_exact_output_records=records,numerics_named_mathematical_bridge_roots=n['mathematical_bridges'],numerics_named_bridge_root_count=len(n['mathematical_bridges']),new_controls_exact_output_function_count=7,baseline_index=dict(path=str(baseline.relative_to(R)),sha256=sha(baseline)),numerics_index=dict(path=str(numeric.relative_to(R)),sha256=sha(numeric)),prepared387_capsule='46individual accepted modules/115selectedroots; fresh full387 source-cold replay NOT RUN; predates floorQ/ceilQ and later fromRI stages',remaining='24 actual old functions still lack whole-body closure. WholefromRI, iconst and toRI actual bodies are accepted; exact original -100 IntervalDyadic constructors are proved in NumericFromRIRefinement and SourceIconst. Complete evaluate/prepare/I/O/source-linked output-to-ANT chain remains incomplete.',qualification='Actual installed C-body execution and exact arithmetic/output joins under explicit physical input/pool/range/capacity applicability. Host Std3 builds; not a whole-program source-first PV completion. Numerics bridge-root count and controls exact-output function groups are different universes and are not summed as a theorem count.')
 p=B/'CURRENT_CONTROLS_BODY_AND_MATH_INDEX_V4.json';p.write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(dict(controls=24,numerics=len(n['concrete_functions']),total=len(union),numerics_bridge_roots=len(n['mathematical_bridges']),index_sha256=sha(p))))
if __name__=='__main__':main()
