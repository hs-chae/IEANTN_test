from pathlib import Path
import hashlib,json,sys,zipfile,zlib
B=Path(__file__).resolve().parent;R=B.parents[1]
def need(v,m):
 if not v:raise RuntimeError(m)
def digest(b):return hashlib.sha256(b).hexdigest()
def main():
 clean=R/'scoped/build/current44-clean-default-OO-v1';rec=json.loads((clean/'RECEIPT.json').read_text());need(rec['status']=='PASS_HOST_COMPOSED_SOURCE_COLD_CURRENT44_COMPONENTS'and rec['base_mode']=='REBUILT_FRESH_IN_THIS_RECIPE'and len(rec['audits'])==419,'actual full clean499 receipt');need(rec['reproducer_sha256']==digest((B/'reproduce.py').read_bytes()),'executed verifier identity')
 controls=R/'scoped/build/current44-cli-controls-v1/RECEIPT.json';c=json.loads(controls.read_text());need(c['status']=='PASS_ACTUAL_CLI_NORMAL_O_OO_ROUTES'and len(c['cases'])==9,'actual CLI controls');files={}
 def put(name,p):
  need(name not in files and p.is_file()and not p.is_symlink(),'package input '+name);files[name]=p.read_bytes()
 for name in ['README.md','prepare.py','prepare_environment.py','reproduce.py','run_cli_controls.py','package.py','SOURCE_LOCK.json','PUBLIC_ENVIRONMENT_CLI_RECEIPT_V1.json','SCOPED_CURRENT43_SOURCE_COMPONENTS_V1.zip']:put(name,B/name)
 for p in sorted((B/'source').rglob('*.lean')):put(str(p.relative_to(B)),p)
 for prefix,root in [('evidence/full-clean499',clean),('evidence/first-composed44',R/'scoped/build/current44-source-cold-extension-v2'),('evidence/first-clean43',R/'scoped/build/current43-source-cold-v1')]:
  for name in ['RECEIPT.json','Audit.lean']:
   p=root/name
   if p.exists():put(prefix+'/'+name,p)
  for name in ['Audit.stdout','Audit.stderr','Audit.time','audit.stdout','audit.stderr','audit.time']:
   p=root/'logs'/name
   if p.exists():put(prefix+'/logs/'+name,p)
  if prefix=='evidence/full-clean499':
   for name in ['RECEIPT.json','Audit.lean']:
    p=root/'base-replay'/name
    if p.exists():put(prefix+'/base492/'+name,p)
   for name in ['audit.stdout','audit.stderr','audit.time']:
    p=root/'base-replay/logs'/name
    if p.exists():put(prefix+'/base492/logs/'+name,p)
 for label in ['current43-source-cold-v1','current44-source-cold-extension-v2','current44-cli-controls-v1','current44-clean-default-OO-v1']:
  for name in ['scope.json','stdout.txt','stderr.txt']:
   p=R/'resources'/label/name
   if p.exists():put('evidence/resources/'+label+'/'+name,p)
 put('evidence/cli-controls/RECEIPT.json',controls)
 for p in sorted(controls.parent.glob('*.stdout')):put('evidence/cli-controls/'+p.name,p)
 for p in sorted(controls.parent.glob('*.stderr')):put('evidence/cli-controls/'+p.name,p)
 for name in ['CURRENT_CONTROLS_BODY_AND_MATH_INDEX_V4.json','current_controls_index_v4.py']:put('indices/'+name,R/'scoped/evaluate-source-v1'/name)
 manifest=dict(status='COMPLETE499_SOURCE_COLD44_BODY_COMPONENT_NO_FULL_PROGRAM_PV',application_sources=499,payloads=885,selected_roots=419,whole_old_C_bodies=44,original_old_C_functions=68,all_selected_closures_standard_axioms_only=True,clean_default_OO_actually_passed=True,normal_O_OO_actual_CLI_cases=9,namespace_isolated=False,actual_C_execution_repeated=False,whole_program_source_first_PV_complete=False,python=sys.version,zlib=zlib.ZLIB_RUNTIME_VERSION,files=[dict(path=n,bytes=len(v),sha256=digest(v))for n,v in sorted(files.items())])
 files['ZIP_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();target=B/'SCOPED_CURRENT44_SOURCE_COLD_COMPONENT_V1.zip';need(not target.exists(),'fresh source/evidence archive')
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,data in sorted(files.items()):
   info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data,compresslevel=9)
 with zipfile.ZipFile(target)as z:
  need(z.testzip()is None and set(z.namelist())==set(files)and len(z.namelist())==len(files),'full archive membership/CRC')
  for name,data in files.items():need(z.read(name)==data,'full archive byte check '+name)
 result=dict(status='PASS_FULL_ARCHIVE_BYTE_READBACK_AND_MEASURED_REPRODUCTION',archive=str(target.resolve()),bytes=target.stat().st_size,sha256=digest(target.read_bytes()),members=len(files),manifest_sha256=digest(files['ZIP_MANIFEST.json']),actual_clean_default_receipt_sha256=digest((clean/'RECEIPT.json').read_bytes()),whole_program_source_first_PV_complete=False);(B/'SOURCE_ARCHIVE_RECEIPT_V1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
