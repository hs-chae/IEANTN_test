from pathlib import Path
import hashlib,json,shutil
B=Path(__file__).resolve().parent;R=B.parents[1]
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 base=R/'scoped/body43-supplement-v1/capsule-v1';lock=json.loads((base/'SOURCE_LOCK.json').read_text());rows=[]
 modules=[('SourceFromSTrace','source-froms-trace-v1'),('SourceScaleFrames','source-scale-frames-v1'),('ToRIStages','source-tori-stages-v3'),('ToRIFrames','source-tori-stages-v3'),('ToRITrace','source-tori-v6'),('SourceToRI','source-tori-v6'),('NumericToRIRefinement','numeric-tori-v1')]
 for name,folder in modules:
  receipt=R/'scoped/frontend/proof'/folder/name/'RECEIPT.json';d=json.loads(receipt.read_text());src=Path(d['source']);need(d['exit_code']==0 and d['source_unchanged']and sha(src)==d['source_sha256'],'accepted current source '+name)
  need(all(set(x['axioms'])<={'propext','Classical.choice','Quot.sound'}for x in d['audit']),'Std3 closure '+name)
  rel=Path('source/ScopedC')/(name+'.lean');dest=B/rel;dest.parent.mkdir(parents=True,exist_ok=True);need(not dest.exists(),'fresh extension source');dest.write_bytes(src.read_bytes())
  rows.append(dict(module=d['module'],path=str(rel),source_sha256=sha(dest),bytes=dest.stat().st_size,receipt=str(receipt),receipt_sha256=sha(receipt),roots=[x['name']for x in d['audit']]))
 out=dict(schema='SOURCE_COLD_CURRENT44_EXTENSION_V1',base_archive_sha256=sha(R/'scoped/body43-supplement-v1/SCOPED_CURRENT43_SOURCE_COMPONENTS_V1.zip'),base_source_lock_sha256=sha(base/'SOURCE_LOCK.json'),base_receipt_sha256=sha(R/'scoped/build/current43-source-cold-v1/RECEIPT.json'),sources=rows,total_application_sources=len(lock['sources'])+len(rows),total_selected_roots=len(lock['roots'])+sum(len(x['roots'])for x in rows),actual_whole_old_C_functions=44,source_first_PV_complete=False,qualification='Additive actual-source body/math extension of the fresh492-source43-body replay. Clean reproduction must first rerun that exact source-only base from pinned public generic libraries, then these seven sources and all combined closures. No arbitrary old application objects are allowed; namespace isolation and actual C executable rerun are not claimed.')
 (B/'SOURCE_LOCK.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in ['total_application_sources','total_selected_roots','actual_whole_old_C_functions']}))
if __name__=='__main__':main()
