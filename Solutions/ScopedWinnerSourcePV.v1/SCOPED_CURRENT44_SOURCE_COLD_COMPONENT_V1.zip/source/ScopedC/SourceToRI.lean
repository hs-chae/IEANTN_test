/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ToRITrace
import ScopedC.CallEventKeys
import ScopedC.CallEventPairs
import ScopedC.DeclarationReturn
import ScopedC.LocalScope
import ScopedC.NumericNatsExtensionality
namespace ScopedC.SourceToRI
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.ToRIStages ScopedC.DyadicRepresentation LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
attribute [local irreducible] finish

def initializer : Syntax.Expr := .record [
  .call (.var "fromS") [.field "." (.var "a") "lo"],
  .call (.var "fromS") [.field "." (.var "a") "hi"]]

/-- Full actual toRI constructor: both installed fromS calls, their physical
caller-field reads and allocation ordering, typed RI local and both scopes.
The decoded rational endpoints exactly equal the input signed words divided
by the actual scale. No whole-function numerical output is assumed. -/
theorem toRI_closed (code : List Function) (installed : Generated.f_toRI∈code) (lib : Library code)
    {l : PoolLayout} {c : Cursor} (valid : Valid l c) (lo hi : Endpoint) (ok : Bool)
    {object slot d : Nat} (scale : SourceFromS.ScaleAt c.state object slot d) (positive : 0 < d)
    (loLive : lo.Live c.state) (hiLive : hi.Live c.state)
    (ordered : lo.mathematical.value ≤ hi.mathematical.value) (room : c.top+9 < capacity) :
    ∃ out : Cursor, ∃ low high : Input,
      SourceCall Header.layout code 7 "toRI" [value lo hi ok] c.state
        (IntervalCasts.value low.source high.source) out.state ∧ Valid l out ∧
      low.Live out.state ∧ high.Live out.state ∧ 0 < low.denominator ∧ 0 < high.denominator ∧
      out=CursorFrames.advance l c (ToRITrace.steps lo hi d) ∧
      NumericRepresentation.interval out.state (IntervalCasts.value low.source high.source)=
        some (⟨(lo.mathematical.value:Rat)/(d:Rat),(hi.mathematical.value:Rat)/(d:Rat),
          div_le_div_of_nonneg_right (by exact_mod_cast ordered) (Nat.cast_nonneg d)⟩:IntervalRat) := by
  obtain ⟨D⟩ := stages_exist code lib valid lo hi ok scale positive loLive hiLive room
  let e1 : CallEvents.Event Header.layout code 6 :=
    ⟨"fromS",[lo.source],(initial c lo hi ok).state,D.low.source,(middle l c lo hi ok d).state,D.first⟩
  let e2 : CallEvents.Event Header.layout code 6 :=
    ⟨"fromS",[hi.source],(middle l c lo hi ok d).state,D.high.source,(finish l c lo hi ok d).state,D.second⟩
  let events := [e1,e2]
  have different : (middle l c lo hi ok d).state.nats.values.length ≠ (initial c lo hi ok).state.nats.values.length := by
    rw [middle_trace valid lo hi ok d (by omega),CursorEffects.size]
    change (initial c lo hi ok).state.nats.values.length+5 ≠ (initial c lo hi ok).state.nats.values.length
    omega
  have distinct : (middle l c lo hi ok d).state ≠ (initial c lo hi ok).state := by
    intro same
    exact different (congrArg (fun s : State => s.nats.values.length) same)
  obtain ⟨service,answer1,answer2,closed⟩ := CallEvents.pair_service e1 e2 distinct
  have expr1 : evalExpr Header.layout service 999 (initial c lo hi ok).state
      (.call (.var "fromS") [.field "." (.var "a") "lo"])=
      some (D.low.source,(middle l c lo hi ok d).state) :=
    ExpressionTemplates.call_one Header.layout service (ToRIFrames.eval_lo service 996 (ToRIFrames.binding c lo hi ok)) answer1
  have expr2 : evalExpr Header.layout service 999 (middle l c lo hi ok d).state
      (.call (.var "fromS") [.field "." (.var "a") "hi"])=
      some (D.high.source,(finish l c lo hi ok d).state) :=
    ExpressionTemplates.call_one Header.layout service (ToRIFrames.eval_hi service 996
      (ToRIFrames.middle_binding valid lo hi ok d (by omega))) answer2
  have expression : evalExpr Header.layout service 1000 (initial c lo hi ok).state initializer=
      some (.aggregate [D.low.source,D.high.source],(finish l c lo hi ok d).state) :=
    ExpressionTemplates.record_two Header.layout service expr1 expr2
  have castLow := RecordCasts.rational_record (neg:=SignedNegCalls.bit D.low.numerator.negative) (finish l c lo hi ok d).state 96 "Q" (by decide +kernel)
    D.lowLive.1 D.lowLive.2 (SignedNegCalls.bit_bound _)
  have castHigh := RecordCasts.rational_record (neg:=SignedNegCalls.bit D.high.numerator.negative) (finish l c lo hi ok d).state 96 "Q" (by decide +kernel)
    D.highLive.1 D.highLive.2 (SignedNegCalls.bit_bound _)
  have cast := IntervalCasts.aggregate (finish l c lo hi ok d).state 96 D.low.source D.high.source castLow castHigh
  have body := DeclarationReturn.body Header.layout service "RI" "r" initializer expression cast (by rfl)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  have shape := ToRIFrames.finish_shape valid D room
  rw [LocalScope.pop_local "RI" "r" (IntervalCasts.value D.low.source D.high.source) shape.1 shape.2] at body
  let out := PoolContextPop.unframe c.state (finish l c lo hi ok d)
  have bp := (List.getElem?_eq_some_iff.mp valid.pool_read).choose
  have bt := (List.getElem?_eq_some_iff.mp valid.top_read).choose
  have bh := (List.getElem?_eq_some_iff.mp valid.high_read).choose
  refine ⟨out,D.low,D.high,?_,PoolContextPop.valid D.finishValid bp bt bh,D.lowLive,D.highLive,
    D.lowPositive,D.highPositive,ToRITrace.final_advance valid D room,?_⟩
  · apply installed_body (f:=Generated.f_toRI) (rank:=6) (service:=service) installed
      closed
      (TypedFrames.bind_one Header.layout c.state "I" "a" (value lo hi ok) (value lo hi ok)
        (DyadicCasts.record {c.state with env:=[]} 97 "I" (by decide +kernel) lo.source hi.source ok
          (Endpoint.cast 97 "S" (by decide +kernel) loLive)
          (Endpoint.cast 97 "S" (by decide +kernel) hiLive))) body
    exact ⟨IntervalCasts.record (finish l c lo hi ok d).state 96 "static RI" (by decide +kernel)
      D.low.source D.high.source castLow castHigh,rfl⟩
  · have dl := Input.decoded D.lowLive D.lowPositive
    have dh := Input.decoded D.highLive D.highPositive
    have order : D.low.mathematical.value ≤ D.high.mathematical.value := by
      rw [D.lowValue,D.highValue]
      exact div_le_div_of_nonneg_right (by exact_mod_cast ordered) (Nat.cast_nonneg d)
    rw [NumericNatsExtensionality.interval (s:=out.state) (t:=(finish l c lo hi ok d).state)
      (by rfl) (IntervalCasts.value D.low.source D.high.source)]
    have divided : (lo.mathematical.value:Rat)/(d:Rat) ≤ (hi.mathematical.value:Rat)/(d:Rat) :=
      div_le_div_of_nonneg_right (by exact_mod_cast ordered) (Nat.cast_nonneg d)
    simp [NumericRepresentation.interval,IntervalCasts.value,dl,dh,D.lowValue,D.highValue,divided]

end ScopedC.SourceToRI
