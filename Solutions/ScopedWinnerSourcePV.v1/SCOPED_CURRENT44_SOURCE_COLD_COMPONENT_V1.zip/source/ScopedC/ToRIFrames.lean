/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ToRIStages
namespace ScopedC.ToRIFrames
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.ToRIStages ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem binding (c : Cursor) (lo hi : Endpoint) (ok : Bool) :
    LocalBinding.At (initial c lo hi ok).state "a" "I" (value lo hi ok) c.state.heap.length :=
  LocalBinding.allocate_head {c.state with env:=[]} "a" "I" (value lo hi ok) rfl

theorem middle_binding {l : PoolLayout} {c : Cursor} (valid : Valid l c) (lo hi : Endpoint) (ok : Bool) (d : Nat)
    (room : c.top+4 < capacity) :
    LocalBinding.At (middle l c lo hi ok d).state "a" "I" (value lo hi ok) c.state.heap.length := by
  rw [middle_trace valid lo hi ok d room]
  have hp := (List.getElem?_eq_some_iff.mp valid.pool_read).choose
  have ht := (List.getElem?_eq_some_iff.mp valid.top_read).choose
  have hh := (List.getElem?_eq_some_iff.mp valid.high_read).choose
  exact LocalBinding.advance (binding c lo hi ok) (SourceFromSTrace.steps lo d)
    (by omega) (by omega) (by omega)

theorem eval_lo (service : Call) (fuel : Nat) {s : State} {lo hi : Endpoint} {ok : Bool} {slot : Nat}
    (bound : LocalBinding.At s "a" "I" (value lo hi ok) slot) :
    evalExpr Header.layout service (fuel+2) s (.field "." (.var "a") "lo")=some (lo.source,s) :=
  ExpressionTemplates.field Header.layout service
    (LocalBinding.eval service fuel bound (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) rfl

theorem eval_hi (service : Call) (fuel : Nat) {s : State} {lo hi : Endpoint} {ok : Bool} {slot : Nat}
    (bound : LocalBinding.At s "a" "I" (value lo hi ok) slot) :
    evalExpr Header.layout service (fuel+2) s (.field "." (.var "a") "hi")=some (hi.source,s) :=
  ExpressionTemplates.field Header.layout service
    (LocalBinding.eval service fuel bound (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)) rfl

theorem finish_shape {code : List Function} {l : PoolLayout} {c : Cursor}
    (valid : Valid l c) {lo hi : Endpoint} {ok : Bool} {d : Nat}
    (D : Stages code l c lo hi ok d) (room : c.top+9 < capacity) :
    (finish l c lo hi ok d).state.heap.length=(initial c lo hi ok).state.heap.length ∧
      (finish l c lo hi ok d).state.env=(initial c lo hi ok).state.env := by
  have firstShape : (middle l c lo hi ok d).state.heap.length=(initial c lo hi ok).state.heap.length ∧
      (middle l c lo hi ok d).state.env=(initial c lo hi ok).state.env := by
    rw [middle_trace valid lo hi ok d (by omega)]
    exact CursorEffects.shape _ _ _
  have r : (middle l c lo hi ok d).top+4 < capacity := by
    rw [middle_trace valid lo hi ok d (by omega),CursorFrames.top_advance]
    change c.top+5+4 < capacity
    omega
  have secondShape : (finish l c lo hi ok d).state.heap.length=(middle l c lo hi ok d).state.heap.length ∧
      (finish l c lo hi ok d).state.env=(middle l c lo hi ok d).state.env := by
    rw [finish,SourceFromSTrace.final_advance D.middleValid hi d r]
    exact CursorEffects.shape _ _ _
  exact ⟨secondShape.1.trans firstShape.1,secondShape.2.trans firstShape.2⟩

end ScopedC.ToRIFrames
