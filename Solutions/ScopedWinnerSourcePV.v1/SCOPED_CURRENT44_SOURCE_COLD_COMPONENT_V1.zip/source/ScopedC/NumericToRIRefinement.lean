/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceToRI
import ScopedC.DyadicValueEquivalence
namespace ScopedC.NumericToRIRefinement
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.ToRIStages ScopedC.DyadicRepresentation LeanCert.Core
set_option autoImplicit false
set_option maxHeartbeats 0

theorem represented_words {s : State} (lo hi : Endpoint) (ok : Bool)
    (loLive : lo.Live s) (hiLive : hi.Live s) (ordered : lo.mathematical.value ≤ hi.mathematical.value)
    (old : IntervalDyadic) (rep : DyadicValueEquivalence.Represents s (value lo hi ok) old ok) :
    old.lo.toRat=(lo.mathematical.value:Rat)/(2^100:Nat) ∧
      old.hi.toRat=(hi.mathematical.value:Rat)/(2^100:Nat) := by
  obtain ⟨canonical,decoded,same⟩ := rep
  have source := DyadicRepresentation.decoded_interval lo hi ok loLive hiLive ordered
  have eqCanonical : canonical=words100 lo.mathematical.value hi.mathematical.value ordered :=
    (Prod.mk.inj (Option.some.inj (decoded.symm.trans source))).1
  subst canonical
  exact ⟨same.1.symm,same.2.symm⟩

/-- Actual toRI exactly reproduces the original dyadic-to-rational operation,
including semantically equivalent old dyadics with coarser stored exponents.
The representation premise is an input-decoder relation, not an assumed output. -/
theorem toRI_math (code : List Function) (installed : Generated.f_toRI∈code) (lib : Library code)
    {l : PoolLayout} {c : Cursor} (valid : Valid l c) (lo hi : Endpoint) (ok : Bool)
    {object slot : Nat} (scale : SourceFromS.ScaleAt c.state object slot (2^100))
    (loLive : lo.Live c.state) (hiLive : hi.Live c.state)
    (ordered : lo.mathematical.value ≤ hi.mathematical.value) (old : IntervalDyadic)
    (rep : DyadicValueEquivalence.Represents c.state (value lo hi ok) old ok)
    (room : c.top+9 < capacity) :
    ∃ out : Cursor, ∃ low high : Input,
      SourceCall Header.layout code 7 "toRI" [value lo hi ok] c.state
        (IntervalCasts.value low.source high.source) out.state ∧ Valid l out ∧
      low.Live out.state ∧ high.Live out.state ∧ 0 < low.denominator ∧ 0 < high.denominator ∧
      out=CursorFrames.advance l c (ToRITrace.steps lo hi (2^100)) ∧
      NumericRepresentation.interval out.state (IntervalCasts.value low.source high.source)=some old.toIntervalRat := by
  have words := represented_words lo hi ok loLive hiLive ordered old rep
  obtain ⟨out,low,high,source,outValid,lowLive,highLive,lowPositive,highPositive,trace,decoded⟩ :=
    SourceToRI.toRI_closed code installed lib valid lo hi ok scale (by positivity) loLive hiLive ordered room
  refine ⟨out,low,high,source,outValid,lowLive,highLive,lowPositive,highPositive,trace,?_⟩
  simpa only [IntervalDyadic.toIntervalRat,words.1,words.2] using decoded

end ScopedC.NumericToRIRefinement
