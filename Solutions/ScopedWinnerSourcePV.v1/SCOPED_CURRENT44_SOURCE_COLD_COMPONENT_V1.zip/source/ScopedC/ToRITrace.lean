/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.ToRIFrames
namespace ScopedC.ToRITrace
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor ScopedC.ToRIStages ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 0

def steps (lo hi : Endpoint) (d : Nat) : List Nat :=
  SourceFromSTrace.steps lo d++SourceFromSTrace.steps hi d

theorem finish_advance {code : List ScopedC.Syntax.Function} {l : PoolLayout} {c : Cursor}
    (valid : Valid l c) {lo hi : Endpoint} {ok : Bool} {d : Nat}
    (D : Stages code l c lo hi ok d) (room : c.top+9 < capacity) :
    finish l c lo hi ok d=CursorFrames.advance l (initial c lo hi ok) (steps lo hi d) := by
  have middleRoom : (middle l c lo hi ok d).top+4 < capacity := by
    rw [middle_trace valid lo hi ok d (by omega),CursorFrames.top_advance]
    change c.top+5+4 < capacity
    omega
  rw [finish,SourceFromSTrace.final_advance D.middleValid hi d middleRoom,
    middle_trace valid lo hi ok d (by omega)]
  exact (CursorSingleFrames.advance_append _ _ _ _).symm

theorem final_advance {code : List ScopedC.Syntax.Function} {l : PoolLayout} {c : Cursor}
    (valid : Valid l c) {lo hi : Endpoint} {ok : Bool} {d : Nat}
    (D : Stages code l c lo hi ok d) (room : c.top+9 < capacity) :
    PoolContextPop.unframe c.state (finish l c lo hi ok d)=CursorFrames.advance l c (steps lo hi d) := by
  rw [finish_advance valid D room]
  change PoolContextPop.unframe c.state
    (CursorFrames.advance l (CursorSingleFrames.framed c "I" "a" (value lo hi ok)) (steps lo hi d))=_
  rw [CursorSingleFrames.advance_framed valid "I" "a" (value lo hi ok) (steps lo hi d)
    (by change c.top+10 ≤ capacity;omega)]
  have pop := OneFrames.pop_frame (s:=c.state) "I" "a" (value lo hi ok)
    (CursorEffects.shape l c (steps lo hi d)).1 (CursorEffects.shape l c (steps lo hi d)).2
  dsimp only [PoolContextPop.unframe,CursorSingleFrames.framed]
  rw [pop]

end ScopedC.ToRITrace
