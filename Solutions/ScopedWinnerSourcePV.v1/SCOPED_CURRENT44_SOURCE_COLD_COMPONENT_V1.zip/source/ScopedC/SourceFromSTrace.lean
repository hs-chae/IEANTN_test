/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceFromS
import ScopedC.CursorSingleFrames
import ScopedC.CursorBorrow
namespace ScopedC.SourceFromSTrace
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor ScopedC.DyadicRepresentation
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def steps (a : Endpoint) (d : Nat) : List Nat :=
  [0,RationalMakeCalls.divisor a d,a.magnitude/RationalMakeCalls.divisor a d,0,d/RationalMakeCalls.divisor a d]

theorem c5_advance (l : PoolLayout) (c : Cursor) (a : Endpoint) (d : Nat) :
    RationalMakeCalls.c5 l c a d=CursorFrames.advance l c (steps a d) := rfl

/-- Exact five-allocation caller-frame-preserving effect of the actual
fromS source summary. This lets later callees consume its returned Q and
read another endpoint from the original caller's concrete I object. -/
theorem final_advance {l : PoolLayout} {c : Cursor} (valid : Valid l c) (a : Endpoint) (d : Nat)
    (room : c.top+4 < capacity) :
    SourceFromS.final l c a d=CursorFrames.advance l c (steps a d) := by
  unfold SourceFromS.final SourceFromS.inner
  rw [c5_advance]
  change PoolContextPop.unframe c.state
    (CursorFrames.advance l (CursorSingleFrames.framed c "S" "a" a.source) (steps a d))=_
  rw [CursorSingleFrames.advance_framed valid "S" "a" a.source (steps a d)
    (by change c.top+5 ≤ capacity;omega)]
  have pop := OneFrames.pop_frame (s:=c.state) "S" "a" a.source
    (CursorEffects.shape l c (steps a d)).1 (CursorEffects.shape l c (steps a d)).2
  dsimp only [PoolContextPop.unframe,CursorSingleFrames.framed]
  rw [pop]

 theorem preserves {l : PoolLayout} {c : Cursor} (valid : Valid l c) (a : Endpoint) (d : Nat)
    (room : c.top+4 < capacity) {slot n : Nat} (live : NatArena.Borrow c.state.nats slot n) :
    NatArena.Borrow (SourceFromS.final l c a d).state.nats slot n := by
  rw [final_advance valid a d room]
  exact CursorBorrow.preserves (steps a d) live

end ScopedC.SourceFromSTrace
