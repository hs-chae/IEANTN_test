/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceFromSTrace
namespace ScopedC.SourceScaleFrames
open ScopedC.Machine ScopedC.PoolCalls ScopedC.PoolCursor
set_option autoImplicit false
set_option maxHeartbeats 0

/-- Scale storage cannot alias any pool-mutated object: its actual scalar N
object is incompatible with the pool's array flag and unsigned counters. -/
theorem separated {l : PoolLayout} {c : Cursor} (valid : Valid l c) {object slot d : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot d) : object ≠ l.pool ∧ object ≠ l.top ∧ object ≠ l.high := by
  have hp : object ≠ l.pool := by
    intro same
    have storage := scale.storage
    rw [same,valid.pool_read] at storage
    have flags := congrArg (fun x : Option Object => x.map Object.isArray) storage
    change some true=some false at flags
    contradiction
  have ht : object ≠ l.top := by
    intro same
    have storage := scale.storage
    rw [same,valid.top_read] at storage
    have types := congrArg (fun x : Option Object => x.map Object.type) storage
    change some "unsigned"=some "N" at types
    have unequal : ("unsigned":String)≠"N" := by decide +kernel
    exact unequal (Option.some.inj types)
  have hh : object ≠ l.high := by
    intro same
    have storage := scale.storage
    rw [same,valid.high_read] at storage
    have types := congrArg (fun x : Option Object => x.map Object.type) storage
    change some "unsigned"=some "N" at types
    have unequal : ("unsigned":String)≠"N" := by decide +kernel
    exact unequal (Option.some.inj types)
  exact ⟨hp,ht,hh⟩

theorem advance {l : PoolLayout} {c : Cursor} (valid : Valid l c) {object slot d : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot d) (values : List Nat) :
    SourceFromS.ScaleAt (CursorFrames.advance l c values).state object slot d := by
  have safe := separated valid scale
  constructor
  · rw [CursorSingleFrames.advance_globals]
    exact scale.lookup
  · rw [CursorSingleFrames.advance_other l c values object safe.1 safe.2.1 safe.2.2]
    exact scale.storage
  · exact CursorBorrow.preserves values scale.live

theorem framed {c : Cursor} {object slot d : Nat} (scale : SourceFromS.ScaleAt c.state object slot d)
    (type name : String) (value : Value) :
    SourceFromS.ScaleAt (OneFrames.frame c.state type name value) object slot d := by
  have bound := (List.getElem?_eq_some_iff.mp scale.storage).choose
  constructor
  · exact scale.lookup
  · simpa only [OneFrames.frame,allocate,List.getElem?_append_left bound] using scale.storage
  · exact scale.live

end ScopedC.SourceScaleFrames
