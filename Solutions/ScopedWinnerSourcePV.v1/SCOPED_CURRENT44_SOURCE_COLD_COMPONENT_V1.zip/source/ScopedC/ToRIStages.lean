/- Copyright (c) 2026 IEANTN contributors. Apache-2.0. -/
import ScopedC.SourceScaleFrames
import ScopedC.NumericRationalCompleteness
import ScopedC.LocalBinding
namespace ScopedC.ToRIStages
open ScopedC.Syntax ScopedC.Machine ScopedC.SourceCalls ScopedC.PoolCalls ScopedC.PoolCursor
open ScopedC.RationalPairFrames (Input)
open ScopedC.DyadicRepresentation ScopedNumerical
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def value (lo hi : Endpoint) (ok : Bool) : Value := DyadicCasts.value lo.source hi.source ok
def initial (c : Cursor) (lo hi : Endpoint) (ok : Bool) : Cursor :=
  {c with state:=OneFrames.frame c.state "I" "a" (value lo hi ok)}
def middle (l : PoolLayout) (c : Cursor) (lo hi : Endpoint) (ok : Bool) (d : Nat) : Cursor :=
  SourceFromS.final l (initial c lo hi ok) lo d
def finish (l : PoolLayout) (c : Cursor) (lo hi : Endpoint) (ok : Bool) (d : Nat) : Cursor :=
  SourceFromS.final l (middle l c lo hi ok d) hi d

structure Library (code : List Function) : Prop where
  fromS : Generated.f_fromS∈code
  qm : Generated.f_qm∈code
  nz : Generated.f_nz∈code
  ng : Generated.f_ng∈code
  nd : Generated.f_nd∈code
  smake : Generated.f_smake∈code
  nu : Generated.f_nu∈code
  ne : Generated.f_ne∈code
  keep : Generated.f_keep∈code

structure Stages (code : List Function) (l : PoolLayout) (c : Cursor) (lo hi : Endpoint) (ok : Bool) (d : Nat) where
  low : Input
  high : Input
  first : SourceCall Header.layout code 6 "fromS" [lo.source] (initial c lo hi ok).state
    low.source (middle l c lo hi ok d).state
  second : SourceCall Header.layout code 6 "fromS" [hi.source] (middle l c lo hi ok d).state
    high.source (finish l c lo hi ok d).state
  middleValid : Valid l (middle l c lo hi ok d)
  finishValid : Valid l (finish l c lo hi ok d)
  lowLive : low.Live (finish l c lo hi ok d).state
  highLive : high.Live (finish l c lo hi ok d).state
  lowPositive : 0 < low.denominator
  highPositive : 0 < high.denominator
  lowValue : low.mathematical.value=lo.mathematical.value/(d:Rat)
  highValue : high.mathematical.value=hi.mathematical.value/(d:Rat)

theorem initial_valid {l : PoolLayout} {c : Cursor} (valid : Valid l c) (lo hi : Endpoint) (ok : Bool) :
    Valid l (initial c lo hi ok) := OneFrames.context_frame valid "I" "a" (value lo hi ok)

theorem middle_trace {l : PoolLayout} {c : Cursor} (valid : Valid l c) (lo hi : Endpoint) (ok : Bool) (d : Nat)
    (room : c.top+4 < capacity) :
    middle l c lo hi ok d=CursorFrames.advance l (initial c lo hi ok) (SourceFromSTrace.steps lo d) :=
  SourceFromSTrace.final_advance (initial_valid valid lo hi ok) lo d room

theorem stages_exist (code : List Function) (lib : Library code) {l : PoolLayout} {c : Cursor}
    (valid : Valid l c) (lo hi : Endpoint) (ok : Bool) {object slot d : Nat}
    (scale : SourceFromS.ScaleAt c.state object slot d) (positive : 0 < d)
    (loLive : lo.Live c.state) (hiLive : hi.Live c.state) (room : c.top+9 < capacity) :
    Nonempty (Stages code l c lo hi ok d) := by
  have initValid := initial_valid valid lo hi ok
  have initScale : SourceFromS.ScaleAt (initial c lo hi ok).state object slot d :=
    SourceScaleFrames.framed scale "I" "a" (value lo hi ok)
  have initRoom : (initial c lo hi ok).top+4 < capacity := by
    change c.top+4 < capacity
    omega
  have first := SourceFromS.fromS_closed code lib.fromS lib.qm lib.nz lib.ng lib.nd lib.smake lib.nu lib.ne lib.keep (c:=initial c lo hi ok)
    lo loLive initScale positive initValid initRoom
  obtain ⟨low,lowSource,lowLive,lowMath,lowPositive⟩ := NumericInputCompleteness.rational first.2.2
  have secondScale : SourceFromS.ScaleAt (middle l c lo hi ok d).state object slot d := by
    rw [middle_trace valid lo hi ok d (by omega)]
    exact SourceScaleFrames.advance initValid initScale (SourceFromSTrace.steps lo d)
  have secondLive : hi.Live (middle l c lo hi ok d).state :=
    SourceFromSTrace.preserves initValid lo d initRoom hiLive
  have secondRoom : (middle l c lo hi ok d).top+4 < capacity := by
    rw [middle_trace valid lo hi ok d (by omega),CursorFrames.top_advance]
    change c.top+5+4 < capacity
    omega
  have second := SourceFromS.fromS_closed code lib.fromS lib.qm lib.nz lib.ng lib.nd lib.smake lib.nu lib.ne lib.keep
    hi secondLive secondScale positive first.2.1 secondRoom
  obtain ⟨high,highSource,highLive,highMath,highPositive⟩ := NumericInputCompleteness.rational second.2.2
  have lowFinish : low.Live (finish l c lo hi ok d).state :=
    ⟨SourceFromSTrace.preserves first.2.1 hi d secondRoom lowLive.1,
      SourceFromSTrace.preserves first.2.1 hi d secondRoom lowLive.2⟩
  have lv : low.mathematical.value=lo.mathematical.value/(d:Rat) := by
    rw [lowMath]
    exact NumericRationalMakeRefinement.normalized_value lo.mathematical d positive
  have hv : high.mathematical.value=hi.mathematical.value/(d:Rat) := by
    rw [highMath]
    exact NumericRationalMakeRefinement.normalized_value hi.mathematical d positive
  refine ⟨⟨low,high,?_,?_,first.2.1,second.2.1,lowFinish,highLive,lowPositive,highPositive,lv,hv⟩⟩
  · rw [lowSource]
    exact first.1
  · rw [highSource]
    exact second.1

end ScopedC.ToRIStages
