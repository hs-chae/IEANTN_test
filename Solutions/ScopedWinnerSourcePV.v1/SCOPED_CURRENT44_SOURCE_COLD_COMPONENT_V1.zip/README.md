# Forty-four old-C helper bodies: complete source-cold component

The completed component combines the clean492-source43-body replay with seven additional actual-source proof modules, yielding499application sources,885raw include payloads and419complete selected theorem closures with only propext, Classical.choice and Quot.sound. It includes fromRI, iconst and toRI, exact original -100 constructors and old dyadic-to-rational conversion, typed argument casts, actual caller field reads and allocation/liveness effects.

This is a helper/body/math component, not a completed Scoped Winner source-first PV experiment. The full numerical producer, remaining helper/prepare/evaluator/main/I/O paths and source-output-to-ANT chain remain unfinished. Later iadd/rhull work lies outside this frozen44-body component. Original programs, mathematical assumptions,39comparator identities,8192/16384algorithms and all original experimental results remain unchanged.

## Reproduce from a clean environment

Obtain the exact public Lean toolchain and Mathlib commit recorded in the embedded43source archive, and build its eight pinned public generic dependencies. No prior application object bank is an allowed input. The source archive contains every application Lean source and raw source payload required by this component.

```
python prepare_environment.py --toolchain /path/to/lean-toolchain --mathlib /path/to/pinned/mathlib --out /tmp/body44-public.json
python reproduce.py --environment /tmp/body44-public.json --out /tmp/body44-clean
```

Run the second command under the approved resource guard. Its default route verifies and extracts the exact embedded source archive, rebuilds492application modules from only the public libraries, checks all402base closures, then compiles the seven new modules and checks all419combined closures. Base proof objects are individually hash-checked before and after and linked into a fresh combined bank under before/after hash checks; new module names cannot overwrite them. The actual measured continuation uses a hash-pinned freshly rebuilt base; the clean default recipe is separately measured.

There are no random seeds. All parameters, sources, compiler/runtime pins, dependency commits and commands are retained in SOURCE_LOCK.json, the embedded43archive and the receipts. The actual CLI acceptance paths were checked in normal,-O and-OO modes, including rejection of an incorrect base and the missing-environment default route. The complete clean default route is additionally run with PYTHONOPTIMIZE=2 inherited by child Python processes. A completed receipt, not this paragraph, establishes that latter run's status.

## What is and is not established

The actual parsed helper body must be installed and all proved physical input/pool/range/capacity conditions must hold. Prepared scale is explicitly required where needed; it is not assumed to exist at static initialization. Source initialization is computed where connected. No function result, successful effect, initial application representation or desired theorem is supplied as a generic platform fact.

The formal execution model, pinned compiler/core-runtime/Nat ABI and documented OS/hardware contracts remain explicit boundaries. Execution-order applicability for the chosen expression semantics remains part of the compiler/source connection. This source-cold proof recipe repeats no C executable run and provides no namespace-isolation claim. It is not a new primary experimental outcome, a source-completeness audit of the papers or a completed source-first PV claim.

The immutable original43archive and all earlier failed or interrupted proof attempts remain preserved. Experiment-owned extracted copies and caches may be regenerated from the pinned archives; accepted proof artifacts and original research inputs are retained.
