"""Rebuild frozen43 from public libraries, then verify the seven-source extension."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,time,zipfile
B=Path(__file__).resolve().parent
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,d):
 q=p.with_suffix('.pending');q.write_text(json.dumps(d,indent=2)+'\n');os.replace(q,p)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--environment',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--continue-verified-base',type=Path);a=ap.parse_args();lock=json.loads((B/'SOURCE_LOCK.json').read_text());out=a.out.resolve();need(not out.exists()and B not in out.parents,'fresh output outside capsule');out.mkdir(parents=True)
 archive=B/'SCOPED_CURRENT43_SOURCE_COMPONENTS_V1.zip';need(sha(archive)==lock['base_archive_sha256'],'exact frozen43 source archive');component=out/'base-source';component.mkdir()
 with zipfile.ZipFile(archive)as z:
  for info in z.infolist():
   p=Path(info.filename);need(not p.is_absolute()and'..'not in p.parts and not info.is_dir(),'safe archive member');need((info.external_attr>>16)&0o170000!=0o120000,'no archive symlinks');target=component/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(info))
 cap=component/'capsule-v1';need(sha(cap/'SOURCE_LOCK.json')==lock['base_source_lock_sha256'],'base source lock');baseLock=json.loads((cap/'SOURCE_LOCK.json').read_text());base=a.continue_verified_base.resolve()if a.continue_verified_base else out/'base-replay'
 if a.continue_verified_base is None:
  subprocess.run(['python',str(cap/'reproduce.py'),'--environment',str(a.environment.resolve()),'--out',str(base),'--jobs','2'],check=True)
 receipt=base/'RECEIPT.json';bd=json.loads(receipt.read_text());need(bd['status']=='PASS_HOST_GENERIC_ONLY_SOURCE_COLD_CURRENT43_COMPONENTS'and bd['application_object_inputs']==[],'fresh source-only43 base');need(bd['source_lock_sha256']==lock['base_source_lock_sha256']and bd['reproducer_sha256']==sha(cap/'reproduce.py'),'base source/reproducer identities');need(bd['source_modules']==492 and bd['theorem_roots']==402,'complete fixed43 base');need([x['name']for x in bd['audits']]==baseLock['roots']and all(set(x['axioms'])<={'propext','Classical.choice','Quot.sound'}for x in bd['audits']),'base completeStd3 roots')
 if a.continue_verified_base:need(sha(receipt)==lock['base_receipt_sha256'],'exact recorded current43 base continuation')
 def checkBase():
  for r in bd['records']:
   if'object_sha256'in r:
    p=base/'objects'/Path(r['name'].replace('.','/')).with_suffix('.olean');need(p.is_file()and sha(p)==r['object_sha256'],'fresh base object pin '+r['name'])
 checkBase();e=json.loads(a.environment.read_text());compiler=Path(e['compiler']);need(sha(compiler)==baseLock['compiler_sha256'],'compiler identity');need([{k:x[k]for k in ['name','url','commit']}for x in e['generic_dependencies']]==baseLock['generic_dependencies'],'public generic dependencies')
 for r in baseLock['runtime_pins']['toolchain_files']:
  p=compiler.parent.parent/r['path'];need(p.is_file()and p.stat().st_size==r['bytes']and sha(p)==r['sha256'],'kernel/runtime identity '+r['path'])
 need(subprocess.run([str(compiler),'--version'],capture_output=True,text=True,check=True).stdout.strip()==baseLock['runtime_pins']['lean_version'],'kernel version')
 objects=out/'objects';objects.mkdir()
 for r in bd['records']:
  if 'object_sha256' in r:
   rel=Path(r['name'].replace('.','/')).with_suffix('.olean');src=base/'objects'/rel;dest=objects/rel;dest.parent.mkdir(parents=True,exist_ok=True);need(not dest.exists(),'fresh verified-base link');os.link(src,dest)
 need(not({r['module']for r in lock['sources']}&{r['name']for r in bd['records']}),'extension names must not overwrite accepted base objects')
 logs=out/'logs';logs.mkdir();env=os.environ.copy();env['LEAN_PATH']=':'.join([str(objects),*[x['objects']for x in e['generic_dependencies']]]);env['LEAN_NUM_THREADS']='1';records=[];start=time.monotonic()
 def execute(role,command):
  so=logs/(role+'.stdout');se=logs/(role+'.stderr');tm=logs/(role+'.time');t=time.monotonic()
  with so.open('w')as f,se.open('w')as g:q=subprocess.run(['/usr/bin/time','-v','-o',str(tm),*command],env=env,cwd=B,stdout=f,stderr=g)
  r=dict(role=role,command=command,exit_code=q.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(so),stderr_sha256=sha(se),time_sha256=sha(tm));need(q.returncode==0,'actual compiler failure '+role);need("declaration uses 'sorry'"not in so.read_text()+se.read_text(),'admitted proof '+role);return r
 try:
  for row in lock['sources']:
   src=B/row['path'];need(src.stat().st_size==row['bytes']and sha(src)==row['source_sha256'],'new source pin '+row['module']);obj=objects/Path(row['module'].replace('.','/')).with_suffix('.olean');obj.parent.mkdir(parents=True,exist_ok=True);r=execute(row['module'],[str(compiler),'-j1','-R',str(B/'source'),str(src),'-o',str(obj)]);r['object_sha256']=sha(obj);records.append(r)
  roots=baseLock['roots']+[n for row in lock['sources']for n in row['roots']];need(len(roots)==419 and len(set(roots))==419,'exact combined root universe');imports=baseLock['root_modules']+[row['module']for row in lock['sources']];audit=out/'Audit.lean';audit.write_text(''.join('import '+n+'\n'for n in imports)+'import Lean.Util.CollectAxioms\nopen Lean Elab\nset_option maxHeartbeats 0\nrun_elab do\n let env ← getEnv\n for n in (['+','.join('`'+n for n in roots)+'] : List Name) do\n  let some ci := env.find? n | throwError "missing {n}"\n  let ax ← Lean.collectAxioms n\n  logInfo m!"EXTENSION44_AUDIT {(Json.mkObj [("name",toJson n.toString),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"\n');records.append(execute('Audit',[str(compiler),'-j1',str(audit)]));audits=[json.loads(x.split('EXTENSION44_AUDIT ',1)[1])for x in(logs/'Audit.stdout').read_text().splitlines()if'EXTENSION44_AUDIT 'in x];need([x['name']for x in audits]==roots and all(set(x['axioms'])<={'propext','Classical.choice','Quot.sound'}for x in audits),'complete combinedStd3 audit');checkBase()
  for row in lock['sources']:need(sha(B/row['path'])==row['source_sha256'],'source changed during compilation')
 except Exception as ex:
  atomic(out/'FAILURE.json',dict(status='FAILED_PRESERVED',error=str(ex),records=records));raise
 result=dict(status='PASS_HOST_COMPOSED_SOURCE_COLD_CURRENT44_COMPONENTS',reproducer_sha256=sha(Path(__file__)),source_lock_sha256=sha(B/'SOURCE_LOCK.json'),base_receipt=str(receipt),base_receipt_sha256=sha(receipt),base_mode='CONTINUED_HASH_PINNED_FRESH_SOURCE_REPLAY'if a.continue_verified_base else'REBUILT_FRESH_IN_THIS_RECIPE',base_application_object_inputs=bd['application_object_inputs'],extension_application_objects_from_verified_base=492,arbitrary_old_application_object_inputs=[],source_modules_total=499,new_source_modules=7,theorem_roots=419,records=records,audits=audits,extension_seconds=time.monotonic()-start,base_seconds=bd['elapsed_seconds'],whole_program_source_first_PV_complete=False,namespace_isolated=False,actual_C_execution_repeated=False,qualification=lock['qualification']);atomic(out/'RECEIPT.json',result);print(json.dumps({k:result[k]for k in ['status','base_mode','source_modules_total','theorem_roots','extension_seconds','base_seconds']}))
if __name__=='__main__':main()
