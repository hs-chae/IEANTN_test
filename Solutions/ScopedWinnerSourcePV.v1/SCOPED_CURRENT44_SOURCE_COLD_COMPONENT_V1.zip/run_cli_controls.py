from pathlib import Path
import json,subprocess,sys,hashlib,time
B=Path(__file__).resolve().parent;R=B.parents[1]
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 out=R/'scoped/build/current44-cli-controls-v1';need(not out.exists(),'fresh control output');out.mkdir();records=[];start=time.monotonic();env=R/'scoped/body43-supplement-v1/PUBLIC_ENVIRONMENT_V1.json';base=R/'scoped/build/current43-source-cold-v1';driver=B/'reproduce.py'
 for mode,flags in [('normal',[]),('O',['-O']),('OO',['-OO'])]:
  cases=[('positive',env,base,True),('bad_base',env,R/'scoped/build/current44-source-cold-extension-v2',False),('default_missing_environment',out/'missing_environment.json',None,False)]
  for name,environment,previous,expected in cases:
   target=out/(mode+'-'+name);cmd=[sys.executable,*flags,str(driver),'--environment',str(environment),'--out',str(target)]
   if previous is not None:cmd+=['--continue-verified-base',str(previous)]
   t=time.monotonic()
   with(out/(mode+'-'+name+'.stdout')).open('w')as so,(out/(mode+'-'+name+'.stderr')).open('w')as se:q=subprocess.run(cmd,cwd=R,stdout=so,stderr=se)
   receipt=target/'RECEIPT.json'
   if expected:
    need(q.returncode==0 and receipt.is_file(),'positive actual CLI '+mode);d=json.loads(receipt.read_text());need(d['status']=='PASS_HOST_COMPOSED_SOURCE_COLD_CURRENT44_COMPONENTS'and d['reproducer_sha256']==sha(driver)and d['theorem_roots']==419,'positive complete419 source-cold closure '+mode)
   else:need(q.returncode!=0 and not receipt.exists(),'negative actual CLI must fail closed '+mode+'/'+name)
   records.append(dict(mode=mode,case=name,expected_success=expected,exit_code=q.returncode,seconds=time.monotonic()-t,command=cmd,receipt_sha256=sha(receipt)if receipt.exists()else None));(out/'PROGRESS.json').write_text(json.dumps(records,indent=2)+'\n')
 result=dict(status='PASS_ACTUAL_CLI_NORMAL_O_OO_ROUTES',cases=records,seconds=time.monotonic()-start,validator_sha256=sha(driver),source_lock_sha256=sha(B/'SOURCE_LOCK.json'),qualification='Each positive reruns the actual seven-source extension and all419 combined Std3 roots against the hash-pinned fresh492 base. Both active route failures are exercised in each mode. The full clean default rebuild remains a separate measured reproducibility run.');tmp=out/'RECEIPT.pending';tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.replace(out/'RECEIPT.json');print(json.dumps(dict(status=result['status'],cases=len(records),seconds=result['seconds'])))
if __name__=='__main__':main()
