/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. -/
import RamanujanPV.FiniteSourceCells
import RamanujanPV.FiniteScalarMillion.LogFinal
import RamanujanPV.SegmentRamanujanMillion
import RamanujanPV.SegmentSourceMargins

/-! Every actual e/log source output is consumed in the original real-cell
enclosures, and every count comes from the actual segmented source program.
The seven-field integer predicates are the unchanged checked row data; their
actual C source execution/correctness is a separately tracked next component. -/
namespace RamanujanPV.FiniteSourceRamanujanMillion
open WindowCells
set_option autoImplicit false

theorem source_logs : FiniteSourceCells.LogProvider LocalCellsMillion.rows 285 :=
  FiniteScalarMillion.all_log_source

theorem complete_certificate : CompleteCertificate 38358837683 38359837684
    ((rawList LocalCellsMillion.rows LocalCellsMillion.rowCount).map (fun r=>r.toCell eLo eHi)) :=
  FiniteSourceCells.complete_certificate SegmentRamanujanMillion.p_provider
    SegmentRamanujanMillion.q_provider LocalCellsMillion.checked source_logs

theorem first_1000001_real_interval {x : ℝ}
    (lower : (38358837683:ℝ) ≤ x) (upper : x < 38359837684) : Holds x :=
  complete_certificate_sound complete_certificate x lower upper

theorem uniform_gap {x : ℝ}
    (lower : (38358837683:ℝ) ≤ x) (upper : x < 38359837684) :
    (501901:ℝ) < gap x :=
  CertificateMargin.checked_array_certificate complete_certificate LocalCellsMillion.checked
    SegmentSourceMargins.million_margins_checked x lower upper

#print axioms source_logs
#print axioms complete_certificate
#print axioms first_1000001_real_interval
#print axioms uniform_gap
end RamanujanPV.FiniteSourceRamanujanMillion
