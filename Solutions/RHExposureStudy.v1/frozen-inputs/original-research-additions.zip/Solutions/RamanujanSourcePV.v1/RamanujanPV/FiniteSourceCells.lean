/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. -/
import RamanujanPV.FiniteWideExpEnclosures
import RamanujanPV.FiniteLogExecution
import RamanujanPV.SegmentWindowCells

/-! Actual e/log source outputs supply the ORIGINAL finite-cell real
enclosures. Counts retain the actual segmented-checker provider. Concrete log
execution packages must be supplied by completed source runs, not a numerical
bound assumption; no mathematical gap/finite positivity is assumed here. -/
namespace RamanujanPV.FiniteSourceCells
open WindowCells SegmentWindowCells QuotientDemandCheck
set_option autoImplicit false

def LogProvider (rows : Lean.RArray RawFactoredCell) (count : Nat) : Prop :=
  ∀i,i<count→FiniteLogExecution.SourceExecution (rows.get i).n (rows.get i).Lu

theorem row_enclosures {pBase qBase pCount qCount pValue qValue : Nat}
    {pEntries qEntries : Lean.RArray PrimeWindow.Entry} {r : RawFactoredCell}
    (spec : RowSpec pBase qBase pCount qCount pValue qValue pEntries qEntries r)
    (sourceE : FiniteWideExpEnclosures.SourceEOutputs)
    (sourceLog : FiniteLogExecution.SourceExecution r.n r.Lu) :
    (r.toCell eLo eHi).Enclosures := by
  have sourceBounds := FiniteWideExpEnclosures.source_e_scaled sourceE
  have logUpper := FiniteLogExecution.source_log_upper_sound sourceLog
  have hlog : Real.log (r.n:ℝ)*(2:ℝ)^40 ≤ (r.Lu:ℝ) :=
    (le_div_iff₀ (by positivity : (0:ℝ) < (2:ℝ)^40)).mp logUpper
  obtain ⟨pn,step,pend,qn,qend,pval,qval,lu,je,ac,strict,lo,hi,logval,m2,mhi,j2,jhi⟩ := spec
  have hexp : Real.exp 1 ≤ (r.n:ℝ) := by
    have lower : (2:ℝ)^35 ≤ (r.n:ℝ) := by exact_mod_cast lo
    linarith [Real.exp_one_lt_d9]
  exact r.toCell_enclosures eLo eHi hexp sourceBounds.1 sourceBounds.2 hlog

/-- Source e/log enclosures replace the corresponding certificate fields.
Actual counts come only from p/q, and row arithmetic/coverage remain unchanged. -/
theorem complete_certificate {pBase qBase pCount qCount pValue qValue stop count : Nat}
    {pEntries qEntries : Lean.RArray PrimeWindow.Entry} {rows : Lean.RArray RawFactoredCell}
    (p : CountProvider pBase pCount pValue pEntries)
    (q : CountProvider qBase qCount qValue qEntries)
    (checked : checkRows pBase qBase pCount qCount pValue qValue stop count pEntries qEntries rows=true)
    (logs : LogProvider rows count) :
    CompleteCertificate pBase stop ((rawList rows count).map (fun r=>r.toCell eLo eHi)) := by
  have original := SegmentWindowCells.complete_certificate p q checked
  have parts : 0<count ∧ allFrom
      (checkRow pBase qBase pCount qCount pValue qValue stop count pEntries qEntries rows) 0 count=true := by
    simpa [checkRows] using checked
  refine ⟨original.1,?_⟩
  intro cell member
  have originalFields := original.2 cell member
  obtain ⟨r,hr,rfl⟩ := List.mem_map.mp member
  change r∈(List.range count).map rows.get at hr
  obtain ⟨i,hi,rfl⟩ := List.mem_map.mp hr
  have index := List.mem_range.mp hi
  have spec := (checkRow_clauses (allFrom_at count 0 parts.2 i (by omega) (by omega))).1
  exact ⟨originalFields.1,originalFields.2.1,
    row_enclosures spec FiniteWideExpEnclosures.actual_source_e_outputs (logs i index)⟩

theorem holds_window {pBase qBase pCount qCount pValue qValue stop count : Nat}
    {pEntries qEntries : Lean.RArray PrimeWindow.Entry} {rows : Lean.RArray RawFactoredCell}
    (p : CountProvider pBase pCount pValue pEntries)
    (q : CountProvider qBase qCount qValue qEntries)
    (checked : checkRows pBase qBase pCount qCount pValue qValue stop count pEntries qEntries rows=true)
    (logs : LogProvider rows count) :
    ∀x:ℝ,(pBase:ℝ)≤x→x<(stop:ℝ)→Holds x :=
  complete_certificate_sound (complete_certificate p q checked logs)

#print axioms row_enclosures
#print axioms complete_certificate
#print axioms holds_window
end RamanujanPV.FiniteSourceCells
