/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import RamanujanPV.QuotientDemandCheck
import RamanujanPV.QuotientCertificateCode
namespace RamanujanPV.QuotientPackedDemand
open QuotientDemandCheck
set_option autoImplicit false
set_option maxHeartbeats 0

theorem unpack_get (tree : Lean.RArray Nat) (i : Nat) :
    (unpack tree).get i=decode (tree.get i) := by
  induction tree with
  | leaf word=>rfl
  | branch pivot left right ihl ihr=>
    simp only [Lean.RArray.get_eq_getImpl,Lean.RArray.getImpl,unpack] at *
    split <;>simp_all

#print axioms unpack_get
end RamanujanPV.QuotientPackedDemand
