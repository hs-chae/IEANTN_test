import RamanujanPV.FiniteLogExecution
namespace RamanujanPV.FiniteLogSmoke
set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false

theorem checked0 : FiniteLogExecution.check 38358837683 (2^35) 35 26795374111319=true := by decide +kernel

theorem source0 : FiniteLogExecution.SourceExecution 38358837683 26795374111319 :=
  FiniteLogExecution.source_execution_of_checked checked0

theorem log0 : Real.log (38358837683:ℝ)≤(26795374111319:ℝ)/(2:ℝ)^40 :=
  FiniteLogExecution.source_log_upper_sound source0

#print axioms checked0
#print axioms source0
#print axioms log0
end RamanujanPV.FiniteLogSmoke
