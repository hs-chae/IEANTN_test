/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import RamanujanPV.SegmentTableAdapter
import RamanujanPV.LocalWindow1000B.Final

/-! Concrete execution-model results for the independently implemented actual
segmented C checker, using the accepted local P/Q classifications. These are
source-function contracts with exact outputs and arbitrary valid scratch-buffer
contents. Actual native caller allocation/input initialization and source/build/
run association must still be validated separately; they are not inferred from
these existential source executions. -/
namespace RamanujanPV.SegmentLocal1000
open QuotientCMachine SegmentMemory SegmentCheckerMath SegmentCFunctionPrefix
open SegmentTableAdapter
set_option autoImplicit false
set_option maxHeartbeats 2000000

theorem p_segment_count : segmentCount 38358837684 38358838683=32 := by
  have localCount := LocalWindow1000B.p_increment 999 (by decide)
  have lastValue : (LocalWindow1000B.pEntries.get 999).cumulative=32 := by rfl
  rw [lastValue] at localCount
  have increment := primeCounting_increment (lo:=38358837684) (hi:=38358838683)
    (by norm_num) (by norm_num)
  norm_num at localCount increment
  omega

theorem q_segment_count : segmentCount 14111427771 14111428139=17 := by
  have localCount := LocalWindow1000B.q_increment 368 (by decide)
  have lastValue : (LocalWindow1000B.qEntries.get 368).cumulative=17 := by rfl
  rw [lastValue] at localCount
  have increment := primeCounting_increment (lo:=14111427771) (hi:=14111428139)
    (by norm_num) (by norm_num)
  norm_num at localCount increment
  omega

/-- Exact source return33 means32 primes in the inclusive1000-integer window.
Every classification and the numerical count are discharged, not assumed. -/
theorem p_source_execution {call : Service} {heap : Heap} {capacity cb fb : Nat}
    (cap : 1000≤capacity) (apart : cb≠fb) (owned : Owned heap)
    (scratch : SegmentCInit.Buffer heap fb 1000)
    (claims : FlagsRep heap cb 1000 (flags LocalWindow1000B.pEntries)) :
    ∃t, Run call SegmentCheckerSource.checkerFunction.body
        (input 38358837684 38358838683 capacity cb fb heap) (.returned t (.u64 33)) ∧
      t.env=(input 38358837684 38358838683 capacity cb fb heap).env ∧ Owned t.heap := by
  exact source_execution_from_checked_table (base:=38358837683) (count:=1000)
    (LocalPrimeTree.bounded_prime_provider LocalWindow1000B.primes_good LocalWindow1000B.primeCount)
    LocalWindow1000B.p_checked (by norm_num) (by norm_num) (by norm_num) cap apart owned scratch
    claims (input_env _ _ _ _ _ _) p_segment_count

/-- Exact source return18 means17 primes in the inclusive369-integer window. -/
theorem q_source_execution {call : Service} {heap : Heap} {capacity cb fb : Nat}
    (cap : 369≤capacity) (apart : cb≠fb) (owned : Owned heap)
    (scratch : SegmentCInit.Buffer heap fb 369)
    (claims : FlagsRep heap cb 369 (flags LocalWindow1000B.qEntries)) :
    ∃t, Run call SegmentCheckerSource.checkerFunction.body
        (input 14111427771 14111428139 capacity cb fb heap) (.returned t (.u64 18)) ∧
      t.env=(input 14111427771 14111428139 capacity cb fb heap).env ∧ Owned t.heap := by
  exact source_execution_from_checked_table (base:=14111427770) (count:=369)
    (LocalPrimeTree.bounded_prime_provider LocalWindow1000B.primes_good LocalWindow1000B.primeCount)
    LocalWindow1000B.q_checked (by norm_num) (by norm_num) (by norm_num) cap apart owned scratch
    claims (input_env _ _ _ _ _ _) q_segment_count

#print axioms p_segment_count
#print axioms q_segment_count
#print axioms p_source_execution
#print axioms q_source_execution
end RamanujanPV.SegmentLocal1000
