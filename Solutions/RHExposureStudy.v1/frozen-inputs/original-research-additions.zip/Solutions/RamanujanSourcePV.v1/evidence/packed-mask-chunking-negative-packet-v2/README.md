# Negative OR-fold chunking study

This is a bounded negative kernel-proof scheduling experiment, not source-first
PV of a new C program and not a stronger number-theoretic theorem. The fixed
production target is the original one-million-bit mask at 38,358,837,684, with
the same global base and global divisor indexing. K=1 is a range/cached-base
calibration; K=2,8,16 split that same fold. No complete production mask identity
was accepted. Fourteen partial statements/data modules passed, four attempts
were intentionally time-censored (two have final receipts and two lack final
RAM/receipt evidence), and eighteen of the 36 proposed modules were unexecuted.
Partial successes are not a composed result. No useful improvement was established.

SOURCE_VERSION_RECOVERY.json records exact SHA-matched historical generator and
runner bytes. The initial mistaken runner-v1 recovery status is preserved under
history/; the recovered .py matches its recorded e04fa... hash. The adjacent
reconstruction-not-accepted.txt remains historical and is not the executed source.
existing_runs/ preserves original commands, proposals, available source/log/RUN/
rusage/control/censor records. Incomplete/proposed Lean files use .lean.txt.
generic_composition/ preserves the separately completed generic composition proof.
No original source, outcome, receipt or proof object was edited or deleted.

Large literal sources and object files are omitted from this compact download;
their exact hashes are listed. Original accepted artifacts remain in the study
storage. Regenerate a particular proposal using the historical generator version
identified by its PROPOSAL.json generator_sha256, for example:

    python3 source_versions/0c36ead26058f7db299c97691249dc1f67b47b083f61ed728d832297494cac66/generate_packed_mask_chunks.py --baseline-source baseline/PackedSievePrimitiveMaskMillion.lean --out /fresh/owned/chunk-proposal

For controls add --control. Compare every generated module source hash with the
packaged corresponding historical PROPOSAL.json; filesystem output paths may
differ, but the generated Lean bytes must match. No Lean numerical experiment
is rerun by packaging or source regeneration. Baseline/generic/helper/dependency
pins and exact available execution receipts are included. Missing final RAM is
reported unavailable rather than estimated. Raw kernel computations alone are
never called PV. This packet does not modify the accepted packed-million result.

All three recovered generator versions were actually executed for SOURCE-only regeneration:33,36,36 module hashes matched their respective historical proposals. The packaged reproduce_sources.py also passed its actual -OO CLI. No Lean numerical experiment was rerun. Use python3 reproduce_sources.py --out /fresh/owned/path for the complete source-only regeneration check.
