#!/usr/bin/env python3
"""Reproduce historical proposal SOURCE bytes only; this is not a Lean run."""
from pathlib import Path
import argparse, hashlib, json, math, subprocess, sys
P=Path(__file__).resolve().parent
def need(value,message):
 if not value: raise ValueError(message)
def read(path):
 def pairs(items):
  result={}
  for key,value in items:
   need(key not in result,"duplicate JSON key");result[key]=value
  return result
 def finite(text):
  value=float(text);need(math.isfinite(value),"finite JSON number");return value
 return json.loads(path.read_text(),object_pairs_hook=pairs,parse_float=finite,
  parse_constant=lambda value:(_ for _ in()).throw(ValueError("nonfinite JSON")))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
parser=argparse.ArgumentParser(allow_abbrev=False);parser.add_argument("--out",type=Path,required=True);a=parser.parse_args()
out=a.out.resolve();need(not out.exists(),"fresh source-regeneration directory");out.mkdir(parents=True)
versions=read(P/"SOURCE_VERSION_RECOVERY.json");rows=[]
for label,study in [("generator_v1","attempt-v1"),("generator_v2","attempt-v2"),("generator_v3","production-v3")]:
 row=next(x for x in versions if x["label"]==label);script=P/row["path"]
 need(sha(script)==row["sha256"],"exact historical generator")
 command=[sys.executable]+(["-OO"]if sys.flags.optimize>=2 else["-O"]if sys.flags.optimize else[])+[str(script),"--baseline-source",str(P/"baseline/PackedSievePrimitiveMaskMillion.lean"),"--out",str(out/label)]
 run=subprocess.run(command,capture_output=True,text=True);need(run.returncode==0,"actual source generation")
 actual=read(out/label/"PROPOSAL.json");expected=read(P/"existing_runs"/study/"PROPOSAL.json")
 amap={x["module"]:x["sha256"]for x in actual["records"]};emap={x["module"]:x["sha256"]for x in expected["records"]}
 need(len(amap)==len(actual["records"]) and amap==emap,"all exact historical Lean source bytes")
 rows.append(dict(version=label,modules=len(amap),command=command))
(out/"SOURCE_REGENERATION_RESULT.json").write_text(json.dumps(dict(status="EXACT_SOURCE_BYTES_ONLY_NO_LEAN_ACCEPTANCE",rows=rows),indent=2)+"\n")
print("EXACT_SOURCE_BYTES_ONLY_NO_LEAN_ACCEPTANCE")

