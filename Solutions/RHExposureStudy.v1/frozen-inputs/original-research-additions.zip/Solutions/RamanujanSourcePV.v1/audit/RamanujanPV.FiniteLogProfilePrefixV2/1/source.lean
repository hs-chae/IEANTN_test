import RamanujanPV.FiniteScalarEval
import RamanujanPV.FiniteLogServices
namespace RamanujanPV.FiniteLogProfilePrefixV2
open FiniteScalarMachine
set_option autoImplicit false
set_option maxHeartbeats 0
set_option Elab.async false

/-- The20-term callee's actual converted parameter environment. -/
def seriesInput (args : List Value) : State := match args with
  | [a,b]=>⟨fun name=>if name="num" then some a else if name="den" then some b else none⟩
  | _=>empty

/-- No series output oracle: this response is computed by executing the
complete source-bound20-term AST with the source-proved ceil helper. -/
def service : Service := fun name args=>
  if name="rpc_log_series_upper" then match args with
    | [a,b]=>if a.type=u64 ∧b.type=u64 then
        FiniteScalarEval.returnedValue FiniteLogCeil.prototypes FiniteLogServices.ceilService 128
          FiniteLogSource.seriesFunction.body (seriesInput args)
      else none
    | _=>none
  else FiniteLogServices.ceilService name args

attribute [irreducible] service

def CalleeExecution (name : String) (args : List Value) (answer : Value) : Prop :=
  (name="rpc_log_ceildiv" ∧∃t,Run FiniteLogCeil.prototypes FiniteLogCeil.noCalls
    FiniteLogSource.ceilFunction.body (FiniteLogServices.sourceInput args) (.returned t answer)) ∨
  (name="rpc_log_series_upper" ∧∃t,Run FiniteLogCeil.prototypes FiniteLogServices.ceilService
    FiniteLogSource.seriesFunction.body (seriesInput args) (.returned t answer))

theorem service_closed {name : String} {args : List Value} {answer : Value}
    (response:service name args=some answer) : CalleeExecution name args answer := by
  unfold service at response
  by_cases nameIsSeries:name="rpc_log_series_upper"
  · subst name
    right
    refine ⟨rfl,?_⟩
    cases args with
    | nil=>simp [service] at response
    | cons a rest=>
      cases rest with
      | nil=>simp [service] at response
      | cons b tail=>
        cases tail with
        | cons c tail=>simp [service] at response
        | nil=>
          simp only [↓reduceIte] at response
          split at response
          next h=>
            exact FiniteScalarEval.returned_value_sound
              (p:=FiniteLogCeil.prototypes) (c:=FiniteLogServices.ceilService) (fuel:=128)
              (body:=FiniteLogSource.seriesFunction.body) (s:=seriesInput [a,b]) response
          next h=>contradiction
  · left
    exact FiniteLogServices.ceil_service_closed (by simpa only [nameIsSeries,↓reduceIte] using response)

def input (n : Nat) : State :=⟨fun name=>if name="n" then some (word64 n) else none⟩

/-- A verified instance is a complete source reference execution on an input,
with the original normalized mathematical value as its returned word. This
object must be constructed by kernel execution, never assumed from native C. -/
def VerifiedInput (n : Nat) : Prop := ∃two k : Nat,
  2≤n ∧n≤2000000000000 ∧two=2^k ∧two≤n ∧n<2*two ∧
  ∃t,Run FiniteLogCeil.prototypes service FiniteLogSource.upperFunction.body
    (input n) (.returned t (word64 (AnalyticTransition.binaryLogUpper n two k)))

/-- Both the actual source run and the independently kernel-verified reference
are retained. Correctness below compares arbitrary completed source outputs. -/
structure SourceExecution (n output : Nat) : Prop where
  verified : VerifiedInput n
  actual : ∃t,Run FiniteLogCeil.prototypes service FiniteLogSource.upperFunction.body
    (input n) (.returned t (word64 output))
  source : LCMSourcePV.RestrictedC.SourceCorresponds FiniteLogSource.render
    FiniteLogSource.actualSource ()
  helpers : ∀name args answer,service name args=some answer → CalleeExecution name args answer
  leafHelpers : ∀name args answer,FiniteLogServices.ceilService name args=some answer →
    name="rpc_log_ceildiv" ∧∃t,Run FiniteLogCeil.prototypes FiniteLogCeil.noCalls
      FiniteLogSource.ceilFunction.body (FiniteLogServices.sourceInput args) (.returned t answer)


#print axioms service_closed
end RamanujanPV.FiniteLogProfilePrefixV2
