/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import RamanujanPV.QuotientDemandCheck
namespace RamanujanPV.QuotientPackedDemand
open QuotientDemandCheck
set_option autoImplicit false
set_option maxHeartbeats 0

/-- Certificate coding only. Every decoded record is still checked by the
proved arithmetic/dependency validator; no numeric field is assumed correct. -/
def field (word offset width : Nat) : Nat := (word >>> offset) % (2^width)

/-- Widths: kind2,p22,v42,value42, four references32 each, four gap indexes22
 each. Total324bits. The source program's actual arithmetic remains uint64. -/
def decode (word : Nat) : Entry :=
  ⟨field word 0 2,field word 2 22,field word 24 42,field word 66 42,
    field word 108 32,field word 140 32,field word 172 32,field word 204 32,
    field word 236 22,field word 258 22,field word 280 22,field word 302 22⟩

/-- Lazy structural decoding preserves balanced kernel lookup. It does not
construct an immutable Array/List and introduces no execution trust premise. -/
def unpack : Lean.RArray Nat→Lean.RArray Entry
  | .leaf word=>.leaf (decode word)
  | .branch pivot left right=>.branch pivot (unpack left) (unpack right)

theorem unpack_get (tree : Lean.RArray Nat) (i : Nat) :
    (unpack tree).get i=decode (tree.get i) := by
  induction tree with
  | leaf word=>rfl
  | branch pivot left right ihl ihr=>
    simp only [Lean.RArray.get_eq_getImpl,Lean.RArray.getImpl,unpack] at *
    split <;>simp_all

#print axioms unpack_get
end RamanujanPV.QuotientPackedDemand
