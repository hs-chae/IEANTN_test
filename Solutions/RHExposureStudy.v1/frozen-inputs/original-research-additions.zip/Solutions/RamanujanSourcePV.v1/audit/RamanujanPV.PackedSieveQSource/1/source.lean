/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. -/
import RamanujanPV.PackedSieveInstances
import RamanujanPV.PackedSievePrimitiveQWindow
namespace RamanujanPV.PackedSieveQSource
open QuotientCCell PackedSieveKernel PackedSieveByteCount
set_option autoImplicit false
set_option maxHeartbeats 0

theorem source_endpoint : SourceExecution 14111795650 632223009 := by
  have result := PackedSieveInstances.source_endpoint (lo:=14111427771) (count:=367880)
    CriticalSourceClosed.q_source (by decide) (by decide) (by decide) (by decide)
  rw [show 14111427771+367880-1=14111795650 by decide,
    show (367880+7)/8=45985 by decide, PackedSievePrimitiveQWindow.raw_byte_result] at result
  exact result

theorem pi_endpoint : Nat.primeCounting 14111795650=632223009 :=
  source_execution_count source_endpoint

theorem ieantn_pi_endpoint : IEANTN.primeCounting (14111795650 : ℝ)=632223009 := by
  rw [Intervals.primeCounting_nat,pi_endpoint]
  norm_num
#print axioms source_endpoint
#print axioms pi_endpoint
#print axioms ieantn_pi_endpoint
end RamanujanPV.PackedSieveQSource
