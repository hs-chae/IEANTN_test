"""Resource-expanded supplemental runs using the existing user-systemd boundary.

Original experimental scopes/results remain immutable. This launcher reserves
aggregate resources before starting a new scope and monitors host headroom.
"""
from pathlib import Path
import argparse
import datetime
import errno
import fcntl
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import time
import uuid
import tempfile

ROOT = Path(__file__).resolve().parents[1]
GiB = 1024 ** 3


def need(ok, message):
    if not ok:
        raise ValueError(message)


def decode(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def atomic(path, data):
    # Mutable live receipts and registry: replace only an exclusively created temp.
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp', dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(fd, 'w') as handle:
            handle.write(json.dumps(data, indent=2, allow_nan=False) + '\n')
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def available():
    info = {line.split(':')[0]: int(line.split()[1]) * 1024
            for line in Path('/proc/meminfo').read_text().splitlines()}
    result = info['MemAvailable']
    group = Path('/sys/fs/cgroup') / Path('/proc/self/cgroup').read_text().strip().split('::')[1].lstrip('/')
    while group.is_relative_to('/sys/fs/cgroup'):
        try:
            maximum = (group / 'memory.max').read_text().strip()
            if maximum != 'max':
                result = min(result, max(0, int(maximum) - int((group / 'memory.current').read_text())))
        except FileNotFoundError:
            pass
        if group == Path('/sys/fs/cgroup'):
            break
        group = group.parent
    return result


def written_bytes():
    # One lstat per observed entry avoids the former is_file -> stat race.
    # Directory descriptors keep traversal inside the opened tree without
    # following a directory replaced by a symlink. Only vanished child entries
    # (ENOENT) are skipped; permission, I/O and all other errors fail closed.
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW

    def count_directory(directory_fd):
        total = 0
        with os.scandir(directory_fd) as entries:
            for entry in entries:
                try:
                    info = os.lstat(entry.name, dir_fd=directory_fd)
                except OSError as error:
                    if error.errno == errno.ENOENT:
                        continue
                    raise
                if stat.S_ISREG(info.st_mode):
                    total += info.st_size
                elif stat.S_ISDIR(info.st_mode):
                    try:
                        child_fd = os.open(entry.name, flags, dir_fd=directory_fd)
                    except OSError as error:
                        if error.errno == errno.ENOENT:
                            continue
                        raise
                    try:
                        total += count_directory(child_fd)
                    finally:
                        os.close(child_fd)
        return total

    root_fd = os.open(ROOT, flags)
    try:
        return count_directory(root_fd)
    finally:
        os.close(root_fd)


def systemctl(*args):
    return subprocess.run(['systemctl', '--user', *args], capture_output=True, text=True, timeout=10)


def reserve(a, policy):
    registry = ROOT / 'evidence/ACTIVE_RUNS.json'
    with (ROOT / 'evidence/RESOURCE_LOCK').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        entries = decode(registry) if registry.exists() else []
        alive = []
        for row in entries:
            if Path('/proc/' + str(row['launcher_pid'])).exists():
                alive.append(row)
        need(sum(r['memory_bytes'] for r in alive) + a.memory_gib * GiB <=
             policy['aggregate_active_memory_budget_bytes'], 'aggregate memory reservation exceeded')
        need(sum(r['cpus'] for r in alive) + a.cpus <= policy['global_CPU_budget'],
             'aggregate CPU reservation exceeded')
        need(not a.heavy or sum(r['heavy'] for r in alive) < policy['max_heavy_concurrency'],
             'heavy job concurrency exceeded; retry after an active job completes')
        need(available() >= policy['minimum_host_available_RAM_bytes'] + a.memory_gib * GiB +
             sum(r['memory_bytes'] for r in alive),
             'insufficient actual host RAM headroom for requested reservation')
        need(shutil.disk_usage(ROOT).free >= policy['minimum_free_disk_bytes'] +
             policy['scratch_total_budget_bytes'], 'insufficient actual disk headroom')
        need(written_bytes() < policy['scratch_total_budget_bytes'], 'scratch allowance exhausted')
        used_cpus = set()
        for existing in alive:
            affinity = existing.get('CPU_affinity')
            if affinity is None:
                running = Path(existing['out']) / 'RUNNING.json'
                affinity = decode(running).get('CPU_affinity', []) if running.exists() else []
            used_cpus.update(affinity)
        preferred = list(range(64, 128)) + list(range(56, 64))
        pool = preferred + sorted(set(os.sched_getaffinity(0)) - set(preferred))
        chosen = [cpu for cpu in pool if cpu in os.sched_getaffinity(0) and cpu not in used_cpus][:a.cpus]
        need(len(chosen) == a.cpus, 'no disjoint CPU block available')
        a.selected_cpus = chosen
        row = dict(launcher_pid=os.getpid(), memory_bytes=a.memory_gib * GiB,
                   cpus=a.cpus, CPU_affinity=chosen, heavy=a.heavy, family=a.family, out=str(a.out))
        alive.append(row)
        atomic(registry, alive)


def launch(a):
    policy_path = ROOT / 'RESOURCE_POLICY.json'
    policy = decode(policy_path)
    need(a.family in ['T01', 'T02', 'T04', 'root_generic'], 'unknown family')
    need(1 <= a.memory_gib <= 300 and a.memory_gib * GiB <=
         policy['per_run_memory_max_bytes'], 'per-run memory allowance exceeded')
    need(1 <= a.cpus <= 32 and 1 <= a.wall <= 86400, 'invalid CPU/wall request')
    need(a.command, 'command required')
    a.out = Path(a.out).absolute()
    need(a.out.is_relative_to(ROOT) and a.out.resolve() == a.out and not a.out.exists(),
         'new output under supplemental workspace required')
    reserve(a, policy)
    a.out.mkdir(parents=True)
    unit = 'ieantn-r2-recovery-' + uuid.uuid4().hex[:12] + '.scope'
    chosen_cpus = a.selected_cpus
    need(len(chosen_cpus) == a.cpus and set(chosen_cpus).issubset(os.sched_getaffinity(0)),
         'requested CPU affinity unavailable')
    command = ['systemd-run', '--user', '--scope', '--quiet', '--collect', '--unit=' + unit,
               '-p', 'MemoryMax=' + str(a.memory_gib * GiB), '-p', 'MemorySwapMax=0',
               '-p', 'TasksMax=1024', '-p', 'CPUQuota=' + str(a.cpus * 100) + '%',
               '-p', 'RuntimeMaxSec=' + str(a.wall), '-p', 'KillSignal=SIGKILL',
               'taskset', '-c', ','.join(map(str, chosen_cpus)), *a.command]
    record = dict(schema=1, phase=policy['label'], utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  unit=unit, command=command, policy_sha256=hashlib.sha256(policy_path.read_bytes()).hexdigest(),
                  launcher_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  requested_memory_bytes=a.memory_gib * GiB, cpus=a.cpus,
                  wall_seconds=a.wall, CPU_affinity=chosen_cpus,
                  inherited_rlimit_as='UNCHANGED_UNLIMITED', samples=[])
    start = time.monotonic()
    group = None
    last_disk = -60.0
    disk_bytes = 0
    stopped = False
    with (a.out / 'stdout.txt').open('xb') as stdout, (a.out / 'stderr.txt').open('xb') as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr)
        atomic(a.out / 'RUNNING.json', dict(record, launcher_pid=os.getpid(), systemd_run_pid=process.pid))
        try:
            while process.poll() is None:
                elapsed = time.monotonic() - start
                if group is None:
                    shown = systemctl('show', unit, '--property=ControlGroup', '--value')
                    if shown.stdout.strip():
                        group = Path('/sys/fs/cgroup') / shown.stdout.strip().lstrip('/')
                        record['cgroup'] = str(group)
                        record['actual_limits'] = {k: (group / k).read_text().strip() if (group / k).exists() else None
                                                   for k in ['memory.max', 'memory.swap.max', 'pids.max', 'cpu.max']}
                sample = dict(seconds=round(elapsed, 3), host_available_RAM_bytes=available(),
                              free_disk_bytes=shutil.disk_usage(ROOT).free)
                if elapsed - last_disk >= 30:
                    disk_bytes, last_disk = written_bytes(), elapsed
                sample['supplemental_workspace_written_bytes'] = disk_bytes
                if group is not None:
                    for name in ['cpu.stat', 'memory.current', 'memory.peak', 'memory.events', 'pids.current']:
                        try:
                            sample[name] = (group / name).read_text().strip()
                        except FileNotFoundError:
                            pass
                record['samples'].append(sample)
                reason = None
                if sample['host_available_RAM_bytes'] < policy['minimum_host_available_RAM_bytes']:
                    reason = 'HOST_RAM_RESERVE'
                if sample['free_disk_bytes'] < policy['minimum_free_disk_bytes']:
                    reason = 'HOST_DISK_RESERVE'
                if disk_bytes > policy['scratch_total_budget_bytes']:
                    reason = 'SCRATCH_BUDGET'
                if elapsed > a.wall + 3:
                    reason = 'OUTER_WALL_FAILSAFE'
                if reason and not stopped:
                    record['stop_reason'], stopped = reason, True
                    systemctl('kill', '--signal=SIGKILL', '--kill-who=all', unit)
                atomic(a.out / 'LIVE.json', dict(record, launcher_pid=os.getpid()))
                time.sleep(2)
        except BaseException:
            systemctl('kill', '--signal=SIGKILL', '--kill-who=all', unit)
            raise
        finally:
            record.update(exit_code=process.wait(), elapsed_seconds=time.monotonic() - start)
            atomic(a.out / 'scope.json', record)
    print(json.dumps({k: record.get(k) for k in ['unit', 'exit_code', 'elapsed_seconds', 'stop_reason', 'actual_limits']}))
    return 0 if record['exit_code'] == 0 and not record.get('stop_reason') else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--family', required=True)
    parser.add_argument('--memory-gib', type=int, default=192)
    parser.add_argument('--cpus', type=int, default=8)
    parser.add_argument('--wall', type=int, default=14400)
    parser.add_argument('--heavy', action='store_true')
    parser.add_argument('--out', required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    a = parser.parse_args()
    if a.command and a.command[0] == '--':
        a.command = a.command[1:]
    try:
        return launch(a)
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print(json.dumps(dict(status='RESOURCE_RUN_REJECTED', reason=str(error))), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
