# Prime-cover source-first component

This capsule rebuilds 158 application Lean modules from source, proves six actual C constructors and fixed mains, compiles and runs those six C mains, and checks every result word against kernel-bound data. It also compiles the five unchanged provider APIs and six original sigma/lcm analytic-tail consumers. The parent project separately handles finite Adaptive/404 branches.

The C program searches for primes; it contains no output or certificate table. Pratt and divisor certificates shorten its ordinary-kernel execution proofs. No new axiom, sorry, or native-execution axiom is used.

## Reproduce

Prepare the pinned generic Lean/Mathlib dependencies listed in ENVIRONMENT.json. The application capsule needs no old application objects. For relocated installations, supply an environment JSON with the same dependency names/revisions and compiler binary hashes but your paths. The compiler is Lean 4.34.0-rc2; Mathlib is pinned at 71a80585ee495fc24472fd0eaffc89d94e4fd8d6.

Run these commands from this directory, using fresh sibling output directories:

    python3 reproduce.py --environment /path/to/environment.json --out ../replay --jobs 4
    python3 audit_replay.py --replay ../replay --out ../final-audit

Final acceptance is ../final-audit/RECEIPT.json with FINAL_STRICT_ACCEPTANCE_PASS. The producer receipt is an intermediate result. The tested source-cold run took 476.47 seconds with eight CPU-affinity cores, four compiler jobs and a 96 GiB memory limit. Maximum individual child OS RSS was about 23.22 GiB; sampled cgroup charges and child RSS are different measurements. No exact cgroup memory peak is claimed.

Validators were checked in normal, -O and -OO modes; no acceptance uses assert. The strict auditor parses multiline axiom reports, checks every source/object/log identity, all six C outputs and all six LCM consumers.

## Trust and mathematical scope

Kernel proofs bind actual source tokens to structured ASTs and execute real expressions, loops, calls, array stores, initialization and returns. Each fixed main starts with its actual static zero array and literal inputs. The modeled successful CStdIO branches are associated with actual return0/output readback; physical compiler/runtime/ABI/standard I/O remain the explicitly approved external boundary. This is not a Lean proof of Linux file bytes or a promise I/O always succeeds.

All LCM conclusions retain the same explicit Dusart 2018 Proposition 5.4 literature input: for every real x at least 89693, a prime p exists with x<p<=x+x/(log x)^3. The component does not newly prove or independently re-audit that paper input. All six original parameters, source algorithms, numeric arrays, mathematical domains and coefficients are retained. No optimality or program-necessity claim is made.

SOURCE_LOCK.json covers every application proof/C source and data fixture. FINAL_PROVIDER_INDEX_V4.json in the parent evidence directory gives exact case/source/claim/receipt identities. Do not place output/cache directories inside this source capsule.
