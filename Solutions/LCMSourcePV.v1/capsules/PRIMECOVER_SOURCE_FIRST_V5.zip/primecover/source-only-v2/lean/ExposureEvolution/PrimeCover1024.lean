import E1Tertiary.LcmTail
import LCMSourcePV.PrimeCover.DriverVerified
namespace ExposureEvolution.PrimeCover1024
open Real
set_option maxRecDepth 20000
set_option maxHeartbeats 0

def StrictGap (X : ℝ) : Prop :=
  ∀ x ≥ X, ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 1024

def next (a : ℕ) : Option ℕ :=
  (List.range ((1025 * a - 1) / 1024 - a)).reverse.findSome? fun k =>
    let p := a + 1 + k
    if Nat.Prime p then some p else none

def run : ℕ → ℕ → ℕ → List ℕ
  | 0, _, _ => []
  | fuel + 1, a, b =>
      if b ≤ a then [] else
        match next a with
        | none => []
        | some p => p :: run fuel p b

def check (a b : ℕ) : List ℕ → Bool
  | [] => decide (b ≤ a)
  | p :: ps => decide (Nat.Prime p ∧ a < p ∧ 1024 * p < 1025 * a) && check p b ps

theorem sound (ps : List ℕ) {a b : ℕ} (hc : check a b ps = true)
    {x : ℝ} (ha : (a : ℝ) ≤ x) (hb : x < b) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 1024 := by
  induction ps generalizing a with
  | nil =>
      have hba : b ≤ a := by simpa only [check, decide_eq_true_eq] using hc
      have hba' : (b : ℝ) ≤ a := by exact_mod_cast hba
      linarith
  | cons p ps ih =>
      have hh : (Nat.Prime p ∧ a < p ∧ 1024 * p < 1025 * a) ∧ check p b ps = true := by
        simpa only [check, Bool.and_eq_true, decide_eq_true_eq] using hc
      by_cases hp : x < (p : ℝ)
      · refine ⟨p, hh.1.1, hp, ?_⟩
        have hr : (1024 : ℝ) * p < 1025 * a := by exact_mod_cast hh.1.2.2
        linarith
      · exact ih hh.2 (le_of_not_gt hp)


-- Exact source-first provider adapters. All original definitions are unchanged.
-- The numerical facts below come from closed execution of the actual C source.
private theorem next_source_eq (a : ℕ) : next a = LCMSourcePV.PrimeCover.Math.next 1024 a := by
  symm
  exact LCMSourcePV.PrimeCover.Math.search_eq_original a _

private theorem run_source_eq (fuel a b : ℕ) :
    run fuel a b = LCMSourcePV.PrimeCover.Math.run 1024 fuel a b := by
  induction fuel generalizing a with
  | zero => rfl
  | succ fuel ih =>
    simp only [run,LCMSourcePV.PrimeCover.Math.run,next_source_eq]
    split
    · rfl
    · cases LCMSourcePV.PrimeCover.Math.next 1024 a with
      | none => rfl
      | some p => exact congrArg (List.cons p) (ih p)

private theorem check_source_eq (a b : ℕ) (ps : List ℕ) :
    check a b ps = LCMSourcePV.PrimeCover.Math.check 1024 a b ps := by
  induction ps generalizing a with
  | nil => rfl
  | cons p ps ih => simp only [check,LCMSourcePV.PrimeCover.Math.check,ih]

def output : List ℕ := [
  58889, 58943, 58997, 59053, 59107, 59159, 59209, 59263, 59281, 59333, 59387, 59443,
  59497, 59539, 59581, 59629, 59671, 59729, 59779, 59833, 59887, 59929, 59981, 60037,
  60091, 60149, 60169, 60223, 60271, 60317, 60373, 60427, 60457, 60509, 60539, 60589,
  60647, 60703, 60761, 60811, 60869, 60923, 60961, 61007, 61057, 61099, 61153, 61211,
  61261, 61297, 61343, 61381, 61417, 61471, 61519, 61561, 61613, 61673, 61729, 61781,
  61837, 61879, 61933, 61991, 62047, 62099, 62143, 62201, 62233, 62273, 62327, 62383,
  62423, 62483, 62539, 62597, 62653, 62701, 62761, 62819, 62873, 62929, 62989, 63031,
  63079, 63131, 63179, 63211, 63247, 63299, 63353, 63409, 63467, 63527, 63589, 63649,
  63709, 63761, 63823, 63863, 63913, 63949, 64007, 64067, 64123, 64171, 64231, 64283,
  64333, 64381, 64439, 64499, 64553, 64613, 64667, 64717, 64763, 64817, 64879, 64937,
  64997, 65053, 65111, 65173, 65213, 65269, 65327, 65381, 65437, 65497, 65557, 65617,
  65677, 65731, 65789, 65851, 65899, 65963, 65993, 66047, 66109, 66173, 66221, 66271,
  66301, 66361, 66413, 66467, 66529, 66593, 66653, 66713, 66763, 66821, 66883, 66947,
  67003, 67061, 67121, 67181, 67231, 67289, 67349, 67411, 67453, 67511, 67567, 67631,
  67679, 67741, 67807, 67867, 67933, 67993, 68059, 68113, 68171, 68227, 68281, 68329,
  68389, 68449, 68507, 68567, 68633, 68699, 68749, 68813, 68879, 68927, 68993, 69031,
  69073, 69127, 69193, 69259, 69317, 69383, 69439, 69499, 69557, 69623, 69677, 69739,
  69779, 69847, 69911, 69959, 70019, 70079, 70141, 70207, 70271, 70327, 70393, 70459,
  70507, 70573, 70639, 70687, 70753, 70793, 70853, 70921, 70981, 71039, 71089, 71153,
  71209, 71263, 71329, 71389, 71453, 71503, 71569, 71633, 71699, 71761, 71821, 71887,
  71947, 71999, 72053, 72109, 72173, 72229, 72287, 72353, 72421, 72481, 72551, 72617,
  72679, 72739, 72797, 72859, 72923, 72977, 73043, 73091, 73141, 73189, 73259, 73327,
  73387, 73453, 73523, 73589, 73651, 73721, 73783, 73849, 73907, 73973, 74027, 74099,
  74167, 74231, 74297, 74363, 74419, 74489, 74561, 74623, 74687, 74759, 74831, 74903,
  74959, 75029, 75083, 75149, 75217, 75289, 75353, 75407, 75479, 75541, 75611, 75683,
  75743, 75797, 75869, 75941, 76003, 76039, 76103, 76163, 76231, 76303, 76369, 76441,
  76511, 76579, 76651, 76717, 76781, 76847, 76919, 76991, 77047, 77101, 77171, 77243,
  77317, 77383, 77447, 77521, 77591, 77659, 77731, 77801, 77867, 77933, 78007, 78079,
  78139, 78203, 78277, 78347, 78401, 78467, 78541, 78607, 78653, 78721, 78797, 78857,
  78929, 78989, 79063, 79139, 79201, 79273, 79349, 79423, 79493, 79561, 79633, 79699,
  79769, 79843, 79907, 79979, 80051, 80111, 80177, 80251, 80329, 80407, 80473, 80537,
  80611, 80687, 80761, 80833, 80911, 80989, 81049, 81119, 81197, 81239, 81307, 81373,
  81439, 81517, 81569, 81647, 81707, 81773, 81847, 81919, 81973, 82051, 82129, 82207,
  82279, 82351, 82421, 82499, 82571, 82651, 82729, 82799, 82847, 82913, 82981, 83059,
  83137, 83207, 83273, 83341, 83417, 83497, 83563, 83641, 83719, 83791, 83869, 83939,
  84017, 84089, 84163, 84239, 84319, 84401, 84481, 84559, 84631, 84713, 84793, 84871,
  84947, 85027, 85109, 85159, 85237, 85313, 85381, 85453, 85531, 85607, 85669, 85751,
  85831, 85909, 85991, 86069, 86143, 86209, 86293, 86371, 86453, 86533, 86599, 86677,
  86753, 86837, 86869, 86951, 87013, 87083, 87151, 87223, 87299, 87383, 87443, 87523,
  87589, 87671, 87751, 87833, 87917, 88001, 88079, 88129, 88211, 88289, 88339, 88423,
  88499, 88547, 88609, 88681, 88747, 88819, 88903, 88969, 89051, 89137, 89213, 89293,
  89371, 89449, 89533, 89611, 89689, 89767
]

theorem executed : run 700 58832 89693 = output ∧
    check 58832 89693 output = true ∧ output.length = 498 := by
  have output_eq : output = LCMSourcePV.PrimeCover.DriverVerified58832D1024.output := by
    rw [LCMSourcePV.PrimeCover.DriverVerified58832D1024.output_eq]
    decide +kernel
  rw [run_source_eq,output_eq,check_source_eq]
  exact ⟨LCMSourcePV.PrimeCover.DriverVerified58832D1024.run_eq,LCMSourcePV.PrimeCover.DriverVerified58832D1024.check_true,LCMSourcePV.PrimeCover.DriverVerified58832D1024.output_length⟩

theorem covered {x : ℝ} (ha : (58832 : ℝ) ≤ x) (hb : x < 89693) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 1024 :=
  sound output executed.2.1 ha hb

theorem full_gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 58832 := by
  intro x hx
  by_cases ht : x < 89693
  · exact covered hx ht
  · have hlarge : (89693 : ℝ) ≤ x := le_of_not_gt ht
    have hx0 : 0 < x := by linarith
    have he : exp (11 : ℝ) < 89693 := by
      have h1 : exp 1 < (11 / 4 : ℝ) := by linarith [Real.exp_one_lt_d9]
      calc exp (11 : ℝ) = (exp 1) ^ 11 := by rw [Real.exp_one_pow]; norm_num
        _ ≤ (11 / 4 : ℝ) ^ 11 := pow_le_pow_left₀ (exp_pos 1).le h1.le 11
        _ < 89693 := by norm_num
    have hl : 11 < log x := by
      have hh := log_lt_log (exp_pos (11 : ℝ)) (he.trans_le hlarge)
      simpa only [log_exp] using hh
    have hlp : 0 < log x := by linarith
    have hc : (1024 : ℝ) < log x ^ 3 := by
      nlinarith [mul_pos (by linarith : 0 < log x - 11) (sq_pos_of_pos hlp)]
    obtain ⟨p, hp, hpx, hpu⟩ := hd x hlarge
    refine ⟨p, hp, hpx, hpu.trans_lt ?_⟩
    norm_num only [Real.rpow_ofNat]
    linarith [div_lt_div_of_pos_left hx0 (by norm_num : (0 : ℝ) < 1024) hc]

#print axioms sound
#print axioms full_gap
end ExposureEvolution.PrimeCover1024

#print axioms ExposureEvolution.PrimeCover1024.executed
