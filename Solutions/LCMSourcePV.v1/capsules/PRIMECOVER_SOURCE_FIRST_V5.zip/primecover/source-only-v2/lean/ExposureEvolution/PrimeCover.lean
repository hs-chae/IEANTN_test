import E1Tertiary.LcmTail
import LCMSourcePV.PrimeCover.DriverVerified
namespace ExposureEvolution.PrimeCover
open Real
set_option maxRecDepth 20000
set_option maxHeartbeats 0

def StrictGap (X : ℝ) : Prop :=
  ∀ x ≥ X, ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 256

def next (a : ℕ) : Option ℕ :=
  (List.range ((257 * a - 1) / 256 - a)).reverse.findSome? fun k =>
    let p := a + 1 + k
    if Nat.Prime p then some p else none

def run : ℕ → ℕ → ℕ → List ℕ
  | 0, _, _ => []
  | fuel + 1, a, b =>
      if b ≤ a then [] else
        match next a with
        | none => []
        | some p => p :: run fuel p b

def check (a b : ℕ) : List ℕ → Bool
  | [] => decide (b ≤ a)
  | p :: ps => decide (Nat.Prime p ∧ a < p ∧ 256 * p < 257 * a) && check p b ps

theorem sound (ps : List ℕ) {a b : ℕ} (hc : check a b ps = true)
    {x : ℝ} (ha : (a : ℝ) ≤ x) (hb : x < b) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 256 := by
  induction ps generalizing a with
  | nil =>
      have hba : b ≤ a := by simpa only [check, decide_eq_true_eq] using hc
      have hba' : (b : ℝ) ≤ a := by exact_mod_cast hba
      linarith
  | cons p ps ih =>
      have hh : (Nat.Prime p ∧ a < p ∧ 256 * p < 257 * a) ∧ check p b ps = true := by
        simpa only [check, Bool.and_eq_true, decide_eq_true_eq] using hc
      by_cases hp : x < (p : ℝ)
      · refine ⟨p, hh.1.1, hp, ?_⟩
        have hr : (256 : ℝ) * p < 257 * a := by exact_mod_cast hh.1.2.2
        linarith
      · exact ih hh.2 (le_of_not_gt hp)


-- Exact source-first provider adapters. All original definitions are unchanged.
-- The numerical facts below come from closed execution of the actual C source.
private theorem next_source_eq (a : ℕ) : next a = LCMSourcePV.PrimeCover.Math.next 256 a := by
  symm
  exact LCMSourcePV.PrimeCover.Math.search_eq_original a _

private theorem run_source_eq (fuel a b : ℕ) :
    run fuel a b = LCMSourcePV.PrimeCover.Math.run 256 fuel a b := by
  induction fuel generalizing a with
  | zero => rfl
  | succ fuel ih =>
    simp only [run,LCMSourcePV.PrimeCover.Math.run,next_source_eq]
    split
    · rfl
    · cases LCMSourcePV.PrimeCover.Math.next 256 a with
      | none => rfl
      | some p => exact congrArg (List.cons p) (ih p)

private theorem check_source_eq (a b : ℕ) (ps : List ℕ) :
    check a b ps = LCMSourcePV.PrimeCover.Math.check 256 a b ps := by
  induction ps generalizing a with
  | nil => rfl
  | cons p ps ih => simp only [check,LCMSourcePV.PrimeCover.Math.check,ih]

def output : List ℕ := [
  8501, 8527, 8543, 8573, 8599, 8629, 8647, 8677, 8707, 8741, 8761, 8783,
  8807, 8839, 8867, 8893, 8923, 8951, 8971, 9001, 9029, 9059, 9091, 9109,
  9137, 9161, 9187, 9221, 9257, 9293, 9323, 9349, 9377, 9413, 9439, 9473,
  9497, 9533, 9551, 9587, 9623, 9649, 9679, 9697, 9733, 9769, 9803, 9839,
  9871, 9907, 9941, 9973, 10009, 10039, 10069, 10103, 10141, 10177, 10211, 10247,
  10273, 10313, 10343, 10369, 10399, 10433, 10463, 10501, 10531, 10567, 10607, 10639,
  10667, 10691, 10729, 10753, 10789, 10831, 10867, 10909, 10949, 10987, 11027, 11069,
  11093, 11131, 11173, 11213, 11251, 11287, 11329, 11369, 11411, 11447, 11491, 11527,
  11551, 11593, 11633, 11677, 11719, 11743, 11783, 11827, 11867, 11909, 11953, 11987,
  12011, 12049, 12073, 12119, 12163, 12203, 12241, 12281, 12323, 12347, 12391, 12437,
  12479, 12527, 12569, 12613, 12659, 12703, 12743, 12791, 12829, 12853, 12899, 12941,
  12983, 13033, 13063, 13109, 13159, 13187, 13229, 13267, 13313, 13339, 13381, 13421,
  13469, 13513, 13553, 13597, 13649, 13697, 13729, 13781, 13831, 13883, 13933, 13967,
  14011, 14057, 14107, 14159, 14207, 14251, 14303, 14347, 14401, 14449, 14503, 14557,
  14593, 14639, 14683, 14737, 14783, 14831, 14887, 14939, 14983, 15031, 15083, 15139,
  15193, 15241, 15299, 15349, 15401, 15461, 15511, 15569, 15629, 15683, 15739, 15797,
  15823, 15881, 15937, 15991, 16033, 16091, 16141, 16193, 16253, 16301, 16363, 16421,
  16481, 16529, 16573, 16633, 16693, 16747, 16811, 16871, 16931, 16993, 17053, 17117,
  17183, 17239, 17299, 17359, 17419, 17483, 17551, 17609, 17669, 17737, 17791, 17851,
  17911, 17977, 18047, 18097, 18149, 18217, 18287, 18353, 18413, 18481, 18553, 18617,
  18679, 18749, 18803, 18869, 18919, 18979, 19051, 19121, 19183, 19249, 19319, 19391,
  19463, 19531, 19603, 19661, 19727, 19801, 19867, 19937, 20011, 20089, 20161, 20233,
  20297, 20369, 20443, 20521, 20599, 20663, 20743, 20809, 20887, 20963, 21031, 21107,
  21187, 21269, 21347, 21419, 21499, 21577, 21661, 21739, 21821, 21893, 21977, 22051,
  22133, 22193, 22279, 22349, 22433, 22511, 22573, 22651, 22739, 22817, 22901, 22973,
  23059, 23143, 23227, 23311, 23399, 23473, 23563, 23633, 23719, 23801, 23893, 23981,
  24071, 24151, 24239, 24329, 24421, 24509, 24593, 24683, 24767, 24859, 24953, 25037,
  25127, 25219, 25309, 25391, 25471, 25561, 25657, 25747, 25847, 25943, 26041, 26141,
  26237, 26339, 26437, 26539, 26641, 26737, 26839, 26927, 27031, 27127, 27211, 27299,
  27397, 27487, 27583, 27689, 27793, 27901, 28001, 28109, 28211, 28319, 28429, 28537,
  28643, 28753, 28859, 28961, 29063, 29173, 29269, 29383, 29483, 29587, 29683, 29789,
  29881, 29989, 30103, 30211, 30323, 30431, 30539, 30649, 30763, 30881, 30983, 31091,
  31193, 31307, 31397, 31517, 31627, 31741, 31859, 31981, 32099, 32213, 32327, 32443,
  32569, 32693, 32803, 32917, 33037, 33161, 33289, 33413, 33533, 33647, 33773, 33893,
  34019, 34147, 34273, 34403, 34537, 34667, 34781, 34913, 35027, 35159, 35291, 35423,
  35543, 35677, 35809, 35933, 36073, 36209, 36343, 36479, 36607, 36749, 36887, 37021,
  37159, 37277, 37409, 37549, 37693, 37831, 37967, 38113, 38261, 38393, 38501, 38651,
  38791, 38933, 39079, 39229, 39373, 39521, 39671, 39821, 39971, 40127, 40283, 40433,
  40583, 40739, 40897, 41051, 41203, 41357, 41513, 41669, 41813, 41969, 42131, 42293,
  42457, 42611, 42773, 42937, 43103, 43271, 43427, 43591, 43759, 43913, 44071, 44221,
  44389, 44549, 44711, 44879, 45053, 45197, 45361, 45533, 45707, 45869, 46027, 46199,
  46351, 46523, 46703, 46877, 47059, 47237, 47419, 47599, 47779, 47963, 48131, 48313,
  48497, 48679, 48869, 49057, 49223, 49411, 49603, 49789, 49957, 50147, 50341, 50527,
  50723, 50909, 51071, 51263, 51461, 51659, 51859, 52057, 52259, 52457, 52639, 52837,
  53017, 53201, 53407, 53611, 53819, 54013, 54217, 54421, 54631, 54833, 55021, 55229,
  55441, 55639, 55849, 56053, 56269, 56479, 56687, 56897, 57119, 57331, 57529, 57751,
  57973, 58199, 58417, 58631, 58831, 59053, 59281, 59509, 59729, 59957, 60169, 60397,
  60631, 60859, 61091, 61297, 61519, 61757, 61991, 62233, 62473, 62701, 62939, 63179,
  63421, 63667, 63913, 64157, 64403, 64633, 64879, 65129, 65381, 65633, 65881, 66137,
  66383, 66629, 66889, 67141, 67399, 67651, 67901, 68161, 68399, 68659, 68927, 69193,
  69463, 69709, 69959, 70229, 70501, 70769, 71039, 71293, 71569, 71843, 72109, 72383,
  72661, 72937, 73189, 73471, 73757, 74027, 74311, 74597, 74887, 75169, 75437, 75731,
  76003, 76289, 76579, 76873, 77171, 77471, 77773, 78059, 78347, 78653, 78941, 79241,
  79549, 79847, 80153, 80449, 80761, 81071, 81373, 81689, 82007, 82307, 82619, 82939,
  83257, 83579, 83903, 84229, 84551, 84871, 85201, 85531, 85853, 86183, 86509, 86843,
  87181, 87517, 87853, 88177, 88513, 88853, 89189, 89533, 89867
]

theorem executed : run 700 8468 89693 = output ∧
    check 8468 89693 output = true ∧ output.length = 669 := by
  have output_eq : output = LCMSourcePV.PrimeCover.DriverVerified8468D256.output := by
    rw [LCMSourcePV.PrimeCover.DriverVerified8468D256.output_eq]
    decide +kernel
  rw [run_source_eq,output_eq,check_source_eq]
  exact ⟨LCMSourcePV.PrimeCover.DriverVerified8468D256.run_eq,LCMSourcePV.PrimeCover.DriverVerified8468D256.check_true,LCMSourcePV.PrimeCover.DriverVerified8468D256.output_length⟩

theorem covered {x : ℝ} (ha : (8468 : ℝ) ≤ x) (hb : x < 89693) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 256 :=
  sound output executed.2.1 ha hb

theorem full_gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 8468 := by
  intro x hx
  by_cases ht : x < 89693
  · exact covered hx ht
  · have hlarge : (89693 : ℝ) ≤ x := le_of_not_gt ht
    have hx0 : 0 < x := by linarith
    have he : exp (7 : ℝ) < 89693 := by
      have h1 : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
      calc exp (7 : ℝ) = (exp 1) ^ 7 := by rw [Real.exp_one_pow]; norm_num
        _ ≤ (3 : ℝ) ^ 7 := pow_le_pow_left₀ (exp_pos 1).le h1.le 7
        _ < 89693 := by norm_num
    have hl : 7 < log x := by
      have hh := log_lt_log (exp_pos (7 : ℝ)) (he.trans_le hlarge)
      simpa only [log_exp] using hh
    have hlp : 0 < log x := by linarith
    have hc : (256 : ℝ) < log x ^ 3 := by
      nlinarith [mul_pos (by linarith : 0 < log x - 7) (sq_pos_of_pos hlp)]
    obtain ⟨p, hp, hpx, hpu⟩ := hd x hlarge
    refine ⟨p, hp, hpx, hpu.trans_lt ?_⟩
    norm_num only [Real.rpow_ofNat]
    linarith [div_lt_div_of_pos_left hx0 (by norm_num : (0 : ℝ) < 256) hc]

#print axioms sound
#print axioms full_gap
end ExposureEvolution.PrimeCover

#print axioms ExposureEvolution.PrimeCover.executed
