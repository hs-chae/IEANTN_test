/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Terence Tao, OpenAI (Codex)
-/
import E1Tertiary.LcmBase
import ExposureEvolution.PrimeCover
/-! A new analytic parameter choice in the published LCM construction.
The source criterion is unchanged. This shared analytic lemma uses relative gap1/256
and the lower bound log(X₀)≥9. It does not execute a finite numerical provider. -/
namespace ExposureEvolution.SharpConstant
open ArithmeticFunction hiding log
open Finset Nat Real
open E1Tertiary.LcmBase
set_option maxHeartbeats 2000000

def StrictGap (X : ℝ) : Prop :=
  ∀ x ≥ X, ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 256

section Abstract

variable {c X₀ : ℝ}

/-- `0 < X₀`, from the prime-gap hypothesis rather than from `c ≤ log X₀` -- see the note above. -/
lemma X₀_pos (hd : StrictGap X₀) : 0 < X₀ := by
  by_contra h
  push_neg at h
  obtain ⟨p, hp, hp_lb, hp_ub⟩ := hd 0 h
  simp only [Real.log_zero, zero_div, add_zero] at hp_ub
  exact absurd (hp_lb.trans hp_ub) (lt_irrefl _)

lemma exp_nine_le (hd : StrictGap X₀)
    (hc : 9 ≤ c) (hcX : c ≤ Real.log X₀) : Real.exp 9 ≤ X₀ :=
  calc Real.exp 9 ≤ Real.exp (Real.log X₀) := Real.exp_le_exp.mpr (hc.trans hcX)
    _ = X₀ := Real.exp_log (X₀_pos hd)

/-- `X₀ > 4096`, from `log X₀ ≥ 9` and `e > 2.7182818283`.  Every place `v1` used a property of the
literal `89693` -- that it exceeds 2, that `1/X₀` is small -- is served by this. -/
lemma X₀_gt (hd : StrictGap X₀)
    (hc : 9 ≤ c) (hcX : c ≤ Real.log X₀) : (4096 : ℝ) < X₀ := by
  refine lt_of_lt_of_le ?_ (exp_nine_le hd hc hcX)
  rw [show (9 : ℝ) = ((9 : ℕ) : ℝ) by norm_num, ← Real.exp_one_pow]
  grw [← Real.exp_one_gt_d9]
  norm_num

variable {n : ℕ}

lemma hsqrt_ge (hn : X₀ ^ 2 ≤ (n : ℝ)) : X₀ ≤ √(n : ℝ) :=
  Real.le_sqrt_of_sq_le hn

/-- `√n > 4096`: the workhorse.  `v1` wrote `√n ≥ 89693` and used it for everything numerical. -/
lemma hsqrt_gt (hd : StrictGap X₀) (hc : 9 ≤ c)
    (hcX : c ≤ Real.log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) : (4096 : ℝ) < √(n : ℝ) :=
  lt_of_lt_of_le (X₀_gt hd hc hcX) (hsqrt_ge hn)

lemma hn_gt (hd : StrictGap X₀) (hc : 9 ≤ c)
    (hcX : c ≤ Real.log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) : (4096 : ℝ) ^ 2 < (n : ℝ) := by
  have h := hsqrt_gt hd hc hcX hn
  have hsq : √(n : ℝ) ^ 2 = (n : ℝ) := Real.sq_sqrt (by positivity)
  nlinarith [Real.sqrt_nonneg ((n : ℝ))]

lemma n_pos (hd : StrictGap X₀) (hc : 9 ≤ c)
    (hcX : c ≤ Real.log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) : 0 < n := by
  have h := hn_gt hd hc hcX hn
  have : (0 : ℝ) < (n : ℝ) := by nlinarith
  exact_mod_cast this

/-- `log √n ≥ c`.  The one thing `c` is for. -/
lemma hlog (hd : StrictGap X₀) (hc : 9 ≤ c)
    (hcX : c ≤ Real.log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) : c ≤ log √(n : ℝ) :=
  hcX.trans (log_le_log (X₀_pos hd) (hsqrt_ge hn))

lemma hlog_pos (hd : StrictGap X₀) (hc : 9 ≤ c)
    (hcX : c ≤ Real.log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) : 0 < log √(n : ℝ) :=
  lt_of_lt_of_le (by linarith) (hlog hd hc hcX hn)

/-- The relative gap bound, converted to a concrete rational once and for all.

The gap parameter is an explicit analytic hypothesis rather than a consequence of logarithms. -/
lemma hgap (hd : StrictGap X₀) (hc : 9 ≤ c)
    (hcX : c ≤ Real.log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    (1 / 256 : ℝ) ≤ 1 / 256 := by norm_num

lemma hε_pos (hd : StrictGap X₀) (hc : 9 ≤ c)
    (hcX : c ≤ Real.log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    0 < 1 + (1 / 256 : ℝ) := by
  have := hlog_pos hd hc hcX hn
  positivity

section Gap

variable (hd : StrictGap X₀) (hc : 9 ≤ c) (hcX : c ≤ Real.log X₀)

include hd hc hcX in
theorem exists_p_primes (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    ∃ p : Fin 3 → ℕ, (∀ i, Nat.Prime (p i)) ∧ StrictMono p ∧
      (∀ i, p i ≤ √(n : ℝ) * (1 + (1 / 256 : ℝ)) ^ (i + 1 : ℝ)) ∧
      √(n : ℝ) < p 0 := by
  let x := √(n : ℝ)
  have hx_pos : 0 < x := (X₀_pos hd).trans_le (hsqrt_ge hn)
  have hlog_pos : 0 < log x := hlog_pos hd hc hcX hn
  set ε := (1 / 256 : ℝ) with hε_def
  have upper {y : ℝ} (hy : 0 < y) (hlog_ge : log y ≥ log x) {p : ℕ}
      (hp : (p : ℝ) < y + y / 256) : (p : ℝ) ≤ y * (1 + ε) := by
    dsimp [ε]
    linarith
  have hε_pos : 0 < ε := by positivity
  have hx1_ge : x * (1 + ε) ≥ X₀ := (hsqrt_ge hn).trans (le_mul_of_one_le_right hx_pos.le
    (by grind))
  have hx2_ge : x * (1 + ε) ^ 2 ≥ X₀ := (hsqrt_ge hn).trans (le_mul_of_one_le_right hx_pos.le
    (by nlinarith [sq_nonneg ε]))
  obtain ⟨p₀, hp₀_prime, hp₀_lb, hp₀_ub⟩ := hd x (hsqrt_ge hn)
  obtain ⟨p₁, hp₁_prime, hp₁_lb, hp₁_ub⟩ := hd _ hx1_ge
  obtain ⟨p₂, hp₂_prime, hp₂_lb, hp₂_ub⟩ := hd _ hx2_ge
  have hp₀_ub' : (p₀ : ℝ) ≤ x * (1 + ε) := upper hx_pos le_rfl hp₀_ub
  have hp₁_ub' : (p₁ : ℝ) ≤ x * (1 + ε) ^ 2 := by
    linarith [sq (1 + ε), upper (by grind) (log_le_log hx_pos (by grind)) hp₁_ub]
  have hp₂_ub' : (p₂ : ℝ) ≤ x * (1 + ε) ^ 3 := by
    linarith [pow_succ (1 + ε) 2, upper (by grind) (log_le_log hx_pos (by grind)) hp₂_ub]
  refine ⟨![p₀, p₁, p₂], fun i ↦ by fin_cases i <;> assumption,
    Fin.strictMono_iff_lt_succ.mpr fun i ↦ by
      fin_cases i
      · exact cast_lt.mp (hp₀_ub'.trans_lt hp₁_lb)
      · exact cast_lt.mp (hp₁_ub'.trans_lt hp₂_lb), fun i ↦ ?_, hp₀_lb⟩
  fin_cases i <;> norm_num
  · convert hp₀_ub' using 2 <;> norm_num [ε]
  · convert hp₁_ub' using 2 <;> norm_num [ε]
  · convert hp₂_ub' using 2 <;> norm_num [ε]

include hd hc hcX in
theorem exists_q_primes (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    ∃ q : Fin 3 → ℕ, (∀ i, Nat.Prime (q i)) ∧ StrictMono q ∧
      (∀ i : Fin 3, n * (1 + (1 / 256 : ℝ)) ^ (-((3 : ℝ) - (i : ℕ))) ≤ q i) ∧
      q 2 < n := by
  let x := √(n : ℝ)
  have hx_pos : 0 < x := (X₀_pos hd).trans_le (hsqrt_ge hn)
  have hlog_pos : 0 < log x := hlog_pos hd hc hcX hn
  set ε := (1 / 256 : ℝ) with hε_def
  have hε_pos : 0 < ε := by positivity
  have h1ε_pos : 0 < 1 + ε := by linarith
  have hn_pos : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  have hn_eq_x2 : (n : ℝ) = x ^ 2 := (sq_sqrt hn_pos.le).symm
  have hX₀_gt : (4096 : ℝ) < X₀ := X₀_gt hd hc hcX
  -- ε is small: this is where `9 ≤ c` enters, and the only place it does.
  have hε_small : ε ≤ 1 / 256 := hgap hd hc hcX hn
  have h1ε3_pos : 0 < (1 + ε) ^ 3 := by positivity
  have h1ε2_pos : 0 < (1 + ε) ^ 2 := by positivity
  have h1ε3_le_2 : (1 + ε) ^ 3 ≤ 2 := by norm_num [ε]
  -- Define y_i = n / (1 + ε)^(3-i), and show y_i ≥ X₀
  have hy₀_ge : n / (1 + ε) ^ 3 ≥ X₀ := by
    calc n / (1 + ε) ^ 3 = x ^ 2 / (1 + ε) ^ 3 := by rw [hn_eq_x2]
      _ ≥ x ^ 2 / 2 := div_le_div_of_nonneg_left (sq_nonneg x) (by grind) h1ε3_le_2
      _ ≥ X₀ ^ 2 / 2 := by
        apply div_le_div_of_nonneg_right (by nlinarith [hsqrt_ge hn, X₀_pos hd])
        norm_num
      _ ≥ X₀ := by nlinarith [X₀_pos hd]
  have h1ε2_le_1ε3 : (1 + ε) ^ 2 ≤ (1 + ε) ^ 3 := by nlinarith [sq_nonneg ε]
  have h1ε_le_1ε2 : 1 + ε ≤ (1 + ε) ^ 2 := by nlinarith [sq_nonneg ε]
  have hy₁_ge : n / (1 + ε) ^ 2 ≥ X₀ := le_trans hy₀_ge
    (div_le_div_of_nonneg_left hn_pos.le h1ε2_pos h1ε2_le_1ε3)
  have hy₂_ge : n / (1 + ε) ≥ X₀ := le_trans hy₁_ge
    (div_le_div_of_nonneg_left hn_pos.le h1ε_pos h1ε_le_1ε2)
  obtain ⟨q₀, hq₀_prime, hq₀_lb, hq₀_ub⟩ := hd (n / (1 + ε) ^ 3) hy₀_ge
  obtain ⟨q₁, hq₁_prime, hq₁_lb, hq₁_ub⟩ := hd (n / (1 + ε) ^ 2) hy₁_ge
  obtain ⟨q₂, hq₂_prime, hq₂_lb, hq₂_ub⟩ := hd (n / (1 + ε)) hy₂_ge
  have hx_ge_2 : x ≥ 2 := by linarith [hsqrt_gt hd hc hcX hn]
  have hy₀_ge_x : n / (1 + ε) ^ 3 ≥ x := by
    calc n / (1 + ε) ^ 3 = x ^ 2 / (1 + ε) ^ 3 := by rw [hn_eq_x2]
      _ ≥ x ^ 2 / 2 := div_le_div_of_nonneg_left (sq_nonneg x) (by grind) h1ε3_le_2
      _ ≥ x := by rw [ge_iff_le, le_div_iff₀' (by norm_num : (0 : ℝ) < 2)]; nlinarith
  have hy₁_ge_x : n / (1 + ε) ^ 2 ≥ x := le_trans hy₀_ge_x
    (div_le_div_of_nonneg_left hn_pos.le h1ε2_pos h1ε2_le_1ε3)
  have hy₂_ge_x : n / (1 + ε) ≥ x := le_trans hy₁_ge_x
    (div_le_div_of_nonneg_left hn_pos.le h1ε_pos h1ε_le_1ε2)
  have upper {y : ℝ} (hy_pos : 0 < y) (hy_ge : y ≥ x) {q : ℕ}
      (hq : (q : ℝ) < y + y / 256) : (q : ℝ) ≤ y * (1 + ε) := by
    dsimp [ε]
    linarith
  have hq₀_ub' : (q₀ : ℝ) ≤ n / (1 + ε) ^ 2 := by
    have := upper (by positivity) hy₀_ge_x hq₀_ub
    calc (q₀ : ℝ) ≤ (n / (1 + ε) ^ 3) * (1 + ε) := this
      _ = n / (1 + ε) ^ 2 := by field_simp
  have hq₁_ub' : (q₁ : ℝ) ≤ n / (1 + ε) := by
    have := upper (by positivity) hy₁_ge_x hq₁_ub
    calc (q₁ : ℝ) ≤ (n / (1 + ε) ^ 2) * (1 + ε) := this
      _ = n / (1 + ε) := by field_simp
  have hq₂_ub' : (q₂ : ℝ) ≤ n := by
    have := upper (by positivity) hy₂_ge_x hq₂_ub
    calc (q₂ : ℝ) ≤ (n / (1 + ε)) * (1 + ε) := this
      _ = n := by field_simp
  have hq₀_lt_q₁ : q₀ < q₁ := Nat.cast_lt.mp (hq₀_ub'.trans_lt hq₁_lb)
  have hq₁_lt_q₂ : q₁ < q₂ := Nat.cast_lt.mp (hq₁_ub'.trans_lt hq₂_lb)
  have hq₂_lt_n : q₂ < n := by
    have hq₂_strict : (q₂ : ℝ) < n := by
      calc (q₂ : ℝ) < n / (1 + ε) + (n / (1 + ε)) / 256 := hq₂_ub
        _ = n := by dsimp [ε]; ring
    exact Nat.cast_lt.mp hq₂_strict
  refine ⟨![q₀, q₁, q₂], fun i ↦ by fin_cases i <;> assumption,
    Fin.strictMono_iff_lt_succ.mpr fun i ↦ by fin_cases i <;> assumption,
    fun i ↦ ?_, hq₂_lt_n⟩
  fin_cases i <;> simp only [hε_def]
  · simp only [CharP.cast_eq_zero, sub_zero]
    have heq : (n : ℝ) * (1 + (1 / 256 : ℝ)) ^ (-(3 : ℝ)) = n / (1 + ε) ^ 3 := by
      rw [rpow_neg h1ε_pos.le, div_eq_mul_inv]
      norm_cast
    rw [heq]
    exact hq₀_lb.le
  · simp only [Nat.cast_one]
    have heq : (n : ℝ) * (1 + (1 / 256 : ℝ)) ^ (-(3 - 1 : ℝ)) = n / (1 + ε) ^ 2 := by
      have h1 : -(3 - 1 : ℝ) = -2 := by ring
      rw [h1, rpow_neg h1ε_pos.le, div_eq_mul_inv]
      norm_cast
    rw [heq]
    exact hq₁_lb.le
  · simp only [Nat.cast_ofNat]
    have heq : (n : ℝ) * (1 + (1 / 256 : ℝ)) ^ (-(3 - 2 : ℝ)) = n / (1 + ε) := by
      have h1 : -(3 - 2 : ℝ) = -1 := by ring
      rw [h1, rpow_neg h1ε_pos.le, rpow_one, div_eq_mul_inv]
    rw [heq]
    exact hq₂_lb.le


theorem prod_q_ge (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    ∏ i, (1 + (1 : ℝ) / (exists_q_primes hd hc hcX hn).choose i) ≤
      ∏ i : Fin 3, (1 + (1 + (1 / 256 : ℝ)) ^ ((i : ℕ) + 1 : ℝ) / n) := by
  have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  rw [show ∏ i : Fin 3, (1 + (1 + (1 / 256 : ℝ)) ^ ((i : ℕ) + 1 : ℝ) / n) =
      ∏ i : Fin 3, (1 + (1 + (1 / 256 : ℝ)) ^ ((3 : ℝ) - (i : ℕ)) / n) by
    simp only [Fin.prod_univ_three, Fin.val_zero, Fin.val_one, Fin.val_two]; ring_nf]
  apply Finset.prod_le_prod₀ (fun _ _ ↦ by positivity)
  intro i _
  suffices h : (1 : ℝ) / (exists_q_primes hd hc hcX hn).choose i ≤
      (1 + (1 / 256 : ℝ)) ^ ((3 : ℝ) - (i : ℕ)) / n from (by linarith)
  have := (exists_q_primes hd hc hcX hn).choose_spec.2.2.1 i
  rw [show (1 + (1 / 256 : ℝ)) ^ ((3 : ℝ) - (i : ℕ)) / n =
      1 / (n / (1 + (1 / 256 : ℝ)) ^ ((3 : ℝ) - (i : ℕ)) ) by field_simp]
  have f0 : (0 : ℝ) < (log √(n : ℝ)) ^ 3 := by positivity [hlog_pos hd hc hcX hn]
  apply one_div_le_one_div_of_le
  · exact div_pos hnp (rpow_pos_of_pos (hε_pos hd hc hcX hn) _)
  · rw [Real.rpow_neg (by norm_num : (0 : ℝ) ≤ 1 + 1 / 256)] at this
    simpa only [div_eq_mul_inv] using this

theorem prod_p_ge (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    ∏ i, (1 + (1 : ℝ) /
        ((exists_p_primes hd hc hcX hn).choose i *
          ((exists_p_primes hd hc hcX hn).choose i + 1))) ≥
      ∏ i : Fin 3,
        (1 + 1 / ((1 + (1 / 256 : ℝ)) ^ (2 * (i : ℕ) + 2 : ℝ) * (n + √n))) := by
  have hlp := hlog_pos hd hc hcX hn
  have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  refine Finset.prod_le_prod₀ (fun i _ => by positivity) fun i _ => ?_
  set p := (exists_p_primes hd hc hcX hn).choose
  have h₀ (i) : √n < p i := by
    have : p 0 ≤ p i := by
      apply (exists_p_primes hd hc hcX hn).choose_spec.2.1.monotone
      simp
    grw [← this]
    exact (exists_p_primes hd hc hcX hn).choose_spec.2.2.2
  gcongr 1 + 1 / ?_
  · have := ((exists_p_primes hd hc hcX hn).choose_spec.1 i).pos
    positivity
  have : p i ≤ √n * (1 + (1 / 256 : ℝ)) ^ (i + 1 : ℝ) :=
    (exists_p_primes hd hc hcX hn).choose_spec.2.2.1 i
  have h₁ : p i ^ 2 ≤ n * (1 + (1 / 256 : ℝ)) ^ (2 * i + 2 : ℝ) := by
    grw [this, mul_pow, sq_sqrt (by simp)]
    norm_cast
    rw [← pow_mul]
    grind
  have h₂ : p i + 1 ≤ p i * (1 / n * (n + √n)) := by
    field_simp [this, hnp.ne']
    linear_combination √n * h₀ i - sq_sqrt (cast_nonneg n)
  grw [h₂, ← mul_assoc, ← sq, h₁]
  field_simp [hnp.ne']
  all_goals norm_num

theorem pq_ratio_ge (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    1 - ((4 : ℝ) * ∏ i, ((exists_p_primes hd hc hcX hn).choose i : ℝ))
    / ∏ i, ((exists_q_primes hd hc hcX hn).choose i : ℝ) ≥
    1 - 4 * (1 + (1 / 256 : ℝ)) ^ 12 / n ^ (3 / 2 : ℝ) := by
  have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  have hep := hε_pos hd hc hcX hn
  have l1 : ((1 + (1 / 256 : ℝ)) ^ 12 / n ^ (3 / 2 : ℝ)) =
    (n ^ (3 / 2 : ℝ) * (1 + (1 / 256 : ℝ)) ^ 6) /
    (n ^ (3 : ℝ) * (1 + (1 / 256 : ℝ)) ^ (- 6 : ℝ)) := by
    rw [rpow_neg hep.le, ← div_eq_mul_inv, div_div_eq_mul_div, mul_assoc,
      mul_comm, ← rpow_natCast, ← rpow_natCast (n := 6), ← rpow_add hep,
      ← div_div_eq_mul_div]
    · congr
      · grind
      · rw [← rpow_sub (by positivity)]; grind
  have l2 : n ^ (3 / 2 : ℝ) * (1 + (1 / 256 : ℝ)) ^ 6 = ∏ i : Fin 3,
    √n * (1 + (1 / 256 : ℝ)) ^ ((i : ℝ) + 1) := by
    rw [← Finset.pow_card_mul_prod, Fin.prod_univ_three, ← rpow_add hep,
      ← rpow_add hep, rpow_div_two_eq_sqrt _ (by positivity)]
    norm_num
  have l3 : n ^ (3 : ℝ) * (1 + (1 / 256 : ℝ)) ^ (- 6 : ℝ) =
    ∏ i : Fin 3, n * (1 + (1 / 256 : ℝ)) ^ (-((3 : ℝ) - i.1))  := by
    rw [← Finset.pow_card_mul_prod, Fin.prod_univ_three, ← rpow_add hep,
      ← rpow_add hep]
    norm_num
  rw [← mul_div_assoc', ← mul_div_assoc', l1, l2, l3]
  gcongr
  all_goals first
    | exact (exists_p_primes hd hc hcX hn).choose_spec.2.2.1 _
    | exact (exists_q_primes hd hc hcX hn).choose_spec.2.2.1 _
    | exact Finset.prod_nonneg fun _ _ => by positivity
    | exact Finset.prod_pos fun _ _ => by positivity
    | (intro _ _; positivity)
    | positivity

/-! Exact rational scalar estimates for the new analytic consumer budget. -/

include hd hc hcX in
theorem inv_n_pow_3_div_2_le (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    1 / ((n : ℝ) ^ (3 / 2 : ℝ)) ≤ (1 / (4096 : ℝ)) * (1 / (n : ℝ)) := by
  have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  have hs := (hsqrt_gt hd hc hcX hn).le
  rw [one_div_mul_one_div, one_div_le_one_div (rpow_pos_of_pos hnp _)
    (mul_pos (by norm_num) hnp), show (3 / 2 : ℝ) = 1 + 1 / 2 by ring,
      rpow_add hnp, rpow_one, mul_comm, ← sqrt_eq_rpow]
  exact mul_le_mul_of_nonneg_left hs hnp.le

include hd hc hcX in
theorem inv_n_add_sqrt_ge (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    1 / ((n : ℝ) + √(n : ℝ)) ≥ (1 / (1 + 1 / (4096 : ℝ))) * (1 / (n : ℝ)) := by
  have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  have hs := (hsqrt_gt hd hc hcX hn).le
  have hsq : √(n : ℝ) ^ 2 = (n : ℝ) := sq_sqrt hnp.le
  have hsp : (0 : ℝ) < √(n : ℝ) := by positivity
  rw [ge_iff_le, one_div_mul_one_div, div_le_div_iff₀ (by positivity) (by positivity)]
  nlinarith [hs, hsq, hsp]

theorem prod_epsilon_le {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (4096 ^ 2 : ℝ)) :
    ∏ i : Fin 3, (1 + ((257 / 256) : ℝ) ^ ((i : ℕ) + 1 : ℝ) * ε) ≤
      1 + 3.024 * ε + 3.05 * ε ^ 2 + 1.03 * ε ^ 3 := by
  norm_cast; norm_num [Fin.prod_univ_three]; nlinarith [hε.1, hε.2]

theorem prod_epsilon_ge {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (4096 ^ 2 : ℝ)) :
    (∏ i : Fin 3,
      (1 + ε / (((257 / 256) : ℝ) ^ (2 * ((i : ℕ) + 1 : ℝ))) * (1 / (1 + 1 / 4096)))) *
        (1 + (3 : ℝ) / 8 * ε) * (1 - 4 * ((257 / 256) : ℝ) ^ 12 / 4096 * ε) ≥
      1 + 3.325 * ε - 0.01 * ε ^ 2 := by
  norm_cast; norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg hε.left 3, pow_nonneg hε.left 4, hε.1, hε.2]

theorem final_comparison {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (4096 ^ 2 : ℝ)) :
    1 + 3.024 * ε + 3.05 * ε ^ 2 + 1.03 * ε ^ 3 ≤ 1 + 3.325 * ε - 0.01 * ε ^ 2 := by
  nlinarith [hε.1, hε.2]

include hd hc hcX in
noncomputable def Criterion.mk' (hn : X₀ ^ 2 ≤ (n : ℝ)) : Criterion where
  n := n
  p := (exists_p_primes hd hc hcX hn).choose
  q := (exists_q_primes hd hc hcX hn).choose
  hn := n_pos hd hc hcX hn
  hp := (exists_p_primes hd hc hcX hn).choose_spec.1
  hp_mono := (exists_p_primes hd hc hcX hn).choose_spec.2.1
  hq := (exists_q_primes hd hc hcX hn).choose_spec.1
  hq_mono := (exists_q_primes hd hc hcX hn).choose_spec.2.1
  h_ord_1 := (exists_p_primes hd hc hcX hn).choose_spec.2.2.2
  h_ord_2 := by
    have hn_pos : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
    have hp' : ((exists_p_primes hd hc hcX hn).choose 2 : ℝ) ≤
        √n * (1 + (1 / 256 : ℝ)) ^ 3 := by
      convert (exists_p_primes hd hc hcX hn).choose_spec.2.2.1 2 using 2; norm_cast
    have hq' : (n : ℝ) * (1 + (1 / 256 : ℝ)) ^ (-3 : ℝ) ≤
        (exists_q_primes hd hc hcX hn).choose 0 := by
      convert (exists_q_primes hd hc hcX hn).choose_spec.2.2.1 0 using 2
      norm_num
    have hε_pos := hε_pos hd hc hcX hn
    have hgap := hgap hd hc hcX hn
    have hmid :
        √n * (1 + (1 / 256 : ℝ)) ^ 3 < (n : ℝ) * (1 + (1 / 256 : ℝ)) ^ (-3 : ℝ) := by
      norm_num
      have hs := hsqrt_gt hd hc hcX hn
      have hsq := Real.sq_sqrt (Nat.cast_nonneg n)
      have hm := mul_nonneg (Real.sqrt_nonneg (n : ℝ)) (show 0 ≤ √(n : ℝ) - 4096 by linarith)
      nlinarith
    exact_mod_cast hp'.trans_lt <| hmid.trans_le hq'
  h_ord_3 := (exists_q_primes hd hc hcX hn).choose_spec.2.2.2
  h_crit := by
    have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
    have hngt := hn_gt hd hc hcX hn
    have hn₀ : 0 ≤ Real.log √(n : ℝ) := (hlog_pos hd hc hcX hn).le
    have h₁ : 1 - (4 : ℝ) *
        (∏ i, (exists_p_primes hd hc hcX hn).choose i : ℝ) /
          ∏ i, ((exists_q_primes hd hc hcX hn).choose i : ℝ) ≥
        1 - 4 * (1 + 1 / 256 : ℝ) ^ 12 * ((1 / 4096) * (1 / n)) := by
      grw [pq_ratio_ge hd hc hcX hn,
        ← inv_n_pow_3_div_2_le hd hc hcX hn]
      simp [field]
    have hnn : 0 ≤ 1 - 4 * (1 + 1 / 256 : ℝ) ^ 12 * ((1 / 4096) * (1 / n)) := by
      have : (1 : ℝ) / n ≤ 1 / 4096 ^ 2 := by
        rw [div_le_div_iff₀ hnp (by norm_num)]; linarith
      nlinarith
    have := hnn.trans h₁
    have hn' : (0 : ℝ) ≤ 1 / (n : ℝ) ∧ (1 : ℝ) / (n : ℝ) ≤ 1 / 4096 ^ 2 :=
      ⟨by positivity, by rw [div_le_div_iff₀ hnp (by norm_num)]; linarith⟩
    grw [prod_q_ge hd hc hcX hn, prod_p_ge hd hc hcX hn, h₁]
    simp_rw [div_eq_mul_one_div (_ ^ (_ : ℝ) : ℝ) (n : ℝ),
      show 3 / (8 * (n : ℝ)) = 3 / 8 * (1 / n) by field_simp, ← one_div_mul_one_div]
    grw [inv_n_add_sqrt_ge hd hc hcX hn]
    set ε : ℝ := 1 / (n : ℝ)
    calc
      _ ≤ ∏ i : Fin 3, (1 + (1 + 1 / 256 : ℝ) ^ (i + 1 : ℝ) * ε) := by gcongr
      _ = ∏ i : Fin 3, (1 + ((257 / 256) : ℝ) ^ (i + 1 : ℝ) * ε) := by norm_num
      _ ≤ _ := (prod_epsilon_le (ε := ε) hn')
      _ ≤ _ := final_comparison hn'
      _ ≤ _ := by
        grw [← prod_epsilon_ge hn']
        apply le_of_eq
        simp [field]
        ring_nf

include hd hc hcX in
/-- The Boolean corollary of this analytic criterion. -/
theorem L_not_HA_of_ge (n : ℕ) (hn : X₀ ^ 2 ≤ (n : ℝ)) : ¬HighlyAbundant (L n) :=
  (Criterion.mk' hd hc hcX hn).not_highlyAbundant

end Gap

end Abstract

end ExposureEvolution.SharpConstant
