/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import Mathlib

import LCMSourcePV.PrimeCover.DriverVerified
namespace E1TwoTracks.TrackAPrimeCover
open Real

/-- Exact integer search; the admissible upper endpoint is strict. -/
def next (a : ℕ) : Option ℕ :=
  (List.range ((67 * a - 1) / 66 - a)).reverse.findSome? fun k =>
    let p := a + 1 + k
    if Nat.Prime p then some p else none

/-- The recalibrated program fills a finite prime cover before the frozen literature tail. -/
def run : ℕ → ℕ → ℕ → List ℕ
  | 0, _, _ => []
  | fuel + 1, a, b =>
    if b ≤ a then [] else
      match next a with
      | none => []
      | some p => p :: run fuel p b

/-- An independent checker. Its specification covers every real input, not just integers. -/
def check (a b : ℕ) : List ℕ → Bool
  | [] => decide (b ≤ a)
  | p :: ps => decide (Nat.Prime p ∧ a < p ∧ 66 * p < 67 * a) && check p b ps

theorem sound (ps : List ℕ) {a b : ℕ} (hc : check a b ps = true)
    {x : ℝ} (ha : (a : ℝ) ≤ x) (hb : x < b) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 66 := by
  induction ps generalizing a with
  | nil =>
    have hba : b ≤ a := by simpa [check] using hc
    have hba' : (b : ℝ) ≤ a := by exact_mod_cast hba
    linarith
  | cons p ps ih =>
    have hh : (Nat.Prime p ∧ a < p ∧ 66 * p < 67 * a) ∧ check p b ps = true := by
      simpa [check] using hc
    by_cases hp : x < (p : ℝ)
    · refine ⟨p, hh.1.1, hp, ?_⟩
      have hr : (66 : ℝ) * p < 67 * a := by exact_mod_cast hh.1.2.2
      linarith
    · exact ih hh.2 (le_of_not_gt hp)

def start : ℕ := 1341
def tail : ℕ := 89693
def fuel : ℕ := 512

-- Exact source-first provider adapters. All original definitions are unchanged.
-- The numerical facts below come from closed execution of the actual C source.
private theorem next_source_eq (a : ℕ) : next a = LCMSourcePV.PrimeCover.Math.next 66 a := by
  symm
  exact LCMSourcePV.PrimeCover.Math.search_eq_original a _

private theorem run_source_eq (fuel a b : ℕ) :
    run fuel a b = LCMSourcePV.PrimeCover.Math.run 66 fuel a b := by
  induction fuel generalizing a with
  | zero => rfl
  | succ fuel ih =>
    simp only [run,LCMSourcePV.PrimeCover.Math.run,next_source_eq]
    split
    · rfl
    · cases LCMSourcePV.PrimeCover.Math.next 66 a with
      | none => rfl
      | some p => exact congrArg (List.cons p) (ih p)

private theorem check_source_eq (a b : ℕ) (ps : List ℕ) :
    check a b ps = LCMSourcePV.PrimeCover.Math.check 66 a b ps := by
  induction ps generalizing a with
  | nil => rfl
  | cons p ps ih => simp only [check,LCMSourcePV.PrimeCover.Math.check,ih]

def output : List ℕ := run fuel start tail

/-- New finite output; consumer correctness uses the independent all-real checker theorem. -/
theorem execution : check start tail output = true := by
  have output_eq : output = LCMSourcePV.PrimeCover.DriverVerified1341D66.output := by
    unfold output fuel start tail
    rw [run_source_eq]
    exact LCMSourcePV.PrimeCover.DriverVerified1341D66.run_eq
  rw [output_eq,check_source_eq]
  exact LCMSourcePV.PrimeCover.DriverVerified1341D66.check_true

theorem covered {x : ℝ} (ha : (1341 : ℝ) ≤ x) (hb : x < 89693) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 66 :=
  sound output execution ha hb

end E1TwoTracks.TrackAPrimeCover

#print axioms E1TwoTracks.TrackAPrimeCover.execution
