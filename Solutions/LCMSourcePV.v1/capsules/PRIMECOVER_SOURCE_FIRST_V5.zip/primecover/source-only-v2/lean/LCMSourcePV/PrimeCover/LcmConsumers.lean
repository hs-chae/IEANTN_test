import E1Tertiary.LcmFinal
import E1TwoTracks.TrackAFinal
import E1TwoTracks.TrackAHighFinal
import ExposureEvolution.SharpSurplus
import ExposureEvolution.Strong45
import ExposureEvolution.PrimeCover1024

/- The two tail proofs below retain the exact original claims, parameters and
proof bodies from ExposureEvolution.Final and Final45. Their finite adaptive
branches are separately owned by the parent project. These source-provider
consumers do not import those still separately migrating numerical branches. -/
namespace LCMSourcePV.PrimeCover.LcmConsumers
open Real ExposureEvolution
lemma exp_nine_small : exp (9 : ℝ) < 8468 := by
  have he : exp 1 < (87 / 32 : ℝ) := by linarith [Real.exp_one_lt_d9]
  calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
    _ ≤ (87 / 32 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le he.le 9
    _ < 8468 := by norm_num

theorem tail256 (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 71707024 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hg : SharpConstant.StrictGap 8468 := PrimeCover.full_gap hd
  have hlog : (9 : ℝ) ≤ log 8468 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) exp_nine_small).le
  have hreal : (8468 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  obtain ⟨m, hm, hσ⟩ := SharpSurplus.quantitative_of_gap
    (c := 9) hg (by norm_num : (9 : ℝ) ≤ 9) hlog n hreal
  refine ⟨m, ?_, hm, hσ⟩
  by_contra hpos
  have hm0 : m = 0 := Nat.eq_zero_of_not_pos hpos
  have hσ' : (1 + 3 / (10 * (n : ℝ))) *
      (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) < 0 := by simpa [hm0] using hσ
  exact not_lt_of_ge (by positivity) hσ'

theorem tail1024 (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 3461204224 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 9 / (20 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have he : exp (9 : ℝ) < 58832 := by
    have he1 : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
    calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
      _ ≤ (3 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le he1.le 9
      _ < 58832 := by norm_num
  have hlog : (9 : ℝ) ≤ log 58832 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) he).le
  have hreal : (58832 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  exact Strong45.quantitative_of_gap (c := 9) (PrimeCover1024.full_gap hd)
    (by norm_num) hlog n hreal

#print axioms E1Tertiary.LcmFinal.quantitative4096
#print axioms E1Tertiary.LcmFinal.quantitative
#print axioms E1TwoTracks.TrackAFinal.quantitative
#print axioms E1TwoTracks.TrackAHighFinal.quantitative
#print axioms tail256
#print axioms tail1024
end LCMSourcePV.PrimeCover.LcmConsumers
