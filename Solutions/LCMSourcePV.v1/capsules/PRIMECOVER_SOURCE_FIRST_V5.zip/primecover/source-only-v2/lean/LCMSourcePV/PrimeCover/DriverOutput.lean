import LCMSourcePV.PrimeCover.DriverExecution

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.Driver

/-- Output of the proved actual main, after its count header. This reads the
source-model stdout produced by global initialization, actual constructor
execution and checked CStdIO calls; it is not an embedded prime table. -/
noncomputable def finalState {text : String} {p : Inputs} {output : List Nat}
    (binding : RestrictedC.SourceCorresponds render text p)
    (trace : CoverTrace p.den p.tail p.capacity p.start output)
    (words : AST.C.InputWords p.start p.tail p.den p.capacity)
    (positive : 0<p.capacity) (space : 8+8*p.capacity<wordMod) : State :=
  Classical.choose (complete binding trace words positive space).2.2.2

theorem final_words {text : String} {p : Inputs} {output : List Nat}
    (binding : RestrictedC.SourceCorresponds render text p)
    (trace : CoverTrace p.den p.tail p.capacity p.start output)
    (words : AST.C.InputWords p.start p.tail p.den p.capacity)
    (positive : 0<p.capacity) (space : 8+8*p.capacity<wordMod) :
    (finalState binding trace words positive space).written=output.length::output :=
  (Classical.choose_spec (complete binding trace words positive space).2.2.2).2

noncomputable def emitted {text : String} {p : Inputs} {output : List Nat}
    (binding : RestrictedC.SourceCorresponds render text p)
    (trace : CoverTrace p.den p.tail p.capacity p.start output)
    (words : AST.C.InputWords p.start p.tail p.den p.capacity)
    (positive : 0<p.capacity) (space : 8+8*p.capacity<wordMod) : List Nat :=
  (finalState binding trace words positive space).written.tail

theorem emitted_eq {text : String} {p : Inputs} {output : List Nat}
    (binding : RestrictedC.SourceCorresponds render text p)
    (trace : CoverTrace p.den p.tail p.capacity p.start output)
    (words : AST.C.InputWords p.start p.tail p.den p.capacity)
    (positive : 0<p.capacity) (space : 8+8*p.capacity<wordMod) :
    emitted binding trace words positive space=output := by
  unfold emitted
  rw [final_words]
  rfl

theorem emitted_checked {text : String} {p : Inputs} {output : List Nat}
    (binding : RestrictedC.SourceCorresponds render text p)
    (trace : CoverTrace p.den p.tail p.capacity p.start output)
    (words : AST.C.InputWords p.start p.tail p.den p.capacity)
    (positive : 0<p.capacity) (space : 8+8*p.capacity<wordMod) :
    Math.check p.den p.start p.tail (emitted binding trace words positive space)=true := by
  rw [emitted_eq]
  exact trace_check trace

theorem emitted_source {text : String} {p : Inputs} {output : List Nat}
    (binding : RestrictedC.SourceCorresponds render text p)
    (trace : CoverTrace p.den p.tail p.capacity p.start output)
    (words : AST.C.InputWords p.start p.tail p.den p.capacity)
    (positive : 0<p.capacity) (space : 8+8*p.capacity<wordMod) :
    Complete text p (emitted binding trace words positive space) := by
  rw [emitted_eq]
  exact complete binding trace words positive space

#print axioms emitted_checked
#print axioms emitted_source
end LCMSourcePV.PrimeCover.Driver
