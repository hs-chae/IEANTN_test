import LCMSourcePV.PrimeCover.Source
import LCMSourcePV.PrimeCover.Memory
import LCMSourcePV.ASTLoops

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.AST
namespace C
open LCMSourcePV.Witness.C

/-- Structural translation of the already source-bound tree. All source
operations, expressions and control statements are translated individually. -/
def expr : Source.Expr → Expr
  | .lit n => .nat n
  | .var v => .var (Source.varText v)
  | .maxWord => .var "UINT64_MAX"
  | .binary op a b => .binary (Source.binText op) (expr a) (expr b)
  | .call1 f a => .call (.var (Source.fnText f)) [expr a]
  | .call2 f a b => .call (.var (Source.fnText f)) [expr a,expr b]

def update : Source.Update → Expr
  | .increment v => .unary "++" (.var (Source.varText v))
  | .decrement v => .unary "--" (.var (Source.varText v))

def stmt : Source.Stmt → Stmt
  | .empty => .skip
  | .sequence a b => .sequence [stmt a,stmt b]
  | .declare v e => .declare [⟨"uint64_t",Source.varText v,some (expr e)⟩]
  | .assign v e => .eval (.binary "=" (.var (Source.varText v)) (expr e))
  | .store base index value => .eval (.binary "=" (.index (expr base) (expr index)) (expr value))
  | .update op => .eval (update op)
  | .returnValue e => .returnStmt (expr e)
  | .ifReturn condition value => .branch (expr condition) (.returnStmt (expr value)) .skip
  | .whileLoop condition body => .whileLoop (expr condition) (stmt body)
  | .forLoop v init condition step body =>
      .forLoop (.declare [⟨"uint64_t",Source.varText v,some (expr init)⟩])
        (some (expr condition)) (update step) (stmt body)

abbrev Env := String → Option Nat
abbrev Service := String → List Nat → Option Nat

def bind (env : Env) (key : String) (value : Nat) : Env :=
  fun name => if name == key then some value else env name
def emptyEnv : Env := fun _ => none

structure Heap where
  base : Nat
  extent : Nat
  words : Nat → Nat

structure State where
  env : Env
  heap : Heap

def heapOf (state : CState) : Heap := ⟨state.base,state.extent,state.buffer⟩

def truth (n : Nat) : Bool := n != 0
def bool (p : Prop) [Decidable p] : Nat := if p then 1 else 0

/-- Exact C uint64 operations; division and remainder reject zero. -/
def binary (op : String) (a b : Nat) : Option Nat :=
  if op == "+" then some ((a+b)%wordMod)
  else if op == "-" then some ((a+wordMod-b)%wordMod)
  else if op == "*" then some ((a*b)%wordMod)
  else if op == "/" then if b=0 then none else some (a/b)
  else if op == "%" then if b=0 then none else some (a%b)
  else if op == "<" then some (bool (a<b))
  else if op == "<=" then some (bool (a≤b))
  else if op == ">" then some (bool (b<a))
  else if op == "==" then some (bool (a=b))
  else none

/-- Pure source expressions. Calls are modular and receive actual evaluated
arguments; each selected service is separately refined to its real AST body. -/
def evalPure (call : Service) (env : Env) : Nat → Expr → Option Nat
  | 0,_ => none
  | fuel+1,.nat n => some (n%wordMod)
  | fuel+1,.var name => if name == "UINT64_MAX" then some (wordMod-1) else env name
  | fuel+1,.binary "&&" a b => do
      let x ← evalPure call env fuel a
      if truth x then pure (bool ((←evalPure call env fuel b)≠0)) else pure 0
  | fuel+1,.binary "||" a b => do
      let x ← evalPure call env fuel a
      if truth x then pure 1 else pure (bool ((←evalPure call env fuel b)≠0))
  | fuel+1,.binary op a b => do
      binary op (←evalPure call env fuel a) (←evalPure call env fuel b)
  | fuel+1,.call (.var name) args => do
      call name (←args.mapM (evalPure call env fuel))
  | _,_ => none

def store (heap : Heap) (base index value : Nat) : Option Heap :=
  if base=heap.base ∧ index<heap.extent ∧ base+8*index<wordMod ∧ value<wordMod then
    some {heap with words:=fun i=>if i=index then value else heap.words i}
  else none

/-- Standalone C assignment, checked indexed store, preincrement/decrement,
and pure expression evaluation. Locals are scalar registers: the selected
functions take no local address and have no observable shadowed local. -/
def eval (call : Service) (s : State) : Expr → Option (State × Nat)
  | .binary "=" (.var name) rhs => do
      let _ ← s.env name
      let value ← evalPure call s.env 100 rhs
      pure ({s with env:=bind s.env name value},value)
  | .binary "=" (.index base index) rhs => do
      let b ← evalPure call s.env 100 base
      let i ← evalPure call s.env 100 index
      let value ← evalPure call s.env 100 rhs
      let heap ← store s.heap b i value
      pure ({s with heap:=heap},value)
  | .unary "++" (.var name) => do
      let old ← s.env name
      let value := (old+1)%wordMod
      pure ({s with env:=bind s.env name value},value)
  | .unary "--" (.var name) => do
      let old ← s.env name
      let value := (old+wordMod-1)%wordMod
      pure ({s with env:=bind s.env name value},value)
  | e => do pure (s,←evalPure call s.env 100 e)

def declare (call : Service) (ds : List Decl) (s : State) : Option State :=
  ds.foldlM (fun state d => do
    if d.type != "uint64_t" then none else
      let initial ← d.value
      let value ← evalPure call state.env 100 initial
      pure {state with env:=bind state.env d.name value}) s

def Eval (call : Service) (e : Expr) (s t : State) (value : Nat) : Prop :=
  eval call s e=some (t,value)
def Declare (call : Service) (ds : List Decl) (s t : State) : Prop :=
  declare call ds s=some t
def Scope (_ : State) (inner outer : ASTLoops.Flow State Nat) : Prop := outer=inner
abbrev Flow := ASTLoops.Flow State Nat
abbrev Run (call : Service) := ASTLoops.StmtRun (Eval call) (Declare call) truth Scope
abbrev SeqRun (call : Service) := ASTLoops.SeqRun (Eval call) (Declare call) truth Scope
abbrev ForRun (call : Service) := ASTLoops.ForRun (Eval call) (Declare call) truth Scope
abbrev WhileRun (call : Service) := ASTLoops.WhileRun (Eval call) (Declare call) truth Scope

theorem bind_same (env : Env) (key : String) (x y : Nat) :
    bind (bind env key x) key y=bind env key y := by
  funext name
  by_cases h : name=key <;> simp [bind,h]

theorem singleton {call : Service} {body : Stmt} {s : State} {out : Flow}
    (run : Run call body s out) : SeqRun call [body] s out := by
  cases out with
  | continuing t => exact ASTLoops.SeqRun.next run (ASTLoops.SeqRun.nil t)
  | returned t value => exact ASTLoops.SeqRun.returned run

theorem sequence2 {call : Service} {a b : Stmt} {s t : State} {out : Flow}
    (first : Run call a s (.continuing t)) (second : Run call b t out) :
    Run call (.sequence [a,b]) s out :=
  ASTLoops.StmtRun.sequence (ASTLoops.SeqRun.next first (singleton second)) rfl

theorem sequence2_returned {call : Service} {a b : Stmt} {s t : State} {value : Nat}
    (first : Run call a s (.returned t value)) :
    Run call (.sequence [a,b]) s (.returned t value) :=
  ASTLoops.StmtRun.sequence (ASTLoops.SeqRun.returned first) rfl

#print axioms bind_same
end C
end LCMSourcePV.PrimeCover.AST
