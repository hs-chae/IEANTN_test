import LucasCore
import LCMSourcePV.PrimeFacts.H00C000
import LCMSourcePV.PrimeFacts.H01C000
import LCMSourcePV.PrimeFacts.H02C000
import LCMSourcePV.PrimeFacts.H03C000
import LCMSourcePV.PrimeFacts.H03C001
import LCMSourcePV.PrimeFacts.H03C002
import LCMSourcePV.PrimeFacts.H03C003
import LCMSourcePV.PrimeFacts.H03C004
import LCMSourcePV.PrimeFacts.H03C005
import LCMSourcePV.PrimeFacts.H03C006
import LCMSourcePV.PrimeFacts.H03C007
import LCMSourcePV.PrimeFacts.H03C008
import LCMSourcePV.PrimeFacts.H03C009
import LCMSourcePV.PrimeFacts.H03C010
import LCMSourcePV.PrimeFacts.H03C011
import LCMSourcePV.PrimeFacts.H03C012
namespace LCMSourcePV.PrimeFacts
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem prime_60169 : Nat.Prime 60169 := by
  refine Round2Recovery.lucas_list_prime (n := 60169) (a := 11)
    (factors := [2, 2, 2, 3, 23, 109]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_23 | exact prime_109
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60223 : Nat.Prime 60223 := by
  refine Round2Recovery.lucas_list_prime (n := 60223) (a := 3)
    (factors := [2, 3, 10037]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_10037
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60259 : Nat.Prime 60259 := by
  refine Round2Recovery.lucas_list_prime (n := 60259) (a := 3)
    (factors := [2, 3, 11, 11, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60373 : Nat.Prime 60373 := by
  refine Round2Recovery.lucas_list_prime (n := 60373) (a := 2)
    (factors := [2, 2, 3, 3, 3, 13, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60427 : Nat.Prime 60427 := by
  refine Round2Recovery.lucas_list_prime (n := 60427) (a := 3)
    (factors := [2, 3, 3, 3, 3, 373]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_373
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60457 : Nat.Prime 60457 := by
  refine Round2Recovery.lucas_list_prime (n := 60457) (a := 13)
    (factors := [2, 2, 2, 3, 11, 229]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_229
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60521 : Nat.Prime 60521 := by
  refine Round2Recovery.lucas_list_prime (n := 60521) (a := 3)
    (factors := [2, 2, 2, 5, 17, 89]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_17 | exact prime_89
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60703 : Nat.Prime 60703 := by
  refine Round2Recovery.lucas_list_prime (n := 60703) (a := 3)
    (factors := [2, 3, 67, 151]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_67 | exact prime_151
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60821 : Nat.Prime 60821 := by
  refine Round2Recovery.lucas_list_prime (n := 60821) (a := 2)
    (factors := [2, 2, 5, 3041]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_3041
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60859 : Nat.Prime 60859 := by
  refine Round2Recovery.lucas_list_prime (n := 60859) (a := 3)
    (factors := [2, 3, 3, 3, 7, 7, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60919 : Nat.Prime 60919 := by
  refine Round2Recovery.lucas_list_prime (n := 60919) (a := 3)
    (factors := [2, 3, 11, 13, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_13 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60923 : Nat.Prime 60923 := by
  refine Round2Recovery.lucas_list_prime (n := 60923) (a := 2)
    (factors := [2, 83, 367]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_83 | exact prime_367
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_60961 : Nat.Prime 60961 := by
  refine Round2Recovery.lucas_list_prime (n := 60961) (a := 7)
    (factors := [2, 2, 2, 2, 2, 3, 5, 127]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_127
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_61057 : Nat.Prime 61057 := by
  refine Round2Recovery.lucas_list_prime (n := 61057) (a := 5)
    (factors := [2, 2, 2, 2, 2, 2, 2, 3, 3, 53]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_53
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_61091 : Nat.Prime 61091 := by
  refine Round2Recovery.lucas_list_prime (n := 61091) (a := 2)
    (factors := [2, 5, 41, 149]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_41 | exact prime_149
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_61471 : Nat.Prime 61471 := by
  refine Round2Recovery.lucas_list_prime (n := 61471) (a := 3)
    (factors := [2, 3, 3, 5, 683]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_683
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_61487 : Nat.Prime 61487 := by
  refine Round2Recovery.lucas_list_prime (n := 61487) (a := 5)
    (factors := [2, 71, 433]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_71 | exact prime_433
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_61613 : Nat.Prime 61613 := by
  refine Round2Recovery.lucas_list_prime (n := 61613) (a := 2)
    (factors := [2, 2, 73, 211]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_73 | exact prime_211
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_61673 : Nat.Prime 61673 := by
  refine Round2Recovery.lucas_list_prime (n := 61673) (a := 5)
    (factors := [2, 2, 2, 13, 593]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_593
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_61781 : Nat.Prime 61781 := by
  refine Round2Recovery.lucas_list_prime (n := 61781) (a := 2)
    (factors := [2, 2, 5, 3089]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_3089
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_61933 : Nat.Prime 61933 := by
  refine Round2Recovery.lucas_list_prime (n := 61933) (a := 5)
    (factors := [2, 2, 3, 13, 397]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_397
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62201 : Nat.Prime 62201 := by
  refine Round2Recovery.lucas_list_prime (n := 62201) (a := 3)
    (factors := [2, 2, 2, 5, 5, 311]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_311
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62351 : Nat.Prime 62351 := by
  refine Round2Recovery.lucas_list_prime (n := 62351) (a := 7)
    (factors := [2, 5, 5, 29, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_29 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62383 : Nat.Prime 62383 := by
  refine Round2Recovery.lucas_list_prime (n := 62383) (a := 5)
    (factors := [2, 3, 37, 281]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_37 | exact prime_281
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62539 : Nat.Prime 62539 := by
  refine Round2Recovery.lucas_list_prime (n := 62539) (a := 2)
    (factors := [2, 3, 7, 1489]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_1489
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62597 : Nat.Prime 62597 := by
  refine Round2Recovery.lucas_list_prime (n := 62597) (a := 2)
    (factors := [2, 2, 15649]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_15649
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62617 : Nat.Prime 62617 := by
  refine Round2Recovery.lucas_list_prime (n := 62617) (a := 5)
    (factors := [2, 2, 2, 3, 2609]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_2609
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62683 : Nat.Prime 62683 := by
  refine Round2Recovery.lucas_list_prime (n := 62683) (a := 3)
    (factors := [2, 3, 31, 337]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_31 | exact prime_337
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62873 : Nat.Prime 62873 := by
  refine Round2Recovery.lucas_list_prime (n := 62873) (a := 3)
    (factors := [2, 2, 2, 29, 271]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_29 | exact prime_271
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62929 : Nat.Prime 62929 := by
  refine Round2Recovery.lucas_list_prime (n := 62929) (a := 14)
    (factors := [2, 2, 2, 2, 3, 3, 19, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_19 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_62989 : Nat.Prime 62989 := by
  refine Round2Recovery.lucas_list_prime (n := 62989) (a := 2)
    (factors := [2, 2, 3, 29, 181]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_29 | exact prime_181
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63031 : Nat.Prime 63031 := by
  refine Round2Recovery.lucas_list_prime (n := 63031) (a := 3)
    (factors := [2, 3, 5, 11, 191]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_11 | exact prime_191
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63079 : Nat.Prime 63079 := by
  refine Round2Recovery.lucas_list_prime (n := 63079) (a := 3)
    (factors := [2, 3, 10513]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_10513
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63211 : Nat.Prime 63211 := by
  refine Round2Recovery.lucas_list_prime (n := 63211) (a := 7)
    (factors := [2, 3, 5, 7, 7, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63247 : Nat.Prime 63247 := by
  refine Round2Recovery.lucas_list_prime (n := 63247) (a := 5)
    (factors := [2, 3, 83, 127]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_83 | exact prime_127
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63281 : Nat.Prime 63281 := by
  refine Round2Recovery.lucas_list_prime (n := 63281) (a := 6)
    (factors := [2, 2, 2, 2, 5, 7, 113]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7 | exact prime_113
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63409 : Nat.Prime 63409 := by
  refine Round2Recovery.lucas_list_prime (n := 63409) (a := 7)
    (factors := [2, 2, 2, 2, 3, 1321]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1321
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63467 : Nat.Prime 63467 := by
  refine Round2Recovery.lucas_list_prime (n := 63467) (a := 2)
    (factors := [2, 13, 2441]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_2441
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63589 : Nat.Prime 63589 := by
  refine Round2Recovery.lucas_list_prime (n := 63589) (a := 2)
    (factors := [2, 2, 3, 7, 757]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_757
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63667 : Nat.Prime 63667 := by
  refine Round2Recovery.lucas_list_prime (n := 63667) (a := 2)
    (factors := [2, 3, 3, 3, 3, 3, 131]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_131
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63913 : Nat.Prime 63913 := by
  refine Round2Recovery.lucas_list_prime (n := 63913) (a := 13)
    (factors := [2, 2, 2, 3, 2663]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_2663
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_63929 : Nat.Prime 63929 := by
  refine Round2Recovery.lucas_list_prime (n := 63929) (a := 3)
    (factors := [2, 2, 2, 61, 131]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_61 | exact prime_131
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64007 : Nat.Prime 64007 := by
  refine Round2Recovery.lucas_list_prime (n := 64007) (a := 5)
    (factors := [2, 32003]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_32003
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_64067 : Nat.Prime 64067 := by
  refine Round2Recovery.lucas_list_prime (n := 64067) (a := 5)
    (factors := [2, 103, 311]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_103 | exact prime_311
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64123 : Nat.Prime 64123 := by
  refine Round2Recovery.lucas_list_prime (n := 64123) (a := 2)
    (factors := [2, 3, 10687]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_10687
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64157 : Nat.Prime 64157 := by
  refine Round2Recovery.lucas_list_prime (n := 64157) (a := 2)
    (factors := [2, 2, 43, 373]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_43 | exact prime_373
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64171 : Nat.Prime 64171 := by
  refine Round2Recovery.lucas_list_prime (n := 64171) (a := 7)
    (factors := [2, 3, 3, 5, 23, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_23 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64237 : Nat.Prime 64237 := by
  refine Round2Recovery.lucas_list_prime (n := 64237) (a := 2)
    (factors := [2, 2, 3, 53, 101]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_53 | exact prime_101
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64381 : Nat.Prime 64381 := by
  refine Round2Recovery.lucas_list_prime (n := 64381) (a := 2)
    (factors := [2, 2, 3, 5, 29, 37]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_29 | exact prime_37
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64439 : Nat.Prime 64439 := by
  refine Round2Recovery.lucas_list_prime (n := 64439) (a := 7)
    (factors := [2, 11, 29, 101]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_29 | exact prime_101
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64661 : Nat.Prime 64661 := by
  refine Round2Recovery.lucas_list_prime (n := 64661) (a := 2)
    (factors := [2, 2, 5, 53, 61]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_53 | exact prime_61
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_64667 : Nat.Prime 64667 := by
  refine Round2Recovery.lucas_list_prime (n := 64667) (a := 2)
    (factors := [2, 7, 31, 149]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_31 | exact prime_149
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65173 : Nat.Prime 65173 := by
  refine Round2Recovery.lucas_list_prime (n := 65173) (a := 2)
    (factors := [2, 2, 3, 5431]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5431
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65239 : Nat.Prime 65239 := by
  refine Round2Recovery.lucas_list_prime (n := 65239) (a := 3)
    (factors := [2, 3, 83, 131]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_83 | exact prime_131
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65327 : Nat.Prime 65327 := by
  refine Round2Recovery.lucas_list_prime (n := 65327) (a := 5)
    (factors := [2, 89, 367]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_89 | exact prime_367
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65497 : Nat.Prime 65497 := by
  refine Round2Recovery.lucas_list_prime (n := 65497) (a := 7)
    (factors := [2, 2, 2, 3, 2729]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_2729
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65557 : Nat.Prime 65557 := by
  refine Round2Recovery.lucas_list_prime (n := 65557) (a := 5)
    (factors := [2, 2, 3, 3, 3, 607]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_607
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65633 : Nat.Prime 65633 := by
  refine Round2Recovery.lucas_list_prime (n := 65633) (a := 3)
    (factors := [2, 2, 2, 2, 2, 7, 293]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_293
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65677 : Nat.Prime 65677 := by
  refine Round2Recovery.lucas_list_prime (n := 65677) (a := 2)
    (factors := [2, 2, 3, 13, 421]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_421
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65731 : Nat.Prime 65731 := by
  refine Round2Recovery.lucas_list_prime (n := 65731) (a := 10)
    (factors := [2, 3, 5, 7, 313]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7 | exact prime_313
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65851 : Nat.Prime 65851 := by
  refine Round2Recovery.lucas_list_prime (n := 65851) (a := 3)
    (factors := [2, 3, 5, 5, 439]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_439
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_65993 : Nat.Prime 65993 := by
  refine Round2Recovery.lucas_list_prime (n := 65993) (a := 3)
    (factors := [2, 2, 2, 73, 113]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_73 | exact prime_113
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66179 : Nat.Prime 66179 := by
  refine Round2Recovery.lucas_list_prime (n := 66179) (a := 2)
    (factors := [2, 7, 29, 163]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_29 | exact prime_163
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66221 : Nat.Prime 66221 := by
  refine Round2Recovery.lucas_list_prime (n := 66221) (a := 2)
    (factors := [2, 2, 5, 7, 11, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7 | exact prime_11 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66361 : Nat.Prime 66361 := by
  refine Round2Recovery.lucas_list_prime (n := 66361) (a := 17)
    (factors := [2, 2, 2, 3, 5, 7, 79]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7 | exact prime_79
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66593 : Nat.Prime 66593 := by
  refine Round2Recovery.lucas_list_prime (n := 66593) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2081]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_2081
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66617 : Nat.Prime 66617 := by
  refine Round2Recovery.lucas_list_prime (n := 66617) (a := 3)
    (factors := [2, 2, 2, 11, 757]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_757
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66653 : Nat.Prime 66653 := by
  refine Round2Recovery.lucas_list_prime (n := 66653) (a := 2)
    (factors := [2, 2, 19, 877]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19 | exact prime_877
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66763 : Nat.Prime 66763 := by
  refine Round2Recovery.lucas_list_prime (n := 66763) (a := 3)
    (factors := [2, 3, 3, 3709]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_3709
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66863 : Nat.Prime 66863 := by
  refine Round2Recovery.lucas_list_prime (n := 66863) (a := 5)
    (factors := [2, 101, 331]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_101 | exact prime_331
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66883 : Nat.Prime 66883 := by
  refine Round2Recovery.lucas_list_prime (n := 66883) (a := 2)
    (factors := [2, 3, 71, 157]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_71 | exact prime_157
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_66977 : Nat.Prime 66977 := by
  refine Round2Recovery.lucas_list_prime (n := 66977) (a := 5)
    (factors := [2, 2, 2, 2, 2, 7, 13, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_13 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67003 : Nat.Prime 67003 := by
  refine Round2Recovery.lucas_list_prime (n := 67003) (a := 2)
    (factors := [2, 3, 13, 859]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_859
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67141 : Nat.Prime 67141 := by
  refine Round2Recovery.lucas_list_prime (n := 67141) (a := 2)
    (factors := [2, 2, 3, 3, 5, 373]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_373
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67231 : Nat.Prime 67231 := by
  refine Round2Recovery.lucas_list_prime (n := 67231) (a := 3)
    (factors := [2, 3, 3, 3, 3, 5, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67289 : Nat.Prime 67289 := by
  refine Round2Recovery.lucas_list_prime (n := 67289) (a := 3)
    (factors := [2, 2, 2, 13, 647]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_647
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67349 : Nat.Prime 67349 := by
  refine Round2Recovery.lucas_list_prime (n := 67349) (a := 2)
    (factors := [2, 2, 113, 149]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_113 | exact prime_149
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67511 : Nat.Prime 67511 := by
  refine Round2Recovery.lucas_list_prime (n := 67511) (a := 11)
    (factors := [2, 5, 43, 157]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_43 | exact prime_157
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67577 : Nat.Prime 67577 := by
  refine Round2Recovery.lucas_list_prime (n := 67577) (a := 3)
    (factors := [2, 2, 2, 8447]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_8447
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67723 : Nat.Prime 67723 := by
  refine Round2Recovery.lucas_list_prime (n := 67723) (a := 5)
    (factors := [2, 3, 11287]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11287
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67819 : Nat.Prime 67819 := by
  refine Round2Recovery.lucas_list_prime (n := 67819) (a := 10)
    (factors := [2, 3, 89, 127]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_89 | exact prime_127
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67943 : Nat.Prime 67943 := by
  refine Round2Recovery.lucas_list_prime (n := 67943) (a := 5)
    (factors := [2, 7, 23, 211]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_23 | exact prime_211
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68059 : Nat.Prime 68059 := by
  refine Round2Recovery.lucas_list_prime (n := 68059) (a := 2)
    (factors := [2, 3, 3, 19, 199]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_19 | exact prime_199
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68113 : Nat.Prime 68113 := by
  refine Round2Recovery.lucas_list_prime (n := 68113) (a := 5)
    (factors := [2, 2, 2, 2, 3, 3, 11, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68161 : Nat.Prime 68161 := by
  refine Round2Recovery.lucas_list_prime (n := 68161) (a := 13)
    (factors := [2, 2, 2, 2, 2, 2, 3, 5, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68209 : Nat.Prime 68209 := by
  refine Round2Recovery.lucas_list_prime (n := 68209) (a := 13)
    (factors := [2, 2, 2, 2, 3, 7, 7, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68227 : Nat.Prime 68227 := by
  refine Round2Recovery.lucas_list_prime (n := 68227) (a := 2)
    (factors := [2, 3, 83, 137]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_83 | exact prime_137
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68311 : Nat.Prime 68311 := by
  refine Round2Recovery.lucas_list_prime (n := 68311) (a := 6)
    (factors := [2, 3, 3, 3, 5, 11, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_11 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68399 : Nat.Prime 68399 := by
  refine Round2Recovery.lucas_list_prime (n := 68399) (a := 7)
    (factors := [2, 11, 3109]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_3109
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68449 : Nat.Prime 68449 := by
  refine Round2Recovery.lucas_list_prime (n := 68449) (a := 7)
    (factors := [2, 2, 2, 2, 2, 3, 23, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_23 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68581 : Nat.Prime 68581 := by
  refine Round2Recovery.lucas_list_prime (n := 68581) (a := 6)
    (factors := [2, 2, 3, 3, 3, 5, 127]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_127
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68633 : Nat.Prime 68633 := by
  refine Round2Recovery.lucas_list_prime (n := 68633) (a := 3)
    (factors := [2, 2, 2, 23, 373]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_23 | exact prime_373
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68699 : Nat.Prime 68699 := by
  refine Round2Recovery.lucas_list_prime (n := 68699) (a := 2)
    (factors := [2, 7, 7, 701]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_701
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_68749 : Nat.Prime 68749 := by
  refine Round2Recovery.lucas_list_prime (n := 68749) (a := 6)
    (factors := [2, 2, 3, 17, 337]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_17 | exact prime_337
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_69011 : Nat.Prime 69011 := by
  refine Round2Recovery.lucas_list_prime (n := 69011) (a := 6)
    (factors := [2, 5, 67, 103]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_67 | exact prime_103
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_69127 : Nat.Prime 69127 := by
  refine Round2Recovery.lucas_list_prime (n := 69127) (a := 5)
    (factors := [2, 3, 41, 281]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_41 | exact prime_281
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

end LCMSourcePV.PrimeFacts
