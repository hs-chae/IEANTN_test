import LCMSourcePV.PrimeCover.ASTCoverBody

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.AST.C
open LCMSourcePV.Witness.C

theorem trace_while_refines {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (call : Service) (correct : NextCorrect call) :
    ∀(state : CState) (s : State) (prior : List Nat) capacity,
      Good capacity state → Stored state prior → CoverRep den tail capacity state s →
      state.a=a → state.count+fuel=capacity →
      ∃(final : CState) (t : State),
        WhileRun call coverCondition coverBody s (.continuing t) ∧
        CoverRep den tail capacity final t ∧ Stored final (prior++ps) ∧
        final.returned=some (prior.length+ps.length) ∧ tail≤final.a ∧ Good capacity final ∧ final.base=state.base := by
  induction trace with
  | done fuel a stop =>
    intro state s prior capacity good stored rep ha hcap
    refine ⟨finish state,s,?_,?_,?_,?_,?_,?_,rfl⟩
    · exact ASTLoops.WhileRun.done (cover_condition_eval rep)
        (by
          have hstop : ¬state.a<tail := by omega
          simp [truth,bool,hstop])
    · simpa [CoverRep,finish,heapOf] using rep
    · simpa [Stored,finish] using stored
    · simp [finish,stored.1]
    · simpa [finish,ha] using stop
    · simpa [Good,finish] using good
  | step fuel a p ps active allowed next rest ih =>
    intro state s prior capacity good stored rep ha hcap
    have hcount : state.count<capacity := by omega
    have sourceAllowed : NextAllowed state.a den := by simpa [ha] using allowed
    have sourceNext : Math.next den state.a=some p := by simpa [ha] using next
    have link := next_some_link sourceAllowed sourceNext
    obtain ⟨sNext,bodyRun,repNext⟩ :=
      cover_body_refines correct rep good hcount sourceAllowed sourceNext
    have newgood := advance_good good hcount link.2.2.2
    have newstored := advance_stored good hcount stored p
    have hnewcap : (advance state p).count+fuel=capacity := by
      change bump state.count+fuel=capacity
      rw [count_bump good hcount]
      omega
    obtain ⟨final,t,run,repFinal,written,returned,endpoint,goodFinal,baseFinal⟩ :=
      ih (advance state p) sNext (prior++[p]) capacity newgood newstored repNext rfl hnewcap
    refine ⟨final,t,?_,repFinal,?_,?_,endpoint,goodFinal,baseFinal⟩
    · exact ASTLoops.WhileRun.next (cover_condition_eval rep)
        (by
          have hactive : state.a<tail := by omega
          simp [truth,bool,hcount,hactive])
        bodyRun run
    · simpa [List.append_assoc] using written
    · simpa [List.length_append,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using returned

def coverInput (start tail den capacity : Nat) (heap : Heap) : State :=
  ⟨bind (bind (bind (bind (bind emptyEnv "start" start) "tail" tail)
    "den" den) "fuel" capacity) "out" heap.base,heap⟩
def coverDeclarationA : Stmt := .declare [⟨"uint64_t","a",some (.var "start")⟩]
def coverDeclarationCount : Stmt := .declare [⟨"uint64_t","count",some (.nat 0)⟩]
def coverEnd : Stmt := .sequence [.whileLoop coverCondition coverBody,
  .sequence [.returnStmt (.var "count"),.skip]]

theorem cover_source_shape : stmt Source.coverFunction.body =
    .sequence [coverDeclarationA,.sequence [coverDeclarationCount,coverEnd]] := rfl

def InputWords (start tail den capacity : Nat) : Prop :=
  start<wordMod ∧ tail<wordMod ∧ den<wordMod ∧ capacity<wordMod

/-- Complete statement-by-statement execution of the actual source cover
constructor, including initialization, its while loop, verified source helper
calls, checked array stores, counter update, assignment and final return. -/
theorem cover_function_refines {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (words : InputWords a tail den fuel)
    (space : 8+8*fuel<wordMod) :
    ∃(final : CState) (t : State),
      Run service (stmt Source.coverFunction.body)
        (coverInput a tail den fuel (heapOf (initial a fuel))) (.returned t ps.length) ∧
      t.heap=heapOf final ∧ Stored final ps ∧ tail≤final.a ∧ Good fuel final ∧ final.base=8 := by
  let input := coverInput a tail den fuel (heapOf (initial a fuel))
  let aState : State := {input with env:=bind input.env "a" a}
  let start : State := {aState with env:=bind aState.env "count" 0}
  have declA : Declare service [⟨"uint64_t","a",some (.var "start")⟩] input aState := by
    simp [Declare,declare,List.foldlM,evalPure,input,coverInput,aState,bind]
  have declCount : Declare service [⟨"uint64_t","count",some (.nat 0)⟩] aState start := by
    simp [Declare,declare,List.foldlM,evalPure,start]
  have rep : CoverRep den tail fuel (initial a fuel) start := by
    simp [CoverRep,start,aState,input,coverInput,bind,initial,heapOf]
  obtain ⟨final,t,loop,repFinal,written,returned,endpoint,goodFinal,baseFinal⟩ := trace_while_refines trace
    service service_next_correct (initial a fuel) start [] fuel
    (initial_good words.1 words.2.2.2 space) (initial_stored a fuel) rep rfl (by simp [initial])
  have stored : Stored final ps := by simpa using written
  have countRead : t.env "count"=some ps.length := by
    rw [←stored.1]
    exact repFinal.2.1
  refine ⟨final,t,?_,repFinal.2.2.2.2.2.2,stored,endpoint,goodFinal,baseFinal⟩
  rw [cover_source_shape]
  apply sequence2 (ASTLoops.StmtRun.declare declA)
  apply sequence2 (ASTLoops.StmtRun.declare declCount)
  apply sequence2 (ASTLoops.StmtRun.whileLoop loop)
  apply sequence2_returned
  exact ASTLoops.StmtRun.returnValue
    (show Eval service (.var "count") t t ps.length by simp [Eval,eval,evalPure,countRead])

/-- The full source-program endpoint includes the proved actual AST of both
modular callees. Every operational call is therefore source-refined, and the
constructor execution has no unproved actual-run or numerical premise. -/
def SourceProgramRun (start tail den capacity : Nat) (output : List Nat) : Prop :=
  RestrictedC.SourceCorresponds Source.render Source.actualSource Source.selectedProgram ∧
  InputWords start tail den capacity ∧
  (∀n result,PrimeExec n result → ∀heap,
    ∃t, Run service (stmt Source.primeFunction.body) (primeInput n heap) (.returned t result) ∧
      t.heap=heap) ∧
  (∀a d result,NextAllowed a d → NextExec a d result → ∀heap,
    ∃t, Run service (stmt Source.nextFunction.body) (nextInput a d heap) (.returned t result) ∧
      t.heap=heap) ∧
  ∃(final : CState) (t : State),
    Run service (stmt Source.coverFunction.body)
      (coverInput start tail den capacity (heapOf (initial start capacity)))
      (.returned t output.length) ∧
    t.heap=heapOf final ∧ Stored final output ∧ tail≤final.a ∧ Good capacity final ∧ final.base=8

theorem source_program_run {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (words : InputWords a tail den fuel)
    (space : 8+8*fuel<wordMod) : SourceProgramRun a tail den fuel ps :=
  ⟨Source.actual_source_checked,words,
    fun _ _ run heap => actual_prime_service run heap,
    fun _ _ _ allowed run heap => actual_next_service allowed run heap,
    cover_function_refines trace words space⟩

#print axioms cover_function_refines
#print axioms source_program_run
end LCMSourcePV.PrimeCover.AST.C
