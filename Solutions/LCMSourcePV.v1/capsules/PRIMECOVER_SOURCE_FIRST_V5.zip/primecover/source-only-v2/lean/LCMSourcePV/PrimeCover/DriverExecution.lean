import LCMSourcePV.PrimeCover.DriverSemantics

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.Driver
open LCMSourcePV.Witness.C

/-- Closed execution of the application main from the allocated zero array.
The actual constructor AST mutates that array; actual fwrite argument objects
and extents are checked before the two generic I/O calls. -/
theorem main_refines (p : Inputs) {output : List Nat}
    (trace : CoverTrace p.den p.tail p.capacity p.start output)
    (words : AST.C.InputWords p.start p.tail p.den p.capacity)
    (positive : 0<p.capacity) (space : 8+8*p.capacity<wordMod) :
    Initialize (array p) (initial p.capacity) ∧
    ∃final, Run (body p) (initial p.capacity) (.returned final 0) ∧
      final.written=output.length::output := by
  have initialized : Initialize (array p) (initial p.capacity) :=
    Initialize.zero p.capacity positive space
  obtain ⟨cFinal,cReturned,constructorRun,heap,stored,endpoint,good,base⟩ :=
    AST.C.cover_function_refines trace words space
  have lengthBound : output.length≤p.capacity := trace_length trace
  have countWord : output.length<wordMod := lt_of_le_of_lt lengthBound words.2.2.2
  let start := initial p.capacity
  let called : State := {start with machine:={start.machine with heap:=cReturned.heap}}
  let counted : State := {called with machine:={called.machine with
    env:=AST.C.bind called.machine.env "count" output.length}}
  let head : State := {counted with written:=counted.written++[output.length]}
  let payload : List Nat := List.ofFn fun i : Fin output.length => head.machine.heap.words i
  let final : State := {head with written:=head.written++payload}
  have arguments :
      [Expr.nat p.start,.nat p.tail,.nat p.den,.nat p.capacity,.var "pc_output"].mapM
        (AST.C.evalPure AST.C.service start.machine.env 100)=
      some [p.start,p.tail,p.den,p.capacity,8] := by
    simp [AST.C.evalPure,List.mapM_cons,List.mapM_nil,start,initial,AST.C.bind,
      Nat.mod_eq_of_lt words.1,Nat.mod_eq_of_lt words.2.1,
      Nat.mod_eq_of_lt words.2.2.1,Nat.mod_eq_of_lt words.2.2.2]
  have constructorEval : Eval (constructor p) start called output.length := by
    exact Eval.constructor arguments rfl rfl words constructorRun
  have declaration : Declare [⟨"uint64_t","count",some (constructor p)⟩] start counted :=
    Declare.cons rfl rfl constructorEval countWord (Declare.nil counted)
  have countRead : counted.machine.env "count"=some output.length := by
    simp [counted,AST.C.bind]
  have writeCount : Eval countWrite counted head 1 := by
    exact Eval.write (by simp [AST.C.evalPure,wordMod])
      (ObjectWords.localCount counted output.length countRead countWord)
  have headCount : head.machine.env "count"=some output.length := countRead
  have arrayPointer : head.machine.env "pc_output"=some head.machine.heap.base := by
    simp [head,counted,called,start,initial,AST.C.bind,heap,AST.C.heapOf,base]
  have arrayExtent : output.length ≤ head.machine.heap.extent := by
    change output.length≤cReturned.heap.extent
    rw [heap]
    change output.length≤cFinal.extent
    rw [good.2.2.2.1]
    exact lengthBound
  have arrayWords : ∀i,i<output.length → head.machine.heap.words i<wordMod := by
    intro i hi
    change cReturned.heap.words i<wordMod
    rw [heap]
    exact good.2.2.2.2.2.2.2 i (lt_of_lt_of_le hi lengthBound)
  have writeArray : Eval arrayWrite head final output.length := by
    exact Eval.write (by simp [AST.C.evalPure,headCount])
      (ObjectWords.outputArray head output.length arrayPointer arrayExtent arrayWords)
  have payload_eq : payload=output := by
    apply List.ext_getElem
    · simp [payload]
    · intro i hi hj
      simpa [payload,head,counted,called,heap,AST.C.heapOf] using stored.2 i hj
  have countCondition : Eval (.binary "==" countWrite (.nat 1)) counted head 1 :=
    Eval.binary writeCount (literal_one head) (by simp [AST.C.binary,AST.C.bool])
  have finalCount : final.machine.env "count"=some output.length := headCount
  have arrayCondition : Eval (.binary "==" arrayWrite (.var "count")) head final 1 := by
    apply Eval.binary writeArray (right:=output.length)
    · exact Eval.pure (machine:=final.machine) (value:=output.length)
        (by simp [AST.C.eval,AST.C.evalPure,finalCount])
    · simp [AST.C.binary,AST.C.bool]
  have inner : Run (.branch (.binary "==" arrayWrite (.var "count"))
      (.returnStmt (.nat 0)) .skip) head (.returned final 0) := by
    apply ASTLoops.StmtRun.branch arrayCondition
    simpa [AST.C.truth] using ASTLoops.StmtRun.returnValue (literal_zero final)
  have middle : Run (.sequence [
      .branch (.binary "==" arrayWrite (.var "count")) (.returnStmt (.nat 0)) .skip,
      .returnStmt (.nat 2)]) head (.returned final 0) :=
    ASTLoops.StmtRun.sequence (ASTLoops.SeqRun.returned inner) rfl
  have outer : Run (.branch (.binary "==" countWrite (.nat 1))
      (.sequence [
        .branch (.binary "==" arrayWrite (.var "count")) (.returnStmt (.nat 0)) .skip,
        .returnStmt (.nat 2)]) .skip) counted (.returned final 0) := by
    apply ASTLoops.StmtRun.branch countCondition
    simpa [AST.C.truth] using middle
  refine ⟨initialized,final,?_,?_⟩
  · exact ASTLoops.StmtRun.sequence
      (ASTLoops.SeqRun.next (ASTLoops.StmtRun.declare declaration)
        (ASTLoops.SeqRun.returned outer)) rfl
  · simp [final,head,counted,called,start,initial,payload_eq]

/-- Complete source-bound main endpoint; array initialization and call
association are proved application obligations. Generic compiler/ABI and
physical CStdIO execution remain explicitly outside the Lean kernel. -/
def Complete (text : String) (p : Inputs) (output : List Nat) : Prop :=
  RestrictedC.SourceCorresponds render text p ∧
  AST.C.SourceProgramRun p.start p.tail p.den p.capacity output ∧
  Initialize (array p) (initial p.capacity) ∧
  ∃final, Run (body p) (initial p.capacity) (.returned final 0) ∧
    final.written=output.length::output

theorem complete {text : String} {p : Inputs} {output : List Nat}
    (binding : RestrictedC.SourceCorresponds render text p)
    (trace : CoverTrace p.den p.tail p.capacity p.start output)
    (words : AST.C.InputWords p.start p.tail p.den p.capacity)
    (positive : 0<p.capacity) (space : 8+8*p.capacity<wordMod) : Complete text p output :=
  ⟨binding,AST.C.source_program_run trace words space,main_refines p trace words positive space⟩

#print axioms main_refines
#print axioms complete
end LCMSourcePV.PrimeCover.Driver
