import LCMSourcePV.PrimeCover.ASTRuntime

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.AST.C
open LCMSourcePV.Witness.C

def CoverRep (den tail capacity : Nat) (state : CState) (s : State) : Prop :=
  s.env "a"=some state.a ∧ s.env "count"=some state.count ∧
  s.env "den"=some den ∧ s.env "tail"=some tail ∧
  s.env "fuel"=some capacity ∧ s.env "out"=some state.base ∧ s.heap=heapOf state

def coverCondition : Expr := .binary "&&" (.binary "<" (.var "count") (.var "fuel"))
  (.binary "<" (.var "a") (.var "tail"))
def coverQuery : Expr := .call (.var "pc_next") [.var "a",.var "den"]
def coverTest : Expr := .binary "==" (.var "p") (.nat 0)
def coverStore : Expr := .binary "=" (.index (.var "out") (.var "count")) (.var "p")
def coverCount : Expr := .unary "++" (.var "count")
def coverAssign : Expr := .binary "=" (.var "a") (.var "p")
def coverBody : Stmt := .sequence [.declare [⟨"uint64_t","p",some coverQuery⟩],
  .sequence [.branch coverTest (.returnStmt (.var "count")) .skip,
  .sequence [.eval coverStore,.sequence [.eval coverCount,
  .sequence [.eval coverAssign,.skip]]]]]

theorem cover_condition_eval {call : Service} {den tail capacity : Nat}
    {state : CState} {s : State} (rep : CoverRep den tail capacity state s) :
    Eval call coverCondition s s (bool (state.count<capacity ∧ state.a<tail)) := by
  rcases rep with ⟨ha,hc,hd,ht,hf,ho,hh⟩
  by_cases active : state.count<capacity <;>
    simp [Eval,eval,evalPure,coverCondition,binary,ha,hc,ht,hf,bool,truth,active] <;>
    split_ifs <;> omega

theorem cover_body_refines {call : Service} (correct : NextCorrect call)
    {den tail capacity : Nat} {state : CState} {s : State} {p : Nat}
    (rep : CoverRep den tail capacity state s) (good : Good capacity state)
    (active : state.count<capacity) (allowed : NextAllowed state.a den)
    (next : Math.next den state.a=some p) :
    ∃t, Run call coverBody s (.continuing t) ∧
      CoverRep den tail capacity (advance state p) t := by
  rcases rep with ⟨ha,hc,hd,ht,hf,ho,hh⟩
  have link := next_some_link allowed next
  have pword : p<wordMod := link.2.2.2
  have positive : p≠0 := by have := link.2.1; omega
  have callResult := correct state.a den p allowed (next_exec_of_some allowed next)
  let called : State := {s with env:=bind s.env "p" p}
  let memory : Heap := {s.heap with words:=fun i=>if i=state.count then p else s.heap.words i}
  let written : State := {called with heap:=memory}
  let counted : State := {written with env:=bind written.env "count" (bump state.count)}
  let final : State := {counted with env:=bind counted.env "a" p}
  have declaration : Declare call [⟨"uint64_t","p",some coverQuery⟩] s called := by
    simp [Declare,declare,List.foldlM,evalPure,coverQuery,List.mapM_cons,List.mapM_nil,
      ha,hd,callResult,called]
  have test : Eval call coverTest called called 0 := by
    simp [Eval,eval,evalPure,coverTest,binary,bool,called,bind,positive]
  have hi : state.count<state.extent := by rw [good.2.2.2.1]; exact active
  have haddress : state.base+8*state.count<wordMod := by
    have := good.2.2.2.2.2.2.1
    omega
  have storeRun : Eval call coverStore called written p := by
    simp [Eval,eval,coverStore,evalPure,called,written,memory,bind,ho,hc,hh,
      store,heapOf,hi,haddress,pword]
  have countRun : Eval call coverCount written counted (bump state.count) := by
    simp [Eval,eval,coverCount,written,called,counted,bind,hc,bump]
  have assignRun : Eval call coverAssign counted final p := by
    simp [Eval,eval,coverAssign,evalPure,counted,written,called,final,bind,ha]
  refine ⟨final,?_,?_⟩
  · apply sequence2 (ASTLoops.StmtRun.declare declaration)
    apply sequence2
    · apply ASTLoops.StmtRun.branch test
      simpa [truth] using ASTLoops.StmtRun.skip called
    · apply sequence2 (ASTLoops.StmtRun.evaluate storeRun)
      apply sequence2 (ASTLoops.StmtRun.evaluate countRun)
      exact sequence2 (ASTLoops.StmtRun.evaluate assignRun) (ASTLoops.StmtRun.skip final)
  · refine ⟨?_,?_,?_,?_,?_,?_,?_⟩
    · simp [final,counted,written,called,bind,advance]
    · simp [final,counted,written,called,bind,advance]
    · simpa [final,counted,written,called,bind] using hd
    · simpa [final,counted,written,called,bind] using ht
    · simpa [final,counted,written,called,bind] using hf
    · simpa [final,counted,written,called,bind,advance] using ho
    · simp [final,counted,written,called,memory,hh,heapOf,advance,writeBuffer]
      rfl

#print axioms cover_body_refines
end LCMSourcePV.PrimeCover.AST.C
