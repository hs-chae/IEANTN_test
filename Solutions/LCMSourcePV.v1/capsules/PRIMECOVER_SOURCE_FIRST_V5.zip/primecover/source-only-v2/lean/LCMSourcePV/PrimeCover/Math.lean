import Mathlib

set_option autoImplicit false
set_option maxHeartbeats 0

namespace LCMSourcePV.PrimeCover.Math
open Real

def search (a : Nat) : Nat → Option Nat
  | 0 => none
  | k+1 => if Nat.Prime (a+1+k) then some (a+1+k) else search a k

def upper (den a : Nat) : Nat := ((den+1)*a-1)/den
def next (den a : Nat) : Option Nat := search a (upper den a-a)

def run (den : Nat) : Nat → Nat → Nat → List Nat
  | 0,_,_ => []
  | fuel+1,a,b => if b≤a then [] else
      match next den a with
      | none => []
      | some p => p :: run den fuel p b

def check (den a b : Nat) : List Nat → Bool
  | [] => decide (b≤a)
  | p::ps => decide (Nat.Prime p ∧ a<p ∧ den*p<(den+1)*a) && check den p b ps

theorem search_eq_original (a count : Nat) :
    search a count = (List.range count).reverse.findSome? (fun k =>
      let p := a+1+k
      if Nat.Prime p then some p else none) := by
  induction count with
  | zero => simp [search]
  | succ k ih =>
    by_cases hp : Nat.Prime (a+1+k)
    · simp [search,List.range_succ,List.reverse_append,ih,hp]
    · simp [search,List.range_succ,List.reverse_append,ih,hp]

theorem search_at_top {a p : Nat} (h : a<p) :
    search a (p-a) = if Nat.Prime p then some p else search a ((p-1)-a) := by
  have he : p-a=((p-1)-a)+1 := by omega
  rw [he,search]
  have hp : a+1+((p-1)-a)=p := by omega
  rw [hp]

theorem search_some_prime {a count p : Nat} (h : search a count=some p) :
    Nat.Prime p := by
  induction count with
  | zero => simp [search] at h
  | succ k ih =>
    by_cases hp : Nat.Prime (a+1+k)
    · simp only [search,if_pos hp,Option.some.injEq] at h
      simpa only [←h] using hp
    · exact ih (by simpa [search,hp] using h)

theorem search_max {a count p : Nat} (hp : Nat.Prime p) (ha : a<p)
    (hu : p≤a+count)
    (largest : ∀ q, p<q → q≤a+count → ¬ Nat.Prime q) :
    search a count=some p := by
  induction count with
  | zero => omega
  | succ k ih =>
    by_cases he : p=a+1+k
    · subst p
      simp [search,hp]
    · have hn : ¬ Nat.Prime (a+1+k) := largest _ (by omega) (by omega)
      simp only [search,if_neg hn]
      exact ih (by omega) (fun q hq hqu => largest q hq (by omega))

theorem next_max {den a p : Nat} (haUpper : a≤upper den a)
    (hp : Nat.Prime p) (ha : a<p) (hu : p≤upper den a)
    (largest : ∀ q, p<q → q≤upper den a → ¬ Nat.Prime q) :
    next den a=some p := by
  unfold next
  apply search_max hp ha (by omega)
  intro q hq hqu
  exact largest q hq (by omega)

/-- Unchanged all-real prime-cover consequence, with the ratio exposed as an
integer denominator. Natural subtraction is never used outside its source
domain in a proof-bearing clause. -/
theorem sound (den : Nat) (hden : 0<den) (ps : List Nat) {a b : Nat}
    (hc : check den a b ps=true) {x : ℝ} (ha : (a:ℝ)≤x) (hb : x<b) :
    ∃p:Nat, Nat.Prime p ∧ x<p ∧ (p:ℝ)<x+x/den := by
  induction ps generalizing a with
  | nil =>
    have hba : b≤a := by simpa [check] using hc
    have hr : (b:ℝ)≤a := by exact_mod_cast hba
    linarith
  | cons p ps ih =>
    have hh : (Nat.Prime p ∧ a<p ∧ den*p<(den+1)*a) ∧ check den p b ps=true := by
      simpa [check] using hc
    by_cases hxp : x<(p:ℝ)
    · refine ⟨p,hh.1.1,hxp,?_⟩
      have hr : (den:ℝ)*p<((den:ℝ)+1)*a := by exact_mod_cast hh.1.2.2
      have hd0 : (0:ℝ)<den := by exact_mod_cast hden
      have hmono : ((den:ℝ)+1)*a≤((den:ℝ)+1)*x :=
        mul_le_mul_of_nonneg_left ha (by positivity)
      apply (mul_lt_mul_iff_right₀ hd0).mp
      have he : (den:ℝ)*(x+x/(den:ℝ))=((den:ℝ)+1)*x := by field_simp <;> ring
      rw [he]
      nlinarith
    · exact ih hh.2 (le_of_not_gt hxp)

#print axioms search_eq_original
#print axioms sound

end LCMSourcePV.PrimeCover.Math
