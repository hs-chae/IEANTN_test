import LucasCore
import LCMSourcePV.PrimeFacts.H00C000
import LCMSourcePV.PrimeFacts.H01C000
import LCMSourcePV.PrimeFacts.H02C000
import LCMSourcePV.PrimeFacts.H03C000
import LCMSourcePV.PrimeFacts.H03C001
import LCMSourcePV.PrimeFacts.H03C002
import LCMSourcePV.PrimeFacts.H03C003
import LCMSourcePV.PrimeFacts.H03C004
import LCMSourcePV.PrimeFacts.H03C005
import LCMSourcePV.PrimeFacts.H03C006
import LCMSourcePV.PrimeFacts.H03C007
import LCMSourcePV.PrimeFacts.H03C008
import LCMSourcePV.PrimeFacts.H03C009
import LCMSourcePV.PrimeFacts.H03C010
import LCMSourcePV.PrimeFacts.H03C011
import LCMSourcePV.PrimeFacts.H03C012
import LCMSourcePV.PrimeFacts.H04C000
import LCMSourcePV.PrimeFacts.H04C001
import LCMSourcePV.PrimeFacts.H04C002
import LCMSourcePV.PrimeFacts.H04C003
import LCMSourcePV.PrimeFacts.H04C004
import LCMSourcePV.PrimeFacts.H04C005
import LCMSourcePV.PrimeFacts.H04C006
import LCMSourcePV.PrimeFacts.H04C007
import LCMSourcePV.PrimeFacts.H04C008
import LCMSourcePV.PrimeFacts.H04C009
import LCMSourcePV.PrimeFacts.H04C010
import LCMSourcePV.PrimeFacts.H04C011
import LCMSourcePV.PrimeFacts.H04C012
import LCMSourcePV.PrimeFacts.H04C013
import LCMSourcePV.PrimeFacts.H04C014
import LCMSourcePV.PrimeFacts.H04C015
import LCMSourcePV.PrimeFacts.H04C016
import LCMSourcePV.PrimeFacts.H04C017
import LCMSourcePV.PrimeFacts.H04C018
import LCMSourcePV.PrimeFacts.H04C019
import LCMSourcePV.PrimeFacts.H04C020
import LCMSourcePV.PrimeFacts.H04C021
import LCMSourcePV.PrimeFacts.H04C022
import LCMSourcePV.PrimeFacts.H04C023
import LCMSourcePV.PrimeFacts.H04C024
import LCMSourcePV.PrimeFacts.H04C025
import LCMSourcePV.PrimeFacts.H04C026
import LCMSourcePV.PrimeFacts.H04C027
import LCMSourcePV.PrimeFacts.H04C028
import LCMSourcePV.PrimeFacts.H04C029
import LCMSourcePV.PrimeFacts.H04C030
namespace LCMSourcePV.PrimeFacts
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem prime_10620823 : Nat.Prime 10620823 := by
  refine Round2Recovery.lucas_list_prime (n := 10620823) (a := 3)
    (factors := [2, 3, 797, 2221]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_797 | exact prime_2221
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10620847 : Nat.Prime 10620847 := by
  refine Round2Recovery.lucas_list_prime (n := 10620847) (a := 5)
    (factors := [2, 3, 3, 83, 7109]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_83 | exact prime_7109
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10620923 : Nat.Prime 10620923 := by
  refine Round2Recovery.lucas_list_prime (n := 10620923) (a := 2)
    (factors := [2, 13, 408497]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_408497
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10620947 : Nat.Prime 10620947 := by
  refine Round2Recovery.lucas_list_prime (n := 10620947) (a := 2)
    (factors := [2, 7, 7, 108377]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_108377
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10620959 : Nat.Prime 10620959 := by
  refine Round2Recovery.lucas_list_prime (n := 10620959) (a := 13)
    (factors := [2, 101, 52579]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_101 | exact prime_52579
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10621063 : Nat.Prime 10621063 := by
  refine Round2Recovery.lucas_list_prime (n := 10621063) (a := 3)
    (factors := [2, 3, 3, 59, 73, 137]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_59 | exact prime_73 | exact prime_137
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10699027 : Nat.Prime 10699027 := by
  refine Round2Recovery.lucas_list_prime (n := 10699027) (a := 2)
    (factors := [2, 3, 13, 73, 1879]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_73 | exact prime_1879
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10699121 : Nat.Prime 10699121 := by
  refine Round2Recovery.lucas_list_prime (n := 10699121) (a := 6)
    (factors := [2, 2, 2, 2, 5, 17, 7867]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_17 | exact prime_7867
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10699159 : Nat.Prime 10699159 := by
  refine Round2Recovery.lucas_list_prime (n := 10699159) (a := 3)
    (factors := [2, 3, 1783193]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1783193
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10699181 : Nat.Prime 10699181 := by
  refine Round2Recovery.lucas_list_prime (n := 10699181) (a := 2)
    (factors := [2, 2, 5, 509, 1051]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_509 | exact prime_1051
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10699201 : Nat.Prime 10699201 := by
  refine Round2Recovery.lucas_list_prime (n := 10699201) (a := 11)
    (factors := [2, 2, 2, 2, 2, 2, 3, 3, 5, 5, 743]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_743
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10699361 : Nat.Prime 10699361 := by
  refine Round2Recovery.lucas_list_prime (n := 10699361) (a := 3)
    (factors := [2, 2, 2, 2, 2, 5, 7, 41, 233]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7 | exact prime_41 | exact prime_233
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10699421 : Nat.Prime 10699421 := by
  refine Round2Recovery.lucas_list_prime (n := 10699421) (a := 3)
    (factors := [2, 2, 5, 534971]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_534971
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

end LCMSourcePV.PrimeFacts
