import LCMSourcePV.PrimeCover.DriverSource

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.Driver
open LCMSourcePV.Witness.C

structure State where
  machine : AST.C.State
  written : List Nat

def initial (capacity : Nat) : State :=
  ⟨⟨AST.C.bind AST.C.emptyEnv "pc_output" 8,⟨8,capacity,fun _=>0⟩⟩,[]⟩

/-- C static aggregate initialization allocates the complete writable array
and zero-fills every omitted element. Application memory is constructed here. -/
inductive Initialize : ArrayDecl → State → Prop
  | zero (capacity : Nat) (positive : 0<capacity)
      (addressable : 8+8*capacity<wordMod) :
      Initialize ⟨"pc_output",capacity,.aggregate [0]⟩ (initial capacity)

/-- Valid uint64 objects passed to fwrite. The source address is checked, the
actual local or array contents are read, and the requested extent is owned. -/
inductive ObjectWords : Expr → State → Nat → List Nat → Prop
  | localCount (s : State) (count : Nat) (read : s.machine.env "count"=some count)
      (word : count<wordMod) : ObjectWords (.unary "&" (.var "count")) s 1 [count]
  | outputArray (s : State) (count : Nat)
      (pointer : s.machine.env "pc_output"=some s.machine.heap.base)
      (owned : count ≤ s.machine.heap.extent)
      (words : ∀i,i<count → s.machine.heap.words i<wordMod) :
      ObjectWords (.var "pc_output") s count
        (List.ofFn fun i : Fin count => s.machine.heap.words i)

/-- Effectful main-expression execution. The constructor call requires a
real execution of its actual AST with a fresh parameter frame. The fwrite
rule is the explicit generic CStdIO successful-copy contract: eight-byte
uint64 objects become stream words. Physical byte layout/files stay in the
disclosed pinned ABI/CStdIO boundary, not a new Lean axiom. -/
inductive Eval : Expr → State → State → Nat → Prop
  | pure {e s machine value}
      (run : AST.C.eval AST.C.service s.machine e=some (machine,value)) :
      Eval e s {s with machine:=machine} value
  | binary {op a b s mid final left right value}
      (first : Eval a s mid left) (second : Eval b mid final right)
      (operation : AST.C.binary op left right=some value) :
      Eval (.binary op a b) s final value
  | constructor {args s start tail den capacity base result final}
      (arguments : args.mapM (AST.C.evalPure AST.C.service s.machine.env 100)=
        some [start,tail,den,capacity,base])
      (pointer : base=s.machine.heap.base) (owned : s.machine.heap.extent=capacity)
      (words : AST.C.InputWords start tail den capacity)
      (run : AST.C.Run AST.C.service (AST.C.stmt Source.coverFunction.body)
        (AST.C.coverInput start tail den capacity s.machine.heap) (.returned final result)) :
      Eval (.call (.var "pc_cover") args) s
        {s with machine:={s.machine with heap:=final.heap}} result
  | write {object countExpr s count payload}
      (countRead : AST.C.evalPure AST.C.service s.machine.env 100 countExpr=some count)
      (valid : ObjectWords object s count payload) :
      Eval (.call (.var "fwrite") [object,.nat 8,countExpr,.var "stdout"])
        s {s with written:=s.written++payload} count

inductive Declare : List Decl → State → State → Prop
  | nil (s : State) : Declare [] s s
  | cons {d ds e s mid final value}
      (type : d.type="uint64_t") (initialized : d.value=some e)
      (run : Eval e s mid value) (word : value<wordMod)
      (rest : Declare ds {mid with machine:={mid.machine with
        env:=AST.C.bind mid.machine.env d.name value}} final) : Declare (d::ds) s final

def Scope (_ : State) (inner outer : ASTLoops.Flow State Nat) : Prop := outer=inner
abbrev Run := ASTLoops.StmtRun Eval Declare AST.C.truth Scope

theorem literal_zero (s : State) : Eval (.nat 0) s s 0 := by
  exact Eval.pure (by simp [AST.C.eval,AST.C.evalPure])
theorem literal_one (s : State) : Eval (.nat 1) s s 1 := by
  exact Eval.pure (by simp [AST.C.eval,AST.C.evalPure,wordMod])

#print axioms literal_one
end LCMSourcePV.PrimeCover.Driver
