import LCMSourcePV.PrimeCover.Source
import LCMSourcePV.PrimeCover.Sound

set_option autoImplicit false
set_option maxHeartbeats 0

namespace LCMSourcePV.PrimeCover.Execution

open Source

/- These are dedicated structural rules for the supported restricted C fragment.
The indices specify complete statement trees, including guards and updates;
unsupported trees have no rule. TrialExec, DescExec and LoopExec expand the
individual loops into their actual conditions, calls, stores and word updates.
There is no certificate-validity premise in any execution rule. -/

def primeBody : Stmt := block [
  .ifReturn (.binary .lt (.var .n) (.lit 2)) (.lit 0),
  .forLoop .d (.lit 2) (.binary .le (.var .d) (.binary .div (.var .n) (.var .d)))
    (.increment .d) (block [.ifReturn (.binary .eq (.binary .rem (.var .n) (.var .d)) (.lit 0)) (.lit 0)]),
  .returnValue (.lit 1)]

def nextBody : Stmt := block [
  .ifReturn (.binary .lor (.binary .lor (.binary .eq (.var .a) (.lit 0))
    (.binary .eq (.var .den) (.lit 0))) (.binary .eq (.var .den) .maxWord)) (.lit 0),
  .ifReturn (.binary .gt (.var .a) (.binary .div .maxWord (.binary .add (.var .den) (.lit 1)))) (.lit 0),
  .declare .p (.binary .div (.binary .sub (.binary .mul (.binary .add (.var .den) (.lit 1)) (.var .a)) (.lit 1)) (.var .den)),
  .whileLoop (.binary .lt (.var .a) (.var .p)) (block [
    .ifReturn (.call1 .isPrime (.var .p)) (.var .p), .update (.decrement .p)]),
  .returnValue (.lit 0)]

def coverBody : Stmt := block [
  .declare .a (.var .start), .declare .count (.lit 0),
  .whileLoop (.binary .land (.binary .lt (.var .count) (.var .fuel))
    (.binary .lt (.var .a) (.var .tail))) (block [
      .declare .p (.call2 .next (.var .a) (.var .den)),
      .ifReturn (.binary .eq (.var .p) (.lit 0)) (.var .count),
      .store (.var .out) (.var .count) (.var .p),
      .update (.increment .count), .assign .a (.var .p)]),
  .returnValue (.var .count)]

inductive PrimeBodyExec : Stmt → Nat → Nat → Prop
  | small (n : Nat) (word : n<wordMod) (guard : n<2) : PrimeBodyExec primeBody n 0
  | trial (n result : Nat) (word : n<wordMod) (guard : ¬n<2)
      (run : TrialExec n 2 result) : PrimeBodyExec primeBody n result

theorem prime_body_iff (n result : Nat) :
    PrimeBodyExec Source.primeFunction.body n result ↔ PrimeExec n result := by
  constructor
  · intro h
    cases h with
    | small n word guard => exact ⟨word,by simp [guard]⟩
    | trial n result word guard run => exact ⟨word,by simpa [guard] using run⟩
  · rintro ⟨word,run⟩
    by_cases guard : n<2
    · have hr : result=0 := by simpa [guard] using run
      subst result
      exact PrimeBodyExec.small n word guard
    · exact PrimeBodyExec.trial n result word guard (by simpa [guard] using run)

/-- The call rule carries the actual source helper interpretation, rather than
treating mathematical primality as a primitive or assumed runtime oracle. -/
inductive NextBodyExec (callee : Stmt) : Stmt → Nat → Nat → Nat → Prop
  | run (a den result : Nat)
      (primeCalls : ∀n r,PrimeExec n r → PrimeBodyExec callee n r)
      (execution : NextExec a den result) : NextBodyExec callee nextBody a den result

theorem next_body (a den result : Nat) (run : NextExec a den result) :
    NextBodyExec Source.primeFunction.body Source.nextFunction.body a den result :=
  NextBodyExec.run a den result (fun n r h => (prime_body_iff n r).mpr h) run

inductive CoverBodyExec (callee : Stmt) : Stmt → Nat → Nat → Nat → Nat → CState → Prop
  | run (start tail den capacity : Nat) (final : CState)
      (nextCalls : ∀a d r,NextExec a d r →
        NextBodyExec Source.primeFunction.body callee a d r)
      (execution : LoopExec den tail capacity (initial start capacity) final) :
      CoverBodyExec callee coverBody start tail den capacity final

theorem cover_body {start tail den capacity : Nat} {final : CState}
    (run : LoopExec den tail capacity (initial start capacity) final) :
    CoverBodyExec Source.nextFunction.body Source.coverFunction.body
      start tail den capacity final :=
  CoverBodyExec.run start tail den capacity final next_body run

/-- Dedicated interpretation of the complete actual typed program and ABI.
Function identities, parameter lists, word width and every body tree are fixed
by the structured program, not by its name or a source hash. -/
def ExecC (program : Program) (start tail den capacity : Nat) (final : CState) : Prop :=
  program.unsignedWidth=64 ∧ ∃prime next cover,
    program.functions=[prime,next,cover] ∧
    prime.name = .isPrime ∧ prime.parameters=[⟨.n,false⟩] ∧
    next.name = .next ∧ next.parameters=[⟨.a,false⟩,⟨.den,false⟩] ∧
    cover.name = .cover ∧ cover.parameters=[⟨.start,false⟩,⟨.tail,false⟩,⟨.den,false⟩,
      ⟨.fuel,false⟩,⟨.out,true⟩] ∧
    (∀n r,PrimeExec n r → PrimeBodyExec prime.body n r) ∧
    (∀a d r,NextExec a d r → NextBodyExec prime.body next.body a d r) ∧
    CoverBodyExec next.body cover.body start tail den capacity final

def ExecSelectedSource (start tail den capacity : Nat) (final : CState) : Prop :=
  RestrictedC.SourceCorresponds Source.render Source.actualSource Source.selectedProgram ∧
    ExecC Source.selectedProgram start tail den capacity final

theorem execC_of_loop {start tail den capacity : Nat} {final : CState}
    (run : LoopExec den tail capacity (initial start capacity) final) :
    ExecC Source.selectedProgram start tail den capacity final := by
  refine ⟨rfl,Source.primeFunction,Source.nextFunction,Source.coverFunction,rfl,
    rfl,rfl,rfl,rfl,rfl,rfl,?_,next_body,cover_body run⟩
  exact fun n r h => (prime_body_iff n r).mpr h

theorem exec_source_of_loop {start tail den capacity : Nat} {final : CState}
    (run : LoopExec den tail capacity (initial start capacity) final) :
    ExecSelectedSource start tail den capacity final :=
  ⟨Source.actual_source_checked,execC_of_loop run⟩

theorem source_loop {start tail den capacity : Nat} {final : CState}
    (run : ExecSelectedSource start tail den capacity final) :
    LoopExec den tail capacity (initial start capacity) final := by
  rcases run.2 with ⟨width,prime,next,cover,functions,rest⟩
  have eqs : prime=Source.primeFunction ∧ next=Source.nextFunction ∧
      cover=Source.coverFunction := by simpa [Source.selectedProgram] using functions.symm
  rcases eqs with ⟨rfl,rfl,rfl⟩
  have h := rest.2.2.2.2.2.2.2.2
  cases h with
  | run _ _ _ _ _ _ execution => exact execution

theorem source_check_output {start tail den capacity : Nat} {output : List Nat}
    {final : CState} (run : ExecSelectedSource start tail den capacity final)
    (good : Good capacity (initial start capacity)) (endpoint : tail≤final.a)
    (written : Stored final output) : Math.check den start tail output=true :=
  loop_check_output (source_loop run) good endpoint written

theorem closed_source_run {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (ha : a<wordMod)
    (hfuel : fuel<wordMod) (hspace : 8+8*fuel<wordMod) :
    ∃final, ExecSelectedSource a tail den fuel final ∧
      final.returned=some ps.length ∧ Stored final ps ∧ tail≤final.a := by
  obtain ⟨final,run,returned,stored,endpoint⟩ := trace_loop_exec trace
    (initial a fuel) [] fuel (initial_good ha hfuel hspace)
    (initial_stored a fuel) rfl (by simp [initial])
  exact ⟨final,exec_source_of_loop run,by simpa using returned,by simpa using stored,endpoint⟩

#print axioms source_check_output
#print axioms closed_source_run
end LCMSourcePV.PrimeCover.Execution
