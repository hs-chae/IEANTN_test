import LCMSourcePV.PrimeCover.AST

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.AST.C
open LCMSourcePV.Witness.C

def trialCondition : Expr := .binary "<=" (.var "d") (.binary "/" (.var "n") (.var "d"))
def trialStep : Expr := .unary "++" (.var "d")
def remainderCondition : Expr := .binary "==" (.binary "%" (.var "n") (.var "d")) (.nat 0)
def trialBody : Stmt := .sequence [.branch remainderCondition (.returnStmt (.nat 0)) .skip,.skip]
def trialOutcome (result : Nat) (s : State) : Flow :=
  if result=0 then .returned s 0 else .continuing s

theorem literal_zero (call : Service) (s : State) : Eval call (.nat 0) s s 0 := by
  simp [Eval,eval,evalPure]
theorem literal_one (call : Service) (s : State) : Eval call (.nat 1) s s 1 := by
  simp [Eval,eval,evalPure,wordMod]

theorem trial_condition_eval {call : Service} {s : State} {n d : Nat}
    (hn : s.env "n"=some n) (hd : s.env "d"=some d) (hd2 : 2≤d) :
    Eval call trialCondition s s (bool (d≤n/d)) := by
  have hd0 : d≠0 := by omega
  simp [Eval,eval,evalPure,trialCondition,hn,hd,binary,hd0]

theorem remainder_condition_eval {call : Service} {s : State} {n d : Nat}
    (hn : s.env "n"=some n) (hd : s.env "d"=some d) (hd2 : 2≤d) :
    Eval call remainderCondition s s (bool (n%d=0)) := by
  have hd0 : d≠0 := by omega
  simp [Eval,eval,evalPure,remainderCondition,hn,hd,binary,hd0]

theorem trial_body_continue {call : Service} {s : State} {n d : Nat}
    (hn : s.env "n"=some n) (hd : s.env "d"=some d) (hd2 : 2≤d)
    (nonzero : n%d≠0) : Run call trialBody s (.continuing s) := by
  apply sequence2
  · apply ASTLoops.StmtRun.branch (remainder_condition_eval hn hd hd2)
    simpa [truth,bool,nonzero] using ASTLoops.StmtRun.skip s
  · exact ASTLoops.StmtRun.skip s

theorem trial_body_return {call : Service} {s : State} {n d : Nat}
    (hn : s.env "n"=some n) (hd : s.env "d"=some d) (hd2 : 2≤d)
    (zero : n%d=0) : Run call trialBody s (.returned s 0) := by
  apply sequence2_returned
  apply ASTLoops.StmtRun.branch (remainder_condition_eval hn hd hd2)
  simpa [truth,bool,zero] using ASTLoops.StmtRun.returnValue (literal_zero call s)

/-- Node-by-node refinement of the actual C for-loop. The generic control
rules execute the guard, source remainder branch, increment and recursive
iteration. No complete-body interpretation constructor is used. -/
theorem trial_for_refines {n d result : Nat} (execution : TrialExec n d result)
    (word : n<wordMod) (hd2 : 2≤d) :
    ∀(call : Service) (s : State), s.env "n"=some n → s.env "d"=some d →
      ∃t, ForRun call (some trialCondition) trialStep trialBody s (trialOutcome result t) ∧
        t.heap=s.heap := by
  revert hd2
  induction execution with
  | done d guard =>
    intro hd2 call s hn hd
    refine ⟨s,?_,rfl⟩
    change ForRun call (some trialCondition) trialStep trialBody s (.continuing s)
    apply ASTLoops.ForRun.done
    simpa [truth,bool,guard] using
      ASTLoops.GuardRun.present (truth:=truth) (trial_condition_eval (call:=call) hn hd hd2)
  | found d guard zero =>
    intro hd2 call s hn hd
    refine ⟨s,?_,rfl⟩
    change ForRun call (some trialCondition) trialStep trialBody s (.returned s 0)
    apply ASTLoops.ForRun.returned
    · simpa [truth,bool,guard] using
        ASTLoops.GuardRun.present (truth:=truth) (trial_condition_eval (call:=call) hn hd hd2)
    · exact trial_body_return hn hd hd2 zero
  | step d result guard nonzero rest ih =>
    intro hd2 call s hn hd
    let next : State := {s with env:=bind s.env "d" (bump d)}
    have hb := bump_exact word hd2 guard
    obtain ⟨t,run,heap⟩ := ih (by omega) call next
      (by simp [next,bind,hn]) (by simp [next,bind])
    refine ⟨t,?_,heap⟩
    apply ASTLoops.ForRun.next
    · simpa [truth,bool,guard] using
        ASTLoops.GuardRun.present (truth:=truth) (trial_condition_eval (call:=call) hn hd hd2)
    · exact trial_body_continue hn hd hd2 nonzero
    · change eval call s (.unary "++" (.var "d"))=some (next,bump d)
      simp [eval,next,hd,bump]
    · exact run

def primeInput (n : Nat) (heap : Heap) : State := ⟨bind emptyEnv "n" n,heap⟩
def primeSmall : Stmt := .branch (.binary "<" (.var "n") (.nat 2)) (.returnStmt (.nat 0)) .skip
def primeFor : Stmt := .forLoop (.declare [⟨"uint64_t","d",some (.nat 2)⟩])
  (some trialCondition) trialStep trialBody
def primeTail : Stmt := .sequence [primeFor,.sequence [.returnStmt (.nat 1),.skip]]

theorem prime_source_shape : stmt Source.primeFunction.body =
    .sequence [primeSmall,primeTail] := rfl

theorem prime_small_eval {call : Service} {s : State} {n : Nat}
    (hn : s.env "n"=some n) :
    Eval call (.binary "<" (.var "n") (.nat 2)) s s (bool (n<2)) := by
  simp [Eval,eval,evalPure,hn,binary,wordMod]

/-- Actual bound source AST execution for every PrimeExec, independently of
the modular call service. Thus the trial-division helper is not a name oracle. -/
theorem prime_function_refines {n result : Nat} (execution : PrimeExec n result)
    (call : Service) (heap : Heap) :
    ∃t, Run call (stmt Source.primeFunction.body) (primeInput n heap) (.returned t result) ∧
      t.heap=heap := by
  rcases execution with ⟨word,execution⟩
  rw [prime_source_shape]
  have hn : (primeInput n heap).env "n"=some n := by simp [primeInput,bind]
  by_cases small : n<2
  · have hr : result=0 := by simpa [small] using execution
    subst result
    refine ⟨primeInput n heap,?_,rfl⟩
    apply sequence2_returned
    apply ASTLoops.StmtRun.branch (prime_small_eval hn)
    simpa [truth,bool,small] using ASTLoops.StmtRun.returnValue (literal_zero call (primeInput n heap))
  · have trial : TrialExec n 2 result := by simpa [small] using execution
    let initial := primeInput n heap
    let start : State := {initial with env:=bind initial.env "d" 2}
    have declaration : Declare call [⟨"uint64_t","d",some (.nat 2)⟩] initial start := by
      simp [Declare,declare,List.foldlM,evalPure,start,wordMod]
    obtain ⟨t,loop,hheap⟩ := trial_for_refines trial word (by omega) call start
      (by simp [start,initial,primeInput,bind]) (by simp [start,bind])
    have first : Run call primeSmall initial (.continuing initial) := by
      apply ASTLoops.StmtRun.branch (prime_small_eval hn)
      simpa [truth,bool,small] using ASTLoops.StmtRun.skip initial
    rcases trial_values trial with hr|hr
    · subst result
      refine ⟨t,sequence2 first ?_,hheap⟩
      apply sequence2_returned
      exact ASTLoops.StmtRun.forLoop (ASTLoops.StmtRun.declare declaration) loop rfl
    · subst result
      refine ⟨t,sequence2 first ?_,hheap⟩
      apply sequence2
      · exact ASTLoops.StmtRun.forLoop (ASTLoops.StmtRun.declare declaration) loop rfl
      · exact sequence2_returned (ASTLoops.StmtRun.returnValue (literal_one call t))

#print axioms prime_function_refines
end LCMSourcePV.PrimeCover.AST.C
