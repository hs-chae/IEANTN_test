import LCMSourcePV.PrimeCover.ASTVerified

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.Driver
open LCMSourcePV.Witness.C

structure Inputs where
  start : Nat
  tail : Nat
  den : Nat
  capacity : Nat

inductive Init where
  | aggregate (values : List Nat)
structure ArrayDecl where
  name : String
  bound : Nat
  initial : Init

def array (p : Inputs) : ArrayDecl := ⟨"pc_output",p.capacity,.aggregate [0]⟩
def constructor (p : Inputs) : Expr := .call (.var "pc_cover")
  [.nat p.start,.nat p.tail,.nat p.den,.nat p.capacity,.var "pc_output"]
def countWrite : Expr := .call (.var "fwrite")
  [.unary "&" (.var "count"),.nat 8,.nat 1,.var "stdout"]
def arrayWrite : Expr := .call (.var "fwrite")
  [.var "pc_output",.nat 8,.var "count",.var "stdout"]
def body (p : Inputs) : Stmt := .sequence [
  .declare [⟨"uint64_t","count",some (constructor p)⟩],
  .branch (.binary "==" countWrite (.nat 1)) (.sequence [
    .branch (.binary "==" arrayWrite (.var "count")) (.returnStmt (.nat 0)) .skip,
    .returnStmt (.nat 2)]) .skip,
  .returnStmt (.nat 1)]

def renderArray (decl : ArrayDecl) : String := match decl.initial with
  | .aggregate values => "static uint64_t "++decl.name++"["++toString decl.bound++"] = {"++
      join (values.map toString)++"};\n"
def render (p : Inputs) : Option String := do
  return "#include <stdio.h>\n#include \"../primecover.c\"\n\n"++renderArray (array p)++
    "\nint main(void) "++(←renderStmt 1000 (body p))++"\n"

def input3273 : Inputs := ⟨3273,89693,125,512⟩
def input4096 : Inputs := ⟨4096,89693,125,512⟩
def input1341 : Inputs := ⟨1341,89693,66,512⟩
def input1674 : Inputs := ⟨1674,89693,84,512⟩
def input8468 : Inputs := ⟨8468,89693,256,700⟩
def input58832 : Inputs := ⟨58832,89693,1024,700⟩

def source3273 : String := include_str "../../../c/drivers-ast/cover_3273_d125.c"
def source4096 : String := include_str "../../../c/drivers-ast/cover_4096_d125.c"
def source1341 : String := include_str "../../../c/drivers-ast/cover_1341_d66.c"
def source1674 : String := include_str "../../../c/drivers-ast/cover_1674_d84.c"
def source8468 : String := include_str "../../../c/drivers-ast/cover_8468_d256.c"
def source58832 : String := include_str "../../../c/drivers-ast/cover_58832_d1024.c"

theorem bound3273 : RestrictedC.SourceCorresponds render source3273 input3273 := by
  refine ⟨(render input3273).getD "",?_,?_,?_⟩ <;> decide +kernel
theorem bound4096 : RestrictedC.SourceCorresponds render source4096 input4096 := by
  refine ⟨(render input4096).getD "",?_,?_,?_⟩ <;> decide +kernel
theorem bound1341 : RestrictedC.SourceCorresponds render source1341 input1341 := by
  refine ⟨(render input1341).getD "",?_,?_,?_⟩ <;> decide +kernel
theorem bound1674 : RestrictedC.SourceCorresponds render source1674 input1674 := by
  refine ⟨(render input1674).getD "",?_,?_,?_⟩ <;> decide +kernel
theorem bound8468 : RestrictedC.SourceCorresponds render source8468 input8468 := by
  refine ⟨(render input8468).getD "",?_,?_,?_⟩ <;> decide +kernel
theorem bound58832 : RestrictedC.SourceCorresponds render source58832 input58832 := by
  refine ⟨(render input58832).getD "",?_,?_,?_⟩ <;> decide +kernel

#print axioms bound3273
#print axioms bound58832
end LCMSourcePV.PrimeCover.Driver
