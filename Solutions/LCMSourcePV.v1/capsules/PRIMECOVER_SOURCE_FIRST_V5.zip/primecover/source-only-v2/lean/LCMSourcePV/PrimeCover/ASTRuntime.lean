import LCMSourcePV.PrimeCover.ASTNext

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.AST.C

/-- The selected program's modular pure-call service. Its mathematical
partial evaluation is justified below by actual statement-tree executions;
unsupported calls reject rather than receiving an assumed interpretation. -/
def service : Service := fun name args =>
  if name == "pc_is_prime" then
    match args with
    | [n] => if n<wordMod then some (if Nat.Prime n then 1 else 0) else none
    | _ => none
  else if name == "pc_next" then
    match args with
    | [a,den] => if NextAllowed a den then some ((Math.next den a).getD 0) else none
    | _ => none
  else none

def NextCorrect (call : Service) : Prop :=
  ∀a den result,NextAllowed a den → NextExec a den result →
    call "pc_next" [a,den]=some result

theorem service_prime_correct : PrimeCorrect service := by
  intro n result run
  have hn := run.1
  have hr : (if Nat.Prime n then 1 else 0)=result := by
    by_cases hp : Nat.Prime n
    · have hh := (prime_exec_correct run).2.mpr hp
      simp [hp,hh]
    · rcases (prime_exec_correct run).1 with hz|ho
      · simp [hp,hz]
      · exact False.elim (hp ((prime_exec_correct run).2.mp ho))
  simp [service,hn,hr]

theorem service_next_correct : NextCorrect service := by
  intro a den result allowed run
  have hr := next_exec_math allowed run
  simp [service,allowed,hr]

/-- Every modular primality answer has an execution of the actual, source-
bound trial-division AST. This is a closed theorem, not a callback assumption. -/
theorem actual_prime_service {n result : Nat} (run : PrimeExec n result) (heap : Heap) :
    ∃t, Run service (stmt Source.primeFunction.body) (primeInput n heap) (.returned t result) ∧
      t.heap=heap := prime_function_refines run service heap

/-- Every modular next-prime answer on a source-admissible call has an
execution of the actual next-prime AST with actual trial-division callees. -/
theorem actual_next_service {a den result : Nat} (allowed : NextAllowed a den)
    (run : NextExec a den result) (heap : Heap) :
    ∃t, Run service (stmt Source.nextFunction.body) (nextInput a den heap) (.returned t result) ∧
      t.heap=heap := next_function_refines allowed run service service_prime_correct heap

#print axioms actual_prime_service
#print axioms actual_next_service
end LCMSourcePV.PrimeCover.AST.C
