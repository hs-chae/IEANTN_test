import LucasCore
import LCMSourcePV.PrimeFacts.H00C000
import LCMSourcePV.PrimeFacts.H01C000
import LCMSourcePV.PrimeFacts.H02C000
import LCMSourcePV.PrimeFacts.H03C000
import LCMSourcePV.PrimeFacts.H03C001
import LCMSourcePV.PrimeFacts.H03C002
import LCMSourcePV.PrimeFacts.H03C003
import LCMSourcePV.PrimeFacts.H03C004
import LCMSourcePV.PrimeFacts.H03C005
import LCMSourcePV.PrimeFacts.H03C006
import LCMSourcePV.PrimeFacts.H03C007
import LCMSourcePV.PrimeFacts.H03C008
import LCMSourcePV.PrimeFacts.H03C009
import LCMSourcePV.PrimeFacts.H03C010
import LCMSourcePV.PrimeFacts.H03C011
import LCMSourcePV.PrimeFacts.H03C012
import LCMSourcePV.PrimeFacts.H04C000
import LCMSourcePV.PrimeFacts.H04C001
import LCMSourcePV.PrimeFacts.H04C002
import LCMSourcePV.PrimeFacts.H04C003
import LCMSourcePV.PrimeFacts.H04C004
import LCMSourcePV.PrimeFacts.H04C005
import LCMSourcePV.PrimeFacts.H04C006
import LCMSourcePV.PrimeFacts.H04C007
import LCMSourcePV.PrimeFacts.H04C008
import LCMSourcePV.PrimeFacts.H04C009
import LCMSourcePV.PrimeFacts.H04C010
import LCMSourcePV.PrimeFacts.H04C011
import LCMSourcePV.PrimeFacts.H04C012
import LCMSourcePV.PrimeFacts.H04C013
import LCMSourcePV.PrimeFacts.H04C014
import LCMSourcePV.PrimeFacts.H04C015
import LCMSourcePV.PrimeFacts.H04C016
import LCMSourcePV.PrimeFacts.H04C017
import LCMSourcePV.PrimeFacts.H04C018
import LCMSourcePV.PrimeFacts.H04C019
import LCMSourcePV.PrimeFacts.H04C020
import LCMSourcePV.PrimeFacts.H04C021
import LCMSourcePV.PrimeFacts.H04C022
import LCMSourcePV.PrimeFacts.H04C023
import LCMSourcePV.PrimeFacts.H04C024
import LCMSourcePV.PrimeFacts.H04C025
import LCMSourcePV.PrimeFacts.H04C026
import LCMSourcePV.PrimeFacts.H04C027
import LCMSourcePV.PrimeFacts.H04C028
import LCMSourcePV.PrimeFacts.H04C029
import LCMSourcePV.PrimeFacts.H04C030
namespace LCMSourcePV.PrimeFacts
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem prime_5779 : Nat.Prime 5779 := by
  refine Round2Recovery.lucas_list_prime (n := 5779) (a := 2)
    (factors := [2, 3, 3, 3, 107]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_107
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_5783 : Nat.Prime 5783 := by
  refine Round2Recovery.lucas_list_prime (n := 5783) (a := 7)
    (factors := [2, 7, 7, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_5879 : Nat.Prime 5879 := by
  refine Round2Recovery.lucas_list_prime (n := 5879) (a := 11)
    (factors := [2, 2939]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_2939
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_5903 : Nat.Prime 5903 := by
  refine Round2Recovery.lucas_list_prime (n := 5903) (a := 5)
    (factors := [2, 13, 227]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_227
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_5939 : Nat.Prime 5939 := by
  refine Round2Recovery.lucas_list_prime (n := 5939) (a := 2)
    (factors := [2, 2969]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_2969
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_6079 : Nat.Prime 6079 := by
  refine Round2Recovery.lucas_list_prime (n := 6079) (a := 17)
    (factors := [2, 3, 1013]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1013
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6197 : Nat.Prime 6197 := by
  refine Round2Recovery.lucas_list_prime (n := 6197) (a := 2)
    (factors := [2, 2, 1549]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_1549
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6199 : Nat.Prime 6199 := by
  refine Round2Recovery.lucas_list_prime (n := 6199) (a := 3)
    (factors := [2, 3, 1033]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1033
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6269 : Nat.Prime 6269 := by
  refine Round2Recovery.lucas_list_prime (n := 6269) (a := 2)
    (factors := [2, 2, 1567]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_1567
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6277 : Nat.Prime 6277 := by
  refine Round2Recovery.lucas_list_prime (n := 6277) (a := 2)
    (factors := [2, 2, 3, 523]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_523
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6367 : Nat.Prime 6367 := by
  refine Round2Recovery.lucas_list_prime (n := 6367) (a := 3)
    (factors := [2, 3, 1061]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1061
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6421 : Nat.Prime 6421 := by
  refine Round2Recovery.lucas_list_prime (n := 6421) (a := 6)
    (factors := [2, 2, 3, 5, 107]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_107
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6491 : Nat.Prime 6491 := by
  refine Round2Recovery.lucas_list_prime (n := 6491) (a := 2)
    (factors := [2, 5, 11, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_11 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6581 : Nat.Prime 6581 := by
  refine Round2Recovery.lucas_list_prime (n := 6581) (a := 14)
    (factors := [2, 2, 5, 7, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6619 : Nat.Prime 6619 := by
  refine Round2Recovery.lucas_list_prime (n := 6619) (a := 2)
    (factors := [2, 3, 1103]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1103
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6673 : Nat.Prime 6673 := by
  refine Round2Recovery.lucas_list_prime (n := 6673) (a := 5)
    (factors := [2, 2, 2, 2, 3, 139]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_139
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6719 : Nat.Prime 6719 := by
  refine Round2Recovery.lucas_list_prime (n := 6719) (a := 11)
    (factors := [2, 3359]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_3359
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_6803 : Nat.Prime 6803 := by
  refine Round2Recovery.lucas_list_prime (n := 6803) (a := 2)
    (factors := [2, 19, 179]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19 | exact prime_179
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6863 : Nat.Prime 6863 := by
  refine Round2Recovery.lucas_list_prime (n := 6863) (a := 5)
    (factors := [2, 47, 73]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_47 | exact prime_73
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6911 : Nat.Prime 6911 := by
  refine Round2Recovery.lucas_list_prime (n := 6911) (a := 7)
    (factors := [2, 5, 691]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_691
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_6991 : Nat.Prime 6991 := by
  refine Round2Recovery.lucas_list_prime (n := 6991) (a := 6)
    (factors := [2, 3, 5, 233]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_233
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7079 : Nat.Prime 7079 := by
  refine Round2Recovery.lucas_list_prime (n := 7079) (a := 7)
    (factors := [2, 3539]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_3539
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_7159 : Nat.Prime 7159 := by
  refine Round2Recovery.lucas_list_prime (n := 7159) (a := 3)
    (factors := [2, 3, 1193]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1193
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7229 : Nat.Prime 7229 := by
  refine Round2Recovery.lucas_list_prime (n := 7229) (a := 2)
    (factors := [2, 2, 13, 139]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_139
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7333 : Nat.Prime 7333 := by
  refine Round2Recovery.lucas_list_prime (n := 7333) (a := 6)
    (factors := [2, 2, 3, 13, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7349 : Nat.Prime 7349 := by
  refine Round2Recovery.lucas_list_prime (n := 7349) (a := 2)
    (factors := [2, 2, 11, 167]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_167
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7433 : Nat.Prime 7433 := by
  refine Round2Recovery.lucas_list_prime (n := 7433) (a := 3)
    (factors := [2, 2, 2, 929]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_929
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7457 : Nat.Prime 7457 := by
  refine Round2Recovery.lucas_list_prime (n := 7457) (a := 3)
    (factors := [2, 2, 2, 2, 2, 233]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_233
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7517 : Nat.Prime 7517 := by
  refine Round2Recovery.lucas_list_prime (n := 7517) (a := 2)
    (factors := [2, 2, 1879]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_1879
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7577 : Nat.Prime 7577 := by
  refine Round2Recovery.lucas_list_prime (n := 7577) (a := 3)
    (factors := [2, 2, 2, 947]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_947
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7607 : Nat.Prime 7607 := by
  refine Round2Recovery.lucas_list_prime (n := 7607) (a := 5)
    (factors := [2, 3803]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_3803
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_7643 : Nat.Prime 7643 := by
  refine Round2Recovery.lucas_list_prime (n := 7643) (a := 2)
    (factors := [2, 3821]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_3821
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_7727 : Nat.Prime 7727 := by
  refine Round2Recovery.lucas_list_prime (n := 7727) (a := 5)
    (factors := [2, 3863]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_3863
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_7757 : Nat.Prime 7757 := by
  refine Round2Recovery.lucas_list_prime (n := 7757) (a := 2)
    (factors := [2, 2, 7, 277]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_277
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7759 : Nat.Prime 7759 := by
  refine Round2Recovery.lucas_list_prime (n := 7759) (a := 3)
    (factors := [2, 3, 3, 431]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_431
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7823 : Nat.Prime 7823 := by
  refine Round2Recovery.lucas_list_prime (n := 7823) (a := 5)
    (factors := [2, 3911]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_3911
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_7883 : Nat.Prime 7883 := by
  refine Round2Recovery.lucas_list_prime (n := 7883) (a := 2)
    (factors := [2, 7, 563]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_563
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7907 : Nat.Prime 7907 := by
  refine Round2Recovery.lucas_list_prime (n := 7907) (a := 2)
    (factors := [2, 59, 67]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_59 | exact prime_67
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_7919 : Nat.Prime 7919 := by
  refine Round2Recovery.lucas_list_prime (n := 7919) (a := 7)
    (factors := [2, 37, 107]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_37 | exact prime_107
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8017 : Nat.Prime 8017 := by
  refine Round2Recovery.lucas_list_prime (n := 8017) (a := 5)
    (factors := [2, 2, 2, 2, 3, 167]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_167
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8179 : Nat.Prime 8179 := by
  refine Round2Recovery.lucas_list_prime (n := 8179) (a := 2)
    (factors := [2, 3, 29, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_29 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8243 : Nat.Prime 8243 := by
  refine Round2Recovery.lucas_list_prime (n := 8243) (a := 2)
    (factors := [2, 13, 317]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_317
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8273 : Nat.Prime 8273 := by
  refine Round2Recovery.lucas_list_prime (n := 8273) (a := 3)
    (factors := [2, 2, 2, 2, 11, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8311 : Nat.Prime 8311 := by
  refine Round2Recovery.lucas_list_prime (n := 8311) (a := 3)
    (factors := [2, 3, 5, 277]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_277
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8369 : Nat.Prime 8369 := by
  refine Round2Recovery.lucas_list_prime (n := 8369) (a := 3)
    (factors := [2, 2, 2, 2, 523]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_523
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8377 : Nat.Prime 8377 := by
  refine Round2Recovery.lucas_list_prime (n := 8377) (a := 5)
    (factors := [2, 2, 2, 3, 349]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_349
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8387 : Nat.Prime 8387 := by
  refine Round2Recovery.lucas_list_prime (n := 8387) (a := 2)
    (factors := [2, 7, 599]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_599
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8389 : Nat.Prime 8389 := by
  refine Round2Recovery.lucas_list_prime (n := 8389) (a := 6)
    (factors := [2, 2, 3, 3, 233]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_233
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8461 : Nat.Prime 8461 := by
  refine Round2Recovery.lucas_list_prime (n := 8461) (a := 6)
    (factors := [2, 2, 3, 3, 5, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8563 : Nat.Prime 8563 := by
  refine Round2Recovery.lucas_list_prime (n := 8563) (a := 2)
    (factors := [2, 3, 1427]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1427
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8627 : Nat.Prime 8627 := by
  refine Round2Recovery.lucas_list_prime (n := 8627) (a := 2)
    (factors := [2, 19, 227]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19 | exact prime_227
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8699 : Nat.Prime 8699 := by
  refine Round2Recovery.lucas_list_prime (n := 8699) (a := 2)
    (factors := [2, 4349]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_4349
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_8707 : Nat.Prime 8707 := by
  refine Round2Recovery.lucas_list_prime (n := 8707) (a := 5)
    (factors := [2, 3, 1451]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1451
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8747 : Nat.Prime 8747 := by
  refine Round2Recovery.lucas_list_prime (n := 8747) (a := 2)
    (factors := [2, 4373]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_4373
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_8783 : Nat.Prime 8783 := by
  refine Round2Recovery.lucas_list_prime (n := 8783) (a := 5)
    (factors := [2, 4391]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_4391
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_8951 : Nat.Prime 8951 := by
  refine Round2Recovery.lucas_list_prime (n := 8951) (a := 13)
    (factors := [2, 5, 5, 179]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_179
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_8969 : Nat.Prime 8969 := by
  refine Round2Recovery.lucas_list_prime (n := 8969) (a := 3)
    (factors := [2, 2, 2, 19, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9173 : Nat.Prime 9173 := by
  refine Round2Recovery.lucas_list_prime (n := 9173) (a := 2)
    (factors := [2, 2, 2293]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_2293
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9203 : Nat.Prime 9203 := by
  refine Round2Recovery.lucas_list_prime (n := 9203) (a := 2)
    (factors := [2, 43, 107]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_43 | exact prime_107
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9209 : Nat.Prime 9209 := by
  refine Round2Recovery.lucas_list_prime (n := 9209) (a := 3)
    (factors := [2, 2, 2, 1151]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_1151
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9221 : Nat.Prime 9221 := by
  refine Round2Recovery.lucas_list_prime (n := 9221) (a := 2)
    (factors := [2, 2, 5, 461]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_461
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9323 : Nat.Prime 9323 := by
  refine Round2Recovery.lucas_list_prime (n := 9323) (a := 2)
    (factors := [2, 59, 79]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_59 | exact prime_79
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9403 : Nat.Prime 9403 := by
  refine Round2Recovery.lucas_list_prime (n := 9403) (a := 3)
    (factors := [2, 3, 1567]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1567
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9419 : Nat.Prime 9419 := by
  refine Round2Recovery.lucas_list_prime (n := 9419) (a := 2)
    (factors := [2, 17, 277]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_17 | exact prime_277
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9497 : Nat.Prime 9497 := by
  refine Round2Recovery.lucas_list_prime (n := 9497) (a := 3)
    (factors := [2, 2, 2, 1187]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_1187
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9533 : Nat.Prime 9533 := by
  refine Round2Recovery.lucas_list_prime (n := 9533) (a := 2)
    (factors := [2, 2, 2383]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_2383
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9689 : Nat.Prime 9689 := by
  refine Round2Recovery.lucas_list_prime (n := 9689) (a := 3)
    (factors := [2, 2, 2, 7, 173]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_173
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9749 : Nat.Prime 9749 := by
  refine Round2Recovery.lucas_list_prime (n := 9749) (a := 2)
    (factors := [2, 2, 2437]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_2437
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9871 : Nat.Prime 9871 := by
  refine Round2Recovery.lucas_list_prime (n := 9871) (a := 3)
    (factors := [2, 3, 5, 7, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9887 : Nat.Prime 9887 := by
  refine Round2Recovery.lucas_list_prime (n := 9887) (a := 5)
    (factors := [2, 4943]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_4943
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_9949 : Nat.Prime 9949 := by
  refine Round2Recovery.lucas_list_prime (n := 9949) (a := 2)
    (factors := [2, 2, 3, 829]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_829
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_9973 : Nat.Prime 9973 := by
  refine Round2Recovery.lucas_list_prime (n := 9973) (a := 11)
    (factors := [2, 2, 3, 3, 277]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_277
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10009 : Nat.Prime 10009 := by
  refine Round2Recovery.lucas_list_prime (n := 10009) (a := 11)
    (factors := [2, 2, 2, 3, 3, 139]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_139
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10069 : Nat.Prime 10069 := by
  refine Round2Recovery.lucas_list_prime (n := 10069) (a := 2)
    (factors := [2, 2, 3, 839]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_839
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10079 : Nat.Prime 10079 := by
  refine Round2Recovery.lucas_list_prime (n := 10079) (a := 11)
    (factors := [2, 5039]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_5039
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_10181 : Nat.Prime 10181 := by
  refine Round2Recovery.lucas_list_prime (n := 10181) (a := 2)
    (factors := [2, 2, 5, 509]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_509
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10247 : Nat.Prime 10247 := by
  refine Round2Recovery.lucas_list_prime (n := 10247) (a := 5)
    (factors := [2, 47, 109]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_47 | exact prime_109
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10253 : Nat.Prime 10253 := by
  refine Round2Recovery.lucas_list_prime (n := 10253) (a := 2)
    (factors := [2, 2, 11, 233]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_233
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10273 : Nat.Prime 10273 := by
  refine Round2Recovery.lucas_list_prime (n := 10273) (a := 10)
    (factors := [2, 2, 2, 2, 2, 3, 107]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_107
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10313 : Nat.Prime 10313 := by
  refine Round2Recovery.lucas_list_prime (n := 10313) (a := 3)
    (factors := [2, 2, 2, 1289]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_1289
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10331 : Nat.Prime 10331 := by
  refine Round2Recovery.lucas_list_prime (n := 10331) (a := 2)
    (factors := [2, 5, 1033]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_1033
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10559 : Nat.Prime 10559 := by
  refine Round2Recovery.lucas_list_prime (n := 10559) (a := 23)
    (factors := [2, 5279]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_5279
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_10567 : Nat.Prime 10567 := by
  refine Round2Recovery.lucas_list_prime (n := 10567) (a := 6)
    (factors := [2, 3, 3, 587]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_587
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10667 : Nat.Prime 10667 := by
  refine Round2Recovery.lucas_list_prime (n := 10667) (a := 2)
    (factors := [2, 5333]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_5333
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_10691 : Nat.Prime 10691 := by
  refine Round2Recovery.lucas_list_prime (n := 10691) (a := 2)
    (factors := [2, 5, 1069]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_1069
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10709 : Nat.Prime 10709 := by
  refine Round2Recovery.lucas_list_prime (n := 10709) (a := 2)
    (factors := [2, 2, 2677]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_2677
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10739 : Nat.Prime 10739 := by
  refine Round2Recovery.lucas_list_prime (n := 10739) (a := 6)
    (factors := [2, 7, 13, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_13 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_10979 : Nat.Prime 10979 := by
  refine Round2Recovery.lucas_list_prime (n := 10979) (a := 2)
    (factors := [2, 11, 499]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_499
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_11047 : Nat.Prime 11047 := by
  refine Round2Recovery.lucas_list_prime (n := 11047) (a := 3)
    (factors := [2, 3, 7, 263]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_263
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_11057 : Nat.Prime 11057 := by
  refine Round2Recovery.lucas_list_prime (n := 11057) (a := 3)
    (factors := [2, 2, 2, 2, 691]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_691
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_11083 : Nat.Prime 11083 := by
  refine Round2Recovery.lucas_list_prime (n := 11083) (a := 2)
    (factors := [2, 3, 1847]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1847
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_11093 : Nat.Prime 11093 := by
  refine Round2Recovery.lucas_list_prime (n := 11093) (a := 2)
    (factors := [2, 2, 47, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_47 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_11261 : Nat.Prime 11261 := by
  refine Round2Recovery.lucas_list_prime (n := 11261) (a := 2)
    (factors := [2, 2, 5, 563]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_563
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_11299 : Nat.Prime 11299 := by
  refine Round2Recovery.lucas_list_prime (n := 11299) (a := 3)
    (factors := [2, 3, 7, 269]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_269
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_11329 : Nat.Prime 11329 := by
  refine Round2Recovery.lucas_list_prime (n := 11329) (a := 7)
    (factors := [2, 2, 2, 2, 2, 2, 3, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_11351 : Nat.Prime 11351 := by
  refine Round2Recovery.lucas_list_prime (n := 11351) (a := 7)
    (factors := [2, 5, 5, 227]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_227
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

end LCMSourcePV.PrimeFacts
