import LCMSourcePV.PrimeCover.Search

set_option autoImplicit false
set_option maxHeartbeats 0

namespace LCMSourcePV.PrimeCover

theorem search_some_bounds {a count p : Nat} (h : Math.search a count=some p) :
    a<p ∧ p≤a+count := by
  induction count with
  | zero => simp [Math.search] at h
  | succ k ih =>
    by_cases hp : Nat.Prime (a+1+k)
    · simp only [Math.search,if_pos hp,Option.some.injEq] at h
      omega
    · have hh := ih (by simpa [Math.search,hp] using h)
      omega

theorem next_some_link {a den p : Nat} (allowed : NextAllowed a den)
    (h : Math.next den a=some p) :
    Nat.Prime p ∧ a<p ∧ den*p<(den+1)*a ∧ p<wordMod := by
  have hs := search_some_bounds h
  have hp := Math.search_some_prime h
  have hu : p≤Math.upper den a := by
    change a<p ∧ p≤a+(Math.upper den a-a) at hs
    omega
  have hprod : den*p≤(den+1)*a-1 := by
    calc
      den*p ≤ den*Math.upper den a := Nat.mul_le_mul_left den hu
      _ ≤ (den+1)*a-1 := by
        simpa only [Math.upper,Nat.mul_comm] using Nat.div_mul_le_self ((den+1)*a-1) den
  have hpos : 0<(den+1)*a := Nat.mul_pos (by omega) allowed.1
  exact ⟨hp,hs.1,by omega,hu.trans_lt (allowed_upper_word allowed)⟩

/-- A finite execution skeleton for successful completion of the actual cover
constructor. Each step identifies the result of the same greedy source search;
no predicate asserting mathematical coverage is a field. -/
inductive CoverTrace (den b : Nat) : Nat → Nat → List Nat → Prop
  | done (fuel a : Nat) (stop : b≤a) : CoverTrace den b fuel a []
  | step (fuel a p : Nat) (ps : List Nat) (active : a<b)
      (allowed : NextAllowed a den) (next : Math.next den a=some p)
      (rest : CoverTrace den b fuel p ps) : CoverTrace den b (fuel+1) a (p::ps)

theorem trace_run {den b fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den b fuel a ps) : Math.run den fuel a b=ps := by
  induction trace with
  | done fuel a stop =>
    cases fuel <;> simp [Math.run,stop]
  | step fuel a p ps active allowed next rest ih =>
    simpa only [Math.run,if_neg (by omega : ¬b≤a),next] using congrArg (List.cons p) ih

theorem trace_check {den b fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den b fuel a ps) : Math.check den a b ps=true := by
  induction trace with
  | done fuel a stop => simp [Math.check,stop]
  | step fuel a p ps active allowed next rest ih =>
    have hp := next_some_link allowed next
    simp [Math.check,hp.1,hp.2.1,hp.2.2.1,ih]

theorem trace_length {den b fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den b fuel a ps) : ps.length≤fuel := by
  induction trace with
  | done => simp
  | step _ _ _ _ _ _ _ _ ih => simp only [List.length_cons]; omega

def gapCheck (den a p : Nat) : Bool :=
  (List.range (Math.upper den a-p)).all fun k => decide (¬Nat.Prime (p+1+k))

theorem gapCheck_sound {den a p : Nat} (h : gapCheck den a p=true) :
    ∀q, p<q → q≤Math.upper den a → ¬Nat.Prime q := by
  intro q hq hu
  have hidx : q-p-1 < Math.upper den a-p := by omega
  have hb := List.all_eq_true.mp h (q-p-1) (List.mem_range.mpr hidx)
  have he : p+1+(q-p-1)=q := by omega
  simpa [he] using hb

instance nextAllowedDecidable (a den : Nat) : Decidable (NextAllowed a den) := by
  unfold NextAllowed
  infer_instance

def traceCheck (den b : Nat) : Nat → Nat → List Nat → Bool
  | _,a,[] => decide (b≤a)
  | fuel,a,p::ps =>
      decide (0<fuel ∧ a<b ∧ NextAllowed a den ∧ a<p ∧ p≤Math.upper den a) &&
        gapCheck den a p && traceCheck den b (fuel-1) p ps

theorem trace_of_checks {den b fuel a : Nat} {ps : List Nat}
    (primes : ∀p∈ps,Nat.Prime p) (checked : traceCheck den b fuel a ps=true) :
    CoverTrace den b fuel a ps := by
  induction ps generalizing fuel a with
  | nil => exact CoverTrace.done fuel a (by simpa [traceCheck] using checked)
  | cons p ps ih =>
    have hh : (0<fuel ∧ a<b ∧ NextAllowed a den ∧ a<p ∧ p≤Math.upper den a) ∧
        gapCheck den a p=true ∧ traceCheck den b (fuel-1) p ps=true := by
      simpa [traceCheck,Bool.and_eq_true,and_assoc] using checked
    have hnext := Math.next_max (by omega : a≤Math.upper den a)
      (primes p (by simp)) hh.1.2.2.2.1 hh.1.2.2.2.2 (gapCheck_sound hh.2.1)
    obtain ⟨remaining,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : fuel≠0)
    apply CoverTrace.step remaining a p ps hh.1.2.1 hh.1.2.2.1 hnext
    apply ih (fun q hq => primes q (by simp [hq]))
    simpa using hh.2.2

#print axioms trace_run
#print axioms trace_check
#print axioms trace_of_checks

end LCMSourcePV.PrimeCover
