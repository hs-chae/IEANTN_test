import LCMSourcePV.PrimeCover.Memory

set_option autoImplicit false
set_option maxHeartbeats 0

namespace LCMSourcePV.PrimeCover

theorem next_positive_allowed {a den p : Nat} (run : NextExec a den p) (hp : 0<p) :
    NextAllowed a den := by
  rcases run with ⟨ha,hd,run⟩
  split at run
  · omega
  · rename_i guards
    split at run
    · omega
    · rename_i overflow
      have hden : 0<den+1 := by omega
      have hprod : (den+1)*a≤wordMod-1 := by
        have hm := Nat.mul_le_mul_left (den+1) (show a≤(wordMod-1)/(den+1) by omega)
        have hquot := Nat.div_mul_le_self (wordMod-1) (den+1)
        nlinarith
      unfold NextAllowed
      exact ⟨by omega,by omega,by omega,by omega⟩

theorem next_positive_some {a den p : Nat} (run : NextExec a den p) (hp : 0<p) :
    Math.next den a=some p := by
  have allowed := next_positive_allowed run hp
  have hh := next_exec_math allowed run
  cases he : Math.next den a with
  | none => simp [he] at hh; omega
  | some q => simpa [he] using hh

theorem stored_unique {state : CState} {xs ys : List Nat}
    (hx : Stored state xs) (hy : Stored state ys) : xs=ys := by
  apply List.ext_getElem
  · exact hx.1.symm.trans hy.1
  · intro i hi hj
    exact (hx.2 i hi).symm.trans (hy.2 i hj)

/-- Reverse correctness: every successful modeled source execution determines
the greedy mathematical trace and the exact words written. The execution rules
do not assume a cover predicate or successful numerical certificate. -/
theorem loop_certificate {den tail capacity : Nat} {state final : CState}
    (run : LoopExec den tail capacity state final) :
    ∀prior, Good capacity state → Stored state prior → tail≤final.a →
      ∃ps, CoverTrace den tail (capacity-state.count) state.a ps ∧
        Stored final (prior++ps) := by
  induction run with
  | done state guard =>
    intro prior good stored endpoint
    refine ⟨[],CoverTrace.done _ _ ?_,?_⟩
    · simpa [finish] using endpoint
    · simpa [Stored,finish] using stored
  | failed state guard call =>
    intro prior good stored endpoint
    simp only [finish] at endpoint
    omega
  | step state final p guard positive call store rest ih =>
    intro prior good stored endpoint
    have allowed := next_positive_allowed call positive
    have next := next_positive_some call positive
    have link := next_some_link allowed next
    obtain ⟨ps,trace,written⟩ := ih (prior++[p])
      (advance_good good guard.1 link.2.2.2)
      (advance_stored good guard.1 stored p) endpoint
    have hcount : capacity-state.count=(capacity-(advance state p).count)+1 := by
      change capacity-state.count=(capacity-bump state.count)+1
      rw [count_bump good guard.1]
      omega
    refine ⟨p::ps,?_,?_⟩
    · rw [hcount]
      exact CoverTrace.step _ _ p ps guard.2 allowed next trace
    · simpa [List.append_assoc] using written

theorem loop_check_output {den tail capacity start : Nat} {output : List Nat}
    {final : CState} (run : LoopExec den tail capacity (initial start capacity) final)
    (good : Good capacity (initial start capacity)) (endpoint : tail≤final.a)
    (written : Stored final output) : Math.check den start tail output=true := by
  obtain ⟨ps,trace,stored⟩ := loop_certificate run [] good (initial_stored _ _) endpoint
  have he : ps=output := stored_unique (by simpa using stored) written
  subst output
  exact trace_check trace

#print axioms loop_certificate
#print axioms loop_check_output

end LCMSourcePV.PrimeCover
