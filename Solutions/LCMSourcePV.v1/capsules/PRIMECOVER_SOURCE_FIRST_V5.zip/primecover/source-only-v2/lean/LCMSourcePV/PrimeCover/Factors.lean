import LCMSourcePV.PrimeCover.Trace

set_option autoImplicit false
set_option maxHeartbeats 0

namespace LCMSourcePV.PrimeCover

/-- Only cheap integer equalities are evaluated. Primality is never an oracle
in this checker: each skipped candidate has a proper divisor. -/
def compositeRange : Nat → Nat → List Nat → Bool
  | _,0,[] => true
  | lo,count+1,d::ds => decide (2≤d ∧ d<lo ∧ lo%d=0) &&
      compositeRange (lo+1) count ds
  | _,_,_ => false

theorem compositeRange_sound {lo count : Nat} {ds : List Nat}
    (checked : compositeRange lo count ds=true) :
    ∀q,lo≤q → q<lo+count → ¬Nat.Prime q := by
  induction ds generalizing lo count with
  | nil => cases count <;> simp_all [compositeRange]
  | cons d ds ih =>
    cases count with
    | zero => simp [compositeRange] at checked
    | succ count =>
      have hh : (2≤d ∧ d<lo ∧ lo%d=0) ∧ compositeRange (lo+1) count ds=true := by
        simpa [compositeRange,Bool.and_eq_true] using checked
      intro q hlo hhi hp
      by_cases he : q=lo
      · subst q
        exact (Nat.prime_def_lt'.mp hp).2 d hh.1.1 hh.1.2.1
          (Nat.dvd_of_mod_eq_zero hh.1.2.2)
      · exact ih hh.2 q (by omega) (by omega) hp

def factorTraceCheck (den b : Nat) : Nat → Nat → List Nat → List (List Nat) → Bool
  | _,a,[],[] => decide (b≤a)
  | fuel,a,p::ps,ds::rest =>
      decide (0<fuel ∧ a<b ∧ NextAllowed a den ∧ a<p ∧ p≤Math.upper den a) &&
        compositeRange (p+1) (Math.upper den a-p) ds &&
        factorTraceCheck den b (fuel-1) p ps rest
  | _,_,_,_ => false

theorem trace_of_factor_checks {den b fuel a : Nat} {ps : List Nat}
    {factors : List (List Nat)} (primes : ∀p∈ps,Nat.Prime p)
    (checked : factorTraceCheck den b fuel a ps factors=true) :
    CoverTrace den b fuel a ps := by
  induction ps generalizing fuel a factors with
  | nil =>
    cases factors with
    | nil => exact CoverTrace.done fuel a (by simpa [factorTraceCheck] using checked)
    | cons => simp [factorTraceCheck] at checked
  | cons p ps ih =>
    cases factors with
    | nil => simp [factorTraceCheck] at checked
    | cons ds rest =>
      have hh : (0<fuel ∧ a<b ∧ NextAllowed a den ∧ a<p ∧ p≤Math.upper den a) ∧
          compositeRange (p+1) (Math.upper den a-p) ds=true ∧
          factorTraceCheck den b (fuel-1) p ps rest=true := by
        simpa [factorTraceCheck,Bool.and_eq_true,and_assoc] using checked
      have composite : ∀q,p<q → q≤Math.upper den a → ¬Nat.Prime q := by
        intro q hq hu
        exact compositeRange_sound hh.2.1 q (by omega) (by omega)
      have hnext := Math.next_max (by omega : a≤Math.upper den a)
        (primes p (by simp)) hh.1.2.2.2.1 hh.1.2.2.2.2 composite
      obtain ⟨remaining,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : fuel≠0)
      apply CoverTrace.step remaining a p ps hh.1.2.1 hh.1.2.2.1 hnext
      apply ih (fun q hq => primes q (by simp [hq]))
      simpa using hh.2.2

def allPrime : List Nat → Prop
  | [] => True
  | p::ps => Nat.Prime p ∧ allPrime ps

theorem allPrime_append {xs ys : List Nat} (hx : allPrime xs) (hy : allPrime ys) :
    allPrime (xs++ys) := by
  induction xs with
  | nil => exact hy
  | cons x xs ih => exact ⟨hx.1,ih hx.2⟩

theorem allPrime_mem {ps : List Nat} (h : allPrime ps) : ∀p∈ps,Nat.Prime p := by
  induction ps with
  | nil => simp
  | cons q qs ih =>
    intro p hp
    rcases List.mem_cons.mp hp with rfl|hp
    · exact h.1
    · exact ih h.2 p hp

#print axioms trace_of_factor_checks
end LCMSourcePV.PrimeCover
