import LCMSourcePV.PrimeCover.ASTTrial

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.AST.C
open LCMSourcePV.Witness.C

def PrimeCorrect (call : Service) : Prop :=
  ∀n result,PrimeExec n result → call "pc_is_prime" [n]=some result

def descCondition : Expr := .binary "<" (.var "a") (.var "p")
def descCall : Expr := .call (.var "pc_is_prime") [.var "p"]
def descBody : Stmt := .sequence [
  .branch descCall (.returnStmt (.var "p")) .skip,
  .sequence [.eval (.unary "--" (.var "p")),.skip]]
def descOutcome (result : Nat) (s : State) : Flow :=
  if result=0 then .continuing s else .returned s result

theorem desc_condition_eval {call : Service} {s : State} {a p : Nat}
    (ha : s.env "a"=some a) (hp : s.env "p"=some p) :
    Eval call descCondition s s (bool (a<p)) := by
  simp [Eval,eval,evalPure,descCondition,ha,hp,binary]

theorem desc_call_eval {call : Service} (correct : PrimeCorrect call)
    {s : State} {p result : Nat} (hp : s.env "p"=some p)
    (run : PrimeExec p result) : Eval call descCall s s result := by
  have hc := correct p result run
  simp [Eval,eval,evalPure,descCall,hp,List.mapM_cons,List.mapM_nil,hc]

theorem desc_refines {a p result : Nat} (execution : DescExec a p result)
    (call : Service) (correct : PrimeCorrect call) :
    ∀s, s.env "a"=some a → s.env "p"=some p →
      ∃t, WhileRun call descCondition descBody s (descOutcome result t) ∧ t.heap=s.heap := by
  induction execution with
  | done p guard =>
    intro s ha hp
    refine ⟨s,?_,rfl⟩
    change WhileRun call descCondition descBody s (.continuing s)
    exact ASTLoops.WhileRun.done (desc_condition_eval ha hp) (by simp [truth,bool,guard])
  | found p guard query =>
    intro s ha hp
    have positive : p≠0 := by omega
    refine ⟨s,?_,rfl⟩
    change WhileRun call descCondition descBody s (if p=0 then _ else _)
    rw [if_neg positive]
    apply ASTLoops.WhileRun.returned (desc_condition_eval ha hp) (by simp [truth,bool,guard])
    apply sequence2_returned
    apply ASTLoops.StmtRun.branch (desc_call_eval correct hp query)
    simpa [truth] using ASTLoops.StmtRun.returnValue
      (show Eval call (.var "p") s s p by simp [Eval,eval,evalPure,hp])
  | step p result guard query rest ih =>
    intro s ha hp
    let next : State := {s with env:=bind s.env "p" (lower p)}
    obtain ⟨t,run,heap⟩ := ih next (by simp [next,bind,ha]) (by simp [next,bind])
    refine ⟨t,?_,heap⟩
    apply ASTLoops.WhileRun.next (desc_condition_eval ha hp) (by simp [truth,bool,guard])
    · apply sequence2
      · apply ASTLoops.StmtRun.branch (desc_call_eval correct hp query)
        simpa [truth] using ASTLoops.StmtRun.skip s
      · apply sequence2
        · apply ASTLoops.StmtRun.evaluate
          change eval call s (.unary "--" (.var "p"))=some (next,lower p)
          simp [eval,next,hp,lower]
        · exact ASTLoops.StmtRun.skip next
    · exact run

def nextFirstGuard : Expr := expr (.binary .lor (.binary .lor
  (.binary .eq (.var .a) (.lit 0)) (.binary .eq (.var .den) (.lit 0)))
  (.binary .eq (.var .den) .maxWord))
def nextSecondGuard : Expr := expr (.binary .gt (.var .a)
  (.binary .div .maxWord (.binary .add (.var .den) (.lit 1))))
def nextInitial : Expr := expr (.binary .div (.binary .sub
  (.binary .mul (.binary .add (.var .den) (.lit 1)) (.var .a)) (.lit 1)) (.var .den))
def nextInput (a den : Nat) (heap : Heap) : State :=
  ⟨bind (bind emptyEnv "a" a) "den" den,heap⟩
def nextFirst : Stmt := .branch nextFirstGuard (.returnStmt (.nat 0)) .skip
def nextSecond : Stmt := .branch nextSecondGuard (.returnStmt (.nat 0)) .skip
def nextDeclaration : Stmt := .declare [⟨"uint64_t","p",some nextInitial⟩]
def nextEnd : Stmt := .sequence [.whileLoop descCondition descBody,
  .sequence [.returnStmt (.nat 0),.skip]]
def nextTail : Stmt := .sequence [nextSecond,.sequence [nextDeclaration,nextEnd]]

theorem next_source_shape : stmt Source.nextFunction.body =
    .sequence [nextFirst,nextTail] := rfl

theorem next_first_eval {call : Service} {s : State} {a den : Nat}
    (allowed : NextAllowed a den) (ha : s.env "a"=some a) (hd : s.env "den"=some den) :
    Eval call nextFirstGuard s s 0 := by
  have ha0 : a≠0 := by have := allowed.1; omega
  have hd0 : den≠0 := by have := allowed.2.1; omega
  have hdmax : den≠wordMod-1 := by have := allowed.2.2.1; omega
  simp [Eval,eval,evalPure,nextFirstGuard,expr,Source.binText,Source.varText,ha,hd,binary,bool,truth,ha0,hd0,hdmax]

theorem next_second_eval {call : Service} {s : State} {a den : Nat}
    (allowed : NextAllowed a den) (ha : s.env "a"=some a) (hd : s.env "den"=some den) :
    Eval call nextSecondGuard s s 0 := by
  have hmod : (den+1)%wordMod=den+1 := Nat.mod_eq_of_lt (by have := allowed.2.2.1; omega)
  have one : 1%wordMod=1 := by decide
  have hden : den+1≠0 := by omega
  have hg := allowed_no_overflow allowed
  simp [Eval,eval,evalPure,nextSecondGuard,expr,Source.binText,Source.varText,ha,hd,binary,bool,one,hmod,hden,hg]

theorem next_initial_eval {call : Service} {s : State} {a den : Nat}
    (allowed : NextAllowed a den) (ha : s.env "a"=some a) (hd : s.env "den"=some den) :
    evalPure call s.env 100 nextInitial=some (Math.upper den a) := by
  have hmod : (den+1)%wordMod=den+1 := Nat.mod_eq_of_lt (by have := allowed.2.2.1; omega)
  have hpmod : ((den+1)*a)%wordMod=(den+1)*a := Nat.mod_eq_of_lt allowed.2.2.2
  have hpos : 0<(den+1)*a := Nat.mul_pos (by omega) allowed.1
  have sub := lower_exact hpos allowed.2.2.2
  have one : 1%wordMod=1 := by decide
  have hd0 : den≠0 := by have := allowed.2.1; omega
  simpa [evalPure,nextInitial,expr,Source.binText,Source.varText,ha,hd,binary,one,hmod,hpmod,hd0,Math.upper,lower] using
    congrArg (fun value => some (value/den)) sub

theorem next_function_refines {a den result : Nat} (allowed : NextAllowed a den)
    (execution : NextExec a den result) (call : Service) (correct : PrimeCorrect call)
    (heap : Heap) :
    ∃t, Run call (stmt Source.nextFunction.body) (nextInput a den heap) (.returned t result) ∧
      t.heap=heap := by
  have hg : ¬(a=0 ∨ den=0 ∨ den=wordMod-1) := by
    rcases allowed with ⟨ha,hd,hm,hp⟩; omega
  have descent : DescExec a (Math.upper den a) result := by
    simpa [hg,allowed_no_overflow allowed] using execution.2.2
  let initial := nextInput a den heap
  let start : State := {initial with env:=bind initial.env "p" (Math.upper den a)}
  have ha : initial.env "a"=some a := by simp [initial,nextInput,bind]
  have hd : initial.env "den"=some den := by simp [initial,nextInput,bind]
  have first : Run call nextFirst initial (.continuing initial) := by
    apply ASTLoops.StmtRun.branch (next_first_eval allowed ha hd)
    simpa [truth] using ASTLoops.StmtRun.skip initial
  have second : Run call nextSecond initial (.continuing initial) := by
    apply ASTLoops.StmtRun.branch (next_second_eval allowed ha hd)
    simpa [truth] using ASTLoops.StmtRun.skip initial
  have declaration : Declare call [⟨"uint64_t","p",some nextInitial⟩] initial start := by
    simp [Declare,declare,List.foldlM,next_initial_eval allowed ha hd,start]
  obtain ⟨t,loop,heap_eq⟩ := desc_refines descent call correct start
    (by simp [start,bind,ha]) (by simp [start,bind])
  refine ⟨t,?_,heap_eq⟩
  rw [next_source_shape]
  apply sequence2 first
  apply sequence2 second
  apply sequence2 (ASTLoops.StmtRun.declare declaration)
  by_cases hr : result=0
  · subst result
    apply sequence2
    · exact ASTLoops.StmtRun.whileLoop loop
    · exact sequence2_returned (ASTLoops.StmtRun.returnValue (literal_zero call t))
  · apply sequence2_returned
    apply ASTLoops.StmtRun.whileLoop
    simpa [descOutcome,hr] using loop

#print axioms next_function_refines
end LCMSourcePV.PrimeCover.AST.C
