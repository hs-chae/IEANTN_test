import Mathlib

set_option autoImplicit false
set_option maxHeartbeats 0

namespace LCMSourcePV.PrimeCover

def wordMod : Nat := 2^64
def bump (d : Nat) : Nat := (d+1) % wordMod

/-- Big-step execution of the actual C `for(d=2;d<=n/d;++d)` body.
The condition, remainder test, early return and uint64 increment are explicit.
This relation performs no primality oracle call. -/
inductive TrialExec (n : Nat) : Nat → Nat → Prop
  | done (d : Nat) (guard : ¬ d ≤ n/d) : TrialExec n d 1
  | found (d : Nat) (guard : d ≤ n/d) (divides : n%d=0) : TrialExec n d 0
  | step (d result : Nat) (guard : d ≤ n/d) (nonzero : n%d≠0)
      (rest : TrialExec n (bump d) result) : TrialExec n d result

/-- Execution of the complete source function: the small-input branch,
initial divisor and returned scalar. Its input is a represented uint64 word. -/
def PrimeExec (n result : Nat) : Prop :=
  n < wordMod ∧ if n < 2 then result=0 else TrialExec n 2 result

theorem bump_exact {n d : Nat} (hn : n < wordMod)
    (hd : 2 ≤ d) (hg : d ≤ n/d) : bump d = d+1 := by
  have hn0 : 0<n := by
    have hdn := hg.trans (Nat.div_le_self n d)
    omega
  have hdn : d<n := hg.trans_lt (Nat.div_lt_self hn0 (by omega))
  unfold bump
  exact Nat.mod_eq_of_lt (by omega)

theorem trial_values {n d result : Nat} (run : TrialExec n d result) :
    result=0 ∨ result=1 := by
  induction run with
  | done => exact Or.inr rfl
  | found => exact Or.inl rfl
  | step _ _ _ _ _ ih => exact ih

theorem trial_success_sound {n d result : Nat} (run : TrialExec n d result)
    (hn : n < wordMod) (hn2 : 2 ≤ n) (hd : 2 ≤ d)
    (prior : ∀ m, 2 ≤ m → m < d → ¬ m ∣ n) :
    result=1 → Nat.Prime n := by
  induction run with
  | done d hg =>
    intro _
    apply Nat.prime_def_le_sqrt.mpr
    refine ⟨hn2,?_⟩
    intro m hm hmS hdvd
    have hmSq : m*m ≤ n := Nat.le_sqrt.mp hmS
    have hmd : m < d := by
      by_contra h
      have hdm : d ≤ m := by omega
      have hdd : d*d ≤ n := (Nat.mul_le_mul hdm hdm).trans hmSq
      have hdiv : d ≤ n/d := (Nat.le_div_iff_mul_le (by omega : 0<d)).mpr hdd
      exact hg hdiv
    exact prior m hm hmd hdvd
  | found d hg hzero => intro h; omega
  | step d result hg hnzero rest ih =>
    intro hr
    have hb := bump_exact hn hd hg
    apply ih (by omega) ?_ hr
    intro m hm hmd hdvd
    rw [hb] at hmd
    by_cases he : m=d
    · subst m
      exact hnzero (Nat.mod_eq_zero_of_dvd hdvd)
    · exact prior m hm (by omega) hdvd

theorem trial_failure_sound {n d result : Nat} (run : TrialExec n d result)
    (hn : n < wordMod) (hd : 2 ≤ d) : result=0 → ¬ Nat.Prime n := by
  induction run with
  | done => intro h; omega
  | found d hg hzero =>
    intro _ hp
    have hdn : d<n := hg.trans_lt (Nat.div_lt_self hp.pos (by omega))
    exact (Nat.prime_def_lt'.mp hp).2 d hd hdn (Nat.dvd_of_mod_eq_zero hzero)
  | step d result hg hnzero rest ih =>
    have hb := bump_exact hn hd hg
    exact ih (by omega)

/-- Source-loop termination with enough finite C iterations. No execution
success or mathematical primality fact is a premise. -/
theorem trial_terminates (n : Nat) (hn : n < wordMod) :
    ∀ fuel d, 2 ≤ d → n < d+fuel → ∃ result, TrialExec n d result := by
  intro fuel
  induction fuel with
  | zero =>
    intro d hd hbound
    refine ⟨1,TrialExec.done d ?_⟩
    intro hg
    have hdn := hg.trans (Nat.div_le_self n d)
    omega
  | succ fuel ih =>
    intro d hd hbound
    by_cases hg : d ≤ n/d
    · by_cases hz : n%d=0
      · exact ⟨0,TrialExec.found d hg hz⟩
      · have hb := bump_exact hn hd hg
        obtain ⟨result,rest⟩ := ih (bump d) (by omega) (by omega)
        exact ⟨result,TrialExec.step d result hg hz rest⟩
    · exact ⟨1,TrialExec.done d hg⟩

theorem prime_exec_terminates (n : Nat) (hn : n < wordMod) :
    ∃ result, PrimeExec n result := by
  by_cases hsmall : n<2
  · exact ⟨0,hn,by simp [hsmall]⟩
  · obtain ⟨result,run⟩ := trial_terminates n hn (n+1) 2 (by omega) (by omega)
    exact ⟨result,hn,by simpa [hsmall] using run⟩

theorem prime_exec_correct {n result : Nat} (run : PrimeExec n result) :
    (result=0 ∨ result=1) ∧ (result=1 ↔ Nat.Prime n) := by
  rcases run with ⟨hn,run⟩
  by_cases hsmall : n<2
  · have hr : result=0 := by simpa [hsmall] using run
    refine ⟨Or.inl hr,?_⟩
    constructor
    · intro h; omega
    · intro hp; have := hp.two_le; omega
  · have hrun : TrialExec n 2 result := by simpa [hsmall] using run
    refine ⟨trial_values hrun,?_⟩
    constructor
    · exact trial_success_sound hrun hn (by omega) (by omega)
        (by intro m hm hlt; omega)
    · intro hp
      rcases trial_values hrun with hz | ho
      · exact False.elim (trial_failure_sound hrun hn (by omega) hz hp)
      · exact ho

theorem prime_exec_of_prime {n : Nat} (hn : n < wordMod) (hp : Nat.Prime n) :
    PrimeExec n 1 := by
  obtain ⟨result,run⟩ := prime_exec_terminates n hn
  have hr := (prime_exec_correct run).2.mpr hp
  simpa only [hr] using run

theorem prime_exec_of_not_prime {n : Nat} (hn : n < wordMod) (hp : ¬ Nat.Prime n) :
    PrimeExec n 0 := by
  obtain ⟨result,run⟩ := prime_exec_terminates n hn
  rcases (prime_exec_correct run).1 with hz | ho
  · simpa only [hz] using run
  · exact False.elim (hp ((prime_exec_correct run).2.mp ho))

#print axioms prime_exec_correct
#print axioms prime_exec_of_prime
#print axioms prime_exec_of_not_prime

end LCMSourcePV.PrimeCover
