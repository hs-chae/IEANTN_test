import LucasCore
import LCMSourcePV.PrimeFacts.H00C000
import LCMSourcePV.PrimeFacts.H01C000
import LCMSourcePV.PrimeFacts.H02C000
import LCMSourcePV.PrimeFacts.H03C000
import LCMSourcePV.PrimeFacts.H03C001
import LCMSourcePV.PrimeFacts.H03C002
import LCMSourcePV.PrimeFacts.H03C003
import LCMSourcePV.PrimeFacts.H03C004
import LCMSourcePV.PrimeFacts.H03C005
import LCMSourcePV.PrimeFacts.H03C006
import LCMSourcePV.PrimeFacts.H03C007
import LCMSourcePV.PrimeFacts.H03C008
import LCMSourcePV.PrimeFacts.H03C009
import LCMSourcePV.PrimeFacts.H03C010
import LCMSourcePV.PrimeFacts.H03C011
import LCMSourcePV.PrimeFacts.H03C012
namespace LCMSourcePV.PrimeFacts
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem prime_24071 : Nat.Prime 24071 := by
  refine Round2Recovery.lucas_list_prime (n := 24071) (a := 11)
    (factors := [2, 5, 29, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_29 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24077 : Nat.Prime 24077 := by
  refine Round2Recovery.lucas_list_prime (n := 24077) (a := 2)
    (factors := [2, 2, 13, 463]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_463
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24151 : Nat.Prime 24151 := by
  refine Round2Recovery.lucas_list_prime (n := 24151) (a := 6)
    (factors := [2, 3, 5, 5, 7, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24203 : Nat.Prime 24203 := by
  refine Round2Recovery.lucas_list_prime (n := 24203) (a := 2)
    (factors := [2, 12101]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_12101
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_24329 : Nat.Prime 24329 := by
  refine Round2Recovery.lucas_list_prime (n := 24329) (a := 3)
    (factors := [2, 2, 2, 3041]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3041
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24533 : Nat.Prime 24533 := by
  refine Round2Recovery.lucas_list_prime (n := 24533) (a := 2)
    (factors := [2, 2, 6133]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_6133
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24551 : Nat.Prime 24551 := by
  refine Round2Recovery.lucas_list_prime (n := 24551) (a := 7)
    (factors := [2, 5, 5, 491]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_491
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24593 : Nat.Prime 24593 := by
  refine Round2Recovery.lucas_list_prime (n := 24593) (a := 3)
    (factors := [2, 2, 2, 2, 29, 53]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_29 | exact prime_53
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24683 : Nat.Prime 24683 := by
  refine Round2Recovery.lucas_list_prime (n := 24683) (a := 2)
    (factors := [2, 7, 41, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_41 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24709 : Nat.Prime 24709 := by
  refine Round2Recovery.lucas_list_prime (n := 24709) (a := 2)
    (factors := [2, 2, 3, 29, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_29 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_24767 : Nat.Prime 24767 := by
  refine Round2Recovery.lucas_list_prime (n := 24767) (a := 5)
    (factors := [2, 7, 29, 61]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_29 | exact prime_61
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25087 : Nat.Prime 25087 := by
  refine Round2Recovery.lucas_list_prime (n := 25087) (a := 3)
    (factors := [2, 3, 37, 113]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_37 | exact prime_113
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25117 : Nat.Prime 25117 := by
  refine Round2Recovery.lucas_list_prime (n := 25117) (a := 5)
    (factors := [2, 2, 3, 7, 13, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_13 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25121 : Nat.Prime 25121 := by
  refine Round2Recovery.lucas_list_prime (n := 25121) (a := 3)
    (factors := [2, 2, 2, 2, 2, 5, 157]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_157
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25127 : Nat.Prime 25127 := by
  refine Round2Recovery.lucas_list_prime (n := 25127) (a := 5)
    (factors := [2, 17, 739]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_17 | exact prime_739
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25261 : Nat.Prime 25261 := by
  refine Round2Recovery.lucas_list_prime (n := 25261) (a := 7)
    (factors := [2, 2, 3, 5, 421]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_421
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25343 : Nat.Prime 25343 := by
  refine Round2Recovery.lucas_list_prime (n := 25343) (a := 5)
    (factors := [2, 12671]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_12671
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_25409 : Nat.Prime 25409 := by
  refine Round2Recovery.lucas_list_prime (n := 25409) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 397]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_397
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25423 : Nat.Prime 25423 := by
  refine Round2Recovery.lucas_list_prime (n := 25423) (a := 3)
    (factors := [2, 3, 19, 223]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_19 | exact prime_223
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25463 : Nat.Prime 25463 := by
  refine Round2Recovery.lucas_list_prime (n := 25463) (a := 5)
    (factors := [2, 29, 439]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_29 | exact prime_439
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25561 : Nat.Prime 25561 := by
  refine Round2Recovery.lucas_list_prime (n := 25561) (a := 11)
    (factors := [2, 2, 2, 3, 3, 5, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25643 : Nat.Prime 25643 := by
  refine Round2Recovery.lucas_list_prime (n := 25643) (a := 2)
    (factors := [2, 12821]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_12821
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_25667 : Nat.Prime 25667 := by
  refine Round2Recovery.lucas_list_prime (n := 25667) (a := 2)
    (factors := [2, 41, 313]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_41 | exact prime_313
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25703 : Nat.Prime 25703 := by
  refine Round2Recovery.lucas_list_prime (n := 25703) (a := 5)
    (factors := [2, 71, 181]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_71 | exact prime_181
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25771 : Nat.Prime 25771 := by
  refine Round2Recovery.lucas_list_prime (n := 25771) (a := 2)
    (factors := [2, 3, 5, 859]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_859
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_25997 : Nat.Prime 25997 := by
  refine Round2Recovery.lucas_list_prime (n := 25997) (a := 2)
    (factors := [2, 2, 67, 97]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_67 | exact prime_97
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26003 : Nat.Prime 26003 := by
  refine Round2Recovery.lucas_list_prime (n := 26003) (a := 2)
    (factors := [2, 13001]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_13001
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_26111 : Nat.Prime 26111 := by
  refine Round2Recovery.lucas_list_prime (n := 26111) (a := 7)
    (factors := [2, 5, 7, 373]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7 | exact prime_373
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26203 : Nat.Prime 26203 := by
  refine Round2Recovery.lucas_list_prime (n := 26203) (a := 3)
    (factors := [2, 3, 11, 397]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_397
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26237 : Nat.Prime 26237 := by
  refine Round2Recovery.lucas_list_prime (n := 26237) (a := 2)
    (factors := [2, 2, 7, 937]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_937
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26293 : Nat.Prime 26293 := by
  refine Round2Recovery.lucas_list_prime (n := 26293) (a := 6)
    (factors := [2, 2, 3, 7, 313]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_313
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26309 : Nat.Prime 26309 := by
  refine Round2Recovery.lucas_list_prime (n := 26309) (a := 2)
    (factors := [2, 2, 6577]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_6577
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26317 : Nat.Prime 26317 := by
  refine Round2Recovery.lucas_list_prime (n := 26317) (a := 6)
    (factors := [2, 2, 3, 3, 17, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_17 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26393 : Nat.Prime 26393 := by
  refine Round2Recovery.lucas_list_prime (n := 26393) (a := 3)
    (factors := [2, 2, 2, 3299]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3299
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26417 : Nat.Prime 26417 := by
  refine Round2Recovery.lucas_list_prime (n := 26417) (a := 3)
    (factors := [2, 2, 2, 2, 13, 127]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_127
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26449 : Nat.Prime 26449 := by
  refine Round2Recovery.lucas_list_prime (n := 26449) (a := 7)
    (factors := [2, 2, 2, 2, 3, 19, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_19 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26479 : Nat.Prime 26479 := by
  refine Round2Recovery.lucas_list_prime (n := 26479) (a := 3)
    (factors := [2, 3, 3, 1471]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1471
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26489 : Nat.Prime 26489 := by
  refine Round2Recovery.lucas_list_prime (n := 26489) (a := 3)
    (factors := [2, 2, 2, 7, 11, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_11 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26501 : Nat.Prime 26501 := by
  refine Round2Recovery.lucas_list_prime (n := 26501) (a := 2)
    (factors := [2, 2, 5, 5, 5, 53]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_53
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26561 : Nat.Prime 26561 := by
  refine Round2Recovery.lucas_list_prime (n := 26561) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 5, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26821 : Nat.Prime 26821 := by
  refine Round2Recovery.lucas_list_prime (n := 26821) (a := 2)
    (factors := [2, 2, 3, 3, 5, 149]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_149
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26839 : Nat.Prime 26839 := by
  refine Round2Recovery.lucas_list_prime (n := 26839) (a := 3)
    (factors := [2, 3, 3, 3, 7, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26861 : Nat.Prime 26861 := by
  refine Round2Recovery.lucas_list_prime (n := 26861) (a := 2)
    (factors := [2, 2, 5, 17, 79]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_17 | exact prime_79
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_26987 : Nat.Prime 26987 := by
  refine Round2Recovery.lucas_list_prime (n := 26987) (a := 2)
    (factors := [2, 103, 131]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_103 | exact prime_131
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27031 : Nat.Prime 27031 := by
  refine Round2Recovery.lucas_list_prime (n := 27031) (a := 6)
    (factors := [2, 3, 5, 17, 53]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_17 | exact prime_53
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27091 : Nat.Prime 27091 := by
  refine Round2Recovery.lucas_list_prime (n := 27091) (a := 2)
    (factors := [2, 3, 3, 5, 7, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27143 : Nat.Prime 27143 := by
  refine Round2Recovery.lucas_list_prime (n := 27143) (a := 5)
    (factors := [2, 41, 331]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_41 | exact prime_331
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27211 : Nat.Prime 27211 := by
  refine Round2Recovery.lucas_list_prime (n := 27211) (a := 10)
    (factors := [2, 3, 5, 907]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_907
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27397 : Nat.Prime 27397 := by
  refine Round2Recovery.lucas_list_prime (n := 27397) (a := 2)
    (factors := [2, 2, 3, 3, 761]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_761
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27509 : Nat.Prime 27509 := by
  refine Round2Recovery.lucas_list_prime (n := 27509) (a := 2)
    (factors := [2, 2, 13, 23, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27539 : Nat.Prime 27539 := by
  refine Round2Recovery.lucas_list_prime (n := 27539) (a := 2)
    (factors := [2, 7, 7, 281]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_281
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27551 : Nat.Prime 27551 := by
  refine Round2Recovery.lucas_list_prime (n := 27551) (a := 17)
    (factors := [2, 5, 5, 19, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_19 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27749 : Nat.Prime 27749 := by
  refine Round2Recovery.lucas_list_prime (n := 27749) (a := 3)
    (factors := [2, 2, 7, 991]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_991
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_27893 : Nat.Prime 27893 := by
  refine Round2Recovery.lucas_list_prime (n := 27893) (a := 2)
    (factors := [2, 2, 19, 367]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19 | exact prime_367
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28097 : Nat.Prime 28097 := by
  refine Round2Recovery.lucas_list_prime (n := 28097) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 439]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_439
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28111 : Nat.Prime 28111 := by
  refine Round2Recovery.lucas_list_prime (n := 28111) (a := 3)
    (factors := [2, 3, 5, 937]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_937
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28123 : Nat.Prime 28123 := by
  refine Round2Recovery.lucas_list_prime (n := 28123) (a := 2)
    (factors := [2, 3, 43, 109]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_43 | exact prime_109
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28181 : Nat.Prime 28181 := by
  refine Round2Recovery.lucas_list_prime (n := 28181) (a := 2)
    (factors := [2, 2, 5, 1409]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_1409
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28349 : Nat.Prime 28349 := by
  refine Round2Recovery.lucas_list_prime (n := 28349) (a := 2)
    (factors := [2, 2, 19, 373]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19 | exact prime_373
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28429 : Nat.Prime 28429 := by
  refine Round2Recovery.lucas_list_prime (n := 28429) (a := 2)
    (factors := [2, 2, 3, 23, 103]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_23 | exact prime_103
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28493 : Nat.Prime 28493 := by
  refine Round2Recovery.lucas_list_prime (n := 28493) (a := 2)
    (factors := [2, 2, 17, 419]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_17 | exact prime_419
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28537 : Nat.Prime 28537 := by
  refine Round2Recovery.lucas_list_prime (n := 28537) (a := 5)
    (factors := [2, 2, 2, 3, 29, 41]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_29 | exact prime_41
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28559 : Nat.Prime 28559 := by
  refine Round2Recovery.lucas_list_prime (n := 28559) (a := 11)
    (factors := [2, 109, 131]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_109 | exact prime_131
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28843 : Nat.Prime 28843 := by
  refine Round2Recovery.lucas_list_prime (n := 28843) (a := 2)
    (factors := [2, 3, 11, 19, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_19 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28871 : Nat.Prime 28871 := by
  refine Round2Recovery.lucas_list_prime (n := 28871) (a := 13)
    (factors := [2, 5, 2887]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_2887
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_28933 : Nat.Prime 28933 := by
  refine Round2Recovery.lucas_list_prime (n := 28933) (a := 2)
    (factors := [2, 2, 3, 2411]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_2411
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29063 : Nat.Prime 29063 := by
  refine Round2Recovery.lucas_list_prime (n := 29063) (a := 10)
    (factors := [2, 11, 1321]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_1321
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29131 : Nat.Prime 29131 := by
  refine Round2Recovery.lucas_list_prime (n := 29131) (a := 2)
    (factors := [2, 3, 5, 971]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_971
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29209 : Nat.Prime 29209 := by
  refine Round2Recovery.lucas_list_prime (n := 29209) (a := 7)
    (factors := [2, 2, 2, 3, 1217]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1217
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29303 : Nat.Prime 29303 := by
  refine Round2Recovery.lucas_list_prime (n := 29303) (a := 7)
    (factors := [2, 7, 7, 13, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_13 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29311 : Nat.Prime 29311 := by
  refine Round2Recovery.lucas_list_prime (n := 29311) (a := 3)
    (factors := [2, 3, 5, 977]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_977
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29327 : Nat.Prime 29327 := by
  refine Round2Recovery.lucas_list_prime (n := 29327) (a := 5)
    (factors := [2, 11, 31, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_31 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29339 : Nat.Prime 29339 := by
  refine Round2Recovery.lucas_list_prime (n := 29339) (a := 2)
    (factors := [2, 14669]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_14669
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_29437 : Nat.Prime 29437 := by
  refine Round2Recovery.lucas_list_prime (n := 29437) (a := 2)
    (factors := [2, 2, 3, 11, 223]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_223
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29453 : Nat.Prime 29453 := by
  refine Round2Recovery.lucas_list_prime (n := 29453) (a := 2)
    (factors := [2, 2, 37, 199]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_37 | exact prime_199
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29537 : Nat.Prime 29537 := by
  refine Round2Recovery.lucas_list_prime (n := 29537) (a := 3)
    (factors := [2, 2, 2, 2, 2, 13, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29633 : Nat.Prime 29633 := by
  refine Round2Recovery.lucas_list_prime (n := 29633) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 463]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_463
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29671 : Nat.Prime 29671 := by
  refine Round2Recovery.lucas_list_prime (n := 29671) (a := 6)
    (factors := [2, 3, 5, 23, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_23 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29789 : Nat.Prime 29789 := by
  refine Round2Recovery.lucas_list_prime (n := 29789) (a := 2)
    (factors := [2, 2, 11, 677]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_677
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29833 : Nat.Prime 29833 := by
  refine Round2Recovery.lucas_list_prime (n := 29833) (a := 5)
    (factors := [2, 2, 2, 3, 11, 113]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_113
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29851 : Nat.Prime 29851 := by
  refine Round2Recovery.lucas_list_prime (n := 29851) (a := 2)
    (factors := [2, 3, 5, 5, 199]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_199
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29863 : Nat.Prime 29863 := by
  refine Round2Recovery.lucas_list_prime (n := 29863) (a := 10)
    (factors := [2, 3, 3, 3, 7, 79]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_79
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_29881 : Nat.Prime 29881 := by
  refine Round2Recovery.lucas_list_prime (n := 29881) (a := 7)
    (factors := [2, 2, 2, 3, 3, 5, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30059 : Nat.Prime 30059 := by
  refine Round2Recovery.lucas_list_prime (n := 30059) (a := 2)
    (factors := [2, 7, 19, 113]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_19 | exact prime_113
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30139 : Nat.Prime 30139 := by
  refine Round2Recovery.lucas_list_prime (n := 30139) (a := 2)
    (factors := [2, 3, 5023]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5023
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30187 : Nat.Prime 30187 := by
  refine Round2Recovery.lucas_list_prime (n := 30187) (a := 5)
    (factors := [2, 3, 3, 3, 13, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30197 : Nat.Prime 30197 := by
  refine Round2Recovery.lucas_list_prime (n := 30197) (a := 2)
    (factors := [2, 2, 7549]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7549
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30203 : Nat.Prime 30203 := by
  refine Round2Recovery.lucas_list_prime (n := 30203) (a := 2)
    (factors := [2, 15101]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_15101
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_30211 : Nat.Prime 30211 := by
  refine Round2Recovery.lucas_list_prime (n := 30211) (a := 2)
    (factors := [2, 3, 5, 19, 53]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_19 | exact prime_53
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30307 : Nat.Prime 30307 := by
  refine Round2Recovery.lucas_list_prime (n := 30307) (a := 2)
    (factors := [2, 3, 5051]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5051
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30559 : Nat.Prime 30559 := by
  refine Round2Recovery.lucas_list_prime (n := 30559) (a := 7)
    (factors := [2, 3, 11, 463]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_463
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30593 : Nat.Prime 30593 := by
  refine Round2Recovery.lucas_list_prime (n := 30593) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 2, 239]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_239
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30671 : Nat.Prime 30671 := by
  refine Round2Recovery.lucas_list_prime (n := 30671) (a := 11)
    (factors := [2, 5, 3067]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_3067
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30763 : Nat.Prime 30763 := by
  refine Round2Recovery.lucas_list_prime (n := 30763) (a := 2)
    (factors := [2, 3, 3, 1709]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_1709
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30851 : Nat.Prime 30851 := by
  refine Round2Recovery.lucas_list_prime (n := 30851) (a := 2)
    (factors := [2, 5, 5, 617]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_617
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_30911 : Nat.Prime 30911 := by
  refine Round2Recovery.lucas_list_prime (n := 30911) (a := 17)
    (factors := [2, 5, 11, 281]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_11 | exact prime_281
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

end LCMSourcePV.PrimeFacts
