import LucasCore
import LCMSourcePV.PrimeFacts.H00C000
import LCMSourcePV.PrimeFacts.H01C000
import LCMSourcePV.PrimeFacts.H02C000
import LCMSourcePV.PrimeFacts.H03C000
import LCMSourcePV.PrimeFacts.H03C001
import LCMSourcePV.PrimeFacts.H03C002
import LCMSourcePV.PrimeFacts.H03C003
import LCMSourcePV.PrimeFacts.H03C004
import LCMSourcePV.PrimeFacts.H03C005
import LCMSourcePV.PrimeFacts.H03C006
import LCMSourcePV.PrimeFacts.H03C007
import LCMSourcePV.PrimeFacts.H03C008
import LCMSourcePV.PrimeFacts.H03C009
import LCMSourcePV.PrimeFacts.H03C010
import LCMSourcePV.PrimeFacts.H03C011
import LCMSourcePV.PrimeFacts.H03C012
import LCMSourcePV.PrimeFacts.H04C000
import LCMSourcePV.PrimeFacts.H04C001
import LCMSourcePV.PrimeFacts.H04C002
import LCMSourcePV.PrimeFacts.H04C003
import LCMSourcePV.PrimeFacts.H04C004
import LCMSourcePV.PrimeFacts.H04C005
import LCMSourcePV.PrimeFacts.H04C006
import LCMSourcePV.PrimeFacts.H04C007
import LCMSourcePV.PrimeFacts.H04C008
import LCMSourcePV.PrimeFacts.H04C009
import LCMSourcePV.PrimeFacts.H04C010
import LCMSourcePV.PrimeFacts.H04C011
import LCMSourcePV.PrimeFacts.H04C012
import LCMSourcePV.PrimeFacts.H04C013
import LCMSourcePV.PrimeFacts.H04C014
import LCMSourcePV.PrimeFacts.H04C015
import LCMSourcePV.PrimeFacts.H04C016
import LCMSourcePV.PrimeFacts.H04C017
import LCMSourcePV.PrimeFacts.H04C018
import LCMSourcePV.PrimeFacts.H04C019
import LCMSourcePV.PrimeFacts.H04C020
import LCMSourcePV.PrimeFacts.H04C021
import LCMSourcePV.PrimeFacts.H04C022
import LCMSourcePV.PrimeFacts.H04C023
import LCMSourcePV.PrimeFacts.H04C024
import LCMSourcePV.PrimeFacts.H04C025
import LCMSourcePV.PrimeFacts.H04C026
import LCMSourcePV.PrimeFacts.H04C027
import LCMSourcePV.PrimeFacts.H04C028
import LCMSourcePV.PrimeFacts.H04C029
import LCMSourcePV.PrimeFacts.H04C030
import LCMSourcePV.PrimeFacts.H05C000
import LCMSourcePV.PrimeFacts.H05C001
import LCMSourcePV.PrimeFacts.H05C002
import LCMSourcePV.PrimeFacts.H05C003
import LCMSourcePV.PrimeFacts.H05C004
import LCMSourcePV.PrimeFacts.H05C005
import LCMSourcePV.PrimeFacts.H05C006
import LCMSourcePV.PrimeFacts.H05C007
import LCMSourcePV.PrimeFacts.H05C008
import LCMSourcePV.PrimeFacts.H05C009
import LCMSourcePV.PrimeFacts.H05C010
import LCMSourcePV.PrimeFacts.H05C011
import LCMSourcePV.PrimeFacts.H05C012
import LCMSourcePV.PrimeFacts.H05C013
import LCMSourcePV.PrimeFacts.H05C014
import LCMSourcePV.PrimeFacts.H05C015
import LCMSourcePV.PrimeFacts.H05C016
import LCMSourcePV.PrimeFacts.H05C017
import LCMSourcePV.PrimeFacts.H05C018
import LCMSourcePV.PrimeFacts.H05C019
import LCMSourcePV.PrimeFacts.H05C020
import LCMSourcePV.PrimeFacts.H05C021
import LCMSourcePV.PrimeFacts.H05C022
import LCMSourcePV.PrimeFacts.H05C023
import LCMSourcePV.PrimeFacts.H05C024
import LCMSourcePV.PrimeFacts.H05C025
import LCMSourcePV.PrimeFacts.H05C026
import LCMSourcePV.PrimeFacts.H05C027
import LCMSourcePV.PrimeFacts.H05C028
import LCMSourcePV.PrimeFacts.H06C000
import LCMSourcePV.PrimeFacts.H06C001
import LCMSourcePV.PrimeFacts.H06C002
import LCMSourcePV.PrimeFacts.H06C003
import LCMSourcePV.PrimeFacts.H06C004
import LCMSourcePV.PrimeFacts.H06C005
import LCMSourcePV.PrimeFacts.H06C006
import LCMSourcePV.PrimeFacts.H06C007
import LCMSourcePV.PrimeFacts.H06C008
import LCMSourcePV.PrimeFacts.H06C009
import LCMSourcePV.PrimeFacts.H06C010
import LCMSourcePV.PrimeFacts.H06C011
import LCMSourcePV.PrimeFacts.H06C012
import LCMSourcePV.PrimeFacts.H07C000
import LCMSourcePV.PrimeFacts.H07C001
import LCMSourcePV.PrimeFacts.H07C002
import LCMSourcePV.PrimeFacts.H07C003
import LCMSourcePV.PrimeFacts.H08C000
import LCMSourcePV.PrimeFacts.H09C000
namespace LCMSourcePV.PrimeFacts
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem prime_6466679 : Nat.Prime 6466679 := by
  refine Round2Recovery.lucas_list_prime (n := 6466679) (a := 7)
    (factors := [2, 3233339]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_3233339
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_7091519 : Nat.Prime 7091519 := by
  refine Round2Recovery.lucas_list_prime (n := 7091519) (a := 7)
    (factors := [2, 7, 506537]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_506537
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

end LCMSourcePV.PrimeFacts
