import LCMSourcePV.PrimeCover.Trial
import LCMSourcePV.PrimeCover.Math

set_option autoImplicit false
set_option maxHeartbeats 0

namespace LCMSourcePV.PrimeCover

def lower (p : Nat) : Nat := (p+wordMod-1) % wordMod

theorem lower_exact {p : Nat} (hp : 0<p) (hw : p<wordMod) : lower p=p-1 := by
  unfold lower
  rw [show p+wordMod-1=(p-1)+wordMod by omega,Nat.add_mod_right]
  exact Nat.mod_eq_of_lt (by omega)

/-- Actual descending C while loop. Each iteration calls the verified source
trial-division function; the loop never invokes a primality oracle. -/
inductive DescExec (a : Nat) : Nat → Nat → Prop
  | done (p : Nat) (guard : ¬a<p) : DescExec a p 0
  | found (p : Nat) (guard : a<p) (call : PrimeExec p 1) : DescExec a p p
  | step (p result : Nat) (guard : a<p) (call : PrimeExec p 0)
      (rest : DescExec a (lower p) result) : DescExec a p result

theorem desc_terminates (a p : Nat) (hp : p<wordMod) :
    ∃ result, DescExec a p result := by
  induction p with
  | zero => exact ⟨0,DescExec.done 0 (by omega)⟩
  | succ p ih =>
    by_cases hg : a<p+1
    · obtain ⟨value,call⟩ := prime_exec_terminates (p+1) hp
      rcases (prime_exec_correct call).1 with hz | ho
      · have hc : PrimeExec (p+1) 0 := by simpa only [hz] using call
        obtain ⟨result,rest⟩ := ih (by omega)
        have hl : lower (p+1)=p := by simpa using lower_exact (by omega : 0<p+1) hp
        exact ⟨result,DescExec.step (p+1) result hg hc (by simpa only [hl] using rest)⟩
      · have hc : PrimeExec (p+1) 1 := by simpa only [ho] using call
        exact ⟨p+1,DescExec.found (p+1) hg hc⟩
    · exact ⟨0,DescExec.done (p+1) hg⟩

theorem desc_math {a p result : Nat} (run : DescExec a p result)
    (hp : p<wordMod) : (Math.search a (p-a)).getD 0=result := by
  induction run with
  | done p hg =>
    have hpa : p≤a := by omega
    simp [Nat.sub_eq_zero_of_le hpa,Math.search]
  | found p hg call =>
    have hprime : Nat.Prime p := (prime_exec_correct call).2.mp rfl
    rw [Math.search_at_top hg,if_pos hprime]
    rfl
  | step p result hg call rest ih =>
    have hprime : ¬Nat.Prime p := by
      intro h
      have bad := (prime_exec_correct call).2.mpr h
      omega
    have hl := lower_exact (by omega : 0<p) hp
    have hrest := ih (by rw [hl]; omega)
    rw [hl] at hrest
    rw [Math.search_at_top hg,if_neg hprime]
    exact hrest

def NextAllowed (a den : Nat) : Prop :=
  0<a ∧ 0<den ∧ den<wordMod-1 ∧ (den+1)*a<wordMod

/-- Execution includes every actual early guard in pc_next. The multiplication,
subtraction and division used for the initial candidate are proved exact below. -/
def NextExec (a den result : Nat) : Prop :=
  a<wordMod ∧ den<wordMod ∧
    if a=0 ∨ den=0 ∨ den=wordMod-1 then result=0
    else if (wordMod-1)/(den+1)<a then result=0
    else DescExec a (Math.upper den a) result

theorem allowed_words {a den : Nat} (h : NextAllowed a den) :
    a<wordMod ∧ den<wordMod := by
  rcases h with ⟨ha,hd,hdw,hp⟩
  have hprod : a≤(den+1)*a := by nlinarith
  omega

theorem allowed_no_overflow {a den : Nat} (h : NextAllowed a den) :
    ¬(wordMod-1)/(den+1)<a := by
  have hprod : a*(den+1)≤wordMod-1 := by
    rw [Nat.mul_comm]
    have := h.2.2.2
    omega
  have hdiv : a≤(wordMod-1)/(den+1) :=
    (Nat.le_div_iff_mul_le (by omega : 0<den+1)).mpr hprod
  omega

theorem allowed_upper_word {a den : Nat} (h : NextAllowed a den) :
    Math.upper den a<wordMod := by
  unfold Math.upper
  have hs := Nat.div_le_self ((den+1)*a-1) den
  have hp := h.2.2.2
  omega

theorem next_exec_terminates {a den : Nat} (h : NextAllowed a den) :
    ∃ result, NextExec a den result := by
  obtain ⟨result,run⟩ := desc_terminates a (Math.upper den a) (allowed_upper_word h)
  refine ⟨result,(allowed_words h).1,(allowed_words h).2,?_⟩
  have hguard : ¬(a=0 ∨ den=0 ∨ den=wordMod-1) := by
    rcases h with ⟨ha,hd,hdw,hp⟩
    omega
  simpa only [if_neg hguard,if_neg (allowed_no_overflow h)] using run

theorem next_exec_math {a den result : Nat} (h : NextAllowed a den)
    (run : NextExec a den result) : (Math.next den a).getD 0=result := by
  have hguard : ¬(a=0 ∨ den=0 ∨ den=wordMod-1) := by
    rcases h with ⟨ha,hd,hdw,hp⟩
    omega
  have hdesc : DescExec a (Math.upper den a) result := by
    simpa only [if_neg hguard,if_neg (allowed_no_overflow h)] using run.2.2
  exact desc_math hdesc (allowed_upper_word h)

theorem next_exec_of_some {a den p : Nat} (h : NextAllowed a den)
    (hspec : Math.next den a=some p) : NextExec a den p := by
  obtain ⟨result,run⟩ := next_exec_terminates h
  have hr := next_exec_math h run
  rw [hspec] at hr
  have heq : p=result := by simpa using hr
  simpa only [←heq] using run

theorem next_exec_of_none {a den : Nat} (h : NextAllowed a den)
    (hspec : Math.next den a=none) : NextExec a den 0 := by
  obtain ⟨result,run⟩ := next_exec_terminates h
  have hr := next_exec_math h run
  rw [hspec] at hr
  have heq : 0=result := by simpa using hr
  simpa only [←heq] using run

#print axioms next_exec_of_some
#print axioms next_exec_of_none

end LCMSourcePV.PrimeCover
