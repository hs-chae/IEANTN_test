import LCMSourcePV.PrimeCover.Trace
import LCMSourcePV.RestrictedC

set_option autoImplicit false
set_option maxHeartbeats 0

namespace LCMSourcePV.PrimeCover

/-- Typed, owned uint64 array object together with the source local variables.
The base is a byte address; the buffer is indexed in eight-byte words. -/
structure CState where
  a : Nat
  count : Nat
  base : Nat
  extent : Nat
  buffer : Nat → Nat
  returned : Option Nat

def Good (capacity : Nat) (state : CState) : Prop :=
  capacity<wordMod ∧ state.a<wordMod ∧ state.count≤capacity ∧
  state.extent=capacity ∧ 0<state.base ∧ state.base%8=0 ∧
  state.base+8*capacity<wordMod ∧ ∀i, i<capacity → state.buffer i<wordMod

def Stored (state : CState) (prior : List Nat) : Prop :=
  state.count=prior.length ∧ ∀i (hi:i<prior.length), state.buffer i=prior[i]

def writeBuffer (state : CState) (index value : Nat) : Nat → Nat :=
  fun i => if i=index then value else state.buffer i

def storeWord (state : CState) (address value : Nat) : Option CState :=
  if state.base≤address ∧ (address-state.base)%8=0 ∧
      (address-state.base)/8<state.extent ∧ address<wordMod ∧ value<wordMod then
    some {state with buffer:=writeBuffer state ((address-state.base)/8) value}
  else none

def advance (state : CState) (p : Nat) : CState :=
  {state with a:=p,count:=bump state.count,buffer:=writeBuffer state state.count p}

def finish (state : CState) : CState := {state with returned:=some state.count}

theorem count_bump {capacity : Nat} {state : CState}
    (good : Good capacity state) (active : state.count<capacity) :
    bump state.count=state.count+1 := by
  unfold bump
  exact Nat.mod_eq_of_lt (by have := good.1; omega)

theorem indexed_store {capacity : Nat} {state : CState} (good : Good capacity state)
    (active : state.count<capacity) {p : Nat} (hp : p<wordMod) :
    storeWord state (state.base+8*state.count) p =
      some {state with buffer:=writeBuffer state state.count p} := by
  have hi : state.count<state.extent := by rw [good.2.2.2.1]; exact active
  have ha : state.base+8*state.count<wordMod := by
    have := good.2.2.2.2.2.2.1
    omega
  simp [storeWord,hi,ha,hp]

theorem advance_good {capacity : Nat} {state : CState} (good : Good capacity state)
    (active : state.count<capacity) {p : Nat} (hp : p<wordMod) :
    Good capacity (advance state p) := by
  rcases good with ⟨hc,ha,hcount,hext,hbase,halign,haddress,hbuffer⟩
  refine ⟨hc,hp,?_,hext,hbase,halign,haddress,?_⟩
  · change bump state.count≤capacity
    rw [count_bump ⟨hc,ha,hcount,hext,hbase,halign,haddress,hbuffer⟩ active]
    omega
  · intro i hi
    change (if i=state.count then p else state.buffer i)<wordMod
    split <;> first | exact hp | exact hbuffer i hi

theorem advance_stored {capacity : Nat} {state : CState} {prior : List Nat}
    (good : Good capacity state) (active : state.count<capacity)
    (stored : Stored state prior) (p : Nat) : Stored (advance state p) (prior++[p]) := by
  refine ⟨?_,?_⟩
  · change bump state.count=(prior++[p]).length
    rw [count_bump good active,stored.1,List.length_append,List.length_singleton]
  · intro i hi
    change (if i=state.count then p else state.buffer i)=(prior++[p])[i]
    by_cases hlt : i<prior.length
    · rw [if_neg (by rw [stored.1]; omega)]
      simpa [List.getElem_append_left hlt] using stored.2 i hlt
    · have he : i=prior.length := by simp only [List.length_append,List.length_singleton] at hi; omega
      subst i
      simp [stored.1]

/-- Dedicated execution of the selected cover while-loop. The actual search
call, early return, checked store and uint64 scalar updates are all explicit. -/
inductive LoopExec (den tail capacity : Nat) : CState → CState → Prop
  | done (state : CState) (guard : ¬(state.count<capacity ∧ state.a<tail)) :
      LoopExec den tail capacity state (finish state)
  | failed (state : CState) (guard : state.count<capacity ∧ state.a<tail)
      (call : NextExec state.a den 0) : LoopExec den tail capacity state (finish state)
  | step (state final : CState) (p : Nat)
      (guard : state.count<capacity ∧ state.a<tail) (positive : 0<p)
      (call : NextExec state.a den p)
      (store : storeWord state (state.base+8*state.count) p=
        some {state with buffer:=writeBuffer state state.count p})
      (rest : LoopExec den tail capacity (advance state p) final) :
      LoopExec den tail capacity state final

theorem trace_loop_exec {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) :
    ∀state prior capacity, Good capacity state → Stored state prior → state.a=a →
      state.count+fuel=capacity →
      ∃final, LoopExec den tail capacity state final ∧
        final.returned=some (prior.length+ps.length) ∧
        Stored final (prior++ps) ∧ tail≤final.a := by
  induction trace with
  | done fuel a stop =>
    intro state prior capacity good stored ha hcapacity
    refine ⟨finish state,LoopExec.done state (by omega),?_,?_,?_⟩
    · simp [finish,stored.1]
    · simpa [finish,Stored] using stored
    · simpa [finish,ha] using stop
  | step fuel a p ps active allowed next rest ih =>
    intro state prior capacity good stored ha hcapacity
    have hg : state.count<capacity := by omega
    have link := next_some_link allowed next
    have hpword : p<wordMod := link.2.2.2
    have nextCall : NextExec state.a den p := by
      rw [ha]
      exact next_exec_of_some allowed next
    have newgood := advance_good good hg hpword
    have newstored := advance_stored good hg stored p
    have hnewcap : (advance state p).count+fuel=capacity := by
      change bump state.count+fuel=capacity
      rw [count_bump good hg]
      omega
    obtain ⟨final,run,returned,output,endpoint⟩ :=
      ih (advance state p) (prior++[p]) capacity newgood newstored rfl hnewcap
    refine ⟨final,LoopExec.step state final p ⟨hg,by omega⟩ (by omega) nextCall
      (indexed_store good hg hpword) run,?_,?_,endpoint⟩
    · simpa [List.length_append,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using returned
    · simpa [List.append_assoc] using output

def initial (start capacity : Nat) : CState :=
  ⟨start,0,8,capacity,fun _=>0,none⟩

theorem initial_good {start capacity : Nat} (hs : start<wordMod)
    (hc : capacity<wordMod) (hspace : 8+8*capacity<wordMod) :
    Good capacity (initial start capacity) := by
  change capacity<wordMod ∧ start<wordMod ∧ 0≤capacity ∧ capacity=capacity ∧ 0<8 ∧ 8%8=0 ∧ 8+8*capacity<wordMod ∧ _
  refine ⟨hc,hs,Nat.zero_le _,rfl,by decide,by decide,hspace,?_⟩
  intro i hi
  change 0<wordMod
  decide

theorem initial_stored (start capacity : Nat) : Stored (initial start capacity) [] := by
  refine ⟨rfl,?_⟩
  intro i hi
  simp at hi

#print axioms trace_loop_exec
#print axioms indexed_store

end LCMSourcePV.PrimeCover
