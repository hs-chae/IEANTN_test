import LCMSourcePV.PrimeCover.ASTCover

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.PrimeCover.AST.C

/-- The written array of a proved execution of the actual source program.
It is extracted from the final machine state, not defined by a prime table. -/
noncomputable def outputState {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (words : InputWords a tail den fuel)
    (space : 8+8*fuel<wordMod) : CState :=
  Classical.choose (source_program_run trace words space).2.2.2.2

theorem output_state_stored {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (words : InputWords a tail den fuel)
    (space : 8+8*fuel<wordMod) : Stored (outputState trace words space) ps :=
  (Classical.choose_spec (Classical.choose_spec
    (source_program_run trace words space).2.2.2.2)).2.2.1

noncomputable def produced {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (words : InputWords a tail den fuel)
    (space : 8+8*fuel<wordMod) : List Nat :=
  List.ofFn fun i : Fin ps.length => (outputState trace words space).buffer i

theorem produced_eq {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (words : InputWords a tail den fuel)
    (space : 8+8*fuel<wordMod) : produced trace words space=ps := by
  apply List.ext_getElem
  · simp [produced]
  · intro i hi hj
    simpa [produced] using (output_state_stored trace words space).2 i hj

theorem produced_checked {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (words : InputWords a tail den fuel)
    (space : 8+8*fuel<wordMod) :
    Math.check den a tail (produced trace words space)=true := by
  rw [produced_eq]
  exact trace_check trace

theorem produced_source {den tail fuel a : Nat} {ps : List Nat}
    (trace : CoverTrace den tail fuel a ps) (words : InputWords a tail den fuel)
    (space : 8+8*fuel<wordMod) :
    SourceProgramRun a tail den fuel (produced trace words space) := by
  rw [produced_eq]
  exact source_program_run trace words space

#print axioms produced_checked
#print axioms produced_source
end LCMSourcePV.PrimeCover.AST.C
