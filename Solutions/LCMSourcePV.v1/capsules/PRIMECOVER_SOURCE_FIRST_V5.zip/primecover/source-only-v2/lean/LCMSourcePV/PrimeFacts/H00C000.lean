import LucasCore
namespace LCMSourcePV.PrimeFacts
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem prime_2 : Nat.Prime 2 := by
  exact Nat.prime_two

end LCMSourcePV.PrimeFacts
