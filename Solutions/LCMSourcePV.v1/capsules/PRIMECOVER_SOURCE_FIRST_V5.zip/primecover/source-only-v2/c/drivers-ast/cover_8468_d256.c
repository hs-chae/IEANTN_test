#include <stdio.h>
#include "../primecover.c"

static uint64_t pc_output[700] = {0};

int main(void) {
uint64_t count = pc_cover(8468,89693,256,700,pc_output);
if((fwrite((&count),8,1,stdout)==1)){
if((fwrite(pc_output,8,count,stdout)==count))return 0;else ;
return 2;
}else ;
return 1;
}
