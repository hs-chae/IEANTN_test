#include <stdio.h>
#include "../primecover.c"

static uint64_t pc_output[512] = {0};

int main(void) {
uint64_t count = pc_cover(3273,89693,125,512,pc_output);
if((fwrite((&count),8,1,stdout)==1)){
if((fwrite(pc_output,8,count,stdout)==count))return 0;else ;
return 2;
}else ;
return 1;
}
