#include <stdint.h>

uint64_t pc_is_prime(uint64_t n) {
    if (n < 2) return 0;
    for (uint64_t d = 2; d <= n / d; ++d) {
        if (n % d == 0) return 0;
    }
    return 1;
}

uint64_t pc_next(uint64_t a, uint64_t den) {
    if (a == 0 || den == 0 || den == UINT64_MAX) return 0;
    if (a > UINT64_MAX / (den + 1)) return 0;
    uint64_t p = ((den + 1) * a - 1) / den;
    while (a < p) {
        if (pc_is_prime(p)) return p;
        --p;
    }
    return 0;
}

uint64_t pc_cover(uint64_t start, uint64_t tail, uint64_t den,
                  uint64_t fuel, uint64_t *out) {
    uint64_t a = start;
    uint64_t count = 0;
    while (count < fuel && a < tail) {
        uint64_t p = pc_next(a, den);
        if (p == 0) return count;
        out[count] = p;
        ++count;
        a = p;
    }
    return count;
}
