#!/usr/bin/env python3
"""Source-cold prime-cover C constructors, actual fixed mains and LCM consumers.

Only pinned generic Lean/Mathlib dependencies may be provided as object inputs.
Every application module is rebuilt into an initially empty output directory.
"""
import argparse,concurrent.futures,hashlib,json,os,pathlib,re,struct,subprocess,tempfile,time
S=pathlib.Path(__file__).resolve().parent
ALLOW={'propext','Classical.choice','Quot.sound'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pairs(items):
    d={}
    for k,v in items:
        if k in d:raise ValueError('duplicate JSON key '+k)
        d[k]=v
    return d
def bad_constant(v):raise ValueError('nonfinite JSON constant '+v)
def load(p):return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=bad_constant)
def publish(p,d):
    fd,name=tempfile.mkstemp(prefix='.receipt-',dir=p.parent)
    with os.fdopen(fd,'w') as f:f.write(json.dumps(d,indent=2)+'\n');f.flush();os.fsync(f.fileno())
    pathlib.Path(name).replace(p)
def fixture_source(rows):
    s='import LCMSourcePV.PrimeCover.DriverVerified\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nnamespace LCMSourcePV.PrimeCover.Fixture\n'
    for r in rows:
        a,d=r['start'],r['den'];literal='['+','.join(map(str,r['output']))+']'
        s+=f'def expected{a} : List Nat := {literal}\ntheorem expected{a}_bound : DriverVerified{a}D{d}.output=expected{a} := by\n  rw [DriverVerified{a}D{d}.output_eq]\n  decide +kernel\n#print axioms expected{a}_bound\n'
    return s+'end LCMSourcePV.PrimeCover.Fixture\n'
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=pathlib.Path,required=True);ap.add_argument('--environment',type=pathlib.Path);ap.add_argument('--jobs',type=int,default=4);ap.add_argument('--validate-only',action='store_true');a=ap.parse_args()
    if not 1<=a.jobs<=8:raise ValueError('jobs must be1..8')
    out=a.out.resolve()
    if out==S or S in out.parents:raise ValueError('output must be outside the source capsule')
    out.mkdir(parents=True,exist_ok=False)
    lock=load(S/'SOURCE_LOCK.json');envfile=a.environment or S/'ENVIRONMENT.json';e=load(envfile)
    required={'schema','targets','files','compiler_sha256','clang_sha256','generic_dependencies','source_module_count','external_generic_imports'}
    if set(lock)!=required or lock['schema']!='lcm-primecover-source-only-v2':raise ValueError('source lock schema')
    paths=[]
    def validate_sources():
        for row in lock['files']:
            if set(row)!={'path','bytes','sha256'} or type(row['bytes']) is not int or row['bytes']<0:raise ValueError('bad locked file record')
            rel=pathlib.PurePosixPath(row['path'])
            if rel.is_absolute() or '..' in rel.parts:raise ValueError('unsafe locked path')
            p=S/rel
            if not p.is_file() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise ValueError('source drift: '+row['path'])
        names=[r['path']for r in lock['files']]
        if len(names)!=len(set(names)):raise ValueError('duplicate locked path')
        actual={str(p.relative_to(S))for root,suffix in [(S/'lean','.lean'),(S/'c','.c')]for p in root.rglob('*'+suffix)}
        expected={p for p in names if p.endswith('.lean') or p.endswith('.c')}
        if actual!=expected:raise ValueError('source population mismatch')
    validate_sources()
    compiler=pathlib.Path(e['compiler']);cc=pathlib.Path(e['clang'])
    if sha(compiler)!=lock['compiler_sha256'] or sha(cc)!=lock['clang_sha256']:raise ValueError('compiler binary mismatch')
    pins={r['name']:r['revision']for r in lock['generic_dependencies']}
    generic=[];seen=set();dependency_checks=[]
    for row in e['generic_dependencies']:
        if row['name']in seen or pins.get(row['name'])!=row['revision']:raise ValueError('generic dependency pin mismatch')
        seen.add(row['name']);repo=pathlib.Path(row['path']);library=pathlib.Path(row['library'])
        head=subprocess.run(['git','-C',str(repo),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
        status=subprocess.run(['git','-C',str(repo),'status','--porcelain','--untracked-files=no'],capture_output=True,text=True,check=True).stdout
        if head!=row['revision'] or status:raise ValueError('generic source revision/cleanliness mismatch: '+row['name'])
        generic.append(library);dependency_checks.append(dict(name=row['name'],revision=head,tracked_source_clean=True,library=str(library),library_exists=library.is_dir()))
    if seen!=set(pins):raise ValueError('generic dependency population mismatch')
    generic.append(compiler.resolve().parent.parent/'lib/lean')
    sources={'.'.join(p.relative_to(S/'lean').with_suffix('').parts):p for p in (S/'lean').rglob('*.lean')}
    if len(sources)!=lock['source_module_count']:raise ValueError('module population mismatch')
    deps={}
    for m,p in sources.items():
        deps[m]=set()
        for q in re.findall(r'^import\s+([A-Za-z0-9_.]+)',p.read_text(),re.M):
            if q in sources:deps[m].add(q)
            elif q not in lock['external_generic_imports'] or not any((d/pathlib.Path(q.replace('.','/')).with_suffix('.olean')).is_file()for d in generic):raise ValueError('non-generic dependency: '+q)
    if any(t not in sources for t in lock['targets']):raise ValueError('missing target')
    fixture=load(S/'EXPECTED_OUTPUTS.json')
    if set(fixture)!={'rows'} or len(fixture['rows'])!=6:raise ValueError('fixture schema/population')
    cases=set()
    for row in fixture['rows']:
        if set(row)!={'start','tail','den','fuel','count','output'}:raise ValueError('fixture row schema')
        if any(type(row[k])is not int or not 0<=row[k]<2**64 for k in ('start','tail','den','fuel','count')):raise ValueError('fixture scalar')
        if type(row['output'])is not list or len(row['output'])!=row['count'] or row['count']>row['fuel'] or any(type(n)is not int or not 0<=n<2**64 for n in row['output']):raise ValueError('fixture output words')
        key=(row['start'],row['den'])
        if key in cases:raise ValueError('duplicate case')
        cases.add(key)
    binding=S/'lean/LCMSourcePV/PrimeCover/FixtureBinding.lean'
    if binding.read_text()!=fixture_source(fixture['rows']):raise ValueError('runtime fixture is not the kernel-bound source data')
    metadata=dict(source_lock_sha256=sha(S/'SOURCE_LOCK.json'),reproducer_sha256=sha(pathlib.Path(__file__)),environment_sha256=sha(envfile),generic_dependencies=dependency_checks,application_cache_input=False)
    if a.validate_only:
        publish(out/'VALIDATION_PASS.json',dict(status='VALIDATION_ONLY_PASS_NO_PROOF_REPLAY',**metadata));print('VALIDATION_ONLY_PASS_NO_PROOF_REPLAY');return
    objects=out/'objects';objects.mkdir();logs=out/'logs';logs.mkdir();environment=dict(os.environ)
    environment['LEAN_PATH']=':'.join(map(str,[objects,*generic]));environment.pop('LEAN_SRC_PATH',None)
    records=[];started=time.monotonic()
    def compile_one(m):
        src=sources[m];obj=objects/pathlib.Path(m.replace('.','/')).with_suffix('.olean');obj.parent.mkdir(parents=True,exist_ok=True)
        cmd=['/usr/bin/time','-v',str(compiler),'-j1','-R',str(S/'lean'),str(src),'-o',str(obj)];t=time.monotonic()
        r=subprocess.run(cmd,env=environment,capture_output=True,text=True);so=logs/(m+'.stdout');se=logs/(m+'.stderr');so.write_text(r.stdout);se.write_text(r.stderr)
        if r.returncode or 'sorryAx' in r.stdout+r.stderr or 'Lean.ofReduceBool' in r.stdout+r.stderr:raise RuntimeError('proof rejected: '+m)
        for line in r.stdout.splitlines():
            if 'depends on axioms:'in line:
                axs=set(line.split('[',1)[1].split(']',1)[0].replace(' ','').split(','))-{''}
                if axs-ALLOW:raise RuntimeError('axiom policy rejected: '+line)
        return dict(module=m,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-t,source_sha256=sha(src),object_sha256=sha(obj),stdout_sha256=sha(so),stderr_sha256=sha(se))
    done=set();pending=set(sources)
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs)as pool:
        active={}
        while pending or active:
            for m in sorted(pending):
                if len(active)>=a.jobs:break
                if deps[m]<=done:active[pool.submit(compile_one,m)]=m;pending.remove(m)
            if not active:raise RuntimeError('cyclic imports')
            ready,_=concurrent.futures.wait(active,return_when=concurrent.futures.FIRST_COMPLETED)
            for f in ready:
                m=active.pop(f);records.append(f.result());done.add(m)
            publish(out/'PROGRESS.json',dict(completed=len(done),total=len(sources),records=records))
    # Every numerical provider/consumer module prints its actual final axiom
    # closure. Require all six main/check and fixture targets, not a sample.
    axioms=(logs/'LCMSourcePV.PrimeCover.DriverVerified.stdout').read_text()
    fixture_log=(logs/'LCMSourcePV.PrimeCover.FixtureBinding.stdout').read_text()
    for row in fixture['rows']:
        a0,d=row['start'],row['den']
        for target in (f'DriverVerified{a0}D{d}.source_run',f'DriverVerified{a0}D{d}.check_true'):
            if target not in axioms:raise RuntimeError('missing final axiom audit '+target)
        if f'expected{a0}_bound'not in fixture_log:raise RuntimeError('missing fixture proof')
    native=[]
    for row in fixture['rows']:
        a0,d=row['start'],row['den'];label=f'{a0}-d{d}';src=S/f'c/drivers-ast/cover_{a0}_d{d}.c';binary=out/label;stream=out/(label+'.words.bin');runs=[]
        for name,cmd in [('build',[str(cc),'-std=c2x','-O2','-isystem','/usr/lib/gcc/x86_64-linux-gnu/11/include',str(src),'-o',str(binary)]),('run',[str(binary)])]:
            t=time.monotonic();stdout=stream if name=='run'else out/(label+'.build.stdout');stderr=out/(label+'.'+name+'.stderr')
            with stdout.open('wb')as o,stderr.open('wb')as er:r=subprocess.run(['/usr/bin/time','-v',*cmd],stdout=o,stderr=er,check=False)
            runs.append(dict(command=cmd,exit_code=r.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr)))
            if r.returncode:raise RuntimeError('actual C '+label+' '+name+' failed')
        raw=stream.read_bytes()
        if len(raw)%8:raise RuntimeError('partial output word')
        values=list(struct.unpack('<'+'Q'*(len(raw)//8),raw))
        if values!=[row['count'],*row['output']]:raise RuntimeError('native output differs from kernel-bound source words')
        native.append(dict(start=a0,den=d,count=row['count'],source_sha256=sha(src),binary_sha256=sha(binary),output_sha256=sha(stream),commands=runs,all_words_equal_kernel_bound_fixture=True))
    validate_sources()
    receipt=dict(status='PASS',source_modules=len(sources),objects_initially_empty=True,seconds=time.monotonic()-started,targets=lock['targets'],axiom_policy=sorted(ALLOW),records=records,native=native,physical_boundary='Pinned uint64_t64/8-byte/little-endian ABI and standard CStdIO object-copy contract; actual process/file I/O is associated by full output-byte receipts, not asserted inside Lean.',**metadata)
    publish(out/'RECEIPT.json',receipt);print(json.dumps({k:receipt[k]for k in ('status','source_modules','seconds','source_lock_sha256')}))
if __name__=='__main__':main()
