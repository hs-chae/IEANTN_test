#!/usr/bin/env python3
"""Strict read-only final acceptance of a completed source-cold replay.
Parses complete multiline compiler axiom reports and checks every recorded
application module and all six physical C output streams.
"""
import argparse,hashlib,json,pathlib,re,struct,tempfile,os
S=pathlib.Path(__file__).resolve().parent
ALLOW={'propext','Classical.choice','Quot.sound'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pairs(items):
    d={}
    for k,v in items:
        if k in d:raise ValueError('duplicate JSON key '+k)
        d[k]=v
    return d
def load(p):return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=lambda s:(_ for _ in ()).throw(ValueError(s)))
def axiom_reports(text):
    pattern=r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]"
    matches=list(re.finditer(pattern,text,re.S))
    if len(matches)!=text.count('depends on axioms:'):raise ValueError('malformed compiler axiom report')
    rows=[]
    for m in matches:
        axioms=[x.strip()for x in m.group(2).split(',')if x.strip()]
        if any(x not in ALLOW for x in axioms):raise ValueError('nonstandard axiom in '+m.group(1)+': '+str(axioms))
        rows.append(dict(declaration=m.group(1),axioms=axioms))
    return rows
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--replay',type=pathlib.Path,required=True);ap.add_argument('--out',type=pathlib.Path,required=True);a=ap.parse_args()
    replay=a.replay.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    lock=load(S/'SOURCE_LOCK.json');r=load(replay/'RECEIPT.json')
    if r['status']!='PASS' or r['source_lock_sha256']!=sha(S/'SOURCE_LOCK.json') or r['objects_initially_empty']is not True or r['application_cache_input']is not False:raise ValueError('replay provenance/status')
    sources={'.'.join(pathlib.PurePosixPath(x['path']).relative_to('lean').with_suffix('').parts):x for x in lock['files']if x['path'].startswith('lean/') and x['path'].endswith('.lean')}
    if r['source_modules']!=len(sources) or len(r['records'])!=len(sources):raise ValueError('module population')
    seen=set();audits=[];all_text=''
    for rec in r['records']:
        m=rec['module']
        if m in seen or m not in sources or rec['exit_code']!=0 or rec['source_sha256']!=sources[m]['sha256']:raise ValueError('module identity/result')
        seen.add(m);src=S/sources[m]['path'];obj=replay/'objects'/pathlib.Path(m.replace('.','/')).with_suffix('.olean');so=replay/'logs'/(m+'.stdout');se=replay/'logs'/(m+'.stderr')
        if sha(src)!=rec['source_sha256'] or sha(obj)!=rec['object_sha256'] or sha(so)!=rec['stdout_sha256'] or sha(se)!=rec['stderr_sha256']:raise ValueError('source/object/log readback '+m)
        text=so.read_text()+'\n'+se.read_text()
        if 'sorryAx'in text or 'Lean.ofReduceBool'in text:raise ValueError('prohibited proof mechanism')
        audits+=axiom_reports(text);all_text+=text
    if seen!=set(sources):raise ValueError('missing module')
    expected=load(S/'EXPECTED_OUTPUTS.json')['rows'];native=r['native'];cases={(x['start'],x['den']):x for x in expected}
    if len(native)!=6 or len({(x['start'],x['den'])for x in native})!=6:raise ValueError('native case population')
    for row in native:
        key=(row['start'],row['den'])
        if key not in cases:raise ValueError('unknown native case')
        e=cases[key];label=f'{key[0]}-d{key[1]}';binary=replay/label;stream=replay/(label+'.words.bin')
        if sha(binary)!=row['binary_sha256'] or sha(stream)!=row['output_sha256']:raise ValueError('native readback')
        raw=stream.read_bytes()
        if len(raw)%8 or list(struct.unpack('<'+'Q'*(len(raw)//8),raw))!=[e['count'],*e['output']]:raise ValueError('physical native words')
        if len(row['commands'])!=2 or any(x['exit_code']!=0 for x in row['commands']):raise ValueError('native command failure')
        for suffix in ('source_run','check_true'):
            name=f'LCMSourcePV.PrimeCover.DriverVerified{key[0]}D{key[1]}.{suffix}'
            if not any(x['declaration']==name for x in audits):raise ValueError('missing final axiom target '+name)
        if not any(x['declaration']==f'LCMSourcePV.PrimeCover.Fixture.expected{key[0]}_bound'for x in audits):raise ValueError('missing fixture target')
    consumers=['E1Tertiary.LcmFinal.quantitative4096','E1Tertiary.LcmFinal.quantitative','E1TwoTracks.TrackAFinal.quantitative','E1TwoTracks.TrackAHighFinal.quantitative','LCMSourcePV.PrimeCover.LcmConsumers.tail256','LCMSourcePV.PrimeCover.LcmConsumers.tail1024']
    if any(not any(x['declaration']==name for x in audits)for name in consumers):raise ValueError('missing full LCM consumer axiom closure')
    result=dict(status='FINAL_STRICT_ACCEPTANCE_PASS',replay_receipt_sha256=sha(replay/'RECEIPT.json'),source_lock_sha256=sha(S/'SOURCE_LOCK.json'),auditor_sha256=sha(pathlib.Path(__file__)),all_source_modules=len(sources),all_native_cases=6,full_LCM_consumers=consumers,axiom_reports=audits,axiom_policy=sorted(ALLOW),physical_boundary=r['physical_boundary'])
    fd,name=tempfile.mkstemp(prefix='.receipt-',dir=out)
    with os.fdopen(fd,'w')as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    pathlib.Path(name).replace(out/'RECEIPT.json');print('FINAL_STRICT_ACCEPTANCE_PASS')
if __name__=='__main__':main()
