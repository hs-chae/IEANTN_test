#!/usr/bin/env python3
"""Package and read back a frozen R-relative source/evidence selection.

No proof or numerical execution is performed. The archive intentionally omits
application objects, executable binaries and caches. Run --verify-only in each
Python optimization mode to independently repeat its complete member readback.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
import time
import zipfile

R = Path(__file__).resolve().parents[1]


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pairs(items):
    out = {}
    for key, value in items:
        require(key not in out, 'duplicate JSON key ' + key)
        out[key] = value
    return out


def load(data):
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))


def safe(name):
    p = PurePosixPath(name)
    require(type(name) is str and str(p) == name and not p.is_absolute()
            and '..' not in p.parts and name != '.', 'unsafe archive path')
    return p


def permitted(name, data):
    p = safe(name)
    require('__pycache__' not in p.parts and p.suffix not in
            {'.olean', '.ilean', '.ir', '.pyc', '.o', '.a', '.so'},
            'object/cache in source-only archive: ' + name)
    require(data[:4] != b'\x7fELF', 'ELF executable in source-only archive: ' + name)


def readme(component):
    witness = component == 'witness'
    capsule = ('witness/source-only-final-v1' if witness else 'primecover/source-only-v2')
    producer = 'reproduce_v2.py' if witness else 'reproduce.py'
    auditor = 'audit_replay_v2.py' if witness else 'audit_replay.py'
    jobs = 16 if witness else 8
    return f'''# {component.title()} source-first LCM release

Extract the archive into a new directory. Its R-relative layout is deliberate:
the proof source capsule is `{capsule}` and the shared public generic setup is
`adaptive/source-only-v1`. Read `{capsule}/{'README_v2.md' if witness else 'README.md'}`.
The original recipes and failed-stage evidence remain historical records.

For an existing pinned public Lean/Mathlib installation, emit component-specific
metadata (eight dependencies for Witness, nine including Cli for PrimeCover):

    python3 adaptive/source-only-v1/prepare_environment.py --component {component} --toolchain /absolute/lean-4.34.0-rc2-linux --mathlib /absolute/mathlib --out /fresh/generic-{component}.json

For a fresh public installation first use the pinned recipe:

    python3 adaptive/source-only-v1/generic_environment/scripts/bootstrap.py --work /fresh/public-generic --receipt /fresh/public-bootstrap.json

Then use that installation's actual toolchain/Mathlib paths in the preparer above.
No old application objects are required or included. Keep replay outputs outside
the source capsule. From `{capsule}` run:

    python3 {producer} --environment /fresh/generic-{component}.json --out /fresh/{component}-proof --jobs {jobs}
    python3 {auditor} --replay /fresh/{component}-proof --out /fresh/{component}-strict

These are portable host replay commands. Final isolation additionally uses the
preserved original namespace helper/SPEC; do not describe direct host execution
as isolated verification. The accepted evidence is explicit about the two-stage
Witness source compilation/audit continuation and the PrimeCover post-success
receipt-filename finalization. Neither failed original outer exit is erased.

The kernel proves application source/AST/execution/output/mathematical closure.
Pinned compiler/runtime/unsigned ABI and successful physical standard I/O remain
the approved generic trust boundary. The analytic tail retains its unchanged
explicit Dusart 2018 Proposition 5.4 source input. No optimality, physical-I/O
infallibility or verified machine-code compiler claim is made.

`MANIFEST.json` pins every other archive member. The included sealer can repeat
complete source-selection/member-hash readback when placed at its original
`primecover/seal_component_archive.py` path in the extracted R-relative tree.
'''.encode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--component', choices=['primecover', 'witness'], required=True)
    ap.add_argument('--archive', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--verify-only', action='store_true')
    a = ap.parse_args()
    started = time.monotonic()
    selection_path = ('primecover/SOURCE_SELECTION_V5.json' if a.component == 'primecover'
                      else 'witness/SOURCE_SELECTION_V1.json')
    expected_schema = ('LCM_PRIMECOVER_FINAL_SOURCE_EVIDENCE_SELECTION_V1' if a.component == 'primecover'
                       else 'LCM_WITNESS_FINAL_SOURCE_EVIDENCE_SELECTION_V1')
    selection_bytes = (R / selection_path).read_bytes()
    selection = load(selection_bytes)
    require(selection['schema'] == expected_schema, 'selection schema')
    members = {}
    for row in selection['files']:
        require(set(row) == {'path', 'bytes', 'sha256'} and type(row['bytes']) is int
                and row['bytes'] >= 0, 'selection row shape')
        name = row['path']
        safe(name)
        require(name not in members, 'duplicate selected member')
        data = (R / name).read_bytes()
        require(len(data) == row['bytes'] and sha(data) == row['sha256'],
                'selected file drift: ' + name)
        permitted(name, data)
        members[name] = data
    root = selection['capsule_root']
    lock_name = root + '/SOURCE_LOCK.json'
    require(lock_name in members and sha(members[lock_name]) == selection['source_lock_sha256'],
            'source lock missing or drifted')
    lock = load(members[lock_name])
    for row in lock['files']:
        name = str(PurePosixPath(root) / safe(row['path']))
        require(name in members and len(members[name]) == row['bytes']
                and sha(members[name]) == row['sha256'], 'source lock coverage: ' + name)
    accepted = selection['canonical_component_receipt']
    require(accepted in members and load(members[accepted])['status'].startswith('PASS_'),
            'component-own acceptance receipt')
    members[selection_path] = selection_bytes
    members['RELEASE_README.md'] = readme(a.component)
    members['primecover/seal_component_archive.py'] = Path(__file__).read_bytes()
    manifest = dict(schema='LCM_SOURCE_ARCHIVE_MEMBER_MANIFEST_V1', component=a.component,
                    source_selection=selection_path, source_selection_sha256=sha(selection_bytes),
                    source_lock_sha256=selection['source_lock_sha256'],
                    files=[dict(path=name, bytes=len(data), sha256=sha(data))
                           for name, data in sorted(members.items())])
    members['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    archive = a.archive.resolve()
    require(not a.out.exists(), 'fresh receipt required')
    if not a.verify_only:
        require(not archive.exists(), 'archive already exists; immutable output')
        archive.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=archive.parent, prefix='.source-archive-')
        os.close(fd)
        try:
            with zipfile.ZipFile(tmp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
                for name, data in sorted(members.items()):
                    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
                    zi.compress_type = zipfile.ZIP_DEFLATED
                    zi.external_attr = 0o100644 << 16
                    z.writestr(zi, data)
            os.rename(tmp, archive)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        require(len(names) == len(set(names)) and set(names) == set(members),
                'archive population differs from selected source/evidence')
        require(z.testzip() is None, 'archive CRC failure')
        for name in names:
            data = z.read(name)
            permitted(name, data)
            require(data == members[name], 'archive member bytes differ: ' + name)
    receipt = dict(status='PASS_SOURCE_ARCHIVE_ALL_MEMBERS_HASH_AND_POPULATION',
                   component=a.component, archive=str(archive.relative_to(R)),
                   archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                   members=len(members), uncompressed_bytes=sum(map(len, members.values())),
                   selected_evidence_files=len(selection['files']),
                   locked_source_files=len(lock['files']), source_selection=selection_path,
                   source_selection_sha256=sha(selection_bytes),
                   source_lock_sha256=selection['source_lock_sha256'],
                   member_manifest_sha256=sha(members['MANIFEST.json']),
                   sealer_sha256=sha(Path(__file__).read_bytes()),
                   seconds=time.monotonic()-started,
                   verification_only=a.verify_only,
                   qualification='Source/evidence packaging readback only; no new proof or numerical execution. Application objects, ELF binaries and caches excluded.')
    a.out.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=a.out.parent, prefix='.archive-receipt-')
    with os.fdopen(fd, 'w') as f:
        json.dump(receipt, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    os.rename(tmp, a.out)
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
