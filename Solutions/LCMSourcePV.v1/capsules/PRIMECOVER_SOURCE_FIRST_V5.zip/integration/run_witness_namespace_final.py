# Copyright (c) 2026 IEANTN contributors. All rights reserved.
# Released under Apache 2.0 license as described in the file LICENSE.
# Authors: OpenAI (Codex)
# Final invocation of the unchanged original IEANTN namespace helper.
from pathlib import Path
import json,os,subprocess,time,hashlib,argparse
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--capsule',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--jobs',type=int,default=16);ap.add_argument('--component',choices=['witness','primecover'],default='witness');a=ap.parse_args()
 if not 1<=a.jobs<=32:raise ValueError('jobs range')
 S=a.capsule.resolve();O=a.out.resolve();O.mkdir(exist_ok=False,parents=True);work=O/'work';(work/'tmp').mkdir(parents=True);root=O/'namespace-root';root.mkdir();original=json.loads((S/'ENVIRONMENT.json').read_text());e=dict(original);entries=[{'kind':'ro','path':'/task','source':str(S)},{'kind':'rw','path':'/work','source':str(work)},{'kind':'dir','path':'/home/worker'},{'kind':'ro','path':'/usr','source':'/usr'},{'kind':'ro','path':'/lib/x86_64-linux-gnu','source':'/usr/lib/x86_64-linux-gnu'},{'kind':'ro','path':'/lib64/ld-linux-x86-64.so.2','source':'/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2'},{'kind':'ro','path':'/bin/sh','source':'/usr/bin/dash'},{'kind':'ro','path':'/bin/bash','source':'/usr/bin/bash'},{'kind':'ro','path':'/opt/lean','source':str(Path(original['compiler']).parent.parent)},{'kind':'ro','path':'/opt/clang','source':str(Path(original['clang']).parent.parent)},{'kind':'ro','path':'/entry.py','source':str(R/'integration/witness_namespace_entry.py')}]
 e['compiler']='/opt/lean/bin/lean';e['clang']='/opt/clang/bin/clang';e['toolchain']='/opt/lean';e['generic_dependencies']=[]
 for dep in original['generic_dependencies']:
  name=dep['name'];sourcePath='/generic-src/'+name;libraryPath='/generic-lib/'+name;entries.append({'kind':'ro','path':sourcePath,'source':dep['path']})
  if Path(dep['library']).is_dir():entries.append({'kind':'ro','path':libraryPath,'source':dep['library']})
  e['generic_dependencies'].append(dict(dep,path=sourcePath,library=libraryPath,sandbox=libraryPath))
 e['namespace_isolation']='Original unchanged IEANTN offline user/mount/PID namespace; sealed source/read-only compiler and public generic sources/libraries; fresh writable work; no application object input.'
 env=O/'INSIDE_ENVIRONMENT.json';env.write_text(json.dumps(e,indent=2)+'\n');entries.append({'kind':'ro','path':'/generic/ENVIRONMENT.json','source':str(env)});spec={'version':1,'root':str(root),'cwd':'/task','uid':os.getuid(),'gid':os.getgid(),'command':['/usr/bin/python3.10','-I','-B','/entry.py',str(a.jobs),a.component],'env':{'PATH':'/opt/lean/bin:/bin:/usr/bin','LANG':'C','LC_ALL':'C','TMPDIR':'/work/tmp','MALLOC_ARENA_MAX':'4'},'network':'offline','tmpfsSize':'256m','tmpSize':'16g','entries':entries};p=O/'SPEC.json';p.write_text(json.dumps(spec,indent=2)+'\n');helper=R/'scripts/agent-sandbox.py';pin=sha(S/'SOURCE_LOCK.json');t=time.monotonic()
 with(O/'stdout.txt').open('wb')as so,(O/'stderr.txt').open('wb')as se:q=subprocess.run(['unshare','--user','--map-root-user','--mount','--propagation','private','--','/usr/bin/python3.10','-I','-B',str(helper),str(p)],stdout=so,stderr=se)
 d={'status':'PASS'if q.returncode==0 else'FAILED_NAMESPACE_PIPELINE','exit_code':q.returncode,'seconds':time.monotonic()-t,'source_lock_sha256':pin,'source_lock_unchanged':sha(S/'SOURCE_LOCK.json')==pin,'spec_sha256':sha(p),'unchanged_original_helper_sha256':sha(helper),'outer_runner_sha256':sha(Path(__file__)),'entry_sha256':sha(R/'integration/witness_namespace_entry.py'),'capsule':str(S),'namespace_work':str(work),'qualification':'Full source/C/strict acceptance is asserted only when the inner NAMESPACE_PIPELINE_RECEIPT and STRICT_RECEIPT both exist and pass; this outer scope receipt is not mathematical evidence alone.'};(O/'NAMESPACE_RUN.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));raise SystemExit(q.returncode if d['source_lock_unchanged']else 1)
if __name__=='__main__':main()
