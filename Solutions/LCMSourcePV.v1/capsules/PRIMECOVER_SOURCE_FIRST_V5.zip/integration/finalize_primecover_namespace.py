# Copyright (c) 2026 IEANTN contributors. All rights reserved.
# Released under Apache 2.0 license as described in the file LICENSE.
# Authors: OpenAI (Codex)
# Additive strict readback of already executed namespace proof/C evidence.
from pathlib import Path
import hashlib,json,subprocess,sys,os,time,tempfile
R=Path(__file__).resolve().parents[1];S=R/'primecover/source-only-v2';P=R/'primecover/full-source-namespace-final-v1';B=R/'primecover/namespace-finalization-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,m):
 if not v:raise ValueError(m)
def pairs(xs):
 d={}
 for k,v in xs:
  need(k not in d,'duplicate JSON');d[k]=v
 return d
def load(p):return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in()).throw(ValueError(x)))
def main():
 B.mkdir(exist_ok=False);source=load(P/'work/proof/RECEIPT.json');strict=load(P/'work/strict/RECEIPT.json');spec=load(P/'SPEC.json');outer=load(P/'NAMESPACE_RUN.json');scope=load(R/'resources/primecover-final-namespace-v1/scope.json');before={str(p):sha(p)for p in [S/'SOURCE_LOCK.json',S/'audit_replay.py',P/'SPEC.json',P/'NAMESPACE_RUN.json',P/'work/proof/RECEIPT.json',P/'work/strict/RECEIPT.json']}
 need(source['status']=='PASS'and source['source_modules']==158 and len(source['records'])==158,'full source proof receipt')
 need(strict['status']=='FINAL_STRICT_ACCEPTANCE_PASS'and strict['all_source_modules']==158 and strict['all_native_cases']==6,'in-namespace strict receipt')
 need(strict['replay_receipt_sha256']==sha(P/'work/proof/RECEIPT.json'),'strict proof association')
 need(strict['auditor_sha256']==sha(S/'audit_replay.py')and strict['source_lock_sha256']==sha(S/'SOURCE_LOCK.json'),'exact auditor/source')
 need(outer['exit_code']==1 and outer['source_lock_unchanged']is True,'preserved original outer failure')
 err=(P/'stderr.txt').read_text();need("ValueError: missing strict acceptance receipt"in err,'known bookkeeping error only')
 need(spec['network']=='offline'and spec['cwd']=='/task','original namespace policy')
 mounts={x['path']:x for x in spec['entries']};need(mounts['/task']['kind']=='ro'and Path(mounts['/task']['source']).resolve()==S.resolve(),'sealed read-only source mount');need(mounts['/work']['kind']=='rw','fresh work mount');need('/generic-src/Cli'in mounts and '/generic-lib/Cli'not in mounts,'Cli source present/cache absence preserved')
 need(outer['spec_sha256']==sha(P/'SPEC.json')and outer['unchanged_original_helper_sha256']==sha(R/'scripts/agent-sandbox.py'),'namespace helper/spec association')
 need(scope['exit_code']==1,'scope original exit preserved')
 runs=[];start=time.monotonic()
 for mode in ['', '-O','-OO']:
  out=B/('strict-'+(mode or 'normal'));cmd=[sys.executable]+([mode]if mode else[])+[str(S/'audit_replay.py'),'--replay',str(P/'work/proof'),'--out',str(out)];t=time.monotonic();q=subprocess.run(cmd,capture_output=True,text=True);log=B/(out.name+'.stdout');log.write_text(q.stdout+q.stderr);need(q.returncode==0,'fresh exact auditor failed '+mode);fresh=load(out/'RECEIPT.json');need(fresh==strict,'fresh strict result changed');runs.append({'optimization':mode or'normal','command':cmd,'exit_code':q.returncode,'seconds':time.monotonic()-t,'receipt_sha256':sha(out/'RECEIPT.json'),'stdout_sha256':sha(log)})
 for p,h in before.items():need(sha(Path(p))==h,'evidence/source changed')
 result={'status':'PASS_FULL158_SIX_C_SIX_LCM_NAMESPACE_WITH_ADDITIVE_STRICT_FINALIZATION','source_modules':158,'native_cases':6,'full_LCM_consumers':strict['full_LCM_consumers'],'namespace_proof_receipt_sha256':sha(P/'work/proof/RECEIPT.json'),'original_in_namespace_strict_sha256':sha(P/'work/strict/RECEIPT.json'),'original_outer_receipt_sha256':sha(P/'NAMESPACE_RUN.json'),'original_scope_sha256':sha(R/'resources/primecover-final-namespace-v1/scope.json'),'spec_sha256':sha(P/'SPEC.json'),'helper_sha256':sha(R/'scripts/agent-sandbox.py'),'finalizer_sha256':sha(Path(__file__)),'readbacks':runs,'seconds':time.monotonic()-start,'evidence_pins':before,'qualification':'Original namespace wrapper remains exit1 after source proof/C and immutable strict auditor both passed; only final receipt filename was wrong (STRICT_RECEIPT expected vs actual RECEIPT). Actual in-namespace strict receipt/hash and known pinned entry control flow establish both prior stage exit0; those are control-flow-derived, not separate captured process receipts. Three fresh host read-only exact-auditor CLIs independently validate every source/object/log/all6physical streams and full6ANT consumers; no158proof rerun or changed mathematical/source claim. No OOM/math failure claimed.','original_outer_status':'FAILED_POST_SUCCESS_RECEIPT_FILENAME_BOOKKEEPING_PRESERVED'}
 fd,tmp=tempfile.mkstemp(dir=B,prefix='.acceptance-')
 with os.fdopen(fd,'w')as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 Path(tmp).replace(B/'FINAL_ACCEPTANCE.json');print(json.dumps({'status':result['status'],'seconds':result['seconds']}))
if __name__=='__main__':main()
