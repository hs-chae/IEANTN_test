# Copyright (c) 2026 IEANTN contributors. All rights reserved.
# Released under Apache 2.0 license as described in the file LICENSE.
# Authors: OpenAI (Codex)
# Reuse of the existing offline source-only replay.
from pathlib import Path
import hashlib,json,subprocess,time,sys
jobs=sys.argv[1];component=sys.argv[2];start=time.monotonic();records=[]
for name,cmd in [('source-proof-and-actual-C',['/usr/bin/python3.10','-I','-B','/task/reproduce.py','--environment','/generic/ENVIRONMENT.json','--out','/work/proof','--jobs',jobs]),('strict-receipt-audit',['/usr/bin/python3.10','-I','-B','/task/audit_replay.py','--replay','/work/proof','--out','/work/strict'])]:
 t=time.monotonic();q=subprocess.run(cmd);records.append({'stage':name,'command':cmd,'exit_code':q.returncode,'seconds':time.monotonic()-t})
 if q.returncode:raise SystemExit(q.returncode)
p=Path('/work/strict/STRICT_RECEIPT.json')
if not p.is_file():raise ValueError('missing strict acceptance receipt')
r={'status':'PASS_SOURCE_COLD_ACTUAL_C_AND_STRICT_AUDIT_OFFLINE_NAMESPACE','component':component,'seconds':time.monotonic()-start,'stages':records,'strict_receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()};Path('/work/NAMESPACE_PIPELINE_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'seconds':r['seconds']}))
