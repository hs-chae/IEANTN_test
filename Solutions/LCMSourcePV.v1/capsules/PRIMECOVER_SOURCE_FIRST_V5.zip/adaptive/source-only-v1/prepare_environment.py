"""Check shared pinned public generic dependencies and emit portable component metadata.
No application objects are inputs and no provided checkout or cache is modified.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,math,os,subprocess,tempfile
S=Path(__file__).resolve().parent
SOURCE_LOCK_SHA='b204282a0b6f60e75c73158be598fd2d54d2416557e6a6015821a376d55367e2'
ENV_LOCK_SHA='888b8a3fbd4b348cedc49aec9ee08b2dd8f704678f581f59c6aab7bbc7b94a73'
RUNTIME_LOCK_SHA='3ce8b2767d0cb64af47e96055e3a600ffe58ffa94f0e8c9580a24cbe7118a8b7'
def require(v,m):
 if not v:raise ValueError(m)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def pairs(items):
 d={}
 for k,v in items:require(k not in d,'duplicate JSON key');d[k]=v
 return d
def finite(s):
 v=float(s);require(math.isfinite(v),'nonfinite JSON');return v
def load(p):return json.loads(p.read_text(),object_pairs_hook=pairs,parse_float=finite,parse_constant=lambda s:(_ for _ in()).throw(ValueError('nonfinite JSON')))
def command(xs):return subprocess.check_output(xs,text=True,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')).strip()
def main():
 p=argparse.ArgumentParser();p.add_argument('--toolchain',type=Path,required=True);p.add_argument('--mathlib',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--component',choices=['adaptive','witness','primecover'],default='adaptive');a=p.parse_args()
 out=a.out.resolve();require(not out.exists(),'fresh environment output required');require(S not in out.parents and out!=S,'environment output outside source capsule')
 root=S/'generic_environment';require(sha(S/'SOURCE_LOCK.json')==SOURCE_LOCK_SHA,'source lock identity');require(sha(root/'ENVIRONMENT.lock.json')==ENV_LOCK_SHA,'public bootstrap lock identity');require(sha(root/'COMPILER_RUNTIME.lock.json')==RUNTIME_LOCK_SHA,'runtime lock identity')
 source=load(S/'SOURCE_LOCK.json');public=load(root/'ENVIRONMENT.lock.json');tool=a.toolchain.resolve();mathlib=a.mathlib.resolve();compiler=tool/'bin/lean';clang=tool/'bin/clang'
 require(sha(compiler)==source['compiler_sha256']and sha(clang)==source['clang_sha256'],'compiler/Clang binary identity')
 spec=importlib.util.spec_from_file_location('ieantn_pinned_runtime',root/'scripts/runtime_identity.py');runtime=importlib.util.module_from_spec(spec);spec.loader.exec_module(runtime);identity=runtime.check_runtime(tool)
 manifest=load(mathlib/'lake-manifest.json');entries=manifest['packages'];manifest_pins={}
 for row in entries:
  require(type(row['name'])is str and row['name']not in manifest_pins,'lake manifest name identity');manifest_pins[row['name']]=row.get('rev')
 dependencies=[]
 selected=list(source['generic_dependencies'])
 if a.component=='primecover':
  cli=next(row for row in public['packages']if row['name']=='Cli')
  require(cli['rev']=='ab3a82db9fea14cf0fd7f5a2de650f4b534640af','PrimeCover Cli source pin')
  selected.append({'name':'Cli','revision':cli['rev']})
 for row in selected:
  name=row['name'];revision=row['revision'];repo=mathlib if name=='mathlib'else mathlib/'.lake/packages'/name
  require(repo.is_dir(),'missing generic dependency '+name)
  if name!='mathlib':require(manifest_pins.get(name)==revision,'lake manifest revision '+name)
  require(command(['git','-C',str(repo),'rev-parse','HEAD'])==revision,'generic commit '+name)
  require(not command(['git','-C',str(repo),'status','--porcelain','--untracked-files=no']),'generic tracked source drift '+name)
  library=repo/'.lake/build/lib/lean'
  require(library.is_dir()or(name=='Cli'and a.component=='primecover'),'generic object directory '+name)
  dependencies.append({'name':name,'revision':revision,'path':str(repo),'library':str(library),'sandbox':'/generic/'+name})
 generic=[Path(r['library'])for r in dependencies]+[tool/'lib/lean']
 for module in source['external_generic_imports']:
  require(any((g/Path(*module.split('.')).with_suffix('.olean')).is_file()for g in generic),'missing pinned generic module '+module)
 d={'schema':'ieantn-shared-generic-environment-v1','component':a.component,'optional_unused_Cli_cache_present':(mathlib/'.lake/packages/Cli/.lake/build/lib/lean').is_dir()if a.component=='primecover'else None,'compiler':str(compiler),'clang':str(clang),'toolchain':str(tool),'compiler_version':identity['version'],'clang_version':command([str(clang),'--version']),'lean_archive_sha256':public['lean_asset']['digest'].removeprefix('sha256:'),'compiler_sha256':sha(compiler),'clang_sha256':sha(clang),'generic_dependencies':dependencies,'actual_runtime_identity':identity,'generic_only':True,'source_lock_sha256':SOURCE_LOCK_SHA,'prepare_script_sha256':sha(Path(__file__)),'public_recipe_lock_sha256':ENV_LOCK_SHA,'qualifier':'Checks an already prepared pinned public generic environment. Fresh OS/download/bootstrap and application proof replay are separate stages. PrimeCover requires9 source metadata entries including unused Cli; Adaptive/Witness require8. An absent unused Cli cache is recorded, not silently built or used as an application dependency.'}
 out.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(dir=out.parent,prefix='.environment-')
 with os.fdopen(fd,'w')as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,out);print(json.dumps({'status':'PINNED_SHARED_GENERIC_ENVIRONMENT_READY','dependencies':len(dependencies),'environment_sha256':sha(out)}))
if __name__=='__main__':main()
