"""Freeze an explicit source/evidence-only Adaptive capsule and check every ZIP byte."""
from pathlib import Path
import hashlib,json,shutil,stat,zipfile
R=Path(__file__).resolve().parents[1];A=R/'adaptive';S=A/'source-only-v1'
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):
 d=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):d.update(b)
 return d.hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def main():
 out=A/'final-component-v1';need(not out.exists(),'fresh component freeze');out.mkdir();shutil.copyfile(R/'network/LICENSE',S/'LICENSE');lock=json.loads((S/'SOURCE_LOCK.json').read_text());need(sha(S/'SOURCE_LOCK.json')=='b204282a0b6f60e75c73158be598fd2d54d2416557e6a6015821a376d55367e2','source lock')
 proof=A/'full-source-cold-v2/work/results';receipt=json.loads((proof/'RECEIPT.json').read_text());need(receipt['status']=='PASS_FOUR_SOURCE_FIRST_PROGRAMS_AND_UNCHANGED_LCM_CONSUMERS','complete proof');strict=A/'final-audit-controls-v2/normal-positive/RECEIPT.json';need(json.loads(strict.read_text())['status']=='FINAL_STRICT_ACCEPTANCE_PASS','strict gate');scope=R/'resources/adaptive-source-cold-v2/scope.json';sd=json.loads(scope.read_text());need(sd['exit_code']==0,'scope gate');samples=sd['samples'];mem=max(int(x['memory.current'])for x in samples if x.get('memory.current')is not None)
 def events(v):return {k:int(n)for k,n in(x.split()for x in v.splitlines())}
 ev=[events(x['memory.events'])for x in samples if x.get('memory.events')];disk={}
 for root in [S,A/'full-source-cold-v2']:
  paths=[p for p in root.rglob('*')if p.is_file()and not p.is_symlink()];disk[str(root.relative_to(R))]={'regular_files':len(paths),'logical_bytes':sum(p.stat().st_size for p in paths),'allocated_file_bytes':sum(p.stat().st_blocks*512 for p in paths)}
 resources={'status':'COMPLETED_ACTUAL_RESOURCE_LEDGER','scope':str(scope.relative_to(R)),'scope_sha256':sha(scope),'inner_seconds':receipt['seconds'],'outer_seconds':sd['elapsed_seconds'],'requested_memory_bytes':sd['requested_memory_bytes'],'actual_limits':sd['actual_limits'],'cpus':sd['cpus'],'sample_count':len(samples),'maximum_sampled_cgroup_charged_memory_bytes':mem,'max_individual_child_RSS_bytes':json.loads(strict.read_text())['max_individual_child_RSS_bytes'],'oom_counter_max':max(x.get('oom',0)for x in ev),'oom_kill_counter_max':max(x.get('oom_kill',0)for x in ev),'current_disk_snapshots':disk,'qualifications':['memory.current is sampled cgroup-charged memory, not exact aggregate process RSS or exact RAM highwater.','Max individual child RSS is measured separately by /usr/bin/time -v.','Disk values are current regular-file logical/allocated snapshots, not peak disk; directory metadata is excluded.','No accepted proof object or original source is deleted. Cleanup removed only6 fully rehashed deterministic generator-control trees; their allocated regular-file sum was986726400bytes.']};write(out/'RESOURCE_LEDGER.json',resources)
 selected={}
 def add(p):
  p=Path(p);need(p.is_file()and not p.is_symlink(),'regular selected source '+str(p));rel=str(p.relative_to(R));need(p.suffix not in {'.olean','.ilean','.o','.pyc'}and'__pycache__'not in p.parts,'no application cache');selected[rel]={'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)}
 for row in lock['files']:
  p=S/row['path'];need(p.stat().st_size==row['bytes']and sha(p)==row['sha256'],'sealed source drift');add(p)
 for n in ['SOURCE_LOCK.json','README.md','LICENSE','regenerate_data.py','audit_replay.py','prepare_environment.py','reproduce.py','reproduce_inner.py','namespace_replay.py','NAMESPACE_ADAPTER_PROVENANCE.json','GENERIC_RECIPE_PROVENANCE.json']:add(S/n)
 for n in ['ENVIRONMENT.lock.json','COMPILER_RUNTIME.lock.json','scripts/bootstrap.py','scripts/runtime_identity.py']:add(S/'generic_environment'/n)
 add(S/'runtime/agent-sandbox.py')
 for n in ['build_component.py','test_tool_clis.py','test_final_auditor.py','cleanup_tool_fixtures.py','DIRECTED_SOURCE_REPRODUCTION_REVIEW_V1.json','TOOL_COUNT_CORRECTION_V1.json','TOOL_FIXTURE_CLEANUP_PREVIEW.json','TOOL_FIXTURE_CLEANUP_RECEIPT.json']:add(A/n)
 for n in ['RECEIPT.json','SPEC.json','INSIDE_ENVIRONMENT.json','NAMESPACE_RUN.json','stdout.txt','stderr.txt']:
  p=(proof if n=='RECEIPT.json'else A/'full-source-cold-v2')/n
  if p.exists():add(p)
 for p in(proof/'logs').iterdir():add(p)
 for p in proof.iterdir():
  if p.is_file()and p.suffix in {'.stdout','.stderr'}:add(p)
 for dirname in ['tool-controls-v1','tool-controls-v2','final-audit-controls-v1','final-audit-controls-v2','wrapper-preflight-v1','wrapper-preflight-v2','component-environment-controls-v1','component-replayer-preflight-v1']:
  root=A/dirname
  for p in root.iterdir():
   if p.is_file()and p.suffix in {'.json','.stdout','.stderr'}:add(p)
   if p.is_dir()and not p.is_symlink()and ('positive'in p.name or p.name in {'normal','O','OO'}):
    for f in p.glob('*.json'):add(f)
 for p in(A/'tool-history-v1').iterdir():
  if p.is_file():add(p)
 for n in ['scope.json','stdout.txt','stderr.txt']:add(R/'resources/adaptive-source-cold-v2'/n)
 for p in [R/'RESOURCE_POLICY.json',R/'scripts/resource_scope.py',R/'scripts/agent-sandbox.py',R/'publication/WITNESS_MAIN_OUTPUT_INDEPENDENT_REVIEW_V1.json',out/'RESOURCE_LEDGER.json']:add(p)
 # Include the proof source audit rather than operational binary caches.
 for n in ['RECEIPT.json','PROTOCOL_EQUIVALENCE.json']:
  p=A/'wrapper-preflight-v1'/n
  if p.exists():add(p)
 source={'schema':'LCM_ADAPTIVE_FINAL_SOURCE_EVIDENCE_SELECTION_V1','scope':'Sealed1792-module mathematical source plus explicit reproducibility/helper/history/acceptance/resource evidence; no appobjects, executables, caches or regeneration fixtures.','source_lock_sha256':sha(S/'SOURCE_LOCK.json'),'files':[selected[k]for k in sorted(selected)]}
 write(out/'SOURCE_SELECTION.json',source);selection_sha=sha(out/'SOURCE_SELECTION.json');selected[str((out/'SOURCE_SELECTION.json').relative_to(R))]={'path':str((out/'SOURCE_SELECTION.json').relative_to(R)),'bytes':(out/'SOURCE_SELECTION.json').stat().st_size,'sha256':selection_sha}
 archive=out/'ADAPTIVE_SOURCE_FIRST_PV_SOURCE_EVIDENCE.zip'
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True)as z:
  for rel,row in sorted(selected.items()):
   p=R/rel;b=p.read_bytes();need(len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256'],'capture drift');info=zipfile.ZipInfo('IEANTN_LCM_ADAPTIVE/'+rel,date_time=(2026,11,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b,compresslevel=9)
 with zipfile.ZipFile(archive)as z:
  need(z.testzip()is None and len(z.namelist())==len(selected),'archive population/CRC')
  for rel,row in selected.items():need(hashlib.sha256(z.read('IEANTN_LCM_ADAPTIVE/'+rel)).hexdigest()==row['sha256'],'member hash')
 index={'schema':'LCM_ADAPTIVE_FINAL_COMPONENT_INDEX_V1','status':'PASS','claim':'Four fixed C checker instances source/body/init/helper/main verified and consumed by unchanged4 finiteLCM statements;1792freshapplication modules/16finalexports/allStd3.','source_lock':str((S/'SOURCE_LOCK.json').relative_to(R)),'source_lock_sha256':sha(S/'SOURCE_LOCK.json'),'source_selection':str((out/'SOURCE_SELECTION.json').relative_to(R)),'source_selection_sha256':selection_sha,'receipt':str(strict.relative_to(R)),'receipt_sha256':sha(strict),'producer_receipt':str((proof/'RECEIPT.json').relative_to(R)),'producer_receipt_sha256':sha(proof/'RECEIPT.json'),'resource_ledger':str((out/'RESOURCE_LEDGER.json').relative_to(R)),'resource_ledger_sha256':sha(out/'RESOURCE_LEDGER.json'),'source_modules':1792,'closed_final_declarations':16,'actual_C_mains':4,'rows':20075,'archive':str(archive.relative_to(R)),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'archive_payload_files':len(selected),'archive_all_member_hashes_checked':True,'generic_setup':'One pinned public generic installation; default8-entry ENVforAdaptive/Witness and--component primecover9-entry ENVincludingunusedCli. Both generated andactualreplayer preflightscheckedall3modes.','reproduction_qualification':'Original isolated fullV2 pipeline actuallycomplete. Portablewrapper individualstages/preflightchecked, not asecondfresh fullcombineddriver orfreshOSbootstrap claim.','original_mathematics_and_primary_outcomes_changed':False,'native_execution_axioms_in_final_declarations':False};write(out/'FINAL_COMPONENT_INDEX.json',index);print(json.dumps(index))
if __name__=='__main__':main()
