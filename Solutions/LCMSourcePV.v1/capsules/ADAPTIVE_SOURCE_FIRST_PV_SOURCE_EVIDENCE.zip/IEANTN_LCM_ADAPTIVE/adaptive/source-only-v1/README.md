# Reproduce the four Adaptive C checker proofs

This capsule proves the four fixed C certificate-checker instances, their actual source/body executions, and the unchanged finite LCM conclusions. It contains 1,792 application Lean modules and four C mains covering 20,075 certificate rows. It does not claim that the historical search that discovered those rows was a verified constructor. The separate Witness component verifies the 404-block constructor.

The theorem in each row says: for every integer n in the stated half-open interval, there exists a positive integer m below lcm(1,…,n) whose divisor sum is greater than (1 + c/n) times the divisor sum of lcm(1,…,n).

| Instance | c | First n included | First n excluded | Rows |
|---|---:|---:|---:|---:|
| One | 3/10 | 1,000,000 | 71,707,024 | 892 |
| Forty | 2/5 | 5,000,000 | 3,461,204,224 | 5,620 |
| FortyFive | 9/20 | 50,000,000 | 3,461,204,224 | 5,042 |
| Direct | 3/10 | 1,000,000 | 8,044,834,249 | 8,521 |

These finite statements have no Dusart premise. Any separately supplied infinite-tail consumer retains its original literature premise. No coefficient, endpoint, locked certificate, or original experimental outcome is changed here.

## Prepare shared generic dependencies once

Use Linux x86-64 with Python 3.10 available as `/usr/bin/python3.10`, Python 3, Git, GNU tar with zstd support, `/usr/bin/time`, and the generic GCC 11 headers at `/usr/lib/gcc/x86_64-linux-gnu/11/include`. The replay uses the existing rootless user/mount/PID/offline-network namespace facility. It does not change host settings. Namespace setup failure is reported separately from a proof failure.

From this capsule directory, choose fresh absolute directories outside it:

```sh
python3 generic_environment/scripts/bootstrap.py \
  --work /absolute/fresh/shared-generic \
  --receipt /absolute/fresh/generic-bootstrap-receipt.json
python3 prepare_environment.py \
  --toolchain /absolute/fresh/shared-generic/lean-4.34.0-rc2-linux \
  --mathlib /absolute/fresh/shared-generic/mathlib \
  --out /absolute/fresh/ENVIRONMENT.json
```

The first command downloads the pinned public Lean release, checks its exact archive/runtime identities, checks out the pinned public Mathlib commit, obtains its public generic cache, verifies its dependencies, and compiles an import smoke check. It accepts `--resume` only for its own marked work directory. The second command checks an already prepared environment read-only and emits the eight-library metadata used by Adaptive and Witness. Reuse the same generic installation for all three components, but generate a separate nine-entry metadata file for PrimeCover (its unchanged source lock also lists the unused Cli package):

```sh
python3 prepare_environment.py \
  --component primecover \
  --toolchain /absolute/fresh/shared-generic/lean-4.34.0-rc2-linux \
  --mathlib /absolute/fresh/shared-generic/mathlib \
  --out /absolute/fresh/PRIMECOVER_ENVIRONMENT.json
```

Pass `PRIMECOVER_ENVIRONMENT.json` only to PrimeCover. An absent unused Cli cache is explicitly recorded; PrimeCover validates all actually imported generic modules and its exact nine source revisions. A namespace adapter must omit an absent unused Cli cache mount rather than treating it as an existing object directory. Do not copy the historical `ENVIRONMENT.json` snapshot as a relocated installation configuration.

Pinned Lean: **4.34.0-rc2**, commit `6a10ac8c22beadecabdbb0919c2b50214762f91d`. Official archive: <https://github.com/leanprover/lean4/releases/download/v4.34.0-rc2/lean-4.34.0-rc2-linux.tar.zst>, 580,281,129 bytes, SHA-256 `3d011041203acacf300d343a39673f7d233743397993797c941346ae9e5df1a8`. The bundled Clang is **22.1.4**. The compiler launcher and shared-runtime identities are both checked; the small launcher hash alone is not a compiler-runtime identity check.

| Generic package | Exact commit |
|---|---|
| mathlib | `71a80585ee495fc24472fd0eaffc89d94e4fd8d6` |
| batteries | `4cac2177c37f5530c4da76aa8e4307f3fc9e4dcb` |
| Qq | `507746ab8f4b643ccdacb2ec4cdb5853fa9f8ab3` |
| aesop | `18889deb9e83ea7420ef51c160d6f88552e744e3` |
| proofwidgets | `a8acbfd87375ff4abe14ce09db5b7664d383bc7f` |
| importGraph | `1681d78dd6e65e38b143f9740d829c826673807c` |
| LeanSearchClient | `ba67e212be1197b84c1f1f6299488a10a3002713` |
| plausible | `d9598f07b1bc701f1e3aae163d2681c1fd978793` |

`generic_environment/ENVIRONMENT.lock.json` records the exact public repository URLs and the additional pinned Cli package used by the generic cache bootstrap. Cli is not one of the eight Adaptive/Witness application replay libraries; it is the ninth source-metadata entry required by the unchanged PrimeCover lock. `COMPILER_RUNTIME.lock.json` binds the shared compiler runtime and standard-library sentinels.

## Execute the complete application replay

```sh
python3 reproduce.py \
  --environment /absolute/fresh/ENVIRONMENT.json \
  --out /absolute/fresh/adaptive-replay \
  --jobs 16
```

This single entry point does all of the following:

1. Regenerates the necessary 40,150 C input/include files in memory from the locked Lean witness lists and checks every byte against the sealed source.
2. Creates a fresh application object/log directory in an offline namespace and compiles all 1,792 application Lean modules using only the pinned generic libraries.
3. Compiles and executes each of the four actual C mains using the pinned bundled Clang.
4. Checks all 16 final declarations, their exact module/source/object/log associations, the four compile/execute paths, and the final ordinary-kernel axiom sets.

The expected final receipt is `adaptive-replay/RECEIPT.json` with status `COMPLETE_ADAPTIVE_REPRODUCTION_PASS`. The detailed proof receipt is under `namespace/work/results/RECEIPT.json`; the independent strict acceptance receipt is under `final-audit/RECEIPT.json`. Failure produces no final acceptance receipt. Inspect the stage `.stdout` and `.stderr` files and preserve a failed output directory; retry using a fresh directory.

To test only dependencies, source identities, and namespace applicability before a costly run, append `--validate-only`. Its status is **`PREFLIGHT_ONLY_NO_PROOFS`**, and it is never proof acceptance. Use `regenerate_data.py --out /absolute/fresh/generated --receipt /absolute/fresh/generated.json` to emit and independently inspect the deterministic numerical include files; the emitted tree has the same sealed hashes as the in-memory check. There is no random seed.

The actual recorded full campaign uses a **256 GiB memory / 16 CPU / 21,600 second** outer resource envelope. It preserves host headroom and does not impose a 4 GiB limit. That envelope is a tested generous execution profile, not a measured minimum RAM requirement. The namespace entry point itself does not install a resource limit; when sharing a host, place it inside the project's separately supplied `resource_scope.py` policy or an equivalent resource envelope. RAM and scratch-disk availability must be checked separately.

## What the proofs establish

`SOURCE_LOCK.json` SHA-256 is `b204282a0b6f60e75c73158be598fd2d54d2416557e6a6015821a376d55367e2`. It fixes the exact mathematical source, actual C header/function/main bytes, locked input lists, and source-to-row associations. Reproduction helpers are separately hash-sealed; changing a helper cannot silently change this mathematical source identity.

`AdaptiveVerified{One,Forty,FortyFive,Direct}.complete` constructs a `LinkedProgramExecution`. It includes actual source rendering, typed static-array initialization, actual helper AST executions, row and cover body execution, word-range/divisor safety, the actual main body, and a nonrecursive implemented primality service. The service is proved from the application's own trial-division AST; it is not a trusted prime oracle or an assumed successful output. Each `coverage_output` is consumed by the unchanged `ExposureEvolution.*Data.accepted` and `.finite` declarations. `FinalAudit.lean` checks those exact 16 exports.

The permitted final axioms are only `propext`, `Classical.choice`, and `Quot.sound`. Neither `native_decide` execution axioms nor `sorryAx` are accepted. The actual source is C23 with exact unsigned `_BitInt` modular semantics. Physical compilation/execution trusts the precisely pinned generic Clang/Lean/runtime, documented host C ABI/OS operations and hardware; this is not a verified machine-code compiler claim. The Python input generator is untrusted: its outputs are checked against the sealed files and kernel-consumed source representations.

## What has actually been tested

The actual isolated source-only V2 campaign passed all 1,792 application modules and all 4 actual C mains in 2,077.11118048 seconds. Its immutable producer receipt is `full-source-cold-v2/work/results/RECEIPT.json` (SHA-256 `41d93573d0601508d1ce9ea869e329e86e27706db4fd8230b6a711ea7828e6a8`, relative to the parent Adaptive component). The independent all-mode strict acceptance receipts are recorded separately from the portable wrapper controls. The new wrapper's actual normal, `-O`, and `-OO` namespace preflights pass; all generator/preparer tests and rejection controls also run through the actual CLIs in those modes. The component release index points to the final full-campaign acceptance and measured resource receipt when complete.

The public bootstrap recipe is copied byte-for-byte from the previously exercised pinned public recipe. This migration checked the prepared generic dependencies, runtime identities, and relocated wrapper applicability; it did **not** repeat a fresh OS installation or the entire public download/cache bootstrap. It also does not claim that the new combined portable driver completed a second full 1,792-module campaign merely because its individual recorded stages and preflight were checked.

Keep the sealed source, locked inputs, accepted proof receipts and essential manifests. Generated regeneration-test directories, duplicate download archives and temporary caches may be removed only after their exact hashes and deterministic regeneration have been checked, and only inside the experiment-owned work directories. Do not delete the only copy of a proof or research input.
