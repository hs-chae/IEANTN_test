"""Independent strict acceptance of all four source-first Adaptive programs."""
from pathlib import Path
import argparse,json,hashlib,re,os,tempfile,math
S=Path(__file__).resolve().parent
LOCK='b204282a0b6f60e75c73158be598fd2d54d2416557e6a6015821a376d55367e2'
ALLOW={'propext','Classical.choice','Quot.sound'}
LABELS={'One','Forty','FortyFive','Direct'}
def require(v,m):
 if not v:raise ValueError(m)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def pairs(xs):
 d={}
 for k,v in xs:
  require(k not in d,'duplicate JSON key');d[k]=v
 return d
def finite_float(s):
 v=float(s)
 require(math.isfinite(v),'nonfinite JSON number')
 return v
def load(p):return json.loads(p.read_text(),object_pairs_hook=pairs,parse_float=finite_float,parse_constant=lambda x:(_ for _ in()).throw(ValueError('nonfinite JSON')))
def number(v):return type(v)in(int,float)and math.isfinite(v)and v>=0
def axioms(s):
 rows=re.findall(r"'([^']+)'\s+depends on axioms:\s*\[([^\]]*)\]",s,re.S);d={}
 for n,b in rows:
  require(n not in d,'duplicate axiom declaration');d[n]=set(re.sub(r'\s+','',b).split(','))-{''}
 return d
def child(p):
 t=p.read_text();m=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',t);require(m is not None,'missing actual RSS '+str(p));return int(m[1])*1024

def main():
 a=argparse.ArgumentParser();a.add_argument('--replay',type=Path,required=True);a.add_argument('--out',type=Path,required=True);o=a.parse_args();R=o.replay.resolve();O=o.out.resolve()
 require(not O.exists(),'fresh audit output required')
 require(O!=S and S not in O.parents,'audit output outside source capsule')
 require(O!=R and R not in O.parents,'audit output outside original replay')
 require(sha(S/'SOURCE_LOCK.json')==LOCK,'source-lock identity')
 lock=load(S/'SOURCE_LOCK.json');d=load(R/'RECEIPT.json')
 require(d['status']=='PASS_FOUR_SOURCE_FIRST_PROGRAMS_AND_UNCHANGED_LCM_CONSUMERS','incomplete producer receipt')
 require(d['source_lock_sha256']==LOCK and d['application_object_inputs']is False,'source-cold claim')
 require(type(d['source_modules'])is int and d['source_modules']==1792 and number(d['seconds']),'source count/time')
 require(d['runner_sha256']==sha(S/'reproduce_inner.py'),'producer runner identity')
 require('offline' in d['namespace_isolation'].lower(),'namespace provenance')
 files={}
 for r in lock['files']:
  require(set(r)=={'path','bytes','sha256'} and type(r['bytes'])is int and r['bytes']>=0 and type(r['path'])is str and re.fullmatch('[0-9a-f]{64}',r['sha256'])is not None,'locked source schema')
  p=Path(r['path']);require(not p.is_absolute()and'..'not in p.parts and r['path']not in files,'source path identity')
  f=S/p;require(f.is_file()and not f.is_symlink()and f.stat().st_size==r['bytes']and sha(f)==r['sha256'],'source bytes '+str(p));files[r['path']]=r
 actual={str(f.relative_to(S))for root in ['lean','source','locked-inputs']for f in(S/root).rglob('*')if f.is_file()or f.is_symlink()}
 require(actual=={n for n in files if n.startswith(('lean/','source/','locked-inputs/'))},'source population drift')
 modules={'.'.join(Path(n).relative_to('lean').with_suffix('').parts):r for n,r in files.items()if n.startswith('lean/')and n.endswith('.lean')}
 require(len(modules)==1792 and len(d['records'])==1792,'full module population')
 records={};peak=0;compiler=None;source_root=None;object_root=None
 for r in d['records']:
  m=r['module'];require(m in modules and m not in records,'written module identity');records[m]=r
  require(r['source_sha256']==modules[m]['sha256']and type(r['exit_code'])is int and r['exit_code']==0 and number(r['seconds']),'module acceptance')
  f=R/'objects'/Path(*m.split('.')).with_suffix('.olean');require(f.is_file()and sha(f)==r['object_sha256'],'object bytes '+m)
  so=R/'logs'/(m+'.stdout');se=R/'logs'/(m+'.stderr');require(sha(so)==r['stdout_sha256']and sha(se)==r['stderr_sha256'],'compile log bytes')
  text=so.read_text()+se.read_text();require(not any(x in text for x in ['sorryAx','Lean.ofReduceBool','native_decide.ax_']),'nonkernel axiom found')
  for name,ax in axioms(so.read_text()).items():require(ax<=ALLOW,'axiom policy '+m+' '+name)
  peak=max(peak,child(se));cmd=r['command']
  require(type(cmd)is list and len(cmd)==9 and all(type(x)is str for x in cmd),'compiler argv schema')
  require(cmd[0:2]==['/usr/bin/time','-v']and cmd[3:5]==['-j1','-R']and cmd[7]=='-o'and Path(cmd[2]).name=='lean','actual compiler command')
  relative=Path(*m.split('.'))
  require(Path(cmd[6])==Path(cmd[5])/relative.with_suffix('.lean'),'actual source command association')
  destination=Path(cmd[8]);require(str(destination).endswith('/'+str(relative.with_suffix('.olean'))),'actual object command association')
  root=destination.parents[len(relative.parts)-1]
  if compiler is None:compiler,source_root,object_root=cmd[2],cmd[5],str(root)
  require((cmd[2],cmd[5],str(root))==(compiler,source_root,object_root),'single fresh compiler/source/object environment')
 require(set(records)==set(modules),'module coverage')
 audited=lock['audited_declarations'];require(len(audited)==16 and len(set(audited))==16 and d['audited_declarations']==audited,'all final declarations')
 ax=axioms((R/'logs/FinalAudit.stdout').read_text());require(set(ax)==set(audited),'final reflection population')
 require({k:sorted(v)for k,v in ax.items()}==d['final_axioms'],'final axiom receipt')
 for n,v in ax.items():require(v<=ALLOW,'final dependency policy '+n)
 require(len(d['actual_C'])==4,'actual C population');seen=set();cases={c['label']:c for c in lock['cases']}
 for r in d['actual_C']:
  label=r['label'];require(label in LABELS and label not in seen,'C case identity');seen.add(label)
  require(type(r['rows'])is int and r['rows']==cases[label]['rows']and sha(S/'source/cases'/label/'main.c')==r['source_sha256'],'C input/source identity')
  require(sha(R/('native-'+label))==r['binary_sha256'],'C binary identity');require(len(r['runs'])==2,'compile/execute route coverage')
  compile_command=r['runs'][0]['command'];execute_command=r['runs'][1]['command']
  require(type(compile_command)is list and len(compile_command)==8 and all(type(x)is str for x in compile_command),'C compiler argv schema')
  require(Path(compile_command[0]).name=='clang'and compile_command[1:5]==['-std=c2x','-O2','-isystem','/usr/lib/gcc/x86_64-linux-gnu/11/include']and compile_command[6]=='-o','actual C compiler invocation')
  require(Path(compile_command[5])==Path(source_root).parent/'source/cases'/label/'main.c'and Path(compile_command[7])==Path(object_root).parent/('native-'+label),'C source/binary command association')
  require(execute_command==[compile_command[7]],'compiled C binary was executed')
  for phase,run in zip(['compile','execute'],r['runs']):
   require(type(run['exit_code'])is int and run['exit_code']==0 and number(run['seconds']),'C execution result');so=R/(label+'-'+phase+'.stdout');se=R/(label+'-'+phase+'.stderr')
   require(sha(so)==run['stdout_sha256']and sha(se)==run['stderr_sha256']and so.read_bytes()==b'','C execution logs')
   require(type(run['command'])is list and run['command'],'C command');peak=max(peak,child(se))
 require(seen==LABELS,'all four C paths')
 O.mkdir();rec={'status':'FINAL_STRICT_ACCEPTANCE_PASS','source_lock_sha256':LOCK,'producer_receipt_sha256':sha(R/'RECEIPT.json'),'auditor_sha256':sha(Path(__file__)),'source_modules':1792,'source_first_programs':4,'closed_final_declarations':16,'allowed_axioms':sorted(ALLOW),'max_individual_child_RSS_bytes':peak,'application_object_inputs':False,'physical_execution_boundary':'Pinned Clang/C23 unsigned _BitInt/host ABI, generic OS/compiler/runtime and physical hardware; no verified machine-code compiler claim.'}
 fd,tmp=tempfile.mkstemp(dir=O,prefix='.receipt-')
 with os.fdopen(fd,'w')as h:json.dump(rec,h,indent=2,allow_nan=False);h.write('\n');h.flush();os.fsync(h.fileno())
 os.replace(tmp,O/'RECEIPT.json');print(json.dumps({'status':rec['status'],'max_individual_child_RSS_bytes':peak}))
if __name__=='__main__':main()
