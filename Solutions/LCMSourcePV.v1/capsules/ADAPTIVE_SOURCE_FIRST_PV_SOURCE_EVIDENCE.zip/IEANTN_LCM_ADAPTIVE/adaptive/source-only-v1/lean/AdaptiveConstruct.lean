import AdaptiveWordSound
namespace LCMSourcePV.Adaptive.C
open E1TwoTracks.TrackB LCMSourcePV.PrimeCover LCMSourcePV.RestrictedC
set_option maxHeartbeats 0
set_option exponentiation.threshold 1024
local instance (r : Row) (n num den : Nat) : Decidable (endpointNat r n num den) := inferInstanceAs (Decidable (_ < _))

/-- Construct a concrete C word/control trace from mathematical input facts.
The reverse soundness theorem is independent of this construction. -/
theorem row_exec_of_valid {r : Row} {num den : Nat} (valid : Valid r num den)
    (safe : ArithmeticSafe r num den) (gate : inputGate r num den = true) : RowExec r num den := by
  obtain ⟨hpe,hqe,hae,hde,hbe⟩ := products_exact safe
  rcases safe with ⟨sp0,sp1,sp2,sq0,sq1,sq2,ss,sk,sP,sQ,sA,sD,sB,sfour,sll,slr,shl,shr⟩
  rcases valid with ⟨hs,hprod,hdiv,hl,hh⟩
  rcases hs with ⟨hlo,hle,hsq,hpq,hql,hp0,hp1,hp2,hq0,hq1,hq2,hp01,hp12,hq01,hq12⟩
  have hpos : 0 < r.block.P := by
    dsimp [Row.block,Block.P]
    exact Nat.mul_pos (Nat.mul_pos hp0.pos hp1.pos) hp2.pos
  have hf : wmul 4 (productP r) = 4*r.block.P := by
    rw [hpe]
    exact Unsigned.mul_exact sfour
  have hpw : 2^r.valuation < 2^512 := Nat.pow_lt_pow_right (by decide) (by omega)
  have hshift : shiftW r.valuation = some (2^r.valuation) := by
    simp only [shiftW,show r.valuation < 512 by omega,↓reduceIte]
    rw [show wcast (2^r.valuation) = 2^r.valuation from Unsigned.repr_exact hpw]
  have safe' : ArithmeticSafe r num den :=
    ⟨sp0,sp1,sp2,sq0,sq1,sq2,ss,sk,sP,sQ,sA,sD,sB,sfour,sll,slr,shl,shr⟩
  refine ⟨gate,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_⟩
  · unfold precheck
    apply decide_eq_true
    rw [show Unsigned.mul 64 r.p0 r.p0 = r.p0*r.p0 from Unsigned.mul_exact ss]
    exact ⟨hlo,hle,by simpa [Row.block,pow_two] using hsq,hpq,hql,hp01,hp12,hq01,hq12⟩
  · exact prime_exec_of_prime (by change r.p0 < 2^64; omega) hp0
  · exact prime_exec_of_prime (by change r.p1 < 2^64; omega) hp1
  · exact prime_exec_of_prime (by change r.p2 < 2^64; omega) hp2
  · exact prime_exec_of_prime (by change r.q0 < 2^64; omega) hq0
  · exact prime_exec_of_prime (by change r.q1 < 2^64; omega) hq1
  · exact prime_exec_of_prime (by change r.q2 < 2^64; omega) hq2
  · unfold productTest
    rw [hf,hqe]
    dsimp only
    simp only [hprod,not_true_eq_false,↓reduceIte]
    rw [Unsigned.div_exact (by omega : 4*r.block.P ≠ 0)]
    simp only [hshift]
    change (Unsigned.rem (r.block.Q/(4*r.block.P)) (2^r.valuation)).bind
      (fun rem => some (rem == 0)) = some true
    rw [Unsigned.rem_exact (by positivity : 2^r.valuation ≠ 0)]
    simp [Nat.mod_eq_zero_of_dvd hdiv]
  · rw [endpoint_exact safe' hpos sll slr]
    exact congrArg some (decide_eq_true hl)
  · rw [endpoint_exact safe' hpos shl shr]
    exact congrArg some (decide_eq_true hh)

#print axioms row_exec_of_valid
end LCMSourcePV.Adaptive.C
