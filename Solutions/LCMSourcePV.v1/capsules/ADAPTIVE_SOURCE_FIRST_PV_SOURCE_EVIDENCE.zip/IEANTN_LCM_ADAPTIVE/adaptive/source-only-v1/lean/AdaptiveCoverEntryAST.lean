/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import AdaptiveCoverAST
namespace LCMSourcePV.Adaptive.C
open LCMSourcePV.Witness.C LCMSourcePV.ASTLoops
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def coverArgumentEnv (count start stop num den : Nat) : Env :=
  bind (bind (bind (bind (bind (bind emptyEnv
    "rows" (.pointer 0)) "count" (.word 64 count)) "start" (.word 64 start))
    "stop" (.word 64 stop)) "num" (.word 64 num)) "den" (.word 64 den)

theorem cover_bind_arguments {count start stop num den : Nat}
    (hc : count<2^64) (ha : start<2^64) (hb : stop<2^64)
    (hn : num<2^64) (hd : den<2^64) :
    bindArgs f_cover_check.parameters [.pointer 0,word 64 count,word 64 start,
      word 64 stop,word 64 num,word 64 den]=some (coverArgumentEnv count start stop num den) := by
  norm_num at hc ha hb hn hd
  simp [f_cover_check,bindArgs,castValue,asNat,word,coverArgumentEnv,
    Nat.mod_eq_of_lt hc,Nat.mod_eq_of_lt ha,Nat.mod_eq_of_lt hb,
    Nat.mod_eq_of_lt hn,Nat.mod_eq_of_lt hd]
  all_goals first | rfl | omega

theorem eval_cover_return {heap env count stop num den i finish}
    (inv : CoverInv env count stop num den i finish) (hend : stop≤finish) :
    evalCoverExpr heap env (.binary "<=" (.var "stop") (.var "lo"))=
      some (boolean true) := by
  simp [evalCoverExpr,evalExpr,inv.stop,inv.lo,binaryValue,hend]

/-- Function execution looks up the actual parsed function, casts its actual
parameters, executes its entire statement AST and casts its returned value.
The body execution is structural, not a tag attached to a separate cover run. -/
def CoverFunctionExec (heap : Heap) (args : List Value) (result : Value) : Prop :=
  ∃ f env final raw, functions.find? (fun f => f.name=="cover_check")=some f ∧
    bindArgs f.parameters args=some env ∧
    CoverStmtRun heap f.body env (.returned final raw) ∧
    castValue f.returnType raw=some result

theorem cover_ast {heap : Heap} {start stop num den finish : Nat}
    (trace : CoverRows num den heap start finish)
    (hc : heap.length<2^64) (ha : start<2^64) (hb : stop<2^64)
    (hn : num<2^64) (hd : den<2^64) (hend : stop≤finish) :
    CoverFunctionExec heap [.pointer 0,word 64 heap.length,word 64 start,
      word 64 stop,word 64 num,word 64 den] (.word 1 1) := by
  let args := coverArgumentEnv heap.length start stop num den
  let loEnv := bind args "lo" (.word 64 start)
  let loopEnv := bind loEnv "i" (.word 64 0)
  have loInit : CoverDeclare heap [⟨"U","lo",some (.var "start")⟩] args loEnv := by
    norm_num at ha
    simp [CoverDeclare,declareCover,evalCoverExpr,evalExpr,args,loEnv,
      coverArgumentEnv,bind,castValue,asNat,word,Nat.mod_eq_of_lt ha]
    all_goals omega
  have iInit : CoverDeclare heap [⟨"U","i",some (.nat 0)⟩] loEnv loopEnv := by
    simp [CoverDeclare,declareCover,evalCoverExpr,evalExpr,castValue,asNat,word,loopEnv]
  have inv : CoverInv loopEnv heap.length stop num den 0 start := by
    constructor <;> simp [loopEnv,loEnv,args,coverArgumentEnv,bind]
  obtain ⟨final,loop,finalInv⟩ := cover_for_run (stop:=stop) trace hc hn hd [] loopEnv
    (by simp) (by simpa using inv)
  have returned := eval_cover_return (heap:=heap) finalInv hend
  refine ⟨f_cover_check,args,final,boolean true,by simp,
    cover_bind_arguments hc ha hb hn hd,?_,by rfl⟩
  change CoverStmtRun heap (.sequence [.declare [⟨"U","lo",some (.var "start")⟩],
    .forLoop (.declare [⟨"U","i",some (.nat 0)⟩]) (some coverCondition)
      coverIncrement coverIteration,
    .returnStmt (.binary "<=" (.var "stop") (.var "lo"))])
    args (.returned final (boolean true))
  apply ASTLoops.StmtRun.sequence
  · apply ASTLoops.SeqRun.next (ASTLoops.StmtRun.declare loInit)
    apply ASTLoops.SeqRun.next (ASTLoops.StmtRun.forLoop (ASTLoops.StmtRun.declare iInit) loop rfl)
    exact ASTLoops.SeqRun.returned (ASTLoops.StmtRun.returnValue (CoverEval.pure returned))
  · rfl

#print axioms cover_ast
end LCMSourcePV.Adaptive.C
