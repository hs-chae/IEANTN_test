import AdaptiveInputOne
import AdaptiveRoutes
namespace LCMSourcePV.Adaptive.CaseOne
open LCMSourcePV.Adaptive.C
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option Elab.async false
theorem values_node000 : LCMSourcePV.Adaptive.InputOne.node000.values = LCMSourcePV.Adaptive.InputOne.Part000.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part001.tree.values := rfl
theorem values_node001 : LCMSourcePV.Adaptive.InputOne.node001.values = LCMSourcePV.Adaptive.InputOne.Part002.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part003.tree.values := rfl
theorem values_node002 : LCMSourcePV.Adaptive.InputOne.node002.values = LCMSourcePV.Adaptive.InputOne.Part004.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part005.tree.values := rfl
theorem values_node003 : LCMSourcePV.Adaptive.InputOne.node003.values = LCMSourcePV.Adaptive.InputOne.Part006.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part007.tree.values := rfl
theorem values_node004 : LCMSourcePV.Adaptive.InputOne.node004.values = LCMSourcePV.Adaptive.InputOne.Part008.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part009.tree.values := rfl
theorem values_node005 : LCMSourcePV.Adaptive.InputOne.node005.values = LCMSourcePV.Adaptive.InputOne.Part010.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part011.tree.values := rfl
theorem values_node006 : LCMSourcePV.Adaptive.InputOne.node006.values = LCMSourcePV.Adaptive.InputOne.Part012.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part013.tree.values := rfl
theorem values_node007 : LCMSourcePV.Adaptive.InputOne.node007.values = LCMSourcePV.Adaptive.InputOne.Part014.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part015.tree.values := rfl
theorem values_node008 : LCMSourcePV.Adaptive.InputOne.node008.values = LCMSourcePV.Adaptive.InputOne.Part016.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part017.tree.values := rfl
theorem values_node009 : LCMSourcePV.Adaptive.InputOne.node009.values = LCMSourcePV.Adaptive.InputOne.Part018.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part019.tree.values := rfl
theorem values_node010 : LCMSourcePV.Adaptive.InputOne.node010.values = LCMSourcePV.Adaptive.InputOne.Part020.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part021.tree.values := rfl
theorem values_node011 : LCMSourcePV.Adaptive.InputOne.node011.values = LCMSourcePV.Adaptive.InputOne.Part022.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part023.tree.values := rfl
theorem values_node012 : LCMSourcePV.Adaptive.InputOne.node012.values = LCMSourcePV.Adaptive.InputOne.Part024.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part025.tree.values := rfl
theorem values_node013 : LCMSourcePV.Adaptive.InputOne.node013.values = LCMSourcePV.Adaptive.InputOne.Part026.tree.values ++ LCMSourcePV.Adaptive.InputOne.Part027.tree.values := rfl
theorem values_node014 : LCMSourcePV.Adaptive.InputOne.node014.values = LCMSourcePV.Adaptive.InputOne.node000.values ++ LCMSourcePV.Adaptive.InputOne.node001.values := rfl
theorem values_node015 : LCMSourcePV.Adaptive.InputOne.node015.values = LCMSourcePV.Adaptive.InputOne.node002.values ++ LCMSourcePV.Adaptive.InputOne.node003.values := rfl
theorem values_node016 : LCMSourcePV.Adaptive.InputOne.node016.values = LCMSourcePV.Adaptive.InputOne.node004.values ++ LCMSourcePV.Adaptive.InputOne.node005.values := rfl
theorem values_node017 : LCMSourcePV.Adaptive.InputOne.node017.values = LCMSourcePV.Adaptive.InputOne.node006.values ++ LCMSourcePV.Adaptive.InputOne.node007.values := rfl
theorem values_node018 : LCMSourcePV.Adaptive.InputOne.node018.values = LCMSourcePV.Adaptive.InputOne.node008.values ++ LCMSourcePV.Adaptive.InputOne.node009.values := rfl
theorem values_node019 : LCMSourcePV.Adaptive.InputOne.node019.values = LCMSourcePV.Adaptive.InputOne.node010.values ++ LCMSourcePV.Adaptive.InputOne.node011.values := rfl
theorem values_node020 : LCMSourcePV.Adaptive.InputOne.node020.values = LCMSourcePV.Adaptive.InputOne.node012.values ++ LCMSourcePV.Adaptive.InputOne.node013.values := rfl
theorem values_node021 : LCMSourcePV.Adaptive.InputOne.node021.values = LCMSourcePV.Adaptive.InputOne.node014.values ++ LCMSourcePV.Adaptive.InputOne.node015.values := rfl
theorem values_node022 : LCMSourcePV.Adaptive.InputOne.node022.values = LCMSourcePV.Adaptive.InputOne.node016.values ++ LCMSourcePV.Adaptive.InputOne.node017.values := rfl
theorem values_node023 : LCMSourcePV.Adaptive.InputOne.node023.values = LCMSourcePV.Adaptive.InputOne.node018.values ++ LCMSourcePV.Adaptive.InputOne.node019.values := rfl
theorem values_node024 : LCMSourcePV.Adaptive.InputOne.node024.values = LCMSourcePV.Adaptive.InputOne.node021.values ++ LCMSourcePV.Adaptive.InputOne.node022.values := rfl
theorem values_node025 : LCMSourcePV.Adaptive.InputOne.node025.values = LCMSourcePV.Adaptive.InputOne.node023.values ++ LCMSourcePV.Adaptive.InputOne.node020.values := rfl
theorem values_node026 : LCMSourcePV.Adaptive.InputOne.node026.values = LCMSourcePV.Adaptive.InputOne.node024.values ++ LCMSourcePV.Adaptive.InputOne.node025.values := rfl
def rows : List Row := LCMSourcePV.Adaptive.RowsOne.Part000.rows ++ LCMSourcePV.Adaptive.RowsOne.Part001.rows ++ LCMSourcePV.Adaptive.RowsOne.Part002.rows ++ LCMSourcePV.Adaptive.RowsOne.Part003.rows ++ LCMSourcePV.Adaptive.RowsOne.Part004.rows ++ LCMSourcePV.Adaptive.RowsOne.Part005.rows ++ LCMSourcePV.Adaptive.RowsOne.Part006.rows ++ LCMSourcePV.Adaptive.RowsOne.Part007.rows ++ LCMSourcePV.Adaptive.RowsOne.Part008.rows ++ LCMSourcePV.Adaptive.RowsOne.Part009.rows ++ LCMSourcePV.Adaptive.RowsOne.Part010.rows ++ LCMSourcePV.Adaptive.RowsOne.Part011.rows ++ LCMSourcePV.Adaptive.RowsOne.Part012.rows ++ LCMSourcePV.Adaptive.RowsOne.Part013.rows ++ LCMSourcePV.Adaptive.RowsOne.Part014.rows ++ LCMSourcePV.Adaptive.RowsOne.Part015.rows ++ LCMSourcePV.Adaptive.RowsOne.Part016.rows ++ LCMSourcePV.Adaptive.RowsOne.Part017.rows ++ LCMSourcePV.Adaptive.RowsOne.Part018.rows ++ LCMSourcePV.Adaptive.RowsOne.Part019.rows ++ LCMSourcePV.Adaptive.RowsOne.Part020.rows ++ LCMSourcePV.Adaptive.RowsOne.Part021.rows ++ LCMSourcePV.Adaptive.RowsOne.Part022.rows ++ LCMSourcePV.Adaptive.RowsOne.Part023.rows ++ LCMSourcePV.Adaptive.RowsOne.Part024.rows ++ LCMSourcePV.Adaptive.RowsOne.Part025.rows ++ LCMSourcePV.Adaptive.RowsOne.Part026.rows ++ LCMSourcePV.Adaptive.RowsOne.Part027.rows
theorem source_values : LCMSourcePV.Adaptive.InputOne.tree.values = rows := by
  simp only [LCMSourcePV.Adaptive.InputOne.tree, values_node000, values_node001, values_node002, values_node003, values_node004, values_node005, values_node006, values_node007, values_node008, values_node009, values_node010, values_node011, values_node012, values_node013, values_node014, values_node015, values_node016, values_node017, values_node018, values_node019, values_node020, values_node021, values_node022, values_node023, values_node024, values_node025, values_node026, LCMSourcePV.Adaptive.InputOne.Part000.values_tree, LCMSourcePV.Adaptive.InputOne.Part001.values_tree, LCMSourcePV.Adaptive.InputOne.Part002.values_tree, LCMSourcePV.Adaptive.InputOne.Part003.values_tree, LCMSourcePV.Adaptive.InputOne.Part004.values_tree, LCMSourcePV.Adaptive.InputOne.Part005.values_tree, LCMSourcePV.Adaptive.InputOne.Part006.values_tree, LCMSourcePV.Adaptive.InputOne.Part007.values_tree, LCMSourcePV.Adaptive.InputOne.Part008.values_tree, LCMSourcePV.Adaptive.InputOne.Part009.values_tree, LCMSourcePV.Adaptive.InputOne.Part010.values_tree, LCMSourcePV.Adaptive.InputOne.Part011.values_tree, LCMSourcePV.Adaptive.InputOne.Part012.values_tree, LCMSourcePV.Adaptive.InputOne.Part013.values_tree, LCMSourcePV.Adaptive.InputOne.Part014.values_tree, LCMSourcePV.Adaptive.InputOne.Part015.values_tree, LCMSourcePV.Adaptive.InputOne.Part016.values_tree, LCMSourcePV.Adaptive.InputOne.Part017.values_tree, LCMSourcePV.Adaptive.InputOne.Part018.values_tree, LCMSourcePV.Adaptive.InputOne.Part019.values_tree, LCMSourcePV.Adaptive.InputOne.Part020.values_tree, LCMSourcePV.Adaptive.InputOne.Part021.values_tree, LCMSourcePV.Adaptive.InputOne.Part022.values_tree, LCMSourcePV.Adaptive.InputOne.Part023.values_tree, LCMSourcePV.Adaptive.InputOne.Part024.values_tree, LCMSourcePV.Adaptive.InputOne.Part025.values_tree, LCMSourcePV.Adaptive.InputOne.Part026.values_tree, LCMSourcePV.Adaptive.InputOne.Part027.values_tree, rows, List.append_assoc]
theorem all_rows : ∀ r ∈ rows, RowExec r 3 10 ∧ ArithmeticSafe r 3 10 := by
  intro r hr
  simp only [rows,List.mem_append,or_assoc] at hr
  rcases hr with h0 | h1 | h2 | h3 | h4 | h5 | h6 | h7 | h8 | h9 | h10 | h11 | h12 | h13 | h14 | h15 | h16 | h17 | h18 | h19 | h20 | h21 | h22 | h23 | h24 | h25 | h26 | h27
  · exact LCMSourcePV.Adaptive.RowsOne.Part000.all_rows r h0
  · exact LCMSourcePV.Adaptive.RowsOne.Part001.all_rows r h1
  · exact LCMSourcePV.Adaptive.RowsOne.Part002.all_rows r h2
  · exact LCMSourcePV.Adaptive.RowsOne.Part003.all_rows r h3
  · exact LCMSourcePV.Adaptive.RowsOne.Part004.all_rows r h4
  · exact LCMSourcePV.Adaptive.RowsOne.Part005.all_rows r h5
  · exact LCMSourcePV.Adaptive.RowsOne.Part006.all_rows r h6
  · exact LCMSourcePV.Adaptive.RowsOne.Part007.all_rows r h7
  · exact LCMSourcePV.Adaptive.RowsOne.Part008.all_rows r h8
  · exact LCMSourcePV.Adaptive.RowsOne.Part009.all_rows r h9
  · exact LCMSourcePV.Adaptive.RowsOne.Part010.all_rows r h10
  · exact LCMSourcePV.Adaptive.RowsOne.Part011.all_rows r h11
  · exact LCMSourcePV.Adaptive.RowsOne.Part012.all_rows r h12
  · exact LCMSourcePV.Adaptive.RowsOne.Part013.all_rows r h13
  · exact LCMSourcePV.Adaptive.RowsOne.Part014.all_rows r h14
  · exact LCMSourcePV.Adaptive.RowsOne.Part015.all_rows r h15
  · exact LCMSourcePV.Adaptive.RowsOne.Part016.all_rows r h16
  · exact LCMSourcePV.Adaptive.RowsOne.Part017.all_rows r h17
  · exact LCMSourcePV.Adaptive.RowsOne.Part018.all_rows r h18
  · exact LCMSourcePV.Adaptive.RowsOne.Part019.all_rows r h19
  · exact LCMSourcePV.Adaptive.RowsOne.Part020.all_rows r h20
  · exact LCMSourcePV.Adaptive.RowsOne.Part021.all_rows r h21
  · exact LCMSourcePV.Adaptive.RowsOne.Part022.all_rows r h22
  · exact LCMSourcePV.Adaptive.RowsOne.Part023.all_rows r h23
  · exact LCMSourcePV.Adaptive.RowsOne.Part024.all_rows r h24
  · exact LCMSourcePV.Adaptive.RowsOne.Part025.all_rows r h25
  · exact LCMSourcePV.Adaptive.RowsOne.Part026.all_rows r h26
  · exact LCMSourcePV.Adaptive.RowsOne.Part027.all_rows r h27
theorem route_000 : route 1000000 LCMSourcePV.Adaptive.RowsOne.Part000.rows = some 1495729 := by decide
theorem length_000 : LCMSourcePV.Adaptive.RowsOne.Part000.rows.length = 32 := rfl
theorem route_001 : route 1495729 LCMSourcePV.Adaptive.RowsOne.Part001.rows = some 2128681 := by decide
theorem length_001 : LCMSourcePV.Adaptive.RowsOne.Part001.rows.length = 32 := rfl
theorem route_002 : route 2128681 LCMSourcePV.Adaptive.RowsOne.Part002.rows = some 2866249 := by decide
theorem length_002 : LCMSourcePV.Adaptive.RowsOne.Part002.rows.length = 32 := rfl
theorem route_003 : route 2866249 LCMSourcePV.Adaptive.RowsOne.Part003.rows = some 3798601 := by decide
theorem length_003 : LCMSourcePV.Adaptive.RowsOne.Part003.rows.length = 32 := rfl
theorem route_004 : route 3798601 LCMSourcePV.Adaptive.RowsOne.Part004.rows = some 4853209 := by decide
theorem length_004 : LCMSourcePV.Adaptive.RowsOne.Part004.rows.length = 32 := rfl
theorem route_005 : route 4853209 LCMSourcePV.Adaptive.RowsOne.Part005.rows = some 5870929 := by decide
theorem length_005 : LCMSourcePV.Adaptive.RowsOne.Part005.rows.length = 32 := rfl
theorem route_006 : route 5870929 LCMSourcePV.Adaptive.RowsOne.Part006.rows = some 7252249 := by decide
theorem length_006 : LCMSourcePV.Adaptive.RowsOne.Part006.rows.length = 32 := rfl
theorem route_007 : route 7252249 LCMSourcePV.Adaptive.RowsOne.Part007.rows = some 8637721 := by decide
theorem length_007 : LCMSourcePV.Adaptive.RowsOne.Part007.rows.length = 32 := rfl
theorem route_008 : route 8637721 LCMSourcePV.Adaptive.RowsOne.Part008.rows = some 10374841 := by decide
theorem length_008 : LCMSourcePV.Adaptive.RowsOne.Part008.rows.length = 32 := rfl
theorem route_009 : route 10374841 LCMSourcePV.Adaptive.RowsOne.Part009.rows = some 12187081 := by decide
theorem length_009 : LCMSourcePV.Adaptive.RowsOne.Part009.rows.length = 32 := rfl
theorem route_010 : route 12187081 LCMSourcePV.Adaptive.RowsOne.Part010.rows = some 13890529 := by decide
theorem length_010 : LCMSourcePV.Adaptive.RowsOne.Part010.rows.length = 32 := rfl
theorem route_011 : route 13890529 LCMSourcePV.Adaptive.RowsOne.Part011.rows = some 16024009 := by decide
theorem length_011 : LCMSourcePV.Adaptive.RowsOne.Part011.rows.length = 32 := rfl
theorem route_012 : route 16024009 LCMSourcePV.Adaptive.RowsOne.Part012.rows = some 18139081 := by decide
theorem length_012 : LCMSourcePV.Adaptive.RowsOne.Part012.rows.length = 32 := rfl
theorem route_013 : route 18139081 LCMSourcePV.Adaptive.RowsOne.Part013.rows = some 20675209 := by decide
theorem length_013 : LCMSourcePV.Adaptive.RowsOne.Part013.rows.length = 32 := rfl
theorem route_014 : route 20675209 LCMSourcePV.Adaptive.RowsOne.Part014.rows = some 23164969 := by decide
theorem length_014 : LCMSourcePV.Adaptive.RowsOne.Part014.rows.length = 32 := rfl
theorem route_015 : route 23164969 LCMSourcePV.Adaptive.RowsOne.Part015.rows = some 25877569 := by decide
theorem length_015 : LCMSourcePV.Adaptive.RowsOne.Part015.rows.length = 32 := rfl
theorem route_016 : route 25877569 LCMSourcePV.Adaptive.RowsOne.Part016.rows = some 29149201 := by decide
theorem length_016 : LCMSourcePV.Adaptive.RowsOne.Part016.rows.length = 32 := rfl
theorem route_017 : route 29149201 LCMSourcePV.Adaptive.RowsOne.Part017.rows = some 31956409 := by decide
theorem length_017 : LCMSourcePV.Adaptive.RowsOne.Part017.rows.length = 32 := rfl
theorem route_018 : route 31956409 LCMSourcePV.Adaptive.RowsOne.Part018.rows = some 34774609 := by decide
theorem length_018 : LCMSourcePV.Adaptive.RowsOne.Part018.rows.length = 32 := rfl
theorem route_019 : route 34774609 LCMSourcePV.Adaptive.RowsOne.Part019.rows = some 38576521 := by decide
theorem length_019 : LCMSourcePV.Adaptive.RowsOne.Part019.rows.length = 32 := rfl
theorem route_020 : route 38576521 LCMSourcePV.Adaptive.RowsOne.Part020.rows = some 41899729 := by decide
theorem length_020 : LCMSourcePV.Adaptive.RowsOne.Part020.rows.length = 32 := rfl
theorem route_021 : route 41899729 LCMSourcePV.Adaptive.RowsOne.Part021.rows = some 45954841 := by decide
theorem length_021 : LCMSourcePV.Adaptive.RowsOne.Part021.rows.length = 32 := rfl
theorem route_022 : route 45954841 LCMSourcePV.Adaptive.RowsOne.Part022.rows = some 49378729 := by decide
theorem length_022 : LCMSourcePV.Adaptive.RowsOne.Part022.rows.length = 32 := rfl
theorem route_023 : route 49378729 LCMSourcePV.Adaptive.RowsOne.Part023.rows = some 54007801 := by decide
theorem length_023 : LCMSourcePV.Adaptive.RowsOne.Part023.rows.length = 32 := rfl
theorem route_024 : route 54007801 LCMSourcePV.Adaptive.RowsOne.Part024.rows = some 58079641 := by decide
theorem length_024 : LCMSourcePV.Adaptive.RowsOne.Part024.rows.length = 32 := rfl
theorem route_025 : route 58079641 LCMSourcePV.Adaptive.RowsOne.Part025.rows = some 62710561 := by decide
theorem length_025 : LCMSourcePV.Adaptive.RowsOne.Part025.rows.length = 32 := rfl
theorem route_026 : route 62710561 LCMSourcePV.Adaptive.RowsOne.Part026.rows = some 67749361 := by decide
theorem length_026 : LCMSourcePV.Adaptive.RowsOne.Part026.rows.length = 32 := rfl
theorem route_027 : route 67749361 LCMSourcePV.Adaptive.RowsOne.Part027.rows = some 71707024 := by decide
theorem length_027 : LCMSourcePV.Adaptive.RowsOne.Part027.rows.length = 28 := rfl
theorem route_complete : route 1000000 rows = some 71707024 := by
  simp only [rows,route_append, route_000, route_001, route_002, route_003, route_004, route_005, route_006, route_007, route_008, route_009, route_010, route_011, route_012, route_013, route_014, route_015, route_016, route_017, route_018, route_019, route_020, route_021, route_022, route_023, route_024, route_025, route_026, route_027, Option.bind_some]
theorem length_rows : rows.length = 892 := by
  simp only [rows,List.length_append, length_000, length_001, length_002, length_003, length_004, length_005, length_006, length_007, length_008, length_009, length_010, length_011, length_012, length_013, length_014, length_015, length_016, length_017, length_018, length_019, length_020, length_021, length_022, length_023, length_024, length_025, length_026, length_027]
theorem adjacency : adjacent 1000000 71707024 rows = true := adjacent_of_route route_complete (by omega)
theorem mathematical_output : ExposureEvolution.Adaptive.coverage 1000000 71707024 (rows.map toOne) = true := coverage_one rows all_rows 1000000 71707024 adjacency
#print axioms mathematical_output
#print axioms source_values
end LCMSourcePV.Adaptive.CaseOne
