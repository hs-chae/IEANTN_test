import AdaptiveWordSound
import ExposureEvolution.Adaptive
import ExposureEvolution.Adaptive40
import ExposureEvolution.Adaptive45
namespace LCMSourcePV.Adaptive.C
set_option maxHeartbeats 0

def adjacent : Nat → Nat → List Row → Bool
  | lo,stop,[] => decide (stop≤lo)
  | lo,stop,r::rs => decide (r.lo=lo) && adjacent (r.hi+1) stop rs

def toOne (r : Row) : ExposureEvolution.Adaptive.Witness := ⟨r.block,r.valuation⟩
def toForty (r : Row) : ExposureEvolution.Adaptive40.Witness := ⟨r.block,r.valuation⟩
def toFortyFive (r : Row) : ExposureEvolution.Adaptive45.Witness := ⟨r.block,r.valuation⟩

theorem one_valid (r : Row) : (toOne r).Valid ↔ Valid r 3 10 := Iff.rfl
theorem forty_valid (r : Row) : (toForty r).Valid ↔ Valid r 2 5 := Iff.rfl
theorem fortyfive_valid (r : Row) : (toFortyFive r).Valid ↔ Valid r 9 20 := Iff.rfl

/-- Unchanged original checker, established from the C word executions. -/
theorem coverage_one (rows : List Row)
    (runs : ∀ r ∈ rows, RowExec r 3 10 ∧ ArithmeticSafe r 3 10)
    (lo stop : Nat) (chain : adjacent lo stop rows = true) :
    ExposureEvolution.Adaptive.coverage lo stop (rows.map toOne) = true := by
  induction rows generalizing lo with
  | nil => simpa only [adjacent,List.map_nil,ExposureEvolution.Adaptive.coverage] using chain
  | cons r rs ih =>
    have hchain : r.lo=lo ∧ adjacent (r.hi+1) stop rs = true := by
      simpa only [adjacent,Bool.and_eq_true,decide_eq_true_eq] using chain
    have row := runs r (by simp)
    have hv : (toOne r).Valid := (one_valid r).mpr (row_exec_sound row.1 row.2)
    have hcheck : (toOne r).check = true := decide_eq_true hv
    have htail : ExposureEvolution.Adaptive.coverage (r.hi+1) stop (rs.map toOne) = true :=
      ih (by intro t ht; exact runs t (by simp [ht])) (r.hi+1) hchain.2
    change (decide (r.lo=lo) && (toOne r).check &&
      ExposureEvolution.Adaptive.coverage (r.hi+1) stop (rs.map toOne)) = true
    rw [decide_eq_true hchain.1,hcheck,htail]
    rfl
#print axioms coverage_one

/-- Unchanged original checker, established from the C word executions. -/
theorem coverage_forty (rows : List Row)
    (runs : ∀ r ∈ rows, RowExec r 2 5 ∧ ArithmeticSafe r 2 5)
    (lo stop : Nat) (chain : adjacent lo stop rows = true) :
    ExposureEvolution.Adaptive40.coverage lo stop (rows.map toForty) = true := by
  induction rows generalizing lo with
  | nil => simpa only [adjacent,List.map_nil,ExposureEvolution.Adaptive40.coverage] using chain
  | cons r rs ih =>
    have hchain : r.lo=lo ∧ adjacent (r.hi+1) stop rs = true := by
      simpa only [adjacent,Bool.and_eq_true,decide_eq_true_eq] using chain
    have row := runs r (by simp)
    have hv : (toForty r).Valid := (forty_valid r).mpr (row_exec_sound row.1 row.2)
    have hcheck : (toForty r).check = true := decide_eq_true hv
    have htail : ExposureEvolution.Adaptive40.coverage (r.hi+1) stop (rs.map toForty) = true :=
      ih (by intro t ht; exact runs t (by simp [ht])) (r.hi+1) hchain.2
    change (decide (r.lo=lo) && (toForty r).check &&
      ExposureEvolution.Adaptive40.coverage (r.hi+1) stop (rs.map toForty)) = true
    rw [decide_eq_true hchain.1,hcheck,htail]
    rfl
#print axioms coverage_forty

/-- Unchanged original checker, established from the C word executions. -/
theorem coverage_fortyfive (rows : List Row)
    (runs : ∀ r ∈ rows, RowExec r 9 20 ∧ ArithmeticSafe r 9 20)
    (lo stop : Nat) (chain : adjacent lo stop rows = true) :
    ExposureEvolution.Adaptive45.coverage lo stop (rows.map toFortyFive) = true := by
  induction rows generalizing lo with
  | nil => simpa only [adjacent,List.map_nil,ExposureEvolution.Adaptive45.coverage] using chain
  | cons r rs ih =>
    have hchain : r.lo=lo ∧ adjacent (r.hi+1) stop rs = true := by
      simpa only [adjacent,Bool.and_eq_true,decide_eq_true_eq] using chain
    have row := runs r (by simp)
    have hv : (toFortyFive r).Valid := (fortyfive_valid r).mpr (row_exec_sound row.1 row.2)
    have hcheck : (toFortyFive r).check = true := decide_eq_true hv
    have htail : ExposureEvolution.Adaptive45.coverage (r.hi+1) stop (rs.map toFortyFive) = true :=
      ih (by intro t ht; exact runs t (by simp [ht])) (r.hi+1) hchain.2
    change (decide (r.lo=lo) && (toFortyFive r).check &&
      ExposureEvolution.Adaptive45.coverage (r.hi+1) stop (rs.map toFortyFive)) = true
    rw [decide_eq_true hchain.1,hcheck,htail]
    rfl
#print axioms coverage_fortyfive
end LCMSourcePV.Adaptive.C
