import AdaptiveInputDirect.Part000
import AdaptiveInputDirect.Part001
import AdaptiveInputDirect.Part002
import AdaptiveInputDirect.Part003
import AdaptiveInputDirect.Part004
import AdaptiveInputDirect.Part005
import AdaptiveInputDirect.Part006
import AdaptiveInputDirect.Part007
import AdaptiveInputDirect.Part008
import AdaptiveInputDirect.Part009
import AdaptiveInputDirect.Part010
import AdaptiveInputDirect.Part011
import AdaptiveInputDirect.Part012
import AdaptiveInputDirect.Part013
import AdaptiveInputDirect.Part014
import AdaptiveInputDirect.Part015
import AdaptiveInputDirect.Part016
import AdaptiveInputDirect.Part017
import AdaptiveInputDirect.Part018
import AdaptiveInputDirect.Part019
import AdaptiveInputDirect.Part020
import AdaptiveInputDirect.Part021
import AdaptiveInputDirect.Part022
import AdaptiveInputDirect.Part023
import AdaptiveInputDirect.Part024
import AdaptiveInputDirect.Part025
import AdaptiveInputDirect.Part026
import AdaptiveInputDirect.Part027
import AdaptiveInputDirect.Part028
import AdaptiveInputDirect.Part029
import AdaptiveInputDirect.Part030
import AdaptiveInputDirect.Part031
import AdaptiveInputDirect.Part032
import AdaptiveInputDirect.Part033
import AdaptiveInputDirect.Part034
import AdaptiveInputDirect.Part035
import AdaptiveInputDirect.Part036
import AdaptiveInputDirect.Part037
import AdaptiveInputDirect.Part038
import AdaptiveInputDirect.Part039
import AdaptiveInputDirect.Part040
import AdaptiveInputDirect.Part041
import AdaptiveInputDirect.Part042
import AdaptiveInputDirect.Part043
import AdaptiveInputDirect.Part044
import AdaptiveInputDirect.Part045
import AdaptiveInputDirect.Part046
import AdaptiveInputDirect.Part047
import AdaptiveInputDirect.Part048
import AdaptiveInputDirect.Part049
import AdaptiveInputDirect.Part050
import AdaptiveInputDirect.Part051
import AdaptiveInputDirect.Part052
import AdaptiveInputDirect.Part053
import AdaptiveInputDirect.Part054
import AdaptiveInputDirect.Part055
import AdaptiveInputDirect.Part056
import AdaptiveInputDirect.Part057
import AdaptiveInputDirect.Part058
import AdaptiveInputDirect.Part059
import AdaptiveInputDirect.Part060
import AdaptiveInputDirect.Part061
import AdaptiveInputDirect.Part062
import AdaptiveInputDirect.Part063
import AdaptiveInputDirect.Part064
import AdaptiveInputDirect.Part065
import AdaptiveInputDirect.Part066
import AdaptiveInputDirect.Part067
import AdaptiveInputDirect.Part068
import AdaptiveInputDirect.Part069
import AdaptiveInputDirect.Part070
import AdaptiveInputDirect.Part071
import AdaptiveInputDirect.Part072
import AdaptiveInputDirect.Part073
import AdaptiveInputDirect.Part074
import AdaptiveInputDirect.Part075
import AdaptiveInputDirect.Part076
import AdaptiveInputDirect.Part077
import AdaptiveInputDirect.Part078
import AdaptiveInputDirect.Part079
import AdaptiveInputDirect.Part080
import AdaptiveInputDirect.Part081
import AdaptiveInputDirect.Part082
import AdaptiveInputDirect.Part083
import AdaptiveInputDirect.Part084
import AdaptiveInputDirect.Part085
import AdaptiveInputDirect.Part086
import AdaptiveInputDirect.Part087
import AdaptiveInputDirect.Part088
import AdaptiveInputDirect.Part089
import AdaptiveInputDirect.Part090
import AdaptiveInputDirect.Part091
import AdaptiveInputDirect.Part092
import AdaptiveInputDirect.Part093
import AdaptiveInputDirect.Part094
import AdaptiveInputDirect.Part095
import AdaptiveInputDirect.Part096
import AdaptiveInputDirect.Part097
import AdaptiveInputDirect.Part098
import AdaptiveInputDirect.Part099
import AdaptiveInputDirect.Part100
import AdaptiveInputDirect.Part101
import AdaptiveInputDirect.Part102
import AdaptiveInputDirect.Part103
import AdaptiveInputDirect.Part104
import AdaptiveInputDirect.Part105
import AdaptiveInputDirect.Part106
import AdaptiveInputDirect.Part107
import AdaptiveInputDirect.Part108
import AdaptiveInputDirect.Part109
import AdaptiveInputDirect.Part110
import AdaptiveInputDirect.Part111
import AdaptiveInputDirect.Part112
import AdaptiveInputDirect.Part113
import AdaptiveInputDirect.Part114
import AdaptiveInputDirect.Part115
import AdaptiveInputDirect.Part116
import AdaptiveInputDirect.Part117
import AdaptiveInputDirect.Part118
import AdaptiveInputDirect.Part119
import AdaptiveInputDirect.Part120
import AdaptiveInputDirect.Part121
import AdaptiveInputDirect.Part122
import AdaptiveInputDirect.Part123
import AdaptiveInputDirect.Part124
import AdaptiveInputDirect.Part125
import AdaptiveInputDirect.Part126
import AdaptiveInputDirect.Part127
import AdaptiveInputDirect.Part128
import AdaptiveInputDirect.Part129
import AdaptiveInputDirect.Part130
import AdaptiveInputDirect.Part131
import AdaptiveInputDirect.Part132
import AdaptiveInputDirect.Part133
import AdaptiveInputDirect.Part134
import AdaptiveInputDirect.Part135
import AdaptiveInputDirect.Part136
import AdaptiveInputDirect.Part137
import AdaptiveInputDirect.Part138
import AdaptiveInputDirect.Part139
import AdaptiveInputDirect.Part140
import AdaptiveInputDirect.Part141
import AdaptiveInputDirect.Part142
import AdaptiveInputDirect.Part143
import AdaptiveInputDirect.Part144
import AdaptiveInputDirect.Part145
import AdaptiveInputDirect.Part146
import AdaptiveInputDirect.Part147
import AdaptiveInputDirect.Part148
import AdaptiveInputDirect.Part149
import AdaptiveInputDirect.Part150
import AdaptiveInputDirect.Part151
import AdaptiveInputDirect.Part152
import AdaptiveInputDirect.Part153
import AdaptiveInputDirect.Part154
import AdaptiveInputDirect.Part155
import AdaptiveInputDirect.Part156
import AdaptiveInputDirect.Part157
import AdaptiveInputDirect.Part158
import AdaptiveInputDirect.Part159
import AdaptiveInputDirect.Part160
import AdaptiveInputDirect.Part161
import AdaptiveInputDirect.Part162
import AdaptiveInputDirect.Part163
import AdaptiveInputDirect.Part164
import AdaptiveInputDirect.Part165
import AdaptiveInputDirect.Part166
import AdaptiveInputDirect.Part167
import AdaptiveInputDirect.Part168
import AdaptiveInputDirect.Part169
import AdaptiveInputDirect.Part170
import AdaptiveInputDirect.Part171
import AdaptiveInputDirect.Part172
import AdaptiveInputDirect.Part173
import AdaptiveInputDirect.Part174
import AdaptiveInputDirect.Part175
import AdaptiveInputDirect.Part176
import AdaptiveInputDirect.Part177
import AdaptiveInputDirect.Part178
import AdaptiveInputDirect.Part179
import AdaptiveInputDirect.Part180
import AdaptiveInputDirect.Part181
import AdaptiveInputDirect.Part182
import AdaptiveInputDirect.Part183
import AdaptiveInputDirect.Part184
import AdaptiveInputDirect.Part185
import AdaptiveInputDirect.Part186
import AdaptiveInputDirect.Part187
import AdaptiveInputDirect.Part188
import AdaptiveInputDirect.Part189
import AdaptiveInputDirect.Part190
import AdaptiveInputDirect.Part191
import AdaptiveInputDirect.Part192
import AdaptiveInputDirect.Part193
import AdaptiveInputDirect.Part194
import AdaptiveInputDirect.Part195
import AdaptiveInputDirect.Part196
import AdaptiveInputDirect.Part197
import AdaptiveInputDirect.Part198
import AdaptiveInputDirect.Part199
import AdaptiveInputDirect.Part200
import AdaptiveInputDirect.Part201
import AdaptiveInputDirect.Part202
import AdaptiveInputDirect.Part203
import AdaptiveInputDirect.Part204
import AdaptiveInputDirect.Part205
import AdaptiveInputDirect.Part206
import AdaptiveInputDirect.Part207
import AdaptiveInputDirect.Part208
import AdaptiveInputDirect.Part209
import AdaptiveInputDirect.Part210
import AdaptiveInputDirect.Part211
import AdaptiveInputDirect.Part212
import AdaptiveInputDirect.Part213
import AdaptiveInputDirect.Part214
import AdaptiveInputDirect.Part215
import AdaptiveInputDirect.Part216
import AdaptiveInputDirect.Part217
import AdaptiveInputDirect.Part218
import AdaptiveInputDirect.Part219
import AdaptiveInputDirect.Part220
import AdaptiveInputDirect.Part221
import AdaptiveInputDirect.Part222
import AdaptiveInputDirect.Part223
import AdaptiveInputDirect.Part224
import AdaptiveInputDirect.Part225
import AdaptiveInputDirect.Part226
import AdaptiveInputDirect.Part227
import AdaptiveInputDirect.Part228
import AdaptiveInputDirect.Part229
import AdaptiveInputDirect.Part230
import AdaptiveInputDirect.Part231
import AdaptiveInputDirect.Part232
import AdaptiveInputDirect.Part233
import AdaptiveInputDirect.Part234
import AdaptiveInputDirect.Part235
import AdaptiveInputDirect.Part236
import AdaptiveInputDirect.Part237
import AdaptiveInputDirect.Part238
import AdaptiveInputDirect.Part239
import AdaptiveInputDirect.Part240
import AdaptiveInputDirect.Part241
import AdaptiveInputDirect.Part242
import AdaptiveInputDirect.Part243
import AdaptiveInputDirect.Part244
import AdaptiveInputDirect.Part245
import AdaptiveInputDirect.Part246
import AdaptiveInputDirect.Part247
import AdaptiveInputDirect.Part248
import AdaptiveInputDirect.Part249
import AdaptiveInputDirect.Part250
import AdaptiveInputDirect.Part251
import AdaptiveInputDirect.Part252
import AdaptiveInputDirect.Part253
import AdaptiveInputDirect.Part254
import AdaptiveInputDirect.Part255
import AdaptiveInputDirect.Part256
import AdaptiveInputDirect.Part257
import AdaptiveInputDirect.Part258
import AdaptiveInputDirect.Part259
import AdaptiveInputDirect.Part260
import AdaptiveInputDirect.Part261
import AdaptiveInputDirect.Part262
import AdaptiveInputDirect.Part263
import AdaptiveInputDirect.Part264
import AdaptiveInputDirect.Part265
import AdaptiveInputDirect.Part266
namespace LCMSourcePV.Adaptive.InputDirect
open LCMSourcePV.Adaptive.C
set_option maxHeartbeats 0
set_option maxRecDepth 200000
def node000 : InputTree := .join "global_000.inc" LCMSourcePV.Adaptive.InputDirect.Part000.tree LCMSourcePV.Adaptive.InputDirect.Part001.tree (include_str ".."/"source"/"cases"/"Direct"/"global_000.inc")
theorem checked_node000 : node000.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part000.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part001.checked_tree⟩
def node001 : InputTree := .join "global_001.inc" LCMSourcePV.Adaptive.InputDirect.Part002.tree LCMSourcePV.Adaptive.InputDirect.Part003.tree (include_str ".."/"source"/"cases"/"Direct"/"global_001.inc")
theorem checked_node001 : node001.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part002.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part003.checked_tree⟩
def node002 : InputTree := .join "global_002.inc" LCMSourcePV.Adaptive.InputDirect.Part004.tree LCMSourcePV.Adaptive.InputDirect.Part005.tree (include_str ".."/"source"/"cases"/"Direct"/"global_002.inc")
theorem checked_node002 : node002.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part004.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part005.checked_tree⟩
def node003 : InputTree := .join "global_003.inc" LCMSourcePV.Adaptive.InputDirect.Part006.tree LCMSourcePV.Adaptive.InputDirect.Part007.tree (include_str ".."/"source"/"cases"/"Direct"/"global_003.inc")
theorem checked_node003 : node003.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part006.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part007.checked_tree⟩
def node004 : InputTree := .join "global_004.inc" LCMSourcePV.Adaptive.InputDirect.Part008.tree LCMSourcePV.Adaptive.InputDirect.Part009.tree (include_str ".."/"source"/"cases"/"Direct"/"global_004.inc")
theorem checked_node004 : node004.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part008.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part009.checked_tree⟩
def node005 : InputTree := .join "global_005.inc" LCMSourcePV.Adaptive.InputDirect.Part010.tree LCMSourcePV.Adaptive.InputDirect.Part011.tree (include_str ".."/"source"/"cases"/"Direct"/"global_005.inc")
theorem checked_node005 : node005.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part010.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part011.checked_tree⟩
def node006 : InputTree := .join "global_006.inc" LCMSourcePV.Adaptive.InputDirect.Part012.tree LCMSourcePV.Adaptive.InputDirect.Part013.tree (include_str ".."/"source"/"cases"/"Direct"/"global_006.inc")
theorem checked_node006 : node006.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part012.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part013.checked_tree⟩
def node007 : InputTree := .join "global_007.inc" LCMSourcePV.Adaptive.InputDirect.Part014.tree LCMSourcePV.Adaptive.InputDirect.Part015.tree (include_str ".."/"source"/"cases"/"Direct"/"global_007.inc")
theorem checked_node007 : node007.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part014.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part015.checked_tree⟩
def node008 : InputTree := .join "global_008.inc" LCMSourcePV.Adaptive.InputDirect.Part016.tree LCMSourcePV.Adaptive.InputDirect.Part017.tree (include_str ".."/"source"/"cases"/"Direct"/"global_008.inc")
theorem checked_node008 : node008.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part016.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part017.checked_tree⟩
def node009 : InputTree := .join "global_009.inc" LCMSourcePV.Adaptive.InputDirect.Part018.tree LCMSourcePV.Adaptive.InputDirect.Part019.tree (include_str ".."/"source"/"cases"/"Direct"/"global_009.inc")
theorem checked_node009 : node009.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part018.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part019.checked_tree⟩
def node010 : InputTree := .join "global_010.inc" LCMSourcePV.Adaptive.InputDirect.Part020.tree LCMSourcePV.Adaptive.InputDirect.Part021.tree (include_str ".."/"source"/"cases"/"Direct"/"global_010.inc")
theorem checked_node010 : node010.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part020.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part021.checked_tree⟩
def node011 : InputTree := .join "global_011.inc" LCMSourcePV.Adaptive.InputDirect.Part022.tree LCMSourcePV.Adaptive.InputDirect.Part023.tree (include_str ".."/"source"/"cases"/"Direct"/"global_011.inc")
theorem checked_node011 : node011.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part022.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part023.checked_tree⟩
def node012 : InputTree := .join "global_012.inc" LCMSourcePV.Adaptive.InputDirect.Part024.tree LCMSourcePV.Adaptive.InputDirect.Part025.tree (include_str ".."/"source"/"cases"/"Direct"/"global_012.inc")
theorem checked_node012 : node012.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part024.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part025.checked_tree⟩
def node013 : InputTree := .join "global_013.inc" LCMSourcePV.Adaptive.InputDirect.Part026.tree LCMSourcePV.Adaptive.InputDirect.Part027.tree (include_str ".."/"source"/"cases"/"Direct"/"global_013.inc")
theorem checked_node013 : node013.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part026.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part027.checked_tree⟩
def node014 : InputTree := .join "global_014.inc" LCMSourcePV.Adaptive.InputDirect.Part028.tree LCMSourcePV.Adaptive.InputDirect.Part029.tree (include_str ".."/"source"/"cases"/"Direct"/"global_014.inc")
theorem checked_node014 : node014.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part028.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part029.checked_tree⟩
def node015 : InputTree := .join "global_015.inc" LCMSourcePV.Adaptive.InputDirect.Part030.tree LCMSourcePV.Adaptive.InputDirect.Part031.tree (include_str ".."/"source"/"cases"/"Direct"/"global_015.inc")
theorem checked_node015 : node015.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part030.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part031.checked_tree⟩
def node016 : InputTree := .join "global_016.inc" LCMSourcePV.Adaptive.InputDirect.Part032.tree LCMSourcePV.Adaptive.InputDirect.Part033.tree (include_str ".."/"source"/"cases"/"Direct"/"global_016.inc")
theorem checked_node016 : node016.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part032.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part033.checked_tree⟩
def node017 : InputTree := .join "global_017.inc" LCMSourcePV.Adaptive.InputDirect.Part034.tree LCMSourcePV.Adaptive.InputDirect.Part035.tree (include_str ".."/"source"/"cases"/"Direct"/"global_017.inc")
theorem checked_node017 : node017.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part034.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part035.checked_tree⟩
def node018 : InputTree := .join "global_018.inc" LCMSourcePV.Adaptive.InputDirect.Part036.tree LCMSourcePV.Adaptive.InputDirect.Part037.tree (include_str ".."/"source"/"cases"/"Direct"/"global_018.inc")
theorem checked_node018 : node018.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part036.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part037.checked_tree⟩
def node019 : InputTree := .join "global_019.inc" LCMSourcePV.Adaptive.InputDirect.Part038.tree LCMSourcePV.Adaptive.InputDirect.Part039.tree (include_str ".."/"source"/"cases"/"Direct"/"global_019.inc")
theorem checked_node019 : node019.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part038.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part039.checked_tree⟩
def node020 : InputTree := .join "global_020.inc" LCMSourcePV.Adaptive.InputDirect.Part040.tree LCMSourcePV.Adaptive.InputDirect.Part041.tree (include_str ".."/"source"/"cases"/"Direct"/"global_020.inc")
theorem checked_node020 : node020.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part040.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part041.checked_tree⟩
def node021 : InputTree := .join "global_021.inc" LCMSourcePV.Adaptive.InputDirect.Part042.tree LCMSourcePV.Adaptive.InputDirect.Part043.tree (include_str ".."/"source"/"cases"/"Direct"/"global_021.inc")
theorem checked_node021 : node021.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part042.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part043.checked_tree⟩
def node022 : InputTree := .join "global_022.inc" LCMSourcePV.Adaptive.InputDirect.Part044.tree LCMSourcePV.Adaptive.InputDirect.Part045.tree (include_str ".."/"source"/"cases"/"Direct"/"global_022.inc")
theorem checked_node022 : node022.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part044.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part045.checked_tree⟩
def node023 : InputTree := .join "global_023.inc" LCMSourcePV.Adaptive.InputDirect.Part046.tree LCMSourcePV.Adaptive.InputDirect.Part047.tree (include_str ".."/"source"/"cases"/"Direct"/"global_023.inc")
theorem checked_node023 : node023.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part046.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part047.checked_tree⟩
def node024 : InputTree := .join "global_024.inc" LCMSourcePV.Adaptive.InputDirect.Part048.tree LCMSourcePV.Adaptive.InputDirect.Part049.tree (include_str ".."/"source"/"cases"/"Direct"/"global_024.inc")
theorem checked_node024 : node024.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part048.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part049.checked_tree⟩
def node025 : InputTree := .join "global_025.inc" LCMSourcePV.Adaptive.InputDirect.Part050.tree LCMSourcePV.Adaptive.InputDirect.Part051.tree (include_str ".."/"source"/"cases"/"Direct"/"global_025.inc")
theorem checked_node025 : node025.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part050.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part051.checked_tree⟩
def node026 : InputTree := .join "global_026.inc" LCMSourcePV.Adaptive.InputDirect.Part052.tree LCMSourcePV.Adaptive.InputDirect.Part053.tree (include_str ".."/"source"/"cases"/"Direct"/"global_026.inc")
theorem checked_node026 : node026.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part052.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part053.checked_tree⟩
def node027 : InputTree := .join "global_027.inc" LCMSourcePV.Adaptive.InputDirect.Part054.tree LCMSourcePV.Adaptive.InputDirect.Part055.tree (include_str ".."/"source"/"cases"/"Direct"/"global_027.inc")
theorem checked_node027 : node027.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part054.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part055.checked_tree⟩
def node028 : InputTree := .join "global_028.inc" LCMSourcePV.Adaptive.InputDirect.Part056.tree LCMSourcePV.Adaptive.InputDirect.Part057.tree (include_str ".."/"source"/"cases"/"Direct"/"global_028.inc")
theorem checked_node028 : node028.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part056.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part057.checked_tree⟩
def node029 : InputTree := .join "global_029.inc" LCMSourcePV.Adaptive.InputDirect.Part058.tree LCMSourcePV.Adaptive.InputDirect.Part059.tree (include_str ".."/"source"/"cases"/"Direct"/"global_029.inc")
theorem checked_node029 : node029.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part058.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part059.checked_tree⟩
def node030 : InputTree := .join "global_030.inc" LCMSourcePV.Adaptive.InputDirect.Part060.tree LCMSourcePV.Adaptive.InputDirect.Part061.tree (include_str ".."/"source"/"cases"/"Direct"/"global_030.inc")
theorem checked_node030 : node030.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part060.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part061.checked_tree⟩
def node031 : InputTree := .join "global_031.inc" LCMSourcePV.Adaptive.InputDirect.Part062.tree LCMSourcePV.Adaptive.InputDirect.Part063.tree (include_str ".."/"source"/"cases"/"Direct"/"global_031.inc")
theorem checked_node031 : node031.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part062.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part063.checked_tree⟩
def node032 : InputTree := .join "global_032.inc" LCMSourcePV.Adaptive.InputDirect.Part064.tree LCMSourcePV.Adaptive.InputDirect.Part065.tree (include_str ".."/"source"/"cases"/"Direct"/"global_032.inc")
theorem checked_node032 : node032.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part064.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part065.checked_tree⟩
def node033 : InputTree := .join "global_033.inc" LCMSourcePV.Adaptive.InputDirect.Part066.tree LCMSourcePV.Adaptive.InputDirect.Part067.tree (include_str ".."/"source"/"cases"/"Direct"/"global_033.inc")
theorem checked_node033 : node033.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part066.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part067.checked_tree⟩
def node034 : InputTree := .join "global_034.inc" LCMSourcePV.Adaptive.InputDirect.Part068.tree LCMSourcePV.Adaptive.InputDirect.Part069.tree (include_str ".."/"source"/"cases"/"Direct"/"global_034.inc")
theorem checked_node034 : node034.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part068.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part069.checked_tree⟩
def node035 : InputTree := .join "global_035.inc" LCMSourcePV.Adaptive.InputDirect.Part070.tree LCMSourcePV.Adaptive.InputDirect.Part071.tree (include_str ".."/"source"/"cases"/"Direct"/"global_035.inc")
theorem checked_node035 : node035.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part070.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part071.checked_tree⟩
def node036 : InputTree := .join "global_036.inc" LCMSourcePV.Adaptive.InputDirect.Part072.tree LCMSourcePV.Adaptive.InputDirect.Part073.tree (include_str ".."/"source"/"cases"/"Direct"/"global_036.inc")
theorem checked_node036 : node036.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part072.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part073.checked_tree⟩
def node037 : InputTree := .join "global_037.inc" LCMSourcePV.Adaptive.InputDirect.Part074.tree LCMSourcePV.Adaptive.InputDirect.Part075.tree (include_str ".."/"source"/"cases"/"Direct"/"global_037.inc")
theorem checked_node037 : node037.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part074.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part075.checked_tree⟩
def node038 : InputTree := .join "global_038.inc" LCMSourcePV.Adaptive.InputDirect.Part076.tree LCMSourcePV.Adaptive.InputDirect.Part077.tree (include_str ".."/"source"/"cases"/"Direct"/"global_038.inc")
theorem checked_node038 : node038.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part076.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part077.checked_tree⟩
def node039 : InputTree := .join "global_039.inc" LCMSourcePV.Adaptive.InputDirect.Part078.tree LCMSourcePV.Adaptive.InputDirect.Part079.tree (include_str ".."/"source"/"cases"/"Direct"/"global_039.inc")
theorem checked_node039 : node039.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part078.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part079.checked_tree⟩
def node040 : InputTree := .join "global_040.inc" LCMSourcePV.Adaptive.InputDirect.Part080.tree LCMSourcePV.Adaptive.InputDirect.Part081.tree (include_str ".."/"source"/"cases"/"Direct"/"global_040.inc")
theorem checked_node040 : node040.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part080.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part081.checked_tree⟩
def node041 : InputTree := .join "global_041.inc" LCMSourcePV.Adaptive.InputDirect.Part082.tree LCMSourcePV.Adaptive.InputDirect.Part083.tree (include_str ".."/"source"/"cases"/"Direct"/"global_041.inc")
theorem checked_node041 : node041.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part082.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part083.checked_tree⟩
def node042 : InputTree := .join "global_042.inc" LCMSourcePV.Adaptive.InputDirect.Part084.tree LCMSourcePV.Adaptive.InputDirect.Part085.tree (include_str ".."/"source"/"cases"/"Direct"/"global_042.inc")
theorem checked_node042 : node042.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part084.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part085.checked_tree⟩
def node043 : InputTree := .join "global_043.inc" LCMSourcePV.Adaptive.InputDirect.Part086.tree LCMSourcePV.Adaptive.InputDirect.Part087.tree (include_str ".."/"source"/"cases"/"Direct"/"global_043.inc")
theorem checked_node043 : node043.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part086.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part087.checked_tree⟩
def node044 : InputTree := .join "global_044.inc" LCMSourcePV.Adaptive.InputDirect.Part088.tree LCMSourcePV.Adaptive.InputDirect.Part089.tree (include_str ".."/"source"/"cases"/"Direct"/"global_044.inc")
theorem checked_node044 : node044.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part088.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part089.checked_tree⟩
def node045 : InputTree := .join "global_045.inc" LCMSourcePV.Adaptive.InputDirect.Part090.tree LCMSourcePV.Adaptive.InputDirect.Part091.tree (include_str ".."/"source"/"cases"/"Direct"/"global_045.inc")
theorem checked_node045 : node045.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part090.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part091.checked_tree⟩
def node046 : InputTree := .join "global_046.inc" LCMSourcePV.Adaptive.InputDirect.Part092.tree LCMSourcePV.Adaptive.InputDirect.Part093.tree (include_str ".."/"source"/"cases"/"Direct"/"global_046.inc")
theorem checked_node046 : node046.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part092.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part093.checked_tree⟩
def node047 : InputTree := .join "global_047.inc" LCMSourcePV.Adaptive.InputDirect.Part094.tree LCMSourcePV.Adaptive.InputDirect.Part095.tree (include_str ".."/"source"/"cases"/"Direct"/"global_047.inc")
theorem checked_node047 : node047.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part094.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part095.checked_tree⟩
def node048 : InputTree := .join "global_048.inc" LCMSourcePV.Adaptive.InputDirect.Part096.tree LCMSourcePV.Adaptive.InputDirect.Part097.tree (include_str ".."/"source"/"cases"/"Direct"/"global_048.inc")
theorem checked_node048 : node048.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part096.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part097.checked_tree⟩
def node049 : InputTree := .join "global_049.inc" LCMSourcePV.Adaptive.InputDirect.Part098.tree LCMSourcePV.Adaptive.InputDirect.Part099.tree (include_str ".."/"source"/"cases"/"Direct"/"global_049.inc")
theorem checked_node049 : node049.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part098.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part099.checked_tree⟩
def node050 : InputTree := .join "global_050.inc" LCMSourcePV.Adaptive.InputDirect.Part100.tree LCMSourcePV.Adaptive.InputDirect.Part101.tree (include_str ".."/"source"/"cases"/"Direct"/"global_050.inc")
theorem checked_node050 : node050.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part100.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part101.checked_tree⟩
def node051 : InputTree := .join "global_051.inc" LCMSourcePV.Adaptive.InputDirect.Part102.tree LCMSourcePV.Adaptive.InputDirect.Part103.tree (include_str ".."/"source"/"cases"/"Direct"/"global_051.inc")
theorem checked_node051 : node051.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part102.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part103.checked_tree⟩
def node052 : InputTree := .join "global_052.inc" LCMSourcePV.Adaptive.InputDirect.Part104.tree LCMSourcePV.Adaptive.InputDirect.Part105.tree (include_str ".."/"source"/"cases"/"Direct"/"global_052.inc")
theorem checked_node052 : node052.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part104.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part105.checked_tree⟩
def node053 : InputTree := .join "global_053.inc" LCMSourcePV.Adaptive.InputDirect.Part106.tree LCMSourcePV.Adaptive.InputDirect.Part107.tree (include_str ".."/"source"/"cases"/"Direct"/"global_053.inc")
theorem checked_node053 : node053.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part106.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part107.checked_tree⟩
def node054 : InputTree := .join "global_054.inc" LCMSourcePV.Adaptive.InputDirect.Part108.tree LCMSourcePV.Adaptive.InputDirect.Part109.tree (include_str ".."/"source"/"cases"/"Direct"/"global_054.inc")
theorem checked_node054 : node054.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part108.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part109.checked_tree⟩
def node055 : InputTree := .join "global_055.inc" LCMSourcePV.Adaptive.InputDirect.Part110.tree LCMSourcePV.Adaptive.InputDirect.Part111.tree (include_str ".."/"source"/"cases"/"Direct"/"global_055.inc")
theorem checked_node055 : node055.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part110.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part111.checked_tree⟩
def node056 : InputTree := .join "global_056.inc" LCMSourcePV.Adaptive.InputDirect.Part112.tree LCMSourcePV.Adaptive.InputDirect.Part113.tree (include_str ".."/"source"/"cases"/"Direct"/"global_056.inc")
theorem checked_node056 : node056.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part112.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part113.checked_tree⟩
def node057 : InputTree := .join "global_057.inc" LCMSourcePV.Adaptive.InputDirect.Part114.tree LCMSourcePV.Adaptive.InputDirect.Part115.tree (include_str ".."/"source"/"cases"/"Direct"/"global_057.inc")
theorem checked_node057 : node057.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part114.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part115.checked_tree⟩
def node058 : InputTree := .join "global_058.inc" LCMSourcePV.Adaptive.InputDirect.Part116.tree LCMSourcePV.Adaptive.InputDirect.Part117.tree (include_str ".."/"source"/"cases"/"Direct"/"global_058.inc")
theorem checked_node058 : node058.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part116.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part117.checked_tree⟩
def node059 : InputTree := .join "global_059.inc" LCMSourcePV.Adaptive.InputDirect.Part118.tree LCMSourcePV.Adaptive.InputDirect.Part119.tree (include_str ".."/"source"/"cases"/"Direct"/"global_059.inc")
theorem checked_node059 : node059.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part118.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part119.checked_tree⟩
def node060 : InputTree := .join "global_060.inc" LCMSourcePV.Adaptive.InputDirect.Part120.tree LCMSourcePV.Adaptive.InputDirect.Part121.tree (include_str ".."/"source"/"cases"/"Direct"/"global_060.inc")
theorem checked_node060 : node060.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part120.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part121.checked_tree⟩
def node061 : InputTree := .join "global_061.inc" LCMSourcePV.Adaptive.InputDirect.Part122.tree LCMSourcePV.Adaptive.InputDirect.Part123.tree (include_str ".."/"source"/"cases"/"Direct"/"global_061.inc")
theorem checked_node061 : node061.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part122.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part123.checked_tree⟩
def node062 : InputTree := .join "global_062.inc" LCMSourcePV.Adaptive.InputDirect.Part124.tree LCMSourcePV.Adaptive.InputDirect.Part125.tree (include_str ".."/"source"/"cases"/"Direct"/"global_062.inc")
theorem checked_node062 : node062.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part124.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part125.checked_tree⟩
def node063 : InputTree := .join "global_063.inc" LCMSourcePV.Adaptive.InputDirect.Part126.tree LCMSourcePV.Adaptive.InputDirect.Part127.tree (include_str ".."/"source"/"cases"/"Direct"/"global_063.inc")
theorem checked_node063 : node063.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part126.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part127.checked_tree⟩
def node064 : InputTree := .join "global_064.inc" LCMSourcePV.Adaptive.InputDirect.Part128.tree LCMSourcePV.Adaptive.InputDirect.Part129.tree (include_str ".."/"source"/"cases"/"Direct"/"global_064.inc")
theorem checked_node064 : node064.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part128.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part129.checked_tree⟩
def node065 : InputTree := .join "global_065.inc" LCMSourcePV.Adaptive.InputDirect.Part130.tree LCMSourcePV.Adaptive.InputDirect.Part131.tree (include_str ".."/"source"/"cases"/"Direct"/"global_065.inc")
theorem checked_node065 : node065.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part130.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part131.checked_tree⟩
def node066 : InputTree := .join "global_066.inc" LCMSourcePV.Adaptive.InputDirect.Part132.tree LCMSourcePV.Adaptive.InputDirect.Part133.tree (include_str ".."/"source"/"cases"/"Direct"/"global_066.inc")
theorem checked_node066 : node066.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part132.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part133.checked_tree⟩
def node067 : InputTree := .join "global_067.inc" LCMSourcePV.Adaptive.InputDirect.Part134.tree LCMSourcePV.Adaptive.InputDirect.Part135.tree (include_str ".."/"source"/"cases"/"Direct"/"global_067.inc")
theorem checked_node067 : node067.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part134.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part135.checked_tree⟩
def node068 : InputTree := .join "global_068.inc" LCMSourcePV.Adaptive.InputDirect.Part136.tree LCMSourcePV.Adaptive.InputDirect.Part137.tree (include_str ".."/"source"/"cases"/"Direct"/"global_068.inc")
theorem checked_node068 : node068.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part136.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part137.checked_tree⟩
def node069 : InputTree := .join "global_069.inc" LCMSourcePV.Adaptive.InputDirect.Part138.tree LCMSourcePV.Adaptive.InputDirect.Part139.tree (include_str ".."/"source"/"cases"/"Direct"/"global_069.inc")
theorem checked_node069 : node069.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part138.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part139.checked_tree⟩
def node070 : InputTree := .join "global_070.inc" LCMSourcePV.Adaptive.InputDirect.Part140.tree LCMSourcePV.Adaptive.InputDirect.Part141.tree (include_str ".."/"source"/"cases"/"Direct"/"global_070.inc")
theorem checked_node070 : node070.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part140.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part141.checked_tree⟩
def node071 : InputTree := .join "global_071.inc" LCMSourcePV.Adaptive.InputDirect.Part142.tree LCMSourcePV.Adaptive.InputDirect.Part143.tree (include_str ".."/"source"/"cases"/"Direct"/"global_071.inc")
theorem checked_node071 : node071.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part142.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part143.checked_tree⟩
def node072 : InputTree := .join "global_072.inc" LCMSourcePV.Adaptive.InputDirect.Part144.tree LCMSourcePV.Adaptive.InputDirect.Part145.tree (include_str ".."/"source"/"cases"/"Direct"/"global_072.inc")
theorem checked_node072 : node072.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part144.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part145.checked_tree⟩
def node073 : InputTree := .join "global_073.inc" LCMSourcePV.Adaptive.InputDirect.Part146.tree LCMSourcePV.Adaptive.InputDirect.Part147.tree (include_str ".."/"source"/"cases"/"Direct"/"global_073.inc")
theorem checked_node073 : node073.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part146.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part147.checked_tree⟩
def node074 : InputTree := .join "global_074.inc" LCMSourcePV.Adaptive.InputDirect.Part148.tree LCMSourcePV.Adaptive.InputDirect.Part149.tree (include_str ".."/"source"/"cases"/"Direct"/"global_074.inc")
theorem checked_node074 : node074.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part148.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part149.checked_tree⟩
def node075 : InputTree := .join "global_075.inc" LCMSourcePV.Adaptive.InputDirect.Part150.tree LCMSourcePV.Adaptive.InputDirect.Part151.tree (include_str ".."/"source"/"cases"/"Direct"/"global_075.inc")
theorem checked_node075 : node075.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part150.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part151.checked_tree⟩
def node076 : InputTree := .join "global_076.inc" LCMSourcePV.Adaptive.InputDirect.Part152.tree LCMSourcePV.Adaptive.InputDirect.Part153.tree (include_str ".."/"source"/"cases"/"Direct"/"global_076.inc")
theorem checked_node076 : node076.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part152.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part153.checked_tree⟩
def node077 : InputTree := .join "global_077.inc" LCMSourcePV.Adaptive.InputDirect.Part154.tree LCMSourcePV.Adaptive.InputDirect.Part155.tree (include_str ".."/"source"/"cases"/"Direct"/"global_077.inc")
theorem checked_node077 : node077.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part154.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part155.checked_tree⟩
def node078 : InputTree := .join "global_078.inc" LCMSourcePV.Adaptive.InputDirect.Part156.tree LCMSourcePV.Adaptive.InputDirect.Part157.tree (include_str ".."/"source"/"cases"/"Direct"/"global_078.inc")
theorem checked_node078 : node078.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part156.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part157.checked_tree⟩
def node079 : InputTree := .join "global_079.inc" LCMSourcePV.Adaptive.InputDirect.Part158.tree LCMSourcePV.Adaptive.InputDirect.Part159.tree (include_str ".."/"source"/"cases"/"Direct"/"global_079.inc")
theorem checked_node079 : node079.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part158.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part159.checked_tree⟩
def node080 : InputTree := .join "global_080.inc" LCMSourcePV.Adaptive.InputDirect.Part160.tree LCMSourcePV.Adaptive.InputDirect.Part161.tree (include_str ".."/"source"/"cases"/"Direct"/"global_080.inc")
theorem checked_node080 : node080.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part160.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part161.checked_tree⟩
def node081 : InputTree := .join "global_081.inc" LCMSourcePV.Adaptive.InputDirect.Part162.tree LCMSourcePV.Adaptive.InputDirect.Part163.tree (include_str ".."/"source"/"cases"/"Direct"/"global_081.inc")
theorem checked_node081 : node081.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part162.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part163.checked_tree⟩
def node082 : InputTree := .join "global_082.inc" LCMSourcePV.Adaptive.InputDirect.Part164.tree LCMSourcePV.Adaptive.InputDirect.Part165.tree (include_str ".."/"source"/"cases"/"Direct"/"global_082.inc")
theorem checked_node082 : node082.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part164.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part165.checked_tree⟩
def node083 : InputTree := .join "global_083.inc" LCMSourcePV.Adaptive.InputDirect.Part166.tree LCMSourcePV.Adaptive.InputDirect.Part167.tree (include_str ".."/"source"/"cases"/"Direct"/"global_083.inc")
theorem checked_node083 : node083.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part166.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part167.checked_tree⟩
def node084 : InputTree := .join "global_084.inc" LCMSourcePV.Adaptive.InputDirect.Part168.tree LCMSourcePV.Adaptive.InputDirect.Part169.tree (include_str ".."/"source"/"cases"/"Direct"/"global_084.inc")
theorem checked_node084 : node084.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part168.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part169.checked_tree⟩
def node085 : InputTree := .join "global_085.inc" LCMSourcePV.Adaptive.InputDirect.Part170.tree LCMSourcePV.Adaptive.InputDirect.Part171.tree (include_str ".."/"source"/"cases"/"Direct"/"global_085.inc")
theorem checked_node085 : node085.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part170.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part171.checked_tree⟩
def node086 : InputTree := .join "global_086.inc" LCMSourcePV.Adaptive.InputDirect.Part172.tree LCMSourcePV.Adaptive.InputDirect.Part173.tree (include_str ".."/"source"/"cases"/"Direct"/"global_086.inc")
theorem checked_node086 : node086.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part172.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part173.checked_tree⟩
def node087 : InputTree := .join "global_087.inc" LCMSourcePV.Adaptive.InputDirect.Part174.tree LCMSourcePV.Adaptive.InputDirect.Part175.tree (include_str ".."/"source"/"cases"/"Direct"/"global_087.inc")
theorem checked_node087 : node087.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part174.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part175.checked_tree⟩
def node088 : InputTree := .join "global_088.inc" LCMSourcePV.Adaptive.InputDirect.Part176.tree LCMSourcePV.Adaptive.InputDirect.Part177.tree (include_str ".."/"source"/"cases"/"Direct"/"global_088.inc")
theorem checked_node088 : node088.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part176.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part177.checked_tree⟩
def node089 : InputTree := .join "global_089.inc" LCMSourcePV.Adaptive.InputDirect.Part178.tree LCMSourcePV.Adaptive.InputDirect.Part179.tree (include_str ".."/"source"/"cases"/"Direct"/"global_089.inc")
theorem checked_node089 : node089.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part178.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part179.checked_tree⟩
def node090 : InputTree := .join "global_090.inc" LCMSourcePV.Adaptive.InputDirect.Part180.tree LCMSourcePV.Adaptive.InputDirect.Part181.tree (include_str ".."/"source"/"cases"/"Direct"/"global_090.inc")
theorem checked_node090 : node090.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part180.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part181.checked_tree⟩
def node091 : InputTree := .join "global_091.inc" LCMSourcePV.Adaptive.InputDirect.Part182.tree LCMSourcePV.Adaptive.InputDirect.Part183.tree (include_str ".."/"source"/"cases"/"Direct"/"global_091.inc")
theorem checked_node091 : node091.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part182.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part183.checked_tree⟩
def node092 : InputTree := .join "global_092.inc" LCMSourcePV.Adaptive.InputDirect.Part184.tree LCMSourcePV.Adaptive.InputDirect.Part185.tree (include_str ".."/"source"/"cases"/"Direct"/"global_092.inc")
theorem checked_node092 : node092.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part184.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part185.checked_tree⟩
def node093 : InputTree := .join "global_093.inc" LCMSourcePV.Adaptive.InputDirect.Part186.tree LCMSourcePV.Adaptive.InputDirect.Part187.tree (include_str ".."/"source"/"cases"/"Direct"/"global_093.inc")
theorem checked_node093 : node093.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part186.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part187.checked_tree⟩
def node094 : InputTree := .join "global_094.inc" LCMSourcePV.Adaptive.InputDirect.Part188.tree LCMSourcePV.Adaptive.InputDirect.Part189.tree (include_str ".."/"source"/"cases"/"Direct"/"global_094.inc")
theorem checked_node094 : node094.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part188.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part189.checked_tree⟩
def node095 : InputTree := .join "global_095.inc" LCMSourcePV.Adaptive.InputDirect.Part190.tree LCMSourcePV.Adaptive.InputDirect.Part191.tree (include_str ".."/"source"/"cases"/"Direct"/"global_095.inc")
theorem checked_node095 : node095.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part190.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part191.checked_tree⟩
def node096 : InputTree := .join "global_096.inc" LCMSourcePV.Adaptive.InputDirect.Part192.tree LCMSourcePV.Adaptive.InputDirect.Part193.tree (include_str ".."/"source"/"cases"/"Direct"/"global_096.inc")
theorem checked_node096 : node096.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part192.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part193.checked_tree⟩
def node097 : InputTree := .join "global_097.inc" LCMSourcePV.Adaptive.InputDirect.Part194.tree LCMSourcePV.Adaptive.InputDirect.Part195.tree (include_str ".."/"source"/"cases"/"Direct"/"global_097.inc")
theorem checked_node097 : node097.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part194.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part195.checked_tree⟩
def node098 : InputTree := .join "global_098.inc" LCMSourcePV.Adaptive.InputDirect.Part196.tree LCMSourcePV.Adaptive.InputDirect.Part197.tree (include_str ".."/"source"/"cases"/"Direct"/"global_098.inc")
theorem checked_node098 : node098.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part196.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part197.checked_tree⟩
def node099 : InputTree := .join "global_099.inc" LCMSourcePV.Adaptive.InputDirect.Part198.tree LCMSourcePV.Adaptive.InputDirect.Part199.tree (include_str ".."/"source"/"cases"/"Direct"/"global_099.inc")
theorem checked_node099 : node099.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part198.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part199.checked_tree⟩
def node100 : InputTree := .join "global_100.inc" LCMSourcePV.Adaptive.InputDirect.Part200.tree LCMSourcePV.Adaptive.InputDirect.Part201.tree (include_str ".."/"source"/"cases"/"Direct"/"global_100.inc")
theorem checked_node100 : node100.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part200.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part201.checked_tree⟩
def node101 : InputTree := .join "global_101.inc" LCMSourcePV.Adaptive.InputDirect.Part202.tree LCMSourcePV.Adaptive.InputDirect.Part203.tree (include_str ".."/"source"/"cases"/"Direct"/"global_101.inc")
theorem checked_node101 : node101.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part202.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part203.checked_tree⟩
def node102 : InputTree := .join "global_102.inc" LCMSourcePV.Adaptive.InputDirect.Part204.tree LCMSourcePV.Adaptive.InputDirect.Part205.tree (include_str ".."/"source"/"cases"/"Direct"/"global_102.inc")
theorem checked_node102 : node102.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part204.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part205.checked_tree⟩
def node103 : InputTree := .join "global_103.inc" LCMSourcePV.Adaptive.InputDirect.Part206.tree LCMSourcePV.Adaptive.InputDirect.Part207.tree (include_str ".."/"source"/"cases"/"Direct"/"global_103.inc")
theorem checked_node103 : node103.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part206.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part207.checked_tree⟩
def node104 : InputTree := .join "global_104.inc" LCMSourcePV.Adaptive.InputDirect.Part208.tree LCMSourcePV.Adaptive.InputDirect.Part209.tree (include_str ".."/"source"/"cases"/"Direct"/"global_104.inc")
theorem checked_node104 : node104.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part208.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part209.checked_tree⟩
def node105 : InputTree := .join "global_105.inc" LCMSourcePV.Adaptive.InputDirect.Part210.tree LCMSourcePV.Adaptive.InputDirect.Part211.tree (include_str ".."/"source"/"cases"/"Direct"/"global_105.inc")
theorem checked_node105 : node105.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part210.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part211.checked_tree⟩
def node106 : InputTree := .join "global_106.inc" LCMSourcePV.Adaptive.InputDirect.Part212.tree LCMSourcePV.Adaptive.InputDirect.Part213.tree (include_str ".."/"source"/"cases"/"Direct"/"global_106.inc")
theorem checked_node106 : node106.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part212.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part213.checked_tree⟩
def node107 : InputTree := .join "global_107.inc" LCMSourcePV.Adaptive.InputDirect.Part214.tree LCMSourcePV.Adaptive.InputDirect.Part215.tree (include_str ".."/"source"/"cases"/"Direct"/"global_107.inc")
theorem checked_node107 : node107.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part214.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part215.checked_tree⟩
def node108 : InputTree := .join "global_108.inc" LCMSourcePV.Adaptive.InputDirect.Part216.tree LCMSourcePV.Adaptive.InputDirect.Part217.tree (include_str ".."/"source"/"cases"/"Direct"/"global_108.inc")
theorem checked_node108 : node108.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part216.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part217.checked_tree⟩
def node109 : InputTree := .join "global_109.inc" LCMSourcePV.Adaptive.InputDirect.Part218.tree LCMSourcePV.Adaptive.InputDirect.Part219.tree (include_str ".."/"source"/"cases"/"Direct"/"global_109.inc")
theorem checked_node109 : node109.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part218.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part219.checked_tree⟩
def node110 : InputTree := .join "global_110.inc" LCMSourcePV.Adaptive.InputDirect.Part220.tree LCMSourcePV.Adaptive.InputDirect.Part221.tree (include_str ".."/"source"/"cases"/"Direct"/"global_110.inc")
theorem checked_node110 : node110.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part220.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part221.checked_tree⟩
def node111 : InputTree := .join "global_111.inc" LCMSourcePV.Adaptive.InputDirect.Part222.tree LCMSourcePV.Adaptive.InputDirect.Part223.tree (include_str ".."/"source"/"cases"/"Direct"/"global_111.inc")
theorem checked_node111 : node111.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part222.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part223.checked_tree⟩
def node112 : InputTree := .join "global_112.inc" LCMSourcePV.Adaptive.InputDirect.Part224.tree LCMSourcePV.Adaptive.InputDirect.Part225.tree (include_str ".."/"source"/"cases"/"Direct"/"global_112.inc")
theorem checked_node112 : node112.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part224.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part225.checked_tree⟩
def node113 : InputTree := .join "global_113.inc" LCMSourcePV.Adaptive.InputDirect.Part226.tree LCMSourcePV.Adaptive.InputDirect.Part227.tree (include_str ".."/"source"/"cases"/"Direct"/"global_113.inc")
theorem checked_node113 : node113.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part226.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part227.checked_tree⟩
def node114 : InputTree := .join "global_114.inc" LCMSourcePV.Adaptive.InputDirect.Part228.tree LCMSourcePV.Adaptive.InputDirect.Part229.tree (include_str ".."/"source"/"cases"/"Direct"/"global_114.inc")
theorem checked_node114 : node114.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part228.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part229.checked_tree⟩
def node115 : InputTree := .join "global_115.inc" LCMSourcePV.Adaptive.InputDirect.Part230.tree LCMSourcePV.Adaptive.InputDirect.Part231.tree (include_str ".."/"source"/"cases"/"Direct"/"global_115.inc")
theorem checked_node115 : node115.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part230.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part231.checked_tree⟩
def node116 : InputTree := .join "global_116.inc" LCMSourcePV.Adaptive.InputDirect.Part232.tree LCMSourcePV.Adaptive.InputDirect.Part233.tree (include_str ".."/"source"/"cases"/"Direct"/"global_116.inc")
theorem checked_node116 : node116.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part232.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part233.checked_tree⟩
def node117 : InputTree := .join "global_117.inc" LCMSourcePV.Adaptive.InputDirect.Part234.tree LCMSourcePV.Adaptive.InputDirect.Part235.tree (include_str ".."/"source"/"cases"/"Direct"/"global_117.inc")
theorem checked_node117 : node117.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part234.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part235.checked_tree⟩
def node118 : InputTree := .join "global_118.inc" LCMSourcePV.Adaptive.InputDirect.Part236.tree LCMSourcePV.Adaptive.InputDirect.Part237.tree (include_str ".."/"source"/"cases"/"Direct"/"global_118.inc")
theorem checked_node118 : node118.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part236.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part237.checked_tree⟩
def node119 : InputTree := .join "global_119.inc" LCMSourcePV.Adaptive.InputDirect.Part238.tree LCMSourcePV.Adaptive.InputDirect.Part239.tree (include_str ".."/"source"/"cases"/"Direct"/"global_119.inc")
theorem checked_node119 : node119.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part238.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part239.checked_tree⟩
def node120 : InputTree := .join "global_120.inc" LCMSourcePV.Adaptive.InputDirect.Part240.tree LCMSourcePV.Adaptive.InputDirect.Part241.tree (include_str ".."/"source"/"cases"/"Direct"/"global_120.inc")
theorem checked_node120 : node120.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part240.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part241.checked_tree⟩
def node121 : InputTree := .join "global_121.inc" LCMSourcePV.Adaptive.InputDirect.Part242.tree LCMSourcePV.Adaptive.InputDirect.Part243.tree (include_str ".."/"source"/"cases"/"Direct"/"global_121.inc")
theorem checked_node121 : node121.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part242.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part243.checked_tree⟩
def node122 : InputTree := .join "global_122.inc" LCMSourcePV.Adaptive.InputDirect.Part244.tree LCMSourcePV.Adaptive.InputDirect.Part245.tree (include_str ".."/"source"/"cases"/"Direct"/"global_122.inc")
theorem checked_node122 : node122.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part244.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part245.checked_tree⟩
def node123 : InputTree := .join "global_123.inc" LCMSourcePV.Adaptive.InputDirect.Part246.tree LCMSourcePV.Adaptive.InputDirect.Part247.tree (include_str ".."/"source"/"cases"/"Direct"/"global_123.inc")
theorem checked_node123 : node123.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part246.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part247.checked_tree⟩
def node124 : InputTree := .join "global_124.inc" LCMSourcePV.Adaptive.InputDirect.Part248.tree LCMSourcePV.Adaptive.InputDirect.Part249.tree (include_str ".."/"source"/"cases"/"Direct"/"global_124.inc")
theorem checked_node124 : node124.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part248.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part249.checked_tree⟩
def node125 : InputTree := .join "global_125.inc" LCMSourcePV.Adaptive.InputDirect.Part250.tree LCMSourcePV.Adaptive.InputDirect.Part251.tree (include_str ".."/"source"/"cases"/"Direct"/"global_125.inc")
theorem checked_node125 : node125.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part250.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part251.checked_tree⟩
def node126 : InputTree := .join "global_126.inc" LCMSourcePV.Adaptive.InputDirect.Part252.tree LCMSourcePV.Adaptive.InputDirect.Part253.tree (include_str ".."/"source"/"cases"/"Direct"/"global_126.inc")
theorem checked_node126 : node126.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part252.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part253.checked_tree⟩
def node127 : InputTree := .join "global_127.inc" LCMSourcePV.Adaptive.InputDirect.Part254.tree LCMSourcePV.Adaptive.InputDirect.Part255.tree (include_str ".."/"source"/"cases"/"Direct"/"global_127.inc")
theorem checked_node127 : node127.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part254.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part255.checked_tree⟩
def node128 : InputTree := .join "global_128.inc" LCMSourcePV.Adaptive.InputDirect.Part256.tree LCMSourcePV.Adaptive.InputDirect.Part257.tree (include_str ".."/"source"/"cases"/"Direct"/"global_128.inc")
theorem checked_node128 : node128.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part256.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part257.checked_tree⟩
def node129 : InputTree := .join "global_129.inc" LCMSourcePV.Adaptive.InputDirect.Part258.tree LCMSourcePV.Adaptive.InputDirect.Part259.tree (include_str ".."/"source"/"cases"/"Direct"/"global_129.inc")
theorem checked_node129 : node129.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part258.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part259.checked_tree⟩
def node130 : InputTree := .join "global_130.inc" LCMSourcePV.Adaptive.InputDirect.Part260.tree LCMSourcePV.Adaptive.InputDirect.Part261.tree (include_str ".."/"source"/"cases"/"Direct"/"global_130.inc")
theorem checked_node130 : node130.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part260.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part261.checked_tree⟩
def node131 : InputTree := .join "global_131.inc" LCMSourcePV.Adaptive.InputDirect.Part262.tree LCMSourcePV.Adaptive.InputDirect.Part263.tree (include_str ".."/"source"/"cases"/"Direct"/"global_131.inc")
theorem checked_node131 : node131.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part262.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part263.checked_tree⟩
def node132 : InputTree := .join "global_132.inc" LCMSourcePV.Adaptive.InputDirect.Part264.tree LCMSourcePV.Adaptive.InputDirect.Part265.tree (include_str ".."/"source"/"cases"/"Direct"/"global_132.inc")
theorem checked_node132 : node132.Checked := ⟨by decide,LCMSourcePV.Adaptive.InputDirect.Part264.checked_tree,LCMSourcePV.Adaptive.InputDirect.Part265.checked_tree⟩
def node133 : InputTree := .join "global_133.inc" node000 node001 (include_str ".."/"source"/"cases"/"Direct"/"global_133.inc")
theorem checked_node133 : node133.Checked := ⟨by decide,checked_node000,checked_node001⟩
def node134 : InputTree := .join "global_134.inc" node002 node003 (include_str ".."/"source"/"cases"/"Direct"/"global_134.inc")
theorem checked_node134 : node134.Checked := ⟨by decide,checked_node002,checked_node003⟩
def node135 : InputTree := .join "global_135.inc" node004 node005 (include_str ".."/"source"/"cases"/"Direct"/"global_135.inc")
theorem checked_node135 : node135.Checked := ⟨by decide,checked_node004,checked_node005⟩
def node136 : InputTree := .join "global_136.inc" node006 node007 (include_str ".."/"source"/"cases"/"Direct"/"global_136.inc")
theorem checked_node136 : node136.Checked := ⟨by decide,checked_node006,checked_node007⟩
def node137 : InputTree := .join "global_137.inc" node008 node009 (include_str ".."/"source"/"cases"/"Direct"/"global_137.inc")
theorem checked_node137 : node137.Checked := ⟨by decide,checked_node008,checked_node009⟩
def node138 : InputTree := .join "global_138.inc" node010 node011 (include_str ".."/"source"/"cases"/"Direct"/"global_138.inc")
theorem checked_node138 : node138.Checked := ⟨by decide,checked_node010,checked_node011⟩
def node139 : InputTree := .join "global_139.inc" node012 node013 (include_str ".."/"source"/"cases"/"Direct"/"global_139.inc")
theorem checked_node139 : node139.Checked := ⟨by decide,checked_node012,checked_node013⟩
def node140 : InputTree := .join "global_140.inc" node014 node015 (include_str ".."/"source"/"cases"/"Direct"/"global_140.inc")
theorem checked_node140 : node140.Checked := ⟨by decide,checked_node014,checked_node015⟩
def node141 : InputTree := .join "global_141.inc" node016 node017 (include_str ".."/"source"/"cases"/"Direct"/"global_141.inc")
theorem checked_node141 : node141.Checked := ⟨by decide,checked_node016,checked_node017⟩
def node142 : InputTree := .join "global_142.inc" node018 node019 (include_str ".."/"source"/"cases"/"Direct"/"global_142.inc")
theorem checked_node142 : node142.Checked := ⟨by decide,checked_node018,checked_node019⟩
def node143 : InputTree := .join "global_143.inc" node020 node021 (include_str ".."/"source"/"cases"/"Direct"/"global_143.inc")
theorem checked_node143 : node143.Checked := ⟨by decide,checked_node020,checked_node021⟩
def node144 : InputTree := .join "global_144.inc" node022 node023 (include_str ".."/"source"/"cases"/"Direct"/"global_144.inc")
theorem checked_node144 : node144.Checked := ⟨by decide,checked_node022,checked_node023⟩
def node145 : InputTree := .join "global_145.inc" node024 node025 (include_str ".."/"source"/"cases"/"Direct"/"global_145.inc")
theorem checked_node145 : node145.Checked := ⟨by decide,checked_node024,checked_node025⟩
def node146 : InputTree := .join "global_146.inc" node026 node027 (include_str ".."/"source"/"cases"/"Direct"/"global_146.inc")
theorem checked_node146 : node146.Checked := ⟨by decide,checked_node026,checked_node027⟩
def node147 : InputTree := .join "global_147.inc" node028 node029 (include_str ".."/"source"/"cases"/"Direct"/"global_147.inc")
theorem checked_node147 : node147.Checked := ⟨by decide,checked_node028,checked_node029⟩
def node148 : InputTree := .join "global_148.inc" node030 node031 (include_str ".."/"source"/"cases"/"Direct"/"global_148.inc")
theorem checked_node148 : node148.Checked := ⟨by decide,checked_node030,checked_node031⟩
def node149 : InputTree := .join "global_149.inc" node032 node033 (include_str ".."/"source"/"cases"/"Direct"/"global_149.inc")
theorem checked_node149 : node149.Checked := ⟨by decide,checked_node032,checked_node033⟩
def node150 : InputTree := .join "global_150.inc" node034 node035 (include_str ".."/"source"/"cases"/"Direct"/"global_150.inc")
theorem checked_node150 : node150.Checked := ⟨by decide,checked_node034,checked_node035⟩
def node151 : InputTree := .join "global_151.inc" node036 node037 (include_str ".."/"source"/"cases"/"Direct"/"global_151.inc")
theorem checked_node151 : node151.Checked := ⟨by decide,checked_node036,checked_node037⟩
def node152 : InputTree := .join "global_152.inc" node038 node039 (include_str ".."/"source"/"cases"/"Direct"/"global_152.inc")
theorem checked_node152 : node152.Checked := ⟨by decide,checked_node038,checked_node039⟩
def node153 : InputTree := .join "global_153.inc" node040 node041 (include_str ".."/"source"/"cases"/"Direct"/"global_153.inc")
theorem checked_node153 : node153.Checked := ⟨by decide,checked_node040,checked_node041⟩
def node154 : InputTree := .join "global_154.inc" node042 node043 (include_str ".."/"source"/"cases"/"Direct"/"global_154.inc")
theorem checked_node154 : node154.Checked := ⟨by decide,checked_node042,checked_node043⟩
def node155 : InputTree := .join "global_155.inc" node044 node045 (include_str ".."/"source"/"cases"/"Direct"/"global_155.inc")
theorem checked_node155 : node155.Checked := ⟨by decide,checked_node044,checked_node045⟩
def node156 : InputTree := .join "global_156.inc" node046 node047 (include_str ".."/"source"/"cases"/"Direct"/"global_156.inc")
theorem checked_node156 : node156.Checked := ⟨by decide,checked_node046,checked_node047⟩
def node157 : InputTree := .join "global_157.inc" node048 node049 (include_str ".."/"source"/"cases"/"Direct"/"global_157.inc")
theorem checked_node157 : node157.Checked := ⟨by decide,checked_node048,checked_node049⟩
def node158 : InputTree := .join "global_158.inc" node050 node051 (include_str ".."/"source"/"cases"/"Direct"/"global_158.inc")
theorem checked_node158 : node158.Checked := ⟨by decide,checked_node050,checked_node051⟩
def node159 : InputTree := .join "global_159.inc" node052 node053 (include_str ".."/"source"/"cases"/"Direct"/"global_159.inc")
theorem checked_node159 : node159.Checked := ⟨by decide,checked_node052,checked_node053⟩
def node160 : InputTree := .join "global_160.inc" node054 node055 (include_str ".."/"source"/"cases"/"Direct"/"global_160.inc")
theorem checked_node160 : node160.Checked := ⟨by decide,checked_node054,checked_node055⟩
def node161 : InputTree := .join "global_161.inc" node056 node057 (include_str ".."/"source"/"cases"/"Direct"/"global_161.inc")
theorem checked_node161 : node161.Checked := ⟨by decide,checked_node056,checked_node057⟩
def node162 : InputTree := .join "global_162.inc" node058 node059 (include_str ".."/"source"/"cases"/"Direct"/"global_162.inc")
theorem checked_node162 : node162.Checked := ⟨by decide,checked_node058,checked_node059⟩
def node163 : InputTree := .join "global_163.inc" node060 node061 (include_str ".."/"source"/"cases"/"Direct"/"global_163.inc")
theorem checked_node163 : node163.Checked := ⟨by decide,checked_node060,checked_node061⟩
def node164 : InputTree := .join "global_164.inc" node062 node063 (include_str ".."/"source"/"cases"/"Direct"/"global_164.inc")
theorem checked_node164 : node164.Checked := ⟨by decide,checked_node062,checked_node063⟩
def node165 : InputTree := .join "global_165.inc" node064 node065 (include_str ".."/"source"/"cases"/"Direct"/"global_165.inc")
theorem checked_node165 : node165.Checked := ⟨by decide,checked_node064,checked_node065⟩
def node166 : InputTree := .join "global_166.inc" node066 node067 (include_str ".."/"source"/"cases"/"Direct"/"global_166.inc")
theorem checked_node166 : node166.Checked := ⟨by decide,checked_node066,checked_node067⟩
def node167 : InputTree := .join "global_167.inc" node068 node069 (include_str ".."/"source"/"cases"/"Direct"/"global_167.inc")
theorem checked_node167 : node167.Checked := ⟨by decide,checked_node068,checked_node069⟩
def node168 : InputTree := .join "global_168.inc" node070 node071 (include_str ".."/"source"/"cases"/"Direct"/"global_168.inc")
theorem checked_node168 : node168.Checked := ⟨by decide,checked_node070,checked_node071⟩
def node169 : InputTree := .join "global_169.inc" node072 node073 (include_str ".."/"source"/"cases"/"Direct"/"global_169.inc")
theorem checked_node169 : node169.Checked := ⟨by decide,checked_node072,checked_node073⟩
def node170 : InputTree := .join "global_170.inc" node074 node075 (include_str ".."/"source"/"cases"/"Direct"/"global_170.inc")
theorem checked_node170 : node170.Checked := ⟨by decide,checked_node074,checked_node075⟩
def node171 : InputTree := .join "global_171.inc" node076 node077 (include_str ".."/"source"/"cases"/"Direct"/"global_171.inc")
theorem checked_node171 : node171.Checked := ⟨by decide,checked_node076,checked_node077⟩
def node172 : InputTree := .join "global_172.inc" node078 node079 (include_str ".."/"source"/"cases"/"Direct"/"global_172.inc")
theorem checked_node172 : node172.Checked := ⟨by decide,checked_node078,checked_node079⟩
def node173 : InputTree := .join "global_173.inc" node080 node081 (include_str ".."/"source"/"cases"/"Direct"/"global_173.inc")
theorem checked_node173 : node173.Checked := ⟨by decide,checked_node080,checked_node081⟩
def node174 : InputTree := .join "global_174.inc" node082 node083 (include_str ".."/"source"/"cases"/"Direct"/"global_174.inc")
theorem checked_node174 : node174.Checked := ⟨by decide,checked_node082,checked_node083⟩
def node175 : InputTree := .join "global_175.inc" node084 node085 (include_str ".."/"source"/"cases"/"Direct"/"global_175.inc")
theorem checked_node175 : node175.Checked := ⟨by decide,checked_node084,checked_node085⟩
def node176 : InputTree := .join "global_176.inc" node086 node087 (include_str ".."/"source"/"cases"/"Direct"/"global_176.inc")
theorem checked_node176 : node176.Checked := ⟨by decide,checked_node086,checked_node087⟩
def node177 : InputTree := .join "global_177.inc" node088 node089 (include_str ".."/"source"/"cases"/"Direct"/"global_177.inc")
theorem checked_node177 : node177.Checked := ⟨by decide,checked_node088,checked_node089⟩
def node178 : InputTree := .join "global_178.inc" node090 node091 (include_str ".."/"source"/"cases"/"Direct"/"global_178.inc")
theorem checked_node178 : node178.Checked := ⟨by decide,checked_node090,checked_node091⟩
def node179 : InputTree := .join "global_179.inc" node092 node093 (include_str ".."/"source"/"cases"/"Direct"/"global_179.inc")
theorem checked_node179 : node179.Checked := ⟨by decide,checked_node092,checked_node093⟩
def node180 : InputTree := .join "global_180.inc" node094 node095 (include_str ".."/"source"/"cases"/"Direct"/"global_180.inc")
theorem checked_node180 : node180.Checked := ⟨by decide,checked_node094,checked_node095⟩
def node181 : InputTree := .join "global_181.inc" node096 node097 (include_str ".."/"source"/"cases"/"Direct"/"global_181.inc")
theorem checked_node181 : node181.Checked := ⟨by decide,checked_node096,checked_node097⟩
def node182 : InputTree := .join "global_182.inc" node098 node099 (include_str ".."/"source"/"cases"/"Direct"/"global_182.inc")
theorem checked_node182 : node182.Checked := ⟨by decide,checked_node098,checked_node099⟩
def node183 : InputTree := .join "global_183.inc" node100 node101 (include_str ".."/"source"/"cases"/"Direct"/"global_183.inc")
theorem checked_node183 : node183.Checked := ⟨by decide,checked_node100,checked_node101⟩
def node184 : InputTree := .join "global_184.inc" node102 node103 (include_str ".."/"source"/"cases"/"Direct"/"global_184.inc")
theorem checked_node184 : node184.Checked := ⟨by decide,checked_node102,checked_node103⟩
def node185 : InputTree := .join "global_185.inc" node104 node105 (include_str ".."/"source"/"cases"/"Direct"/"global_185.inc")
theorem checked_node185 : node185.Checked := ⟨by decide,checked_node104,checked_node105⟩
def node186 : InputTree := .join "global_186.inc" node106 node107 (include_str ".."/"source"/"cases"/"Direct"/"global_186.inc")
theorem checked_node186 : node186.Checked := ⟨by decide,checked_node106,checked_node107⟩
def node187 : InputTree := .join "global_187.inc" node108 node109 (include_str ".."/"source"/"cases"/"Direct"/"global_187.inc")
theorem checked_node187 : node187.Checked := ⟨by decide,checked_node108,checked_node109⟩
def node188 : InputTree := .join "global_188.inc" node110 node111 (include_str ".."/"source"/"cases"/"Direct"/"global_188.inc")
theorem checked_node188 : node188.Checked := ⟨by decide,checked_node110,checked_node111⟩
def node189 : InputTree := .join "global_189.inc" node112 node113 (include_str ".."/"source"/"cases"/"Direct"/"global_189.inc")
theorem checked_node189 : node189.Checked := ⟨by decide,checked_node112,checked_node113⟩
def node190 : InputTree := .join "global_190.inc" node114 node115 (include_str ".."/"source"/"cases"/"Direct"/"global_190.inc")
theorem checked_node190 : node190.Checked := ⟨by decide,checked_node114,checked_node115⟩
def node191 : InputTree := .join "global_191.inc" node116 node117 (include_str ".."/"source"/"cases"/"Direct"/"global_191.inc")
theorem checked_node191 : node191.Checked := ⟨by decide,checked_node116,checked_node117⟩
def node192 : InputTree := .join "global_192.inc" node118 node119 (include_str ".."/"source"/"cases"/"Direct"/"global_192.inc")
theorem checked_node192 : node192.Checked := ⟨by decide,checked_node118,checked_node119⟩
def node193 : InputTree := .join "global_193.inc" node120 node121 (include_str ".."/"source"/"cases"/"Direct"/"global_193.inc")
theorem checked_node193 : node193.Checked := ⟨by decide,checked_node120,checked_node121⟩
def node194 : InputTree := .join "global_194.inc" node122 node123 (include_str ".."/"source"/"cases"/"Direct"/"global_194.inc")
theorem checked_node194 : node194.Checked := ⟨by decide,checked_node122,checked_node123⟩
def node195 : InputTree := .join "global_195.inc" node124 node125 (include_str ".."/"source"/"cases"/"Direct"/"global_195.inc")
theorem checked_node195 : node195.Checked := ⟨by decide,checked_node124,checked_node125⟩
def node196 : InputTree := .join "global_196.inc" node126 node127 (include_str ".."/"source"/"cases"/"Direct"/"global_196.inc")
theorem checked_node196 : node196.Checked := ⟨by decide,checked_node126,checked_node127⟩
def node197 : InputTree := .join "global_197.inc" node128 node129 (include_str ".."/"source"/"cases"/"Direct"/"global_197.inc")
theorem checked_node197 : node197.Checked := ⟨by decide,checked_node128,checked_node129⟩
def node198 : InputTree := .join "global_198.inc" node130 node131 (include_str ".."/"source"/"cases"/"Direct"/"global_198.inc")
theorem checked_node198 : node198.Checked := ⟨by decide,checked_node130,checked_node131⟩
def node199 : InputTree := .join "global_199.inc" node132 LCMSourcePV.Adaptive.InputDirect.Part266.tree (include_str ".."/"source"/"cases"/"Direct"/"global_199.inc")
theorem checked_node199 : node199.Checked := ⟨by decide,checked_node132,LCMSourcePV.Adaptive.InputDirect.Part266.checked_tree⟩
def node200 : InputTree := .join "global_200.inc" node133 node134 (include_str ".."/"source"/"cases"/"Direct"/"global_200.inc")
theorem checked_node200 : node200.Checked := ⟨by decide,checked_node133,checked_node134⟩
def node201 : InputTree := .join "global_201.inc" node135 node136 (include_str ".."/"source"/"cases"/"Direct"/"global_201.inc")
theorem checked_node201 : node201.Checked := ⟨by decide,checked_node135,checked_node136⟩
def node202 : InputTree := .join "global_202.inc" node137 node138 (include_str ".."/"source"/"cases"/"Direct"/"global_202.inc")
theorem checked_node202 : node202.Checked := ⟨by decide,checked_node137,checked_node138⟩
def node203 : InputTree := .join "global_203.inc" node139 node140 (include_str ".."/"source"/"cases"/"Direct"/"global_203.inc")
theorem checked_node203 : node203.Checked := ⟨by decide,checked_node139,checked_node140⟩
def node204 : InputTree := .join "global_204.inc" node141 node142 (include_str ".."/"source"/"cases"/"Direct"/"global_204.inc")
theorem checked_node204 : node204.Checked := ⟨by decide,checked_node141,checked_node142⟩
def node205 : InputTree := .join "global_205.inc" node143 node144 (include_str ".."/"source"/"cases"/"Direct"/"global_205.inc")
theorem checked_node205 : node205.Checked := ⟨by decide,checked_node143,checked_node144⟩
def node206 : InputTree := .join "global_206.inc" node145 node146 (include_str ".."/"source"/"cases"/"Direct"/"global_206.inc")
theorem checked_node206 : node206.Checked := ⟨by decide,checked_node145,checked_node146⟩
def node207 : InputTree := .join "global_207.inc" node147 node148 (include_str ".."/"source"/"cases"/"Direct"/"global_207.inc")
theorem checked_node207 : node207.Checked := ⟨by decide,checked_node147,checked_node148⟩
def node208 : InputTree := .join "global_208.inc" node149 node150 (include_str ".."/"source"/"cases"/"Direct"/"global_208.inc")
theorem checked_node208 : node208.Checked := ⟨by decide,checked_node149,checked_node150⟩
def node209 : InputTree := .join "global_209.inc" node151 node152 (include_str ".."/"source"/"cases"/"Direct"/"global_209.inc")
theorem checked_node209 : node209.Checked := ⟨by decide,checked_node151,checked_node152⟩
def node210 : InputTree := .join "global_210.inc" node153 node154 (include_str ".."/"source"/"cases"/"Direct"/"global_210.inc")
theorem checked_node210 : node210.Checked := ⟨by decide,checked_node153,checked_node154⟩
def node211 : InputTree := .join "global_211.inc" node155 node156 (include_str ".."/"source"/"cases"/"Direct"/"global_211.inc")
theorem checked_node211 : node211.Checked := ⟨by decide,checked_node155,checked_node156⟩
def node212 : InputTree := .join "global_212.inc" node157 node158 (include_str ".."/"source"/"cases"/"Direct"/"global_212.inc")
theorem checked_node212 : node212.Checked := ⟨by decide,checked_node157,checked_node158⟩
def node213 : InputTree := .join "global_213.inc" node159 node160 (include_str ".."/"source"/"cases"/"Direct"/"global_213.inc")
theorem checked_node213 : node213.Checked := ⟨by decide,checked_node159,checked_node160⟩
def node214 : InputTree := .join "global_214.inc" node161 node162 (include_str ".."/"source"/"cases"/"Direct"/"global_214.inc")
theorem checked_node214 : node214.Checked := ⟨by decide,checked_node161,checked_node162⟩
def node215 : InputTree := .join "global_215.inc" node163 node164 (include_str ".."/"source"/"cases"/"Direct"/"global_215.inc")
theorem checked_node215 : node215.Checked := ⟨by decide,checked_node163,checked_node164⟩
def node216 : InputTree := .join "global_216.inc" node165 node166 (include_str ".."/"source"/"cases"/"Direct"/"global_216.inc")
theorem checked_node216 : node216.Checked := ⟨by decide,checked_node165,checked_node166⟩
def node217 : InputTree := .join "global_217.inc" node167 node168 (include_str ".."/"source"/"cases"/"Direct"/"global_217.inc")
theorem checked_node217 : node217.Checked := ⟨by decide,checked_node167,checked_node168⟩
def node218 : InputTree := .join "global_218.inc" node169 node170 (include_str ".."/"source"/"cases"/"Direct"/"global_218.inc")
theorem checked_node218 : node218.Checked := ⟨by decide,checked_node169,checked_node170⟩
def node219 : InputTree := .join "global_219.inc" node171 node172 (include_str ".."/"source"/"cases"/"Direct"/"global_219.inc")
theorem checked_node219 : node219.Checked := ⟨by decide,checked_node171,checked_node172⟩
def node220 : InputTree := .join "global_220.inc" node173 node174 (include_str ".."/"source"/"cases"/"Direct"/"global_220.inc")
theorem checked_node220 : node220.Checked := ⟨by decide,checked_node173,checked_node174⟩
def node221 : InputTree := .join "global_221.inc" node175 node176 (include_str ".."/"source"/"cases"/"Direct"/"global_221.inc")
theorem checked_node221 : node221.Checked := ⟨by decide,checked_node175,checked_node176⟩
def node222 : InputTree := .join "global_222.inc" node177 node178 (include_str ".."/"source"/"cases"/"Direct"/"global_222.inc")
theorem checked_node222 : node222.Checked := ⟨by decide,checked_node177,checked_node178⟩
def node223 : InputTree := .join "global_223.inc" node179 node180 (include_str ".."/"source"/"cases"/"Direct"/"global_223.inc")
theorem checked_node223 : node223.Checked := ⟨by decide,checked_node179,checked_node180⟩
def node224 : InputTree := .join "global_224.inc" node181 node182 (include_str ".."/"source"/"cases"/"Direct"/"global_224.inc")
theorem checked_node224 : node224.Checked := ⟨by decide,checked_node181,checked_node182⟩
def node225 : InputTree := .join "global_225.inc" node183 node184 (include_str ".."/"source"/"cases"/"Direct"/"global_225.inc")
theorem checked_node225 : node225.Checked := ⟨by decide,checked_node183,checked_node184⟩
def node226 : InputTree := .join "global_226.inc" node185 node186 (include_str ".."/"source"/"cases"/"Direct"/"global_226.inc")
theorem checked_node226 : node226.Checked := ⟨by decide,checked_node185,checked_node186⟩
def node227 : InputTree := .join "global_227.inc" node187 node188 (include_str ".."/"source"/"cases"/"Direct"/"global_227.inc")
theorem checked_node227 : node227.Checked := ⟨by decide,checked_node187,checked_node188⟩
def node228 : InputTree := .join "global_228.inc" node189 node190 (include_str ".."/"source"/"cases"/"Direct"/"global_228.inc")
theorem checked_node228 : node228.Checked := ⟨by decide,checked_node189,checked_node190⟩
def node229 : InputTree := .join "global_229.inc" node191 node192 (include_str ".."/"source"/"cases"/"Direct"/"global_229.inc")
theorem checked_node229 : node229.Checked := ⟨by decide,checked_node191,checked_node192⟩
def node230 : InputTree := .join "global_230.inc" node193 node194 (include_str ".."/"source"/"cases"/"Direct"/"global_230.inc")
theorem checked_node230 : node230.Checked := ⟨by decide,checked_node193,checked_node194⟩
def node231 : InputTree := .join "global_231.inc" node195 node196 (include_str ".."/"source"/"cases"/"Direct"/"global_231.inc")
theorem checked_node231 : node231.Checked := ⟨by decide,checked_node195,checked_node196⟩
def node232 : InputTree := .join "global_232.inc" node197 node198 (include_str ".."/"source"/"cases"/"Direct"/"global_232.inc")
theorem checked_node232 : node232.Checked := ⟨by decide,checked_node197,checked_node198⟩
def node233 : InputTree := .join "global_233.inc" node200 node201 (include_str ".."/"source"/"cases"/"Direct"/"global_233.inc")
theorem checked_node233 : node233.Checked := ⟨by decide,checked_node200,checked_node201⟩
def node234 : InputTree := .join "global_234.inc" node202 node203 (include_str ".."/"source"/"cases"/"Direct"/"global_234.inc")
theorem checked_node234 : node234.Checked := ⟨by decide,checked_node202,checked_node203⟩
def node235 : InputTree := .join "global_235.inc" node204 node205 (include_str ".."/"source"/"cases"/"Direct"/"global_235.inc")
theorem checked_node235 : node235.Checked := ⟨by decide,checked_node204,checked_node205⟩
def node236 : InputTree := .join "global_236.inc" node206 node207 (include_str ".."/"source"/"cases"/"Direct"/"global_236.inc")
theorem checked_node236 : node236.Checked := ⟨by decide,checked_node206,checked_node207⟩
def node237 : InputTree := .join "global_237.inc" node208 node209 (include_str ".."/"source"/"cases"/"Direct"/"global_237.inc")
theorem checked_node237 : node237.Checked := ⟨by decide,checked_node208,checked_node209⟩
def node238 : InputTree := .join "global_238.inc" node210 node211 (include_str ".."/"source"/"cases"/"Direct"/"global_238.inc")
theorem checked_node238 : node238.Checked := ⟨by decide,checked_node210,checked_node211⟩
def node239 : InputTree := .join "global_239.inc" node212 node213 (include_str ".."/"source"/"cases"/"Direct"/"global_239.inc")
theorem checked_node239 : node239.Checked := ⟨by decide,checked_node212,checked_node213⟩
def node240 : InputTree := .join "global_240.inc" node214 node215 (include_str ".."/"source"/"cases"/"Direct"/"global_240.inc")
theorem checked_node240 : node240.Checked := ⟨by decide,checked_node214,checked_node215⟩
def node241 : InputTree := .join "global_241.inc" node216 node217 (include_str ".."/"source"/"cases"/"Direct"/"global_241.inc")
theorem checked_node241 : node241.Checked := ⟨by decide,checked_node216,checked_node217⟩
def node242 : InputTree := .join "global_242.inc" node218 node219 (include_str ".."/"source"/"cases"/"Direct"/"global_242.inc")
theorem checked_node242 : node242.Checked := ⟨by decide,checked_node218,checked_node219⟩
def node243 : InputTree := .join "global_243.inc" node220 node221 (include_str ".."/"source"/"cases"/"Direct"/"global_243.inc")
theorem checked_node243 : node243.Checked := ⟨by decide,checked_node220,checked_node221⟩
def node244 : InputTree := .join "global_244.inc" node222 node223 (include_str ".."/"source"/"cases"/"Direct"/"global_244.inc")
theorem checked_node244 : node244.Checked := ⟨by decide,checked_node222,checked_node223⟩
def node245 : InputTree := .join "global_245.inc" node224 node225 (include_str ".."/"source"/"cases"/"Direct"/"global_245.inc")
theorem checked_node245 : node245.Checked := ⟨by decide,checked_node224,checked_node225⟩
def node246 : InputTree := .join "global_246.inc" node226 node227 (include_str ".."/"source"/"cases"/"Direct"/"global_246.inc")
theorem checked_node246 : node246.Checked := ⟨by decide,checked_node226,checked_node227⟩
def node247 : InputTree := .join "global_247.inc" node228 node229 (include_str ".."/"source"/"cases"/"Direct"/"global_247.inc")
theorem checked_node247 : node247.Checked := ⟨by decide,checked_node228,checked_node229⟩
def node248 : InputTree := .join "global_248.inc" node230 node231 (include_str ".."/"source"/"cases"/"Direct"/"global_248.inc")
theorem checked_node248 : node248.Checked := ⟨by decide,checked_node230,checked_node231⟩
def node249 : InputTree := .join "global_249.inc" node232 node199 (include_str ".."/"source"/"cases"/"Direct"/"global_249.inc")
theorem checked_node249 : node249.Checked := ⟨by decide,checked_node232,checked_node199⟩
def node250 : InputTree := .join "global_250.inc" node233 node234 (include_str ".."/"source"/"cases"/"Direct"/"global_250.inc")
theorem checked_node250 : node250.Checked := ⟨by decide,checked_node233,checked_node234⟩
def node251 : InputTree := .join "global_251.inc" node235 node236 (include_str ".."/"source"/"cases"/"Direct"/"global_251.inc")
theorem checked_node251 : node251.Checked := ⟨by decide,checked_node235,checked_node236⟩
def node252 : InputTree := .join "global_252.inc" node237 node238 (include_str ".."/"source"/"cases"/"Direct"/"global_252.inc")
theorem checked_node252 : node252.Checked := ⟨by decide,checked_node237,checked_node238⟩
def node253 : InputTree := .join "global_253.inc" node239 node240 (include_str ".."/"source"/"cases"/"Direct"/"global_253.inc")
theorem checked_node253 : node253.Checked := ⟨by decide,checked_node239,checked_node240⟩
def node254 : InputTree := .join "global_254.inc" node241 node242 (include_str ".."/"source"/"cases"/"Direct"/"global_254.inc")
theorem checked_node254 : node254.Checked := ⟨by decide,checked_node241,checked_node242⟩
def node255 : InputTree := .join "global_255.inc" node243 node244 (include_str ".."/"source"/"cases"/"Direct"/"global_255.inc")
theorem checked_node255 : node255.Checked := ⟨by decide,checked_node243,checked_node244⟩
def node256 : InputTree := .join "global_256.inc" node245 node246 (include_str ".."/"source"/"cases"/"Direct"/"global_256.inc")
theorem checked_node256 : node256.Checked := ⟨by decide,checked_node245,checked_node246⟩
def node257 : InputTree := .join "global_257.inc" node247 node248 (include_str ".."/"source"/"cases"/"Direct"/"global_257.inc")
theorem checked_node257 : node257.Checked := ⟨by decide,checked_node247,checked_node248⟩
def node258 : InputTree := .join "global_258.inc" node250 node251 (include_str ".."/"source"/"cases"/"Direct"/"global_258.inc")
theorem checked_node258 : node258.Checked := ⟨by decide,checked_node250,checked_node251⟩
def node259 : InputTree := .join "global_259.inc" node252 node253 (include_str ".."/"source"/"cases"/"Direct"/"global_259.inc")
theorem checked_node259 : node259.Checked := ⟨by decide,checked_node252,checked_node253⟩
def node260 : InputTree := .join "global_260.inc" node254 node255 (include_str ".."/"source"/"cases"/"Direct"/"global_260.inc")
theorem checked_node260 : node260.Checked := ⟨by decide,checked_node254,checked_node255⟩
def node261 : InputTree := .join "global_261.inc" node256 node257 (include_str ".."/"source"/"cases"/"Direct"/"global_261.inc")
theorem checked_node261 : node261.Checked := ⟨by decide,checked_node256,checked_node257⟩
def node262 : InputTree := .join "global_262.inc" node258 node259 (include_str ".."/"source"/"cases"/"Direct"/"global_262.inc")
theorem checked_node262 : node262.Checked := ⟨by decide,checked_node258,checked_node259⟩
def node263 : InputTree := .join "global_263.inc" node260 node261 (include_str ".."/"source"/"cases"/"Direct"/"global_263.inc")
theorem checked_node263 : node263.Checked := ⟨by decide,checked_node260,checked_node261⟩
def node264 : InputTree := .join "global_264.inc" node262 node263 (include_str ".."/"source"/"cases"/"Direct"/"global_264.inc")
theorem checked_node264 : node264.Checked := ⟨by decide,checked_node262,checked_node263⟩
def node265 : InputTree := .join "global_265.inc" node264 node249 (include_str ".."/"source"/"cases"/"Direct"/"global_265.inc")
theorem checked_node265 : node265.Checked := ⟨by decide,checked_node264,checked_node249⟩
def tree := node265
theorem checked_tree : tree.Checked := checked_node265
theorem entry_source : entrySource "global_265.inc" 8521 1000000 8044834249 3 10 = some (include_str ".."/"source"/"cases"/"Direct"/"main.c") := by decide
#print axioms checked_tree
#print axioms entry_source
end LCMSourcePV.Adaptive.InputDirect
