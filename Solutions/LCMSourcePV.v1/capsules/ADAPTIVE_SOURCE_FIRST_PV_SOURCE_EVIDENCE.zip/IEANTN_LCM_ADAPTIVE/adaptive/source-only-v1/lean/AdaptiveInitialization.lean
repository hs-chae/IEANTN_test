import AdaptiveInputSource
import AdaptiveHeader
namespace LCMSourcePV.Adaptive.C
set_option maxHeartbeats 0

/-- The standard unsigned conversion used by a C aggregate initializer. -/
def castRow (r : Row) : Row :=
  ⟨r.lo%2^64,r.hi%2^64,r.p0%2^64,r.p1%2^64,r.p2%2^64,
    r.q0%2^64,r.q1%2^64,r.q2%2^64,r.valuation%2^64⟩

theorem castRow_exact {r : Row} (h : RowRepresented r) : castRow r=r := by
  cases r with
  | mk lo hi p0 p1 p2 q0 q1 q2 valuation =>
    dsimp [castRow]
    congr 1 <;> apply Nat.mod_eq_of_lt <;> apply h <;> simp [Row.fields]

/-- Operational initialization of the actual static array. A leaf writes all
nine fields after their unsigned conversions; a join executes the two source
includes in order. No initially-correct application memory is assumed. -/
inductive Initialize : InputTree → Heap → Prop
  | leaf (name : String) (row : Row) (source : String) :
      Initialize (.leaf name row source) [castRow row]
  | join (name : String) (left right : InputTree) (source : String)
      (a b : Heap) (lrun : Initialize left a) (rrun : Initialize right b) :
      Initialize (.join name left right source) (a++b)

theorem initialize_checked {tree : InputTree} (checked : tree.Checked) :
    Initialize tree tree.values := by
  induction tree with
  | leaf name row source =>
    have step := Initialize.leaf name row source
    simpa only [castRow_exact checked.2,InputTree.values] using step
  | join name left right source il ir =>
    exact Initialize.join name left right source _ _ (il checked.2.1) (ir checked.2.2)

/-- Complete structured translation unit: verified functions are included,
the source initializer allocates the readonly Row array, then main executes.
Only the generic C compiler/startup/OS/hardware implementation is external. -/
structure ProgramUnit where
  input : InputTree
  count : Nat
  start : Nat
  stop : Nat
  num : Nat
  den : Nat

def ProgramUnit.render (p : ProgramUnit) : Option String :=
  entrySource p.input.name p.count p.start p.stop p.num p.den

def ProgramUnit.Initializes (p : ProgramUnit) (heap : Heap) : Prop :=
  Initialize p.input heap ∧ heap.length=p.count

#print axioms castRow_exact
#print axioms initialize_checked
end LCMSourcePV.Adaptive.C
