import AdaptiveInputSource
import AdaptiveRowsDirect.Part266
namespace LCMSourcePV.Adaptive.InputDirect.Part266
open LCMSourcePV.Adaptive.C
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def leaf00 : InputTree := .leaf "r_266_00.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row00 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_00.inc")
theorem checked_leaf00 : leaf00.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run00.gate⟩
def leaf01 : InputTree := .leaf "r_266_01.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row01 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_01.inc")
theorem checked_leaf01 : leaf01.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run01.gate⟩
def leaf02 : InputTree := .leaf "r_266_02.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row02 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_02.inc")
theorem checked_leaf02 : leaf02.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run02.gate⟩
def leaf03 : InputTree := .leaf "r_266_03.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row03 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_03.inc")
theorem checked_leaf03 : leaf03.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run03.gate⟩
def leaf04 : InputTree := .leaf "r_266_04.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row04 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_04.inc")
theorem checked_leaf04 : leaf04.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run04.gate⟩
def leaf05 : InputTree := .leaf "r_266_05.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row05 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_05.inc")
theorem checked_leaf05 : leaf05.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run05.gate⟩
def leaf06 : InputTree := .leaf "r_266_06.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row06 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_06.inc")
theorem checked_leaf06 : leaf06.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run06.gate⟩
def leaf07 : InputTree := .leaf "r_266_07.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row07 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_07.inc")
theorem checked_leaf07 : leaf07.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run07.gate⟩
def leaf08 : InputTree := .leaf "r_266_08.inc" LCMSourcePV.Adaptive.RowsDirect.Part266.row08 (include_str ".."/".."/"source"/"cases"/"Direct"/"r_266_08.inc")
theorem checked_leaf08 : leaf08.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsDirect.Part266.run08.gate⟩
def node000 : InputTree := .join "n_266_000.inc" leaf00 leaf01 (include_str ".."/".."/"source"/"cases"/"Direct"/"n_266_000.inc")
theorem checked_node000 : node000.Checked := ⟨by decide,checked_leaf00,checked_leaf01⟩
def node001 : InputTree := .join "n_266_001.inc" leaf02 leaf03 (include_str ".."/".."/"source"/"cases"/"Direct"/"n_266_001.inc")
theorem checked_node001 : node001.Checked := ⟨by decide,checked_leaf02,checked_leaf03⟩
def node002 : InputTree := .join "n_266_002.inc" leaf04 leaf05 (include_str ".."/".."/"source"/"cases"/"Direct"/"n_266_002.inc")
theorem checked_node002 : node002.Checked := ⟨by decide,checked_leaf04,checked_leaf05⟩
def node003 : InputTree := .join "n_266_003.inc" leaf06 leaf07 (include_str ".."/".."/"source"/"cases"/"Direct"/"n_266_003.inc")
theorem checked_node003 : node003.Checked := ⟨by decide,checked_leaf06,checked_leaf07⟩
def node004 : InputTree := .join "n_266_004.inc" node000 node001 (include_str ".."/".."/"source"/"cases"/"Direct"/"n_266_004.inc")
theorem checked_node004 : node004.Checked := ⟨by decide,checked_node000,checked_node001⟩
def node005 : InputTree := .join "n_266_005.inc" node002 node003 (include_str ".."/".."/"source"/"cases"/"Direct"/"n_266_005.inc")
theorem checked_node005 : node005.Checked := ⟨by decide,checked_node002,checked_node003⟩
def node006 : InputTree := .join "n_266_006.inc" node004 node005 (include_str ".."/".."/"source"/"cases"/"Direct"/"n_266_006.inc")
theorem checked_node006 : node006.Checked := ⟨by decide,checked_node004,checked_node005⟩
def node007 : InputTree := .join "n_266_007.inc" node006 leaf08 (include_str ".."/".."/"source"/"cases"/"Direct"/"n_266_007.inc")
theorem checked_node007 : node007.Checked := ⟨by decide,checked_node006,checked_leaf08⟩
def tree := node007
theorem checked_tree : tree.Checked := checked_node007
theorem values_tree : tree.values = LCMSourcePV.Adaptive.RowsDirect.Part266.rows := rfl
#print axioms checked_tree
end LCMSourcePV.Adaptive.InputDirect.Part266
