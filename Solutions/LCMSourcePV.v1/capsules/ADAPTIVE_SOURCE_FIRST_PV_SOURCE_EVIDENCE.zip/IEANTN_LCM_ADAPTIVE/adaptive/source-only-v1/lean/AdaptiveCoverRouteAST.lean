/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import AdaptiveCoverEntryAST
import AdaptiveRoutes
namespace LCMSourcePV.Adaptive.C
set_option maxHeartbeats 0

theorem CoverRows.of_route {rows : List Row} {lo finish num den : Nat}
    (runs : ∀ r∈rows, RowExec r num den) (run : route lo rows=some finish) :
    CoverRows num den rows lo finish := by
  induction rows generalizing lo with
  | nil =>
    have he : lo=finish := Option.some.inj run
    subst finish
    exact CoverRows.nil lo
  | cons r rs ih =>
    have head := runs r (by simp)
    have tail : ∀ r∈rs, RowExec r num den := fun r hr => runs r (by simp [hr])
    unfold route at run
    split at run
    · rename_i align
      exact CoverRows.cons r rs lo finish align head (ih tail run)
    · cases run

theorem cover_ast_of_route {heap : Heap} {start stop num den finish : Nat}
    (runs : ∀ r∈heap, RowExec r num den) (run : route start heap=some finish)
    (hc : heap.length<2^64) (ha : start<2^64) (hb : stop<2^64)
    (hn : num<2^64) (hd : den<2^64) (hend : stop≤finish) :
    CoverFunctionExec heap [.pointer 0,word 64 heap.length,word 64 start,
      word 64 stop,word 64 num,word 64 den] (.word 1 1) :=
  cover_ast (CoverRows.of_route runs run) hc ha hb hn hd hend

#print axioms CoverRows.of_route
#print axioms cover_ast_of_route
end LCMSourcePV.Adaptive.C
