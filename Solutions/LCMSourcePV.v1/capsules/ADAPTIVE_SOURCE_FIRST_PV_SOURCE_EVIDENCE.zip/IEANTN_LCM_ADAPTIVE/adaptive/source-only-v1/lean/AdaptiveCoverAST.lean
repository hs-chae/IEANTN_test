/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import AdaptiveASTRefinement
import LCMSourcePV.ASTLoops

namespace LCMSourcePV.Adaptive.C
open LCMSourcePV.Witness.C
open LCMSourcePV.ASTLoops
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- Pure expression evaluation, extended by a bounded address-of-array-element.
The heap is the actual represented readonly Row array, not a source oracle. -/
def evalCoverExpr (heap : Heap) (env : Env) : Expr → Option Value
  | .unary "&" (.index base index) => do
      let .pointer offset ← evalExpr (execFunction heap 8) heap env 100 base | none
      let .word _ i ← evalExpr (execFunction heap 8) heap env 100 index | none
      let _ ← heap[offset+i]?
      return .pointer (offset+i)
  | expr => evalExpr (execFunction heap 8) heap env 100 expr

def assignmentValue : Value → Value → Option Value
  | .word width _, .word _ n => some (word width n)
  | .pointer _, .pointer index => some (.pointer index)
  | _, _ => none

/-- Source-expression steps. Assignments and increments execute their AST
operands and apply the target unsigned representation, rather than updating
an independently specified abstract cover counter. -/
inductive CoverEval (heap : Heap) : Expr → Env → Env → Value → Prop
  | pure {expr env value} (run : evalCoverExpr heap env expr=some value) :
      CoverEval heap expr env env value
  | assign {name rhs env old value stored}
      (target : env name=some old) (run : evalCoverExpr heap env rhs=some value)
      (cast : assignmentValue old value=some stored) :
      CoverEval heap (.binary "=" (.var name) rhs) env (bind env name stored) stored
  | increment {name env width n}
      (target : env name=some (.word width n)) :
      CoverEval heap (.unary "++" (.var name)) env
        (bind env name (word width (n+1))) (word width (n+1))

def declareCover (heap : Heap) (decls : List Decl) (env : Env) : Option Env :=
  decls.foldlM (fun state d => do
    let expr ← d.value
    let value ← evalCoverExpr heap state expr
    let represented ← castValue d.type value
    return bind state d.name represented) env

def CoverDeclare (heap : Heap) (decls : List Decl) (a b : Env) : Prop :=
  declareCover heap decls a=some b

/-- Dead local bindings may remain in this value projection. The fixed source
does not shadow an outer binding or read r/i outside their lexical scope, and
no pointer to local storage is formed. Only the source return is observable. -/
def coverScope (_ : Env) (a b : ASTLoops.Flow Env Value) : Prop := a=b

abbrev CoverStmtRun (heap : Heap) :=
  ASTLoops.StmtRun (CoverEval heap) (CoverDeclare heap) truth coverScope
abbrev CoverSeqRun (heap : Heap) :=
  ASTLoops.SeqRun (CoverEval heap) (CoverDeclare heap) truth coverScope
abbrev CoverForRun (heap : Heap) :=
  ASTLoops.ForRun (CoverEval heap) (CoverDeclare heap) truth coverScope

structure CoverInv (env : Env) (count stop num den i lo : Nat) : Prop where
  rows : env "rows"=some (.pointer 0)
  count : env "count"=some (.word 64 count)
  stop : env "stop"=some (.word 64 stop)
  num : env "num"=some (.word 64 num)
  den : env "den"=some (.word 64 den)
  index : env "i"=some (.word 64 i)
  lo : env "lo"=some (.word 64 lo)

def coverCondition : Expr := .binary "<" (.var "i") (.var "count")
def coverIncrement : Expr := .unary "++" (.var "i")
def coverIteration : Stmt := .sequence [
  .declare [⟨"const Row*","r",some (.unary "&" (.index (.var "rows") (.var "i")))⟩],
  .branch (.binary "||" (.binary "!=" (.field "->" (.var "r") "lo") (.var "lo"))
    (.unary "!" (.call (.var "row_check") [.var "r",.var "num",.var "den"])))
    (.returnStmt (.var "false")) .skip,
  .eval (.binary "=" (.var "lo") (.binary "+" (.field "->" (.var "r") "hi") (.nat 1)))]

theorem eval_cover_condition {heap env count stop num den i lo}
    (inv : CoverInv env count stop num den i lo) :
    evalCoverExpr heap env coverCondition=some (boolean (i<count)) := by
  simp [evalCoverExpr,coverCondition,evalExpr,inv.index,inv.count,binaryValue]

theorem eval_cover_address {heap env count stop num den i lo r}
    (inv : CoverInv env count stop num den i lo) (read : heap[i]?=some r) :
    evalCoverExpr heap env (.unary "&" (.index (.var "rows") (.var "i")))=
      some (.pointer i) := by
  simp [evalCoverExpr,evalExpr,inv.rows,inv.index,read]

theorem CoverInv.bind_r {env count stop num den i lo}
    (inv : CoverInv env count stop num den i lo) (index : Nat) :
    CoverInv (bind env "r" (.pointer index)) count stop num den i lo := by
  rcases inv with ⟨hr,hc,hs,hn,hd,hi,hl⟩
  constructor <;> simp [bind,hr,hc,hs,hn,hd,hi,hl]

theorem CoverInv.bind_lo {env count stop num den i lo}
    (inv : CoverInv env count stop num den i lo) (next : Nat) :
    CoverInv (bind env "lo" (.word 64 next)) count stop num den i next := by
  rcases inv with ⟨hr,hc,hs,hn,hd,hi,hl⟩
  constructor <;> simp [bind,hr,hc,hs,hn,hd,hi,hl]

theorem CoverInv.bind_i {env count stop num den i lo}
    (inv : CoverInv env count stop num den i lo) (next : Nat) :
    CoverInv (bind env "i" (.word 64 next)) count stop num den next lo := by
  rcases inv with ⟨hr,hc,hs,hn,hd,hi,hl⟩
  constructor <;> simp [bind,hr,hc,hs,hn,hd,hi,hl]

theorem declare_cover_r {heap env count stop num den i lo r}
    (inv : CoverInv env count stop num den i lo) (read : heap[i]?=some r) :
    CoverDeclare heap [⟨"const Row*","r",some (.unary "&" (.index (.var "rows") (.var "i")))⟩]
      env (bind env "r" (.pointer i)) := by
  simp [CoverDeclare,declareCover,eval_cover_address inv read,castValue]

theorem row_widths {r : Row} {num den : Nat} (run : RowExec r num den) :
    r.lo<2^64 ∧ r.hi<2^64 ∧ r.hi+1<2^64 := by
  have gate := run.gate
  simp only [inputGate,decide_eq_true_eq] at gate
  have ha : (2:Nat)^40+1<2^64 := by norm_num
  exact ⟨by omega,by omega,by omega⟩

def coverReject : Expr :=
  .binary "||" (.binary "!=" (.field "->" (.var "r") "lo") (.var "lo"))
    (.unary "!" (.call (.var "row_check") [.var "r",.var "num",.var "den"]))
def coverNext : Expr := .binary "+" (.field "->" (.var "r") "hi") (.nat 1)

theorem eval_cover_reject {heap env count stop num den i lo r}
    (inv : CoverInv env count stop num den i lo) (ptr : env "r"=some (.pointer i))
    (read : heap[i]?=some r) (align : r.lo=lo) (run : RowExec r num den)
    (hnum : num<2^64) (hden : den<2^64) :
    evalCoverExpr heap env coverReject=some (boolean false) := by
  have hrow := Adaptive.C.row_ast heap r i 4 num den read run
  have hlo := (row_widths run).1
  simp only [word,Nat.mod_eq_of_lt hnum,Nat.mod_eq_of_lt hden] at hrow
  simp [evalCoverExpr,coverReject,evalExpr,ptr,inv.lo,inv.num,inv.den,
    read,Row.field,binaryValue,word,Nat.mod_eq_of_lt hlo,align,hrow,truth,boolean]
  all_goals omega

theorem eval_cover_next {heap env count stop num den i lo r}
    (inv : CoverInv env count stop num den i lo) (ptr : env "r"=some (.pointer i))
    (read : heap[i]?=some r) (run : RowExec r num den) :
    evalCoverExpr heap env coverNext=some (.word 64 (r.hi+1)) := by
  have hs := row_widths run
  simp [evalCoverExpr,coverNext,evalExpr,ptr,read,Row.field,binaryValue,word,
    Nat.mod_eq_of_lt hs.2.1,Nat.mod_eq_of_lt hs.2.2]
  all_goals omega

theorem cover_iteration_run {heap env count stop num den i lo r}
    (inv : CoverInv env count stop num den i lo) (read : heap[i]?=some r)
    (align : r.lo=lo) (run : RowExec r num den)
    (hnum : num<2^64) (hden : den<2^64) :
    ∃ nextEnv, CoverStmtRun heap coverIteration env (.continuing nextEnv) ∧
      CoverInv nextEnv count stop num den i (r.hi+1) := by
  let ptrEnv := bind env "r" (.pointer i)
  let nextEnv := bind ptrEnv "lo" (.word 64 (r.hi+1))
  have ptrInv : CoverInv ptrEnv count stop num den i lo := inv.bind_r i
  have ptr : ptrEnv "r"=some (.pointer i) := by simp [ptrEnv,bind]
  have reject := eval_cover_reject ptrInv ptr read align run hnum hden
  have next := eval_cover_next ptrInv ptr read run
  have hs := row_widths run
  have assignment : CoverEval heap (.binary "=" (.var "lo") coverNext)
      ptrEnv nextEnv (.word 64 (r.hi+1)) := by
    apply CoverEval.assign ptrInv.lo next
    simp [assignmentValue,word,Nat.mod_eq_of_lt hs.2.2]
    all_goals omega
  refine ⟨nextEnv,?_,ptrInv.bind_lo (r.hi+1)⟩
  change CoverStmtRun heap (.sequence [_,.branch coverReject _ _,
    .eval (.binary "=" (.var "lo") coverNext)]) env (.continuing nextEnv)
  apply ASTLoops.StmtRun.sequence
  · apply ASTLoops.SeqRun.next (ASTLoops.StmtRun.declare (declare_cover_r inv read))
    apply ASTLoops.SeqRun.next
    · apply ASTLoops.StmtRun.branch (CoverEval.pure reject)
      exact ASTLoops.StmtRun.skip ptrEnv
    · exact ASTLoops.SeqRun.next (ASTLoops.StmtRun.evaluate assignment)
        (ASTLoops.SeqRun.nil nextEnv)
  · rfl

/-- A certificate of the visited row calls and actual source alignment. This
is an input to the structural AST theorem, not a replacement execution model. -/
inductive CoverRows (num den : Nat) : List Row → Nat → Nat → Prop
  | nil (lo : Nat) : CoverRows num den [] lo lo
  | cons (r : Row) (rs : List Row) (lo finish : Nat)
      (align : r.lo=lo) (checked : RowExec r num den)
      (rest : CoverRows num den rs (r.hi+1) finish) :
      CoverRows num den (r::rs) lo finish

theorem CoverRows.finish_width {num den rs lo finish} (trace : CoverRows num den rs lo finish)
    (hlo : lo<2^64) : finish<2^64 := by
  induction trace with
  | nil => exact hlo
  | cons r rs lo finish align checked rest ih =>
    exact ih (row_widths checked).2.2

theorem cover_guard_true {heap env count stop num den i lo}
    (inv : CoverInv env count stop num den i lo) (guard : i<count) :
    ASTLoops.GuardRun (CoverEval heap) truth (some coverCondition) env env true := by
  have eq := eval_cover_condition (heap:=heap) inv
  have expr : CoverEval heap coverCondition env env (boolean true) :=
    CoverEval.pure (by simpa [guard] using eq)
  exact ASTLoops.GuardRun.present expr

theorem cover_guard_false {heap env count stop num den i lo}
    (inv : CoverInv env count stop num den i lo) (guard : ¬i<count) :
    ASTLoops.GuardRun (CoverEval heap) truth (some coverCondition) env env false := by
  have eq := eval_cover_condition (heap:=heap) inv
  have expr : CoverEval heap coverCondition env env (boolean false) :=
    CoverEval.pure (by simpa [guard] using eq)
  exact ASTLoops.GuardRun.present expr

theorem cover_for_run {heap : Heap} {num den lo finish : Nat} {rs : List Row}
    (trace : CoverRows num den rs lo finish)
    (hcount : heap.length<2^64) (hnum : num<2^64) (hden : den<2^64) :
    ∀ (prior : List Row) (env : Env), heap=prior++rs →
      CoverInv env heap.length stop num den prior.length lo →
      ∃ finalEnv, CoverForRun heap (some coverCondition) coverIncrement coverIteration
        env (.continuing finalEnv) ∧
        CoverInv finalEnv heap.length stop num den heap.length finish := by
  induction trace with
  | nil lo =>
    intro prior env he inv
    have hh : prior.length=heap.length := by simp [he]
    refine ⟨env,?_,?_⟩
    · exact ASTLoops.ForRun.done (cover_guard_false inv (by omega))
    · simpa only [hh] using inv
  | cons r rs lo finish align checked rest ih =>
    intro prior env he inv
    have read : heap[prior.length]?=some r := by simp [he]
    have guard : prior.length<heap.length := by simp [he]
    have hinc : prior.length+1<2^64 := by
      have hh : prior.length+1≤heap.length := by simp [he]
      omega
    obtain ⟨bodyEnv,bodyRun,bodyInv⟩ := cover_iteration_run inv read align checked hnum hden
    let nextEnv := bind bodyEnv "i" (.word 64 (prior.length+1))
    have inc : CoverEval heap coverIncrement bodyEnv nextEnv (.word 64 (prior.length+1)) := by
      simpa only [coverIncrement,word,Nat.mod_eq_of_lt hinc] using
        (CoverEval.increment (heap:=heap) bodyInv.index)
    have nextInv : CoverInv nextEnv heap.length stop num den (prior++[r]).length (r.hi+1) := by
      simpa [nextEnv] using bodyInv.bind_i (prior.length+1)
    obtain ⟨finalEnv,loop,finalInv⟩ := ih (prior++[r]) nextEnv
      (by simpa [List.append_assoc] using he) nextInv
    exact ⟨finalEnv,ASTLoops.ForRun.next (cover_guard_true inv guard) bodyRun inc loop,finalInv⟩

end LCMSourcePV.Adaptive.C
