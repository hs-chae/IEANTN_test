/- Restricted unsigned C23 semantics for the actual adaptive verifier.
   No compiler execution, external oracle, or numerical axiom is used. -/
import AdaptiveCAST
import LCMSourcePV.PrimeCover.Trial
namespace LCMSourcePV.Adaptive.C
open LCMSourcePV.Witness.C

inductive Value where
  | word (width value : Nat)
  | pointer (row : Nat)
  deriving Repr, DecidableEq

def word (width value : Nat) : Value := .word width (value % 2^width)
def boolean (b : Bool) : Value := .word 32 (if b then 1 else 0)
def truth : Value → Bool
  | .word _ n => n != 0
  | .pointer _ => true

def asNat : Value → Option Nat
  | .word _ n => some n
  | _ => none

def castValue (type : String) (v : Value) : Option Value := do
  if type == "const Row*" then
    match v with
    | .pointer _ => return v
    | _ => none
  else
    let n ← asNat v
    if type == "U" then return word 64 n
    else if type == "W" then return word 512 n
    else if type == "bool" then return .word 1 (if n == 0 then 0 else 1)
    else none

/-- All arithmetic in the verifier is unsigned, after the usual promotion
of its nonnegative small integer literals. The wider operand determines the
rank. Division/remainder and shifts reject C undefined cases explicitly. -/
def binaryValue (op : String) (a b : Value) : Option Value := do
  let .word wa x := a | none
  let .word wb y := b | none
  let width := max wa wb
  if op == "+" then return word width (x+y)
  else if op == "-" then return word width (x+2^width-y)
  else if op == "*" then return word width (x*y)
  else if op == "/" then if y == 0 then none else return word width (x/y)
  else if op == "%" then if y == 0 then none else return word width (x%y)
  else if op == "<<" then if y < wa then return word wa (x*2^y) else none
  else if op == ">>" then if y < wa then return word wa (x/2^y) else none
  else if op == "<" then return boolean (x<y)
  else if op == "<=" then return boolean (x≤y)
  else if op == ">" then return boolean (x>y)
  else if op == ">=" then return boolean (x≥y)
  else if op == "==" then return boolean (x==y)
  else if op == "!=" then return boolean (x != y)
  else none

/-- Nine represented uint64 fields, in exactly the source struct order. -/
structure Row where
  lo : Nat
  hi : Nat
  p0 : Nat
  p1 : Nat
  p2 : Nat
  q0 : Nat
  q1 : Nat
  q2 : Nat
  valuation : Nat
  deriving Repr, DecidableEq

def Row.field (r : Row) (f : String) : Option Value :=
  if f == "lo" then some (word 64 r.lo)
  else if f == "hi" then some (word 64 r.hi)
  else if f == "p0" then some (word 64 r.p0)
  else if f == "p1" then some (word 64 r.p1)
  else if f == "p2" then some (word 64 r.p2)
  else if f == "q0" then some (word 64 r.q0)
  else if f == "q1" then some (word 64 r.q1)
  else if f == "q2" then some (word 64 r.q2)
  else if f == "valuation" then some (word 64 r.valuation)
  else none

abbrev Env := String → Option Value
abbrev Heap := List Row
abbrev Call := String → List Value → Option Value

def emptyEnv : Env := fun _ => none
def bind (env : Env) (key : String) (v : Value) : Env :=
  fun k => if k == key then some v else env k

/-- Evaluation of real expression ASTs. Short circuit operators do not
execute their right operands when C would skip them. Array reads are bounded.
Calls are supplied by the modular function semantics below. -/
def evalExpr (call : Call) (heap : Heap) (env : Env) : Nat → Expr → Option Value
  | 0, _ => none
  | fuel+1, .nat n => some (word 32 n)
  | fuel+1, .var n =>
      if n == "true" then some (boolean true)
      else if n == "false" then some (boolean false)
      else env n
  | fuel+1, .unary "!" e => do return boolean (!(truth (←evalExpr call heap env fuel e)))
  | fuel+1, .cast t e => do castValue t (←evalExpr call heap env fuel e)
  | fuel+1, .binary "&&" a b => do
      let x ← evalExpr call heap env fuel a
      if truth x then return boolean (truth (←evalExpr call heap env fuel b))
      else return boolean false
  | fuel+1, .binary "||" a b => do
      let x ← evalExpr call heap env fuel a
      if truth x then return boolean true
      else return boolean (truth (←evalExpr call heap env fuel b))
  | fuel+1, .binary op a b => do
      binaryValue op (←evalExpr call heap env fuel a) (←evalExpr call heap env fuel b)
  | fuel+1, .field "->" obj name => do
      let .pointer index ← evalExpr call heap env fuel obj | none
      let r ← heap[index]?
      r.field name
  | fuel+1, .call (.var name) args => do
      call name (←args.mapM (evalExpr call heap env fuel))
  | _, _ => none

inductive Flow where
  | continuing (env : Env)
  | returned (value : Value)

/-- The loop-free source functions use ordinary block sequencing, initialized
declarations, conditional branches and returns. Unsupported syntax rejects.
Local storage is internal; only a return value is observable by the caller. -/
def execStmt (call : Call) (heap : Heap) : Nat → Env → Stmt → Option Flow
  | 0, _, _ => none
  | fuel+1, env, .skip => some (.continuing env)
  | fuel+1, env, .eval _ => none
  | fuel+1, env, .returnStmt e => do
      return .returned (←evalExpr call heap env 100 e)
  | fuel+1, env, .declare decls => do
      let next ← decls.foldlM (fun state d => do
        let init ← d.value
        let v ← evalExpr call heap state 100 init
        let represented ← castValue d.type v
        return bind state d.name represented) env
      return .continuing next
  | fuel+1, env, .branch e yes no => do
      let v ← evalExpr call heap env 100 e
      execStmt call heap fuel env (if truth v then yes else no)
  | fuel+1, env, .sequence body => do
      body.foldlM (fun status s => do
        match status with
        | .returned v => return .returned v
        | .continuing state => execStmt call heap fuel state s) (.continuing env)
  | _, _, _ => none

/-- Parameter declarations cast values before function-body execution. -/
def bindArgs (ps : List (String × String)) (args : List Value) : Option Env := do
  if ps.length != args.length then none else
  (ps.zip args).foldlM (fun env item => do
    let v ← castValue item.1.1 item.2
    return bind env item.1.2 v) emptyEnv

/-- Modular semantics: `pc_is_prime` is the proved terminating C trial loop,
represented by its unique result. All other calls interpret their actual AST.
The separate refinement theorem below establishes the trial-loop execution;
there is no unproved oracle premise. -/
def execFunction (heap : Heap) : Nat → Call
  | 0, _, _ => none
  | fuel+1, name, args =>
    if name == "pc_is_prime" then
      match args with
      | [.word 64 n] =>
          if n < 2^64 then some (word 64 (if Nat.Prime n then 1 else 0)) else none
      | _ => none
    else do
      let f ← functions.find? (fun f => f.name == name)
      let env ← bindArgs f.parameters args
      let .returned v ← execStmt (execFunction heap fuel) heap 100 env f.body | none
      castValue f.returnType v

/-- The modular prime service always has an execution of the actual C loop.
Primality certificates may shorten this proof; they do not replace the loop
with an axiom or alter its operational meaning. -/
theorem prime_service_execution (n : Nat) (hn : n < 2^64) :
    LCMSourcePV.PrimeCover.PrimeExec n (if Nat.Prime n then 1 else 0) := by
  split_ifs with hp
  · exact LCMSourcePV.PrimeCover.prime_exec_of_prime hn hp
  · exact LCMSourcePV.PrimeCover.prime_exec_of_not_prime hn hp

#print axioms prime_service_execution
end LCMSourcePV.Adaptive.C
