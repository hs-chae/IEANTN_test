import AdaptiveWords
import AdaptiveLookup

namespace LCMSourcePV.Adaptive.C
open LCMSourcePV.PrimeCover LCMSourcePV.RestrictedC
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option exponentiation.threshold 1024

theorem product_p_ast (heap : Heap) (r : Row) (index fuel : Nat)
    (read : heap[index]?=some r)
    (p0 : r.p0<2^64) (p1 : r.p1<2^64) (p2 : r.p2<2^64) :
    execFunction heap (fuel+1) "product_p" [.pointer index] =
      some (word 512 (productP r)) := by
  have h0 : r.p0 % 18446744073709551616 = r.p0 := Nat.mod_eq_of_lt p0
  have h1 : r.p1 % 18446744073709551616 = r.p1 := Nat.mod_eq_of_lt p1
  have h2 : r.p2 % 18446744073709551616 = r.p2 := Nat.mod_eq_of_lt p2
  simp [execFunction,lookup_product_p,f_product_p,bindArgs,List.foldlM,
    castValue,evalExpr,execStmt,List.mapM_cons,List.mapM_nil,
    bind,emptyEnv,binaryValue,asNat,Row.field,read,word,productP,wmul,wcast,
    Unsigned.mul,Unsigned.repr,Unsigned.modulus,h0,h1,h2]

theorem product_q_ast (heap : Heap) (r : Row) (index fuel : Nat)
    (read : heap[index]?=some r)
    (q0 : r.q0<2^64) (q1 : r.q1<2^64) (q2 : r.q2<2^64) :
    execFunction heap (fuel+1) "product_q" [.pointer index] =
      some (word 512 (productQ r)) := by
  have h0 : r.q0 % 18446744073709551616 = r.q0 := Nat.mod_eq_of_lt q0
  have h1 : r.q1 % 18446744073709551616 = r.q1 := Nat.mod_eq_of_lt q1
  have h2 : r.q2 % 18446744073709551616 = r.q2 := Nat.mod_eq_of_lt q2
  simp [execFunction,lookup_product_q,f_product_q,bindArgs,List.foldlM,
    castValue,evalExpr,execStmt,List.mapM_cons,List.mapM_nil,
    bind,emptyEnv,binaryValue,asNat,Row.field,read,word,productQ,wmul,wcast,
    Unsigned.mul,Unsigned.repr,Unsigned.modulus,h0,h1,h2]

structure WordRow (r : Row) : Prop where
  lo : r.lo<2^64
  hi : r.hi<2^64
  p0 : r.p0<2^64
  p1 : r.p1<2^64
  p2 : r.p2<2^64
  q0 : r.q0<2^64
  q1 : r.q1<2^64
  q2 : r.q2<2^64
  valuation : r.valuation<2^64

theorem inputGate_words {r : Row} {num den : Nat} (h : inputGate r num den=true) :
    WordRow r ∧ num<2^64 ∧ den<2^64 := by
  simp only [inputGate,decide_eq_true_eq] at h
  norm_num at h ⊢
  refine ⟨⟨?_,?_,?_,?_,?_,?_,?_,?_,?_⟩,?_,?_⟩ <;> omega

theorem endpoint_ast (heap : Heap) (r : Row) (index fuel n num den : Nat)
    (read : heap[index]?=some r) (w : WordRow r)
    (wn : n<2^64) (wnum : num<2^64) (wden : den<2^64) (result : Bool)
    (valid : endpointWord r n num den=some result) :
    execFunction heap (fuel+2) "endpoint" [.pointer index,word 64 n,word 64 num,word 64 den] =
      some (.word 1 (if result then 1 else 0)) := by
  have hlo : r.lo%18446744073709551616=r.lo := Nat.mod_eq_of_lt w.lo
  have hhi : r.hi%18446744073709551616=r.hi := Nat.mod_eq_of_lt w.hi
  have hp0 : r.p0%18446744073709551616=r.p0 := Nat.mod_eq_of_lt w.p0
  have hp1 : r.p1%18446744073709551616=r.p1 := Nat.mod_eq_of_lt w.p1
  have hp2 : r.p2%18446744073709551616=r.p2 := Nat.mod_eq_of_lt w.p2
  have hq0 : r.q0%18446744073709551616=r.q0 := Nat.mod_eq_of_lt w.q0
  have hq1 : r.q1%18446744073709551616=r.q1 := Nat.mod_eq_of_lt w.q1
  have hq2 : r.q2%18446744073709551616=r.q2 := Nat.mod_eq_of_lt w.q2
  have hv : r.valuation%18446744073709551616=r.valuation := Nat.mod_eq_of_lt w.valuation
  have hn : n%18446744073709551616=n := Nat.mod_eq_of_lt wn
  have hnum : num%18446744073709551616=num := Nat.mod_eq_of_lt wnum
  have hden : den%18446744073709551616=den := Nat.mod_eq_of_lt wden
  have four_nonzero : wmul 4 (productP r)≠0 := by
    intro hz
    simp [endpointWord,Unsigned.div,hz] at valid
  have scale_valid : uadd r.valuation 3<512 := by
    by_contra hn
    simp [endpointWord,Unsigned.div,four_nonzero,shiftW,hn] at valid
  have half_valid : uadd r.valuation 2<512 := by
    by_contra hn
    simp [endpointWord,Unsigned.div,four_nonzero,shiftW,scale_valid,hn] at valid
  have scale_mod := Nat.mod_eq_of_lt (Nat.pow_lt_pow_right (by decide : 1<2) scale_valid)
  have half_mod := Nat.mod_eq_of_lt (Nat.pow_lt_pow_right (by decide : 1<2) half_valid)
  simp only [uadd,Unsigned.add,Unsigned.repr,Unsigned.modulus] at scale_mod half_mod
  norm_num only [Nat.reducePow] at scale_mod half_mod
  have qword : productQ r / wmul 4 (productP r)<2^512 := by
    apply lt_of_le_of_lt (Nat.div_le_self _ _)
    exact Nat.mod_lt _ (by decide)
  have qmod := Nat.mod_eq_of_lt qword
  simp only [productQ,productP,wmul,wcast,uadd,Unsigned.mul,Unsigned.add,
    Unsigned.repr,Unsigned.modulus] at four_nonzero scale_valid half_valid qmod
  norm_num at four_nonzero scale_valid half_valid qmod
  rw [execFunction]
  simp (config := {maxSteps := 200000}) [lookup_endpoint,f_endpoint,bindArgs,List.foldlM,
    castValue,evalExpr,execStmt,List.mapM_cons,List.mapM_nil,
    bind,emptyEnv,binaryValue,asNat,Row.field,read,truth,boolean,
    product_p_ast heap r index fuel read w.p0 w.p1 w.p2,
    product_q_ast heap r index fuel read w.q0 w.q1 w.q2,
    word,endpointWord,shiftW,productP,productQ,sourceA,sourceB,sourceD,
    wmul,wadd,wcast,uadd,Unsigned.mul,Unsigned.add,Unsigned.repr,Unsigned.modulus,
    Unsigned.div,hlo,hhi,hp0,hp1,hp2,hq0,hq1,hq2,hv,hn,hnum,hden,
    four_nonzero,scale_valid,half_valid,scale_mod,half_mod,qmod] at valid ⊢
  cases result <;> simp_all
  all_goals try (intro impossibleWord impossibleArgs; have := congrArg List.length impossibleArgs; simp at this)

theorem prime_ast (heap : Heap) (fuel n : Nat) (run : PrimeExec n 1) :
    execFunction heap (fuel+1) "pc_is_prime" [.word 64 n]=some (.word 64 1) := by
  have hp : Nat.Prime n := (prime_exec_correct run).2.mp rfl
  have hn : n<2^64 := run.1
  norm_num at hn
  simp [execFunction,hn,hp,word]

theorem productTest_conditions {r : Row} (h : productTest r=some true) :
    wmul 4 (productP r)<productQ r ∧ wmul 4 (productP r)≠0 ∧
    r.valuation<512 ∧
    (productQ r / wmul 4 (productP r)) % wcast (2^r.valuation)=0 := by
  have hlt : wmul 4 (productP r)<productQ r := by
    by_contra hn
    simp [productTest,hn] at h
  have hn : wmul 4 (productP r)≠0 := by
    intro hz
    simp [productTest,hlt,Unsigned.div,hz] at h
  have hv : r.valuation<512 := by
    by_contra hn'
    simp [productTest,hlt,Unsigned.div,hn,shiftW,hn'] at h
  have hpow : wcast (2^r.valuation)≠0 := by
    have hh : 2^r.valuation<2^512 := Nat.pow_lt_pow_right (by decide) hv
    change 2^r.valuation % 2^512≠0
    rw [Nat.mod_eq_of_lt hh]
    exact Nat.ne_of_gt (Nat.pow_pos (by decide))
  refine ⟨hlt,hn,hv,?_⟩
  simpa [productTest,hlt,Unsigned.div,hn,shiftW,hv,Unsigned.rem,hpow] using h

theorem row_ast (heap : Heap) (r : Row) (index fuel num den : Nat)
    (read : heap[index]?=some r) (run : RowExec r num den) :
    execFunction heap (fuel+4) "row_check" [.pointer index,word 64 num,word 64 den] =
      some (.word 1 1) := by
  obtain ⟨w,wnum,wden⟩ := inputGate_words run.gate
  have gate := run.gate
  simp only [inputGate,decide_eq_true_eq] at gate
  norm_num at gate
  rcases gate with ⟨numle,denpos,denle,vlt,lolt,hilt,p0lt,p1lt,p2lt,q0lt,q1lt,q2lt⟩
  have pre := run.pre
  simp only [precheck,decide_eq_true_eq,Unsigned.mul,Unsigned.repr,Unsigned.modulus] at pre
  norm_num at pre
  rcases pre with ⟨lopos,lohi,hip,pq,ql,p01,p12,q01,q12⟩
  have den_ne : den≠0 := Nat.ne_of_gt denpos
  have vshift : r.valuation<512 := by omega
  have power_word : 2^r.valuation%2^512=2^r.valuation :=
    Nat.mod_eq_of_lt (Nat.pow_lt_pow_right (by decide) vshift)
  have power_ne : 2^r.valuation≠0 := Nat.ne_of_gt (Nat.pow_pos (by decide))
  norm_num only [Nat.reducePow] at power_word
  obtain ⟨prodlt,prodne,vsmall,remzero⟩ := productTest_conditions run.product
  have hlo : r.lo%18446744073709551616=r.lo := Nat.mod_eq_of_lt w.lo
  have hhi : r.hi%18446744073709551616=r.hi := Nat.mod_eq_of_lt w.hi
  have hp0 : r.p0%18446744073709551616=r.p0 := Nat.mod_eq_of_lt w.p0
  have hp1 : r.p1%18446744073709551616=r.p1 := Nat.mod_eq_of_lt w.p1
  have hp2 : r.p2%18446744073709551616=r.p2 := Nat.mod_eq_of_lt w.p2
  have hq0 : r.q0%18446744073709551616=r.q0 := Nat.mod_eq_of_lt w.q0
  have hq1 : r.q1%18446744073709551616=r.q1 := Nat.mod_eq_of_lt w.q1
  have hq2 : r.q2%18446744073709551616=r.q2 := Nat.mod_eq_of_lt w.q2
  have hv : r.valuation%18446744073709551616=r.valuation := Nat.mod_eq_of_lt w.valuation
  have hnum : num%18446744073709551616=num := Nat.mod_eq_of_lt wnum
  have hden : den%18446744073709551616=den := Nat.mod_eq_of_lt wden
  have lowerCall : execFunction heap (fuel+3) "endpoint"
      [.pointer index,.word 64 r.lo,.word 64 num,.word 64 den]=some (.word 1 1) := by
    simpa [word,hlo,hnum,hden,Nat.add_assoc] using
      endpoint_ast heap r index (fuel+1) r.lo num den read w w.lo wnum wden true run.lower
  have upperCall : execFunction heap (fuel+3) "endpoint"
      [.pointer index,.word 64 r.hi,.word 64 num,.word 64 den]=some (.word 1 1) := by
    simpa [word,hhi,hnum,hden,Nat.add_assoc] using
      endpoint_ast heap r index (fuel+1) r.hi num den read w w.hi wnum wden true run.upper
  have qword : productQ r / wmul 4 (productP r)<2^512 := by
    apply lt_of_le_of_lt (Nat.div_le_self _ _)
    exact Nat.mod_lt _ (by decide)
  have qmod := Nat.mod_eq_of_lt qword
  have quotient_mod :
      (r.q0*r.q1*r.q2%2^512 / (4*(r.p0*r.p1*r.p2)%2^512))%2^512 =
        r.q0*r.q1*r.q2%2^512 / (4*(r.p0*r.p1*r.p2)%2^512) := by
    apply Nat.mod_eq_of_lt
    simpa [productQ,productP,wmul,wcast,Unsigned.mul,Unsigned.repr,Unsigned.modulus] using qword
  have remainder_zero :
      (r.q0*r.q1*r.q2%2^512 / (4*(r.p0*r.p1*r.p2)%2^512))%2^r.valuation=0 := by
    simpa [productQ,productP,wmul,wcast,Unsigned.mul,Unsigned.repr,Unsigned.modulus,power_word] using remzero
  norm_num only [Nat.reducePow] at quotient_mod remainder_zero
  simp only [productQ,productP,wmul,wcast,Unsigned.mul,Unsigned.repr,Unsigned.modulus]
    at prodlt prodne remzero qmod
  norm_num at prodlt prodne remzero
  norm_num only [Nat.reducePow] at qmod
  simp only [power_word] at remzero
  rw [execFunction]
  simp (config := {maxSteps := 400000}) [lookup_row_check,f_row_check,bindArgs,List.foldlM,
    castValue,evalExpr,execStmt,List.mapM_cons,List.mapM_nil,
    bind,emptyEnv,binaryValue,asNat,Row.field,read,truth,boolean,
    product_p_ast heap r index (fuel+2) read w.p0 w.p1 w.p2,
    product_q_ast heap r index (fuel+2) read w.q0 w.q1 w.q2,
    prime_ast heap (fuel+2) r.p0 run.p0,prime_ast heap (fuel+2) r.p1 run.p1,
    prime_ast heap (fuel+2) r.p2 run.p2,prime_ast heap (fuel+2) r.q0 run.q0,
    prime_ast heap (fuel+2) r.q1 run.q1,prime_ast heap (fuel+2) r.q2 run.q2,
    lowerCall,upperCall,
    word,productP,productQ,wmul,wcast,Unsigned.mul,Unsigned.repr,Unsigned.modulus,
    hlo,hhi,hp0,hp1,hp2,hq0,hq1,hq2,hv,hnum,hden,
    numle,denpos,denle,den_ne,vlt,lolt,hilt,p0lt,p1lt,p2lt,q0lt,q1lt,q2lt,
    not_lt.mpr numle,not_lt.mpr denle,not_le.mpr vlt,
    not_le.mpr lolt,not_le.mpr hilt,not_le.mpr p0lt,not_le.mpr p1lt,not_le.mpr p2lt,
    not_le.mpr q0lt,not_le.mpr q1lt,not_le.mpr q2lt,
    lopos,lohi,hip,pq,ql,p01,p12,q01,q12,prodlt,prodne,vsmall,remzero,qmod,quotient_mod,remainder_zero,power_word,power_ne]
  all_goals try (intro impossibleWord impossibleArgs; have := congrArg List.length impossibleArgs; simp at this)

#print axioms row_ast

#print axioms endpoint_ast
#print axioms product_p_ast
end LCMSourcePV.Adaptive.C
