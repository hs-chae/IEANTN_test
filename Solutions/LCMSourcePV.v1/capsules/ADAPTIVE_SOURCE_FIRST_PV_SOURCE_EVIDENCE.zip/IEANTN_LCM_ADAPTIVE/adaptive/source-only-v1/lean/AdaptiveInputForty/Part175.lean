import AdaptiveInputSource
import AdaptiveRowsForty.Part175
namespace LCMSourcePV.Adaptive.InputForty.Part175
open LCMSourcePV.Adaptive.C
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def leaf00 : InputTree := .leaf "r_175_00.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row00 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_00.inc")
theorem checked_leaf00 : leaf00.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run00.gate⟩
def leaf01 : InputTree := .leaf "r_175_01.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row01 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_01.inc")
theorem checked_leaf01 : leaf01.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run01.gate⟩
def leaf02 : InputTree := .leaf "r_175_02.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row02 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_02.inc")
theorem checked_leaf02 : leaf02.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run02.gate⟩
def leaf03 : InputTree := .leaf "r_175_03.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row03 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_03.inc")
theorem checked_leaf03 : leaf03.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run03.gate⟩
def leaf04 : InputTree := .leaf "r_175_04.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row04 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_04.inc")
theorem checked_leaf04 : leaf04.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run04.gate⟩
def leaf05 : InputTree := .leaf "r_175_05.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row05 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_05.inc")
theorem checked_leaf05 : leaf05.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run05.gate⟩
def leaf06 : InputTree := .leaf "r_175_06.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row06 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_06.inc")
theorem checked_leaf06 : leaf06.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run06.gate⟩
def leaf07 : InputTree := .leaf "r_175_07.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row07 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_07.inc")
theorem checked_leaf07 : leaf07.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run07.gate⟩
def leaf08 : InputTree := .leaf "r_175_08.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row08 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_08.inc")
theorem checked_leaf08 : leaf08.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run08.gate⟩
def leaf09 : InputTree := .leaf "r_175_09.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row09 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_09.inc")
theorem checked_leaf09 : leaf09.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run09.gate⟩
def leaf10 : InputTree := .leaf "r_175_10.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row10 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_10.inc")
theorem checked_leaf10 : leaf10.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run10.gate⟩
def leaf11 : InputTree := .leaf "r_175_11.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row11 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_11.inc")
theorem checked_leaf11 : leaf11.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run11.gate⟩
def leaf12 : InputTree := .leaf "r_175_12.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row12 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_12.inc")
theorem checked_leaf12 : leaf12.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run12.gate⟩
def leaf13 : InputTree := .leaf "r_175_13.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row13 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_13.inc")
theorem checked_leaf13 : leaf13.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run13.gate⟩
def leaf14 : InputTree := .leaf "r_175_14.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row14 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_14.inc")
theorem checked_leaf14 : leaf14.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run14.gate⟩
def leaf15 : InputTree := .leaf "r_175_15.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row15 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_15.inc")
theorem checked_leaf15 : leaf15.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run15.gate⟩
def leaf16 : InputTree := .leaf "r_175_16.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row16 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_16.inc")
theorem checked_leaf16 : leaf16.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run16.gate⟩
def leaf17 : InputTree := .leaf "r_175_17.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row17 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_17.inc")
theorem checked_leaf17 : leaf17.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run17.gate⟩
def leaf18 : InputTree := .leaf "r_175_18.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row18 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_18.inc")
theorem checked_leaf18 : leaf18.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run18.gate⟩
def leaf19 : InputTree := .leaf "r_175_19.inc" LCMSourcePV.Adaptive.RowsForty.Part175.row19 (include_str ".."/".."/"source"/"cases"/"Forty"/"r_175_19.inc")
theorem checked_leaf19 : leaf19.Checked := ⟨by decide,represented_of_gate LCMSourcePV.Adaptive.RowsForty.Part175.run19.gate⟩
def node000 : InputTree := .join "n_175_000.inc" leaf00 leaf01 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_000.inc")
theorem checked_node000 : node000.Checked := ⟨by decide,checked_leaf00,checked_leaf01⟩
def node001 : InputTree := .join "n_175_001.inc" leaf02 leaf03 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_001.inc")
theorem checked_node001 : node001.Checked := ⟨by decide,checked_leaf02,checked_leaf03⟩
def node002 : InputTree := .join "n_175_002.inc" leaf04 leaf05 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_002.inc")
theorem checked_node002 : node002.Checked := ⟨by decide,checked_leaf04,checked_leaf05⟩
def node003 : InputTree := .join "n_175_003.inc" leaf06 leaf07 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_003.inc")
theorem checked_node003 : node003.Checked := ⟨by decide,checked_leaf06,checked_leaf07⟩
def node004 : InputTree := .join "n_175_004.inc" leaf08 leaf09 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_004.inc")
theorem checked_node004 : node004.Checked := ⟨by decide,checked_leaf08,checked_leaf09⟩
def node005 : InputTree := .join "n_175_005.inc" leaf10 leaf11 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_005.inc")
theorem checked_node005 : node005.Checked := ⟨by decide,checked_leaf10,checked_leaf11⟩
def node006 : InputTree := .join "n_175_006.inc" leaf12 leaf13 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_006.inc")
theorem checked_node006 : node006.Checked := ⟨by decide,checked_leaf12,checked_leaf13⟩
def node007 : InputTree := .join "n_175_007.inc" leaf14 leaf15 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_007.inc")
theorem checked_node007 : node007.Checked := ⟨by decide,checked_leaf14,checked_leaf15⟩
def node008 : InputTree := .join "n_175_008.inc" leaf16 leaf17 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_008.inc")
theorem checked_node008 : node008.Checked := ⟨by decide,checked_leaf16,checked_leaf17⟩
def node009 : InputTree := .join "n_175_009.inc" leaf18 leaf19 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_009.inc")
theorem checked_node009 : node009.Checked := ⟨by decide,checked_leaf18,checked_leaf19⟩
def node010 : InputTree := .join "n_175_010.inc" node000 node001 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_010.inc")
theorem checked_node010 : node010.Checked := ⟨by decide,checked_node000,checked_node001⟩
def node011 : InputTree := .join "n_175_011.inc" node002 node003 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_011.inc")
theorem checked_node011 : node011.Checked := ⟨by decide,checked_node002,checked_node003⟩
def node012 : InputTree := .join "n_175_012.inc" node004 node005 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_012.inc")
theorem checked_node012 : node012.Checked := ⟨by decide,checked_node004,checked_node005⟩
def node013 : InputTree := .join "n_175_013.inc" node006 node007 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_013.inc")
theorem checked_node013 : node013.Checked := ⟨by decide,checked_node006,checked_node007⟩
def node014 : InputTree := .join "n_175_014.inc" node008 node009 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_014.inc")
theorem checked_node014 : node014.Checked := ⟨by decide,checked_node008,checked_node009⟩
def node015 : InputTree := .join "n_175_015.inc" node010 node011 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_015.inc")
theorem checked_node015 : node015.Checked := ⟨by decide,checked_node010,checked_node011⟩
def node016 : InputTree := .join "n_175_016.inc" node012 node013 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_016.inc")
theorem checked_node016 : node016.Checked := ⟨by decide,checked_node012,checked_node013⟩
def node017 : InputTree := .join "n_175_017.inc" node015 node016 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_017.inc")
theorem checked_node017 : node017.Checked := ⟨by decide,checked_node015,checked_node016⟩
def node018 : InputTree := .join "n_175_018.inc" node017 node014 (include_str ".."/".."/"source"/"cases"/"Forty"/"n_175_018.inc")
theorem checked_node018 : node018.Checked := ⟨by decide,checked_node017,checked_node014⟩
def tree := node018
theorem checked_tree : tree.Checked := checked_node018
theorem values_tree : tree.values = LCMSourcePV.Adaptive.RowsForty.Part175.rows := rfl
#print axioms checked_tree
end LCMSourcePV.Adaptive.InputForty.Part175
