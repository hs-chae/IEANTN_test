import AdaptiveSourceFiles
namespace LCMSourcePV.Adaptive.C
open LCMSourcePV.Witness.C
set_option maxHeartbeats 0
set_option maxRecDepth 200000

inductive TypeDecl where
  | uint64Alias (name : String)
  | unsignedBitIntAlias (width : Nat) (name : String)
  | record (name fieldType : String) (fields : List String)

def types : List TypeDecl := [
  .uint64Alias "U", .unsignedBitIntAlias 512 "W",
  .record "Row" "U" ["lo","hi","p0","p1","p2","q0","q1","q2","valuation"]]

def renderType : TypeDecl → String
  | .uint64Alias name => "typedef uint64_t "++name++";\n"
  | .unsignedBitIntAlias width name => "typedef unsigned _BitInt("++toString width++") "++name++";\n"
  | .record name type fields => "typedef struct { "++type++" "++String.intercalate "," fields++"; } "++name++";\n"

def renderPrototype (f : Function) : String :=
  f.returnType++" "++f.name++"("++String.intercalate "," (f.parameters.map fun (t,n)=>t++" "++n)++");\n"

def renderHeader : String :=
  "#ifndef IEANTN_ADAPTIVE_API_H\n#define IEANTN_ADAPTIVE_API_H\n#include <stdint.h>\n#include <stdbool.h>\n"++
  String.join (types.map renderType) ++ String.join (functions.map renderPrototype) ++ "#endif\n"

theorem actual_typed_header : renderHeader =
    (include_str ".."/"source"/"parts"/"adaptive_api.h") := by decide

def aliasWidth (name : String) : Option Nat :=
  types.findSome? fun t => match t with
    | .uint64Alias n => if n=name then some 64 else none
    | .unsignedBitIntAlias width n => if n=name then some width else none
    | _ => none

theorem actual_U_width : aliasWidth "U" = some 64 := rfl
theorem actual_W_width : aliasWidth "W" = some 512 := rfl

def recordFields : List String :=
  ["lo","hi","p0","p1","p2","q0","q1","q2","valuation"]
theorem actual_Row_field_order : types = [
    .uint64Alias "U",.unsignedBitIntAlias 512 "W",.record "Row" "U" recordFields] := rfl

#print axioms actual_typed_header
end LCMSourcePV.Adaptive.C
