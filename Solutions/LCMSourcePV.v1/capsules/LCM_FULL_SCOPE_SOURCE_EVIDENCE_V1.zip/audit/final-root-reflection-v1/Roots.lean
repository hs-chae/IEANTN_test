import E1Tertiary.LcmAnalytic
import E1Tertiary.LcmFinal
import E1Tertiary.LcmResult
import E1Tertiary.LcmSurplus
import E1TwoTracks.Frontier
import E1TwoTracks.TrackACompare
import E1TwoTracks.TrackAFinal
import E1TwoTracks.TrackAHighBaseline
import E1TwoTracks.TrackAHighFinal
import E1TwoTracks.TrackAHighHistorical
import E1TwoTracks.TrackAHighSurplus
import E1TwoTracks.TrackASurplus
import E1TwoTracks.TrackBAdaptive
import E1TwoTracks.TrackBBlocks
import E1TwoTracks.TrackBExactCheck
import E1TwoTracks.TrackBExactProgram
import E1TwoTracks.TrackBInstance
import E1TwoTracks.TrackBParityCheck
import E1TwoTracks.TrackBParityProgram
import E1TwoTracks.TrackBProgram
import E1TwoTracks.TrackN
import E1TwoTracks.TrackNFixed
import E1TwoTracks.TrackNFixedHigh
import E1TwoTracks.TrackNHistorical
import E1TwoTracks.TrackNPower
import ExposureEvolution.Adaptive
import ExposureEvolution.Adaptive40
import ExposureEvolution.Adaptive40Data
import ExposureEvolution.Adaptive45
import ExposureEvolution.Adaptive45Data
import ExposureEvolution.AdaptiveData
import ExposureEvolution.Compact40FinalV1
import ExposureEvolution.CompactCoverage40
import ExposureEvolution.DirectOldJoinDataV1
import ExposureEvolution.DirectOldJoinFinalV1
import ExposureEvolution.Dual60CheckerV1
import ExposureEvolution.Dual60FinalV1
import ExposureEvolution.Dual60FunctionalControlsV1
import ExposureEvolution.Dual60TailV1
import ExposureEvolution.DualKernelCoverage60
import ExposureEvolution.Final
import ExposureEvolution.Final40
import ExposureEvolution.Final45
import ExposureEvolution.GraphKernelSolutionsV1
import ExposureEvolution.KernelBlockCoverage
import ExposureEvolution.KernelFinal
import ExposureEvolution.KernelSharpSurplus
import ExposureEvolution.SharpSurplus
import ExposureEvolution.Strong45
import ExposureEvolution.StrongKernelCoverage40
import ExposureEvolution.StrongKernelCoverage45
import ExposureEvolution.StrongKernelFinal40
import ExposureEvolution.StrongKernelFinal45
import ExposureEvolution.StrongOldGap40V1
import IEANTN.Bridges.DualEvolutionSupport.ExposureEvolution.Dual60TailV1
import IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.Dual60TailV1
import IEANTN.Bridges.DualEvolutionV1.LCM
import IEANTN.Bridges.DualEvolutionV2.LCM
import IEANTN.Bridges.StrongEvolutionSupport.ExposureEvolution.Strong45
import IEANTN.Bridges.StrongEvolutionV1.LCM
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxRecDepth 200000
set_option maxHeartbeats 0
run_elab do
  let env ← getEnv
  let roots : List Name := [``E1TwoTracks.TrackAHighFinal.quantitative,``ExposureEvolution.Adaptive40.Witness.sound,``E1TwoTracks.TrackB.quantitative,``E1TwoTracks.TrackNHistorical.quantitative_low,``ExposureEvolution.DirectOldJoinFinalV1.tail,``E1TwoTracks.TrackB.Block.exactSound,``ExposureEvolution.KernelFinal.tail,``ExposureEvolution.Dual60CheckerV1.coverage_sound,``ExposureEvolution.AdaptiveData.finite,``ExposureEvolution.KernelFinal.whole_ray,``ExposureEvolution.KernelBlockCoverage.finite,``ExposureEvolution.SharpSurplus.quantitative_of_gap,``E1TwoTracks.TrackB.exactFinite,``E1TwoTracks.Frontier.frozen_supplied,``ExposureEvolution.GraphKernelSolutionsV1.tail_surplus,``IEANTN.Bridges.DualEvolutionV1.whole60,``E1TwoTracks.TrackB.parityFinite,``ExposureEvolution.Compact40FinalV1.tail,``E1TwoTracks.TrackNHistorical.quantitative,``E1TwoTracks.TrackNFixedHigh.quantitative,``IEANTN.Bridges.DualEvolutionV2.tail60,``ExposureEvolution.Adaptive40Data.finite,``IEANTN.Bridges.StrongEvolutionV1.whole45,``E1TwoTracks.TrackB.Block.paritySound,``E1TwoTracks.TrackNFixed.quantitative,``E1Tertiary.LcmFinal.quantitative,``E1TwoTracks.Frontier.supplied,``ExposureEvolution.DualKernelCoverage60.finite,``ExposureEvolution.Adaptive40.coverage_sound,``E1TwoTracks.TrackASurplus.quantitative_of_gap,``ExposureEvolution.Dual60FunctionalControlsV1.tail_only,``ExposureEvolution.Dual60TailV1.quantitative_of_gap,``ExposureEvolution.Dual60FinalV1.tail,``ExposureEvolution.StrongKernelFinal45.tail,``E1TwoTracks.TrackB.exactSound,``E1TwoTracks.TrackNPower.quantitative_low,``IEANTN.Bridges.StrongEvolutionV1.tail45,``ExposureEvolution.Final40.whole_ray,``ExposureEvolution.StrongKernelFinal40.whole_ray,``E1Tertiary.LcmAnalytic.quantitative,``E1TwoTracks.TrackB.adaptiveFinite,``ExposureEvolution.StrongKernelCoverage40.finite,``E1TwoTracks.TrackAHighBaseline.quantitative,``E1Tertiary.LcmSurplus.historical_quantitative,``ExposureEvolution.Final.whole_ray,``E1Tertiary.LcmSurplus.quantitative_of_gap,``ExposureEvolution.StrongKernelCoverage45.finite,``E1Tertiary.LcmResult.not_highly_abundant,``ExposureEvolution.CompactCoverage40.finite,``E1TwoTracks.TrackAHighHistorical.quantitative,``IEANTN.Bridges.StrongEvolutionV1.whole40,``ExposureEvolution.StrongKernelFinal45.whole_ray,``ExposureEvolution.StrongKernelFinal40.tail,``ExposureEvolution.Adaptive.Witness.sound,``E1TwoTracks.TrackB.parityQuantitative,``E1TwoTracks.TrackB.Block.sound,``ExposureEvolution.Dual60FunctionalControlsV1.finite_only,``ExposureEvolution.Adaptive45.coverage_sound,``E1TwoTracks.TrackB.paritySound,``ExposureEvolution.Final40.tail,``IEANTN.Bridges.DualEvolutionV1.tail60,``IEANTN.Bridges.DualEvolutionV2.whole60,``E1TwoTracks.TrackAFinal.quantitative,``IEANTN.Bridges.DualEvolutionSupport.ExposureEvolution.Dual60TailV1.quantitative_of_gap,``E1TwoTracks.TrackB.sound,``ExposureEvolution.GraphKernelSolutionsV1.whole_ray,``E1TwoTracks.TrackB.adaptiveQuantitative,``E1TwoTracks.TrackB.finite_surplus,``ExposureEvolution.Strong45.quantitative_of_gap,``IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.Dual60TailV1.quantitative_of_gap,``E1TwoTracks.TrackNPower.quantitative_high,``ExposureEvolution.DirectOldJoinFinalV1.whole_ray,``E1TwoTracks.TrackAHighSurplus.quantitative_of_gap,``ExposureEvolution.StrongOldGap40V1.quantitative_of_gap,``IEANTN.Bridges.StrongEvolutionSupport.ExposureEvolution.Strong45.quantitative_of_gap,``ExposureEvolution.DirectOldJoinDataV1.finite,``ExposureEvolution.Adaptive.coverage_sound,``E1TwoTracks.TrackN.quantitative,``ExposureEvolution.Final45.whole_ray,``ExposureEvolution.KernelSharpSurplus.quantitative_of_gap,``ExposureEvolution.Dual60FinalV1.whole_ray,``ExposureEvolution.Final45.tail,``ExposureEvolution.Dual60CheckerV1.Witness.sound,``ExposureEvolution.Adaptive45.Witness.sound,``E1TwoTracks.TrackNPower.finite,``E1Tertiary.LcmFinal.quantitative4096,``ExposureEvolution.Adaptive45Data.finite,``E1TwoTracks.TrackB.exactQuantitative,``E1TwoTracks.TrackACompare.whole_new_interval,``ExposureEvolution.Compact40FinalV1.whole_ray,``ExposureEvolution.Final.tail]
  for name in roots do
    let some ci := env.find? name | throwError "missing root {name}"
    let axioms ← Lean.collectAxioms name
    let ty ← Meta.ppExpr ci.type
    let row := Json.mkObj [("name",toJson name.toString),("type",toJson ty.pretty),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (axioms.toList.map Name.toString))]
    logInfo m!"FINALROOT {row.compress}"
