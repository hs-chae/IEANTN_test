import ExposureEvolution.Dual60FinalV1
namespace ExposureEvolution.Dual60FunctionalControlsV1
open E1TwoTracks.TrackB
set_option Elab.async false
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-- The original fixed-four adaptive method, at the SAME desired coefficient3/5. -/
def old_endpoint60 (b : Block) (valuation n : ℕ) : Prop :=
  let m := b.Q / (4*b.P)
  2^(valuation+3)*(5*n+3)*b.A*b.D + 5*b.B*(4*b.P*m) <
    5*(2^(valuation+3)*n+2^(valuation+2))*b.B*(4*b.P*m)
instance (b : Block) (j n : ℕ) : Decidable (old_endpoint60 b j n) :=
  inferInstanceAs (Decidable (_ < _))
def first : ExposureEvolution.Dual60CheckerV1.Witness := ⟨⟨5000000, 5004168, 2237, 2239, 2243, 4932619, 4932757, 4932827⟩, 11⟩
theorem new_core72_accepts_first : first.check = true :=
  ExposureEvolution.DualKernelBlocks60_000.checked00
/-- Exact failure of the frozen fixed-four numerical predicate atn=5m.
This says nothing about mathematical nonexistence of a different witness. -/
theorem old_core4_rejects_same_margin : ¬ old_endpoint60 first.block first.valuation 5000000 := by
  norm_num [old_endpoint60,first,Block.P,Block.Q,Block.A,Block.D,Block.B]
theorem finite_only (n : ℕ) (hn : 5000000 ≤ n ∧ n < 71707024) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1+3/(5*(n:ℝ)))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ)<ArithmeticFunction.sigma 1 m :=
  ExposureEvolution.DualKernelCoverage60.finite n hn
theorem tail_only (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 71707024 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1+3/(5*(n:ℝ)))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ)<ArithmeticFunction.sigma 1 m :=
  ExposureEvolution.Dual60FinalV1.tail hd n hn
#print axioms new_core72_accepts_first
#print axioms old_core4_rejects_same_margin
#print axioms finite_only
#print axioms tail_only
end ExposureEvolution.Dual60FunctionalControlsV1
