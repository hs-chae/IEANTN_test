/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1Tertiary.LcmSurplus
import E1Tertiary.LcmResult
namespace E1Tertiary.LcmFinal
open Real
/-- Actual tertiary quantitative theorem consuming the evolved prime-cover execution. -/
theorem quantitative4096 (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 16777216 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  have hlog : (5 : ℝ) ≤ Real.log 4096 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (5 : ℝ)) LcmResult.exp_five_small).le
  have hnn : (4096 : ℝ)^2 ≤ n := by exact_mod_cast hn
  exact LcmSurplus.quantitative_of_gap (LcmResult.gap hd) (by norm_num : (5 : ℝ) ≤ 5) hlog n hnn
/-- Reoptimized evolved result; compare with the independent P2 analytic route on this whole ray. -/
theorem quantitative (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 10712529 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  have he5 : exp (5 : ℝ) < 3273 := by
    have he : exp 1 ≤ (68/25 : ℝ) := by linarith [Real.exp_one_lt_d9]
    calc exp (5 : ℝ) = (exp 1)^5 := by rw [Real.exp_one_pow]; norm_num
      _ ≤ (68/25 : ℝ)^5 := pow_le_pow_left₀ (exp_pos 1).le he 5
      _ < 3273 := by norm_num
  have hlog : (5 : ℝ) ≤ Real.log 3273 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (5 : ℝ)) he5).le
  have hnn : (3273 : ℝ)^2 ≤ n := by exact_mod_cast hn
  exact LcmSurplus.quantitative_of_gap (LcmResult.gap3273 hd) (by norm_num : (5 : ℝ) ≤ 5) hlog n hnn

end E1Tertiary.LcmFinal
