/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
/- Frozen-evidence analytic challenge: fixed primes read from the OLD3273
cover; improved q selection uses only the original Dusart2018 premise. -/
import E1Tertiary.LcmResult
import E1Tertiary.LcmSurplus
import E1Tertiary.LcmFinal
namespace E1TwoTracks.TrackNFixed
open Real Finset Nat
open E1Tertiary.LcmBase
set_option maxHeartbeats 3000000
set_option maxRecDepth 100000

/-- Three disjoint old-cover intervals, with integer upper rounding.
Only the already admitted whole-real gap theorem is instantiated. -/
theorem p_exists (hd : Dusart2018.v1.proposition_5_4) :
    ∃ p : Fin 3 → ℕ, (∀ i, Nat.Prime (p i)) ∧ StrictMono p ∧
      (∀ i, 3273 < p i) ∧ (∀ i, p i ≤ (![3299,3325,3351] : Fin 3 → ℕ) i) := by
  have old := E1Tertiary.LcmResult.gap3273 hd
  obtain ⟨p0,hp0,hl0,hu0⟩ := old 3273 (by norm_num)
  obtain ⟨p1,hp1,hl1,hu1⟩ := old 3299 (by norm_num)
  obtain ⟨p2,hp2,hl2,hu2⟩ := old 3325 (by norm_num)
  have hb0 : p0 ≤ 3299 := by
    have : (p0:ℝ) < 3300 := by linarith
    have : p0 < 3300 := by exact_mod_cast this
    omega
  have hb1 : p1 ≤ 3325 := by
    have : (p1:ℝ) < 3326 := by linarith
    have : p1 < 3326 := by exact_mod_cast this
    omega
  have hb2 : p2 ≤ 3351 := by
    have : (p2:ℝ) < 3352 := by linarith
    have : p2 < 3352 := by exact_mod_cast this
    omega
  have hl0' : 3273 < p0 := by exact_mod_cast hl0
  have hl1' : 3299 < p1 := by exact_mod_cast hl1
  have hl2' : 3325 < p2 := by exact_mod_cast hl2
  refine ⟨![p0,p1,p2], ?_, ?_, ?_, ?_⟩
  · intro i; fin_cases i <;> assumption
  · intro i j hij; fin_cases i <;> fin_cases j <;> simp_all <;> omega
  · intro i; fin_cases i <;> dsimp <;> omega
  · intro i; fin_cases i <;> dsimp <;> assumption

noncomputable def a : ℝ := 1332/1331

theorem a_pos : (0:ℝ) < a := by norm_num [a]
theorem a_gt_one : (1:ℝ) < a := by norm_num [a]

theorem gap (hd : Dusart2018.v1.proposition_5_4) {x : ℝ} (hx : 1000000 ≤ x) :
    ∃ q : ℕ, Nat.Prime q ∧ x < q ∧ (q:ℝ) ≤ a*x := by
  have hxp : (0:ℝ) < x := by linarith
  have he : exp (11:ℝ) < 1000000 := by
    rw [show (11:ℝ)=((11:ℕ):ℝ) by norm_num, ←Real.exp_one_pow]
    grw [Real.exp_one_lt_d9]
    norm_num
  have hl : (11:ℝ) < log x := by
    simpa only [log_exp] using log_lt_log (exp_pos (11:ℝ)) (he.trans_le hx)
  have hc : (1331:ℝ) < log x^3 := by nlinarith [sq_nonneg (log x-11)]
  obtain ⟨q,hq,hlo,hhi⟩ := hd x (by linarith)
  refine ⟨q,hq,hlo,?_⟩
  have hdiv : x/log x^3 ≤ x/1331 :=
    div_le_div_of_nonneg_left hxp.le (by norm_num) hc.le
  norm_num only [Real.rpow_ofNat] at hhi
  norm_num [a] at *
  linarith

theorem q_exists (hd : Dusart2018.v1.proposition_5_4) {n : ℝ} (hn : 10100000 ≤ n) :
    ∃ q : Fin 3 → ℕ, (∀ i, Nat.Prime (q i)) ∧ StrictMono q ∧
      (∀ i, (997/1000:ℝ)*n ≤ q i) ∧ (∀ i, (q i:ℝ) < n) := by
  have hnp : (0:ℝ) < n := by linarith
  have ha1 : (0:ℝ) < a := a_pos
  have hamin : (1:ℝ) < a := a_gt_one
  have hx4 : 1000000 ≤ n/a^4 := by
    apply (le_div_iff₀ (by positivity : (0:ℝ)<a^4)).mpr
    norm_num [a] at *
    linarith
  have hx3 : 1000000 ≤ n/a^3 := by
    apply (le_div_iff₀ (by positivity : (0:ℝ)<a^3)).mpr
    norm_num [a] at *
    linarith
  have hx2 : 1000000 ≤ n/a^2 := by
    apply (le_div_iff₀ (by positivity : (0:ℝ)<a^2)).mpr
    norm_num [a] at *
    linarith
  obtain ⟨q0,hp0,hl0,hu0⟩ := gap hd hx4
  obtain ⟨q1,hp1,hl1,hu1⟩ := gap hd hx3
  obtain ⟨q2,hp2,hl2,hu2⟩ := gap hd hx2
  have he0 : a*(n/a^4) = n/a^3 := by field_simp <;> ring
  have he1 : a*(n/a^3) = n/a^2 := by field_simp <;> ring
  have he2 : a*(n/a^2) = n/a := by field_simp <;> ring
  rw [he0] at hu0
  rw [he1] at hu1
  rw [he2] at hu2
  have h01 : q0 < q1 := by exact_mod_cast hu0.trans_lt hl1
  have h12 : q1 < q2 := by exact_mod_cast hu1.trans_lt hl2
  have hbase : (997/1000:ℝ)*n ≤ n/a^4 := by
    apply (le_div_iff₀ (by positivity : (0:ℝ)<a^4)).mpr
    norm_num [a]
    nlinarith
  have hlast : n/a < n := (div_lt_self hnp a_gt_one)
  refine ⟨![q0,q1,q2], ?_, ?_, ?_, ?_⟩
  · intro i; fin_cases i <;> assumption
  · intro i j hij; fin_cases i <;> fin_cases j <;> simp_all <;> omega
  · intro i
    have hq0 : (997/1000:ℝ)*n ≤ q0 := hbase.trans hl0.le
    have hq01 : (q0:ℝ)<q1 := by exact_mod_cast h01
    have hq12 : (q1:ℝ)<q2 := by exact_mod_cast h12
    fin_cases i <;> dsimp <;> linarith
  · intro i
    have hq01 : (q0:ℝ)<q1 := by exact_mod_cast h01
    have hq12 : (q1:ℝ)<q2 := by exact_mod_cast h12
    fin_cases i <;> dsimp <;> linarith

theorem scalar {e : ℝ} (he : 0 ≤ e) (he' : e ≤ 1/10000000) :
    (1+e/10)*(1+(1000/997:ℝ)*e)^3 ≤
      (1+(137/50:ℝ)*e)*(1+(3/8:ℝ)*e)*(1-(3/2000:ℝ)*e) := by
  have h2 : e^2 ≤ e/10000000 := by nlinarith
  have h3 : e^3 ≤ e^2/10000000 := by
    nlinarith [mul_nonneg (sq_nonneg e) (sub_nonneg.mpr he')]
  have h4 : e^4 ≤ e^3/10000000 := by
    nlinarith [mul_nonneg (pow_nonneg he 3) (sub_nonneg.mpr he')]
  nlinarith [pow_nonneg he 2,pow_nonneg he 3,pow_nonneg he 4]

theorem ratio {n : ℝ} (hn : 10100000 ≤ n) (p q : Fin 3 → ℕ)
    (hp : ∀ i, p i ≤ (![3299,3325,3351] : Fin 3 → ℕ) i)
    (hprime : ∀ i, Nat.Prime (p i))
    (hq : ∀ i, (997/1000:ℝ)*n ≤ q i) :
    (1+1/(10*n))*∏ i, (1+(1:ℝ)/q i) ≤
      (∏ i, (1+1/(p i*(p i+1):ℝ)))*(1+3/(8*n))*
      (1-4*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ))) := by
  have hnp : (0:ℝ) < n := by linarith
  have he : (0:ℝ) ≤ 1/n := by positivity
  have hep : (0:ℝ) < 1/n := by positivity
  have he' : (1:ℝ)/n ≤ 1/10000000 :=
    one_div_le_one_div_of_le (by norm_num) (by linarith)
  have hp' (i : Fin 3) : (p i:ℝ) ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by
    have h := hp i
    fin_cases i <;> dsimp at * <;> exact_mod_cast h
  have hp0 (i : Fin 3) : (0:ℝ)<p i := by exact_mod_cast (hprime i).pos
  have hq0 (i : Fin 3) : (0:ℝ)<q i := (by positivity : (0:ℝ)<(997/1000:ℝ)*n).trans_le (hq i)
  have hBconst : 1+(137/50:ℝ)/10100000 ≤
      ∏ i, (1+1/((![3299,3325,3351] : Fin 3 → ℝ) i *
        ((![3299,3325,3351] : Fin 3 → ℝ) i+1))) := by
    norm_num [Fin.prod_univ_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]
  have hB : 1+(137/50:ℝ)*(1/n) ≤ ∏ i, (1+1/(p i*(p i+1):ℝ)) := by
    calc
      _ ≤ 1+(137/50:ℝ)/10100000 := by
        have hi : (1:ℝ)/n ≤ 1/10100000 := one_div_le_one_div_of_le (by norm_num) hn
        nlinarith
      _ ≤ _ := hBconst
      _ ≤ _ := by
        apply Finset.prod_le_prod₀
        · intro i hi
          have hc : 0 ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by fin_cases i <;> dsimp <;> norm_num
          positivity
        · intro i hi
          have hc : 0 ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by fin_cases i <;> dsimp <;> norm_num
          have hmul : (p i:ℝ)*(p i+1) ≤
              (![3299,3325,3351] : Fin 3 → ℝ) i * ((![3299,3325,3351] : Fin 3 → ℝ) i+1) := by
            exact mul_le_mul (hp' i) (by linarith [hp' i]) (by linarith [hp0 i]) hc
          have hh := one_div_le_one_div_of_le (mul_pos (hp0 i) (by linarith [hp0 i])) hmul
          linarith
  have hA : (∏ i, (1+(1:ℝ)/q i)) ≤ (1+(1000/997:ℝ)*(1/n))^3 := by
    have ht (i : Fin 3) : 1+(1:ℝ)/q i ≤ 1+(1000/997:ℝ)*(1/n) := by
      have hi := one_div_le_one_div_of_le (by positivity : (0:ℝ)<(997/1000:ℝ)*n) (hq i)
      have heq : (1:ℝ)/((997/1000:ℝ)*n) = (1000/997:ℝ)*(1/n) := by field_simp <;> ring
      rw [heq] at hi
      linarith
    calc
      _ ≤ ∏ i : Fin 3, (1+(1000/997:ℝ)*(1/n)) := Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply ht)
      _ = _ := by simp [Fin.prod_univ_three] <;> ring
  have hQ : ((997/1000:ℝ)*n)^3 ≤ ∏ i, (q i:ℝ) := by
    calc
      _ = ∏ i : Fin 3, ((997/1000:ℝ)*n) := by simp [Fin.prod_univ_three] <;> ring
      _ ≤ _ := Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply hq)
  have hP : (∏ i, (p i:ℝ)) ≤ (3299:ℝ)*3325*3351 := by
    calc
      _ ≤ ∏ i : Fin 3, (![3299,3325,3351] : Fin 3 → ℝ) i :=
        Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply hp')
      _ = _ := by norm_num [Fin.prod_univ_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]
  have hR : 1-(3/2000:ℝ)*(1/n) ≤
      1-4*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ)) := by
    have hrat : 4*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ)) ≤
        4*((3299:ℝ)*3325*3351)/(((997/1000:ℝ)*n)^3) := by
      exact div_le_div₀ (by positivity) (by linarith) (by positivity) hQ
    have hn2 : (10100000:ℝ)^2 ≤ n^2 :=
      pow_le_pow_left₀ (by norm_num) hn 2
    have hc : 4*((3299:ℝ)*3325*3351) ≤ (3/2000:ℝ)*(997/1000:ℝ)^3*n^2 := by nlinarith
    have hr : 4*((3299:ℝ)*3325*3351)/(((997/1000:ℝ)*n)^3) ≤ (3/2000:ℝ)/n := by
      apply (div_le_div_iff₀ (by positivity) hnp).mpr
      nlinarith [mul_le_mul_of_nonneg_right hc hnp.le]
    simpa only [div_eq_mul_inv,one_div,one_mul] using sub_le_sub_left (hrat.trans hr) 1
  have hR0 : (0:ℝ) ≤ 1-(3/2000:ℝ)*(1/n) := by linarith
  have hlow := scalar he he'
  calc
    _ ≤ (1+(1/n)/10)*(1+(1000/997:ℝ)*(1/n))^3 := by
      rw [show (1:ℝ)/(10*n)=(1/n)/10 by ring]
      exact mul_le_mul_of_nonneg_left hA (by positivity)
    _ ≤ _ := hlow
    _ ≤ _ := by
      rw [show (3:ℝ)/(8*n)=(3/8:ℝ)*(1/n) by ring]
      exact mul_le_mul (mul_le_mul_of_nonneg_right hB (by positivity)) hR hR0 (by positivity)

/-- Improved completed frozen-C result, with all new analytic ideas retained. -/
theorem quantitative (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 10100000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ)))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases hbig : 10712529 ≤ n
  · exact E1Tertiary.LcmFinal.quantitative hd n hbig
  have hnr : (10100000:ℝ) ≤ n := by exact_mod_cast hn
  obtain ⟨p,hp,hpm,hpl,hpu⟩ := p_exists hd
  obtain ⟨q,hq,hqm,hql,hqu⟩ := q_exists hd hnr
  have hr := ratio hnr p q hpu hp hql
  let c : Criterion := {
    n := n
    hn := by omega
    p := p
    hp := hp
    hp_mono := hpm
    q := q
    hq := hq
    hq_mono := hqm
    h_ord_1 := by
      have hpp : 3273 < p 0 := hpl 0
      have hpp' : (3273:ℝ) < p 0 := by exact_mod_cast hpp
      have hnu : (n:ℝ) < (3273:ℝ)^2 := by
        have : n < 10712529 := by omega
        exact_mod_cast this
      have hs : Real.sqrt (n:ℝ) < 3273 := (Real.sqrt_lt (by positivity) (by norm_num)).mpr hnu
      exact hs.trans hpp'
    h_ord_2 := by
      have hp2 : p 2 ≤ 3351 := by simpa using hpu 2
      have hq0 := hql 0
      have hq0' : (3351:ℝ) < q 0 := by linarith
      have : 3351 < q 0 := by exact_mod_cast hq0'
      omega
    h_ord_3 := by exact_mod_cast hqu 2
    h_crit := by
      have hA0 : (0:ℝ) ≤ ∏ i, (1+(1:ℝ)/q i) := by positivity
      have hmul : (∏ i, (1+(1:ℝ)/q i)) ≤
          (1+1/(10*(n:ℝ)))*∏ i, (1+(1:ℝ)/q i) := by
        nlinarith [mul_nonneg (by positivity : (0:ℝ)≤1/(10*(n:ℝ))) hA0]
      exact hmul.trans hr
  }
  refine ⟨c.M,c.M_lt,?_⟩
  exact E1Tertiary.LcmSurplus.criterion_surplus c (by positivity) hr

#print axioms quantitative
end E1TwoTracks.TrackNFixed
