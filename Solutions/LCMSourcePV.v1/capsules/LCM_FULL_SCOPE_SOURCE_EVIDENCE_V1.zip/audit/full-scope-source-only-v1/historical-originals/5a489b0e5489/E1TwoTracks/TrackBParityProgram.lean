/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackBProgram
import E1TwoTracks.TrackBParityCheck
import E1Tertiary.LcmFinal
namespace E1TwoTracks.TrackB
set_option maxRecDepth 10000
set_option maxHeartbeats 3000000

def shrinkParity : ℕ → Block → Option Block
  | 0, b => if b.parityCheck then some b else none
  | k+1, b => if b.parityCheck then some b else
      if b.hi ≤ b.lo then none else
        shrinkParity k {b with hi := b.lo + (b.hi-b.lo)/2}

def chooseParityQ (primeFuel fitFuel lo stop p0 p1 p2 : ℕ) : ℕ → ℕ → Option Block
  | 0, _ => none
  | fuel+1, top => do
      let q2 ← prevPrime primeFuel top
      let q1 ← prevPrime primeFuel (q2-1)
      let q0 ← prevPrime primeFuel (q1-1)
      let b : Block := ⟨lo,min (p0^2-1) (stop-1),p0,p1,p2,q0,q1,q2⟩
      let candidate := if (b.Q/(4*b.P))%2=0 then shrinkParity fitFuel b else none
      match candidate with
      | some b => pure b
      | none => chooseParityQ primeFuel fitFuel lo stop p0 p1 p2 fuel (q2-1)

def makeParity (primeFuel fitFuel qFuel lo stop : ℕ) : Option Block := do
  let p0 ← nextPrime primeFuel (Nat.sqrt lo+1)
  let p1 ← nextPrime primeFuel (p0+1)
  let p2 ← nextPrime primeFuel (p1+1)
  chooseParityQ primeFuel fitFuel lo stop p0 p1 p2 qFuel (lo-1)

def runParity (primeFuel fitFuel qFuel : ℕ) : ℕ → ℕ → ℕ → Option (List Block)
  | 0, lo, stop => if stop ≤ lo then some [] else none
  | fuel+1, lo, stop => if stop ≤ lo then some [] else do
      let b ← makeParity primeFuel fitFuel qFuel lo stop
      let bs ← runParity primeFuel fitFuel qFuel fuel (b.hi+1) stop
      pure (b::bs)

def checkParity : ℕ → ℕ → List Block → Bool
  | lo, stop, [] => decide (stop ≤ lo)
  | lo, stop, b::bs => decide (b.lo=lo) && b.parityCheck && checkParity (b.hi+1) stop bs

theorem paritySound (lo stop : ℕ) (bs : List Block) (hb : checkParity lo stop bs = true)
    (n : ℕ) (hn : lo ≤ n ∧ n < stop) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  induction bs generalizing lo with
  | nil => simp only [checkParity, decide_eq_true_eq] at hb; omega
  | cons b bs ih =>
      simp only [checkParity, Bool.and_eq_true, decide_eq_true_eq] at hb
      rcases hb with ⟨⟨hlo,hv⟩,ht⟩
      by_cases hnh : n ≤ b.hi
      · exact b.paritySound hv n (hlo ▸ hn.1) hnh
      · exact ih (b.hi+1) ht ⟨by omega,hn.2⟩

def parityStart : ℕ := 110000
def parityStop : ℕ := 10712529
def parityOutput : List Block := (runParity 1000 30 64 1024 parityStart parityStop).getD []

theorem parityExecution :
    (runParity 1000 30 64 1024 parityStart parityStop).isSome = true ∧
    checkParity parityStart parityStop parityOutput = true ∧ parityOutput.length = 396 := by native_decide

theorem parityFinite (n : ℕ) (hn : parityStart ≤ n ∧ n < parityStop) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m :=
  paritySound parityStart parityStop parityOutput parityExecution.2.1 n hn

theorem parityQuantitative (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 110000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases h : n < parityStop
  · exact parityFinite n ⟨hn,h⟩
  · exact E1Tertiary.LcmFinal.quantitative hd n (by simpa only [parityStop] using Nat.le_of_not_lt h)

#eval IO.println (Lean.toJson (parityOutput.map fun b => [b.lo,b.hi,b.p0,b.p1,b.p2,b.q0,b.q1,b.q2])).compress
#print axioms parityQuantitative
end E1TwoTracks.TrackB
