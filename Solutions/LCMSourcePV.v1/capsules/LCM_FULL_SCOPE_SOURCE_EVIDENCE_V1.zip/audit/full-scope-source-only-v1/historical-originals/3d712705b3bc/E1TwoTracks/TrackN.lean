/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1Tertiary.LcmResult
import E1TwoTracks.TrackASurplus

namespace E1TwoTracks.TrackN
open Real

/-- Reoptimize the old C cover with the treatment's new analytic budget.
No new prime search, primality evaluation, or output is used. -/
theorem gap (hd : Dusart2018.v1.proposition_5_4) :
    TrackAConstant.StrictGap 3250 := by
  intro x hx
  have old := E1Tertiary.LcmResult.gap3273 hd
  by_cases h : (3273 : ℝ) ≤ x
  · obtain ⟨p, hp, hxp, hpx⟩ := old x h
    refine ⟨p, hp, hxp, ?_⟩
    linarith
  · obtain ⟨p, hp, hxp, hpx⟩ := old 3273 (by norm_num)
    refine ⟨p, hp, by linarith, ?_⟩
    linarith

theorem log_start : (7 : ℝ) ≤ log 3250 := by
  have he : exp (7 : ℝ) < 3250 := by
    rw [show (7 : ℝ) = ((7 : ℕ) : ℝ) by norm_num, ← Real.exp_one_pow]
    grw [Real.exp_one_lt_d9]
    norm_num
  simpa only [log_exp] using (log_lt_log (exp_pos (7 : ℝ)) he).le

/-- Completed, analytically reoptimized C baseline. It inherits only the old
PrimeCover3273 output; the new Track A and B outputs are absent. -/
theorem quantitative (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 10562500 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1 / (10 * (n : ℝ))) *
        (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  exact TrackASurplus.quantitative_of_gap (gap hd)
    (by norm_num : (7 : ℝ) ≤ 7) log_start n (by exact_mod_cast hn)

/-- The proved uniform surplus supplied by an onset theorem, on its full domain.
Zero means that this particular completed theorem supplies no positive allowance. -/
noncomputable def allowance (onset n : ℕ) : ℝ :=
  if onset ≤ n then 1 / (10 * (n : ℝ)) else 0

theorem allowance_strict {onset n : ℕ} (hp : 0 < onset)
    (hlo : onset ≤ n) (hhi : n < 10562500) :
    allowance 10562500 n < allowance onset n := by
  simp only [allowance, if_pos hlo, if_neg (by omega : ¬10562500 ≤ n)]
  have hn : (0 : ℝ) < n := by exact_mod_cast (lt_of_lt_of_le hp hlo)
  positivity

theorem allowance_tie {onset n : ℕ} (h : onset ≤ 10562500) (hn : 10562500 ≤ n) :
    allowance 10562500 n = allowance onset n := by
  simp [allowance, hn, h.trans hn]

end E1TwoTracks.TrackN
