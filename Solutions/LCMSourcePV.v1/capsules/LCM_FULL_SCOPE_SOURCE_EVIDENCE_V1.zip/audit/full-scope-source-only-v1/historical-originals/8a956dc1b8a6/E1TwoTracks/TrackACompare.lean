/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackAHighFinal
import E1TwoTracks.TrackAHighBaseline
namespace E1TwoTracks.TrackACompare

/-- Exact comparison of the whole relative-margin functions on their real domain. -/
theorem margin_strict {n : ℝ} (hn : 0 < n) :
    1 + 1 / (10 * n) < 1 + 3 / (20 * n) := by
  have hidentity : 3 / (20 * n) - 1 / (10 * n) = 1 / (20 * n) := by
    field_simp [hn.ne']
    <;> ring
  have hpositive : 0 < 1 / (20 * n) := by positivity
  linarith

/-- The higher-margin treatment onset is strictly below the completed frozen-C onset. -/
theorem onset_strict : (2802276 : ℕ) < 10634121 := by norm_num

/-- Every natural point in the entire new interval has the actual stronger divisor-sum
witness. The second conclusion records only the completed baseline's stated domain,
not a claim that other NoPV proofs are impossible. -/
theorem whole_new_interval (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 2802276 ≤ n) (hupper : n < 10634121) :
    ¬10634121 ≤ n ∧ ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 3 / (20 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  exact ⟨by omega, TrackAHighFinal.quantitative hd n hn⟩
end E1TwoTracks.TrackACompare
