/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
/- The new constructor can refine a rejected interval rather than discarding
its six-prime witness. All accepted intervals still use the same sound checker. -/
import E1TwoTracks.TrackBProgram
import E1Tertiary.LcmFinal
namespace E1TwoTracks.TrackB
set_option maxRecDepth 10000
set_option maxHeartbeats 3000000

/-- Test the longest block first, then halve it if a criterion endpoint fails. -/
def shrinkBlock : ℕ → Block → Option Block
  | 0, b => if b.check then some b else none
  | k+1, b => if b.check then some b else
      if b.hi ≤ b.lo then none else
        shrinkBlock k {b with hi := b.lo + (b.hi-b.lo)/2}

def makeAdaptive (primeFuel fitFuel lo stop : ℕ) : Option Block := do
  let p0 ← nextPrime primeFuel (Nat.sqrt lo + 1)
  let p1 ← nextPrime primeFuel (p0+1)
  let p2 ← nextPrime primeFuel (p1+1)
  let q2 ← prevPrime primeFuel (lo-1)
  let q1 ← prevPrime primeFuel (q2-1)
  let q0 ← prevPrime primeFuel (q1-1)
  shrinkBlock fitFuel ⟨lo, min (p0^2-1) (stop-1), p0, p1, p2, q0, q1, q2⟩

def runAdaptive (primeFuel fitFuel : ℕ) : ℕ → ℕ → ℕ → Option (List Block)
  | 0, lo, stop => if stop ≤ lo then some [] else none
  | fuel+1, lo, stop => if stop ≤ lo then some [] else do
      let b ← makeAdaptive primeFuel fitFuel lo stop
      let bs ← runAdaptive primeFuel fitFuel fuel (b.hi+1) stop
      pure (b::bs)

def adaptiveStart : ℕ := 275000
def adaptiveStop : ℕ := 10712529
def adaptiveOutput : List Block := (runAdaptive 1000 30 1024 adaptiveStart adaptiveStop).getD []

theorem adaptiveExecution :
    (runAdaptive 1000 30 1024 adaptiveStart adaptiveStop).isSome = true ∧
    check adaptiveStart adaptiveStop adaptiveOutput = true ∧ adaptiveOutput.length = 365 := by native_decide

theorem adaptiveFinite (n : ℕ) (hn : adaptiveStart ≤ n ∧ n < adaptiveStop) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m :=
  sound adaptiveStart adaptiveStop adaptiveOutput adaptiveExecution.2.1 n hn

/-- Lowered onset from adaptive criterion-aware witness coverage. -/
theorem adaptiveQuantitative (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 275000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases h : n < adaptiveStop
  · exact adaptiveFinite n ⟨hn,h⟩
  · exact E1Tertiary.LcmFinal.quantitative hd n (by simpa only [adaptiveStop] using Nat.le_of_not_lt h)

#eval IO.println (Lean.toJson (adaptiveOutput.map fun b => [b.lo,b.hi,b.p0,b.p1,b.p2,b.q0,b.q1,b.q2])).compress
#print axioms adaptiveQuantitative
end E1TwoTracks.TrackB
