/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackNPowerMath
import E1TwoTracks.TrackNFixed
import E1TwoTracks.TrackAHighBaseline
namespace E1TwoTracks.TrackNPower
open Real Finset Nat
open E1TwoTracks.TrackNFixed
open E1TwoTracks.TrackNPowerBase
set_option maxHeartbeats 3000000
set_option maxRecDepth 100000

theorem q_exists (hd : Dusart2018.v1.proposition_5_4) {n : ℝ} (hn : 9000000 ≤ n) :
    ∃ q : Fin 3 → ℕ, (∀ i, Nat.Prime (q i)) ∧ StrictMono q ∧
      (∀ i, (997/1000:ℝ)*n ≤ q i) ∧ (∀ i, (q i:ℝ) < n) := by
  have hnp : (0:ℝ) < n := by linarith
  have ha1 : (0:ℝ) < a := a_pos
  have hamin : (1:ℝ) < a := a_gt_one
  have hx4 : 1000000 ≤ n/a^4 := by
    apply (le_div_iff₀ (by positivity : (0:ℝ)<a^4)).mpr
    norm_num [a] at *
    linarith
  have hx3 : 1000000 ≤ n/a^3 := by
    apply (le_div_iff₀ (by positivity : (0:ℝ)<a^3)).mpr
    norm_num [a] at *
    linarith
  have hx2 : 1000000 ≤ n/a^2 := by
    apply (le_div_iff₀ (by positivity : (0:ℝ)<a^2)).mpr
    norm_num [a] at *
    linarith
  obtain ⟨q0,hp0,hl0,hu0⟩ := gap hd hx4
  obtain ⟨q1,hp1,hl1,hu1⟩ := gap hd hx3
  obtain ⟨q2,hp2,hl2,hu2⟩ := gap hd hx2
  have he0 : a*(n/a^4) = n/a^3 := by field_simp <;> ring
  have he1 : a*(n/a^3) = n/a^2 := by field_simp <;> ring
  have he2 : a*(n/a^2) = n/a := by field_simp <;> ring
  rw [he0] at hu0
  rw [he1] at hu1
  rw [he2] at hu2
  have h01 : q0 < q1 := by exact_mod_cast hu0.trans_lt hl1
  have h12 : q1 < q2 := by exact_mod_cast hu1.trans_lt hl2
  have hbase : (997/1000:ℝ)*n ≤ n/a^4 := by
    apply (le_div_iff₀ (by positivity : (0:ℝ)<a^4)).mpr
    norm_num [a]
    nlinarith
  have hlast : n/a < n := (div_lt_self hnp a_gt_one)
  refine ⟨![q0,q1,q2], ?_, ?_, ?_, ?_⟩
  · intro i; fin_cases i <;> assumption
  · intro i j hij; fin_cases i <;> fin_cases j <;> simp_all <;> omega
  · intro i
    have hq0 : (997/1000:ℝ)*n ≤ q0 := hbase.trans hl0.le
    have hq01 : (q0:ℝ)<q1 := by exact_mod_cast h01
    have hq12 : (q1:ℝ)<q2 := by exact_mod_cast h12
    fin_cases i <;> dsimp <;> linarith
  · intro i
    have hq01 : (q0:ℝ)<q1 := by exact_mod_cast h01
    have hq12 : (q1:ℝ)<q2 := by exact_mod_cast h12
    fin_cases i <;> dsimp <;> linarith

theorem scalar_low {e : ℝ} (he : 0 ≤ e) (he' : e ≤ 1/9000000) :
    (1+(1/10:ℝ)*e)*(1+(1000/997:ℝ)*e)^3 ≤
      (1+(2639/1000:ℝ)*e)*(1+(31/64:ℝ)*e)*(1-(13/1000:ℝ)*e) := by
  have h2 : e^2 ≤ e/9000000 := by nlinarith
  have h3 : e^3 ≤ e^2/9000000 := by
    nlinarith [mul_nonneg (sq_nonneg e) (sub_nonneg.mpr he')]
  have h4 : e^4 ≤ e^3/9000000 := by
    nlinarith [mul_nonneg (pow_nonneg he 3) (sub_nonneg.mpr he')]
  nlinarith [pow_nonneg he 2,pow_nonneg he 3,pow_nonneg he 4]

theorem scalar_high {e : ℝ} (he : 0 ≤ e) (he' : e ≤ 1/9000000) :
    (1+(3/20:ℝ)*e)*(1+(1000/997:ℝ)*e)^3 ≤
      (1+(269/100:ℝ)*e)*(1+(31/64:ℝ)*e)*(1-(13/1000:ℝ)*e) := by
  have h2 : e^2 ≤ e/9000000 := by nlinarith
  have h3 : e^3 ≤ e^2/9000000 := by
    nlinarith [mul_nonneg (sq_nonneg e) (sub_nonneg.mpr he')]
  have h4 : e^4 ≤ e^3/9000000 := by
    nlinarith [mul_nonneg (pow_nonneg he 3) (sub_nonneg.mpr he')]
  nlinarith [pow_nonneg he 2,pow_nonneg he 3,pow_nonneg he 4]

theorem ratio {T n beta margin : ℝ} (hT : 9730000 ≤ T) (hn : T ≤ n)
    (hbeta : 0 ≤ beta) (hmargin : 0 ≤ margin)
    (hBconst : 1+beta/T ≤ ∏ i : Fin 3,
      (1+1/((![3299,3325,3351] : Fin 3 → ℝ) i *
        ((![3299,3325,3351] : Fin 3 → ℝ) i+1))))
    (hscalar : ∀ {e : ℝ}, 0 ≤ e → e ≤ 1/9000000 →
      (1+margin*e)*(1+(1000/997:ℝ)*e)^3 ≤
        (1+beta*e)*(1+(31/64:ℝ)*e)*(1-(13/1000:ℝ)*e))
    (p q : Fin 3 → ℕ)
    (hp : ∀ i, p i ≤ (![3299,3325,3351] : Fin 3 → ℕ) i)
    (hprime : ∀ i, Nat.Prime (p i))
    (hq : ∀ i, (997/1000:ℝ)*n ≤ q i) :
    (1+margin/n)*∏ i, (1+(1:ℝ)/q i) ≤
      (∏ i, (1+1/(p i*(p i+1):ℝ)))*(1+31/(64*n))*
      (1-32*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ))) := by
  have hnp : (0:ℝ) < n := by linarith
  have he : (0:ℝ) ≤ 1/n := by positivity
  have hep : (0:ℝ) < 1/n := by positivity
  have he' : (1:ℝ)/n ≤ 1/9000000 :=
    one_div_le_one_div_of_le (by norm_num) (by linarith [hT])
  have hp' (i : Fin 3) : (p i:ℝ) ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by
    have h := hp i
    fin_cases i <;> dsimp at * <;> exact_mod_cast h
  have hp0 (i : Fin 3) : (0:ℝ)<p i := by exact_mod_cast (hprime i).pos
  have hq0 (i : Fin 3) : (0:ℝ)<q i := (by positivity : (0:ℝ)<(997/1000:ℝ)*n).trans_le (hq i)
  have hBconst := hBconst
  have hB : 1+beta*(1/n) ≤ ∏ i, (1+1/(p i*(p i+1):ℝ)) := by
    calc
      _ ≤ 1+beta/T := by
        have hi : (1:ℝ)/n ≤ 1/T := one_div_le_one_div_of_le (by linarith [hT]) hn
        simpa [div_eq_mul_inv] using mul_le_mul_of_nonneg_left hi hbeta
      _ ≤ _ := hBconst
      _ ≤ _ := by
        apply Finset.prod_le_prod₀
        · intro i hi
          have hc : 0 ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by fin_cases i <;> dsimp <;> norm_num
          positivity
        · intro i hi
          have hc : 0 ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by fin_cases i <;> dsimp <;> norm_num
          have hmul : (p i:ℝ)*(p i+1) ≤
              (![3299,3325,3351] : Fin 3 → ℝ) i * ((![3299,3325,3351] : Fin 3 → ℝ) i+1) := by
            exact mul_le_mul (hp' i) (by linarith [hp' i]) (by linarith [hp0 i]) hc
          have hh := one_div_le_one_div_of_le (mul_pos (hp0 i) (by linarith [hp0 i])) hmul
          linarith
  have hA : (∏ i, (1+(1:ℝ)/q i)) ≤ (1+(1000/997:ℝ)*(1/n))^3 := by
    have ht (i : Fin 3) : 1+(1:ℝ)/q i ≤ 1+(1000/997:ℝ)*(1/n) := by
      have hi := one_div_le_one_div_of_le (by positivity : (0:ℝ)<(997/1000:ℝ)*n) (hq i)
      have heq : (1:ℝ)/((997/1000:ℝ)*n) = (1000/997:ℝ)*(1/n) := by field_simp <;> ring
      rw [heq] at hi
      linarith
    calc
      _ ≤ ∏ i : Fin 3, (1+(1000/997:ℝ)*(1/n)) := Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply ht)
      _ = _ := by simp [Fin.prod_univ_three] <;> ring
  have hQ : ((997/1000:ℝ)*n)^3 ≤ ∏ i, (q i:ℝ) := by
    calc
      _ = ∏ i : Fin 3, ((997/1000:ℝ)*n) := by simp [Fin.prod_univ_three] <;> ring
      _ ≤ _ := Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply hq)
  have hP : (∏ i, (p i:ℝ)) ≤ (3299:ℝ)*3325*3351 := by
    calc
      _ ≤ ∏ i : Fin 3, (![3299,3325,3351] : Fin 3 → ℝ) i :=
        Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply hp')
      _ = _ := by norm_num [Fin.prod_univ_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]
  have hR : 1-(13/1000:ℝ)*(1/n) ≤
      1-32*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ)) := by
    have hrat : 32*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ)) ≤
        32*((3299:ℝ)*3325*3351)/(((997/1000:ℝ)*n)^3) := by
      exact div_le_div₀ (by positivity) (by linarith) (by positivity) hQ
    have hn2 : (T:ℝ)^2 ≤ n^2 :=
      pow_le_pow_left₀ (by linarith [hT]) hn 2
    have htarget : (9730000:ℝ)^2 ≤ T^2 := pow_le_pow_left₀ (by norm_num) hT 2
    have hc : 32*((3299:ℝ)*3325*3351) ≤ (13/1000:ℝ)*(997/1000:ℝ)^3*n^2 := by nlinarith
    have hr : 32*((3299:ℝ)*3325*3351)/(((997/1000:ℝ)*n)^3) ≤ (13/1000:ℝ)/n := by
      apply (div_le_div_iff₀ (by positivity) hnp).mpr
      nlinarith [mul_le_mul_of_nonneg_right hc hnp.le]
    simpa only [div_eq_mul_inv,one_div,one_mul] using sub_le_sub_left (hrat.trans hr) 1
  have hR0 : (0:ℝ) ≤ 1-(13/1000:ℝ)*(1/n) := by linarith
  have hlow := hscalar he he'
  calc
    _ ≤ (1+margin*(1/n))*(1+(1000/997:ℝ)*(1/n))^3 := by
      rw [show margin/n=margin*(1/n) by ring]
      exact mul_le_mul_of_nonneg_left hA (by positivity)
    _ ≤ _ := hlow
    _ ≤ _ := by
      rw [show (31:ℝ)/(64*n)=(31/64:ℝ)*(1/n) by ring]
      exact mul_le_mul (mul_le_mul_of_nonneg_right hB (by positivity)) hR hR0 (by positivity)


/-- Actual finite NoPV consumer for every scalar parameter package proved above. -/
theorem finite {T beta margin : ℝ} (hT : 9730000 ≤ T)
    (hbeta : 0 ≤ beta) (hmargin : 0 ≤ margin)
    (hBconst : 1+beta/T ≤ ∏ i : Fin 3,
      (1+1/((![3299,3325,3351] : Fin 3 → ℝ) i *
        ((![3299,3325,3351] : Fin 3 → ℝ) i+1))))
    (hscalar : ∀ {e : ℝ}, 0 ≤ e → e ≤ 1/9000000 →
      (1+margin*e)*(1+(1000/997:ℝ)*e)^3 ≤
        (1+beta*e)*(1+(31/64:ℝ)*e)*(1-(13/1000:ℝ)*e))
    (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : T ≤ n) (hu : n < 10712529) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+margin/(n:ℝ))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hnr : (9000000:ℝ) ≤ n := by linarith
  obtain ⟨p,hp,hpm,hpl,hpu⟩ := p_exists hd
  obtain ⟨q,hq,hqm,hql,hqu⟩ := q_exists hd hnr
  have hr := ratio hT hn hbeta hmargin hBconst hscalar p q hpu hp hql
  have hQ : (0:ℝ) < ∏ i, (q i:ℝ) := prod_pos fun i _ => by exact_mod_cast (hq i).pos
  have hRpos : (0:ℝ) < 1-32*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ)) := by
    have hA : 0 < (1+margin/(n:ℝ))*∏ i, (1+(1:ℝ)/q i) :=
      mul_pos (by positivity) (prod_pos fun i _ => by positivity)
    have hBC : 0 < (∏ i, (1+1/(p i*(p i+1):ℝ)))*(1+31/(64*(n:ℝ))) := by positivity
    by_contra hbad
    have hrbad := mul_nonpos_of_nonneg_of_nonpos hBC.le (le_of_not_gt hbad)
    linarith
  let c : PowerCriterion := {
    k := 5
    hk := by norm_num
    n := n
    hn := by exact_mod_cast (show (1:ℝ) ≤ n by linarith)
    p := p
    hp := hp
    hp_mono := hpm
    q := q
    hq := hq
    hq_mono := hqm
    h_ord_1 := by
      have hpp : (3273:ℝ) < p 0 := by exact_mod_cast hpl 0
      have hnu : (n:ℝ) < (3273:ℝ)^2 := by exact_mod_cast hu
      exact ((Real.sqrt_lt (by positivity) (by norm_num)).mpr hnu).trans hpp
    h_ord_2 := by
      have hp2 : p 2 ≤ 3351 := by simpa using hpu 2
      have hq0 := hql 0
      have hq0' : (3351:ℝ) < q 0 := by linarith
      have : 3351 < q 0 := by exact_mod_cast hq0'
      omega
    h_ord_3 := by exact_mod_cast hqu 2
    h_product := by
      rw [sub_pos, div_lt_one hQ] at hRpos
      norm_num only [Nat.reducePow]
      exact_mod_cast hRpos
  }
  refine ⟨c.M,c.M_lt,?_⟩
  apply E1TwoTracks.TrackNPowerMath.criterion_surplus c 0 (by simp) (t := margin/(n:ℝ)) (by positivity)
  change (1+margin/(n:ℝ))*∏ i, (1+(1:ℝ)/q i) ≤
      (∏ i, (1+1/(p i*(p i+1):ℝ)))*(1+(1-(1/2:ℝ)^(0+5))/(2*(n:ℝ)))*
      (1-(2:ℝ)^5*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ)))
  have hgamma : (1-(1/2:ℝ)^(0+5))/(2*(n:ℝ)) = 31/(64*(n:ℝ)) := by
    norm_num
    <;> field_simp
    <;> ring
  rw [hgamma]
  norm_num only [Nat.reduceAdd, pow_succ, pow_zero, one_mul] at *
  convert hr using 1 <;> ring

/-- Reoptimized NoPV with a forced32 core; no newly evaluated numerical input. -/
theorem quantitative_low (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 9730000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ)))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases hbig : 10712529 ≤ n
  · exact E1Tertiary.LcmFinal.quantitative hd n hbig
  have hnr : (9730000:ℝ) ≤ n := by exact_mod_cast hn
  have hBC : 1+(2639/1000:ℝ)/9730000 ≤ ∏ i : Fin 3,
      (1+1/((![3299,3325,3351] : Fin 3 → ℝ) i *
        ((![3299,3325,3351] : Fin 3 → ℝ) i+1))) := by
    norm_num [Fin.prod_univ_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]
  simpa only [div_div] using finite (by norm_num : (9730000:ℝ) ≤ 9730000)
    (by norm_num : (0:ℝ) ≤ 2639/1000) (by norm_num : (0:ℝ) ≤ 1/10) hBC
    (fun he he' => scalar_low he he') hd n hnr (by omega)

/-- Higher-margin NoPV, with the same newly shared analytic forced-core idea. -/
theorem quantitative_high (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 9920000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+3/(20*(n:ℝ)))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases hbig : 10634121 ≤ n
  · exact E1TwoTracks.TrackAHighBaseline.quantitative hd n hbig
  have hnr : (9920000:ℝ) ≤ n := by exact_mod_cast hn
  have hBC : 1+(269/100:ℝ)/9920000 ≤ ∏ i : Fin 3,
      (1+1/((![3299,3325,3351] : Fin 3 → ℝ) i *
        ((![3299,3325,3351] : Fin 3 → ℝ) i+1))) := by
    norm_num [Fin.prod_univ_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]
  simpa only [div_div] using finite (by norm_num : (9730000:ℝ) ≤ 9920000)
    (by norm_num : (0:ℝ) ≤ 269/100) (by norm_num : (0:ℝ) ≤ 3/20) hBC
    (fun he he' => scalar_high he he') hd n hnr (by omega)

#print axioms quantitative_low
#print axioms quantitative_high

end E1TwoTracks.TrackNPower
