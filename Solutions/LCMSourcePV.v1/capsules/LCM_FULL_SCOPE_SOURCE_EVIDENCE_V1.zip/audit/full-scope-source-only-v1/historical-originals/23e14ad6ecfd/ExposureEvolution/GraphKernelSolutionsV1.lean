import ExposureEvolution.KernelFinal
import IEANTN.Nodes.PrimeCover256.v1.Conclusions
import IEANTN.Nodes.PrimeGap256.v1.Conclusions
import IEANTN.Nodes.LCMFinite03.v1.Conclusions
import IEANTN.Nodes.LCMTail03.v1.Conclusions
import IEANTN.Nodes.LCMQuant03.v1.Conclusions

namespace ExposureEvolution.GraphKernelSolutionsV1
open Real

theorem finite_cover : PrimeCover256.v1.finite_cover := by
  intro x hx
  exact KernelPrimeChecked.covered hx.1 hx.2

theorem strict_gap (hd : Dusart2018.v1.proposition_5_4)
    (hcover : PrimeCover256.v1.finite_cover) : PrimeGap256.v1.strict_gap := by
  intro x hx
  by_cases ht : x < 89693
  · exact hcover x ⟨hx, ht⟩
  · have hlarge : (89693 : ℝ) ≤ x := le_of_not_gt ht
    have hx0 : 0 < x := by linarith
    have he : exp (7 : ℝ) < 89693 := by
      have h1 : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
      calc exp (7 : ℝ) = (exp 1) ^ 7 := by rw [Real.exp_one_pow]; norm_num
        _ ≤ (3 : ℝ) ^ 7 := pow_le_pow_left₀ (exp_pos 1).le h1.le 7
        _ < 89693 := by norm_num
    have hl : 7 < log x := by
      have hh := log_lt_log (exp_pos (7 : ℝ)) (he.trans_le hlarge)
      simpa only [log_exp] using hh
    have hlp : 0 < log x := by linarith
    have hc : (256 : ℝ) < log x ^ 3 := by
      nlinarith [mul_pos (by linarith : 0 < log x - 7) (sq_pos_of_pos hlp)]
    obtain ⟨p, hp, hpx, hpu⟩ := hd x hlarge
    refine ⟨p, hp, hpx, hpu.trans_lt ?_⟩
    norm_num only [Real.rpow_ofNat]
    linarith [div_lt_div_of_pos_left hx0 (by norm_num : (0 : ℝ) < 256) hc]


theorem finite_surplus : LCMFinite03.v1.finite_surplus := by
  intro n hn
  exact KernelBlockCoverage.finite n hn

theorem tail_surplus (hgap : PrimeGap256.v1.strict_gap) : LCMTail03.v1.tail_surplus := by
  intro n hn
  have hg : KernelSharpConstant.StrictGap 8468 := hgap
  have hlog : (9 : ℝ) ≤ log 8468 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) KernelFinal.exp_nine_small).le
  have hreal : (8468 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  obtain ⟨m, hm, hσ⟩ := KernelSharpSurplus.quantitative_of_gap
    (c := 9) hg (by norm_num : (9 : ℝ) ≤ 9) hlog n hreal
  refine ⟨m, ?_, hm, hσ⟩
  by_contra hpos
  have hm0 : m = 0 := Nat.eq_zero_of_not_pos hpos
  have hσ' : (1 + 3 / (10 * (n : ℝ))) *
      (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) < 0 := by simpa [hm0] using hσ
  exact not_lt_of_ge (by positivity) hσ'


theorem whole_ray (hfinite : LCMFinite03.v1.finite_surplus)
    (htail : LCMTail03.v1.tail_surplus) : LCMQuant03.v1.whole_ray := by
  intro n hn
  by_cases ht : n < 71707024
  · exact hfinite n ⟨hn, ht⟩
  · exact htail n (Nat.le_of_not_lt ht)

#print axioms finite_cover
#print axioms strict_gap
#print axioms finite_surplus
#print axioms tail_surplus
#print axioms whole_ray
end ExposureEvolution.GraphKernelSolutionsV1
