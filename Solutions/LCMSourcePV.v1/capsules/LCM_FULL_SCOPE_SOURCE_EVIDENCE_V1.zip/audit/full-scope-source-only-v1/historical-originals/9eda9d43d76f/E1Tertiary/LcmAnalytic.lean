/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1Tertiary.LcmSurplus
/-! P2 sensitivity: an explicitly additional, equally offered literature premise.
Dusart1999, Math.Comp.68(225),411–415, §4, printedp414: x≥3275,
a prime in [x,x+x/(2ln²x)]. No new numerical provider is imported here. -/
namespace E1Tertiary.LcmAnalytic
open Real E1Tertiary.LcmConstant

/-- Deliberately preserve the primary source's closed left endpoint. -/
def Dusart1999 : Prop := ∀ x : ℝ, 3275 ≤ x →
  ∃ p : ℕ, Nat.Prime p ∧ x ≤ p ∧ (p : ℝ) ≤ x + x / (2 * log x^2)

theorem exp_eight_small : exp (8 : ℝ) < 3273 := by
  have he : exp 1 ≤ (68/25 : ℝ) := by linarith [Real.exp_one_lt_d9]
  calc exp (8 : ℝ) = (exp 1)^8 := by rw [Real.exp_one_pow]; norm_num
    _ ≤ (68/25 : ℝ)^8 := pow_le_pow_left₀ (exp_pos 1).le he 8
    _ < 3273 := by norm_num

/-- Strict endpoints obtained with a fixed, explicit positive shift and proved slack. -/
theorem gap_3275 (hd : Dusart1999) : StrictGap 3275 := by
  intro x hx
  have hxp : 0 < x := by linarith
  let y : ℝ := (10001/10000) * x
  have hxy : x < y := by dsimp [y]; linarith
  have hy : (3275 : ℝ) < y := by linarith
  have hyp : 0 < y := hxp.trans hxy
  have hl : 8 < log y := by
    simpa only [log_exp] using log_lt_log (exp_pos (8 : ℝ)) (exp_eight_small.trans (by linarith))
  have hc : (128 : ℝ) ≤ 2 * log y^2 := by nlinarith
  obtain ⟨p, hp, hlp, hup⟩ := hd y hy.le
  refine ⟨p, hp, hxy.trans_le hlp, ?_⟩
  have hb : y / (2 * log y^2) ≤ y / 128 := div_le_div_of_nonneg_left hyp.le (by norm_num) hc
  dsimp [y] at hb hup
  linarith

/-- Ordinary endpoint arithmetic defeats the finite-cover improvement too.
The literature witness at3275.1 is forced below3301; primality excludes the even3300. -/
theorem gap_3273 (hd : Dusart1999) : StrictGap 3273 := by
  intro x hx
  by_cases hlarge : (3275 : ℝ) ≤ x
  · exact gap_3275 hd x hlarge
  · have hxs : x < 3275 := lt_of_not_ge hlarge
    let y : ℝ := 32751/10
    have hyp : 0 < y := by norm_num [y]
    have hy8 : exp (8 : ℝ) < y := exp_eight_small.trans (by norm_num [y])
    have hl : 8 < log y := by simpa only [log_exp] using log_lt_log (exp_pos (8 : ℝ)) hy8
    have hc : (128 : ℝ) ≤ 2 * log y^2 := by nlinarith
    obtain ⟨p, hp, hlp, hup⟩ := hd y (by norm_num [y])
    have hb : y / (2 * log y^2) ≤ y / 128 := div_le_div_of_nonneg_left hyp.le (by norm_num) hc
    have hp3301 : (p : ℝ) < 3301 := by dsimp [y] at hb hup; linarith
    have hpN : p ≤ 3300 := by
      have : p < 3301 := by exact_mod_cast hp3301
      omega
    have hne : p ≠ 3300 := by
      intro heq
      have hdv : 2 ∣ p := by rw [heq]; norm_num
      have heq2 := (Nat.dvd_prime hp).mp hdv
      rcases heq2 with h | h <;> omega
    have hp3299 : p ≤ 3299 := by omega
    refine ⟨p, hp, ?_, ?_⟩
    · dsimp [y] at hlp; linarith
    · have : (p : ℝ) ≤ 3299 := by exact_mod_cast hp3299
      linarith

theorem quantitative (hd : Dusart1999) (n : ℕ) (hn : 10712529 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  have he5 : exp (5 : ℝ) < 3273 :=
    (exp_lt_exp.mpr (by norm_num : (5 : ℝ) < 8)).trans exp_eight_small
  have hlog : (5 : ℝ) ≤ log 3273 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (5 : ℝ)) he5).le
  have hnn : (3273 : ℝ)^2 ≤ n := by exact_mod_cast hn
  exact LcmSurplus.quantitative_of_gap (gap_3273 hd) (by norm_num : (5 : ℝ) ≤ 5) hlog n hnn
end E1Tertiary.LcmAnalytic
