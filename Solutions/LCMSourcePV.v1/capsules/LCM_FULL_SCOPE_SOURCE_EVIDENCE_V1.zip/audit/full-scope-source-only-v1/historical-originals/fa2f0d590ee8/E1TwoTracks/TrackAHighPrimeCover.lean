/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import Mathlib

namespace E1TwoTracks.TrackAHighPrimeCover
open Real

/-- Exact integer search; the admissible upper endpoint is strict. -/
def next (a : ℕ) : Option ℕ :=
  (List.range ((85 * a - 1) / 84 - a)).reverse.findSome? fun k =>
    let p := a + 1 + k
    if Nat.Prime p then some p else none

/-- The recalibrated program fills a finite prime cover before the frozen literature tail. -/
def run : ℕ → ℕ → ℕ → List ℕ
  | 0, _, _ => []
  | fuel + 1, a, b =>
    if b ≤ a then [] else
      match next a with
      | none => []
      | some p => p :: run fuel p b

/-- An independent checker. Its specification covers every real input, not just integers. -/
def check (a b : ℕ) : List ℕ → Bool
  | [] => decide (b ≤ a)
  | p :: ps => decide (Nat.Prime p ∧ a < p ∧ 84 * p < 85 * a) && check p b ps

theorem sound (ps : List ℕ) {a b : ℕ} (hc : check a b ps = true)
    {x : ℝ} (ha : (a : ℝ) ≤ x) (hb : x < b) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 84 := by
  induction ps generalizing a with
  | nil =>
    have hba : b ≤ a := by simpa [check] using hc
    have hba' : (b : ℝ) ≤ a := by exact_mod_cast hba
    linarith
  | cons p ps ih =>
    have hh : (Nat.Prime p ∧ a < p ∧ 84 * p < 85 * a) ∧ check p b ps = true := by
      simpa [check] using hc
    by_cases hp : x < (p : ℝ)
    · refine ⟨p, hh.1.1, hp, ?_⟩
      have hr : (84 : ℝ) * p < 85 * a := by exact_mod_cast hh.1.2.2
      linarith
    · exact ih hh.2 (le_of_not_gt hp)

def start : ℕ := 1674
def tail : ℕ := 89693
def fuel : ℕ := 512
def output : List ℕ := run fuel start tail

/-- New finite output; consumer correctness uses the independent all-real checker theorem. -/
theorem execution : check start tail output = true := by native_decide

theorem covered {x : ℝ} (ha : (1674 : ℝ) ≤ x) (hb : x < 89693) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 84 :=
  sound output execution ha hb

end E1TwoTracks.TrackAHighPrimeCover
