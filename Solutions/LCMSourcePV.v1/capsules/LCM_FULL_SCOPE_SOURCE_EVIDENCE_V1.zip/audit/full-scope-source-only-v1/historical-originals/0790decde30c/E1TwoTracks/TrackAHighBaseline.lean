/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackAHighSurplus
import E1Tertiary.LcmResult
namespace E1TwoTracks.TrackAHighBaseline
open Real E1TwoTracks.TrackAHighConstant

/-- Current-frozen prime coverage alone extends analytically to3261 when the new analytic
consumer's1/84gap is used. No new finite prime search is involved. -/
theorem gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 3261 := by
  intro x hx
  by_cases hlarge : (3273 : ℝ) ≤ x
  · obtain ⟨p, hp, hpx, hpu⟩ := E1Tertiary.LcmResult.gap3273 hd x hlarge
    refine ⟨p, hp, hpx, ?_⟩
    have hxp : 0 < x := by linarith
    linarith
  · obtain ⟨p, hp, hpl, hpu⟩ := E1Tertiary.LcmResult.gap3273 hd 3273 (by norm_num)
    have hp3300 : (p : ℝ) < 3300 := by linarith
    have hpn : p ≤ 3299 := by
      have : p < 3300 := by exact_mod_cast hp3300
      omega
    have hpr : (p : ℝ) ≤ 3299 := by exact_mod_cast hpn
    exact ⟨p, hp, by linarith, by linarith⟩

theorem exp_seven_small : exp (7 : ℝ) < 3261 := by
  have he : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
  calc exp (7 : ℝ) = (exp 1)^7 := by rw [Real.exp_one_pow]; norm_num
    _ ≤ (3 : ℝ)^7 := pow_le_pow_left₀ (exp_pos 1).le he.le 7
    _ < 3261 := by norm_num

/-- Stronger shared frozen-evidence analytic result after adopting the new consumer. -/
theorem quantitative (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 10634121 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 3 / (20 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  have hlog : (7 : ℝ) ≤ Real.log 3261 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (7 : ℝ)) exp_seven_small).le
  have hnn : (3261 : ℝ)^2 ≤ n := by exact_mod_cast hn
  exact TrackAHighSurplus.quantitative_of_gap (gap hd) (by norm_num : (7 : ℝ) ≤ 7) hlog n hnn
end E1TwoTracks.TrackAHighBaseline
