/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackAHighSurplus
import E1Tertiary.LcmTail
namespace E1TwoTracks.TrackAHighHistorical
open Real E1TwoTracks.TrackAHighConstant

/-- Historical frozen 2018 tail, with the new analytic gap and margin parameters. -/
theorem gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 89693 := by
  intro x hx
  obtain ⟨p, hp, hpx, hpu⟩ := E1Tertiary.LcmTail.gap hd x hx
  refine ⟨p, hp, hpx, ?_⟩
  have hxp : 0 < x := by linarith
  linarith

/-- Historical NoPV gets all later analytic advances, including the stronger margin. -/
theorem quantitative (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 8044834249 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 3 / (20 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  have he : exp (7 : ℝ) < 89693 := by
    have he1 : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
    calc exp (7 : ℝ) = (exp 1)^7 := by rw [Real.exp_one_pow]; norm_num
      _ ≤ (3 : ℝ)^7 := pow_le_pow_left₀ (exp_pos 1).le he1.le 7
      _ < 89693 := by norm_num
  have hlog : (7 : ℝ) ≤ Real.log 89693 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (7 : ℝ)) he).le
  have hnn : (89693 : ℝ)^2 ≤ n := by exact_mod_cast hn
  exact TrackAHighSurplus.quantitative_of_gap (gap hd) (by norm_num : (7 : ℝ) ≤ 7) hlog n hnn
end E1TwoTracks.TrackAHighHistorical
