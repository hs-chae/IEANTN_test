/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1Tertiary.PrimeCover
import E1Tertiary.LcmConstant
import E1Tertiary.LcmTail
namespace E1Tertiary.LcmResult
open Real
open E1Tertiary.LcmConstant

theorem exp_five_small : exp (5 : ℝ) < 4096 := LcmTail.exp_five_small

theorem gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 4096 := by
  intro x hx
  by_cases ht : x < 89693
  · exact PrimeCover.covered hx ht
  · exact LcmTail.gap hd x (le_of_not_gt ht)

theorem not_highly_abundant (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 16777216 ≤ n) :
    ¬ Lcm.v2.HighlyAbundant (Nat.lcmUpto n) := by
  have hlog : (5 : ℝ) ≤ log 4096 := by
    have hh := log_lt_log (exp_pos (5 : ℝ)) exp_five_small
    simpa only [log_exp] using hh.le
  have hnn : (4096 : ℝ)^2 ≤ n := by exact_mod_cast hn
  exact L_not_HA_of_ge (gap hd) (c := 5) (by norm_num) hlog n hnn

theorem gap3273 (hd : Dusart2018.v1.proposition_5_4) : StrictGap 3273 := by
  intro x hx
  by_cases ht : x < 89693
  · exact PrimeCover.covered3273 hx ht
  · exact LcmTail.gap hd x (le_of_not_gt ht)

end E1Tertiary.LcmResult
