/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
/- New source-criterion constructor: adaptive blocks, a two-dimensional search
for large-prime witnesses, certified 2-adic gain, and exact rounding loss. -/
import E1TwoTracks.TrackBProgram
import E1TwoTracks.TrackBExactCheck
import E1Tertiary.LcmFinal
namespace E1TwoTracks.TrackB
set_option maxRecDepth 10000
set_option maxHeartbeats 3000000

def shrinkExact : ℕ → Block → Option Block
  | 0, b => if b.exactCheck then some b else none
  | k+1, b => if b.exactCheck then some b else
      if b.hi ≤ b.lo then none else
        shrinkExact k {b with hi := b.lo + (b.hi-b.lo)/2}

def chooseExactQ0 (primeFuel fitFuel lo stop p0 p1 p2 q1 q2 : ℕ) : ℕ → ℕ → Option Block
  | 0, _ => none
  | fuel+1, top => do
      let q0 ← prevPrime primeFuel top
      let b : Block := ⟨lo,min (p0^2-1) (stop-1),p0,p1,p2,q0,q1,q2⟩
      let candidate := if (b.Q/(4*b.P))%8=0 then shrinkExact fitFuel b else none
      match candidate with
      | some b => pure b
      | none => chooseExactQ0 primeFuel fitFuel lo stop p0 p1 p2 q1 q2 fuel (q0-1)

def chooseExactQ1 (primeFuel fitFuel q0Fuel lo stop p0 p1 p2 q2 : ℕ) : ℕ → ℕ → Option Block
  | 0, _ => none
  | fuel+1, top => do
      let q1 ← prevPrime primeFuel top
      match chooseExactQ0 primeFuel fitFuel lo stop p0 p1 p2 q1 q2 q0Fuel (q1-1) with
      | some b => pure b
      | none => chooseExactQ1 primeFuel fitFuel q0Fuel lo stop p0 p1 p2 q2 fuel (q1-1)

def makeExact (primeFuel fitFuel q0Fuel q1Fuel lo stop : ℕ) : Option Block := do
  let p0 ← nextPrime primeFuel (Nat.sqrt lo+1)
  let p1 ← nextPrime primeFuel (p0+1)
  let p2 ← nextPrime primeFuel (p1+1)
  let q2 ← prevPrime primeFuel (lo-1)
  chooseExactQ1 primeFuel fitFuel q0Fuel lo stop p0 p1 p2 q2 q1Fuel (q2-1)

def runExact (primeFuel fitFuel q0Fuel q1Fuel : ℕ) : ℕ → ℕ → ℕ → Option (List Block)
  | 0, lo, stop => if stop ≤ lo then some [] else none
  | fuel+1, lo, stop => if stop ≤ lo then some [] else do
      let b ← makeExact primeFuel fitFuel q0Fuel q1Fuel lo stop
      let bs ← runExact primeFuel fitFuel q0Fuel q1Fuel fuel (b.hi+1) stop
      pure (b::bs)

def checkExact : ℕ → ℕ → List Block → Bool
  | lo, stop, [] => decide (stop ≤ lo)
  | lo, stop, b::bs => decide (b.lo=lo) && b.exactCheck && checkExact (b.hi+1) stop bs

theorem exactSound (lo stop : ℕ) (bs : List Block) (hb : checkExact lo stop bs = true)
    (n : ℕ) (hn : lo ≤ n ∧ n < stop) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  induction bs generalizing lo with
  | nil => simp only [checkExact, decide_eq_true_eq] at hb; omega
  | cons b bs ih =>
      simp only [checkExact, Bool.and_eq_true, decide_eq_true_eq] at hb
      rcases hb with ⟨⟨hlo,hv⟩,ht⟩
      by_cases hnh : n ≤ b.hi
      · exact b.exactSound hv n (hlo ▸ hn.1) hnh
      · exact ih (b.hi+1) ht ⟨by omega,hn.2⟩

def exactStart : ℕ := 81000
def exactStop : ℕ := 10712529
def exactOutput : List Block := (runExact 1000 30 32 16 1024 exactStart exactStop).getD []

theorem exactExecution :
    (runExact 1000 30 32 16 1024 exactStart exactStop).isSome = true ∧
    checkExact exactStart exactStop exactOutput = true ∧ exactOutput.length = 404 := by native_decide

/-- New finite quantitative theorem, independent of every literature contract. -/
theorem exactFinite (n : ℕ) (hn : exactStart ≤ n ∧ n < exactStop) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m :=
  exactSound exactStart exactStop exactOutput exactExecution.2.1 n hn

/-- Uniform quantitative ray from a newly constructed and checked witness cover. -/
theorem exactQuantitative (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 81000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases h : n < exactStop
  · exact exactFinite n ⟨hn,h⟩
  · exact E1Tertiary.LcmFinal.quantitative hd n (by simpa only [exactStop] using Nat.le_of_not_lt h)

#eval IO.println (Lean.toJson (exactOutput.map fun b => [b.lo,b.hi,b.p0,b.p1,b.p2,b.q0,b.q1,b.q2])).compress
#print axioms exactFinite
#print axioms exactQuantitative
end E1TwoTracks.TrackB
