import IEANTN.Nodes.Dual60Numerics.v1.Conclusions
import IEANTN.Nodes.PrimeGap256.v1.Conclusions
import IEANTN.Nodes.LCMDualEvolution.v1.Conclusions
import IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.Dual60TailV1
namespace IEANTN.Bridges.DualEvolutionV2
open Real
set_option Elab.async false
lemma exp_nine_small : exp (9 : ℝ) < 8468 := by
  have he : exp 1 < (87 / 32 : ℝ) := by linarith [Real.exp_one_lt_d9]
  calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
    _ ≤ (87 / 32 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le he.le 9
    _ < 8468 := by norm_num

theorem tail60 (hgap : PrimeGap256.v1.strict_gap) (n : ℕ) (hn : 71707024 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hlog : (9 : ℝ) ≤ log 8468 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) exp_nine_small).le
  have hreal : (8468 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  exact IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.Dual60TailV1.quantitative_of_gap (c := 9)
    (hgap) (by norm_num) hlog n hreal

theorem whole60 (hfinite : Dual60Numerics.v1.finite_surplus60)
    (hgap : PrimeGap256.v1.strict_gap) : LCMDualEvolution.v1.whole_ray60 := by
  intro n hn
  by_cases h : n < 71707024
  · exact hfinite n ⟨hn,h⟩
  · exact tail60 hgap n (Nat.le_of_not_lt h)
#print axioms whole60
end IEANTN.Bridges.DualEvolutionV2
