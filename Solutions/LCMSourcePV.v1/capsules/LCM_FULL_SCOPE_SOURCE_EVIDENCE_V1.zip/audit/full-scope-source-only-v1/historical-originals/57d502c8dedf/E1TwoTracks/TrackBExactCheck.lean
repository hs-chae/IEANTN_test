/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackBParityCheck
import E1TwoTracks.TrackBRawPowerMath
namespace E1TwoTracks.TrackB
open Finset Nat Real
open E1TwoTracks.TrackBRawBase
set_option maxHeartbeats 3000000

def Block.exactEndpoint (b : Block) (n : ℕ) : Prop :=
  64*(10*n+1)*b.A*b.D < 10*(64*n+31)*b.B*(4*b.P*(b.Q/(4*b.P):ℕ))
instance (b : Block) (n : ℕ) : Decidable (b.exactEndpoint n) := inferInstanceAs (Decidable (_ < _))
def Block.exactValid (b : Block) : Prop :=
  b.structureValid ∧ 4*b.P < b.Q ∧ (b.Q/(4*b.P):ℕ)%8=0 ∧ b.exactEndpoint b.lo ∧ b.exactEndpoint b.hi
instance (b : Block) : Decidable b.exactValid := inferInstanceAs (Decidable (_ ∧ _))
def Block.exactCheck (b : Block) : Bool := decide b.exactValid

theorem affine_endpoints_strict {a b c d l h x : ℝ}
    (hl : a*l+b < c*l+d) (hh : a*h+b < c*h+d) (hxl : l ≤ x) (hxh : x ≤ h) :
    a*x+b < c*x+d := by
  by_cases hac : a ≤ c
  · nlinarith [mul_nonneg (sub_nonneg.mpr hac) (sub_nonneg.mpr hxl)]
  · nlinarith [mul_nonneg (sub_nonneg.mpr (le_of_not_ge hac)) (sub_nonneg.mpr hxh)]

theorem Block.exactEndpointSound (b : Block) (hb : b.exactValid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    64*(10*(n:ℝ)+1)*b.A*b.D < 10*(64*(n:ℝ)+31)*b.B*(4*b.P*(b.Q/(4*b.P):ℕ)) := by
  have hl : 64*(10*(b.lo:ℝ)+1)*b.A*b.D < 10*(64*(b.lo:ℝ)+31)*b.B*(4*b.P*(b.Q/(4*b.P):ℕ)) := by exact_mod_cast hb.2.2.2.1
  have hh : 64*(10*(b.hi:ℝ)+1)*b.A*b.D < 10*(64*(b.hi:ℝ)+31)*b.B*(4*b.P*(b.Q/(4*b.P):ℕ)) := by exact_mod_cast hb.2.2.2.2
  have hn1 : (b.lo:ℝ) ≤ n := by exact_mod_cast hnl
  have hn2 : (n:ℝ) ≤ b.hi := by exact_mod_cast hnh
  have ha := affine_endpoints_strict
    (a := 640*(b.A:ℝ)*b.D) (b := 64*(b.A:ℝ)*b.D)
    (c := 640*(b.B:ℝ)*(4*b.P*(b.Q/(4*b.P):ℕ))) (d := 310*(b.B:ℝ)*(4*b.P*(b.Q/(4*b.P):ℕ)))
    (l := b.lo) (h := b.hi) (x := n) (by nlinarith [hl]) (by nlinarith [hh]) hn1 hn2
  nlinarith [ha]

theorem Block.exactRatio (b : Block) (hb : b.exactValid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    (1 + 1 / (10*(n:ℝ))) * ∏ i, (1 + (1:ℝ) / b.q i) <
      (∏ i, (1 + 1 / (b.p i * (b.p i+1):ℝ))) * (1 + 31 / (64*(n:ℝ))) *
      ((4 * ∏ i, (b.p i:ℝ)) * (b.Q/(4*b.P):ℕ) / ∏ i, (b.q i:ℝ)) := by
  rcases hb with ⟨⟨hl, hle, hs, hpq, hql, hp0, hp1, hp2, hq0, hq1, hq2, hp01, hp12, hq01, hq12⟩, hsize, heven, helo, hehi⟩
  have hn : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (lt_of_lt_of_le (by decide : 0 < 1) hl) hnl)
  have hp0' : (0:ℝ) < b.p0 := by exact_mod_cast hp0.pos
  have hp1' : (0:ℝ) < b.p1 := by exact_mod_cast hp1.pos
  have hp2' : (0:ℝ) < b.p2 := by exact_mod_cast hp2.pos
  have hq0' : (0:ℝ) < b.q0 := by exact_mod_cast hq0.pos
  have hq1' : (0:ℝ) < b.q1 := by exact_mod_cast hq1.pos
  have hq2' : (0:ℝ) < b.q2 := by exact_mod_cast hq2.pos
  have hD : (0:ℝ) < b.D := by dsimp [Block.D]; push_cast; positivity
  have hQ : (0:ℝ) < b.Q := by dsimp [Block.Q]; push_cast; positivity
  have hratQ : (∏ i, (1 + (1:ℝ) / b.q i)) = (b.A:ℝ)/b.Q := by
    simp [Fin.prod_univ_three, Block.q, Block.A, Block.Q]
    field_simp
    <;> ring
  have hratP : (∏ i, (1 + 1 / (b.p i * (b.p i+1):ℝ))) = (b.B:ℝ)/b.D := by
    simp [Fin.prod_univ_three, Block.p, Block.B, Block.D]
    field_simp
    <;> ring
  have hprodP : (∏ i, (b.p i:ℝ)) = (b.P:ℝ) := by simp [Fin.prod_univ_three, Block.p, Block.P]
  have hprodQ : (∏ i, (b.q i:ℝ)) = (b.Q:ℝ) := by simp [Fin.prod_univ_three, Block.q, Block.Q]
  rw [hratQ, hratP, hprodP, hprodQ]
  have he := b.exactEndpointSound ⟨⟨hl, hle, hs, hpq, hql, hp0, hp1, hp2, hq0, hq1, hq2, hp01, hp12, hq01, hq12⟩, hsize, heven, helo, hehi⟩ n hnl hnh
  apply (mul_lt_mul_iff_right₀ (show (0:ℝ) < 640*n*b.D*b.Q by positivity)).mp
  convert he using 1 <;> (try rfl) <;> (try field_simp [ne_of_gt hn, ne_of_gt hD, ne_of_gt hQ]) <;> push_cast <;> ring

noncomputable def Block.exactCriterion (b : Block) (hb : b.exactValid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) : RawCriterion where
  n := n
  hn := hb.1.1.trans hnl
  p := b.p
  hp := by rcases hb.1 with ⟨_, _, _, _, _, h0, h1, h2, _⟩; intro i; fin_cases i <;> assumption
  hp_mono := by
    rcases hb.1 with ⟨_, _, _, _, _, _, _, _, _, _, _, h01, h12, _⟩
    intro i j hij; fin_cases i <;> fin_cases j <;> simp_all [Block.p] <;> omega
  q := b.q
  hq := by rcases hb.1 with ⟨_, _, _, _, _, _, _, _, h0, h1, h2, _⟩; intro i; fin_cases i <;> assumption
  hq_mono := by
    rcases hb.1 with ⟨_, _, _, _, _, _, _, _, _, _, _, _, _, h01, h12⟩
    intro i j hij; fin_cases i <;> fin_cases j <;> simp_all [Block.q] <;> omega
  h_ord_1 := by
    have hs : (n:ℝ) < (b.p0:ℝ)^2 := by exact_mod_cast (lt_of_le_of_lt hnh hb.1.2.2.1)
    have hp : (0:ℝ) ≤ b.p0 := by positivity
    simpa [Block.p] using (Real.sqrt_lt (by positivity) hp).mpr hs
  h_ord_2 := hb.1.2.2.2.1
  h_ord_3 := hb.1.2.2.2.2.1.trans_le hnl
  h_product := by simpa [Block.P, Block.Q, Block.p, Block.q, Fin.prod_univ_three] using hb.2.1

theorem Block.exactDiv (b : Block) (hb : b.exactValid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) : 2^3 ∣ (b.exactCriterion hb n hnl hnh).m := by
  have h := Nat.dvd_of_mod_eq_zero hb.2.2.1
  simpa [Block.exactCriterion, E1TwoTracks.TrackBRawBase.RawCriterion.m,
    Block.P, Block.Q, Block.p, Block.q, Fin.prod_univ_three] using h

theorem Block.exactSound (b : Block) (hb : b.exactCheck = true) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hv : b.exactValid := of_decide_eq_true hb
  let c := b.exactCriterion hv n hnl hnh
  refine ⟨c.M,c.M_lt,?_⟩
  have h := b.exactRatio hv n hnl hnh
  have hgamma : (1-(1/2:ℝ)^(3+2))/(2*(n:ℝ)) = 31/(64*(n:ℝ)) := by norm_num <;> field_simp <;> ring
  have hh : (1 + 1/(10*(n:ℝ))) * ∏ i, (1 + (1:ℝ)/c.q i) <
      (∏ i, (1 + 1/(c.p i*(c.p i+1):ℝ))) * (1 + (1-(1/2:ℝ)^(3+2))/(2*c.n)) *
        ((4*∏ i,(c.p i:ℝ))*c.m/∏ i,(c.q i:ℝ)) := by
    dsimp only [c, Block.exactCriterion]
    rw [hgamma]
    simpa [RawCriterion.m, Block.P, Block.Q, Block.p, Block.q, Fin.prod_univ_three] using h
  exact E1TwoTracks.TrackBRawPowerMath.criterion_surplus_exact c 3 (b.exactDiv hv n hnl hnh) (by positivity) hh

end E1TwoTracks.TrackB
