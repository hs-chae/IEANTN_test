/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.KernelSharpConstant
import IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.DualAdicMathV1
namespace IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.Dual60TailV1
open Finset Nat Real IEANTN.Bridges.DualEvolutionSupportV2.E1Tertiary.LcmBase IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.KernelSharpConstant
set_option Elab.async false
set_option maxHeartbeats 2000000
/-- New internal core72 independent2/3-adic transport for the OLD relative-gap1/256 provider; margin3/5. -/
theorem scalar_surplus {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (4096 ^ 2 : ℝ)) :
    (1 + 3 * ε / 5) * (1 + 3.024 * ε + 3.05 * ε^2 + 1.03 * ε^3) ≤
      1 + 3.66 * ε - 0.02 * ε^2 := by
  have h2 : ε^2 ≤ ε / 4096^2 := by nlinarith
  have h3 : ε^3 ≤ ε^2 / 4096^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hε.2)]
  have h4 : ε^4 ≤ ε^2 / 4096^4 := by
    have := mul_le_mul_of_nonneg_right h3 hε.1
    nlinarith
  nlinarith [sq_nonneg ε]

theorem prod_epsilon_ge72 {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (4096 ^ 2 : ℝ)) :
    (∏ i : Fin 3,
      (1 + ε / (((257 / 256) : ℝ) ^ (2 * ((i : ℕ) + 1 : ℝ))) *
        (1 / (1 + 1 / 4096)))) *
      (1 + (317 : ℝ) / 432 * ε) * (1 - 72 * ((257 / 256) : ℝ) ^ 12 / 4096 * ε) ≥
      1 + 3.66 * ε - 0.02 * ε ^ 2 := by
  norm_cast
  norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg hε.left 3, pow_nonneg hε.left 4, hε.1, hε.2]

theorem pq_ratio_ge72 {c X₀ : ℝ} {n : ℕ} (hd : StrictGap X₀)
    (hc : 9 ≤ c) (hcX : c ≤ log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    1 - ((72 : ℝ) * ∏ i, ((exists_p_primes hd hc hcX hn).choose i : ℝ)) /
      ∏ i, ((exists_q_primes hd hc hcX hn).choose i : ℝ) ≥
    1 - 72 * (1 + (1 / 256 : ℝ)) ^ 12 / n ^ (3 / 2 : ℝ) := by
  have h := KernelSharpConstant.pq_ratio_ge hd hc hcX hn
  simp only [div_eq_mul_inv] at h ⊢
  nlinarith [h]

/-- The same original product criterion, keeping its natural quantitative slack. -/
theorem comparison {c X₀ : ℝ} {n : ℕ} (hd : StrictGap X₀)
    (hc : 9 ≤ c) (hcX : c ≤ log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    let C := KernelSharpConstant.Criterion.mk' hd hc hcX hn
    (1 + 3 / (5 * (n : ℝ))) * ∏ i, (1 + (1 : ℝ) / C.q i) ≤
      (∏ i, (1 + 1 / (C.p i * (C.p i + 1) : ℝ))) *
      (1 + 317 / (432 * (n : ℝ))) *
      (1 - 72 * (∏ i, (C.p i : ℝ)) / ∏ i, (C.q i : ℝ)) := by
  dsimp only [KernelSharpConstant.Criterion.mk']
  have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  have hngt := hn_gt hd hc hcX hn
  have hn₀ : 0 ≤ Real.log √(n : ℝ) := (hlog_pos hd hc hcX hn).le
  have h₁ : 1 - (72 : ℝ) *
      (∏ i, (exists_p_primes hd hc hcX hn).choose i : ℝ) /
        ∏ i, ((exists_q_primes hd hc hcX hn).choose i : ℝ) ≥
      1 - 72 * (1 + 1 / 256 : ℝ) ^ 12 * ((1 / 4096) * (1 / n)) := by
    grw [pq_ratio_ge72 hd hc hcX hn,
      ← inv_n_pow_3_div_2_le hd hc hcX hn]
    simp [field]
  have hnn : 0 ≤ 1 - 72 * (1 + 1 / 256 : ℝ) ^ 12 * ((1 / 4096) * (1 / n)) := by
    have : (1 : ℝ) / n ≤ 1 / 4096 ^ 2 := by
      rw [div_le_div_iff₀ hnp (by norm_num)]; linarith
    nlinarith
  have := hnn.trans h₁
  have hn' : (0 : ℝ) ≤ 1 / (n : ℝ) ∧ (1 : ℝ) / (n : ℝ) ≤ 1 / 4096 ^ 2 :=
    ⟨by positivity, by rw [div_le_div_iff₀ hnp (by norm_num)]; linarith⟩
  grw [prod_q_ge hd hc hcX hn, prod_p_ge hd hc hcX hn, h₁]
  simp_rw [div_eq_mul_one_div (_ ^ (_ : ℝ) : ℝ) (n : ℝ),
    show 317 / (432 * (n : ℝ)) = 317 / 432 * (1 / n) by field_simp, ← one_div_mul_one_div]
  grw [inv_n_add_sqrt_ge hd hc hcX hn]
  set ε : ℝ := 1 / (n : ℝ)
  calc
    _ ≤ (1 + (3 / 5 : ℝ) * ε) * ∏ i : Fin 3, (1 + (1 + 1 / 256 : ℝ) ^ (i + 1 : ℝ) * ε) := by gcongr <;> dsimp [ε] <;> ring_nf <;> exact le_rfl
    _ = (1 + 3 * ε / 5) * ∏ i : Fin 3, (1 + ((257 / 256) : ℝ) ^ (i + 1 : ℝ) * ε) := by norm_num <;> ring_nf <;> simp
    _ ≤ (1 + 3 * ε / 5) * (1 + 3.024 * ε + 3.05 * ε^2 + 1.03 * ε^3) :=
        mul_le_mul_of_nonneg_left (KernelSharpConstant.prod_epsilon_le (ε := ε) hn') (by positivity)
    _ ≤ _ := scalar_surplus hn'
    _ ≤ _ := by
      grw [← prod_epsilon_ge72 hn']
      apply le_of_eq
      simp [field]
      ring_nf

/-- New independent2/3 exponent analytic transport; old relative gap1/256, coefficient3/5. -/
theorem quantitative_of_gap {c X₀ : ℝ} (hd : StrictGap X₀)
    (hc : 9 ≤ c) (hcX : c ≤ Real.log X₀) (n : ℕ) (hn : X₀^2 ≤ (n:ℝ)) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1+3/(5*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  let C := KernelSharpConstant.Criterion.mk' hd hc hcX hn
  have hr := comparison hd hc hcX hn
  change (1+3/(5*(n:ℝ))) * ∏ i,(1+(1:ℝ)/C.q i) ≤
    (∏ i,(1+1/(C.p i*(C.p i+1):ℝ))) * (1+317/(432*(n:ℝ))) *
    (1-72*(∏ i,(C.p i:ℝ))/∏ i,(C.q i:ℝ)) at hr
  have hnp : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num:0<1) C.hn)
  have hQ : (0:ℝ) < ∏ i,(C.q i:ℝ) := Finset.prod_pos fun i _ => by exact_mod_cast (C.hq i).pos
  have hR : (0:ℝ) < 1-72*(∏ i,(C.p i:ℝ))/∏ i,(C.q i:ℝ) := by
    have hA : (0:ℝ) < (1+3/(5*(n:ℝ))) * ∏ i,(1+(1:ℝ)/C.q i) :=
      mul_pos (by positivity) (Finset.prod_pos fun i _ => by positivity)
    have hB : (0:ℝ) < (∏ i,(1+1/(C.p i*(C.p i+1):ℝ))) * (1+317/(432*(n:ℝ))) := by positivity
    by_contra hbad
    have hh := mul_nonpos_of_nonneg_of_nonpos hB.le (le_of_not_gt hbad)
    linarith
  let D : IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.DualAdicBaseV1.PowerCriterion := {
    k := 3
    hk := by norm_num
    l := 2
    hl := by norm_num
    n := n
    hn := C.hn
    p := C.p
    hp := C.hp
    hp_mono := C.hp_mono
    hthree := by
      have hs := hsqrt_gt hd hc hcX hn
      have hp : √(n:ℝ) < C.p 0 := C.h_ord_1
      have : (3:ℝ) < C.p 0 := by linarith
      exact_mod_cast this
    q := C.q
    hq := C.hq
    hq_mono := C.hq_mono
    h_ord_1 := C.h_ord_1
    h_ord_2 := C.h_ord_2
    h_ord_3 := C.h_ord_3
    h_product := by
      rw [sub_pos,div_lt_one hQ] at hR
      norm_num only [Nat.reducePow]
      exact_mod_cast hR
  }
  have hcore : (1+317/(432*(n:ℝ))) ≤
      IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.DualAdicMathV1.core2 D * IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.DualAdicMathV1.core3 D := by
    dsimp [IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.DualAdicMathV1.core2,IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.DualAdicMathV1.core3,D]
    norm_num
    field_simp
    nlinarith [sq_nonneg (n:ℝ)]
  refine ⟨D.M,D.M_pos,D.M_lt,?_⟩
  apply IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.DualAdicMathV1.criterion_surplus D (t:=3/(5*(n:ℝ))) (by positivity)
  have hm := mul_le_mul_of_nonneg_left hcore
    (show (0:ℝ) ≤ (∏ i,(1+1/(C.p i*(C.p i+1):ℝ))) *
      (1-72*(∏ i,(C.p i:ℝ))/∏ i,(C.q i:ℝ)) from mul_nonneg (by positivity) hR.le)
  norm_num [D] at *
  nlinarith
#print axioms quantitative_of_gap
end IEANTN.Bridges.DualEvolutionSupportV2.ExposureEvolution.Dual60TailV1
