import ExposureEvolution.StrongKernelData45
import ExposureEvolution.StrongKernelBlocks45_000
import ExposureEvolution.StrongKernelBlocks45_001
import ExposureEvolution.StrongKernelBlocks45_002
import ExposureEvolution.StrongKernelBlocks45_003
import ExposureEvolution.StrongKernelBlocks45_004
import ExposureEvolution.StrongKernelBlocks45_005
import ExposureEvolution.StrongKernelBlocks45_006
import ExposureEvolution.StrongKernelBlocks45_007
import ExposureEvolution.StrongKernelBlocks45_008
import ExposureEvolution.StrongKernelBlocks45_009
import ExposureEvolution.StrongKernelBlocks45_010
import ExposureEvolution.StrongKernelBlocks45_011
import ExposureEvolution.StrongKernelBlocks45_012
import ExposureEvolution.StrongKernelBlocks45_013
import ExposureEvolution.StrongKernelBlocks45_014
import ExposureEvolution.StrongKernelBlocks45_015
import ExposureEvolution.StrongKernelBlocks45_016
import ExposureEvolution.StrongKernelBlocks45_017
import ExposureEvolution.StrongKernelBlocks45_018
import ExposureEvolution.StrongKernelBlocks45_019
import ExposureEvolution.StrongKernelBlocks45_020
import ExposureEvolution.StrongKernelBlocks45_021
import ExposureEvolution.StrongKernelBlocks45_022
import ExposureEvolution.StrongKernelBlocks45_023
import ExposureEvolution.StrongKernelBlocks45_024
import ExposureEvolution.StrongKernelBlocks45_025
import ExposureEvolution.StrongKernelBlocks45_026
import ExposureEvolution.StrongKernelBlocks45_027
import ExposureEvolution.StrongKernelBlocks45_028
import ExposureEvolution.StrongKernelBlocks45_029
import ExposureEvolution.StrongKernelBlocks45_030
import ExposureEvolution.StrongKernelBlocks45_031
import ExposureEvolution.StrongKernelBlocks45_032
import ExposureEvolution.StrongKernelBlocks45_033
import ExposureEvolution.StrongKernelBlocks45_034
import ExposureEvolution.StrongKernelBlocks45_035
import ExposureEvolution.StrongKernelBlocks45_036
import ExposureEvolution.StrongKernelBlocks45_037
import ExposureEvolution.StrongKernelBlocks45_038
import ExposureEvolution.StrongKernelBlocks45_039
import ExposureEvolution.StrongKernelBlocks45_040
import ExposureEvolution.StrongKernelBlocks45_041
import ExposureEvolution.StrongKernelBlocks45_042
import ExposureEvolution.StrongKernelBlocks45_043
import ExposureEvolution.StrongKernelBlocks45_044
import ExposureEvolution.StrongKernelBlocks45_045
import ExposureEvolution.StrongKernelBlocks45_046
import ExposureEvolution.StrongKernelBlocks45_047
import ExposureEvolution.StrongKernelBlocks45_048
import ExposureEvolution.StrongKernelBlocks45_049
import ExposureEvolution.StrongKernelBlocks45_050
import ExposureEvolution.StrongKernelBlocks45_051
import ExposureEvolution.StrongKernelBlocks45_052
import ExposureEvolution.StrongKernelBlocks45_053
import ExposureEvolution.StrongKernelBlocks45_054
import ExposureEvolution.StrongKernelBlocks45_055
import ExposureEvolution.StrongKernelBlocks45_056
import ExposureEvolution.StrongKernelBlocks45_057
import ExposureEvolution.StrongKernelBlocks45_058
import ExposureEvolution.StrongKernelBlocks45_059
import ExposureEvolution.StrongKernelBlocks45_060
import ExposureEvolution.StrongKernelBlocks45_061
import ExposureEvolution.StrongKernelBlocks45_062
import ExposureEvolution.StrongKernelBlocks45_063
import ExposureEvolution.StrongKernelBlocks45_064
import ExposureEvolution.StrongKernelBlocks45_065
import ExposureEvolution.StrongKernelBlocks45_066
import ExposureEvolution.StrongKernelBlocks45_067
import ExposureEvolution.StrongKernelBlocks45_068
import ExposureEvolution.StrongKernelBlocks45_069
import ExposureEvolution.StrongKernelBlocks45_070
import ExposureEvolution.StrongKernelBlocks45_071
import ExposureEvolution.StrongKernelBlocks45_072
import ExposureEvolution.StrongKernelBlocks45_073
import ExposureEvolution.StrongKernelBlocks45_074
import ExposureEvolution.StrongKernelBlocks45_075
import ExposureEvolution.StrongKernelBlocks45_076
import ExposureEvolution.StrongKernelBlocks45_077
import ExposureEvolution.StrongKernelBlocks45_078
namespace ExposureEvolution.StrongKernelCoverage45
open ExposureEvolution.Adaptive45
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem chunk_identity000 : ExposureEvolution.StrongKernelData45.chunk000 =
    ExposureEvolution.StrongKernelBlocks45_000.witnesses ++ ExposureEvolution.StrongKernelBlocks45_001.witnesses := by rfl

theorem chunk_identity001 : ExposureEvolution.StrongKernelData45.chunk001 =
    ExposureEvolution.StrongKernelBlocks45_002.witnesses ++ ExposureEvolution.StrongKernelBlocks45_003.witnesses := by rfl

theorem chunk_identity002 : ExposureEvolution.StrongKernelData45.chunk002 =
    ExposureEvolution.StrongKernelBlocks45_004.witnesses ++ ExposureEvolution.StrongKernelBlocks45_005.witnesses := by rfl

theorem chunk_identity003 : ExposureEvolution.StrongKernelData45.chunk003 =
    ExposureEvolution.StrongKernelBlocks45_006.witnesses ++ ExposureEvolution.StrongKernelBlocks45_007.witnesses := by rfl

theorem chunk_identity004 : ExposureEvolution.StrongKernelData45.chunk004 =
    ExposureEvolution.StrongKernelBlocks45_008.witnesses ++ ExposureEvolution.StrongKernelBlocks45_009.witnesses := by rfl

theorem chunk_identity005 : ExposureEvolution.StrongKernelData45.chunk005 =
    ExposureEvolution.StrongKernelBlocks45_010.witnesses ++ ExposureEvolution.StrongKernelBlocks45_011.witnesses := by rfl

theorem chunk_identity006 : ExposureEvolution.StrongKernelData45.chunk006 =
    ExposureEvolution.StrongKernelBlocks45_012.witnesses ++ ExposureEvolution.StrongKernelBlocks45_013.witnesses := by rfl

theorem chunk_identity007 : ExposureEvolution.StrongKernelData45.chunk007 =
    ExposureEvolution.StrongKernelBlocks45_014.witnesses ++ ExposureEvolution.StrongKernelBlocks45_015.witnesses := by rfl

theorem chunk_identity008 : ExposureEvolution.StrongKernelData45.chunk008 =
    ExposureEvolution.StrongKernelBlocks45_016.witnesses ++ ExposureEvolution.StrongKernelBlocks45_017.witnesses := by rfl

theorem chunk_identity009 : ExposureEvolution.StrongKernelData45.chunk009 =
    ExposureEvolution.StrongKernelBlocks45_018.witnesses ++ ExposureEvolution.StrongKernelBlocks45_019.witnesses := by rfl

theorem chunk_identity010 : ExposureEvolution.StrongKernelData45.chunk010 =
    ExposureEvolution.StrongKernelBlocks45_020.witnesses ++ ExposureEvolution.StrongKernelBlocks45_021.witnesses := by rfl

theorem chunk_identity011 : ExposureEvolution.StrongKernelData45.chunk011 =
    ExposureEvolution.StrongKernelBlocks45_022.witnesses ++ ExposureEvolution.StrongKernelBlocks45_023.witnesses := by rfl

theorem chunk_identity012 : ExposureEvolution.StrongKernelData45.chunk012 =
    ExposureEvolution.StrongKernelBlocks45_024.witnesses ++ ExposureEvolution.StrongKernelBlocks45_025.witnesses := by rfl

theorem chunk_identity013 : ExposureEvolution.StrongKernelData45.chunk013 =
    ExposureEvolution.StrongKernelBlocks45_026.witnesses ++ ExposureEvolution.StrongKernelBlocks45_027.witnesses := by rfl

theorem chunk_identity014 : ExposureEvolution.StrongKernelData45.chunk014 =
    ExposureEvolution.StrongKernelBlocks45_028.witnesses ++ ExposureEvolution.StrongKernelBlocks45_029.witnesses := by rfl

theorem chunk_identity015 : ExposureEvolution.StrongKernelData45.chunk015 =
    ExposureEvolution.StrongKernelBlocks45_030.witnesses ++ ExposureEvolution.StrongKernelBlocks45_031.witnesses := by rfl

theorem chunk_identity016 : ExposureEvolution.StrongKernelData45.chunk016 =
    ExposureEvolution.StrongKernelBlocks45_032.witnesses ++ ExposureEvolution.StrongKernelBlocks45_033.witnesses := by rfl

theorem chunk_identity017 : ExposureEvolution.StrongKernelData45.chunk017 =
    ExposureEvolution.StrongKernelBlocks45_034.witnesses ++ ExposureEvolution.StrongKernelBlocks45_035.witnesses := by rfl

theorem chunk_identity018 : ExposureEvolution.StrongKernelData45.chunk018 =
    ExposureEvolution.StrongKernelBlocks45_036.witnesses ++ ExposureEvolution.StrongKernelBlocks45_037.witnesses := by rfl

theorem chunk_identity019 : ExposureEvolution.StrongKernelData45.chunk019 =
    ExposureEvolution.StrongKernelBlocks45_038.witnesses ++ ExposureEvolution.StrongKernelBlocks45_039.witnesses := by rfl

theorem chunk_identity020 : ExposureEvolution.StrongKernelData45.chunk020 =
    ExposureEvolution.StrongKernelBlocks45_040.witnesses ++ ExposureEvolution.StrongKernelBlocks45_041.witnesses := by rfl

theorem chunk_identity021 : ExposureEvolution.StrongKernelData45.chunk021 =
    ExposureEvolution.StrongKernelBlocks45_042.witnesses ++ ExposureEvolution.StrongKernelBlocks45_043.witnesses := by rfl

theorem chunk_identity022 : ExposureEvolution.StrongKernelData45.chunk022 =
    ExposureEvolution.StrongKernelBlocks45_044.witnesses ++ ExposureEvolution.StrongKernelBlocks45_045.witnesses := by rfl

theorem chunk_identity023 : ExposureEvolution.StrongKernelData45.chunk023 =
    ExposureEvolution.StrongKernelBlocks45_046.witnesses ++ ExposureEvolution.StrongKernelBlocks45_047.witnesses := by rfl

theorem chunk_identity024 : ExposureEvolution.StrongKernelData45.chunk024 =
    ExposureEvolution.StrongKernelBlocks45_048.witnesses ++ ExposureEvolution.StrongKernelBlocks45_049.witnesses := by rfl

theorem chunk_identity025 : ExposureEvolution.StrongKernelData45.chunk025 =
    ExposureEvolution.StrongKernelBlocks45_050.witnesses ++ ExposureEvolution.StrongKernelBlocks45_051.witnesses := by rfl

theorem chunk_identity026 : ExposureEvolution.StrongKernelData45.chunk026 =
    ExposureEvolution.StrongKernelBlocks45_052.witnesses ++ ExposureEvolution.StrongKernelBlocks45_053.witnesses := by rfl

theorem chunk_identity027 : ExposureEvolution.StrongKernelData45.chunk027 =
    ExposureEvolution.StrongKernelBlocks45_054.witnesses ++ ExposureEvolution.StrongKernelBlocks45_055.witnesses := by rfl

theorem chunk_identity028 : ExposureEvolution.StrongKernelData45.chunk028 =
    ExposureEvolution.StrongKernelBlocks45_056.witnesses ++ ExposureEvolution.StrongKernelBlocks45_057.witnesses := by rfl

theorem chunk_identity029 : ExposureEvolution.StrongKernelData45.chunk029 =
    ExposureEvolution.StrongKernelBlocks45_058.witnesses ++ ExposureEvolution.StrongKernelBlocks45_059.witnesses := by rfl

theorem chunk_identity030 : ExposureEvolution.StrongKernelData45.chunk030 =
    ExposureEvolution.StrongKernelBlocks45_060.witnesses ++ ExposureEvolution.StrongKernelBlocks45_061.witnesses := by rfl

theorem chunk_identity031 : ExposureEvolution.StrongKernelData45.chunk031 =
    ExposureEvolution.StrongKernelBlocks45_062.witnesses ++ ExposureEvolution.StrongKernelBlocks45_063.witnesses := by rfl

theorem chunk_identity032 : ExposureEvolution.StrongKernelData45.chunk032 =
    ExposureEvolution.StrongKernelBlocks45_064.witnesses ++ ExposureEvolution.StrongKernelBlocks45_065.witnesses := by rfl

theorem chunk_identity033 : ExposureEvolution.StrongKernelData45.chunk033 =
    ExposureEvolution.StrongKernelBlocks45_066.witnesses ++ ExposureEvolution.StrongKernelBlocks45_067.witnesses := by rfl

theorem chunk_identity034 : ExposureEvolution.StrongKernelData45.chunk034 =
    ExposureEvolution.StrongKernelBlocks45_068.witnesses ++ ExposureEvolution.StrongKernelBlocks45_069.witnesses := by rfl

theorem chunk_identity035 : ExposureEvolution.StrongKernelData45.chunk035 =
    ExposureEvolution.StrongKernelBlocks45_070.witnesses ++ ExposureEvolution.StrongKernelBlocks45_071.witnesses := by rfl

theorem chunk_identity036 : ExposureEvolution.StrongKernelData45.chunk036 =
    ExposureEvolution.StrongKernelBlocks45_072.witnesses ++ ExposureEvolution.StrongKernelBlocks45_073.witnesses := by rfl

theorem chunk_identity037 : ExposureEvolution.StrongKernelData45.chunk037 =
    ExposureEvolution.StrongKernelBlocks45_074.witnesses ++ ExposureEvolution.StrongKernelBlocks45_075.witnesses := by rfl

theorem chunk_identity038 : ExposureEvolution.StrongKernelData45.chunk038 =
    ExposureEvolution.StrongKernelBlocks45_076.witnesses ++ ExposureEvolution.StrongKernelBlocks45_077.witnesses := by rfl

theorem chunk_identity039 : ExposureEvolution.StrongKernelData45.chunk039 =
    ExposureEvolution.StrongKernelBlocks45_078.witnesses := by rfl

theorem same_values : ExposureEvolution.StrongKernelData45.witnesses =
  ExposureEvolution.StrongKernelBlocks45_000.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_001.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_002.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_003.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_004.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_005.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_006.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_007.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_008.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_009.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_010.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_011.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_012.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_013.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_014.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_015.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_016.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_017.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_018.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_019.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_020.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_021.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_022.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_023.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_024.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_025.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_026.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_027.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_028.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_029.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_030.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_031.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_032.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_033.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_034.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_035.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_036.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_037.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_038.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_039.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_040.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_041.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_042.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_043.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_044.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_045.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_046.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_047.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_048.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_049.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_050.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_051.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_052.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_053.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_054.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_055.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_056.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_057.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_058.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_059.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_060.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_061.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_062.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_063.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_064.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_065.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_066.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_067.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_068.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_069.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_070.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_071.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_072.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_073.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_074.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_075.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_076.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_077.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_078.witnesses := by
  simp only [ExposureEvolution.StrongKernelData45.witnesses,
    chunk_identity000,
    chunk_identity001,
    chunk_identity002,
    chunk_identity003,
    chunk_identity004,
    chunk_identity005,
    chunk_identity006,
    chunk_identity007,
    chunk_identity008,
    chunk_identity009,
    chunk_identity010,
    chunk_identity011,
    chunk_identity012,
    chunk_identity013,
    chunk_identity014,
    chunk_identity015,
    chunk_identity016,
    chunk_identity017,
    chunk_identity018,
    chunk_identity019,
    chunk_identity020,
    chunk_identity021,
    chunk_identity022,
    chunk_identity023,
    chunk_identity024,
    chunk_identity025,
    chunk_identity026,
    chunk_identity027,
    chunk_identity028,
    chunk_identity029,
    chunk_identity030,
    chunk_identity031,
    chunk_identity032,
    chunk_identity033,
    chunk_identity034,
    chunk_identity035,
    chunk_identity036,
    chunk_identity037,
    chunk_identity038,
    chunk_identity039, List.append_assoc]

theorem accepted : coverage 50000000 3461204224 ExposureEvolution.StrongKernelData45.witnesses = true := by
  have h : coverage 50000000 3461204224 (
    ExposureEvolution.StrongKernelBlocks45_000.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_001.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_002.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_003.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_004.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_005.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_006.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_007.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_008.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_009.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_010.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_011.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_012.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_013.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_014.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_015.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_016.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_017.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_018.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_019.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_020.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_021.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_022.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_023.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_024.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_025.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_026.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_027.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_028.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_029.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_030.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_031.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_032.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_033.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_034.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_035.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_036.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_037.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_038.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_039.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_040.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_041.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_042.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_043.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_044.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_045.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_046.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_047.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_048.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_049.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_050.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_051.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_052.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_053.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_054.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_055.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_056.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_057.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_058.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_059.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_060.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_061.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_062.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_063.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_064.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_065.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_066.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_067.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_068.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_069.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_070.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_071.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_072.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_073.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_074.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_075.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_076.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_077.witnesses ++
  ExposureEvolution.StrongKernelBlocks45_078.witnesses) = true := by
    apply ExposureEvolution.StrongKernelBlocks45_000.extend
    apply ExposureEvolution.StrongKernelBlocks45_001.extend
    apply ExposureEvolution.StrongKernelBlocks45_002.extend
    apply ExposureEvolution.StrongKernelBlocks45_003.extend
    apply ExposureEvolution.StrongKernelBlocks45_004.extend
    apply ExposureEvolution.StrongKernelBlocks45_005.extend
    apply ExposureEvolution.StrongKernelBlocks45_006.extend
    apply ExposureEvolution.StrongKernelBlocks45_007.extend
    apply ExposureEvolution.StrongKernelBlocks45_008.extend
    apply ExposureEvolution.StrongKernelBlocks45_009.extend
    apply ExposureEvolution.StrongKernelBlocks45_010.extend
    apply ExposureEvolution.StrongKernelBlocks45_011.extend
    apply ExposureEvolution.StrongKernelBlocks45_012.extend
    apply ExposureEvolution.StrongKernelBlocks45_013.extend
    apply ExposureEvolution.StrongKernelBlocks45_014.extend
    apply ExposureEvolution.StrongKernelBlocks45_015.extend
    apply ExposureEvolution.StrongKernelBlocks45_016.extend
    apply ExposureEvolution.StrongKernelBlocks45_017.extend
    apply ExposureEvolution.StrongKernelBlocks45_018.extend
    apply ExposureEvolution.StrongKernelBlocks45_019.extend
    apply ExposureEvolution.StrongKernelBlocks45_020.extend
    apply ExposureEvolution.StrongKernelBlocks45_021.extend
    apply ExposureEvolution.StrongKernelBlocks45_022.extend
    apply ExposureEvolution.StrongKernelBlocks45_023.extend
    apply ExposureEvolution.StrongKernelBlocks45_024.extend
    apply ExposureEvolution.StrongKernelBlocks45_025.extend
    apply ExposureEvolution.StrongKernelBlocks45_026.extend
    apply ExposureEvolution.StrongKernelBlocks45_027.extend
    apply ExposureEvolution.StrongKernelBlocks45_028.extend
    apply ExposureEvolution.StrongKernelBlocks45_029.extend
    apply ExposureEvolution.StrongKernelBlocks45_030.extend
    apply ExposureEvolution.StrongKernelBlocks45_031.extend
    apply ExposureEvolution.StrongKernelBlocks45_032.extend
    apply ExposureEvolution.StrongKernelBlocks45_033.extend
    apply ExposureEvolution.StrongKernelBlocks45_034.extend
    apply ExposureEvolution.StrongKernelBlocks45_035.extend
    apply ExposureEvolution.StrongKernelBlocks45_036.extend
    apply ExposureEvolution.StrongKernelBlocks45_037.extend
    apply ExposureEvolution.StrongKernelBlocks45_038.extend
    apply ExposureEvolution.StrongKernelBlocks45_039.extend
    apply ExposureEvolution.StrongKernelBlocks45_040.extend
    apply ExposureEvolution.StrongKernelBlocks45_041.extend
    apply ExposureEvolution.StrongKernelBlocks45_042.extend
    apply ExposureEvolution.StrongKernelBlocks45_043.extend
    apply ExposureEvolution.StrongKernelBlocks45_044.extend
    apply ExposureEvolution.StrongKernelBlocks45_045.extend
    apply ExposureEvolution.StrongKernelBlocks45_046.extend
    apply ExposureEvolution.StrongKernelBlocks45_047.extend
    apply ExposureEvolution.StrongKernelBlocks45_048.extend
    apply ExposureEvolution.StrongKernelBlocks45_049.extend
    apply ExposureEvolution.StrongKernelBlocks45_050.extend
    apply ExposureEvolution.StrongKernelBlocks45_051.extend
    apply ExposureEvolution.StrongKernelBlocks45_052.extend
    apply ExposureEvolution.StrongKernelBlocks45_053.extend
    apply ExposureEvolution.StrongKernelBlocks45_054.extend
    apply ExposureEvolution.StrongKernelBlocks45_055.extend
    apply ExposureEvolution.StrongKernelBlocks45_056.extend
    apply ExposureEvolution.StrongKernelBlocks45_057.extend
    apply ExposureEvolution.StrongKernelBlocks45_058.extend
    apply ExposureEvolution.StrongKernelBlocks45_059.extend
    apply ExposureEvolution.StrongKernelBlocks45_060.extend
    apply ExposureEvolution.StrongKernelBlocks45_061.extend
    apply ExposureEvolution.StrongKernelBlocks45_062.extend
    apply ExposureEvolution.StrongKernelBlocks45_063.extend
    apply ExposureEvolution.StrongKernelBlocks45_064.extend
    apply ExposureEvolution.StrongKernelBlocks45_065.extend
    apply ExposureEvolution.StrongKernelBlocks45_066.extend
    apply ExposureEvolution.StrongKernelBlocks45_067.extend
    apply ExposureEvolution.StrongKernelBlocks45_068.extend
    apply ExposureEvolution.StrongKernelBlocks45_069.extend
    apply ExposureEvolution.StrongKernelBlocks45_070.extend
    apply ExposureEvolution.StrongKernelBlocks45_071.extend
    apply ExposureEvolution.StrongKernelBlocks45_072.extend
    apply ExposureEvolution.StrongKernelBlocks45_073.extend
    apply ExposureEvolution.StrongKernelBlocks45_074.extend
    apply ExposureEvolution.StrongKernelBlocks45_075.extend
    apply ExposureEvolution.StrongKernelBlocks45_076.extend
    apply ExposureEvolution.StrongKernelBlocks45_077.extend
    apply ExposureEvolution.StrongKernelBlocks45_078.extend
    decide +kernel
  simpa only [same_values] using h

theorem finite (n : ℕ) (hn : 50000000 ≤ n ∧ n < 3461204224) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 9 / (20 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m :=
  coverage_sound 50000000 3461204224 ExposureEvolution.StrongKernelData45.witnesses accepted n hn

#print axioms accepted
#print axioms finite
end ExposureEvolution.StrongKernelCoverage45
