import ExposureEvolution.DirectOldJoinDataV1
import ExposureEvolution.KernelSharpSurplus
namespace ExposureEvolution.DirectOldJoinFinalV1
set_option Elab.async false
open Real

/-- The old source alone supplies the strict relative gap above its original threshold. -/
theorem source_gap (hd : Dusart2018.v1.proposition_5_4) :
    KernelSharpConstant.StrictGap 89693 := by
  intro x hx
  have hx0 : 0 < x := by linarith
  have he : exp (9 : ℝ) < 89693 := by
    have h1 : exp 1 < (3 : ℝ) := by linarith [Real.exp_one_lt_d9]
    calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
      _ ≤ (3 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le h1.le 9
      _ < 89693 := by norm_num
  have hl : 9 < log x := by
    simpa only [log_exp] using log_lt_log (exp_pos (9 : ℝ)) (he.trans_le hx)
  have hlp : 0 < log x := by linarith
  have hc : (256 : ℝ) < log x ^ 3 := by
    nlinarith [mul_pos (by linarith : 0 < log x - 9) (sq_pos_of_pos hlp)]
  obtain ⟨p, hp, hpx, hpu⟩ := hd x hx
  refine ⟨p, hp, hpx, hpu.trans_lt ?_⟩
  norm_num only [Real.rpow_ofNat]
  linarith [div_lt_div_of_pos_left hx0 (by norm_num : (0 : ℝ) < 256) hc]

lemma log_source_threshold : (9 : ℝ) ≤ log 89693 := by
  have h1 : exp 1 < (3 : ℝ) := by linarith [Real.exp_one_lt_d9]
  have he : exp (9 : ℝ) < 89693 := by
    calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
      _ ≤ (3 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le h1.le 9
      _ < 89693 := by norm_num
  simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) he).le

theorem tail (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 8044834249 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hreal : (89693 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  obtain ⟨m, hm, hσ⟩ := KernelSharpSurplus.quantitative_of_gap
    (c := 9) (source_gap hd) (by norm_num) log_source_threshold n hreal
  refine ⟨m, ?_, hm, hσ⟩
  by_contra hpos
  have hm0 : m = 0 := Nat.eq_zero_of_not_pos hpos
  have hσ' : (1 + 3 / (10 * (n : ℝ))) *
      (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) < 0 := by
    simpa [hm0] using hσ
  exact not_lt_of_ge (by positivity) hσ'

theorem whole_ray (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 1000000 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases h : n < 8044834249
  · exact DirectOldJoinDataV1.finite n ⟨hn, h⟩
  · exact tail hd n (Nat.le_of_not_lt h)

#print axioms source_gap
#print axioms tail
#print axioms whole_ray
end ExposureEvolution.DirectOldJoinFinalV1
