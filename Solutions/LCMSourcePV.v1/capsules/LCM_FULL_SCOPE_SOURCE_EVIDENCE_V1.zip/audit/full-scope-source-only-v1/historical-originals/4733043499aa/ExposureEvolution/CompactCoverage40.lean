import ExposureEvolution.CompactData40
import ExposureEvolution.CompactBlocks40_000
import ExposureEvolution.CompactBlocks40_001
import ExposureEvolution.CompactBlocks40_002
import ExposureEvolution.CompactBlocks40_003
import ExposureEvolution.CompactBlocks40_004
import ExposureEvolution.CompactBlocks40_005
import ExposureEvolution.CompactBlocks40_006
import ExposureEvolution.CompactBlocks40_007
import ExposureEvolution.CompactBlocks40_008
import ExposureEvolution.CompactBlocks40_009
import ExposureEvolution.CompactBlocks40_010
import ExposureEvolution.CompactBlocks40_011
namespace ExposureEvolution.CompactCoverage40
open ExposureEvolution.Adaptive40
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem chunk_identity000 : ExposureEvolution.CompactData40.chunk000 =
    ExposureEvolution.CompactBlocks40_000.witnesses ++ ExposureEvolution.CompactBlocks40_001.witnesses := by rfl

theorem chunk_identity001 : ExposureEvolution.CompactData40.chunk001 =
    ExposureEvolution.CompactBlocks40_002.witnesses ++ ExposureEvolution.CompactBlocks40_003.witnesses := by rfl

theorem chunk_identity002 : ExposureEvolution.CompactData40.chunk002 =
    ExposureEvolution.CompactBlocks40_004.witnesses ++ ExposureEvolution.CompactBlocks40_005.witnesses := by rfl

theorem chunk_identity003 : ExposureEvolution.CompactData40.chunk003 =
    ExposureEvolution.CompactBlocks40_006.witnesses ++ ExposureEvolution.CompactBlocks40_007.witnesses := by rfl

theorem chunk_identity004 : ExposureEvolution.CompactData40.chunk004 =
    ExposureEvolution.CompactBlocks40_008.witnesses ++ ExposureEvolution.CompactBlocks40_009.witnesses := by rfl

theorem chunk_identity005 : ExposureEvolution.CompactData40.chunk005 =
    ExposureEvolution.CompactBlocks40_010.witnesses ++ ExposureEvolution.CompactBlocks40_011.witnesses := by rfl

theorem same_values : ExposureEvolution.CompactData40.witnesses =
  ExposureEvolution.CompactBlocks40_000.witnesses ++
  ExposureEvolution.CompactBlocks40_001.witnesses ++
  ExposureEvolution.CompactBlocks40_002.witnesses ++
  ExposureEvolution.CompactBlocks40_003.witnesses ++
  ExposureEvolution.CompactBlocks40_004.witnesses ++
  ExposureEvolution.CompactBlocks40_005.witnesses ++
  ExposureEvolution.CompactBlocks40_006.witnesses ++
  ExposureEvolution.CompactBlocks40_007.witnesses ++
  ExposureEvolution.CompactBlocks40_008.witnesses ++
  ExposureEvolution.CompactBlocks40_009.witnesses ++
  ExposureEvolution.CompactBlocks40_010.witnesses ++
  ExposureEvolution.CompactBlocks40_011.witnesses := by
  simp only [ExposureEvolution.CompactData40.witnesses,
    chunk_identity000,
    chunk_identity001,
    chunk_identity002,
    chunk_identity003,
    chunk_identity004,
    chunk_identity005, List.append_assoc]

theorem accepted : coverage 4932841 71707024 ExposureEvolution.CompactData40.witnesses = true := by
  have h : coverage 4932841 71707024 (
    ExposureEvolution.CompactBlocks40_000.witnesses ++
  ExposureEvolution.CompactBlocks40_001.witnesses ++
  ExposureEvolution.CompactBlocks40_002.witnesses ++
  ExposureEvolution.CompactBlocks40_003.witnesses ++
  ExposureEvolution.CompactBlocks40_004.witnesses ++
  ExposureEvolution.CompactBlocks40_005.witnesses ++
  ExposureEvolution.CompactBlocks40_006.witnesses ++
  ExposureEvolution.CompactBlocks40_007.witnesses ++
  ExposureEvolution.CompactBlocks40_008.witnesses ++
  ExposureEvolution.CompactBlocks40_009.witnesses ++
  ExposureEvolution.CompactBlocks40_010.witnesses ++
  ExposureEvolution.CompactBlocks40_011.witnesses) = true := by
    apply ExposureEvolution.CompactBlocks40_000.extend
    apply ExposureEvolution.CompactBlocks40_001.extend
    apply ExposureEvolution.CompactBlocks40_002.extend
    apply ExposureEvolution.CompactBlocks40_003.extend
    apply ExposureEvolution.CompactBlocks40_004.extend
    apply ExposureEvolution.CompactBlocks40_005.extend
    apply ExposureEvolution.CompactBlocks40_006.extend
    apply ExposureEvolution.CompactBlocks40_007.extend
    apply ExposureEvolution.CompactBlocks40_008.extend
    apply ExposureEvolution.CompactBlocks40_009.extend
    apply ExposureEvolution.CompactBlocks40_010.extend
    apply ExposureEvolution.CompactBlocks40_011.extend
    decide +kernel
  simpa only [same_values] using h

theorem finite (n : ℕ) (hn : 4932841 ≤ n ∧ n < 71707024) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 2 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m :=
  coverage_sound 4932841 71707024 ExposureEvolution.CompactData40.witnesses accepted n hn

#print axioms accepted
#print axioms finite
end ExposureEvolution.CompactCoverage40
