/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
/- Independent constructor for source-criterion block witnesses. -/
import E1TwoTracks.TrackBBlocks
namespace E1TwoTracks.TrackB
set_option maxRecDepth 10000
set_option maxHeartbeats 3000000

/-- Fuel-bounded upward prime search, returning the prime itself. -/
def nextPrime : ℕ → ℕ → Option ℕ
  | 0, _ => none
  | k+1, a => if a.Prime then some a else nextPrime k (a+1)

/-- Fuel-bounded downward prime search, returning the prime itself. -/
def prevPrime : ℕ → ℕ → Option ℕ
  | 0, _ => none
  | k+1, a => if a.Prime then some a else if a=0 then none else prevPrime k (a-1)

/-- Choose medium primes just above sqrt(lo) and large primes just below lo,
then take the maximal interval on which the first medium prime stays above sqrt.
The exact source criterion, including its quantitative surplus, must pass at
both endpoints before this candidate is accepted. -/
def makeBlock (primeFuel lo stop : ℕ) : Option Block := do
  let p0 ← nextPrime primeFuel (Nat.sqrt lo + 1)
  let p1 ← nextPrime primeFuel (p0+1)
  let p2 ← nextPrime primeFuel (p1+1)
  let q2 ← prevPrime primeFuel (lo-1)
  let q1 ← prevPrime primeFuel (q2-1)
  let q0 ← prevPrime primeFuel (q1-1)
  let b : Block := ⟨lo, min (p0^2-1) (stop-1), p0, p1, p2, q0, q1, q2⟩
  if b.check then some b else none

/-- Produce successive source-criterion blocks until stop is reached. -/
def run (primeFuel : ℕ) : ℕ → ℕ → ℕ → Option (List Block)
  | 0, lo, stop => if stop ≤ lo then some [] else none
  | fuel+1, lo, stop => if stop ≤ lo then some [] else do
      let b ← makeBlock primeFuel lo stop
      let bs ← run primeFuel fuel (b.hi+1) stop
      pure (b::bs)

/-- Independent checker: every interval must be certified and intervals join
without a gap. The terminal endpoint is checked as well. -/
def check : ℕ → ℕ → List Block → Bool
  | lo, stop, [] => decide (stop ≤ lo)
  | lo, stop, b::bs => decide (b.lo=lo) && b.check && check (b.hi+1) stop bs

/-- The checker proves full coverage of the original divisor-sum quantity. -/
theorem sound (lo stop : ℕ) (bs : List Block) (hb : check lo stop bs = true)
    (n : ℕ) (hn : lo ≤ n ∧ n < stop) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  induction bs generalizing lo with
  | nil => simp only [check, decide_eq_true_eq] at hb; omega
  | cons b bs ih =>
      simp only [check, Bool.and_eq_true, decide_eq_true_eq] at hb
      rcases hb with ⟨⟨hlo, hv⟩, ht⟩
      by_cases hnh : n ≤ b.hi
      · exact b.sound hv n (hlo ▸ hn.1) hnh
      · exact ih (b.hi+1) ht ⟨by omega, hn.2⟩

end E1TwoTracks.TrackB
