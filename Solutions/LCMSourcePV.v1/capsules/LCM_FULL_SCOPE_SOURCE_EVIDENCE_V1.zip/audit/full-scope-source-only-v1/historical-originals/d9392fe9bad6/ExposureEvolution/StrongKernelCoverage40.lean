import ExposureEvolution.StrongKernelData40
import ExposureEvolution.StrongKernelBlocks40_000
import ExposureEvolution.StrongKernelBlocks40_001
import ExposureEvolution.StrongKernelBlocks40_002
import ExposureEvolution.StrongKernelBlocks40_003
import ExposureEvolution.StrongKernelBlocks40_004
import ExposureEvolution.StrongKernelBlocks40_005
import ExposureEvolution.StrongKernelBlocks40_006
import ExposureEvolution.StrongKernelBlocks40_007
import ExposureEvolution.StrongKernelBlocks40_008
import ExposureEvolution.StrongKernelBlocks40_009
import ExposureEvolution.StrongKernelBlocks40_010
import ExposureEvolution.StrongKernelBlocks40_011
import ExposureEvolution.StrongKernelBlocks40_012
import ExposureEvolution.StrongKernelBlocks40_013
import ExposureEvolution.StrongKernelBlocks40_014
import ExposureEvolution.StrongKernelBlocks40_015
import ExposureEvolution.StrongKernelBlocks40_016
import ExposureEvolution.StrongKernelBlocks40_017
import ExposureEvolution.StrongKernelBlocks40_018
import ExposureEvolution.StrongKernelBlocks40_019
import ExposureEvolution.StrongKernelBlocks40_020
import ExposureEvolution.StrongKernelBlocks40_021
import ExposureEvolution.StrongKernelBlocks40_022
import ExposureEvolution.StrongKernelBlocks40_023
import ExposureEvolution.StrongKernelBlocks40_024
import ExposureEvolution.StrongKernelBlocks40_025
import ExposureEvolution.StrongKernelBlocks40_026
import ExposureEvolution.StrongKernelBlocks40_027
import ExposureEvolution.StrongKernelBlocks40_028
import ExposureEvolution.StrongKernelBlocks40_029
import ExposureEvolution.StrongKernelBlocks40_030
import ExposureEvolution.StrongKernelBlocks40_031
import ExposureEvolution.StrongKernelBlocks40_032
import ExposureEvolution.StrongKernelBlocks40_033
import ExposureEvolution.StrongKernelBlocks40_034
import ExposureEvolution.StrongKernelBlocks40_035
import ExposureEvolution.StrongKernelBlocks40_036
import ExposureEvolution.StrongKernelBlocks40_037
import ExposureEvolution.StrongKernelBlocks40_038
import ExposureEvolution.StrongKernelBlocks40_039
import ExposureEvolution.StrongKernelBlocks40_040
import ExposureEvolution.StrongKernelBlocks40_041
import ExposureEvolution.StrongKernelBlocks40_042
import ExposureEvolution.StrongKernelBlocks40_043
import ExposureEvolution.StrongKernelBlocks40_044
import ExposureEvolution.StrongKernelBlocks40_045
import ExposureEvolution.StrongKernelBlocks40_046
import ExposureEvolution.StrongKernelBlocks40_047
import ExposureEvolution.StrongKernelBlocks40_048
import ExposureEvolution.StrongKernelBlocks40_049
import ExposureEvolution.StrongKernelBlocks40_050
import ExposureEvolution.StrongKernelBlocks40_051
import ExposureEvolution.StrongKernelBlocks40_052
import ExposureEvolution.StrongKernelBlocks40_053
import ExposureEvolution.StrongKernelBlocks40_054
import ExposureEvolution.StrongKernelBlocks40_055
import ExposureEvolution.StrongKernelBlocks40_056
import ExposureEvolution.StrongKernelBlocks40_057
import ExposureEvolution.StrongKernelBlocks40_058
import ExposureEvolution.StrongKernelBlocks40_059
import ExposureEvolution.StrongKernelBlocks40_060
import ExposureEvolution.StrongKernelBlocks40_061
import ExposureEvolution.StrongKernelBlocks40_062
import ExposureEvolution.StrongKernelBlocks40_063
import ExposureEvolution.StrongKernelBlocks40_064
import ExposureEvolution.StrongKernelBlocks40_065
import ExposureEvolution.StrongKernelBlocks40_066
import ExposureEvolution.StrongKernelBlocks40_067
import ExposureEvolution.StrongKernelBlocks40_068
import ExposureEvolution.StrongKernelBlocks40_069
import ExposureEvolution.StrongKernelBlocks40_070
import ExposureEvolution.StrongKernelBlocks40_071
import ExposureEvolution.StrongKernelBlocks40_072
import ExposureEvolution.StrongKernelBlocks40_073
import ExposureEvolution.StrongKernelBlocks40_074
import ExposureEvolution.StrongKernelBlocks40_075
import ExposureEvolution.StrongKernelBlocks40_076
import ExposureEvolution.StrongKernelBlocks40_077
import ExposureEvolution.StrongKernelBlocks40_078
import ExposureEvolution.StrongKernelBlocks40_079
import ExposureEvolution.StrongKernelBlocks40_080
import ExposureEvolution.StrongKernelBlocks40_081
import ExposureEvolution.StrongKernelBlocks40_082
import ExposureEvolution.StrongKernelBlocks40_083
import ExposureEvolution.StrongKernelBlocks40_084
import ExposureEvolution.StrongKernelBlocks40_085
import ExposureEvolution.StrongKernelBlocks40_086
import ExposureEvolution.StrongKernelBlocks40_087
namespace ExposureEvolution.StrongKernelCoverage40
open ExposureEvolution.Adaptive40
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem chunk_identity000 : ExposureEvolution.StrongKernelData40.chunk000 =
    ExposureEvolution.StrongKernelBlocks40_000.witnesses ++ ExposureEvolution.StrongKernelBlocks40_001.witnesses := by rfl

theorem chunk_identity001 : ExposureEvolution.StrongKernelData40.chunk001 =
    ExposureEvolution.StrongKernelBlocks40_002.witnesses ++ ExposureEvolution.StrongKernelBlocks40_003.witnesses := by rfl

theorem chunk_identity002 : ExposureEvolution.StrongKernelData40.chunk002 =
    ExposureEvolution.StrongKernelBlocks40_004.witnesses ++ ExposureEvolution.StrongKernelBlocks40_005.witnesses := by rfl

theorem chunk_identity003 : ExposureEvolution.StrongKernelData40.chunk003 =
    ExposureEvolution.StrongKernelBlocks40_006.witnesses ++ ExposureEvolution.StrongKernelBlocks40_007.witnesses := by rfl

theorem chunk_identity004 : ExposureEvolution.StrongKernelData40.chunk004 =
    ExposureEvolution.StrongKernelBlocks40_008.witnesses ++ ExposureEvolution.StrongKernelBlocks40_009.witnesses := by rfl

theorem chunk_identity005 : ExposureEvolution.StrongKernelData40.chunk005 =
    ExposureEvolution.StrongKernelBlocks40_010.witnesses ++ ExposureEvolution.StrongKernelBlocks40_011.witnesses := by rfl

theorem chunk_identity006 : ExposureEvolution.StrongKernelData40.chunk006 =
    ExposureEvolution.StrongKernelBlocks40_012.witnesses ++ ExposureEvolution.StrongKernelBlocks40_013.witnesses := by rfl

theorem chunk_identity007 : ExposureEvolution.StrongKernelData40.chunk007 =
    ExposureEvolution.StrongKernelBlocks40_014.witnesses ++ ExposureEvolution.StrongKernelBlocks40_015.witnesses := by rfl

theorem chunk_identity008 : ExposureEvolution.StrongKernelData40.chunk008 =
    ExposureEvolution.StrongKernelBlocks40_016.witnesses ++ ExposureEvolution.StrongKernelBlocks40_017.witnesses := by rfl

theorem chunk_identity009 : ExposureEvolution.StrongKernelData40.chunk009 =
    ExposureEvolution.StrongKernelBlocks40_018.witnesses ++ ExposureEvolution.StrongKernelBlocks40_019.witnesses := by rfl

theorem chunk_identity010 : ExposureEvolution.StrongKernelData40.chunk010 =
    ExposureEvolution.StrongKernelBlocks40_020.witnesses ++ ExposureEvolution.StrongKernelBlocks40_021.witnesses := by rfl

theorem chunk_identity011 : ExposureEvolution.StrongKernelData40.chunk011 =
    ExposureEvolution.StrongKernelBlocks40_022.witnesses ++ ExposureEvolution.StrongKernelBlocks40_023.witnesses := by rfl

theorem chunk_identity012 : ExposureEvolution.StrongKernelData40.chunk012 =
    ExposureEvolution.StrongKernelBlocks40_024.witnesses ++ ExposureEvolution.StrongKernelBlocks40_025.witnesses := by rfl

theorem chunk_identity013 : ExposureEvolution.StrongKernelData40.chunk013 =
    ExposureEvolution.StrongKernelBlocks40_026.witnesses ++ ExposureEvolution.StrongKernelBlocks40_027.witnesses := by rfl

theorem chunk_identity014 : ExposureEvolution.StrongKernelData40.chunk014 =
    ExposureEvolution.StrongKernelBlocks40_028.witnesses ++ ExposureEvolution.StrongKernelBlocks40_029.witnesses := by rfl

theorem chunk_identity015 : ExposureEvolution.StrongKernelData40.chunk015 =
    ExposureEvolution.StrongKernelBlocks40_030.witnesses ++ ExposureEvolution.StrongKernelBlocks40_031.witnesses := by rfl

theorem chunk_identity016 : ExposureEvolution.StrongKernelData40.chunk016 =
    ExposureEvolution.StrongKernelBlocks40_032.witnesses ++ ExposureEvolution.StrongKernelBlocks40_033.witnesses := by rfl

theorem chunk_identity017 : ExposureEvolution.StrongKernelData40.chunk017 =
    ExposureEvolution.StrongKernelBlocks40_034.witnesses ++ ExposureEvolution.StrongKernelBlocks40_035.witnesses := by rfl

theorem chunk_identity018 : ExposureEvolution.StrongKernelData40.chunk018 =
    ExposureEvolution.StrongKernelBlocks40_036.witnesses ++ ExposureEvolution.StrongKernelBlocks40_037.witnesses := by rfl

theorem chunk_identity019 : ExposureEvolution.StrongKernelData40.chunk019 =
    ExposureEvolution.StrongKernelBlocks40_038.witnesses ++ ExposureEvolution.StrongKernelBlocks40_039.witnesses := by rfl

theorem chunk_identity020 : ExposureEvolution.StrongKernelData40.chunk020 =
    ExposureEvolution.StrongKernelBlocks40_040.witnesses ++ ExposureEvolution.StrongKernelBlocks40_041.witnesses := by rfl

theorem chunk_identity021 : ExposureEvolution.StrongKernelData40.chunk021 =
    ExposureEvolution.StrongKernelBlocks40_042.witnesses ++ ExposureEvolution.StrongKernelBlocks40_043.witnesses := by rfl

theorem chunk_identity022 : ExposureEvolution.StrongKernelData40.chunk022 =
    ExposureEvolution.StrongKernelBlocks40_044.witnesses ++ ExposureEvolution.StrongKernelBlocks40_045.witnesses := by rfl

theorem chunk_identity023 : ExposureEvolution.StrongKernelData40.chunk023 =
    ExposureEvolution.StrongKernelBlocks40_046.witnesses ++ ExposureEvolution.StrongKernelBlocks40_047.witnesses := by rfl

theorem chunk_identity024 : ExposureEvolution.StrongKernelData40.chunk024 =
    ExposureEvolution.StrongKernelBlocks40_048.witnesses ++ ExposureEvolution.StrongKernelBlocks40_049.witnesses := by rfl

theorem chunk_identity025 : ExposureEvolution.StrongKernelData40.chunk025 =
    ExposureEvolution.StrongKernelBlocks40_050.witnesses ++ ExposureEvolution.StrongKernelBlocks40_051.witnesses := by rfl

theorem chunk_identity026 : ExposureEvolution.StrongKernelData40.chunk026 =
    ExposureEvolution.StrongKernelBlocks40_052.witnesses ++ ExposureEvolution.StrongKernelBlocks40_053.witnesses := by rfl

theorem chunk_identity027 : ExposureEvolution.StrongKernelData40.chunk027 =
    ExposureEvolution.StrongKernelBlocks40_054.witnesses ++ ExposureEvolution.StrongKernelBlocks40_055.witnesses := by rfl

theorem chunk_identity028 : ExposureEvolution.StrongKernelData40.chunk028 =
    ExposureEvolution.StrongKernelBlocks40_056.witnesses ++ ExposureEvolution.StrongKernelBlocks40_057.witnesses := by rfl

theorem chunk_identity029 : ExposureEvolution.StrongKernelData40.chunk029 =
    ExposureEvolution.StrongKernelBlocks40_058.witnesses ++ ExposureEvolution.StrongKernelBlocks40_059.witnesses := by rfl

theorem chunk_identity030 : ExposureEvolution.StrongKernelData40.chunk030 =
    ExposureEvolution.StrongKernelBlocks40_060.witnesses ++ ExposureEvolution.StrongKernelBlocks40_061.witnesses := by rfl

theorem chunk_identity031 : ExposureEvolution.StrongKernelData40.chunk031 =
    ExposureEvolution.StrongKernelBlocks40_062.witnesses ++ ExposureEvolution.StrongKernelBlocks40_063.witnesses := by rfl

theorem chunk_identity032 : ExposureEvolution.StrongKernelData40.chunk032 =
    ExposureEvolution.StrongKernelBlocks40_064.witnesses ++ ExposureEvolution.StrongKernelBlocks40_065.witnesses := by rfl

theorem chunk_identity033 : ExposureEvolution.StrongKernelData40.chunk033 =
    ExposureEvolution.StrongKernelBlocks40_066.witnesses ++ ExposureEvolution.StrongKernelBlocks40_067.witnesses := by rfl

theorem chunk_identity034 : ExposureEvolution.StrongKernelData40.chunk034 =
    ExposureEvolution.StrongKernelBlocks40_068.witnesses ++ ExposureEvolution.StrongKernelBlocks40_069.witnesses := by rfl

theorem chunk_identity035 : ExposureEvolution.StrongKernelData40.chunk035 =
    ExposureEvolution.StrongKernelBlocks40_070.witnesses ++ ExposureEvolution.StrongKernelBlocks40_071.witnesses := by rfl

theorem chunk_identity036 : ExposureEvolution.StrongKernelData40.chunk036 =
    ExposureEvolution.StrongKernelBlocks40_072.witnesses ++ ExposureEvolution.StrongKernelBlocks40_073.witnesses := by rfl

theorem chunk_identity037 : ExposureEvolution.StrongKernelData40.chunk037 =
    ExposureEvolution.StrongKernelBlocks40_074.witnesses ++ ExposureEvolution.StrongKernelBlocks40_075.witnesses := by rfl

theorem chunk_identity038 : ExposureEvolution.StrongKernelData40.chunk038 =
    ExposureEvolution.StrongKernelBlocks40_076.witnesses ++ ExposureEvolution.StrongKernelBlocks40_077.witnesses := by rfl

theorem chunk_identity039 : ExposureEvolution.StrongKernelData40.chunk039 =
    ExposureEvolution.StrongKernelBlocks40_078.witnesses ++ ExposureEvolution.StrongKernelBlocks40_079.witnesses := by rfl

theorem chunk_identity040 : ExposureEvolution.StrongKernelData40.chunk040 =
    ExposureEvolution.StrongKernelBlocks40_080.witnesses ++ ExposureEvolution.StrongKernelBlocks40_081.witnesses := by rfl

theorem chunk_identity041 : ExposureEvolution.StrongKernelData40.chunk041 =
    ExposureEvolution.StrongKernelBlocks40_082.witnesses ++ ExposureEvolution.StrongKernelBlocks40_083.witnesses := by rfl

theorem chunk_identity042 : ExposureEvolution.StrongKernelData40.chunk042 =
    ExposureEvolution.StrongKernelBlocks40_084.witnesses ++ ExposureEvolution.StrongKernelBlocks40_085.witnesses := by rfl

theorem chunk_identity043 : ExposureEvolution.StrongKernelData40.chunk043 =
    ExposureEvolution.StrongKernelBlocks40_086.witnesses ++ ExposureEvolution.StrongKernelBlocks40_087.witnesses := by rfl

theorem same_values : ExposureEvolution.StrongKernelData40.witnesses =
  ExposureEvolution.StrongKernelBlocks40_000.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_001.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_002.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_003.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_004.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_005.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_006.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_007.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_008.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_009.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_010.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_011.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_012.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_013.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_014.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_015.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_016.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_017.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_018.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_019.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_020.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_021.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_022.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_023.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_024.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_025.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_026.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_027.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_028.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_029.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_030.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_031.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_032.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_033.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_034.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_035.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_036.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_037.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_038.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_039.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_040.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_041.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_042.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_043.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_044.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_045.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_046.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_047.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_048.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_049.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_050.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_051.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_052.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_053.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_054.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_055.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_056.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_057.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_058.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_059.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_060.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_061.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_062.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_063.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_064.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_065.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_066.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_067.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_068.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_069.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_070.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_071.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_072.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_073.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_074.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_075.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_076.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_077.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_078.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_079.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_080.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_081.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_082.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_083.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_084.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_085.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_086.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_087.witnesses := by
  simp only [ExposureEvolution.StrongKernelData40.witnesses,
    chunk_identity000,
    chunk_identity001,
    chunk_identity002,
    chunk_identity003,
    chunk_identity004,
    chunk_identity005,
    chunk_identity006,
    chunk_identity007,
    chunk_identity008,
    chunk_identity009,
    chunk_identity010,
    chunk_identity011,
    chunk_identity012,
    chunk_identity013,
    chunk_identity014,
    chunk_identity015,
    chunk_identity016,
    chunk_identity017,
    chunk_identity018,
    chunk_identity019,
    chunk_identity020,
    chunk_identity021,
    chunk_identity022,
    chunk_identity023,
    chunk_identity024,
    chunk_identity025,
    chunk_identity026,
    chunk_identity027,
    chunk_identity028,
    chunk_identity029,
    chunk_identity030,
    chunk_identity031,
    chunk_identity032,
    chunk_identity033,
    chunk_identity034,
    chunk_identity035,
    chunk_identity036,
    chunk_identity037,
    chunk_identity038,
    chunk_identity039,
    chunk_identity040,
    chunk_identity041,
    chunk_identity042,
    chunk_identity043, List.append_assoc]

theorem accepted : coverage 5000000 3461204224 ExposureEvolution.StrongKernelData40.witnesses = true := by
  have h : coverage 5000000 3461204224 (
    ExposureEvolution.StrongKernelBlocks40_000.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_001.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_002.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_003.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_004.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_005.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_006.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_007.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_008.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_009.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_010.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_011.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_012.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_013.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_014.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_015.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_016.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_017.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_018.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_019.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_020.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_021.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_022.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_023.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_024.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_025.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_026.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_027.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_028.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_029.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_030.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_031.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_032.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_033.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_034.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_035.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_036.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_037.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_038.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_039.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_040.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_041.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_042.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_043.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_044.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_045.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_046.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_047.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_048.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_049.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_050.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_051.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_052.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_053.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_054.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_055.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_056.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_057.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_058.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_059.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_060.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_061.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_062.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_063.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_064.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_065.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_066.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_067.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_068.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_069.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_070.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_071.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_072.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_073.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_074.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_075.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_076.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_077.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_078.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_079.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_080.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_081.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_082.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_083.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_084.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_085.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_086.witnesses ++
  ExposureEvolution.StrongKernelBlocks40_087.witnesses) = true := by
    apply ExposureEvolution.StrongKernelBlocks40_000.extend
    apply ExposureEvolution.StrongKernelBlocks40_001.extend
    apply ExposureEvolution.StrongKernelBlocks40_002.extend
    apply ExposureEvolution.StrongKernelBlocks40_003.extend
    apply ExposureEvolution.StrongKernelBlocks40_004.extend
    apply ExposureEvolution.StrongKernelBlocks40_005.extend
    apply ExposureEvolution.StrongKernelBlocks40_006.extend
    apply ExposureEvolution.StrongKernelBlocks40_007.extend
    apply ExposureEvolution.StrongKernelBlocks40_008.extend
    apply ExposureEvolution.StrongKernelBlocks40_009.extend
    apply ExposureEvolution.StrongKernelBlocks40_010.extend
    apply ExposureEvolution.StrongKernelBlocks40_011.extend
    apply ExposureEvolution.StrongKernelBlocks40_012.extend
    apply ExposureEvolution.StrongKernelBlocks40_013.extend
    apply ExposureEvolution.StrongKernelBlocks40_014.extend
    apply ExposureEvolution.StrongKernelBlocks40_015.extend
    apply ExposureEvolution.StrongKernelBlocks40_016.extend
    apply ExposureEvolution.StrongKernelBlocks40_017.extend
    apply ExposureEvolution.StrongKernelBlocks40_018.extend
    apply ExposureEvolution.StrongKernelBlocks40_019.extend
    apply ExposureEvolution.StrongKernelBlocks40_020.extend
    apply ExposureEvolution.StrongKernelBlocks40_021.extend
    apply ExposureEvolution.StrongKernelBlocks40_022.extend
    apply ExposureEvolution.StrongKernelBlocks40_023.extend
    apply ExposureEvolution.StrongKernelBlocks40_024.extend
    apply ExposureEvolution.StrongKernelBlocks40_025.extend
    apply ExposureEvolution.StrongKernelBlocks40_026.extend
    apply ExposureEvolution.StrongKernelBlocks40_027.extend
    apply ExposureEvolution.StrongKernelBlocks40_028.extend
    apply ExposureEvolution.StrongKernelBlocks40_029.extend
    apply ExposureEvolution.StrongKernelBlocks40_030.extend
    apply ExposureEvolution.StrongKernelBlocks40_031.extend
    apply ExposureEvolution.StrongKernelBlocks40_032.extend
    apply ExposureEvolution.StrongKernelBlocks40_033.extend
    apply ExposureEvolution.StrongKernelBlocks40_034.extend
    apply ExposureEvolution.StrongKernelBlocks40_035.extend
    apply ExposureEvolution.StrongKernelBlocks40_036.extend
    apply ExposureEvolution.StrongKernelBlocks40_037.extend
    apply ExposureEvolution.StrongKernelBlocks40_038.extend
    apply ExposureEvolution.StrongKernelBlocks40_039.extend
    apply ExposureEvolution.StrongKernelBlocks40_040.extend
    apply ExposureEvolution.StrongKernelBlocks40_041.extend
    apply ExposureEvolution.StrongKernelBlocks40_042.extend
    apply ExposureEvolution.StrongKernelBlocks40_043.extend
    apply ExposureEvolution.StrongKernelBlocks40_044.extend
    apply ExposureEvolution.StrongKernelBlocks40_045.extend
    apply ExposureEvolution.StrongKernelBlocks40_046.extend
    apply ExposureEvolution.StrongKernelBlocks40_047.extend
    apply ExposureEvolution.StrongKernelBlocks40_048.extend
    apply ExposureEvolution.StrongKernelBlocks40_049.extend
    apply ExposureEvolution.StrongKernelBlocks40_050.extend
    apply ExposureEvolution.StrongKernelBlocks40_051.extend
    apply ExposureEvolution.StrongKernelBlocks40_052.extend
    apply ExposureEvolution.StrongKernelBlocks40_053.extend
    apply ExposureEvolution.StrongKernelBlocks40_054.extend
    apply ExposureEvolution.StrongKernelBlocks40_055.extend
    apply ExposureEvolution.StrongKernelBlocks40_056.extend
    apply ExposureEvolution.StrongKernelBlocks40_057.extend
    apply ExposureEvolution.StrongKernelBlocks40_058.extend
    apply ExposureEvolution.StrongKernelBlocks40_059.extend
    apply ExposureEvolution.StrongKernelBlocks40_060.extend
    apply ExposureEvolution.StrongKernelBlocks40_061.extend
    apply ExposureEvolution.StrongKernelBlocks40_062.extend
    apply ExposureEvolution.StrongKernelBlocks40_063.extend
    apply ExposureEvolution.StrongKernelBlocks40_064.extend
    apply ExposureEvolution.StrongKernelBlocks40_065.extend
    apply ExposureEvolution.StrongKernelBlocks40_066.extend
    apply ExposureEvolution.StrongKernelBlocks40_067.extend
    apply ExposureEvolution.StrongKernelBlocks40_068.extend
    apply ExposureEvolution.StrongKernelBlocks40_069.extend
    apply ExposureEvolution.StrongKernelBlocks40_070.extend
    apply ExposureEvolution.StrongKernelBlocks40_071.extend
    apply ExposureEvolution.StrongKernelBlocks40_072.extend
    apply ExposureEvolution.StrongKernelBlocks40_073.extend
    apply ExposureEvolution.StrongKernelBlocks40_074.extend
    apply ExposureEvolution.StrongKernelBlocks40_075.extend
    apply ExposureEvolution.StrongKernelBlocks40_076.extend
    apply ExposureEvolution.StrongKernelBlocks40_077.extend
    apply ExposureEvolution.StrongKernelBlocks40_078.extend
    apply ExposureEvolution.StrongKernelBlocks40_079.extend
    apply ExposureEvolution.StrongKernelBlocks40_080.extend
    apply ExposureEvolution.StrongKernelBlocks40_081.extend
    apply ExposureEvolution.StrongKernelBlocks40_082.extend
    apply ExposureEvolution.StrongKernelBlocks40_083.extend
    apply ExposureEvolution.StrongKernelBlocks40_084.extend
    apply ExposureEvolution.StrongKernelBlocks40_085.extend
    apply ExposureEvolution.StrongKernelBlocks40_086.extend
    apply ExposureEvolution.StrongKernelBlocks40_087.extend
    decide +kernel
  simpa only [same_values] using h

theorem finite (n : ℕ) (hn : 5000000 ≤ n ∧ n < 3461204224) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 2 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m :=
  coverage_sound 5000000 3461204224 ExposureEvolution.StrongKernelData40.witnesses accepted n hn

#print axioms accepted
#print axioms finite
end ExposureEvolution.StrongKernelCoverage40
