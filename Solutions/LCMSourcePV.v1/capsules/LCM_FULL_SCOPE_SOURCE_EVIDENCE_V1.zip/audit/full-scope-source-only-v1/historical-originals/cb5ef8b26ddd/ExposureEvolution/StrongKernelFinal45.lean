import ExposureEvolution.StrongKernelCoverage45
import ExposureEvolution.StrongKernelGap1024
import ExposureEvolution.Strong45

namespace ExposureEvolution.StrongKernelFinal45
open Real
set_option Elab.async false

theorem tail (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 3461204224 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 9 / (20 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have he : exp (9 : ℝ) < 58832 := by
    have he1 : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
    calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
      _ ≤ (3 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le he1.le 9
      _ < 58832 := by norm_num
  have hlog : (9 : ℝ) ≤ log 58832 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) he).le
  have hreal : (58832 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  exact Strong45.quantitative_of_gap (c := 9) (StrongKernelGap1024.full_gap hd)
    (by norm_num) hlog n hreal

theorem whole_ray (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 50000000 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 9 / (20 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases h : n < 3461204224
  · exact StrongKernelCoverage45.finite n ⟨hn, h⟩
  · exact tail hd n (Nat.le_of_not_lt h)

#print axioms whole_ray
end ExposureEvolution.StrongKernelFinal45
