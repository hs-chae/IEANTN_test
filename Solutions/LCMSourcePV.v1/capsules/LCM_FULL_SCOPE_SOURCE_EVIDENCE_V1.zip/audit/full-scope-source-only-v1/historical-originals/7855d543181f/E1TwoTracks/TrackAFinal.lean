/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackAPrimeCover
import E1TwoTracks.TrackASurplus
import E1Tertiary.LcmTail
namespace E1TwoTracks.TrackAFinal
open Real E1TwoTracks.TrackAConstant

theorem exp_seven_small : exp (7 : ℝ) < 1341 := by
  have he : exp 1 < (11 / 4 : ℝ) := by linarith [Real.exp_one_lt_d9]
  calc exp (7 : ℝ) = (exp 1)^7 := by rw [Real.exp_one_pow]; norm_num
    _ ≤ (11 / 4 : ℝ)^7 := pow_le_pow_left₀ (exp_pos 1).le he.le 7
    _ < 1341 := by norm_num

/-- The finite recalibrated output and the unchanged 2018 source tail cover the whole ray. -/
theorem gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 1341 := by
  intro x hx
  by_cases ht : x < 89693
  · exact TrackAPrimeCover.covered hx ht
  · obtain ⟨p, hp, hpx, hpu⟩ := E1Tertiary.LcmTail.gap hd x (le_of_not_gt ht)
    refine ⟨p, hp, hpx, ?_⟩
    have hxp : 0 < x := by linarith
    linarith

/-- Actual quantitative divisor-sum conclusion, for every natural input above the new onset. -/
theorem quantitative (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 1798281 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  have hlog : (7 : ℝ) ≤ Real.log 1341 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (7 : ℝ)) exp_seven_small).le
  have hnn : (1341 : ℝ)^2 ≤ n := by exact_mod_cast hn
  exact TrackASurplus.quantitative_of_gap (gap hd) (by norm_num : (7 : ℝ) ≤ 7) hlog n hnn

end E1TwoTracks.TrackAFinal
