/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
/- Strong frozen-evidence .15/n comparison: analytic qtail and three old-cover intervals. -/
import E1TwoTracks.TrackNFixed
import E1TwoTracks.TrackAHighBaseline
namespace E1TwoTracks.TrackNFixedHigh
open Real Finset Nat E1Tertiary.LcmBase E1TwoTracks.TrackNFixed
set_option maxHeartbeats 3000000
set_option maxRecDepth 100000

theorem scalar {e : ℝ} (he : 0 ≤ e) (he' : e ≤ 1/10000000) :
    (1+3*e/20)*(1+(1000/997:ℝ)*e)^3 ≤
      (1+(279/100:ℝ)*e)*(1+(3/8:ℝ)*e)*(1-(3/2000:ℝ)*e) := by
  have h2 : e^2 ≤ e/10000000 := by nlinarith
  have h3 : e^3 ≤ e^2/10000000 := by
    nlinarith [mul_nonneg (sq_nonneg e) (sub_nonneg.mpr he')]
  have h4 : e^4 ≤ e^3/10000000 := by
    nlinarith [mul_nonneg (pow_nonneg he 3) (sub_nonneg.mpr he')]
  nlinarith [pow_nonneg he 2,pow_nonneg he 3,pow_nonneg he 4]

theorem ratio {n : ℝ} (hn : 10300000 ≤ n) (p q : Fin 3 → ℕ)
    (hp : ∀ i, p i ≤ (![3299,3325,3351] : Fin 3 → ℕ) i)
    (hprime : ∀ i, Nat.Prime (p i))
    (hq : ∀ i, (997/1000:ℝ)*n ≤ q i) :
    (1+3/(20*n))*∏ i, (1+(1:ℝ)/q i) ≤
      (∏ i, (1+1/(p i*(p i+1):ℝ)))*(1+3/(8*n))*
      (1-4*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ))) := by
  have hnp : (0:ℝ) < n := by linarith
  have he : (0:ℝ) ≤ 1/n := by positivity
  have hep : (0:ℝ) < 1/n := by positivity
  have he' : (1:ℝ)/n ≤ 1/10000000 :=
    one_div_le_one_div_of_le (by norm_num) (by linarith)
  have hp' (i : Fin 3) : (p i:ℝ) ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by
    have h := hp i
    fin_cases i <;> dsimp at * <;> exact_mod_cast h
  have hp0 (i : Fin 3) : (0:ℝ)<p i := by exact_mod_cast (hprime i).pos
  have hq0 (i : Fin 3) : (0:ℝ)<q i := (by positivity : (0:ℝ)<(997/1000:ℝ)*n).trans_le (hq i)
  have hBconst : 1+(279/100:ℝ)/10300000 ≤
      ∏ i, (1+1/((![3299,3325,3351] : Fin 3 → ℝ) i *
        ((![3299,3325,3351] : Fin 3 → ℝ) i+1))) := by
    norm_num [Fin.prod_univ_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]
  have hB : 1+(279/100:ℝ)*(1/n) ≤ ∏ i, (1+1/(p i*(p i+1):ℝ)) := by
    calc
      _ ≤ 1+(279/100:ℝ)/10300000 := by
        have hi : (1:ℝ)/n ≤ 1/10300000 := one_div_le_one_div_of_le (by norm_num) hn
        nlinarith
      _ ≤ _ := hBconst
      _ ≤ _ := by
        apply Finset.prod_le_prod₀
        · intro i hi
          have hc : 0 ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by fin_cases i <;> dsimp <;> norm_num
          positivity
        · intro i hi
          have hc : 0 ≤ (![3299,3325,3351] : Fin 3 → ℝ) i := by fin_cases i <;> dsimp <;> norm_num
          have hmul : (p i:ℝ)*(p i+1) ≤
              (![3299,3325,3351] : Fin 3 → ℝ) i * ((![3299,3325,3351] : Fin 3 → ℝ) i+1) := by
            exact mul_le_mul (hp' i) (by linarith [hp' i]) (by linarith [hp0 i]) hc
          have hh := one_div_le_one_div_of_le (mul_pos (hp0 i) (by linarith [hp0 i])) hmul
          linarith
  have hA : (∏ i, (1+(1:ℝ)/q i)) ≤ (1+(1000/997:ℝ)*(1/n))^3 := by
    have ht (i : Fin 3) : 1+(1:ℝ)/q i ≤ 1+(1000/997:ℝ)*(1/n) := by
      have hi := one_div_le_one_div_of_le (by positivity : (0:ℝ)<(997/1000:ℝ)*n) (hq i)
      have heq : (1:ℝ)/((997/1000:ℝ)*n) = (1000/997:ℝ)*(1/n) := by field_simp <;> ring
      rw [heq] at hi
      linarith
    calc
      _ ≤ ∏ i : Fin 3, (1+(1000/997:ℝ)*(1/n)) := Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply ht)
      _ = _ := by simp [Fin.prod_univ_three] <;> ring
  have hQ : ((997/1000:ℝ)*n)^3 ≤ ∏ i, (q i:ℝ) := by
    calc
      _ = ∏ i : Fin 3, ((997/1000:ℝ)*n) := by simp [Fin.prod_univ_three] <;> ring
      _ ≤ _ := Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply hq)
  have hP : (∏ i, (p i:ℝ)) ≤ (3299:ℝ)*3325*3351 := by
    calc
      _ ≤ ∏ i : Fin 3, (![3299,3325,3351] : Fin 3 → ℝ) i :=
        Finset.prod_le_prod₀ (by intros; positivity) (by intros; apply hp')
      _ = _ := by norm_num [Fin.prod_univ_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]
  have hR : 1-(3/2000:ℝ)*(1/n) ≤
      1-4*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ)) := by
    have hrat : 4*(∏ i, (p i:ℝ))/(∏ i, (q i:ℝ)) ≤
        4*((3299:ℝ)*3325*3351)/(((997/1000:ℝ)*n)^3) := by
      exact div_le_div₀ (by positivity) (by linarith) (by positivity) hQ
    have hn2 : (10300000:ℝ)^2 ≤ n^2 :=
      pow_le_pow_left₀ (by norm_num) hn 2
    have hc : 4*((3299:ℝ)*3325*3351) ≤ (3/2000:ℝ)*(997/1000:ℝ)^3*n^2 := by nlinarith
    have hr : 4*((3299:ℝ)*3325*3351)/(((997/1000:ℝ)*n)^3) ≤ (3/2000:ℝ)/n := by
      apply (div_le_div_iff₀ (by positivity) hnp).mpr
      nlinarith [mul_le_mul_of_nonneg_right hc hnp.le]
    simpa only [div_eq_mul_inv,one_div,one_mul] using sub_le_sub_left (hrat.trans hr) 1
  have hR0 : (0:ℝ) ≤ 1-(3/2000:ℝ)*(1/n) := by linarith
  have hlow := scalar he he'
  calc
    _ ≤ (1+3*(1/n)/20)*(1+(1000/997:ℝ)*(1/n))^3 := by
      rw [show (3:ℝ)/(20*n)=3*(1/n)/20 by ring]
      exact mul_le_mul_of_nonneg_left hA (by positivity)
    _ ≤ _ := hlow
    _ ≤ _ := by
      rw [show (3:ℝ)/(8*n)=(3/8:ℝ)*(1/n) by ring]
      exact mul_le_mul (mul_le_mul_of_nonneg_right hB (by positivity)) hR hR0 (by positivity)

/-- Improved completed frozen-C result, with all new analytic ideas retained. -/
theorem quantitative (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 10300000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+3/(20*(n:ℝ)))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases hbig : 10634121 ≤ n
  · exact E1TwoTracks.TrackAHighBaseline.quantitative hd n hbig
  have hnr : (10300000:ℝ) ≤ n := by exact_mod_cast hn
  obtain ⟨p,hp,hpm,hpl,hpu⟩ := p_exists hd
  obtain ⟨q,hq,hqm,hql,hqu⟩ := q_exists hd (by linarith : (10100000:ℝ) ≤ n)
  have hr := ratio hnr p q hpu hp hql
  let c : Criterion := {
    n := n
    hn := by omega
    p := p
    hp := hp
    hp_mono := hpm
    q := q
    hq := hq
    hq_mono := hqm
    h_ord_1 := by
      have hpp : 3273 < p 0 := hpl 0
      have hpp' : (3273:ℝ) < p 0 := by exact_mod_cast hpp
      have hnu : (n:ℝ) < (3273:ℝ)^2 := by
        have : n < 10712529 := by omega
        exact_mod_cast this
      have hs : Real.sqrt (n:ℝ) < 3273 := (Real.sqrt_lt (by positivity) (by norm_num)).mpr hnu
      exact hs.trans hpp'
    h_ord_2 := by
      have hp2 : p 2 ≤ 3351 := by simpa using hpu 2
      have hq0 := hql 0
      have hq0' : (3351:ℝ) < q 0 := by linarith
      have : 3351 < q 0 := by exact_mod_cast hq0'
      omega
    h_ord_3 := by exact_mod_cast hqu 2
    h_crit := by
      have hA0 : (0:ℝ) ≤ ∏ i, (1+(1:ℝ)/q i) := by positivity
      have hmul : (∏ i, (1+(1:ℝ)/q i)) ≤
          (1+3/(20*(n:ℝ)))*∏ i, (1+(1:ℝ)/q i) := by
        nlinarith [mul_nonneg (by positivity : (0:ℝ)≤3/(20*(n:ℝ))) hA0]
      exact hmul.trans hr
  }
  refine ⟨c.M,c.M_lt,?_⟩
  exact E1Tertiary.LcmSurplus.criterion_surplus c (by positivity) hr

#print axioms quantitative
end E1TwoTracks.TrackNFixedHigh
