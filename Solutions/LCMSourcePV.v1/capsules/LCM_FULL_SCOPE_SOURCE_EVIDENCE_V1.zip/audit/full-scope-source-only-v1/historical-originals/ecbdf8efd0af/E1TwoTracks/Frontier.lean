/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackAHighFinal
import E1TwoTracks.TrackBExactProgram
import E1TwoTracks.TrackNPower

namespace E1TwoTracks.Frontier

/-- Uniform quantitative allowance supplied by the completed frozen-C proofs.
Zero records the absence of a positive allowance from these completed proofs. -/
noncomputable def frozen (n : ℕ) : ℝ :=
  if 9920000 ≤ n then 3 / (20 * (n : ℝ))
  else if 9730000 ≤ n then 1 / (10 * (n : ℝ)) else 0

/-- The two newly verified programs supply different parts of one frontier. -/
noncomputable def evolved (n : ℕ) : ℝ :=
  if 2802276 ≤ n then 3 / (20 * (n : ℝ))
  else if 81000 ≤ n then 1 / (10 * (n : ℝ)) else 0

theorem frozen_supplied (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 9730000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + frozen n) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases hh : 9920000 ≤ n
  · simpa only [frozen, if_pos hh] using TrackNPower.quantitative_high hd n hh
  · simpa only [frozen, if_neg hh, if_pos hn] using TrackNPower.quantitative_low hd n hn

/-- Actual two-program divisor-sum theorem. The finite lower branch is
unconditional; only the larger ray uses the original 2018 literature contract. -/
theorem supplied (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 81000 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + evolved n) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases hh : 2802276 ≤ n
  · simpa only [evolved, if_pos hh] using TrackAHighFinal.quantitative hd n hh
  · have hstop : n < TrackB.exactStop := by unfold TrackB.exactStop; omega
    have hstart : TrackB.exactStart ≤ n := hn
    simpa only [evolved, if_neg hh, if_pos hn] using TrackB.exactFinite n ⟨hstart,hstop⟩

lemma margin_strict {n : ℕ} (hn : 0 < n) :
    (1 : ℝ) / (10 * n) < 3 / (20 * n) := by
  have hp : (0 : ℝ) < n := by exact_mod_cast hn
  apply (div_lt_div_iff₀ (by positivity) (by positivity)).mpr
  nlinarith

/-- Comparison is proved on the entire natural domain, including all joins. -/
theorem dominates (n : ℕ) : frozen n ≤ evolved n := by
  by_cases hh : 9920000 ≤ n
  · have he : 2802276 ≤ n := by omega
    simp [frozen, evolved, hh, he]
  · by_cases hl : 9730000 ≤ n
    · have he : 2802276 ≤ n := by omega
      simp only [frozen, evolved, if_neg hh, if_pos hl, if_pos he]
      exact (margin_strict (by omega)).le
    · simp only [frozen, if_neg hh, if_neg hl]
      unfold evolved
      split_ifs <;> positivity

/-- Strict advantage over the completed matched allowance on every integer
of this full interval. This is not a non-derivability or optimality theorem. -/
theorem strict (n : ℕ) (hn : 81000 ≤ n ∧ n < 9920000) : frozen n < evolved n := by
  have hh : ¬9920000 ≤ n := by omega
  by_cases hl : 9730000 ≤ n
  · have he : 2802276 ≤ n := by omega
    simp only [frozen, evolved, if_neg hh, if_pos hl, if_pos he]
    exact margin_strict (by omega)
  · simp only [frozen, if_neg hh, if_neg hl]
    have hp : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
    unfold evolved
    split_ifs <;> first | positivity | omega

theorem tie (n : ℕ) (hn : 9920000 ≤ n) : frozen n = evolved n := by
  have he : 2802276 ≤ n := by omega
  simp [frozen, evolved, hn, he]

end E1TwoTracks.Frontier
