import IEANTN.Nodes.EvolutionNumerics.v1.Conclusions
import IEANTN.Nodes.PrimeGap1024.v1.Conclusions
import IEANTN.Nodes.LCMStrongEvolution.v1.Conclusions
import IEANTN.Bridges.StrongEvolutionSupport.ExposureEvolution.Strong45
namespace IEANTN.Bridges.StrongEvolutionV1
set_option Elab.async false
open Real

lemma tail45 (hgap : PrimeGap1024.v1.strict_gap) (n : ℕ) (hn : 3461204224 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 9 / (20 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have he : exp (9 : ℝ) < 58832 := by
    have he1 : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
    calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
      _ ≤ (3 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le he1.le 9
      _ < 58832 := by norm_num
  have hlog : (9 : ℝ) ≤ log 58832 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) he).le
  have hreal : (58832 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  exact IEANTN.Bridges.StrongEvolutionSupport.ExposureEvolution.Strong45.quantitative_of_gap (c := 9) (hgap)
    (by norm_num) hlog n hreal


theorem whole40 (hfinite : EvolutionNumerics.v1.finite_surplus40)
    (hgap : PrimeGap1024.v1.strict_gap) : LCMStrongEvolution.v1.whole_ray40 := by
  intro n hn
  by_cases h : n < 3461204224
  · exact hfinite n ⟨hn, h⟩
  · obtain ⟨m, hpos, hsmall, hlarge⟩ := tail45 hgap n (Nat.le_of_not_lt h)
    refine ⟨m, hpos, hsmall, lt_of_le_of_lt ?_ hlarge⟩
    apply mul_le_mul_of_nonneg_right _ (by positivity)
    rw [show (2 : ℝ) / (5 * n) = (2 / 5 : ℝ) / n by ring,
      show (9 : ℝ) / (20 * n) = (9 / 20 : ℝ) / n by ring]
    have hc : (2 / 5 : ℝ) / (n : ℝ) ≤ (9 / 20 : ℝ) / (n : ℝ) :=
      div_le_div_of_nonneg_right (by norm_num : (2 / 5 : ℝ) ≤ 9 / 20) (Nat.cast_nonneg n)
    linarith [hc]

#print axioms whole40

theorem whole45 (hfinite : EvolutionNumerics.v1.finite_surplus45)
    (hgap : PrimeGap1024.v1.strict_gap) : LCMStrongEvolution.v1.whole_ray45 := by
  intro n hn
  by_cases h : n < 3461204224
  · exact hfinite n ⟨hn, h⟩
  · exact tail45 hgap n (Nat.le_of_not_lt h)

#print axioms whole45
end IEANTN.Bridges.StrongEvolutionV1
