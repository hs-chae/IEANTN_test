import ExposureEvolution.Adaptive40Data
import ExposureEvolution.Final45
namespace ExposureEvolution.Final40

theorem tail (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 3461204224 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 2 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  obtain ⟨m, hpos, hsmall, hlarge⟩ := Final45.tail hd n hn
  refine ⟨m, hpos, hsmall, lt_of_le_of_lt ?_ hlarge⟩
  apply mul_le_mul_of_nonneg_right _ (by positivity)
  rw [show (2 : ℝ) / (5 * n) = (2 / 5 : ℝ) / n by ring,
    show (9 : ℝ) / (20 * n) = (9 / 20 : ℝ) / n by ring]
  have hc : (2 / 5 : ℝ) / (n : ℝ) ≤ (9 / 20 : ℝ) / (n : ℝ) :=
    div_le_div_of_nonneg_right (by norm_num : (2 / 5 : ℝ) ≤ 9 / 20) (Nat.cast_nonneg n)
  linarith [hc]

theorem whole_ray (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 5000000 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 2 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases h : n < 3461204224
  · exact Adaptive40Data.finite n ⟨hn, h⟩
  · exact tail hd n (Nat.le_of_not_lt h)

#print axioms whole_ray
end ExposureEvolution.Final40
