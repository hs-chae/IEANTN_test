import ExposureEvolution.CompactCoverage40
import ExposureEvolution.Compact40Gap256
import ExposureEvolution.StrongOldGap40V1
namespace ExposureEvolution.Compact40FinalV1
open Real
set_option Elab.async false

lemma exp_nine_small : exp (9 : ℝ) < 8468 := by
  have he : exp 1 < (87 / 32 : ℝ) := by linarith [Real.exp_one_lt_d9]
  calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
    _ ≤ (87 / 32 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le he.le 9
    _ < 8468 := by norm_num

theorem tail (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 71707024 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 2 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hlog : (9 : ℝ) ≤ log 8468 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) exp_nine_small).le
  have hreal : (8468 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  exact StrongOldGap40V1.quantitative_of_gap (c := 9)
    (Compact40Gap256.full_gap hd) (by norm_num) hlog n hreal

/-- Same full .4/n claim, using730 finite cells and the original669-output gap provider. -/
theorem whole_ray (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 5000000 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 2 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases h : n < 71707024
  · exact CompactCoverage40.finite n ⟨by omega, h⟩
  · exact tail hd n (Nat.le_of_not_lt h)

#print axioms whole_ray
end ExposureEvolution.Compact40FinalV1
