import ChainCore
namespace Candidate
open LcmDev Multiplicity Real Finset
set_option Elab.async false
set_option maxHeartbeats 5000000
theorem scalar : FixedChain.ScalarCertificate (((1001:ℝ)/1000)^3) ((1000000000:ℝ)/1003003001) ((1:ℝ)/13) := by
  intro ε hε
  have hsmall : ε ≤ 1 := hε.2.trans (by norm_num)
  have h2 : ε^2 ≤ ε/(89693^2:ℝ) := by nlinarith [mul_nonneg hε.1 (sub_nonneg.mpr hε.2)]
  have h3 : ε^3 ≤ ε^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hsmall)]
  have h4 : ε^4 ≤ ε^3 := by nlinarith [mul_nonneg (pow_nonneg hε.1 3) (sub_nonneg.mpr hsmall)]
  have h5 : ε^5 ≤ ε^4 := by nlinarith [mul_nonneg (pow_nonneg hε.1 4) (sub_nonneg.mpr hsmall)]
  norm_num [FixedChain.ScalarCertificate]
  nlinarith [pow_nonneg hε.1 3,pow_nonneg hε.1 4,pow_nonneg hε.1 5]

theorem result : Exposure01.Goal ((1:ℚ)/13) := by
  intro source n hn
  have hn0 : (0:ℝ)<n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<89693^2) hn)
  have hs := LcmDev.hsqrt_ge hn
  have hs0 : 0<Real.sqrt (n:ℝ) := Real.sqrt_pos.mpr hn0
  have hsq := Real.sq_sqrt hn0.le
  have hstart : (89693:ℝ) ≤ ((1000000000:ℝ)/1003003001)*n := by
    have hnr : (89693^2:ℝ)≤n := by exact_mod_cast hn
    nlinarith only [hnr]
  obtain ⟨p,hp,hpm,hpl,hpu⟩ := FixedChain.source_fixed_grid source ((1001:ℝ)/1000) (Real.sqrt n) hs (by norm_num)
  obtain ⟨q,hq,hqm,hql,hqu⟩ := FixedChain.source_fixed_grid source ((1001:ℝ)/1000) (((1000000000:ℝ)/1003003001)*n) hstart (by norm_num)
  have hpbound (i : Fin 3) : (p i:ℝ)≤((1001:ℝ)/1000)^3*Real.sqrt n := by
    have hh : (p i:ℝ)≤p 2 := by exact_mod_cast hpm.monotone (Fin.le_last i)
    exact hh.trans hpu.le
  have hqbound (i : Fin 3) : ((1000000000:ℝ)/1003003001)*n≤(q i:ℝ) := by
    have hh : (q 0:ℝ)≤q i := by exact_mod_cast hqm.monotone (Fin.zero_le i)
    exact hql.le.trans hh
  have hsep : (p 2:ℝ)<q 0 := by
    have hmid : ((1001:ℝ)/1000)^3*Real.sqrt n < ((1000000000:ℝ)/1003003001)*n := by nlinarith
    exact hpu.le.trans_lt (hmid.trans hql)
  have hqend : q 2<n := by
    have hh : (q 2:ℝ)<n := by
      convert hqu using 1 <;> ring
    exact_mod_cast hh
  have hinit : (0+1:ℝ)≤((1:ℝ)/13)*Real.sqrt n := by norm_num; nlinarith
  have hbase := FixedChain.window_comparison n 0 hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
    (((1001:ℝ)/1000)^3) ((1000000000:ℝ)/1003003001) ((1:ℝ)/13) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound (by simpa using hinit) scalar
  let C : Criterion := {
    n:=n,hn:=by omega,p:=p,hp:=hp,hp_mono:=hpm,q:=q,hq:=hq,hq_mono:=hqm,
    h_ord_1:=hpl,h_ord_2:=by exact_mod_cast hsep,h_ord_3:=hqend,h_crit:=by simpa using hbase }
  let K : ℕ := Exposure01.Count ((1:ℚ)/13) n
  have hK : (K:ℝ)≤((1:ℝ)/13)*Real.sqrt n := by
    simpa only [K,Exposure01.Count,Rat.cast_div,Rat.cast_ofNat,Rat.cast_one] using
      Nat.floor_le (by positivity : (0:ℝ)≤((1:ℝ)/13)*Real.sqrt n)
  have hJ (j : ℕ) (hj : j<K) : (j+0+1:ℝ)≤((1:ℝ)/13)*Real.sqrt n := by
    have hj1 : (j+1:ℝ)≤K := by exact_mod_cast (Nat.succ_le_iff.mpr hj)
    norm_num at hs ⊢
    linarith
  have hh := FixedChain.count_offsets C K 0 (by
    intro j hj
    have hc := FixedChain.window_comparison n (j+0) hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
      (((1001:ℝ)/1000)^3) ((1000000000:ℝ)/1003003001) ((1:ℝ)/13) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound (by simpa only [Nat.cast_add,Nat.cast_zero,Nat.cast_one] using hJ j hj) scalar
    simpa only [Nat.cast_add,Nat.cast_zero,Nat.cast_one] using hc)
  simpa only [C,K] using hh
theorem comparison : Exposure01.Comparison ((1:ℚ)/13) := by
  norm_num [Exposure01.Comparison,Exposure01.Count]
end Candidate
