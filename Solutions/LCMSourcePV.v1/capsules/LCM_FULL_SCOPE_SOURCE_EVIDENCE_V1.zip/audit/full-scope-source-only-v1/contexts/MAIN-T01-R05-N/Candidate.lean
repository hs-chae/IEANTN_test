import ChainCore
namespace Candidate
open LcmDev Multiplicity Real Finset
set_option Elab.async false
set_option maxHeartbeats 5000000
theorem scalar : FixedChain.ScalarCertificate (((1301:ℝ)/1300)^3) ((997:ℝ)/1000) ((2:ℝ)/25) := by
  intro ε hε
  have hsmall : ε ≤ 1 := hε.2.trans (by norm_num)
  have h2 : ε^2 ≤ ε/(89693^2:ℝ) := by nlinarith [mul_nonneg hε.1 (sub_nonneg.mpr hε.2)]
  have h3 : ε^3 ≤ ε^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hsmall)]
  have h4 : ε^4 ≤ ε^3 := by nlinarith [mul_nonneg (pow_nonneg hε.1 3) (sub_nonneg.mpr hsmall)]
  have h5 : ε^5 ≤ ε^4 := by nlinarith [mul_nonneg (pow_nonneg hε.1 4) (sub_nonneg.mpr hsmall)]
  norm_num [FixedChain.ScalarCertificate]
  nlinarith [pow_nonneg hε.1 3,pow_nonneg hε.1 4,pow_nonneg hε.1 5]

theorem uniform_scalar : FixedChain.ScalarCertificate (((1301:ℝ)/1300)^3) ((997:ℝ)/1000) ((893296945009618425111982250:ℝ)/10678141438471345233208851701) := by
  intro ε hε
  have hsmall : ε ≤ 1 := hε.2.trans (by norm_num)
  have h2 : ε^2 ≤ ε/(89693^2:ℝ) := by nlinarith [mul_nonneg hε.1 (sub_nonneg.mpr hε.2)]
  have h3 : ε^3 ≤ ε^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hsmall)]
  have h4 : ε^4 ≤ ε^3 := by nlinarith [mul_nonneg (pow_nonneg hε.1 3) (sub_nonneg.mpr hsmall)]
  have h5 : ε^5 ≤ ε^4 := by nlinarith [mul_nonneg (pow_nonneg hε.1 4) (sub_nonneg.mpr hsmall)]
  norm_num [FixedChain.ScalarCertificate]
  nlinarith [pow_nonneg hε.1 3,pow_nonneg hε.1 4,pow_nonneg hε.1 5]

theorem result : Exposure01.Goal ((2:ℚ)/25) := by
  intro source n hn
  have hn0 : (0:ℝ)<n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<89693^2) hn)
  have hs := LcmDev.hsqrt_ge hn
  have hs0 : 0<Real.sqrt (n:ℝ) := Real.sqrt_pos.mpr hn0
  have hsq := Real.sq_sqrt hn0.le
  have hstart : (89693:ℝ) ≤ ((997:ℝ)/1000)*n := by
    have hnr : (89693^2:ℝ)≤n := by exact_mod_cast hn
    nlinarith only [hnr]
  obtain ⟨p,hp,hpm,hpl,hpu⟩ := FixedChain.source_three source ((1301:ℝ)/1300) (Real.sqrt n) hs (by norm_num)
  obtain ⟨q,hq,hqm,hql,hqu⟩ := FixedChain.source_three source (40027/40000) (((997:ℝ)/1000)*n) hstart (by norm_num)
  have hpbound (i : Fin 3) : (p i:ℝ)≤((1301:ℝ)/1300)^3*Real.sqrt n := by
    have hh : (p i:ℝ)≤p 2 := by exact_mod_cast hpm.monotone (Fin.le_last i)
    exact hh.trans hpu
  have hqbound (i : Fin 3) : ((997:ℝ)/1000)*n≤(q i:ℝ) := by
    have hh : (q 0:ℝ)≤q i := by exact_mod_cast hqm.monotone (Fin.zero_le i)
    exact hql.le.trans hh
  have hsep : (p 2:ℝ)<q 0 := by
    have hmid : ((1301:ℝ)/1300)^3*Real.sqrt n < ((997:ℝ)/1000)*n := by nlinarith
    exact hpu.trans_lt (hmid.trans hql)
  have hqend : q 2<n := by
    have hh : (q 2:ℝ)<n := by
      nlinarith only [hqu,hn0]
    exact_mod_cast hh
  have hinit : (0+1:ℝ)≤((2:ℝ)/25)*Real.sqrt n := by norm_num; nlinarith
  have hbase := FixedChain.window_comparison n 0 hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
    (((1301:ℝ)/1300)^3) ((997:ℝ)/1000) ((2:ℝ)/25) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound (by simpa using hinit) scalar
  let C : Criterion := {
    n:=n,hn:=by omega,p:=p,hp:=hp,hp_mono:=hpm,q:=q,hq:=hq,hq_mono:=hqm,
    h_ord_1:=hpl,h_ord_2:=by exact_mod_cast hsep,h_ord_3:=hqend,h_crit:=by simpa using hbase }
  let K : ℕ := Exposure01.Count ((2:ℚ)/25) n
  have hK : (K:ℝ)≤((2:ℝ)/25)*Real.sqrt n := by
    simpa only [K,Exposure01.Count,Rat.cast_div,Rat.cast_ofNat,Rat.cast_one] using
      Nat.floor_le (by positivity : (0:ℝ)≤((2:ℝ)/25)*Real.sqrt n)
  have hJ (j : ℕ) (hj : j<K) : (j+0+1:ℝ)≤((2:ℝ)/25)*Real.sqrt n := by
    have hj1 : (j+1:ℝ)≤K := by exact_mod_cast (Nat.succ_le_iff.mpr hj)
    norm_num at hs ⊢
    linarith
  let P : ℝ := ∏ i,(p i:ℝ)
  let Q : ℝ := ∏ i,(q i:ℝ)
  let T : ℝ := Q/(4*P)
  let β : ℝ := 1/(1+((17:ℝ)/50)/(n:ℝ))
  let β' : ℝ := 1-((340001:ℝ)/1000000)/(n:ℝ)
  let lo : ℝ := β*T
  let I : Finset ℕ := Finset.Ico (Nat.floor lo+1) (Nat.ceil T)
  let κ : ℝ := 4*((2:ℝ)/25)*((((1301:ℝ)/1300)^3)/((997:ℝ)/1000))^3
  have hP : 0 < P := Finset.prod_pos fun i _ => by exact_mod_cast (hp i).pos
  have hQ : 0 < Q := Finset.prod_pos fun i _ => by exact_mod_cast (hq i).pos
  have hT : 0 < T := by dsimp [T]; positivity
  have hnr : (89693^2:ℝ) ≤ n := by exact_mod_cast hn
  have hβ : 0 < β := by dsimp [β]; positivity
  have hlo : 0 < lo := mul_pos hβ hT
  have hratio (t : ℕ) : (witness C t:ℝ)/(L C.n) = (t:ℝ)/T := by
    rw [FixedChain.witness_ratio]
    dsimp [T,P,Q,C]
    field_simp
    <;> ring
  have hu := FixedChain.window_uniform n hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
    (((1301:ℝ)/1300)^3) ((997:ℝ)/1000) ((893296945009618425111982250:ℝ)/10678141438471345233208851701) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound uniform_scalar
  have hformula : 4*((893296945009618425111982250:ℝ)/10678141438471345233208851701)*((((1301:ℝ)/1300)^3)/((997:ℝ)/1000))^3*(1/(n:ℝ)) = ((340001:ℝ)/1000000)/(n:ℝ) := by norm_num; ring
  rw [hformula] at hu
  have hbelow : β' < β := by
    have hdiv : ((17:ℝ)/50)/(n:ℝ)<((340001:ℝ)/1000000)/(n:ℝ) := div_lt_div_of_pos_right (by norm_num) hn0
    have hm : 1-((17:ℝ)/50)/(n:ℝ) ≤ 1/(1+((17:ℝ)/50)/(n:ℝ)) := by
      apply (le_div_iff₀ (by positivity : (0:ℝ)<1+((17:ℝ)/50)/(n:ℝ))).mpr
      nlinarith [sq_nonneg (((17:ℝ)/50)/(n:ℝ))]
    dsimp [β',β]
    linarith
  have hlimit : β ≤ 1-κ/(n:ℝ) := by
    dsimp [β]
    apply (div_le_iff₀ (by positivity : (0:ℝ)<1+((17:ℝ)/50)/(n:ℝ))).mpr
    dsimp [κ]
    field_simp
    nlinarith only [hnr]
  have hbounds (t : ℕ) (ht : t ∈ I) : lo ≤ (t:ℝ) ∧ (t:ℝ)<T := by
    obtain ⟨hl,hh⟩ := Finset.mem_Ico.mp ht
    have hh' : lo < (Nat.floor lo+1:ℕ) := by exact_mod_cast Nat.lt_floor_add_one lo
    exact ⟨(hh'.trans_le (by exact_mod_cast hl)).le,Nat.lt_ceil.mp hh⟩
  have hmem (j : ℕ) (hj : j < K) : C.m-j ∈ I := by
    have hc := FixedChain.window_comparison n j hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
      (((1301:ℝ)/1300)^3) ((997:ℝ)/1000) ((2:ℝ)/25) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound (by simpa using hJ j hj) scalar
    have hg := FixedChain.offset_density C j hc
    have hjm : j < C.m := by omega
    have hr := FixedChain.offset_ratio C j hjm
    have hl := FixedChain.window_loss n j hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
      (((1301:ℝ)/1300)^3) ((997:ℝ)/1000) ((2:ℝ)/25) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound (by simpa using hJ j hj)
    have hlow : lo < ((C.m-j:ℕ):ℝ) := by
      have hl' : 4*(j+1:ℝ)*P/Q ≤ κ/(n:ℝ) := by simpa [κ,P,Q,div_eq_mul_inv,mul_assoc] using hl
      have hh : β < ((C.m-j:ℕ):ℝ)/T := by
        rw [← hratio]
        change 1-4*(j+1:ℝ)*P/Q < (witness C (C.m-j):ℝ)/(L C.n) at hr
        linarith only [hr,hl',hlimit]
      exact (lt_div_iff₀ hT).mp hh
    have hupper : ((C.m-j:ℕ):ℝ) < T := by
      apply (div_lt_one hT).mp
      rw [← hratio]
      exact (div_lt_one (by exact_mod_cast C.L_pos : (0:ℝ)<L C.n)).mpr (by exact_mod_cast hg.2.1)
    apply Finset.mem_Ico.mpr
    exact ⟨by have hf := (Nat.floor_lt hlo.le).mpr hlow; omega,Nat.lt_ceil.mpr hupper⟩
  have hh := FixedChain.count_from_offsets C K I hmem (by
    intro t ht
    have hb := (hbounds t ht).1
    exact_mod_cast hlo.trans_le hb) (by
    intro t ht
    obtain ⟨hl,hh⟩ := hbounds t ht
    have htpos : 0 < t := by exact_mod_cast hlo.trans_le hl
    have hsmall : witness C t < L C.n := by
      have hr : (witness C t:ℝ)/(L C.n) < 1 := by rw [hratio]; exact (div_lt_one hT).mpr hh
      exact_mod_cast (div_lt_one (by exact_mod_cast C.L_pos : (0:ℝ)<L C.n)).mp hr
    apply FixedChain.ratio_good C t β' htpos hsmall
    · rw [hratio]
      exact hbelow.trans_le ((le_div_iff₀ hT).mpr hl)
    · change (∏ i,(1+(1:ℝ)/q i)) ≤ (∏ i,(1+1/(p i*(p i+1):ℝ)))*(1+3/(8*(n:ℝ)))*(1-((340001:ℝ)/1000000)/(n:ℝ))
      exact hu)
  simpa only [C,K] using hh
theorem comparison : Exposure01.Comparison ((2:ℚ)/25) := by
  norm_num [Exposure01.Comparison,Exposure01.Count]
end Candidate
