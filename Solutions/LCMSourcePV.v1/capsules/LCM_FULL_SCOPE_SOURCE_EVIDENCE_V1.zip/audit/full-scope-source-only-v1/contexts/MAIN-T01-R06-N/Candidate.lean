import ChainCore
namespace Candidate
open LcmDev Multiplicity Real Finset
set_option Elab.async false
set_option maxHeartbeats 5000000
theorem scalar : FixedChain.ScalarCertificate (((1001:ℝ)/1000)^3) ((1000000000000:ℝ)/1004006004001) ((49:ℝ)/600) := by
  intro ε hε
  have hsmall : ε ≤ 1 := hε.2.trans (by norm_num)
  have h2 : ε^2 ≤ ε/(89693^2:ℝ) := by nlinarith [mul_nonneg hε.1 (sub_nonneg.mpr hε.2)]
  have h3 : ε^3 ≤ ε^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hsmall)]
  have h4 : ε^4 ≤ ε^3 := by nlinarith [mul_nonneg (pow_nonneg hε.1 3) (sub_nonneg.mpr hsmall)]
  have h5 : ε^5 ≤ ε^4 := by nlinarith [mul_nonneg (pow_nonneg hε.1 4) (sub_nonneg.mpr hsmall)]
  norm_num [FixedChain.ScalarCertificate]
  nlinarith [pow_nonneg hε.1 3,pow_nonneg hε.1 4,pow_nonneg hε.1 5]

theorem uniform_scalar : FixedChain.ScalarCertificate (((1001:ℝ)/1000)^3) ((1000000000000:ℝ)/1004006004001) ((250000750000000000000000000000000000000000000000000000000000000:ℝ)/3063634008016210141451352849207030400819002853064958990630063003) := by
  intro ε hε
  have hsmall : ε ≤ 1 := hε.2.trans (by norm_num)
  have h2 : ε^2 ≤ ε/(89693^2:ℝ) := by nlinarith [mul_nonneg hε.1 (sub_nonneg.mpr hε.2)]
  have h3 : ε^3 ≤ ε^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hsmall)]
  have h4 : ε^4 ≤ ε^3 := by nlinarith [mul_nonneg (pow_nonneg hε.1 3) (sub_nonneg.mpr hsmall)]
  have h5 : ε^5 ≤ ε^4 := by nlinarith [mul_nonneg (pow_nonneg hε.1 4) (sub_nonneg.mpr hsmall)]
  norm_num [FixedChain.ScalarCertificate]
  nlinarith [pow_nonneg hε.1 3,pow_nonneg hε.1 4,pow_nonneg hε.1 5]

theorem result : Exposure01.Goal ((49:ℚ)/600) := by
  intro source n hn
  have hn0 : (0:ℝ)<n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<89693^2) hn)
  have hs := LcmDev.hsqrt_ge hn
  have hs0 : 0<Real.sqrt (n:ℝ) := Real.sqrt_pos.mpr hn0
  have hsq := Real.sq_sqrt hn0.le
  have hstart : (89693:ℝ) ≤ ((1000000000000:ℝ)/1004006004001)*n := by
    have hnr : (89693^2:ℝ)≤n := by exact_mod_cast hn
    nlinarith only [hnr]
  obtain ⟨p,hp,hpm,hpl,hpu,hpproduct⟩ := FixedChain.source_three_product source ((1001:ℝ)/1000) (Real.sqrt n) hs (by norm_num)
  obtain ⟨q,hq,hqm,hql,hqu⟩ := FixedChain.source_three source (40027/40000) (((1000000000000:ℝ)/1004006004001)*n) hstart (by norm_num)
  have hpbound (i : Fin 3) : (p i:ℝ)≤((1001:ℝ)/1000)^3*Real.sqrt n := by
    have hh : (p i:ℝ)≤p 2 := by exact_mod_cast hpm.monotone (Fin.le_last i)
    exact hh.trans hpu
  have hqbound (i : Fin 3) : ((1000000000000:ℝ)/1004006004001)*n≤(q i:ℝ) := by
    have hh : (q 0:ℝ)≤q i := by exact_mod_cast hqm.monotone (Fin.zero_le i)
    exact hql.le.trans hh
  have hsep : (p 2:ℝ)<q 0 := by
    have hmid : ((1001:ℝ)/1000)^3*Real.sqrt n < ((1000000000000:ℝ)/1004006004001)*n := by nlinarith
    exact hpu.trans_lt (hmid.trans hql)
  have hqend : q 2<n := by
    have hh : (q 2:ℝ)<n := by
      nlinarith only [hqu,hn0]
    exact_mod_cast hh
  have hinit : (0+1:ℝ)≤((49:ℝ)/600)*Real.sqrt n := by norm_num; nlinarith
  have hbase := FixedChain.window_comparison n 0 hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
    (((1001:ℝ)/1000)^3) ((1000000000000:ℝ)/1004006004001) ((49:ℝ)/600) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound (by simpa using hinit) scalar
  let C : Criterion := {
    n:=n,hn:=by omega,p:=p,hp:=hp,hp_mono:=hpm,q:=q,hq:=hq,hq_mono:=hqm,
    h_ord_1:=hpl,h_ord_2:=by exact_mod_cast hsep,h_ord_3:=hqend,h_crit:=by simpa using hbase }
  let K : ℕ := Exposure01.Count ((49:ℚ)/600) n
  have hK : (K:ℝ)≤((49:ℝ)/600)*Real.sqrt n := by
    simpa only [K,Exposure01.Count,Rat.cast_div,Rat.cast_ofNat,Rat.cast_one] using
      Nat.floor_le (by positivity : (0:ℝ)≤((49:ℝ)/600)*Real.sqrt n)
  have hJ (j : ℕ) (hj : j<K) : (j+0+1:ℝ)≤((49:ℝ)/600)*Real.sqrt n := by
    have hj1 : (j+1:ℝ)≤K := by exact_mod_cast (Nat.succ_le_iff.mpr hj)
    norm_num at hs ⊢
    linarith
  let P : ℝ := ∏ i,(p i:ℝ)
  let Q : ℝ := ∏ i,(q i:ℝ)
  let T : ℝ := Q/(4*P)
  let β : ℝ := 1-((1:ℝ)/3)/(n:ℝ)
  let β' : ℝ := 1-((1000003:ℝ)/3000000)/(n:ℝ)
  let lo : ℝ := β*T
  let I : Finset ℕ := Finset.Ico (Nat.ceil lo) (Nat.ceil T)
  let κ : ℝ := 4*((49:ℝ)/600)*((((1001:ℝ)/1000)^3)/((1000000000000:ℝ)/1004006004001))^3
  have hP : 0 < P := Finset.prod_pos fun i _ => by exact_mod_cast (hp i).pos
  have hQ : 0 < Q := Finset.prod_pos fun i _ => by exact_mod_cast (hq i).pos
  have hT : 0 < T := by dsimp [T]; positivity
  have hnr : (89693^2:ℝ) ≤ n := by exact_mod_cast hn
  have hβ : 0 < β := by dsimp [β]; apply sub_pos.mpr; exact (div_lt_one hn0).mpr (by nlinarith only [hnr])
  have hlo : 0 < lo := mul_pos hβ hT
  have hratio (t : ℕ) : (witness C t:ℝ)/(L C.n) = (t:ℝ)/T := by
    rw [FixedChain.witness_ratio]
    dsimp [T,P,Q,C]
    field_simp
    <;> ring
  have hu := FixedChain.window_uniform n hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
    (((1001:ℝ)/1000)^3) ((1000000000000:ℝ)/1004006004001) ((250000750000000000000000000000000000000000000000000000000000000:ℝ)/3063634008016210141451352849207030400819002853064958990630063003) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound uniform_scalar
  have hformula : 4*((250000750000000000000000000000000000000000000000000000000000000:ℝ)/3063634008016210141451352849207030400819002853064958990630063003)*((((1001:ℝ)/1000)^3)/((1000000000000:ℝ)/1004006004001))^3*(1/(n:ℝ)) = ((1000003:ℝ)/3000000)/(n:ℝ) := by norm_num; ring
  rw [hformula] at hu
  have hbelow : β' < β := by
    have hh := div_lt_div_of_pos_right (by norm_num : (((1:ℝ)/3):ℝ)<((1000003:ℝ)/3000000)) hn0
    dsimp [β',β]
    linarith
  have hprod : P ≤ ((1006015020015006001:ℝ)/1000000000000000000)*(Real.sqrt n)^3 := by convert hpproduct using 1 <;> norm_num [P]
  have hqprod : ((1000000000000000000000000000000000000:ℝ)/1012066220495792924792495220066012001)*(n:ℝ)^3 ≤ Q := by
    calc
      _ = ∏ _i : Fin 3, ((1000000000000:ℝ)/1004006004001)*(n:ℝ) := by simp; ring
      _ ≤ Q := by dsimp [Q]; gcongr with i; exact hqbound i
  have hTlower := FixedChain.quotient_lower n hn0 p q (fun i=>(hp i).pos) ((1006015020015006001:ℝ)/1000000000000000000) ((1000000000000000000000000000000000000:ℝ)/1012066220495792924792495220066012001) (by norm_num) (by norm_num) hprod hqprod
  change ((1000000000000000000000000000000000000:ℝ)/1012066220495792924792495220066012001)/(4*((1006015020015006001:ℝ)/1000000000000000000))*(n:ℝ)*Real.sqrt n ≤ T at hTlower
  have hwidth : T-lo=((1:ℝ)/3)*T/(n:ℝ) := by dsimp [lo,β]; ring
  have hwidthlower : ((1:ℝ)/3)*((1000000000000000000000000000000000000:ℝ)/1012066220495792924792495220066012001)/(4*((1006015020015006001:ℝ)/1000000000000000000))*Real.sqrt n ≤ T-lo := by
    rw [hwidth]
    have hh := mul_le_mul_of_nonneg_left hTlower (show (0:ℝ)≤((1:ℝ)/3)/(n:ℝ) by positivity)
    calc
      ((1:ℝ)/3)*((1000000000000000000000000000000000000:ℝ)/1012066220495792924792495220066012001)/(4*((1006015020015006001:ℝ)/1000000000000000000))*Real.sqrt n = (((1:ℝ)/3)/(n:ℝ))*(((1000000000000000000000000000000000000:ℝ)/1012066220495792924792495220066012001)/(4*((1006015020015006001:ℝ)/1000000000000000000))*(n:ℝ)*Real.sqrt n) := by field_simp <;> ring
      _ ≤ (((1:ℝ)/3)/(n:ℝ))*T := hh
      _ = ((1:ℝ)/3)*T/(n:ℝ) := by ring
  let Kactual : ℕ := Nat.floor (T/(3*(n:ℝ)))
  let start : ℕ := Nat.ceil lo
  have hwidthid : T-lo=T/(3*(n:ℝ)) := by rw [hwidth]; ring
  have hactual : (Kactual:ℝ)≤T-lo := by
    rw [hwidthid]
    exact Nat.floor_le (by positivity)
  have htarget : ((49:ℝ)/600)*Real.sqrt n ≤ T/(3*(n:ℝ)) := by
    rw [← hwidthid]
    have hc : (((49:ℝ)/600):ℝ)≤((1:ℝ)/3)*((1000000000000000000000000000000000000:ℝ)/1012066220495792924792495220066012001)/(4*((1006015020015006001:ℝ)/1000000000000000000)) := by norm_num
    exact (mul_le_mul_of_nonneg_right hc (Real.sqrt_nonneg _)).trans hwidthlower
  have hcount : K≤Kactual := by
    simpa only [K,Kactual,Exposure01.Count,Rat.cast_div,Rat.cast_ofNat] using Nat.floor_mono htarget
  have hgood (j : ℕ) (hj : j < Kactual) : 0 < witness C (start+j) ∧
      witness C (start+j) < L C.n ∧ (σ (L C.n):ℝ) < σ (witness C (start+j)) := by
    have hj1 : (j+1:ℝ)≤Kactual := by exact_mod_cast (Nat.succ_le_iff.mpr hj)
    have hlow : lo ≤ (start+j:ℝ) := by
      have hh := Nat.le_ceil lo
      dsimp [start]
      push_cast
      linarith [(Nat.cast_nonneg j : (0:ℝ) ≤ j)]
    have hupper : (start+j:ℝ)<T := by
      have hh := Nat.ceil_lt_add_one hlo.le
      dsimp [start]
      push_cast
      linarith
    have htpos : 0 < start+j := by exact_mod_cast hlo.trans_le hlow
    have hsmall : witness C (start+j) < L C.n := by
      have hr : (witness C (start+j):ℝ)/(L C.n) < 1 := by rw [hratio]; exact (div_lt_one hT).mpr (by simpa only [Nat.cast_add] using hupper)
      exact_mod_cast (div_lt_one (by exact_mod_cast C.L_pos : (0:ℝ)<L C.n)).mp hr
    apply FixedChain.ratio_good C (start+j) β' htpos hsmall
    · rw [hratio]
      exact hbelow.trans_le ((le_div_iff₀ hT).mpr (by simpa only [Nat.cast_add] using hlow))
    · change (∏ i,(1+(1:ℝ)/q i)) ≤ (∏ i,(1+1/(p i*(p i+1):ℝ)))*(1+3/(8*(n:ℝ)))*(1-((1000003:ℝ)/3000000)/(n:ℝ))
      exact hu
  obtain ⟨S,hcard,hgoodS⟩ := FixedChain.count_ascending C Kactual start hgood
  refine ⟨S,?_,?_⟩
  · change K≤S.card
    rw [hcard]
    exact hcount
  · simpa only [C] using hgoodS
theorem comparison : Exposure01.Comparison ((49:ℚ)/600) := by
  norm_num [Exposure01.Comparison,Exposure01.Count]
end Candidate
