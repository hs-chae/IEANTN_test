/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import QRHRound2.LcmWitnessNoPVMath
/-! New exact rational budget for the two-prime-power analytic construction.
For k=80 and n>=10^200, explicit prime-location bounds imply margin (4/5)/n.
All scalar inequalities are ordinary Lean algebra and introduce no numerical output. -/
namespace QRHRound2.LcmWitnessNoPVBounds
open Finset Nat Real QRHRound2.LcmWitnessNoPVBase QRHRound2.LcmWitnessNoPVMath
set_option maxHeartbeats 4000000

theorem scalar {e : ℝ} (he : 0 ≤ e) (heu : e ≤ 1 / 1000000) :
    (1 + 4 / 5 * e) * (1 + (100002 / 100000 : ℝ) * e)^3 ≤
      (1 + 2997 / 1000 * e) * (1 + 499 / 1000 * e) *
        (1 + 333 / 1000 * e) * (1 - e / 1000) := by
  have h2 : e^2 ≤ e / 1000000 := by nlinarith
  have h3 : e^3 ≤ e^2 / 1000000 := by
    nlinarith [mul_nonneg (sq_nonneg e) (sub_nonneg.mpr heu)]
  have h4 : e^4 ≤ e^2 / 1000000^2 := by
    have hh := mul_le_mul_of_nonneg_right h3 he
    nlinarith
  nlinarith [sq_nonneg e]

theorem budget (C : PowerCriterion) (hk : C.k = 80)
    (hn : (10 : ℝ)^200 ≤ C.n)
    (hp : ∀ i, (C.p i : ℝ) ≤ (100001 / 100000 : ℝ) * √(C.n : ℝ))
    (hq : ∀ i, (99999 / 100000 : ℝ) * C.n ≤ C.q i) :
    (1 + (4 / 5 : ℝ) / C.n) * ∏ i, (1 + (1 : ℝ) / C.q i) ≤
      (∏ i, (1 + 1 / (C.p i * (C.p i + 1) : ℝ))) *
        core2 C * core3 C *
        (1 - 6^C.k * (∏ i, (C.p i : ℝ)) / ∏ i, (C.q i : ℝ)) := by
  have hnpos : (0 : ℝ) < C.n := by exact_mod_cast C.hn
  have hs0 := Real.sqrt_nonneg (C.n : ℝ)
  have hs2 := Real.sq_sqrt (show (0 : ℝ) ≤ C.n by positivity)
  have hs : (10 : ℝ)^100 ≤ √(C.n : ℝ) := by
    apply Real.le_sqrt_of_sq_le
    nlinarith only [hn]
  have he : (0 : ℝ) ≤ 1 / C.n := by positivity
  have heu : (1 : ℝ) / C.n ≤ 1 / 1000000 := by
    rw [div_le_div_iff₀ hnpos (by norm_num)]
    norm_num at hn ⊢
    linarith
  have hpp (i : Fin 3) : (C.p i : ℝ) * (C.p i + 1) ≤ (1000 / 999 : ℝ) * C.n := by
    have hp0 : (0 : ℝ) ≤ C.p i := by positivity
    have hpsq := sq_le_sq₀ hp0 (by positivity : (0 : ℝ) ≤ (100001 / 100000 : ℝ) * √(C.n : ℝ)) |>.mpr (hp i)
    nlinarith [hp i, mul_nonneg hs0 (sub_nonneg.mpr hs)]
  have hpi (i : Fin 3) : 1 + (999 / 1000 : ℝ) * (1 / C.n) ≤
      1 + 1 / (C.p i * (C.p i + 1) : ℝ) := by
    have pp : (0 : ℝ) < C.p i := by exact_mod_cast (C.hp i).pos
    have hh := one_div_le_one_div_of_le (by positivity : (0 : ℝ) < (C.p i : ℝ) * (C.p i + 1)) (hpp i)
    have heq : (1 : ℝ) / ((1000 / 999 : ℝ) * C.n) = 999 / 1000 * (1 / C.n) := by field_simp <;> ring
    rw [heq] at hh
    linarith
  have hBp : 1 + 2997 / 1000 * (1 / (C.n : ℝ)) ≤
      ∏ i, (1 + 1 / (C.p i * (C.p i + 1) : ℝ)) := by
    have hh := Finset.prod_le_prod₀ (s := Finset.univ)
      (fun (i : Fin 3) _ => by positivity : ∀ i ∈ Finset.univ, 0 ≤ 1 + (999 / 1000 : ℝ) * (1 / C.n))
      (fun i _ => hpi i)
    have hh' : (1 + (999 / 1000 : ℝ) * (1 / C.n))^3 ≤
        ∏ i, (1 + 1 / (C.p i * (C.p i + 1) : ℝ)) := by
      simpa [Fin.prod_univ_three, pow_succ] using hh
    refine le_trans ?_ hh'
    nlinarith [sq_nonneg ((1 : ℝ) / C.n), pow_nonneg he 3]
  have hqi (i : Fin 3) : 1 + (1 : ℝ) / C.q i ≤ 1 + (100002 / 100000 : ℝ) * (1 / C.n) := by
    have hh := one_div_le_one_div_of_le
      (show (0 : ℝ) < (99999 / 100000 : ℝ) * C.n by positivity) (hq i)
    have hh2 : (1 : ℝ) / ((99999 / 100000 : ℝ) * C.n) ≤
        (100002 / 100000 : ℝ) * (1 / C.n) := by
      field_simp
      nlinarith
    linarith
  have hAq : ∏ i, (1 + (1 : ℝ) / C.q i) ≤ (1 + (100002 / 100000 : ℝ) * (1 / C.n))^3 := by
    have hh := Finset.prod_le_prod₀ (s := Finset.univ)
      (fun (i : Fin 3) _ => by positivity : ∀ i ∈ Finset.univ, 0 ≤ 1 + (1 : ℝ) / C.q i)
      (fun i _ => hqi i)
    simpa [Fin.prod_univ_three, pow_succ] using hh
  have hP : (∏ i, (C.p i : ℝ)) ≤ ((100001 / 100000 : ℝ) * √(C.n : ℝ))^3 := by
    have hh := Finset.prod_le_prod₀ (s := Finset.univ)
      (fun (i : Fin 3) _ => by positivity : ∀ i ∈ Finset.univ, (0 : ℝ) ≤ C.p i)
      (fun i _ => hp i)
    simpa [Fin.prod_univ_three, pow_succ] using hh
  have hQ : ((99999 / 100000 : ℝ) * C.n)^3 ≤ ∏ i, (C.q i : ℝ) := by
    have hh := Finset.prod_le_prod₀ (s := Finset.univ)
      (fun (i : Fin 3) _ => by positivity : ∀ i ∈ Finset.univ, (0 : ℝ) ≤ (99999 / 100000 : ℝ) * C.n)
      (fun i _ => hq i)
    simpa [Fin.prod_univ_three, pow_succ] using hh
  have hround : (6 : ℝ)^C.k * (∏ i, (C.p i : ℝ)) / ∏ i, (C.q i : ℝ) ≤ (1 / (C.n : ℝ)) / 1000 := by
    have hratio : (6 : ℝ)^80 * (∏ i, (C.p i : ℝ)) / (∏ i, (C.q i : ℝ)) ≤
        (6 : ℝ)^80 * ((100001 / 100000 : ℝ) * √(C.n : ℝ))^3 / ((99999 / 100000 : ℝ) * C.n)^3 :=
      div_le_div₀ (by positivity)
        (mul_le_mul_of_nonneg_left hP (by positivity : (0 : ℝ) ≤ 6^80))
        (by positivity : (0 : ℝ) < ((99999 / 100000 : ℝ) * C.n)^3) hQ
    rw [hk]
    refine hratio.trans ?_
    rw [div_le_div_iff₀ (by positivity : (0 : ℝ) < ((99999 / 100000 : ℝ) * C.n)^3) (by norm_num : (0 : ℝ) < 1000)]
    field_simp
    have hc : (1000 : ℝ) * 6^80 * 100001^3 ≤ 99999^3 * √(C.n : ℝ) := by
      calc _ ≤ (99999 : ℝ)^3 * 10^100 := by norm_num
        _ ≤ _ := mul_le_mul_of_nonneg_left hs (by positivity)
    conv_rhs => rw [←hs2]
    convert mul_le_mul_of_nonneg_right hc (pow_nonneg hs0 3) using 1 <;> first | rfl | ring
  have h2 : 1 + 499 / 1000 * (1 / (C.n : ℝ)) ≤ core2 C := by
    dsimp [core2]; rw [hk]
    have hc : (499 / 1000 : ℝ) ≤ (1 - (1 / 2)^80) / 2 := by norm_num
    have hh := mul_le_mul_of_nonneg_right hc he
    convert (add_le_add_right hh 1) using 1 <;> first | rfl | (simp only [div_eq_mul_inv, mul_inv_rev]; ring)
  have h3 : 1 + 333 / 1000 * (1 / (C.n : ℝ)) ≤ core3 C := by
    dsimp [core3]; rw [hk]
    have hc : (333 / 1000 : ℝ) ≤ (1 - (1 / 3)^80) / 3 := by norm_num
    have hh := mul_le_mul_of_nonneg_right hc he
    convert (add_le_add_right hh 1) using 1 <;> first | rfl | (simp only [div_eq_mul_inv, mul_inv_rev]; ring)
  have hr0 : 0 ≤ 1 - (1 / (C.n : ℝ)) / 1000 := by linarith
  have hh := scalar he heu
  have hmul := mul_le_mul_of_nonneg_left hAq (show 0 ≤ 1 + (4 / 5 : ℝ) / C.n by positivity)
  have hcore2pos := core2_pos C
  have hcore3pos := core3_pos C
  have hright : (1 + 2997 / 1000 * (1 / (C.n : ℝ))) *
      (1 + 499 / 1000 * (1 / (C.n : ℝ))) *
      (1 + 333 / 1000 * (1 / (C.n : ℝ))) * (1 - (1 / (C.n : ℝ)) / 1000) ≤
      (∏ i, (1 + 1 / (C.p i * (C.p i + 1) : ℝ))) * core2 C * core3 C *
        (1 - 6^C.k * (∏ i, (C.p i : ℝ)) / ∏ i, (C.q i : ℝ)) := by
    gcongr <;> positivity
  apply hmul.trans
  convert hh.trans hright using 1 <;> ring
end QRHRound2.LcmWitnessNoPVBounds
