/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import QRHRound2.LcmWitnessNoPVBounds
import QRHRound2.LcmWitnessNoPVPrimes
import IEANTN.Nodes.Dusart2018.v1.Conclusions
/-! Completed old-source-only analytic sigma-surplus ray.
The explicit hypothesis Dusart2018.v1.proposition_5_4 is the inherited literature
contract from Proposition5.4, PDFp16/printed242; this file derives a strict10^-6
relative prime interval above exp101 and supplies the new6^80 construction. -/
namespace QRHRound2.LcmWitnessNoPV
open Finset Nat Real QRHRound2.LcmWitnessNoPVBase
open QRHRound2.LcmWitnessNoPVMath QRHRound2.LcmWitnessNoPVBounds
open QRHRound2.LcmWitnessNoPVPrimes
set_option maxHeartbeats 4000000
set_option maxRecDepth 4000

/-- The unchanged Dusart 2018 prime-interval contract, with a very generous threshold. -/
theorem gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap (exp 101) := by
  intro x hx
  have he : (89693 : ℝ) < exp 101 := by
    calc (89693 : ℝ) < 2^101 := by norm_num
      _ ≤ (exp 1)^101 := pow_le_pow_left₀ (by norm_num) (by linarith [Real.exp_one_gt_d9]) _
      _ = exp 101 := by rw [Real.exp_one_pow]; norm_num
  have hxp : 0 < x := (exp_pos 101).trans_le hx
  have hl : (101 : ℝ) ≤ log x := by
    simpa only [log_exp] using log_le_log (exp_pos 101) hx
  have hc : (1000000 : ℝ) < log x ^ 3 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hl) (sq_nonneg (log x))]
  obtain ⟨p, hp, hp0, hp1⟩ := hd x (he.le.trans hx)
  refine ⟨p, hp, hp0, hp1.trans_lt ?_⟩
  norm_num only [Real.rpow_ofNat]
  linarith [div_lt_div_of_pos_left hxp (by norm_num : (0 : ℝ) < 1000000) hc]

theorem threshold {n : ℕ} (hn : (10 : ℝ)^200 ≤ n) : (exp 101)^2 ≤ (n : ℝ) := by
  have he : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
  have h101 : exp (101 : ℝ) = (exp 1)^101 := by
    rw [Real.exp_one_pow]
    norm_num
  calc
    (exp 101)^2 = ((exp 1)^101)^2 := by rw [h101]
    _ = (exp 1)^202 := by rw [←pow_mul]
    _ ≤ (3 : ℝ)^202 := pow_le_pow_left₀ (exp_pos 1).le he.le _
    _ ≤ 10^200 := by norm_num
    _ ≤ n := hn

section Construction
variable (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : (10 : ℝ)^200 ≤ n)
noncomputable def p : Fin 3 → ℕ :=
  (exists_p_primes (gap hd) (by norm_num : (7 : ℝ) ≤ 7)
    (by norm_num : (7 : ℝ) ≤ log (exp 101)) (threshold hn)).choose
noncomputable def q : Fin 3 → ℕ :=
  (exists_q_primes (gap hd) (by norm_num : (7 : ℝ) ≤ 7)
    (by norm_num : (7 : ℝ) ≤ log (exp 101)) (threshold hn)).choose

theorem pspec : (∀ i, (p hd n hn i).Prime) ∧ StrictMono (p hd n hn) ∧
    (∀ i, (p hd n hn i : ℝ) ≤ √(n : ℝ) * (1 + (1 / 1000000 : ℝ)) ^ (i + 1 : ℝ)) ∧
    √(n : ℝ) < p hd n hn 0 :=
  (exists_p_primes (gap hd) (by norm_num : (7 : ℝ) ≤ 7)
    (by norm_num : (7 : ℝ) ≤ log (exp 101)) (threshold hn)).choose_spec

theorem qspec : (∀ i, (q hd n hn i).Prime) ∧ StrictMono (q hd n hn) ∧
    (∀ i : Fin 3, n * (1 + (1 / 1000000 : ℝ)) ^ (-((3 : ℝ) - (i : ℕ))) ≤ q hd n hn i) ∧
    q hd n hn 2 < n :=
  (exists_q_primes (gap hd) (by norm_num : (7 : ℝ) ≤ 7)
    (by norm_num : (7 : ℝ) ≤ log (exp 101)) (threshold hn)).choose_spec

theorem pbound (i : Fin 3) : (p hd n hn i : ℝ) ≤ (100001 / 100000 : ℝ) * √(n : ℝ) := by
  have h := (pspec hd n hn).2.2.1 i
  have hs := Real.sqrt_nonneg (n : ℝ)
  fin_cases i <;> norm_num at h ⊢ <;> nlinarith

theorem qbound (i : Fin 3) : (99999 / 100000 : ℝ) * n ≤ q hd n hn i := by
  have h := (qspec hd n hn).2.2.1 i
  have hn0 : (0 : ℝ) ≤ n := by positivity
  fin_cases i <;> norm_num at h ⊢ <;> nlinarith

include hn in
theorem sqrt_lower : (10 : ℝ)^100 ≤ √(n : ℝ) := by
  apply Real.le_sqrt_of_sq_le
  nlinarith only [hn]

theorem product : 6^80 * ∏ i, p hd n hn i < ∏ i, q hd n hn i := by
  have hs : 0 < √(n : ℝ) := by linarith [sqrt_lower n hn]
  have hpP : (∏ i, (p hd n hn i : ℝ)) ≤ ((100001 / 100000 : ℝ) * √(n : ℝ))^3 := by
    have hh := Finset.prod_le_prod₀ (s := Finset.univ)
      (fun (i : Fin 3) _ => by positivity : ∀ i ∈ Finset.univ, (0 : ℝ) ≤ p hd n hn i)
      (fun i _ => pbound hd n hn i)
    simpa [Fin.prod_univ_three, pow_succ] using hh
  have hqQ : ((99999 / 100000 : ℝ) * n)^3 ≤ ∏ i, (q hd n hn i : ℝ) := by
    have hh := Finset.prod_le_prod₀ (s := Finset.univ)
      (fun (i : Fin 3) _ => by positivity : ∀ i ∈ Finset.univ, (0 : ℝ) ≤ (99999 / 100000 : ℝ) * n)
      (fun i _ => qbound hd n hn i)
    simpa [Fin.prod_univ_three, pow_succ] using hh
  have hc : (6 : ℝ)^80 * (100001 / 100000)^3 < (99999 / 100000)^3 * √(n : ℝ)^3 := by
    calc _ < (99999 / 100000 : ℝ)^3 * (10^100)^3 := by norm_num
      _ ≤ _ := by gcongr; exact sqrt_lower n hn
  have hh := mul_lt_mul_of_pos_right hc (pow_pos hs 3)
  have hs2 : √(n : ℝ)^2 = (n : ℝ) := Real.sq_sqrt (by positivity)
  have hs6 := congrArg (fun (x : ℝ) => x^3) hs2
  have hmid : (6 : ℝ)^80 * ((100001 / 100000 : ℝ) * √(n : ℝ))^3 <
      ((99999 / 100000 : ℝ) * n)^3 := by
    convert hh using 1 <;> first | rfl | (rw [mul_pow]; nlinarith [hs6])
  have hfinal := (mul_le_mul_of_nonneg_left hpP (show (0 : ℝ) ≤ 6^80 by positivity)).trans_lt (hmid.trans_le hqQ)
  exact_mod_cast hfinal

noncomputable def criterion : PowerCriterion where
  k := 80
  hk := by norm_num
  n := n
  hn := by
    have hnp : (0 : ℝ) < n := by linarith [hn]
    have hnp' : 0 < n := by exact_mod_cast hnp
    omega
  p := p hd n hn
  hp := (pspec hd n hn).1
  hp_mono := (pspec hd n hn).2.1
  hthree := by
    have hh := (pspec hd n hn).2.2.2
    have hs := sqrt_lower n hn
    have : (3 : ℝ) < p hd n hn 0 := by linarith
    exact_mod_cast this
  q := q hd n hn
  hq := (qspec hd n hn).1
  hq_mono := (qspec hd n hn).2.1
  h_ord_1 := (pspec hd n hn).2.2.2
  h_ord_2 := by
    have hp := pbound hd n hn 2
    have hq := qbound hd n hn 0
    have hs := sqrt_lower n hn
    have hs2 := Real.sq_sqrt (show (0 : ℝ) ≤ n by positivity)
    have hx : (100001 / 100000 : ℝ) * √(n : ℝ) < (99999 / 100000 : ℝ) * n := by
      nlinarith [mul_nonneg (Real.sqrt_nonneg (n : ℝ)) (sub_nonneg.mpr hs)]
    exact_mod_cast hp.trans_lt (hx.trans_le hq)
  h_ord_3 := (qspec hd n hn).2.2.2
  h_product := product hd n hn

include hd hn in
/-- Completed old-source-only challenger: no newly generated prime or numerical certificate. -/
theorem actualConsumer : ∃ m : ℕ, m < Nat.lcmUpto n ∧
    (1 + (4 / 5 : ℝ) / n) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
      ArithmeticFunction.sigma 1 m := by
  let C := criterion hd n hn
  refine ⟨C.M, C.M_lt, ?_⟩
  exact criterion_surplus C (by positivity) (budget C rfl hn
    (pbound hd n hn) (qbound hd n hn))
end Construction
end QRHRound2.LcmWitnessNoPV
