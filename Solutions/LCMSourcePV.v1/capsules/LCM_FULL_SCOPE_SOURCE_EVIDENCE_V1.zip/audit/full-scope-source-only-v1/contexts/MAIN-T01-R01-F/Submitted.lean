import Mathlib

namespace SubmittedExposure01

def Source : Prop := ∀ x : ℝ, 89693 ≤ x → ∃ p : ℕ,
  Nat.Prime p ∧ x < p ∧ (p:ℝ) ≤ x+x/(Real.log x)^3

noncomputable def Count (α : ℚ) (n : ℕ) : ℕ := ⌊(α:ℝ)*Real.sqrt (n:ℝ)⌋₊

noncomputable def Goal (α : ℚ) : Prop := Source → ∀ n : ℕ, 89693^2 ≤ n →
  ∃ S : Finset ℕ, Count α n ≤ S.card ∧ ∀ m ∈ S,
    0 < m ∧ m < Nat.lcmUpto n ∧
    (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) < ArithmeticFunction.sigma 1 m

noncomputable def Comparison (α : ℚ) : Prop := 0 < α ∧ 2 ≤ Count α (89693^2)
end SubmittedExposure01

namespace SubmittedCandidate

def coefficient : ℚ := 1/20

theorem comparison : SubmittedExposure01.Comparison coefficient := by
  constructor
  · norm_num [coefficient]
  · unfold SubmittedExposure01.Count
    apply Nat.le_floor
    have hs : Real.sqrt ((89693 ^ 2 : ℕ) : ℝ) = 89693 := by
      norm_num
    rw [hs]
    norm_num [coefficient]

/-- Dilation of every divisor gives a lower bound without a coprimality hypothesis. -/
theorem sigma_dilation (A t : ℕ) (hA : 0 < A) (ht : 0 < t) :
    t * ArithmeticFunction.sigma 1 A ≤ ArithmeticFunction.sigma 1 (A*t) := by
  classical
  have hi : Function.Injective (fun d : ℕ => t*d) := by
    intro x y h
    exact Nat.eq_of_mul_eq_mul_left ht h
  have hsub : A.divisors.image (fun d => t*d) ⊆ (A*t).divisors := by
    intro z hz
    obtain ⟨d, hd, rfl⟩ := Finset.mem_image.mp hz
    apply Nat.mem_divisors.mpr
    constructor
    · obtain ⟨k, hk⟩ := (Nat.mem_divisors.mp hd).1
      refine ⟨k, ?_⟩
      rw [hk]
      ring
    · exact ne_of_gt (Nat.mul_pos hA ht)
  rw [ArithmeticFunction.sigma_one_apply, ArithmeticFunction.sigma_one_apply]
  calc
    t * ∑ d ∈ A.divisors, d = ∑ d ∈ A.divisors, t*d := Finset.mul_sum ..
    _ = ∑ z ∈ A.divisors.image (fun d => t*d), z := by
      rw [Finset.sum_image]
      exact hi.injOn
    _ ≤ ∑ z ∈ (A*t).divisors, z := Finset.sum_le_sum_of_subset hsub

/-- A finite interval of dilations gives distinct strict divisor-sum witnesses.
This is a reduction lemma, not the prime-interval construction required for result. -/
theorem interval_witnesses (L A a b : ℕ) (hA : 0 < A) (ha : 0 < a)
    (hab : a ≤ b) (hsize : A*(b-1) < L)
    (hsigma : ArithmeticFunction.sigma 1 L < a * ArithmeticFunction.sigma 1 A) :
    ∃ S : Finset ℕ, S.card = b-a ∧ ∀ m ∈ S,
      0 < m ∧ m < L ∧
      (ArithmeticFunction.sigma 1 L : ℝ) < ArithmeticFunction.sigma 1 m := by
  classical
  let S := (Finset.Ico a b).image (fun t => A*t)
  refine ⟨S, ?_, ?_⟩
  · dsimp [S]
    rw [Finset.card_image_of_injective]
    · exact Nat.card_Ico a b
    · intro x y h
      exact Nat.eq_of_mul_eq_mul_left hA h
  · intro m hm
    obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hm
    have hta : a ≤ t := (Finset.mem_Ico.mp ht).1
    have htb : t < b := (Finset.mem_Ico.mp ht).2
    have htpos : 0 < t := lt_of_lt_of_le ha hta
    refine ⟨Nat.mul_pos hA htpos, ?_, ?_⟩
    · exact lt_of_le_of_lt (Nat.mul_le_mul_left A (by omega : t ≤ b-1)) hsize
    · have hd := sigma_dilation A t hA htpos
      have hnat : ArithmeticFunction.sigma 1 L < ArithmeticFunction.sigma 1 (A*t) :=
        lt_of_lt_of_le (lt_of_lt_of_le hsigma (Nat.mul_le_mul_right _ hta)) hd
      exact_mod_cast hnat

end SubmittedCandidate
