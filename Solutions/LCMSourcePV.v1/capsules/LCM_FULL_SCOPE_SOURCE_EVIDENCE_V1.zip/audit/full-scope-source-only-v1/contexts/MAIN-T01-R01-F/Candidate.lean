import ChainCore
import Submitted
namespace Candidate
open LcmDev Multiplicity Real Finset
set_option Elab.async false
set_option maxHeartbeats 5000000
theorem scalar : FixedChain.ScalarCertificate (((1001:ℝ)/1000)^3) ((99:ℝ)/100) ((89713:ℝ)/1793860) := by
  intro ε hε
  have hsmall : ε ≤ 1 := hε.2.trans (by norm_num)
  have h2 : ε^2 ≤ ε/(89693^2:ℝ) := by nlinarith [mul_nonneg hε.1 (sub_nonneg.mpr hε.2)]
  have h3 : ε^3 ≤ ε^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hsmall)]
  have h4 : ε^4 ≤ ε^3 := by nlinarith [mul_nonneg (pow_nonneg hε.1 3) (sub_nonneg.mpr hsmall)]
  have h5 : ε^5 ≤ ε^4 := by nlinarith [mul_nonneg (pow_nonneg hε.1 4) (sub_nonneg.mpr hsmall)]
  norm_num [FixedChain.ScalarCertificate]
  nlinarith [pow_nonneg hε.1 3,pow_nonneg hε.1 4,pow_nonneg hε.1 5]

theorem result : Exposure01.Goal ((1:ℚ)/20) := by
  intro source n hn
  have hn0 : (0:ℝ)<n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<89693^2) hn)
  have hs := LcmDev.hsqrt_ge hn
  have hs0 : 0<Real.sqrt (n:ℝ) := Real.sqrt_pos.mpr hn0
  have hsq := Real.sq_sqrt hn0.le
  have hstart : (89693:ℝ) ≤ ((99:ℝ)/100)*n := by
    have hnr : (89693^2:ℝ)≤n := by exact_mod_cast hn
    nlinarith only [hnr]
  obtain ⟨p,hp,hpm,hpl,hpu⟩ := FixedChain.source_three source ((1001:ℝ)/1000) (Real.sqrt n) hs (by norm_num)
  obtain ⟨q,hq,hqm,hql,hqu⟩ := FixedChain.source_three source (40027/40000) (((99:ℝ)/100)*n) hstart (by norm_num)
  have hpbound (i : Fin 3) : (p i:ℝ)≤((1001:ℝ)/1000)^3*Real.sqrt n := by
    have hh : (p i:ℝ)≤p 2 := by exact_mod_cast hpm.monotone (Fin.le_last i)
    exact hh.trans hpu
  have hqbound (i : Fin 3) : ((99:ℝ)/100)*n≤(q i:ℝ) := by
    have hh : (q 0:ℝ)≤q i := by exact_mod_cast hqm.monotone (Fin.zero_le i)
    exact hql.le.trans hh
  have hsep : (p 2:ℝ)<q 0 := by
    have hmid : ((1001:ℝ)/1000)^3*Real.sqrt n < ((99:ℝ)/100)*n := by nlinarith
    exact hpu.trans_lt (hmid.trans hql)
  have hqend : q 2<n := by
    have hh : (q 2:ℝ)<n := by
      nlinarith only [hqu,hn0]
    exact_mod_cast hh
  have hinit : (0+1:ℝ)≤((89713:ℝ)/1793860)*Real.sqrt n := by norm_num; nlinarith
  have hbase := FixedChain.window_comparison n 0 hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
    (((1001:ℝ)/1000)^3) ((99:ℝ)/100) ((89713:ℝ)/1793860) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound (by simpa using hinit) scalar
  let C : Criterion := {
    n:=n,hn:=by omega,p:=p,hp:=hp,hp_mono:=hpm,q:=q,hq:=hq,hq_mono:=hqm,
    h_ord_1:=hpl,h_ord_2:=by exact_mod_cast hsep,h_ord_3:=hqend,h_crit:=by simpa using hbase }
  let K : ℕ := Exposure01.Count ((1:ℚ)/20) n
  have hK : (K:ℝ)≤((1:ℝ)/20)*Real.sqrt n := by
    simpa only [K,Exposure01.Count,Rat.cast_div,Rat.cast_ofNat,Rat.cast_one] using
      Nat.floor_le (by positivity : (0:ℝ)≤((1:ℝ)/20)*Real.sqrt n)
  have hJ (j : ℕ) (hj : j<K) : (j+1+1:ℝ)≤((89713:ℝ)/1793860)*Real.sqrt n := by
    have hj1 : (j+1:ℝ)≤K := by exact_mod_cast (Nat.succ_le_iff.mpr hj)
    norm_num at hs ⊢
    linarith
  have hD : (K+1:ℝ) ≤ ((89713:ℝ)/1793860)*Real.sqrt n := by linarith
  have hc := FixedChain.window_comparison n K hn p q (fun i=>(hp i).pos) (fun i=>(hq i).pos)
    (((1001:ℝ)/1000)^3) ((99:ℝ)/100) ((89713:ℝ)/1793860) (by norm_num) (by norm_num) (by norm_num) hpbound hqbound hD scalar
  obtain ⟨hapos, hsmall, hgain⟩ := FixedChain.offset_density C K hc
  let d := witness C 1
  let v := σ (L C.n) / σ d
  let qmax := (L C.n-1)/d
  have hd : 0 < d := witness_pos C 1 (by norm_num)
  have hσ : 0 < σ d := by rw [σ,ArithmeticFunction.sigma_pos_iff]; exact hd
  have hσgain : σ (L C.n) < (C.m-K)*σ d := by exact_mod_cast hgain
  have hv : v < C.m-K := by
    have hh : v*σ d ≤ σ (L C.n) := Nat.div_mul_le_self (σ (L C.n)) (σ d)
    nlinarith only [hh,hσgain,hσ]
  have htop : d*C.m < L C.n := by
    have heq : d*C.m=C.M := by simp [d,witness,Criterion.M]; ring
    rw [heq]
    exact C.M_lt
  have hq : C.m ≤ qmax := by
    apply (Nat.le_div_iff_mul_le hd).mpr
    rw [Nat.mul_comm]
    omega
  have hvq : v+1 ≤ qmax+1 := by omega
  have hsmallmax : d*((qmax+1)-1) < L C.n := by
    have hh : d*qmax ≤ L C.n-1 := Nat.mul_div_le (L C.n-1) d
    have hL := C.L_pos
    simpa using (show d*qmax < L C.n by omega)
  have hgainfirst : σ (L C.n) < (v+1)*σ d := by
    have hm := Nat.mod_lt (σ (L C.n)) hσ
    have he := Nat.mod_add_div (σ (L C.n)) (σ d)
    dsimp [v]
    nlinarith
  obtain ⟨S,hcard,hgood⟩ := SubmittedCandidate.interval_witnesses (L C.n) d (v+1) (qmax+1) hd (Nat.succ_pos v) hvq hsmallmax hgainfirst
  refine ⟨S,?_,?_⟩
  · change K ≤ S.card
    rw [hcard]
    omega
  · simpa only [L,σ,Nat.lcmUpto] using hgood
theorem comparison : Exposure01.Comparison ((1:ℚ)/20) := by
  norm_num [Exposure01.Comparison,Exposure01.Count]
end Candidate
