import Submitted
import ChainCore
import T01Certificates
namespace Candidate
open LcmDev Multiplicity Real
set_option Elab.async false
set_option maxHeartbeats 5000000
theorem result : Exposure01.Goal (1/16) := by
  apply SubmittedCandidate.result_of_certificates (1/16)
  intro source n hn
  have hd : Dusart2018.v1.proposition_5_4 := by
    intro x hx
    simpa only [IEANTN.HasPrimeInInterval, Real.rpow_ofNat] using source x hx
  let C := Criterion.mk' hd hn
  let K : ℕ := Exposure01.Count (1/16) n
  have hK : (K:ℝ) ≤ (1/16:ℝ)*Real.sqrt n := by
    simpa only [K, Exposure01.Count, Rat.cast_div, Rat.cast_one, Rat.cast_ofNat] using
      Nat.floor_le (by positivity : (0:ℝ) ≤ (1/16:ℝ)*Real.sqrt n)
  have hJ : (K+1:ℝ) ≤ (899/10000:ℝ)*Real.sqrt n := by
    have hs := LcmDev.hsqrt_ge hn
    linarith
  have hc := MultiplicityGeneral.comparison (899/10000) (by norm_num)
    MultiplicityGeneral.scalar_certificate_899 hd hn hJ
  change (∏ i,(1+(1:ℝ)/C.q i)) ≤
    (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ)))*
      (1-4*(K+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) at hc
  obtain ⟨hapos, hsmall, hgain⟩ := FixedChain.offset_density C K hc
  have hdpos : 0 < witness C 1 := witness_pos C 1 (by norm_num)
  have hsum : C.m-K+K = C.m := by omega
  have hsmall' : witness C 1 * (C.m-K+K) ≤ Nat.lcmUpto n := by
    rw [hsum]
    have heq : witness C 1 * C.m = C.M := by simp [witness, Criterion.M]; ring
    rw [heq]
    simpa [C,Criterion.mk',L,Nat.lcmUpto] using C.M_lt.le
  refine ⟨witness C 1,C.m-K,K,hdpos,hapos,hsmall',?_,?_⟩
  · have hh : σ (L C.n) < (C.m-K)*σ (witness C 1) := by exact_mod_cast hgain
    simpa [C,Criterion.mk',L,σ,Nat.lcmUpto] using hh
  · rfl
theorem comparison : Exposure01.Comparison (1/16) := by
  norm_num [Exposure01.Comparison,Exposure01.Count]
end Candidate
