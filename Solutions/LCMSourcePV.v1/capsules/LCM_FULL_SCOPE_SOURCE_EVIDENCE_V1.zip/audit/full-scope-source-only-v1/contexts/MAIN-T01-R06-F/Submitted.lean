import Mathlib

namespace SubmittedExposure01

def Source : Prop := ∀ x : ℝ, 89693 ≤ x → ∃ p : ℕ,
  Nat.Prime p ∧ x < p ∧ (p:ℝ) ≤ x+x/(Real.log x)^3

noncomputable def Count (α : ℚ) (n : ℕ) : ℕ := ⌊(α:ℝ)*Real.sqrt (n:ℝ)⌋₊

noncomputable def Goal (α : ℚ) : Prop := Source → ∀ n : ℕ, 89693^2 ≤ n →
  ∃ S : Finset ℕ, Count α n ≤ S.card ∧ ∀ m ∈ S,
    0 < m ∧ m < Nat.lcmUpto n ∧
    (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) < ArithmeticFunction.sigma 1 m

noncomputable def Comparison (α : ℚ) : Prop := 0 < α ∧ 2 ≤ Count α (89693^2)
end SubmittedExposure01

namespace SubmittedCandidate
open SubmittedExposure01

theorem comparison : Comparison (1 / 16 : ℚ) := by
  constructor
  · norm_num
  · unfold Count
    apply Nat.le_floor
    have hs : Real.sqrt ((89693 ^ 2 : ℕ) : ℝ) = 89693 := by
      norm_num
    rw [hs]
    norm_num

/-- Scaling the divisors gives a lower bound without any coprimality hypothesis. -/
theorem mul_sigma_le (k d : ℕ) (hk : 0 < k) (hd : 0 < d) :
    k * ArithmeticFunction.sigma 1 d ≤ ArithmeticFunction.sigma 1 (k * d) := by
  rw [ArithmeticFunction.sigma_one_apply, ArithmeticFunction.sigma_one_apply]
  have hinj : Function.Injective (fun x : ℕ => k * x) := by
    intro x y h
    nlinarith
  have hsub : d.divisors.image (fun x => k * x) ⊆ (k * d).divisors := by
    intro x hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    apply Nat.mem_divisors.mpr
    exact ⟨Nat.mul_dvd_mul_left k (Nat.mem_divisors.mp hy).1, by positivity⟩
  calc
    k * ∑ x ∈ d.divisors, x = ∑ x ∈ d.divisors, k * x := Finset.mul_sum ..
    _ = ∑ x ∈ d.divisors.image (fun x => k * x), x := by
      rw [Finset.sum_image]
      exact fun x _ y _ h => hinj h
    _ ≤ ∑ x ∈ (k * d).divisors, x :=
      Finset.sum_le_sum_of_subset_of_nonneg hsub (by intros; omega)

/-- An integer interval of multipliers produces genuinely distinct witnesses. -/
theorem interval_witnesses (L d a t : ℕ)
    (hd : 0 < d) (ha : 0 < a)
    (hsmall : d * (a + t) < L + d)
    (hgain : ArithmeticFunction.sigma 1 L < a * ArithmeticFunction.sigma 1 d) :
    ∃ S : Finset ℕ, S.card = t ∧ ∀ m ∈ S,
      0 < m ∧ m < L ∧ ArithmeticFunction.sigma 1 L < ArithmeticFunction.sigma 1 m := by
  let f : ℕ → ℕ := fun j => d * (a + j)
  have hi : Function.Injective f := by
    intro x y h
    dsimp [f] at h
    nlinarith
  refine ⟨(Finset.range t).image f, ?_, ?_⟩
  · rw [Finset.card_image_of_injective _ hi, Finset.card_range]
  · intro m hm
    obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp hm
    have hjt : j < t := Finset.mem_range.mp hj
    have hpos : 0 < a + j := by omega
    have hmpos : 0 < f j := Nat.mul_pos hd hpos
    have hmlt : f j < L := by
      dsimp [f]
      nlinarith
    refine ⟨hmpos, hmlt, ?_⟩
    have hmul := mul_sigma_le (a + j) d hpos hd
    dsimp [f]
    rw [Nat.mul_comm d]
    exact lt_of_lt_of_le hgain (le_trans (Nat.mul_le_mul_right _ (Nat.le_add_right a j)) hmul)

/-- A sufficient finite-arithmetic certificate for the target at a given n. -/
theorem goal_at_of_interval (α : ℚ) (n d a t : ℕ)
    (hd : 0 < d) (ha : 0 < a)
    (hsmall : d * (a + t) ≤ Nat.lcmUpto n)
    (hgain : ArithmeticFunction.sigma 1 (Nat.lcmUpto n) <
      a * ArithmeticFunction.sigma 1 d)
    (hcount : Count α n ≤ t) :
    ∃ S : Finset ℕ, Count α n ≤ S.card ∧ ∀ m ∈ S,
      0 < m ∧ m < Nat.lcmUpto n ∧
      (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) < ArithmeticFunction.sigma 1 m := by
  obtain ⟨S, hcard, hS⟩ := interval_witnesses (Nat.lcmUpto n) d a t hd ha (by omega) hgain
  refine ⟨S, by omega, ?_⟩
  intro m hm
  obtain ⟨hpos, hlt, hsig⟩ := hS m hm
  exact ⟨hpos, hlt, by exact_mod_cast hsig⟩

/-- An explicit count obtainable from a single divisor-sum density bound.
The division here is natural integer division. -/
theorem quotient_witnesses (L d : ℕ) (hL : 0 < L) (hd : 0 < d)
    (hs : 0 < ArithmeticFunction.sigma 1 d)
    (hgap : ArithmeticFunction.sigma 1 L / ArithmeticFunction.sigma 1 d < (L - 1) / d) :
    ∃ S : Finset ℕ,
      S.card = (L - 1) / d - ArithmeticFunction.sigma 1 L / ArithmeticFunction.sigma 1 d ∧
      ∀ m ∈ S, 0 < m ∧ m < L ∧
        ArithmeticFunction.sigma 1 L < ArithmeticFunction.sigma 1 m := by
  let v := ArithmeticFunction.sigma 1 L / ArithmeticFunction.sigma 1 d
  let q := (L - 1) / d
  have hvq : v < q := hgap
  have hsum : v + 1 + (q - v) = q + 1 := by omega
  apply interval_witnesses L d (v + 1) (q - v) hd (Nat.succ_pos v)
  · rw [hsum, Nat.mul_add, Nat.mul_one]
    have hdiv : d * q ≤ L - 1 := by
      dsimp [q]
      exact Nat.mul_div_le (L - 1) d
    omega
  · have hrem := Nat.mod_lt (ArithmeticFunction.sigma 1 L) hs
    have heq := Nat.mod_add_div (ArithmeticFunction.sigma 1 L) (ArithmeticFunction.sigma 1 d)
    dsimp [v]
    nlinarith

/-- The remaining task is to construct these integer certificates from Source.
This theorem does not assert that such certificates exist. -/
theorem result_of_certificates (α : ℚ)
    (certificates : Source → ∀ n : ℕ, 89693 ^ 2 ≤ n →
      ∃ d a t : ℕ, 0 < d ∧ 0 < a ∧
        d * (a + t) ≤ Nat.lcmUpto n ∧
        ArithmeticFunction.sigma 1 (Nat.lcmUpto n) < a * ArithmeticFunction.sigma 1 d ∧
        Count α n ≤ t) : Goal α := by
  intro source n hn
  obtain ⟨d, a, t, hd, ha, hsmall, hgain, hcount⟩ := certificates source n hn
  exact goal_at_of_interval α n d a t hd ha hsmall hgain hcount

end SubmittedCandidate
