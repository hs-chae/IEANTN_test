import Quotient
import Interface
namespace FixedChain
open ArithmeticFunction hiding log
open Finset Nat Real LcmDev Multiplicity
set_option Elab.async false
set_option maxHeartbeats 5000000

lemma source_three_log (hs : Exposure01.Source) (r x l : ℝ) (hx : 89693 ≤ x)
    (hl : 0 < l) (hlx : l ≤ Real.log x) (hr : 1 + 1/l^3 ≤ r) :
    ∃ p : Fin 3 → ℕ, (∀ i, Nat.Prime (p i)) ∧ StrictMono p ∧
      x < p 0 ∧ (p 2 : ℝ) ≤ r^3*x := by
  have hr1 : 1 ≤ r := by
    have hh : 0 < 1/l^3 := by positivity
    linarith
  have step (y : ℝ) (hy : x ≤ y) :
      ∃ p : ℕ, Nat.Prime p ∧ y < p ∧ (p:ℝ) ≤ r*y := by
    obtain ⟨p,hp,hlo,hhi⟩ := hs y (hx.trans hy)
    have hy0 : 0 < y := by linarith
    have hly : l ≤ Real.log y := hlx.trans (Real.log_le_log (by linarith) hy)
    have hpow : l^3 ≤ (Real.log y)^3 := by gcongr
    have hd := div_le_div_of_nonneg_left hy0.le (pow_pos hl 3) hpow
    refine ⟨p,hp,hlo,?_⟩
    have hmul := mul_le_mul_of_nonneg_right hr hy0.le
    calc
      (p:ℝ) ≤ y+y/(Real.log y)^3 := hhi
      _ ≤ y+y/l^3 := by gcongr
      _ = (1+1/l^3)*y := by ring
      _ ≤ r*y := hmul
  obtain ⟨p0,hp0,hl0,hu0⟩ := step x le_rfl
  obtain ⟨p1,hp1,hl1,hu1⟩ := step p0 hl0.le
  obtain ⟨p2,hp2,hl2,hu2⟩ := step p1 (hl0.trans hl1).le
  refine ⟨![p0,p1,p2],(by intro i; fin_cases i <;> assumption),?_,hl0,?_⟩
  · apply Fin.strictMono_iff_lt_succ.mpr
    intro i
    fin_cases i <;> norm_num
    · exact_mod_cast hl1
    · exact_mod_cast hl2
  · change (p2:ℝ) ≤ r^3*x
    calc
      (p2:ℝ) ≤ r*p1 := hu2
      _ ≤ r*(r*p0) := mul_le_mul_of_nonneg_left hu1 (by linarith)
      _ ≤ r*(r*(r*x)) := by gcongr
      _ = _ := by ring

lemma source_three (hs : Exposure01.Source) (r x : ℝ) (hx : 89693 ≤ x)
    (hr : 1 + 1/(11.4 : ℝ)^3 ≤ r) :
    ∃ p : Fin 3 → ℕ, (∀ i, Nat.Prime (p i)) ∧ StrictMono p ∧
      x < p 0 ∧ (p 2 : ℝ) ≤ r^3*x :=
  source_three_log hs r x 11.4 hx (by norm_num)
    (LcmDev.log_X₀_gt.le.trans (Real.log_le_log (by norm_num) hx)) hr

lemma source_step (hs : Exposure01.Source) (x : ℝ) (hx : 89693 ≤ x) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p:ℝ) ≤ (40027/40000:ℝ)*x := by
  obtain ⟨p,hp,hl,hu⟩ := hs x hx
  have hx0 : 0 < x := by linarith
  have hlog : (11.4:ℝ) ≤ Real.log x :=
    LcmDev.log_X₀_gt.le.trans (Real.log_le_log (by norm_num) hx)
  have hpow : (11.4:ℝ)^3 ≤ (Real.log x)^3 := by gcongr
  have hd := div_le_div_of_nonneg_left hx0.le (by norm_num : (0:ℝ)<11.4^3) hpow
  have hnum : 1+1/(11.4:ℝ)^3 ≤ 40027/40000 := by norm_num
  refine ⟨p,hp,hl,?_⟩
  calc
    (p:ℝ) ≤ x+x/(Real.log x)^3 := hu
    _ ≤ x+x/11.4^3 := by gcongr
    _ = (1+1/(11.4:ℝ)^3)*x := by ring
    _ ≤ _ := by gcongr

lemma source_fixed_grid (hs : Exposure01.Source) (r x : ℝ) (hx : 89693 ≤ x)
    (hr : (40027/40000:ℝ) < r) :
    ∃ p : Fin 3 → ℕ, (∀ i, Nat.Prime (p i)) ∧ StrictMono p ∧
      x < p 0 ∧ (p 2:ℝ) < r^3*x := by
  have hr1 : 1 < r := by linarith
  have hx0 : 0 < x := by linarith
  have hx1 : 89693 ≤ x*r := by nlinarith
  have hx2 : 89693 ≤ x*r^2 := by nlinarith [sq_nonneg (r-1)]
  obtain ⟨p0,hp0,hl0,hu0⟩ := source_step hs x hx
  obtain ⟨p1,hp1,hl1,hu1⟩ := source_step hs (x*r) hx1
  obtain ⟨p2,hp2,hl2,hu2⟩ := source_step hs (x*r^2) hx2
  have h01 : (p0:ℝ) < p1 := lt_of_le_of_lt hu0 (by nlinarith)
  have h12 : (p1:ℝ) < p2 := by
    have hh : (40027/40000:ℝ)*(x*r) < x*r^2 := by nlinarith [mul_pos hx0 (sub_pos.mpr hr)]
    exact hu1.trans_lt (hh.trans hl2)
  refine ⟨![p0,p1,p2],(by intro i; fin_cases i <;> assumption),?_,hl0,?_⟩
  · apply Fin.strictMono_iff_lt_succ.mpr
    intro i
    fin_cases i <;> norm_num
    · exact_mod_cast h01
    · exact_mod_cast h12
  · change (p2:ℝ) < r^3*x
    have hh := mul_lt_mul_of_pos_right hr (mul_pos hx0 (pow_pos (by linarith) 2))
    nlinarith

def ScalarCertificate (a b α : ℝ) : Prop :=
  ∀ ε : ℝ, 0 ≤ ε ∧ ε ≤ 1/(89693^2:ℝ) →
    (1+ε/b)^3 ≤ (1+ε/(a^2+a/89693))^3*(1+3/8*ε)*
      (1-4*α*(a/b)^3*ε)

lemma window_comparison (n j : ℕ) (hn : 89693^2 ≤ n)
    (p q : Fin 3 → ℕ) (hp : ∀ i, 0 < p i) (hq : ∀ i, 0 < q i)
    (a b α : ℝ) (ha : 0 < a) (hb : 0 < b) (hα : 0 ≤ α)
    (hpbound : ∀ i, (p i:ℝ) ≤ a*Real.sqrt n)
    (hqbound : ∀ i, b*n ≤ (q i:ℝ))
    (hj : (j+1:ℝ) ≤ α*Real.sqrt n) (hcert : ScalarCertificate a b α) :
    (∏ i,(1+(1:ℝ)/q i)) ≤
      (∏ i,(1+1/(p i*(p i+1):ℝ)))*(1+3/(8*(n:ℝ)))*
      (1-4*(j+1:ℝ)*(∏ i,(p i:ℝ))/(∏ i,(q i:ℝ))) := by
  have hn0 : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<89693^2) hn)
  have hs0 : 0 < Real.sqrt (n:ℝ) := Real.sqrt_pos.mpr hn0
  have hsX := LcmDev.hsqrt_ge hn
  have hsq := Real.sq_sqrt hn0.le
  have hP : (∏ i,(p i:ℝ)) ≤ (a*Real.sqrt n)^3 := by
    calc
      _ ≤ ∏ _i : Fin 3, a*Real.sqrt (n:ℝ) := by gcongr with i; exact hpbound i
      _ = _ := by simp
  have hQ : (b*n)^3 ≤ ∏ i,(q i:ℝ) := by
    calc
      _ = ∏ _i : Fin 3, b*(n:ℝ) := by simp
      _ ≤ _ := by gcongr with i; exact hqbound i
  have hQ0 : 0 < ∏ i,(q i:ℝ) := Finset.prod_pos fun i _ => by exact_mod_cast hq i
  have hpq : (∏ i,(p i:ℝ))/(∏ i,(q i:ℝ)) ≤ (a/b)^3/((n:ℝ)*Real.sqrt n) := by
    calc
      _ ≤ (a*Real.sqrt n)^3/(b*n)^3 := div_le_div₀ (by positivity) hP (by positivity) hQ
      _ = _ := by
        rw [← hsq, Real.sqrt_sq hs0.le]
        field_simp
        <;> ring
  have hloss : 4*(j+1:ℝ)*(∏ i,(p i:ℝ))/(∏ i,(q i:ℝ)) ≤
      4*α*(a/b)^3*(1/(n:ℝ)) := by
    calc
      _ = 4*(j+1:ℝ)*((∏ i,(p i:ℝ))/(∏ i,(q i:ℝ))) := by ring
      _ ≤ 4*(j+1:ℝ)*((a/b)^3/((n:ℝ)*Real.sqrt n)) := by gcongr
      _ ≤ 4*(α*Real.sqrt n)*((a/b)^3/((n:ℝ)*Real.sqrt n)) := by gcongr
      _ = _ := by field_simp <;> ring
  have hsmall : 0 ≤ 1/(n:ℝ) ∧ 1/(n:ℝ) ≤ 1/(89693^2:ℝ) :=
    ⟨by positivity, one_div_le_one_div_of_le (by norm_num) (by exact_mod_cast hn)⟩
  have scalar := hcert (1/(n:ℝ)) hsmall
  have hden : 0 < a^2+a/89693 := by positivity
  have hpden (i : Fin 3) : (p i:ℝ)*(p i+1) ≤ (a^2+a/89693)*(n:ℝ) := by
    have hp0 : (0:ℝ) ≤ p i := Nat.cast_nonneg _
    have hupper : (p i:ℝ)*(p i+1) ≤ (a*Real.sqrt n)*(a*Real.sqrt n+1) := by gcongr; exact hpbound i; exact hpbound i
    have hxs : (89693:ℝ)*Real.sqrt n ≤ n := by nlinarith
    have hh := mul_le_mul_of_nonneg_left hxs ha.le
    nlinarith
  have hpfactor : (1+(1/(n:ℝ))/(a^2+a/89693))^3 ≤ ∏ i,(1+1/(p i*(p i+1):ℝ)) := by
    calc
      _ = ∏ _i : Fin 3, (1+(1/(n:ℝ))/(a^2+a/89693)) := by simp
      _ ≤ _ := by
        apply Finset.prod_le_prod₀ (by intros; positivity)
        intro i hi
        apply add_le_add_right
        have hpi : (0:ℝ) < p i := by exact_mod_cast hp i
        have hh := one_div_le_one_div_of_le (by positivity : (0:ℝ)<(p i:ℝ)*(p i+1)) (hpden i)
        simpa [div_eq_mul_inv, mul_comm] using hh
  have hqfactor : (∏ i,(1+(1:ℝ)/q i)) ≤ (1+(1/(n:ℝ))/b)^3 := by
    calc
      _ ≤ ∏ _i : Fin 3, (1+(1/(n:ℝ))/b) := by
        apply Finset.prod_le_prod₀ (by intros; positivity)
        intro i hi
        apply add_le_add_right
        have hh := one_div_le_one_div_of_le (by positivity : (0:ℝ)<b*n) (hqbound i)
        simpa [div_eq_mul_inv, mul_comm] using hh
      _ = _ := by simp
  have hfac : 0 ≤ 1-4*α*(a/b)^3*(1/(n:ℝ)) := by
    by_contra h
    have hpre : 0 < (1+(1/(n:ℝ))/(a^2+a/89693))^3*(1+3/8*(1/(n:ℝ))) := by positivity
    have hneg := mul_neg_of_pos_of_neg hpre (lt_of_not_ge h)
    have hleft : 0 < (1+(1/(n:ℝ))/b)^3 := by positivity
    linarith
  calc
    _ ≤ (1+(1/(n:ℝ))/b)^3 := hqfactor
    _ ≤ (1+(1/(n:ℝ))/(a^2+a/89693))^3*(1+3/8*(1/(n:ℝ)))*
      (1-4*α*(a/b)^3*(1/(n:ℝ))) := scalar
    _ ≤ (∏ i,(1+1/(p i*(p i+1):ℝ)))*(1+3/8*(1/(n:ℝ)))*
      (1-4*(j+1:ℝ)*(∏ i,(p i:ℝ))/(∏ i,(q i:ℝ))) := by gcongr
    _ = _ := by ring

lemma window_uniform (n : ℕ) (hn : 89693^2 ≤ n)
    (p q : Fin 3 → ℕ) (hp : ∀ i, 0 < p i) (hq : ∀ i, 0 < q i)
    (a b α : ℝ) (ha : 0 < a) (hb : 0 < b) (hα : 0 ≤ α)
    (hpbound : ∀ i, (p i:ℝ) ≤ a*Real.sqrt n)
    (hqbound : ∀ i, b*n ≤ (q i:ℝ))
    (hcert : ScalarCertificate a b α) :
    (∏ i,(1+(1:ℝ)/q i)) ≤
      (∏ i,(1+1/(p i*(p i+1):ℝ)))*(1+3/(8*(n:ℝ)))*
      (1-4*α*(a/b)^3*(1/(n:ℝ))) := by
  have hn0 : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<89693^2) hn)
  have hs0 : 0 < Real.sqrt (n:ℝ) := Real.sqrt_pos.mpr hn0
  have hsX := LcmDev.hsqrt_ge hn
  have hsq := Real.sq_sqrt hn0.le
  have hsmall : 0 ≤ 1/(n:ℝ) ∧ 1/(n:ℝ) ≤ 1/(89693^2:ℝ) :=
    ⟨by positivity, one_div_le_one_div_of_le (by norm_num) (by exact_mod_cast hn)⟩
  have scalar := hcert (1/(n:ℝ)) hsmall
  have hden : 0 < a^2+a/89693 := by positivity
  have hpden (i : Fin 3) : (p i:ℝ)*(p i+1) ≤ (a^2+a/89693)*(n:ℝ) := by
    have hp0 : (0:ℝ) ≤ p i := Nat.cast_nonneg _
    have hupper : (p i:ℝ)*(p i+1) ≤ (a*Real.sqrt n)*(a*Real.sqrt n+1) := by gcongr; exact hpbound i; exact hpbound i
    have hxs : (89693:ℝ)*Real.sqrt n ≤ n := by nlinarith
    have hh := mul_le_mul_of_nonneg_left hxs ha.le
    nlinarith
  have hpfactor : (1+(1/(n:ℝ))/(a^2+a/89693))^3 ≤ ∏ i,(1+1/(p i*(p i+1):ℝ)) := by
    calc
      _ = ∏ _i : Fin 3, (1+(1/(n:ℝ))/(a^2+a/89693)) := by simp
      _ ≤ _ := by
        apply Finset.prod_le_prod₀ (by intros; positivity)
        intro i hi
        apply add_le_add_right
        have hpi : (0:ℝ) < p i := by exact_mod_cast hp i
        have hh := one_div_le_one_div_of_le (by positivity : (0:ℝ)<(p i:ℝ)*(p i+1)) (hpden i)
        simpa [div_eq_mul_inv, mul_comm] using hh
  have hqfactor : (∏ i,(1+(1:ℝ)/q i)) ≤ (1+(1/(n:ℝ))/b)^3 := by
    calc
      _ ≤ ∏ _i : Fin 3, (1+(1/(n:ℝ))/b) := by
        apply Finset.prod_le_prod₀ (by intros; positivity)
        intro i hi
        apply add_le_add_right
        have hh := one_div_le_one_div_of_le (by positivity : (0:ℝ)<b*n) (hqbound i)
        simpa [div_eq_mul_inv, mul_comm] using hh
      _ = _ := by simp
  have hfac : 0 ≤ 1-4*α*(a/b)^3*(1/(n:ℝ)) := by
    by_contra h
    have hpre : 0 < (1+(1/(n:ℝ))/(a^2+a/89693))^3*(1+3/8*(1/(n:ℝ))) := by positivity
    have hneg := mul_neg_of_pos_of_neg hpre (lt_of_not_ge h)
    have hleft : 0 < (1+(1/(n:ℝ))/b)^3 := by positivity
    linarith
  calc
    _ ≤ (1+(1/(n:ℝ))/b)^3 := hqfactor
    _ ≤ (1+(1/(n:ℝ))/(a^2+a/89693))^3*(1+3/8*(1/(n:ℝ)))*
      (1-4*α*(a/b)^3*(1/(n:ℝ))) := scalar
    _ ≤ (∏ i,(1+1/(p i*(p i+1):ℝ)))*(1+3/8*(1/(n:ℝ)))*
      (1-4*α*(a/b)^3*(1/(n:ℝ))) := by gcongr
    _ = _ := by ring

lemma offset_good (C : Criterion) (j : ℕ)
    (hc : (∏ i,(1+(1:ℝ)/C.q i)) ≤
      (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ)))*
      (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))) :
    0 < witness C (C.m-j) ∧ witness C (C.m-j) < L C.n ∧
      (σ (L C.n):ℝ) < σ (witness C (C.m-j)) := by
  let A : ℕ := 4*∏ i,C.p i
  let Q : ℕ := ∏ i,C.q i
  have hA : 0 < A := mul_pos (by norm_num) (Finset.prod_pos fun i _ => (C.hp i).pos)
  have hQ : (0:ℝ) < Q := by exact_mod_cast (Finset.prod_pos fun i _ => (C.hq i).pos)
  have hn0 : (0:ℝ) < C.n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<1) C.hn)
  have hR : 0 < 1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)) := by
    have hleft : 0 < ∏ i,(1+(1:ℝ)/C.q i) := Finset.prod_pos fun i _ => by positivity
    have hpre : 0 < (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ))) := by positivity
    by_contra hh
    have hh' := mul_nonpos_of_nonneg_of_nonpos hpre.le (le_of_not_gt hh)
    linarith only [hc,hleft,hh']
  have hAJ : A*(j+1) < Q := by
    rw [sub_pos,div_lt_one (by simpa [Q] using hQ)] at hR
    dsimp [A,Q]
    have hh : 4*(j+1)*(∏ i,C.p i) < ∏ i,C.q i := by exact_mod_cast hR
    simpa [Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using hh
  have hjm : j < C.m := by
    have hm : j+1 ≤ Q/A := (Nat.le_div_iff_mul_le hA).mpr (by simpa [Nat.mul_comm] using hAJ.le)
    exact lt_of_lt_of_le (Nat.lt_succ_self j) hm
  have hmpos : 0 < C.m-j := Nat.sub_pos_of_lt hjm
  have hwpos := witness_pos C (C.m-j) hmpos
  have hwsmall : witness C (C.m-j) < L C.n := by
    have hh : witness C (C.m-j) ≤ C.M :=
      Nat.mul_le_mul_right C.L' (Nat.mul_le_mul_left A (Nat.sub_le C.m j))
    exact hh.trans_lt C.M_lt
  refine ⟨hwpos,hwsmall,?_⟩
  have hLp : (0:ℝ) < L C.n := by exact_mod_cast C.L_pos
  have hWp : (0:ℝ) < witness C (C.m-j) := by exact_mod_cast hwpos
  have hLp' : (C.L':ℝ) ≠ 0 := by exact_mod_cast C.L'_pos.ne'
  have hQp : (0:ℝ) < ∏ i,(C.q i:ℝ) := by simpa [Q] using hQ
  have hratio : (witness C (C.m-j):ℝ)/(L C.n) = (A:ℝ)*((C.m-j:ℕ):ℝ)/Q := by
    rw [C.L_eq_prod_q_mul_L']
    dsimp [witness,A,Q]
    push_cast
    field_simp [hLp',ne_of_gt hQp]
    <;> ring
  have hround : 1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)) <
      (witness C (C.m-j):ℝ)/(L C.n) := by
    rw [hratio]
    apply (lt_div_iff₀ hQ).mpr
    have hmod : (Q:ℝ) = (A:ℝ)*C.m+C.r := by exact_mod_cast C.prod_q_eq
    have hr : (C.r:ℝ) < A := by exact_mod_cast C.r_le
    have hsub : ((C.m-j:ℕ):ℝ) = (C.m:ℝ)-j := Nat.cast_sub hjm.le
    have heq : (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))*(Q:ℝ) =
        (Q:ℝ)-(A:ℝ)*(j+1) := by
      dsimp [A,Q]
      push_cast
      field_simp [ne_of_gt hQp]
      <;> ring
    rw [heq,hsub]
    nlinarith only [hmod,hr]
  have hsigp : 0 < σnorm (witness C (C.m-j)) := by
    unfold σnorm
    exact div_pos (by exact_mod_cast (show 0 < σ (witness C (C.m-j)) by rw [σ,sigma_pos_iff]; exact hwpos)) hWp
  have hsig : σnorm (L C.n) ≤ σnorm (witness C (C.m-j))*
      (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) := by
    rw [C.σnorm_ln_eq]
    have hb := sigma_lower C (C.m-j) hmpos
    have hs : 0 ≤ σnorm C.L' := by unfold σnorm; positivity
    change σnorm (witness C (C.m-j)) ≥ σnorm C.L'*
      (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ))) at hb
    calc
      _ ≤ σnorm C.L'*((∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ)))*
          (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))) :=
        mul_le_mul_of_nonneg_left hc hs
      _ = (σnorm C.L'*(∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ))))*
          (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hb hR.le

  have hfinal := hsig.trans_lt (mul_lt_mul_of_pos_left hround hsigp)
  have heq : σnorm (witness C (C.m-j))*((witness C (C.m-j):ℝ)/(L C.n)) =
      (σ (witness C (C.m-j)):ℝ)/(L C.n) := by
    unfold σnorm
    field_simp
  rw [heq] at hfinal
  exact (div_lt_div_iff_of_pos_right hLp).mp hfinal


lemma offset_density (C : Criterion) (j : ℕ)
    (hc : (∏ i,(1+(1:ℝ)/C.q i)) ≤
      (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ)))*
      (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))) :
    0 < C.m-j ∧ witness C (C.m-j) < L C.n ∧
      (σ (L C.n):ℝ) < ((C.m-j:ℕ):ℝ)*σ (witness C 1) := by
  let A : ℕ := 4*∏ i,C.p i
  let Q : ℕ := ∏ i,C.q i
  have hA : 0 < A := mul_pos (by norm_num) (Finset.prod_pos fun i _ => (C.hp i).pos)
  have hQ : (0:ℝ) < Q := by exact_mod_cast (Finset.prod_pos fun i _ => (C.hq i).pos)
  have hn0 : (0:ℝ) < C.n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<1) C.hn)
  have hR : 0 < 1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)) := by
    have hleft : 0 < ∏ i,(1+(1:ℝ)/C.q i) := Finset.prod_pos fun i _ => by positivity
    have hpre : 0 < (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ))) := by positivity
    by_contra hh
    have hh' := mul_nonpos_of_nonneg_of_nonpos hpre.le (le_of_not_gt hh)
    linarith only [hc,hleft,hh']
  have hAJ : A*(j+1) < Q := by
    rw [sub_pos,div_lt_one (by simpa [Q] using hQ)] at hR
    dsimp [A,Q]
    have hh : 4*(j+1)*(∏ i,C.p i) < ∏ i,C.q i := by exact_mod_cast hR
    simpa [Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using hh
  have hjm : j < C.m := by
    have hm : j+1 ≤ Q/A := (Nat.le_div_iff_mul_le hA).mpr (by simpa [Nat.mul_comm] using hAJ.le)
    exact lt_of_lt_of_le (Nat.lt_succ_self j) hm
  have hmpos : 0 < C.m-j := Nat.sub_pos_of_lt hjm
  have hwpos := witness_pos C (C.m-j) hmpos
  have hwsmall : witness C (C.m-j) < L C.n := by
    have hh : witness C (C.m-j) ≤ C.M :=
      Nat.mul_le_mul_right C.L' (Nat.mul_le_mul_left A (Nat.sub_le C.m j))
    exact hh.trans_lt C.M_lt
  refine ⟨hmpos,hwsmall,?_⟩
  have hLp : (0:ℝ) < L C.n := by exact_mod_cast C.L_pos
  have hWp : (0:ℝ) < witness C (C.m-j) := by exact_mod_cast hwpos
  have hLp' : (C.L':ℝ) ≠ 0 := by exact_mod_cast C.L'_pos.ne'
  have hQp : (0:ℝ) < ∏ i,(C.q i:ℝ) := by simpa [Q] using hQ
  have hratio : (witness C (C.m-j):ℝ)/(L C.n) = (A:ℝ)*((C.m-j:ℕ):ℝ)/Q := by
    rw [C.L_eq_prod_q_mul_L']
    dsimp [witness,A,Q]
    push_cast
    field_simp [hLp',ne_of_gt hQp]
    <;> ring
  have hround : 1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)) <
      (witness C (C.m-j):ℝ)/(L C.n) := by
    rw [hratio]
    apply (lt_div_iff₀ hQ).mpr
    have hmod : (Q:ℝ) = (A:ℝ)*C.m+C.r := by exact_mod_cast C.prod_q_eq
    have hr : (C.r:ℝ) < A := by exact_mod_cast C.r_le
    have hsub : ((C.m-j:ℕ):ℝ) = (C.m:ℝ)-j := Nat.cast_sub hjm.le
    have heq : (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))*(Q:ℝ) =
        (Q:ℝ)-(A:ℝ)*(j+1) := by
      dsimp [A,Q]
      push_cast
      field_simp [ne_of_gt hQp]
      <;> ring
    rw [heq,hsub]
    nlinarith only [hmod,hr]
  have hsigp : 0 < σnorm (witness C 1) := by
    unfold σnorm
    exact div_pos (by exact_mod_cast (show 0 < σ (witness C 1) by rw [σ,sigma_pos_iff]; exact witness_pos C 1 (by norm_num))) (by exact_mod_cast witness_pos C 1 (by norm_num))
  have hsig : σnorm (L C.n) ≤ σnorm (witness C 1)*
      (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) := by
    rw [C.σnorm_ln_eq]
    have hb := sigma_lower C 1 (by norm_num)
    have hs : 0 ≤ σnorm C.L' := by unfold σnorm; positivity
    change σnorm (witness C 1) ≥ σnorm C.L'*
      (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ))) at hb
    calc
      _ ≤ σnorm C.L'*((∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ)))*
          (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))) :=
        mul_le_mul_of_nonneg_left hc hs
      _ = (σnorm C.L'*(∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ))))*
          (1-4*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hb hR.le

  have hfinal := hsig.trans_lt (mul_lt_mul_of_pos_left hround hsigp)
  have heq : σnorm (witness C 1)*((witness C (C.m-j):ℝ)/(L C.n)) =
      ((C.m-j:ℕ):ℝ)*(σ (witness C 1):ℝ)/(L C.n) := by
    have hw : witness C (C.m-j) = witness C 1 * (C.m-j) := by simp [witness]; ring
    have hd0 : (witness C 1 : ℝ) ≠ 0 := by exact_mod_cast (witness_pos C 1 (by norm_num)).ne'
    unfold σnorm
    rw [hw]
    push_cast
    field_simp [hd0, hLp.ne']
    <;> ring
  rw [heq] at hfinal
  exact (div_lt_div_iff_of_pos_right hLp).mp hfinal


lemma ratio_good (C : Criterion) (t : ℕ) (β : ℝ) (ht : 0 < t)
    (hsmall : witness C t < L C.n)
    (hgap : β < (witness C t:ℝ)/(L C.n))
    (hc : (∏ i,(1+(1:ℝ)/C.q i)) ≤
      (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ)))*β) :
    0 < witness C t ∧ witness C t < L C.n ∧
      (σ (L C.n):ℝ) < σ (witness C t) := by
  have hW := witness_pos C t ht
  have hL : (0:ℝ) < L C.n := by exact_mod_cast C.L_pos
  have hWp : (0:ℝ) < witness C t := by exact_mod_cast hW
  have hβ : 0 < β := by
    have hl : 0 < ∏ i,(1+(1:ℝ)/C.q i) := Finset.prod_pos fun i _ => by positivity
    have hp : 0 < (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ))) := by positivity
    by_contra h
    have hh := mul_nonpos_of_nonneg_of_nonpos hp.le (le_of_not_gt h)
    linarith
  have hnorm : σnorm (L C.n) ≤ σnorm (witness C t)*β := by
    rw [C.σnorm_ln_eq]
    have hs : 0 ≤ σnorm C.L' := by unfold σnorm; positivity
    have hb := sigma_lower C t ht
    calc
      _ ≤ σnorm C.L'*((∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ)))*β) :=
        mul_le_mul_of_nonneg_left hc hs
      _ = (σnorm C.L'*(∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ))))*β := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hb hβ.le
  have hnormW : 0 < σnorm (witness C t) := by
    unfold σnorm
    exact div_pos (by exact_mod_cast (show 0 < σ (witness C t) by rw [σ,sigma_pos_iff]; exact hW)) hWp
  have hh := hnorm.trans_lt (mul_lt_mul_of_pos_left hgap hnormW)
  have heq : σnorm (witness C t)*((witness C t:ℝ)/(L C.n)) = (σ (witness C t):ℝ)/(L C.n) := by
    unfold σnorm
    field_simp
  rw [heq] at hh
  exact ⟨hW,hsmall,(div_lt_div_iff_of_pos_right hL).mp hh⟩

theorem count_offsets (C : Criterion) (K start : ℕ)
    (hcmp : ∀ j : ℕ, j < K →
      (∏ i,(1+(1:ℝ)/C.q i)) ≤
      (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+3/(8*(C.n:ℝ)))*
        (1-4*(j+start+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))) :
    ∃ S : Finset ℕ, K ≤ S.card ∧ ∀ m ∈ S,
      0 < m ∧ m < Nat.lcmUpto C.n ∧
        (ArithmeticFunction.sigma 1 (Nat.lcmUpto C.n):ℝ) < ArithmeticFunction.sigma 1 m := by
  classical
  have hgood (j : ℕ) (hj : j < K) := offset_good C (j+start) (by simpa only [Nat.cast_add] using hcmp j hj)
  have hsubpos (j : ℕ) (hj : j < K) : 0 < C.m-(j+start) := by
    have hh := (hgood j hj).1
    by_contra hn
    have heq : C.m-(j+start)=0 := by omega
    simp [witness,heq] at hh
  let f : ℕ → ℕ := fun j => witness C (C.m-(j+start))
  let S : Finset ℕ := (Finset.range K).image f
  have hinj : Set.InjOn f (Finset.range K) := by
    intro i hi j hj hij
    have hi0 := hsubpos i (Finset.mem_range.mp hi)
    have hj0 := hsubpos j (Finset.mem_range.mp hj)
    have hA : 0 < 4*∏ i,C.p i := mul_pos (by norm_num) (Finset.prod_pos fun i _ => (C.hp i).pos)
    have h1 := Nat.eq_of_mul_eq_mul_right C.L'_pos hij
    have h2 := Nat.eq_of_mul_eq_mul_left hA h1
    omega
  refine ⟨S,?_,?_⟩
  · have hh : S.card=K := by rw [Finset.card_image_of_injOn hinj,Finset.card_range]
    exact hh.ge
  · intro m hm
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hm
    simpa [f,L,σ,Nat.lcmUpto] using hgood j (Finset.mem_range.mp hj)

end FixedChain
