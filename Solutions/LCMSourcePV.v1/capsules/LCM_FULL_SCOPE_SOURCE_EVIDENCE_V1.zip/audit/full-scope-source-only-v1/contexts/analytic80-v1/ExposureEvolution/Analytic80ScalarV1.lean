import Mathlib
namespace ExposureEvolution.Analytic80ScalarV1
open Finset Real
set_option maxHeartbeats 4000000
lemma p_lower {e : ℝ} (he : 0≤e) :
    1+2.99454*e ≤ ∏ i : Fin 3,
      (1+e/((2198/2197:ℝ)^(2*((i:ℕ)+1:ℝ)))*(1/(1+1/(1000000:ℝ)))) := by
  norm_cast
  norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg he 2,pow_nonneg he 3]
lemma q_upper {e : ℝ} (he : 0≤e) :
    (∏ i : Fin 3,(1+(2198/2197:ℝ)^((i:ℕ)+1:ℝ)*e)) ≤
      1+3.00274*e+3.006*e^2+1.003*e^3 := by
  norm_cast
  norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg he 2,pow_nonneg he 3]
lemma scalar {e : ℝ} (he : 0≤e) (heu : e≤1/(10:ℝ)^12) :
    (1+(4/5:ℝ)*e)*(1+3.00274*e+3.006*e^2+1.003*e^3) ≤
      (1+2.99454*e)*(1+0.81633*e)*(1-0.00783*e) := by
  have h2 : e^2 ≤ e/(10:ℝ)^12 := by nlinarith
  have h3 : e^3 ≤ e^2/(10:ℝ)^12 := by
    nlinarith [mul_nonneg (sq_nonneg e) (sub_nonneg.mpr heu)]
  have h4 : e^4 ≤ e^2/(10:ℝ)^24 := by
    have h := mul_le_mul_of_nonneg_right h3 he
    norm_num [show (24:ℕ)=12+12 by norm_num,pow_add] at h ⊢
    nlinarith
  nlinarith [sq_nonneg e]
lemma rounding_constant : (7776:ℝ)*(2198/2197:ℝ)^12/1000000 ≤ 0.00783 := by norm_num
#print axioms scalar
end ExposureEvolution.Analytic80ScalarV1
