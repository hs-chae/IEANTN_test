import ExposureEvolution.Analytic80GeometryV1
import ExposureEvolution.Analytic80ScalarV1
import QRHRound2.LcmWitnessNoPVMath
import IEANTN.Nodes.Dusart2018.v1.Conclusions
namespace ExposureEvolution.Analytic80V1
open Finset Nat Real E1Tertiary.LcmBase
open ExposureEvolution.Analytic80GeometryV1
set_option Elab.async false
set_option maxHeartbeats 4000000
lemma exp_thirteen_small : exp (13:ℝ)<1000000 := by
  have he : exp 1<(14/5:ℝ) := by linarith [Real.exp_one_lt_d9]
  calc exp (13:ℝ)=(exp 1)^13 := by rw [Real.exp_one_pow];norm_num
       _≤(14/5:ℝ)^13 := pow_le_pow_left₀ (exp_pos 1).le he.le 13
       _<1000000 := by norm_num
lemma source_gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 1000000 := by
  intro x hx
  have hx0 : 0< x := by linarith
  have hl : 13< Real.log x := by
    have h := log_lt_log (exp_pos (13:ℝ)) (exp_thirteen_small.trans_le hx)
    simpa only [log_exp] using h
  have hl0 : 0< Real.log x := by linarith
  have hc : (2197:ℝ)< Real.log x^3 := by
    nlinarith [mul_pos (by linarith : 0< Real.log x-13) (sq_pos_of_pos hl0)]
  obtain ⟨p,hp,hpx,hpu⟩ := hd x (by linarith)
  refine ⟨p,hp,hpx,hpu.trans_lt ?_⟩
  norm_num only [Real.rpow_ofNat]
  linarith [div_lt_div_of_pos_left hx0 (by norm_num : (0:ℝ)<2197) hc]
lemma log_height : (13:ℝ)≤ Real.log 1000000 := by
  have h := log_lt_log (exp_pos (13:ℝ)) exp_thirteen_small
  simpa only [log_exp] using h.le
lemma inverse_height (n : ℕ) (hn : (1000000:ℝ)^2≤ n) :
    1/((n:ℝ)^(3/2:ℝ)) ≤ (1/(1000000:ℝ))*(1/n) := by
  have hnp : (0:ℝ)< n := by nlinarith
  have hs : (1000000:ℝ)≤ Real.sqrt (n:ℝ) := le_sqrt_of_sq_le hn
  rw [one_div_mul_one_div,one_div_le_one_div (rpow_pos_of_pos hnp _)
    (mul_pos (by norm_num) hnp),show (3/2:ℝ)=1+1/2 by ring,
    rpow_add hnp,rpow_one,mul_comm,←sqrt_eq_rpow]
  exact mul_le_mul_of_nonneg_left hs hnp.le
lemma inverse_n_sqrt (n : ℕ) (hn : (1000000:ℝ)^2≤ n) :
    1/((n:ℝ)+Real.sqrt n) ≥ (1/(1+1/(1000000:ℝ)))*(1/n) := by
  have hnp : (0:ℝ)< n := by nlinarith
  have hs : (1000000:ℝ)≤ Real.sqrt (n:ℝ) := le_sqrt_of_sq_le hn
  have hsq : Real.sqrt (n:ℝ)^2=(n:ℝ) := sq_sqrt hnp.le
  have hsp : (0:ℝ)< Real.sqrt (n:ℝ) := by positivity
  rw [ge_iff_le,one_div_mul_one_div,div_le_div_iff₀ (by positivity) (by positivity)]
  nlinarith [hs,hsq,hsp]
lemma pq_ratio (hd : StrictGap 1000000) (n : ℕ) (hn : (1000000:ℝ)^2≤ n) :
    let C := Analytic80GeometryV1.Criterion.mk' hd (by norm_num : (9:ℝ)≤13) log_height hn
    1-(7776:ℝ)*(∏i,(C.p i:ℝ))/∏i,(C.q i:ℝ) ≥
      1-7776*(1+1/2197:ℝ)^12/(n:ℝ)^(3/2:ℝ) := by
  have h := Analytic80GeometryV1.pq_ratio_ge hd (by norm_num : (9:ℝ)≤13) log_height hn
  dsimp only [Analytic80GeometryV1.Criterion.mk']
  simp only [div_eq_mul_inv] at h ⊢
  nlinarith [h]
lemma product_lower {e : ℝ} (he : 0≤ e) (heu : e≤1/(10:ℝ)^12) :
    (1+2.99454*e)*(1+0.81633*e)*(1-0.00783*e) ≤
      (∏i : Fin 3,(1+e/((2198/2197:ℝ)^(2*((i:ℕ)+1:ℝ)))*(1/(1+1/(1000000:ℝ)))))*
        (1+0.81633*e)*(1-7776*(2198/2197:ℝ)^12/1000000*e) := by
  have hR : 0≤1-0.00783*e := by nlinarith
  gcongr
  · exact Analytic80ScalarV1.p_lower he
  · nlinarith [Analytic80ScalarV1.rounding_constant]
lemma comparison (hd : StrictGap 1000000) (n : ℕ) (hn : (1000000:ℝ)^2≤ n) :
    let C := Analytic80GeometryV1.Criterion.mk' hd (by norm_num : (9:ℝ)≤13) log_height hn
    (1+4/(5*(n:ℝ)))*∏i,(1+(1:ℝ)/C.q i) ≤
      (∏i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+0.81633/(n:ℝ))*
        (1-7776*(∏i,(C.p i:ℝ))/∏i,(C.q i:ℝ)) := by
  dsimp only [Analytic80GeometryV1.Criterion.mk']
  have hnp : (0:ℝ)< n := by nlinarith
  have he : (0:ℝ)≤1/(n:ℝ) := by positivity
  have heu : (1:ℝ)/(n:ℝ)≤1/(10:ℝ)^12 := by
    rw [div_le_div_iff₀ hnp (by norm_num)]
    norm_num at hn ⊢
    exact hn
  have h₁ : 1-(7776:ℝ)*(∏i,((exists_p_primes hd (by norm_num : (9:ℝ)≤13) log_height hn).choose i:ℝ))/
        (∏i,((exists_q_primes hd (by norm_num : (9:ℝ)≤13) log_height hn).choose i:ℝ)) ≥
      1-7776*(1+1/2197:ℝ)^12*((1/1000000)*(1/n)) := by
    have hr := pq_ratio hd n hn
    dsimp only [Analytic80GeometryV1.Criterion.mk'] at hr
    grw [hr,←inverse_height n hn]
    simp [field]
  have hnn : 0≤1-7776*(1+1/2197:ℝ)^12*((1/1000000)*(1/n)) := by
    nlinarith [Analytic80ScalarV1.rounding_constant]
  have := hnn.trans h₁
  grw [prod_q_ge hd (by norm_num : (9:ℝ)≤13) log_height hn,
    prod_p_ge hd (by norm_num : (9:ℝ)≤13) log_height hn,h₁]
  simp_rw [div_eq_mul_one_div (_^(_:ℝ):ℝ) (n:ℝ),
    show 0.81633/(n:ℝ)=(0.81633:ℝ)*(1/n) by ring,←one_div_mul_one_div]
  grw [inverse_n_sqrt n hn]
  set e : ℝ := 1/(n:ℝ)
  calc
    _≤(1+(4/5:ℝ)*e)*∏i : Fin 3,(1+(1+1/2197:ℝ)^((i:ℕ)+1:ℝ)*e) := by
      gcongr <;> dsimp [e] <;> ring_nf <;> exact le_rfl
    _=(1+(4/5:ℝ)*e)*∏i : Fin 3,(1+(2198/2197:ℝ)^((i:ℕ)+1:ℝ)*e) := by norm_num
    _≤(1+(4/5:ℝ)*e)*(1+3.00274*e+3.006*e^2+1.003*e^3) :=
      mul_le_mul_of_nonneg_left (Analytic80ScalarV1.q_upper he) (by positivity)
    _≤(1+2.99454*e)*(1+0.81633*e)*(1-0.00783*e) := Analytic80ScalarV1.scalar he heu
    _≤_ := by
      convert product_lower he heu using 1 <;> norm_num [Fin.prod_univ_three] <;> ring

/-- New data-free analytic construction with core6^5 and explicit whole-ray onset.
It is separate posthoc mathematics, not a change to any locked candidate or arm. -/
theorem quantitative_of_gap (hd : StrictGap 1000000) (n : ℕ) (hn : (1000000:ℝ)^2 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1+4/(5*(n:ℝ)))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  let C := Analytic80GeometryV1.Criterion.mk' hd (by norm_num : (9:ℝ) ≤ 13) log_height hn
  have hr := comparison hd n hn
  change (1+4/(5*(n:ℝ)))*(∏i,(1+(1:ℝ)/C.q i)) ≤
    (∏i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+0.81633/(n:ℝ))*
      (1-7776*(∏i,(C.p i:ℝ))/∏i,(C.q i:ℝ)) at hr
  have hnp : (0:ℝ) < n := by nlinarith
  have hQ : (0:ℝ) < ∏i,(C.q i:ℝ) := Finset.prod_pos fun i _ => by exact_mod_cast (C.hq i).pos
  have hR : (0:ℝ) < 1-7776*(∏i,(C.p i:ℝ))/∏i,(C.q i:ℝ) := by
    have hA : (0:ℝ) < (1+4/(5*(n:ℝ)))*(∏i,(1+(1:ℝ)/C.q i)) :=
      mul_pos (by positivity) (Finset.prod_pos fun i _ => by positivity)
    have hB : (0:ℝ) < (∏i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+0.81633/(n:ℝ)) := by positivity
    by_contra hbad
    have hh := mul_nonpos_of_nonneg_of_nonpos hB.le (le_of_not_gt hbad)
    linarith
  let D : QRHRound2.LcmWitnessNoPVBase.PowerCriterion := {
    k := 5
    hk := by norm_num
    n := n
    hn := C.hn
    p := C.p
    hp := C.hp
    hp_mono := C.hp_mono
    hthree := by
      have hs : (1000000:ℝ) ≤ Real.sqrt (n:ℝ) := le_sqrt_of_sq_le hn
      have hp : Real.sqrt (n:ℝ) < C.p 0 := C.h_ord_1
      have hh : (3:ℝ) < C.p 0 := by linarith
      exact_mod_cast hh
    q := C.q
    hq := C.hq
    hq_mono := C.hq_mono
    h_ord_1 := C.h_ord_1
    h_ord_2 := C.h_ord_2
    h_ord_3 := C.h_ord_3
    h_product := by
      rw [sub_pos,div_lt_one hQ] at hR
      norm_num only [Nat.reducePow]
      exact_mod_cast hR }
  have hcore : (1+0.81633/(n:ℝ)) ≤
      QRHRound2.LcmWitnessNoPVMath.core2 D*QRHRound2.LcmWitnessNoPVMath.core3 D := by
    dsimp [QRHRound2.LcmWitnessNoPVMath.core2,QRHRound2.LcmWitnessNoPVMath.core3,D]
    norm_num
    field_simp
    nlinarith [sq_nonneg (n:ℝ)]
  refine ⟨D.M,D.M_pos,D.M_lt,?_⟩
  apply QRHRound2.LcmWitnessNoPVMath.criterion_surplus D (t:=4/(5*(n:ℝ))) (by positivity)
  have hm := mul_le_mul_of_nonneg_left hcore
    (show (0:ℝ) ≤ (∏i,(1+1/(C.p i*(C.p i+1):ℝ)))*
      (1-7776*(∏i,(C.p i:ℝ))/∏i,(C.q i:ℝ)) from mul_nonneg (by positivity) hR.le)
  norm_num [D] at *
  nlinarith

theorem whole_ray (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 1000000000000 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1+(4/5:ℝ)/(n:ℝ))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hreal : (1000000:ℝ)^2 ≤ n := by norm_num;exact_mod_cast hn
  have h := quantitative_of_gap (source_gap hd) n hreal
  convert h using 1 <;> ring
#print axioms whole_ray
end ExposureEvolution.Analytic80V1
