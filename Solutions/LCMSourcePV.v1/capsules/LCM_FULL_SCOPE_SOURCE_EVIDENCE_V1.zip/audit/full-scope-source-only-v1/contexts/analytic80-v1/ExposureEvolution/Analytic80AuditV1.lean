import ExposureEvolution.Analytic80V1
import Lean.Util.CollectAxioms
namespace ExposureEvolution.Analytic80AuditV1
open Lean Elab Command
run_elab do
  let env ← getEnv
  let root := ``ExposureEvolution.Analytic80V1.whole_ray
  let some ci := env.find? root | throwError "missing actualnewanalyticconsumer"
  let expected ← Term.elabType (← `(Dusart2018.v1.proposition_5_4 → ∀ n : ℕ,
    1000000000000 ≤ n → ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1+(4/5:ℝ)/(n:ℝ))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m))
  unless ← Meta.isDefEq ci.type expected do throwError "literalfullnewanalyticraytypemismatch"
  let ax ← Lean.collectAxioms root
  unless ax.toList.all [``propext,``Classical.choice,``Quot.sound].contains do
    throwError "nonstandard rootaxiom"
  logInfo m!"ANALYTIC80_AUDIT_JSON {(Json.mkObj [
    ("status",toJson "FULL_DATA_FREE_POINT8_WHOLE_RAY_FROM_ONE_TRILLION_STANDARD_KERNEL_PASS"),
    ("root",toJson root.toString),("type",toJson (toString (← Meta.ppExpr ci.type))),
    ("axioms",toJson (ax.toList.map Name.toString)),
    ("numerical_prime_certificate_used",toJson false)]).compress}"
end ExposureEvolution.Analytic80AuditV1
