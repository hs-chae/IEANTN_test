/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Terence Tao, OpenAI (Codex)
-/
import E1TwoTracks.TrackNPowerBase
namespace E1TwoTracks.TrackNPowerMath
open ArithmeticFunction hiding log
open Finset Nat Real
open E1TwoTracks.TrackNPowerBase
set_option maxHeartbeats 3000000

lemma val_two (c : PowerCriterion) (kExtra : ℕ) (hdiv : 2 ^ kExtra ∣ c.m) :
    c.L'.factorization 2 + (kExtra + c.k) ≤ c.M.factorization 2 := by
  have hp : 0 < ∏ i, c.p i := Finset.prod_pos fun i _ => (c.hp i).pos
  have ha : 2^c.k * ∏ i, c.p i ≠ 0 := by positivity
  have hm : c.m ≠ 0 := c.m_pos.ne'
  have hl : c.L' ≠ 0 := c.L'_pos.ne'
  have h4 : c.k ≤ (2^c.k * ∏ i, c.p i).factorization 2 :=
    (Nat.prime_two.pow_dvd_iff_le_factorization ha).mp (dvd_mul_right _ _)
  have h2 : kExtra ≤ c.m.factorization 2 :=
    (Nat.prime_two.pow_dvd_iff_le_factorization hm).mp hdiv
  change c.L'.factorization 2 + (kExtra + c.k) ≤ ((2^c.k * ∏ i, c.p i) * c.m * c.L').factorization 2
  rw [Nat.factorization_mul (mul_ne_zero ha hm) hl, Nat.factorization_mul ha hm]
  simp only [Finsupp.add_apply]
  omega

lemma ratio_ge_aux {k : ℕ} (n j : ℕ) (hk : 2 ^ k ≤ n) :
    (∑ i ∈ Finset.range (k + j + 1), (1 / 2 : ℝ) ^ i) /
      (∑ i ∈ Finset.range (k + 1), (1 / 2 : ℝ) ^ i) ≥
      1 + (1 - (1 / 2 : ℝ) ^ j) / (2 * n) := by
  have hu : 0 < (1 / 2 : ℝ) ^ k := by positivity
  have hu1 : (1 / 2 : ℝ) ^ k ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hv : 0 ≤ 1 - (1 / 2 : ℝ) ^ j := sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))
  have hn : (0 : ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by positivity : 0 < 2 ^ k) hk)
  have hinv : (n : ℝ)⁻¹ ≤ (1 / 2 : ℝ) ^ k := by
    simpa using inv_anti₀ (by positivity) (mod_cast hk)
  have hs1 : (∑ i ∈ Finset.range (k + j + 1), (1 / 2 : ℝ) ^ i) =
      2 - (1 / 2 : ℝ)^k * (1 / 2 : ℝ)^j := by
    norm_num [geom_sum_eq, pow_add]; ring
  have hs2 : (∑ i ∈ Finset.range (k + 1), (1 / 2 : ℝ) ^ i) =
      2 - (1 / 2 : ℝ)^k := by
    norm_num [geom_sum_eq, pow_add]; ring
  rw [hs1, hs2, ge_iff_le, le_div_iff₀ (by linarith : 0 < 2 - (1 / 2 : ℝ)^k)]
  have hterm : (1 - (1 / 2 : ℝ)^j) / (2 * n) ≤
      (1 - (1 / 2 : ℝ)^j) * (1 / 2 : ℝ)^k / 2 := by
    simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm] using
      mul_le_mul_of_nonneg_left hinv (div_nonneg hv (by norm_num : (0 : ℝ) ≤ 2))
  have hnon : 0 ≤ (1 - (1 / 2 : ℝ)^j) / (2 * n) := by positivity
  nlinarith [mul_nonneg hv (sq_nonneg ((1 / 2 : ℝ)^k))]

theorem sigma_boost (c : PowerCriterion) (kExtra : ℕ) (hdiv : 2 ^ kExtra ∣ c.m) :
    σnorm c.M ≥
      σnorm c.L' * (∏ i, (1 + 1 / (c.p i * (c.p i + 1 : ℝ)))) * (1 + (1 - (1 / 2 : ℝ) ^ (kExtra + c.k)) / (2 * c.n)) := by
  have hcoef : 0 ≤ 1 - (1 / 2 : ℝ) ^ (kExtra + c.k) :=
    sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))
  have h_sigma_norm_M : (σnorm c.M) = (σnorm (c.L' : ℕ)) * (∏ p ∈ Nat.primeFactors c.M,
      ((∑ i ∈ Finset.range (Nat.factorization c.M p + 1), (1 / p : ℝ) ^ i) /
      (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i))) := by
    have h_sigma_norm_prod : ∀ {n : ℕ}, n ≠ 0 → (σnorm n : ℝ) = (∏ p ∈ Nat.primeFactors n,
        ((∑ i ∈ Finset.range (Nat.factorization n p + 1), (1 / p : ℝ) ^ i))) := by
      intro n hn_ne_zero
      have h_sigma_def : ((σ n) : ℝ) = (∏ p ∈ Nat.primeFactors n, (∑ i ∈ Finset.range
          (Nat.factorization n p + 1), (p ^ i : ℝ))) := by
        unfold σ
        have h_sigma_def : ∀ {n : ℕ}, n ≠ 0 → (Nat.divisors n).sum (fun d ↦ d) =
            ∏ p ∈ n.primeFactors, (∑ i ∈ Finset.range (Nat.factorization n p + 1), p ^ i) := by
          exact fun {n} a ↦ sum_divisors a
        convert congr_arg (( ↑ ) : ℕ → ℝ) (h_sigma_def hn_ne_zero) using 1 <;>
        norm_num [ArithmeticFunction.sigma]
      have h_sigma_def : (n : ℝ) = (∏ p ∈ Nat.primeFactors n, (p ^ (Nat.factorization n p) : ℝ)) :=
        mod_cast Eq.symm (Nat.prod_factorization_pow_eq_self hn_ne_zero)
      simp_all only [div_eq_mul_inv]
      rw [← div_eq_mul_inv, ← Finset.prod_div_distrib]
      refine Finset.prod_congr rfl fun p hp ↦ ?_
      field_simp
      rw [Finset.mul_sum _ _ _, ← Finset.sum_flip]
      exact Finset.sum_congr rfl fun i hi ↦ by
        rw [show ((1:ℝ) / ↑p) ^ i = 1 / ((↑p) ^ i) by simp]
        rw [mul_one_div, eq_div_iff (pow_ne_zero _ <| Nat.cast_ne_zero.mpr <| Nat.ne_of_gt <|
          Nat.pos_of_mem_primeFactors hp), ←pow_add, Nat.sub_add_cancel <|
          Finset.mem_range_succ_iff.mp hi]
    by_cases hM : c.M = 0 <;> by_cases hL' : c.L' = 0
    · simp_all
    · exact absurd hM (Nat.ne_of_gt (PowerCriterion.M_pos c))
    · exact absurd hL' (Nat.ne_of_gt (PowerCriterion.L'_pos c))
    · simp_all only [ne_eq, one_div, inv_pow, not_false_eq_true, prod_div_distrib]
      rw [mul_div, eq_div_iff]
      · rw [mul_comm, ← Finset.prod_subset (show c.L'.primeFactors ⊆ c.M.primeFactors from ?_)]
        · intro p hp hpn; rw [Nat.factorization_eq_zero_of_not_dvd] <;> aesop
        · intro p hp; simp_all only [mem_primeFactors, ne_eq, not_false_eq_true, and_true, true_and]
          exact dvd_trans hp.2 (by exact ⟨(2^c.k * ∏ i, c.p i) * c.m, by rw [PowerCriterion.M]; ring⟩)
      · exact Finset.prod_ne_zero_iff.mpr fun p hp ↦ ne_of_gt <| Finset.sum_pos
          (fun _ _ ↦ inv_pos.mpr <| pow_pos (Nat.cast_pos.mpr <| Nat.pos_of_mem_primeFactors hp) _)
          <| by norm_num
  have h_ratio_terms (p : ℕ) (hp : p ∈ Nat.primeFactors c.M) : (∑ i ∈ Finset.range
      (Nat.factorization c.M p + 1), (1 / p : ℝ) ^ i) / (∑ i ∈ Finset.range
      (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i) ≥ if p ∈ Finset.image c.p Finset.univ
      then (1 + 1 / (p * (p + 1) : ℝ)) else if p = 2 then (1 + (1 - (1 / 2 : ℝ) ^ (kExtra + c.k)) / (2 * c.n)) else 1 := by
    split_ifs
    · obtain ⟨i, hi⟩ : ∃ i : Fin 3, p = c.p i := by grind
      have h_ratio_p_i : (∑ i ∈ Finset.range (Nat.factorization c.M p + 1), (1 / p : ℝ) ^ i) /
          (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i) ≥
          (∑ i ∈ Finset.range 3, (1 / p : ℝ) ^ i) / (∑ i ∈ Finset.range 2, (1 / p : ℝ) ^ i) := by
        rw [show Nat.factorization (c.L' : ℕ) p = 1 from hi ▸ c.val_p_L' i]
        exact div_le_div_of_nonneg_right (Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono
          (by grind [c.val_p_M_ge_two i])) fun _ _ _ ↦ by positivity)
          (Finset.sum_nonneg fun _ _ ↦ by positivity)
      convert h_ratio_p_i using 1; norm_num [Finset.sum_range_succ]; ring_nf; field_simp; grind
    · have h_geo_series : (∑ i ∈ Finset.range (Nat.factorization c.M 2 + 1), (1 / 2 : ℝ) ^ i)
          / (∑ i ∈ Finset.range (Nat.factorization c.L' 2 + 1), (1 / 2 : ℝ) ^ i) ≥
          (1 + (1 - (1 / 2 : ℝ) ^ (kExtra + c.k)) / (2 * c.n)) := by
        have h_geo_series : (∑ i ∈ Finset.range (Nat.factorization c.M 2 + 1), (1 / 2 : ℝ) ^ i)
            / (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + 1), (1 / 2 : ℝ) ^ i) ≥
            (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + (kExtra + c.k) + 1), (1 / 2 : ℝ) ^ i) /
            (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + 1), (1 / 2 : ℝ) ^ i) := by
          exact div_le_div_of_nonneg_right (Finset.sum_le_sum_of_subset_of_nonneg
            (Finset.range_mono (by linarith [val_two c kExtra hdiv])) fun _ _ _ ↦ by positivity)
            (Finset.sum_nonneg fun _ _ ↦ by positivity)
        refine le_trans ?_ h_geo_series
        convert ratio_ge_aux c.n (kExtra + c.k) _ using 1
        exact c.val_two_L'.symm ▸ Nat.pow_log_le_self 2 (by linarith [c.hn])
      aesop
    · rw [ge_iff_le, le_div_iff₀] <;> norm_num
      · refine Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono (Nat.succ_le_succ ?_))
          fun ?_ ?_ ?_ ↦ by positivity
        have h_div : c.L' ∣ c.M := by
          exact dvd_mul_left _ _
        exact (Nat.factorization_le_iff_dvd (by aesop) (by aesop)) |>.2 h_div p
      · exact Finset.sum_pos (fun _ _ ↦ inv_pos.mpr (pow_pos (Nat.cast_pos.mpr
          (Nat.pos_of_mem_primeFactors hp)) _)) (by norm_num)
  have h_prod_ratio_terms : (∏ p ∈ Nat.primeFactors c.M,
      ((∑ i ∈ Finset.range (Nat.factorization c.M p + 1), (1 / p : ℝ) ^ i) /
      (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i))) ≥
      (∏ p ∈ Finset.image c.p Finset.univ, (1 + 1/(p * (p + 1) : ℝ)))*(1 + (1 - (1 / 2 : ℝ) ^ (kExtra + c.k)) / (2 * c.n)) := by
    refine le_trans ?_ (Finset.prod_le_prod₀ ?_ h_ratio_terms)
    · rw [Finset.prod_ite]
      refine mul_le_mul ?_ ?_ (by positivity) (Finset.prod_nonneg fun _ _ ↦ by positivity)
      · rw [Finset.prod_subset]
        · simp only [mem_image, mem_univ, true_and, subset_iff, mem_filter, mem_primeFactors,
            forall_exists_index, forall_apply_eq_imp_iff, exists_apply_eq_apply, and_true]
          intro i; exact ⟨c.hp i, by
            exact dvd_mul_of_dvd_left (dvd_mul_of_dvd_left (dvd_mul_of_dvd_right
              (Finset.dvd_prod_of_mem _ (Finset.mem_univ _)) _) _) _, by
              exact Nat.ne_of_gt (PowerCriterion.M_pos c)⟩
        · aesop
      · rw [Finset.prod_ite]
        by_cases h : 2 ∈ c.M.primeFactors <;> simp_all +decide only
          [mem_primeFactors, true_and, prod_const]
        · simp only [one_pow, mul_one]
          refine le_self_pow₀ (M₀ := ℝ) (by norm_num ; positivity) ?_
          · norm_num; exact ⟨2, Nat.prime_two, h.1, h.2, fun i ↦ by linarith [c.p_gt_two i], rfl⟩
        · contrapose! h
          refine ⟨dvd_mul_of_dvd_left ?_ _, Nat.ne_of_gt (PowerCriterion.M_pos c)⟩
          · exact dvd_mul_of_dvd_left (dvd_mul_of_dvd_left (dvd_pow_self 2 (by have hk := c.hk; omega : c.k ≠ 0)) _) _
    · intro p hp; split_ifs <;> positivity
  simp_all
  rw [Finset.prod_image] at h_prod_ratio_terms <;> norm_num [Finset.prod_range_succ] at *
  · simpa only [mul_assoc] using mul_le_mul_of_nonneg_left h_prod_ratio_terms <|
      show 0 ≤ σnorm c.L' by exact div_nonneg (Nat.cast_nonneg _) <| Nat.cast_nonneg _
  · simp [c.hp_mono.injective]





theorem criterion_surplus (c : PowerCriterion) (kExtra : ℕ) (hdiv : 2 ^ kExtra ∣ c.m) {t : ℝ} (ht : 0 ≤ t)
    (h : (1 + t) * ∏ i, (1 + (1 : ℝ) / c.q i) ≤
      (∏ i, (1 + 1 / (c.p i * (c.p i + 1) : ℝ))) *
      (1 + (1 - (1 / 2 : ℝ) ^ (kExtra + c.k)) / (2 * c.n)) *
      (1 - 2^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ))) :
    (1 + t) * (σ (L c.n) : ℝ) < σ c.M := by
  have hMpos : (0 : ℝ) < c.M := by exact_mod_cast c.M_pos
  have hLpos : (0 : ℝ) < L c.n := by exact_mod_cast c.L_pos
  have hqpos : (0 : ℝ) < ∏ i, (c.q i : ℝ) := prod_pos fun i _ => by exact_mod_cast (c.hq i).pos
  have hRpos : (0 : ℝ) < 1 - 2^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ) := by
    rw [sub_pos, div_lt_one hqpos]
    exact_mod_cast c.prod_p_le_prod_q
  have hRlt : 1 - 2^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ) < (c.M : ℝ) / L c.n := by
    have hh := c.Ln_div_M_lt
    push_cast at hh
    rw [lt_inv_comm₀ (div_pos hLpos hMpos) hRpos, inv_div] at hh
    exact_mod_cast hh
  have hsigpos : 0 < σnorm (L c.n) := by
    rw [σnorm]; exact div_pos (by exact_mod_cast (show 0 < σ (L c.n) by
      rw [σ, ArithmeticFunction.sigma_pos_iff]; exact c.L_pos)) hLpos
  have hsig'pos : 0 ≤ σnorm c.L' := by unfold σnorm; positivity
  have hsig : (1 + t) * σnorm (L c.n) ≤ σnorm c.M *
      (1 - 2^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ)) := by
    rw [c.σnorm_ln_eq]
    nlinarith [mul_le_mul_of_nonneg_left h hsig'pos,
      mul_le_mul_of_nonneg_right (sigma_boost c kExtra hdiv) hRpos.le]
  have hsigMpos : 0 < σnorm c.M := by
    have : 0 < (1 + t) * σnorm (L c.n) := mul_pos (by linarith) hsigpos
    have : 0 < σnorm c.M * (1 - 2^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ)) := this.trans_le hsig
    exact (mul_pos_iff_of_pos_right hRpos).mp this
  have hfinal : (1 + t) * σnorm (L c.n) < σnorm c.M * ((c.M : ℝ) / L c.n) :=
    hsig.trans_lt (mul_lt_mul_of_pos_left hRlt hsigMpos)
  dsimp [σnorm] at hfinal
  have hid : (σ c.M : ℝ) / c.M * ((c.M : ℝ) / L c.n) = σ c.M / L c.n := by field_simp
  rw [hid] at hfinal
  exact (div_lt_div_iff_of_pos_right hLpos).mp (by simpa [mul_div_assoc] using hfinal)



/-- Criterion using the exact rounding quotient, rather than its worst-case loss. -/
theorem criterion_surplus_exact (c : PowerCriterion) (kExtra : ℕ)
    (hdiv : 2 ^ kExtra ∣ c.m) {t : ℝ} (ht : 0 ≤ t)
    (h : (1 + t) * ∏ i, (1 + (1 : ℝ) / c.q i) <
      (∏ i, (1 + 1 / (c.p i * (c.p i + 1) : ℝ))) *
      (1 + (1 - (1 / 2 : ℝ) ^ (kExtra + c.k)) / (2 * c.n)) *
      ((2^c.k * ∏ i, (c.p i : ℝ)) * c.m / ∏ i, (c.q i : ℝ))) :
    (1 + t) * (σ (L c.n) : ℝ) < σ c.M := by
  have hMpos : (0 : ℝ) < c.M := by exact_mod_cast c.M_pos
  have hLpos : (0 : ℝ) < L c.n := by exact_mod_cast c.L_pos
  have hL'pos : (0 : ℝ) < c.L' := by exact_mod_cast c.L'_pos
  have hsig'pos : 0 < σnorm c.L' := by
    unfold σnorm
    exact div_pos (by exact_mod_cast (show 0 < σ c.L' by
      rw [σ, ArithmeticFunction.sigma_pos_iff]; exact c.L'_pos)) hL'pos
  have hid : (c.M : ℝ) / L c.n =
      (2^c.k * ∏ i, (c.p i : ℝ)) * c.m / ∏ i, (c.q i : ℝ) := by
    rw [c.L_eq_prod_q_mul_L']
    simp only [PowerCriterion.M, Nat.cast_mul, Finset.prod_natCast]
    field_simp <;> norm_num <;> ring
  have hrpos : 0 ≤ (2^c.k * ∏ i, (c.p i : ℝ)) * c.m / ∏ i, (c.q i : ℝ) := by positivity
  have hfin : (1 + t) * σnorm (L c.n) < σnorm c.M * ((c.M : ℝ) / L c.n) := by
    rw [c.σnorm_ln_eq, hid]
    have hh := mul_lt_mul_of_pos_left h hsig'pos
    have hb := mul_le_mul_of_nonneg_right (sigma_boost c kExtra hdiv) hrpos
    nlinarith
  dsimp [σnorm] at hfin
  have hid2 : (σ c.M : ℝ) / c.M * ((c.M : ℝ) / L c.n) = σ c.M / L c.n := by field_simp
  rw [hid2] at hfin
  exact (div_lt_div_iff_of_pos_right hLpos).mp (by simpa [mul_div_assoc] using hfin)

end E1TwoTracks.TrackNPowerMath
