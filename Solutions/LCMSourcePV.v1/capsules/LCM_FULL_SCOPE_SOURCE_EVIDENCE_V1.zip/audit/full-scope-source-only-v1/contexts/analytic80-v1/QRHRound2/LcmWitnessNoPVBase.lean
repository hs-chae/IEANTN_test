/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Terence Tao, OpenAI (Codex)

This file adapts the frozen `E1TwoTracks.TrackNPowerBase` development. Its retained
LCM/divisibility prefix descends from `Solutions/Lcm.v1/LcmDev.lean` and
`PrimeNumberTheoremAnd/IEANTN/Lcm.lean` in
https://github.com/AlexKontorovich/PrimeNumberTheoremAnd at commit
 ae881f2e2b3acefc9b92f8d4dda7c2b8f6e8f5fe, under Apache 2.0.

The declarations here include a new two-prime-power construction. `PowerCriterion`
uses the variable core `6^k`, the explicit prime condition `3 < p 0`, and the
product-size hypothesis `6^k * product(p) < product(q)`. The witness, quotient and
remainder constructions, factorization and divisibility arguments are adapted to
that core; the 3-adic LCM valuation is added alongside the retained 2-adic argument.
The original published LCM criterion has a fixed core and its sufficient product
inequality. It does not assert this new parameterized criterion or the new
quantitative margin; those are proved in this module and LcmWitnessNoPVMath.
-/
import Mathlib.NumberTheory.Chebyshev
import Mathlib.Analysis.Complex.ExponentialBounds
import IEANTN.Nodes.Lcm.v2.Conclusions

/-! The 6^k witness construction and its LCM/divisibility facts.
No finite numerical output or QRH premise is introduced. -/
namespace QRHRound2.LcmWitnessNoPVBase

open ArithmeticFunction hiding log
open Finset Nat Real



def σ : ArithmeticFunction ℕ := sigma 1

noncomputable abbrev σnorm (n : ℕ) : ℝ := (σ n : ℝ) / (n : ℝ)

def HighlyAbundant (N : ℕ) : Prop :=
  ∀ m : ℕ, m < N → σ m < σ N


def L (n : ℕ) : ℕ := (Finset.Icc 1 n).lcm _root_.id





structure PowerCriterion where
  k : ℕ
  hk : 1 ≤ k
  n : ℕ
  hn : n ≥ 1
  p : Fin 3 → ℕ
  hp : ∀ i, Nat.Prime (p i)
  hp_mono : StrictMono p
  hthree : 3 < p 0
  q : Fin 3 → ℕ
  hq : ∀ i, Nat.Prime (q i)
  hq_mono : StrictMono q
  h_ord_1 : √(n : ℝ) < p 0
  h_ord_2 : p 2 < q 0
  h_ord_3 : q 2 < n
  h_product : 6^k * ∏ i, p i < ∏ i, q i

/-- The raw witness construction needs only room to form its positive quotient.
The final sigma inequality is supplied separately by the consumer. -/
theorem PowerCriterion.prod_p_le_prod_q (c : PowerCriterion) : 6^c.k * ∏ i, c.p i < ∏ i, c.q i :=
  c.h_product

lemma PowerCriterion.p_gt_two (c : PowerCriterion) (i : Fin 3) : 2 < c.p i := by
  have h_pi_gt_two : ∀ i, 1 < c.p i := fun i ↦ Nat.Prime.one_lt (c.hp i)
  by_contra h_contra
  interval_cases _ : c.p i; iterate 2 grind
  · have := c.h_ord_1; have := c.h_ord_2; have := c.h_ord_3; fin_cases i
    · simp_all only [Fin.isValue, Fin.zero_eta, cast_ofNat]
      rw [Real.sqrt_lt] at * <;> norm_cast at * <;>
      linarith [h_pi_gt_two 0, h_pi_gt_two 1, h_pi_gt_two 2, c.hp_mono (show 0 < 1 by decide),
        c.hp_mono (show 1 < 2 by decide), c.hq_mono (show 0 < 1 by decide),
        c.hq_mono (show 1 < 2 by decide)]
    · grind [c.hp_mono (show 0 < 1 by decide) , c.hp_mono (show 1 < 2 by decide)]
    · grind [h_pi_gt_two 0, h_pi_gt_two 1, h_pi_gt_two 2, c.hp_mono (show 0 < 1 by decide),
        c.hp_mono (show 1 < 2 by decide)]

lemma PowerCriterion.q_gt_two (c : PowerCriterion) (i : Fin 3) : 2 < c.q i := by
  have h_q_gt_two : ∀ i, 2 < c.q i := fun i ↦ by
    have h_q_gt_p : ∀ i, c.p 2 < c.q i := fun i ↦ by
      fin_cases i <;> linarith! [c.hp_mono <| show 0 < 1 by decide, c.hp_mono <|
        show 1 < 2 by decide, c.hq_mono <| show 0 < 1 by decide, c.hq_mono <|
        show 1 < 2 by decide, c.h_ord_2, c.h_ord_3]
    grind [c.p_gt_two 2]
  exact h_q_gt_two i


lemma PowerCriterion.p_gt_three (c : PowerCriterion) (i : Fin 3) : 3 < c.p i :=
  c.hthree.trans_le (c.hp_mono.monotone (Fin.zero_le i))

lemma PowerCriterion.q_gt_three (c : PowerCriterion) (i : Fin 3) : 3 < c.q i :=
  (c.p_gt_three 2).trans (c.h_ord_2.trans_le (c.hq_mono.monotone (Fin.zero_le i)))

noncomputable def PowerCriterion.L' (c : PowerCriterion) : ℕ := L c.n / ∏ i, c.q i

lemma PowerCriterion.prod_q_dvd_L (c : PowerCriterion) : ∏ i, c.q i ∣ L c.n :=
  Fintype.prod_dvd_of_isRelPrime (fun i j h ↦ coprime_iff_isRelPrime.mp <|
    (coprime_primes (c.hq i) (c.hq j)).mpr (c.hq_mono.injective.ne h)) fun i ↦ dvd_lcm <|
      mem_Icc.mpr ⟨(c.hq i).one_le, (c.hq_mono.monotone (Fin.le_last i)).trans c.h_ord_3.le⟩

lemma PowerCriterion.L_pos (c : PowerCriterion) : 0 < L c.n :=
  lt_of_lt_of_le Nat.zero_lt_one <| one_le_iff_ne_zero.mpr fun h ↦ by simp_all [L]

lemma PowerCriterion.L'_pos (c : PowerCriterion) : 0 < c.L' :=
  div_pos (le_of_dvd c.L_pos c.prod_q_dvd_L) (prod_pos fun i _ ↦ (c.hq i).pos)

lemma PowerCriterion.L_eq_prod_q_mul_L' (c : PowerCriterion) : L c.n = (∏ i, c.q i) * c.L' := by
  rw [L', Nat.mul_div_cancel' c.prod_q_dvd_L]

lemma PowerCriterion.val_two_L' (c : PowerCriterion) : (c.L').factorization 2 = Nat.log 2 c.n := by
  have h_lcm : ∀ n : ℕ, n ≥ 1 → Nat.factorization (L n) 2 = Nat.log 2 n := by
    have h_lcm_exp : ∀ n : ℕ, n ≥ 1 → (Nat.factorization (Finset.lcm (Finset.Icc 1 n)
        (fun x ↦ x)) 2) = Finset.sup (Finset.Icc 1 n) (fun x ↦ Nat.factorization x 2) := by
      intros n hn
      have h_lcm_exp : ∀ {S : Finset ℕ}, (∀ x ∈ S, x ≠ 0) → (Nat.factorization (Finset.lcm S
          (fun x ↦ x)) 2) = Finset.sup S (fun x ↦ Nat.factorization x 2) := by
        intro S hS
        induction S using Finset.induction with
        | empty => simp
        | insert x S hxS ih =>
            simp_all only [lcm_insert]
            erw [Nat.factorization_lcm] <;> simp_all
      exact h_lcm_exp fun x hx ↦ by linarith [Finset.mem_Icc.mp hx]
    have h_sup : ∀ n : ℕ, n ≥ 1 → Finset.sup (Finset.Icc 1 n) (fun x ↦ Nat.factorization x 2) =
       Nat.log 2 n := fun n hn ↦ by
      apply le_antisymm
      · exact Finset.sup_le fun x hx ↦ Nat.le_log_of_pow_le (by decide) <|
          Nat.le_trans (Nat.le_of_dvd (by linarith [Finset.mem_Icc.mp hx])
          <| Nat.ordProj_dvd _ _) <| by linarith [Finset.mem_Icc.mp hx]
      · refine le_trans ?_ (Finset.le_sup <| Finset.mem_Icc.mpr ⟨Nat.one_le_pow _ _ zero_lt_two,
          Nat.pow_log_le_self 2 <| by linarith⟩)
        norm_num [Nat.Prime.factorization_self (prime_two)]
    aesop
  rw [show c.L' = L c.n / (∏ i, c.q i) by rfl, Nat.factorization_div] <;> norm_num [h_lcm, c.hn]
  · rw [Nat.factorization_eq_zero_of_not_dvd] <;> norm_num [Fin.prod_univ_three]
    norm_num [Nat.mul_mod, Nat.mod_mod, Nat.odd_iff.mp (Nat.Prime.odd_of_ne_two (c.hq 0)
      (by linarith [c.p_gt_two 0, c.q_gt_two 0])), Nat.odd_iff.mp (Nat.Prime.odd_of_ne_two (c.hq 1)
      (by linarith [c.p_gt_two 1, c.q_gt_two 1])), Nat.odd_iff.mp (Nat.Prime.odd_of_ne_two (c.hq 2)
      (by linarith [c.p_gt_two 2, c.q_gt_two 2]))]
  · exact prod_q_dvd_L c

lemma PowerCriterion.val_three_L' (c : PowerCriterion) : c.L'.factorization 3 = Nat.log 3 c.n := by
  have hL : (L c.n).factorization 3 = Nat.log 3 c.n := by
    simpa only [L, Nat.lcmUpto] using Nat.factorization_lcmUpto c.n Nat.prime_three
  have hnot : ¬3 ∣ ∏ i, c.q i := by
    intro hd
    obtain ⟨i, _, hi⟩ := Nat.prime_three.prime.exists_mem_finset_dvd hd
    have he : 3 = c.q i := (Nat.prime_dvd_prime_iff_eq Nat.prime_three (c.hq i)).mp hi
    linarith [c.q_gt_three i]
  rw [PowerCriterion.L', Nat.factorization_div]
  · simp only [Finsupp.tsub_apply, hL, Nat.factorization_eq_zero_of_not_dvd hnot, Nat.sub_zero]
  · exact c.prod_q_dvd_L

lemma PowerCriterion.val_p_L' (c : PowerCriterion) (i : Fin 3) : (c.L').factorization (c.p i) = 1 := by
  have h_pi_factor : Nat.factorization (L c.n) (c.p i) = 1 := by
    have h_prime_factor : ∀ {p : ℕ}, Nat.Prime p → Real.sqrt c.n < p → p < c.n →
        (Nat.factorization (L c.n)) p = 1 := @fun p hp hp_sqrt hp_lt_n ↦ by
      have h_prime_factor : (Nat.factorization (L c.n)) p = 1 := by
        have h_prime_factor_def : (Nat.factorization (L c.n)) p = Finset.sup (Finset.Icc 1 c.n)
            (fun i ↦ Nat.factorization i p) := by
          have h_prime_factor_def : (Nat.factorization (Finset.lcm (Finset.Icc 1 c.n) (fun i ↦ i)))
              p = Finset.sup (Finset.Icc 1 c.n) (fun i ↦ Nat.factorization i p) := by
            have h_lcm_factorization : ∀ {S : Finset ℕ}, (∀ i ∈ S, i ≠ 0) →
                (Nat.factorization (Finset.lcm S (fun i ↦ i))) p =
                Finset.sup S (fun i ↦ Nat.factorization i p) := by
              intros S hS_nonzero
              induction S using Finset.induction with
              | empty => simp [Finset.lcm]
              | insert i S hiS ih =>
                  by_cases hi : i = 0
                  · simp_all
                  simp only [lcm_insert]
                  erw [Nat.factorization_lcm] <;> simp_all
            exact h_lcm_factorization fun i hi ↦ by linarith [Finset.mem_Icc.mp hi]
          exact h_prime_factor_def
        have h_prime_power : ∀ i ∈ Finset.Icc 1 c.n, Nat.factorization i p ≤ 1 := fun i hi ↦ by
          have h_prime_power : p^2 > c.n := by
            rw [Real.sqrt_lt] at hp_sqrt <;> norm_cast at * <;> nlinarith only [hp_sqrt, hp_lt_n]
          exact le_of_not_gt fun h ↦ absurd (Nat.dvd_trans (pow_dvd_pow p h) (Nat.ordProj_dvd i p))
            (Nat.not_dvd_of_pos_of_lt (Finset.mem_Icc.mp hi |>.1)
            (by nlinarith [Finset.mem_Icc.mp hi |>.2]))
        refine h_prime_factor_def.trans (le_antisymm (Finset.sup_le h_prime_power) ?_)
        exact le_trans (by norm_num [hp]) (Finset.le_sup (f := fun i ↦ Nat.factorization i p)
          (Finset.mem_Icc.mpr ⟨hp.pos, hp_lt_n.le⟩))
      exact (Nat.add_right_cancel (congrFun (congrArg HAdd.hAdd ((h_prime_factor.symm))) p)).symm
    apply h_prime_factor (c.hp i) (c.h_ord_1.trans_le (by
      exact_mod_cast c.hp_mono.monotone (Nat.zero_le _))) (by
        have := c.h_ord_2; have := c.h_ord_3; fin_cases i <;> linarith! [c.hp_mono <|
          show 0 < 1 by decide, c.hp_mono <| show 1 < 2 by decide, c.hq_mono <|
          show 0 < 1 by decide, c.hq_mono <| show 1 < 2 by decide])
  have h_pi_factor_L' : Nat.factorization (L c.n) (c.p i) = Nat.factorization (c.L')
      (c.p i) + Nat.factorization (∏ i, c.q i) (c.p i) := by
    have h_pi_factor_L' : Nat.factorization (L c.n) = Nat.factorization (c.L') +
        Nat.factorization (∏ i, c.q i) := by
      rw [← Nat.factorization_mul] <;> norm_num [c.L'_pos.ne']
      · rw [mul_comm, PowerCriterion.L_eq_prod_q_mul_L']
      · exact Finset.prod_ne_zero_iff.mpr fun i _ ↦ Nat.Prime.ne_zero (c.hq i)
    aesop
  have h_pi_not_div_q : ∀ j, ¬(c.p i ∣ c.q j) := by
    intro j hj; have := c.hq j; have := c.hp i; simp_all only [Nat.prime_dvd_prime_iff_eq]
    have := c.h_ord_2; have := c.h_ord_3; fin_cases i <;> fin_cases j <;> linarith! [c.hp_mono <|
      show 0 < 1 by decide, c.hp_mono <| show 1 < 2 by decide, c.hq_mono <|
      show 0 < 1 by decide, c.hq_mono <| show 1 < 2 by decide]
  simp_all [Fin.prod_univ_three,Nat.factorization_mul,Nat.Prime.ne_zero (c.hq _),
    Nat.factorization_eq_zero_of_not_dvd (h_pi_not_div_q _)]

theorem PowerCriterion.ln_eq (c : PowerCriterion) : L c.n = c.q 0 * c.q 1 * c.q 2 * c.L' := by
  rw [L', ← Fin.prod_univ_three, Nat.mul_div_cancel' <| Fintype.prod_dvd_of_isRelPrime ?_ ?_]
  · refine fun i j h ↦ Nat.coprime_iff_isRelPrime.mp ?_
    exact Nat.coprime_primes (c.hq i) (c.hq j) |>.mpr <| c.hq_mono.injective.ne h
  refine fun i ↦
    Finset.dvd_lcm <| Finset.mem_Icc.mpr ⟨c.hq i |>.one_le, le_trans ?_ c.h_ord_3.le⟩
  exact c.hq_mono.monotone <| Fin.le_last i

theorem PowerCriterion.q_not_dvd_L' (c : PowerCriterion) : ∀ i, ¬(c.q i ∣ c.L') := by
  intro i hqi
  have hn_lt_q_sq := Real.lt_sq_of_sqrt_lt <| c.h_ord_1.trans_le <| cast_le.mpr <|
    show c.p 0 ≤ c.q i by
      grw [c.hp_mono.monotone <| Fin.zero_le 2, c.h_ord_2, c.hq_mono.monotone <| Fin.zero_le i]
  norm_cast at hn_lt_q_sq
  suffices ¬(c.q i) ^ 2 ∣ L c.n from this <| Nat.pow_two _ ▸ by
    refine mul_dvd_mul_right (Finset.dvd_prod_of_mem c.q <| Finset.mem_univ i) _ |>.trans ?_
    exact Fin.prod_univ_three c.q ▸ c.ln_eq ▸ mul_dvd_mul_left _ hqi

  set p : ℕ := c.q i
  have hp : Nat.Prime p := c.hq i

  -- 1) prime power divides binary lcm iff divides one side
  have pow_dvd_lcm_iff (a b k : ℕ) (ha : a ≠ 0) (hb : b ≠ 0) :
      p ^ k ∣ Nat.lcm a b ↔ (p ^ k ∣ a ∨ p ^ k ∣ b) := by
    refine ⟨?_, by grind [dvd_trans, Nat.dvd_lcm_left, Nat.dvd_lcm_right]⟩
    grind [Prime.pow_dvd_iff_le_factorization, lcm_ne_zero, Nat.factorization_lcm, Finsupp.sup_apply]

  -- 2) prime power divides finset-lcm -> appears in some member
  have exists_mem_of_pow_dvd_finset_lcm (s : Finset ℕ) (hs_nz : ∀ x ∈ s, x ≠ 0) (k)
      (hk : 0 < k) (h : p ^ k ∣ s.lcm _root_.id) : ∃ m ∈ s, p ^ k ∣ m := by
    induction s using Finset.induction with
    | empty =>
      have := one_lt_pow hk.ne' hp.one_lt |>.trans_le <| le_of_dvd zero_lt_one h
      contradiction
    | insert a s ha ih =>
      have ha0 := hs_nz _ <| mem_insert_self a s
      have hs_nz' := (hs_nz · <| mem_insert_of_mem ·)
      have hs0 := lcm_ne_zero_iff.mpr hs_nz'
      have := (pow_dvd_lcm_iff _ _ k ha0 hs0).1 <| by simpa using! h
      rcases this with hpa | hps
      · exact ⟨a, mem_insert_self a s, hpa⟩
      · have ⟨m, hmS, hpm⟩ := ih hs_nz' hps
        exact ⟨m, mem_insert_of_mem hmS, hpm⟩

  intro hq2
  have ⟨m, hmIcc, hpm⟩ := exists_mem_of_pow_dvd_finset_lcm _ (by grind) 2 zero_lt_two hq2
  refine not_lt_of_ge ?_ hn_lt_q_sq
  refine le_trans (le_of_dvd ?_ hpm) (Finset.mem_Icc.mp hmIcc).2
  exact succ_le_iff.mp (Finset.mem_Icc.mp hmIcc).1

theorem PowerCriterion.σnorm_ln_eq (c : PowerCriterion) :
    σnorm (L c.n) = σnorm c.L' * ∏ i, (1 + (1 : ℝ) / c.q i) := by
  have hcop : ∀ i j, i ≠ j → (c.q i).Coprime (c.q j) := fun i j h ↦
    (coprime_primes (c.hq i) (c.hq j)).mpr (c.hq_mono.injective.ne h)
  have hcopL' : ∀ i, (c.q i).Coprime c.L' := fun i ↦
    (c.hq i).coprime_iff_not_dvd.mpr (c.q_not_dvd_L' i)
  have hσ_prime : ∀ i, sigma 1 (c.q i) = 1 + c.q i := fun i ↦ by
    rw [← pow_one (c.q i), sigma_one_apply_prime_pow (c.hq i)]
    simp [reduceAdd, geom_sum_two, pow_one, add_comm]
  simp only [σnorm, σ, c.L_eq_prod_q_mul_L', Fin.prod_univ_three]
  rw [show c.q 0 * c.q 1 * c.q 2 * c.L' = (c.q 0 * c.q 1 * c.q 2) * c.L' by ring,
      isMultiplicative_sigma.map_mul_of_coprime (coprime_mul_iff_left.mpr
        ⟨coprime_mul_iff_left.mpr ⟨hcopL' 0, hcopL' 1⟩, hcopL' 2⟩),
      show c.q 0 * c.q 1 * c.q 2 = c.q 0 * (c.q 1 * c.q 2) by ring,
      isMultiplicative_sigma.map_mul_of_coprime (coprime_mul_iff_right.mpr
        ⟨hcop 0 1 Fin.zero_ne_one, hcop 0 2 <| not_eq_of_beq_eq_false rfl⟩),
      isMultiplicative_sigma.map_mul_of_coprime (hcop 1 2 <| not_eq_of_beq_eq_false rfl),
      hσ_prime, hσ_prime, hσ_prime]
  have hq_ne : ∀ i, (c.q i : ℝ) ≠ 0 := fun i ↦ (cast_pos.mpr (c.hq i).pos).ne'
  field_simp [hq_ne, (cast_pos.mpr c.L'_pos).ne']
  grind

def PowerCriterion.m (c : PowerCriterion) : ℕ := (∏ i, c.q i) / (6^c.k * ∏ i, c.p i)

def PowerCriterion.r (c : PowerCriterion) : ℕ := (∏ i, c.q i) % (6^c.k * ∏ i, c.p i)

theorem PowerCriterion.r_ge (c : PowerCriterion) : 0 < c.r := by
  simp only [r, Nat.pos_iff_ne_zero, ne_eq]
  intro h
  have h_dvd : c.p 2 ∣ ∏ i, c.q i :=
    (Finset.dvd_prod_of_mem _ (Finset.mem_univ 2)).trans <|
      (Nat.dvd_mul_left _ (6^c.k)).trans (Nat.dvd_of_mod_eq_zero h)
  obtain ⟨i, _, hi⟩ := (c.hp 2).prime.exists_mem_finset_dvd h_dvd
  have : c.p 2 = c.q i := ((c.hq i).dvd_iff_eq (c.hp 2).ne_one).mp hi |>.symm
  exact absurd this (c.h_ord_2.trans_le (c.hq_mono.monotone (zero_le i))).ne

theorem PowerCriterion.r_le (c : PowerCriterion) : c.r < 6^c.k * ∏ i, c.p i :=
  mod_lt _ <| mul_pos (pow_pos (by norm_num) c.k) <| Finset.prod_pos <| fun i _ ↦ Prime.pos (c.hp i)

theorem PowerCriterion.prod_q_eq (c : PowerCriterion) : ∏ i, c.q i = (6^c.k * ∏ i, c.p i) * c.m + c.r := by
  simp only [m, r, Nat.div_add_mod]

noncomputable def PowerCriterion.M (c : PowerCriterion) : ℕ := (6^c.k * ∏ i, c.p i) * c.m * c.L'

lemma PowerCriterion.m_pos (c : PowerCriterion) : 0 < c.m :=
  Nat.div_pos c.prod_p_le_prod_q.le (mul_pos (pow_pos (by norm_num) c.k) (prod_pos fun i _ ↦ (c.hp i).pos))

lemma PowerCriterion.M_pos (c : PowerCriterion) : 0 < c.M :=
  mul_pos (mul_pos (mul_pos (pow_pos (by norm_num) c.k) (prod_pos fun i _ ↦ (c.hp i).pos)) c.m_pos) c.L'_pos

lemma PowerCriterion.val_p_M_ge_two (c : PowerCriterion) (i : Fin 3) :
    2 ≤ c.M.factorization (c.p i) := by
  have hP : 0 < ∏ i, c.p i := prod_pos fun i _ => (c.hp i).pos
  have ha : 6^c.k * ∏ i, c.p i ≠ 0 := by positivity
  have hm : c.m ≠ 0 := c.m_pos.ne'
  have hl : c.L' ≠ 0 := c.L'_pos.ne'
  have hd : (c.p i)^1 ∣ 6^c.k * ∏ i, c.p i := by
    simpa using dvd_mul_of_dvd_right (Finset.dvd_prod_of_mem _ (Finset.mem_univ i)) (6^c.k)
  have hf : 1 ≤ (6^c.k * ∏ i, c.p i).factorization (c.p i) :=
    ((c.hp i).pow_dvd_iff_le_factorization ha).mp hd
  change 2 ≤ ((6^c.k * ∏ i, c.p i) * c.m * c.L').factorization (c.p i)
  rw [Nat.factorization_mul (mul_ne_zero ha hm) hl, Nat.factorization_mul ha hm]
  simp only [Finsupp.add_apply]
  rw [c.val_p_L' i]
  omega

theorem PowerCriterion.M_lt (c : PowerCriterion) : c.M < L c.n := by
  calc c.M < ((6^c.k * ∏ i, c.p i) * c.m + c.r) * c.L' :=
        mul_lt_mul_of_pos_right (Nat.lt_add_of_pos_right c.r_ge) c.L'_pos
    _ = (∏ i, c.q i) * c.L' := by rw [← c.prod_q_eq]
    _ = L c.n := c.L_eq_prod_q_mul_L'.symm

theorem PowerCriterion.Ln_div_M_gt (c : PowerCriterion) : (1 : ℝ) < L c.n / c.M := by
  rw [one_lt_div (cast_pos.mpr c.M_pos)]
  exact_mod_cast c.M_lt

theorem PowerCriterion.Ln_div_M_lt (c : PowerCriterion) :
    L c.n / c.M < (1 - ((6 : ℝ)^c.k) * (∏ i, c.p i) / (∏ i, c.q i))⁻¹ := by
  have hprod_q_pos_R : (0 : ℝ) < (∏ i, c.q i) :=
    cast_pos.mpr <| prod_pos fun i _ ↦ (c.hq i).pos
  have hLM_eq :
      (L c.n : ℝ) / c.M = ((∏ i, c.q i) : ℝ) / (((6^c.k * ∏ i, c.p i) * c.m) : ℕ) := by
    simp only [c.L_eq_prod_q_mul_L', M, cast_mul]
    have hL'_ne : (c.L' : ℝ) ≠ 0 := cast_ne_zero.mpr c.L'_pos.ne'
    field_simp
    congr 1
    exact prod_natCast univ c.q
  have hLM_eq' : (L c.n : ℝ) / c.M = (1 - (c.r : ℝ) / (∏ i, c.q i))⁻¹ := by
    have hprod_q_eq_R : ((∏ i, c.q i) : ℝ) = ((6^c.k * ∏ i, c.p i) * c.m : ℕ) + c.r := by
      exact_mod_cast c.prod_q_eq
    have h4pm_pos : 0 < (6^c.k * ∏ i, c.p i) * c.m := mul_pos
      (mul_pos (by norm_num) <| prod_pos fun i _ ↦ (c.hp i).pos) c.m_pos
    rw [hLM_eq, hprod_q_eq_R]
    have hne : (((6^c.k * ∏ i, c.p i) * c.m : ℕ) : ℝ) ≠ 0 := cast_ne_zero.mpr h4pm_pos.ne'
    have hsum_pos : (0 : ℝ) < ((6^c.k * ∏ i, c.p i) * c.m : ℕ) + c.r := by positivity
    field_simp
    simp_all
  have h1_sub_pos : (0 : ℝ) < 1 - ((6 : ℝ)^c.k) * (∏ i, c.p i) / (∏ i, c.q i) := by
    rw [sub_pos, div_lt_one hprod_q_pos_R]; exact_mod_cast c.prod_p_le_prod_q
  have hsub_lt : 1 - ((6 : ℝ)^c.k) * (∏ i, c.p i) / (∏ i, c.q i) <
      1 - (c.r : ℝ) / (∏ i, c.q i) := by gcongr; exact_mod_cast c.r_le
  rw [hLM_eq']
  have hinv := one_div_lt_one_div_of_lt h1_sub_pos hsub_lt
  simp only [one_div] at hinv
  convert hinv using 2



end QRHRound2.LcmWitnessNoPVBase
