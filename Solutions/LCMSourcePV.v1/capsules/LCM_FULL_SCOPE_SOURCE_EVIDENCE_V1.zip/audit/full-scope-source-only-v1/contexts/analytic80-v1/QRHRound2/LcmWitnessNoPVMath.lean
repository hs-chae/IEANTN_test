/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Terence Tao, OpenAI (Codex)
-/
import QRHRound2.LcmWitnessNoPVBase
import E1TwoTracks.TrackNPowerMath
/-! New 2-adic plus 3-adic normalized-sigma boost for the 6^k construction.
The 2-adic geometric-series bound is reused from E1TwoTracks.TrackNPowerMath.
The 3-adic ratio, combined Euler product and resulting surplus transfer are proved
here for the new PowerCriterion in LcmWitnessNoPVBase. -/
namespace QRHRound2.LcmWitnessNoPVMath
open ArithmeticFunction hiding log
open Finset Nat Real
open QRHRound2.LcmWitnessNoPVBase
set_option maxHeartbeats 6000000

lemma val_core (c : PowerCriterion) {b : ℕ} (hb : b.Prime) (hd : b ∣ 6) :
    c.L'.factorization b + c.k ≤ c.M.factorization b := by
  have hP : 0 < ∏ i, c.p i := prod_pos fun i _ => (c.hp i).pos
  have ha : 6^c.k * ∏ i, c.p i ≠ 0 := by positivity
  have hm : c.m ≠ 0 := c.m_pos.ne'
  have hl : c.L' ≠ 0 := c.L'_pos.ne'
  have hpow : b^c.k ∣ 6^c.k * ∏ i, c.p i :=
    dvd_mul_of_dvd_left (pow_dvd_pow_of_dvd hd c.k) _
  have hf : c.k ≤ (6^c.k * ∏ i, c.p i).factorization b :=
    (hb.pow_dvd_iff_le_factorization ha).mp hpow
  change c.L'.factorization b + c.k ≤ ((6^c.k * ∏ i, c.p i) * c.m * c.L').factorization b
  rw [Nat.factorization_mul (mul_ne_zero ha hm) hl, Nat.factorization_mul ha hm]
  simp only [Finsupp.add_apply]
  omega

lemma ratio_three {k : ℕ} (n j : ℕ) (hk : 3 ^ k ≤ n) :
    (∑ i ∈ Finset.range (k + j + 1), (1 / 3 : ℝ) ^ i) /
      (∑ i ∈ Finset.range (k + 1), (1 / 3 : ℝ) ^ i) ≥
      1 + (1 - (1 / 3 : ℝ) ^ j) / (3 * n) := by
  have hu : 0 < (1 / 3 : ℝ) ^ k := by positivity
  have hu1 : (1 / 3 : ℝ) ^ k ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hv : 0 ≤ 1 - (1 / 3 : ℝ) ^ j := sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))
  have hn : (0 : ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by positivity : 0 < 3 ^ k) hk)
  have hinv : (n : ℝ)⁻¹ ≤ (1 / 3 : ℝ) ^ k := by
    simpa using inv_anti₀ (by positivity) (mod_cast hk)
  have hs1 : (∑ i ∈ Finset.range (k + j + 1), (1 / 3 : ℝ) ^ i) =
      3/2 - (1/2 : ℝ) * (1 / 3 : ℝ)^k * (1 / 3 : ℝ)^j := by
    norm_num [geom_sum_eq, pow_add]; ring
  have hs2 : (∑ i ∈ Finset.range (k + 1), (1 / 3 : ℝ) ^ i) =
      3/2 - (1/2 : ℝ) * (1 / 3 : ℝ)^k := by
    norm_num [geom_sum_eq, pow_add]; ring
  rw [hs1, hs2, ge_iff_le, le_div_iff₀ (by linarith : 0 < 3/2 - (1/2 : ℝ) * (1 / 3 : ℝ)^k)]
  have hterm : (1 - (1 / 3 : ℝ)^j) / (3 * n) ≤
      (1 - (1 / 3 : ℝ)^j) * (1 / 3 : ℝ)^k / 3 := by
    simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm] using
      mul_le_mul_of_nonneg_left hinv (div_nonneg hv (by norm_num : (0 : ℝ) ≤ 3))
  have hnon : 0 ≤ (1 - (1 / 3 : ℝ)^j) / (3 * n) := by positivity
  nlinarith

noncomputable def core2 (c : PowerCriterion) : ℝ := 1 + (1 - (1/2:ℝ)^c.k)/(2*c.n)
noncomputable def core3 (c : PowerCriterion) : ℝ := 1 + (1 - (1/3:ℝ)^c.k)/(3*c.n)

lemma core2_pos (c : PowerCriterion) : 0 < core2 c := by
  have hh : 0 ≤ 1 - (1/2:ℝ)^c.k := sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))
  unfold core2
  positivity
lemma core3_pos (c : PowerCriterion) : 0 < core3 c := by
  have hh : 0 ≤ 1 - (1/3:ℝ)^c.k := sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))
  unfold core3
  positivity

theorem sigma_boost (c : PowerCriterion) :
    σnorm c.M ≥ σnorm c.L' * (∏ i, (1 + 1 / (c.p i * (c.p i + 1 : ℝ)))) * core2 c * core3 c := by
  have h_sigma_norm_M : (σnorm c.M) = (σnorm (c.L' : ℕ)) * (∏ p ∈ Nat.primeFactors c.M,
      ((∑ i ∈ Finset.range (Nat.factorization c.M p + 1), (1 / p : ℝ) ^ i) /
      (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i))) := by
    have h_sigma_norm_prod : ∀ {n : ℕ}, n ≠ 0 → (σnorm n : ℝ) = (∏ p ∈ Nat.primeFactors n,
        ((∑ i ∈ Finset.range (Nat.factorization n p + 1), (1 / p : ℝ) ^ i))) := by
      intro n hn_ne_zero
      have h_sigma_def : ((σ n) : ℝ) = (∏ p ∈ Nat.primeFactors n, (∑ i ∈ Finset.range
          (Nat.factorization n p + 1), (p ^ i : ℝ))) := by
        unfold σ
        have h_sigma_def : ∀ {n : ℕ}, n ≠ 0 → (Nat.divisors n).sum (fun d ↦ d) =
            ∏ p ∈ n.primeFactors, (∑ i ∈ Finset.range (Nat.factorization n p + 1), p ^ i) := by
          exact fun {n} a ↦ sum_divisors a
        convert congr_arg (( ↑ ) : ℕ → ℝ) (h_sigma_def hn_ne_zero) using 1 <;>
        norm_num [ArithmeticFunction.sigma]
      have h_sigma_def : (n : ℝ) = (∏ p ∈ Nat.primeFactors n, (p ^ (Nat.factorization n p) : ℝ)) :=
        mod_cast Eq.symm (Nat.prod_factorization_pow_eq_self hn_ne_zero)
      simp_all only [div_eq_mul_inv]
      rw [← div_eq_mul_inv, ← Finset.prod_div_distrib]
      refine Finset.prod_congr rfl fun p hp ↦ ?_
      field_simp
      rw [Finset.mul_sum _ _ _, ← Finset.sum_flip]
      exact Finset.sum_congr rfl fun i hi ↦ by
        rw [show ((1:ℝ) / ↑p) ^ i = 1 / ((↑p) ^ i) by simp]
        rw [mul_one_div, eq_div_iff (pow_ne_zero _ <| Nat.cast_ne_zero.mpr <| Nat.ne_of_gt <|
          Nat.pos_of_mem_primeFactors hp), ←pow_add, Nat.sub_add_cancel <|
          Finset.mem_range_succ_iff.mp hi]
    by_cases hM : c.M = 0 <;> by_cases hL' : c.L' = 0
    · simp_all
    · exact absurd hM (Nat.ne_of_gt (PowerCriterion.M_pos c))
    · exact absurd hL' (Nat.ne_of_gt (PowerCriterion.L'_pos c))
    · simp_all only [ne_eq, one_div, inv_pow, not_false_eq_true, prod_div_distrib]
      rw [mul_div, eq_div_iff]
      · rw [mul_comm, ← Finset.prod_subset (show c.L'.primeFactors ⊆ c.M.primeFactors from ?_)]
        · intro p hp hpn; rw [Nat.factorization_eq_zero_of_not_dvd] <;> aesop
        · intro p hp; simp_all only [mem_primeFactors, ne_eq, not_false_eq_true, and_true, true_and]
          exact dvd_trans hp.2 (by exact ⟨(6^c.k * ∏ i, c.p i) * c.m, by rw [PowerCriterion.M]; ring⟩)
      · exact Finset.prod_ne_zero_iff.mpr fun p hp ↦ ne_of_gt <| Finset.sum_pos
          (fun _ _ ↦ inv_pos.mpr <| pow_pos (Nat.cast_pos.mpr <| Nat.pos_of_mem_primeFactors hp) _)
          <| by norm_num
  have h_ratio_terms (p : ℕ) (hp : p ∈ Nat.primeFactors c.M) : (∑ i ∈ Finset.range
      (Nat.factorization c.M p + 1), (1 / p : ℝ) ^ i) / (∑ i ∈ Finset.range
      (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i) ≥ if p ∈ Finset.image c.p Finset.univ
      then (1 + 1 / (p * (p + 1) : ℝ)) else if p = 2 then core2 c else if p = 3 then core3 c else 1 := by
    split_ifs
    · obtain ⟨i, hi⟩ : ∃ i : Fin 3, p = c.p i := by grind
      have h_ratio_p_i : (∑ i ∈ Finset.range (Nat.factorization c.M p + 1), (1 / p : ℝ) ^ i) /
          (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i) ≥
          (∑ i ∈ Finset.range 3, (1 / p : ℝ) ^ i) / (∑ i ∈ Finset.range 2, (1 / p : ℝ) ^ i) := by
        rw [show Nat.factorization (c.L' : ℕ) p = 1 from hi ▸ c.val_p_L' i]
        exact div_le_div_of_nonneg_right (Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono
          (by grind [c.val_p_M_ge_two i])) fun _ _ _ ↦ by positivity)
          (Finset.sum_nonneg fun _ _ ↦ by positivity)
      convert h_ratio_p_i using 1; norm_num [Finset.sum_range_succ]; ring_nf; field_simp; grind
    · have h_geo_series : (∑ i ∈ Finset.range (Nat.factorization c.M 2 + 1), (1 / 2 : ℝ) ^ i)
          / (∑ i ∈ Finset.range (Nat.factorization c.L' 2 + 1), (1 / 2 : ℝ) ^ i) ≥
          (1 + (1 - (1 / 2 : ℝ) ^ c.k) / (2 * c.n)) := by
        have h_geo_series : (∑ i ∈ Finset.range (Nat.factorization c.M 2 + 1), (1 / 2 : ℝ) ^ i)
            / (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + 1), (1 / 2 : ℝ) ^ i) ≥
            (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + c.k + 1), (1 / 2 : ℝ) ^ i) /
            (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + 1), (1 / 2 : ℝ) ^ i) := by
          exact div_le_div_of_nonneg_right (Finset.sum_le_sum_of_subset_of_nonneg
            (Finset.range_mono (by linarith [val_core c Nat.prime_two (by decide : 2 ∣ 6)])) fun _ _ _ ↦ by positivity)
            (Finset.sum_nonneg fun _ _ ↦ by positivity)
        refine le_trans ?_ h_geo_series
        convert E1TwoTracks.TrackNPowerMath.ratio_ge_aux c.n c.k _ using 1
        exact c.val_two_L'.symm ▸ Nat.pow_log_le_self 2 (by linarith [c.hn])
      simpa [core2, *] using h_geo_series
    · have h_geo_series : (∑ i ∈ Finset.range (Nat.factorization c.M 3 + 1), (1 / 3 : ℝ) ^ i)
          / (∑ i ∈ Finset.range (Nat.factorization c.L' 3 + 1), (1 / 3 : ℝ) ^ i) ≥
          (1 + (1 - (1 / 3 : ℝ) ^ c.k) / (3 * c.n)) := by
        have h_geo_series : (∑ i ∈ Finset.range (Nat.factorization c.M 3 + 1), (1 / 3 : ℝ) ^ i)
            / (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 3 + 1), (1 / 3 : ℝ) ^ i) ≥
            (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 3 + c.k + 1), (1 / 3 : ℝ) ^ i) /
            (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 3 + 1), (1 / 3 : ℝ) ^ i) := by
          exact div_le_div_of_nonneg_right (Finset.sum_le_sum_of_subset_of_nonneg
            (Finset.range_mono (by linarith [val_core c Nat.prime_three (by decide : 3 ∣ 6)])) fun _ _ _ ↦ by positivity)
            (Finset.sum_nonneg fun _ _ ↦ by positivity)
        refine le_trans ?_ h_geo_series
        convert ratio_three c.n c.k _ using 1
        exact c.val_three_L'.symm ▸ Nat.pow_log_le_self 3 (by linarith [c.hn])
      simpa [core3, *] using h_geo_series
    · rw [ge_iff_le, le_div_iff₀] <;> norm_num
      · refine Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono (Nat.succ_le_succ ?_))
          fun ?_ ?_ ?_ ↦ by positivity
        have h_div : c.L' ∣ c.M := by
          exact dvd_mul_left _ _
        exact (Nat.factorization_le_iff_dvd (by aesop) (by aesop)) |>.2 h_div p
      · exact Finset.sum_pos (fun _ _ ↦ inv_pos.mpr (pow_pos (Nat.cast_pos.mpr
          (Nat.pos_of_mem_primeFactors hp)) _)) (by norm_num)

  let I := Finset.image c.p Finset.univ
  let S := c.M.primeFactors
  let fm : ℕ → ℝ := fun p => if p ∈ I then 1 + 1 / (p * (p + 1) : ℝ) else 1
  let f2 : ℕ → ℝ := fun p => if p = 2 then core2 c else 1
  let f3 : ℕ → ℝ := fun p => if p = 3 then core3 c else 1
  have hsub : I ⊆ S := by
    intro p hp
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hp
    refine Nat.mem_primeFactors.mpr ⟨c.hp i, ?_, c.M_pos.ne'⟩
    exact dvd_mul_of_dvd_left (dvd_mul_of_dvd_left
      (dvd_mul_of_dvd_right (Finset.dvd_prod_of_mem _ (Finset.mem_univ i)) _) _) _
  have h2m : 2 ∈ S := by
    refine Nat.mem_primeFactors.mpr ⟨Nat.prime_two, ?_, c.M_pos.ne'⟩
    have hbase : 2 ∣ 6^c.k := dvd_trans (by decide : 2 ∣ 6) (dvd_pow_self 6 (by have hk := c.hk; omega))
    exact dvd_mul_of_dvd_left (dvd_mul_of_dvd_left (dvd_mul_of_dvd_left hbase _) _) _
  have h3m : 3 ∈ S := by
    refine Nat.mem_primeFactors.mpr ⟨Nat.prime_three, ?_, c.M_pos.ne'⟩
    have hbase : 3 ∣ 6^c.k := dvd_trans (by decide : 3 ∣ 6) (dvd_pow_self 6 (by have hk := c.hk; omega))
    exact dvd_mul_of_dvd_left (dvd_mul_of_dvd_left (dvd_mul_of_dvd_left hbase _) _) _
  have heq (p : ℕ) :
      (if p ∈ I then 1 + 1 / (p * (p + 1) : ℝ) else if p = 2 then core2 c else if p = 3 then core3 c else 1) =
        fm p * f2 p * f3 p := by
    by_cases hm : p ∈ I
    · have h2 : p ≠ 2 := by
        obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hm
        linarith [c.p_gt_three i]
      have h3 : p ≠ 3 := by
        obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hm
        linarith [c.p_gt_three i]
      simp [fm,f2,f3,hm,h2,h3]
    · by_cases h2 : p = 2
      · subst p; simp [fm,f2,f3,hm]
      · by_cases h3 : p = 3
        · subst p; simp [fm,f2,f3,hm,h2]
        · simp [fm,f2,f3,hm,h2,h3]
  have hfm : (∏ p ∈ S, fm p) = ∏ p ∈ I, (1 + 1 / (p * (p+1) : ℝ)) := by
    have hs : (∏ p ∈ I, fm p) = ∏ p ∈ S, fm p :=
      Finset.prod_subset hsub (fun p _ hp => by simp [fm,hp])
    rw [←hs]
    exact Finset.prod_congr rfl (fun p hp => by simp [fm,hp])
  have hf2 : (∏ p ∈ S, f2 p) = core2 c := by
    dsimp [f2]
    exact Finset.prod_ite_eq_of_mem' S 2 (fun _ => core2 c) h2m
  have hf3 : (∏ p ∈ S, f3 p) = core3 c := by
    dsimp [f3]
    exact Finset.prod_ite_eq_of_mem' S 3 (fun _ => core3 c) h3m
  have hI : (∏ p ∈ I, (1 + 1/(p*(p+1):ℝ))) = ∏ i, (1 + 1/(c.p i*(c.p i+1):ℝ)) := by
    rw [Finset.prod_image]
    intro i _ j _ hij
    exact c.hp_mono.injective hij
  have hprod := Finset.prod_le_prod₀ (s := S)
    (fun p _ => show 0 ≤ (if p ∈ I then 1 + 1 / (p*(p+1):ℝ)
      else if p=2 then core2 c else if p=3 then core3 c else 1) by
      split_ifs <;> first | exact (core2_pos c).le | exact (core3_pos c).le | positivity)
    h_ratio_terms
  simp_rw [heq] at hprod
  rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib, hfm, hf2, hf3, hI] at hprod
  rw [h_sigma_norm_M]
  have hs := mul_le_mul_of_nonneg_left hprod
    (show 0 ≤ σnorm c.L' by unfold σnorm; positivity)
  simpa only [mul_assoc] using hs

theorem criterion_surplus (c : PowerCriterion) {t : ℝ} (ht : 0 ≤ t)
    (h : (1 + t) * ∏ i, (1 + (1 : ℝ) / c.q i) ≤
      (∏ i, (1 + 1 / (c.p i * (c.p i + 1) : ℝ))) *
      core2 c * core3 c *
      (1 - 6^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ))) :
    (1 + t) * (σ (L c.n) : ℝ) < σ c.M := by
  have hMpos : (0 : ℝ) < c.M := by exact_mod_cast c.M_pos
  have hLpos : (0 : ℝ) < L c.n := by exact_mod_cast c.L_pos
  have hqpos : (0 : ℝ) < ∏ i, (c.q i : ℝ) := prod_pos fun i _ => by exact_mod_cast (c.hq i).pos
  have hRpos : (0 : ℝ) < 1 - 6^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ) := by
    rw [sub_pos, div_lt_one hqpos]
    exact_mod_cast c.prod_p_le_prod_q
  have hRlt : 1 - 6^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ) < (c.M : ℝ) / L c.n := by
    have hh := c.Ln_div_M_lt
    push_cast at hh
    rw [lt_inv_comm₀ (div_pos hLpos hMpos) hRpos, inv_div] at hh
    exact_mod_cast hh
  have hsigpos : 0 < σnorm (L c.n) := by
    rw [σnorm]; exact div_pos (by exact_mod_cast (show 0 < σ (L c.n) by
      rw [σ, ArithmeticFunction.sigma_pos_iff]; exact c.L_pos)) hLpos
  have hsig'pos : 0 ≤ σnorm c.L' := by unfold σnorm; positivity
  have hsig : (1 + t) * σnorm (L c.n) ≤ σnorm c.M *
      (1 - 6^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ)) := by
    rw [c.σnorm_ln_eq]
    nlinarith [mul_le_mul_of_nonneg_left h hsig'pos,
      mul_le_mul_of_nonneg_right (sigma_boost c) hRpos.le]
  have hsigMpos : 0 < σnorm c.M := by
    have : 0 < (1 + t) * σnorm (L c.n) := mul_pos (by linarith) hsigpos
    have : 0 < σnorm c.M * (1 - 6^c.k * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ)) := this.trans_le hsig
    exact (mul_pos_iff_of_pos_right hRpos).mp this
  have hfinal : (1 + t) * σnorm (L c.n) < σnorm c.M * ((c.M : ℝ) / L c.n) :=
    hsig.trans_lt (mul_lt_mul_of_pos_left hRlt hsigMpos)
  dsimp [σnorm] at hfinal
  have hid : (σ c.M : ℝ) / c.M * ((c.M : ℝ) / L c.n) = σ c.M / L c.n := by field_simp
  rw [hid] at hfinal
  exact (div_lt_div_iff_of_pos_right hLpos).mp (by simpa [mul_div_assoc] using hfinal)





end QRHRound2.LcmWitnessNoPVMath
