import Base
import Family
import Interface
open ArithmeticFunction Finset Nat Real LcmDev
namespace Candidate

theorem upper_aux {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    ∏ i : Fin 3, (1 + (1.000675 : ℝ) ^ ((i : ℕ) + 1 : ℝ) * ε) ≤
      1 + 3.004052 * ε + 3.01 * ε ^ 2 + 1.01 * ε ^ 3 := by
  norm_cast; norm_num [Fin.prod_univ_three]; nlinarith

theorem product_aux {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    (∏ i : Fin 3,
      (1 + ε / ((1.000675 : ℝ) ^ (2 * ((i : ℕ) + 1 : ℝ))) * (1 / (1 + 1/89693)))) *
        (1 + (3 : ℝ) / 8 * ε) * (1 - (3628261 / 10000000 : ℝ) * ε) ≥
      1 + 3.004055 * ε - 2 * ε ^ 2 := by
  norm_cast; norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg hε.left 3, pow_nonneg hε.left 4]

theorem comparison_aux {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    1 + 3.004052 * ε + 3.01 * ε ^ 2 + 1.01 * ε ^ 3 ≤ 1 + 3.004055 * ε - 2 * ε ^ 2 := by
  nlinarith

noncomputable def make (hd : Dusart2018.v1.proposition_5_4) {n : ℕ} (hn : n ≥ X₀ ^ 2) (t : ℕ) (ht : (t + 1 : ℝ) ≤ (3599 / 40000) * √n) : LcmFamily.Criterion where
  t := t
  n := n
  p := (exists_p_primes hd hn).choose
  q := (exists_q_primes hd hn).choose
  hn := le_trans (by decide : 1 ≤ 89693 ^ 2) hn
  hp := (exists_p_primes hd hn).choose_spec.1
  hp_mono := (exists_p_primes hd hn).choose_spec.2.1
  hq := (exists_q_primes hd hn).choose_spec.1
  hq_mono := (exists_q_primes hd hn).choose_spec.2.1
  h_ord_1 := (exists_p_primes hd hn).choose_spec.2.2.2
  h_ord_2 := by
    have hn_pos : (0 : ℝ) < n := by positivity
    have hp' : ((exists_p_primes hd hn).choose 2 : ℝ) ≤ √n * (1 + 1 / (log √n) ^ 3) ^ 3 := by
      convert (exists_p_primes hd hn).choose_spec.2.2.1 2 using 2; norm_cast
    have hq' : n * (1 + 1 / (log √n) ^ 3) ^ (-3 : ℝ) ≤ (exists_q_primes hd hn).choose 0 := by
      convert (exists_q_primes hd hn).choose_spec.2.2.1 0 using 2
      norm_num
    have hε_pos := hε_pos hn
    have hmid :
        √n * (1 + 1 / (log √n) ^ 3) ^ 3 < n * (1 + 1 / (log √n) ^ 3) ^ (-3 : ℝ) := by
      norm_cast
      norm_num [rpow_neg_one] at *
      rw [← div_eq_mul_inv, lt_div_iff₀ <| pow_pos hε_pos 3]
      have : (1 + ((log √n) ^ 3)⁻¹) ^ 6 < 2 :=
        calc (1 + ((log √n) ^ 3)⁻¹) ^ 6 < (1 + (11 ^ 3 : ℝ)⁻¹) ^ 6 := by gcongr; linarith [hlog hn]
          _ ≤ 2 := by norm_num
      nlinarith [mul_self_sqrt (Nat.cast_nonneg n), hsqrt_ge hn]
    exact_mod_cast hp'.trans_lt <| hmid.trans_le hq'
  h_ord_3 := (exists_q_primes hd hn).choose_spec.2.2.2
  h_crit := by
    have hn₀ : 0 ≤ Real.log √n := by
      grw [hn]
      simp [log_nonneg]
    have hnpos : (0 : ℝ) < n := by positivity
    have hxpos : 0 < √(n : ℝ) := Real.sqrt_pos.2 hnpos
    have ha : (1 + 1 / (log √(n : ℝ)) ^ 3) ^ 12 ≤ (1.000675 : ℝ) ^ 12 := by
      gcongr
      linarith [inv_cube_log_sqrt_le hn]
    have he : 4 * (t + 1 : ℝ) * (1 + 1 / (log √(n : ℝ)) ^ 3) ^ 12 / (n : ℝ) ^ (3 / 2 : ℝ) ≤ (3628261 / 10000000) * (1 / n) := by
      rw [show (n : ℝ) ^ (3 / 2 : ℝ) = n * √(n : ℝ) by
        rw [show (3 / 2 : ℝ) = 1 + 1 / 2 by ring, Real.rpow_add hnpos, Real.rpow_one, ← Real.sqrt_eq_rpow]]
      apply (div_le_iff₀ (mul_pos hnpos hxpos)).2
      have hm := mul_le_mul ht ha (by positivity) (by positivity : (0 : ℝ) ≤ (3599 / 40000) * √n)
      have hc : 4 * (3599 / 40000 : ℝ) * (1.000675 : ℝ) ^ 12 ≤ 3628261 / 10000000 := by norm_num
      have hm' := mul_le_mul_of_nonneg_right hc hxpos.le
      field_simp
      nlinarith
    have hold := pq_ratio_ge hd hn
    have h₁ : 1 - (4 : ℝ) * (t + 1) *
        (∏ i, (exists_p_primes hd hn).choose i : ℝ) / ∏ i, ((exists_q_primes hd hn).choose i : ℝ) ≥
        1 - (3628261 / 10000000) * (1 / n) := by
      have hm := mul_le_mul_of_nonneg_left (show (4 : ℝ) * (∏ i, (exists_p_primes hd hn).choose i : ℝ) / ∏ i, ((exists_q_primes hd hn).choose i : ℝ) ≤ 4 * (1 + 1 / (log √(n : ℝ)) ^ 3) ^ 12 / (n : ℝ) ^ (3 / 2 : ℝ) by linarith [hold]) (show 0 ≤ (t + 1 : ℝ) by positivity)
      simp only [div_eq_mul_inv] at hm he ⊢
      nlinarith
    have hnonneg : 0 ≤ 1 - (3628261 / 10000000 : ℝ) * (1 / n) := by
      have : (1 : ℝ) / n ≤ 1 / 89693 ^ 2 := by grw [hn]; norm_num
      nlinarith
    have := hnonneg.trans h₁
    have hn' : (0 : ℝ) ≤ 1 / ↑n ∧ (1 : ℝ) / ↑n ≤ 1 / 89693 ^ 2 := ⟨by simp, by grw [hn]; simp⟩
    grw [prod_q_ge hd hn, prod_p_ge hd hn, h₁]
    simp_rw [div_eq_mul_one_div (_ ^ (_ : ℝ) : ℝ) (n : ℝ),
      show 3 / (8 * n : ℝ) = 3 / 8 * (1 / n) by field_simp, ← one_div_mul_one_div]
    grw [inv_cube_log_sqrt_le hn, inv_n_add_sqrt_ge hn]
    set ε : ℝ := 1 / n
    calc
      _ ≤ ∏ i : Fin 3, (1 + (1 + 0.000675 : ℝ) ^ (i + 1 : ℝ) * ε) := by gcongr
      _ = ∏ i : Fin 3, (1 + (1.000675 : ℝ) ^ (i + 1 : ℝ) * ε) := by norm_num [div_eq_mul_inv]
      _ ≤ _ := (upper_aux (ε := ε) hn')
      _ ≤ _ := comparison_aux hn'
      _ ≤ _ := by
        grw [← product_aux hn']
        apply le_of_eq
        norm_num [Fin.prod_univ_three]
        ring
        simp




theorem result : Exposure01.Goal (3599 / 40000) := by
  intro hs n hn
  have hd : Dusart2018.v1.proposition_5_4 := by
    intro x hx
    simpa only [IEANTN.HasPrimeInInterval, Real.rpow_ofNat] using hs x hx
  let k := Exposure01.Count (3599 / 40000) n
  have hk : (k : ℝ) ≤ (3599 / 40000) * √(n : ℝ) := by
    dsimp [k, Exposure01.Count]
    norm_num only [Rat.cast_div, Rat.cast_ofNat]
    exact Nat.floor_le (by positivity)
  have ht (i : Fin k) : (i.val + 1 : ℝ) ≤ (3599 / 40000) * √(n : ℝ) := by
    have hi : (i.val + 1 : ℕ) ≤ k := i.isLt
    exact (by exact_mod_cast hi : (i.val + 1 : ℝ) ≤ k).trans hk
  let c (i : Fin k) := make hd hn i.val (ht i)
  have hinj : Function.Injective (fun i : Fin k ↦ (c i).M) := by
    intro i j hij
    let A := 4 * ∏ z, (exists_p_primes hd hn).choose z
    let D := (∏ z, (exists_q_primes hd hn).choose z) / A
    let C := LcmFamily.L n / ∏ z, (exists_q_primes hd hn).choose z
    have hA : 0 < A := (c i).d_pos
    have hC : 0 < C := (c i).L'_pos
    change A * (D - i.val) * C = A * (D - j.val) * C at hij
    have hmul : A * (D - i.val) = A * (D - j.val) := (mul_left_inj' hC.ne').mp hij
    have hsub : D - i.val = D - j.val := (mul_right_inj' hA.ne').mp hmul
    have hi : i.val < D := (c i).t_lt_div
    have hj : j.val < D := (c j).t_lt_div
    apply Fin.ext
    omega
  refine ⟨Finset.univ.image (fun i : Fin k ↦ (c i).M), ?_, ?_⟩
  · rw [Finset.card_image_of_injective _ hinj]
    simp [k]
  · intro m hm
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hm
    refine ⟨(c i).M_pos, (c i).M_lt, ?_⟩
    exact (c i).not_highlyAbundant_2 (c i).σnorm_M_ge_σnorm_L'_mul

theorem comparison : Exposure01.Comparison (3599 / 40000) := by
  unfold Exposure01.Comparison
  constructor
  · norm_num
  · norm_num [Exposure01.Count, Real.sqrt_sq_eq_abs, Exposure01.Comparison]

end Candidate
