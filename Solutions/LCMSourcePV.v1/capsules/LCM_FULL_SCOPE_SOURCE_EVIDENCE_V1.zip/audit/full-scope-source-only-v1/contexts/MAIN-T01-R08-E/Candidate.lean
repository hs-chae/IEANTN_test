import Construction
import Interface

namespace Candidate
open LcmDev Finset

def coefficient : ℚ := 3599 / 40000

theorem comparison : Exposure01.Comparison coefficient := by
  norm_num [Exposure01.Comparison, Exposure01.Count, coefficient,
    show (((89693 : ℕ) ^ 2 : ℕ) : ℝ) = (89693 : ℝ) ^ 2 by norm_num,
    Real.sqrt_sq_eq_abs]

theorem result : Exposure01.Goal coefficient := by
  intro hd n hn
  have hd' : Dusart2018.v1.proposition_5_4 := by
    intro x hx
    simpa only [IEANTN.HasPrimeInInterval, Real.rpow_ofNat] using hd x hx
  let N := Exposure01.Count coefficient n
  have bound (k : ℕ) (hk : k < N) : (k : ℝ) + 1 ≤ (3599 / 40000 : ℝ) * Real.sqrt n := by
    have h1 : k + 1 ≤ N := hk
    have h2 : (N : ℝ) ≤ (3599 / 40000 : ℝ) * Real.sqrt n := by
      have hf : (⌊(3599 / 40000 : ℝ) * Real.sqrt n⌋₊ : ℝ) ≤
          (3599 / 40000 : ℝ) * Real.sqrt n := Nat.floor_le (by positivity)
      simpa [N, Exposure01.Count, coefficient] using hf
    exact le_trans (by exact_mod_cast h1) h2
  let c (i : {k // k ∈ Finset.range N}) := Criterion.mk' hd' hn i.val
    (bound i.val (Finset.mem_range.mp i.property))
  let f (i : {k // k ∈ Finset.range N}) := (c i).M
  have finj : Function.Injective f := by
    intro i j hij
    have hpi : (c i).p = (c j).p := rfl
    have hqi : (c i).q = (c j).q := rfl
    have hli : (c i).L' = (c j).L' := rfl
    have he : (4 * ∏ z, (c i).p z) * (c i).m * (c i).L' =
        (4 * ∏ z, (c j).p z) * (c j).m * (c j).L' := hij
    rw [← hpi, ← hli] at he
    have he1 := Nat.eq_of_mul_eq_mul_right (c i).L'_pos he
    have he2 := Nat.eq_of_mul_eq_mul_left (c i).base_pos he1
    have hi := (c i).k_lt_div
    have hj := (c j).k_lt_div
    simp only [Criterion.m] at he2
    rw [← hpi, ← hqi] at he2 hj
    have hk : (c i).k = i.val := rfl
    have hk' : (c j).k = j.val := rfl
    rw [hk] at he2 hi
    rw [hk'] at he2 hj
    apply Subtype.ext
    omega
  refine ⟨(Finset.range N).attach.image f, ?_, ?_⟩
  · rw [Finset.card_image_of_injective _ finj, Finset.card_attach, Finset.card_range]
  · intro m hm
    obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hm
    refine ⟨(c i).M_pos, ?_, ?_⟩
    · exact (c i).M_lt
    · exact_mod_cast (c i).sigma_gt_final

end Candidate
