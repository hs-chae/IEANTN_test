import Multiplicity
import Interface
namespace Candidate
open LcmDev Finset Nat Real
open ArithmeticFunction hiding log
abbrev alpha : ℚ := 11247 / 125000
lemma comparison : Exposure01.Comparison alpha := by
  constructor
  · norm_num [alpha]
  · norm_num [Exposure01.Count, alpha, Real.sqrt_sq_eq_abs]

lemma poly_upper {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    ∏ i : Fin 3, (1 + (1.000675 : ℝ) ^ ((i : ℕ) + 1 : ℝ) * ε) ≤
      1 + 3.00405183 * ε + 3.01 * ε ^ 2 + 1.01 * ε ^ 3 := by
  norm_cast; norm_num [Fin.prod_univ_three]; nlinarith

lemma poly_lower {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    (∏ i : Fin 3,
      (1 + ε / ((1.000675 : ℝ) ^ (2 * ((i : ℕ) + 1 : ℝ))) * (1 / (1 + 1/89693)))) *
        (1 + (3 : ℝ) / 8 * ε) * (1 - (36283007 / 100000000 : ℝ) * ε) ≥
      1 + 3.00405203 * ε - 2 * ε ^ 2 := by
  norm_cast; norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg hε.left 3, pow_nonneg hε.left 4]
lemma poly_comparison {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    1 + 3.00405183 * ε + 3.01 * ε ^ 2 + 1.01 * ε ^ 3 ≤ 1 + 3.00405203 * ε - 2 * ε ^ 2 := by
  nlinarith

lemma ratio_bound (hd : Dusart2018.v1.proposition_5_4) {n : ℕ} (hn : n ≥ X₀ ^ 2)
    (k : ℕ) (hk : (k : ℝ) ≤ (11247/125000 : ℝ) * √(n : ℝ)) :
    4 * (∏ i, ((Criterion.mk' hd hn).p i : ℝ)) * k /
      (∏ i, ((Criterion.mk' hd hn).q i : ℝ)) ≤ (36283007/100000000 : ℝ) / n := by
  have h := pq_ratio_ge hd hn
  have hnpos : (0 : ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0 < 89693^2) hn)
  have hx : 0 < √(n : ℝ) := sqrt_pos.2 hnpos
  have hr : (n : ℝ) ^ (3/2 : ℝ) = n * √(n : ℝ) := by
    rw [show (3/2 : ℝ) = 1 + 1/2 by ring, rpow_add hnpos, rpow_one, ← sqrt_eq_rpow]
  have hbase : 4 * (∏ i, ((Criterion.mk' hd hn).p i : ℝ)) /
      (∏ i, ((Criterion.mk' hd hn).q i : ℝ)) ≤
      4 * (1 + 1 / (log √(n : ℝ)) ^ 3) ^ 12 / (n * √(n : ℝ)) := by
    dsimp [Criterion.mk']
    rw [hr] at h
    linarith
  have ha : (1 + 1 / (log √(n : ℝ)) ^ 3) ^ 12 ≤ (1.000675 : ℝ)^12 := by
    apply pow_le_pow_left₀ (by positivity [hlog hn])
    linarith [inv_cube_log_sqrt_le hn]
  calc
    _ = (4 * (∏ i, ((Criterion.mk' hd hn).p i : ℝ)) /
      (∏ i, ((Criterion.mk' hd hn).q i : ℝ))) * k := by ring
    _ ≤ (4 * (1 + 1 / (log √(n : ℝ)) ^ 3) ^ 12 / (n * √(n : ℝ))) * ((11247/125000 : ℝ) * √(n : ℝ)) :=
      mul_le_mul hbase hk (by positivity) (by positivity [hlog hn])
    _ = 4 * (11247/125000 : ℝ) * (1 + 1 / (log √(n : ℝ)) ^ 3) ^ 12 / n := by field_simp
    _ ≤ 4 * (11247/125000 : ℝ) * (1.000675 : ℝ)^12 / n := by gcongr
    _ ≤ (36283007/100000000 : ℝ) / n := by gcongr; norm_num

lemma criterion_many (hd : Dusart2018.v1.proposition_5_4) {n : ℕ} (hn : n ≥ X₀ ^ 2)
    (k : ℕ) (hk : (k : ℝ) ≤ (11247/125000 : ℝ) * √(n : ℝ)) :
    let c := Criterion.mk' hd hn
    (∏ i, (1 + (1 : ℝ) / c.q i)) ≤
      (∏ i, (1 + (1 : ℝ) / (c.p i * (c.p i + 1)))) * (1 + (3 : ℝ) / (8 * n)) *
      (1 - 4 * (∏ i, (c.p i : ℝ)) * k / ∏ i, (c.q i : ℝ)) := by
  have hn₀ : 0 ≤ Real.log √n := by linarith [hlog hn]
  have h₁ := ratio_bound hd hn k hk
  have hpos : 0 ≤ 1 - (36283007/100000000 : ℝ) / n := by
    have : (89693^2 : ℝ) ≤ n := by exact_mod_cast hn
    rw [sub_nonneg, div_le_one (by positivity)]
    linarith
  have hn' : (0 : ℝ) ≤ 1 / ↑n ∧ (1 : ℝ) / ↑n ≤ 1 / 89693 ^ 2 := ⟨by simp, by grw [hn]; simp⟩
  dsimp only
  change _ ≤ _ * _ * (1 - 4 * (∏ i, ((Criterion.mk' hd hn).p i : ℝ)) * k / _)
  have hg := sub_le_sub_left h₁ 1
  apply le_trans ?_ (mul_le_mul_of_nonneg_left hg (by positivity))
  change (∏ i, (1 + (1 : ℝ) / (exists_q_primes hd hn).choose i)) ≤
    (∏ i, (1 + (1 : ℝ) / ((exists_p_primes hd hn).choose i * ((exists_p_primes hd hn).choose i + 1)))) * _ * _
  grw [prod_q_ge hd hn, prod_p_ge hd hn]
  simp_rw [div_eq_mul_one_div (_ ^ (_ : ℝ) : ℝ) (n : ℝ),
    show 3 / (8 * n : ℝ) = 3 / 8 * (1 / n) by field_simp, ← one_div_mul_one_div]
  grw [inv_cube_log_sqrt_le hn, inv_n_add_sqrt_ge hn]
  set ε : ℝ := 1 / n
  calc
    _ ≤ ∏ i : Fin 3, (1 + (1 + 0.000675 : ℝ) ^ (i + 1 : ℝ) * ε) := by gcongr
    _ = ∏ i : Fin 3, (1 + (1.000675 : ℝ) ^ (i + 1 : ℝ) * ε) := by norm_num [div_eq_mul_inv]
    _ ≤ _  := poly_upper hn'
    _ ≤ _ := poly_comparison hn'
    _ ≤ _ := by
      grw [← poly_lower hn']
      apply le_of_eq
      simp [field]
      ring_nf
end Candidate
