import Construction
namespace Candidate
open LcmDev Real
 theorem result : Exposure01.Goal alpha := by
  intro hd n hn
  have hd' : Dusart2018.v1.proposition_5_4 := by
    simpa only [Exposure01.Source, Dusart2018.v1.proposition_5_4, IEANTN.HasPrimeInInterval.logPower,
      IEANTN.HasPrimeInInterval, Real.rpow_ofNat] using hd
  have hcount : 2 ≤ Exposure01.Count alpha n := by
    apply le_trans comparison.2
    apply Nat.floor_mono
    apply mul_le_mul_of_nonneg_left _ (by norm_num [alpha])
    exact Real.sqrt_le_sqrt (by exact_mod_cast hn)
  have hk : (Exposure01.Count alpha n : ℝ) ≤ (11247/125000 : ℝ) * √(n : ℝ) := by
    simpa only [Exposure01.Count, alpha, Rat.cast_div, Rat.cast_ofNat] using Nat.floor_le (by positivity : (0 : ℝ) ≤ (11247/125000 : ℝ) * √(n : ℝ))
  obtain ⟨S, hS, hgood⟩ := many_witnesses (Criterion.mk' hd' hn) (Exposure01.Count alpha n)
    (by omega) (criterion_many hd' hn _ hk)
  refine ⟨S, hS, ?_⟩
  intro m hm
  simpa only [Criterion.mk', LcmDev.L, Nat.lcmUpto, LcmDev.σ] using hgood m hm
end Candidate
