import Analysis
namespace Candidate
open LcmDev Finset Nat Real
open ArithmeticFunction hiding log
lemma many_witnesses (c : Criterion) (k : ℕ) (hk : 0 < k)
    (hc : (∏ i, (1 + (1 : ℝ) / c.q i)) ≤
      (∏ i, (1 + (1 : ℝ) / (c.p i * (c.p i + 1)))) * (1 + (3 : ℝ) / (8 * c.n)) *
      (1 - 4 * (∏ i, (c.p i : ℝ)) * k / ∏ i, (c.q i : ℝ))) :
    ∃ S : Finset ℕ, k ≤ S.card ∧ ∀ x ∈ S,
      0 < x ∧ x < L c.n ∧ (σ (L c.n) : ℝ) < σ x := by
  let P := ∏ i, c.p i
  let Q := ∏ i, c.q i
  have hP : 0 < P := prod_pos fun i _ ↦ (c.hp i).pos
  have hQ : 0 < Q := prod_pos fun i _ ↦ (c.hq i).pos
  have hLP : 0 < (c.L' : ℝ) := by exact_mod_cast c.L'_pos
  have hQreal : 0 < (Q : ℝ) := by exact_mod_cast hQ
  have hgain : 0 < (∏ i, (1 + (1 : ℝ) / (c.p i * (c.p i + 1)))) * (1 + (3 : ℝ) / (8 * c.n)) := by positivity
  have hR : 0 < 1 - 4 * (P : ℝ) * k / Q := by
    have hpos : 0 < ∏ i, (1 + (1 : ℝ) / c.q i) := prod_pos fun i _ ↦ by positivity
    have hc' : (∏ i, (1 + (1 : ℝ) / c.q i)) ≤
      (∏ i, (1 + (1 : ℝ) / (c.p i * (c.p i + 1)))) * (1 + (3 : ℝ) / (8 * c.n)) * (1 - 4 * (P : ℝ) * k / Q) := by
      simpa only [P, Q, cast_prod] using hc
    nlinarith
  have hPk : 4 * P * k < Q := by
    have : 4 * (P : ℝ) * k < Q := (div_lt_one hQreal).1 (by linarith : 4 * (P : ℝ) * k / Q < 1)
    exact_mod_cast this
  have hkm : k ≤ c.m := by
    dsimp [Criterion.m]
    exact (Nat.le_div_iff_mul_le (by positivity)).2 (by dsimp [P, Q] at hPk; nlinarith)
  have hgood (j : ℕ) (hj : j < k) :
      0 < c.alt (c.m - j) ∧ c.alt (c.m - j) < L c.n ∧
      (σ (L c.n) : ℝ) < σ (c.alt (c.m - j)) := by
    have ht : 0 < c.m - j := Nat.sub_pos_of_lt (lt_of_lt_of_le hj hkm)
    have hMpos := c.alt_pos (c.m - j) ht
    have hmj : c.m - j + j = c.m := Nat.sub_add_cancel (le_of_lt (lt_of_lt_of_le hj hkm))
    have heq : c.alt (c.m - j) + (c.r + 4 * P * j) * c.L' = L c.n := by
      calc
        _ = (4 * P * (c.m - j + j) + c.r) * c.L' := by dsimp [Criterion.alt, P]; ring
        _ = (4 * P * c.m + c.r) * c.L' := by rw [hmj]
        _ = L c.n := by rw [← c.prod_q_eq, ← c.L_eq_prod_q_mul_L']
    have hdefpos : 0 < c.r + 4 * P * j := by have := c.r_ge; omega
    have hsmall : c.alt (c.m - j) < L c.n := by nlinarith [c.L'_pos]
    have hdeflt : c.r + 4 * P * j < 4 * P * k := by
      have := c.r_le
      have : j + 1 ≤ k := hj
      dsimp [P] at *
      nlinarith
    have hnL : 0 < (L c.n : ℝ) := by exact_mod_cast c.L_pos
    have hnM : 0 < (c.alt (c.m - j) : ℝ) := by exact_mod_cast hMpos
    have hfL' : 0 < σnorm c.L' := by
      exact div_pos (by exact_mod_cast (show 0 < σ c.L' by rw [σ, sigma_pos_iff]; exact c.L'_pos)) hLP
    have hfM : 0 < σnorm (c.alt (c.m - j)) := by
      exact div_pos (by exact_mod_cast (show 0 < σ (c.alt (c.m - j)) by rw [σ, sigma_pos_iff]; exact hMpos)) hnM
    have hnorm := c.norm_alt_ge (c.m - j) ht
    have hbound : σnorm (L c.n) ≤ σnorm (c.alt (c.m - j)) * (1 - 4 * (P : ℝ) * k / Q) := by
      rw [c.σnorm_ln_eq]
      have hc' : (∏ i, (1 + (1 : ℝ) / c.q i)) ≤
        (∏ i, (1 + (1 : ℝ) / (c.p i * (c.p i + 1)))) * (1 + (3 : ℝ) / (8 * c.n)) * (1 - 4 * (P : ℝ) * k / Q) := by
        simpa only [P, Q, cast_prod] using hc
      nlinarith
    have hratio : 1 - 4 * (P : ℝ) * k / Q < (c.alt (c.m - j) : ℝ) / L c.n := by
      apply (lt_div_iff₀ hnL).2
      rw [c.L_eq_prod_q_mul_L', Nat.cast_mul]
      change (1 - 4 * (P : ℝ) * k / Q) * ((Q : ℝ) * c.L') < _
      have heqR : (c.alt (c.m - j) : ℝ) + ((c.r : ℝ) + 4 * P * j) * c.L' = (Q : ℝ) * c.L' := by
        exact_mod_cast heq.trans c.L_eq_prod_q_mul_L'
      have hltR : (c.r : ℝ) + 4 * P * j < 4 * P * k := by exact_mod_cast hdeflt
      field_simp
      nlinarith
    have hfinal : σnorm (L c.n) < σnorm (c.alt (c.m - j)) * ((c.alt (c.m - j) : ℝ) / L c.n) := by
      nlinarith
    have hsigma : (σ (L c.n) : ℝ) < σ (c.alt (c.m - j)) := by
      dsimp [σnorm] at hfinal
      field_simp at hfinal
      nlinarith
    exact ⟨hMpos, hsmall, hsigma⟩
  refine ⟨(range k).image (fun j ↦ c.alt (c.m - j)), ?_, ?_⟩
  · rw [card_image_iff.mpr, card_range]
    intro i hi j hj hij
    have hi' : i < k := mem_range.mp hi
    have hj' : j < k := mem_range.mp hj
    dsimp [Criterion.alt] at hij
    have hsub : c.m - i = c.m - j := by
      have hh := (mul_left_inj' c.L'_pos.ne').mp hij
      exact (mul_right_inj' (show (4 * ∏ i, c.p i) ≠ 0 by positivity)).mp hh
    omega
  · intro x hx
    obtain ⟨j, hj, rfl⟩ := mem_image.mp hx
    exact hgood j (mem_range.mp hj)
end Candidate
