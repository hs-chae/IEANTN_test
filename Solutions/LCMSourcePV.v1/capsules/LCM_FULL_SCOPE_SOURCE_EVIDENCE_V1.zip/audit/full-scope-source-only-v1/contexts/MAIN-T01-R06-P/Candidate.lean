import PowerCount
import Interface
namespace PowerFixedCertificate
set_option maxHeartbeats 5000000
theorem certificate : MultiplicityK.ScalarCertificate 1 ((589 : ℝ)/5000) := by
  intro ε hε
  have hsmall : ε ≤ 1 := hε.2.trans (by norm_num)
  have h2 : ε^2 ≤ ε/(89693^2:ℝ) := by
    nlinarith [mul_nonneg hε.1 (sub_nonneg.mpr hε.2)]
  have h3 : ε^3 ≤ ε^2 := by
    nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hsmall)]
  have h4 : ε^4 ≤ ε^3 := by
    nlinarith [mul_nonneg (pow_nonneg hε.1 3) (sub_nonneg.mpr hsmall)]
  have h5 : ε^5 ≤ ε^4 := by
    nlinarith [mul_nonneg (pow_nonneg hε.1 4) (sub_nonneg.mpr hsmall)]
  dsimp only [MultiplicityK.scalarLeft,MultiplicityK.scalarPrefactor]
  norm_cast
  norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg hε.1 3,pow_nonneg hε.1 4,pow_nonneg hε.1 5]
end PowerFixedCertificate
namespace Candidate
theorem result : Exposure01.Goal ((589 : ℚ)/5000) := by
  intro hs n hn
  have hd : Dusart2018.v1.proposition_5_4 := by
    intro x hx
    simpa only [IEANTN.HasPrimeInInterval,Real.rpow_ofNat] using hs x hx
  have hh := MultiplicityK.count_many 1 (by norm_num) ((589 : ℝ)/5000) (by norm_num) PowerFixedCertificate.certificate hd n hn
  simpa [Exposure01.Count,div_eq_mul_inv,mul_assoc,mul_left_comm,mul_comm] using hh
theorem comparison : Exposure01.Comparison ((589 : ℚ)/5000) := by
  norm_num [Exposure01.Comparison,Exposure01.Count]
#print axioms result
#print axioms comparison
end Candidate
