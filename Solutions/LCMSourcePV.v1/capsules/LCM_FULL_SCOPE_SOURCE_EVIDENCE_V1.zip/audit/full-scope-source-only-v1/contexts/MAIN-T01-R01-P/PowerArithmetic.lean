import PowerQuotient
namespace MultiplicityK
open ArithmeticFunction hiding log
open Finset Nat Real LcmDev
set_option Elab.async false
set_option maxHeartbeats 3000000

def quotient (k : ℕ) (c : Criterion) : ℕ := (∏ i,c.q i)/(2^k*∏ i,c.p i)
def remainder (k : ℕ) (c : Criterion) : ℕ := (∏ i,c.q i)%(2^k*∏ i,c.p i)

lemma remainder_pos (k : ℕ) (c : Criterion) : 0 < remainder k c := by
  simp only [remainder,Nat.pos_iff_ne_zero,ne_eq]
  intro h
  have hd : c.p 2 ∣ ∏ i,c.q i :=
    (Finset.dvd_prod_of_mem _ (Finset.mem_univ 2)).trans
      ((Nat.dvd_mul_left _ (2^k)).trans (Nat.dvd_of_mod_eq_zero h))
  obtain ⟨i,_,hi⟩ := (c.hp 2).prime.exists_mem_finset_dvd hd
  have he : c.p 2 = c.q i := ((c.hq i).dvd_iff_eq (c.hp 2).ne_one).mp hi |>.symm
  exact absurd he (c.h_ord_2.trans_le (c.hq_mono.monotone (zero_le i))).ne

lemma remainder_lt (k : ℕ) (c : Criterion) : remainder k c < 2^k*∏ i,c.p i :=
  Nat.mod_lt _ (mul_pos (pow_pos (by norm_num) k) (Finset.prod_pos fun i _ => (c.hp i).pos))

lemma div_identity (k : ℕ) (c : Criterion) :
    ∏ i,c.q i = (2^k*∏ i,c.p i)*quotient k c + remainder k c := by
  simp only [quotient,remainder,Nat.div_add_mod]

lemma maximum_lt (k : ℕ) (c : Criterion) : witness k c (quotient k c) < L c.n := by
  calc witness k c (quotient k c) <
      ((2^k*∏ i,c.p i)*quotient k c + remainder k c)*c.L' :=
        mul_lt_mul_of_pos_right (Nat.lt_add_of_pos_right (remainder_pos k c)) c.L'_pos
    _ = (∏ i,c.q i)*c.L' := by rw [←div_identity k c]
    _ = L c.n := c.L_eq_prod_q_mul_L'.symm

lemma quotient_injective (k : ℕ) (C : Criterion) (K : ℕ)
    (hpos : ∀ j : ℕ, j < K → 0 < witness k C (quotient k C-j)) :
    Set.InjOn (fun j : ℕ => witness k C (quotient k C-j)) (Finset.range K) := by
  intro a ha b hb hab
  have hwa := hpos a (Finset.mem_range.mp ha)
  have hwb := hpos b (Finset.mem_range.mp hb)
  have hma : 0 < quotient k C-a := by
    by_contra hh
    have hz : quotient k C-a=0 := Nat.eq_zero_of_not_pos hh
    simp [witness,hz] at hwa
  have hmb : 0 < quotient k C-b := by
    by_contra hh
    have hz : quotient k C-b=0 := Nat.eq_zero_of_not_pos hh
    simp [witness,hz] at hwb
  have hA : 0 < 2^k*∏ i,C.p i := mul_pos (pow_pos (by norm_num) k) (Finset.prod_pos fun i _ => (C.hp i).pos)
  have hq : quotient k C-a=quotient k C-b :=
    Nat.mul_left_cancel hA (Nat.mul_right_cancel C.L'_pos hab)
  omega

end MultiplicityK
