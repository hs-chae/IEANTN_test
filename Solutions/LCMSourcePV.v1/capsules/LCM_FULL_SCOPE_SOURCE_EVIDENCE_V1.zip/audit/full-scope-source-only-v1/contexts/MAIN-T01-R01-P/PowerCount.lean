import PowerTail
namespace MultiplicityK
open ArithmeticFunction hiding log
open Finset Nat Real LcmDev
set_option Elab.async false
set_option maxHeartbeats 5000000
theorem count_many (k : ℕ) (hk : 1 ≤ k) (α : ℝ) (hα : 0 ≤ α) (hcert : ScalarCertificate k α) (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 89693^2 ≤ n) :
    ∃ S : Finset ℕ, ⌊α * Real.sqrt (n:ℝ)⌋₊ ≤ S.card ∧
      ∀ m ∈ S, 0 < m ∧ m < Nat.lcmUpto n ∧
        (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) < ArithmeticFunction.sigma 1 m := by
  classical
  let C := LcmDev.Criterion.mk' hd hn
  let K : ℕ := ⌊α * Real.sqrt (n:ℝ)⌋₊
  have hK : (K:ℝ) ≤ α * Real.sqrt n := Nat.floor_le (mul_nonneg hα (Real.sqrt_nonneg _))
  have hJ : ∀ j:ℕ,j<K → (j+1:ℝ) ≤ α * Real.sqrt n := by
    intro j hj
    have hh : (j+1:ℝ) ≤ (K:ℝ) := by exact_mod_cast (Nat.succ_le_iff.mpr hj)
    exact hh.trans hK
  have hgood : ∀ j:ℕ,j<K → 0<witness k C (quotient k C-j) ∧ witness k C (quotient k C-j)<L n ∧
      (σ (L n):ℝ)<σ (witness k C (quotient k C-j)) := by
    intro j hj
    exact offset_good k hk α hα hcert hd hn (hJ j hj)
  let S : Finset ℕ := (Finset.range K).image (fun j=>witness k C (quotient k C-j))
  refine ⟨S,?_,?_⟩
  · have hc : S.card=K := by
      rw [Finset.card_image_of_injOn (quotient_injective k C K (fun j hj=>(hgood j hj).1)),Finset.card_range]
    exact hc.ge
  · intro m hm
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hm
    exact hgood j (Finset.mem_range.mp hj)



end MultiplicityK
#print axioms MultiplicityK.count_many
