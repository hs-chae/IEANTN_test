import Baseline
set_option Elab.async false
set_option maxHeartbeats 6000000

namespace MultiplicityK
open ArithmeticFunction hiding log
open Finset Nat Real LcmDev

noncomputable def witness (k : ℕ) (c : Criterion) (m : ℕ) : ℕ :=
  (2^k * ∏ i, c.p i) * m * c.L'

lemma witness_pos (k : ℕ) (c : Criterion) (m : ℕ) (hm : 0 < m) : 0 < witness k c m := by
  exact mul_pos (mul_pos (mul_pos (pow_pos (by norm_num) k) (Finset.prod_pos fun i _ => (c.hp i).pos)) hm) c.L'_pos

lemma forced_two (k : ℕ) (c : Criterion) (m : ℕ) (hm : 0 < m) :
    c.L'.factorization 2 + k ≤ (witness k c m).factorization 2 := by
  have hP : 0 < ∏ i, c.p i := Finset.prod_pos fun i _ => (c.hp i).pos
  have hA : 2^k*∏ i, c.p i ≠ 0 := by positivity
  have htwo : k ≤ (2^k*∏ i, c.p i).factorization 2 :=
    (Nat.prime_two.pow_dvd_iff_le_factorization hA).mp (dvd_mul_right _ _)
  rw [witness, Nat.factorization_mul (mul_ne_zero hA hm.ne') c.L'_pos.ne',
    Nat.factorization_mul hA hm.ne']
  simp only [Finsupp.add_apply]
  omega

lemma forced_p (k : ℕ) (c : Criterion) (m : ℕ) (hm : 0 < m) (i : Fin 3) :
    2 ≤ (witness k c m).factorization (c.p i) := by
  have hP : 0 < ∏ i, c.p i := Finset.prod_pos fun i _ => (c.hp i).pos
  have hA : 2^k*∏ i, c.p i ≠ 0 := by positivity
  have hprime : 1 ≤ (2^k*∏ i, c.p i).factorization (c.p i) :=
    ((c.hp i).pow_dvd_iff_le_factorization hA).mp (by
      simpa using dvd_mul_of_dvd_right (Finset.dvd_prod_of_mem _ (Finset.mem_univ i)) (2^k))
  rw [witness, Nat.factorization_mul (mul_ne_zero hA hm.ne') c.L'_pos.ne',
    Nat.factorization_mul hA hm.ne']
  simp only [Finsupp.add_apply]
  rw [c.val_p_L' i]
  omega

lemma ratio_ge_aux {k : ℕ} (n j : ℕ) (hk : 2 ^ k ≤ n) :
    (∑ i ∈ Finset.range (k + j + 1), (1 / 2 : ℝ) ^ i) /
      (∑ i ∈ Finset.range (k + 1), (1 / 2 : ℝ) ^ i) ≥
      1 + (1 - (1 / 2 : ℝ) ^ j) / (2 * n) := by
  have hu : 0 < (1 / 2 : ℝ) ^ k := by positivity
  have hu1 : (1 / 2 : ℝ) ^ k ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hv : 0 ≤ 1 - (1 / 2 : ℝ) ^ j := sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))
  have hn : (0 : ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by positivity : 0 < 2 ^ k) hk)
  have hinv : (n : ℝ)⁻¹ ≤ (1 / 2 : ℝ) ^ k := by
    simpa using inv_anti₀ (by positivity) (mod_cast hk)
  have hs1 : (∑ i ∈ Finset.range (k + j + 1), (1 / 2 : ℝ) ^ i) =
      2 - (1 / 2 : ℝ)^k * (1 / 2 : ℝ)^j := by
    norm_num [geom_sum_eq, pow_add]; ring
  have hs2 : (∑ i ∈ Finset.range (k + 1), (1 / 2 : ℝ) ^ i) =
      2 - (1 / 2 : ℝ)^k := by
    norm_num [geom_sum_eq, pow_add]; ring
  rw [hs1, hs2, ge_iff_le, le_div_iff₀ (by linarith : 0 < 2 - (1 / 2 : ℝ)^k)]
  have hterm : (1 - (1 / 2 : ℝ)^j) / (2 * n) ≤
      (1 - (1 / 2 : ℝ)^j) * (1 / 2 : ℝ)^k / 2 := by
    simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm] using
      mul_le_mul_of_nonneg_left hinv (div_nonneg hv (by norm_num : (0 : ℝ) ≤ 2))
  have hnon : 0 ≤ (1 - (1 / 2 : ℝ)^j) / (2 * n) := by positivity
  nlinarith [mul_nonneg hv (sq_nonneg ((1 / 2 : ℝ)^k))]


lemma sigma_lower (k : ℕ) (hk : 1 ≤ k) (c : Criterion) (m : ℕ) (hm : 0 < m) :
    σnorm (witness k c m) ≥ σnorm c.L' *
      (∏ i, (1+1/(c.p i*(c.p i+1:ℝ))))*(1+(1-(1/2:ℝ)^k)/(2*c.n)) := by
  have hgain : 0 ≤ 1-(1/2:ℝ)^k := sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))

  have h_sigma_norm_M : (σnorm (witness k c m)) = (σnorm (c.L' : ℕ)) * (∏ p ∈ Nat.primeFactors (witness k c m),
      ((∑ i ∈ Finset.range (Nat.factorization (witness k c m) p + 1), (1 / p : ℝ) ^ i) /
      (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i))) := by
    have h_sigma_norm_prod : ∀ {n : ℕ}, n ≠ 0 → (σnorm n : ℝ) = (∏ p ∈ Nat.primeFactors n,
        ((∑ i ∈ Finset.range (Nat.factorization n p + 1), (1 / p : ℝ) ^ i))) := by
      intro n hn_ne_zero
      have h_sigma_def : ((σ n) : ℝ) = (∏ p ∈ Nat.primeFactors n, (∑ i ∈ Finset.range
          (Nat.factorization n p + 1), (p ^ i : ℝ))) := by
        unfold σ
        have h_sigma_def : ∀ {n : ℕ}, n ≠ 0 → (Nat.divisors n).sum (fun d ↦ d) =
            ∏ p ∈ n.primeFactors, (∑ i ∈ Finset.range (Nat.factorization n p + 1), p ^ i) := by
          exact fun {n} a ↦ sum_divisors a
        convert congr_arg (( ↑ ) : ℕ → ℝ) (h_sigma_def hn_ne_zero) using 1 <;>
        norm_num [ArithmeticFunction.sigma]
      have h_sigma_def : (n : ℝ) = (∏ p ∈ Nat.primeFactors n, (p ^ (Nat.factorization n p) : ℝ)) :=
        mod_cast Eq.symm (Nat.prod_factorization_pow_eq_self hn_ne_zero)
      simp_all only [div_eq_mul_inv]
      rw [← div_eq_mul_inv, ← Finset.prod_div_distrib]
      refine Finset.prod_congr rfl fun p hp ↦ ?_
      field_simp
      rw [Finset.mul_sum _ _ _, ← Finset.sum_flip]
      exact Finset.sum_congr rfl fun i hi ↦ by
        rw [show ((1:ℝ) / ↑p) ^ i = 1 / ((↑p) ^ i) by simp]
        rw [mul_one_div, eq_div_iff (pow_ne_zero _ <| Nat.cast_ne_zero.mpr <| Nat.ne_of_gt <|
          Nat.pos_of_mem_primeFactors hp), ←pow_add, Nat.sub_add_cancel <|
          Finset.mem_range_succ_iff.mp hi]
    by_cases hM : (witness k c m) = 0 <;> by_cases hL' : c.L' = 0
    · simp_all
    · exact absurd hM (Nat.ne_of_gt (witness_pos k c m hm))
    · exact absurd hL' (Nat.ne_of_gt (Criterion.L'_pos c))
    · simp_all only [ne_eq, one_div, inv_pow, not_false_eq_true, prod_div_distrib]
      rw [mul_div, eq_div_iff]
      · rw [mul_comm, ← Finset.prod_subset (show c.L'.primeFactors ⊆ (witness k c m).primeFactors from ?_)]
        · intro p hp hpn; rw [Nat.factorization_eq_zero_of_not_dvd] <;> aesop
        · intro p hp; simp_all only [mem_primeFactors, ne_eq, not_false_eq_true, and_true, true_and]
          exact dvd_trans hp.2 (by exact ⟨(2^k * ∏ i, c.p i) * m, by rw [witness]; ring⟩)
      · exact Finset.prod_ne_zero_iff.mpr fun p hp ↦ ne_of_gt <| Finset.sum_pos
          (fun _ _ ↦ inv_pos.mpr <| pow_pos (Nat.cast_pos.mpr <| Nat.pos_of_mem_primeFactors hp) _)
          <| by norm_num
  have h_ratio_terms (p : ℕ) (hp : p ∈ Nat.primeFactors (witness k c m)) : (∑ i ∈ Finset.range
      (Nat.factorization (witness k c m) p + 1), (1 / p : ℝ) ^ i) / (∑ i ∈ Finset.range
      (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i) ≥ if p ∈ Finset.image c.p Finset.univ
      then (1 + 1 / (p * (p + 1) : ℝ)) else if p = 2 then (1 + (1-(1/2:ℝ)^k) / (2 * c.n : ℝ)) else 1 := by
    split_ifs
    · obtain ⟨i, hi⟩ : ∃ i : Fin 3, p = c.p i := by grind
      have h_ratio_p_i : (∑ i ∈ Finset.range (Nat.factorization (witness k c m) p + 1), (1 / p : ℝ) ^ i) /
          (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i) ≥
          (∑ i ∈ Finset.range 3, (1 / p : ℝ) ^ i) / (∑ i ∈ Finset.range 2, (1 / p : ℝ) ^ i) := by
        rw [show Nat.factorization (c.L' : ℕ) p = 1 from hi ▸ c.val_p_L' i]
        exact div_le_div_of_nonneg_right (Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono
          (by grind [forced_p k c m hm i])) fun _ _ _ ↦ by positivity)
          (Finset.sum_nonneg fun _ _ ↦ by positivity)
      convert h_ratio_p_i using 1; norm_num [Finset.sum_range_succ]; ring_nf; field_simp; grind
    · have h_geo_series : (∑ i ∈ Finset.range (Nat.factorization (witness k c m) 2 + 1), (1 / 2 : ℝ) ^ i)
          / (∑ i ∈ Finset.range (Nat.factorization c.L' 2 + 1), (1 / 2 : ℝ) ^ i) ≥
          (1 + (1-(1/2:ℝ)^k) / (2 * c.n : ℝ)) := by
        have h_geo_series : (∑ i ∈ Finset.range (Nat.factorization (witness k c m) 2 + 1), (1 / 2 : ℝ) ^ i)
            / (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + 1), (1 / 2 : ℝ) ^ i) ≥
            (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + k + 1), (1 / 2 : ℝ) ^ i) /
            (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) 2 + 1), (1 / 2 : ℝ) ^ i) := by
          exact div_le_div_of_nonneg_right (Finset.sum_le_sum_of_subset_of_nonneg
            (Finset.range_mono (by linarith [forced_two k c m hm])) fun _ _ _ ↦ by positivity)
            (Finset.sum_nonneg fun _ _ ↦ by positivity)
        refine le_trans ?_ h_geo_series
        convert ratio_ge_aux c.n k _ using 1
        exact c.val_two_L'.symm ▸ Nat.pow_log_le_self 2 (by linarith [c.hn])
      aesop
    · rw [ge_iff_le, le_div_iff₀] <;> norm_num
      · refine Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono (Nat.succ_le_succ ?_))
          fun ?_ ?_ ?_ ↦ by positivity
        have h_div : c.L' ∣ (witness k c m) := by
          exact dvd_mul_left _ _
        exact (Nat.factorization_le_iff_dvd (by aesop) (by aesop)) |>.2 h_div p
      · exact Finset.sum_pos (fun _ _ ↦ inv_pos.mpr (pow_pos (Nat.cast_pos.mpr
          (Nat.pos_of_mem_primeFactors hp)) _)) (by norm_num)
  have h_prod_ratio_terms : (∏ p ∈ Nat.primeFactors (witness k c m),
      ((∑ i ∈ Finset.range (Nat.factorization (witness k c m) p + 1), (1 / p : ℝ) ^ i) /
      (∑ i ∈ Finset.range (Nat.factorization (c.L' : ℕ) p + 1), (1 / p : ℝ) ^ i))) ≥
      (∏ p ∈ Finset.image c.p Finset.univ, (1 + 1/(p * (p + 1) : ℝ)))*(1 + (1-(1/2:ℝ)^k) / (2 * c.n : ℝ)) := by
    refine le_trans ?_ (Finset.prod_le_prod₀ ?_ h_ratio_terms)
    · rw [Finset.prod_ite]
      refine mul_le_mul ?_ ?_ (by positivity) (Finset.prod_nonneg fun _ _ ↦ by positivity)
      · rw [Finset.prod_subset]
        · simp only [mem_image, mem_univ, true_and, subset_iff, mem_filter, mem_primeFactors,
            forall_exists_index, forall_apply_eq_imp_iff, exists_apply_eq_apply, and_true]
          intro i; exact ⟨c.hp i, by
            exact dvd_mul_of_dvd_left (dvd_mul_of_dvd_left (dvd_mul_of_dvd_right
              (Finset.dvd_prod_of_mem _ (Finset.mem_univ _)) _) _) _, by
              exact Nat.ne_of_gt (witness_pos k c m hm)⟩
        · aesop
      · rw [Finset.prod_ite]
        by_cases h : 2 ∈ (witness k c m).primeFactors <;> simp_all +decide only
          [mem_primeFactors, true_and, prod_const]
        · simp only [one_pow, mul_one]
          refine le_self_pow₀ (M₀ := ℝ) (by norm_num ; positivity) ?_
          · norm_num; exact ⟨2, Nat.prime_two, h.1, h.2, fun i ↦ by linarith [c.p_gt_two i], rfl⟩
        · contrapose! h
          refine ⟨dvd_mul_of_dvd_left ?_ _, Nat.ne_of_gt (witness_pos k c m hm)⟩
          · exact dvd_mul_of_dvd_left (dvd_mul_of_dvd_left (dvd_pow_self 2 (by omega)) _) _
    · intro p hp; split_ifs <;> positivity
  simp_all
  rw [Finset.prod_image] at h_prod_ratio_terms <;> norm_num [Finset.prod_range_succ] at *
  · simpa only [mul_assoc] using mul_le_mul_of_nonneg_left h_prod_ratio_terms <|
      show 0 ≤ σnorm c.L' by exact div_nonneg (Nat.cast_nonneg _) <| Nat.cast_nonneg _
  · simp [c.hp_mono.injective]

end MultiplicityK
