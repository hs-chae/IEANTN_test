import PowerArithmetic

namespace MultiplicityK
open ArithmeticFunction hiding log
open Finset Nat Real LcmDev
set_option Elab.async false
set_option maxHeartbeats 5000000

noncomputable def scalarLeft (ε : ℝ) : ℝ :=
  ∏ i : Fin 3, (1 + (1.000675 : ℝ) ^ ((i : ℕ) + 1 : ℝ) * ε)
noncomputable def scalarPrefactor (k : ℕ) (ε : ℝ) : ℝ :=
  (∏ i : Fin 3, (1 + ε / (1.000675 : ℝ) ^ (2 * ((i : ℕ) + 1 : ℝ)) *
    (1 / (1 + 1 / 89693)))) * (1 + ((1-(1/2:ℝ)^k)/2) * ε)

/-- A closed scalar polynomial obligation; every application must supply its
ordinary-kernel proof. This is NOT an additional mathematical/source premise. -/
def ScalarCertificate (k : ℕ) (α : ℝ) : Prop :=
  ∀ ε : ℝ, 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ) →
    scalarLeft ε ≤ scalarPrefactor k ε * (1 - (2^k) * (1.000675 : ℝ)^12 * α * ε)

lemma loss_bound (k : ℕ) (α : ℝ) (hα : 0 ≤ α) (hd : Dusart2018.v1.proposition_5_4) {n j : ℕ}
    (hn : 89693^2 ≤ n) (hj : (j+1:ℝ) ≤ α * Real.sqrt n) :
    let C := LcmDev.Criterion.mk' hd hn
    (2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)) ≤
      (2^k) * (1.000675:ℝ)^12 * α*(1/n) := by
  dsimp only [LcmDev.Criterion.mk']
  have hn0 : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0 < 89693^2) hn)
  have hs0 : (0:ℝ) < Real.sqrt n := Real.sqrt_pos.mpr hn0
  have hlpos : 0 < Real.log (Real.sqrt n) := by linarith [hlog hn]
  have hbase :
      (2^k)*(∏ i,((exists_p_primes hd hn).choose i:ℝ))/(∏ i,((exists_q_primes hd hn).choose i:ℝ)) ≤
      (2^k)*(1.000675:ℝ)^12/(n:ℝ)^(3/2:ℝ) := by
    have hh : 1-4*(∏ i,((exists_p_primes hd hn).choose i:ℝ))/(∏ i,((exists_q_primes hd hn).choose i:ℝ)) ≥
        1-4*(1+0.000675:ℝ)^12/(n:ℝ)^(3/2:ℝ) := by
      grw [pq_ratio_ge hd hn, inv_cube_log_sqrt_le hn]
    norm_num at hh
    have hratio : (∏ i,((exists_p_primes hd hn).choose i:ℝ))/(∏ i,((exists_q_primes hd hn).choose i:ℝ)) ≤
        (1.000675:ℝ)^12/(n:ℝ)^(3/2:ℝ) := by
      norm_num [div_eq_mul_inv,mul_assoc] at hh ⊢
      nlinarith only [hh]
    simpa only [mul_div_assoc] using mul_le_mul_of_nonneg_left hratio (show (0:ℝ) ≤ 2^k by positivity)
  calc
    _ = (j+1:ℝ)*((2^k)*(∏ i,((exists_p_primes hd hn).choose i:ℝ))/(∏ i,((exists_q_primes hd hn).choose i:ℝ))) := by ring
    _ ≤ (j+1:ℝ)*((2^k)*(1.000675:ℝ)^12/(n:ℝ)^(3/2:ℝ)) :=
      mul_le_mul_of_nonneg_left hbase (by positivity)
    _ ≤ (α * Real.sqrt n)*((2^k)*(1.000675:ℝ)^12/(n:ℝ)^(3/2:ℝ)) :=
      mul_le_mul_of_nonneg_right hj (by positivity)
    _ = _ := by
      have he : (n:ℝ)^(3/2:ℝ) = (n:ℝ)*Real.sqrt n := by
        rw [show (3/2:ℝ)=1+1/2 by ring,Real.rpow_add hn0,Real.rpow_one,←Real.sqrt_eq_rpow]
      rw [he]
      field_simp
      <;> ring


lemma comparison (k : ℕ) (hk : 1 ≤ k) (α : ℝ) (hα : 0 ≤ α) (hcert : ScalarCertificate k α) (hd : Dusart2018.v1.proposition_5_4) {n j : ℕ}
    (hn : 89693^2 ≤ n) (hj : (j+1:ℝ) ≤ α * Real.sqrt n) :
    let C := LcmDev.Criterion.mk' hd hn
    (∏ i,(1+(1:ℝ)/C.q i)) ≤
      (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+(1-(1/2:ℝ)^k)/(2*(n:ℝ)))*
      (1-(2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) := by
  have hgain : 0 ≤ 1-(1/2:ℝ)^k := sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))
  dsimp only [LcmDev.Criterion.mk']
  have hn0 : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<89693^2) hn)
  have hlpos : 0 < Real.log (Real.sqrt n) := by linarith [hlog hn]
  have h1 : 1-(2^k)*(j+1:ℝ)*(∏ i,((exists_p_primes hd hn).choose i:ℝ))/(∏ i,((exists_q_primes hd hn).choose i:ℝ)) ≥
      1-(2^k) * (1.000675:ℝ)^12 * α*(1/(n:ℝ)) := by
    have hh := loss_bound k α hα hd hn hj
    dsimp only [LcmDev.Criterion.mk'] at hh
    linarith only [hh]
  have hn' : (0:ℝ) ≤ 1/(n:ℝ) ∧ (1:ℝ)/(n:ℝ) ≤ 1/89693^2 :=
    ⟨by positivity,one_div_le_one_div_of_le (by norm_num) (by exact_mod_cast hn)⟩
  have scalar := hcert (1/(n:ℝ)) hn'
  have hleft : 0 < scalarLeft (1/(n:ℝ)) := by
    unfold scalarLeft
    exact Finset.prod_pos fun i _ => by positivity
  have hpre : 0 < scalarPrefactor k (1/(n:ℝ)) := by
    unfold scalarPrefactor
    positivity
  have h0 : 0 ≤ 1-(2^k) * (1.000675:ℝ)^12 * α*(1/(n:ℝ)) := by
    have hpositive : 0 < 1-(2^k) * (1.000675:ℝ)^12 * α*(1/(n:ℝ)) := by
      by_contra hh
      have hnop := mul_nonpos_of_nonneg_of_nonpos hpre.le (le_of_not_gt hh)
      exact (not_le_of_gt hleft) (scalar.trans hnop)
    exact hpositive.le
  have hR := h0.trans h1
  grw [prod_q_ge hd hn,prod_p_ge hd hn,h1]
  simp_rw [div_eq_mul_one_div (_^(_:ℝ):ℝ) (n:ℝ),
    show (1-(1/2:ℝ)^k)/(2*n)=((1-(1/2:ℝ)^k)/2)*(1/n) by field_simp,←one_div_mul_one_div]
  grw [inv_cube_log_sqrt_le hn,inv_n_add_sqrt_ge hn]
  set ε : ℝ := 1/n
  calc
    _ ≤ ∏ i:Fin 3,(1+(1+0.000675:ℝ)^(i+1:ℝ)*ε) := by gcongr
    _ = ∏ i:Fin 3,(1+(1.000675:ℝ)^(i+1:ℝ)*ε) := by norm_num [div_eq_mul_inv]
    _ ≤ _ := hcert ε hn'
    _ = _ := by
      unfold scalarPrefactor
      apply congrArg (fun z:ℝ => z*(1+((1-(1/2:ℝ)^k)/2)*ε)*(1-(2^k) * (1.000675:ℝ)^12 * α*ε))
      apply Finset.prod_congr rfl
      intro i hi
      norm_num
      ring_nf


lemma offset_good (k : ℕ) (hk : 1 ≤ k) (α : ℝ) (hα : 0 ≤ α) (hcert : ScalarCertificate k α) (hd : Dusart2018.v1.proposition_5_4) {n j : ℕ}
    (hn : 89693^2 ≤ n) (hj : (j+1:ℝ) ≤ α * Real.sqrt n) :
    let C := LcmDev.Criterion.mk' hd hn
    0 < witness k C ((quotient k C)-j) ∧ witness k C ((quotient k C)-j) < L n ∧
      (σ (L n):ℝ) < σ (witness k C ((quotient k C)-j)) := by
  have hgain : 0 ≤ 1-(1/2:ℝ)^k := sub_nonneg.mpr (pow_le_one₀ (by norm_num) (by norm_num))
  let C := LcmDev.Criterion.mk' hd hn
  let A : ℕ := (2^k)*∏ i,C.p i
  let Q : ℕ := ∏ i,C.q i
  have hA : 0 < A := mul_pos (by positivity) (Finset.prod_pos fun i _ => (C.hp i).pos)
  have hQ : (0:ℝ) < Q := by exact_mod_cast (Finset.prod_pos fun i _ => (C.hq i).pos)
  have hc := comparison k hk α hα hcert hd hn hj
  change (∏ i,(1+(1:ℝ)/C.q i)) ≤
    (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+(1-(1/2:ℝ)^k)/(2*(n:ℝ)))*
      (1-(2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) at hc
  have hn0 : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0<89693^2) hn)
  have hR : 0 < 1-(2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)) := by
    have hleft : 0 < ∏ i,(1+(1:ℝ)/C.q i) := Finset.prod_pos fun i _ => by positivity
    have hpre : 0 < (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+(1-(1/2:ℝ)^k)/(2*(n:ℝ))) := by positivity
    by_contra hh
    have hh' := mul_nonpos_of_nonneg_of_nonpos hpre.le (le_of_not_gt hh)
    linarith only [hc,hleft,hh']
  have hAJ : A*(j+1) < Q := by
    rw [sub_pos,div_lt_one (by simpa [Q] using hQ)] at hR
    dsimp [A,Q]
    have hh : (2^k)*(j+1)*(∏ i,C.p i) < ∏ i,C.q i := by exact_mod_cast hR
    simpa [Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using hh
  have hjm : j < quotient k C := by
    have hm : j+1 ≤ Q/A := (Nat.le_div_iff_mul_le hA).mpr (by simpa [Nat.mul_comm] using hAJ.le)
    exact lt_of_lt_of_le (Nat.lt_succ_self j) hm
  have hmpos : 0 < quotient k C-j := Nat.sub_pos_of_lt hjm
  have hwpos := witness_pos k C (quotient k C-j) hmpos
  have hwsmall : witness k C ((quotient k C)-j) < L n := by
    have hh : witness k C ((quotient k C)-j) ≤ witness k C (quotient k C) :=
      Nat.mul_le_mul_right C.L' (Nat.mul_le_mul_left A (Nat.sub_le (quotient k C) j))
    exact hh.trans_lt (maximum_lt k C)
  refine ⟨hwpos,hwsmall,?_⟩
  have hLp : (0:ℝ) < L C.n := by exact_mod_cast C.L_pos
  have hWp : (0:ℝ) < witness k C ((quotient k C)-j) := by exact_mod_cast hwpos
  have hLp' : (C.L':ℝ) ≠ 0 := by exact_mod_cast C.L'_pos.ne'
  have hQp : (0:ℝ) < ∏ i,(C.q i:ℝ) := by simpa [Q] using hQ
  have hratio : (witness k C ((quotient k C)-j):ℝ)/(L C.n) = (A:ℝ)*(((quotient k C)-j:ℕ):ℝ)/Q := by
    rw [C.L_eq_prod_q_mul_L']
    dsimp [witness,A,Q]
    push_cast
    field_simp [hLp',ne_of_gt hQp]
    <;> ring
  have hround : 1-(2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)) <
      (witness k C ((quotient k C)-j):ℝ)/(L C.n) := by
    rw [hratio]
    apply (lt_div_iff₀ hQ).mpr
    have hmod : (Q:ℝ) = (A:ℝ)*quotient k C+remainder k C := by exact_mod_cast div_identity k C
    have hr : (remainder k C:ℝ) < A := by exact_mod_cast remainder_lt k C
    have hsub : (((quotient k C)-j:ℕ):ℝ) = (quotient k C:ℝ)-j := Nat.cast_sub hjm.le
    have heq : (1-(2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))*(Q:ℝ) =
        (Q:ℝ)-(A:ℝ)*(j+1) := by
      dsimp [A,Q]
      push_cast
      field_simp [ne_of_gt hQp]
      <;> ring
    rw [heq,hsub]
    nlinarith only [hmod,hr]
  have hsigp : 0 < σnorm (witness k C ((quotient k C)-j)) := by
    unfold σnorm
    exact div_pos (by exact_mod_cast (show 0 < σ (witness k C ((quotient k C)-j)) by rw [σ,sigma_pos_iff]; exact hwpos)) hWp
  have hsig : σnorm (L C.n) ≤ σnorm (witness k C ((quotient k C)-j))*
      (1-(2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) := by
    rw [C.σnorm_ln_eq]
    have hb := sigma_lower k hk C (quotient k C-j) hmpos
    have hs : 0 ≤ σnorm C.L' := by unfold σnorm; positivity
    change σnorm (witness k C ((quotient k C)-j)) ≥ σnorm C.L'*
      (∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+(1-(1/2:ℝ)^k)/(2*(n:ℝ))) at hb
    calc
      _ ≤ σnorm C.L'*((∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+(1-(1/2:ℝ)^k)/(2*(n:ℝ)))*
          (1-(2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ)))) :=
        mul_le_mul_of_nonneg_left hc hs
      _ = (σnorm C.L'*(∏ i,(1+1/(C.p i*(C.p i+1):ℝ)))*(1+(1-(1/2:ℝ)^k)/(2*(n:ℝ))))*
          (1-(2^k)*(j+1:ℝ)*(∏ i,(C.p i:ℝ))/(∏ i,(C.q i:ℝ))) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hb hR.le

  have hfinal := hsig.trans_lt (mul_lt_mul_of_pos_left hround hsigp)
  have heq : σnorm (witness k C ((quotient k C)-j))*((witness k C ((quotient k C)-j):ℝ)/(L C.n)) =
      (σ (witness k C ((quotient k C)-j)):ℝ)/(L C.n) := by
    unfold σnorm
    field_simp
  rw [heq] at hfinal
  exact (div_lt_div_iff_of_pos_right hLp).mp hfinal



end MultiplicityK
