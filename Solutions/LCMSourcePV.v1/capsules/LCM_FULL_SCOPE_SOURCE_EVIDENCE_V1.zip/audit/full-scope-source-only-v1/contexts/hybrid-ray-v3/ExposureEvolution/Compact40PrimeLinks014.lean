import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks014
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_39229 : next 39229 = some 39373 := by
  have hl : (List.range ((257 * 39229 - 1) / 256 - 39229)).reverse =
      [152, 151, 150, 149, 148, 147, 146, 145, 144, 143] ++ (List.range 143).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_39373]

theorem next_39373 : next 39373 = some 39521 := by
  have hl : (List.range ((257 * 39373 - 1) / 256 - 39373)).reverse =
      [152, 151, 150, 149, 148, 147] ++ (List.range 147).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_39521]

theorem next_39521 : next 39521 = some 39671 := by
  have hl : (List.range ((257 * 39521 - 1) / 256 - 39521)).reverse =
      [153, 152, 151, 150, 149] ++ (List.range 149).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_39671]

theorem next_39671 : next 39671 = some 39821 := by
  have hl : (List.range ((257 * 39671 - 1) / 256 - 39671)).reverse =
      [153, 152, 151, 150, 149] ++ (List.range 149).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_39821]

theorem next_39821 : next 39821 = some 39971 := by
  have hl : (List.range ((257 * 39821 - 1) / 256 - 39821)).reverse =
      [154, 153, 152, 151, 150, 149] ++ (List.range 149).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_39971]

theorem next_39971 : next 39971 = some 40127 := by
  have hl : (List.range ((257 * 39971 - 1) / 256 - 39971)).reverse =
      [155] ++ (List.range 155).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_40127]

theorem next_40127 : next 40127 = some 40283 := by
  have hl : (List.range ((257 * 40127 - 1) / 256 - 40127)).reverse =
      [155] ++ (List.range 155).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_40283]

theorem next_40283 : next 40283 = some 40433 := by
  have hl : (List.range ((257 * 40283 - 1) / 256 - 40283)).reverse =
      [156, 155, 154, 153, 152, 151, 150, 149] ++ (List.range 149).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_40433]

theorem next_40433 : next 40433 = some 40583 := by
  have hl : (List.range ((257 * 40433 - 1) / 256 - 40433)).reverse =
      [156, 155, 154, 153, 152, 151, 150, 149] ++ (List.range 149).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_40583]

theorem next_40583 : next 40583 = some 40739 := by
  have hl : (List.range ((257 * 40583 - 1) / 256 - 40583)).reverse =
      [157, 156, 155] ++ (List.range 155).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_40739]

theorem next_40739 : next 40739 = some 40897 := by
  have hl : (List.range ((257 * 40739 - 1) / 256 - 40739)).reverse =
      [158, 157] ++ (List.range 157).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_40897]

theorem next_40897 : next 40897 = some 41051 := by
  have hl : (List.range ((257 * 40897 - 1) / 256 - 40897)).reverse =
      [158, 157, 156, 155, 154, 153] ++ (List.range 153).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_41051]

theorem next_41051 : next 41051 = some 41203 := by
  have hl : (List.range ((257 * 41051 - 1) / 256 - 41051)).reverse =
      [159, 158, 157, 156, 155, 154, 153, 152, 151] ++ (List.range 151).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_41203]

theorem next_41203 : next 41203 = some 41357 := by
  have hl : (List.range ((257 * 41203 - 1) / 256 - 41203)).reverse =
      [159, 158, 157, 156, 155, 154, 153] ++ (List.range 153).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_41357]

theorem next_41357 : next 41357 = some 41513 := by
  have hl : (List.range ((257 * 41357 - 1) / 256 - 41357)).reverse =
      [160, 159, 158, 157, 156, 155] ++ (List.range 155).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_41513]

theorem next_41513 : next 41513 = some 41669 := by
  have hl : (List.range ((257 * 41513 - 1) / 256 - 41513)).reverse =
      [161, 160, 159, 158, 157, 156, 155] ++ (List.range 155).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_41669]

theorem next_41669 : next 41669 = some 41813 := by
  have hl : (List.range ((257 * 41669 - 1) / 256 - 41669)).reverse =
      [161, 160, 159, 158, 157, 156, 155, 154, 153, 152, 151, 150, 149, 148, 147, 146, 145, 144, 143] ++ (List.range 143).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_41813]

theorem next_41813 : next 41813 = some 41969 := by
  have hl : (List.range ((257 * 41813 - 1) / 256 - 41813)).reverse =
      [162, 161, 160, 159, 158, 157, 156, 155] ++ (List.range 155).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_41969]

theorem next_41969 : next 41969 = some 42131 := by
  have hl : (List.range ((257 * 41969 - 1) / 256 - 41969)).reverse =
      [162, 161] ++ (List.range 161).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_42131]

theorem next_42131 : next 42131 = some 42293 := by
  have hl : (List.range ((257 * 42131 - 1) / 256 - 42131)).reverse =
      [163, 162, 161] ++ (List.range 161).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_42293]

theorem next_42293 : next 42293 = some 42457 := by
  have hl : (List.range ((257 * 42293 - 1) / 256 - 42293)).reverse =
      [164, 163] ++ (List.range 163).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_42457]

theorem next_42457 : next 42457 = some 42611 := by
  have hl : (List.range ((257 * 42457 - 1) / 256 - 42457)).reverse =
      [164, 163, 162, 161, 160, 159, 158, 157, 156, 155, 154, 153] ++ (List.range 153).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_42611]

theorem next_42611 : next 42611 = some 42773 := by
  have hl : (List.range ((257 * 42611 - 1) / 256 - 42611)).reverse =
      [165, 164, 163, 162, 161] ++ (List.range 161).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_42773]

theorem next_42773 : next 42773 = some 42937 := by
  have hl : (List.range ((257 * 42773 - 1) / 256 - 42773)).reverse =
      [166, 165, 164, 163] ++ (List.range 163).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_42937]

theorem next_42937 : next 42937 = some 43103 := by
  have hl : (List.range ((257 * 42937 - 1) / 256 - 42937)).reverse =
      [166, 165] ++ (List.range 165).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_43103]

theorem next_43103 : next 43103 = some 43271 := by
  have hl : (List.range ((257 * 43103 - 1) / 256 - 43103)).reverse =
      [167] ++ (List.range 167).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_43271]

theorem next_43271 : next 43271 = some 43427 := by
  have hl : (List.range ((257 * 43271 - 1) / 256 - 43271)).reverse =
      [168, 167, 166, 165, 164, 163, 162, 161, 160, 159, 158, 157, 156, 155] ++ (List.range 155).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_43427]

theorem next_43427 : next 43427 = some 43591 := by
  have hl : (List.range ((257 * 43427 - 1) / 256 - 43427)).reverse =
      [168, 167, 166, 165, 164, 163] ++ (List.range 163).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_43591]

theorem next_43591 : next 43591 = some 43759 := by
  have hl : (List.range ((257 * 43591 - 1) / 256 - 43591)).reverse =
      [169, 168, 167] ++ (List.range 167).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_43759]

theorem next_43759 : next 43759 = some 43913 := by
  have hl : (List.range ((257 * 43759 - 1) / 256 - 43759)).reverse =
      [169, 168, 167, 166, 165, 164, 163, 162, 161, 160, 159, 158, 157, 156, 155, 154, 153] ++ (List.range 153).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_43913]

theorem next_43913 : next 43913 = some 44071 := by
  have hl : (List.range ((257 * 43913 - 1) / 256 - 43913)).reverse =
      [170, 169, 168, 167, 166, 165, 164, 163, 162, 161, 160, 159, 158, 157] ++ (List.range 157).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_44071]

theorem next_44071 : next 44071 = some 44221 := by
  have hl : (List.range ((257 * 44071 - 1) / 256 - 44071)).reverse =
      [171, 170, 169, 168, 167, 166, 165, 164, 163, 162, 161, 160, 159, 158, 157, 156, 155, 154, 153, 152, 151, 150, 149] ++ (List.range 149).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_44221]

def primes : List ℕ := [39373, 39521, 39671, 39821, 39971, 40127, 40283, 40433, 40583, 40739, 40897, 41051, 41203, 41357, 41513, 41669, 41813, 41969, 42131, 42293, 42457, 42611, 42773, 42937, 43103, 43271, 43427, 43591, 43759, 43913, 44071, 44221]

theorem segment : run 252 39229 89693 =
    primes ++ run 220 44221 89693 := by
  rw [Compact40PrimeCompose256.step 251 39229 89693 39373
    (by decide +kernel) next_39229]
  rw [Compact40PrimeCompose256.step 250 39373 89693 39521
    (by decide +kernel) next_39373]
  rw [Compact40PrimeCompose256.step 249 39521 89693 39671
    (by decide +kernel) next_39521]
  rw [Compact40PrimeCompose256.step 248 39671 89693 39821
    (by decide +kernel) next_39671]
  rw [Compact40PrimeCompose256.step 247 39821 89693 39971
    (by decide +kernel) next_39821]
  rw [Compact40PrimeCompose256.step 246 39971 89693 40127
    (by decide +kernel) next_39971]
  rw [Compact40PrimeCompose256.step 245 40127 89693 40283
    (by decide +kernel) next_40127]
  rw [Compact40PrimeCompose256.step 244 40283 89693 40433
    (by decide +kernel) next_40283]
  rw [Compact40PrimeCompose256.step 243 40433 89693 40583
    (by decide +kernel) next_40433]
  rw [Compact40PrimeCompose256.step 242 40583 89693 40739
    (by decide +kernel) next_40583]
  rw [Compact40PrimeCompose256.step 241 40739 89693 40897
    (by decide +kernel) next_40739]
  rw [Compact40PrimeCompose256.step 240 40897 89693 41051
    (by decide +kernel) next_40897]
  rw [Compact40PrimeCompose256.step 239 41051 89693 41203
    (by decide +kernel) next_41051]
  rw [Compact40PrimeCompose256.step 238 41203 89693 41357
    (by decide +kernel) next_41203]
  rw [Compact40PrimeCompose256.step 237 41357 89693 41513
    (by decide +kernel) next_41357]
  rw [Compact40PrimeCompose256.step 236 41513 89693 41669
    (by decide +kernel) next_41513]
  rw [Compact40PrimeCompose256.step 235 41669 89693 41813
    (by decide +kernel) next_41669]
  rw [Compact40PrimeCompose256.step 234 41813 89693 41969
    (by decide +kernel) next_41813]
  rw [Compact40PrimeCompose256.step 233 41969 89693 42131
    (by decide +kernel) next_41969]
  rw [Compact40PrimeCompose256.step 232 42131 89693 42293
    (by decide +kernel) next_42131]
  rw [Compact40PrimeCompose256.step 231 42293 89693 42457
    (by decide +kernel) next_42293]
  rw [Compact40PrimeCompose256.step 230 42457 89693 42611
    (by decide +kernel) next_42457]
  rw [Compact40PrimeCompose256.step 229 42611 89693 42773
    (by decide +kernel) next_42611]
  rw [Compact40PrimeCompose256.step 228 42773 89693 42937
    (by decide +kernel) next_42773]
  rw [Compact40PrimeCompose256.step 227 42937 89693 43103
    (by decide +kernel) next_42937]
  rw [Compact40PrimeCompose256.step 226 43103 89693 43271
    (by decide +kernel) next_43103]
  rw [Compact40PrimeCompose256.step 225 43271 89693 43427
    (by decide +kernel) next_43271]
  rw [Compact40PrimeCompose256.step 224 43427 89693 43591
    (by decide +kernel) next_43427]
  rw [Compact40PrimeCompose256.step 223 43591 89693 43759
    (by decide +kernel) next_43591]
  rw [Compact40PrimeCompose256.step 222 43759 89693 43913
    (by decide +kernel) next_43759]
  rw [Compact40PrimeCompose256.step 221 43913 89693 44071
    (by decide +kernel) next_43913]
  rw [Compact40PrimeCompose256.step 220 44071 89693 44221
    (by decide +kernel) next_44071]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 44221 stop tail = true) :
    check 39229 stop (primes ++ tail) = true := by
  change check _ _ (39373 :: 39521 :: 39671 :: 39821 :: 39971 :: 40127 :: 40283 :: 40433 :: 40583 :: 40739 :: 40897 :: 41051 :: 41203 :: 41357 :: 41513 :: 41669 :: 41813 :: 41969 :: 42131 :: 42293 :: 42457 :: 42611 :: 42773 :: 42937 :: 43103 :: 43271 :: 43427 :: 43591 :: 43759 :: 43913 :: 44071 :: 44221 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_39373, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_39521, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_39671, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_39821, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_39971, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_40127, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_40283, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_40433, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_40583, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_40739, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_40897, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_41051, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_41203, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_41357, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_41513, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_41669, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_41813, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_41969, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_42131, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_42293, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_42457, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_42611, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_42773, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_42937, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_43103, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_43271, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_43427, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_43591, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_43759, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_43913, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_44071, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_44221, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks014
