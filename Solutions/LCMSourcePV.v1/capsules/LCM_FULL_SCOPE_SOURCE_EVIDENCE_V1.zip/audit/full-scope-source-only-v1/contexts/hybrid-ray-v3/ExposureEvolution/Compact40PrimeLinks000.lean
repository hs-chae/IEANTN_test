import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks000
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_8468 : next 8468 = some 8501 := by
  have hl : (List.range ((257 * 8468 - 1) / 256 - 8468)).reverse =
      [32] ++ (List.range 32).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8501]

theorem next_8501 : next 8501 = some 8527 := by
  have hl : (List.range ((257 * 8501 - 1) / 256 - 8501)).reverse =
      [32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8527]

theorem next_8527 : next 8527 = some 8543 := by
  have hl : (List.range ((257 * 8527 - 1) / 256 - 8527)).reverse =
      [32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15] ++ (List.range 15).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8543]

theorem next_8543 : next 8543 = some 8573 := by
  have hl : (List.range ((257 * 8543 - 1) / 256 - 8543)).reverse =
      [32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8573]

theorem next_8573 : next 8573 = some 8599 := by
  have hl : (List.range ((257 * 8573 - 1) / 256 - 8573)).reverse =
      [32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8599]

theorem next_8599 : next 8599 = some 8629 := by
  have hl : (List.range ((257 * 8599 - 1) / 256 - 8599)).reverse =
      [32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8629]

theorem next_8629 : next 8629 = some 8647 := by
  have hl : (List.range ((257 * 8629 - 1) / 256 - 8629)).reverse =
      [32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17] ++ (List.range 17).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8647]

theorem next_8647 : next 8647 = some 8677 := by
  have hl : (List.range ((257 * 8647 - 1) / 256 - 8647)).reverse =
      [32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8677]

theorem next_8677 : next 8677 = some 8707 := by
  have hl : (List.range ((257 * 8677 - 1) / 256 - 8677)).reverse =
      [32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8707]

theorem next_8707 : next 8707 = some 8741 := by
  have hl : (List.range ((257 * 8707 - 1) / 256 - 8707)).reverse =
      [33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8741]

theorem next_8741 : next 8741 = some 8761 := by
  have hl : (List.range ((257 * 8741 - 1) / 256 - 8741)).reverse =
      [33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19] ++ (List.range 19).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8761]

theorem next_8761 : next 8761 = some 8783 := by
  have hl : (List.range ((257 * 8761 - 1) / 256 - 8761)).reverse =
      [33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21] ++ (List.range 21).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8783]

theorem next_8783 : next 8783 = some 8807 := by
  have hl : (List.range ((257 * 8783 - 1) / 256 - 8783)).reverse =
      [33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8807]

theorem next_8807 : next 8807 = some 8839 := by
  have hl : (List.range ((257 * 8807 - 1) / 256 - 8807)).reverse =
      [33, 32, 31] ++ (List.range 31).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8839]

theorem next_8839 : next 8839 = some 8867 := by
  have hl : (List.range ((257 * 8839 - 1) / 256 - 8839)).reverse =
      [33, 32, 31, 30, 29, 28, 27] ++ (List.range 27).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8867]

theorem next_8867 : next 8867 = some 8893 := by
  have hl : (List.range ((257 * 8867 - 1) / 256 - 8867)).reverse =
      [33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8893]

theorem next_8893 : next 8893 = some 8923 := by
  have hl : (List.range ((257 * 8893 - 1) / 256 - 8893)).reverse =
      [33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8923]

theorem next_8923 : next 8923 = some 8951 := by
  have hl : (List.range ((257 * 8923 - 1) / 256 - 8923)).reverse =
      [33, 32, 31, 30, 29, 28, 27] ++ (List.range 27).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8951]

theorem next_8951 : next 8951 = some 8971 := by
  have hl : (List.range ((257 * 8951 - 1) / 256 - 8951)).reverse =
      [33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19] ++ (List.range 19).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_8971]

theorem next_8971 : next 8971 = some 9001 := by
  have hl : (List.range ((257 * 8971 - 1) / 256 - 8971)).reverse =
      [34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9001]

theorem next_9001 : next 9001 = some 9029 := by
  have hl : (List.range ((257 * 9001 - 1) / 256 - 9001)).reverse =
      [34, 33, 32, 31, 30, 29, 28, 27] ++ (List.range 27).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9029]

theorem next_9029 : next 9029 = some 9059 := by
  have hl : (List.range ((257 * 9029 - 1) / 256 - 9029)).reverse =
      [34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9059]

theorem next_9059 : next 9059 = some 9091 := by
  have hl : (List.range ((257 * 9059 - 1) / 256 - 9059)).reverse =
      [34, 33, 32, 31] ++ (List.range 31).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9091]

theorem next_9091 : next 9091 = some 9109 := by
  have hl : (List.range ((257 * 9091 - 1) / 256 - 9091)).reverse =
      [34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17] ++ (List.range 17).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9109]

theorem next_9109 : next 9109 = some 9137 := by
  have hl : (List.range ((257 * 9109 - 1) / 256 - 9109)).reverse =
      [34, 33, 32, 31, 30, 29, 28, 27] ++ (List.range 27).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9137]

theorem next_9137 : next 9137 = some 9161 := by
  have hl : (List.range ((257 * 9137 - 1) / 256 - 9137)).reverse =
      [34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9161]

theorem next_9161 : next 9161 = some 9187 := by
  have hl : (List.range ((257 * 9161 - 1) / 256 - 9161)).reverse =
      [34, 33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9187]

theorem next_9187 : next 9187 = some 9221 := by
  have hl : (List.range ((257 * 9187 - 1) / 256 - 9187)).reverse =
      [34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9221]

theorem next_9221 : next 9221 = some 9257 := by
  have hl : (List.range ((257 * 9221 - 1) / 256 - 9221)).reverse =
      [35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9257]

theorem next_9257 : next 9257 = some 9293 := by
  have hl : (List.range ((257 * 9257 - 1) / 256 - 9257)).reverse =
      [35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9293]

theorem next_9293 : next 9293 = some 9323 := by
  have hl : (List.range ((257 * 9293 - 1) / 256 - 9293)).reverse =
      [35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9323]

theorem next_9323 : next 9323 = some 9349 := by
  have hl : (List.range ((257 * 9323 - 1) / 256 - 9323)).reverse =
      [35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9349]

def primes : List ℕ := [8501, 8527, 8543, 8573, 8599, 8629, 8647, 8677, 8707, 8741, 8761, 8783, 8807, 8839, 8867, 8893, 8923, 8951, 8971, 9001, 9029, 9059, 9091, 9109, 9137, 9161, 9187, 9221, 9257, 9293, 9323, 9349]

theorem segment : run 700 8468 89693 =
    primes ++ run 668 9349 89693 := by
  rw [Compact40PrimeCompose256.step 699 8468 89693 8501
    (by decide +kernel) next_8468]
  rw [Compact40PrimeCompose256.step 698 8501 89693 8527
    (by decide +kernel) next_8501]
  rw [Compact40PrimeCompose256.step 697 8527 89693 8543
    (by decide +kernel) next_8527]
  rw [Compact40PrimeCompose256.step 696 8543 89693 8573
    (by decide +kernel) next_8543]
  rw [Compact40PrimeCompose256.step 695 8573 89693 8599
    (by decide +kernel) next_8573]
  rw [Compact40PrimeCompose256.step 694 8599 89693 8629
    (by decide +kernel) next_8599]
  rw [Compact40PrimeCompose256.step 693 8629 89693 8647
    (by decide +kernel) next_8629]
  rw [Compact40PrimeCompose256.step 692 8647 89693 8677
    (by decide +kernel) next_8647]
  rw [Compact40PrimeCompose256.step 691 8677 89693 8707
    (by decide +kernel) next_8677]
  rw [Compact40PrimeCompose256.step 690 8707 89693 8741
    (by decide +kernel) next_8707]
  rw [Compact40PrimeCompose256.step 689 8741 89693 8761
    (by decide +kernel) next_8741]
  rw [Compact40PrimeCompose256.step 688 8761 89693 8783
    (by decide +kernel) next_8761]
  rw [Compact40PrimeCompose256.step 687 8783 89693 8807
    (by decide +kernel) next_8783]
  rw [Compact40PrimeCompose256.step 686 8807 89693 8839
    (by decide +kernel) next_8807]
  rw [Compact40PrimeCompose256.step 685 8839 89693 8867
    (by decide +kernel) next_8839]
  rw [Compact40PrimeCompose256.step 684 8867 89693 8893
    (by decide +kernel) next_8867]
  rw [Compact40PrimeCompose256.step 683 8893 89693 8923
    (by decide +kernel) next_8893]
  rw [Compact40PrimeCompose256.step 682 8923 89693 8951
    (by decide +kernel) next_8923]
  rw [Compact40PrimeCompose256.step 681 8951 89693 8971
    (by decide +kernel) next_8951]
  rw [Compact40PrimeCompose256.step 680 8971 89693 9001
    (by decide +kernel) next_8971]
  rw [Compact40PrimeCompose256.step 679 9001 89693 9029
    (by decide +kernel) next_9001]
  rw [Compact40PrimeCompose256.step 678 9029 89693 9059
    (by decide +kernel) next_9029]
  rw [Compact40PrimeCompose256.step 677 9059 89693 9091
    (by decide +kernel) next_9059]
  rw [Compact40PrimeCompose256.step 676 9091 89693 9109
    (by decide +kernel) next_9091]
  rw [Compact40PrimeCompose256.step 675 9109 89693 9137
    (by decide +kernel) next_9109]
  rw [Compact40PrimeCompose256.step 674 9137 89693 9161
    (by decide +kernel) next_9137]
  rw [Compact40PrimeCompose256.step 673 9161 89693 9187
    (by decide +kernel) next_9161]
  rw [Compact40PrimeCompose256.step 672 9187 89693 9221
    (by decide +kernel) next_9187]
  rw [Compact40PrimeCompose256.step 671 9221 89693 9257
    (by decide +kernel) next_9221]
  rw [Compact40PrimeCompose256.step 670 9257 89693 9293
    (by decide +kernel) next_9257]
  rw [Compact40PrimeCompose256.step 669 9293 89693 9323
    (by decide +kernel) next_9293]
  rw [Compact40PrimeCompose256.step 668 9323 89693 9349
    (by decide +kernel) next_9323]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 9349 stop tail = true) :
    check 8468 stop (primes ++ tail) = true := by
  change check _ _ (8501 :: 8527 :: 8543 :: 8573 :: 8599 :: 8629 :: 8647 :: 8677 :: 8707 :: 8741 :: 8761 :: 8783 :: 8807 :: 8839 :: 8867 :: 8893 :: 8923 :: 8951 :: 8971 :: 9001 :: 9029 :: 9059 :: 9091 :: 9109 :: 9137 :: 9161 :: 9187 :: 9221 :: 9257 :: 9293 :: 9323 :: 9349 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8501, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8527, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8543, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8573, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8599, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8629, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8647, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8677, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8707, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8741, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8761, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8783, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8807, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8839, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8867, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8893, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8923, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8951, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_8971, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9001, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9029, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9059, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9091, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9109, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9137, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9161, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9187, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9221, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9257, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9293, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9323, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9349, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks000
