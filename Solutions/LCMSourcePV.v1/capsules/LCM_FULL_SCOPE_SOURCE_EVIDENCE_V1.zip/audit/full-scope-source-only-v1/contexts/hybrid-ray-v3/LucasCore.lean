import PartialFactor

namespace Round2Recovery
open PartialFactor

/-- The exact full-factor Lucas/Pratt test used by the locked C001/C004 code. -/
theorem lucas_list_prime {n a : ℕ} {factors : List ℕ} (hn : 1 < n)
    (hprimes : ∀ q ∈ factors, Nat.Prime q) (hprod : factors.prod = n - 1)
    (hpow : modPow a (n - 1) n = 1)
    (hcop : ∀ q ∈ factors, (modPow a ((n - 1) / q) n + n - 1).Coprime n) :
    Nat.Prime n := by
  apply lucas_primality n (a : ZMod n)
  · rw [← modPow_cast, hpow]
    simp
  · intro q hq hqd heq
    have hmem : q ∈ factors := mem_list_primes_of_dvd_prod hq.prime
      (fun q hq => (hprimes q hq).prime) (hprod.symm ▸ hqd)
    have hc := hcop q hmem
    have hm : modPow a ((n - 1) / q) n = 1 := by
      rw [modPow_eq]
      have hz : ((a ^ ((n - 1) / q) : ℕ) : ZMod n) = (1 : ℕ) := by
        simpa only [Nat.cast_pow, Nat.cast_one] using heq
      have hmod := (ZMod.natCast_eq_natCast_iff' _ _ n).mp hz
      simpa only [Nat.mod_eq_of_lt hn] using hmod
    rw [hm] at hc
    have hh : 1 + n - 1 = n := by omega
    rw [hh] at hc
    have := hc.gcd_eq_one
    simp only [Nat.gcd_self] at this
    omega

end Round2Recovery

#print axioms Round2Recovery.lucas_list_prime
