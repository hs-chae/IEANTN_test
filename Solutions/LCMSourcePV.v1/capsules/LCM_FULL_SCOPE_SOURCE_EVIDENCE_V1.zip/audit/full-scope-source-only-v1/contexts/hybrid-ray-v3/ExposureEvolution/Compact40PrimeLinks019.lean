import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks019
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_71293 : next 71293 = some 71569 := by
  have hl : (List.range ((257 * 71293 - 1) / 256 - 71293)).reverse =
      [277, 276, 275] ++ (List.range 275).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_71569]

theorem next_71569 : next 71569 = some 71843 := by
  have hl : (List.range ((257 * 71569 - 1) / 256 - 71569)).reverse =
      [278, 277, 276, 275, 274, 273] ++ (List.range 273).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_71843]

theorem next_71843 : next 71843 = some 72109 := by
  have hl : (List.range ((257 * 71843 - 1) / 256 - 71843)).reverse =
      [279, 278, 277, 276, 275, 274, 273, 272, 271, 270, 269, 268, 267, 266, 265] ++ (List.range 265).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_72109]

theorem next_72109 : next 72109 = some 72383 := by
  have hl : (List.range ((257 * 72109 - 1) / 256 - 72109)).reverse =
      [280, 279, 278, 277, 276, 275, 274, 273] ++ (List.range 273).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_72383]

theorem next_72383 : next 72383 = some 72661 := by
  have hl : (List.range ((257 * 72383 - 1) / 256 - 72383)).reverse =
      [281, 280, 279, 278, 277] ++ (List.range 277).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_72661]

theorem next_72661 : next 72661 = some 72937 := by
  have hl : (List.range ((257 * 72661 - 1) / 256 - 72661)).reverse =
      [282, 281, 280, 279, 278, 277, 276, 275] ++ (List.range 275).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_72937]

theorem next_72937 : next 72937 = some 73189 := by
  have hl : (List.range ((257 * 72937 - 1) / 256 - 72937)).reverse =
      [283, 282, 281, 280, 279, 278, 277, 276, 275, 274, 273, 272, 271, 270, 269, 268, 267, 266, 265, 264, 263, 262, 261, 260, 259, 258, 257, 256, 255, 254, 253, 252, 251] ++ (List.range 251).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_73189]

theorem next_73189 : next 73189 = some 73471 := by
  have hl : (List.range ((257 * 73189 - 1) / 256 - 73189)).reverse =
      [284, 283, 282, 281] ++ (List.range 281).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_73471]

theorem next_73471 : next 73471 = some 73757 := by
  have hl : (List.range ((257 * 73471 - 1) / 256 - 73471)).reverse =
      [285] ++ (List.range 285).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_73757]

theorem next_73757 : next 73757 = some 74027 := by
  have hl : (List.range ((257 * 73757 - 1) / 256 - 73757)).reverse =
      [287, 286, 285, 284, 283, 282, 281, 280, 279, 278, 277, 276, 275, 274, 273, 272, 271, 270, 269] ++ (List.range 269).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_74027]

theorem next_74027 : next 74027 = some 74311 := by
  have hl : (List.range ((257 * 74027 - 1) / 256 - 74027)).reverse =
      [288, 287, 286, 285, 284, 283] ++ (List.range 283).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_74311]

theorem next_74311 : next 74311 = some 74597 := by
  have hl : (List.range ((257 * 74311 - 1) / 256 - 74311)).reverse =
      [289, 288, 287, 286, 285] ++ (List.range 285).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_74597]

theorem next_74597 : next 74597 = some 74887 := by
  have hl : (List.range ((257 * 74597 - 1) / 256 - 74597)).reverse =
      [290, 289] ++ (List.range 289).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_74887]

theorem next_74887 : next 74887 = some 75169 := by
  have hl : (List.range ((257 * 74887 - 1) / 256 - 74887)).reverse =
      [291, 290, 289, 288, 287, 286, 285, 284, 283, 282, 281] ++ (List.range 281).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_75169]

theorem next_75169 : next 75169 = some 75437 := by
  have hl : (List.range ((257 * 75169 - 1) / 256 - 75169)).reverse =
      [292, 291, 290, 289, 288, 287, 286, 285, 284, 283, 282, 281, 280, 279, 278, 277, 276, 275, 274, 273, 272, 271, 270, 269, 268, 267] ++ (List.range 267).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_75437]

theorem next_75437 : next 75437 = some 75731 := by
  have hl : (List.range ((257 * 75437 - 1) / 256 - 75437)).reverse =
      [293] ++ (List.range 293).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_75731]

theorem next_75731 : next 75731 = some 76003 := by
  have hl : (List.range ((257 * 75731 - 1) / 256 - 75731)).reverse =
      [294, 293, 292, 291, 290, 289, 288, 287, 286, 285, 284, 283, 282, 281, 280, 279, 278, 277, 276, 275, 274, 273, 272, 271] ++ (List.range 271).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_76003]

theorem next_76003 : next 76003 = some 76289 := by
  have hl : (List.range ((257 * 76003 - 1) / 256 - 76003)).reverse =
      [295, 294, 293, 292, 291, 290, 289, 288, 287, 286, 285] ++ (List.range 285).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_76289]

theorem next_76289 : next 76289 = some 76579 := by
  have hl : (List.range ((257 * 76289 - 1) / 256 - 76289)).reverse =
      [297, 296, 295, 294, 293, 292, 291, 290, 289] ++ (List.range 289).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_76579]

theorem next_76579 : next 76579 = some 76873 := by
  have hl : (List.range ((257 * 76579 - 1) / 256 - 76579)).reverse =
      [298, 297, 296, 295, 294, 293] ++ (List.range 293).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_76873]

theorem next_76873 : next 76873 = some 77171 := by
  have hl : (List.range ((257 * 76873 - 1) / 256 - 76873)).reverse =
      [299, 298, 297] ++ (List.range 297).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_77171]

theorem next_77171 : next 77171 = some 77471 := by
  have hl : (List.range ((257 * 77171 - 1) / 256 - 77171)).reverse =
      [300, 299] ++ (List.range 299).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_77471]

theorem next_77471 : next 77471 = some 77773 := by
  have hl : (List.range ((257 * 77471 - 1) / 256 - 77471)).reverse =
      [301] ++ (List.range 301).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_77773]

theorem next_77773 : next 77773 = some 78059 := by
  have hl : (List.range ((257 * 77773 - 1) / 256 - 77773)).reverse =
      [302, 301, 300, 299, 298, 297, 296, 295, 294, 293, 292, 291, 290, 289, 288, 287, 286, 285] ++ (List.range 285).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_78059]

theorem next_78059 : next 78059 = some 78347 := by
  have hl : (List.range ((257 * 78059 - 1) / 256 - 78059)).reverse =
      [303, 302, 301, 300, 299, 298, 297, 296, 295, 294, 293, 292, 291, 290, 289, 288, 287] ++ (List.range 287).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_78347]

theorem next_78347 : next 78347 = some 78653 := by
  have hl : (List.range ((257 * 78347 - 1) / 256 - 78347)).reverse =
      [305] ++ (List.range 305).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_78653]

theorem next_78653 : next 78653 = some 78941 := by
  have hl : (List.range ((257 * 78653 - 1) / 256 - 78653)).reverse =
      [306, 305, 304, 303, 302, 301, 300, 299, 298, 297, 296, 295, 294, 293, 292, 291, 290, 289, 288, 287] ++ (List.range 287).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_78941]

theorem next_78941 : next 78941 = some 79241 := by
  have hl : (List.range ((257 * 78941 - 1) / 256 - 78941)).reverse =
      [307, 306, 305, 304, 303, 302, 301, 300, 299] ++ (List.range 299).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_79241]

theorem next_79241 : next 79241 = some 79549 := by
  have hl : (List.range ((257 * 79241 - 1) / 256 - 79241)).reverse =
      [308, 307] ++ (List.range 307).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_79549]

theorem next_79549 : next 79549 = some 79847 := by
  have hl : (List.range ((257 * 79549 - 1) / 256 - 79549)).reverse =
      [309, 308, 307, 306, 305, 304, 303, 302, 301, 300, 299, 298, 297] ++ (List.range 297).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_79847]

theorem next_79847 : next 79847 = some 80153 := by
  have hl : (List.range ((257 * 79847 - 1) / 256 - 79847)).reverse =
      [310, 309, 308, 307, 306, 305] ++ (List.range 305).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_80153]

theorem next_80153 : next 80153 = some 80449 := by
  have hl : (List.range ((257 * 80153 - 1) / 256 - 80153)).reverse =
      [312, 311, 310, 309, 308, 307, 306, 305, 304, 303, 302, 301, 300, 299, 298, 297, 296, 295] ++ (List.range 295).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_80449]

def primes : List ℕ := [71569, 71843, 72109, 72383, 72661, 72937, 73189, 73471, 73757, 74027, 74311, 74597, 74887, 75169, 75437, 75731, 76003, 76289, 76579, 76873, 77171, 77471, 77773, 78059, 78347, 78653, 78941, 79241, 79549, 79847, 80153, 80449]

theorem segment : run 92 71293 89693 =
    primes ++ run 60 80449 89693 := by
  rw [Compact40PrimeCompose256.step 91 71293 89693 71569
    (by decide +kernel) next_71293]
  rw [Compact40PrimeCompose256.step 90 71569 89693 71843
    (by decide +kernel) next_71569]
  rw [Compact40PrimeCompose256.step 89 71843 89693 72109
    (by decide +kernel) next_71843]
  rw [Compact40PrimeCompose256.step 88 72109 89693 72383
    (by decide +kernel) next_72109]
  rw [Compact40PrimeCompose256.step 87 72383 89693 72661
    (by decide +kernel) next_72383]
  rw [Compact40PrimeCompose256.step 86 72661 89693 72937
    (by decide +kernel) next_72661]
  rw [Compact40PrimeCompose256.step 85 72937 89693 73189
    (by decide +kernel) next_72937]
  rw [Compact40PrimeCompose256.step 84 73189 89693 73471
    (by decide +kernel) next_73189]
  rw [Compact40PrimeCompose256.step 83 73471 89693 73757
    (by decide +kernel) next_73471]
  rw [Compact40PrimeCompose256.step 82 73757 89693 74027
    (by decide +kernel) next_73757]
  rw [Compact40PrimeCompose256.step 81 74027 89693 74311
    (by decide +kernel) next_74027]
  rw [Compact40PrimeCompose256.step 80 74311 89693 74597
    (by decide +kernel) next_74311]
  rw [Compact40PrimeCompose256.step 79 74597 89693 74887
    (by decide +kernel) next_74597]
  rw [Compact40PrimeCompose256.step 78 74887 89693 75169
    (by decide +kernel) next_74887]
  rw [Compact40PrimeCompose256.step 77 75169 89693 75437
    (by decide +kernel) next_75169]
  rw [Compact40PrimeCompose256.step 76 75437 89693 75731
    (by decide +kernel) next_75437]
  rw [Compact40PrimeCompose256.step 75 75731 89693 76003
    (by decide +kernel) next_75731]
  rw [Compact40PrimeCompose256.step 74 76003 89693 76289
    (by decide +kernel) next_76003]
  rw [Compact40PrimeCompose256.step 73 76289 89693 76579
    (by decide +kernel) next_76289]
  rw [Compact40PrimeCompose256.step 72 76579 89693 76873
    (by decide +kernel) next_76579]
  rw [Compact40PrimeCompose256.step 71 76873 89693 77171
    (by decide +kernel) next_76873]
  rw [Compact40PrimeCompose256.step 70 77171 89693 77471
    (by decide +kernel) next_77171]
  rw [Compact40PrimeCompose256.step 69 77471 89693 77773
    (by decide +kernel) next_77471]
  rw [Compact40PrimeCompose256.step 68 77773 89693 78059
    (by decide +kernel) next_77773]
  rw [Compact40PrimeCompose256.step 67 78059 89693 78347
    (by decide +kernel) next_78059]
  rw [Compact40PrimeCompose256.step 66 78347 89693 78653
    (by decide +kernel) next_78347]
  rw [Compact40PrimeCompose256.step 65 78653 89693 78941
    (by decide +kernel) next_78653]
  rw [Compact40PrimeCompose256.step 64 78941 89693 79241
    (by decide +kernel) next_78941]
  rw [Compact40PrimeCompose256.step 63 79241 89693 79549
    (by decide +kernel) next_79241]
  rw [Compact40PrimeCompose256.step 62 79549 89693 79847
    (by decide +kernel) next_79549]
  rw [Compact40PrimeCompose256.step 61 79847 89693 80153
    (by decide +kernel) next_79847]
  rw [Compact40PrimeCompose256.step 60 80153 89693 80449
    (by decide +kernel) next_80153]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 80449 stop tail = true) :
    check 71293 stop (primes ++ tail) = true := by
  change check _ _ (71569 :: 71843 :: 72109 :: 72383 :: 72661 :: 72937 :: 73189 :: 73471 :: 73757 :: 74027 :: 74311 :: 74597 :: 74887 :: 75169 :: 75437 :: 75731 :: 76003 :: 76289 :: 76579 :: 76873 :: 77171 :: 77471 :: 77773 :: 78059 :: 78347 :: 78653 :: 78941 :: 79241 :: 79549 :: 79847 :: 80153 :: 80449 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_71569, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_71843, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_72109, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_72383, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_72661, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_72937, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_73189, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_73471, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_73757, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_74027, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_74311, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_74597, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_74887, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_75169, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_75437, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_75731, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_76003, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_76289, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_76579, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_76873, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_77171, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_77471, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_77773, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_78059, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_78347, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_78653, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_78941, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_79241, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_79549, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_79847, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_80153, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_80449, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks019
