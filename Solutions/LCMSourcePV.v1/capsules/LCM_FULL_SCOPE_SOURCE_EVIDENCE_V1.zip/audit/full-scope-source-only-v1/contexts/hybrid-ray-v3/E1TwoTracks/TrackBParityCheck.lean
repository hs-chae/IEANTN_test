/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1TwoTracks.TrackBBlocks
import E1TwoTracks.TrackBParityMath
namespace E1TwoTracks.TrackB
open Finset Nat Real
open E1Tertiary.LcmBase
set_option maxHeartbeats 3000000

def Block.structureValid (b : Block) : Prop :=
  1 ≤ b.lo ∧ b.lo ≤ b.hi ∧ b.hi < b.p0^2 ∧ b.p2 < b.q0 ∧ b.q2 < b.lo ∧
  b.p0.Prime ∧ b.p1.Prime ∧ b.p2.Prime ∧ b.q0.Prime ∧ b.q1.Prime ∧ b.q2.Prime ∧
  b.p0 < b.p1 ∧ b.p1 < b.p2 ∧ b.q0 < b.q1 ∧ b.q1 < b.q2
instance (b : Block) : Decidable b.structureValid := inferInstanceAs (Decidable (_ ∧ _))

def Block.parityEndpoint (b : Block) (n : ℕ) : Prop :=
  16*(10*n+1)*b.A*b.D + 40*(16*n+7)*b.B*b.P ≤ 10*(16*n+7)*b.B*b.Q
instance (b : Block) (n : ℕ) : Decidable (b.parityEndpoint n) := inferInstanceAs (Decidable (_ ≤ _))
def Block.parityValid (b : Block) : Prop :=
  b.structureValid ∧ (b.Q/(4*b.P))%2=0 ∧ b.parityEndpoint b.lo ∧ b.parityEndpoint b.hi
instance (b : Block) : Decidable b.parityValid := inferInstanceAs (Decidable (_ ∧ _))
def Block.parityCheck (b : Block) : Bool := decide b.parityValid

theorem Block.parityEndpointSound (b : Block) (hb : b.parityValid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    16*(10*(n:ℝ)+1)*b.A*b.D + 40*(16*(n:ℝ)+7)*b.B*b.P ≤
      10*(16*(n:ℝ)+7)*b.B*b.Q := by
  have hl : 16*(10*(b.lo:ℝ)+1)*b.A*b.D + 40*(16*(b.lo:ℝ)+7)*b.B*b.P ≤
      10*(16*(b.lo:ℝ)+7)*b.B*b.Q := by exact_mod_cast hb.2.2.1
  have hh : 16*(10*(b.hi:ℝ)+1)*b.A*b.D + 40*(16*(b.hi:ℝ)+7)*b.B*b.P ≤
      10*(16*(b.hi:ℝ)+7)*b.B*b.Q := by exact_mod_cast hb.2.2.2
  have hn1 : (b.lo:ℝ) ≤ n := by exact_mod_cast hnl
  have hn2 : (n:ℝ) ≤ b.hi := by exact_mod_cast hnh
  have ha := affine_endpoints
    (a := 160*(b.A:ℝ)*b.D + 640*b.B*b.P)
    (b := 16*(b.A:ℝ)*b.D + 280*b.B*b.P)
    (c := 160*(b.B:ℝ)*b.Q) (d := 70*(b.B:ℝ)*b.Q)
    (l := b.lo) (h := b.hi) (x := n) (by nlinarith [hl]) (by nlinarith [hh]) hn1 hn2
  nlinarith [ha]

theorem Block.parityRatio (b : Block) (hb : b.parityValid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    (1 + 1 / (10*(n:ℝ))) * ∏ i, (1 + (1:ℝ) / b.q i) ≤
      (∏ i, (1 + 1 / (b.p i * (b.p i+1):ℝ))) * (1 + 7 / (16*(n:ℝ))) *
      (1 - 4 * (∏ i, (b.p i:ℝ)) / ∏ i, (b.q i:ℝ)) := by
  rcases hb with ⟨⟨hl, hle, hs, hpq, hql, hp0, hp1, hp2, hq0, hq1, hq2, hp01, hp12, hq01, hq12⟩, heven, helo, hehi⟩
  have hn : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (lt_of_lt_of_le (by decide : 0 < 1) hl) hnl)
  have hp0' : (0:ℝ) < b.p0 := by exact_mod_cast hp0.pos
  have hp1' : (0:ℝ) < b.p1 := by exact_mod_cast hp1.pos
  have hp2' : (0:ℝ) < b.p2 := by exact_mod_cast hp2.pos
  have hq0' : (0:ℝ) < b.q0 := by exact_mod_cast hq0.pos
  have hq1' : (0:ℝ) < b.q1 := by exact_mod_cast hq1.pos
  have hq2' : (0:ℝ) < b.q2 := by exact_mod_cast hq2.pos
  have hD : (0:ℝ) < b.D := by dsimp [Block.D]; push_cast; positivity
  have hQ : (0:ℝ) < b.Q := by dsimp [Block.Q]; push_cast; positivity
  have hratQ : (∏ i, (1 + (1:ℝ) / b.q i)) = (b.A:ℝ)/b.Q := by
    simp [Fin.prod_univ_three, Block.q, Block.A, Block.Q]
    field_simp
    <;> ring
  have hratP : (∏ i, (1 + 1 / (b.p i * (b.p i+1):ℝ))) = (b.B:ℝ)/b.D := by
    simp [Fin.prod_univ_three, Block.p, Block.B, Block.D]
    field_simp
    <;> ring
  have hprodP : (∏ i, (b.p i:ℝ)) = (b.P:ℝ) := by simp [Fin.prod_univ_three, Block.p, Block.P]
  have hprodQ : (∏ i, (b.q i:ℝ)) = (b.Q:ℝ) := by simp [Fin.prod_univ_three, Block.q, Block.Q]
  rw [hratQ, hratP, hprodP, hprodQ]
  have he := b.parityEndpointSound ⟨⟨hl, hle, hs, hpq, hql, hp0, hp1, hp2, hq0, hq1, hq2, hp01, hp12, hq01, hq12⟩, heven, helo, hehi⟩ n hnl hnh
  have he' : 16*(10*(n:ℝ)+1)*b.A*b.D ≤
      10*(16*(n:ℝ)+7)*b.B*b.Q - 40*(16*(n:ℝ)+7)*b.B*b.P := by linarith
  apply (mul_le_mul_iff_right₀ (show (0:ℝ) < 160*n*b.D*b.Q by positivity)).mp
  convert he' using 1 <;> (try rfl) <;> (try field_simp [ne_of_gt hn, ne_of_gt hD, ne_of_gt hQ]) <;> ring

noncomputable def Block.parityCriterion (b : Block) (hb : b.parityValid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) : Criterion where
  n := n
  hn := hb.1.1.trans hnl
  p := b.p
  hp := by rcases hb.1 with ⟨_, _, _, _, _, h0, h1, h2, _⟩; intro i; fin_cases i <;> assumption
  hp_mono := by
    rcases hb.1 with ⟨_, _, _, _, _, _, _, _, _, _, _, h01, h12, _⟩
    intro i j hij; fin_cases i <;> fin_cases j <;> simp_all [Block.p] <;> omega
  q := b.q
  hq := by rcases hb.1 with ⟨_, _, _, _, _, _, _, _, h0, h1, h2, _⟩; intro i; fin_cases i <;> assumption
  hq_mono := by
    rcases hb.1 with ⟨_, _, _, _, _, _, _, _, _, _, _, _, _, h01, h12⟩
    intro i j hij; fin_cases i <;> fin_cases j <;> simp_all [Block.q] <;> omega
  h_ord_1 := by
    have hs : (n:ℝ) < (b.p0:ℝ)^2 := by exact_mod_cast (lt_of_le_of_lt hnh hb.1.2.2.1)
    have hp : (0:ℝ) ≤ b.p0 := by positivity
    simpa [Block.p] using (Real.sqrt_lt (by positivity) hp).mpr hs
  h_ord_2 := hb.1.2.2.2.1
  h_ord_3 := hb.1.2.2.2.2.1.trans_le hnl
  h_crit := by
    have hh := b.parityRatio hb n hnl hnh
    have hn : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (lt_of_lt_of_le (by decide : 0 < 1) hb.1.1) hnl)
    set A : ℝ := ∏ i, (1 + (1:ℝ) / b.q i)
    set B : ℝ := ∏ i, (1 + 1 / (b.p i * (b.p i+1):ℝ))
    set R : ℝ := 1 - 4 * (∏ i, (b.p i:ℝ)) / ∏ i, (b.q i:ℝ)
    have hA : 0 < A := by dsimp [A]; exact Finset.prod_pos fun i _ => by positivity
    have hBR : 0 ≤ B*R := by
      have ht : 0 < (1+1/(10*(n:ℝ)))*A := mul_pos (by positivity) hA
      have hnew : 0 < B*R*(1+7/(16*(n:ℝ))) := by nlinarith [hh]
      exact le_of_lt ((mul_pos_iff_of_pos_right (by positivity : (0:ℝ)<1+7/(16*(n:ℝ)))).mp hnew)
    have hscalar : (1+7/(16*(n:ℝ))) ≤ (1+1/(10*(n:ℝ)))*(1+3/(8*(n:ℝ))) := by
      have hi : (0:ℝ) < 1/n := by positivity
      have hs : (1+7/(16*(n:ℝ))) = 1+(7/16:ℝ)*(1/n) := by field_simp <;> ring
      have ht : (1+1/(10*(n:ℝ)))*(1+3/(8*(n:ℝ))) = 1+(19/40:ℝ)*(1/n)+(3/80:ℝ)*(1/n)^2 := by field_simp <;> ring
      rw [hs,ht]; nlinarith [sq_nonneg ((n:ℝ)⁻¹)]
    apply (mul_le_mul_iff_left₀ (show (0:ℝ)<1+1/(10*(n:ℝ)) by positivity)).mp
    have hx := mul_le_mul_of_nonneg_left hscalar hBR
    nlinarith [hh, hx]

theorem Block.parityEven (b : Block) (hb : b.parityValid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) : 2 ∣ (b.parityCriterion hb n hnl hnh).m := by
  have h := Nat.dvd_of_mod_eq_zero hb.2.1
  simpa [Block.parityCriterion, E1Tertiary.LcmBase.Criterion.m,
    Block.P, Block.Q, Block.p, Block.q, Fin.prod_univ_three] using h

theorem Block.paritySound (b : Block) (hb : b.parityCheck = true) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hv : b.parityValid := of_decide_eq_true hb
  let c := b.parityCriterion hv n hnl hnh
  refine ⟨c.M, c.M_lt, ?_⟩
  exact E1TwoTracks.TrackBParityMath.criterion_surplus c (b.parityEven hv n hnl hnh)
    (by positivity) (b.parityRatio hv n hnl hnh)

end E1TwoTracks.TrackB
