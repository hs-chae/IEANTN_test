import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks12
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨16024009, 16056048, 4007, 4013, 4019, 16023583, 16023611, 16024007⟩, 8⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4007,
    ExposureEvolution.KernelPratt.prime_4013,
    ExposureEvolution.KernelPratt.prime_4019,
    ExposureEvolution.KernelPratt.prime_16023583,
    ExposureEvolution.KernelPratt.prime_16023611,
    ExposureEvolution.KernelPratt.prime_16024007]

def block01 : Witness := ⟨⟨16056049, 16104168, 4013, 4019, 4021, 16055843, 16056023, 16056031⟩, 15⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4013,
    ExposureEvolution.KernelPratt.prime_4019,
    ExposureEvolution.KernelPratt.prime_4021,
    ExposureEvolution.KernelPratt.prime_16055843,
    ExposureEvolution.KernelPratt.prime_16056023,
    ExposureEvolution.KernelPratt.prime_16056031]

def block02 : Witness := ⟨⟨16104169, 16152360, 4019, 4021, 4027, 16103839, 16104157, 16104167⟩, 9⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4019,
    ExposureEvolution.KernelPratt.prime_4021,
    ExposureEvolution.KernelPratt.prime_4027,
    ExposureEvolution.KernelPratt.prime_16103839,
    ExposureEvolution.KernelPratt.prime_16104157,
    ExposureEvolution.KernelPratt.prime_16104167]

def block03 : Witness := ⟨⟨16152361, 16168440, 4021, 4027, 4049, 16152167, 16152341, 16152347⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4021,
    ExposureEvolution.KernelPratt.prime_4027,
    ExposureEvolution.KernelPratt.prime_4049,
    ExposureEvolution.KernelPratt.prime_16152167,
    ExposureEvolution.KernelPratt.prime_16152341,
    ExposureEvolution.KernelPratt.prime_16152347]

def block04 : Witness := ⟨⟨16168441, 16216728, 4027, 4049, 4051, 16168417, 16168429, 16168433⟩, 9⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4027,
    ExposureEvolution.KernelPratt.prime_4049,
    ExposureEvolution.KernelPratt.prime_4051,
    ExposureEvolution.KernelPratt.prime_16168417,
    ExposureEvolution.KernelPratt.prime_16168429,
    ExposureEvolution.KernelPratt.prime_16168433]

def block05 : Witness := ⟨⟨16216729, 16394400, 4049, 4051, 4057, 16216399, 16216637, 16216723⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4049,
    ExposureEvolution.KernelPratt.prime_4051,
    ExposureEvolution.KernelPratt.prime_4057,
    ExposureEvolution.KernelPratt.prime_16216399,
    ExposureEvolution.KernelPratt.prime_16216637,
    ExposureEvolution.KernelPratt.prime_16216723]

def block06 : Witness := ⟨⟨16394401, 16410600, 4051, 4057, 4073, 16394233, 16394353, 16394393⟩, 12⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4051,
    ExposureEvolution.KernelPratt.prime_4057,
    ExposureEvolution.KernelPratt.prime_4073,
    ExposureEvolution.KernelPratt.prime_16394233,
    ExposureEvolution.KernelPratt.prime_16394353,
    ExposureEvolution.KernelPratt.prime_16394393]

def block07 : Witness := ⟨⟨16410601, 16459248, 4057, 4073, 4079, 16410113, 16410463, 16410599⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4057,
    ExposureEvolution.KernelPratt.prime_4073,
    ExposureEvolution.KernelPratt.prime_4079,
    ExposureEvolution.KernelPratt.prime_16410113,
    ExposureEvolution.KernelPratt.prime_16410463,
    ExposureEvolution.KernelPratt.prime_16410599]

def block08 : Witness := ⟨⟨16459249, 16589328, 4073, 4079, 4091, 16458791, 16459021, 16459207⟩, 8⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4073,
    ExposureEvolution.KernelPratt.prime_4079,
    ExposureEvolution.KernelPratt.prime_4091,
    ExposureEvolution.KernelPratt.prime_16458791,
    ExposureEvolution.KernelPratt.prime_16459021,
    ExposureEvolution.KernelPratt.prime_16459207]

def block09 : Witness := ⟨⟨16589329, 16638240, 4079, 4091, 4093, 16589137, 16589219, 16589317⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4079,
    ExposureEvolution.KernelPratt.prime_4091,
    ExposureEvolution.KernelPratt.prime_4093,
    ExposureEvolution.KernelPratt.prime_16589137,
    ExposureEvolution.KernelPratt.prime_16589219,
    ExposureEvolution.KernelPratt.prime_16589317]

def block10 : Witness := ⟨⟨16638241, 16736280, 4091, 4093, 4099, 16637857, 16637897, 16638221⟩, 10⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4091,
    ExposureEvolution.KernelPratt.prime_4093,
    ExposureEvolution.KernelPratt.prime_4099,
    ExposureEvolution.KernelPratt.prime_16637857,
    ExposureEvolution.KernelPratt.prime_16637897,
    ExposureEvolution.KernelPratt.prime_16638221]

def block11 : Witness := ⟨⟨16736281, 16752648, 4093, 4099, 4111, 16735853, 16736257, 16736273⟩, 7⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4093,
    ExposureEvolution.KernelPratt.prime_4099,
    ExposureEvolution.KernelPratt.prime_4111,
    ExposureEvolution.KernelPratt.prime_16735853,
    ExposureEvolution.KernelPratt.prime_16736257,
    ExposureEvolution.KernelPratt.prime_16736273]

def block12 : Witness := ⟨⟨16752649, 16801800, 4099, 4111, 4127, 16752181, 16752469, 16752647⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4099,
    ExposureEvolution.KernelPratt.prime_4111,
    ExposureEvolution.KernelPratt.prime_4127,
    ExposureEvolution.KernelPratt.prime_16752181,
    ExposureEvolution.KernelPratt.prime_16752469,
    ExposureEvolution.KernelPratt.prime_16752647]

def block13 : Witness := ⟨⟨16801801, 16900320, 4111, 4127, 4129, 16801391, 16801781, 16801793⟩, 10⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4111,
    ExposureEvolution.KernelPratt.prime_4127,
    ExposureEvolution.KernelPratt.prime_4129,
    ExposureEvolution.KernelPratt.prime_16801391,
    ExposureEvolution.KernelPratt.prime_16801781,
    ExposureEvolution.KernelPratt.prime_16801793]

def block14 : Witness := ⟨⟨16900321, 17032128, 4127, 4129, 4133, 16900097, 16900249, 16900309⟩, 9⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4127,
    ExposureEvolution.KernelPratt.prime_4129,
    ExposureEvolution.KernelPratt.prime_4133,
    ExposureEvolution.KernelPratt.prime_16900097,
    ExposureEvolution.KernelPratt.prime_16900249,
    ExposureEvolution.KernelPratt.prime_16900309]

def block15 : Witness := ⟨⟨17032129, 17048640, 4129, 4133, 4139, 17031541, 17031659, 17032123⟩, 13⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4129,
    ExposureEvolution.KernelPratt.prime_4133,
    ExposureEvolution.KernelPratt.prime_4139,
    ExposureEvolution.KernelPratt.prime_17031541,
    ExposureEvolution.KernelPratt.prime_17031659,
    ExposureEvolution.KernelPratt.prime_17032123]

def block16 : Witness := ⟨⟨17048641, 17081688, 4133, 4139, 4153, 17048393, 17048513, 17048617⟩, 7⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4133,
    ExposureEvolution.KernelPratt.prime_4139,
    ExposureEvolution.KernelPratt.prime_4153,
    ExposureEvolution.KernelPratt.prime_17048393,
    ExposureEvolution.KernelPratt.prime_17048513,
    ExposureEvolution.KernelPratt.prime_17048617]

def block17 : Witness := ⟨⟨17081689, 17131320, 4139, 4153, 4157, 17081557, 17081611, 17081671⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4139,
    ExposureEvolution.KernelPratt.prime_4153,
    ExposureEvolution.KernelPratt.prime_4157,
    ExposureEvolution.KernelPratt.prime_17081557,
    ExposureEvolution.KernelPratt.prime_17081611,
    ExposureEvolution.KernelPratt.prime_17081671]

def block18 : Witness := ⟨⟨17131321, 17247408, 4153, 4157, 4159, 17131237, 17131273, 17131277⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4153,
    ExposureEvolution.KernelPratt.prime_4157,
    ExposureEvolution.KernelPratt.prime_4159,
    ExposureEvolution.KernelPratt.prime_17131237,
    ExposureEvolution.KernelPratt.prime_17131273,
    ExposureEvolution.KernelPratt.prime_17131277]

def block19 : Witness := ⟨⟨17247409, 17280648, 4157, 4159, 4177, 17247047, 17247361, 17247407⟩, 11⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4157,
    ExposureEvolution.KernelPratt.prime_4159,
    ExposureEvolution.KernelPratt.prime_4177,
    ExposureEvolution.KernelPratt.prime_17247047,
    ExposureEvolution.KernelPratt.prime_17247361,
    ExposureEvolution.KernelPratt.prime_17247407]

def block20 : Witness := ⟨⟨17280649, 17297280, 4159, 4177, 4201, 17280283, 17280359, 17280611⟩, 6⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4159,
    ExposureEvolution.KernelPratt.prime_4177,
    ExposureEvolution.KernelPratt.prime_4201,
    ExposureEvolution.KernelPratt.prime_17280283,
    ExposureEvolution.KernelPratt.prime_17280359,
    ExposureEvolution.KernelPratt.prime_17280611]

def block21 : Witness := ⟨⟨17297281, 17447328, 4177, 4201, 4211, 17296931, 17297257, 17297263⟩, 8⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4177,
    ExposureEvolution.KernelPratt.prime_4201,
    ExposureEvolution.KernelPratt.prime_4211,
    ExposureEvolution.KernelPratt.prime_17296931,
    ExposureEvolution.KernelPratt.prime_17297257,
    ExposureEvolution.KernelPratt.prime_17297263]

def block22 : Witness := ⟨⟨17447329, 17648400, 4201, 4211, 4217, 17446907, 17447237, 17447323⟩, 10⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4201,
    ExposureEvolution.KernelPratt.prime_4211,
    ExposureEvolution.KernelPratt.prime_4217,
    ExposureEvolution.KernelPratt.prime_17446907,
    ExposureEvolution.KernelPratt.prime_17447237,
    ExposureEvolution.KernelPratt.prime_17447323]

def block23 : Witness := ⟨⟨17648401, 17732520, 4211, 4217, 4219, 17648003, 17648027, 17648387⟩, 10⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4211,
    ExposureEvolution.KernelPratt.prime_4217,
    ExposureEvolution.KernelPratt.prime_4219,
    ExposureEvolution.KernelPratt.prime_17648003,
    ExposureEvolution.KernelPratt.prime_17648027,
    ExposureEvolution.KernelPratt.prime_17648387]

def block24 : Witness := ⟨⟨17732521, 17783088, 4217, 4219, 4229, 17732381, 17732413, 17732483⟩, 13⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4217,
    ExposureEvolution.KernelPratt.prime_4219,
    ExposureEvolution.KernelPratt.prime_4229,
    ExposureEvolution.KernelPratt.prime_17732381,
    ExposureEvolution.KernelPratt.prime_17732413,
    ExposureEvolution.KernelPratt.prime_17732483]

def block25 : Witness := ⟨⟨17783089, 17799960, 4219, 4229, 4231, 17782861, 17783039, 17783063⟩, 8⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4219,
    ExposureEvolution.KernelPratt.prime_4229,
    ExposureEvolution.KernelPratt.prime_4231,
    ExposureEvolution.KernelPratt.prime_17782861,
    ExposureEvolution.KernelPratt.prime_17783039,
    ExposureEvolution.KernelPratt.prime_17783063]

def block26 : Witness := ⟨⟨17799961, 17884440, 4229, 4231, 4241, 17799773, 17799841, 17799959⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4229,
    ExposureEvolution.KernelPratt.prime_4231,
    ExposureEvolution.KernelPratt.prime_4241,
    ExposureEvolution.KernelPratt.prime_17799773,
    ExposureEvolution.KernelPratt.prime_17799841,
    ExposureEvolution.KernelPratt.prime_17799959]

def block27 : Witness := ⟨⟨17884441, 17901360, 4231, 4241, 4243, 17884193, 17884249, 17884439⟩, 10⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4231,
    ExposureEvolution.KernelPratt.prime_4241,
    ExposureEvolution.KernelPratt.prime_4243,
    ExposureEvolution.KernelPratt.prime_17884193,
    ExposureEvolution.KernelPratt.prime_17884249,
    ExposureEvolution.KernelPratt.prime_17884439]

def block28 : Witness := ⟨⟨17901361, 17986080, 4241, 4243, 4253, 17901071, 17901197, 17901349⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4241,
    ExposureEvolution.KernelPratt.prime_4243,
    ExposureEvolution.KernelPratt.prime_4253,
    ExposureEvolution.KernelPratt.prime_17901071,
    ExposureEvolution.KernelPratt.prime_17901197,
    ExposureEvolution.KernelPratt.prime_17901349]

def block29 : Witness := ⟨⟨17986081, 18003048, 4243, 4253, 4259, 17985853, 17986049, 17986079⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4243,
    ExposureEvolution.KernelPratt.prime_4253,
    ExposureEvolution.KernelPratt.prime_4259,
    ExposureEvolution.KernelPratt.prime_17985853,
    ExposureEvolution.KernelPratt.prime_17986049,
    ExposureEvolution.KernelPratt.prime_17986079]

def block30 : Witness := ⟨⟨18003049, 18088008, 4253, 4259, 4261, 18002891, 18002921, 18003023⟩, 9⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4253,
    ExposureEvolution.KernelPratt.prime_4259,
    ExposureEvolution.KernelPratt.prime_4261,
    ExposureEvolution.KernelPratt.prime_18002891,
    ExposureEvolution.KernelPratt.prime_18002921,
    ExposureEvolution.KernelPratt.prime_18003023]

def block31 : Witness := ⟨⟨18088009, 18139080, 4259, 4261, 4271, 18087479, 18087887, 18087991⟩, 10⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4259,
    ExposureEvolution.KernelPratt.prime_4261,
    ExposureEvolution.KernelPratt.prime_4271,
    ExposureEvolution.KernelPratt.prime_18087479,
    ExposureEvolution.KernelPratt.prime_18087887,
    ExposureEvolution.KernelPratt.prime_18087991]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 18139081 stop tail = true) :
    coverage 16024009 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks12
