import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_004
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨18258529, 18344088, 4283, 4289, 4297, 18257951, 18258241, 18258517⟩, 10⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4283,
    ExposureEvolution.Compact40Pratt.prime_4289,
    ExposureEvolution.Compact40Pratt.prime_4297,
    ExposureEvolution.Compact40Pratt.prime_18257951,
    ExposureEvolution.Compact40Pratt.prime_18258241,
    ExposureEvolution.Compact40Pratt.prime_18258517]

def block01 : Witness := ⟨⟨18344089, 18395520, 4289, 4297, 4327, 18343813, 18343931, 18344083⟩, 7⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4289,
    ExposureEvolution.Compact40Pratt.prime_4297,
    ExposureEvolution.Compact40Pratt.prime_4327,
    ExposureEvolution.Compact40Pratt.prime_18343813,
    ExposureEvolution.Compact40Pratt.prime_18343931,
    ExposureEvolution.Compact40Pratt.prime_18344083]

def block02 : Witness := ⟨⟨18395521, 18464208, 4297, 4327, 4337, 18395011, 18395053, 18395473⟩, 8⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4297,
    ExposureEvolution.Compact40Pratt.prime_4327,
    ExposureEvolution.Compact40Pratt.prime_4337,
    ExposureEvolution.Compact40Pratt.prime_18395011,
    ExposureEvolution.Compact40Pratt.prime_18395053,
    ExposureEvolution.Compact40Pratt.prime_18395473]

def block03 : Witness := ⟨⟨18464209, 18722928, 4327, 4337, 4339, 18463747, 18463909, 18464203⟩, 10⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4327,
    ExposureEvolution.Compact40Pratt.prime_4337,
    ExposureEvolution.Compact40Pratt.prime_4339,
    ExposureEvolution.Compact40Pratt.prime_18463747,
    ExposureEvolution.Compact40Pratt.prime_18463909,
    ExposureEvolution.Compact40Pratt.prime_18464203]

def block04 : Witness := ⟨⟨18722929, 18809568, 4337, 4339, 4349, 18722617, 18722761, 18722909⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4337,
    ExposureEvolution.Compact40Pratt.prime_4339,
    ExposureEvolution.Compact40Pratt.prime_4349,
    ExposureEvolution.Compact40Pratt.prime_18722617,
    ExposureEvolution.Compact40Pratt.prime_18722761,
    ExposureEvolution.Compact40Pratt.prime_18722909]

def block05 : Witness := ⟨⟨18809569, 18826920, 4339, 4349, 4357, 18809177, 18809389, 18809521⟩, 7⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4339,
    ExposureEvolution.Compact40Pratt.prime_4349,
    ExposureEvolution.Compact40Pratt.prime_4357,
    ExposureEvolution.Compact40Pratt.prime_18809177,
    ExposureEvolution.Compact40Pratt.prime_18809389,
    ExposureEvolution.Compact40Pratt.prime_18809521]

def block06 : Witness := ⟨⟨18826921, 18913800, 4349, 4357, 4363, 18826499, 18826711, 18826901⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4349,
    ExposureEvolution.Compact40Pratt.prime_4357,
    ExposureEvolution.Compact40Pratt.prime_4363,
    ExposureEvolution.Compact40Pratt.prime_18826499,
    ExposureEvolution.Compact40Pratt.prime_18826711,
    ExposureEvolution.Compact40Pratt.prime_18826901]

def block07 : Witness := ⟨⟨18913801, 18983448, 4357, 4363, 4373, 18913541, 18913717, 18913799⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4357,
    ExposureEvolution.Compact40Pratt.prime_4363,
    ExposureEvolution.Compact40Pratt.prime_4373,
    ExposureEvolution.Compact40Pratt.prime_18913541,
    ExposureEvolution.Compact40Pratt.prime_18913717,
    ExposureEvolution.Compact40Pratt.prime_18913799]

def block08 : Witness := ⟨⟨18983449, 19035768, 4363, 4373, 4391, 18983011, 18983021, 18983423⟩, 8⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4363,
    ExposureEvolution.Compact40Pratt.prime_4373,
    ExposureEvolution.Compact40Pratt.prime_4391,
    ExposureEvolution.Compact40Pratt.prime_18983011,
    ExposureEvolution.Compact40Pratt.prime_18983021,
    ExposureEvolution.Compact40Pratt.prime_18983423]

def block09 : Witness := ⟨⟨19035769, 19123128, 4373, 4391, 4397, 19035619, 19035623, 19035763⟩, 6⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4373,
    ExposureEvolution.Compact40Pratt.prime_4391,
    ExposureEvolution.Compact40Pratt.prime_4397,
    ExposureEvolution.Compact40Pratt.prime_19035619,
    ExposureEvolution.Compact40Pratt.prime_19035623,
    ExposureEvolution.Compact40Pratt.prime_19035763]

def block10 : Witness := ⟨⟨19123129, 19280880, 4391, 4397, 4409, 19122899, 19123057, 19123127⟩, 8⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4391,
    ExposureEvolution.Compact40Pratt.prime_4397,
    ExposureEvolution.Compact40Pratt.prime_4409,
    ExposureEvolution.Compact40Pratt.prime_19122899,
    ExposureEvolution.Compact40Pratt.prime_19123057,
    ExposureEvolution.Compact40Pratt.prime_19123127]

def block11 : Witness := ⟨⟨19280881, 19333608, 4397, 4409, 4421, 19280381, 19280717, 19280869⟩, 7⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4397,
    ExposureEvolution.Compact40Pratt.prime_4409,
    ExposureEvolution.Compact40Pratt.prime_4421,
    ExposureEvolution.Compact40Pratt.prime_19280381,
    ExposureEvolution.Compact40Pratt.prime_19280717,
    ExposureEvolution.Compact40Pratt.prime_19280869]

def block12 : Witness := ⟨⟨19333609, 19439280, 4409, 4421, 4423, 19333177, 19333313, 19333597⟩, 12⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4409,
    ExposureEvolution.Compact40Pratt.prime_4421,
    ExposureEvolution.Compact40Pratt.prime_4423,
    ExposureEvolution.Compact40Pratt.prime_19333177,
    ExposureEvolution.Compact40Pratt.prime_19333313,
    ExposureEvolution.Compact40Pratt.prime_19333597]

def block13 : Witness := ⟨⟨19439281, 19545240, 4421, 4423, 4441, 19438963, 19439159, 19439267⟩, 12⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4421,
    ExposureEvolution.Compact40Pratt.prime_4423,
    ExposureEvolution.Compact40Pratt.prime_4441,
    ExposureEvolution.Compact40Pratt.prime_19438963,
    ExposureEvolution.Compact40Pratt.prime_19439159,
    ExposureEvolution.Compact40Pratt.prime_19439267]

def block14 : Witness := ⟨⟨19545241, 19562928, 4423, 4441, 4447, 19544783, 19545157, 19545203⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4423,
    ExposureEvolution.Compact40Pratt.prime_4441,
    ExposureEvolution.Compact40Pratt.prime_4447,
    ExposureEvolution.Compact40Pratt.prime_19544783,
    ExposureEvolution.Compact40Pratt.prime_19545157,
    ExposureEvolution.Compact40Pratt.prime_19545203]

def block15 : Witness := ⟨⟨19562929, 19722480, 4441, 4447, 4451, 19562539, 19562713, 19562927⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4441,
    ExposureEvolution.Compact40Pratt.prime_4447,
    ExposureEvolution.Compact40Pratt.prime_4451,
    ExposureEvolution.Compact40Pratt.prime_19562539,
    ExposureEvolution.Compact40Pratt.prime_19562713,
    ExposureEvolution.Compact40Pratt.prime_19562927]

def block16 : Witness := ⟨⟨19722481, 19775808, 4447, 4451, 4457, 19722317, 19722401, 19722473⟩, 9⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4447,
    ExposureEvolution.Compact40Pratt.prime_4451,
    ExposureEvolution.Compact40Pratt.prime_4457,
    ExposureEvolution.Compact40Pratt.prime_19722317,
    ExposureEvolution.Compact40Pratt.prime_19722401,
    ExposureEvolution.Compact40Pratt.prime_19722473]

def block17 : Witness := ⟨⟨19775809, 19811400, 4451, 4457, 4463, 19775527, 19775617, 19775801⟩, 11⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4451,
    ExposureEvolution.Compact40Pratt.prime_4457,
    ExposureEvolution.Compact40Pratt.prime_4463,
    ExposureEvolution.Compact40Pratt.prime_19775527,
    ExposureEvolution.Compact40Pratt.prime_19775617,
    ExposureEvolution.Compact40Pratt.prime_19775801]

def block18 : Witness := ⟨⟨19811401, 19864848, 4457, 4463, 4481, 19810957, 19811177, 19811399⟩, 11⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4457,
    ExposureEvolution.Compact40Pratt.prime_4463,
    ExposureEvolution.Compact40Pratt.prime_4481,
    ExposureEvolution.Compact40Pratt.prime_19810957,
    ExposureEvolution.Compact40Pratt.prime_19811177,
    ExposureEvolution.Compact40Pratt.prime_19811399]

def block19 : Witness := ⟨⟨19864849, 19918368, 4463, 4481, 4483, 19864417, 19864567, 19864837⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4463,
    ExposureEvolution.Compact40Pratt.prime_4481,
    ExposureEvolution.Compact40Pratt.prime_4483,
    ExposureEvolution.Compact40Pratt.prime_19864417,
    ExposureEvolution.Compact40Pratt.prime_19864567,
    ExposureEvolution.Compact40Pratt.prime_19864837]

def block20 : Witness := ⟨⟨19918369, 20079360, 4481, 4483, 4493, 19917949, 19918133, 19918361⟩, 10⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4481,
    ExposureEvolution.Compact40Pratt.prime_4483,
    ExposureEvolution.Compact40Pratt.prime_4493,
    ExposureEvolution.Compact40Pratt.prime_19917949,
    ExposureEvolution.Compact40Pratt.prime_19918133,
    ExposureEvolution.Compact40Pratt.prime_19918361]

def block21 : Witness := ⟨⟨20079361, 20097288, 4483, 4493, 4507, 20079109, 20079239, 20079343⟩, 9⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4483,
    ExposureEvolution.Compact40Pratt.prime_4493,
    ExposureEvolution.Compact40Pratt.prime_4507,
    ExposureEvolution.Compact40Pratt.prime_20079109,
    ExposureEvolution.Compact40Pratt.prime_20079239,
    ExposureEvolution.Compact40Pratt.prime_20079343]

def block22 : Witness := ⟨⟨20097289, 20187048, 4493, 4507, 4513, 20097151, 20097223, 20097263⟩, 10⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4493,
    ExposureEvolution.Compact40Pratt.prime_4507,
    ExposureEvolution.Compact40Pratt.prime_4513,
    ExposureEvolution.Compact40Pratt.prime_20097151,
    ExposureEvolution.Compact40Pratt.prime_20097223,
    ExposureEvolution.Compact40Pratt.prime_20097263]

def block23 : Witness := ⟨⟨20187049, 20313048, 4507, 4513, 4517, 20186399, 20186809, 20187043⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4507,
    ExposureEvolution.Compact40Pratt.prime_4513,
    ExposureEvolution.Compact40Pratt.prime_4517,
    ExposureEvolution.Compact40Pratt.prime_20186399,
    ExposureEvolution.Compact40Pratt.prime_20186809,
    ExposureEvolution.Compact40Pratt.prime_20187043]

def block24 : Witness := ⟨⟨20313049, 20367168, 4513, 4517, 4519, 20312693, 20312959, 20313047⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4513,
    ExposureEvolution.Compact40Pratt.prime_4517,
    ExposureEvolution.Compact40Pratt.prime_4519,
    ExposureEvolution.Compact40Pratt.prime_20312693,
    ExposureEvolution.Compact40Pratt.prime_20312959,
    ExposureEvolution.Compact40Pratt.prime_20313047]

def block25 : Witness := ⟨⟨20367169, 20403288, 4517, 4519, 4523, 20366737, 20366809, 20367143⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4517,
    ExposureEvolution.Compact40Pratt.prime_4519,
    ExposureEvolution.Compact40Pratt.prime_4523,
    ExposureEvolution.Compact40Pratt.prime_20366737,
    ExposureEvolution.Compact40Pratt.prime_20366809,
    ExposureEvolution.Compact40Pratt.prime_20367143]

def block26 : Witness := ⟨⟨20403289, 20421360, 4519, 4523, 4547, 20403197, 20403233, 20403241⟩, 9⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4519,
    ExposureEvolution.Compact40Pratt.prime_4523,
    ExposureEvolution.Compact40Pratt.prime_4547,
    ExposureEvolution.Compact40Pratt.prime_20403197,
    ExposureEvolution.Compact40Pratt.prime_20403233,
    ExposureEvolution.Compact40Pratt.prime_20403241]

def block27 : Witness := ⟨⟨20421361, 20457528, 4523, 4547, 4549, 20420957, 20420977, 20421347⟩, 13⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4523,
    ExposureEvolution.Compact40Pratt.prime_4547,
    ExposureEvolution.Compact40Pratt.prime_4549,
    ExposureEvolution.Compact40Pratt.prime_20420957,
    ExposureEvolution.Compact40Pratt.prime_20420977,
    ExposureEvolution.Compact40Pratt.prime_20421347]

def block28 : Witness := ⟨⟨20457529, 20675208, 4547, 4549, 4561, 20457299, 20457497, 20457517⟩, 6⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4547,
    ExposureEvolution.Compact40Pratt.prime_4549,
    ExposureEvolution.Compact40Pratt.prime_4561,
    ExposureEvolution.Compact40Pratt.prime_20457299,
    ExposureEvolution.Compact40Pratt.prime_20457497,
    ExposureEvolution.Compact40Pratt.prime_20457517]

def block29 : Witness := ⟨⟨20675209, 20693400, 4549, 4561, 4567, 20674867, 20675023, 20675203⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4549,
    ExposureEvolution.Compact40Pratt.prime_4561,
    ExposureEvolution.Compact40Pratt.prime_4567,
    ExposureEvolution.Compact40Pratt.prime_20674867,
    ExposureEvolution.Compact40Pratt.prime_20675023,
    ExposureEvolution.Compact40Pratt.prime_20675203]

def block30 : Witness := ⟨⟨20693401, 20802720, 4561, 4567, 4583, 20693087, 20693357, 20693389⟩, 12⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4561,
    ExposureEvolution.Compact40Pratt.prime_4567,
    ExposureEvolution.Compact40Pratt.prime_4583,
    ExposureEvolution.Compact40Pratt.prime_20693087,
    ExposureEvolution.Compact40Pratt.prime_20693357,
    ExposureEvolution.Compact40Pratt.prime_20693389]

def block31 : Witness := ⟨⟨20802721, 20857488, 4567, 4583, 4591, 20802371, 20802559, 20802709⟩, 8⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4567,
    ExposureEvolution.Compact40Pratt.prime_4583,
    ExposureEvolution.Compact40Pratt.prime_4591,
    ExposureEvolution.Compact40Pratt.prime_20802371,
    ExposureEvolution.Compact40Pratt.prime_20802559,
    ExposureEvolution.Compact40Pratt.prime_20802709]

def block32 : Witness := ⟨⟨20857489, 21003888, 4583, 4591, 4597, 20856947, 20857247, 20857483⟩, 10⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4583,
    ExposureEvolution.Compact40Pratt.prime_4591,
    ExposureEvolution.Compact40Pratt.prime_4597,
    ExposureEvolution.Compact40Pratt.prime_20856947,
    ExposureEvolution.Compact40Pratt.prime_20857247,
    ExposureEvolution.Compact40Pratt.prime_20857483]

def block33 : Witness := ⟨⟨21003889, 21077280, 4591, 4597, 4603, 21003713, 21003751, 21003887⟩, 7⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4591,
    ExposureEvolution.Compact40Pratt.prime_4597,
    ExposureEvolution.Compact40Pratt.prime_4603,
    ExposureEvolution.Compact40Pratt.prime_21003713,
    ExposureEvolution.Compact40Pratt.prime_21003751,
    ExposureEvolution.Compact40Pratt.prime_21003887]

def block34 : Witness := ⟨⟨21077281, 21132408, 4597, 4603, 4621, 21076667, 21077051, 21077257⟩, 7⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4597,
    ExposureEvolution.Compact40Pratt.prime_4603,
    ExposureEvolution.Compact40Pratt.prime_4621,
    ExposureEvolution.Compact40Pratt.prime_21076667,
    ExposureEvolution.Compact40Pratt.prime_21077051,
    ExposureEvolution.Compact40Pratt.prime_21077257]

def block35 : Witness := ⟨⟨21132409, 21187608, 4603, 4621, 4637, 21132211, 21132229, 21132383⟩, 12⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4603,
    ExposureEvolution.Compact40Pratt.prime_4621,
    ExposureEvolution.Compact40Pratt.prime_4637,
    ExposureEvolution.Compact40Pratt.prime_21132211,
    ExposureEvolution.Compact40Pratt.prime_21132229,
    ExposureEvolution.Compact40Pratt.prime_21132383]

def block36 : Witness := ⟨⟨21187609, 21353640, 4621, 4637, 4639, 21187193, 21187241, 21187597⟩, 7⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4621,
    ExposureEvolution.Compact40Pratt.prime_4637,
    ExposureEvolution.Compact40Pratt.prime_4639,
    ExposureEvolution.Compact40Pratt.prime_21187193,
    ExposureEvolution.Compact40Pratt.prime_21187241,
    ExposureEvolution.Compact40Pratt.prime_21187597]

def block37 : Witness := ⟨⟨21353641, 21501768, 4637, 4639, 4643, 21353443, 21353461, 21353639⟩, 5⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4637,
    ExposureEvolution.Compact40Pratt.prime_4639,
    ExposureEvolution.Compact40Pratt.prime_4643,
    ExposureEvolution.Compact40Pratt.prime_21353443,
    ExposureEvolution.Compact40Pratt.prime_21353461,
    ExposureEvolution.Compact40Pratt.prime_21353639]

def block38 : Witness := ⟨⟨21501769, 21520320, 4639, 4643, 4649, 21501287, 21501553, 21501737⟩, 11⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4639,
    ExposureEvolution.Compact40Pratt.prime_4643,
    ExposureEvolution.Compact40Pratt.prime_4649,
    ExposureEvolution.Compact40Pratt.prime_21501287,
    ExposureEvolution.Compact40Pratt.prime_21501553,
    ExposureEvolution.Compact40Pratt.prime_21501737]

def block39 : Witness := ⟨⟨21520321, 21557448, 4643, 4649, 4651, 21520151, 21520241, 21520307⟩, 11⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4643,
    ExposureEvolution.Compact40Pratt.prime_4649,
    ExposureEvolution.Compact40Pratt.prime_4651,
    ExposureEvolution.Compact40Pratt.prime_21520151,
    ExposureEvolution.Compact40Pratt.prime_21520241,
    ExposureEvolution.Compact40Pratt.prime_21520307]

def block40 : Witness := ⟨⟨21557449, 21613200, 4649, 4651, 4657, 21556943, 21556999, 21557447⟩, 11⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4649,
    ExposureEvolution.Compact40Pratt.prime_4651,
    ExposureEvolution.Compact40Pratt.prime_4657,
    ExposureEvolution.Compact40Pratt.prime_21556943,
    ExposureEvolution.Compact40Pratt.prime_21556999,
    ExposureEvolution.Compact40Pratt.prime_21557447]

def block41 : Witness := ⟨⟨21613201, 21631800, 4651, 4657, 4663, 21612991, 21613153, 21613199⟩, 7⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4651,
    ExposureEvolution.Compact40Pratt.prime_4657,
    ExposureEvolution.Compact40Pratt.prime_4663,
    ExposureEvolution.Compact40Pratt.prime_21612991,
    ExposureEvolution.Compact40Pratt.prime_21613153,
    ExposureEvolution.Compact40Pratt.prime_21613199]

def block42 : Witness := ⟨⟨21631801, 21687648, 4657, 4663, 4673, 21631471, 21631483, 21631777⟩, 8⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4657,
    ExposureEvolution.Compact40Pratt.prime_4663,
    ExposureEvolution.Compact40Pratt.prime_4673,
    ExposureEvolution.Compact40Pratt.prime_21631471,
    ExposureEvolution.Compact40Pratt.prime_21631483,
    ExposureEvolution.Compact40Pratt.prime_21631777]

def block43 : Witness := ⟨⟨21687649, 21743568, 4663, 4673, 4679, 21687203, 21687541, 21687641⟩, 8⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4663,
    ExposureEvolution.Compact40Pratt.prime_4673,
    ExposureEvolution.Compact40Pratt.prime_4679,
    ExposureEvolution.Compact40Pratt.prime_21687203,
    ExposureEvolution.Compact40Pratt.prime_21687541,
    ExposureEvolution.Compact40Pratt.prime_21687641]

def block44 : Witness := ⟨⟨21743569, 21836928, 4673, 4679, 4691, 21743081, 21743107, 21743551⟩, 10⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4673,
    ExposureEvolution.Compact40Pratt.prime_4679,
    ExposureEvolution.Compact40Pratt.prime_4691,
    ExposureEvolution.Compact40Pratt.prime_21743081,
    ExposureEvolution.Compact40Pratt.prime_21743107,
    ExposureEvolution.Compact40Pratt.prime_21743551]

def block45 : Witness := ⟨⟨21836929, 21893040, 4679, 4691, 4703, 21836531, 21836861, 21836921⟩, 9⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4679,
    ExposureEvolution.Compact40Pratt.prime_4691,
    ExposureEvolution.Compact40Pratt.prime_4703,
    ExposureEvolution.Compact40Pratt.prime_21836531,
    ExposureEvolution.Compact40Pratt.prime_21836861,
    ExposureEvolution.Compact40Pratt.prime_21836921]

def block46 : Witness := ⟨⟨21893041, 22005480, 4691, 4703, 4721, 21892873, 21892901, 21893009⟩, 8⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4691,
    ExposureEvolution.Compact40Pratt.prime_4703,
    ExposureEvolution.Compact40Pratt.prime_4721,
    ExposureEvolution.Compact40Pratt.prime_21892873,
    ExposureEvolution.Compact40Pratt.prime_21892901,
    ExposureEvolution.Compact40Pratt.prime_21893009]

def block47 : Witness := ⟨⟨22005481, 22118208, 4703, 4721, 4723, 22005107, 22005131, 22005449⟩, 6⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4703,
    ExposureEvolution.Compact40Pratt.prime_4721,
    ExposureEvolution.Compact40Pratt.prime_4723,
    ExposureEvolution.Compact40Pratt.prime_22005107,
    ExposureEvolution.Compact40Pratt.prime_22005131,
    ExposureEvolution.Compact40Pratt.prime_22005449]

def block48 : Witness := ⟨⟨22118209, 22287840, 4721, 4723, 4729, 22117891, 22118113, 22118179⟩, 12⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4721,
    ExposureEvolution.Compact40Pratt.prime_4723,
    ExposureEvolution.Compact40Pratt.prime_4729,
    ExposureEvolution.Compact40Pratt.prime_22117891,
    ExposureEvolution.Compact40Pratt.prime_22118113,
    ExposureEvolution.Compact40Pratt.prime_22118179]

def block49 : Witness := ⟨⟨22287841, 22306728, 4723, 4729, 4733, 22287739, 22287821, 22287829⟩, 8⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4723,
    ExposureEvolution.Compact40Pratt.prime_4729,
    ExposureEvolution.Compact40Pratt.prime_4733,
    ExposureEvolution.Compact40Pratt.prime_22287739,
    ExposureEvolution.Compact40Pratt.prime_22287821,
    ExposureEvolution.Compact40Pratt.prime_22287829]

def block50 : Witness := ⟨⟨22306729, 22363440, 4729, 4733, 4751, 22306517, 22306657, 22306727⟩, 8⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4729,
    ExposureEvolution.Compact40Pratt.prime_4733,
    ExposureEvolution.Compact40Pratt.prime_4751,
    ExposureEvolution.Compact40Pratt.prime_22306517,
    ExposureEvolution.Compact40Pratt.prime_22306657,
    ExposureEvolution.Compact40Pratt.prime_22306727]

def block51 : Witness := ⟨⟨22363441, 22401288, 4733, 4751, 4759, 22362953, 22363213, 22363433⟩, 9⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4733,
    ExposureEvolution.Compact40Pratt.prime_4751,
    ExposureEvolution.Compact40Pratt.prime_4759,
    ExposureEvolution.Compact40Pratt.prime_22362953,
    ExposureEvolution.Compact40Pratt.prime_22363213,
    ExposureEvolution.Compact40Pratt.prime_22363433]

def block52 : Witness := ⟨⟨22401289, 22572000, 4751, 4759, 4783, 22401017, 22401221, 22401259⟩, 7⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4751,
    ExposureEvolution.Compact40Pratt.prime_4759,
    ExposureEvolution.Compact40Pratt.prime_4783,
    ExposureEvolution.Compact40Pratt.prime_22401017,
    ExposureEvolution.Compact40Pratt.prime_22401221,
    ExposureEvolution.Compact40Pratt.prime_22401259]

def block53 : Witness := ⟨⟨22572001, 22648080, 4759, 4783, 4787, 22571821, 22571833, 22571987⟩, 11⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4759,
    ExposureEvolution.Compact40Pratt.prime_4783,
    ExposureEvolution.Compact40Pratt.prime_4787,
    ExposureEvolution.Compact40Pratt.prime_22571821,
    ExposureEvolution.Compact40Pratt.prime_22571833,
    ExposureEvolution.Compact40Pratt.prime_22571987]

def block54 : Witness := ⟨⟨22648081, 22877088, 4783, 4787, 4789, 22647733, 22647769, 22648051⟩, 6⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4783,
    ExposureEvolution.Compact40Pratt.prime_4787,
    ExposureEvolution.Compact40Pratt.prime_4789,
    ExposureEvolution.Compact40Pratt.prime_22647733,
    ExposureEvolution.Compact40Pratt.prime_22647769,
    ExposureEvolution.Compact40Pratt.prime_22648051]

def block55 : Witness := ⟨⟨22877089, 22915368, 4787, 4789, 4793, 22876787, 22876979, 22877081⟩, 7⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4787,
    ExposureEvolution.Compact40Pratt.prime_4789,
    ExposureEvolution.Compact40Pratt.prime_4793,
    ExposureEvolution.Compact40Pratt.prime_22876787,
    ExposureEvolution.Compact40Pratt.prime_22876979,
    ExposureEvolution.Compact40Pratt.prime_22877081]

def block56 : Witness := ⟨⟨22915369, 22934520, 4789, 4793, 4799, 22914971, 22915297, 22915363⟩, 9⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4789,
    ExposureEvolution.Compact40Pratt.prime_4793,
    ExposureEvolution.Compact40Pratt.prime_4799,
    ExposureEvolution.Compact40Pratt.prime_22914971,
    ExposureEvolution.Compact40Pratt.prime_22915297,
    ExposureEvolution.Compact40Pratt.prime_22915363]

def block57 : Witness := ⟨⟨22934521, 22972848, 4793, 4799, 4801, 22934029, 22934251, 22934503⟩, 11⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4793,
    ExposureEvolution.Compact40Pratt.prime_4799,
    ExposureEvolution.Compact40Pratt.prime_4801,
    ExposureEvolution.Compact40Pratt.prime_22934029,
    ExposureEvolution.Compact40Pratt.prime_22934251,
    ExposureEvolution.Compact40Pratt.prime_22934503]

def block58 : Witness := ⟨⟨22972849, 23030400, 4799, 4801, 4813, 22972283, 22972777, 22972847⟩, 9⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4799,
    ExposureEvolution.Compact40Pratt.prime_4801,
    ExposureEvolution.Compact40Pratt.prime_4813,
    ExposureEvolution.Compact40Pratt.prime_22972283,
    ExposureEvolution.Compact40Pratt.prime_22972777,
    ExposureEvolution.Compact40Pratt.prime_22972847]

def block59 : Witness := ⟨⟨23030401, 23049600, 4801, 4813, 4817, 23030081, 23030377, 23030389⟩, 8⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4801,
    ExposureEvolution.Compact40Pratt.prime_4813,
    ExposureEvolution.Compact40Pratt.prime_4817,
    ExposureEvolution.Compact40Pratt.prime_23030081,
    ExposureEvolution.Compact40Pratt.prime_23030377,
    ExposureEvolution.Compact40Pratt.prime_23030389]

def block60 : Witness := ⟨⟨23049601, 23164968, 4813, 4817, 4831, 23049137, 23049157, 23049571⟩, 13⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4813,
    ExposureEvolution.Compact40Pratt.prime_4817,
    ExposureEvolution.Compact40Pratt.prime_4831,
    ExposureEvolution.Compact40Pratt.prime_23049137,
    ExposureEvolution.Compact40Pratt.prime_23049157,
    ExposureEvolution.Compact40Pratt.prime_23049571]

def block61 : Witness := ⟨⟨23164969, 23203488, 4817, 4831, 4861, 23164681, 23164699, 23164963⟩, 9⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4817,
    ExposureEvolution.Compact40Pratt.prime_4831,
    ExposureEvolution.Compact40Pratt.prime_4861,
    ExposureEvolution.Compact40Pratt.prime_23164681,
    ExposureEvolution.Compact40Pratt.prime_23164699,
    ExposureEvolution.Compact40Pratt.prime_23164963]

def block62 : Witness := ⟨⟨23203489, 23338560, 4831, 4861, 4871, 23203207, 23203321, 23203483⟩, 7⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4831,
    ExposureEvolution.Compact40Pratt.prime_4861,
    ExposureEvolution.Compact40Pratt.prime_4871,
    ExposureEvolution.Compact40Pratt.prime_23203207,
    ExposureEvolution.Compact40Pratt.prime_23203321,
    ExposureEvolution.Compact40Pratt.prime_23203483]

def block63 : Witness := ⟨⟨23338561, 23629320, 4861, 4871, 4877, 23338457, 23338493, 23338547⟩, 8⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4861,
    ExposureEvolution.Compact40Pratt.prime_4871,
    ExposureEvolution.Compact40Pratt.prime_4877,
    ExposureEvolution.Compact40Pratt.prime_23338457,
    ExposureEvolution.Compact40Pratt.prime_23338493,
    ExposureEvolution.Compact40Pratt.prime_23338547]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 23629321 stop tail = true) :
    coverage 18258529 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_004
