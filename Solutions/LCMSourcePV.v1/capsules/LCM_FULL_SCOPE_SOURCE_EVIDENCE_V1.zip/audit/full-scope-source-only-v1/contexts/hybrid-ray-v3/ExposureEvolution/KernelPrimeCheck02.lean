import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelPrimeCheck02
open ExposureEvolution KernelPrimeProgram
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def primes : List ℕ := [12829, 12853, 12899, 12941, 12983, 13033, 13063, 13109, 13159, 13187, 13229, 13267, 13313, 13339, 13381, 13421, 13469, 13513, 13553, 13597, 13649, 13697, 13729, 13781, 13831, 13883, 13933, 13967, 14011, 14057, 14107, 14159, 14207, 14251, 14303, 14347, 14401, 14449, 14503, 14557, 14593, 14639, 14683, 14737, 14783, 14831, 14887, 14939, 14983, 15031, 15083, 15139, 15193, 15241, 15299, 15349, 15401, 15461, 15511, 15569, 15629, 15683, 15739, 15797]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 15797 stop tail = true) :
    check 12791 stop (primes ++ tail) = true := by
  change check _ _ (12829 :: 12853 :: 12899 :: 12941 :: 12983 :: 13033 :: 13063 :: 13109 :: 13159 :: 13187 :: 13229 :: 13267 :: 13313 :: 13339 :: 13381 :: 13421 :: 13469 :: 13513 :: 13553 :: 13597 :: 13649 :: 13697 :: 13729 :: 13781 :: 13831 :: 13883 :: 13933 :: 13967 :: 14011 :: 14057 :: 14107 :: 14159 :: 14207 :: 14251 :: 14303 :: 14347 :: 14401 :: 14449 :: 14503 :: 14557 :: 14593 :: 14639 :: 14683 :: 14737 :: 14783 :: 14831 :: 14887 :: 14939 :: 14983 :: 15031 :: 15083 :: 15139 :: 15193 :: 15241 :: 15299 :: 15349 :: 15401 :: 15461 :: 15511 :: 15569 :: 15629 :: 15683 :: 15739 :: 15797 :: tail) = true
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12829, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12853, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12899, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12941, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12983, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13033, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13063, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13109, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13159, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13187, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13229, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13267, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13313, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13339, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13381, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13421, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13469, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13513, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13553, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13597, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13649, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13697, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13729, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13781, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13831, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13883, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13933, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_13967, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14011, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14057, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14107, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14159, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14207, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14251, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14303, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14347, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14401, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14449, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14503, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14557, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14593, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14639, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14683, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14737, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14783, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14831, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14887, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14939, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_14983, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15031, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15083, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15139, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15193, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15241, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15299, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15349, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15401, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15461, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15511, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15569, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15629, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15683, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15739, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15797, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms extend
end ExposureEvolution.KernelPrimeCheck02
