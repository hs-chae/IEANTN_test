/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1Tertiary.LcmTail
namespace E1Tertiary.LcmSurplus
open Finset Nat Real
open E1Tertiary.LcmBase
open E1Tertiary.LcmConstant
set_option maxHeartbeats 2000000

/-- A surplus in the original criterion gives a surplus in the actual divisor sum. -/
theorem criterion_surplus (c : Criterion) {t : ℝ} (ht : 0 ≤ t)
    (h : (1 + t) * ∏ i, (1 + (1 : ℝ) / c.q i) ≤
      (∏ i, (1 + 1 / (c.p i * (c.p i + 1) : ℝ))) *
      (1 + 3 / (8 * (c.n : ℝ))) *
      (1 - 4 * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ))) :
    (1 + t) * (σ (L c.n) : ℝ) < σ c.M := by
  have hMpos : (0 : ℝ) < c.M := by exact_mod_cast c.M_pos
  have hLpos : (0 : ℝ) < L c.n := by exact_mod_cast c.L_pos
  have hqpos : (0 : ℝ) < ∏ i, (c.q i : ℝ) := prod_pos fun i _ => by exact_mod_cast (c.hq i).pos
  have hRpos : (0 : ℝ) < 1 - 4 * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ) := by
    rw [sub_pos, div_lt_one hqpos]
    exact_mod_cast c.prod_p_le_prod_q
  have hRlt : 1 - 4 * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ) < (c.M : ℝ) / L c.n := by
    have hh := c.Ln_div_M_lt
    push_cast at hh
    rw [lt_inv_comm₀ (div_pos hLpos hMpos) hRpos, inv_div] at hh
    exact_mod_cast hh
  have hsigpos : 0 < σnorm (L c.n) := by
    rw [σnorm]; exact div_pos (by exact_mod_cast (show 0 < σ (L c.n) by
      rw [σ, ArithmeticFunction.sigma_pos_iff]; exact c.L_pos)) hLpos
  have hsig'pos : 0 ≤ σnorm c.L' := by unfold σnorm; positivity
  have hsig : (1 + t) * σnorm (L c.n) ≤ σnorm c.M *
      (1 - 4 * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ)) := by
    rw [c.σnorm_ln_eq]
    nlinarith [mul_le_mul_of_nonneg_left h hsig'pos,
      mul_le_mul_of_nonneg_right c.σnorm_M_ge_σnorm_L'_mul hRpos.le]
  have hsigMpos : 0 < σnorm c.M := by
    have : 0 < (1 + t) * σnorm (L c.n) := mul_pos (by linarith) hsigpos
    have : 0 < σnorm c.M * (1 - 4 * (∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ)) := this.trans_le hsig
    exact (mul_pos_iff_of_pos_right hRpos).mp this
  have hfinal : (1 + t) * σnorm (L c.n) < σnorm c.M * ((c.M : ℝ) / L c.n) :=
    hsig.trans_lt (mul_lt_mul_of_pos_left hRlt hsigMpos)
  dsimp [σnorm] at hfinal
  have hid : (σ c.M : ℝ) / c.M * ((c.M : ℝ) / L c.n) = σ c.M / L c.n := by field_simp
  rw [hid] at hfinal
  exact (div_lt_div_iff_of_pos_right hLpos).mp (by simpa [mul_div_assoc] using hfinal)

/-- The fixed consumer budget retains a ten-percent-of-1/n quantitative surplus. -/
theorem scalar_surplus {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (148 ^ 2 : ℝ)) :
    (1 + ε / 10) * (1 + 3.05 * ε + 3.1 * ε^2 + 1.05 * ε^3) ≤
      1 + 3.2 * ε - 0.01 * ε^2 := by
  have h2 : ε^2 ≤ ε / 148^2 := by nlinarith
  have h3 : ε^3 ≤ ε^2 / 148^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hε.2)]
  have h4 : ε^4 ≤ ε^2 / 148^4 := by
    have := mul_le_mul_of_nonneg_right h3 hε.1
    nlinarith
  nlinarith [sq_nonneg ε]

/-- The same original product criterion, keeping its natural quantitative slack. -/
theorem comparison {c X₀ : ℝ} {n : ℕ} (hd : StrictGap X₀)
    (hc : 5 ≤ c) (hcX : c ≤ log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    let C := LcmConstant.Criterion.mk' hd hc hcX hn
    (1 + 1 / (10 * (n : ℝ))) * ∏ i, (1 + (1 : ℝ) / C.q i) ≤
      (∏ i, (1 + 1 / (C.p i * (C.p i + 1) : ℝ))) *
      (1 + 3 / (8 * (n : ℝ))) *
      (1 - 4 * (∏ i, (C.p i : ℝ)) / ∏ i, (C.q i : ℝ)) := by
  dsimp only [LcmConstant.Criterion.mk']
  have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  have hngt := hn_gt hd hc hcX hn
  have hn₀ : 0 ≤ Real.log √(n : ℝ) := (hlog_pos hd hc hcX hn).le
  have h₁ : 1 - (4 : ℝ) *
      (∏ i, (exists_p_primes hd hc hcX hn).choose i : ℝ) /
        ∏ i, ((exists_q_primes hd hc hcX hn).choose i : ℝ) ≥
      1 - 4 * (1 + 1 / 125 : ℝ) ^ 12 * ((1 / 148) * (1 / n)) := by
    grw [pq_ratio_ge hd hc hcX hn,
      ← inv_n_pow_3_div_2_le hd hc hcX hn]
    simp [field]
  have hnn : 0 ≤ 1 - 4 * (1 + 1 / 125 : ℝ) ^ 12 * ((1 / 148) * (1 / n)) := by
    have : (1 : ℝ) / n ≤ 1 / 148 ^ 2 := by
      rw [div_le_div_iff₀ hnp (by norm_num)]; linarith
    nlinarith
  have := hnn.trans h₁
  have hn' : (0 : ℝ) ≤ 1 / (n : ℝ) ∧ (1 : ℝ) / (n : ℝ) ≤ 1 / 148 ^ 2 :=
    ⟨by positivity, by rw [div_le_div_iff₀ hnp (by norm_num)]; linarith⟩
  grw [prod_q_ge hd hc hcX hn, prod_p_ge hd hc hcX hn, h₁]
  simp_rw [div_eq_mul_one_div (_ ^ (_ : ℝ) : ℝ) (n : ℝ),
    show 3 / (8 * (n : ℝ)) = 3 / 8 * (1 / n) by field_simp, ← one_div_mul_one_div]
  grw [inv_n_add_sqrt_ge hd hc hcX hn]
  set ε : ℝ := 1 / (n : ℝ)
  calc
    _ ≤ (1 + (1 / 10 : ℝ) * ε) * ∏ i : Fin 3, (1 + (1 + 1 / 125 : ℝ) ^ (i + 1 : ℝ) * ε) := by gcongr
    _ = (1 + ε / 10) * ∏ i : Fin 3, (1 + (1.008 : ℝ) ^ (i + 1 : ℝ) * ε) := by norm_num <;> ring_nf <;> simp
    _ ≤ (1 + ε / 10) * (1 + 3.05 * ε + 3.1 * ε^2 + 1.05 * ε^3) :=
        mul_le_mul_of_nonneg_left (LcmConstant.prod_epsilon_le (ε := ε) hn') (by positivity)
    _ ≤ _ := scalar_surplus hn'
    _ ≤ _ := by
      grw [← LcmConstant.prod_epsilon_ge hn']
      apply le_of_eq
      simp [field]
      ring_nf

/-- Shared construction, with its prime-cover premise fully exposed. -/
theorem quantitative_of_gap {c X₀ : ℝ} (hd : StrictGap X₀)
    (hc : 5 ≤ c) (hcX : c ≤ Real.log X₀) (n : ℕ) (hn : X₀^2 ≤ (n : ℝ)) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  let C := LcmConstant.Criterion.mk' hd hc hcX hn
  refine ⟨C.M, C.M_lt, ?_⟩
  exact criterion_surplus C (by positivity) (comparison hd hc hcX hn)

/-- Strong shared no-new-provider result, after reoptimizing the old construction. -/
theorem historical_quantitative (hd : Dusart2018.v1.proposition_5_4)
    (n : ℕ) (hn : 8044834249 ≤ n) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  have hexp : exp (5 : ℝ) < 89693 := LcmTail.exp_five_small.trans (by norm_num)
  have hlog : (5 : ℝ) ≤ Real.log 89693 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (5 : ℝ)) hexp).le
  have hnn : (89693 : ℝ)^2 ≤ n := by exact_mod_cast hn
  exact quantitative_of_gap (LcmTail.gap hd) (by norm_num : (5 : ℝ) ≤ 5) hlog n hnn

end E1Tertiary.LcmSurplus
