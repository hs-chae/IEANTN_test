/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import E1Tertiary.LcmConstant
import IEANTN.Nodes.Dusart2018.v1.Conclusions
namespace E1Tertiary.LcmTail
open Real E1Tertiary.LcmConstant
theorem exp_five_small : exp (5 : ℝ) < 4096 := by
  have he : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
  calc exp (5 : ℝ) = (exp 1)^5 := by rw [Real.exp_one_pow]; norm_num
    _ ≤ (3 : ℝ)^5 := pow_le_pow_left₀ (exp_pos 1).le he.le 5
    _ < 4096 := by norm_num

/-- Frozen literature tail alone; this module imports no new prime computation. -/
theorem gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 89693 := by
  intro x hlarge
  have hx : (4096 : ℝ) ≤ x := by linarith
  have hxp : 0 < x := by linarith
  have hl : 5 < log x := by
    have hh := log_lt_log (exp_pos (5 : ℝ)) (exp_five_small.trans_le hx)
    simpa only [log_exp] using hh
  have hlp : 0 < log x := by linarith
  have hc : (125 : ℝ) < log x ^ 3 := by nlinarith [mul_pos (by linarith : 0 < log x - 5) (sq_pos_of_pos hlp)]
  obtain ⟨p, hp, hpx, hpu⟩ := hd x hlarge
  refine ⟨p, hp, hpx, hpu.trans_lt ?_⟩
  norm_num only [Real.rpow_ofNat]
  linarith [div_lt_div_of_pos_left hxp (by norm_num : (0 : ℝ) < 125) hc]
end E1Tertiary.LcmTail
