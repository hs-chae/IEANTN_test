import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks015
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_44221 : next 44221 = some 44389 := by
  have hl : (List.range ((257 * 44221 - 1) / 256 - 44221)).reverse =
      [171, 170, 169, 168, 167] ++ (List.range 167).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_44389]

theorem next_44389 : next 44389 = some 44549 := by
  have hl : (List.range ((257 * 44389 - 1) / 256 - 44389)).reverse =
      [172, 171, 170, 169, 168, 167, 166, 165, 164, 163, 162, 161, 160, 159] ++ (List.range 159).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_44549]

theorem next_44549 : next 44549 = some 44711 := by
  have hl : (List.range ((257 * 44549 - 1) / 256 - 44549)).reverse =
      [173, 172, 171, 170, 169, 168, 167, 166, 165, 164, 163, 162, 161] ++ (List.range 161).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_44711]

theorem next_44711 : next 44711 = some 44879 := by
  have hl : (List.range ((257 * 44711 - 1) / 256 - 44711)).reverse =
      [173, 172, 171, 170, 169, 168, 167] ++ (List.range 167).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_44879]

theorem next_44879 : next 44879 = some 45053 := by
  have hl : (List.range ((257 * 44879 - 1) / 256 - 44879)).reverse =
      [174, 173] ++ (List.range 173).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_45053]

theorem next_45053 : next 45053 = some 45197 := by
  have hl : (List.range ((257 * 45053 - 1) / 256 - 45053)).reverse =
      [174, 173, 172, 171, 170, 169, 168, 167, 166, 165, 164, 163, 162, 161, 160, 159, 158, 157, 156, 155, 154, 153, 152, 151, 150, 149, 148, 147, 146, 145, 144, 143] ++ (List.range 143).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_45197]

theorem next_45197 : next 45197 = some 45361 := by
  have hl : (List.range ((257 * 45197 - 1) / 256 - 45197)).reverse =
      [175, 174, 173, 172, 171, 170, 169, 168, 167, 166, 165, 164, 163] ++ (List.range 163).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_45361]

theorem next_45361 : next 45361 = some 45533 := by
  have hl : (List.range ((257 * 45361 - 1) / 256 - 45361)).reverse =
      [176, 175, 174, 173, 172, 171] ++ (List.range 171).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_45533]

theorem next_45533 : next 45533 = some 45707 := by
  have hl : (List.range ((257 * 45533 - 1) / 256 - 45533)).reverse =
      [176, 175, 174, 173] ++ (List.range 173).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_45707]

theorem next_45707 : next 45707 = some 45869 := by
  have hl : (List.range ((257 * 45707 - 1) / 256 - 45707)).reverse =
      [177, 176, 175, 174, 173, 172, 171, 170, 169, 168, 167, 166, 165, 164, 163, 162, 161] ++ (List.range 161).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_45869]

theorem next_45869 : next 45869 = some 46027 := by
  have hl : (List.range ((257 * 45869 - 1) / 256 - 45869)).reverse =
      [178, 177, 176, 175, 174, 173, 172, 171, 170, 169, 168, 167, 166, 165, 164, 163, 162, 161, 160, 159, 158, 157] ++ (List.range 157).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_46027]

theorem next_46027 : next 46027 = some 46199 := by
  have hl : (List.range ((257 * 46027 - 1) / 256 - 46027)).reverse =
      [178, 177, 176, 175, 174, 173, 172, 171] ++ (List.range 171).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_46199]

theorem next_46199 : next 46199 = some 46351 := by
  have hl : (List.range ((257 * 46199 - 1) / 256 - 46199)).reverse =
      [179, 178, 177, 176, 175, 174, 173, 172, 171, 170, 169, 168, 167, 166, 165, 164, 163, 162, 161, 160, 159, 158, 157, 156, 155, 154, 153, 152, 151] ++ (List.range 151).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_46351]

theorem next_46351 : next 46351 = some 46523 := by
  have hl : (List.range ((257 * 46351 - 1) / 256 - 46351)).reverse =
      [180, 179, 178, 177, 176, 175, 174, 173, 172, 171] ++ (List.range 171).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_46523]

theorem next_46523 : next 46523 = some 46703 := by
  have hl : (List.range ((257 * 46523 - 1) / 256 - 46523)).reverse =
      [180, 179] ++ (List.range 179).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_46703]

theorem next_46703 : next 46703 = some 46877 := by
  have hl : (List.range ((257 * 46703 - 1) / 256 - 46703)).reverse =
      [181, 180, 179, 178, 177, 176, 175, 174, 173] ++ (List.range 173).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_46877]

theorem next_46877 : next 46877 = some 47059 := by
  have hl : (List.range ((257 * 46877 - 1) / 256 - 46877)).reverse =
      [182, 181] ++ (List.range 181).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_47059]

theorem next_47059 : next 47059 = some 47237 := by
  have hl : (List.range ((257 * 47059 - 1) / 256 - 47059)).reverse =
      [182, 181, 180, 179, 178, 177] ++ (List.range 177).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_47237]

theorem next_47237 : next 47237 = some 47419 := by
  have hl : (List.range ((257 * 47237 - 1) / 256 - 47237)).reverse =
      [183, 182, 181] ++ (List.range 181).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_47419]

theorem next_47419 : next 47419 = some 47599 := by
  have hl : (List.range ((257 * 47419 - 1) / 256 - 47419)).reverse =
      [184, 183, 182, 181, 180, 179] ++ (List.range 179).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_47599]

theorem next_47599 : next 47599 = some 47779 := by
  have hl : (List.range ((257 * 47599 - 1) / 256 - 47599)).reverse =
      [184, 183, 182, 181, 180, 179] ++ (List.range 179).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_47779]

theorem next_47779 : next 47779 = some 47963 := by
  have hl : (List.range ((257 * 47779 - 1) / 256 - 47779)).reverse =
      [185, 184, 183] ++ (List.range 183).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_47963]

theorem next_47963 : next 47963 = some 48131 := by
  have hl : (List.range ((257 * 47963 - 1) / 256 - 47963)).reverse =
      [186, 185, 184, 183, 182, 181, 180, 179, 178, 177, 176, 175, 174, 173, 172, 171, 170, 169, 168, 167] ++ (List.range 167).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_48131]

theorem next_48131 : next 48131 = some 48313 := by
  have hl : (List.range ((257 * 48131 - 1) / 256 - 48131)).reverse =
      [187, 186, 185, 184, 183, 182, 181] ++ (List.range 181).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_48313]

theorem next_48313 : next 48313 = some 48497 := by
  have hl : (List.range ((257 * 48313 - 1) / 256 - 48313)).reverse =
      [187, 186, 185, 184, 183] ++ (List.range 183).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_48497]

theorem next_48497 : next 48497 = some 48679 := by
  have hl : (List.range ((257 * 48497 - 1) / 256 - 48497)).reverse =
      [188, 187, 186, 185, 184, 183, 182, 181] ++ (List.range 181).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_48679]

theorem next_48679 : next 48679 = some 48869 := by
  have hl : (List.range ((257 * 48679 - 1) / 256 - 48679)).reverse =
      [189] ++ (List.range 189).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_48869]

theorem next_48869 : next 48869 = some 49057 := by
  have hl : (List.range ((257 * 48869 - 1) / 256 - 48869)).reverse =
      [189, 188, 187] ++ (List.range 187).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_49057]

theorem next_49057 : next 49057 = some 49223 := by
  have hl : (List.range ((257 * 49057 - 1) / 256 - 49057)).reverse =
      [190, 189, 188, 187, 186, 185, 184, 183, 182, 181, 180, 179, 178, 177, 176, 175, 174, 173, 172, 171, 170, 169, 168, 167, 166, 165] ++ (List.range 165).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_49223]

theorem next_49223 : next 49223 = some 49411 := by
  have hl : (List.range ((257 * 49223 - 1) / 256 - 49223)).reverse =
      [191, 190, 189, 188, 187] ++ (List.range 187).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_49411]

theorem next_49411 : next 49411 = some 49603 := by
  have hl : (List.range ((257 * 49411 - 1) / 256 - 49411)).reverse =
      [192, 191] ++ (List.range 191).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_49603]

theorem next_49603 : next 49603 = some 49789 := by
  have hl : (List.range ((257 * 49603 - 1) / 256 - 49603)).reverse =
      [192, 191, 190, 189, 188, 187, 186, 185] ++ (List.range 185).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_49789]

def primes : List ℕ := [44389, 44549, 44711, 44879, 45053, 45197, 45361, 45533, 45707, 45869, 46027, 46199, 46351, 46523, 46703, 46877, 47059, 47237, 47419, 47599, 47779, 47963, 48131, 48313, 48497, 48679, 48869, 49057, 49223, 49411, 49603, 49789]

theorem segment : run 220 44221 89693 =
    primes ++ run 188 49789 89693 := by
  rw [Compact40PrimeCompose256.step 219 44221 89693 44389
    (by decide +kernel) next_44221]
  rw [Compact40PrimeCompose256.step 218 44389 89693 44549
    (by decide +kernel) next_44389]
  rw [Compact40PrimeCompose256.step 217 44549 89693 44711
    (by decide +kernel) next_44549]
  rw [Compact40PrimeCompose256.step 216 44711 89693 44879
    (by decide +kernel) next_44711]
  rw [Compact40PrimeCompose256.step 215 44879 89693 45053
    (by decide +kernel) next_44879]
  rw [Compact40PrimeCompose256.step 214 45053 89693 45197
    (by decide +kernel) next_45053]
  rw [Compact40PrimeCompose256.step 213 45197 89693 45361
    (by decide +kernel) next_45197]
  rw [Compact40PrimeCompose256.step 212 45361 89693 45533
    (by decide +kernel) next_45361]
  rw [Compact40PrimeCompose256.step 211 45533 89693 45707
    (by decide +kernel) next_45533]
  rw [Compact40PrimeCompose256.step 210 45707 89693 45869
    (by decide +kernel) next_45707]
  rw [Compact40PrimeCompose256.step 209 45869 89693 46027
    (by decide +kernel) next_45869]
  rw [Compact40PrimeCompose256.step 208 46027 89693 46199
    (by decide +kernel) next_46027]
  rw [Compact40PrimeCompose256.step 207 46199 89693 46351
    (by decide +kernel) next_46199]
  rw [Compact40PrimeCompose256.step 206 46351 89693 46523
    (by decide +kernel) next_46351]
  rw [Compact40PrimeCompose256.step 205 46523 89693 46703
    (by decide +kernel) next_46523]
  rw [Compact40PrimeCompose256.step 204 46703 89693 46877
    (by decide +kernel) next_46703]
  rw [Compact40PrimeCompose256.step 203 46877 89693 47059
    (by decide +kernel) next_46877]
  rw [Compact40PrimeCompose256.step 202 47059 89693 47237
    (by decide +kernel) next_47059]
  rw [Compact40PrimeCompose256.step 201 47237 89693 47419
    (by decide +kernel) next_47237]
  rw [Compact40PrimeCompose256.step 200 47419 89693 47599
    (by decide +kernel) next_47419]
  rw [Compact40PrimeCompose256.step 199 47599 89693 47779
    (by decide +kernel) next_47599]
  rw [Compact40PrimeCompose256.step 198 47779 89693 47963
    (by decide +kernel) next_47779]
  rw [Compact40PrimeCompose256.step 197 47963 89693 48131
    (by decide +kernel) next_47963]
  rw [Compact40PrimeCompose256.step 196 48131 89693 48313
    (by decide +kernel) next_48131]
  rw [Compact40PrimeCompose256.step 195 48313 89693 48497
    (by decide +kernel) next_48313]
  rw [Compact40PrimeCompose256.step 194 48497 89693 48679
    (by decide +kernel) next_48497]
  rw [Compact40PrimeCompose256.step 193 48679 89693 48869
    (by decide +kernel) next_48679]
  rw [Compact40PrimeCompose256.step 192 48869 89693 49057
    (by decide +kernel) next_48869]
  rw [Compact40PrimeCompose256.step 191 49057 89693 49223
    (by decide +kernel) next_49057]
  rw [Compact40PrimeCompose256.step 190 49223 89693 49411
    (by decide +kernel) next_49223]
  rw [Compact40PrimeCompose256.step 189 49411 89693 49603
    (by decide +kernel) next_49411]
  rw [Compact40PrimeCompose256.step 188 49603 89693 49789
    (by decide +kernel) next_49603]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 49789 stop tail = true) :
    check 44221 stop (primes ++ tail) = true := by
  change check _ _ (44389 :: 44549 :: 44711 :: 44879 :: 45053 :: 45197 :: 45361 :: 45533 :: 45707 :: 45869 :: 46027 :: 46199 :: 46351 :: 46523 :: 46703 :: 46877 :: 47059 :: 47237 :: 47419 :: 47599 :: 47779 :: 47963 :: 48131 :: 48313 :: 48497 :: 48679 :: 48869 :: 49057 :: 49223 :: 49411 :: 49603 :: 49789 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_44389, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_44549, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_44711, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_44879, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_45053, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_45197, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_45361, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_45533, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_45707, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_45869, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_46027, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_46199, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_46351, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_46523, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_46703, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_46877, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_47059, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_47237, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_47419, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_47599, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_47779, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_47963, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_48131, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_48313, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_48497, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_48679, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_48869, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_49057, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_49223, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_49411, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_49603, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_49789, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks015
