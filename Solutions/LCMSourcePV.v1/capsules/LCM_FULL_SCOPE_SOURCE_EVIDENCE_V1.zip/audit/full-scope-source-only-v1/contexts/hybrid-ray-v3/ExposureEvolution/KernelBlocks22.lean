import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks22
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨45954841, 45981960, 6781, 6791, 6793, 45954511, 45954607, 45954833⟩, 12⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6781,
    ExposureEvolution.KernelPratt.prime_6791,
    ExposureEvolution.KernelPratt.prime_6793,
    ExposureEvolution.KernelPratt.prime_45954511,
    ExposureEvolution.KernelPratt.prime_45954607,
    ExposureEvolution.KernelPratt.prime_45954833]

def block01 : Witness := ⟨⟨45981961, 46117680, 6791, 6793, 6803, 45981371, 45981937, 45981953⟩, 9⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6791,
    ExposureEvolution.KernelPratt.prime_6793,
    ExposureEvolution.KernelPratt.prime_6803,
    ExposureEvolution.KernelPratt.prime_45981371,
    ExposureEvolution.KernelPratt.prime_45981937,
    ExposureEvolution.KernelPratt.prime_45981953]

def block02 : Witness := ⟨⟨46117681, 46144848, 6793, 6803, 6823, 46117327, 46117451, 46117667⟩, 12⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6793,
    ExposureEvolution.KernelPratt.prime_6803,
    ExposureEvolution.KernelPratt.prime_6823,
    ExposureEvolution.KernelPratt.prime_46117327,
    ExposureEvolution.KernelPratt.prime_46117451,
    ExposureEvolution.KernelPratt.prime_46117667]

def block03 : Witness := ⟨⟨46144849, 46280808, 6803, 6823, 6827, 46144493, 46144669, 46144837⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6803,
    ExposureEvolution.KernelPratt.prime_6823,
    ExposureEvolution.KernelPratt.prime_6827,
    ExposureEvolution.KernelPratt.prime_46144493,
    ExposureEvolution.KernelPratt.prime_46144669,
    ExposureEvolution.KernelPratt.prime_46144837]

def block04 : Witness := ⟨⟨46280809, 46553328, 6823, 6827, 6829, 46280309, 46280519, 46280803⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6823,
    ExposureEvolution.KernelPratt.prime_6827,
    ExposureEvolution.KernelPratt.prime_6829,
    ExposureEvolution.KernelPratt.prime_46280309,
    ExposureEvolution.KernelPratt.prime_46280519,
    ExposureEvolution.KernelPratt.prime_46280803]

def block05 : Witness := ⟨⟨46553329, 46607928, 6827, 6829, 6833, 46552813, 46552969, 46553321⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6827,
    ExposureEvolution.KernelPratt.prime_6829,
    ExposureEvolution.KernelPratt.prime_6833,
    ExposureEvolution.KernelPratt.prime_46552813,
    ExposureEvolution.KernelPratt.prime_46552969,
    ExposureEvolution.KernelPratt.prime_46553321]

def block06 : Witness := ⟨⟨46607929, 46635240, 6829, 6833, 6841, 46607797, 46607839, 46607923⟩, 10⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6829,
    ExposureEvolution.KernelPratt.prime_6833,
    ExposureEvolution.KernelPratt.prime_6841,
    ExposureEvolution.KernelPratt.prime_46607797,
    ExposureEvolution.KernelPratt.prime_46607839,
    ExposureEvolution.KernelPratt.prime_46607923]

def block07 : Witness := ⟨⟨46635241, 46689888, 6833, 6841, 6857, 46634719, 46634743, 46635227⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6833,
    ExposureEvolution.KernelPratt.prime_6841,
    ExposureEvolution.KernelPratt.prime_6857,
    ExposureEvolution.KernelPratt.prime_46634719,
    ExposureEvolution.KernelPratt.prime_46634743,
    ExposureEvolution.KernelPratt.prime_46635227]

def block08 : Witness := ⟨⟨46689889, 46799280, 6841, 6857, 6863, 46689469, 46689607, 46689829⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6841,
    ExposureEvolution.KernelPratt.prime_6857,
    ExposureEvolution.KernelPratt.prime_6863,
    ExposureEvolution.KernelPratt.prime_46689469,
    ExposureEvolution.KernelPratt.prime_46689607,
    ExposureEvolution.KernelPratt.prime_46689829]

def block09 : Witness := ⟨⟨46799281, 47018448, 6857, 6863, 6869, 46798867, 46798993, 46799257⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6857,
    ExposureEvolution.KernelPratt.prime_6863,
    ExposureEvolution.KernelPratt.prime_6869,
    ExposureEvolution.KernelPratt.prime_46798867,
    ExposureEvolution.KernelPratt.prime_46798993,
    ExposureEvolution.KernelPratt.prime_46799257]

def block10 : Witness := ⟨⟨47018449, 47100768, 6863, 6869, 6871, 47018099, 47018333, 47018443⟩, 12⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6863,
    ExposureEvolution.KernelPratt.prime_6869,
    ExposureEvolution.KernelPratt.prime_6871,
    ExposureEvolution.KernelPratt.prime_47018099,
    ExposureEvolution.KernelPratt.prime_47018333,
    ExposureEvolution.KernelPratt.prime_47018443]

def block11 : Witness := ⟨⟨47100769, 47183160, 6869, 6871, 6883, 47100271, 47100631, 47100763⟩, 8⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6869,
    ExposureEvolution.KernelPratt.prime_6871,
    ExposureEvolution.KernelPratt.prime_6883,
    ExposureEvolution.KernelPratt.prime_47100271,
    ExposureEvolution.KernelPratt.prime_47100631,
    ExposureEvolution.KernelPratt.prime_47100763]

def block12 : Witness := ⟨⟨47183161, 47210640, 6871, 6883, 6899, 47182657, 47182693, 47183153⟩, 8⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6871,
    ExposureEvolution.KernelPratt.prime_6883,
    ExposureEvolution.KernelPratt.prime_6899,
    ExposureEvolution.KernelPratt.prime_47182657,
    ExposureEvolution.KernelPratt.prime_47182693,
    ExposureEvolution.KernelPratt.prime_47183153]

def block13 : Witness := ⟨⟨47210641, 47375688, 6883, 6899, 6907, 47210297, 47210357, 47210629⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6883,
    ExposureEvolution.KernelPratt.prime_6899,
    ExposureEvolution.KernelPratt.prime_6907,
    ExposureEvolution.KernelPratt.prime_47210297,
    ExposureEvolution.KernelPratt.prime_47210357,
    ExposureEvolution.KernelPratt.prime_47210629]

def block14 : Witness := ⟨⟨47375689, 47596200, 6899, 6907, 6911, 47375491, 47375677, 47375687⟩, 11⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6899,
    ExposureEvolution.KernelPratt.prime_6907,
    ExposureEvolution.KernelPratt.prime_6911,
    ExposureEvolution.KernelPratt.prime_47375491,
    ExposureEvolution.KernelPratt.prime_47375677,
    ExposureEvolution.KernelPratt.prime_47375687]

def block15 : Witness := ⟨⟨47596201, 47706648, 6907, 6911, 6917, 47595857, 47596189, 47596193⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6907,
    ExposureEvolution.KernelPratt.prime_6911,
    ExposureEvolution.KernelPratt.prime_6917,
    ExposureEvolution.KernelPratt.prime_47595857,
    ExposureEvolution.KernelPratt.prime_47596189,
    ExposureEvolution.KernelPratt.prime_47596193]

def block16 : Witness := ⟨⟨47706649, 47761920, 6911, 6917, 6947, 47706151, 47706181, 47706629⟩, 8⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6911,
    ExposureEvolution.KernelPratt.prime_6917,
    ExposureEvolution.KernelPratt.prime_6947,
    ExposureEvolution.KernelPratt.prime_47706151,
    ExposureEvolution.KernelPratt.prime_47706181,
    ExposureEvolution.KernelPratt.prime_47706629]

def block17 : Witness := ⟨⟨47761921, 47844888, 6917, 6947, 6949, 47761601, 47761699, 47761919⟩, 10⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6917,
    ExposureEvolution.KernelPratt.prime_6947,
    ExposureEvolution.KernelPratt.prime_6949,
    ExposureEvolution.KernelPratt.prime_47761601,
    ExposureEvolution.KernelPratt.prime_47761699,
    ExposureEvolution.KernelPratt.prime_47761919]

def block18 : Witness := ⟨⟨47844889, 48260808, 6947, 6949, 6959, 47844383, 47844607, 47844877⟩, 14⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6947,
    ExposureEvolution.KernelPratt.prime_6949,
    ExposureEvolution.KernelPratt.prime_6959,
    ExposureEvolution.KernelPratt.prime_47844383,
    ExposureEvolution.KernelPratt.prime_47844607,
    ExposureEvolution.KernelPratt.prime_47844877]

def block19 : Witness := ⟨⟨48260809, 48288600, 6949, 6959, 6961, 48260593, 48260789, 48260801⟩, 7⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6949,
    ExposureEvolution.KernelPratt.prime_6959,
    ExposureEvolution.KernelPratt.prime_6961,
    ExposureEvolution.KernelPratt.prime_48260593,
    ExposureEvolution.KernelPratt.prime_48260789,
    ExposureEvolution.KernelPratt.prime_48260801]

def block20 : Witness := ⟨⟨48288601, 48427680, 6959, 6961, 6967, 48288083, 48288323, 48288571⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6959,
    ExposureEvolution.KernelPratt.prime_6961,
    ExposureEvolution.KernelPratt.prime_6967,
    ExposureEvolution.KernelPratt.prime_48288083,
    ExposureEvolution.KernelPratt.prime_48288323,
    ExposureEvolution.KernelPratt.prime_48288571]

def block21 : Witness := ⟨⟨48427681, 48455520, 6961, 6967, 6971, 48427307, 48427649, 48427661⟩, 7⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6961,
    ExposureEvolution.KernelPratt.prime_6967,
    ExposureEvolution.KernelPratt.prime_6971,
    ExposureEvolution.KernelPratt.prime_48427307,
    ExposureEvolution.KernelPratt.prime_48427649,
    ExposureEvolution.KernelPratt.prime_48427661]

def block22 : Witness := ⟨⟨48455521, 48539088, 6967, 6971, 6977, 48454999, 48455131, 48455513⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6967,
    ExposureEvolution.KernelPratt.prime_6971,
    ExposureEvolution.KernelPratt.prime_6977,
    ExposureEvolution.KernelPratt.prime_48454999,
    ExposureEvolution.KernelPratt.prime_48455131,
    ExposureEvolution.KernelPratt.prime_48455513]

def block23 : Witness := ⟨⟨48539089, 48594840, 6971, 6977, 6983, 48538759, 48538781, 48539083⟩, 13⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6971,
    ExposureEvolution.KernelPratt.prime_6977,
    ExposureEvolution.KernelPratt.prime_6983,
    ExposureEvolution.KernelPratt.prime_48538759,
    ExposureEvolution.KernelPratt.prime_48538781,
    ExposureEvolution.KernelPratt.prime_48539083]

def block24 : Witness := ⟨⟨48594841, 48678528, 6977, 6983, 6991, 48594437, 48594479, 48594827⟩, 11⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6977,
    ExposureEvolution.KernelPratt.prime_6983,
    ExposureEvolution.KernelPratt.prime_6991,
    ExposureEvolution.KernelPratt.prime_48594437,
    ExposureEvolution.KernelPratt.prime_48594479,
    ExposureEvolution.KernelPratt.prime_48594827]

def block25 : Witness := ⟨⟨48678529, 48762288, 6983, 6991, 6997, 48678173, 48678251, 48678491⟩, 7⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6983,
    ExposureEvolution.KernelPratt.prime_6991,
    ExposureEvolution.KernelPratt.prime_6997,
    ExposureEvolution.KernelPratt.prime_48678173,
    ExposureEvolution.KernelPratt.prime_48678251,
    ExposureEvolution.KernelPratt.prime_48678491]

def block26 : Witness := ⟨⟨48762289, 48874080, 6991, 6997, 7001, 48761969, 48762011, 48762283⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6991,
    ExposureEvolution.KernelPratt.prime_6997,
    ExposureEvolution.KernelPratt.prime_7001,
    ExposureEvolution.KernelPratt.prime_48761969,
    ExposureEvolution.KernelPratt.prime_48762011,
    ExposureEvolution.KernelPratt.prime_48762283]

def block27 : Witness := ⟨⟨48874081, 48958008, 6997, 7001, 7013, 48873683, 48873973, 48874051⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6997,
    ExposureEvolution.KernelPratt.prime_7001,
    ExposureEvolution.KernelPratt.prime_7013,
    ExposureEvolution.KernelPratt.prime_48873683,
    ExposureEvolution.KernelPratt.prime_48873973,
    ExposureEvolution.KernelPratt.prime_48874051]

def block28 : Witness := ⟨⟨48958009, 49014000, 7001, 7013, 7019, 48957653, 48957757, 48958001⟩, 11⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7001,
    ExposureEvolution.KernelPratt.prime_7013,
    ExposureEvolution.KernelPratt.prime_7019,
    ExposureEvolution.KernelPratt.prime_48957653,
    ExposureEvolution.KernelPratt.prime_48957757,
    ExposureEvolution.KernelPratt.prime_48958001]

def block29 : Witness := ⟨⟨49014001, 49182168, 7013, 7019, 7027, 49013803, 49013929, 49013971⟩, 10⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7013,
    ExposureEvolution.KernelPratt.prime_7019,
    ExposureEvolution.KernelPratt.prime_7027,
    ExposureEvolution.KernelPratt.prime_49013803,
    ExposureEvolution.KernelPratt.prime_49013929,
    ExposureEvolution.KernelPratt.prime_49013971]

def block30 : Witness := ⟨⟨49182169, 49266360, 7019, 7027, 7039, 49181617, 49181729, 49182149⟩, 12⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7019,
    ExposureEvolution.KernelPratt.prime_7027,
    ExposureEvolution.KernelPratt.prime_7039,
    ExposureEvolution.KernelPratt.prime_49181617,
    ExposureEvolution.KernelPratt.prime_49181729,
    ExposureEvolution.KernelPratt.prime_49182149]

def block31 : Witness := ⟨⟨49266361, 49378728, 7027, 7039, 7043, 49266229, 49266233, 49266353⟩, 8⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7027,
    ExposureEvolution.KernelPratt.prime_7039,
    ExposureEvolution.KernelPratt.prime_7043,
    ExposureEvolution.KernelPratt.prime_49266229,
    ExposureEvolution.KernelPratt.prime_49266233,
    ExposureEvolution.KernelPratt.prime_49266353]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 49378729 stop tail = true) :
    coverage 45954841 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks22
