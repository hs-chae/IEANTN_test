import ExposureEvolution.KernelPrimeChecked
namespace ExposureEvolution.KernelFullGap
open Real ExposureEvolution.KernelPrimeProgram ExposureEvolution.KernelPrimeChecked

theorem full_gap (hd : Dusart2018.v1.proposition_5_4) : StrictGap 8468 := by
  intro x hx
  by_cases ht : x < 89693
  · exact covered hx ht
  · have hlarge : (89693 : ℝ) ≤ x := le_of_not_gt ht
    have hx0 : 0 < x := by linarith
    have he : exp (7 : ℝ) < 89693 := by
      have h1 : exp 1 < 3 := by linarith [Real.exp_one_lt_d9]
      calc exp (7 : ℝ) = (exp 1) ^ 7 := by rw [Real.exp_one_pow]; norm_num
        _ ≤ (3 : ℝ) ^ 7 := pow_le_pow_left₀ (exp_pos 1).le h1.le 7
        _ < 89693 := by norm_num
    have hl : 7 < log x := by
      have hh := log_lt_log (exp_pos (7 : ℝ)) (he.trans_le hlarge)
      simpa only [log_exp] using hh
    have hlp : 0 < log x := by linarith
    have hc : (256 : ℝ) < log x ^ 3 := by
      nlinarith [mul_pos (by linarith : 0 < log x - 7) (sq_pos_of_pos hlp)]
    obtain ⟨p, hp, hpx, hpu⟩ := hd x hlarge
    refine ⟨p, hp, hpx, hpu.trans_lt ?_⟩
    norm_num only [Real.rpow_ofNat]
    linarith [div_lt_div_of_pos_left hx0 (by norm_num : (0 : ℝ) < 256) hc]

#print axioms full_gap
end ExposureEvolution.KernelFullGap
