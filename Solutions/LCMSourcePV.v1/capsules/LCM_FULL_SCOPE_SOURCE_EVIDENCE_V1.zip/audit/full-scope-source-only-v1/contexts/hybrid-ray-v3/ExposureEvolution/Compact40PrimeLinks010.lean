import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks010
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_24683 : next 24683 = some 24767 := by
  have hl : (List.range ((257 * 24683 - 1) / 256 - 24683)).reverse =
      [95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24767]

theorem next_24767 : next 24767 = some 24859 := by
  have hl : (List.range ((257 * 24767 - 1) / 256 - 24767)).reverse =
      [95, 94, 93, 92, 91] ++ (List.range 91).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24859]

theorem next_24859 : next 24859 = some 24953 := by
  have hl : (List.range ((257 * 24859 - 1) / 256 - 24859)).reverse =
      [96, 95, 94, 93] ++ (List.range 93).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24953]

theorem next_24953 : next 24953 = some 25037 := by
  have hl : (List.range ((257 * 24953 - 1) / 256 - 24953)).reverse =
      [96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25037]

theorem next_25037 : next 25037 = some 25127 := by
  have hl : (List.range ((257 * 25037 - 1) / 256 - 25037)).reverse =
      [96, 95, 94, 93, 92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25127]

theorem next_25127 : next 25127 = some 25219 := by
  have hl : (List.range ((257 * 25127 - 1) / 256 - 25127)).reverse =
      [97, 96, 95, 94, 93, 92, 91] ++ (List.range 91).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25219]

theorem next_25219 : next 25219 = some 25309 := by
  have hl : (List.range ((257 * 25219 - 1) / 256 - 25219)).reverse =
      [97, 96, 95, 94, 93, 92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25309]

theorem next_25309 : next 25309 = some 25391 := by
  have hl : (List.range ((257 * 25309 - 1) / 256 - 25309)).reverse =
      [97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81] ++ (List.range 81).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25391]

theorem next_25391 : next 25391 = some 25471 := by
  have hl : (List.range ((257 * 25391 - 1) / 256 - 25391)).reverse =
      [98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 80, 79] ++ (List.range 79).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25471]

theorem next_25471 : next 25471 = some 25561 := by
  have hl : (List.range ((257 * 25471 - 1) / 256 - 25471)).reverse =
      [98, 97, 96, 95, 94, 93, 92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25561]

theorem next_25561 : next 25561 = some 25657 := by
  have hl : (List.range ((257 * 25561 - 1) / 256 - 25561)).reverse =
      [98, 97, 96, 95] ++ (List.range 95).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25657]

theorem next_25657 : next 25657 = some 25747 := by
  have hl : (List.range ((257 * 25657 - 1) / 256 - 25657)).reverse =
      [99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25747]

theorem next_25747 : next 25747 = some 25847 := by
  have hl : (List.range ((257 * 25747 - 1) / 256 - 25747)).reverse =
      [99] ++ (List.range 99).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25847]

theorem next_25847 : next 25847 = some 25943 := by
  have hl : (List.range ((257 * 25847 - 1) / 256 - 25847)).reverse =
      [99, 98, 97, 96, 95] ++ (List.range 95).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_25943]

theorem next_25943 : next 25943 = some 26041 := by
  have hl : (List.range ((257 * 25943 - 1) / 256 - 25943)).reverse =
      [100, 99, 98, 97] ++ (List.range 97).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26041]

theorem next_26041 : next 26041 = some 26141 := by
  have hl : (List.range ((257 * 26041 - 1) / 256 - 26041)).reverse =
      [100, 99] ++ (List.range 99).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26141]

theorem next_26141 : next 26141 = some 26237 := by
  have hl : (List.range ((257 * 26141 - 1) / 256 - 26141)).reverse =
      [101, 100, 99, 98, 97, 96, 95] ++ (List.range 95).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26237]

theorem next_26237 : next 26237 = some 26339 := by
  have hl : (List.range ((257 * 26237 - 1) / 256 - 26237)).reverse =
      [101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26339]

theorem next_26339 : next 26339 = some 26437 := by
  have hl : (List.range ((257 * 26339 - 1) / 256 - 26339)).reverse =
      [101, 100, 99, 98, 97] ++ (List.range 97).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26437]

theorem next_26437 : next 26437 = some 26539 := by
  have hl : (List.range ((257 * 26437 - 1) / 256 - 26437)).reverse =
      [102, 101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26539]

theorem next_26539 : next 26539 = some 26641 := by
  have hl : (List.range ((257 * 26539 - 1) / 256 - 26539)).reverse =
      [102, 101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26641]

theorem next_26641 : next 26641 = some 26737 := by
  have hl : (List.range ((257 * 26641 - 1) / 256 - 26641)).reverse =
      [103, 102, 101, 100, 99, 98, 97, 96, 95] ++ (List.range 95).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26737]

theorem next_26737 : next 26737 = some 26839 := by
  have hl : (List.range ((257 * 26737 - 1) / 256 - 26737)).reverse =
      [103, 102, 101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26839]

theorem next_26839 : next 26839 = some 26927 := by
  have hl : (List.range ((257 * 26839 - 1) / 256 - 26839)).reverse =
      [103, 102, 101, 100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87] ++ (List.range 87).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_26927]

theorem next_26927 : next 26927 = some 27031 := by
  have hl : (List.range ((257 * 26927 - 1) / 256 - 26927)).reverse =
      [104, 103] ++ (List.range 103).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27031]

theorem next_27031 : next 27031 = some 27127 := by
  have hl : (List.range ((257 * 27031 - 1) / 256 - 27031)).reverse =
      [104, 103, 102, 101, 100, 99, 98, 97, 96, 95] ++ (List.range 95).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27127]

theorem next_27127 : next 27127 = some 27211 := by
  have hl : (List.range ((257 * 27127 - 1) / 256 - 27127)).reverse =
      [104, 103, 102, 101, 100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27211]

theorem next_27211 : next 27211 = some 27299 := by
  have hl : (List.range ((257 * 27211 - 1) / 256 - 27211)).reverse =
      [105, 104, 103, 102, 101, 100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87] ++ (List.range 87).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27299]

theorem next_27299 : next 27299 = some 27397 := by
  have hl : (List.range ((257 * 27299 - 1) / 256 - 27299)).reverse =
      [105, 104, 103, 102, 101, 100, 99, 98, 97] ++ (List.range 97).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27397]

theorem next_27397 : next 27397 = some 27487 := by
  have hl : (List.range ((257 * 27397 - 1) / 256 - 27397)).reverse =
      [106, 105, 104, 103, 102, 101, 100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27487]

theorem next_27487 : next 27487 = some 27583 := by
  have hl : (List.range ((257 * 27487 - 1) / 256 - 27487)).reverse =
      [106, 105, 104, 103, 102, 101, 100, 99, 98, 97, 96, 95] ++ (List.range 95).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27583]

theorem next_27583 : next 27583 = some 27689 := by
  have hl : (List.range ((257 * 27583 - 1) / 256 - 27583)).reverse =
      [106, 105] ++ (List.range 105).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27689]

def primes : List ℕ := [24767, 24859, 24953, 25037, 25127, 25219, 25309, 25391, 25471, 25561, 25657, 25747, 25847, 25943, 26041, 26141, 26237, 26339, 26437, 26539, 26641, 26737, 26839, 26927, 27031, 27127, 27211, 27299, 27397, 27487, 27583, 27689]

theorem segment : run 380 24683 89693 =
    primes ++ run 348 27689 89693 := by
  rw [Compact40PrimeCompose256.step 379 24683 89693 24767
    (by decide +kernel) next_24683]
  rw [Compact40PrimeCompose256.step 378 24767 89693 24859
    (by decide +kernel) next_24767]
  rw [Compact40PrimeCompose256.step 377 24859 89693 24953
    (by decide +kernel) next_24859]
  rw [Compact40PrimeCompose256.step 376 24953 89693 25037
    (by decide +kernel) next_24953]
  rw [Compact40PrimeCompose256.step 375 25037 89693 25127
    (by decide +kernel) next_25037]
  rw [Compact40PrimeCompose256.step 374 25127 89693 25219
    (by decide +kernel) next_25127]
  rw [Compact40PrimeCompose256.step 373 25219 89693 25309
    (by decide +kernel) next_25219]
  rw [Compact40PrimeCompose256.step 372 25309 89693 25391
    (by decide +kernel) next_25309]
  rw [Compact40PrimeCompose256.step 371 25391 89693 25471
    (by decide +kernel) next_25391]
  rw [Compact40PrimeCompose256.step 370 25471 89693 25561
    (by decide +kernel) next_25471]
  rw [Compact40PrimeCompose256.step 369 25561 89693 25657
    (by decide +kernel) next_25561]
  rw [Compact40PrimeCompose256.step 368 25657 89693 25747
    (by decide +kernel) next_25657]
  rw [Compact40PrimeCompose256.step 367 25747 89693 25847
    (by decide +kernel) next_25747]
  rw [Compact40PrimeCompose256.step 366 25847 89693 25943
    (by decide +kernel) next_25847]
  rw [Compact40PrimeCompose256.step 365 25943 89693 26041
    (by decide +kernel) next_25943]
  rw [Compact40PrimeCompose256.step 364 26041 89693 26141
    (by decide +kernel) next_26041]
  rw [Compact40PrimeCompose256.step 363 26141 89693 26237
    (by decide +kernel) next_26141]
  rw [Compact40PrimeCompose256.step 362 26237 89693 26339
    (by decide +kernel) next_26237]
  rw [Compact40PrimeCompose256.step 361 26339 89693 26437
    (by decide +kernel) next_26339]
  rw [Compact40PrimeCompose256.step 360 26437 89693 26539
    (by decide +kernel) next_26437]
  rw [Compact40PrimeCompose256.step 359 26539 89693 26641
    (by decide +kernel) next_26539]
  rw [Compact40PrimeCompose256.step 358 26641 89693 26737
    (by decide +kernel) next_26641]
  rw [Compact40PrimeCompose256.step 357 26737 89693 26839
    (by decide +kernel) next_26737]
  rw [Compact40PrimeCompose256.step 356 26839 89693 26927
    (by decide +kernel) next_26839]
  rw [Compact40PrimeCompose256.step 355 26927 89693 27031
    (by decide +kernel) next_26927]
  rw [Compact40PrimeCompose256.step 354 27031 89693 27127
    (by decide +kernel) next_27031]
  rw [Compact40PrimeCompose256.step 353 27127 89693 27211
    (by decide +kernel) next_27127]
  rw [Compact40PrimeCompose256.step 352 27211 89693 27299
    (by decide +kernel) next_27211]
  rw [Compact40PrimeCompose256.step 351 27299 89693 27397
    (by decide +kernel) next_27299]
  rw [Compact40PrimeCompose256.step 350 27397 89693 27487
    (by decide +kernel) next_27397]
  rw [Compact40PrimeCompose256.step 349 27487 89693 27583
    (by decide +kernel) next_27487]
  rw [Compact40PrimeCompose256.step 348 27583 89693 27689
    (by decide +kernel) next_27583]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 27689 stop tail = true) :
    check 24683 stop (primes ++ tail) = true := by
  change check _ _ (24767 :: 24859 :: 24953 :: 25037 :: 25127 :: 25219 :: 25309 :: 25391 :: 25471 :: 25561 :: 25657 :: 25747 :: 25847 :: 25943 :: 26041 :: 26141 :: 26237 :: 26339 :: 26437 :: 26539 :: 26641 :: 26737 :: 26839 :: 26927 :: 27031 :: 27127 :: 27211 :: 27299 :: 27397 :: 27487 :: 27583 :: 27689 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24767, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24859, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24953, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25037, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25127, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25219, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25309, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25391, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25471, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25561, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25657, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25747, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25847, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_25943, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26041, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26141, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26237, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26339, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26437, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26539, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26641, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26737, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26839, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_26927, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27031, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27127, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27211, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27299, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27397, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27487, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27583, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27689, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks010
