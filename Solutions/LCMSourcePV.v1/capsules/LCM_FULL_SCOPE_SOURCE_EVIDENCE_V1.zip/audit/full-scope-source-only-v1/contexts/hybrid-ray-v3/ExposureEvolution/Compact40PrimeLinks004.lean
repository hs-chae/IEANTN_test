import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks004
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_12791 : next 12791 = some 12829 := by
  have hl : (List.range ((257 * 12791 - 1) / 256 - 12791)).reverse =
      [48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12829]

theorem next_12829 : next 12829 = some 12853 := by
  have hl : (List.range ((257 * 12829 - 1) / 256 - 12829)).reverse =
      [49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12853]

theorem next_12853 : next 12853 = some 12899 := by
  have hl : (List.range ((257 * 12853 - 1) / 256 - 12853)).reverse =
      [49, 48, 47, 46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12899]

theorem next_12899 : next 12899 = some 12941 := by
  have hl : (List.range ((257 * 12899 - 1) / 256 - 12899)).reverse =
      [49, 48, 47, 46, 45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12941]

theorem next_12941 : next 12941 = some 12983 := by
  have hl : (List.range ((257 * 12941 - 1) / 256 - 12941)).reverse =
      [49, 48, 47, 46, 45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12983]

theorem next_12983 : next 12983 = some 13033 := by
  have hl : (List.range ((257 * 12983 - 1) / 256 - 12983)).reverse =
      [49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13033]

theorem next_13033 : next 13033 = some 13063 := by
  have hl : (List.range ((257 * 13033 - 1) / 256 - 13033)).reverse =
      [49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13063]

theorem next_13063 : next 13063 = some 13109 := by
  have hl : (List.range ((257 * 13063 - 1) / 256 - 13063)).reverse =
      [50, 49, 48, 47, 46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13109]

theorem next_13109 : next 13109 = some 13159 := by
  have hl : (List.range ((257 * 13109 - 1) / 256 - 13109)).reverse =
      [50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13159]

theorem next_13159 : next 13159 = some 13187 := by
  have hl : (List.range ((257 * 13159 - 1) / 256 - 13159)).reverse =
      [50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27] ++ (List.range 27).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13187]

theorem next_13187 : next 13187 = some 13229 := by
  have hl : (List.range ((257 * 13187 - 1) / 256 - 13187)).reverse =
      [50, 49, 48, 47, 46, 45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13229]

theorem next_13229 : next 13229 = some 13267 := by
  have hl : (List.range ((257 * 13229 - 1) / 256 - 13229)).reverse =
      [50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13267]

theorem next_13267 : next 13267 = some 13313 := by
  have hl : (List.range ((257 * 13267 - 1) / 256 - 13267)).reverse =
      [50, 49, 48, 47, 46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13313]

theorem next_13313 : next 13313 = some 13339 := by
  have hl : (List.range ((257 * 13313 - 1) / 256 - 13313)).reverse =
      [51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13339]

theorem next_13339 : next 13339 = some 13381 := by
  have hl : (List.range ((257 * 13339 - 1) / 256 - 13339)).reverse =
      [51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13381]

theorem next_13381 : next 13381 = some 13421 := by
  have hl : (List.range ((257 * 13381 - 1) / 256 - 13381)).reverse =
      [51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13421]

theorem next_13421 : next 13421 = some 13469 := by
  have hl : (List.range ((257 * 13421 - 1) / 256 - 13421)).reverse =
      [51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13469]

theorem next_13469 : next 13469 = some 13513 := by
  have hl : (List.range ((257 * 13469 - 1) / 256 - 13469)).reverse =
      [51, 50, 49, 48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13513]

theorem next_13513 : next 13513 = some 13553 := by
  have hl : (List.range ((257 * 13513 - 1) / 256 - 13513)).reverse =
      [51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13553]

theorem next_13553 : next 13553 = some 13597 := by
  have hl : (List.range ((257 * 13553 - 1) / 256 - 13553)).reverse =
      [51, 50, 49, 48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13597]

theorem next_13597 : next 13597 = some 13649 := by
  have hl : (List.range ((257 * 13597 - 1) / 256 - 13597)).reverse =
      [52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13649]

theorem next_13649 : next 13649 = some 13697 := by
  have hl : (List.range ((257 * 13649 - 1) / 256 - 13649)).reverse =
      [52, 51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13697]

theorem next_13697 : next 13697 = some 13729 := by
  have hl : (List.range ((257 * 13697 - 1) / 256 - 13697)).reverse =
      [52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31] ++ (List.range 31).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13729]

theorem next_13729 : next 13729 = some 13781 := by
  have hl : (List.range ((257 * 13729 - 1) / 256 - 13729)).reverse =
      [52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13781]

theorem next_13781 : next 13781 = some 13831 := by
  have hl : (List.range ((257 * 13781 - 1) / 256 - 13781)).reverse =
      [52, 51, 50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13831]

theorem next_13831 : next 13831 = some 13883 := by
  have hl : (List.range ((257 * 13831 - 1) / 256 - 13831)).reverse =
      [53, 52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13883]

theorem next_13883 : next 13883 = some 13933 := by
  have hl : (List.range ((257 * 13883 - 1) / 256 - 13883)).reverse =
      [53, 52, 51, 50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13933]

theorem next_13933 : next 13933 = some 13967 := by
  have hl : (List.range ((257 * 13933 - 1) / 256 - 13933)).reverse =
      [53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_13967]

theorem next_13967 : next 13967 = some 14011 := by
  have hl : (List.range ((257 * 13967 - 1) / 256 - 13967)).reverse =
      [53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14011]

theorem next_14011 : next 14011 = some 14057 := by
  have hl : (List.range ((257 * 14011 - 1) / 256 - 14011)).reverse =
      [53, 52, 51, 50, 49, 48, 47, 46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14057]

theorem next_14057 : next 14057 = some 14107 := by
  have hl : (List.range ((257 * 14057 - 1) / 256 - 14057)).reverse =
      [53, 52, 51, 50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14107]

theorem next_14107 : next 14107 = some 14159 := by
  have hl : (List.range ((257 * 14107 - 1) / 256 - 14107)).reverse =
      [54, 53, 52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14159]

def primes : List ℕ := [12829, 12853, 12899, 12941, 12983, 13033, 13063, 13109, 13159, 13187, 13229, 13267, 13313, 13339, 13381, 13421, 13469, 13513, 13553, 13597, 13649, 13697, 13729, 13781, 13831, 13883, 13933, 13967, 14011, 14057, 14107, 14159]

theorem segment : run 572 12791 89693 =
    primes ++ run 540 14159 89693 := by
  rw [Compact40PrimeCompose256.step 571 12791 89693 12829
    (by decide +kernel) next_12791]
  rw [Compact40PrimeCompose256.step 570 12829 89693 12853
    (by decide +kernel) next_12829]
  rw [Compact40PrimeCompose256.step 569 12853 89693 12899
    (by decide +kernel) next_12853]
  rw [Compact40PrimeCompose256.step 568 12899 89693 12941
    (by decide +kernel) next_12899]
  rw [Compact40PrimeCompose256.step 567 12941 89693 12983
    (by decide +kernel) next_12941]
  rw [Compact40PrimeCompose256.step 566 12983 89693 13033
    (by decide +kernel) next_12983]
  rw [Compact40PrimeCompose256.step 565 13033 89693 13063
    (by decide +kernel) next_13033]
  rw [Compact40PrimeCompose256.step 564 13063 89693 13109
    (by decide +kernel) next_13063]
  rw [Compact40PrimeCompose256.step 563 13109 89693 13159
    (by decide +kernel) next_13109]
  rw [Compact40PrimeCompose256.step 562 13159 89693 13187
    (by decide +kernel) next_13159]
  rw [Compact40PrimeCompose256.step 561 13187 89693 13229
    (by decide +kernel) next_13187]
  rw [Compact40PrimeCompose256.step 560 13229 89693 13267
    (by decide +kernel) next_13229]
  rw [Compact40PrimeCompose256.step 559 13267 89693 13313
    (by decide +kernel) next_13267]
  rw [Compact40PrimeCompose256.step 558 13313 89693 13339
    (by decide +kernel) next_13313]
  rw [Compact40PrimeCompose256.step 557 13339 89693 13381
    (by decide +kernel) next_13339]
  rw [Compact40PrimeCompose256.step 556 13381 89693 13421
    (by decide +kernel) next_13381]
  rw [Compact40PrimeCompose256.step 555 13421 89693 13469
    (by decide +kernel) next_13421]
  rw [Compact40PrimeCompose256.step 554 13469 89693 13513
    (by decide +kernel) next_13469]
  rw [Compact40PrimeCompose256.step 553 13513 89693 13553
    (by decide +kernel) next_13513]
  rw [Compact40PrimeCompose256.step 552 13553 89693 13597
    (by decide +kernel) next_13553]
  rw [Compact40PrimeCompose256.step 551 13597 89693 13649
    (by decide +kernel) next_13597]
  rw [Compact40PrimeCompose256.step 550 13649 89693 13697
    (by decide +kernel) next_13649]
  rw [Compact40PrimeCompose256.step 549 13697 89693 13729
    (by decide +kernel) next_13697]
  rw [Compact40PrimeCompose256.step 548 13729 89693 13781
    (by decide +kernel) next_13729]
  rw [Compact40PrimeCompose256.step 547 13781 89693 13831
    (by decide +kernel) next_13781]
  rw [Compact40PrimeCompose256.step 546 13831 89693 13883
    (by decide +kernel) next_13831]
  rw [Compact40PrimeCompose256.step 545 13883 89693 13933
    (by decide +kernel) next_13883]
  rw [Compact40PrimeCompose256.step 544 13933 89693 13967
    (by decide +kernel) next_13933]
  rw [Compact40PrimeCompose256.step 543 13967 89693 14011
    (by decide +kernel) next_13967]
  rw [Compact40PrimeCompose256.step 542 14011 89693 14057
    (by decide +kernel) next_14011]
  rw [Compact40PrimeCompose256.step 541 14057 89693 14107
    (by decide +kernel) next_14057]
  rw [Compact40PrimeCompose256.step 540 14107 89693 14159
    (by decide +kernel) next_14107]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 14159 stop tail = true) :
    check 12791 stop (primes ++ tail) = true := by
  change check _ _ (12829 :: 12853 :: 12899 :: 12941 :: 12983 :: 13033 :: 13063 :: 13109 :: 13159 :: 13187 :: 13229 :: 13267 :: 13313 :: 13339 :: 13381 :: 13421 :: 13469 :: 13513 :: 13553 :: 13597 :: 13649 :: 13697 :: 13729 :: 13781 :: 13831 :: 13883 :: 13933 :: 13967 :: 14011 :: 14057 :: 14107 :: 14159 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12829, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12853, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12899, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12941, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12983, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13033, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13063, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13109, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13159, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13187, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13229, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13267, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13313, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13339, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13381, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13421, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13469, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13513, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13553, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13597, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13649, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13697, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13729, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13781, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13831, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13883, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13933, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_13967, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14011, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14057, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14107, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14159, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks004
