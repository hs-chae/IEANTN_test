import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_006
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨29343889, 29365560, 5419, 5431, 5437, 29343499, 29343829, 29343871⟩, 12⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5419,
    ExposureEvolution.Compact40Pratt.prime_5431,
    ExposureEvolution.Compact40Pratt.prime_5437,
    ExposureEvolution.Compact40Pratt.prime_29343499,
    ExposureEvolution.Compact40Pratt.prime_29343829,
    ExposureEvolution.Compact40Pratt.prime_29343871]

def block01 : Witness := ⟨⟨29365561, 29495760, 5431, 5437, 5441, 29365249, 29365537, 29365547⟩, 9⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5431,
    ExposureEvolution.Compact40Pratt.prime_5437,
    ExposureEvolution.Compact40Pratt.prime_5441,
    ExposureEvolution.Compact40Pratt.prime_29365249,
    ExposureEvolution.Compact40Pratt.prime_29365537,
    ExposureEvolution.Compact40Pratt.prime_29365547]

def block02 : Witness := ⟨⟨29495761, 29560968, 5437, 5441, 5443, 29495311, 29495413, 29495717⟩, 10⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5437,
    ExposureEvolution.Compact40Pratt.prime_5441,
    ExposureEvolution.Compact40Pratt.prime_5443,
    ExposureEvolution.Compact40Pratt.prime_29495311,
    ExposureEvolution.Compact40Pratt.prime_29495413,
    ExposureEvolution.Compact40Pratt.prime_29495717]

def block03 : Witness := ⟨⟨29560969, 29604480, 5441, 5443, 5449, 29560493, 29560721, 29560939⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5441,
    ExposureEvolution.Compact40Pratt.prime_5443,
    ExposureEvolution.Compact40Pratt.prime_5449,
    ExposureEvolution.Compact40Pratt.prime_29560493,
    ExposureEvolution.Compact40Pratt.prime_29560721,
    ExposureEvolution.Compact40Pratt.prime_29560939]

def block04 : Witness := ⟨⟨29604481, 29626248, 5443, 5449, 5471, 29603941, 29604431, 29604469⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5443,
    ExposureEvolution.Compact40Pratt.prime_5449,
    ExposureEvolution.Compact40Pratt.prime_5471,
    ExposureEvolution.Compact40Pratt.prime_29603941,
    ExposureEvolution.Compact40Pratt.prime_29604431,
    ExposureEvolution.Compact40Pratt.prime_29604469]

def block05 : Witness := ⟨⟨29626249, 29691600, 5449, 5471, 5477, 29625901, 29625943, 29626243⟩, 6⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5449,
    ExposureEvolution.Compact40Pratt.prime_5471,
    ExposureEvolution.Compact40Pratt.prime_5477,
    ExposureEvolution.Compact40Pratt.prime_29625901,
    ExposureEvolution.Compact40Pratt.prime_29625943,
    ExposureEvolution.Compact40Pratt.prime_29626243]

def block06 : Witness := ⟨⟨29691601, 29931840, 5471, 5477, 5479, 29691577, 29691581, 29691593⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5471,
    ExposureEvolution.Compact40Pratt.prime_5477,
    ExposureEvolution.Compact40Pratt.prime_5479,
    ExposureEvolution.Compact40Pratt.prime_29691577,
    ExposureEvolution.Compact40Pratt.prime_29691581,
    ExposureEvolution.Compact40Pratt.prime_29691593]

def block07 : Witness := ⟨⟨29931841, 29997528, 5477, 5479, 5483, 29931449, 29931637, 29931817⟩, 8⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5477,
    ExposureEvolution.Compact40Pratt.prime_5479,
    ExposureEvolution.Compact40Pratt.prime_5483,
    ExposureEvolution.Compact40Pratt.prime_29931449,
    ExposureEvolution.Compact40Pratt.prime_29931637,
    ExposureEvolution.Compact40Pratt.prime_29931817]

def block08 : Witness := ⟨⟨29997529, 30019440, 5479, 5483, 5501, 29996987, 29997293, 29997521⟩, 10⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5479,
    ExposureEvolution.Compact40Pratt.prime_5483,
    ExposureEvolution.Compact40Pratt.prime_5501,
    ExposureEvolution.Compact40Pratt.prime_29996987,
    ExposureEvolution.Compact40Pratt.prime_29997293,
    ExposureEvolution.Compact40Pratt.prime_29997521]

def block09 : Witness := ⟨⟨30019441, 30063288, 5483, 5501, 5503, 30019079, 30019081, 30019387⟩, 10⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5483,
    ExposureEvolution.Compact40Pratt.prime_5501,
    ExposureEvolution.Compact40Pratt.prime_5503,
    ExposureEvolution.Compact40Pratt.prime_30019079,
    ExposureEvolution.Compact40Pratt.prime_30019081,
    ExposureEvolution.Compact40Pratt.prime_30019387]

def block10 : Witness := ⟨⟨30063289, 30261000, 5501, 5503, 5507, 30062999, 30063097, 30063287⟩, 7⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5501,
    ExposureEvolution.Compact40Pratt.prime_5503,
    ExposureEvolution.Compact40Pratt.prime_5507,
    ExposureEvolution.Compact40Pratt.prime_30062999,
    ExposureEvolution.Compact40Pratt.prime_30063097,
    ExposureEvolution.Compact40Pratt.prime_30063287]

def block11 : Witness := ⟨⟨30261001, 30283008, 5503, 5507, 5519, 30260491, 30260873, 30260999⟩, 7⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5503,
    ExposureEvolution.Compact40Pratt.prime_5507,
    ExposureEvolution.Compact40Pratt.prime_5519,
    ExposureEvolution.Compact40Pratt.prime_30260491,
    ExposureEvolution.Compact40Pratt.prime_30260873,
    ExposureEvolution.Compact40Pratt.prime_30260999]

def block12 : Witness := ⟨⟨30283009, 30327048, 5507, 5519, 5521, 30282619, 30282829, 30282971⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5507,
    ExposureEvolution.Compact40Pratt.prime_5519,
    ExposureEvolution.Compact40Pratt.prime_5521,
    ExposureEvolution.Compact40Pratt.prime_30282619,
    ExposureEvolution.Compact40Pratt.prime_30282829,
    ExposureEvolution.Compact40Pratt.prime_30282971]

def block13 : Witness := ⟨⟨30327049, 30459360, 5519, 5521, 5527, 30326561, 30326629, 30327043⟩, 9⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5519,
    ExposureEvolution.Compact40Pratt.prime_5521,
    ExposureEvolution.Compact40Pratt.prime_5527,
    ExposureEvolution.Compact40Pratt.prime_30326561,
    ExposureEvolution.Compact40Pratt.prime_30326629,
    ExposureEvolution.Compact40Pratt.prime_30327043]

def block14 : Witness := ⟨⟨30459361, 30481440, 5521, 5527, 5531, 30458797, 30459227, 30459353⟩, 14⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5521,
    ExposureEvolution.Compact40Pratt.prime_5527,
    ExposureEvolution.Compact40Pratt.prime_5531,
    ExposureEvolution.Compact40Pratt.prime_30458797,
    ExposureEvolution.Compact40Pratt.prime_30459227,
    ExposureEvolution.Compact40Pratt.prime_30459353]

def block15 : Witness := ⟨⟨30481441, 30547728, 5527, 5531, 5557, 30481237, 30481261, 30481433⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5527,
    ExposureEvolution.Compact40Pratt.prime_5531,
    ExposureEvolution.Compact40Pratt.prime_5557,
    ExposureEvolution.Compact40Pratt.prime_30481237,
    ExposureEvolution.Compact40Pratt.prime_30481261,
    ExposureEvolution.Compact40Pratt.prime_30481433]

def block16 : Witness := ⟨⟨30547729, 30591960, 5531, 5557, 5563, 30547471, 30547567, 30547723⟩, 8⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5531,
    ExposureEvolution.Compact40Pratt.prime_5557,
    ExposureEvolution.Compact40Pratt.prime_5563,
    ExposureEvolution.Compact40Pratt.prime_30547471,
    ExposureEvolution.Compact40Pratt.prime_30547567,
    ExposureEvolution.Compact40Pratt.prime_30547723]

def block17 : Witness := ⟨⟨30591961, 30880248, 5557, 5563, 5569, 30591647, 30591893, 30591931⟩, 7⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5557,
    ExposureEvolution.Compact40Pratt.prime_5563,
    ExposureEvolution.Compact40Pratt.prime_5569,
    ExposureEvolution.Compact40Pratt.prime_30591647,
    ExposureEvolution.Compact40Pratt.prime_30591893,
    ExposureEvolution.Compact40Pratt.prime_30591931]

def block18 : Witness := ⟨⟨30880249, 30946968, 5563, 5569, 5573, 30880009, 30880217, 30880219⟩, 8⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5563,
    ExposureEvolution.Compact40Pratt.prime_5569,
    ExposureEvolution.Compact40Pratt.prime_5573,
    ExposureEvolution.Compact40Pratt.prime_30880009,
    ExposureEvolution.Compact40Pratt.prime_30880217,
    ExposureEvolution.Compact40Pratt.prime_30880219]

def block19 : Witness := ⟨⟨30946969, 31013760, 5569, 5573, 5581, 30946499, 30946789, 30946961⟩, 20⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5569,
    ExposureEvolution.Compact40Pratt.prime_5573,
    ExposureEvolution.Compact40Pratt.prime_5581,
    ExposureEvolution.Compact40Pratt.prime_30946499,
    ExposureEvolution.Compact40Pratt.prime_30946789,
    ExposureEvolution.Compact40Pratt.prime_30946961]

def block20 : Witness := ⟨⟨31013761, 31058328, 5573, 5581, 5591, 31013347, 31013417, 31013747⟩, 9⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5573,
    ExposureEvolution.Compact40Pratt.prime_5581,
    ExposureEvolution.Compact40Pratt.prime_5591,
    ExposureEvolution.Compact40Pratt.prime_31013347,
    ExposureEvolution.Compact40Pratt.prime_31013417,
    ExposureEvolution.Compact40Pratt.prime_31013747]

def block21 : Witness := ⟨⟨31058329, 31147560, 5581, 5591, 5623, 31058147, 31058243, 31058327⟩, 8⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5581,
    ExposureEvolution.Compact40Pratt.prime_5591,
    ExposureEvolution.Compact40Pratt.prime_5623,
    ExposureEvolution.Compact40Pratt.prime_31058147,
    ExposureEvolution.Compact40Pratt.prime_31058243,
    ExposureEvolution.Compact40Pratt.prime_31058327]

def block22 : Witness := ⟨⟨31147561, 31259280, 5591, 5623, 5639, 31147373, 31147381, 31147559⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5591,
    ExposureEvolution.Compact40Pratt.prime_5623,
    ExposureEvolution.Compact40Pratt.prime_5639,
    ExposureEvolution.Compact40Pratt.prime_31147373,
    ExposureEvolution.Compact40Pratt.prime_31147381,
    ExposureEvolution.Compact40Pratt.prime_31147559]

def block23 : Witness := ⟨⟨31259281, 31618128, 5623, 5639, 5641, 31258681, 31258739, 31259269⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5623,
    ExposureEvolution.Compact40Pratt.prime_5639,
    ExposureEvolution.Compact40Pratt.prime_5641,
    ExposureEvolution.Compact40Pratt.prime_31258681,
    ExposureEvolution.Compact40Pratt.prime_31258739,
    ExposureEvolution.Compact40Pratt.prime_31259269]

def block24 : Witness := ⟨⟨31618129, 31798320, 5639, 5641, 5647, 31617667, 31618001, 31618127⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5639,
    ExposureEvolution.Compact40Pratt.prime_5641,
    ExposureEvolution.Compact40Pratt.prime_5647,
    ExposureEvolution.Compact40Pratt.prime_31617667,
    ExposureEvolution.Compact40Pratt.prime_31618001,
    ExposureEvolution.Compact40Pratt.prime_31618127]

def block25 : Witness := ⟨⟨31798321, 31820880, 5641, 5647, 5651, 31798079, 31798127, 31798307⟩, 8⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5641,
    ExposureEvolution.Compact40Pratt.prime_5647,
    ExposureEvolution.Compact40Pratt.prime_5651,
    ExposureEvolution.Compact40Pratt.prime_31798079,
    ExposureEvolution.Compact40Pratt.prime_31798127,
    ExposureEvolution.Compact40Pratt.prime_31798307]

def block26 : Witness := ⟨⟨31820881, 31888608, 5647, 5651, 5653, 31820501, 31820669, 31820869⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5647,
    ExposureEvolution.Compact40Pratt.prime_5651,
    ExposureEvolution.Compact40Pratt.prime_5653,
    ExposureEvolution.Compact40Pratt.prime_31820501,
    ExposureEvolution.Compact40Pratt.prime_31820669,
    ExposureEvolution.Compact40Pratt.prime_31820869]

def block27 : Witness := ⟨⟨31888609, 31933800, 5651, 5653, 5657, 31888393, 31888471, 31888601⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5651,
    ExposureEvolution.Compact40Pratt.prime_5653,
    ExposureEvolution.Compact40Pratt.prime_5657,
    ExposureEvolution.Compact40Pratt.prime_31888393,
    ExposureEvolution.Compact40Pratt.prime_31888471,
    ExposureEvolution.Compact40Pratt.prime_31888601]

def block28 : Witness := ⟨⟨31933801, 31956408, 5653, 5657, 5659, 31933501, 31933703, 31933799⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5653,
    ExposureEvolution.Compact40Pratt.prime_5657,
    ExposureEvolution.Compact40Pratt.prime_5659,
    ExposureEvolution.Compact40Pratt.prime_31933501,
    ExposureEvolution.Compact40Pratt.prime_31933703,
    ExposureEvolution.Compact40Pratt.prime_31933799]

def block29 : Witness := ⟨⟨31956409, 32001648, 5657, 5659, 5669, 31955953, 31956007, 31956391⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5657,
    ExposureEvolution.Compact40Pratt.prime_5659,
    ExposureEvolution.Compact40Pratt.prime_5669,
    ExposureEvolution.Compact40Pratt.prime_31955953,
    ExposureEvolution.Compact40Pratt.prime_31956007,
    ExposureEvolution.Compact40Pratt.prime_31956391]

def block30 : Witness := ⟨⟨32001649, 32024280, 5659, 5669, 5683, 32001421, 32001569, 32001631⟩, 9⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5659,
    ExposureEvolution.Compact40Pratt.prime_5669,
    ExposureEvolution.Compact40Pratt.prime_5683,
    ExposureEvolution.Compact40Pratt.prime_32001421,
    ExposureEvolution.Compact40Pratt.prime_32001569,
    ExposureEvolution.Compact40Pratt.prime_32001631]

def block31 : Witness := ⟨⟨32024281, 32137560, 5669, 5683, 5689, 32024059, 32024173, 32024269⟩, 6⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5669,
    ExposureEvolution.Compact40Pratt.prime_5683,
    ExposureEvolution.Compact40Pratt.prime_5689,
    ExposureEvolution.Compact40Pratt.prime_32024059,
    ExposureEvolution.Compact40Pratt.prime_32024173,
    ExposureEvolution.Compact40Pratt.prime_32024269]

def block32 : Witness := ⟨⟨32137561, 32296488, 5683, 5689, 5693, 32137043, 32137337, 32137549⟩, 9⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5683,
    ExposureEvolution.Compact40Pratt.prime_5689,
    ExposureEvolution.Compact40Pratt.prime_5693,
    ExposureEvolution.Compact40Pratt.prime_32137043,
    ExposureEvolution.Compact40Pratt.prime_32137337,
    ExposureEvolution.Compact40Pratt.prime_32137549]

def block33 : Witness := ⟨⟨32296489, 32364720, 5689, 5693, 5701, 32296321, 32296471, 32296487⟩, 7⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5689,
    ExposureEvolution.Compact40Pratt.prime_5693,
    ExposureEvolution.Compact40Pratt.prime_5701,
    ExposureEvolution.Compact40Pratt.prime_32296321,
    ExposureEvolution.Compact40Pratt.prime_32296471,
    ExposureEvolution.Compact40Pratt.prime_32296487]

def block34 : Witness := ⟨⟨32364721, 32410248, 5693, 5701, 5711, 32364193, 32364511, 32364707⟩, 10⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5693,
    ExposureEvolution.Compact40Pratt.prime_5701,
    ExposureEvolution.Compact40Pratt.prime_5711,
    ExposureEvolution.Compact40Pratt.prime_32364193,
    ExposureEvolution.Compact40Pratt.prime_32364511,
    ExposureEvolution.Compact40Pratt.prime_32364707]

def block35 : Witness := ⟨⟨32410249, 32501400, 5701, 5711, 5717, 32409827, 32409997, 32410247⟩, 10⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5701,
    ExposureEvolution.Compact40Pratt.prime_5711,
    ExposureEvolution.Compact40Pratt.prime_5717,
    ExposureEvolution.Compact40Pratt.prime_32409827,
    ExposureEvolution.Compact40Pratt.prime_32409997,
    ExposureEvolution.Compact40Pratt.prime_32410247]

def block36 : Witness := ⟨⟨32501401, 32615520, 5711, 5717, 5737, 32500907, 32501197, 32501377⟩, 8⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5711,
    ExposureEvolution.Compact40Pratt.prime_5717,
    ExposureEvolution.Compact40Pratt.prime_5737,
    ExposureEvolution.Compact40Pratt.prime_32500907,
    ExposureEvolution.Compact40Pratt.prime_32501197,
    ExposureEvolution.Compact40Pratt.prime_32501377]

def block37 : Witness := ⟨⟨32615521, 32684088, 5717, 5737, 5741, 32614999, 32615339, 32615519⟩, 10⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5717,
    ExposureEvolution.Compact40Pratt.prime_5737,
    ExposureEvolution.Compact40Pratt.prime_5741,
    ExposureEvolution.Compact40Pratt.prime_32614999,
    ExposureEvolution.Compact40Pratt.prime_32615339,
    ExposureEvolution.Compact40Pratt.prime_32615519]

def block38 : Witness := ⟨⟨32684089, 32913168, 5737, 5741, 5743, 32683613, 32684017, 32684083⟩, 7⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5737,
    ExposureEvolution.Compact40Pratt.prime_5741,
    ExposureEvolution.Compact40Pratt.prime_5743,
    ExposureEvolution.Compact40Pratt.prime_32683613,
    ExposureEvolution.Compact40Pratt.prime_32684017,
    ExposureEvolution.Compact40Pratt.prime_32684083]

def block39 : Witness := ⟨⟨32913169, 32959080, 5741, 5743, 5749, 32912653, 32912821, 32913151⟩, 9⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5741,
    ExposureEvolution.Compact40Pratt.prime_5743,
    ExposureEvolution.Compact40Pratt.prime_5749,
    ExposureEvolution.Compact40Pratt.prime_32912653,
    ExposureEvolution.Compact40Pratt.prime_32912821,
    ExposureEvolution.Compact40Pratt.prime_32913151]

def block40 : Witness := ⟨⟨32959081, 32982048, 5743, 5749, 5779, 32958883, 32958907, 32959063⟩, 9⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5743,
    ExposureEvolution.Compact40Pratt.prime_5749,
    ExposureEvolution.Compact40Pratt.prime_5779,
    ExposureEvolution.Compact40Pratt.prime_32958883,
    ExposureEvolution.Compact40Pratt.prime_32958907,
    ExposureEvolution.Compact40Pratt.prime_32959063]

def block41 : Witness := ⟨⟨32982049, 33051000, 5749, 5779, 5783, 32981593, 32981899, 32982017⟩, 12⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5749,
    ExposureEvolution.Compact40Pratt.prime_5779,
    ExposureEvolution.Compact40Pratt.prime_5783,
    ExposureEvolution.Compact40Pratt.prime_32981593,
    ExposureEvolution.Compact40Pratt.prime_32981899,
    ExposureEvolution.Compact40Pratt.prime_32982017]

def block42 : Witness := ⟨⟨33051001, 33396840, 5779, 5783, 5791, 33050723, 33050741, 33050999⟩, 14⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5779,
    ExposureEvolution.Compact40Pratt.prime_5783,
    ExposureEvolution.Compact40Pratt.prime_5791,
    ExposureEvolution.Compact40Pratt.prime_33050723,
    ExposureEvolution.Compact40Pratt.prime_33050741,
    ExposureEvolution.Compact40Pratt.prime_33050999]

def block43 : Witness := ⟨⟨33396841, 33443088, 5783, 5791, 5801, 33396409, 33396749, 33396833⟩, 8⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5783,
    ExposureEvolution.Compact40Pratt.prime_5791,
    ExposureEvolution.Compact40Pratt.prime_5801,
    ExposureEvolution.Compact40Pratt.prime_33396409,
    ExposureEvolution.Compact40Pratt.prime_33396749,
    ExposureEvolution.Compact40Pratt.prime_33396833]

def block44 : Witness := ⟨⟨33443089, 33535680, 5791, 5801, 5807, 33442627, 33442853, 33443083⟩, 8⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5791,
    ExposureEvolution.Compact40Pratt.prime_5801,
    ExposureEvolution.Compact40Pratt.prime_5807,
    ExposureEvolution.Compact40Pratt.prime_33442627,
    ExposureEvolution.Compact40Pratt.prime_33442853,
    ExposureEvolution.Compact40Pratt.prime_33443083]

def block45 : Witness := ⟨⟨33535681, 33651600, 5801, 5807, 5813, 33535031, 33535529, 33535651⟩, 9⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5801,
    ExposureEvolution.Compact40Pratt.prime_5807,
    ExposureEvolution.Compact40Pratt.prime_5813,
    ExposureEvolution.Compact40Pratt.prime_33535031,
    ExposureEvolution.Compact40Pratt.prime_33535529,
    ExposureEvolution.Compact40Pratt.prime_33535651]

def block46 : Witness := ⟨⟨33651601, 33721248, 5807, 5813, 5821, 33651469, 33651511, 33651589⟩, 7⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5807,
    ExposureEvolution.Compact40Pratt.prime_5813,
    ExposureEvolution.Compact40Pratt.prime_5821,
    ExposureEvolution.Compact40Pratt.prime_33651469,
    ExposureEvolution.Compact40Pratt.prime_33651511,
    ExposureEvolution.Compact40Pratt.prime_33651589]

def block47 : Witness := ⟨⟨33721249, 33790968, 5813, 5821, 5827, 33720733, 33721189, 33721223⟩, 9⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5813,
    ExposureEvolution.Compact40Pratt.prime_5821,
    ExposureEvolution.Compact40Pratt.prime_5827,
    ExposureEvolution.Compact40Pratt.prime_33720733,
    ExposureEvolution.Compact40Pratt.prime_33721189,
    ExposureEvolution.Compact40Pratt.prime_33721223]

def block48 : Witness := ⟨⟨33790969, 33884040, 5821, 5827, 5839, 33790853, 33790957, 33790963⟩, 8⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5821,
    ExposureEvolution.Compact40Pratt.prime_5827,
    ExposureEvolution.Compact40Pratt.prime_5839,
    ExposureEvolution.Compact40Pratt.prime_33790853,
    ExposureEvolution.Compact40Pratt.prime_33790957,
    ExposureEvolution.Compact40Pratt.prime_33790963]

def block49 : Witness := ⟨⟨33884041, 33953928, 5827, 5839, 5843, 33883721, 33883933, 33884033⟩, 8⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5827,
    ExposureEvolution.Compact40Pratt.prime_5839,
    ExposureEvolution.Compact40Pratt.prime_5843,
    ExposureEvolution.Compact40Pratt.prime_33883721,
    ExposureEvolution.Compact40Pratt.prime_33883933,
    ExposureEvolution.Compact40Pratt.prime_33884033]

def block50 : Witness := ⟨⟨33953929, 34093920, 5839, 5843, 5849, 33953503, 33953813, 33953921⟩, 8⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5839,
    ExposureEvolution.Compact40Pratt.prime_5843,
    ExposureEvolution.Compact40Pratt.prime_5849,
    ExposureEvolution.Compact40Pratt.prime_33953503,
    ExposureEvolution.Compact40Pratt.prime_33953813,
    ExposureEvolution.Compact40Pratt.prime_33953921]

def block51 : Witness := ⟨⟨34093921, 34140648, 5843, 5849, 5851, 34093537, 34093601, 34093907⟩, 9⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5843,
    ExposureEvolution.Compact40Pratt.prime_5849,
    ExposureEvolution.Compact40Pratt.prime_5851,
    ExposureEvolution.Compact40Pratt.prime_34093537,
    ExposureEvolution.Compact40Pratt.prime_34093601,
    ExposureEvolution.Compact40Pratt.prime_34093907]

def block52 : Witness := ⟨⟨34140649, 34210800, 5849, 5851, 5857, 34140443, 34140523, 34140643⟩, 9⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5849,
    ExposureEvolution.Compact40Pratt.prime_5851,
    ExposureEvolution.Compact40Pratt.prime_5857,
    ExposureEvolution.Compact40Pratt.prime_34140443,
    ExposureEvolution.Compact40Pratt.prime_34140523,
    ExposureEvolution.Compact40Pratt.prime_34140643]

def block53 : Witness := ⟨⟨34210801, 34234200, 5851, 5857, 5861, 34210271, 34210651, 34210753⟩, 9⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5851,
    ExposureEvolution.Compact40Pratt.prime_5857,
    ExposureEvolution.Compact40Pratt.prime_5861,
    ExposureEvolution.Compact40Pratt.prime_34210271,
    ExposureEvolution.Compact40Pratt.prime_34210651,
    ExposureEvolution.Compact40Pratt.prime_34210753]

def block54 : Witness := ⟨⟨34234201, 34304448, 5857, 5861, 5867, 34233743, 34233751, 34234177⟩, 8⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5857,
    ExposureEvolution.Compact40Pratt.prime_5861,
    ExposureEvolution.Compact40Pratt.prime_5867,
    ExposureEvolution.Compact40Pratt.prime_34233743,
    ExposureEvolution.Compact40Pratt.prime_34233751,
    ExposureEvolution.Compact40Pratt.prime_34234177]

def block55 : Witness := ⟨⟨34304449, 34351320, 5861, 5867, 5869, 34304191, 34304251, 34304447⟩, 7⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5861,
    ExposureEvolution.Compact40Pratt.prime_5867,
    ExposureEvolution.Compact40Pratt.prime_5869,
    ExposureEvolution.Compact40Pratt.prime_34304191,
    ExposureEvolution.Compact40Pratt.prime_34304251,
    ExposureEvolution.Compact40Pratt.prime_34304447]

def block56 : Witness := ⟨⟨34351321, 34421688, 5867, 5869, 5879, 34351201, 34351307, 34351309⟩, 11⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5867,
    ExposureEvolution.Compact40Pratt.prime_5869,
    ExposureEvolution.Compact40Pratt.prime_5879,
    ExposureEvolution.Compact40Pratt.prime_34351201,
    ExposureEvolution.Compact40Pratt.prime_34351307,
    ExposureEvolution.Compact40Pratt.prime_34351309]

def block57 : Witness := ⟨⟨34421689, 34445160, 5869, 5879, 5881, 34421561, 34421623, 34421671⟩, 8⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5869,
    ExposureEvolution.Compact40Pratt.prime_5879,
    ExposureEvolution.Compact40Pratt.prime_5881,
    ExposureEvolution.Compact40Pratt.prime_34421561,
    ExposureEvolution.Compact40Pratt.prime_34421623,
    ExposureEvolution.Compact40Pratt.prime_34421671]

def block58 : Witness := ⟨⟨34445161, 34562640, 5879, 5881, 5897, 34444483, 34444523, 34445129⟩, 7⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5879,
    ExposureEvolution.Compact40Pratt.prime_5881,
    ExposureEvolution.Compact40Pratt.prime_5897,
    ExposureEvolution.Compact40Pratt.prime_34444483,
    ExposureEvolution.Compact40Pratt.prime_34444523,
    ExposureEvolution.Compact40Pratt.prime_34445129]

def block59 : Witness := ⟨⟨34562641, 34586160, 5881, 5897, 5903, 34562089, 34562233, 34562623⟩, 8⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5881,
    ExposureEvolution.Compact40Pratt.prime_5897,
    ExposureEvolution.Compact40Pratt.prime_5903,
    ExposureEvolution.Compact40Pratt.prime_34562089,
    ExposureEvolution.Compact40Pratt.prime_34562233,
    ExposureEvolution.Compact40Pratt.prime_34562623]

def block60 : Witness := ⟨⟨34586161, 34774608, 5897, 5903, 5923, 34586081, 34586113, 34586131⟩, 9⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5897,
    ExposureEvolution.Compact40Pratt.prime_5903,
    ExposureEvolution.Compact40Pratt.prime_5923,
    ExposureEvolution.Compact40Pratt.prime_34586081,
    ExposureEvolution.Compact40Pratt.prime_34586113,
    ExposureEvolution.Compact40Pratt.prime_34586131]

def block61 : Witness := ⟨⟨34774609, 34845408, 5903, 5923, 5927, 34774049, 34774381, 34774559⟩, 8⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5903,
    ExposureEvolution.Compact40Pratt.prime_5923,
    ExposureEvolution.Compact40Pratt.prime_5927,
    ExposureEvolution.Compact40Pratt.prime_34774049,
    ExposureEvolution.Compact40Pratt.prime_34774381,
    ExposureEvolution.Compact40Pratt.prime_34774559]

def block62 : Witness := ⟨⟨34845409, 35081928, 5923, 5927, 5939, 34845347, 34845397, 34845403⟩, 7⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5923,
    ExposureEvolution.Compact40Pratt.prime_5927,
    ExposureEvolution.Compact40Pratt.prime_5939,
    ExposureEvolution.Compact40Pratt.prime_34845347,
    ExposureEvolution.Compact40Pratt.prime_34845397,
    ExposureEvolution.Compact40Pratt.prime_34845403]

def block63 : Witness := ⟨⟨35081929, 35129328, 5927, 5939, 5953, 35081731, 35081869, 35081927⟩, 9⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5927,
    ExposureEvolution.Compact40Pratt.prime_5939,
    ExposureEvolution.Compact40Pratt.prime_5953,
    ExposureEvolution.Compact40Pratt.prime_35081731,
    ExposureEvolution.Compact40Pratt.prime_35081869,
    ExposureEvolution.Compact40Pratt.prime_35081927]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 35129329 stop tail = true) :
    coverage 29343889 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_006
