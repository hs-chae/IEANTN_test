import ExposureEvolution.Dual60CheckerV1
namespace ExposureEvolution.DualKernelCompose60
open ExposureEvolution.Dual60CheckerV1
set_option Elab.async false

theorem coverage_cons (lo stop : ℕ) (w : Witness) (ws : List Witness)
    (hlo : w.block.lo = lo) (hw : w.check = true)
    (ht : coverage (w.block.hi + 1) stop ws = true) :
    coverage lo stop (w :: ws) = true := by
  simp only [coverage, hlo, decide_true, hw, ht, Bool.true_and]

end ExposureEvolution.DualKernelCompose60
