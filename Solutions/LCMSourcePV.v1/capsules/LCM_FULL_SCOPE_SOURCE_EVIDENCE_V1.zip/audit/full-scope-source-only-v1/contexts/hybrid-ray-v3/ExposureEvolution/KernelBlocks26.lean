import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks26
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨62710561, 62837328, 7927, 7933, 7937, 62710129, 62710157, 62710559⟩, 5⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7927,
    ExposureEvolution.KernelPratt.prime_7933,
    ExposureEvolution.KernelPratt.prime_7937,
    ExposureEvolution.KernelPratt.prime_62710129,
    ExposureEvolution.KernelPratt.prime_62710157,
    ExposureEvolution.KernelPratt.prime_62710559]

def block01 : Witness := ⟨⟨62837329, 62932488, 7933, 7937, 7949, 62837053, 62837087, 62837317⟩, 9⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7933,
    ExposureEvolution.KernelPratt.prime_7937,
    ExposureEvolution.KernelPratt.prime_7949,
    ExposureEvolution.KernelPratt.prime_62837053,
    ExposureEvolution.KernelPratt.prime_62837087,
    ExposureEvolution.KernelPratt.prime_62837317]

def block02 : Witness := ⟨⟨62932489, 62995968, 7937, 7949, 7951, 62932039, 62932451, 62932469⟩, 9⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7937,
    ExposureEvolution.KernelPratt.prime_7949,
    ExposureEvolution.KernelPratt.prime_7951,
    ExposureEvolution.KernelPratt.prime_62932039,
    ExposureEvolution.KernelPratt.prime_62932451,
    ExposureEvolution.KernelPratt.prime_62932469]

def block03 : Witness := ⟨⟨62995969, 63186600, 7949, 7951, 7963, 62995313, 62995763, 62995951⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7949,
    ExposureEvolution.KernelPratt.prime_7951,
    ExposureEvolution.KernelPratt.prime_7963,
    ExposureEvolution.KernelPratt.prime_62995313,
    ExposureEvolution.KernelPratt.prime_62995763,
    ExposureEvolution.KernelPratt.prime_62995951]

def block04 : Witness := ⟨⟨63186601, 63218400, 7951, 7963, 7993, 63186413, 63186527, 63186583⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7951,
    ExposureEvolution.KernelPratt.prime_7963,
    ExposureEvolution.KernelPratt.prime_7993,
    ExposureEvolution.KernelPratt.prime_63186413,
    ExposureEvolution.KernelPratt.prime_63186527,
    ExposureEvolution.KernelPratt.prime_63186583]

def block05 : Witness := ⟨⟨63218401, 63409368, 7963, 7993, 8009, 63218137, 63218327, 63218399⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7963,
    ExposureEvolution.KernelPratt.prime_7993,
    ExposureEvolution.KernelPratt.prime_8009,
    ExposureEvolution.KernelPratt.prime_63218137,
    ExposureEvolution.KernelPratt.prime_63218327,
    ExposureEvolution.KernelPratt.prime_63218399]

def block06 : Witness := ⟨⟨63409369, 63888048, 7993, 8009, 8011, 63409007, 63409267, 63409349⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7993,
    ExposureEvolution.KernelPratt.prime_8009,
    ExposureEvolution.KernelPratt.prime_8011,
    ExposureEvolution.KernelPratt.prime_63409007,
    ExposureEvolution.KernelPratt.prime_63409267,
    ExposureEvolution.KernelPratt.prime_63409349]

def block07 : Witness := ⟨⟨63888049, 64144080, 8009, 8011, 8017, 63887953, 63888031, 63888047⟩, 8⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8009,
    ExposureEvolution.KernelPratt.prime_8011,
    ExposureEvolution.KernelPratt.prime_8017,
    ExposureEvolution.KernelPratt.prime_63887953,
    ExposureEvolution.KernelPratt.prime_63888031,
    ExposureEvolution.KernelPratt.prime_63888047]

def block08 : Witness := ⟨⟨64144081, 64176120, 8011, 8017, 8039, 64143613, 64143623, 64144037⟩, 7⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8011,
    ExposureEvolution.KernelPratt.prime_8017,
    ExposureEvolution.KernelPratt.prime_8039,
    ExposureEvolution.KernelPratt.prime_64143613,
    ExposureEvolution.KernelPratt.prime_64143623,
    ExposureEvolution.KernelPratt.prime_64144037]

def block09 : Witness := ⟨⟨64176121, 64272288, 8017, 8039, 8053, 64175971, 64176001, 64176113⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8017,
    ExposureEvolution.KernelPratt.prime_8039,
    ExposureEvolution.KernelPratt.prime_8053,
    ExposureEvolution.KernelPratt.prime_64175971,
    ExposureEvolution.KernelPratt.prime_64176001,
    ExposureEvolution.KernelPratt.prime_64176113]

def block10 : Witness := ⟨⟨64272289, 64625520, 8039, 8053, 8059, 64271947, 64272127, 64272233⟩, 12⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8039,
    ExposureEvolution.KernelPratt.prime_8053,
    ExposureEvolution.KernelPratt.prime_8059,
    ExposureEvolution.KernelPratt.prime_64271947,
    ExposureEvolution.KernelPratt.prime_64272127,
    ExposureEvolution.KernelPratt.prime_64272233]

def block11 : Witness := ⟨⟨64625521, 64850808, 8053, 8059, 8069, 64625207, 64625257, 64625467⟩, 9⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8053,
    ExposureEvolution.KernelPratt.prime_8059,
    ExposureEvolution.KernelPratt.prime_8069,
    ExposureEvolution.KernelPratt.prime_64625207,
    ExposureEvolution.KernelPratt.prime_64625257,
    ExposureEvolution.KernelPratt.prime_64625467]

def block12 : Witness := ⟨⟨64850809, 64947480, 8059, 8069, 8081, 64850197, 64850701, 64850771⟩, 10⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8059,
    ExposureEvolution.KernelPratt.prime_8069,
    ExposureEvolution.KernelPratt.prime_8081,
    ExposureEvolution.KernelPratt.prime_64850197,
    ExposureEvolution.KernelPratt.prime_64850701,
    ExposureEvolution.KernelPratt.prime_64850771]

def block13 : Witness := ⟨⟨64947481, 65108760, 8069, 8081, 8087, 64947137, 64947227, 64947479⟩, 7⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8069,
    ExposureEvolution.KernelPratt.prime_8081,
    ExposureEvolution.KernelPratt.prime_8087,
    ExposureEvolution.KernelPratt.prime_64947137,
    ExposureEvolution.KernelPratt.prime_64947227,
    ExposureEvolution.KernelPratt.prime_64947479]

def block14 : Witness := ⟨⟨65108761, 65302560, 8081, 8087, 8089, 65108089, 65108629, 65108749⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8081,
    ExposureEvolution.KernelPratt.prime_8087,
    ExposureEvolution.KernelPratt.prime_8089,
    ExposureEvolution.KernelPratt.prime_65108089,
    ExposureEvolution.KernelPratt.prime_65108629,
    ExposureEvolution.KernelPratt.prime_65108749]

def block15 : Witness := ⟨⟨65302561, 65399568, 8087, 8089, 8093, 65302351, 65302547, 65302553⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8087,
    ExposureEvolution.KernelPratt.prime_8089,
    ExposureEvolution.KernelPratt.prime_8093,
    ExposureEvolution.KernelPratt.prime_65302351,
    ExposureEvolution.KernelPratt.prime_65302547,
    ExposureEvolution.KernelPratt.prime_65302553]

def block16 : Witness := ⟨⟨65399569, 65431920, 8089, 8093, 8101, 65399039, 65399093, 65399563⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8089,
    ExposureEvolution.KernelPratt.prime_8093,
    ExposureEvolution.KernelPratt.prime_8101,
    ExposureEvolution.KernelPratt.prime_65399039,
    ExposureEvolution.KernelPratt.prime_65399093,
    ExposureEvolution.KernelPratt.prime_65399563]

def block17 : Witness := ⟨⟨65431921, 65496648, 8093, 8101, 8111, 65431547, 65431673, 65431913⟩, 11⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8093,
    ExposureEvolution.KernelPratt.prime_8101,
    ExposureEvolution.KernelPratt.prime_8111,
    ExposureEvolution.KernelPratt.prime_65431547,
    ExposureEvolution.KernelPratt.prime_65431673,
    ExposureEvolution.KernelPratt.prime_65431913]

def block18 : Witness := ⟨⟨65496649, 65626200, 8101, 8111, 8117, 65495987, 65495993, 65496647⟩, 10⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8101,
    ExposureEvolution.KernelPratt.prime_8111,
    ExposureEvolution.KernelPratt.prime_8117,
    ExposureEvolution.KernelPratt.prime_65495987,
    ExposureEvolution.KernelPratt.prime_65495993,
    ExposureEvolution.KernelPratt.prime_65496647]

def block19 : Witness := ⟨⟨65626201, 65788320, 8111, 8117, 8123, 65625809, 65626037, 65626193⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8111,
    ExposureEvolution.KernelPratt.prime_8117,
    ExposureEvolution.KernelPratt.prime_8123,
    ExposureEvolution.KernelPratt.prime_65625809,
    ExposureEvolution.KernelPratt.prime_65626037,
    ExposureEvolution.KernelPratt.prime_65626193]

def block20 : Witness := ⟨⟨65788321, 65885688, 8117, 8123, 8147, 65787737, 65788157, 65788319⟩, 10⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8117,
    ExposureEvolution.KernelPratt.prime_8123,
    ExposureEvolution.KernelPratt.prime_8147,
    ExposureEvolution.KernelPratt.prime_65787737,
    ExposureEvolution.KernelPratt.prime_65788157,
    ExposureEvolution.KernelPratt.prime_65788319]

def block21 : Witness := ⟨⟨65885689, 65983128, 8123, 8147, 8161, 65885311, 65885333, 65885669⟩, 10⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8123,
    ExposureEvolution.KernelPratt.prime_8147,
    ExposureEvolution.KernelPratt.prime_8161,
    ExposureEvolution.KernelPratt.prime_65885311,
    ExposureEvolution.KernelPratt.prime_65885333,
    ExposureEvolution.KernelPratt.prime_65885669]

def block22 : Witness := ⟨⟨65983129, 66373608, 8147, 8161, 8167, 65982659, 65983009, 65983121⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8147,
    ExposureEvolution.KernelPratt.prime_8161,
    ExposureEvolution.KernelPratt.prime_8167,
    ExposureEvolution.KernelPratt.prime_65982659,
    ExposureEvolution.KernelPratt.prime_65983009,
    ExposureEvolution.KernelPratt.prime_65983121]

def block23 : Witness := ⟨⟨66373609, 66601920, 8161, 8167, 8171, 66373187, 66373339, 66373603⟩, 9⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8161,
    ExposureEvolution.KernelPratt.prime_8167,
    ExposureEvolution.KernelPratt.prime_8171,
    ExposureEvolution.KernelPratt.prime_66373187,
    ExposureEvolution.KernelPratt.prime_66373339,
    ExposureEvolution.KernelPratt.prime_66373603]

def block24 : Witness := ⟨⟨66601921, 66699888, 8167, 8171, 8179, 66601693, 66601747, 66601901⟩, 8⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8167,
    ExposureEvolution.KernelPratt.prime_8171,
    ExposureEvolution.KernelPratt.prime_8179,
    ExposureEvolution.KernelPratt.prime_66601693,
    ExposureEvolution.KernelPratt.prime_66601747,
    ExposureEvolution.KernelPratt.prime_66601901]

def block25 : Witness := ⟨⟨66699889, 66765240, 8171, 8179, 8191, 66699649, 66699761, 66699847⟩, 15⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8171,
    ExposureEvolution.KernelPratt.prime_8179,
    ExposureEvolution.KernelPratt.prime_8191,
    ExposureEvolution.KernelPratt.prime_66699649,
    ExposureEvolution.KernelPratt.prime_66699761,
    ExposureEvolution.KernelPratt.prime_66699847]

def block26 : Witness := ⟨⟨66765241, 66896040, 8179, 8191, 8209, 66765059, 66765199, 66765211⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8179,
    ExposureEvolution.KernelPratt.prime_8191,
    ExposureEvolution.KernelPratt.prime_8209,
    ExposureEvolution.KernelPratt.prime_66765059,
    ExposureEvolution.KernelPratt.prime_66765199,
    ExposureEvolution.KernelPratt.prime_66765211]

def block27 : Witness := ⟨⟨66896041, 67092480, 8191, 8209, 8219, 66895771, 66895943, 66896033⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8191,
    ExposureEvolution.KernelPratt.prime_8209,
    ExposureEvolution.KernelPratt.prime_8219,
    ExposureEvolution.KernelPratt.prime_66895771,
    ExposureEvolution.KernelPratt.prime_66895943,
    ExposureEvolution.KernelPratt.prime_66896033]

def block28 : Witness := ⟨⟨67092481, 67387680, 8209, 8219, 8221, 67092001, 67092367, 67092461⟩, 8⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8209,
    ExposureEvolution.KernelPratt.prime_8219,
    ExposureEvolution.KernelPratt.prime_8221,
    ExposureEvolution.KernelPratt.prime_67092001,
    ExposureEvolution.KernelPratt.prime_67092367,
    ExposureEvolution.KernelPratt.prime_67092461]

def block29 : Witness := ⟨⟨67387681, 67551960, 8219, 8221, 8231, 67387517, 67387627, 67387679⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8219,
    ExposureEvolution.KernelPratt.prime_8221,
    ExposureEvolution.KernelPratt.prime_8231,
    ExposureEvolution.KernelPratt.prime_67387517,
    ExposureEvolution.KernelPratt.prime_67387627,
    ExposureEvolution.KernelPratt.prime_67387679]

def block30 : Witness := ⟨⟨67551961, 67584840, 8221, 8231, 8233, 67551619, 67551703, 67551959⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8221,
    ExposureEvolution.KernelPratt.prime_8231,
    ExposureEvolution.KernelPratt.prime_8233,
    ExposureEvolution.KernelPratt.prime_67551619,
    ExposureEvolution.KernelPratt.prime_67551703,
    ExposureEvolution.KernelPratt.prime_67551959]

def block31 : Witness := ⟨⟨67584841, 67749360, 8231, 8233, 8237, 67584331, 67584599, 67584817⟩, 7⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8231,
    ExposureEvolution.KernelPratt.prime_8233,
    ExposureEvolution.KernelPratt.prime_8237,
    ExposureEvolution.KernelPratt.prime_67584331,
    ExposureEvolution.KernelPratt.prime_67584599,
    ExposureEvolution.KernelPratt.prime_67584817]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 67749361 stop tail = true) :
    coverage 62710561 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks26
