import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks08
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨8637721, 8720208, 2953, 2957, 2963, 8637323, 8637373, 8637701⟩, 8⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2953,
    ExposureEvolution.KernelPratt.prime_2957,
    ExposureEvolution.KernelPratt.prime_2963,
    ExposureEvolution.KernelPratt.prime_8637323,
    ExposureEvolution.KernelPratt.prime_8637373,
    ExposureEvolution.KernelPratt.prime_8637701]

def block01 : Witness := ⟨⟨8720209, 8743848, 2957, 2963, 2969, 8719939, 8719961, 8720191⟩, 8⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2957,
    ExposureEvolution.KernelPratt.prime_2963,
    ExposureEvolution.KernelPratt.prime_2969,
    ExposureEvolution.KernelPratt.prime_8719939,
    ExposureEvolution.KernelPratt.prime_8719961,
    ExposureEvolution.KernelPratt.prime_8720191]

def block02 : Witness := ⟨⟨8743849, 8779368, 2963, 2969, 2971, 8743513, 8743753, 8743843⟩, 10⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2963,
    ExposureEvolution.KernelPratt.prime_2969,
    ExposureEvolution.KernelPratt.prime_2971,
    ExposureEvolution.KernelPratt.prime_8743513,
    ExposureEvolution.KernelPratt.prime_8743753,
    ExposureEvolution.KernelPratt.prime_8743843]

def block03 : Witness := ⟨⟨8779369, 8814960, 2969, 2971, 2999, 8778901, 8779063, 8779321⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2969,
    ExposureEvolution.KernelPratt.prime_2971,
    ExposureEvolution.KernelPratt.prime_2999,
    ExposureEvolution.KernelPratt.prime_8778901,
    ExposureEvolution.KernelPratt.prime_8779063,
    ExposureEvolution.KernelPratt.prime_8779321]

def block04 : Witness := ⟨⟨8814961, 8826840, 2971, 2999, 3001, 8814779, 8814929, 8814941⟩, 8⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2971,
    ExposureEvolution.KernelPratt.prime_2999,
    ExposureEvolution.KernelPratt.prime_3001,
    ExposureEvolution.KernelPratt.prime_8814779,
    ExposureEvolution.KernelPratt.prime_8814929,
    ExposureEvolution.KernelPratt.prime_8814941]

def block05 : Witness := ⟨⟨8826841, 8994000, 2999, 3001, 3011, 8826463, 8826809, 8826833⟩, 10⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2999,
    ExposureEvolution.KernelPratt.prime_3001,
    ExposureEvolution.KernelPratt.prime_3011,
    ExposureEvolution.KernelPratt.prime_8826463,
    ExposureEvolution.KernelPratt.prime_8826809,
    ExposureEvolution.KernelPratt.prime_8826833]

def block06 : Witness := ⟨⟨8994001, 9006000, 3001, 3011, 3019, 8993827, 8993839, 8993981⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3001,
    ExposureEvolution.KernelPratt.prime_3011,
    ExposureEvolution.KernelPratt.prime_3019,
    ExposureEvolution.KernelPratt.prime_8993827,
    ExposureEvolution.KernelPratt.prime_8993839,
    ExposureEvolution.KernelPratt.prime_8993981]

def block07 : Witness := ⟨⟨9006001, 9066120, 3011, 3019, 3023, 9005473, 9005839, 9005989⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3011,
    ExposureEvolution.KernelPratt.prime_3019,
    ExposureEvolution.KernelPratt.prime_3023,
    ExposureEvolution.KernelPratt.prime_9005473,
    ExposureEvolution.KernelPratt.prime_9005839,
    ExposureEvolution.KernelPratt.prime_9005989]

def block08 : Witness := ⟨⟨9066121, 9114360, 3019, 3023, 3037, 9065839, 9065923, 9066091⟩, 5⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3019,
    ExposureEvolution.KernelPratt.prime_3023,
    ExposureEvolution.KernelPratt.prime_3037,
    ExposureEvolution.KernelPratt.prime_9065839,
    ExposureEvolution.KernelPratt.prime_9065923,
    ExposureEvolution.KernelPratt.prime_9066091]

def block09 : Witness := ⟨⟨9114361, 9138528, 3023, 3037, 3041, 9114073, 9114263, 9114353⟩, 9⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3023,
    ExposureEvolution.KernelPratt.prime_3037,
    ExposureEvolution.KernelPratt.prime_3041,
    ExposureEvolution.KernelPratt.prime_9114073,
    ExposureEvolution.KernelPratt.prime_9114263,
    ExposureEvolution.KernelPratt.prime_9114353]

def block10 : Witness := ⟨⟨9138529, 9223368, 3037, 3041, 3049, 9138329, 9138443, 9138527⟩, 7⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3037,
    ExposureEvolution.KernelPratt.prime_3041,
    ExposureEvolution.KernelPratt.prime_3049,
    ExposureEvolution.KernelPratt.prime_9138329,
    ExposureEvolution.KernelPratt.prime_9138443,
    ExposureEvolution.KernelPratt.prime_9138527]

def block11 : Witness := ⟨⟨9223369, 9247680, 3041, 3049, 3061, 9223003, 9223091, 9223351⟩, 13⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3041,
    ExposureEvolution.KernelPratt.prime_3049,
    ExposureEvolution.KernelPratt.prime_3061,
    ExposureEvolution.KernelPratt.prime_9223003,
    ExposureEvolution.KernelPratt.prime_9223091,
    ExposureEvolution.KernelPratt.prime_9223351]

def block12 : Witness := ⟨⟨9247681, 9296400, 3049, 3061, 3067, 9247409, 9247489, 9247663⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3049,
    ExposureEvolution.KernelPratt.prime_3061,
    ExposureEvolution.KernelPratt.prime_3067,
    ExposureEvolution.KernelPratt.prime_9247409,
    ExposureEvolution.KernelPratt.prime_9247489,
    ExposureEvolution.KernelPratt.prime_9247663]

def block13 : Witness := ⟨⟨9296401, 9369720, 3061, 3067, 3079, 9296029, 9296087, 9296387⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3061,
    ExposureEvolution.KernelPratt.prime_3067,
    ExposureEvolution.KernelPratt.prime_3079,
    ExposureEvolution.KernelPratt.prime_9296029,
    ExposureEvolution.KernelPratt.prime_9296087,
    ExposureEvolution.KernelPratt.prime_9296387]

def block14 : Witness := ⟨⟨9369721, 9406488, 3067, 3079, 3083, 9369677, 9369709, 9369713⟩, 9⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3067,
    ExposureEvolution.KernelPratt.prime_3079,
    ExposureEvolution.KernelPratt.prime_3083,
    ExposureEvolution.KernelPratt.prime_9369677,
    ExposureEvolution.KernelPratt.prime_9369709,
    ExposureEvolution.KernelPratt.prime_9369713]

def block15 : Witness := ⟨⟨9406489, 9480240, 3079, 3083, 3089, 9406289, 9406291, 9406483⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3079,
    ExposureEvolution.KernelPratt.prime_3083,
    ExposureEvolution.KernelPratt.prime_3089,
    ExposureEvolution.KernelPratt.prime_9406289,
    ExposureEvolution.KernelPratt.prime_9406291,
    ExposureEvolution.KernelPratt.prime_9406483]

def block16 : Witness := ⟨⟨9480241, 9504888, 3083, 3089, 3109, 9479923, 9479971, 9480239⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3083,
    ExposureEvolution.KernelPratt.prime_3089,
    ExposureEvolution.KernelPratt.prime_3109,
    ExposureEvolution.KernelPratt.prime_9479923,
    ExposureEvolution.KernelPratt.prime_9479971,
    ExposureEvolution.KernelPratt.prime_9480239]

def block17 : Witness := ⟨⟨9504889, 9541920, 3089, 3109, 3119, 9504653, 9504823, 9504877⟩, 10⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3089,
    ExposureEvolution.KernelPratt.prime_3109,
    ExposureEvolution.KernelPratt.prime_3119,
    ExposureEvolution.KernelPratt.prime_9504653,
    ExposureEvolution.KernelPratt.prime_9504823,
    ExposureEvolution.KernelPratt.prime_9504877]

def block18 : Witness := ⟨⟨9541921, 9665880, 3109, 3119, 3121, 9541589, 9541871, 9541919⟩, 7⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3109,
    ExposureEvolution.KernelPratt.prime_3119,
    ExposureEvolution.KernelPratt.prime_3121,
    ExposureEvolution.KernelPratt.prime_9541589,
    ExposureEvolution.KernelPratt.prime_9541871,
    ExposureEvolution.KernelPratt.prime_9541919]

def block19 : Witness := ⟨⟨9665881, 9728160, 3119, 3121, 3137, 9665587, 9665609, 9665863⟩, 7⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3119,
    ExposureEvolution.KernelPratt.prime_3121,
    ExposureEvolution.KernelPratt.prime_3137,
    ExposureEvolution.KernelPratt.prime_9665587,
    ExposureEvolution.KernelPratt.prime_9665609,
    ExposureEvolution.KernelPratt.prime_9665863]

def block20 : Witness := ⟨⟨9728161, 9740640, 3121, 3137, 3163, 9727799, 9727973, 9728153⟩, 10⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3121,
    ExposureEvolution.KernelPratt.prime_3137,
    ExposureEvolution.KernelPratt.prime_3163,
    ExposureEvolution.KernelPratt.prime_9727799,
    ExposureEvolution.KernelPratt.prime_9727973,
    ExposureEvolution.KernelPratt.prime_9728153]

def block21 : Witness := ⟨⟨9740641, 9840768, 3137, 3163, 3167, 9740413, 9740513, 9740639⟩, 13⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3137,
    ExposureEvolution.KernelPratt.prime_3163,
    ExposureEvolution.KernelPratt.prime_3167,
    ExposureEvolution.KernelPratt.prime_9740413,
    ExposureEvolution.KernelPratt.prime_9740513,
    ExposureEvolution.KernelPratt.prime_9740639]

def block22 : Witness := ⟨⟨9840769, 10004568, 3163, 3167, 3169, 9840253, 9840647, 9840763⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3163,
    ExposureEvolution.KernelPratt.prime_3167,
    ExposureEvolution.KernelPratt.prime_3169,
    ExposureEvolution.KernelPratt.prime_9840253,
    ExposureEvolution.KernelPratt.prime_9840647,
    ExposureEvolution.KernelPratt.prime_9840763]

def block23 : Witness := ⟨⟨10004569, 10029888, 3167, 3169, 3181, 10004263, 10004297, 10004557⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3167,
    ExposureEvolution.KernelPratt.prime_3169,
    ExposureEvolution.KernelPratt.prime_3181,
    ExposureEvolution.KernelPratt.prime_10004263,
    ExposureEvolution.KernelPratt.prime_10004297,
    ExposureEvolution.KernelPratt.prime_10004557]

def block24 : Witness := ⟨⟨10029889, 10042560, 3169, 3181, 3187, 10029619, 10029829, 10029883⟩, 10⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3169,
    ExposureEvolution.KernelPratt.prime_3181,
    ExposureEvolution.KernelPratt.prime_3187,
    ExposureEvolution.KernelPratt.prime_10029619,
    ExposureEvolution.KernelPratt.prime_10029829,
    ExposureEvolution.KernelPratt.prime_10029883]

def block25 : Witness := ⟨⟨10042561, 10118760, 3181, 3187, 3191, 10042103, 10042147, 10042553⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3181,
    ExposureEvolution.KernelPratt.prime_3187,
    ExposureEvolution.KernelPratt.prime_3191,
    ExposureEvolution.KernelPratt.prime_10042103,
    ExposureEvolution.KernelPratt.prime_10042147,
    ExposureEvolution.KernelPratt.prime_10042553]

def block26 : Witness := ⟨⟨10118761, 10156968, 3187, 3191, 3203, 10118569, 10118609, 10118753⟩, 9⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3187,
    ExposureEvolution.KernelPratt.prime_3191,
    ExposureEvolution.KernelPratt.prime_3203,
    ExposureEvolution.KernelPratt.prime_10118569,
    ExposureEvolution.KernelPratt.prime_10118609,
    ExposureEvolution.KernelPratt.prime_10118753]

def block27 : Witness := ⟨⟨10156969, 10182480, 3191, 3203, 3209, 10156723, 10156771, 10156957⟩, 7⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3191,
    ExposureEvolution.KernelPratt.prime_3203,
    ExposureEvolution.KernelPratt.prime_3209,
    ExposureEvolution.KernelPratt.prime_10156723,
    ExposureEvolution.KernelPratt.prime_10156771,
    ExposureEvolution.KernelPratt.prime_10156957]

def block28 : Witness := ⟨⟨10182481, 10259208, 3203, 3209, 3217, 10182097, 10182239, 10182463⟩, 7⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3203,
    ExposureEvolution.KernelPratt.prime_3209,
    ExposureEvolution.KernelPratt.prime_3217,
    ExposureEvolution.KernelPratt.prime_10182097,
    ExposureEvolution.KernelPratt.prime_10182239,
    ExposureEvolution.KernelPratt.prime_10182463]

def block29 : Witness := ⟨⟨10259209, 10297680, 3209, 3217, 3221, 10258951, 10259083, 10259203⟩, 11⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3209,
    ExposureEvolution.KernelPratt.prime_3217,
    ExposureEvolution.KernelPratt.prime_3221,
    ExposureEvolution.KernelPratt.prime_10258951,
    ExposureEvolution.KernelPratt.prime_10259083,
    ExposureEvolution.KernelPratt.prime_10259203]

def block30 : Witness := ⟨⟨10297681, 10349088, 3217, 3221, 3229, 10297439, 10297607, 10297669⟩, 9⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3217,
    ExposureEvolution.KernelPratt.prime_3221,
    ExposureEvolution.KernelPratt.prime_3229,
    ExposureEvolution.KernelPratt.prime_10297439,
    ExposureEvolution.KernelPratt.prime_10297607,
    ExposureEvolution.KernelPratt.prime_10297669]

def block31 : Witness := ⟨⟨10349089, 10374840, 3221, 3229, 3251, 10348841, 10348951, 10349083⟩, 11⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3221,
    ExposureEvolution.KernelPratt.prime_3229,
    ExposureEvolution.KernelPratt.prime_3251,
    ExposureEvolution.KernelPratt.prime_10348841,
    ExposureEvolution.KernelPratt.prime_10348951,
    ExposureEvolution.KernelPratt.prime_10349083]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 10374841 stop tail = true) :
    coverage 8637721 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks08
