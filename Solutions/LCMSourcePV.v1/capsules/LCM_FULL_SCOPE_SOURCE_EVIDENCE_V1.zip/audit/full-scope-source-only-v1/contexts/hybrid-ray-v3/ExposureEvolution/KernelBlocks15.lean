import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks15
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨23164969, 23203488, 4817, 4831, 4861, 23164681, 23164699, 23164963⟩, 9⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4817,
    ExposureEvolution.KernelPratt.prime_4831,
    ExposureEvolution.KernelPratt.prime_4861,
    ExposureEvolution.KernelPratt.prime_23164681,
    ExposureEvolution.KernelPratt.prime_23164699,
    ExposureEvolution.KernelPratt.prime_23164963]

def block01 : Witness := ⟨⟨23203489, 23338560, 4831, 4861, 4871, 23203207, 23203321, 23203483⟩, 7⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4831,
    ExposureEvolution.KernelPratt.prime_4861,
    ExposureEvolution.KernelPratt.prime_4871,
    ExposureEvolution.KernelPratt.prime_23203207,
    ExposureEvolution.KernelPratt.prime_23203321,
    ExposureEvolution.KernelPratt.prime_23203483]

def block02 : Witness := ⟨⟨23338561, 23629320, 4861, 4871, 4877, 23338457, 23338493, 23338547⟩, 8⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4861,
    ExposureEvolution.KernelPratt.prime_4871,
    ExposureEvolution.KernelPratt.prime_4877,
    ExposureEvolution.KernelPratt.prime_23338457,
    ExposureEvolution.KernelPratt.prime_23338493,
    ExposureEvolution.KernelPratt.prime_23338547]

def block03 : Witness := ⟨⟨23629321, 23726640, 4871, 4877, 4889, 23629033, 23629259, 23629313⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4871,
    ExposureEvolution.KernelPratt.prime_4877,
    ExposureEvolution.KernelPratt.prime_4889,
    ExposureEvolution.KernelPratt.prime_23629033,
    ExposureEvolution.KernelPratt.prime_23629259,
    ExposureEvolution.KernelPratt.prime_23629313]

def block04 : Witness := ⟨⟨23726641, 23785128, 4877, 4889, 4903, 23726513, 23726561, 23726603⟩, 8⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4877,
    ExposureEvolution.KernelPratt.prime_4889,
    ExposureEvolution.KernelPratt.prime_4903,
    ExposureEvolution.KernelPratt.prime_23726513,
    ExposureEvolution.KernelPratt.prime_23726561,
    ExposureEvolution.KernelPratt.prime_23726603]

def block05 : Witness := ⟨⟨23785129, 23902320, 4889, 4903, 4909, 23784899, 23784947, 23785121⟩, 8⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4889,
    ExposureEvolution.KernelPratt.prime_4903,
    ExposureEvolution.KernelPratt.prime_4909,
    ExposureEvolution.KernelPratt.prime_23784899,
    ExposureEvolution.KernelPratt.prime_23784947,
    ExposureEvolution.KernelPratt.prime_23785121]

def block06 : Witness := ⟨⟨23902321, 24039408, 4903, 4909, 4919, 23902159, 23902181, 23902309⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4903,
    ExposureEvolution.KernelPratt.prime_4909,
    ExposureEvolution.KernelPratt.prime_4919,
    ExposureEvolution.KernelPratt.prime_23902159,
    ExposureEvolution.KernelPratt.prime_23902181,
    ExposureEvolution.KernelPratt.prime_23902309]

def block07 : Witness := ⟨⟨24039409, 24098280, 4909, 4919, 4931, 24039031, 24039383, 24039397⟩, 7⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4909,
    ExposureEvolution.KernelPratt.prime_4919,
    ExposureEvolution.KernelPratt.prime_4931,
    ExposureEvolution.KernelPratt.prime_24039031,
    ExposureEvolution.KernelPratt.prime_24039383,
    ExposureEvolution.KernelPratt.prime_24039397]

def block08 : Witness := ⟨⟨24098281, 24196560, 4919, 4931, 4933, 24097679, 24097963, 24098209⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4919,
    ExposureEvolution.KernelPratt.prime_4931,
    ExposureEvolution.KernelPratt.prime_4933,
    ExposureEvolution.KernelPratt.prime_24097679,
    ExposureEvolution.KernelPratt.prime_24097963,
    ExposureEvolution.KernelPratt.prime_24098209]

def block09 : Witness := ⟨⟨24196561, 24314760, 4931, 4933, 4937, 24196181, 24196531, 24196541⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4931,
    ExposureEvolution.KernelPratt.prime_4933,
    ExposureEvolution.KernelPratt.prime_4937,
    ExposureEvolution.KernelPratt.prime_24196181,
    ExposureEvolution.KernelPratt.prime_24196531,
    ExposureEvolution.KernelPratt.prime_24196541]

def block10 : Witness := ⟨⟨24314761, 24334488, 4933, 4937, 4943, 24314327, 24314677, 24314753⟩, 10⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4933,
    ExposureEvolution.KernelPratt.prime_4937,
    ExposureEvolution.KernelPratt.prime_4943,
    ExposureEvolution.KernelPratt.prime_24314327,
    ExposureEvolution.KernelPratt.prime_24314677,
    ExposureEvolution.KernelPratt.prime_24314753]

def block11 : Witness := ⟨⟨24334489, 24373968, 4937, 4943, 4951, 24334091, 24334241, 24334481⟩, 9⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4937,
    ExposureEvolution.KernelPratt.prime_4943,
    ExposureEvolution.KernelPratt.prime_4951,
    ExposureEvolution.KernelPratt.prime_24334091,
    ExposureEvolution.KernelPratt.prime_24334241,
    ExposureEvolution.KernelPratt.prime_24334481]

def block12 : Witness := ⟨⟨24373969, 24433248, 4943, 4951, 4957, 24373703, 24373907, 24373963⟩, 8⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4943,
    ExposureEvolution.KernelPratt.prime_4951,
    ExposureEvolution.KernelPratt.prime_4957,
    ExposureEvolution.KernelPratt.prime_24373703,
    ExposureEvolution.KernelPratt.prime_24373907,
    ExposureEvolution.KernelPratt.prime_24373963]

def block13 : Witness := ⟨⟨24433249, 24512400, 4951, 4957, 4967, 24432847, 24433187, 24433243⟩, 7⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4951,
    ExposureEvolution.KernelPratt.prime_4957,
    ExposureEvolution.KernelPratt.prime_4967,
    ExposureEvolution.KernelPratt.prime_24432847,
    ExposureEvolution.KernelPratt.prime_24433187,
    ExposureEvolution.KernelPratt.prime_24433243]

def block14 : Witness := ⟨⟨24512401, 24571848, 4957, 4967, 4969, 24511999, 24512281, 24512399⟩, 10⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4957,
    ExposureEvolution.KernelPratt.prime_4967,
    ExposureEvolution.KernelPratt.prime_4969,
    ExposureEvolution.KernelPratt.prime_24511999,
    ExposureEvolution.KernelPratt.prime_24512281,
    ExposureEvolution.KernelPratt.prime_24512399]

def block15 : Witness := ⟨⟨24571849, 24671088, 4967, 4969, 4973, 24571457, 24571487, 24571847⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4967,
    ExposureEvolution.KernelPratt.prime_4969,
    ExposureEvolution.KernelPratt.prime_4973,
    ExposureEvolution.KernelPratt.prime_24571457,
    ExposureEvolution.KernelPratt.prime_24571487,
    ExposureEvolution.KernelPratt.prime_24571847]

def block16 : Witness := ⟨⟨24671089, 24690960, 4969, 4973, 4987, 24670963, 24671051, 24671081⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4969,
    ExposureEvolution.KernelPratt.prime_4973,
    ExposureEvolution.KernelPratt.prime_4987,
    ExposureEvolution.KernelPratt.prime_24670963,
    ExposureEvolution.KernelPratt.prime_24671051,
    ExposureEvolution.KernelPratt.prime_24671081]

def block17 : Witness := ⟨⟨24690961, 24730728, 4973, 4987, 4993, 24690349, 24690649, 24690929⟩, 9⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4973,
    ExposureEvolution.KernelPratt.prime_4987,
    ExposureEvolution.KernelPratt.prime_4993,
    ExposureEvolution.KernelPratt.prime_24690349,
    ExposureEvolution.KernelPratt.prime_24690649,
    ExposureEvolution.KernelPratt.prime_24690929]

def block18 : Witness := ⟨⟨24730729, 24870168, 4987, 4993, 4999, 24730351, 24730661, 24730669⟩, 11⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4987,
    ExposureEvolution.KernelPratt.prime_4993,
    ExposureEvolution.KernelPratt.prime_4999,
    ExposureEvolution.KernelPratt.prime_24730351,
    ExposureEvolution.KernelPratt.prime_24730661,
    ExposureEvolution.KernelPratt.prime_24730669]

def block19 : Witness := ⟨⟨24870169, 24930048, 4993, 4999, 5003, 24870011, 24870137, 24870161⟩, 7⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4993,
    ExposureEvolution.KernelPratt.prime_4999,
    ExposureEvolution.KernelPratt.prime_5003,
    ExposureEvolution.KernelPratt.prime_24870011,
    ExposureEvolution.KernelPratt.prime_24870137,
    ExposureEvolution.KernelPratt.prime_24870161]

def block20 : Witness := ⟨⟨24930049, 24990000, 4999, 5003, 5009, 24929929, 24930043, 24930047⟩, 7⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4999,
    ExposureEvolution.KernelPratt.prime_5003,
    ExposureEvolution.KernelPratt.prime_5009,
    ExposureEvolution.KernelPratt.prime_24929929,
    ExposureEvolution.KernelPratt.prime_24930043,
    ExposureEvolution.KernelPratt.prime_24930047]

def block21 : Witness := ⟨⟨24990001, 25030008, 5003, 5009, 5011, 24989821, 24989879, 24989971⟩, 7⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5003,
    ExposureEvolution.KernelPratt.prime_5009,
    ExposureEvolution.KernelPratt.prime_5011,
    ExposureEvolution.KernelPratt.prime_24989821,
    ExposureEvolution.KernelPratt.prime_24989879,
    ExposureEvolution.KernelPratt.prime_24989971]

def block22 : Witness := ⟨⟨25030009, 25090080, 5009, 5011, 5021, 25029731, 25029853, 25029959⟩, 6⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5009,
    ExposureEvolution.KernelPratt.prime_5011,
    ExposureEvolution.KernelPratt.prime_5021,
    ExposureEvolution.KernelPratt.prime_25029731,
    ExposureEvolution.KernelPratt.prime_25029853,
    ExposureEvolution.KernelPratt.prime_25029959]

def block23 : Witness := ⟨⟨25090081, 25110120, 5011, 5021, 5023, 25089601, 25089863, 25090069⟩, 9⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5011,
    ExposureEvolution.KernelPratt.prime_5021,
    ExposureEvolution.KernelPratt.prime_5023,
    ExposureEvolution.KernelPratt.prime_25089601,
    ExposureEvolution.KernelPratt.prime_25089863,
    ExposureEvolution.KernelPratt.prime_25090069]

def block24 : Witness := ⟨⟨25110121, 25210440, 5021, 5023, 5039, 25109881, 25109971, 25110119⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5021,
    ExposureEvolution.KernelPratt.prime_5023,
    ExposureEvolution.KernelPratt.prime_5039,
    ExposureEvolution.KernelPratt.prime_25109881,
    ExposureEvolution.KernelPratt.prime_25109971,
    ExposureEvolution.KernelPratt.prime_25110119]

def block25 : Witness := ⟨⟨25210441, 25230528, 5023, 5039, 5051, 25210253, 25210403, 25210433⟩, 11⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5023,
    ExposureEvolution.KernelPratt.prime_5039,
    ExposureEvolution.KernelPratt.prime_5051,
    ExposureEvolution.KernelPratt.prime_25210253,
    ExposureEvolution.KernelPratt.prime_25210403,
    ExposureEvolution.KernelPratt.prime_25210433]

def block26 : Witness := ⟨⟨25230529, 25391520, 5039, 5051, 5059, 25230277, 25230449, 25230511⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5039,
    ExposureEvolution.KernelPratt.prime_5051,
    ExposureEvolution.KernelPratt.prime_5059,
    ExposureEvolution.KernelPratt.prime_25230277,
    ExposureEvolution.KernelPratt.prime_25230449,
    ExposureEvolution.KernelPratt.prime_25230511]

def block27 : Witness := ⟨⟨25391521, 25512600, 5051, 5059, 5077, 25391071, 25391437, 25391479⟩, 10⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5051,
    ExposureEvolution.KernelPratt.prime_5059,
    ExposureEvolution.KernelPratt.prime_5077,
    ExposureEvolution.KernelPratt.prime_25391071,
    ExposureEvolution.KernelPratt.prime_25391437,
    ExposureEvolution.KernelPratt.prime_25391479]

def block28 : Witness := ⟨⟨25512601, 25593480, 5059, 5077, 5081, 25512467, 25512523, 25512593⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5059,
    ExposureEvolution.KernelPratt.prime_5077,
    ExposureEvolution.KernelPratt.prime_5081,
    ExposureEvolution.KernelPratt.prime_25512467,
    ExposureEvolution.KernelPratt.prime_25512523,
    ExposureEvolution.KernelPratt.prime_25512593]

def block29 : Witness := ⟨⟨25593481, 25775928, 5077, 5081, 5087, 25593277, 25593317, 25593461⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5077,
    ExposureEvolution.KernelPratt.prime_5081,
    ExposureEvolution.KernelPratt.prime_5087,
    ExposureEvolution.KernelPratt.prime_25593277,
    ExposureEvolution.KernelPratt.prime_25593317,
    ExposureEvolution.KernelPratt.prime_25593461]

def block30 : Witness := ⟨⟨25775929, 25816560, 5081, 5087, 5099, 25775471, 25775473, 25775917⟩, 11⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5081,
    ExposureEvolution.KernelPratt.prime_5087,
    ExposureEvolution.KernelPratt.prime_5099,
    ExposureEvolution.KernelPratt.prime_25775471,
    ExposureEvolution.KernelPratt.prime_25775473,
    ExposureEvolution.KernelPratt.prime_25775917]

def block31 : Witness := ⟨⟨25816561, 25877568, 5087, 5099, 5101, 25816477, 25816517, 25816547⟩, 6⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5087,
    ExposureEvolution.KernelPratt.prime_5099,
    ExposureEvolution.KernelPratt.prime_5101,
    ExposureEvolution.KernelPratt.prime_25816477,
    ExposureEvolution.KernelPratt.prime_25816517,
    ExposureEvolution.KernelPratt.prime_25816547]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 25877569 stop tail = true) :
    coverage 23164969 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks15
