import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_005
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨23629321, 23726640, 4871, 4877, 4889, 23629033, 23629259, 23629313⟩, 8⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4871,
    ExposureEvolution.Compact40Pratt.prime_4877,
    ExposureEvolution.Compact40Pratt.prime_4889,
    ExposureEvolution.Compact40Pratt.prime_23629033,
    ExposureEvolution.Compact40Pratt.prime_23629259,
    ExposureEvolution.Compact40Pratt.prime_23629313]

def block01 : Witness := ⟨⟨23726641, 23785128, 4877, 4889, 4903, 23726513, 23726561, 23726603⟩, 8⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4877,
    ExposureEvolution.Compact40Pratt.prime_4889,
    ExposureEvolution.Compact40Pratt.prime_4903,
    ExposureEvolution.Compact40Pratt.prime_23726513,
    ExposureEvolution.Compact40Pratt.prime_23726561,
    ExposureEvolution.Compact40Pratt.prime_23726603]

def block02 : Witness := ⟨⟨23785129, 23902320, 4889, 4903, 4909, 23784899, 23784947, 23785121⟩, 8⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4889,
    ExposureEvolution.Compact40Pratt.prime_4903,
    ExposureEvolution.Compact40Pratt.prime_4909,
    ExposureEvolution.Compact40Pratt.prime_23784899,
    ExposureEvolution.Compact40Pratt.prime_23784947,
    ExposureEvolution.Compact40Pratt.prime_23785121]

def block03 : Witness := ⟨⟨23902321, 24039408, 4903, 4909, 4919, 23902159, 23902181, 23902309⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4903,
    ExposureEvolution.Compact40Pratt.prime_4909,
    ExposureEvolution.Compact40Pratt.prime_4919,
    ExposureEvolution.Compact40Pratt.prime_23902159,
    ExposureEvolution.Compact40Pratt.prime_23902181,
    ExposureEvolution.Compact40Pratt.prime_23902309]

def block04 : Witness := ⟨⟨24039409, 24098280, 4909, 4919, 4931, 24039031, 24039383, 24039397⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4909,
    ExposureEvolution.Compact40Pratt.prime_4919,
    ExposureEvolution.Compact40Pratt.prime_4931,
    ExposureEvolution.Compact40Pratt.prime_24039031,
    ExposureEvolution.Compact40Pratt.prime_24039383,
    ExposureEvolution.Compact40Pratt.prime_24039397]

def block05 : Witness := ⟨⟨24098281, 24196560, 4919, 4931, 4933, 24097679, 24097963, 24098209⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4919,
    ExposureEvolution.Compact40Pratt.prime_4931,
    ExposureEvolution.Compact40Pratt.prime_4933,
    ExposureEvolution.Compact40Pratt.prime_24097679,
    ExposureEvolution.Compact40Pratt.prime_24097963,
    ExposureEvolution.Compact40Pratt.prime_24098209]

def block06 : Witness := ⟨⟨24196561, 24314760, 4931, 4933, 4937, 24196181, 24196531, 24196541⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4931,
    ExposureEvolution.Compact40Pratt.prime_4933,
    ExposureEvolution.Compact40Pratt.prime_4937,
    ExposureEvolution.Compact40Pratt.prime_24196181,
    ExposureEvolution.Compact40Pratt.prime_24196531,
    ExposureEvolution.Compact40Pratt.prime_24196541]

def block07 : Witness := ⟨⟨24314761, 24334488, 4933, 4937, 4943, 24314327, 24314677, 24314753⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4933,
    ExposureEvolution.Compact40Pratt.prime_4937,
    ExposureEvolution.Compact40Pratt.prime_4943,
    ExposureEvolution.Compact40Pratt.prime_24314327,
    ExposureEvolution.Compact40Pratt.prime_24314677,
    ExposureEvolution.Compact40Pratt.prime_24314753]

def block08 : Witness := ⟨⟨24334489, 24373968, 4937, 4943, 4951, 24334091, 24334241, 24334481⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4937,
    ExposureEvolution.Compact40Pratt.prime_4943,
    ExposureEvolution.Compact40Pratt.prime_4951,
    ExposureEvolution.Compact40Pratt.prime_24334091,
    ExposureEvolution.Compact40Pratt.prime_24334241,
    ExposureEvolution.Compact40Pratt.prime_24334481]

def block09 : Witness := ⟨⟨24373969, 24433248, 4943, 4951, 4957, 24373703, 24373907, 24373963⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4943,
    ExposureEvolution.Compact40Pratt.prime_4951,
    ExposureEvolution.Compact40Pratt.prime_4957,
    ExposureEvolution.Compact40Pratt.prime_24373703,
    ExposureEvolution.Compact40Pratt.prime_24373907,
    ExposureEvolution.Compact40Pratt.prime_24373963]

def block10 : Witness := ⟨⟨24433249, 24512400, 4951, 4957, 4967, 24432847, 24433187, 24433243⟩, 7⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4951,
    ExposureEvolution.Compact40Pratt.prime_4957,
    ExposureEvolution.Compact40Pratt.prime_4967,
    ExposureEvolution.Compact40Pratt.prime_24432847,
    ExposureEvolution.Compact40Pratt.prime_24433187,
    ExposureEvolution.Compact40Pratt.prime_24433243]

def block11 : Witness := ⟨⟨24512401, 24571848, 4957, 4967, 4969, 24511999, 24512281, 24512399⟩, 10⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4957,
    ExposureEvolution.Compact40Pratt.prime_4967,
    ExposureEvolution.Compact40Pratt.prime_4969,
    ExposureEvolution.Compact40Pratt.prime_24511999,
    ExposureEvolution.Compact40Pratt.prime_24512281,
    ExposureEvolution.Compact40Pratt.prime_24512399]

def block12 : Witness := ⟨⟨24571849, 24671088, 4967, 4969, 4973, 24571457, 24571487, 24571847⟩, 8⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4967,
    ExposureEvolution.Compact40Pratt.prime_4969,
    ExposureEvolution.Compact40Pratt.prime_4973,
    ExposureEvolution.Compact40Pratt.prime_24571457,
    ExposureEvolution.Compact40Pratt.prime_24571487,
    ExposureEvolution.Compact40Pratt.prime_24571847]

def block13 : Witness := ⟨⟨24671089, 24690960, 4969, 4973, 4987, 24670963, 24671051, 24671081⟩, 10⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4969,
    ExposureEvolution.Compact40Pratt.prime_4973,
    ExposureEvolution.Compact40Pratt.prime_4987,
    ExposureEvolution.Compact40Pratt.prime_24670963,
    ExposureEvolution.Compact40Pratt.prime_24671051,
    ExposureEvolution.Compact40Pratt.prime_24671081]

def block14 : Witness := ⟨⟨24690961, 24730728, 4973, 4987, 4993, 24690349, 24690649, 24690929⟩, 9⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4973,
    ExposureEvolution.Compact40Pratt.prime_4987,
    ExposureEvolution.Compact40Pratt.prime_4993,
    ExposureEvolution.Compact40Pratt.prime_24690349,
    ExposureEvolution.Compact40Pratt.prime_24690649,
    ExposureEvolution.Compact40Pratt.prime_24690929]

def block15 : Witness := ⟨⟨24730729, 24870168, 4987, 4993, 4999, 24730351, 24730661, 24730669⟩, 11⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4987,
    ExposureEvolution.Compact40Pratt.prime_4993,
    ExposureEvolution.Compact40Pratt.prime_4999,
    ExposureEvolution.Compact40Pratt.prime_24730351,
    ExposureEvolution.Compact40Pratt.prime_24730661,
    ExposureEvolution.Compact40Pratt.prime_24730669]

def block16 : Witness := ⟨⟨24870169, 24930048, 4993, 4999, 5003, 24870011, 24870137, 24870161⟩, 7⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4993,
    ExposureEvolution.Compact40Pratt.prime_4999,
    ExposureEvolution.Compact40Pratt.prime_5003,
    ExposureEvolution.Compact40Pratt.prime_24870011,
    ExposureEvolution.Compact40Pratt.prime_24870137,
    ExposureEvolution.Compact40Pratt.prime_24870161]

def block17 : Witness := ⟨⟨24930049, 24990000, 4999, 5003, 5009, 24929929, 24930043, 24930047⟩, 7⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4999,
    ExposureEvolution.Compact40Pratt.prime_5003,
    ExposureEvolution.Compact40Pratt.prime_5009,
    ExposureEvolution.Compact40Pratt.prime_24929929,
    ExposureEvolution.Compact40Pratt.prime_24930043,
    ExposureEvolution.Compact40Pratt.prime_24930047]

def block18 : Witness := ⟨⟨24990001, 25030008, 5003, 5009, 5011, 24989821, 24989879, 24989971⟩, 7⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5003,
    ExposureEvolution.Compact40Pratt.prime_5009,
    ExposureEvolution.Compact40Pratt.prime_5011,
    ExposureEvolution.Compact40Pratt.prime_24989821,
    ExposureEvolution.Compact40Pratt.prime_24989879,
    ExposureEvolution.Compact40Pratt.prime_24989971]

def block19 : Witness := ⟨⟨25030009, 25090080, 5009, 5011, 5021, 25029731, 25029853, 25029959⟩, 6⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5009,
    ExposureEvolution.Compact40Pratt.prime_5011,
    ExposureEvolution.Compact40Pratt.prime_5021,
    ExposureEvolution.Compact40Pratt.prime_25029731,
    ExposureEvolution.Compact40Pratt.prime_25029853,
    ExposureEvolution.Compact40Pratt.prime_25029959]

def block20 : Witness := ⟨⟨25090081, 25110120, 5011, 5021, 5023, 25089601, 25089863, 25090069⟩, 9⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5011,
    ExposureEvolution.Compact40Pratt.prime_5021,
    ExposureEvolution.Compact40Pratt.prime_5023,
    ExposureEvolution.Compact40Pratt.prime_25089601,
    ExposureEvolution.Compact40Pratt.prime_25089863,
    ExposureEvolution.Compact40Pratt.prime_25090069]

def block21 : Witness := ⟨⟨25110121, 25210440, 5021, 5023, 5039, 25109881, 25109971, 25110119⟩, 9⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5021,
    ExposureEvolution.Compact40Pratt.prime_5023,
    ExposureEvolution.Compact40Pratt.prime_5039,
    ExposureEvolution.Compact40Pratt.prime_25109881,
    ExposureEvolution.Compact40Pratt.prime_25109971,
    ExposureEvolution.Compact40Pratt.prime_25110119]

def block22 : Witness := ⟨⟨25210441, 25230528, 5023, 5039, 5051, 25210253, 25210403, 25210433⟩, 11⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5023,
    ExposureEvolution.Compact40Pratt.prime_5039,
    ExposureEvolution.Compact40Pratt.prime_5051,
    ExposureEvolution.Compact40Pratt.prime_25210253,
    ExposureEvolution.Compact40Pratt.prime_25210403,
    ExposureEvolution.Compact40Pratt.prime_25210433]

def block23 : Witness := ⟨⟨25230529, 25391520, 5039, 5051, 5059, 25230277, 25230449, 25230511⟩, 7⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5039,
    ExposureEvolution.Compact40Pratt.prime_5051,
    ExposureEvolution.Compact40Pratt.prime_5059,
    ExposureEvolution.Compact40Pratt.prime_25230277,
    ExposureEvolution.Compact40Pratt.prime_25230449,
    ExposureEvolution.Compact40Pratt.prime_25230511]

def block24 : Witness := ⟨⟨25391521, 25512600, 5051, 5059, 5077, 25391071, 25391437, 25391479⟩, 10⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5051,
    ExposureEvolution.Compact40Pratt.prime_5059,
    ExposureEvolution.Compact40Pratt.prime_5077,
    ExposureEvolution.Compact40Pratt.prime_25391071,
    ExposureEvolution.Compact40Pratt.prime_25391437,
    ExposureEvolution.Compact40Pratt.prime_25391479]

def block25 : Witness := ⟨⟨25512601, 25593480, 5059, 5077, 5081, 25512467, 25512523, 25512593⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5059,
    ExposureEvolution.Compact40Pratt.prime_5077,
    ExposureEvolution.Compact40Pratt.prime_5081,
    ExposureEvolution.Compact40Pratt.prime_25512467,
    ExposureEvolution.Compact40Pratt.prime_25512523,
    ExposureEvolution.Compact40Pratt.prime_25512593]

def block26 : Witness := ⟨⟨25593481, 25775928, 5077, 5081, 5087, 25593277, 25593317, 25593461⟩, 9⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5077,
    ExposureEvolution.Compact40Pratt.prime_5081,
    ExposureEvolution.Compact40Pratt.prime_5087,
    ExposureEvolution.Compact40Pratt.prime_25593277,
    ExposureEvolution.Compact40Pratt.prime_25593317,
    ExposureEvolution.Compact40Pratt.prime_25593461]

def block27 : Witness := ⟨⟨25775929, 25816560, 5081, 5087, 5099, 25775471, 25775473, 25775917⟩, 11⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5081,
    ExposureEvolution.Compact40Pratt.prime_5087,
    ExposureEvolution.Compact40Pratt.prime_5099,
    ExposureEvolution.Compact40Pratt.prime_25775471,
    ExposureEvolution.Compact40Pratt.prime_25775473,
    ExposureEvolution.Compact40Pratt.prime_25775917]

def block28 : Witness := ⟨⟨25816561, 25877568, 5087, 5099, 5101, 25816477, 25816517, 25816547⟩, 6⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5087,
    ExposureEvolution.Compact40Pratt.prime_5099,
    ExposureEvolution.Compact40Pratt.prime_5101,
    ExposureEvolution.Compact40Pratt.prime_25816477,
    ExposureEvolution.Compact40Pratt.prime_25816517,
    ExposureEvolution.Compact40Pratt.prime_25816547]

def block29 : Witness := ⟨⟨25877569, 25999800, 5099, 5101, 5107, 25877239, 25877561, 25877567⟩, 6⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5099,
    ExposureEvolution.Compact40Pratt.prime_5101,
    ExposureEvolution.Compact40Pratt.prime_5107,
    ExposureEvolution.Compact40Pratt.prime_25877239,
    ExposureEvolution.Compact40Pratt.prime_25877561,
    ExposureEvolution.Compact40Pratt.prime_25877567]

def block30 : Witness := ⟨⟨25999801, 26020200, 5101, 5107, 5113, 25999451, 25999691, 25999751⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5101,
    ExposureEvolution.Compact40Pratt.prime_5107,
    ExposureEvolution.Compact40Pratt.prime_5113,
    ExposureEvolution.Compact40Pratt.prime_25999451,
    ExposureEvolution.Compact40Pratt.prime_25999691,
    ExposureEvolution.Compact40Pratt.prime_25999751]

def block31 : Witness := ⟨⟨26020201, 26081448, 5107, 5113, 5119, 26019803, 26019971, 26020157⟩, 14⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5107,
    ExposureEvolution.Compact40Pratt.prime_5113,
    ExposureEvolution.Compact40Pratt.prime_5119,
    ExposureEvolution.Compact40Pratt.prime_26019803,
    ExposureEvolution.Compact40Pratt.prime_26019971,
    ExposureEvolution.Compact40Pratt.prime_26020157]

def block32 : Witness := ⟨⟨26081449, 26142768, 5113, 5119, 5147, 26081113, 26081257, 26081437⟩, 8⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5113,
    ExposureEvolution.Compact40Pratt.prime_5119,
    ExposureEvolution.Compact40Pratt.prime_5147,
    ExposureEvolution.Compact40Pratt.prime_26081113,
    ExposureEvolution.Compact40Pratt.prime_26081257,
    ExposureEvolution.Compact40Pratt.prime_26081437]

def block33 : Witness := ⟨⟨26142769, 26204160, 5119, 5147, 5153, 26142577, 26142629, 26142737⟩, 9⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5119,
    ExposureEvolution.Compact40Pratt.prime_5147,
    ExposureEvolution.Compact40Pratt.prime_5153,
    ExposureEvolution.Compact40Pratt.prime_26142577,
    ExposureEvolution.Compact40Pratt.prime_26142629,
    ExposureEvolution.Compact40Pratt.prime_26142737]

def block34 : Witness := ⟨⟨26204161, 26491608, 5147, 5153, 5167, 26203627, 26203873, 26204159⟩, 14⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5147,
    ExposureEvolution.Compact40Pratt.prime_5153,
    ExposureEvolution.Compact40Pratt.prime_5167,
    ExposureEvolution.Compact40Pratt.prime_26203627,
    ExposureEvolution.Compact40Pratt.prime_26203873,
    ExposureEvolution.Compact40Pratt.prime_26204159]

def block35 : Witness := ⟨⟨26491609, 26553408, 5153, 5167, 5171, 26491429, 26491433, 26491603⟩, 8⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5153,
    ExposureEvolution.Compact40Pratt.prime_5167,
    ExposureEvolution.Compact40Pratt.prime_5171,
    ExposureEvolution.Compact40Pratt.prime_26491429,
    ExposureEvolution.Compact40Pratt.prime_26491433,
    ExposureEvolution.Compact40Pratt.prime_26491603]

def block36 : Witness := ⟨⟨26553409, 26697888, 5167, 5171, 5179, 26553029, 26553257, 26553407⟩, 8⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5167,
    ExposureEvolution.Compact40Pratt.prime_5171,
    ExposureEvolution.Compact40Pratt.prime_5179,
    ExposureEvolution.Compact40Pratt.prime_26553029,
    ExposureEvolution.Compact40Pratt.prime_26553257,
    ExposureEvolution.Compact40Pratt.prime_26553407]

def block37 : Witness := ⟨⟨26697889, 26739240, 5171, 5179, 5189, 26697439, 26697511, 26697877⟩, 9⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5171,
    ExposureEvolution.Compact40Pratt.prime_5179,
    ExposureEvolution.Compact40Pratt.prime_5189,
    ExposureEvolution.Compact40Pratt.prime_26697439,
    ExposureEvolution.Compact40Pratt.prime_26697511,
    ExposureEvolution.Compact40Pratt.prime_26697877]

def block38 : Witness := ⟨⟨26739241, 26822040, 5179, 5189, 5197, 26738791, 26738839, 26739227⟩, 7⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5179,
    ExposureEvolution.Compact40Pratt.prime_5189,
    ExposureEvolution.Compact40Pratt.prime_5197,
    ExposureEvolution.Compact40Pratt.prime_26738791,
    ExposureEvolution.Compact40Pratt.prime_26738839,
    ExposureEvolution.Compact40Pratt.prime_26739227]

def block39 : Witness := ⟨⟨26822041, 26925720, 5189, 5197, 5209, 26821643, 26821961, 26822027⟩, 8⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5189,
    ExposureEvolution.Compact40Pratt.prime_5197,
    ExposureEvolution.Compact40Pratt.prime_5209,
    ExposureEvolution.Compact40Pratt.prime_26821643,
    ExposureEvolution.Compact40Pratt.prime_26821961,
    ExposureEvolution.Compact40Pratt.prime_26822027]

def block40 : Witness := ⟨⟨26925721, 27008808, 5197, 5209, 5227, 26925281, 26925293, 26925707⟩, 8⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5197,
    ExposureEvolution.Compact40Pratt.prime_5209,
    ExposureEvolution.Compact40Pratt.prime_5227,
    ExposureEvolution.Compact40Pratt.prime_26925281,
    ExposureEvolution.Compact40Pratt.prime_26925293,
    ExposureEvolution.Compact40Pratt.prime_26925707]

def block41 : Witness := ⟨⟨27008809, 27133680, 5209, 5227, 5231, 27008549, 27008593, 27008803⟩, 10⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5209,
    ExposureEvolution.Compact40Pratt.prime_5227,
    ExposureEvolution.Compact40Pratt.prime_5231,
    ExposureEvolution.Compact40Pratt.prime_27008549,
    ExposureEvolution.Compact40Pratt.prime_27008593,
    ExposureEvolution.Compact40Pratt.prime_27008803]

def block42 : Witness := ⟨⟨27133681, 27321528, 5227, 5231, 5233, 27133331, 27133417, 27133679⟩, 10⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5227,
    ExposureEvolution.Compact40Pratt.prime_5231,
    ExposureEvolution.Compact40Pratt.prime_5233,
    ExposureEvolution.Compact40Pratt.prime_27133331,
    ExposureEvolution.Compact40Pratt.prime_27133417,
    ExposureEvolution.Compact40Pratt.prime_27133679]

def block43 : Witness := ⟨⟨27321529, 27363360, 5231, 5233, 5237, 27321251, 27321403, 27321517⟩, 9⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5231,
    ExposureEvolution.Compact40Pratt.prime_5233,
    ExposureEvolution.Compact40Pratt.prime_5237,
    ExposureEvolution.Compact40Pratt.prime_27321251,
    ExposureEvolution.Compact40Pratt.prime_27321403,
    ExposureEvolution.Compact40Pratt.prime_27321517]

def block44 : Witness := ⟨⟨27363361, 27384288, 5233, 5237, 5261, 27363121, 27363131, 27363341⟩, 7⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5233,
    ExposureEvolution.Compact40Pratt.prime_5237,
    ExposureEvolution.Compact40Pratt.prime_5261,
    ExposureEvolution.Compact40Pratt.prime_27363121,
    ExposureEvolution.Compact40Pratt.prime_27363131,
    ExposureEvolution.Compact40Pratt.prime_27363341]

def block45 : Witness := ⟨⟨27384289, 27426168, 5237, 5261, 5273, 27384113, 27384157, 27384277⟩, 11⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5237,
    ExposureEvolution.Compact40Pratt.prime_5261,
    ExposureEvolution.Compact40Pratt.prime_5273,
    ExposureEvolution.Compact40Pratt.prime_27384113,
    ExposureEvolution.Compact40Pratt.prime_27384157,
    ExposureEvolution.Compact40Pratt.prime_27384277]

def block46 : Witness := ⟨⟨27426169, 27678120, 5261, 5273, 5279, 27425869, 27426127, 27426137⟩, 10⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5261,
    ExposureEvolution.Compact40Pratt.prime_5273,
    ExposureEvolution.Compact40Pratt.prime_5279,
    ExposureEvolution.Compact40Pratt.prime_27425869,
    ExposureEvolution.Compact40Pratt.prime_27426127,
    ExposureEvolution.Compact40Pratt.prime_27426137]

def block47 : Witness := ⟨⟨27678121, 27804528, 5273, 5279, 5281, 27677807, 27677833, 27678103⟩, 10⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5273,
    ExposureEvolution.Compact40Pratt.prime_5279,
    ExposureEvolution.Compact40Pratt.prime_5281,
    ExposureEvolution.Compact40Pratt.prime_27677807,
    ExposureEvolution.Compact40Pratt.prime_27677833,
    ExposureEvolution.Compact40Pratt.prime_27678103]

def block48 : Witness := ⟨⟨27804529, 27867840, 5279, 5281, 5297, 27804019, 27804319, 27804509⟩, 8⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5279,
    ExposureEvolution.Compact40Pratt.prime_5281,
    ExposureEvolution.Compact40Pratt.prime_5297,
    ExposureEvolution.Compact40Pratt.prime_27804019,
    ExposureEvolution.Compact40Pratt.prime_27804319,
    ExposureEvolution.Compact40Pratt.prime_27804509]

def block49 : Witness := ⟨⟨27867841, 27888960, 5281, 5297, 5303, 27867493, 27867683, 27867839⟩, 9⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5281,
    ExposureEvolution.Compact40Pratt.prime_5297,
    ExposureEvolution.Compact40Pratt.prime_5303,
    ExposureEvolution.Compact40Pratt.prime_27867493,
    ExposureEvolution.Compact40Pratt.prime_27867683,
    ExposureEvolution.Compact40Pratt.prime_27867839]

def block50 : Witness := ⟨⟨27888961, 28058208, 5297, 5303, 5309, 27888677, 27888703, 27888947⟩, 8⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5297,
    ExposureEvolution.Compact40Pratt.prime_5303,
    ExposureEvolution.Compact40Pratt.prime_5309,
    ExposureEvolution.Compact40Pratt.prime_27888677,
    ExposureEvolution.Compact40Pratt.prime_27888703,
    ExposureEvolution.Compact40Pratt.prime_27888947]

def block51 : Witness := ⟨⟨28058209, 28121808, 5303, 5309, 5323, 28058087, 28058159, 28058189⟩, 9⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5303,
    ExposureEvolution.Compact40Pratt.prime_5309,
    ExposureEvolution.Compact40Pratt.prime_5323,
    ExposureEvolution.Compact40Pratt.prime_28058087,
    ExposureEvolution.Compact40Pratt.prime_28058159,
    ExposureEvolution.Compact40Pratt.prime_28058189]

def block52 : Witness := ⟨⟨28121809, 28185480, 5309, 5323, 5333, 28121389, 28121657, 28121803⟩, 9⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5309,
    ExposureEvolution.Compact40Pratt.prime_5323,
    ExposureEvolution.Compact40Pratt.prime_5333,
    ExposureEvolution.Compact40Pratt.prime_28121389,
    ExposureEvolution.Compact40Pratt.prime_28121657,
    ExposureEvolution.Compact40Pratt.prime_28121803]

def block53 : Witness := ⟨⟨28185481, 28334328, 5323, 5333, 5347, 28185211, 28185271, 28185467⟩, 9⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5323,
    ExposureEvolution.Compact40Pratt.prime_5333,
    ExposureEvolution.Compact40Pratt.prime_5347,
    ExposureEvolution.Compact40Pratt.prime_28185211,
    ExposureEvolution.Compact40Pratt.prime_28185271,
    ExposureEvolution.Compact40Pratt.prime_28185467]

def block54 : Witness := ⟨⟨28334329, 28440888, 5333, 5347, 5351, 28333939, 28334269, 28334311⟩, 10⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5333,
    ExposureEvolution.Compact40Pratt.prime_5347,
    ExposureEvolution.Compact40Pratt.prime_5351,
    ExposureEvolution.Compact40Pratt.prime_28333939,
    ExposureEvolution.Compact40Pratt.prime_28334269,
    ExposureEvolution.Compact40Pratt.prime_28334311]

def block55 : Witness := ⟨⟨28440889, 28590408, 5347, 5351, 5381, 28440611, 28440743, 28440887⟩, 8⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5347,
    ExposureEvolution.Compact40Pratt.prime_5351,
    ExposureEvolution.Compact40Pratt.prime_5381,
    ExposureEvolution.Compact40Pratt.prime_28440611,
    ExposureEvolution.Compact40Pratt.prime_28440743,
    ExposureEvolution.Compact40Pratt.prime_28440887]

def block56 : Witness := ⟨⟨28590409, 28633200, 5351, 5381, 5387, 28589917, 28590031, 28590391⟩, 9⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5351,
    ExposureEvolution.Compact40Pratt.prime_5381,
    ExposureEvolution.Compact40Pratt.prime_5387,
    ExposureEvolution.Compact40Pratt.prime_28589917,
    ExposureEvolution.Compact40Pratt.prime_28590031,
    ExposureEvolution.Compact40Pratt.prime_28590391]

def block57 : Witness := ⟨⟨28633201, 28955160, 5381, 5387, 5393, 28632707, 28633127, 28633147⟩, 10⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5381,
    ExposureEvolution.Compact40Pratt.prime_5387,
    ExposureEvolution.Compact40Pratt.prime_5393,
    ExposureEvolution.Compact40Pratt.prime_28632707,
    ExposureEvolution.Compact40Pratt.prime_28633127,
    ExposureEvolution.Compact40Pratt.prime_28633147]

def block58 : Witness := ⟨⟨28955161, 29019768, 5387, 5393, 5399, 28954967, 28955009, 28955141⟩, 8⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5387,
    ExposureEvolution.Compact40Pratt.prime_5393,
    ExposureEvolution.Compact40Pratt.prime_5399,
    ExposureEvolution.Compact40Pratt.prime_28954967,
    ExposureEvolution.Compact40Pratt.prime_28955009,
    ExposureEvolution.Compact40Pratt.prime_28955141]

def block59 : Witness := ⟨⟨29019769, 29084448, 5393, 5399, 5407, 29019311, 29019647, 29019761⟩, 8⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5393,
    ExposureEvolution.Compact40Pratt.prime_5399,
    ExposureEvolution.Compact40Pratt.prime_5407,
    ExposureEvolution.Compact40Pratt.prime_29019311,
    ExposureEvolution.Compact40Pratt.prime_29019647,
    ExposureEvolution.Compact40Pratt.prime_29019761]

def block60 : Witness := ⟨⟨29084449, 29149200, 5399, 5407, 5413, 29084249, 29084423, 29084431⟩, 8⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5399,
    ExposureEvolution.Compact40Pratt.prime_5407,
    ExposureEvolution.Compact40Pratt.prime_5413,
    ExposureEvolution.Compact40Pratt.prime_29084249,
    ExposureEvolution.Compact40Pratt.prime_29084423,
    ExposureEvolution.Compact40Pratt.prime_29084431]

def block61 : Witness := ⟨⟨29149201, 29235648, 5407, 5413, 5417, 29148929, 29149189, 29149199⟩, 8⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5407,
    ExposureEvolution.Compact40Pratt.prime_5413,
    ExposureEvolution.Compact40Pratt.prime_5417,
    ExposureEvolution.Compact40Pratt.prime_29148929,
    ExposureEvolution.Compact40Pratt.prime_29149189,
    ExposureEvolution.Compact40Pratt.prime_29149199]

def block62 : Witness := ⟨⟨29235649, 29300568, 5413, 5417, 5419, 29235203, 29235497, 29235637⟩, 8⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5413,
    ExposureEvolution.Compact40Pratt.prime_5417,
    ExposureEvolution.Compact40Pratt.prime_5419,
    ExposureEvolution.Compact40Pratt.prime_29235203,
    ExposureEvolution.Compact40Pratt.prime_29235497,
    ExposureEvolution.Compact40Pratt.prime_29235637]

def block63 : Witness := ⟨⟨29300569, 29343888, 5417, 5419, 5431, 29300087, 29300543, 29300563⟩, 11⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5417,
    ExposureEvolution.Compact40Pratt.prime_5419,
    ExposureEvolution.Compact40Pratt.prime_5431,
    ExposureEvolution.Compact40Pratt.prime_29300087,
    ExposureEvolution.Compact40Pratt.prime_29300543,
    ExposureEvolution.Compact40Pratt.prime_29300563]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 29343889 stop tail = true) :
    coverage 23629321 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_005
