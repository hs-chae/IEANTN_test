import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks14
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨20675209, 20693400, 4549, 4561, 4567, 20674867, 20675023, 20675203⟩, 7⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4549,
    ExposureEvolution.KernelPratt.prime_4561,
    ExposureEvolution.KernelPratt.prime_4567,
    ExposureEvolution.KernelPratt.prime_20674867,
    ExposureEvolution.KernelPratt.prime_20675023,
    ExposureEvolution.KernelPratt.prime_20675203]

def block01 : Witness := ⟨⟨20693401, 20802720, 4561, 4567, 4583, 20693087, 20693357, 20693389⟩, 12⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4561,
    ExposureEvolution.KernelPratt.prime_4567,
    ExposureEvolution.KernelPratt.prime_4583,
    ExposureEvolution.KernelPratt.prime_20693087,
    ExposureEvolution.KernelPratt.prime_20693357,
    ExposureEvolution.KernelPratt.prime_20693389]

def block02 : Witness := ⟨⟨20802721, 20857488, 4567, 4583, 4591, 20802371, 20802559, 20802709⟩, 8⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4567,
    ExposureEvolution.KernelPratt.prime_4583,
    ExposureEvolution.KernelPratt.prime_4591,
    ExposureEvolution.KernelPratt.prime_20802371,
    ExposureEvolution.KernelPratt.prime_20802559,
    ExposureEvolution.KernelPratt.prime_20802709]

def block03 : Witness := ⟨⟨20857489, 21003888, 4583, 4591, 4597, 20856947, 20857247, 20857483⟩, 10⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4583,
    ExposureEvolution.KernelPratt.prime_4591,
    ExposureEvolution.KernelPratt.prime_4597,
    ExposureEvolution.KernelPratt.prime_20856947,
    ExposureEvolution.KernelPratt.prime_20857247,
    ExposureEvolution.KernelPratt.prime_20857483]

def block04 : Witness := ⟨⟨21003889, 21077280, 4591, 4597, 4603, 21003713, 21003751, 21003887⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4591,
    ExposureEvolution.KernelPratt.prime_4597,
    ExposureEvolution.KernelPratt.prime_4603,
    ExposureEvolution.KernelPratt.prime_21003713,
    ExposureEvolution.KernelPratt.prime_21003751,
    ExposureEvolution.KernelPratt.prime_21003887]

def block05 : Witness := ⟨⟨21077281, 21132408, 4597, 4603, 4621, 21076667, 21077051, 21077257⟩, 7⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4597,
    ExposureEvolution.KernelPratt.prime_4603,
    ExposureEvolution.KernelPratt.prime_4621,
    ExposureEvolution.KernelPratt.prime_21076667,
    ExposureEvolution.KernelPratt.prime_21077051,
    ExposureEvolution.KernelPratt.prime_21077257]

def block06 : Witness := ⟨⟨21132409, 21187608, 4603, 4621, 4637, 21132211, 21132229, 21132383⟩, 12⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4603,
    ExposureEvolution.KernelPratt.prime_4621,
    ExposureEvolution.KernelPratt.prime_4637,
    ExposureEvolution.KernelPratt.prime_21132211,
    ExposureEvolution.KernelPratt.prime_21132229,
    ExposureEvolution.KernelPratt.prime_21132383]

def block07 : Witness := ⟨⟨21187609, 21353640, 4621, 4637, 4639, 21187193, 21187241, 21187597⟩, 7⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4621,
    ExposureEvolution.KernelPratt.prime_4637,
    ExposureEvolution.KernelPratt.prime_4639,
    ExposureEvolution.KernelPratt.prime_21187193,
    ExposureEvolution.KernelPratt.prime_21187241,
    ExposureEvolution.KernelPratt.prime_21187597]

def block08 : Witness := ⟨⟨21353641, 21501768, 4637, 4639, 4643, 21353443, 21353461, 21353639⟩, 5⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4637,
    ExposureEvolution.KernelPratt.prime_4639,
    ExposureEvolution.KernelPratt.prime_4643,
    ExposureEvolution.KernelPratt.prime_21353443,
    ExposureEvolution.KernelPratt.prime_21353461,
    ExposureEvolution.KernelPratt.prime_21353639]

def block09 : Witness := ⟨⟨21501769, 21520320, 4639, 4643, 4649, 21501287, 21501553, 21501737⟩, 11⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4639,
    ExposureEvolution.KernelPratt.prime_4643,
    ExposureEvolution.KernelPratt.prime_4649,
    ExposureEvolution.KernelPratt.prime_21501287,
    ExposureEvolution.KernelPratt.prime_21501553,
    ExposureEvolution.KernelPratt.prime_21501737]

def block10 : Witness := ⟨⟨21520321, 21557448, 4643, 4649, 4651, 21520151, 21520241, 21520307⟩, 11⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4643,
    ExposureEvolution.KernelPratt.prime_4649,
    ExposureEvolution.KernelPratt.prime_4651,
    ExposureEvolution.KernelPratt.prime_21520151,
    ExposureEvolution.KernelPratt.prime_21520241,
    ExposureEvolution.KernelPratt.prime_21520307]

def block11 : Witness := ⟨⟨21557449, 21613200, 4649, 4651, 4657, 21556943, 21556999, 21557447⟩, 11⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4649,
    ExposureEvolution.KernelPratt.prime_4651,
    ExposureEvolution.KernelPratt.prime_4657,
    ExposureEvolution.KernelPratt.prime_21556943,
    ExposureEvolution.KernelPratt.prime_21556999,
    ExposureEvolution.KernelPratt.prime_21557447]

def block12 : Witness := ⟨⟨21613201, 21631800, 4651, 4657, 4663, 21612991, 21613153, 21613199⟩, 7⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4651,
    ExposureEvolution.KernelPratt.prime_4657,
    ExposureEvolution.KernelPratt.prime_4663,
    ExposureEvolution.KernelPratt.prime_21612991,
    ExposureEvolution.KernelPratt.prime_21613153,
    ExposureEvolution.KernelPratt.prime_21613199]

def block13 : Witness := ⟨⟨21631801, 21687648, 4657, 4663, 4673, 21631471, 21631483, 21631777⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4657,
    ExposureEvolution.KernelPratt.prime_4663,
    ExposureEvolution.KernelPratt.prime_4673,
    ExposureEvolution.KernelPratt.prime_21631471,
    ExposureEvolution.KernelPratt.prime_21631483,
    ExposureEvolution.KernelPratt.prime_21631777]

def block14 : Witness := ⟨⟨21687649, 21743568, 4663, 4673, 4679, 21687203, 21687541, 21687641⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4663,
    ExposureEvolution.KernelPratt.prime_4673,
    ExposureEvolution.KernelPratt.prime_4679,
    ExposureEvolution.KernelPratt.prime_21687203,
    ExposureEvolution.KernelPratt.prime_21687541,
    ExposureEvolution.KernelPratt.prime_21687641]

def block15 : Witness := ⟨⟨21743569, 21836928, 4673, 4679, 4691, 21743081, 21743107, 21743551⟩, 10⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4673,
    ExposureEvolution.KernelPratt.prime_4679,
    ExposureEvolution.KernelPratt.prime_4691,
    ExposureEvolution.KernelPratt.prime_21743081,
    ExposureEvolution.KernelPratt.prime_21743107,
    ExposureEvolution.KernelPratt.prime_21743551]

def block16 : Witness := ⟨⟨21836929, 21893040, 4679, 4691, 4703, 21836531, 21836861, 21836921⟩, 9⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4679,
    ExposureEvolution.KernelPratt.prime_4691,
    ExposureEvolution.KernelPratt.prime_4703,
    ExposureEvolution.KernelPratt.prime_21836531,
    ExposureEvolution.KernelPratt.prime_21836861,
    ExposureEvolution.KernelPratt.prime_21836921]

def block17 : Witness := ⟨⟨21893041, 22005480, 4691, 4703, 4721, 21892873, 21892901, 21893009⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4691,
    ExposureEvolution.KernelPratt.prime_4703,
    ExposureEvolution.KernelPratt.prime_4721,
    ExposureEvolution.KernelPratt.prime_21892873,
    ExposureEvolution.KernelPratt.prime_21892901,
    ExposureEvolution.KernelPratt.prime_21893009]

def block18 : Witness := ⟨⟨22005481, 22118208, 4703, 4721, 4723, 22005107, 22005131, 22005449⟩, 6⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4703,
    ExposureEvolution.KernelPratt.prime_4721,
    ExposureEvolution.KernelPratt.prime_4723,
    ExposureEvolution.KernelPratt.prime_22005107,
    ExposureEvolution.KernelPratt.prime_22005131,
    ExposureEvolution.KernelPratt.prime_22005449]

def block19 : Witness := ⟨⟨22118209, 22287840, 4721, 4723, 4729, 22117891, 22118113, 22118179⟩, 12⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4721,
    ExposureEvolution.KernelPratt.prime_4723,
    ExposureEvolution.KernelPratt.prime_4729,
    ExposureEvolution.KernelPratt.prime_22117891,
    ExposureEvolution.KernelPratt.prime_22118113,
    ExposureEvolution.KernelPratt.prime_22118179]

def block20 : Witness := ⟨⟨22287841, 22306728, 4723, 4729, 4733, 22287739, 22287821, 22287829⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4723,
    ExposureEvolution.KernelPratt.prime_4729,
    ExposureEvolution.KernelPratt.prime_4733,
    ExposureEvolution.KernelPratt.prime_22287739,
    ExposureEvolution.KernelPratt.prime_22287821,
    ExposureEvolution.KernelPratt.prime_22287829]

def block21 : Witness := ⟨⟨22306729, 22363440, 4729, 4733, 4751, 22306517, 22306657, 22306727⟩, 8⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4729,
    ExposureEvolution.KernelPratt.prime_4733,
    ExposureEvolution.KernelPratt.prime_4751,
    ExposureEvolution.KernelPratt.prime_22306517,
    ExposureEvolution.KernelPratt.prime_22306657,
    ExposureEvolution.KernelPratt.prime_22306727]

def block22 : Witness := ⟨⟨22363441, 22401288, 4733, 4751, 4759, 22362953, 22363213, 22363433⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4733,
    ExposureEvolution.KernelPratt.prime_4751,
    ExposureEvolution.KernelPratt.prime_4759,
    ExposureEvolution.KernelPratt.prime_22362953,
    ExposureEvolution.KernelPratt.prime_22363213,
    ExposureEvolution.KernelPratt.prime_22363433]

def block23 : Witness := ⟨⟨22401289, 22572000, 4751, 4759, 4783, 22401017, 22401221, 22401259⟩, 7⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4751,
    ExposureEvolution.KernelPratt.prime_4759,
    ExposureEvolution.KernelPratt.prime_4783,
    ExposureEvolution.KernelPratt.prime_22401017,
    ExposureEvolution.KernelPratt.prime_22401221,
    ExposureEvolution.KernelPratt.prime_22401259]

def block24 : Witness := ⟨⟨22572001, 22648080, 4759, 4783, 4787, 22571821, 22571833, 22571987⟩, 11⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4759,
    ExposureEvolution.KernelPratt.prime_4783,
    ExposureEvolution.KernelPratt.prime_4787,
    ExposureEvolution.KernelPratt.prime_22571821,
    ExposureEvolution.KernelPratt.prime_22571833,
    ExposureEvolution.KernelPratt.prime_22571987]

def block25 : Witness := ⟨⟨22648081, 22877088, 4783, 4787, 4789, 22647733, 22647769, 22648051⟩, 6⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4783,
    ExposureEvolution.KernelPratt.prime_4787,
    ExposureEvolution.KernelPratt.prime_4789,
    ExposureEvolution.KernelPratt.prime_22647733,
    ExposureEvolution.KernelPratt.prime_22647769,
    ExposureEvolution.KernelPratt.prime_22648051]

def block26 : Witness := ⟨⟨22877089, 22915368, 4787, 4789, 4793, 22876787, 22876979, 22877081⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4787,
    ExposureEvolution.KernelPratt.prime_4789,
    ExposureEvolution.KernelPratt.prime_4793,
    ExposureEvolution.KernelPratt.prime_22876787,
    ExposureEvolution.KernelPratt.prime_22876979,
    ExposureEvolution.KernelPratt.prime_22877081]

def block27 : Witness := ⟨⟨22915369, 22934520, 4789, 4793, 4799, 22914971, 22915297, 22915363⟩, 9⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4789,
    ExposureEvolution.KernelPratt.prime_4793,
    ExposureEvolution.KernelPratt.prime_4799,
    ExposureEvolution.KernelPratt.prime_22914971,
    ExposureEvolution.KernelPratt.prime_22915297,
    ExposureEvolution.KernelPratt.prime_22915363]

def block28 : Witness := ⟨⟨22934521, 22972848, 4793, 4799, 4801, 22934029, 22934251, 22934503⟩, 11⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4793,
    ExposureEvolution.KernelPratt.prime_4799,
    ExposureEvolution.KernelPratt.prime_4801,
    ExposureEvolution.KernelPratt.prime_22934029,
    ExposureEvolution.KernelPratt.prime_22934251,
    ExposureEvolution.KernelPratt.prime_22934503]

def block29 : Witness := ⟨⟨22972849, 23030400, 4799, 4801, 4813, 22972283, 22972777, 22972847⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4799,
    ExposureEvolution.KernelPratt.prime_4801,
    ExposureEvolution.KernelPratt.prime_4813,
    ExposureEvolution.KernelPratt.prime_22972283,
    ExposureEvolution.KernelPratt.prime_22972777,
    ExposureEvolution.KernelPratt.prime_22972847]

def block30 : Witness := ⟨⟨23030401, 23049600, 4801, 4813, 4817, 23030081, 23030377, 23030389⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4801,
    ExposureEvolution.KernelPratt.prime_4813,
    ExposureEvolution.KernelPratt.prime_4817,
    ExposureEvolution.KernelPratt.prime_23030081,
    ExposureEvolution.KernelPratt.prime_23030377,
    ExposureEvolution.KernelPratt.prime_23030389]

def block31 : Witness := ⟨⟨23049601, 23164968, 4813, 4817, 4831, 23049137, 23049157, 23049571⟩, 13⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4813,
    ExposureEvolution.KernelPratt.prime_4817,
    ExposureEvolution.KernelPratt.prime_4831,
    ExposureEvolution.KernelPratt.prime_23049137,
    ExposureEvolution.KernelPratt.prime_23049157,
    ExposureEvolution.KernelPratt.prime_23049571]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 23164969 stop tail = true) :
    coverage 20675209 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks14
