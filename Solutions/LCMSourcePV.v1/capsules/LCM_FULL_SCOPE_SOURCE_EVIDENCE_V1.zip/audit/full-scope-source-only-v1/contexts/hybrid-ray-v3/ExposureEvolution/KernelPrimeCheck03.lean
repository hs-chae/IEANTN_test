import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelPrimeCheck03
open ExposureEvolution KernelPrimeProgram
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def primes : List ℕ := [15823, 15881, 15937, 15991, 16033, 16091, 16141, 16193, 16253, 16301, 16363, 16421, 16481, 16529, 16573, 16633, 16693, 16747, 16811, 16871, 16931, 16993, 17053, 17117, 17183, 17239, 17299, 17359, 17419, 17483, 17551, 17609, 17669, 17737, 17791, 17851, 17911, 17977, 18047, 18097, 18149, 18217, 18287, 18353, 18413, 18481, 18553, 18617, 18679, 18749, 18803, 18869, 18919, 18979, 19051, 19121, 19183, 19249, 19319, 19391, 19463, 19531, 19603, 19661]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 19661 stop tail = true) :
    check 15797 stop (primes ++ tail) = true := by
  change check _ _ (15823 :: 15881 :: 15937 :: 15991 :: 16033 :: 16091 :: 16141 :: 16193 :: 16253 :: 16301 :: 16363 :: 16421 :: 16481 :: 16529 :: 16573 :: 16633 :: 16693 :: 16747 :: 16811 :: 16871 :: 16931 :: 16993 :: 17053 :: 17117 :: 17183 :: 17239 :: 17299 :: 17359 :: 17419 :: 17483 :: 17551 :: 17609 :: 17669 :: 17737 :: 17791 :: 17851 :: 17911 :: 17977 :: 18047 :: 18097 :: 18149 :: 18217 :: 18287 :: 18353 :: 18413 :: 18481 :: 18553 :: 18617 :: 18679 :: 18749 :: 18803 :: 18869 :: 18919 :: 18979 :: 19051 :: 19121 :: 19183 :: 19249 :: 19319 :: 19391 :: 19463 :: 19531 :: 19603 :: 19661 :: tail) = true
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15823, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15881, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15937, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_15991, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16033, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16091, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16141, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16193, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16253, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16301, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16363, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16421, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16481, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16529, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16573, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16633, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16693, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16747, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16811, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16871, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16931, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_16993, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17053, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17117, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17183, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17239, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17299, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17359, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17419, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17483, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17551, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17609, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17669, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17737, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17791, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17851, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17911, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_17977, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18047, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18097, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18149, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18217, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18287, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18353, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18413, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18481, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18553, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18617, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18679, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18749, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18803, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18869, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18919, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_18979, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19051, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19121, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19183, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19249, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19319, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19391, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19463, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19531, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19603, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_19661, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms extend
end ExposureEvolution.KernelPrimeCheck03
