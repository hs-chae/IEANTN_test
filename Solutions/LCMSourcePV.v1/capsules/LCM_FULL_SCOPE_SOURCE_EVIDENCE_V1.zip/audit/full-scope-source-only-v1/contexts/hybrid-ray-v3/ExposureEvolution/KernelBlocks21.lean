import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks21
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨41899729, 42003360, 6481, 6491, 6521, 41899523, 41899703, 41899717⟩, 13⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6481,
    ExposureEvolution.KernelPratt.prime_6491,
    ExposureEvolution.KernelPratt.prime_6521,
    ExposureEvolution.KernelPratt.prime_41899523,
    ExposureEvolution.KernelPratt.prime_41899703,
    ExposureEvolution.KernelPratt.prime_41899717]

def block01 : Witness := ⟨⟨42003361, 42133080, 6491, 6521, 6529, 42002839, 42003317, 42003337⟩, 6⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6491,
    ExposureEvolution.KernelPratt.prime_6521,
    ExposureEvolution.KernelPratt.prime_6529,
    ExposureEvolution.KernelPratt.prime_42002839,
    ExposureEvolution.KernelPratt.prime_42003317,
    ExposureEvolution.KernelPratt.prime_42003337]

def block02 : Witness := ⟨⟨42133081, 42523440, 6521, 6529, 6547, 42132719, 42132763, 42133073⟩, 12⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6521,
    ExposureEvolution.KernelPratt.prime_6529,
    ExposureEvolution.KernelPratt.prime_6547,
    ExposureEvolution.KernelPratt.prime_42132719,
    ExposureEvolution.KernelPratt.prime_42132763,
    ExposureEvolution.KernelPratt.prime_42133073]

def block03 : Witness := ⟨⟨42523441, 42627840, 6529, 6547, 6551, 42523177, 42523381, 42523433⟩, 10⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6529,
    ExposureEvolution.KernelPratt.prime_6547,
    ExposureEvolution.KernelPratt.prime_6551,
    ExposureEvolution.KernelPratt.prime_42523177,
    ExposureEvolution.KernelPratt.prime_42523381,
    ExposureEvolution.KernelPratt.prime_42523433]

def block04 : Witness := ⟨⟨42627841, 42863208, 6547, 6551, 6553, 42627391, 42627713, 42627833⟩, 9⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6547,
    ExposureEvolution.KernelPratt.prime_6551,
    ExposureEvolution.KernelPratt.prime_6553,
    ExposureEvolution.KernelPratt.prime_42627391,
    ExposureEvolution.KernelPratt.prime_42627713,
    ExposureEvolution.KernelPratt.prime_42627833]

def block05 : Witness := ⟨⟨42863209, 42915600, 6551, 6553, 6563, 42863059, 42863123, 42863203⟩, 7⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6551,
    ExposureEvolution.KernelPratt.prime_6553,
    ExposureEvolution.KernelPratt.prime_6563,
    ExposureEvolution.KernelPratt.prime_42863059,
    ExposureEvolution.KernelPratt.prime_42863123,
    ExposureEvolution.KernelPratt.prime_42863203]

def block06 : Witness := ⟨⟨42915601, 42941808, 6553, 6563, 6569, 42915083, 42915209, 42915581⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6553,
    ExposureEvolution.KernelPratt.prime_6563,
    ExposureEvolution.KernelPratt.prime_6569,
    ExposureEvolution.KernelPratt.prime_42915083,
    ExposureEvolution.KernelPratt.prime_42915209,
    ExposureEvolution.KernelPratt.prime_42915581]

def block07 : Witness := ⟨⟨42941809, 43072968, 6563, 6569, 6571, 42941527, 42941629, 42941797⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6563,
    ExposureEvolution.KernelPratt.prime_6569,
    ExposureEvolution.KernelPratt.prime_6571,
    ExposureEvolution.KernelPratt.prime_42941527,
    ExposureEvolution.KernelPratt.prime_42941629,
    ExposureEvolution.KernelPratt.prime_42941797]

def block08 : Witness := ⟨⟨43072969, 43151760, 6569, 6571, 6577, 43072573, 43072651, 43072961⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6569,
    ExposureEvolution.KernelPratt.prime_6571,
    ExposureEvolution.KernelPratt.prime_6577,
    ExposureEvolution.KernelPratt.prime_43072573,
    ExposureEvolution.KernelPratt.prime_43072651,
    ExposureEvolution.KernelPratt.prime_43072961]

def block09 : Witness := ⟨⟨43151761, 43178040, 6571, 6577, 6581, 43151099, 43151309, 43151743⟩, 9⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6571,
    ExposureEvolution.KernelPratt.prime_6577,
    ExposureEvolution.KernelPratt.prime_6581,
    ExposureEvolution.KernelPratt.prime_43151099,
    ExposureEvolution.KernelPratt.prime_43151309,
    ExposureEvolution.KernelPratt.prime_43151743]

def block10 : Witness := ⟨⟨43178041, 43256928, 6577, 6581, 6599, 43177583, 43177609, 43178039⟩, 9⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6577,
    ExposureEvolution.KernelPratt.prime_6581,
    ExposureEvolution.KernelPratt.prime_6599,
    ExposureEvolution.KernelPratt.prime_43177583,
    ExposureEvolution.KernelPratt.prime_43177609,
    ExposureEvolution.KernelPratt.prime_43178039]

def block11 : Witness := ⟨⟨43256929, 43309560, 6581, 6599, 6607, 43256693, 43256761, 43256911⟩, 7⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6581,
    ExposureEvolution.KernelPratt.prime_6599,
    ExposureEvolution.KernelPratt.prime_6607,
    ExposureEvolution.KernelPratt.prime_43256693,
    ExposureEvolution.KernelPratt.prime_43256761,
    ExposureEvolution.KernelPratt.prime_43256911]

def block12 : Witness := ⟨⟨43309561, 43546800, 6599, 6607, 6619, 43309157, 43309289, 43309547⟩, 10⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6599,
    ExposureEvolution.KernelPratt.prime_6607,
    ExposureEvolution.KernelPratt.prime_6619,
    ExposureEvolution.KernelPratt.prime_43309157,
    ExposureEvolution.KernelPratt.prime_43309289,
    ExposureEvolution.KernelPratt.prime_43309547]

def block13 : Witness := ⟨⟨43546801, 43652448, 6607, 6619, 6637, 43546681, 43546687, 43546799⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6607,
    ExposureEvolution.KernelPratt.prime_6619,
    ExposureEvolution.KernelPratt.prime_6637,
    ExposureEvolution.KernelPratt.prime_43546681,
    ExposureEvolution.KernelPratt.prime_43546687,
    ExposureEvolution.KernelPratt.prime_43546799]

def block14 : Witness := ⟨⟨43652449, 43811160, 6619, 6637, 6653, 43651961, 43651981, 43652419⟩, 13⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6619,
    ExposureEvolution.KernelPratt.prime_6637,
    ExposureEvolution.KernelPratt.prime_6653,
    ExposureEvolution.KernelPratt.prime_43651961,
    ExposureEvolution.KernelPratt.prime_43651981,
    ExposureEvolution.KernelPratt.prime_43652419]

def block15 : Witness := ⟨⟨43811161, 44049768, 6637, 6653, 6659, 43810603, 43810609, 43811147⟩, 6⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6637,
    ExposureEvolution.KernelPratt.prime_6653,
    ExposureEvolution.KernelPratt.prime_6659,
    ExposureEvolution.KernelPratt.prime_43810603,
    ExposureEvolution.KernelPratt.prime_43810609,
    ExposureEvolution.KernelPratt.prime_43811147]

def block16 : Witness := ⟨⟨44049769, 44262408, 6653, 6659, 6661, 44049613, 44049661, 44049767⟩, 7⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6653,
    ExposureEvolution.KernelPratt.prime_6659,
    ExposureEvolution.KernelPratt.prime_6661,
    ExposureEvolution.KernelPratt.prime_44049613,
    ExposureEvolution.KernelPratt.prime_44049661,
    ExposureEvolution.KernelPratt.prime_44049767]

def block17 : Witness := ⟨⟨44262409, 44342280, 6659, 6661, 6673, 44262137, 44262193, 44262377⟩, 9⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6659,
    ExposureEvolution.KernelPratt.prime_6661,
    ExposureEvolution.KernelPratt.prime_6673,
    ExposureEvolution.KernelPratt.prime_44262137,
    ExposureEvolution.KernelPratt.prime_44262193,
    ExposureEvolution.KernelPratt.prime_44262377]

def block18 : Witness := ⟨⟨44342281, 44368920, 6661, 6673, 6679, 44342083, 44342107, 44342261⟩, 8⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6661,
    ExposureEvolution.KernelPratt.prime_6673,
    ExposureEvolution.KernelPratt.prime_6679,
    ExposureEvolution.KernelPratt.prime_44342083,
    ExposureEvolution.KernelPratt.prime_44342107,
    ExposureEvolution.KernelPratt.prime_44342261]

def block19 : Witness := ⟨⟨44368921, 44528928, 6673, 6679, 6689, 44368573, 44368631, 44368879⟩, 10⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6673,
    ExposureEvolution.KernelPratt.prime_6679,
    ExposureEvolution.KernelPratt.prime_6689,
    ExposureEvolution.KernelPratt.prime_44368573,
    ExposureEvolution.KernelPratt.prime_44368631,
    ExposureEvolution.KernelPratt.prime_44368879]

def block20 : Witness := ⟨⟨44528929, 44609040, 6679, 6689, 6691, 44528633, 44528773, 44528921⟩, 10⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6679,
    ExposureEvolution.KernelPratt.prime_6689,
    ExposureEvolution.KernelPratt.prime_6691,
    ExposureEvolution.KernelPratt.prime_44528633,
    ExposureEvolution.KernelPratt.prime_44528773,
    ExposureEvolution.KernelPratt.prime_44528921]

def block21 : Witness := ⟨⟨44609041, 44742720, 6689, 6691, 6701, 44608787, 44608997, 44609023⟩, 6⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6689,
    ExposureEvolution.KernelPratt.prime_6691,
    ExposureEvolution.KernelPratt.prime_6701,
    ExposureEvolution.KernelPratt.prime_44608787,
    ExposureEvolution.KernelPratt.prime_44608997,
    ExposureEvolution.KernelPratt.prime_44609023]

def block22 : Witness := ⟨⟨44742721, 44769480, 6691, 6701, 6703, 44742101, 44742277, 44742713⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6691,
    ExposureEvolution.KernelPratt.prime_6701,
    ExposureEvolution.KernelPratt.prime_6703,
    ExposureEvolution.KernelPratt.prime_44742101,
    ExposureEvolution.KernelPratt.prime_44742277,
    ExposureEvolution.KernelPratt.prime_44742713]

def block23 : Witness := ⟨⟨44769481, 44903400, 6701, 6703, 6709, 44769013, 44769391, 44769479⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6701,
    ExposureEvolution.KernelPratt.prime_6703,
    ExposureEvolution.KernelPratt.prime_6709,
    ExposureEvolution.KernelPratt.prime_44769013,
    ExposureEvolution.KernelPratt.prime_44769391,
    ExposureEvolution.KernelPratt.prime_44769479]

def block24 : Witness := ⟨⟨44903401, 44930208, 6703, 6709, 6719, 44902937, 44902943, 44903393⟩, 7⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6703,
    ExposureEvolution.KernelPratt.prime_6709,
    ExposureEvolution.KernelPratt.prime_6719,
    ExposureEvolution.KernelPratt.prime_44902937,
    ExposureEvolution.KernelPratt.prime_44902943,
    ExposureEvolution.KernelPratt.prime_44903393]

def block25 : Witness := ⟨⟨44930209, 45010680, 6709, 6719, 6733, 44930143, 44930189, 44930203⟩, 7⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6709,
    ExposureEvolution.KernelPratt.prime_6719,
    ExposureEvolution.KernelPratt.prime_6733,
    ExposureEvolution.KernelPratt.prime_44930143,
    ExposureEvolution.KernelPratt.prime_44930189,
    ExposureEvolution.KernelPratt.prime_44930203]

def block26 : Witness := ⟨⟨45010681, 45144960, 6719, 6733, 6737, 45010393, 45010477, 45010649⟩, 11⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6719,
    ExposureEvolution.KernelPratt.prime_6733,
    ExposureEvolution.KernelPratt.prime_6737,
    ExposureEvolution.KernelPratt.prime_45010393,
    ExposureEvolution.KernelPratt.prime_45010477,
    ExposureEvolution.KernelPratt.prime_45010649]

def block27 : Witness := ⟨⟨45144961, 45333288, 6733, 6737, 6761, 45144821, 45144901, 45144947⟩, 7⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6733,
    ExposureEvolution.KernelPratt.prime_6737,
    ExposureEvolution.KernelPratt.prime_6761,
    ExposureEvolution.KernelPratt.prime_45144821,
    ExposureEvolution.KernelPratt.prime_45144901,
    ExposureEvolution.KernelPratt.prime_45144947]

def block28 : Witness := ⟨⟨45333289, 45387168, 6737, 6761, 6763, 45333019, 45333089, 45333283⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6737,
    ExposureEvolution.KernelPratt.prime_6761,
    ExposureEvolution.KernelPratt.prime_6763,
    ExposureEvolution.KernelPratt.prime_45333019,
    ExposureEvolution.KernelPratt.prime_45333089,
    ExposureEvolution.KernelPratt.prime_45333283]

def block29 : Witness := ⟨⟨45387169, 45711120, 6761, 6763, 6779, 45386851, 45386863, 45387151⟩, 11⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6761,
    ExposureEvolution.KernelPratt.prime_6763,
    ExposureEvolution.KernelPratt.prime_6779,
    ExposureEvolution.KernelPratt.prime_45386851,
    ExposureEvolution.KernelPratt.prime_45386863,
    ExposureEvolution.KernelPratt.prime_45387151]

def block30 : Witness := ⟨⟨45711121, 45738168, 6763, 6779, 6781, 45711037, 45711089, 45711109⟩, 7⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6763,
    ExposureEvolution.KernelPratt.prime_6779,
    ExposureEvolution.KernelPratt.prime_6781,
    ExposureEvolution.KernelPratt.prime_45711037,
    ExposureEvolution.KernelPratt.prime_45711089,
    ExposureEvolution.KernelPratt.prime_45711109]

def block31 : Witness := ⟨⟨45738169, 45954840, 6779, 6781, 6791, 45738103, 45738131, 45738167⟩, 8⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6779,
    ExposureEvolution.KernelPratt.prime_6781,
    ExposureEvolution.KernelPratt.prime_6791,
    ExposureEvolution.KernelPratt.prime_45738103,
    ExposureEvolution.KernelPratt.prime_45738131,
    ExposureEvolution.KernelPratt.prime_45738167]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 45954841 stop tail = true) :
    coverage 41899729 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks21
