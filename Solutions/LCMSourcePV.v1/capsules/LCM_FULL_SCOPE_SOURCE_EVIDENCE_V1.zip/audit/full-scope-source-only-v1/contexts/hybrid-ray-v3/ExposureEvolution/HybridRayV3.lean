import ExposureEvolution.KernelFinal
import ExposureEvolution.Dual60FinalV1
import ExposureEvolution.Analytic80V1
namespace ExposureEvolution.HybridRayV3
noncomputable def coefficient (n : ℕ) : ℝ :=
  if 5000000 ≤ n then if 1000000000000 ≤ n then 4/5 else 3/5 else 3/10
/-- A piecewise whole ray from existing proved branches, retaining each actual onset.
No optimality, global-best or experimental-treatment attribution is claimed. -/
theorem whole_ray (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 1000000 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1+coefficient n/(n:ℝ))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) < ArithmeticFunction.sigma 1 m := by
  by_cases h5 : 5000000 ≤ n
  · by_cases h8 : 1000000000000 ≤ n
    · obtain ⟨m,hm0,hm,hs⟩ := Analytic80V1.whole_ray hd n h8
      refine ⟨m,hm0,hm,?_⟩
      simpa only [coefficient,if_pos h5,if_pos h8] using hs
    · obtain ⟨m,hm0,hm,hs⟩ := Dual60FinalV1.whole_ray hd n h5
      refine ⟨m,hm0,hm,?_⟩
      simpa only [coefficient,if_pos h5,if_neg h8,div_div,show (5:ℝ)*(n:ℝ)=(5*(n:ℝ)) by ring] using hs
  · obtain ⟨m,hm0,hm,hs⟩ := KernelFinal.whole_ray hd n hn
    refine ⟨m,hm0,hm,?_⟩
    simpa only [coefficient,if_neg h5,div_div] using hs
#print axioms whole_ray
end ExposureEvolution.HybridRayV3
