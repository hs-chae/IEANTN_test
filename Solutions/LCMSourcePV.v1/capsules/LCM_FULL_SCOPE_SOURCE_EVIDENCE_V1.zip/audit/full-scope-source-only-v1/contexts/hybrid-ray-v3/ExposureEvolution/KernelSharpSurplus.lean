/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import ExposureEvolution.KernelSharpConstant
import E1Tertiary.LcmSurplus
namespace ExposureEvolution.KernelSharpSurplus
open Finset Nat Real E1Tertiary.LcmBase ExposureEvolution.KernelSharpConstant
set_option maxHeartbeats 2000000
/-- The fixed consumer budget retains a thirty-percent-of-1/n quantitative surplus. -/
theorem scalar_surplus {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (4096 ^ 2 : ℝ)) :
    (1 + 3 * ε / 10) * (1 + 3.024 * ε + 3.05 * ε^2 + 1.03 * ε^3) ≤
      1 + 3.325 * ε - 0.01 * ε^2 := by
  have h2 : ε^2 ≤ ε / 4096^2 := by nlinarith
  have h3 : ε^3 ≤ ε^2 / 4096^2 := by nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hε.2)]
  have h4 : ε^4 ≤ ε^2 / 4096^4 := by
    have := mul_le_mul_of_nonneg_right h3 hε.1
    nlinarith
  nlinarith [sq_nonneg ε]

/-- The same original product criterion, keeping its natural quantitative slack. -/
theorem comparison {c X₀ : ℝ} {n : ℕ} (hd : StrictGap X₀)
    (hc : 9 ≤ c) (hcX : c ≤ log X₀) (hn : X₀ ^ 2 ≤ (n : ℝ)) :
    let C := KernelSharpConstant.Criterion.mk' hd hc hcX hn
    (1 + 3 / (10 * (n : ℝ))) * ∏ i, (1 + (1 : ℝ) / C.q i) ≤
      (∏ i, (1 + 1 / (C.p i * (C.p i + 1) : ℝ))) *
      (1 + 3 / (8 * (n : ℝ))) *
      (1 - 4 * (∏ i, (C.p i : ℝ)) / ∏ i, (C.q i : ℝ)) := by
  dsimp only [KernelSharpConstant.Criterion.mk']
  have hnp : (0 : ℝ) < n := by exact_mod_cast n_pos hd hc hcX hn
  have hngt := hn_gt hd hc hcX hn
  have hn₀ : 0 ≤ Real.log √(n : ℝ) := (hlog_pos hd hc hcX hn).le
  have h₁ : 1 - (4 : ℝ) *
      (∏ i, (exists_p_primes hd hc hcX hn).choose i : ℝ) /
        ∏ i, ((exists_q_primes hd hc hcX hn).choose i : ℝ) ≥
      1 - 4 * (1 + 1 / 256 : ℝ) ^ 12 * ((1 / 4096) * (1 / n)) := by
    grw [pq_ratio_ge hd hc hcX hn,
      ← inv_n_pow_3_div_2_le hd hc hcX hn]
    simp [field]
  have hnn : 0 ≤ 1 - 4 * (1 + 1 / 256 : ℝ) ^ 12 * ((1 / 4096) * (1 / n)) := by
    have : (1 : ℝ) / n ≤ 1 / 4096 ^ 2 := by
      rw [div_le_div_iff₀ hnp (by norm_num)]; linarith
    nlinarith
  have := hnn.trans h₁
  have hn' : (0 : ℝ) ≤ 1 / (n : ℝ) ∧ (1 : ℝ) / (n : ℝ) ≤ 1 / 4096 ^ 2 :=
    ⟨by positivity, by rw [div_le_div_iff₀ hnp (by norm_num)]; linarith⟩
  grw [prod_q_ge hd hc hcX hn, prod_p_ge hd hc hcX hn, h₁]
  simp_rw [div_eq_mul_one_div (_ ^ (_ : ℝ) : ℝ) (n : ℝ),
    show 3 / (8 * (n : ℝ)) = 3 / 8 * (1 / n) by field_simp, ← one_div_mul_one_div]
  grw [inv_n_add_sqrt_ge hd hc hcX hn]
  set ε : ℝ := 1 / (n : ℝ)
  calc
    _ ≤ (1 + (3 / 10 : ℝ) * ε) * ∏ i : Fin 3, (1 + (1 + 1 / 256 : ℝ) ^ (i + 1 : ℝ) * ε) := by gcongr <;> dsimp [ε] <;> ring_nf <;> exact le_rfl
    _ = (1 + 3 * ε / 10) * ∏ i : Fin 3, (1 + ((257 / 256) : ℝ) ^ (i + 1 : ℝ) * ε) := by norm_num <;> ring_nf <;> simp
    _ ≤ (1 + 3 * ε / 10) * (1 + 3.024 * ε + 3.05 * ε^2 + 1.03 * ε^3) :=
        mul_le_mul_of_nonneg_left (KernelSharpConstant.prod_epsilon_le (ε := ε) hn') (by positivity)
    _ ≤ _ := scalar_surplus hn'
    _ ≤ _ := by
      grw [← KernelSharpConstant.prod_epsilon_ge hn']
      apply le_of_eq
      simp [field]
      ring_nf

/-- Shared construction, with its prime-cover premise fully exposed. -/
theorem quantitative_of_gap {c X₀ : ℝ} (hd : StrictGap X₀)
    (hc : 9 ≤ c) (hcX : c ≤ Real.log X₀) (n : ℕ) (hn : X₀^2 ≤ (n : ℝ)) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 3 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ)
        < ArithmeticFunction.sigma 1 m := by
  let C := KernelSharpConstant.Criterion.mk' hd hc hcX hn
  refine ⟨C.M, C.M_lt, ?_⟩
  exact E1Tertiary.LcmSurplus.criterion_surplus C (by positivity) (comparison hd hc hcX hn)


#check @quantitative_of_gap
#print axioms quantitative_of_gap
end ExposureEvolution.KernelSharpSurplus
