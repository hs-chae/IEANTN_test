import ExposureEvolution.DualKernelData60
import ExposureEvolution.DualKernelBlocks60_000
import ExposureEvolution.DualKernelBlocks60_001
import ExposureEvolution.DualKernelBlocks60_002
import ExposureEvolution.DualKernelBlocks60_003
import ExposureEvolution.DualKernelBlocks60_004
import ExposureEvolution.DualKernelBlocks60_005
import ExposureEvolution.DualKernelBlocks60_006
import ExposureEvolution.DualKernelBlocks60_007
import ExposureEvolution.DualKernelBlocks60_008
import ExposureEvolution.DualKernelBlocks60_009
import ExposureEvolution.DualKernelBlocks60_010
import ExposureEvolution.DualKernelBlocks60_011
namespace ExposureEvolution.DualKernelCoverage60
open ExposureEvolution.Dual60CheckerV1
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem chunk_identity000 : ExposureEvolution.DualKernelData60.chunk000 =
    ExposureEvolution.DualKernelBlocks60_000.witnesses ++ ExposureEvolution.DualKernelBlocks60_001.witnesses := by rfl

theorem chunk_identity001 : ExposureEvolution.DualKernelData60.chunk001 =
    ExposureEvolution.DualKernelBlocks60_002.witnesses ++ ExposureEvolution.DualKernelBlocks60_003.witnesses := by rfl

theorem chunk_identity002 : ExposureEvolution.DualKernelData60.chunk002 =
    ExposureEvolution.DualKernelBlocks60_004.witnesses ++ ExposureEvolution.DualKernelBlocks60_005.witnesses := by rfl

theorem chunk_identity003 : ExposureEvolution.DualKernelData60.chunk003 =
    ExposureEvolution.DualKernelBlocks60_006.witnesses ++ ExposureEvolution.DualKernelBlocks60_007.witnesses := by rfl

theorem chunk_identity004 : ExposureEvolution.DualKernelData60.chunk004 =
    ExposureEvolution.DualKernelBlocks60_008.witnesses ++ ExposureEvolution.DualKernelBlocks60_009.witnesses := by rfl

theorem chunk_identity005 : ExposureEvolution.DualKernelData60.chunk005 =
    ExposureEvolution.DualKernelBlocks60_010.witnesses ++ ExposureEvolution.DualKernelBlocks60_011.witnesses := by rfl

theorem same_values : ExposureEvolution.DualKernelData60.witnesses =
  ExposureEvolution.DualKernelBlocks60_000.witnesses ++
  ExposureEvolution.DualKernelBlocks60_001.witnesses ++
  ExposureEvolution.DualKernelBlocks60_002.witnesses ++
  ExposureEvolution.DualKernelBlocks60_003.witnesses ++
  ExposureEvolution.DualKernelBlocks60_004.witnesses ++
  ExposureEvolution.DualKernelBlocks60_005.witnesses ++
  ExposureEvolution.DualKernelBlocks60_006.witnesses ++
  ExposureEvolution.DualKernelBlocks60_007.witnesses ++
  ExposureEvolution.DualKernelBlocks60_008.witnesses ++
  ExposureEvolution.DualKernelBlocks60_009.witnesses ++
  ExposureEvolution.DualKernelBlocks60_010.witnesses ++
  ExposureEvolution.DualKernelBlocks60_011.witnesses := by
  simp only [ExposureEvolution.DualKernelData60.witnesses,
    chunk_identity000,
    chunk_identity001,
    chunk_identity002,
    chunk_identity003,
    chunk_identity004,
    chunk_identity005, List.append_assoc]

theorem accepted : coverage 5000000 71707024 ExposureEvolution.DualKernelData60.witnesses = true := by
  have h : coverage 5000000 71707024 (
    ExposureEvolution.DualKernelBlocks60_000.witnesses ++
  ExposureEvolution.DualKernelBlocks60_001.witnesses ++
  ExposureEvolution.DualKernelBlocks60_002.witnesses ++
  ExposureEvolution.DualKernelBlocks60_003.witnesses ++
  ExposureEvolution.DualKernelBlocks60_004.witnesses ++
  ExposureEvolution.DualKernelBlocks60_005.witnesses ++
  ExposureEvolution.DualKernelBlocks60_006.witnesses ++
  ExposureEvolution.DualKernelBlocks60_007.witnesses ++
  ExposureEvolution.DualKernelBlocks60_008.witnesses ++
  ExposureEvolution.DualKernelBlocks60_009.witnesses ++
  ExposureEvolution.DualKernelBlocks60_010.witnesses ++
  ExposureEvolution.DualKernelBlocks60_011.witnesses) = true := by
    apply ExposureEvolution.DualKernelBlocks60_000.extend
    apply ExposureEvolution.DualKernelBlocks60_001.extend
    apply ExposureEvolution.DualKernelBlocks60_002.extend
    apply ExposureEvolution.DualKernelBlocks60_003.extend
    apply ExposureEvolution.DualKernelBlocks60_004.extend
    apply ExposureEvolution.DualKernelBlocks60_005.extend
    apply ExposureEvolution.DualKernelBlocks60_006.extend
    apply ExposureEvolution.DualKernelBlocks60_007.extend
    apply ExposureEvolution.DualKernelBlocks60_008.extend
    apply ExposureEvolution.DualKernelBlocks60_009.extend
    apply ExposureEvolution.DualKernelBlocks60_010.extend
    apply ExposureEvolution.DualKernelBlocks60_011.extend
    decide +kernel
  simpa only [same_values] using h

theorem finite (n : ℕ) (hn : 5000000 ≤ n ∧ n < 71707024) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m :=
  coverage_sound 5000000 71707024 ExposureEvolution.DualKernelData60.witnesses accepted n hn

#print axioms accepted
#print axioms finite
end ExposureEvolution.DualKernelCoverage60
