import LucasCore
namespace ExposureEvolution.Compact40Pratt
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem prime_2 : Nat.Prime 2 := by
  exact Nat.prime_two

theorem prime_3 : Nat.Prime 3 := by
  refine Round2Recovery.lucas_list_prime (n := 3) (a := 2)
    (factors := [2]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl
    all_goals first | exact prime_2
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl
    all_goals decide +kernel

theorem prime_5 : Nat.Prime 5 := by
  refine Round2Recovery.lucas_list_prime (n := 5) (a := 2)
    (factors := [2, 2]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_7 : Nat.Prime 7 := by
  refine Round2Recovery.lucas_list_prime (n := 7) (a := 3)
    (factors := [2, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_11 : Nat.Prime 11 := by
  refine Round2Recovery.lucas_list_prime (n := 11) (a := 2)
    (factors := [2, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_13 : Nat.Prime 13 := by
  refine Round2Recovery.lucas_list_prime (n := 13) (a := 2)
    (factors := [2, 2, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_17 : Nat.Prime 17 := by
  refine Round2Recovery.lucas_list_prime (n := 17) (a := 3)
    (factors := [2, 2, 2, 2]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_19 : Nat.Prime 19 := by
  refine Round2Recovery.lucas_list_prime (n := 19) (a := 2)
    (factors := [2, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_23 : Nat.Prime 23 := by
  refine Round2Recovery.lucas_list_prime (n := 23) (a := 5)
    (factors := [2, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_29 : Nat.Prime 29 := by
  refine Round2Recovery.lucas_list_prime (n := 29) (a := 2)
    (factors := [2, 2, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_31 : Nat.Prime 31 := by
  refine Round2Recovery.lucas_list_prime (n := 31) (a := 3)
    (factors := [2, 3, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_37 : Nat.Prime 37 := by
  refine Round2Recovery.lucas_list_prime (n := 37) (a := 2)
    (factors := [2, 2, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_41 : Nat.Prime 41 := by
  refine Round2Recovery.lucas_list_prime (n := 41) (a := 6)
    (factors := [2, 2, 2, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_43 : Nat.Prime 43 := by
  refine Round2Recovery.lucas_list_prime (n := 43) (a := 3)
    (factors := [2, 3, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_47 : Nat.Prime 47 := by
  refine Round2Recovery.lucas_list_prime (n := 47) (a := 5)
    (factors := [2, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_53 : Nat.Prime 53 := by
  refine Round2Recovery.lucas_list_prime (n := 53) (a := 2)
    (factors := [2, 2, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_59 : Nat.Prime 59 := by
  refine Round2Recovery.lucas_list_prime (n := 59) (a := 2)
    (factors := [2, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_61 : Nat.Prime 61 := by
  refine Round2Recovery.lucas_list_prime (n := 61) (a := 2)
    (factors := [2, 2, 3, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_67 : Nat.Prime 67 := by
  refine Round2Recovery.lucas_list_prime (n := 67) (a := 2)
    (factors := [2, 3, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_71 : Nat.Prime 71 := by
  refine Round2Recovery.lucas_list_prime (n := 71) (a := 7)
    (factors := [2, 5, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_73 : Nat.Prime 73 := by
  refine Round2Recovery.lucas_list_prime (n := 73) (a := 5)
    (factors := [2, 2, 2, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_79 : Nat.Prime 79 := by
  refine Round2Recovery.lucas_list_prime (n := 79) (a := 3)
    (factors := [2, 3, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_83 : Nat.Prime 83 := by
  refine Round2Recovery.lucas_list_prime (n := 83) (a := 2)
    (factors := [2, 41]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_41
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_89 : Nat.Prime 89 := by
  refine Round2Recovery.lucas_list_prime (n := 89) (a := 3)
    (factors := [2, 2, 2, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_97 : Nat.Prime 97 := by
  refine Round2Recovery.lucas_list_prime (n := 97) (a := 5)
    (factors := [2, 2, 2, 2, 2, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_101 : Nat.Prime 101 := by
  refine Round2Recovery.lucas_list_prime (n := 101) (a := 2)
    (factors := [2, 2, 5, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_103 : Nat.Prime 103 := by
  refine Round2Recovery.lucas_list_prime (n := 103) (a := 5)
    (factors := [2, 3, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_107 : Nat.Prime 107 := by
  refine Round2Recovery.lucas_list_prime (n := 107) (a := 2)
    (factors := [2, 53]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_53
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_109 : Nat.Prime 109 := by
  refine Round2Recovery.lucas_list_prime (n := 109) (a := 6)
    (factors := [2, 2, 3, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_113 : Nat.Prime 113 := by
  refine Round2Recovery.lucas_list_prime (n := 113) (a := 3)
    (factors := [2, 2, 2, 2, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_127 : Nat.Prime 127 := by
  refine Round2Recovery.lucas_list_prime (n := 127) (a := 3)
    (factors := [2, 3, 3, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_131 : Nat.Prime 131 := by
  refine Round2Recovery.lucas_list_prime (n := 131) (a := 2)
    (factors := [2, 5, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_137 : Nat.Prime 137 := by
  refine Round2Recovery.lucas_list_prime (n := 137) (a := 3)
    (factors := [2, 2, 2, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_139 : Nat.Prime 139 := by
  refine Round2Recovery.lucas_list_prime (n := 139) (a := 2)
    (factors := [2, 3, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_149 : Nat.Prime 149 := by
  refine Round2Recovery.lucas_list_prime (n := 149) (a := 2)
    (factors := [2, 2, 37]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_37
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_151 : Nat.Prime 151 := by
  refine Round2Recovery.lucas_list_prime (n := 151) (a := 6)
    (factors := [2, 3, 5, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_157 : Nat.Prime 157 := by
  refine Round2Recovery.lucas_list_prime (n := 157) (a := 5)
    (factors := [2, 2, 3, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_163 : Nat.Prime 163 := by
  refine Round2Recovery.lucas_list_prime (n := 163) (a := 2)
    (factors := [2, 3, 3, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_167 : Nat.Prime 167 := by
  refine Round2Recovery.lucas_list_prime (n := 167) (a := 5)
    (factors := [2, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_173 : Nat.Prime 173 := by
  refine Round2Recovery.lucas_list_prime (n := 173) (a := 2)
    (factors := [2, 2, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_179 : Nat.Prime 179 := by
  refine Round2Recovery.lucas_list_prime (n := 179) (a := 2)
    (factors := [2, 89]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_89
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_181 : Nat.Prime 181 := by
  refine Round2Recovery.lucas_list_prime (n := 181) (a := 2)
    (factors := [2, 2, 3, 3, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_191 : Nat.Prime 191 := by
  refine Round2Recovery.lucas_list_prime (n := 191) (a := 19)
    (factors := [2, 5, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_193 : Nat.Prime 193 := by
  refine Round2Recovery.lucas_list_prime (n := 193) (a := 5)
    (factors := [2, 2, 2, 2, 2, 2, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_197 : Nat.Prime 197 := by
  refine Round2Recovery.lucas_list_prime (n := 197) (a := 2)
    (factors := [2, 2, 7, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_199 : Nat.Prime 199 := by
  refine Round2Recovery.lucas_list_prime (n := 199) (a := 3)
    (factors := [2, 3, 3, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_211 : Nat.Prime 211 := by
  refine Round2Recovery.lucas_list_prime (n := 211) (a := 2)
    (factors := [2, 3, 5, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_223 : Nat.Prime 223 := by
  refine Round2Recovery.lucas_list_prime (n := 223) (a := 3)
    (factors := [2, 3, 37]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_37
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_227 : Nat.Prime 227 := by
  refine Round2Recovery.lucas_list_prime (n := 227) (a := 2)
    (factors := [2, 113]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_113
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_229 : Nat.Prime 229 := by
  refine Round2Recovery.lucas_list_prime (n := 229) (a := 6)
    (factors := [2, 2, 3, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_233 : Nat.Prime 233 := by
  refine Round2Recovery.lucas_list_prime (n := 233) (a := 3)
    (factors := [2, 2, 2, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_239 : Nat.Prime 239 := by
  refine Round2Recovery.lucas_list_prime (n := 239) (a := 7)
    (factors := [2, 7, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_241 : Nat.Prime 241 := by
  refine Round2Recovery.lucas_list_prime (n := 241) (a := 7)
    (factors := [2, 2, 2, 2, 3, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_251 : Nat.Prime 251 := by
  refine Round2Recovery.lucas_list_prime (n := 251) (a := 6)
    (factors := [2, 5, 5, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_257 : Nat.Prime 257 := by
  refine Round2Recovery.lucas_list_prime (n := 257) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 2, 2]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_263 : Nat.Prime 263 := by
  refine Round2Recovery.lucas_list_prime (n := 263) (a := 5)
    (factors := [2, 131]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_131
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_269 : Nat.Prime 269 := by
  refine Round2Recovery.lucas_list_prime (n := 269) (a := 2)
    (factors := [2, 2, 67]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_67
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_271 : Nat.Prime 271 := by
  refine Round2Recovery.lucas_list_prime (n := 271) (a := 6)
    (factors := [2, 3, 3, 3, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_277 : Nat.Prime 277 := by
  refine Round2Recovery.lucas_list_prime (n := 277) (a := 5)
    (factors := [2, 2, 3, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_281 : Nat.Prime 281 := by
  refine Round2Recovery.lucas_list_prime (n := 281) (a := 3)
    (factors := [2, 2, 2, 5, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_283 : Nat.Prime 283 := by
  refine Round2Recovery.lucas_list_prime (n := 283) (a := 3)
    (factors := [2, 3, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_293 : Nat.Prime 293 := by
  refine Round2Recovery.lucas_list_prime (n := 293) (a := 2)
    (factors := [2, 2, 73]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_73
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_307 : Nat.Prime 307 := by
  refine Round2Recovery.lucas_list_prime (n := 307) (a := 5)
    (factors := [2, 3, 3, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_311 : Nat.Prime 311 := by
  refine Round2Recovery.lucas_list_prime (n := 311) (a := 17)
    (factors := [2, 5, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_313 : Nat.Prime 313 := by
  refine Round2Recovery.lucas_list_prime (n := 313) (a := 10)
    (factors := [2, 2, 2, 3, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_317 : Nat.Prime 317 := by
  refine Round2Recovery.lucas_list_prime (n := 317) (a := 2)
    (factors := [2, 2, 79]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_79
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_331 : Nat.Prime 331 := by
  refine Round2Recovery.lucas_list_prime (n := 331) (a := 3)
    (factors := [2, 3, 5, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_337 : Nat.Prime 337 := by
  refine Round2Recovery.lucas_list_prime (n := 337) (a := 10)
    (factors := [2, 2, 2, 2, 3, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_347 : Nat.Prime 347 := by
  refine Round2Recovery.lucas_list_prime (n := 347) (a := 2)
    (factors := [2, 173]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_173
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_349 : Nat.Prime 349 := by
  refine Round2Recovery.lucas_list_prime (n := 349) (a := 2)
    (factors := [2, 2, 3, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_353 : Nat.Prime 353 := by
  refine Round2Recovery.lucas_list_prime (n := 353) (a := 3)
    (factors := [2, 2, 2, 2, 2, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_359 : Nat.Prime 359 := by
  refine Round2Recovery.lucas_list_prime (n := 359) (a := 7)
    (factors := [2, 179]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_179
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_367 : Nat.Prime 367 := by
  refine Round2Recovery.lucas_list_prime (n := 367) (a := 6)
    (factors := [2, 3, 61]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_61
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_373 : Nat.Prime 373 := by
  refine Round2Recovery.lucas_list_prime (n := 373) (a := 2)
    (factors := [2, 2, 3, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_379 : Nat.Prime 379 := by
  refine Round2Recovery.lucas_list_prime (n := 379) (a := 2)
    (factors := [2, 3, 3, 3, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_383 : Nat.Prime 383 := by
  refine Round2Recovery.lucas_list_prime (n := 383) (a := 5)
    (factors := [2, 191]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_191
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_389 : Nat.Prime 389 := by
  refine Round2Recovery.lucas_list_prime (n := 389) (a := 2)
    (factors := [2, 2, 97]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_97
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_397 : Nat.Prime 397 := by
  refine Round2Recovery.lucas_list_prime (n := 397) (a := 5)
    (factors := [2, 2, 3, 3, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_401 : Nat.Prime 401 := by
  refine Round2Recovery.lucas_list_prime (n := 401) (a := 3)
    (factors := [2, 2, 2, 2, 5, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_409 : Nat.Prime 409 := by
  refine Round2Recovery.lucas_list_prime (n := 409) (a := 21)
    (factors := [2, 2, 2, 3, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_419 : Nat.Prime 419 := by
  refine Round2Recovery.lucas_list_prime (n := 419) (a := 2)
    (factors := [2, 11, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_421 : Nat.Prime 421 := by
  refine Round2Recovery.lucas_list_prime (n := 421) (a := 2)
    (factors := [2, 2, 3, 5, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_431 : Nat.Prime 431 := by
  refine Round2Recovery.lucas_list_prime (n := 431) (a := 7)
    (factors := [2, 5, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_433 : Nat.Prime 433 := by
  refine Round2Recovery.lucas_list_prime (n := 433) (a := 5)
    (factors := [2, 2, 2, 2, 3, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_439 : Nat.Prime 439 := by
  refine Round2Recovery.lucas_list_prime (n := 439) (a := 15)
    (factors := [2, 3, 73]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_73
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_443 : Nat.Prime 443 := by
  refine Round2Recovery.lucas_list_prime (n := 443) (a := 2)
    (factors := [2, 13, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_449 : Nat.Prime 449 := by
  refine Round2Recovery.lucas_list_prime (n := 449) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_457 : Nat.Prime 457 := by
  refine Round2Recovery.lucas_list_prime (n := 457) (a := 13)
    (factors := [2, 2, 2, 3, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_461 : Nat.Prime 461 := by
  refine Round2Recovery.lucas_list_prime (n := 461) (a := 2)
    (factors := [2, 2, 5, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_463 : Nat.Prime 463 := by
  refine Round2Recovery.lucas_list_prime (n := 463) (a := 3)
    (factors := [2, 3, 7, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_467 : Nat.Prime 467 := by
  refine Round2Recovery.lucas_list_prime (n := 467) (a := 2)
    (factors := [2, 233]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_233
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_479 : Nat.Prime 479 := by
  refine Round2Recovery.lucas_list_prime (n := 479) (a := 13)
    (factors := [2, 239]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_239
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_487 : Nat.Prime 487 := by
  refine Round2Recovery.lucas_list_prime (n := 487) (a := 3)
    (factors := [2, 3, 3, 3, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_491 : Nat.Prime 491 := by
  refine Round2Recovery.lucas_list_prime (n := 491) (a := 2)
    (factors := [2, 5, 7, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_499 : Nat.Prime 499 := by
  refine Round2Recovery.lucas_list_prime (n := 499) (a := 7)
    (factors := [2, 3, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_503 : Nat.Prime 503 := by
  refine Round2Recovery.lucas_list_prime (n := 503) (a := 5)
    (factors := [2, 251]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_251
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_509 : Nat.Prime 509 := by
  refine Round2Recovery.lucas_list_prime (n := 509) (a := 2)
    (factors := [2, 2, 127]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_127
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_521 : Nat.Prime 521 := by
  refine Round2Recovery.lucas_list_prime (n := 521) (a := 3)
    (factors := [2, 2, 2, 5, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_523 : Nat.Prime 523 := by
  refine Round2Recovery.lucas_list_prime (n := 523) (a := 2)
    (factors := [2, 3, 3, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_541 : Nat.Prime 541 := by
  refine Round2Recovery.lucas_list_prime (n := 541) (a := 2)
    (factors := [2, 2, 3, 3, 3, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_547 : Nat.Prime 547 := by
  refine Round2Recovery.lucas_list_prime (n := 547) (a := 2)
    (factors := [2, 3, 7, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_557 : Nat.Prime 557 := by
  refine Round2Recovery.lucas_list_prime (n := 557) (a := 2)
    (factors := [2, 2, 139]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_139
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_563 : Nat.Prime 563 := by
  refine Round2Recovery.lucas_list_prime (n := 563) (a := 2)
    (factors := [2, 281]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_281
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_569 : Nat.Prime 569 := by
  refine Round2Recovery.lucas_list_prime (n := 569) (a := 3)
    (factors := [2, 2, 2, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_571 : Nat.Prime 571 := by
  refine Round2Recovery.lucas_list_prime (n := 571) (a := 3)
    (factors := [2, 3, 5, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_577 : Nat.Prime 577 := by
  refine Round2Recovery.lucas_list_prime (n := 577) (a := 5)
    (factors := [2, 2, 2, 2, 2, 2, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_587 : Nat.Prime 587 := by
  refine Round2Recovery.lucas_list_prime (n := 587) (a := 2)
    (factors := [2, 293]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_293
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_593 : Nat.Prime 593 := by
  refine Round2Recovery.lucas_list_prime (n := 593) (a := 3)
    (factors := [2, 2, 2, 2, 37]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_37
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_599 : Nat.Prime 599 := by
  refine Round2Recovery.lucas_list_prime (n := 599) (a := 7)
    (factors := [2, 13, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_601 : Nat.Prime 601 := by
  refine Round2Recovery.lucas_list_prime (n := 601) (a := 7)
    (factors := [2, 2, 2, 3, 5, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_607 : Nat.Prime 607 := by
  refine Round2Recovery.lucas_list_prime (n := 607) (a := 3)
    (factors := [2, 3, 101]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_101
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_613 : Nat.Prime 613 := by
  refine Round2Recovery.lucas_list_prime (n := 613) (a := 2)
    (factors := [2, 2, 3, 3, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_617 : Nat.Prime 617 := by
  refine Round2Recovery.lucas_list_prime (n := 617) (a := 3)
    (factors := [2, 2, 2, 7, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_619 : Nat.Prime 619 := by
  refine Round2Recovery.lucas_list_prime (n := 619) (a := 2)
    (factors := [2, 3, 103]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_103
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_631 : Nat.Prime 631 := by
  refine Round2Recovery.lucas_list_prime (n := 631) (a := 3)
    (factors := [2, 3, 3, 5, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_641 : Nat.Prime 641 := by
  refine Round2Recovery.lucas_list_prime (n := 641) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 2, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_643 : Nat.Prime 643 := by
  refine Round2Recovery.lucas_list_prime (n := 643) (a := 11)
    (factors := [2, 3, 107]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_107
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_647 : Nat.Prime 647 := by
  refine Round2Recovery.lucas_list_prime (n := 647) (a := 5)
    (factors := [2, 17, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_17 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_653 : Nat.Prime 653 := by
  refine Round2Recovery.lucas_list_prime (n := 653) (a := 2)
    (factors := [2, 2, 163]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_163
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_659 : Nat.Prime 659 := by
  refine Round2Recovery.lucas_list_prime (n := 659) (a := 2)
    (factors := [2, 7, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_661 : Nat.Prime 661 := by
  refine Round2Recovery.lucas_list_prime (n := 661) (a := 2)
    (factors := [2, 2, 3, 5, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_673 : Nat.Prime 673 := by
  refine Round2Recovery.lucas_list_prime (n := 673) (a := 5)
    (factors := [2, 2, 2, 2, 2, 3, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_677 : Nat.Prime 677 := by
  refine Round2Recovery.lucas_list_prime (n := 677) (a := 2)
    (factors := [2, 2, 13, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_683 : Nat.Prime 683 := by
  refine Round2Recovery.lucas_list_prime (n := 683) (a := 5)
    (factors := [2, 11, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_691 : Nat.Prime 691 := by
  refine Round2Recovery.lucas_list_prime (n := 691) (a := 3)
    (factors := [2, 3, 5, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_701 : Nat.Prime 701 := by
  refine Round2Recovery.lucas_list_prime (n := 701) (a := 2)
    (factors := [2, 2, 5, 5, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_709 : Nat.Prime 709 := by
  refine Round2Recovery.lucas_list_prime (n := 709) (a := 2)
    (factors := [2, 2, 3, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_719 : Nat.Prime 719 := by
  refine Round2Recovery.lucas_list_prime (n := 719) (a := 11)
    (factors := [2, 359]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_359
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_727 : Nat.Prime 727 := by
  refine Round2Recovery.lucas_list_prime (n := 727) (a := 5)
    (factors := [2, 3, 11, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_733 : Nat.Prime 733 := by
  refine Round2Recovery.lucas_list_prime (n := 733) (a := 6)
    (factors := [2, 2, 3, 61]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_61
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_739 : Nat.Prime 739 := by
  refine Round2Recovery.lucas_list_prime (n := 739) (a := 3)
    (factors := [2, 3, 3, 41]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_41
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_743 : Nat.Prime 743 := by
  refine Round2Recovery.lucas_list_prime (n := 743) (a := 5)
    (factors := [2, 7, 53]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_53
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_751 : Nat.Prime 751 := by
  refine Round2Recovery.lucas_list_prime (n := 751) (a := 3)
    (factors := [2, 3, 5, 5, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_757 : Nat.Prime 757 := by
  refine Round2Recovery.lucas_list_prime (n := 757) (a := 2)
    (factors := [2, 2, 3, 3, 3, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_761 : Nat.Prime 761 := by
  refine Round2Recovery.lucas_list_prime (n := 761) (a := 6)
    (factors := [2, 2, 2, 5, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_769 : Nat.Prime 769 := by
  refine Round2Recovery.lucas_list_prime (n := 769) (a := 11)
    (factors := [2, 2, 2, 2, 2, 2, 2, 2, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_773 : Nat.Prime 773 := by
  refine Round2Recovery.lucas_list_prime (n := 773) (a := 2)
    (factors := [2, 2, 193]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_193
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_787 : Nat.Prime 787 := by
  refine Round2Recovery.lucas_list_prime (n := 787) (a := 2)
    (factors := [2, 3, 131]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_131
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_797 : Nat.Prime 797 := by
  refine Round2Recovery.lucas_list_prime (n := 797) (a := 2)
    (factors := [2, 2, 199]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_199
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_809 : Nat.Prime 809 := by
  refine Round2Recovery.lucas_list_prime (n := 809) (a := 3)
    (factors := [2, 2, 2, 101]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_101
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_811 : Nat.Prime 811 := by
  refine Round2Recovery.lucas_list_prime (n := 811) (a := 3)
    (factors := [2, 3, 3, 3, 3, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_821 : Nat.Prime 821 := by
  refine Round2Recovery.lucas_list_prime (n := 821) (a := 2)
    (factors := [2, 2, 5, 41]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_41
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_823 : Nat.Prime 823 := by
  refine Round2Recovery.lucas_list_prime (n := 823) (a := 3)
    (factors := [2, 3, 137]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_137
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_827 : Nat.Prime 827 := by
  refine Round2Recovery.lucas_list_prime (n := 827) (a := 2)
    (factors := [2, 7, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_829 : Nat.Prime 829 := by
  refine Round2Recovery.lucas_list_prime (n := 829) (a := 2)
    (factors := [2, 2, 3, 3, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_839 : Nat.Prime 839 := by
  refine Round2Recovery.lucas_list_prime (n := 839) (a := 11)
    (factors := [2, 419]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_419
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_853 : Nat.Prime 853 := by
  refine Round2Recovery.lucas_list_prime (n := 853) (a := 2)
    (factors := [2, 2, 3, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_857 : Nat.Prime 857 := by
  refine Round2Recovery.lucas_list_prime (n := 857) (a := 3)
    (factors := [2, 2, 2, 107]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_107
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_859 : Nat.Prime 859 := by
  refine Round2Recovery.lucas_list_prime (n := 859) (a := 2)
    (factors := [2, 3, 11, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_863 : Nat.Prime 863 := by
  refine Round2Recovery.lucas_list_prime (n := 863) (a := 5)
    (factors := [2, 431]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_431
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_877 : Nat.Prime 877 := by
  refine Round2Recovery.lucas_list_prime (n := 877) (a := 2)
    (factors := [2, 2, 3, 73]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_73
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_881 : Nat.Prime 881 := by
  refine Round2Recovery.lucas_list_prime (n := 881) (a := 3)
    (factors := [2, 2, 2, 2, 5, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_883 : Nat.Prime 883 := by
  refine Round2Recovery.lucas_list_prime (n := 883) (a := 2)
    (factors := [2, 3, 3, 7, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_887 : Nat.Prime 887 := by
  refine Round2Recovery.lucas_list_prime (n := 887) (a := 5)
    (factors := [2, 443]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_443
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_907 : Nat.Prime 907 := by
  refine Round2Recovery.lucas_list_prime (n := 907) (a := 2)
    (factors := [2, 3, 151]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_151
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_911 : Nat.Prime 911 := by
  refine Round2Recovery.lucas_list_prime (n := 911) (a := 17)
    (factors := [2, 5, 7, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_7 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_919 : Nat.Prime 919 := by
  refine Round2Recovery.lucas_list_prime (n := 919) (a := 7)
    (factors := [2, 3, 3, 3, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_929 : Nat.Prime 929 := by
  refine Round2Recovery.lucas_list_prime (n := 929) (a := 3)
    (factors := [2, 2, 2, 2, 2, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_937 : Nat.Prime 937 := by
  refine Round2Recovery.lucas_list_prime (n := 937) (a := 5)
    (factors := [2, 2, 2, 3, 3, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_941 : Nat.Prime 941 := by
  refine Round2Recovery.lucas_list_prime (n := 941) (a := 2)
    (factors := [2, 2, 5, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_947 : Nat.Prime 947 := by
  refine Round2Recovery.lucas_list_prime (n := 947) (a := 2)
    (factors := [2, 11, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_953 : Nat.Prime 953 := by
  refine Round2Recovery.lucas_list_prime (n := 953) (a := 3)
    (factors := [2, 2, 2, 7, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_967 : Nat.Prime 967 := by
  refine Round2Recovery.lucas_list_prime (n := 967) (a := 5)
    (factors := [2, 3, 7, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_971 : Nat.Prime 971 := by
  refine Round2Recovery.lucas_list_prime (n := 971) (a := 6)
    (factors := [2, 5, 97]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_97
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_977 : Nat.Prime 977 := by
  refine Round2Recovery.lucas_list_prime (n := 977) (a := 3)
    (factors := [2, 2, 2, 2, 61]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_61
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_983 : Nat.Prime 983 := by
  refine Round2Recovery.lucas_list_prime (n := 983) (a := 5)
    (factors := [2, 491]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_491
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_991 : Nat.Prime 991 := by
  refine Round2Recovery.lucas_list_prime (n := 991) (a := 6)
    (factors := [2, 3, 3, 5, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_997 : Nat.Prime 997 := by
  refine Round2Recovery.lucas_list_prime (n := 997) (a := 7)
    (factors := [2, 2, 3, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1009 : Nat.Prime 1009 := by
  refine Round2Recovery.lucas_list_prime (n := 1009) (a := 11)
    (factors := [2, 2, 2, 2, 3, 3, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1013 : Nat.Prime 1013 := by
  refine Round2Recovery.lucas_list_prime (n := 1013) (a := 3)
    (factors := [2, 2, 11, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1019 : Nat.Prime 1019 := by
  refine Round2Recovery.lucas_list_prime (n := 1019) (a := 2)
    (factors := [2, 509]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_509
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1021 : Nat.Prime 1021 := by
  refine Round2Recovery.lucas_list_prime (n := 1021) (a := 10)
    (factors := [2, 2, 3, 5, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1031 : Nat.Prime 1031 := by
  refine Round2Recovery.lucas_list_prime (n := 1031) (a := 14)
    (factors := [2, 5, 103]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_103
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1033 : Nat.Prime 1033 := by
  refine Round2Recovery.lucas_list_prime (n := 1033) (a := 5)
    (factors := [2, 2, 2, 3, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1039 : Nat.Prime 1039 := by
  refine Round2Recovery.lucas_list_prime (n := 1039) (a := 3)
    (factors := [2, 3, 173]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_173
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1049 : Nat.Prime 1049 := by
  refine Round2Recovery.lucas_list_prime (n := 1049) (a := 3)
    (factors := [2, 2, 2, 131]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_131
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1051 : Nat.Prime 1051 := by
  refine Round2Recovery.lucas_list_prime (n := 1051) (a := 7)
    (factors := [2, 3, 5, 5, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1061 : Nat.Prime 1061 := by
  refine Round2Recovery.lucas_list_prime (n := 1061) (a := 2)
    (factors := [2, 2, 5, 53]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_53
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1063 : Nat.Prime 1063 := by
  refine Round2Recovery.lucas_list_prime (n := 1063) (a := 3)
    (factors := [2, 3, 3, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1069 : Nat.Prime 1069 := by
  refine Round2Recovery.lucas_list_prime (n := 1069) (a := 6)
    (factors := [2, 2, 3, 89]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_89
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1087 : Nat.Prime 1087 := by
  refine Round2Recovery.lucas_list_prime (n := 1087) (a := 3)
    (factors := [2, 3, 181]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_181
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1091 : Nat.Prime 1091 := by
  refine Round2Recovery.lucas_list_prime (n := 1091) (a := 2)
    (factors := [2, 5, 109]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_109
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1093 : Nat.Prime 1093 := by
  refine Round2Recovery.lucas_list_prime (n := 1093) (a := 5)
    (factors := [2, 2, 3, 7, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1097 : Nat.Prime 1097 := by
  refine Round2Recovery.lucas_list_prime (n := 1097) (a := 3)
    (factors := [2, 2, 2, 137]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_137
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1103 : Nat.Prime 1103 := by
  refine Round2Recovery.lucas_list_prime (n := 1103) (a := 5)
    (factors := [2, 19, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1109 : Nat.Prime 1109 := by
  refine Round2Recovery.lucas_list_prime (n := 1109) (a := 2)
    (factors := [2, 2, 277]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_277
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1117 : Nat.Prime 1117 := by
  refine Round2Recovery.lucas_list_prime (n := 1117) (a := 2)
    (factors := [2, 2, 3, 3, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1123 : Nat.Prime 1123 := by
  refine Round2Recovery.lucas_list_prime (n := 1123) (a := 2)
    (factors := [2, 3, 11, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1129 : Nat.Prime 1129 := by
  refine Round2Recovery.lucas_list_prime (n := 1129) (a := 11)
    (factors := [2, 2, 2, 3, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1151 : Nat.Prime 1151 := by
  refine Round2Recovery.lucas_list_prime (n := 1151) (a := 17)
    (factors := [2, 5, 5, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1153 : Nat.Prime 1153 := by
  refine Round2Recovery.lucas_list_prime (n := 1153) (a := 5)
    (factors := [2, 2, 2, 2, 2, 2, 2, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1163 : Nat.Prime 1163 := by
  refine Round2Recovery.lucas_list_prime (n := 1163) (a := 5)
    (factors := [2, 7, 83]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_83
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1171 : Nat.Prime 1171 := by
  refine Round2Recovery.lucas_list_prime (n := 1171) (a := 2)
    (factors := [2, 3, 3, 5, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1181 : Nat.Prime 1181 := by
  refine Round2Recovery.lucas_list_prime (n := 1181) (a := 7)
    (factors := [2, 2, 5, 59]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_59
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1187 : Nat.Prime 1187 := by
  refine Round2Recovery.lucas_list_prime (n := 1187) (a := 2)
    (factors := [2, 593]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_593
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1193 : Nat.Prime 1193 := by
  refine Round2Recovery.lucas_list_prime (n := 1193) (a := 3)
    (factors := [2, 2, 2, 149]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_149
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1201 : Nat.Prime 1201 := by
  refine Round2Recovery.lucas_list_prime (n := 1201) (a := 11)
    (factors := [2, 2, 2, 2, 3, 5, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1213 : Nat.Prime 1213 := by
  refine Round2Recovery.lucas_list_prime (n := 1213) (a := 2)
    (factors := [2, 2, 3, 101]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_101
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1217 : Nat.Prime 1217 := by
  refine Round2Recovery.lucas_list_prime (n := 1217) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1223 : Nat.Prime 1223 := by
  refine Round2Recovery.lucas_list_prime (n := 1223) (a := 5)
    (factors := [2, 13, 47]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_47
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1229 : Nat.Prime 1229 := by
  refine Round2Recovery.lucas_list_prime (n := 1229) (a := 2)
    (factors := [2, 2, 307]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_307
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1231 : Nat.Prime 1231 := by
  refine Round2Recovery.lucas_list_prime (n := 1231) (a := 3)
    (factors := [2, 3, 5, 41]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_41
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1237 : Nat.Prime 1237 := by
  refine Round2Recovery.lucas_list_prime (n := 1237) (a := 2)
    (factors := [2, 2, 3, 103]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_103
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1249 : Nat.Prime 1249 := by
  refine Round2Recovery.lucas_list_prime (n := 1249) (a := 7)
    (factors := [2, 2, 2, 2, 2, 3, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1259 : Nat.Prime 1259 := by
  refine Round2Recovery.lucas_list_prime (n := 1259) (a := 2)
    (factors := [2, 17, 37]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_17 | exact prime_37
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1277 : Nat.Prime 1277 := by
  refine Round2Recovery.lucas_list_prime (n := 1277) (a := 2)
    (factors := [2, 2, 11, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1279 : Nat.Prime 1279 := by
  refine Round2Recovery.lucas_list_prime (n := 1279) (a := 3)
    (factors := [2, 3, 3, 71]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_71
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1283 : Nat.Prime 1283 := by
  refine Round2Recovery.lucas_list_prime (n := 1283) (a := 2)
    (factors := [2, 641]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_641
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1289 : Nat.Prime 1289 := by
  refine Round2Recovery.lucas_list_prime (n := 1289) (a := 6)
    (factors := [2, 2, 2, 7, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1291 : Nat.Prime 1291 := by
  refine Round2Recovery.lucas_list_prime (n := 1291) (a := 2)
    (factors := [2, 3, 5, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1297 : Nat.Prime 1297 := by
  refine Round2Recovery.lucas_list_prime (n := 1297) (a := 10)
    (factors := [2, 2, 2, 2, 3, 3, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1301 : Nat.Prime 1301 := by
  refine Round2Recovery.lucas_list_prime (n := 1301) (a := 2)
    (factors := [2, 2, 5, 5, 13]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_13
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1303 : Nat.Prime 1303 := by
  refine Round2Recovery.lucas_list_prime (n := 1303) (a := 6)
    (factors := [2, 3, 7, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1307 : Nat.Prime 1307 := by
  refine Round2Recovery.lucas_list_prime (n := 1307) (a := 2)
    (factors := [2, 653]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_653
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1319 : Nat.Prime 1319 := by
  refine Round2Recovery.lucas_list_prime (n := 1319) (a := 13)
    (factors := [2, 659]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_659
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1321 : Nat.Prime 1321 := by
  refine Round2Recovery.lucas_list_prime (n := 1321) (a := 13)
    (factors := [2, 2, 2, 3, 5, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1327 : Nat.Prime 1327 := by
  refine Round2Recovery.lucas_list_prime (n := 1327) (a := 3)
    (factors := [2, 3, 13, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1361 : Nat.Prime 1361 := by
  refine Round2Recovery.lucas_list_prime (n := 1361) (a := 3)
    (factors := [2, 2, 2, 2, 5, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1367 : Nat.Prime 1367 := by
  refine Round2Recovery.lucas_list_prime (n := 1367) (a := 5)
    (factors := [2, 683]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_683
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1373 : Nat.Prime 1373 := by
  refine Round2Recovery.lucas_list_prime (n := 1373) (a := 2)
    (factors := [2, 2, 7, 7, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1381 : Nat.Prime 1381 := by
  refine Round2Recovery.lucas_list_prime (n := 1381) (a := 2)
    (factors := [2, 2, 3, 5, 23]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_23
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1399 : Nat.Prime 1399 := by
  refine Round2Recovery.lucas_list_prime (n := 1399) (a := 13)
    (factors := [2, 3, 233]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_233
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1409 : Nat.Prime 1409 := by
  refine Round2Recovery.lucas_list_prime (n := 1409) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 2, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1423 : Nat.Prime 1423 := by
  refine Round2Recovery.lucas_list_prime (n := 1423) (a := 3)
    (factors := [2, 3, 3, 79]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_79
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1427 : Nat.Prime 1427 := by
  refine Round2Recovery.lucas_list_prime (n := 1427) (a := 2)
    (factors := [2, 23, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_23 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1429 : Nat.Prime 1429 := by
  refine Round2Recovery.lucas_list_prime (n := 1429) (a := 6)
    (factors := [2, 2, 3, 7, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1433 : Nat.Prime 1433 := by
  refine Round2Recovery.lucas_list_prime (n := 1433) (a := 3)
    (factors := [2, 2, 2, 179]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_179
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1439 : Nat.Prime 1439 := by
  refine Round2Recovery.lucas_list_prime (n := 1439) (a := 7)
    (factors := [2, 719]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_719
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1447 : Nat.Prime 1447 := by
  refine Round2Recovery.lucas_list_prime (n := 1447) (a := 3)
    (factors := [2, 3, 241]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_241
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1451 : Nat.Prime 1451 := by
  refine Round2Recovery.lucas_list_prime (n := 1451) (a := 2)
    (factors := [2, 5, 5, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1453 : Nat.Prime 1453 := by
  refine Round2Recovery.lucas_list_prime (n := 1453) (a := 2)
    (factors := [2, 2, 3, 11, 11]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_11
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1459 : Nat.Prime 1459 := by
  refine Round2Recovery.lucas_list_prime (n := 1459) (a := 3)
    (factors := [2, 3, 3, 3, 3, 3, 3]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1471 : Nat.Prime 1471 := by
  refine Round2Recovery.lucas_list_prime (n := 1471) (a := 6)
    (factors := [2, 3, 5, 7, 7]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_7
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1481 : Nat.Prime 1481 := by
  refine Round2Recovery.lucas_list_prime (n := 1481) (a := 3)
    (factors := [2, 2, 2, 5, 37]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_37
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1483 : Nat.Prime 1483 := by
  refine Round2Recovery.lucas_list_prime (n := 1483) (a := 2)
    (factors := [2, 3, 13, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_13 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1487 : Nat.Prime 1487 := by
  refine Round2Recovery.lucas_list_prime (n := 1487) (a := 5)
    (factors := [2, 743]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_743
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1489 : Nat.Prime 1489 := by
  refine Round2Recovery.lucas_list_prime (n := 1489) (a := 14)
    (factors := [2, 2, 2, 2, 3, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1493 : Nat.Prime 1493 := by
  refine Round2Recovery.lucas_list_prime (n := 1493) (a := 2)
    (factors := [2, 2, 373]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_373
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1499 : Nat.Prime 1499 := by
  refine Round2Recovery.lucas_list_prime (n := 1499) (a := 2)
    (factors := [2, 7, 107]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_107
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1511 : Nat.Prime 1511 := by
  refine Round2Recovery.lucas_list_prime (n := 1511) (a := 11)
    (factors := [2, 5, 151]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_151
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1523 : Nat.Prime 1523 := by
  refine Round2Recovery.lucas_list_prime (n := 1523) (a := 2)
    (factors := [2, 761]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_761
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

theorem prime_1531 : Nat.Prime 1531 := by
  refine Round2Recovery.lucas_list_prime (n := 1531) (a := 2)
    (factors := [2, 3, 3, 5, 17]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_5 | exact prime_17
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1543 : Nat.Prime 1543 := by
  refine Round2Recovery.lucas_list_prime (n := 1543) (a := 5)
    (factors := [2, 3, 257]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_257
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1549 : Nat.Prime 1549 := by
  refine Round2Recovery.lucas_list_prime (n := 1549) (a := 2)
    (factors := [2, 2, 3, 3, 43]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_43
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1553 : Nat.Prime 1553 := by
  refine Round2Recovery.lucas_list_prime (n := 1553) (a := 3)
    (factors := [2, 2, 2, 2, 97]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_97
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1559 : Nat.Prime 1559 := by
  refine Round2Recovery.lucas_list_prime (n := 1559) (a := 19)
    (factors := [2, 19, 41]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_19 | exact prime_41
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1567 : Nat.Prime 1567 := by
  refine Round2Recovery.lucas_list_prime (n := 1567) (a := 3)
    (factors := [2, 3, 3, 3, 29]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_29
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1571 : Nat.Prime 1571 := by
  refine Round2Recovery.lucas_list_prime (n := 1571) (a := 2)
    (factors := [2, 5, 157]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5 | exact prime_157
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1579 : Nat.Prime 1579 := by
  refine Round2Recovery.lucas_list_prime (n := 1579) (a := 3)
    (factors := [2, 3, 263]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_263
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1583 : Nat.Prime 1583 := by
  refine Round2Recovery.lucas_list_prime (n := 1583) (a := 5)
    (factors := [2, 7, 113]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_7 | exact prime_113
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1597 : Nat.Prime 1597 := by
  refine Round2Recovery.lucas_list_prime (n := 1597) (a := 11)
    (factors := [2, 2, 3, 7, 19]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_7 | exact prime_19
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1601 : Nat.Prime 1601 := by
  refine Round2Recovery.lucas_list_prime (n := 1601) (a := 3)
    (factors := [2, 2, 2, 2, 2, 2, 5, 5]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_5
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1607 : Nat.Prime 1607 := by
  refine Round2Recovery.lucas_list_prime (n := 1607) (a := 5)
    (factors := [2, 11, 73]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_11 | exact prime_73
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1609 : Nat.Prime 1609 := by
  refine Round2Recovery.lucas_list_prime (n := 1609) (a := 7)
    (factors := [2, 2, 2, 3, 67]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_3 | exact prime_67
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1613 : Nat.Prime 1613 := by
  refine Round2Recovery.lucas_list_prime (n := 1613) (a := 3)
    (factors := [2, 2, 13, 31]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals first | exact prime_2 | exact prime_13 | exact prime_31
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl | rfl | rfl
    all_goals decide +kernel

theorem prime_1619 : Nat.Prime 1619 := by
  refine Round2Recovery.lucas_list_prime (n := 1619) (a := 2)
    (factors := [2, 809]) (by norm_num) ?_ (by norm_num) ?_ ?_
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals first | exact prime_2 | exact prime_809
  · decide +kernel
  · intro q hq
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hq
    rcases hq with rfl | rfl
    all_goals decide +kernel

#print axioms prime_1619
end ExposureEvolution.Compact40Pratt
