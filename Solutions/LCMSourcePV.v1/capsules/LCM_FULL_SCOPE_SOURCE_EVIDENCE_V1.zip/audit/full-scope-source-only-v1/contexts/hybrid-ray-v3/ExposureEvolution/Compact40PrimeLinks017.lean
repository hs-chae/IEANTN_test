import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks017
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_56053 : next 56053 = some 56269 := by
  have hl : (List.range ((257 * 56053 - 1) / 256 - 56053)).reverse =
      [217, 216, 215] ++ (List.range 215).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_56269]

theorem next_56269 : next 56269 = some 56479 := by
  have hl : (List.range ((257 * 56269 - 1) / 256 - 56269)).reverse =
      [218, 217, 216, 215, 214, 213, 212, 211, 210, 209] ++ (List.range 209).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_56479]

theorem next_56479 : next 56479 = some 56687 := by
  have hl : (List.range ((257 * 56479 - 1) / 256 - 56479)).reverse =
      [219, 218, 217, 216, 215, 214, 213, 212, 211, 210, 209, 208, 207] ++ (List.range 207).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_56687]

theorem next_56687 : next 56687 = some 56897 := by
  have hl : (List.range ((257 * 56687 - 1) / 256 - 56687)).reverse =
      [220, 219, 218, 217, 216, 215, 214, 213, 212, 211, 210, 209] ++ (List.range 209).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_56897]

theorem next_56897 : next 56897 = some 57119 := by
  have hl : (List.range ((257 * 56897 - 1) / 256 - 56897)).reverse =
      [221] ++ (List.range 221).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_57119]

theorem next_57119 : next 57119 = some 57331 := by
  have hl : (List.range ((257 * 57119 - 1) / 256 - 57119)).reverse =
      [222, 221, 220, 219, 218, 217, 216, 215, 214, 213, 212, 211] ++ (List.range 211).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_57331]

theorem next_57331 : next 57331 = some 57529 := by
  have hl : (List.range ((257 * 57331 - 1) / 256 - 57331)).reverse =
      [222, 221, 220, 219, 218, 217, 216, 215, 214, 213, 212, 211, 210, 209, 208, 207, 206, 205, 204, 203, 202, 201, 200, 199, 198, 197] ++ (List.range 197).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_57529]

theorem next_57529 : next 57529 = some 57751 := by
  have hl : (List.range ((257 * 57529 - 1) / 256 - 57529)).reverse =
      [223, 222, 221] ++ (List.range 221).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_57751]

theorem next_57751 : next 57751 = some 57973 := by
  have hl : (List.range ((257 * 57751 - 1) / 256 - 57751)).reverse =
      [224, 223, 222, 221] ++ (List.range 221).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_57973]

theorem next_57973 : next 57973 = some 58199 := by
  have hl : (List.range ((257 * 57973 - 1) / 256 - 57973)).reverse =
      [225] ++ (List.range 225).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_58199]

theorem next_58199 : next 58199 = some 58417 := by
  have hl : (List.range ((257 * 58199 - 1) / 256 - 58199)).reverse =
      [226, 225, 224, 223, 222, 221, 220, 219, 218, 217] ++ (List.range 217).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_58417]

theorem next_58417 : next 58417 = some 58631 := by
  have hl : (List.range ((257 * 58417 - 1) / 256 - 58417)).reverse =
      [227, 226, 225, 224, 223, 222, 221, 220, 219, 218, 217, 216, 215, 214, 213] ++ (List.range 213).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_58631]

theorem next_58631 : next 58631 = some 58831 := by
  have hl : (List.range ((257 * 58631 - 1) / 256 - 58631)).reverse =
      [228, 227, 226, 225, 224, 223, 222, 221, 220, 219, 218, 217, 216, 215, 214, 213, 212, 211, 210, 209, 208, 207, 206, 205, 204, 203, 202, 201, 200, 199] ++ (List.range 199).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_58831]

theorem next_58831 : next 58831 = some 59053 := by
  have hl : (List.range ((257 * 58831 - 1) / 256 - 58831)).reverse =
      [228, 227, 226, 225, 224, 223, 222, 221] ++ (List.range 221).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_59053]

theorem next_59053 : next 59053 = some 59281 := by
  have hl : (List.range ((257 * 59053 - 1) / 256 - 59053)).reverse =
      [229, 228, 227] ++ (List.range 227).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_59281]

theorem next_59281 : next 59281 = some 59509 := by
  have hl : (List.range ((257 * 59281 - 1) / 256 - 59281)).reverse =
      [230, 229, 228, 227] ++ (List.range 227).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_59509]

theorem next_59509 : next 59509 = some 59729 := by
  have hl : (List.range ((257 * 59509 - 1) / 256 - 59509)).reverse =
      [231, 230, 229, 228, 227, 226, 225, 224, 223, 222, 221, 220, 219] ++ (List.range 219).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_59729]

theorem next_59729 : next 59729 = some 59957 := by
  have hl : (List.range ((257 * 59729 - 1) / 256 - 59729)).reverse =
      [232, 231, 230, 229, 228, 227] ++ (List.range 227).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_59957]

theorem next_59957 : next 59957 = some 60169 := by
  have hl : (List.range ((257 * 59957 - 1) / 256 - 59957)).reverse =
      [233, 232, 231, 230, 229, 228, 227, 226, 225, 224, 223, 222, 221, 220, 219, 218, 217, 216, 215, 214, 213, 212, 211] ++ (List.range 211).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_60169]

theorem next_60169 : next 60169 = some 60397 := by
  have hl : (List.range ((257 * 60169 - 1) / 256 - 60169)).reverse =
      [234, 233, 232, 231, 230, 229, 228, 227] ++ (List.range 227).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_60397]

theorem next_60397 : next 60397 = some 60631 := by
  have hl : (List.range ((257 * 60397 - 1) / 256 - 60397)).reverse =
      [234, 233] ++ (List.range 233).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_60631]

theorem next_60631 : next 60631 = some 60859 := by
  have hl : (List.range ((257 * 60631 - 1) / 256 - 60631)).reverse =
      [235, 234, 233, 232, 231, 230, 229, 228, 227] ++ (List.range 227).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_60859]

theorem next_60859 : next 60859 = some 61091 := by
  have hl : (List.range ((257 * 60859 - 1) / 256 - 60859)).reverse =
      [236, 235, 234, 233, 232, 231] ++ (List.range 231).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_61091]

theorem next_61091 : next 61091 = some 61297 := by
  have hl : (List.range ((257 * 61091 - 1) / 256 - 61091)).reverse =
      [237, 236, 235, 234, 233, 232, 231, 230, 229, 228, 227, 226, 225, 224, 223, 222, 221, 220, 219, 218, 217, 216, 215, 214, 213, 212, 211, 210, 209, 208, 207, 206, 205] ++ (List.range 205).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_61297]

theorem next_61297 : next 61297 = some 61519 := by
  have hl : (List.range ((257 * 61297 - 1) / 256 - 61297)).reverse =
      [238, 237, 236, 235, 234, 233, 232, 231, 230, 229, 228, 227, 226, 225, 224, 223, 222, 221] ++ (List.range 221).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_61519]

theorem next_61519 : next 61519 = some 61757 := by
  have hl : (List.range ((257 * 61519 - 1) / 256 - 61519)).reverse =
      [239, 238, 237] ++ (List.range 237).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_61757]

theorem next_61757 : next 61757 = some 61991 := by
  have hl : (List.range ((257 * 61757 - 1) / 256 - 61757)).reverse =
      [240, 239, 238, 237, 236, 235, 234, 233] ++ (List.range 233).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_61991]

theorem next_61991 : next 61991 = some 62233 := by
  have hl : (List.range ((257 * 61991 - 1) / 256 - 61991)).reverse =
      [241] ++ (List.range 241).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_62233]

theorem next_62233 : next 62233 = some 62473 := by
  have hl : (List.range ((257 * 62233 - 1) / 256 - 62233)).reverse =
      [242, 241, 240, 239] ++ (List.range 239).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_62473]

theorem next_62473 : next 62473 = some 62701 := by
  have hl : (List.range ((257 * 62473 - 1) / 256 - 62473)).reverse =
      [243, 242, 241, 240, 239, 238, 237, 236, 235, 234, 233, 232, 231, 230, 229, 228, 227] ++ (List.range 227).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_62701]

theorem next_62701 : next 62701 = some 62939 := by
  have hl : (List.range ((257 * 62701 - 1) / 256 - 62701)).reverse =
      [243, 242, 241, 240, 239, 238, 237] ++ (List.range 237).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_62939]

theorem next_62939 : next 62939 = some 63179 := by
  have hl : (List.range ((257 * 62939 - 1) / 256 - 62939)).reverse =
      [244, 243, 242, 241, 240, 239] ++ (List.range 239).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_63179]

def primes : List ℕ := [56269, 56479, 56687, 56897, 57119, 57331, 57529, 57751, 57973, 58199, 58417, 58631, 58831, 59053, 59281, 59509, 59729, 59957, 60169, 60397, 60631, 60859, 61091, 61297, 61519, 61757, 61991, 62233, 62473, 62701, 62939, 63179]

theorem segment : run 156 56053 89693 =
    primes ++ run 124 63179 89693 := by
  rw [Compact40PrimeCompose256.step 155 56053 89693 56269
    (by decide +kernel) next_56053]
  rw [Compact40PrimeCompose256.step 154 56269 89693 56479
    (by decide +kernel) next_56269]
  rw [Compact40PrimeCompose256.step 153 56479 89693 56687
    (by decide +kernel) next_56479]
  rw [Compact40PrimeCompose256.step 152 56687 89693 56897
    (by decide +kernel) next_56687]
  rw [Compact40PrimeCompose256.step 151 56897 89693 57119
    (by decide +kernel) next_56897]
  rw [Compact40PrimeCompose256.step 150 57119 89693 57331
    (by decide +kernel) next_57119]
  rw [Compact40PrimeCompose256.step 149 57331 89693 57529
    (by decide +kernel) next_57331]
  rw [Compact40PrimeCompose256.step 148 57529 89693 57751
    (by decide +kernel) next_57529]
  rw [Compact40PrimeCompose256.step 147 57751 89693 57973
    (by decide +kernel) next_57751]
  rw [Compact40PrimeCompose256.step 146 57973 89693 58199
    (by decide +kernel) next_57973]
  rw [Compact40PrimeCompose256.step 145 58199 89693 58417
    (by decide +kernel) next_58199]
  rw [Compact40PrimeCompose256.step 144 58417 89693 58631
    (by decide +kernel) next_58417]
  rw [Compact40PrimeCompose256.step 143 58631 89693 58831
    (by decide +kernel) next_58631]
  rw [Compact40PrimeCompose256.step 142 58831 89693 59053
    (by decide +kernel) next_58831]
  rw [Compact40PrimeCompose256.step 141 59053 89693 59281
    (by decide +kernel) next_59053]
  rw [Compact40PrimeCompose256.step 140 59281 89693 59509
    (by decide +kernel) next_59281]
  rw [Compact40PrimeCompose256.step 139 59509 89693 59729
    (by decide +kernel) next_59509]
  rw [Compact40PrimeCompose256.step 138 59729 89693 59957
    (by decide +kernel) next_59729]
  rw [Compact40PrimeCompose256.step 137 59957 89693 60169
    (by decide +kernel) next_59957]
  rw [Compact40PrimeCompose256.step 136 60169 89693 60397
    (by decide +kernel) next_60169]
  rw [Compact40PrimeCompose256.step 135 60397 89693 60631
    (by decide +kernel) next_60397]
  rw [Compact40PrimeCompose256.step 134 60631 89693 60859
    (by decide +kernel) next_60631]
  rw [Compact40PrimeCompose256.step 133 60859 89693 61091
    (by decide +kernel) next_60859]
  rw [Compact40PrimeCompose256.step 132 61091 89693 61297
    (by decide +kernel) next_61091]
  rw [Compact40PrimeCompose256.step 131 61297 89693 61519
    (by decide +kernel) next_61297]
  rw [Compact40PrimeCompose256.step 130 61519 89693 61757
    (by decide +kernel) next_61519]
  rw [Compact40PrimeCompose256.step 129 61757 89693 61991
    (by decide +kernel) next_61757]
  rw [Compact40PrimeCompose256.step 128 61991 89693 62233
    (by decide +kernel) next_61991]
  rw [Compact40PrimeCompose256.step 127 62233 89693 62473
    (by decide +kernel) next_62233]
  rw [Compact40PrimeCompose256.step 126 62473 89693 62701
    (by decide +kernel) next_62473]
  rw [Compact40PrimeCompose256.step 125 62701 89693 62939
    (by decide +kernel) next_62701]
  rw [Compact40PrimeCompose256.step 124 62939 89693 63179
    (by decide +kernel) next_62939]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 63179 stop tail = true) :
    check 56053 stop (primes ++ tail) = true := by
  change check _ _ (56269 :: 56479 :: 56687 :: 56897 :: 57119 :: 57331 :: 57529 :: 57751 :: 57973 :: 58199 :: 58417 :: 58631 :: 58831 :: 59053 :: 59281 :: 59509 :: 59729 :: 59957 :: 60169 :: 60397 :: 60631 :: 60859 :: 61091 :: 61297 :: 61519 :: 61757 :: 61991 :: 62233 :: 62473 :: 62701 :: 62939 :: 63179 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_56269, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_56479, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_56687, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_56897, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_57119, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_57331, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_57529, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_57751, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_57973, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_58199, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_58417, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_58631, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_58831, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_59053, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_59281, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_59509, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_59729, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_59957, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_60169, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_60397, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_60631, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_60859, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_61091, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_61297, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_61519, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_61757, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_61991, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_62233, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_62473, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_62701, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_62939, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_63179, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks017
