import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_007
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨35129329, 35271720, 5939, 5953, 5981, 35128913, 35129183, 35129321⟩, 7⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5939,
    ExposureEvolution.Compact40Pratt.prime_5953,
    ExposureEvolution.Compact40Pratt.prime_5981,
    ExposureEvolution.Compact40Pratt.prime_35128913,
    ExposureEvolution.Compact40Pratt.prime_35129183,
    ExposureEvolution.Compact40Pratt.prime_35129321]

def block01 : Witness := ⟨⟨35271721, 35438208, 5953, 5981, 5987, 35271421, 35271623, 35271703⟩, 15⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5953,
    ExposureEvolution.Compact40Pratt.prime_5981,
    ExposureEvolution.Compact40Pratt.prime_5987,
    ExposureEvolution.Compact40Pratt.prime_35271421,
    ExposureEvolution.Compact40Pratt.prime_35271623,
    ExposureEvolution.Compact40Pratt.prime_35271703]

def block02 : Witness := ⟨⟨35438209, 35772360, 5981, 5987, 6007, 35437663, 35438129, 35438191⟩, 8⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5981,
    ExposureEvolution.Compact40Pratt.prime_5987,
    ExposureEvolution.Compact40Pratt.prime_6007,
    ExposureEvolution.Compact40Pratt.prime_35437663,
    ExposureEvolution.Compact40Pratt.prime_35438129,
    ExposureEvolution.Compact40Pratt.prime_35438191]

def block03 : Witness := ⟨⟨35772361, 35844168, 5987, 6007, 6011, 35771909, 35772203, 35772343⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_5987,
    ExposureEvolution.Compact40Pratt.prime_6007,
    ExposureEvolution.Compact40Pratt.prime_6011,
    ExposureEvolution.Compact40Pratt.prime_35771909,
    ExposureEvolution.Compact40Pratt.prime_35772203,
    ExposureEvolution.Compact40Pratt.prime_35772343]

def block04 : Witness := ⟨⟨35844169, 36084048, 6007, 6011, 6029, 35843699, 35843879, 35844167⟩, 12⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6007,
    ExposureEvolution.Compact40Pratt.prime_6011,
    ExposureEvolution.Compact40Pratt.prime_6029,
    ExposureEvolution.Compact40Pratt.prime_35843699,
    ExposureEvolution.Compact40Pratt.prime_35843879,
    ExposureEvolution.Compact40Pratt.prime_35844167]

def block05 : Witness := ⟨⟨36084049, 36132120, 6011, 6029, 6037, 36083591, 36083897, 36084023⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6011,
    ExposureEvolution.Compact40Pratt.prime_6029,
    ExposureEvolution.Compact40Pratt.prime_6037,
    ExposureEvolution.Compact40Pratt.prime_36083591,
    ExposureEvolution.Compact40Pratt.prime_36083897,
    ExposureEvolution.Compact40Pratt.prime_36084023]

def block06 : Witness := ⟨⟨36132121, 36348840, 6029, 6037, 6043, 36131819, 36131891, 36132119⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6029,
    ExposureEvolution.Compact40Pratt.prime_6037,
    ExposureEvolution.Compact40Pratt.prime_6043,
    ExposureEvolution.Compact40Pratt.prime_36131819,
    ExposureEvolution.Compact40Pratt.prime_36131891,
    ExposureEvolution.Compact40Pratt.prime_36132119]

def block07 : Witness := ⟨⟨36348841, 36445368, 6037, 6043, 6047, 36348421, 36348731, 36348821⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6037,
    ExposureEvolution.Compact40Pratt.prime_6043,
    ExposureEvolution.Compact40Pratt.prime_6047,
    ExposureEvolution.Compact40Pratt.prime_36348421,
    ExposureEvolution.Compact40Pratt.prime_36348731,
    ExposureEvolution.Compact40Pratt.prime_36348821]

def block08 : Witness := ⟨⟨36445369, 36517848, 6043, 6047, 6053, 36444917, 36445009, 36445361⟩, 11⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6043,
    ExposureEvolution.Compact40Pratt.prime_6047,
    ExposureEvolution.Compact40Pratt.prime_6053,
    ExposureEvolution.Compact40Pratt.prime_36444917,
    ExposureEvolution.Compact40Pratt.prime_36445009,
    ExposureEvolution.Compact40Pratt.prime_36445361]

def block09 : Witness := ⟨⟨36517849, 36566208, 6047, 6053, 6067, 36517799, 36517801, 36517847⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6047,
    ExposureEvolution.Compact40Pratt.prime_6053,
    ExposureEvolution.Compact40Pratt.prime_6067,
    ExposureEvolution.Compact40Pratt.prime_36517799,
    ExposureEvolution.Compact40Pratt.prime_36517801,
    ExposureEvolution.Compact40Pratt.prime_36517847]

def block10 : Witness := ⟨⟨36566209, 36638808, 6053, 6067, 6073, 36565517, 36565873, 36566197⟩, 11⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6053,
    ExposureEvolution.Compact40Pratt.prime_6067,
    ExposureEvolution.Compact40Pratt.prime_6073,
    ExposureEvolution.Compact40Pratt.prime_36565517,
    ExposureEvolution.Compact40Pratt.prime_36565873,
    ExposureEvolution.Compact40Pratt.prime_36566197]

def block11 : Witness := ⟨⟨36638809, 36808488, 6067, 6073, 6079, 36638123, 36638443, 36638761⟩, 8⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6067,
    ExposureEvolution.Compact40Pratt.prime_6073,
    ExposureEvolution.Compact40Pratt.prime_6079,
    ExposureEvolution.Compact40Pratt.prime_36638123,
    ExposureEvolution.Compact40Pratt.prime_36638443,
    ExposureEvolution.Compact40Pratt.prime_36638761]

def block12 : Witness := ⟨⟨36808489, 36881328, 6073, 6079, 6089, 36808063, 36808273, 36808483⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6073,
    ExposureEvolution.Compact40Pratt.prime_6079,
    ExposureEvolution.Compact40Pratt.prime_6089,
    ExposureEvolution.Compact40Pratt.prime_36808063,
    ExposureEvolution.Compact40Pratt.prime_36808273,
    ExposureEvolution.Compact40Pratt.prime_36808483]

def block13 : Witness := ⟨⟨36881329, 36954240, 6079, 6089, 6091, 36880849, 36881051, 36881321⟩, 13⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6079,
    ExposureEvolution.Compact40Pratt.prime_6089,
    ExposureEvolution.Compact40Pratt.prime_6091,
    ExposureEvolution.Compact40Pratt.prime_36880849,
    ExposureEvolution.Compact40Pratt.prime_36881051,
    ExposureEvolution.Compact40Pratt.prime_36881321]

def block14 : Witness := ⟨⟨36954241, 37075920, 6089, 6091, 6101, 36954041, 36954223, 36954233⟩, 9⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6089,
    ExposureEvolution.Compact40Pratt.prime_6091,
    ExposureEvolution.Compact40Pratt.prime_6101,
    ExposureEvolution.Compact40Pratt.prime_36954041,
    ExposureEvolution.Compact40Pratt.prime_36954223,
    ExposureEvolution.Compact40Pratt.prime_36954233]

def block15 : Witness := ⟨⟨37075921, 37100280, 6091, 6101, 6113, 37075267, 37075303, 37075867⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6091,
    ExposureEvolution.Compact40Pratt.prime_6101,
    ExposureEvolution.Compact40Pratt.prime_6113,
    ExposureEvolution.Compact40Pratt.prime_37075267,
    ExposureEvolution.Compact40Pratt.prime_37075303,
    ExposureEvolution.Compact40Pratt.prime_37075867]

def block16 : Witness := ⟨⟨37100281, 37222200, 6101, 6113, 6121, 37100131, 37100177, 37100257⟩, 12⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6101,
    ExposureEvolution.Compact40Pratt.prime_6113,
    ExposureEvolution.Compact40Pratt.prime_6121,
    ExposureEvolution.Compact40Pratt.prime_37100131,
    ExposureEvolution.Compact40Pratt.prime_37100177,
    ExposureEvolution.Compact40Pratt.prime_37100257]

def block17 : Witness := ⟨⟨37222201, 37368768, 6113, 6121, 6131, 37221923, 37221949, 37222187⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6113,
    ExposureEvolution.Compact40Pratt.prime_6121,
    ExposureEvolution.Compact40Pratt.prime_6131,
    ExposureEvolution.Compact40Pratt.prime_37221923,
    ExposureEvolution.Compact40Pratt.prime_37221949,
    ExposureEvolution.Compact40Pratt.prime_37222187]

def block18 : Witness := ⟨⟨37368769, 37466640, 6121, 6131, 6133, 37368029, 37368731, 37368743⟩, 10⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6121,
    ExposureEvolution.Compact40Pratt.prime_6131,
    ExposureEvolution.Compact40Pratt.prime_6133,
    ExposureEvolution.Compact40Pratt.prime_37368029,
    ExposureEvolution.Compact40Pratt.prime_37368731,
    ExposureEvolution.Compact40Pratt.prime_37368743]

def block19 : Witness := ⟨⟨37466641, 37589160, 6131, 6133, 6143, 37466159, 37466411, 37466621⟩, 7⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6131,
    ExposureEvolution.Compact40Pratt.prime_6133,
    ExposureEvolution.Compact40Pratt.prime_6143,
    ExposureEvolution.Compact40Pratt.prime_37466159,
    ExposureEvolution.Compact40Pratt.prime_37466411,
    ExposureEvolution.Compact40Pratt.prime_37466621]

def block20 : Witness := ⟨⟨37589161, 37613688, 6133, 6143, 6151, 37588987, 37589099, 37589131⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6133,
    ExposureEvolution.Compact40Pratt.prime_6143,
    ExposureEvolution.Compact40Pratt.prime_6151,
    ExposureEvolution.Compact40Pratt.prime_37588987,
    ExposureEvolution.Compact40Pratt.prime_37589099,
    ExposureEvolution.Compact40Pratt.prime_37589131]

def block21 : Witness := ⟨⟨37613689, 37736448, 6143, 6151, 6163, 37613431, 37613473, 37613683⟩, 8⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6143,
    ExposureEvolution.Compact40Pratt.prime_6151,
    ExposureEvolution.Compact40Pratt.prime_6163,
    ExposureEvolution.Compact40Pratt.prime_37613431,
    ExposureEvolution.Compact40Pratt.prime_37613473,
    ExposureEvolution.Compact40Pratt.prime_37613683]

def block22 : Witness := ⟨⟨37736449, 37834800, 6151, 6163, 6173, 37736291, 37736339, 37736431⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6151,
    ExposureEvolution.Compact40Pratt.prime_6163,
    ExposureEvolution.Compact40Pratt.prime_6173,
    ExposureEvolution.Compact40Pratt.prime_37736291,
    ExposureEvolution.Compact40Pratt.prime_37736339,
    ExposureEvolution.Compact40Pratt.prime_37736431]

def block23 : Witness := ⟨⟨37834801, 37982568, 6163, 6173, 6197, 37834273, 37834721, 37834733⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6163,
    ExposureEvolution.Compact40Pratt.prime_6173,
    ExposureEvolution.Compact40Pratt.prime_6197,
    ExposureEvolution.Compact40Pratt.prime_37834273,
    ExposureEvolution.Compact40Pratt.prime_37834721,
    ExposureEvolution.Compact40Pratt.prime_37834733]

def block24 : Witness := ⟨⟨37982569, 38105928, 6173, 6197, 6199, 37982317, 37982381, 37982563⟩, 10⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6173,
    ExposureEvolution.Compact40Pratt.prime_6197,
    ExposureEvolution.Compact40Pratt.prime_6199,
    ExposureEvolution.Compact40Pratt.prime_37982317,
    ExposureEvolution.Compact40Pratt.prime_37982381,
    ExposureEvolution.Compact40Pratt.prime_37982563]

def block25 : Witness := ⟨⟨38105929, 38402808, 6197, 6199, 6203, 38105539, 38105593, 38105923⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6197,
    ExposureEvolution.Compact40Pratt.prime_6199,
    ExposureEvolution.Compact40Pratt.prime_6203,
    ExposureEvolution.Compact40Pratt.prime_38105539,
    ExposureEvolution.Compact40Pratt.prime_38105593,
    ExposureEvolution.Compact40Pratt.prime_38105923]

def block26 : Witness := ⟨⟨38402809, 38427600, 6199, 6203, 6211, 38402291, 38402681, 38402797⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6199,
    ExposureEvolution.Compact40Pratt.prime_6203,
    ExposureEvolution.Compact40Pratt.prime_6211,
    ExposureEvolution.Compact40Pratt.prime_38402291,
    ExposureEvolution.Compact40Pratt.prime_38402681,
    ExposureEvolution.Compact40Pratt.prime_38402797]

def block27 : Witness := ⟨⟨38427601, 38477208, 6203, 6211, 6217, 38427041, 38427047, 38427563⟩, 7⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6203,
    ExposureEvolution.Compact40Pratt.prime_6211,
    ExposureEvolution.Compact40Pratt.prime_6217,
    ExposureEvolution.Compact40Pratt.prime_38427041,
    ExposureEvolution.Compact40Pratt.prime_38427047,
    ExposureEvolution.Compact40Pratt.prime_38427563]

def block28 : Witness := ⟨⟨38477209, 38576520, 6211, 6217, 6221, 38476897, 38477083, 38477203⟩, 7⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6211,
    ExposureEvolution.Compact40Pratt.prime_6217,
    ExposureEvolution.Compact40Pratt.prime_6221,
    ExposureEvolution.Compact40Pratt.prime_38476897,
    ExposureEvolution.Compact40Pratt.prime_38477083,
    ExposureEvolution.Compact40Pratt.prime_38477203]

def block29 : Witness := ⟨⟨38576521, 38651088, 6217, 6221, 6229, 38576287, 38576477, 38576513⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6217,
    ExposureEvolution.Compact40Pratt.prime_6221,
    ExposureEvolution.Compact40Pratt.prime_6229,
    ExposureEvolution.Compact40Pratt.prime_38576287,
    ExposureEvolution.Compact40Pratt.prime_38576477,
    ExposureEvolution.Compact40Pratt.prime_38576513]

def block30 : Witness := ⟨⟨38651089, 38700840, 6221, 6229, 6247, 38650631, 38650837, 38651087⟩, 10⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6221,
    ExposureEvolution.Compact40Pratt.prime_6229,
    ExposureEvolution.Compact40Pratt.prime_6247,
    ExposureEvolution.Compact40Pratt.prime_38650631,
    ExposureEvolution.Compact40Pratt.prime_38650837,
    ExposureEvolution.Compact40Pratt.prime_38651087]

def block31 : Witness := ⟨⟨38700841, 38800440, 6229, 6247, 6257, 38700419, 38700481, 38700839⟩, 11⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6229,
    ExposureEvolution.Compact40Pratt.prime_6247,
    ExposureEvolution.Compact40Pratt.prime_6257,
    ExposureEvolution.Compact40Pratt.prime_38700419,
    ExposureEvolution.Compact40Pratt.prime_38700481,
    ExposureEvolution.Compact40Pratt.prime_38700839]

def block32 : Witness := ⟨⟨38800441, 39025008, 6247, 6257, 6263, 38799923, 38800367, 38800393⟩, 8⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6247,
    ExposureEvolution.Compact40Pratt.prime_6257,
    ExposureEvolution.Compact40Pratt.prime_6263,
    ExposureEvolution.Compact40Pratt.prime_38799923,
    ExposureEvolution.Compact40Pratt.prime_38800367,
    ExposureEvolution.Compact40Pratt.prime_38800393]

def block33 : Witness := ⟨⟨39025009, 39150048, 6257, 6263, 6269, 39024457, 39024487, 39024983⟩, 10⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6257,
    ExposureEvolution.Compact40Pratt.prime_6263,
    ExposureEvolution.Compact40Pratt.prime_6269,
    ExposureEvolution.Compact40Pratt.prime_39024457,
    ExposureEvolution.Compact40Pratt.prime_39024487,
    ExposureEvolution.Compact40Pratt.prime_39024983]

def block34 : Witness := ⟨⟨39150049, 39225168, 6263, 6269, 6271, 39149833, 39150017, 39150037⟩, 14⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6263,
    ExposureEvolution.Compact40Pratt.prime_6269,
    ExposureEvolution.Compact40Pratt.prime_6271,
    ExposureEvolution.Compact40Pratt.prime_39149833,
    ExposureEvolution.Compact40Pratt.prime_39150017,
    ExposureEvolution.Compact40Pratt.prime_39150037]

def block35 : Witness := ⟨⟨39225169, 39300360, 6269, 6271, 6277, 39224687, 39225049, 39225091⟩, 9⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6269,
    ExposureEvolution.Compact40Pratt.prime_6271,
    ExposureEvolution.Compact40Pratt.prime_6277,
    ExposureEvolution.Compact40Pratt.prime_39224687,
    ExposureEvolution.Compact40Pratt.prime_39225049,
    ExposureEvolution.Compact40Pratt.prime_39225091]

def block36 : Witness := ⟨⟨39300361, 39325440, 6271, 6277, 6287, 39299947, 39300167, 39300337⟩, 8⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6271,
    ExposureEvolution.Compact40Pratt.prime_6277,
    ExposureEvolution.Compact40Pratt.prime_6287,
    ExposureEvolution.Compact40Pratt.prime_39299947,
    ExposureEvolution.Compact40Pratt.prime_39300167,
    ExposureEvolution.Compact40Pratt.prime_39300337]

def block37 : Witness := ⟨⟨39325441, 39400728, 6277, 6287, 6299, 39324827, 39325241, 39325411⟩, 9⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6277,
    ExposureEvolution.Compact40Pratt.prime_6287,
    ExposureEvolution.Compact40Pratt.prime_6299,
    ExposureEvolution.Compact40Pratt.prime_39324827,
    ExposureEvolution.Compact40Pratt.prime_39325241,
    ExposureEvolution.Compact40Pratt.prime_39325411]

def block38 : Witness := ⟨⟨39400729, 39526368, 6287, 6299, 6301, 39400391, 39400393, 39400703⟩, 9⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6287,
    ExposureEvolution.Compact40Pratt.prime_6299,
    ExposureEvolution.Compact40Pratt.prime_6301,
    ExposureEvolution.Compact40Pratt.prime_39400391,
    ExposureEvolution.Compact40Pratt.prime_39400393,
    ExposureEvolution.Compact40Pratt.prime_39400703]

def block39 : Witness := ⟨⟨39526369, 39677400, 6299, 6301, 6311, 39525737, 39525803, 39526367⟩, 10⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6299,
    ExposureEvolution.Compact40Pratt.prime_6301,
    ExposureEvolution.Compact40Pratt.prime_6311,
    ExposureEvolution.Compact40Pratt.prime_39525737,
    ExposureEvolution.Compact40Pratt.prime_39525803,
    ExposureEvolution.Compact40Pratt.prime_39526367]

def block40 : Witness := ⟨⟨39677401, 39702600, 6301, 6311, 6317, 39676927, 39677387, 39677399⟩, 8⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6301,
    ExposureEvolution.Compact40Pratt.prime_6311,
    ExposureEvolution.Compact40Pratt.prime_6317,
    ExposureEvolution.Compact40Pratt.prime_39676927,
    ExposureEvolution.Compact40Pratt.prime_39677387,
    ExposureEvolution.Compact40Pratt.prime_39677399]

def block41 : Witness := ⟨⟨39702601, 39828720, 6311, 6317, 6323, 39701969, 39702007, 39702569⟩, 9⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6311,
    ExposureEvolution.Compact40Pratt.prime_6317,
    ExposureEvolution.Compact40Pratt.prime_6323,
    ExposureEvolution.Compact40Pratt.prime_39701969,
    ExposureEvolution.Compact40Pratt.prime_39702007,
    ExposureEvolution.Compact40Pratt.prime_39702569]

def block42 : Witness := ⟨⟨39828721, 39904488, 6317, 6323, 6329, 39828401, 39828497, 39828713⟩, 8⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6317,
    ExposureEvolution.Compact40Pratt.prime_6323,
    ExposureEvolution.Compact40Pratt.prime_6329,
    ExposureEvolution.Compact40Pratt.prime_39828401,
    ExposureEvolution.Compact40Pratt.prime_39828497,
    ExposureEvolution.Compact40Pratt.prime_39828713]

def block43 : Witness := ⟨⟨39904489, 39980328, 6323, 6329, 6337, 39904429, 39904441, 39904477⟩, 12⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6323,
    ExposureEvolution.Compact40Pratt.prime_6329,
    ExposureEvolution.Compact40Pratt.prime_6337,
    ExposureEvolution.Compact40Pratt.prime_39904429,
    ExposureEvolution.Compact40Pratt.prime_39904441,
    ExposureEvolution.Compact40Pratt.prime_39904477]

def block44 : Witness := ⟨⟨39980329, 40056240, 6329, 6337, 6343, 39980167, 39980249, 39980327⟩, 8⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6329,
    ExposureEvolution.Compact40Pratt.prime_6337,
    ExposureEvolution.Compact40Pratt.prime_6343,
    ExposureEvolution.Compact40Pratt.prime_39980167,
    ExposureEvolution.Compact40Pratt.prime_39980249,
    ExposureEvolution.Compact40Pratt.prime_39980327]

def block45 : Witness := ⟨⟨40056241, 40157568, 6337, 6343, 6353, 40055957, 40056019, 40056229⟩, 14⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6337,
    ExposureEvolution.Compact40Pratt.prime_6343,
    ExposureEvolution.Compact40Pratt.prime_6353,
    ExposureEvolution.Compact40Pratt.prime_40055957,
    ExposureEvolution.Compact40Pratt.prime_40056019,
    ExposureEvolution.Compact40Pratt.prime_40056229]

def block46 : Witness := ⟨⟨40157569, 40233648, 6343, 6353, 6359, 40157119, 40157147, 40157567⟩, 8⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6343,
    ExposureEvolution.Compact40Pratt.prime_6353,
    ExposureEvolution.Compact40Pratt.prime_6359,
    ExposureEvolution.Compact40Pratt.prime_40157119,
    ExposureEvolution.Compact40Pratt.prime_40157147,
    ExposureEvolution.Compact40Pratt.prime_40157567]

def block47 : Witness := ⟨⟨40233649, 40360608, 6353, 6359, 6361, 40233181, 40233379, 40233631⟩, 11⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6353,
    ExposureEvolution.Compact40Pratt.prime_6359,
    ExposureEvolution.Compact40Pratt.prime_6361,
    ExposureEvolution.Compact40Pratt.prime_40233181,
    ExposureEvolution.Compact40Pratt.prime_40233379,
    ExposureEvolution.Compact40Pratt.prime_40233631]

def block48 : Witness := ⟨⟨40360609, 40436880, 6359, 6361, 6367, 40360387, 40360597, 40360603⟩, 9⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6359,
    ExposureEvolution.Compact40Pratt.prime_6361,
    ExposureEvolution.Compact40Pratt.prime_6367,
    ExposureEvolution.Compact40Pratt.prime_40360387,
    ExposureEvolution.Compact40Pratt.prime_40360597,
    ExposureEvolution.Compact40Pratt.prime_40360603]

def block49 : Witness := ⟨⟨40436881, 40462320, 6361, 6367, 6373, 40436359, 40436453, 40436867⟩, 9⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6361,
    ExposureEvolution.Compact40Pratt.prime_6367,
    ExposureEvolution.Compact40Pratt.prime_6373,
    ExposureEvolution.Compact40Pratt.prime_40436359,
    ExposureEvolution.Compact40Pratt.prime_40436453,
    ExposureEvolution.Compact40Pratt.prime_40436867]

def block50 : Witness := ⟨⟨40462321, 40538688, 6367, 6373, 6379, 40461713, 40462133, 40462319⟩, 11⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6367,
    ExposureEvolution.Compact40Pratt.prime_6373,
    ExposureEvolution.Compact40Pratt.prime_6379,
    ExposureEvolution.Compact40Pratt.prime_40461713,
    ExposureEvolution.Compact40Pratt.prime_40462133,
    ExposureEvolution.Compact40Pratt.prime_40462319]

def block51 : Witness := ⟨⟨40538689, 40615128, 6373, 6379, 6389, 40538161, 40538629, 40538683⟩, 9⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6373,
    ExposureEvolution.Compact40Pratt.prime_6379,
    ExposureEvolution.Compact40Pratt.prime_6389,
    ExposureEvolution.Compact40Pratt.prime_40538161,
    ExposureEvolution.Compact40Pratt.prime_40538629,
    ExposureEvolution.Compact40Pratt.prime_40538683]

def block52 : Witness := ⟨⟨40615129, 40691640, 6379, 6389, 6397, 40614689, 40615049, 40615123⟩, 6⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6379,
    ExposureEvolution.Compact40Pratt.prime_6389,
    ExposureEvolution.Compact40Pratt.prime_6397,
    ExposureEvolution.Compact40Pratt.prime_40614689,
    ExposureEvolution.Compact40Pratt.prime_40615049,
    ExposureEvolution.Compact40Pratt.prime_40615123]

def block53 : Witness := ⟨⟨40691641, 40819320, 6389, 6397, 6421, 40691113, 40691509, 40691633⟩, 9⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6389,
    ExposureEvolution.Compact40Pratt.prime_6397,
    ExposureEvolution.Compact40Pratt.prime_6421,
    ExposureEvolution.Compact40Pratt.prime_40691113,
    ExposureEvolution.Compact40Pratt.prime_40691509,
    ExposureEvolution.Compact40Pratt.prime_40691633]

def block54 : Witness := ⟨⟨40819321, 40921608, 6397, 6421, 6427, 40819117, 40819213, 40819291⟩, 8⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6397,
    ExposureEvolution.Compact40Pratt.prime_6421,
    ExposureEvolution.Compact40Pratt.prime_6427,
    ExposureEvolution.Compact40Pratt.prime_40819117,
    ExposureEvolution.Compact40Pratt.prime_40819213,
    ExposureEvolution.Compact40Pratt.prime_40819291]

def block55 : Witness := ⟨⟨40921609, 41229240, 6421, 6427, 6449, 40921367, 40921469, 40921603⟩, 9⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6421,
    ExposureEvolution.Compact40Pratt.prime_6427,
    ExposureEvolution.Compact40Pratt.prime_6449,
    ExposureEvolution.Compact40Pratt.prime_40921367,
    ExposureEvolution.Compact40Pratt.prime_40921469,
    ExposureEvolution.Compact40Pratt.prime_40921603]

def block56 : Witness := ⟨⟨41229241, 41306328, 6427, 6449, 6451, 41229007, 41229049, 41229197⟩, 5⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6427,
    ExposureEvolution.Compact40Pratt.prime_6449,
    ExposureEvolution.Compact40Pratt.prime_6451,
    ExposureEvolution.Compact40Pratt.prime_41229007,
    ExposureEvolution.Compact40Pratt.prime_41229049,
    ExposureEvolution.Compact40Pratt.prime_41229197]

def block57 : Witness := ⟨⟨41306329, 41589600, 6449, 6451, 6469, 41305837, 41306257, 41306327⟩, 8⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6449,
    ExposureEvolution.Compact40Pratt.prime_6451,
    ExposureEvolution.Compact40Pratt.prime_6469,
    ExposureEvolution.Compact40Pratt.prime_41305837,
    ExposureEvolution.Compact40Pratt.prime_41306257,
    ExposureEvolution.Compact40Pratt.prime_41306327]

def block58 : Witness := ⟨⟨41589601, 41615400, 6451, 6469, 6473, 41589413, 41589481, 41589563⟩, 7⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6451,
    ExposureEvolution.Compact40Pratt.prime_6469,
    ExposureEvolution.Compact40Pratt.prime_6473,
    ExposureEvolution.Compact40Pratt.prime_41589413,
    ExposureEvolution.Compact40Pratt.prime_41589481,
    ExposureEvolution.Compact40Pratt.prime_41589563]

def block59 : Witness := ⟨⟨41615401, 41847960, 6469, 6473, 6481, 41614999, 41615059, 41615393⟩, 14⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6469,
    ExposureEvolution.Compact40Pratt.prime_6473,
    ExposureEvolution.Compact40Pratt.prime_6481,
    ExposureEvolution.Compact40Pratt.prime_41614999,
    ExposureEvolution.Compact40Pratt.prime_41615059,
    ExposureEvolution.Compact40Pratt.prime_41615393]

def block60 : Witness := ⟨⟨41847961, 41899728, 6473, 6481, 6491, 41847571, 41847929, 41847943⟩, 8⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6473,
    ExposureEvolution.Compact40Pratt.prime_6481,
    ExposureEvolution.Compact40Pratt.prime_6491,
    ExposureEvolution.Compact40Pratt.prime_41847571,
    ExposureEvolution.Compact40Pratt.prime_41847929,
    ExposureEvolution.Compact40Pratt.prime_41847943]

def block61 : Witness := ⟨⟨41899729, 42003360, 6481, 6491, 6521, 41899523, 41899703, 41899717⟩, 13⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6481,
    ExposureEvolution.Compact40Pratt.prime_6491,
    ExposureEvolution.Compact40Pratt.prime_6521,
    ExposureEvolution.Compact40Pratt.prime_41899523,
    ExposureEvolution.Compact40Pratt.prime_41899703,
    ExposureEvolution.Compact40Pratt.prime_41899717]

def block62 : Witness := ⟨⟨42003361, 42133080, 6491, 6521, 6529, 42002839, 42003317, 42003337⟩, 6⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6491,
    ExposureEvolution.Compact40Pratt.prime_6521,
    ExposureEvolution.Compact40Pratt.prime_6529,
    ExposureEvolution.Compact40Pratt.prime_42002839,
    ExposureEvolution.Compact40Pratt.prime_42003317,
    ExposureEvolution.Compact40Pratt.prime_42003337]

def block63 : Witness := ⟨⟨42133081, 42523440, 6521, 6529, 6547, 42132719, 42132763, 42133073⟩, 12⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6521,
    ExposureEvolution.Compact40Pratt.prime_6529,
    ExposureEvolution.Compact40Pratt.prime_6547,
    ExposureEvolution.Compact40Pratt.prime_42132719,
    ExposureEvolution.Compact40Pratt.prime_42132763,
    ExposureEvolution.Compact40Pratt.prime_42133073]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 42523441 stop tail = true) :
    coverage 35129329 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_007
