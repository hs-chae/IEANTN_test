import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks11
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨13890529, 13935288, 3733, 3739, 3761, 13890313, 13890421, 13890509⟩, 7⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3733,
    ExposureEvolution.KernelPratt.prime_3739,
    ExposureEvolution.KernelPratt.prime_3761,
    ExposureEvolution.KernelPratt.prime_13890313,
    ExposureEvolution.KernelPratt.prime_13890421,
    ExposureEvolution.KernelPratt.prime_13890509]

def block01 : Witness := ⟨⟨13935289, 13980120, 3739, 3761, 3767, 13934969, 13935161, 13935281⟩, 8⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3739,
    ExposureEvolution.KernelPratt.prime_3761,
    ExposureEvolution.KernelPratt.prime_3767,
    ExposureEvolution.KernelPratt.prime_13934969,
    ExposureEvolution.KernelPratt.prime_13935161,
    ExposureEvolution.KernelPratt.prime_13935281]

def block02 : Witness := ⟨⟨13980121, 14145120, 3761, 3767, 3769, 13979759, 13979963, 13980107⟩, 7⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3761,
    ExposureEvolution.KernelPratt.prime_3767,
    ExposureEvolution.KernelPratt.prime_3769,
    ExposureEvolution.KernelPratt.prime_13979759,
    ExposureEvolution.KernelPratt.prime_13979963,
    ExposureEvolution.KernelPratt.prime_13980107]

def block03 : Witness := ⟨⟨14145121, 14190288, 3767, 3769, 3779, 14144593, 14144671, 14145091⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3767,
    ExposureEvolution.KernelPratt.prime_3769,
    ExposureEvolution.KernelPratt.prime_3779,
    ExposureEvolution.KernelPratt.prime_14144593,
    ExposureEvolution.KernelPratt.prime_14144671,
    ExposureEvolution.KernelPratt.prime_14145091]

def block04 : Witness := ⟨⟨14190289, 14205360, 3769, 3779, 3793, 14190229, 14190269, 14190271⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3769,
    ExposureEvolution.KernelPratt.prime_3779,
    ExposureEvolution.KernelPratt.prime_3793,
    ExposureEvolution.KernelPratt.prime_14190229,
    ExposureEvolution.KernelPratt.prime_14190269,
    ExposureEvolution.KernelPratt.prime_14190271]

def block05 : Witness := ⟨⟨14205361, 14280840, 3779, 3793, 3797, 14205101, 14205281, 14205349⟩, 11⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3779,
    ExposureEvolution.KernelPratt.prime_3793,
    ExposureEvolution.KernelPratt.prime_3797,
    ExposureEvolution.KernelPratt.prime_14205101,
    ExposureEvolution.KernelPratt.prime_14205281,
    ExposureEvolution.KernelPratt.prime_14205349]

def block06 : Witness := ⟨⟨14280841, 14386848, 3793, 3797, 3803, 14280379, 14280451, 14280829⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3793,
    ExposureEvolution.KernelPratt.prime_3797,
    ExposureEvolution.KernelPratt.prime_3803,
    ExposureEvolution.KernelPratt.prime_14280379,
    ExposureEvolution.KernelPratt.prime_14280451,
    ExposureEvolution.KernelPratt.prime_14280829]

def block07 : Witness := ⟨⟨14386849, 14417208, 3797, 3803, 3821, 14386733, 14386739, 14386837⟩, 7⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3797,
    ExposureEvolution.KernelPratt.prime_3803,
    ExposureEvolution.KernelPratt.prime_3821,
    ExposureEvolution.KernelPratt.prime_14386733,
    ExposureEvolution.KernelPratt.prime_14386739,
    ExposureEvolution.KernelPratt.prime_14386837]

def block08 : Witness := ⟨⟨14417209, 14462808, 3803, 3821, 3823, 14417023, 14417149, 14417191⟩, 7⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3803,
    ExposureEvolution.KernelPratt.prime_3821,
    ExposureEvolution.KernelPratt.prime_3823,
    ExposureEvolution.KernelPratt.prime_14417023,
    ExposureEvolution.KernelPratt.prime_14417149,
    ExposureEvolution.KernelPratt.prime_14417191]

def block09 : Witness := ⟨⟨14462809, 14600040, 3821, 3823, 3833, 14462549, 14462783, 14462807⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3821,
    ExposureEvolution.KernelPratt.prime_3823,
    ExposureEvolution.KernelPratt.prime_3833,
    ExposureEvolution.KernelPratt.prime_14462549,
    ExposureEvolution.KernelPratt.prime_14462783,
    ExposureEvolution.KernelPratt.prime_14462807]

def block10 : Witness := ⟨⟨14600041, 14615328, 3823, 3833, 3847, 14599639, 14599759, 14600017⟩, 13⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3823,
    ExposureEvolution.KernelPratt.prime_3833,
    ExposureEvolution.KernelPratt.prime_3847,
    ExposureEvolution.KernelPratt.prime_14599639,
    ExposureEvolution.KernelPratt.prime_14599759,
    ExposureEvolution.KernelPratt.prime_14600017]

def block11 : Witness := ⟨⟨14615329, 14691888, 3833, 3847, 3851, 14615201, 14615239, 14615309⟩, 7⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3833,
    ExposureEvolution.KernelPratt.prime_3847,
    ExposureEvolution.KernelPratt.prime_3851,
    ExposureEvolution.KernelPratt.prime_14615201,
    ExposureEvolution.KernelPratt.prime_14615239,
    ExposureEvolution.KernelPratt.prime_14615309]

def block12 : Witness := ⟨⟨14691889, 14799408, 3847, 3851, 3853, 14691511, 14691877, 14691881⟩, 10⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3847,
    ExposureEvolution.KernelPratt.prime_3851,
    ExposureEvolution.KernelPratt.prime_3853,
    ExposureEvolution.KernelPratt.prime_14691511,
    ExposureEvolution.KernelPratt.prime_14691877,
    ExposureEvolution.KernelPratt.prime_14691881]

def block13 : Witness := ⟨⟨14799409, 14830200, 3851, 3853, 3863, 14798941, 14799397, 14799403⟩, 10⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3851,
    ExposureEvolution.KernelPratt.prime_3853,
    ExposureEvolution.KernelPratt.prime_3863,
    ExposureEvolution.KernelPratt.prime_14798941,
    ExposureEvolution.KernelPratt.prime_14799397,
    ExposureEvolution.KernelPratt.prime_14799403]

def block14 : Witness := ⟨⟨14830201, 14845608, 3853, 3863, 3877, 14829721, 14830033, 14830199⟩, 10⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3853,
    ExposureEvolution.KernelPratt.prime_3863,
    ExposureEvolution.KernelPratt.prime_3877,
    ExposureEvolution.KernelPratt.prime_14829721,
    ExposureEvolution.KernelPratt.prime_14830033,
    ExposureEvolution.KernelPratt.prime_14830199]

def block15 : Witness := ⟨⟨14845609, 14922768, 3863, 3877, 3881, 14845231, 14845469, 14845591⟩, 10⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3863,
    ExposureEvolution.KernelPratt.prime_3877,
    ExposureEvolution.KernelPratt.prime_3881,
    ExposureEvolution.KernelPratt.prime_14845231,
    ExposureEvolution.KernelPratt.prime_14845469,
    ExposureEvolution.KernelPratt.prime_14845591]

def block16 : Witness := ⟨⟨14922769, 15031128, 3877, 3881, 3889, 14922599, 14922757, 14922767⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3877,
    ExposureEvolution.KernelPratt.prime_3881,
    ExposureEvolution.KernelPratt.prime_3889,
    ExposureEvolution.KernelPratt.prime_14922599,
    ExposureEvolution.KernelPratt.prime_14922757,
    ExposureEvolution.KernelPratt.prime_14922767]

def block17 : Witness := ⟨⟨15031129, 15062160, 3881, 3889, 3907, 15030857, 15030947, 15031103⟩, 11⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3881,
    ExposureEvolution.KernelPratt.prime_3889,
    ExposureEvolution.KernelPratt.prime_3907,
    ExposureEvolution.KernelPratt.prime_15030857,
    ExposureEvolution.KernelPratt.prime_15030947,
    ExposureEvolution.KernelPratt.prime_15031103]

def block18 : Witness := ⟨⟨15062161, 15124320, 3889, 3907, 3911, 15061811, 15062057, 15062143⟩, 10⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3889,
    ExposureEvolution.KernelPratt.prime_3907,
    ExposureEvolution.KernelPratt.prime_3911,
    ExposureEvolution.KernelPratt.prime_15061811,
    ExposureEvolution.KernelPratt.prime_15062057,
    ExposureEvolution.KernelPratt.prime_15062143]

def block19 : Witness := ⟨⟨15124321, 15264648, 3907, 3911, 3917, 15124099, 15124297, 15124309⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3907,
    ExposureEvolution.KernelPratt.prime_3911,
    ExposureEvolution.KernelPratt.prime_3917,
    ExposureEvolution.KernelPratt.prime_15124099,
    ExposureEvolution.KernelPratt.prime_15124297,
    ExposureEvolution.KernelPratt.prime_15124309]

def block20 : Witness := ⟨⟨15264649, 15295920, 3911, 3917, 3919, 15264287, 15264311, 15264637⟩, 11⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3911,
    ExposureEvolution.KernelPratt.prime_3917,
    ExposureEvolution.KernelPratt.prime_3919,
    ExposureEvolution.KernelPratt.prime_15264287,
    ExposureEvolution.KernelPratt.prime_15264311,
    ExposureEvolution.KernelPratt.prime_15264637]

def block21 : Witness := ⟨⟨15295921, 15342888, 3917, 3919, 3923, 15295447, 15295717, 15295919⟩, 9⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3917,
    ExposureEvolution.KernelPratt.prime_3919,
    ExposureEvolution.KernelPratt.prime_3923,
    ExposureEvolution.KernelPratt.prime_15295447,
    ExposureEvolution.KernelPratt.prime_15295717,
    ExposureEvolution.KernelPratt.prime_15295919]

def block22 : Witness := ⟨⟨15342889, 15358560, 3919, 3923, 3929, 15342581, 15342763, 15342883⟩, 11⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3919,
    ExposureEvolution.KernelPratt.prime_3923,
    ExposureEvolution.KernelPratt.prime_3929,
    ExposureEvolution.KernelPratt.prime_15342581,
    ExposureEvolution.KernelPratt.prime_15342763,
    ExposureEvolution.KernelPratt.prime_15342883]

def block23 : Witness := ⟨⟨15358561, 15389928, 3923, 3929, 3931, 15358159, 15358373, 15358537⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3923,
    ExposureEvolution.KernelPratt.prime_3929,
    ExposureEvolution.KernelPratt.prime_3931,
    ExposureEvolution.KernelPratt.prime_15358159,
    ExposureEvolution.KernelPratt.prime_15358373,
    ExposureEvolution.KernelPratt.prime_15358537]

def block24 : Witness := ⟨⟨15389929, 15437040, 3929, 3931, 3943, 15389441, 15389519, 15389909⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3929,
    ExposureEvolution.KernelPratt.prime_3931,
    ExposureEvolution.KernelPratt.prime_3943,
    ExposureEvolution.KernelPratt.prime_15389441,
    ExposureEvolution.KernelPratt.prime_15389519,
    ExposureEvolution.KernelPratt.prime_15389909]

def block25 : Witness := ⟨⟨15437041, 15452760, 3931, 3943, 3947, 15436313, 15436373, 15436943⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3931,
    ExposureEvolution.KernelPratt.prime_3943,
    ExposureEvolution.KernelPratt.prime_3947,
    ExposureEvolution.KernelPratt.prime_15436313,
    ExposureEvolution.KernelPratt.prime_15436373,
    ExposureEvolution.KernelPratt.prime_15436943]

def block26 : Witness := ⟨⟨15452761, 15547248, 3943, 3947, 3967, 15452417, 15452443, 15452747⟩, 11⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3943,
    ExposureEvolution.KernelPratt.prime_3947,
    ExposureEvolution.KernelPratt.prime_3967,
    ExposureEvolution.KernelPratt.prime_15452417,
    ExposureEvolution.KernelPratt.prime_15452443,
    ExposureEvolution.KernelPratt.prime_15452747]

def block27 : Witness := ⟨⟨15547249, 15578808, 3947, 3967, 3989, 15547019, 15547099, 15547247⟩, 9⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3947,
    ExposureEvolution.KernelPratt.prime_3967,
    ExposureEvolution.KernelPratt.prime_3989,
    ExposureEvolution.KernelPratt.prime_15547019,
    ExposureEvolution.KernelPratt.prime_15547099,
    ExposureEvolution.KernelPratt.prime_15547247]

def block28 : Witness := ⟨⟨15578809, 15737088, 3967, 3989, 4001, 15578467, 15578779, 15578807⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3967,
    ExposureEvolution.KernelPratt.prime_3989,
    ExposureEvolution.KernelPratt.prime_4001,
    ExposureEvolution.KernelPratt.prime_15578467,
    ExposureEvolution.KernelPratt.prime_15578779,
    ExposureEvolution.KernelPratt.prime_15578807]

def block29 : Witness := ⟨⟨15737089, 15912120, 3989, 4001, 4003, 15736873, 15737023, 15737081⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3989,
    ExposureEvolution.KernelPratt.prime_4001,
    ExposureEvolution.KernelPratt.prime_4003,
    ExposureEvolution.KernelPratt.prime_15736873,
    ExposureEvolution.KernelPratt.prime_15737023,
    ExposureEvolution.KernelPratt.prime_15737081]

def block30 : Witness := ⟨⟨15912121, 16008000, 4001, 4003, 4007, 15911647, 15911717, 15912079⟩, 10⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4001,
    ExposureEvolution.KernelPratt.prime_4003,
    ExposureEvolution.KernelPratt.prime_4007,
    ExposureEvolution.KernelPratt.prime_15911647,
    ExposureEvolution.KernelPratt.prime_15911717,
    ExposureEvolution.KernelPratt.prime_15912079]

def block31 : Witness := ⟨⟨16008001, 16024008, 4003, 4007, 4013, 16007531, 16007603, 16007993⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4003,
    ExposureEvolution.KernelPratt.prime_4007,
    ExposureEvolution.KernelPratt.prime_4013,
    ExposureEvolution.KernelPratt.prime_16007531,
    ExposureEvolution.KernelPratt.prime_16007603,
    ExposureEvolution.KernelPratt.prime_16007993]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 16024009 stop tail = true) :
    coverage 13890529 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks11
