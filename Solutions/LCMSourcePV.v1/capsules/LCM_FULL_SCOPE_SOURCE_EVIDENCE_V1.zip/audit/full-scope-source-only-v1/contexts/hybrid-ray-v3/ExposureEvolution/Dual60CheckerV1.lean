import E1TwoTracks.TrackBParityCheck
import ExposureEvolution.DualAdicMathV1
namespace ExposureEvolution.Dual60CheckerV1
open Finset Nat Real E1TwoTracks.TrackB
set_option Elab.async false
set_option maxHeartbeats 3000000
structure Witness where
  block : Block
  valuation : ℕ
  deriving Repr, DecidableEq
/-- The inherited valuation field is preserved as original data; this criterion uses core72. -/
def Witness.endpoint (w : Witness) (n : ℕ) : Prop :=
  432 * (5*n+3) * w.block.A * w.block.D +
    5 * (432*n+317) * w.block.B * (72*w.block.P) ≤
    5 * (432*n+317) * w.block.B * w.block.Q
instance (w : Witness) (n : ℕ) : Decidable (w.endpoint n) := inferInstanceAs (Decidable (_ ≤ _))
def Witness.Valid (w : Witness) : Prop :=
  w.block.structureValid ∧ 72*w.block.P < w.block.Q ∧ 3 < w.block.p0 ∧
    w.endpoint w.block.lo ∧ w.endpoint w.block.hi
instance (w : Witness) : Decidable w.Valid := inferInstanceAs (Decidable (_ ∧ _))
def Witness.check (w : Witness) : Bool := decide w.Valid
noncomputable def Witness.criterion (w : Witness) (hv : w.Valid) (n : ℕ)
    (hnl : w.block.lo ≤ n) (hnh : n ≤ w.block.hi) : ExposureEvolution.DualAdicBaseV1.PowerCriterion := by
  let b := w.block
  exact {
    k := 3
    hk := by norm_num
    l := 2
    hl := by norm_num
    hthree := hv.2.2.1
    n := n
    hn := hv.1.1.trans hnl
    p := b.p
    hp := by rcases hv.1 with ⟨_, _, _, _, _, h0, h1, h2, _⟩; intro i; fin_cases i <;> assumption
    hp_mono := by
      rcases hv.1 with ⟨_, _, _, _, _, _, _, _, _, _, _, h01, h12, _⟩
      intro i j hij; fin_cases i <;> fin_cases j <;> simp_all [Block.p, b] <;> omega
    q := b.q
    hq := by rcases hv.1 with ⟨_, _, _, _, _, _, _, _, h0, h1, h2, _⟩; intro i; fin_cases i <;> assumption
    hq_mono := by
      rcases hv.1 with ⟨_, _, _, _, _, _, _, _, _, _, _, _, _, h01, h12⟩
      intro i j hij; fin_cases i <;> fin_cases j <;> simp_all [Block.q, b] <;> omega
    h_ord_1 := by
      have hs : (n : ℝ) < (b.p0 : ℝ) ^ 2 := by
        exact_mod_cast (lt_of_le_of_lt hnh hv.1.2.2.1)
      have hp : (0 : ℝ) ≤ b.p0 := by positivity
      simpa [Block.p] using (Real.sqrt_lt (by positivity) hp).mpr hs
    h_ord_2 := hv.1.2.2.2.1
    h_ord_3 := hv.1.2.2.2.2.1.trans_le hnl
    h_product := by
      simpa [Block.P, Block.Q, Block.p, Block.q, Fin.prod_univ_three] using hv.2.1
  }

theorem Witness.endpoint_sound (w : Witness) (hv : w.Valid) (n : ℕ)
    (hnl : w.block.lo ≤ n) (hnh : n ≤ w.block.hi) :
    432 * (5*(n:ℝ)+3) * w.block.A * w.block.D +
      5 * (432*(n:ℝ)+317) * w.block.B * (72*w.block.P) ≤
      5 * (432*(n:ℝ)+317) * w.block.B * w.block.Q := by
  have hl : 432 * (5*(w.block.lo:ℝ)+3) * w.block.A * w.block.D +
      5 * (432*(w.block.lo:ℝ)+317) * w.block.B * (72*w.block.P) ≤
      5 * (432*(w.block.lo:ℝ)+317) * w.block.B * w.block.Q := by exact_mod_cast hv.2.2.2.1
  have hh : 432 * (5*(w.block.hi:ℝ)+3) * w.block.A * w.block.D +
      5 * (432*(w.block.hi:ℝ)+317) * w.block.B * (72*w.block.P) ≤
      5 * (432*(w.block.hi:ℝ)+317) * w.block.B * w.block.Q := by exact_mod_cast hv.2.2.2.2
  have ha := affine_endpoints
    (a := 2160*(w.block.A:ℝ)*w.block.D + 155520*w.block.B*w.block.P)
    (b := 1296*(w.block.A:ℝ)*w.block.D + 114120*w.block.B*w.block.P)
    (c := 2160*(w.block.B:ℝ)*w.block.Q) (d := 1585*(w.block.B:ℝ)*w.block.Q)
    (l := w.block.lo) (h := w.block.hi) (x := n)
    (by nlinarith [hl]) (by nlinarith [hh]) (by exact_mod_cast hnl) (by exact_mod_cast hnh)
  nlinarith [ha]

theorem Witness.ratio (w : Witness) (hv : w.Valid) (n : ℕ)
    (hnl : w.block.lo ≤ n) (hnh : n ≤ w.block.hi) :
    (1 + 3 / (5 * (n : ℝ))) * ∏ i, (1 + (1 : ℝ) / w.block.q i) ≤
      (∏ i, (1 + 1 / (w.block.p i * (w.block.p i + 1) : ℝ))) *
      (1 + 317 / (432 * (n:ℝ))) *
      (1 - (72 * ∏ i, (w.block.p i : ℝ)) / ∏ i, (w.block.q i : ℝ)) := by
  rcases hv.1 with ⟨hl, hle, hs, hpq, hql, hp0, hp1, hp2, hq0, hq1, hq2, hp01, hp12, hq01, hq12⟩
  have hn : (0 : ℝ) < n := by
    exact_mod_cast (lt_of_lt_of_le (by decide : 0 < 1) (hl.trans hnl))
  have hp0' : (0 : ℝ) < w.block.p0 := by exact_mod_cast hp0.pos
  have hp1' : (0 : ℝ) < w.block.p1 := by exact_mod_cast hp1.pos
  have hp2' : (0 : ℝ) < w.block.p2 := by exact_mod_cast hp2.pos
  have hq0' : (0 : ℝ) < w.block.q0 := by exact_mod_cast hq0.pos
  have hq1' : (0 : ℝ) < w.block.q1 := by exact_mod_cast hq1.pos
  have hq2' : (0 : ℝ) < w.block.q2 := by exact_mod_cast hq2.pos
  have hD : (0 : ℝ) < w.block.D := by dsimp [Block.D]; push_cast; positivity
  have hQ : (0 : ℝ) < w.block.Q := by dsimp [Block.Q]; push_cast; positivity
  have hratQ : (∏ i, (1 + (1 : ℝ) / w.block.q i)) = (w.block.A : ℝ) / w.block.Q := by
    simp [Fin.prod_univ_three, Block.q, Block.A, Block.Q]
    field_simp <;> ring
  have hratP : (∏ i, (1 + 1 / (w.block.p i * (w.block.p i + 1) : ℝ))) =
      (w.block.B : ℝ) / w.block.D := by
    simp [Fin.prod_univ_three, Block.p, Block.B, Block.D]
    field_simp <;> ring
  have hprodP : (∏ i, (w.block.p i : ℝ)) = (w.block.P : ℝ) := by
    simp [Fin.prod_univ_three, Block.p, Block.P]
  have hprodQ : (∏ i, (w.block.q i : ℝ)) = (w.block.Q : ℝ) := by
    simp [Fin.prod_univ_three, Block.q, Block.Q]
  rw [hratQ, hratP, hprodP, hprodQ]
  have he := w.endpoint_sound hv n hnl hnh
  have he' : 432 * (5*(n:ℝ)+3) * w.block.A * w.block.D ≤
      5 * (432*(n:ℝ)+317) * w.block.B * (w.block.Q-72*w.block.P) := by nlinarith [he]
  apply (mul_le_mul_iff_right₀ (show (0 : ℝ) < 432 * 5 * n * w.block.D * w.block.Q by positivity)).mp
  convert he' using 1 <;> (try rfl) <;> (try field_simp [hn.ne', hD.ne', hQ.ne']) <;> push_cast <;> ring

theorem Witness.sound (w : Witness) (hw : w.check = true) (n : ℕ)
    (hnl : w.block.lo ≤ n) (hnh : n ≤ w.block.hi) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hv : w.Valid := of_decide_eq_true hw
  let c := w.criterion hv n hnl hnh
  have hn : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num:0<1) c.hn)
  have hfloor : (0:ℝ) ≤ 1 - (72 * ∏ i, (c.p i : ℝ)) / ∏ i, (c.q i : ℝ) := by
    apply sub_nonneg.mpr
    apply (div_le_one (Finset.prod_pos fun i _ => by exact_mod_cast (c.hq i).pos)).mpr
    have hp := c.h_product
    norm_num only [Nat.reducePow] at hp
    exact_mod_cast hp.le
  have hcore : (1 + 317 / (432 * (n:ℝ))) ≤
      ExposureEvolution.DualAdicMathV1.core2 c * ExposureEvolution.DualAdicMathV1.core3 c := by
    dsimp [ExposureEvolution.DualAdicMathV1.core2,ExposureEvolution.DualAdicMathV1.core3,c,Witness.criterion]
    norm_num
    field_simp
    nlinarith [sq_nonneg (n:ℝ)]
  refine ⟨c.M,c.M_pos,c.M_lt,?_⟩
  apply ExposureEvolution.DualAdicMathV1.criterion_surplus c (t := 3/(5*(n:ℝ))) (by positivity)
  have hh := w.ratio hv n hnl hnh
  change (1+3/(5*(n:ℝ))) * ∏ i,(1+(1:ℝ)/c.q i) ≤
    (∏ i,(1+1/(c.p i*(c.p i+1):ℝ))) * (1+317/(432*(n:ℝ))) *
    (1-(72*∏ i,(c.p i:ℝ))/∏ i,(c.q i:ℝ)) at hh
  have hm := mul_le_mul_of_nonneg_left hcore
    (show (0:ℝ) ≤ (∏ i,(1+1/(c.p i*(c.p i+1):ℝ))) *
      (1-(72*∏ i,(c.p i:ℝ))/∏ i,(c.q i:ℝ)) from mul_nonneg (by positivity) hfloor)
  norm_num [c,Witness.criterion] at *
  nlinarith

#print axioms Witness.sound

/-- Every adjacent interval and the final endpoint are independently checked. -/
def coverage : ℕ → ℕ → List Witness → Bool
  | lo, stop, [] => decide (stop ≤ lo)
  | lo, stop, w :: ws =>
      decide (w.block.lo = lo) && w.check && coverage (w.block.hi + 1) stop ws

theorem coverage_sound (lo stop : ℕ) (ws : List Witness)
    (hc : coverage lo stop ws = true) (n : ℕ) (hn : lo ≤ n ∧ n < stop) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (5 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  induction ws generalizing lo with
  | nil =>
      have hstop : stop ≤ lo := by simpa only [coverage, decide_eq_true_eq] using hc
      omega
  | cons w ws ih =>
      simp only [coverage, Bool.and_eq_true, decide_eq_true_eq] at hc
      rcases hc with ⟨⟨hlo, hw⟩, htail⟩
      by_cases hhigh : n ≤ w.block.hi
      · exact w.sound hw n (hlo ▸ hn.1) hhigh
      · exact ih (w.block.hi + 1) htail ⟨by omega, hn.2⟩

#print axioms coverage_sound
end ExposureEvolution.Dual60CheckerV1
