import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks27
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨67749361, 67782288, 8233, 8237, 8243, 67749181, 67749251, 67749349⟩, 9⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8233,
    ExposureEvolution.KernelPratt.prime_8237,
    ExposureEvolution.KernelPratt.prime_8243,
    ExposureEvolution.KernelPratt.prime_67749181,
    ExposureEvolution.KernelPratt.prime_67749251,
    ExposureEvolution.KernelPratt.prime_67749349]

def block01 : Witness := ⟨⟨67782289, 67848168, 8237, 8243, 8263, 67781801, 67781893, 67782277⟩, 10⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8237,
    ExposureEvolution.KernelPratt.prime_8243,
    ExposureEvolution.KernelPratt.prime_8263,
    ExposureEvolution.KernelPratt.prime_67781801,
    ExposureEvolution.KernelPratt.prime_67781893,
    ExposureEvolution.KernelPratt.prime_67782277]

def block02 : Witness := ⟨⟨67848169, 67947048, 8243, 8263, 8269, 67847777, 67847779, 67848167⟩, 12⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8243,
    ExposureEvolution.KernelPratt.prime_8263,
    ExposureEvolution.KernelPratt.prime_8269,
    ExposureEvolution.KernelPratt.prime_67847777,
    ExposureEvolution.KernelPratt.prime_67847779,
    ExposureEvolution.KernelPratt.prime_67848167]

def block03 : Witness := ⟨⟨67947049, 68277168, 8263, 8269, 8273, 67946743, 67946939, 67947023⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8263,
    ExposureEvolution.KernelPratt.prime_8269,
    ExposureEvolution.KernelPratt.prime_8273,
    ExposureEvolution.KernelPratt.prime_67946743,
    ExposureEvolution.KernelPratt.prime_67946939,
    ExposureEvolution.KernelPratt.prime_67947023]

def block04 : Witness := ⟨⟨68277169, 68376360, 8269, 8273, 8287, 68276683, 68277149, 68277161⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8269,
    ExposureEvolution.KernelPratt.prime_8273,
    ExposureEvolution.KernelPratt.prime_8287,
    ExposureEvolution.KernelPratt.prime_68276683,
    ExposureEvolution.KernelPratt.prime_68277149,
    ExposureEvolution.KernelPratt.prime_68277161]

def block05 : Witness := ⟨⟨68376361, 68442528, 8273, 8287, 8291, 68375999, 68376179, 68376349⟩, 11⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8273,
    ExposureEvolution.KernelPratt.prime_8287,
    ExposureEvolution.KernelPratt.prime_8291,
    ExposureEvolution.KernelPratt.prime_68375999,
    ExposureEvolution.KernelPratt.prime_68376179,
    ExposureEvolution.KernelPratt.prime_68376349]

def block06 : Witness := ⟨⟨68442529, 68674368, 8287, 8291, 8293, 68442091, 68442167, 68442499⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8287,
    ExposureEvolution.KernelPratt.prime_8291,
    ExposureEvolution.KernelPratt.prime_8293,
    ExposureEvolution.KernelPratt.prime_68442091,
    ExposureEvolution.KernelPratt.prime_68442167,
    ExposureEvolution.KernelPratt.prime_68442499]

def block07 : Witness := ⟨⟨68674369, 68740680, 8291, 8293, 8297, 68674049, 68674153, 68674367⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8291,
    ExposureEvolution.KernelPratt.prime_8293,
    ExposureEvolution.KernelPratt.prime_8297,
    ExposureEvolution.KernelPratt.prime_68674049,
    ExposureEvolution.KernelPratt.prime_68674153,
    ExposureEvolution.KernelPratt.prime_68674367]

def block08 : Witness := ⟨⟨68740681, 68773848, 8293, 8297, 8311, 68740319, 68740481, 68740627⟩, 6⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8293,
    ExposureEvolution.KernelPratt.prime_8297,
    ExposureEvolution.KernelPratt.prime_8311,
    ExposureEvolution.KernelPratt.prime_68740319,
    ExposureEvolution.KernelPratt.prime_68740481,
    ExposureEvolution.KernelPratt.prime_68740627]

def block09 : Witness := ⟨⟨68773849, 68840208, 8297, 8311, 8317, 68773631, 68773651, 68773843⟩, 13⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8297,
    ExposureEvolution.KernelPratt.prime_8311,
    ExposureEvolution.KernelPratt.prime_8317,
    ExposureEvolution.KernelPratt.prime_68773631,
    ExposureEvolution.KernelPratt.prime_68773651,
    ExposureEvolution.KernelPratt.prime_68773843]

def block10 : Witness := ⟨⟨68840209, 69072720, 8311, 8317, 8329, 68839973, 68840099, 68840201⟩, 13⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8311,
    ExposureEvolution.KernelPratt.prime_8317,
    ExposureEvolution.KernelPratt.prime_8329,
    ExposureEvolution.KernelPratt.prime_68839973,
    ExposureEvolution.KernelPratt.prime_68840099,
    ExposureEvolution.KernelPratt.prime_68840201]

def block11 : Witness := ⟨⟨69072721, 69172488, 8317, 8329, 8353, 69072571, 69072709, 69072713⟩, 11⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8317,
    ExposureEvolution.KernelPratt.prime_8329,
    ExposureEvolution.KernelPratt.prime_8353,
    ExposureEvolution.KernelPratt.prime_69072571,
    ExposureEvolution.KernelPratt.prime_69072709,
    ExposureEvolution.KernelPratt.prime_69072713]

def block12 : Witness := ⟨⟨69172489, 69372240, 8329, 8353, 8363, 69172093, 69172139, 69172469⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8329,
    ExposureEvolution.KernelPratt.prime_8353,
    ExposureEvolution.KernelPratt.prime_8363,
    ExposureEvolution.KernelPratt.prime_69172093,
    ExposureEvolution.KernelPratt.prime_69172139,
    ExposureEvolution.KernelPratt.prime_69172469]

def block13 : Witness := ⟨⟨69372241, 69772608, 8353, 8363, 8369, 69371803, 69372049, 69372239⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8353,
    ExposureEvolution.KernelPratt.prime_8363,
    ExposureEvolution.KernelPratt.prime_8369,
    ExposureEvolution.KernelPratt.prime_69371803,
    ExposureEvolution.KernelPratt.prime_69372049,
    ExposureEvolution.KernelPratt.prime_69372239]

def block14 : Witness := ⟨⟨69772609, 69939768, 8363, 8369, 8377, 69772243, 69772387, 69772603⟩, 9⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8363,
    ExposureEvolution.KernelPratt.prime_8369,
    ExposureEvolution.KernelPratt.prime_8377,
    ExposureEvolution.KernelPratt.prime_69772243,
    ExposureEvolution.KernelPratt.prime_69772387,
    ExposureEvolution.KernelPratt.prime_69772603]

def block15 : Witness := ⟨⟨69939769, 70040160, 8369, 8377, 8387, 69939517, 69939553, 69939761⟩, 11⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8369,
    ExposureEvolution.KernelPratt.prime_8377,
    ExposureEvolution.KernelPratt.prime_8387,
    ExposureEvolution.KernelPratt.prime_69939517,
    ExposureEvolution.KernelPratt.prime_69939553,
    ExposureEvolution.KernelPratt.prime_69939761]

def block16 : Witness := ⟨⟨70040161, 70174128, 8377, 8387, 8389, 70039997, 70040107, 70040123⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8377,
    ExposureEvolution.KernelPratt.prime_8387,
    ExposureEvolution.KernelPratt.prime_8389,
    ExposureEvolution.KernelPratt.prime_70039997,
    ExposureEvolution.KernelPratt.prime_70040107,
    ExposureEvolution.KernelPratt.prime_70040123]

def block17 : Witness := ⟨⟨70174129, 70341768, 8387, 8389, 8419, 70173629, 70174063, 70174123⟩, 9⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8387,
    ExposureEvolution.KernelPratt.prime_8389,
    ExposureEvolution.KernelPratt.prime_8419,
    ExposureEvolution.KernelPratt.prime_70173629,
    ExposureEvolution.KernelPratt.prime_70174063,
    ExposureEvolution.KernelPratt.prime_70174123]

def block18 : Witness := ⟨⟨70341769, 70375320, 8389, 8419, 8423, 70341533, 70341721, 70341757⟩, 8⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8389,
    ExposureEvolution.KernelPratt.prime_8419,
    ExposureEvolution.KernelPratt.prime_8423,
    ExposureEvolution.KernelPratt.prime_70341533,
    ExposureEvolution.KernelPratt.prime_70341721,
    ExposureEvolution.KernelPratt.prime_70341757]

def block19 : Witness := ⟨⟨70375321, 70879560, 8419, 8423, 8429, 70375231, 70375243, 70375313⟩, 10⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8419,
    ExposureEvolution.KernelPratt.prime_8423,
    ExposureEvolution.KernelPratt.prime_8429,
    ExposureEvolution.KernelPratt.prime_70375231,
    ExposureEvolution.KernelPratt.prime_70375243,
    ExposureEvolution.KernelPratt.prime_70375313]

def block20 : Witness := ⟨⟨70879561, 70946928, 8423, 8429, 8431, 70879033, 70879091, 70879493⟩, 9⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8423,
    ExposureEvolution.KernelPratt.prime_8429,
    ExposureEvolution.KernelPratt.prime_8431,
    ExposureEvolution.KernelPratt.prime_70879033,
    ExposureEvolution.KernelPratt.prime_70879091,
    ExposureEvolution.KernelPratt.prime_70879493]

def block21 : Witness := ⟨⟨70946929, 71048040, 8429, 8431, 8443, 70946459, 70946747, 70946921⟩, 10⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8429,
    ExposureEvolution.KernelPratt.prime_8431,
    ExposureEvolution.KernelPratt.prime_8443,
    ExposureEvolution.KernelPratt.prime_70946459,
    ExposureEvolution.KernelPratt.prime_70946747,
    ExposureEvolution.KernelPratt.prime_70946921]

def block22 : Witness := ⟨⟨71048041, 71081760, 8431, 8443, 8447, 71047637, 71047891, 71048017⟩, 8⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8431,
    ExposureEvolution.KernelPratt.prime_8443,
    ExposureEvolution.KernelPratt.prime_8447,
    ExposureEvolution.KernelPratt.prime_71047637,
    ExposureEvolution.KernelPratt.prime_71047891,
    ExposureEvolution.KernelPratt.prime_71048017]

def block23 : Witness := ⟨⟨71081761, 71284248, 8443, 8447, 8461, 71081243, 71081509, 71081701⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8443,
    ExposureEvolution.KernelPratt.prime_8447,
    ExposureEvolution.KernelPratt.prime_8461,
    ExposureEvolution.KernelPratt.prime_71081243,
    ExposureEvolution.KernelPratt.prime_71081509,
    ExposureEvolution.KernelPratt.prime_71081701]

def block24 : Witness := ⟨⟨71284249, 71351808, 8447, 8461, 8467, 71283889, 71284063, 71284229⟩, 10⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8447,
    ExposureEvolution.KernelPratt.prime_8461,
    ExposureEvolution.KernelPratt.prime_8467,
    ExposureEvolution.KernelPratt.prime_71283889,
    ExposureEvolution.KernelPratt.prime_71284063,
    ExposureEvolution.KernelPratt.prime_71284229]

def block25 : Witness := ⟨⟨71351809, 71588520, 8461, 8467, 8501, 71351347, 71351719, 71351789⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8461,
    ExposureEvolution.KernelPratt.prime_8467,
    ExposureEvolution.KernelPratt.prime_8501,
    ExposureEvolution.KernelPratt.prime_71351347,
    ExposureEvolution.KernelPratt.prime_71351719,
    ExposureEvolution.KernelPratt.prime_71351789]

def block26 : Witness := ⟨⟨71588521, 71690088, 8467, 8501, 8513, 71588119, 71588353, 71588509⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8467,
    ExposureEvolution.KernelPratt.prime_8501,
    ExposureEvolution.KernelPratt.prime_8513,
    ExposureEvolution.KernelPratt.prime_71588119,
    ExposureEvolution.KernelPratt.prime_71588353,
    ExposureEvolution.KernelPratt.prime_71588509]

def block27 : Witness := ⟨⟨71690089, 71707023, 8501, 8513, 8521, 71689483, 71689837, 71690083⟩, 9⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_8501,
    ExposureEvolution.KernelPratt.prime_8513,
    ExposureEvolution.KernelPratt.prime_8521,
    ExposureEvolution.KernelPratt.prime_71689483,
    ExposureEvolution.KernelPratt.prime_71689837,
    ExposureEvolution.KernelPratt.prime_71690083]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 71707024 stop tail = true) :
    coverage 67749361 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks27
