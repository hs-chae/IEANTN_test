import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks09
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨10374841, 10426440, 3229, 3251, 3253, 10374281, 10374773, 10374839⟩, 9⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3229,
    ExposureEvolution.KernelPratt.prime_3251,
    ExposureEvolution.KernelPratt.prime_3253,
    ExposureEvolution.KernelPratt.prime_10374281,
    ExposureEvolution.KernelPratt.prime_10374773,
    ExposureEvolution.KernelPratt.prime_10374839]

def block01 : Witness := ⟨⟨10426441, 10569000, 3251, 3253, 3257, 10426043, 10426363, 10426417⟩, 8⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3251,
    ExposureEvolution.KernelPratt.prime_3253,
    ExposureEvolution.KernelPratt.prime_3257,
    ExposureEvolution.KernelPratt.prime_10426043,
    ExposureEvolution.KernelPratt.prime_10426363,
    ExposureEvolution.KernelPratt.prime_10426417]

def block02 : Witness := ⟨⟨10569001, 10582008, 3253, 3257, 3259, 10568471, 10568653, 10568993⟩, 11⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3253,
    ExposureEvolution.KernelPratt.prime_3257,
    ExposureEvolution.KernelPratt.prime_3259,
    ExposureEvolution.KernelPratt.prime_10568471,
    ExposureEvolution.KernelPratt.prime_10568653,
    ExposureEvolution.KernelPratt.prime_10568993]

def block03 : Witness := ⟨⟨10582009, 10608048, 3257, 3259, 3271, 10581517, 10581937, 10581959⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3257,
    ExposureEvolution.KernelPratt.prime_3259,
    ExposureEvolution.KernelPratt.prime_3271,
    ExposureEvolution.KernelPratt.prime_10581517,
    ExposureEvolution.KernelPratt.prime_10581937,
    ExposureEvolution.KernelPratt.prime_10581959]

def block04 : Witness := ⟨⟨10608049, 10621080, 3259, 3271, 3299, 10607449, 10607819, 10608029⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3259,
    ExposureEvolution.KernelPratt.prime_3271,
    ExposureEvolution.KernelPratt.prime_3299,
    ExposureEvolution.KernelPratt.prime_10607449,
    ExposureEvolution.KernelPratt.prime_10607819,
    ExposureEvolution.KernelPratt.prime_10608029]

def block05 : Witness := ⟨⟨10621081, 10699440, 3271, 3299, 3301, 10620947, 10620977, 10621063⟩, 13⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3271,
    ExposureEvolution.KernelPratt.prime_3299,
    ExposureEvolution.KernelPratt.prime_3301,
    ExposureEvolution.KernelPratt.prime_10620947,
    ExposureEvolution.KernelPratt.prime_10620977,
    ExposureEvolution.KernelPratt.prime_10621063]

def block06 : Witness := ⟨⟨10699441, 10883400, 3299, 3301, 3307, 10698911, 10698983, 10699421⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3299,
    ExposureEvolution.KernelPratt.prime_3301,
    ExposureEvolution.KernelPratt.prime_3307,
    ExposureEvolution.KernelPratt.prime_10698911,
    ExposureEvolution.KernelPratt.prime_10698983,
    ExposureEvolution.KernelPratt.prime_10699421]

def block07 : Witness := ⟨⟨10883401, 10896600, 3301, 3307, 3313, 10883269, 10883321, 10883399⟩, 7⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3301,
    ExposureEvolution.KernelPratt.prime_3307,
    ExposureEvolution.KernelPratt.prime_3313,
    ExposureEvolution.KernelPratt.prime_10883269,
    ExposureEvolution.KernelPratt.prime_10883321,
    ExposureEvolution.KernelPratt.prime_10883399]

def block08 : Witness := ⟨⟨10896601, 10936248, 3307, 3313, 3319, 10896341, 10896539, 10896577⟩, 11⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3307,
    ExposureEvolution.KernelPratt.prime_3313,
    ExposureEvolution.KernelPratt.prime_3319,
    ExposureEvolution.KernelPratt.prime_10896341,
    ExposureEvolution.KernelPratt.prime_10896539,
    ExposureEvolution.KernelPratt.prime_10896577]

def block09 : Witness := ⟨⟨10936249, 10975968, 3313, 3319, 3323, 10935713, 10936169, 10936243⟩, 10⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3313,
    ExposureEvolution.KernelPratt.prime_3319,
    ExposureEvolution.KernelPratt.prime_3323,
    ExposureEvolution.KernelPratt.prime_10935713,
    ExposureEvolution.KernelPratt.prime_10936169,
    ExposureEvolution.KernelPratt.prime_10936243]

def block10 : Witness := ⟨⟨10975969, 11015760, 3319, 3323, 3329, 10975681, 10975831, 10975967⟩, 7⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3319,
    ExposureEvolution.KernelPratt.prime_3323,
    ExposureEvolution.KernelPratt.prime_3329,
    ExposureEvolution.KernelPratt.prime_10975681,
    ExposureEvolution.KernelPratt.prime_10975831,
    ExposureEvolution.KernelPratt.prime_10975967]

def block11 : Witness := ⟨⟨11015761, 11042328, 3323, 3329, 3331, 11015461, 11015663, 11015743⟩, 12⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3323,
    ExposureEvolution.KernelPratt.prime_3329,
    ExposureEvolution.KernelPratt.prime_3331,
    ExposureEvolution.KernelPratt.prime_11015461,
    ExposureEvolution.KernelPratt.prime_11015663,
    ExposureEvolution.KernelPratt.prime_11015743]

def block12 : Witness := ⟨⟨11042329, 11082240, 3329, 3331, 3343, 11041777, 11042131, 11042309⟩, 11⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3329,
    ExposureEvolution.KernelPratt.prime_3331,
    ExposureEvolution.KernelPratt.prime_3343,
    ExposureEvolution.KernelPratt.prime_11041777,
    ExposureEvolution.KernelPratt.prime_11042131,
    ExposureEvolution.KernelPratt.prime_11042309]

def block13 : Witness := ⟨⟨11082241, 11095560, 3331, 3343, 3347, 11082133, 11082193, 11082233⟩, 9⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3331,
    ExposureEvolution.KernelPratt.prime_3343,
    ExposureEvolution.KernelPratt.prime_3347,
    ExposureEvolution.KernelPratt.prime_11082133,
    ExposureEvolution.KernelPratt.prime_11082193,
    ExposureEvolution.KernelPratt.prime_11082233]

def block14 : Witness := ⟨⟨11095561, 11175648, 3343, 3347, 3359, 11095211, 11095439, 11095559⟩, 10⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3343,
    ExposureEvolution.KernelPratt.prime_3347,
    ExposureEvolution.KernelPratt.prime_3359,
    ExposureEvolution.KernelPratt.prime_11095211,
    ExposureEvolution.KernelPratt.prime_11095439,
    ExposureEvolution.KernelPratt.prime_11095559]

def block15 : Witness := ⟨⟨11175649, 11202408, 3347, 3359, 3361, 11175491, 11175503, 11175617⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3347,
    ExposureEvolution.KernelPratt.prime_3359,
    ExposureEvolution.KernelPratt.prime_3361,
    ExposureEvolution.KernelPratt.prime_11175491,
    ExposureEvolution.KernelPratt.prime_11175503,
    ExposureEvolution.KernelPratt.prime_11175617]

def block16 : Witness := ⟨⟨11202409, 11282880, 3359, 3361, 3371, 11202073, 11202293, 11202349⟩, 7⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3359,
    ExposureEvolution.KernelPratt.prime_3361,
    ExposureEvolution.KernelPratt.prime_3371,
    ExposureEvolution.KernelPratt.prime_11202073,
    ExposureEvolution.KernelPratt.prime_11202293,
    ExposureEvolution.KernelPratt.prime_11202349]

def block17 : Witness := ⟨⟨11282881, 11296320, 3361, 3371, 3373, 11282779, 11282839, 11282879⟩, 11⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3361,
    ExposureEvolution.KernelPratt.prime_3371,
    ExposureEvolution.KernelPratt.prime_3373,
    ExposureEvolution.KernelPratt.prime_11282779,
    ExposureEvolution.KernelPratt.prime_11282839,
    ExposureEvolution.KernelPratt.prime_11282879]

def block18 : Witness := ⟨⟨11296321, 11363640, 3371, 3373, 3389, 11296223, 11296253, 11296301⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3371,
    ExposureEvolution.KernelPratt.prime_3373,
    ExposureEvolution.KernelPratt.prime_3389,
    ExposureEvolution.KernelPratt.prime_11296223,
    ExposureEvolution.KernelPratt.prime_11296253,
    ExposureEvolution.KernelPratt.prime_11296301]

def block19 : Witness := ⟨⟨11363641, 11377128, 3373, 3389, 3391, 11363243, 11363249, 11363617⟩, 11⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3373,
    ExposureEvolution.KernelPratt.prime_3389,
    ExposureEvolution.KernelPratt.prime_3391,
    ExposureEvolution.KernelPratt.prime_11363243,
    ExposureEvolution.KernelPratt.prime_11363249,
    ExposureEvolution.KernelPratt.prime_11363617]

def block20 : Witness := ⟨⟨11377129, 11485320, 3389, 3391, 3407, 11376571, 11376581, 11377127⟩, 7⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3389,
    ExposureEvolution.KernelPratt.prime_3391,
    ExposureEvolution.KernelPratt.prime_3407,
    ExposureEvolution.KernelPratt.prime_11376571,
    ExposureEvolution.KernelPratt.prime_11376581,
    ExposureEvolution.KernelPratt.prime_11377127]

def block21 : Witness := ⟨⟨11485321, 11498880, 3391, 3407, 3413, 11485079, 11485151, 11485277⟩, 9⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3391,
    ExposureEvolution.KernelPratt.prime_3407,
    ExposureEvolution.KernelPratt.prime_3413,
    ExposureEvolution.KernelPratt.prime_11485079,
    ExposureEvolution.KernelPratt.prime_11485151,
    ExposureEvolution.KernelPratt.prime_11485277]

def block22 : Witness := ⟨⟨11498881, 11607648, 3407, 3413, 3433, 11498789, 11498813, 11498843⟩, 8⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3407,
    ExposureEvolution.KernelPratt.prime_3413,
    ExposureEvolution.KernelPratt.prime_3433,
    ExposureEvolution.KernelPratt.prime_11498789,
    ExposureEvolution.KernelPratt.prime_11498813,
    ExposureEvolution.KernelPratt.prime_11498843]

def block23 : Witness := ⟨⟨11607649, 11648568, 3413, 3433, 3449, 11607289, 11607523, 11607623⟩, 10⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3413,
    ExposureEvolution.KernelPratt.prime_3433,
    ExposureEvolution.KernelPratt.prime_3449,
    ExposureEvolution.KernelPratt.prime_11607289,
    ExposureEvolution.KernelPratt.prime_11607523,
    ExposureEvolution.KernelPratt.prime_11607623]

def block24 : Witness := ⟨⟨11648569, 11785488, 3433, 3449, 3457, 11648251, 11648423, 11648561⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3433,
    ExposureEvolution.KernelPratt.prime_3449,
    ExposureEvolution.KernelPratt.prime_3457,
    ExposureEvolution.KernelPratt.prime_11648251,
    ExposureEvolution.KernelPratt.prime_11648423,
    ExposureEvolution.KernelPratt.prime_11648561]

def block25 : Witness := ⟨⟨11785489, 11895600, 3449, 3457, 3461, 11785349, 11785441, 11785463⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3449,
    ExposureEvolution.KernelPratt.prime_3457,
    ExposureEvolution.KernelPratt.prime_3461,
    ExposureEvolution.KernelPratt.prime_11785349,
    ExposureEvolution.KernelPratt.prime_11785441,
    ExposureEvolution.KernelPratt.prime_11785463]

def block26 : Witness := ⟨⟨11895601, 11950848, 3457, 3461, 3463, 11895199, 11895361, 11895589⟩, 10⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3457,
    ExposureEvolution.KernelPratt.prime_3461,
    ExposureEvolution.KernelPratt.prime_3463,
    ExposureEvolution.KernelPratt.prime_11895199,
    ExposureEvolution.KernelPratt.prime_11895361,
    ExposureEvolution.KernelPratt.prime_11895589]

def block27 : Witness := ⟨⟨11950849, 11978520, 3461, 3463, 3467, 11950481, 11950537, 11950837⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3461,
    ExposureEvolution.KernelPratt.prime_3463,
    ExposureEvolution.KernelPratt.prime_3467,
    ExposureEvolution.KernelPratt.prime_11950481,
    ExposureEvolution.KernelPratt.prime_11950537,
    ExposureEvolution.KernelPratt.prime_11950837]

def block28 : Witness := ⟨⟨11978521, 11992368, 3463, 3467, 3469, 11978023, 11978359, 11978507⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3463,
    ExposureEvolution.KernelPratt.prime_3467,
    ExposureEvolution.KernelPratt.prime_3469,
    ExposureEvolution.KernelPratt.prime_11978023,
    ExposureEvolution.KernelPratt.prime_11978359,
    ExposureEvolution.KernelPratt.prime_11978507]

def block29 : Witness := ⟨⟨11992369, 12020088, 3467, 3469, 3491, 11992037, 11992063, 11992349⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3467,
    ExposureEvolution.KernelPratt.prime_3469,
    ExposureEvolution.KernelPratt.prime_3491,
    ExposureEvolution.KernelPratt.prime_11992037,
    ExposureEvolution.KernelPratt.prime_11992063,
    ExposureEvolution.KernelPratt.prime_11992349]

def block30 : Witness := ⟨⟨12020089, 12033960, 3469, 3491, 3499, 12019927, 12019933, 12020083⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3469,
    ExposureEvolution.KernelPratt.prime_3491,
    ExposureEvolution.KernelPratt.prime_3499,
    ExposureEvolution.KernelPratt.prime_12019927,
    ExposureEvolution.KernelPratt.prime_12019933,
    ExposureEvolution.KernelPratt.prime_12020083]

def block31 : Witness := ⟨⟨12033961, 12187080, 3491, 3499, 3511, 12033533, 12033877, 12033953⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3491,
    ExposureEvolution.KernelPratt.prime_3499,
    ExposureEvolution.KernelPratt.prime_3511,
    ExposureEvolution.KernelPratt.prime_12033533,
    ExposureEvolution.KernelPratt.prime_12033877,
    ExposureEvolution.KernelPratt.prime_12033953]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 12187081 stop tail = true) :
    coverage 10374841 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks09
