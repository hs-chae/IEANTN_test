import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks012
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_31091 : next 31091 = some 31193 := by
  have hl : (List.range ((257 * 31091 - 1) / 256 - 31091)).reverse =
      [120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31193]

theorem next_31193 : next 31193 = some 31307 := by
  have hl : (List.range ((257 * 31193 - 1) / 256 - 31193)).reverse =
      [120, 119, 118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31307]

theorem next_31307 : next 31307 = some 31397 := by
  have hl : (List.range ((257 * 31307 - 1) / 256 - 31307)).reverse =
      [121, 120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31397]

theorem next_31397 : next 31397 = some 31517 := by
  have hl : (List.range ((257 * 31397 - 1) / 256 - 31397)).reverse =
      [121, 120, 119] ++ (List.range 119).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31517]

theorem next_31517 : next 31517 = some 31627 := by
  have hl : (List.range ((257 * 31517 - 1) / 256 - 31517)).reverse =
      [122, 121, 120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109] ++ (List.range 109).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31627]

theorem next_31627 : next 31627 = some 31741 := by
  have hl : (List.range ((257 * 31627 - 1) / 256 - 31627)).reverse =
      [122, 121, 120, 119, 118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31741]

theorem next_31741 : next 31741 = some 31859 := by
  have hl : (List.range ((257 * 31741 - 1) / 256 - 31741)).reverse =
      [122, 121, 120, 119, 118, 117] ++ (List.range 117).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31859]

theorem next_31859 : next 31859 = some 31981 := by
  have hl : (List.range ((257 * 31859 - 1) / 256 - 31859)).reverse =
      [123, 122, 121] ++ (List.range 121).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31981]

theorem next_31981 : next 31981 = some 32099 := by
  have hl : (List.range ((257 * 31981 - 1) / 256 - 31981)).reverse =
      [123, 122, 121, 120, 119, 118, 117] ++ (List.range 117).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_32099]

theorem next_32099 : next 32099 = some 32213 := by
  have hl : (List.range ((257 * 32099 - 1) / 256 - 32099)).reverse =
      [124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_32213]

theorem next_32213 : next 32213 = some 32327 := by
  have hl : (List.range ((257 * 32213 - 1) / 256 - 32213)).reverse =
      [124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_32327]

theorem next_32327 : next 32327 = some 32443 := by
  have hl : (List.range ((257 * 32327 - 1) / 256 - 32327)).reverse =
      [125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115] ++ (List.range 115).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_32443]

theorem next_32443 : next 32443 = some 32569 := by
  have hl : (List.range ((257 * 32443 - 1) / 256 - 32443)).reverse =
      [125] ++ (List.range 125).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_32569]

theorem next_32569 : next 32569 = some 32693 := by
  have hl : (List.range ((257 * 32569 - 1) / 256 - 32569)).reverse =
      [126, 125, 124, 123] ++ (List.range 123).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_32693]

theorem next_32693 : next 32693 = some 32803 := by
  have hl : (List.range ((257 * 32693 - 1) / 256 - 32693)).reverse =
      [126, 125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109] ++ (List.range 109).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_32803]

theorem next_32803 : next 32803 = some 32917 := by
  have hl : (List.range ((257 * 32803 - 1) / 256 - 32803)).reverse =
      [127, 126, 125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_32917]

theorem next_32917 : next 32917 = some 33037 := by
  have hl : (List.range ((257 * 32917 - 1) / 256 - 32917)).reverse =
      [127, 126, 125, 124, 123, 122, 121, 120, 119] ++ (List.range 119).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_33037]

theorem next_33037 : next 33037 = some 33161 := by
  have hl : (List.range ((257 * 33037 - 1) / 256 - 33037)).reverse =
      [128, 127, 126, 125, 124, 123] ++ (List.range 123).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_33161]

theorem next_33161 : next 33161 = some 33289 := by
  have hl : (List.range ((257 * 33161 - 1) / 256 - 33161)).reverse =
      [128, 127] ++ (List.range 127).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_33289]

theorem next_33289 : next 33289 = some 33413 := by
  have hl : (List.range ((257 * 33289 - 1) / 256 - 33289)).reverse =
      [129, 128, 127, 126, 125, 124, 123] ++ (List.range 123).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_33413]

theorem next_33413 : next 33413 = some 33533 := by
  have hl : (List.range ((257 * 33413 - 1) / 256 - 33413)).reverse =
      [129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119] ++ (List.range 119).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_33533]

theorem next_33533 : next 33533 = some 33647 := by
  have hl : (List.range ((257 * 33533 - 1) / 256 - 33533)).reverse =
      [129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_33647]

theorem next_33647 : next 33647 = some 33773 := by
  have hl : (List.range ((257 * 33647 - 1) / 256 - 33647)).reverse =
      [130, 129, 128, 127, 126, 125] ++ (List.range 125).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_33773]

theorem next_33773 : next 33773 = some 33893 := by
  have hl : (List.range ((257 * 33773 - 1) / 256 - 33773)).reverse =
      [130, 129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119] ++ (List.range 119).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_33893]

theorem next_33893 : next 33893 = some 34019 := by
  have hl : (List.range ((257 * 33893 - 1) / 256 - 33893)).reverse =
      [131, 130, 129, 128, 127, 126, 125] ++ (List.range 125).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_34019]

theorem next_34019 : next 34019 = some 34147 := by
  have hl : (List.range ((257 * 34019 - 1) / 256 - 34019)).reverse =
      [131, 130, 129, 128, 127] ++ (List.range 127).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_34147]

theorem next_34147 : next 34147 = some 34273 := by
  have hl : (List.range ((257 * 34147 - 1) / 256 - 34147)).reverse =
      [132, 131, 130, 129, 128, 127, 126, 125] ++ (List.range 125).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_34273]

theorem next_34273 : next 34273 = some 34403 := by
  have hl : (List.range ((257 * 34273 - 1) / 256 - 34273)).reverse =
      [132, 131, 130, 129] ++ (List.range 129).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_34403]

theorem next_34403 : next 34403 = some 34537 := by
  have hl : (List.range ((257 * 34403 - 1) / 256 - 34403)).reverse =
      [133] ++ (List.range 133).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_34537]

theorem next_34537 : next 34537 = some 34667 := by
  have hl : (List.range ((257 * 34537 - 1) / 256 - 34537)).reverse =
      [133, 132, 131, 130, 129] ++ (List.range 129).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_34667]

theorem next_34667 : next 34667 = some 34781 := by
  have hl : (List.range ((257 * 34667 - 1) / 256 - 34667)).reverse =
      [134, 133, 132, 131, 130, 129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_34781]

theorem next_34781 : next 34781 = some 34913 := by
  have hl : (List.range ((257 * 34781 - 1) / 256 - 34781)).reverse =
      [134, 133, 132, 131] ++ (List.range 131).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_34913]

def primes : List ℕ := [31193, 31307, 31397, 31517, 31627, 31741, 31859, 31981, 32099, 32213, 32327, 32443, 32569, 32693, 32803, 32917, 33037, 33161, 33289, 33413, 33533, 33647, 33773, 33893, 34019, 34147, 34273, 34403, 34537, 34667, 34781, 34913]

theorem segment : run 316 31091 89693 =
    primes ++ run 284 34913 89693 := by
  rw [Compact40PrimeCompose256.step 315 31091 89693 31193
    (by decide +kernel) next_31091]
  rw [Compact40PrimeCompose256.step 314 31193 89693 31307
    (by decide +kernel) next_31193]
  rw [Compact40PrimeCompose256.step 313 31307 89693 31397
    (by decide +kernel) next_31307]
  rw [Compact40PrimeCompose256.step 312 31397 89693 31517
    (by decide +kernel) next_31397]
  rw [Compact40PrimeCompose256.step 311 31517 89693 31627
    (by decide +kernel) next_31517]
  rw [Compact40PrimeCompose256.step 310 31627 89693 31741
    (by decide +kernel) next_31627]
  rw [Compact40PrimeCompose256.step 309 31741 89693 31859
    (by decide +kernel) next_31741]
  rw [Compact40PrimeCompose256.step 308 31859 89693 31981
    (by decide +kernel) next_31859]
  rw [Compact40PrimeCompose256.step 307 31981 89693 32099
    (by decide +kernel) next_31981]
  rw [Compact40PrimeCompose256.step 306 32099 89693 32213
    (by decide +kernel) next_32099]
  rw [Compact40PrimeCompose256.step 305 32213 89693 32327
    (by decide +kernel) next_32213]
  rw [Compact40PrimeCompose256.step 304 32327 89693 32443
    (by decide +kernel) next_32327]
  rw [Compact40PrimeCompose256.step 303 32443 89693 32569
    (by decide +kernel) next_32443]
  rw [Compact40PrimeCompose256.step 302 32569 89693 32693
    (by decide +kernel) next_32569]
  rw [Compact40PrimeCompose256.step 301 32693 89693 32803
    (by decide +kernel) next_32693]
  rw [Compact40PrimeCompose256.step 300 32803 89693 32917
    (by decide +kernel) next_32803]
  rw [Compact40PrimeCompose256.step 299 32917 89693 33037
    (by decide +kernel) next_32917]
  rw [Compact40PrimeCompose256.step 298 33037 89693 33161
    (by decide +kernel) next_33037]
  rw [Compact40PrimeCompose256.step 297 33161 89693 33289
    (by decide +kernel) next_33161]
  rw [Compact40PrimeCompose256.step 296 33289 89693 33413
    (by decide +kernel) next_33289]
  rw [Compact40PrimeCompose256.step 295 33413 89693 33533
    (by decide +kernel) next_33413]
  rw [Compact40PrimeCompose256.step 294 33533 89693 33647
    (by decide +kernel) next_33533]
  rw [Compact40PrimeCompose256.step 293 33647 89693 33773
    (by decide +kernel) next_33647]
  rw [Compact40PrimeCompose256.step 292 33773 89693 33893
    (by decide +kernel) next_33773]
  rw [Compact40PrimeCompose256.step 291 33893 89693 34019
    (by decide +kernel) next_33893]
  rw [Compact40PrimeCompose256.step 290 34019 89693 34147
    (by decide +kernel) next_34019]
  rw [Compact40PrimeCompose256.step 289 34147 89693 34273
    (by decide +kernel) next_34147]
  rw [Compact40PrimeCompose256.step 288 34273 89693 34403
    (by decide +kernel) next_34273]
  rw [Compact40PrimeCompose256.step 287 34403 89693 34537
    (by decide +kernel) next_34403]
  rw [Compact40PrimeCompose256.step 286 34537 89693 34667
    (by decide +kernel) next_34537]
  rw [Compact40PrimeCompose256.step 285 34667 89693 34781
    (by decide +kernel) next_34667]
  rw [Compact40PrimeCompose256.step 284 34781 89693 34913
    (by decide +kernel) next_34781]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 34913 stop tail = true) :
    check 31091 stop (primes ++ tail) = true := by
  change check _ _ (31193 :: 31307 :: 31397 :: 31517 :: 31627 :: 31741 :: 31859 :: 31981 :: 32099 :: 32213 :: 32327 :: 32443 :: 32569 :: 32693 :: 32803 :: 32917 :: 33037 :: 33161 :: 33289 :: 33413 :: 33533 :: 33647 :: 33773 :: 33893 :: 34019 :: 34147 :: 34273 :: 34403 :: 34537 :: 34667 :: 34781 :: 34913 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31193, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31307, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31397, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31517, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31627, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31741, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31859, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31981, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_32099, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_32213, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_32327, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_32443, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_32569, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_32693, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_32803, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_32917, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_33037, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_33161, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_33289, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_33413, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_33533, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_33647, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_33773, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_33893, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_34019, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_34147, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_34273, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_34403, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_34537, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_34667, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_34781, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_34913, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks012
