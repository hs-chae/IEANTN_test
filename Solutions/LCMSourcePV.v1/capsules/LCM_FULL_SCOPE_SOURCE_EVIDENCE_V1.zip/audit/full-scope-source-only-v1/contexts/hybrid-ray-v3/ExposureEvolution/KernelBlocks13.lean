import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks13
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨18139081, 18156120, 4261, 4271, 4273, 18138661, 18138739, 18139073⟩, 6⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4261,
    ExposureEvolution.KernelPratt.prime_4271,
    ExposureEvolution.KernelPratt.prime_4273,
    ExposureEvolution.KernelPratt.prime_18138661,
    ExposureEvolution.KernelPratt.prime_18138739,
    ExposureEvolution.KernelPratt.prime_18139073]

def block01 : Witness := ⟨⟨18156121, 18241440, 4271, 4273, 4283, 18155747, 18155783, 18156107⟩, 10⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4271,
    ExposureEvolution.KernelPratt.prime_4273,
    ExposureEvolution.KernelPratt.prime_4283,
    ExposureEvolution.KernelPratt.prime_18155747,
    ExposureEvolution.KernelPratt.prime_18155783,
    ExposureEvolution.KernelPratt.prime_18156107]

def block02 : Witness := ⟨⟨18241441, 18258528, 4273, 4283, 4289, 18241081, 18241163, 18241439⟩, 11⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4273,
    ExposureEvolution.KernelPratt.prime_4283,
    ExposureEvolution.KernelPratt.prime_4289,
    ExposureEvolution.KernelPratt.prime_18241081,
    ExposureEvolution.KernelPratt.prime_18241163,
    ExposureEvolution.KernelPratt.prime_18241439]

def block03 : Witness := ⟨⟨18258529, 18344088, 4283, 4289, 4297, 18257951, 18258241, 18258517⟩, 10⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4283,
    ExposureEvolution.KernelPratt.prime_4289,
    ExposureEvolution.KernelPratt.prime_4297,
    ExposureEvolution.KernelPratt.prime_18257951,
    ExposureEvolution.KernelPratt.prime_18258241,
    ExposureEvolution.KernelPratt.prime_18258517]

def block04 : Witness := ⟨⟨18344089, 18395520, 4289, 4297, 4327, 18343813, 18343931, 18344083⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4289,
    ExposureEvolution.KernelPratt.prime_4297,
    ExposureEvolution.KernelPratt.prime_4327,
    ExposureEvolution.KernelPratt.prime_18343813,
    ExposureEvolution.KernelPratt.prime_18343931,
    ExposureEvolution.KernelPratt.prime_18344083]

def block05 : Witness := ⟨⟨18395521, 18464208, 4297, 4327, 4337, 18395011, 18395053, 18395473⟩, 8⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4297,
    ExposureEvolution.KernelPratt.prime_4327,
    ExposureEvolution.KernelPratt.prime_4337,
    ExposureEvolution.KernelPratt.prime_18395011,
    ExposureEvolution.KernelPratt.prime_18395053,
    ExposureEvolution.KernelPratt.prime_18395473]

def block06 : Witness := ⟨⟨18464209, 18722928, 4327, 4337, 4339, 18463747, 18463909, 18464203⟩, 10⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4327,
    ExposureEvolution.KernelPratt.prime_4337,
    ExposureEvolution.KernelPratt.prime_4339,
    ExposureEvolution.KernelPratt.prime_18463747,
    ExposureEvolution.KernelPratt.prime_18463909,
    ExposureEvolution.KernelPratt.prime_18464203]

def block07 : Witness := ⟨⟨18722929, 18809568, 4337, 4339, 4349, 18722617, 18722761, 18722909⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4337,
    ExposureEvolution.KernelPratt.prime_4339,
    ExposureEvolution.KernelPratt.prime_4349,
    ExposureEvolution.KernelPratt.prime_18722617,
    ExposureEvolution.KernelPratt.prime_18722761,
    ExposureEvolution.KernelPratt.prime_18722909]

def block08 : Witness := ⟨⟨18809569, 18826920, 4339, 4349, 4357, 18809177, 18809389, 18809521⟩, 7⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4339,
    ExposureEvolution.KernelPratt.prime_4349,
    ExposureEvolution.KernelPratt.prime_4357,
    ExposureEvolution.KernelPratt.prime_18809177,
    ExposureEvolution.KernelPratt.prime_18809389,
    ExposureEvolution.KernelPratt.prime_18809521]

def block09 : Witness := ⟨⟨18826921, 18913800, 4349, 4357, 4363, 18826499, 18826711, 18826901⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4349,
    ExposureEvolution.KernelPratt.prime_4357,
    ExposureEvolution.KernelPratt.prime_4363,
    ExposureEvolution.KernelPratt.prime_18826499,
    ExposureEvolution.KernelPratt.prime_18826711,
    ExposureEvolution.KernelPratt.prime_18826901]

def block10 : Witness := ⟨⟨18913801, 18983448, 4357, 4363, 4373, 18913541, 18913717, 18913799⟩, 9⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4357,
    ExposureEvolution.KernelPratt.prime_4363,
    ExposureEvolution.KernelPratt.prime_4373,
    ExposureEvolution.KernelPratt.prime_18913541,
    ExposureEvolution.KernelPratt.prime_18913717,
    ExposureEvolution.KernelPratt.prime_18913799]

def block11 : Witness := ⟨⟨18983449, 19035768, 4363, 4373, 4391, 18983011, 18983021, 18983423⟩, 8⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4363,
    ExposureEvolution.KernelPratt.prime_4373,
    ExposureEvolution.KernelPratt.prime_4391,
    ExposureEvolution.KernelPratt.prime_18983011,
    ExposureEvolution.KernelPratt.prime_18983021,
    ExposureEvolution.KernelPratt.prime_18983423]

def block12 : Witness := ⟨⟨19035769, 19123128, 4373, 4391, 4397, 19035619, 19035623, 19035763⟩, 6⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4373,
    ExposureEvolution.KernelPratt.prime_4391,
    ExposureEvolution.KernelPratt.prime_4397,
    ExposureEvolution.KernelPratt.prime_19035619,
    ExposureEvolution.KernelPratt.prime_19035623,
    ExposureEvolution.KernelPratt.prime_19035763]

def block13 : Witness := ⟨⟨19123129, 19280880, 4391, 4397, 4409, 19122899, 19123057, 19123127⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4391,
    ExposureEvolution.KernelPratt.prime_4397,
    ExposureEvolution.KernelPratt.prime_4409,
    ExposureEvolution.KernelPratt.prime_19122899,
    ExposureEvolution.KernelPratt.prime_19123057,
    ExposureEvolution.KernelPratt.prime_19123127]

def block14 : Witness := ⟨⟨19280881, 19333608, 4397, 4409, 4421, 19280381, 19280717, 19280869⟩, 7⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4397,
    ExposureEvolution.KernelPratt.prime_4409,
    ExposureEvolution.KernelPratt.prime_4421,
    ExposureEvolution.KernelPratt.prime_19280381,
    ExposureEvolution.KernelPratt.prime_19280717,
    ExposureEvolution.KernelPratt.prime_19280869]

def block15 : Witness := ⟨⟨19333609, 19439280, 4409, 4421, 4423, 19333177, 19333313, 19333597⟩, 12⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4409,
    ExposureEvolution.KernelPratt.prime_4421,
    ExposureEvolution.KernelPratt.prime_4423,
    ExposureEvolution.KernelPratt.prime_19333177,
    ExposureEvolution.KernelPratt.prime_19333313,
    ExposureEvolution.KernelPratt.prime_19333597]

def block16 : Witness := ⟨⟨19439281, 19545240, 4421, 4423, 4441, 19438963, 19439159, 19439267⟩, 12⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4421,
    ExposureEvolution.KernelPratt.prime_4423,
    ExposureEvolution.KernelPratt.prime_4441,
    ExposureEvolution.KernelPratt.prime_19438963,
    ExposureEvolution.KernelPratt.prime_19439159,
    ExposureEvolution.KernelPratt.prime_19439267]

def block17 : Witness := ⟨⟨19545241, 19562928, 4423, 4441, 4447, 19544783, 19545157, 19545203⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4423,
    ExposureEvolution.KernelPratt.prime_4441,
    ExposureEvolution.KernelPratt.prime_4447,
    ExposureEvolution.KernelPratt.prime_19544783,
    ExposureEvolution.KernelPratt.prime_19545157,
    ExposureEvolution.KernelPratt.prime_19545203]

def block18 : Witness := ⟨⟨19562929, 19722480, 4441, 4447, 4451, 19562539, 19562713, 19562927⟩, 8⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4441,
    ExposureEvolution.KernelPratt.prime_4447,
    ExposureEvolution.KernelPratt.prime_4451,
    ExposureEvolution.KernelPratt.prime_19562539,
    ExposureEvolution.KernelPratt.prime_19562713,
    ExposureEvolution.KernelPratt.prime_19562927]

def block19 : Witness := ⟨⟨19722481, 19775808, 4447, 4451, 4457, 19722317, 19722401, 19722473⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4447,
    ExposureEvolution.KernelPratt.prime_4451,
    ExposureEvolution.KernelPratt.prime_4457,
    ExposureEvolution.KernelPratt.prime_19722317,
    ExposureEvolution.KernelPratt.prime_19722401,
    ExposureEvolution.KernelPratt.prime_19722473]

def block20 : Witness := ⟨⟨19775809, 19811400, 4451, 4457, 4463, 19775527, 19775617, 19775801⟩, 11⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4451,
    ExposureEvolution.KernelPratt.prime_4457,
    ExposureEvolution.KernelPratt.prime_4463,
    ExposureEvolution.KernelPratt.prime_19775527,
    ExposureEvolution.KernelPratt.prime_19775617,
    ExposureEvolution.KernelPratt.prime_19775801]

def block21 : Witness := ⟨⟨19811401, 19864848, 4457, 4463, 4481, 19810957, 19811177, 19811399⟩, 11⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4457,
    ExposureEvolution.KernelPratt.prime_4463,
    ExposureEvolution.KernelPratt.prime_4481,
    ExposureEvolution.KernelPratt.prime_19810957,
    ExposureEvolution.KernelPratt.prime_19811177,
    ExposureEvolution.KernelPratt.prime_19811399]

def block22 : Witness := ⟨⟨19864849, 19918368, 4463, 4481, 4483, 19864417, 19864567, 19864837⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4463,
    ExposureEvolution.KernelPratt.prime_4481,
    ExposureEvolution.KernelPratt.prime_4483,
    ExposureEvolution.KernelPratt.prime_19864417,
    ExposureEvolution.KernelPratt.prime_19864567,
    ExposureEvolution.KernelPratt.prime_19864837]

def block23 : Witness := ⟨⟨19918369, 20079360, 4481, 4483, 4493, 19917949, 19918133, 19918361⟩, 10⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4481,
    ExposureEvolution.KernelPratt.prime_4483,
    ExposureEvolution.KernelPratt.prime_4493,
    ExposureEvolution.KernelPratt.prime_19917949,
    ExposureEvolution.KernelPratt.prime_19918133,
    ExposureEvolution.KernelPratt.prime_19918361]

def block24 : Witness := ⟨⟨20079361, 20097288, 4483, 4493, 4507, 20079109, 20079239, 20079343⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4483,
    ExposureEvolution.KernelPratt.prime_4493,
    ExposureEvolution.KernelPratt.prime_4507,
    ExposureEvolution.KernelPratt.prime_20079109,
    ExposureEvolution.KernelPratt.prime_20079239,
    ExposureEvolution.KernelPratt.prime_20079343]

def block25 : Witness := ⟨⟨20097289, 20187048, 4493, 4507, 4513, 20097151, 20097223, 20097263⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4493,
    ExposureEvolution.KernelPratt.prime_4507,
    ExposureEvolution.KernelPratt.prime_4513,
    ExposureEvolution.KernelPratt.prime_20097151,
    ExposureEvolution.KernelPratt.prime_20097223,
    ExposureEvolution.KernelPratt.prime_20097263]

def block26 : Witness := ⟨⟨20187049, 20313048, 4507, 4513, 4517, 20186399, 20186809, 20187043⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4507,
    ExposureEvolution.KernelPratt.prime_4513,
    ExposureEvolution.KernelPratt.prime_4517,
    ExposureEvolution.KernelPratt.prime_20186399,
    ExposureEvolution.KernelPratt.prime_20186809,
    ExposureEvolution.KernelPratt.prime_20187043]

def block27 : Witness := ⟨⟨20313049, 20367168, 4513, 4517, 4519, 20312693, 20312959, 20313047⟩, 9⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4513,
    ExposureEvolution.KernelPratt.prime_4517,
    ExposureEvolution.KernelPratt.prime_4519,
    ExposureEvolution.KernelPratt.prime_20312693,
    ExposureEvolution.KernelPratt.prime_20312959,
    ExposureEvolution.KernelPratt.prime_20313047]

def block28 : Witness := ⟨⟨20367169, 20403288, 4517, 4519, 4523, 20366737, 20366809, 20367143⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4517,
    ExposureEvolution.KernelPratt.prime_4519,
    ExposureEvolution.KernelPratt.prime_4523,
    ExposureEvolution.KernelPratt.prime_20366737,
    ExposureEvolution.KernelPratt.prime_20366809,
    ExposureEvolution.KernelPratt.prime_20367143]

def block29 : Witness := ⟨⟨20403289, 20421360, 4519, 4523, 4547, 20403197, 20403233, 20403241⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4519,
    ExposureEvolution.KernelPratt.prime_4523,
    ExposureEvolution.KernelPratt.prime_4547,
    ExposureEvolution.KernelPratt.prime_20403197,
    ExposureEvolution.KernelPratt.prime_20403233,
    ExposureEvolution.KernelPratt.prime_20403241]

def block30 : Witness := ⟨⟨20421361, 20457528, 4523, 4547, 4549, 20420957, 20420977, 20421347⟩, 13⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4523,
    ExposureEvolution.KernelPratt.prime_4547,
    ExposureEvolution.KernelPratt.prime_4549,
    ExposureEvolution.KernelPratt.prime_20420957,
    ExposureEvolution.KernelPratt.prime_20420977,
    ExposureEvolution.KernelPratt.prime_20421347]

def block31 : Witness := ⟨⟨20457529, 20675208, 4547, 4549, 4561, 20457299, 20457497, 20457517⟩, 6⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_4547,
    ExposureEvolution.KernelPratt.prime_4549,
    ExposureEvolution.KernelPratt.prime_4561,
    ExposureEvolution.KernelPratt.prime_20457299,
    ExposureEvolution.KernelPratt.prime_20457497,
    ExposureEvolution.KernelPratt.prime_20457517]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 20675209 stop tail = true) :
    coverage 18139081 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks13
