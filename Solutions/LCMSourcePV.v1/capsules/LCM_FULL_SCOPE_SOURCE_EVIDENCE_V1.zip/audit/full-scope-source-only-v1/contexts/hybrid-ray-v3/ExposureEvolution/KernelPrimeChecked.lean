import ExposureEvolution.KernelPrimeProgram
import ExposureEvolution.KernelPrimeCheck00
import ExposureEvolution.KernelPrimeCheck01
import ExposureEvolution.KernelPrimeCheck02
import ExposureEvolution.KernelPrimeCheck03
import ExposureEvolution.KernelPrimeCheck04
import ExposureEvolution.KernelPrimeCheck05
import ExposureEvolution.KernelPrimeCheck06
import ExposureEvolution.KernelPrimeCheck07
import ExposureEvolution.KernelPrimeCheck08
import ExposureEvolution.KernelPrimeCheck09
import ExposureEvolution.KernelPrimeCheck10
namespace ExposureEvolution.KernelPrimeChecked
open ExposureEvolution.KernelPrimeProgram
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem same_values : output =
  ExposureEvolution.KernelPrimeCheck00.primes ++
  ExposureEvolution.KernelPrimeCheck01.primes ++
  ExposureEvolution.KernelPrimeCheck02.primes ++
  ExposureEvolution.KernelPrimeCheck03.primes ++
  ExposureEvolution.KernelPrimeCheck04.primes ++
  ExposureEvolution.KernelPrimeCheck05.primes ++
  ExposureEvolution.KernelPrimeCheck06.primes ++
  ExposureEvolution.KernelPrimeCheck07.primes ++
  ExposureEvolution.KernelPrimeCheck08.primes ++
  ExposureEvolution.KernelPrimeCheck09.primes ++
  ExposureEvolution.KernelPrimeCheck10.primes := by rfl

theorem accepted : check 8468 89693 output = true := by
  rw [same_values]
  apply ExposureEvolution.KernelPrimeCheck00.extend
  apply ExposureEvolution.KernelPrimeCheck01.extend
  apply ExposureEvolution.KernelPrimeCheck02.extend
  apply ExposureEvolution.KernelPrimeCheck03.extend
  apply ExposureEvolution.KernelPrimeCheck04.extend
  apply ExposureEvolution.KernelPrimeCheck05.extend
  apply ExposureEvolution.KernelPrimeCheck06.extend
  apply ExposureEvolution.KernelPrimeCheck07.extend
  apply ExposureEvolution.KernelPrimeCheck08.extend
  apply ExposureEvolution.KernelPrimeCheck09.extend
  apply ExposureEvolution.KernelPrimeCheck10.extend
  decide +kernel

theorem length : output.length = 669 := by rfl

theorem covered {x : ℝ} (ha : (8468 : ℝ) ≤ x) (hb : x < 89693) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 256 :=
  sound output accepted ha hb

#print axioms accepted
#print axioms covered
end ExposureEvolution.KernelPrimeChecked
