import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_009
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨49801249, 49970760, 7069, 7079, 7103, 49800833, 49800851, 49801243⟩, 8⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7069,
    ExposureEvolution.Compact40Pratt.prime_7079,
    ExposureEvolution.Compact40Pratt.prime_7103,
    ExposureEvolution.Compact40Pratt.prime_49800833,
    ExposureEvolution.Compact40Pratt.prime_49800851,
    ExposureEvolution.Compact40Pratt.prime_49801243]

def block01 : Witness := ⟨⟨49970761, 50112240, 7079, 7103, 7109, 49970507, 49970681, 49970749⟩, 10⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7079,
    ExposureEvolution.Compact40Pratt.prime_7103,
    ExposureEvolution.Compact40Pratt.prime_7109,
    ExposureEvolution.Compact40Pratt.prime_49970507,
    ExposureEvolution.Compact40Pratt.prime_49970681,
    ExposureEvolution.Compact40Pratt.prime_49970749]

def block02 : Witness := ⟨⟨50112241, 50452608, 7103, 7109, 7121, 50111923, 50112169, 50112229⟩, 10⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7103,
    ExposureEvolution.Compact40Pratt.prime_7109,
    ExposureEvolution.Compact40Pratt.prime_7121,
    ExposureEvolution.Compact40Pratt.prime_50111923,
    ExposureEvolution.Compact40Pratt.prime_50112169,
    ExposureEvolution.Compact40Pratt.prime_50112229]

def block03 : Witness := ⟨⟨50452609, 50537880, 7109, 7121, 7127, 50452229, 50452561, 50452603⟩, 7⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7109,
    ExposureEvolution.Compact40Pratt.prime_7121,
    ExposureEvolution.Compact40Pratt.prime_7127,
    ExposureEvolution.Compact40Pratt.prime_50452229,
    ExposureEvolution.Compact40Pratt.prime_50452561,
    ExposureEvolution.Compact40Pratt.prime_50452603]

def block04 : Witness := ⟨⟨50537881, 50708640, 7121, 7127, 7129, 50537351, 50537717, 50537869⟩, 11⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7121,
    ExposureEvolution.Compact40Pratt.prime_7127,
    ExposureEvolution.Compact40Pratt.prime_7129,
    ExposureEvolution.Compact40Pratt.prime_50537351,
    ExposureEvolution.Compact40Pratt.prime_50537717,
    ExposureEvolution.Compact40Pratt.prime_50537869]

def block05 : Witness := ⟨⟨50708641, 50794128, 7127, 7129, 7151, 50708101, 50708323, 50708621⟩, 8⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7127,
    ExposureEvolution.Compact40Pratt.prime_7129,
    ExposureEvolution.Compact40Pratt.prime_7151,
    ExposureEvolution.Compact40Pratt.prime_50708101,
    ExposureEvolution.Compact40Pratt.prime_50708323,
    ExposureEvolution.Compact40Pratt.prime_50708621]

def block06 : Witness := ⟨⟨50794129, 50822640, 7129, 7151, 7159, 50793961, 50793989, 50794127⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7129,
    ExposureEvolution.Compact40Pratt.prime_7151,
    ExposureEvolution.Compact40Pratt.prime_7159,
    ExposureEvolution.Compact40Pratt.prime_50793961,
    ExposureEvolution.Compact40Pratt.prime_50793989,
    ExposureEvolution.Compact40Pratt.prime_50794127]

def block07 : Witness := ⟨⟨50822641, 51136800, 7151, 7159, 7177, 50822159, 50822251, 50822621⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7151,
    ExposureEvolution.Compact40Pratt.prime_7159,
    ExposureEvolution.Compact40Pratt.prime_7177,
    ExposureEvolution.Compact40Pratt.prime_50822159,
    ExposureEvolution.Compact40Pratt.prime_50822251,
    ExposureEvolution.Compact40Pratt.prime_50822621]

def block08 : Witness := ⟨⟨51136801, 51251280, 7159, 7177, 7187, 51136339, 51136457, 51136793⟩, 10⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7159,
    ExposureEvolution.Compact40Pratt.prime_7177,
    ExposureEvolution.Compact40Pratt.prime_7187,
    ExposureEvolution.Compact40Pratt.prime_51136339,
    ExposureEvolution.Compact40Pratt.prime_51136457,
    ExposureEvolution.Compact40Pratt.prime_51136793]

def block09 : Witness := ⟨⟨51251281, 51509328, 7177, 7187, 7193, 51250879, 51250889, 51251269⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7177,
    ExposureEvolution.Compact40Pratt.prime_7187,
    ExposureEvolution.Compact40Pratt.prime_7193,
    ExposureEvolution.Compact40Pratt.prime_51250879,
    ExposureEvolution.Compact40Pratt.prime_51250889,
    ExposureEvolution.Compact40Pratt.prime_51251269]

def block10 : Witness := ⟨⟨51509329, 51652968, 7187, 7193, 7207, 51508811, 51509203, 51509327⟩, 8⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7187,
    ExposureEvolution.Compact40Pratt.prime_7193,
    ExposureEvolution.Compact40Pratt.prime_7207,
    ExposureEvolution.Compact40Pratt.prime_51508811,
    ExposureEvolution.Compact40Pratt.prime_51509203,
    ExposureEvolution.Compact40Pratt.prime_51509327]

def block11 : Witness := ⟨⟨51652969, 51739248, 7193, 7207, 7211, 51652609, 51652753, 51652967⟩, 9⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7193,
    ExposureEvolution.Compact40Pratt.prime_7207,
    ExposureEvolution.Compact40Pratt.prime_7211,
    ExposureEvolution.Compact40Pratt.prime_51652609,
    ExposureEvolution.Compact40Pratt.prime_51652753,
    ExposureEvolution.Compact40Pratt.prime_51652967]

def block12 : Witness := ⟨⟨51739249, 51940848, 7207, 7211, 7213, 51739097, 51739189, 51739243⟩, 8⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7207,
    ExposureEvolution.Compact40Pratt.prime_7211,
    ExposureEvolution.Compact40Pratt.prime_7213,
    ExposureEvolution.Compact40Pratt.prime_51739097,
    ExposureEvolution.Compact40Pratt.prime_51739189,
    ExposureEvolution.Compact40Pratt.prime_51739243]

def block13 : Witness := ⟨⟨51940849, 51998520, 7211, 7213, 7219, 51940289, 51940771, 51940843⟩, 13⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7211,
    ExposureEvolution.Compact40Pratt.prime_7213,
    ExposureEvolution.Compact40Pratt.prime_7219,
    ExposureEvolution.Compact40Pratt.prime_51940289,
    ExposureEvolution.Compact40Pratt.prime_51940771,
    ExposureEvolution.Compact40Pratt.prime_51940843]

def block14 : Witness := ⟨⟨51998521, 52027368, 7213, 7219, 7229, 51997909, 51998033, 51998477⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7213,
    ExposureEvolution.Compact40Pratt.prime_7219,
    ExposureEvolution.Compact40Pratt.prime_7229,
    ExposureEvolution.Compact40Pratt.prime_51997909,
    ExposureEvolution.Compact40Pratt.prime_51998033,
    ExposureEvolution.Compact40Pratt.prime_51998477]

def block15 : Witness := ⟨⟨52027369, 52113960, 7219, 7229, 7237, 52026941, 52027181, 52027351⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7219,
    ExposureEvolution.Compact40Pratt.prime_7229,
    ExposureEvolution.Compact40Pratt.prime_7237,
    ExposureEvolution.Compact40Pratt.prime_52026941,
    ExposureEvolution.Compact40Pratt.prime_52027181,
    ExposureEvolution.Compact40Pratt.prime_52027351]

def block16 : Witness := ⟨⟨52113961, 52258440, 7229, 7237, 7243, 52113889, 52113917, 52113953⟩, 11⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7229,
    ExposureEvolution.Compact40Pratt.prime_7237,
    ExposureEvolution.Compact40Pratt.prime_7243,
    ExposureEvolution.Compact40Pratt.prime_52113889,
    ExposureEvolution.Compact40Pratt.prime_52113917,
    ExposureEvolution.Compact40Pratt.prime_52113953]

def block17 : Witness := ⟨⟨52258441, 52374168, 7237, 7243, 7247, 52258133, 52258429, 52258439⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7237,
    ExposureEvolution.Compact40Pratt.prime_7243,
    ExposureEvolution.Compact40Pratt.prime_7247,
    ExposureEvolution.Compact40Pratt.prime_52258133,
    ExposureEvolution.Compact40Pratt.prime_52258429,
    ExposureEvolution.Compact40Pratt.prime_52258439]

def block18 : Witness := ⟨⟨52374169, 52461048, 7243, 7247, 7253, 52374037, 52374149, 52374167⟩, 10⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7243,
    ExposureEvolution.Compact40Pratt.prime_7247,
    ExposureEvolution.Compact40Pratt.prime_7253,
    ExposureEvolution.Compact40Pratt.prime_52374037,
    ExposureEvolution.Compact40Pratt.prime_52374149,
    ExposureEvolution.Compact40Pratt.prime_52374167]

def block19 : Witness := ⟨⟨52461049, 52519008, 7247, 7253, 7283, 52460519, 52460927, 52461007⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7247,
    ExposureEvolution.Compact40Pratt.prime_7253,
    ExposureEvolution.Compact40Pratt.prime_7283,
    ExposureEvolution.Compact40Pratt.prime_52460519,
    ExposureEvolution.Compact40Pratt.prime_52460927,
    ExposureEvolution.Compact40Pratt.prime_52461007]

def block20 : Witness := ⟨⟨52519009, 52606008, 7253, 7283, 7297, 52518443, 52518481, 52519007⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7253,
    ExposureEvolution.Compact40Pratt.prime_7283,
    ExposureEvolution.Compact40Pratt.prime_7297,
    ExposureEvolution.Compact40Pratt.prime_52518443,
    ExposureEvolution.Compact40Pratt.prime_52518481,
    ExposureEvolution.Compact40Pratt.prime_52519007]

def block21 : Witness := ⟨⟨52606009, 53042088, 7283, 7297, 7307, 52605593, 52605967, 52605983⟩, 7⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7283,
    ExposureEvolution.Compact40Pratt.prime_7297,
    ExposureEvolution.Compact40Pratt.prime_7307,
    ExposureEvolution.Compact40Pratt.prime_52605593,
    ExposureEvolution.Compact40Pratt.prime_52605967,
    ExposureEvolution.Compact40Pratt.prime_52605983]

def block22 : Witness := ⟨⟨53042089, 53246208, 7297, 7307, 7309, 53041621, 53041999, 53042081⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7297,
    ExposureEvolution.Compact40Pratt.prime_7307,
    ExposureEvolution.Compact40Pratt.prime_7309,
    ExposureEvolution.Compact40Pratt.prime_53041621,
    ExposureEvolution.Compact40Pratt.prime_53041999,
    ExposureEvolution.Compact40Pratt.prime_53042081]

def block23 : Witness := ⟨⟨53246209, 53392248, 7307, 7309, 7321, 53245823, 53246087, 53246203⟩, 7⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7307,
    ExposureEvolution.Compact40Pratt.prime_7309,
    ExposureEvolution.Compact40Pratt.prime_7321,
    ExposureEvolution.Compact40Pratt.prime_53245823,
    ExposureEvolution.Compact40Pratt.prime_53246087,
    ExposureEvolution.Compact40Pratt.prime_53246203]

def block24 : Witness := ⟨⟨53392249, 53421480, 7309, 7321, 7331, 53391979, 53392067, 53392243⟩, 8⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7309,
    ExposureEvolution.Compact40Pratt.prime_7321,
    ExposureEvolution.Compact40Pratt.prime_7331,
    ExposureEvolution.Compact40Pratt.prime_53391979,
    ExposureEvolution.Compact40Pratt.prime_53392067,
    ExposureEvolution.Compact40Pratt.prime_53392243]

def block25 : Witness := ⟨⟨53421481, 53597040, 7321, 7331, 7333, 53421163, 53421169, 53421461⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7321,
    ExposureEvolution.Compact40Pratt.prime_7331,
    ExposureEvolution.Compact40Pratt.prime_7333,
    ExposureEvolution.Compact40Pratt.prime_53421163,
    ExposureEvolution.Compact40Pratt.prime_53421169,
    ExposureEvolution.Compact40Pratt.prime_53421461]

def block26 : Witness := ⟨⟨53597041, 53743560, 7331, 7333, 7349, 53596567, 53596883, 53597029⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7331,
    ExposureEvolution.Compact40Pratt.prime_7333,
    ExposureEvolution.Compact40Pratt.prime_7349,
    ExposureEvolution.Compact40Pratt.prime_53596567,
    ExposureEvolution.Compact40Pratt.prime_53596883,
    ExposureEvolution.Compact40Pratt.prime_53597029]

def block27 : Witness := ⟨⟨53743561, 53772888, 7333, 7349, 7351, 53743051, 53743121, 53743541⟩, 9⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7333,
    ExposureEvolution.Compact40Pratt.prime_7349,
    ExposureEvolution.Compact40Pratt.prime_7351,
    ExposureEvolution.Compact40Pratt.prime_53743051,
    ExposureEvolution.Compact40Pratt.prime_53743121,
    ExposureEvolution.Compact40Pratt.prime_53743541]

def block28 : Witness := ⟨⟨53772889, 54007800, 7349, 7351, 7369, 53772227, 53772709, 53772883⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7349,
    ExposureEvolution.Compact40Pratt.prime_7351,
    ExposureEvolution.Compact40Pratt.prime_7369,
    ExposureEvolution.Compact40Pratt.prime_53772227,
    ExposureEvolution.Compact40Pratt.prime_53772709,
    ExposureEvolution.Compact40Pratt.prime_53772883]

def block29 : Witness := ⟨⟨54007801, 54037200, 7351, 7369, 7393, 54007579, 54007649, 54007799⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7351,
    ExposureEvolution.Compact40Pratt.prime_7369,
    ExposureEvolution.Compact40Pratt.prime_7393,
    ExposureEvolution.Compact40Pratt.prime_54007579,
    ExposureEvolution.Compact40Pratt.prime_54007649,
    ExposureEvolution.Compact40Pratt.prime_54007799]

def block30 : Witness := ⟨⟨54037201, 54302160, 7369, 7393, 7411, 54037133, 54037141, 54037171⟩, 10⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7369,
    ExposureEvolution.Compact40Pratt.prime_7393,
    ExposureEvolution.Compact40Pratt.prime_7411,
    ExposureEvolution.Compact40Pratt.prime_54037133,
    ExposureEvolution.Compact40Pratt.prime_54037141,
    ExposureEvolution.Compact40Pratt.prime_54037171]

def block31 : Witness := ⟨⟨54302161, 54656448, 7393, 7411, 7417, 54301501, 54301661, 54302147⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7393,
    ExposureEvolution.Compact40Pratt.prime_7411,
    ExposureEvolution.Compact40Pratt.prime_7417,
    ExposureEvolution.Compact40Pratt.prime_54301501,
    ExposureEvolution.Compact40Pratt.prime_54301661,
    ExposureEvolution.Compact40Pratt.prime_54302147]

def block32 : Witness := ⟨⟨54656449, 54922920, 7411, 7417, 7433, 54655973, 54656219, 54656429⟩, 7⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7411,
    ExposureEvolution.Compact40Pratt.prime_7417,
    ExposureEvolution.Compact40Pratt.prime_7433,
    ExposureEvolution.Compact40Pratt.prime_54655973,
    ExposureEvolution.Compact40Pratt.prime_54656219,
    ExposureEvolution.Compact40Pratt.prime_54656429]

def block33 : Witness := ⟨⟨54922921, 55011888, 7417, 7433, 7451, 54922489, 54922663, 54922867⟩, 10⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7417,
    ExposureEvolution.Compact40Pratt.prime_7433,
    ExposureEvolution.Compact40Pratt.prime_7451,
    ExposureEvolution.Compact40Pratt.prime_54922489,
    ExposureEvolution.Compact40Pratt.prime_54922663,
    ExposureEvolution.Compact40Pratt.prime_54922867]

def block34 : Witness := ⟨⟨55011889, 55249488, 7433, 7451, 7457, 55011379, 55011731, 55011871⟩, 9⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7433,
    ExposureEvolution.Compact40Pratt.prime_7451,
    ExposureEvolution.Compact40Pratt.prime_7457,
    ExposureEvolution.Compact40Pratt.prime_55011379,
    ExposureEvolution.Compact40Pratt.prime_55011731,
    ExposureEvolution.Compact40Pratt.prime_55011871]

def block35 : Witness := ⟨⟨55249489, 55517400, 7451, 7457, 7459, 55249091, 55249213, 55249477⟩, 13⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7451,
    ExposureEvolution.Compact40Pratt.prime_7457,
    ExposureEvolution.Compact40Pratt.prime_7459,
    ExposureEvolution.Compact40Pratt.prime_55249091,
    ExposureEvolution.Compact40Pratt.prime_55249213,
    ExposureEvolution.Compact40Pratt.prime_55249477]

def block36 : Witness := ⟨⟨55517401, 55606848, 7457, 7459, 7477, 55517149, 55517179, 55517389⟩, 9⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7457,
    ExposureEvolution.Compact40Pratt.prime_7459,
    ExposureEvolution.Compact40Pratt.prime_7477,
    ExposureEvolution.Compact40Pratt.prime_55517149,
    ExposureEvolution.Compact40Pratt.prime_55517179,
    ExposureEvolution.Compact40Pratt.prime_55517389]

def block37 : Witness := ⟨⟨55606849, 55636680, 7459, 7477, 7481, 55606349, 55606679, 55606841⟩, 9⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7459,
    ExposureEvolution.Compact40Pratt.prime_7477,
    ExposureEvolution.Compact40Pratt.prime_7481,
    ExposureEvolution.Compact40Pratt.prime_55606349,
    ExposureEvolution.Compact40Pratt.prime_55606679,
    ExposureEvolution.Compact40Pratt.prime_55606841]

def block38 : Witness := ⟨⟨55636681, 55905528, 7477, 7481, 7487, 55636547, 55636613, 55636663⟩, 7⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7477,
    ExposureEvolution.Compact40Pratt.prime_7481,
    ExposureEvolution.Compact40Pratt.prime_7487,
    ExposureEvolution.Compact40Pratt.prime_55636547,
    ExposureEvolution.Compact40Pratt.prime_55636613,
    ExposureEvolution.Compact40Pratt.prime_55636663]

def block39 : Witness := ⟨⟨55905529, 55965360, 7481, 7487, 7489, 55904843, 55905193, 55905491⟩, 9⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7481,
    ExposureEvolution.Compact40Pratt.prime_7487,
    ExposureEvolution.Compact40Pratt.prime_7489,
    ExposureEvolution.Compact40Pratt.prime_55904843,
    ExposureEvolution.Compact40Pratt.prime_55905193,
    ExposureEvolution.Compact40Pratt.prime_55905491]

def block40 : Witness := ⟨⟨55965361, 56055168, 7487, 7489, 7499, 55965043, 55965307, 55965353⟩, 11⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7487,
    ExposureEvolution.Compact40Pratt.prime_7489,
    ExposureEvolution.Compact40Pratt.prime_7499,
    ExposureEvolution.Compact40Pratt.prime_55965043,
    ExposureEvolution.Compact40Pratt.prime_55965307,
    ExposureEvolution.Compact40Pratt.prime_55965353]

def block41 : Witness := ⟨⟨56055169, 56085120, 7489, 7499, 7507, 56055029, 56055047, 56055151⟩, 13⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7489,
    ExposureEvolution.Compact40Pratt.prime_7499,
    ExposureEvolution.Compact40Pratt.prime_7507,
    ExposureEvolution.Compact40Pratt.prime_56055029,
    ExposureEvolution.Compact40Pratt.prime_56055047,
    ExposureEvolution.Compact40Pratt.prime_56055151]

def block42 : Witness := ⟨⟨56085121, 56235000, 7499, 7507, 7517, 56084729, 56085067, 56085119⟩, 8⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7499,
    ExposureEvolution.Compact40Pratt.prime_7507,
    ExposureEvolution.Compact40Pratt.prime_7517,
    ExposureEvolution.Compact40Pratt.prime_56084729,
    ExposureEvolution.Compact40Pratt.prime_56085067,
    ExposureEvolution.Compact40Pratt.prime_56085119]

def block43 : Witness := ⟨⟨56235001, 56355048, 7507, 7517, 7523, 56234617, 56234803, 56234987⟩, 10⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7507,
    ExposureEvolution.Compact40Pratt.prime_7517,
    ExposureEvolution.Compact40Pratt.prime_7523,
    ExposureEvolution.Compact40Pratt.prime_56234617,
    ExposureEvolution.Compact40Pratt.prime_56234803,
    ExposureEvolution.Compact40Pratt.prime_56234987]

def block44 : Witness := ⟨⟨56355049, 56505288, 7517, 7523, 7529, 56354723, 56354773, 56355041⟩, 7⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7517,
    ExposureEvolution.Compact40Pratt.prime_7523,
    ExposureEvolution.Compact40Pratt.prime_7529,
    ExposureEvolution.Compact40Pratt.prime_56354723,
    ExposureEvolution.Compact40Pratt.prime_56354773,
    ExposureEvolution.Compact40Pratt.prime_56355041]

def block45 : Witness := ⟨⟨56505289, 56595528, 7523, 7529, 7537, 56505103, 56505131, 56505283⟩, 8⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7523,
    ExposureEvolution.Compact40Pratt.prime_7529,
    ExposureEvolution.Compact40Pratt.prime_7537,
    ExposureEvolution.Compact40Pratt.prime_56505103,
    ExposureEvolution.Compact40Pratt.prime_56505131,
    ExposureEvolution.Compact40Pratt.prime_56505283]

def block46 : Witness := ⟨⟨56595529, 56685840, 7529, 7537, 7541, 56595017, 56595173, 56595463⟩, 11⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7529,
    ExposureEvolution.Compact40Pratt.prime_7537,
    ExposureEvolution.Compact40Pratt.prime_7541,
    ExposureEvolution.Compact40Pratt.prime_56595017,
    ExposureEvolution.Compact40Pratt.prime_56595173,
    ExposureEvolution.Compact40Pratt.prime_56595463]

def block47 : Witness := ⟨⟨56685841, 56806368, 7537, 7541, 7547, 56685457, 56685767, 56685833⟩, 9⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7537,
    ExposureEvolution.Compact40Pratt.prime_7541,
    ExposureEvolution.Compact40Pratt.prime_7547,
    ExposureEvolution.Compact40Pratt.prime_56685457,
    ExposureEvolution.Compact40Pratt.prime_56685767,
    ExposureEvolution.Compact40Pratt.prime_56685833]

def block48 : Witness := ⟨⟨56806369, 56866680, 7541, 7547, 7549, 56806201, 56806223, 56806363⟩, 10⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7541,
    ExposureEvolution.Compact40Pratt.prime_7547,
    ExposureEvolution.Compact40Pratt.prime_7549,
    ExposureEvolution.Compact40Pratt.prime_56806201,
    ExposureEvolution.Compact40Pratt.prime_56806223,
    ExposureEvolution.Compact40Pratt.prime_56806363]

def block49 : Witness := ⟨⟨56866681, 56957208, 7547, 7549, 7559, 56866079, 56866223, 56866643⟩, 9⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7547,
    ExposureEvolution.Compact40Pratt.prime_7549,
    ExposureEvolution.Compact40Pratt.prime_7559,
    ExposureEvolution.Compact40Pratt.prime_56866079,
    ExposureEvolution.Compact40Pratt.prime_56866223,
    ExposureEvolution.Compact40Pratt.prime_56866643]

def block50 : Witness := ⟨⟨56957209, 56987400, 7549, 7559, 7561, 56956877, 56956909, 56957207⟩, 8⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7549,
    ExposureEvolution.Compact40Pratt.prime_7559,
    ExposureEvolution.Compact40Pratt.prime_7561,
    ExposureEvolution.Compact40Pratt.prime_56956877,
    ExposureEvolution.Compact40Pratt.prime_56956909,
    ExposureEvolution.Compact40Pratt.prime_56957207]

def block51 : Witness := ⟨⟨56987401, 57138480, 7559, 7561, 7573, 56986777, 56987087, 56987351⟩, 7⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7559,
    ExposureEvolution.Compact40Pratt.prime_7561,
    ExposureEvolution.Compact40Pratt.prime_7573,
    ExposureEvolution.Compact40Pratt.prime_56986777,
    ExposureEvolution.Compact40Pratt.prime_56987087,
    ExposureEvolution.Compact40Pratt.prime_56987351]

def block52 : Witness := ⟨⟨57138481, 57168720, 7561, 7573, 7577, 57138143, 57138287, 57138413⟩, 9⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7561,
    ExposureEvolution.Compact40Pratt.prime_7573,
    ExposureEvolution.Compact40Pratt.prime_7577,
    ExposureEvolution.Compact40Pratt.prime_57138143,
    ExposureEvolution.Compact40Pratt.prime_57138287,
    ExposureEvolution.Compact40Pratt.prime_57138413]

def block53 : Witness := ⟨⟨57168721, 57350328, 7573, 7577, 7583, 57168427, 57168523, 57168689⟩, 9⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7573,
    ExposureEvolution.Compact40Pratt.prime_7577,
    ExposureEvolution.Compact40Pratt.prime_7583,
    ExposureEvolution.Compact40Pratt.prime_57168427,
    ExposureEvolution.Compact40Pratt.prime_57168523,
    ExposureEvolution.Compact40Pratt.prime_57168689]

def block54 : Witness := ⟨⟨57350329, 57410928, 7577, 7583, 7589, 57349727, 57350221, 57350327⟩, 10⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7577,
    ExposureEvolution.Compact40Pratt.prime_7583,
    ExposureEvolution.Compact40Pratt.prime_7589,
    ExposureEvolution.Compact40Pratt.prime_57349727,
    ExposureEvolution.Compact40Pratt.prime_57350221,
    ExposureEvolution.Compact40Pratt.prime_57350327]

def block55 : Witness := ⟨⟨57410929, 57501888, 7583, 7589, 7591, 57410677, 57410747, 57410917⟩, 7⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7583,
    ExposureEvolution.Compact40Pratt.prime_7589,
    ExposureEvolution.Compact40Pratt.prime_7591,
    ExposureEvolution.Compact40Pratt.prime_57410677,
    ExposureEvolution.Compact40Pratt.prime_57410747,
    ExposureEvolution.Compact40Pratt.prime_57410917]

def block56 : Witness := ⟨⟨57501889, 57592920, 7589, 7591, 7603, 57501473, 57501481, 57501883⟩, 10⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7589,
    ExposureEvolution.Compact40Pratt.prime_7591,
    ExposureEvolution.Compact40Pratt.prime_7603,
    ExposureEvolution.Compact40Pratt.prime_57501473,
    ExposureEvolution.Compact40Pratt.prime_57501481,
    ExposureEvolution.Compact40Pratt.prime_57501883]

def block57 : Witness := ⟨⟨57592921, 57623280, 7591, 7603, 7607, 57592697, 57592853, 57592919⟩, 12⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7591,
    ExposureEvolution.Compact40Pratt.prime_7603,
    ExposureEvolution.Compact40Pratt.prime_7607,
    ExposureEvolution.Compact40Pratt.prime_57592697,
    ExposureEvolution.Compact40Pratt.prime_57592853,
    ExposureEvolution.Compact40Pratt.prime_57592919]

def block58 : Witness := ⟨⟨57623281, 57805608, 7603, 7607, 7621, 57623191, 57623231, 57623273⟩, 8⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7603,
    ExposureEvolution.Compact40Pratt.prime_7607,
    ExposureEvolution.Compact40Pratt.prime_7621,
    ExposureEvolution.Compact40Pratt.prime_57623191,
    ExposureEvolution.Compact40Pratt.prime_57623231,
    ExposureEvolution.Compact40Pratt.prime_57623273]

def block59 : Witness := ⟨⟨57805609, 57866448, 7607, 7621, 7639, 57805529, 57805567, 57805597⟩, 6⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7607,
    ExposureEvolution.Compact40Pratt.prime_7621,
    ExposureEvolution.Compact40Pratt.prime_7639,
    ExposureEvolution.Compact40Pratt.prime_57805529,
    ExposureEvolution.Compact40Pratt.prime_57805567,
    ExposureEvolution.Compact40Pratt.prime_57805597]

def block60 : Witness := ⟨⟨57866449, 58079640, 7621, 7639, 7643, 57866009, 57866209, 57866423⟩, 9⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7621,
    ExposureEvolution.Compact40Pratt.prime_7639,
    ExposureEvolution.Compact40Pratt.prime_7643,
    ExposureEvolution.Compact40Pratt.prime_57866009,
    ExposureEvolution.Compact40Pratt.prime_57866209,
    ExposureEvolution.Compact40Pratt.prime_57866423]

def block61 : Witness := ⟨⟨58079641, 58354320, 7639, 7643, 7649, 58079009, 58079039, 58079611⟩, 9⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7639,
    ExposureEvolution.Compact40Pratt.prime_7643,
    ExposureEvolution.Compact40Pratt.prime_7649,
    ExposureEvolution.Compact40Pratt.prime_58079009,
    ExposureEvolution.Compact40Pratt.prime_58079039,
    ExposureEvolution.Compact40Pratt.prime_58079611]

def block62 : Witness := ⟨⟨58354321, 58415448, 7643, 7649, 7669, 58353781, 58354099, 58354313⟩, 9⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7643,
    ExposureEvolution.Compact40Pratt.prime_7649,
    ExposureEvolution.Compact40Pratt.prime_7669,
    ExposureEvolution.Compact40Pratt.prime_58353781,
    ExposureEvolution.Compact40Pratt.prime_58354099,
    ExposureEvolution.Compact40Pratt.prime_58354313]

def block63 : Witness := ⟨⟨58415449, 58507200, 7649, 7669, 7673, 58415051, 58415261, 58415411⟩, 12⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7649,
    ExposureEvolution.Compact40Pratt.prime_7669,
    ExposureEvolution.Compact40Pratt.prime_7673,
    ExposureEvolution.Compact40Pratt.prime_58415051,
    ExposureEvolution.Compact40Pratt.prime_58415261,
    ExposureEvolution.Compact40Pratt.prime_58415411]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 58507201 stop tail = true) :
    coverage 49801249 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_009
