import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_003
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨14145121, 14190288, 3767, 3769, 3779, 14144593, 14144671, 14145091⟩, 8⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3767,
    ExposureEvolution.Compact40Pratt.prime_3769,
    ExposureEvolution.Compact40Pratt.prime_3779,
    ExposureEvolution.Compact40Pratt.prime_14144593,
    ExposureEvolution.Compact40Pratt.prime_14144671,
    ExposureEvolution.Compact40Pratt.prime_14145091]

def block01 : Witness := ⟨⟨14190289, 14205360, 3769, 3779, 3793, 14190229, 14190269, 14190271⟩, 7⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3769,
    ExposureEvolution.Compact40Pratt.prime_3779,
    ExposureEvolution.Compact40Pratt.prime_3793,
    ExposureEvolution.Compact40Pratt.prime_14190229,
    ExposureEvolution.Compact40Pratt.prime_14190269,
    ExposureEvolution.Compact40Pratt.prime_14190271]

def block02 : Witness := ⟨⟨14205361, 14280840, 3779, 3793, 3797, 14205101, 14205281, 14205349⟩, 11⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3779,
    ExposureEvolution.Compact40Pratt.prime_3793,
    ExposureEvolution.Compact40Pratt.prime_3797,
    ExposureEvolution.Compact40Pratt.prime_14205101,
    ExposureEvolution.Compact40Pratt.prime_14205281,
    ExposureEvolution.Compact40Pratt.prime_14205349]

def block03 : Witness := ⟨⟨14280841, 14386848, 3793, 3797, 3803, 14280379, 14280451, 14280829⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3793,
    ExposureEvolution.Compact40Pratt.prime_3797,
    ExposureEvolution.Compact40Pratt.prime_3803,
    ExposureEvolution.Compact40Pratt.prime_14280379,
    ExposureEvolution.Compact40Pratt.prime_14280451,
    ExposureEvolution.Compact40Pratt.prime_14280829]

def block04 : Witness := ⟨⟨14386849, 14417208, 3797, 3803, 3821, 14386733, 14386739, 14386837⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3797,
    ExposureEvolution.Compact40Pratt.prime_3803,
    ExposureEvolution.Compact40Pratt.prime_3821,
    ExposureEvolution.Compact40Pratt.prime_14386733,
    ExposureEvolution.Compact40Pratt.prime_14386739,
    ExposureEvolution.Compact40Pratt.prime_14386837]

def block05 : Witness := ⟨⟨14417209, 14462808, 3803, 3821, 3823, 14417023, 14417149, 14417191⟩, 7⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3803,
    ExposureEvolution.Compact40Pratt.prime_3821,
    ExposureEvolution.Compact40Pratt.prime_3823,
    ExposureEvolution.Compact40Pratt.prime_14417023,
    ExposureEvolution.Compact40Pratt.prime_14417149,
    ExposureEvolution.Compact40Pratt.prime_14417191]

def block06 : Witness := ⟨⟨14462809, 14600040, 3821, 3823, 3833, 14462549, 14462783, 14462807⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3821,
    ExposureEvolution.Compact40Pratt.prime_3823,
    ExposureEvolution.Compact40Pratt.prime_3833,
    ExposureEvolution.Compact40Pratt.prime_14462549,
    ExposureEvolution.Compact40Pratt.prime_14462783,
    ExposureEvolution.Compact40Pratt.prime_14462807]

def block07 : Witness := ⟨⟨14600041, 14615328, 3823, 3833, 3847, 14599639, 14599759, 14600017⟩, 13⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3823,
    ExposureEvolution.Compact40Pratt.prime_3833,
    ExposureEvolution.Compact40Pratt.prime_3847,
    ExposureEvolution.Compact40Pratt.prime_14599639,
    ExposureEvolution.Compact40Pratt.prime_14599759,
    ExposureEvolution.Compact40Pratt.prime_14600017]

def block08 : Witness := ⟨⟨14615329, 14691888, 3833, 3847, 3851, 14615201, 14615239, 14615309⟩, 7⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3833,
    ExposureEvolution.Compact40Pratt.prime_3847,
    ExposureEvolution.Compact40Pratt.prime_3851,
    ExposureEvolution.Compact40Pratt.prime_14615201,
    ExposureEvolution.Compact40Pratt.prime_14615239,
    ExposureEvolution.Compact40Pratt.prime_14615309]

def block09 : Witness := ⟨⟨14691889, 14799408, 3847, 3851, 3853, 14691511, 14691877, 14691881⟩, 10⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3847,
    ExposureEvolution.Compact40Pratt.prime_3851,
    ExposureEvolution.Compact40Pratt.prime_3853,
    ExposureEvolution.Compact40Pratt.prime_14691511,
    ExposureEvolution.Compact40Pratt.prime_14691877,
    ExposureEvolution.Compact40Pratt.prime_14691881]

def block10 : Witness := ⟨⟨14799409, 14830200, 3851, 3853, 3863, 14798941, 14799397, 14799403⟩, 10⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3851,
    ExposureEvolution.Compact40Pratt.prime_3853,
    ExposureEvolution.Compact40Pratt.prime_3863,
    ExposureEvolution.Compact40Pratt.prime_14798941,
    ExposureEvolution.Compact40Pratt.prime_14799397,
    ExposureEvolution.Compact40Pratt.prime_14799403]

def block11 : Witness := ⟨⟨14830201, 14845608, 3853, 3863, 3877, 14829721, 14830033, 14830199⟩, 10⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3853,
    ExposureEvolution.Compact40Pratt.prime_3863,
    ExposureEvolution.Compact40Pratt.prime_3877,
    ExposureEvolution.Compact40Pratt.prime_14829721,
    ExposureEvolution.Compact40Pratt.prime_14830033,
    ExposureEvolution.Compact40Pratt.prime_14830199]

def block12 : Witness := ⟨⟨14845609, 14922768, 3863, 3877, 3881, 14845231, 14845469, 14845591⟩, 10⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3863,
    ExposureEvolution.Compact40Pratt.prime_3877,
    ExposureEvolution.Compact40Pratt.prime_3881,
    ExposureEvolution.Compact40Pratt.prime_14845231,
    ExposureEvolution.Compact40Pratt.prime_14845469,
    ExposureEvolution.Compact40Pratt.prime_14845591]

def block13 : Witness := ⟨⟨14922769, 15031128, 3877, 3881, 3889, 14922599, 14922757, 14922767⟩, 10⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3877,
    ExposureEvolution.Compact40Pratt.prime_3881,
    ExposureEvolution.Compact40Pratt.prime_3889,
    ExposureEvolution.Compact40Pratt.prime_14922599,
    ExposureEvolution.Compact40Pratt.prime_14922757,
    ExposureEvolution.Compact40Pratt.prime_14922767]

def block14 : Witness := ⟨⟨15031129, 15062160, 3881, 3889, 3907, 15030857, 15030947, 15031103⟩, 11⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3881,
    ExposureEvolution.Compact40Pratt.prime_3889,
    ExposureEvolution.Compact40Pratt.prime_3907,
    ExposureEvolution.Compact40Pratt.prime_15030857,
    ExposureEvolution.Compact40Pratt.prime_15030947,
    ExposureEvolution.Compact40Pratt.prime_15031103]

def block15 : Witness := ⟨⟨15062161, 15124320, 3889, 3907, 3911, 15061811, 15062057, 15062143⟩, 10⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3889,
    ExposureEvolution.Compact40Pratt.prime_3907,
    ExposureEvolution.Compact40Pratt.prime_3911,
    ExposureEvolution.Compact40Pratt.prime_15061811,
    ExposureEvolution.Compact40Pratt.prime_15062057,
    ExposureEvolution.Compact40Pratt.prime_15062143]

def block16 : Witness := ⟨⟨15124321, 15264648, 3907, 3911, 3917, 15124099, 15124297, 15124309⟩, 9⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3907,
    ExposureEvolution.Compact40Pratt.prime_3911,
    ExposureEvolution.Compact40Pratt.prime_3917,
    ExposureEvolution.Compact40Pratt.prime_15124099,
    ExposureEvolution.Compact40Pratt.prime_15124297,
    ExposureEvolution.Compact40Pratt.prime_15124309]

def block17 : Witness := ⟨⟨15264649, 15295920, 3911, 3917, 3919, 15264287, 15264311, 15264637⟩, 11⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3911,
    ExposureEvolution.Compact40Pratt.prime_3917,
    ExposureEvolution.Compact40Pratt.prime_3919,
    ExposureEvolution.Compact40Pratt.prime_15264287,
    ExposureEvolution.Compact40Pratt.prime_15264311,
    ExposureEvolution.Compact40Pratt.prime_15264637]

def block18 : Witness := ⟨⟨15295921, 15342888, 3917, 3919, 3923, 15295447, 15295717, 15295919⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3917,
    ExposureEvolution.Compact40Pratt.prime_3919,
    ExposureEvolution.Compact40Pratt.prime_3923,
    ExposureEvolution.Compact40Pratt.prime_15295447,
    ExposureEvolution.Compact40Pratt.prime_15295717,
    ExposureEvolution.Compact40Pratt.prime_15295919]

def block19 : Witness := ⟨⟨15342889, 15358560, 3919, 3923, 3929, 15342581, 15342763, 15342883⟩, 11⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3919,
    ExposureEvolution.Compact40Pratt.prime_3923,
    ExposureEvolution.Compact40Pratt.prime_3929,
    ExposureEvolution.Compact40Pratt.prime_15342581,
    ExposureEvolution.Compact40Pratt.prime_15342763,
    ExposureEvolution.Compact40Pratt.prime_15342883]

def block20 : Witness := ⟨⟨15358561, 15389928, 3923, 3929, 3931, 15358159, 15358373, 15358537⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3923,
    ExposureEvolution.Compact40Pratt.prime_3929,
    ExposureEvolution.Compact40Pratt.prime_3931,
    ExposureEvolution.Compact40Pratt.prime_15358159,
    ExposureEvolution.Compact40Pratt.prime_15358373,
    ExposureEvolution.Compact40Pratt.prime_15358537]

def block21 : Witness := ⟨⟨15389929, 15437040, 3929, 3931, 3943, 15389441, 15389519, 15389909⟩, 9⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3929,
    ExposureEvolution.Compact40Pratt.prime_3931,
    ExposureEvolution.Compact40Pratt.prime_3943,
    ExposureEvolution.Compact40Pratt.prime_15389441,
    ExposureEvolution.Compact40Pratt.prime_15389519,
    ExposureEvolution.Compact40Pratt.prime_15389909]

def block22 : Witness := ⟨⟨15437041, 15452760, 3931, 3943, 3947, 15436313, 15436373, 15436943⟩, 10⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3931,
    ExposureEvolution.Compact40Pratt.prime_3943,
    ExposureEvolution.Compact40Pratt.prime_3947,
    ExposureEvolution.Compact40Pratt.prime_15436313,
    ExposureEvolution.Compact40Pratt.prime_15436373,
    ExposureEvolution.Compact40Pratt.prime_15436943]

def block23 : Witness := ⟨⟨15452761, 15547248, 3943, 3947, 3967, 15452417, 15452443, 15452747⟩, 11⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3943,
    ExposureEvolution.Compact40Pratt.prime_3947,
    ExposureEvolution.Compact40Pratt.prime_3967,
    ExposureEvolution.Compact40Pratt.prime_15452417,
    ExposureEvolution.Compact40Pratt.prime_15452443,
    ExposureEvolution.Compact40Pratt.prime_15452747]

def block24 : Witness := ⟨⟨15547249, 15578808, 3947, 3967, 3989, 15547019, 15547099, 15547247⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3947,
    ExposureEvolution.Compact40Pratt.prime_3967,
    ExposureEvolution.Compact40Pratt.prime_3989,
    ExposureEvolution.Compact40Pratt.prime_15547019,
    ExposureEvolution.Compact40Pratt.prime_15547099,
    ExposureEvolution.Compact40Pratt.prime_15547247]

def block25 : Witness := ⟨⟨15578809, 15737088, 3967, 3989, 4001, 15578467, 15578779, 15578807⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3967,
    ExposureEvolution.Compact40Pratt.prime_3989,
    ExposureEvolution.Compact40Pratt.prime_4001,
    ExposureEvolution.Compact40Pratt.prime_15578467,
    ExposureEvolution.Compact40Pratt.prime_15578779,
    ExposureEvolution.Compact40Pratt.prime_15578807]

def block26 : Witness := ⟨⟨15737089, 15912120, 3989, 4001, 4003, 15736873, 15737023, 15737081⟩, 9⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3989,
    ExposureEvolution.Compact40Pratt.prime_4001,
    ExposureEvolution.Compact40Pratt.prime_4003,
    ExposureEvolution.Compact40Pratt.prime_15736873,
    ExposureEvolution.Compact40Pratt.prime_15737023,
    ExposureEvolution.Compact40Pratt.prime_15737081]

def block27 : Witness := ⟨⟨15912121, 16008000, 4001, 4003, 4007, 15911647, 15911717, 15912079⟩, 10⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4001,
    ExposureEvolution.Compact40Pratt.prime_4003,
    ExposureEvolution.Compact40Pratt.prime_4007,
    ExposureEvolution.Compact40Pratt.prime_15911647,
    ExposureEvolution.Compact40Pratt.prime_15911717,
    ExposureEvolution.Compact40Pratt.prime_15912079]

def block28 : Witness := ⟨⟨16008001, 16024008, 4003, 4007, 4013, 16007531, 16007603, 16007993⟩, 9⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4003,
    ExposureEvolution.Compact40Pratt.prime_4007,
    ExposureEvolution.Compact40Pratt.prime_4013,
    ExposureEvolution.Compact40Pratt.prime_16007531,
    ExposureEvolution.Compact40Pratt.prime_16007603,
    ExposureEvolution.Compact40Pratt.prime_16007993]

def block29 : Witness := ⟨⟨16024009, 16056048, 4007, 4013, 4019, 16023583, 16023611, 16024007⟩, 8⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4007,
    ExposureEvolution.Compact40Pratt.prime_4013,
    ExposureEvolution.Compact40Pratt.prime_4019,
    ExposureEvolution.Compact40Pratt.prime_16023583,
    ExposureEvolution.Compact40Pratt.prime_16023611,
    ExposureEvolution.Compact40Pratt.prime_16024007]

def block30 : Witness := ⟨⟨16056049, 16104168, 4013, 4019, 4021, 16055843, 16056023, 16056031⟩, 15⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4013,
    ExposureEvolution.Compact40Pratt.prime_4019,
    ExposureEvolution.Compact40Pratt.prime_4021,
    ExposureEvolution.Compact40Pratt.prime_16055843,
    ExposureEvolution.Compact40Pratt.prime_16056023,
    ExposureEvolution.Compact40Pratt.prime_16056031]

def block31 : Witness := ⟨⟨16104169, 16152360, 4019, 4021, 4027, 16103839, 16104157, 16104167⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4019,
    ExposureEvolution.Compact40Pratt.prime_4021,
    ExposureEvolution.Compact40Pratt.prime_4027,
    ExposureEvolution.Compact40Pratt.prime_16103839,
    ExposureEvolution.Compact40Pratt.prime_16104157,
    ExposureEvolution.Compact40Pratt.prime_16104167]

def block32 : Witness := ⟨⟨16152361, 16168440, 4021, 4027, 4049, 16152167, 16152341, 16152347⟩, 9⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4021,
    ExposureEvolution.Compact40Pratt.prime_4027,
    ExposureEvolution.Compact40Pratt.prime_4049,
    ExposureEvolution.Compact40Pratt.prime_16152167,
    ExposureEvolution.Compact40Pratt.prime_16152341,
    ExposureEvolution.Compact40Pratt.prime_16152347]

def block33 : Witness := ⟨⟨16168441, 16216728, 4027, 4049, 4051, 16168417, 16168429, 16168433⟩, 9⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4027,
    ExposureEvolution.Compact40Pratt.prime_4049,
    ExposureEvolution.Compact40Pratt.prime_4051,
    ExposureEvolution.Compact40Pratt.prime_16168417,
    ExposureEvolution.Compact40Pratt.prime_16168429,
    ExposureEvolution.Compact40Pratt.prime_16168433]

def block34 : Witness := ⟨⟨16216729, 16394400, 4049, 4051, 4057, 16216399, 16216637, 16216723⟩, 9⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4049,
    ExposureEvolution.Compact40Pratt.prime_4051,
    ExposureEvolution.Compact40Pratt.prime_4057,
    ExposureEvolution.Compact40Pratt.prime_16216399,
    ExposureEvolution.Compact40Pratt.prime_16216637,
    ExposureEvolution.Compact40Pratt.prime_16216723]

def block35 : Witness := ⟨⟨16394401, 16410600, 4051, 4057, 4073, 16394233, 16394353, 16394393⟩, 12⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4051,
    ExposureEvolution.Compact40Pratt.prime_4057,
    ExposureEvolution.Compact40Pratt.prime_4073,
    ExposureEvolution.Compact40Pratt.prime_16394233,
    ExposureEvolution.Compact40Pratt.prime_16394353,
    ExposureEvolution.Compact40Pratt.prime_16394393]

def block36 : Witness := ⟨⟨16410601, 16459248, 4057, 4073, 4079, 16410113, 16410463, 16410599⟩, 9⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4057,
    ExposureEvolution.Compact40Pratt.prime_4073,
    ExposureEvolution.Compact40Pratt.prime_4079,
    ExposureEvolution.Compact40Pratt.prime_16410113,
    ExposureEvolution.Compact40Pratt.prime_16410463,
    ExposureEvolution.Compact40Pratt.prime_16410599]

def block37 : Witness := ⟨⟨16459249, 16589328, 4073, 4079, 4091, 16458791, 16459021, 16459207⟩, 8⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4073,
    ExposureEvolution.Compact40Pratt.prime_4079,
    ExposureEvolution.Compact40Pratt.prime_4091,
    ExposureEvolution.Compact40Pratt.prime_16458791,
    ExposureEvolution.Compact40Pratt.prime_16459021,
    ExposureEvolution.Compact40Pratt.prime_16459207]

def block38 : Witness := ⟨⟨16589329, 16638240, 4079, 4091, 4093, 16589137, 16589219, 16589317⟩, 8⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4079,
    ExposureEvolution.Compact40Pratt.prime_4091,
    ExposureEvolution.Compact40Pratt.prime_4093,
    ExposureEvolution.Compact40Pratt.prime_16589137,
    ExposureEvolution.Compact40Pratt.prime_16589219,
    ExposureEvolution.Compact40Pratt.prime_16589317]

def block39 : Witness := ⟨⟨16638241, 16736280, 4091, 4093, 4099, 16637857, 16637897, 16638221⟩, 10⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4091,
    ExposureEvolution.Compact40Pratt.prime_4093,
    ExposureEvolution.Compact40Pratt.prime_4099,
    ExposureEvolution.Compact40Pratt.prime_16637857,
    ExposureEvolution.Compact40Pratt.prime_16637897,
    ExposureEvolution.Compact40Pratt.prime_16638221]

def block40 : Witness := ⟨⟨16736281, 16752648, 4093, 4099, 4111, 16735853, 16736257, 16736273⟩, 7⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4093,
    ExposureEvolution.Compact40Pratt.prime_4099,
    ExposureEvolution.Compact40Pratt.prime_4111,
    ExposureEvolution.Compact40Pratt.prime_16735853,
    ExposureEvolution.Compact40Pratt.prime_16736257,
    ExposureEvolution.Compact40Pratt.prime_16736273]

def block41 : Witness := ⟨⟨16752649, 16801800, 4099, 4111, 4127, 16752181, 16752469, 16752647⟩, 9⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4099,
    ExposureEvolution.Compact40Pratt.prime_4111,
    ExposureEvolution.Compact40Pratt.prime_4127,
    ExposureEvolution.Compact40Pratt.prime_16752181,
    ExposureEvolution.Compact40Pratt.prime_16752469,
    ExposureEvolution.Compact40Pratt.prime_16752647]

def block42 : Witness := ⟨⟨16801801, 16900320, 4111, 4127, 4129, 16801391, 16801781, 16801793⟩, 10⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4111,
    ExposureEvolution.Compact40Pratt.prime_4127,
    ExposureEvolution.Compact40Pratt.prime_4129,
    ExposureEvolution.Compact40Pratt.prime_16801391,
    ExposureEvolution.Compact40Pratt.prime_16801781,
    ExposureEvolution.Compact40Pratt.prime_16801793]

def block43 : Witness := ⟨⟨16900321, 17032128, 4127, 4129, 4133, 16900097, 16900249, 16900309⟩, 9⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4127,
    ExposureEvolution.Compact40Pratt.prime_4129,
    ExposureEvolution.Compact40Pratt.prime_4133,
    ExposureEvolution.Compact40Pratt.prime_16900097,
    ExposureEvolution.Compact40Pratt.prime_16900249,
    ExposureEvolution.Compact40Pratt.prime_16900309]

def block44 : Witness := ⟨⟨17032129, 17048640, 4129, 4133, 4139, 17031541, 17031659, 17032123⟩, 13⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4129,
    ExposureEvolution.Compact40Pratt.prime_4133,
    ExposureEvolution.Compact40Pratt.prime_4139,
    ExposureEvolution.Compact40Pratt.prime_17031541,
    ExposureEvolution.Compact40Pratt.prime_17031659,
    ExposureEvolution.Compact40Pratt.prime_17032123]

def block45 : Witness := ⟨⟨17048641, 17081688, 4133, 4139, 4153, 17048393, 17048513, 17048617⟩, 7⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4133,
    ExposureEvolution.Compact40Pratt.prime_4139,
    ExposureEvolution.Compact40Pratt.prime_4153,
    ExposureEvolution.Compact40Pratt.prime_17048393,
    ExposureEvolution.Compact40Pratt.prime_17048513,
    ExposureEvolution.Compact40Pratt.prime_17048617]

def block46 : Witness := ⟨⟨17081689, 17131320, 4139, 4153, 4157, 17081557, 17081611, 17081671⟩, 8⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4139,
    ExposureEvolution.Compact40Pratt.prime_4153,
    ExposureEvolution.Compact40Pratt.prime_4157,
    ExposureEvolution.Compact40Pratt.prime_17081557,
    ExposureEvolution.Compact40Pratt.prime_17081611,
    ExposureEvolution.Compact40Pratt.prime_17081671]

def block47 : Witness := ⟨⟨17131321, 17247408, 4153, 4157, 4159, 17131237, 17131273, 17131277⟩, 9⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4153,
    ExposureEvolution.Compact40Pratt.prime_4157,
    ExposureEvolution.Compact40Pratt.prime_4159,
    ExposureEvolution.Compact40Pratt.prime_17131237,
    ExposureEvolution.Compact40Pratt.prime_17131273,
    ExposureEvolution.Compact40Pratt.prime_17131277]

def block48 : Witness := ⟨⟨17247409, 17280648, 4157, 4159, 4177, 17247047, 17247361, 17247407⟩, 11⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4157,
    ExposureEvolution.Compact40Pratt.prime_4159,
    ExposureEvolution.Compact40Pratt.prime_4177,
    ExposureEvolution.Compact40Pratt.prime_17247047,
    ExposureEvolution.Compact40Pratt.prime_17247361,
    ExposureEvolution.Compact40Pratt.prime_17247407]

def block49 : Witness := ⟨⟨17280649, 17297280, 4159, 4177, 4201, 17280283, 17280359, 17280611⟩, 6⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4159,
    ExposureEvolution.Compact40Pratt.prime_4177,
    ExposureEvolution.Compact40Pratt.prime_4201,
    ExposureEvolution.Compact40Pratt.prime_17280283,
    ExposureEvolution.Compact40Pratt.prime_17280359,
    ExposureEvolution.Compact40Pratt.prime_17280611]

def block50 : Witness := ⟨⟨17297281, 17447328, 4177, 4201, 4211, 17296931, 17297257, 17297263⟩, 8⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4177,
    ExposureEvolution.Compact40Pratt.prime_4201,
    ExposureEvolution.Compact40Pratt.prime_4211,
    ExposureEvolution.Compact40Pratt.prime_17296931,
    ExposureEvolution.Compact40Pratt.prime_17297257,
    ExposureEvolution.Compact40Pratt.prime_17297263]

def block51 : Witness := ⟨⟨17447329, 17648400, 4201, 4211, 4217, 17446907, 17447237, 17447323⟩, 10⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4201,
    ExposureEvolution.Compact40Pratt.prime_4211,
    ExposureEvolution.Compact40Pratt.prime_4217,
    ExposureEvolution.Compact40Pratt.prime_17446907,
    ExposureEvolution.Compact40Pratt.prime_17447237,
    ExposureEvolution.Compact40Pratt.prime_17447323]

def block52 : Witness := ⟨⟨17648401, 17732520, 4211, 4217, 4219, 17648003, 17648027, 17648387⟩, 10⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4211,
    ExposureEvolution.Compact40Pratt.prime_4217,
    ExposureEvolution.Compact40Pratt.prime_4219,
    ExposureEvolution.Compact40Pratt.prime_17648003,
    ExposureEvolution.Compact40Pratt.prime_17648027,
    ExposureEvolution.Compact40Pratt.prime_17648387]

def block53 : Witness := ⟨⟨17732521, 17783088, 4217, 4219, 4229, 17732381, 17732413, 17732483⟩, 13⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4217,
    ExposureEvolution.Compact40Pratt.prime_4219,
    ExposureEvolution.Compact40Pratt.prime_4229,
    ExposureEvolution.Compact40Pratt.prime_17732381,
    ExposureEvolution.Compact40Pratt.prime_17732413,
    ExposureEvolution.Compact40Pratt.prime_17732483]

def block54 : Witness := ⟨⟨17783089, 17799960, 4219, 4229, 4231, 17782861, 17783039, 17783063⟩, 8⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4219,
    ExposureEvolution.Compact40Pratt.prime_4229,
    ExposureEvolution.Compact40Pratt.prime_4231,
    ExposureEvolution.Compact40Pratt.prime_17782861,
    ExposureEvolution.Compact40Pratt.prime_17783039,
    ExposureEvolution.Compact40Pratt.prime_17783063]

def block55 : Witness := ⟨⟨17799961, 17884440, 4229, 4231, 4241, 17799773, 17799841, 17799959⟩, 7⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4229,
    ExposureEvolution.Compact40Pratt.prime_4231,
    ExposureEvolution.Compact40Pratt.prime_4241,
    ExposureEvolution.Compact40Pratt.prime_17799773,
    ExposureEvolution.Compact40Pratt.prime_17799841,
    ExposureEvolution.Compact40Pratt.prime_17799959]

def block56 : Witness := ⟨⟨17884441, 17901360, 4231, 4241, 4243, 17884193, 17884249, 17884439⟩, 10⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4231,
    ExposureEvolution.Compact40Pratt.prime_4241,
    ExposureEvolution.Compact40Pratt.prime_4243,
    ExposureEvolution.Compact40Pratt.prime_17884193,
    ExposureEvolution.Compact40Pratt.prime_17884249,
    ExposureEvolution.Compact40Pratt.prime_17884439]

def block57 : Witness := ⟨⟨17901361, 17986080, 4241, 4243, 4253, 17901071, 17901197, 17901349⟩, 10⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4241,
    ExposureEvolution.Compact40Pratt.prime_4243,
    ExposureEvolution.Compact40Pratt.prime_4253,
    ExposureEvolution.Compact40Pratt.prime_17901071,
    ExposureEvolution.Compact40Pratt.prime_17901197,
    ExposureEvolution.Compact40Pratt.prime_17901349]

def block58 : Witness := ⟨⟨17986081, 18003048, 4243, 4253, 4259, 17985853, 17986049, 17986079⟩, 9⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4243,
    ExposureEvolution.Compact40Pratt.prime_4253,
    ExposureEvolution.Compact40Pratt.prime_4259,
    ExposureEvolution.Compact40Pratt.prime_17985853,
    ExposureEvolution.Compact40Pratt.prime_17986049,
    ExposureEvolution.Compact40Pratt.prime_17986079]

def block59 : Witness := ⟨⟨18003049, 18088008, 4253, 4259, 4261, 18002891, 18002921, 18003023⟩, 9⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4253,
    ExposureEvolution.Compact40Pratt.prime_4259,
    ExposureEvolution.Compact40Pratt.prime_4261,
    ExposureEvolution.Compact40Pratt.prime_18002891,
    ExposureEvolution.Compact40Pratt.prime_18002921,
    ExposureEvolution.Compact40Pratt.prime_18003023]

def block60 : Witness := ⟨⟨18088009, 18139080, 4259, 4261, 4271, 18087479, 18087887, 18087991⟩, 10⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4259,
    ExposureEvolution.Compact40Pratt.prime_4261,
    ExposureEvolution.Compact40Pratt.prime_4271,
    ExposureEvolution.Compact40Pratt.prime_18087479,
    ExposureEvolution.Compact40Pratt.prime_18087887,
    ExposureEvolution.Compact40Pratt.prime_18087991]

def block61 : Witness := ⟨⟨18139081, 18156120, 4261, 4271, 4273, 18138661, 18138739, 18139073⟩, 6⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4261,
    ExposureEvolution.Compact40Pratt.prime_4271,
    ExposureEvolution.Compact40Pratt.prime_4273,
    ExposureEvolution.Compact40Pratt.prime_18138661,
    ExposureEvolution.Compact40Pratt.prime_18138739,
    ExposureEvolution.Compact40Pratt.prime_18139073]

def block62 : Witness := ⟨⟨18156121, 18241440, 4271, 4273, 4283, 18155747, 18155783, 18156107⟩, 10⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4271,
    ExposureEvolution.Compact40Pratt.prime_4273,
    ExposureEvolution.Compact40Pratt.prime_4283,
    ExposureEvolution.Compact40Pratt.prime_18155747,
    ExposureEvolution.Compact40Pratt.prime_18155783,
    ExposureEvolution.Compact40Pratt.prime_18156107]

def block63 : Witness := ⟨⟨18241441, 18258528, 4273, 4283, 4289, 18241081, 18241163, 18241439⟩, 11⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_4273,
    ExposureEvolution.Compact40Pratt.prime_4283,
    ExposureEvolution.Compact40Pratt.prime_4289,
    ExposureEvolution.Compact40Pratt.prime_18241081,
    ExposureEvolution.Compact40Pratt.prime_18241163,
    ExposureEvolution.Compact40Pratt.prime_18241439]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 18258529 stop tail = true) :
    coverage 14145121 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_003
