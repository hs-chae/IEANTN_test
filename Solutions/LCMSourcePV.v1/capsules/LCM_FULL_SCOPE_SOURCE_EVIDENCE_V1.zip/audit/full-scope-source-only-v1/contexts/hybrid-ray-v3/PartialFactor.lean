/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import Mathlib

/-! Self-contained new partial-factor Pocklington checker.
`modPow`, `modPow_eq` and `modPow_cast` reuse the generic arbitrary-precision
arithmetic implementation in
`ieantn-ntt-composition-20261010/lean/GoldbachGPU/Certificates/ModPow.lean`.
The partial-factor primality proof and node checker are new here. -/
namespace Round2Recovery.PartialFactor

def modPow (a e n : ℕ) : ℕ :=
  if e = 0 then 1 % n else
    let r := modPow a (e / 2) n
    if e % 2 = 0 then r * r % n else r * r * a % n
termination_by e

theorem modPow_eq (a e n : ℕ) : modPow a e n = a ^ e % n := by
  induction e using Nat.strong_induction_on with
  | h e ih =>
    rw [modPow]
    split
    · next he => simp [he]
    · next he =>
      have ht : e / 2 < e := Nat.div_lt_self (by omega) (by omega)
      rw [ih _ ht]
      have hd := Nat.mod_add_div e 2
      have hm := Nat.mod_lt e (by omega : 0 < 2)
      split
      · next hz =>
        have hx : e = e/2 + e/2 := by omega
        conv_rhs => rw [hx, pow_add]
        simp [Nat.mul_mod]
      · next hz =>
        have hx : e = e/2 + e/2 + 1 := by omega
        conv_rhs => rw [hx, pow_add, pow_add]
        simp [Nat.mul_mod]

theorem modPow_cast (a e n : ℕ) : (modPow a e n : ZMod n) = (a : ZMod n)^e := by
  rw [modPow_eq, ZMod.natCast_mod, Nat.cast_pow]

theorem partial_factor_prime {n q r a : ℕ} (hn : 2 ≤ n) (hq : q.Prime)
    (hprod : n - 1 = r * q) (hlarge : n < q ^ 2)
    (hpow : modPow a (n - 1) n = 1)
    (hcop : (modPow a r n + n - 1).Coprime n) : n.Prime := by
  by_contra hnp
  let p := n.minFac
  have hp : p.Prime := Nat.minFac_prime (by omega : n ≠ 1)
  have hpn : p ∣ n := Nat.minFac_dvd n
  have hpsq : p ^ 2 ≤ n := Nat.minFac_sq_le_self (by omega : 0 < n) hnp
  haveI : Fact p.Prime := ⟨hp⟩
  have ha_n : (a : ZMod n) ^ (n - 1) = 1 := by
    rw [← modPow_cast, hpow]
    simp
  have ha_p : (a : ZMod p) ^ (n - 1) = 1 := by
    have hh := congrArg (ZMod.castHom hpn (ZMod p)) ha_n
    simpa only [ZMod.castHom_apply, ZMod.cast_pow hpn, ZMod.cast_natCast hpn,
      ZMod.cast_one hpn] using hh
  have hnpos : 0 < n - 1 := by omega
  have ha0 : (a : ZMod p) ≠ 0 := by
    intro hz
    rw [hz, zero_pow hnpos.ne'] at ha_p
    exact zero_ne_one ha_p
  have har : (a : ZMod p) ^ r ≠ 1 := by
    intro he
    have hc : (modPow a r n : ZMod p) = 1 := by
      have hh := congrArg (ZMod.castHom hpn (ZMod p)) (modPow_cast a r n)
      simpa only [ZMod.castHom_apply, ZMod.cast_pow hpn, ZMod.cast_natCast hpn, he] using hh
    have hzero : ((modPow a r n + n - 1 : ℕ) : ZMod p) = 0 := by
      rw [Nat.cast_sub (by omega : 1 ≤ modPow a r n + n), Nat.cast_add]
      have hnzero : (n : ZMod p) = 0 := (ZMod.natCast_eq_zero_iff n p).mpr hpn
      simp [hc, hnzero]
    have hd : p ∣ modPow a r n + n - 1 :=
      (ZMod.natCast_eq_zero_iff _ _).mp hzero
    have hbad := Nat.dvd_gcd hd hpn
    rw [hcop.gcd_eq_one] at hbad
    exact hp.not_dvd_one hbad
  have hord : orderOf (a : ZMod p) ∣ r * q := by
    rw [← hprod]
    exact orderOf_dvd_of_pow_eq_one ha_p
  have hqord : q ∣ orderOf (a : ZMod p) := by
    by_contra hh
    have hc : (orderOf (a : ZMod p)).Coprime q :=
      (hq.coprime_iff_not_dvd.mpr hh).symm
    have hd : orderOf (a : ZMod p) ∣ r := hc.dvd_of_dvd_mul_right hord
    exact har (orderOf_dvd_iff_pow_eq_one.mp hd)
  have hqp : q ∣ p - 1 := hqord.trans (ZMod.orderOf_dvd_card_sub_one ha0)
  have hp2 : 2 ≤ p := hp.two_le
  have hqle : q ≤ p - 1 := Nat.le_of_dvd (by omega : 0 < p - 1) hqp
  have hqplt : q < p := by omega
  nlinarith

structure Node where
  n : ℕ
  parent : ℕ
  multiplier : ℕ
  base : ℕ
  deriving Repr

def checkNode (known : List ℕ) (c : Node) : Bool :=
  decide (2 ≤ c.n ∧ c.parent ∈ known ∧ c.n - 1 = c.multiplier * c.parent ∧
    c.n < c.parent ^ 2 ∧ modPow c.base (c.n - 1) c.n = 1 ∧
    (modPow c.base c.multiplier c.n + c.n - 1).Coprime c.n)

theorem checkNode_sound {known : List ℕ} {c : Node}
    (hk : ∀ q ∈ known, Nat.Prime q) (hc : checkNode known c = true) : c.n.Prime := by
  simp only [checkNode, decide_eq_true_eq] at hc
  exact partial_factor_prime hc.1 (hk _ hc.2.1) hc.2.2.1 hc.2.2.2.1
    hc.2.2.2.2.1 hc.2.2.2.2.2

end Round2Recovery.PartialFactor

#print axioms Round2Recovery.PartialFactor.partial_factor_prime
