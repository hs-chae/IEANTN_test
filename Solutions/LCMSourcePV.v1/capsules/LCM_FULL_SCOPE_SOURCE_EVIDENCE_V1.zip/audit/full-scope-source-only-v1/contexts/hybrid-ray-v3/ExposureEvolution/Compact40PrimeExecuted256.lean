import ExposureEvolution.Compact40PrimeProgram256
import ExposureEvolution.Compact40PrimeLinks000
import ExposureEvolution.Compact40PrimeLinks001
import ExposureEvolution.Compact40PrimeLinks002
import ExposureEvolution.Compact40PrimeLinks003
import ExposureEvolution.Compact40PrimeLinks004
import ExposureEvolution.Compact40PrimeLinks005
import ExposureEvolution.Compact40PrimeLinks006
import ExposureEvolution.Compact40PrimeLinks007
import ExposureEvolution.Compact40PrimeLinks008
import ExposureEvolution.Compact40PrimeLinks009
import ExposureEvolution.Compact40PrimeLinks010
import ExposureEvolution.Compact40PrimeLinks011
import ExposureEvolution.Compact40PrimeLinks012
import ExposureEvolution.Compact40PrimeLinks013
import ExposureEvolution.Compact40PrimeLinks014
import ExposureEvolution.Compact40PrimeLinks015
import ExposureEvolution.Compact40PrimeLinks016
import ExposureEvolution.Compact40PrimeLinks017
import ExposureEvolution.Compact40PrimeLinks018
import ExposureEvolution.Compact40PrimeLinks019
import ExposureEvolution.Compact40PrimeLinks020
namespace ExposureEvolution.Compact40PrimeExecuted256
open ExposureEvolution.Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem same_values : output =
  ExposureEvolution.Compact40PrimeLinks000.primes ++
  ExposureEvolution.Compact40PrimeLinks001.primes ++
  ExposureEvolution.Compact40PrimeLinks002.primes ++
  ExposureEvolution.Compact40PrimeLinks003.primes ++
  ExposureEvolution.Compact40PrimeLinks004.primes ++
  ExposureEvolution.Compact40PrimeLinks005.primes ++
  ExposureEvolution.Compact40PrimeLinks006.primes ++
  ExposureEvolution.Compact40PrimeLinks007.primes ++
  ExposureEvolution.Compact40PrimeLinks008.primes ++
  ExposureEvolution.Compact40PrimeLinks009.primes ++
  ExposureEvolution.Compact40PrimeLinks010.primes ++
  ExposureEvolution.Compact40PrimeLinks011.primes ++
  ExposureEvolution.Compact40PrimeLinks012.primes ++
  ExposureEvolution.Compact40PrimeLinks013.primes ++
  ExposureEvolution.Compact40PrimeLinks014.primes ++
  ExposureEvolution.Compact40PrimeLinks015.primes ++
  ExposureEvolution.Compact40PrimeLinks016.primes ++
  ExposureEvolution.Compact40PrimeLinks017.primes ++
  ExposureEvolution.Compact40PrimeLinks018.primes ++
  ExposureEvolution.Compact40PrimeLinks019.primes ++
  ExposureEvolution.Compact40PrimeLinks020.primes := by rfl

theorem run_eq : run 700 8468 89693 = output := by
  rw [ExposureEvolution.Compact40PrimeLinks000.segment]
  rw [ExposureEvolution.Compact40PrimeLinks001.segment]
  rw [ExposureEvolution.Compact40PrimeLinks002.segment]
  rw [ExposureEvolution.Compact40PrimeLinks003.segment]
  rw [ExposureEvolution.Compact40PrimeLinks004.segment]
  rw [ExposureEvolution.Compact40PrimeLinks005.segment]
  rw [ExposureEvolution.Compact40PrimeLinks006.segment]
  rw [ExposureEvolution.Compact40PrimeLinks007.segment]
  rw [ExposureEvolution.Compact40PrimeLinks008.segment]
  rw [ExposureEvolution.Compact40PrimeLinks009.segment]
  rw [ExposureEvolution.Compact40PrimeLinks010.segment]
  rw [ExposureEvolution.Compact40PrimeLinks011.segment]
  rw [ExposureEvolution.Compact40PrimeLinks012.segment]
  rw [ExposureEvolution.Compact40PrimeLinks013.segment]
  rw [ExposureEvolution.Compact40PrimeLinks014.segment]
  rw [ExposureEvolution.Compact40PrimeLinks015.segment]
  rw [ExposureEvolution.Compact40PrimeLinks016.segment]
  rw [ExposureEvolution.Compact40PrimeLinks017.segment]
  rw [ExposureEvolution.Compact40PrimeLinks018.segment]
  rw [ExposureEvolution.Compact40PrimeLinks019.segment]
  rw [ExposureEvolution.Compact40PrimeLinks020.segment]
  have hstop : run 31 89867 89693 = [] := by rfl
  rw [hstop]
  rfl

theorem accepted : check 8468 89693 output = true := by
  rw [same_values]
  apply ExposureEvolution.Compact40PrimeLinks000.extend
  apply ExposureEvolution.Compact40PrimeLinks001.extend
  apply ExposureEvolution.Compact40PrimeLinks002.extend
  apply ExposureEvolution.Compact40PrimeLinks003.extend
  apply ExposureEvolution.Compact40PrimeLinks004.extend
  apply ExposureEvolution.Compact40PrimeLinks005.extend
  apply ExposureEvolution.Compact40PrimeLinks006.extend
  apply ExposureEvolution.Compact40PrimeLinks007.extend
  apply ExposureEvolution.Compact40PrimeLinks008.extend
  apply ExposureEvolution.Compact40PrimeLinks009.extend
  apply ExposureEvolution.Compact40PrimeLinks010.extend
  apply ExposureEvolution.Compact40PrimeLinks011.extend
  apply ExposureEvolution.Compact40PrimeLinks012.extend
  apply ExposureEvolution.Compact40PrimeLinks013.extend
  apply ExposureEvolution.Compact40PrimeLinks014.extend
  apply ExposureEvolution.Compact40PrimeLinks015.extend
  apply ExposureEvolution.Compact40PrimeLinks016.extend
  apply ExposureEvolution.Compact40PrimeLinks017.extend
  apply ExposureEvolution.Compact40PrimeLinks018.extend
  apply ExposureEvolution.Compact40PrimeLinks019.extend
  apply ExposureEvolution.Compact40PrimeLinks020.extend
  decide +kernel

theorem length : output.length = 669 := by rfl

theorem executed : run 700 8468 89693 = output ∧
    check 8468 89693 output = true ∧ output.length = 669 :=
  ⟨run_eq, accepted, length⟩

theorem covered {x : ℝ} (ha : (8468 : ℝ) ≤ x) (hb : x < 89693) :
    ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p : ℝ) < x + x / 256 :=
  sound output accepted ha hb

#print axioms executed
end ExposureEvolution.Compact40PrimeExecuted256
