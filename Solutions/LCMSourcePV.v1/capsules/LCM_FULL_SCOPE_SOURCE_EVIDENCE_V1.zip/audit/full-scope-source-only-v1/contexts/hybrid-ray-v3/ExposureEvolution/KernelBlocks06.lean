import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks06
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨5870929, 5938968, 2437, 2441, 2447, 5870467, 5870561, 5870927⟩, 12⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2437,
    ExposureEvolution.KernelPratt.prime_2441,
    ExposureEvolution.KernelPratt.prime_2447,
    ExposureEvolution.KernelPratt.prime_5870467,
    ExposureEvolution.KernelPratt.prime_5870561,
    ExposureEvolution.KernelPratt.prime_5870927]

def block01 : Witness := ⟨⟨5938969, 5958480, 2441, 2447, 2459, 5938663, 5938711, 5938957⟩, 9⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2441,
    ExposureEvolution.KernelPratt.prime_2447,
    ExposureEvolution.KernelPratt.prime_2459,
    ExposureEvolution.KernelPratt.prime_5938663,
    ExposureEvolution.KernelPratt.prime_5938711,
    ExposureEvolution.KernelPratt.prime_5938957]

def block02 : Witness := ⟨⟨5958481, 5987808, 2447, 2459, 2467, 5957971, 5958319, 5958473⟩, 9⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2447,
    ExposureEvolution.KernelPratt.prime_2459,
    ExposureEvolution.KernelPratt.prime_2467,
    ExposureEvolution.KernelPratt.prime_5957971,
    ExposureEvolution.KernelPratt.prime_5958319,
    ExposureEvolution.KernelPratt.prime_5958473]

def block03 : Witness := ⟨⟨5987809, 6046680, 2459, 2467, 2473, 5987447, 5987551, 5987803⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2459,
    ExposureEvolution.KernelPratt.prime_2467,
    ExposureEvolution.KernelPratt.prime_2473,
    ExposureEvolution.KernelPratt.prime_5987447,
    ExposureEvolution.KernelPratt.prime_5987551,
    ExposureEvolution.KernelPratt.prime_5987803]

def block04 : Witness := ⟨⟨6046681, 6086088, 2467, 2473, 2477, 6046283, 6046349, 6046669⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2467,
    ExposureEvolution.KernelPratt.prime_2473,
    ExposureEvolution.KernelPratt.prime_2477,
    ExposureEvolution.KernelPratt.prime_6046283,
    ExposureEvolution.KernelPratt.prime_6046349,
    ExposureEvolution.KernelPratt.prime_6046669]

def block05 : Witness := ⟨⟨6086089, 6115728, 2473, 2477, 2503, 6085627, 6085741, 6086063⟩, 8⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2473,
    ExposureEvolution.KernelPratt.prime_2477,
    ExposureEvolution.KernelPratt.prime_2503,
    ExposureEvolution.KernelPratt.prime_6085627,
    ExposureEvolution.KernelPratt.prime_6085741,
    ExposureEvolution.KernelPratt.prime_6086063]

def block06 : Witness := ⟨⟨6115729, 6135528, 2477, 2503, 2521, 6115367, 6115691, 6115717⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2477,
    ExposureEvolution.KernelPratt.prime_2503,
    ExposureEvolution.KernelPratt.prime_2521,
    ExposureEvolution.KernelPratt.prime_6115367,
    ExposureEvolution.KernelPratt.prime_6115691,
    ExposureEvolution.KernelPratt.prime_6115717]

def block07 : Witness := ⟨⟨6135529, 6265008, 2503, 2521, 2531, 6135047, 6135491, 6135523⟩, 11⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2503,
    ExposureEvolution.KernelPratt.prime_2521,
    ExposureEvolution.KernelPratt.prime_2531,
    ExposureEvolution.KernelPratt.prime_6135047,
    ExposureEvolution.KernelPratt.prime_6135491,
    ExposureEvolution.KernelPratt.prime_6135523]

def block08 : Witness := ⟨⟨6265009, 6355440, 2521, 2531, 2539, 6264571, 6264793, 6265001⟩, 7⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2521,
    ExposureEvolution.KernelPratt.prime_2531,
    ExposureEvolution.KernelPratt.prime_2539,
    ExposureEvolution.KernelPratt.prime_6264571,
    ExposureEvolution.KernelPratt.prime_6264793,
    ExposureEvolution.KernelPratt.prime_6265001]

def block09 : Witness := ⟨⟨6355441, 6405960, 2531, 2539, 2543, 6354967, 6355103, 6355381⟩, 10⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2531,
    ExposureEvolution.KernelPratt.prime_2539,
    ExposureEvolution.KernelPratt.prime_2543,
    ExposureEvolution.KernelPratt.prime_6354967,
    ExposureEvolution.KernelPratt.prime_6355103,
    ExposureEvolution.KernelPratt.prime_6355381]

def block10 : Witness := ⟨⟨6405961, 6446520, 2539, 2543, 2549, 6405761, 6405929, 6405943⟩, 7⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2539,
    ExposureEvolution.KernelPratt.prime_2543,
    ExposureEvolution.KernelPratt.prime_2549,
    ExposureEvolution.KernelPratt.prime_6405761,
    ExposureEvolution.KernelPratt.prime_6405929,
    ExposureEvolution.KernelPratt.prime_6405943]

def block11 : Witness := ⟨⟨6446521, 6466848, 2543, 2549, 2551, 6446051, 6446183, 6446513⟩, 12⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2543,
    ExposureEvolution.KernelPratt.prime_2549,
    ExposureEvolution.KernelPratt.prime_2551,
    ExposureEvolution.KernelPratt.prime_6446051,
    ExposureEvolution.KernelPratt.prime_6446183,
    ExposureEvolution.KernelPratt.prime_6446513]

def block12 : Witness := ⟨⟨6466849, 6497400, 2549, 2551, 2557, 6466501, 6466711, 6466847⟩, 7⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2549,
    ExposureEvolution.KernelPratt.prime_2551,
    ExposureEvolution.KernelPratt.prime_2557,
    ExposureEvolution.KernelPratt.prime_6466501,
    ExposureEvolution.KernelPratt.prime_6466711,
    ExposureEvolution.KernelPratt.prime_6466847]

def block13 : Witness := ⟨⟨6497401, 6507600, 2551, 2557, 2579, 6497087, 6497167, 6497399⟩, 12⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2551,
    ExposureEvolution.KernelPratt.prime_2557,
    ExposureEvolution.KernelPratt.prime_2579,
    ExposureEvolution.KernelPratt.prime_6497087,
    ExposureEvolution.KernelPratt.prime_6497167,
    ExposureEvolution.KernelPratt.prime_6497399]

def block14 : Witness := ⟨⟨6507601, 6538248, 2557, 2579, 2591, 6507167, 6507407, 6507587⟩, 9⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2557,
    ExposureEvolution.KernelPratt.prime_2579,
    ExposureEvolution.KernelPratt.prime_2591,
    ExposureEvolution.KernelPratt.prime_6507167,
    ExposureEvolution.KernelPratt.prime_6507407,
    ExposureEvolution.KernelPratt.prime_6507587]

def block15 : Witness := ⟨⟨6538249, 6651240, 2579, 2591, 2593, 6537701, 6538057, 6538219⟩, 10⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2579,
    ExposureEvolution.KernelPratt.prime_2591,
    ExposureEvolution.KernelPratt.prime_2593,
    ExposureEvolution.KernelPratt.prime_6537701,
    ExposureEvolution.KernelPratt.prime_6538057,
    ExposureEvolution.KernelPratt.prime_6538219]

def block16 : Witness := ⟨⟨6651241, 6713280, 2591, 2593, 2609, 6650821, 6651091, 6651223⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2591,
    ExposureEvolution.KernelPratt.prime_2593,
    ExposureEvolution.KernelPratt.prime_2609,
    ExposureEvolution.KernelPratt.prime_6650821,
    ExposureEvolution.KernelPratt.prime_6651091,
    ExposureEvolution.KernelPratt.prime_6651223]

def block17 : Witness := ⟨⟨6713281, 6723648, 2593, 2609, 2617, 6712847, 6713089, 6713279⟩, 10⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2593,
    ExposureEvolution.KernelPratt.prime_2609,
    ExposureEvolution.KernelPratt.prime_2617,
    ExposureEvolution.KernelPratt.prime_6712847,
    ExposureEvolution.KernelPratt.prime_6713089,
    ExposureEvolution.KernelPratt.prime_6713279]

def block18 : Witness := ⟨⟨6723649, 6806880, 2609, 2617, 2621, 6723539, 6723571, 6723643⟩, 11⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2609,
    ExposureEvolution.KernelPratt.prime_2617,
    ExposureEvolution.KernelPratt.prime_2621,
    ExposureEvolution.KernelPratt.prime_6723539,
    ExposureEvolution.KernelPratt.prime_6723571,
    ExposureEvolution.KernelPratt.prime_6723643]

def block19 : Witness := ⟨⟨6806881, 6848688, 2617, 2621, 2633, 6806381, 6806729, 6806837⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2617,
    ExposureEvolution.KernelPratt.prime_2621,
    ExposureEvolution.KernelPratt.prime_2633,
    ExposureEvolution.KernelPratt.prime_6806381,
    ExposureEvolution.KernelPratt.prime_6806729,
    ExposureEvolution.KernelPratt.prime_6806837]

def block20 : Witness := ⟨⟨6848689, 6869640, 2621, 2633, 2647, 6848291, 6848377, 6848659⟩, 9⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2621,
    ExposureEvolution.KernelPratt.prime_2633,
    ExposureEvolution.KernelPratt.prime_2647,
    ExposureEvolution.KernelPratt.prime_6848291,
    ExposureEvolution.KernelPratt.prime_6848377,
    ExposureEvolution.KernelPratt.prime_6848659]

def block21 : Witness := ⟨⟨6869641, 6932688, 2633, 2647, 2657, 6869327, 6869437, 6869633⟩, 13⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2633,
    ExposureEvolution.KernelPratt.prime_2647,
    ExposureEvolution.KernelPratt.prime_2657,
    ExposureEvolution.KernelPratt.prime_6869327,
    ExposureEvolution.KernelPratt.prime_6869437,
    ExposureEvolution.KernelPratt.prime_6869633]

def block22 : Witness := ⟨⟨6932689, 7006608, 2647, 2657, 2659, 6932173, 6932543, 6932669⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2647,
    ExposureEvolution.KernelPratt.prime_2657,
    ExposureEvolution.KernelPratt.prime_2659,
    ExposureEvolution.KernelPratt.prime_6932173,
    ExposureEvolution.KernelPratt.prime_6932543,
    ExposureEvolution.KernelPratt.prime_6932669]

def block23 : Witness := ⟨⟨7006609, 7059648, 2657, 2659, 2663, 7006451, 7006541, 7006607⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2657,
    ExposureEvolution.KernelPratt.prime_2659,
    ExposureEvolution.KernelPratt.prime_2663,
    ExposureEvolution.KernelPratt.prime_7006451,
    ExposureEvolution.KernelPratt.prime_7006541,
    ExposureEvolution.KernelPratt.prime_7006607]

def block24 : Witness := ⟨⟨7059649, 7070280, 2659, 2663, 2671, 7059323, 7059529, 7059631⟩, 7⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2659,
    ExposureEvolution.KernelPratt.prime_2663,
    ExposureEvolution.KernelPratt.prime_2671,
    ExposureEvolution.KernelPratt.prime_7059323,
    ExposureEvolution.KernelPratt.prime_7059529,
    ExposureEvolution.KernelPratt.prime_7059631]

def block25 : Witness := ⟨⟨7070281, 7091568, 2663, 2671, 2677, 7069973, 7070099, 7070267⟩, 11⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2663,
    ExposureEvolution.KernelPratt.prime_2671,
    ExposureEvolution.KernelPratt.prime_2677,
    ExposureEvolution.KernelPratt.prime_7069973,
    ExposureEvolution.KernelPratt.prime_7070099,
    ExposureEvolution.KernelPratt.prime_7070267]

def block26 : Witness := ⟨⟨7091569, 7134240, 2671, 2677, 2683, 7091473, 7091537, 7091549⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2671,
    ExposureEvolution.KernelPratt.prime_2677,
    ExposureEvolution.KernelPratt.prime_2683,
    ExposureEvolution.KernelPratt.prime_7091473,
    ExposureEvolution.KernelPratt.prime_7091537,
    ExposureEvolution.KernelPratt.prime_7091549]

def block27 : Witness := ⟨⟨7134241, 7166328, 2677, 2683, 2687, 7134109, 7134119, 7134233⟩, 9⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2677,
    ExposureEvolution.KernelPratt.prime_2683,
    ExposureEvolution.KernelPratt.prime_2687,
    ExposureEvolution.KernelPratt.prime_7134109,
    ExposureEvolution.KernelPratt.prime_7134119,
    ExposureEvolution.KernelPratt.prime_7134233]

def block28 : Witness := ⟨⟨7166329, 7198488, 2683, 2687, 2689, 7165913, 7166153, 7166321⟩, 7⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2683,
    ExposureEvolution.KernelPratt.prime_2687,
    ExposureEvolution.KernelPratt.prime_2689,
    ExposureEvolution.KernelPratt.prime_7165913,
    ExposureEvolution.KernelPratt.prime_7166153,
    ExposureEvolution.KernelPratt.prime_7166321]

def block29 : Witness := ⟨⟨7198489, 7219968, 2687, 2689, 2693, 7197977, 7198349, 7198483⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2687,
    ExposureEvolution.KernelPratt.prime_2689,
    ExposureEvolution.KernelPratt.prime_2693,
    ExposureEvolution.KernelPratt.prime_7197977,
    ExposureEvolution.KernelPratt.prime_7198349,
    ExposureEvolution.KernelPratt.prime_7198483]

def block30 : Witness := ⟨⟨7219969, 7230720, 2689, 2693, 2699, 7219361, 7219757, 7219963⟩, 10⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2689,
    ExposureEvolution.KernelPratt.prime_2693,
    ExposureEvolution.KernelPratt.prime_2699,
    ExposureEvolution.KernelPratt.prime_7219361,
    ExposureEvolution.KernelPratt.prime_7219757,
    ExposureEvolution.KernelPratt.prime_7219963]

def block31 : Witness := ⟨⟨7230721, 7252248, 2693, 2699, 2707, 7230323, 7230481, 7230709⟩, 8⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2693,
    ExposureEvolution.KernelPratt.prime_2699,
    ExposureEvolution.KernelPratt.prime_2707,
    ExposureEvolution.KernelPratt.prime_7230323,
    ExposureEvolution.KernelPratt.prime_7230481,
    ExposureEvolution.KernelPratt.prime_7230709]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 7252249 stop tail = true) :
    coverage 5870929 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks06
