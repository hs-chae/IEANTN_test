import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelPrimeCheck01
open ExposureEvolution KernelPrimeProgram
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def primes : List ℕ := [10399, 10433, 10463, 10501, 10531, 10567, 10607, 10639, 10667, 10691, 10729, 10753, 10789, 10831, 10867, 10909, 10949, 10987, 11027, 11069, 11093, 11131, 11173, 11213, 11251, 11287, 11329, 11369, 11411, 11447, 11491, 11527, 11551, 11593, 11633, 11677, 11719, 11743, 11783, 11827, 11867, 11909, 11953, 11987, 12011, 12049, 12073, 12119, 12163, 12203, 12241, 12281, 12323, 12347, 12391, 12437, 12479, 12527, 12569, 12613, 12659, 12703, 12743, 12791]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 12791 stop tail = true) :
    check 10369 stop (primes ++ tail) = true := by
  change check _ _ (10399 :: 10433 :: 10463 :: 10501 :: 10531 :: 10567 :: 10607 :: 10639 :: 10667 :: 10691 :: 10729 :: 10753 :: 10789 :: 10831 :: 10867 :: 10909 :: 10949 :: 10987 :: 11027 :: 11069 :: 11093 :: 11131 :: 11173 :: 11213 :: 11251 :: 11287 :: 11329 :: 11369 :: 11411 :: 11447 :: 11491 :: 11527 :: 11551 :: 11593 :: 11633 :: 11677 :: 11719 :: 11743 :: 11783 :: 11827 :: 11867 :: 11909 :: 11953 :: 11987 :: 12011 :: 12049 :: 12073 :: 12119 :: 12163 :: 12203 :: 12241 :: 12281 :: 12323 :: 12347 :: 12391 :: 12437 :: 12479 :: 12527 :: 12569 :: 12613 :: 12659 :: 12703 :: 12743 :: 12791 :: tail) = true
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10399, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10433, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10463, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10501, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10531, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10567, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10607, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10639, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10667, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10691, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10729, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10753, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10789, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10831, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10867, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10909, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10949, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_10987, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11027, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11069, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11093, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11131, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11173, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11213, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11251, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11287, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11329, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11369, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11411, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11447, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11491, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11527, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11551, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11593, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11633, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11677, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11719, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11743, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11783, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11827, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11867, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11909, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11953, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_11987, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12011, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12049, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12073, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12119, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12163, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12203, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12241, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12281, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12323, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12347, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12391, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12437, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12479, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12527, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12569, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12613, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12659, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12703, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12743, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_12791, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms extend
end ExposureEvolution.KernelPrimeCheck01
