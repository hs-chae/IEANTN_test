import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_001
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨7349521, 7360368, 2713, 2719, 2729, 7349141, 7349393, 7349513⟩, 13⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2713,
    ExposureEvolution.Compact40Pratt.prime_2719,
    ExposureEvolution.Compact40Pratt.prime_2729,
    ExposureEvolution.Compact40Pratt.prime_7349141,
    ExposureEvolution.Compact40Pratt.prime_7349393,
    ExposureEvolution.Compact40Pratt.prime_7349513]

def block01 : Witness := ⟨⟨7360369, 7392960, 2719, 2729, 2731, 7359817, 7359949, 7360363⟩, 7⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2719,
    ExposureEvolution.Compact40Pratt.prime_2729,
    ExposureEvolution.Compact40Pratt.prime_2731,
    ExposureEvolution.Compact40Pratt.prime_7359817,
    ExposureEvolution.Compact40Pratt.prime_7359949,
    ExposureEvolution.Compact40Pratt.prime_7360363]

def block02 : Witness := ⟨⟨7392961, 7447440, 2729, 2731, 2741, 7392373, 7392617, 7392953⟩, 9⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2729,
    ExposureEvolution.Compact40Pratt.prime_2731,
    ExposureEvolution.Compact40Pratt.prime_2741,
    ExposureEvolution.Compact40Pratt.prime_7392373,
    ExposureEvolution.Compact40Pratt.prime_7392617,
    ExposureEvolution.Compact40Pratt.prime_7392953]

def block03 : Witness := ⟨⟨7447441, 7458360, 2731, 2741, 2749, 7447051, 7447061, 7447439⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2731,
    ExposureEvolution.Compact40Pratt.prime_2741,
    ExposureEvolution.Compact40Pratt.prime_2749,
    ExposureEvolution.Compact40Pratt.prime_7447051,
    ExposureEvolution.Compact40Pratt.prime_7447061,
    ExposureEvolution.Compact40Pratt.prime_7447439]

def block04 : Witness := ⟨⟨7458361, 7513080, 2741, 2749, 2753, 7457839, 7458067, 7458313⟩, 8⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2741,
    ExposureEvolution.Compact40Pratt.prime_2749,
    ExposureEvolution.Compact40Pratt.prime_2753,
    ExposureEvolution.Compact40Pratt.prime_7457839,
    ExposureEvolution.Compact40Pratt.prime_7458067,
    ExposureEvolution.Compact40Pratt.prime_7458313]

def block05 : Witness := ⟨⟨7513081, 7557000, 2749, 2753, 2767, 7512773, 7512853, 7513073⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2749,
    ExposureEvolution.Compact40Pratt.prime_2753,
    ExposureEvolution.Compact40Pratt.prime_2767,
    ExposureEvolution.Compact40Pratt.prime_7512773,
    ExposureEvolution.Compact40Pratt.prime_7512853,
    ExposureEvolution.Compact40Pratt.prime_7513073]

def block06 : Witness := ⟨⟨7557001, 7579008, 2753, 2767, 2777, 7556629, 7556641, 7556999⟩, 7⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2753,
    ExposureEvolution.Compact40Pratt.prime_2767,
    ExposureEvolution.Compact40Pratt.prime_2777,
    ExposureEvolution.Compact40Pratt.prime_7556629,
    ExposureEvolution.Compact40Pratt.prime_7556641,
    ExposureEvolution.Compact40Pratt.prime_7556999]

def block07 : Witness := ⟨⟨7579009, 7656288, 2767, 2777, 2789, 7578553, 7578643, 7579003⟩, 8⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2767,
    ExposureEvolution.Compact40Pratt.prime_2777,
    ExposureEvolution.Compact40Pratt.prime_2789,
    ExposureEvolution.Compact40Pratt.prime_7578553,
    ExposureEvolution.Compact40Pratt.prime_7578643,
    ExposureEvolution.Compact40Pratt.prime_7579003]

def block08 : Witness := ⟨⟨7656289, 7711728, 2777, 2789, 2791, 7655737, 7656043, 7656281⟩, 12⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2777,
    ExposureEvolution.Compact40Pratt.prime_2789,
    ExposureEvolution.Compact40Pratt.prime_2791,
    ExposureEvolution.Compact40Pratt.prime_7655737,
    ExposureEvolution.Compact40Pratt.prime_7656043,
    ExposureEvolution.Compact40Pratt.prime_7656281]

def block09 : Witness := ⟨⟨7711729, 7778520, 2789, 2791, 2797, 7711687, 7711703, 7711723⟩, 11⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2789,
    ExposureEvolution.Compact40Pratt.prime_2791,
    ExposureEvolution.Compact40Pratt.prime_2797,
    ExposureEvolution.Compact40Pratt.prime_7711687,
    ExposureEvolution.Compact40Pratt.prime_7711703,
    ExposureEvolution.Compact40Pratt.prime_7711723]

def block10 : Witness := ⟨⟨7778521, 7789680, 2791, 2797, 2801, 7778327, 7778339, 7778509⟩, 8⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2791,
    ExposureEvolution.Compact40Pratt.prime_2797,
    ExposureEvolution.Compact40Pratt.prime_2801,
    ExposureEvolution.Compact40Pratt.prime_7778327,
    ExposureEvolution.Compact40Pratt.prime_7778339,
    ExposureEvolution.Compact40Pratt.prime_7778509]

def block11 : Witness := ⟨⟨7789681, 7823208, 2797, 2801, 2803, 7789363, 7789393, 7789669⟩, 10⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2797,
    ExposureEvolution.Compact40Pratt.prime_2801,
    ExposureEvolution.Compact40Pratt.prime_2803,
    ExposureEvolution.Compact40Pratt.prime_7789363,
    ExposureEvolution.Compact40Pratt.prime_7789393,
    ExposureEvolution.Compact40Pratt.prime_7789669]

def block12 : Witness := ⟨⟨7823209, 7845600, 2801, 2803, 2819, 7823093, 7823183, 7823203⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2801,
    ExposureEvolution.Compact40Pratt.prime_2803,
    ExposureEvolution.Compact40Pratt.prime_2819,
    ExposureEvolution.Compact40Pratt.prime_7823093,
    ExposureEvolution.Compact40Pratt.prime_7823183,
    ExposureEvolution.Compact40Pratt.prime_7823203]

def block13 : Witness := ⟨⟨7845601, 7856808, 2803, 2819, 2833, 7845203, 7845301, 7845587⟩, 9⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2803,
    ExposureEvolution.Compact40Pratt.prime_2819,
    ExposureEvolution.Compact40Pratt.prime_2833,
    ExposureEvolution.Compact40Pratt.prime_7845203,
    ExposureEvolution.Compact40Pratt.prime_7845301,
    ExposureEvolution.Compact40Pratt.prime_7845587]

def block14 : Witness := ⟨⟨7856809, 7946760, 2819, 2833, 2837, 7856231, 7856587, 7856803⟩, 7⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2819,
    ExposureEvolution.Compact40Pratt.prime_2833,
    ExposureEvolution.Compact40Pratt.prime_2837,
    ExposureEvolution.Compact40Pratt.prime_7856231,
    ExposureEvolution.Compact40Pratt.prime_7856587,
    ExposureEvolution.Compact40Pratt.prime_7856803]

def block15 : Witness := ⟨⟨7946761, 8025888, 2833, 2837, 2843, 7946683, 7946717, 7946747⟩, 6⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2833,
    ExposureEvolution.Compact40Pratt.prime_2837,
    ExposureEvolution.Compact40Pratt.prime_2843,
    ExposureEvolution.Compact40Pratt.prime_7946683,
    ExposureEvolution.Compact40Pratt.prime_7946717,
    ExposureEvolution.Compact40Pratt.prime_7946747]

def block16 : Witness := ⟨⟨8025889, 8048568, 2837, 2843, 2851, 8025469, 8025679, 8025883⟩, 8⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2837,
    ExposureEvolution.Compact40Pratt.prime_2843,
    ExposureEvolution.Compact40Pratt.prime_2851,
    ExposureEvolution.Compact40Pratt.prime_8025469,
    ExposureEvolution.Compact40Pratt.prime_8025679,
    ExposureEvolution.Compact40Pratt.prime_8025883]

def block17 : Witness := ⟨⟨8048569, 8082648, 2843, 2851, 2857, 8048083, 8048389, 8048567⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2843,
    ExposureEvolution.Compact40Pratt.prime_2851,
    ExposureEvolution.Compact40Pratt.prime_2857,
    ExposureEvolution.Compact40Pratt.prime_8048083,
    ExposureEvolution.Compact40Pratt.prime_8048389,
    ExposureEvolution.Compact40Pratt.prime_8048567]

def block18 : Witness := ⟨⟨8082649, 8128200, 2851, 2857, 2861, 8082127, 8082397, 8082631⟩, 11⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2851,
    ExposureEvolution.Compact40Pratt.prime_2857,
    ExposureEvolution.Compact40Pratt.prime_2861,
    ExposureEvolution.Compact40Pratt.prime_8082127,
    ExposureEvolution.Compact40Pratt.prime_8082397,
    ExposureEvolution.Compact40Pratt.prime_8082631]

def block19 : Witness := ⟨⟨8128201, 8162448, 2857, 2861, 2879, 8127697, 8128063, 8128187⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2857,
    ExposureEvolution.Compact40Pratt.prime_2861,
    ExposureEvolution.Compact40Pratt.prime_2879,
    ExposureEvolution.Compact40Pratt.prime_8127697,
    ExposureEvolution.Compact40Pratt.prime_8128063,
    ExposureEvolution.Compact40Pratt.prime_8128187]

def block20 : Witness := ⟨⟨8162449, 8185320, 2861, 2879, 2887, 8162069, 8162353, 8162437⟩, 9⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2861,
    ExposureEvolution.Compact40Pratt.prime_2879,
    ExposureEvolution.Compact40Pratt.prime_2887,
    ExposureEvolution.Compact40Pratt.prime_8162069,
    ExposureEvolution.Compact40Pratt.prime_8162353,
    ExposureEvolution.Compact40Pratt.prime_8162437]

def block21 : Witness := ⟨⟨8185321, 8288640, 2879, 2887, 2897, 8185039, 8185291, 8185301⟩, 9⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2879,
    ExposureEvolution.Compact40Pratt.prime_2887,
    ExposureEvolution.Compact40Pratt.prime_2897,
    ExposureEvolution.Compact40Pratt.prime_8185039,
    ExposureEvolution.Compact40Pratt.prime_8185291,
    ExposureEvolution.Compact40Pratt.prime_8185301]

def block22 : Witness := ⟨⟨8288641, 8334768, 2887, 2897, 2903, 8288263, 8288557, 8288633⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2887,
    ExposureEvolution.Compact40Pratt.prime_2897,
    ExposureEvolution.Compact40Pratt.prime_2903,
    ExposureEvolution.Compact40Pratt.prime_8288263,
    ExposureEvolution.Compact40Pratt.prime_8288557,
    ExposureEvolution.Compact40Pratt.prime_8288633]

def block23 : Witness := ⟨⟨8334769, 8392608, 2897, 2903, 2909, 8334461, 8334499, 8334757⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2897,
    ExposureEvolution.Compact40Pratt.prime_2903,
    ExposureEvolution.Compact40Pratt.prime_2909,
    ExposureEvolution.Compact40Pratt.prime_8334461,
    ExposureEvolution.Compact40Pratt.prime_8334499,
    ExposureEvolution.Compact40Pratt.prime_8334757]

def block24 : Witness := ⟨⟨8392609, 8427408, 2903, 2909, 2917, 8392327, 8392561, 8392607⟩, 10⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2903,
    ExposureEvolution.Compact40Pratt.prime_2909,
    ExposureEvolution.Compact40Pratt.prime_2917,
    ExposureEvolution.Compact40Pratt.prime_8392327,
    ExposureEvolution.Compact40Pratt.prime_8392561,
    ExposureEvolution.Compact40Pratt.prime_8392607]

def block25 : Witness := ⟨⟨8427409, 8462280, 2909, 2917, 2927, 8427043, 8427161, 8427403⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2909,
    ExposureEvolution.Compact40Pratt.prime_2917,
    ExposureEvolution.Compact40Pratt.prime_2927,
    ExposureEvolution.Compact40Pratt.prime_8427043,
    ExposureEvolution.Compact40Pratt.prime_8427161,
    ExposureEvolution.Compact40Pratt.prime_8427403]

def block26 : Witness := ⟨⟨8462281, 8508888, 2917, 2927, 2939, 8462071, 8462093, 8462263⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2917,
    ExposureEvolution.Compact40Pratt.prime_2927,
    ExposureEvolution.Compact40Pratt.prime_2939,
    ExposureEvolution.Compact40Pratt.prime_8462071,
    ExposureEvolution.Compact40Pratt.prime_8462093,
    ExposureEvolution.Compact40Pratt.prime_8462263]

def block27 : Witness := ⟨⟨8508889, 8567328, 2927, 2939, 2953, 8508671, 8508847, 8508881⟩, 10⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2927,
    ExposureEvolution.Compact40Pratt.prime_2939,
    ExposureEvolution.Compact40Pratt.prime_2953,
    ExposureEvolution.Compact40Pratt.prime_8508671,
    ExposureEvolution.Compact40Pratt.prime_8508847,
    ExposureEvolution.Compact40Pratt.prime_8508881]

def block28 : Witness := ⟨⟨8567329, 8637720, 2939, 2953, 2957, 8566799, 8567281, 8567311⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2939,
    ExposureEvolution.Compact40Pratt.prime_2953,
    ExposureEvolution.Compact40Pratt.prime_2957,
    ExposureEvolution.Compact40Pratt.prime_8566799,
    ExposureEvolution.Compact40Pratt.prime_8567281,
    ExposureEvolution.Compact40Pratt.prime_8567311]

def block29 : Witness := ⟨⟨8637721, 8720208, 2953, 2957, 2963, 8637323, 8637373, 8637701⟩, 8⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2953,
    ExposureEvolution.Compact40Pratt.prime_2957,
    ExposureEvolution.Compact40Pratt.prime_2963,
    ExposureEvolution.Compact40Pratt.prime_8637323,
    ExposureEvolution.Compact40Pratt.prime_8637373,
    ExposureEvolution.Compact40Pratt.prime_8637701]

def block30 : Witness := ⟨⟨8720209, 8743848, 2957, 2963, 2969, 8719939, 8719961, 8720191⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2957,
    ExposureEvolution.Compact40Pratt.prime_2963,
    ExposureEvolution.Compact40Pratt.prime_2969,
    ExposureEvolution.Compact40Pratt.prime_8719939,
    ExposureEvolution.Compact40Pratt.prime_8719961,
    ExposureEvolution.Compact40Pratt.prime_8720191]

def block31 : Witness := ⟨⟨8743849, 8779368, 2963, 2969, 2971, 8743513, 8743753, 8743843⟩, 10⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2963,
    ExposureEvolution.Compact40Pratt.prime_2969,
    ExposureEvolution.Compact40Pratt.prime_2971,
    ExposureEvolution.Compact40Pratt.prime_8743513,
    ExposureEvolution.Compact40Pratt.prime_8743753,
    ExposureEvolution.Compact40Pratt.prime_8743843]

def block32 : Witness := ⟨⟨8779369, 8814960, 2969, 2971, 2999, 8778901, 8779063, 8779321⟩, 8⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2969,
    ExposureEvolution.Compact40Pratt.prime_2971,
    ExposureEvolution.Compact40Pratt.prime_2999,
    ExposureEvolution.Compact40Pratt.prime_8778901,
    ExposureEvolution.Compact40Pratt.prime_8779063,
    ExposureEvolution.Compact40Pratt.prime_8779321]

def block33 : Witness := ⟨⟨8814961, 8826840, 2971, 2999, 3001, 8814779, 8814929, 8814941⟩, 8⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2971,
    ExposureEvolution.Compact40Pratt.prime_2999,
    ExposureEvolution.Compact40Pratt.prime_3001,
    ExposureEvolution.Compact40Pratt.prime_8814779,
    ExposureEvolution.Compact40Pratt.prime_8814929,
    ExposureEvolution.Compact40Pratt.prime_8814941]

def block34 : Witness := ⟨⟨8826841, 8994000, 2999, 3001, 3011, 8826463, 8826809, 8826833⟩, 10⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2999,
    ExposureEvolution.Compact40Pratt.prime_3001,
    ExposureEvolution.Compact40Pratt.prime_3011,
    ExposureEvolution.Compact40Pratt.prime_8826463,
    ExposureEvolution.Compact40Pratt.prime_8826809,
    ExposureEvolution.Compact40Pratt.prime_8826833]

def block35 : Witness := ⟨⟨8994001, 9006000, 3001, 3011, 3019, 8993827, 8993839, 8993981⟩, 9⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3001,
    ExposureEvolution.Compact40Pratt.prime_3011,
    ExposureEvolution.Compact40Pratt.prime_3019,
    ExposureEvolution.Compact40Pratt.prime_8993827,
    ExposureEvolution.Compact40Pratt.prime_8993839,
    ExposureEvolution.Compact40Pratt.prime_8993981]

def block36 : Witness := ⟨⟨9006001, 9066120, 3011, 3019, 3023, 9005473, 9005839, 9005989⟩, 10⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3011,
    ExposureEvolution.Compact40Pratt.prime_3019,
    ExposureEvolution.Compact40Pratt.prime_3023,
    ExposureEvolution.Compact40Pratt.prime_9005473,
    ExposureEvolution.Compact40Pratt.prime_9005839,
    ExposureEvolution.Compact40Pratt.prime_9005989]

def block37 : Witness := ⟨⟨9066121, 9114360, 3019, 3023, 3037, 9065839, 9065923, 9066091⟩, 5⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3019,
    ExposureEvolution.Compact40Pratt.prime_3023,
    ExposureEvolution.Compact40Pratt.prime_3037,
    ExposureEvolution.Compact40Pratt.prime_9065839,
    ExposureEvolution.Compact40Pratt.prime_9065923,
    ExposureEvolution.Compact40Pratt.prime_9066091]

def block38 : Witness := ⟨⟨9114361, 9138528, 3023, 3037, 3041, 9114073, 9114263, 9114353⟩, 9⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3023,
    ExposureEvolution.Compact40Pratt.prime_3037,
    ExposureEvolution.Compact40Pratt.prime_3041,
    ExposureEvolution.Compact40Pratt.prime_9114073,
    ExposureEvolution.Compact40Pratt.prime_9114263,
    ExposureEvolution.Compact40Pratt.prime_9114353]

def block39 : Witness := ⟨⟨9138529, 9223368, 3037, 3041, 3049, 9138329, 9138443, 9138527⟩, 7⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3037,
    ExposureEvolution.Compact40Pratt.prime_3041,
    ExposureEvolution.Compact40Pratt.prime_3049,
    ExposureEvolution.Compact40Pratt.prime_9138329,
    ExposureEvolution.Compact40Pratt.prime_9138443,
    ExposureEvolution.Compact40Pratt.prime_9138527]

def block40 : Witness := ⟨⟨9223369, 9247680, 3041, 3049, 3061, 9223003, 9223091, 9223351⟩, 13⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3041,
    ExposureEvolution.Compact40Pratt.prime_3049,
    ExposureEvolution.Compact40Pratt.prime_3061,
    ExposureEvolution.Compact40Pratt.prime_9223003,
    ExposureEvolution.Compact40Pratt.prime_9223091,
    ExposureEvolution.Compact40Pratt.prime_9223351]

def block41 : Witness := ⟨⟨9247681, 9296400, 3049, 3061, 3067, 9247409, 9247489, 9247663⟩, 9⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3049,
    ExposureEvolution.Compact40Pratt.prime_3061,
    ExposureEvolution.Compact40Pratt.prime_3067,
    ExposureEvolution.Compact40Pratt.prime_9247409,
    ExposureEvolution.Compact40Pratt.prime_9247489,
    ExposureEvolution.Compact40Pratt.prime_9247663]

def block42 : Witness := ⟨⟨9296401, 9369720, 3061, 3067, 3079, 9296029, 9296087, 9296387⟩, 8⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3061,
    ExposureEvolution.Compact40Pratt.prime_3067,
    ExposureEvolution.Compact40Pratt.prime_3079,
    ExposureEvolution.Compact40Pratt.prime_9296029,
    ExposureEvolution.Compact40Pratt.prime_9296087,
    ExposureEvolution.Compact40Pratt.prime_9296387]

def block43 : Witness := ⟨⟨9369721, 9406488, 3067, 3079, 3083, 9369677, 9369709, 9369713⟩, 9⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3067,
    ExposureEvolution.Compact40Pratt.prime_3079,
    ExposureEvolution.Compact40Pratt.prime_3083,
    ExposureEvolution.Compact40Pratt.prime_9369677,
    ExposureEvolution.Compact40Pratt.prime_9369709,
    ExposureEvolution.Compact40Pratt.prime_9369713]

def block44 : Witness := ⟨⟨9406489, 9480240, 3079, 3083, 3089, 9406289, 9406291, 9406483⟩, 9⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3079,
    ExposureEvolution.Compact40Pratt.prime_3083,
    ExposureEvolution.Compact40Pratt.prime_3089,
    ExposureEvolution.Compact40Pratt.prime_9406289,
    ExposureEvolution.Compact40Pratt.prime_9406291,
    ExposureEvolution.Compact40Pratt.prime_9406483]

def block45 : Witness := ⟨⟨9480241, 9504888, 3083, 3089, 3109, 9479923, 9479971, 9480239⟩, 10⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3083,
    ExposureEvolution.Compact40Pratt.prime_3089,
    ExposureEvolution.Compact40Pratt.prime_3109,
    ExposureEvolution.Compact40Pratt.prime_9479923,
    ExposureEvolution.Compact40Pratt.prime_9479971,
    ExposureEvolution.Compact40Pratt.prime_9480239]

def block46 : Witness := ⟨⟨9504889, 9541920, 3089, 3109, 3119, 9504653, 9504823, 9504877⟩, 10⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3089,
    ExposureEvolution.Compact40Pratt.prime_3109,
    ExposureEvolution.Compact40Pratt.prime_3119,
    ExposureEvolution.Compact40Pratt.prime_9504653,
    ExposureEvolution.Compact40Pratt.prime_9504823,
    ExposureEvolution.Compact40Pratt.prime_9504877]

def block47 : Witness := ⟨⟨9541921, 9665880, 3109, 3119, 3121, 9541589, 9541871, 9541919⟩, 7⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3109,
    ExposureEvolution.Compact40Pratt.prime_3119,
    ExposureEvolution.Compact40Pratt.prime_3121,
    ExposureEvolution.Compact40Pratt.prime_9541589,
    ExposureEvolution.Compact40Pratt.prime_9541871,
    ExposureEvolution.Compact40Pratt.prime_9541919]

def block48 : Witness := ⟨⟨9665881, 9728160, 3119, 3121, 3137, 9665587, 9665609, 9665863⟩, 7⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3119,
    ExposureEvolution.Compact40Pratt.prime_3121,
    ExposureEvolution.Compact40Pratt.prime_3137,
    ExposureEvolution.Compact40Pratt.prime_9665587,
    ExposureEvolution.Compact40Pratt.prime_9665609,
    ExposureEvolution.Compact40Pratt.prime_9665863]

def block49 : Witness := ⟨⟨9728161, 9740640, 3121, 3137, 3163, 9727799, 9727973, 9728153⟩, 10⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3121,
    ExposureEvolution.Compact40Pratt.prime_3137,
    ExposureEvolution.Compact40Pratt.prime_3163,
    ExposureEvolution.Compact40Pratt.prime_9727799,
    ExposureEvolution.Compact40Pratt.prime_9727973,
    ExposureEvolution.Compact40Pratt.prime_9728153]

def block50 : Witness := ⟨⟨9740641, 9840768, 3137, 3163, 3167, 9740413, 9740513, 9740639⟩, 13⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3137,
    ExposureEvolution.Compact40Pratt.prime_3163,
    ExposureEvolution.Compact40Pratt.prime_3167,
    ExposureEvolution.Compact40Pratt.prime_9740413,
    ExposureEvolution.Compact40Pratt.prime_9740513,
    ExposureEvolution.Compact40Pratt.prime_9740639]

def block51 : Witness := ⟨⟨9840769, 10004568, 3163, 3167, 3169, 9840253, 9840647, 9840763⟩, 7⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3163,
    ExposureEvolution.Compact40Pratt.prime_3167,
    ExposureEvolution.Compact40Pratt.prime_3169,
    ExposureEvolution.Compact40Pratt.prime_9840253,
    ExposureEvolution.Compact40Pratt.prime_9840647,
    ExposureEvolution.Compact40Pratt.prime_9840763]

def block52 : Witness := ⟨⟨10004569, 10029888, 3167, 3169, 3181, 10004263, 10004297, 10004557⟩, 8⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3167,
    ExposureEvolution.Compact40Pratt.prime_3169,
    ExposureEvolution.Compact40Pratt.prime_3181,
    ExposureEvolution.Compact40Pratt.prime_10004263,
    ExposureEvolution.Compact40Pratt.prime_10004297,
    ExposureEvolution.Compact40Pratt.prime_10004557]

def block53 : Witness := ⟨⟨10029889, 10042560, 3169, 3181, 3187, 10029619, 10029829, 10029883⟩, 10⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3169,
    ExposureEvolution.Compact40Pratt.prime_3181,
    ExposureEvolution.Compact40Pratt.prime_3187,
    ExposureEvolution.Compact40Pratt.prime_10029619,
    ExposureEvolution.Compact40Pratt.prime_10029829,
    ExposureEvolution.Compact40Pratt.prime_10029883]

def block54 : Witness := ⟨⟨10042561, 10118760, 3181, 3187, 3191, 10042103, 10042147, 10042553⟩, 10⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3181,
    ExposureEvolution.Compact40Pratt.prime_3187,
    ExposureEvolution.Compact40Pratt.prime_3191,
    ExposureEvolution.Compact40Pratt.prime_10042103,
    ExposureEvolution.Compact40Pratt.prime_10042147,
    ExposureEvolution.Compact40Pratt.prime_10042553]

def block55 : Witness := ⟨⟨10118761, 10156968, 3187, 3191, 3203, 10118569, 10118609, 10118753⟩, 9⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3187,
    ExposureEvolution.Compact40Pratt.prime_3191,
    ExposureEvolution.Compact40Pratt.prime_3203,
    ExposureEvolution.Compact40Pratt.prime_10118569,
    ExposureEvolution.Compact40Pratt.prime_10118609,
    ExposureEvolution.Compact40Pratt.prime_10118753]

def block56 : Witness := ⟨⟨10156969, 10182480, 3191, 3203, 3209, 10156723, 10156771, 10156957⟩, 7⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3191,
    ExposureEvolution.Compact40Pratt.prime_3203,
    ExposureEvolution.Compact40Pratt.prime_3209,
    ExposureEvolution.Compact40Pratt.prime_10156723,
    ExposureEvolution.Compact40Pratt.prime_10156771,
    ExposureEvolution.Compact40Pratt.prime_10156957]

def block57 : Witness := ⟨⟨10182481, 10259208, 3203, 3209, 3217, 10182097, 10182239, 10182463⟩, 7⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3203,
    ExposureEvolution.Compact40Pratt.prime_3209,
    ExposureEvolution.Compact40Pratt.prime_3217,
    ExposureEvolution.Compact40Pratt.prime_10182097,
    ExposureEvolution.Compact40Pratt.prime_10182239,
    ExposureEvolution.Compact40Pratt.prime_10182463]

def block58 : Witness := ⟨⟨10259209, 10297680, 3209, 3217, 3221, 10258951, 10259083, 10259203⟩, 11⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3209,
    ExposureEvolution.Compact40Pratt.prime_3217,
    ExposureEvolution.Compact40Pratt.prime_3221,
    ExposureEvolution.Compact40Pratt.prime_10258951,
    ExposureEvolution.Compact40Pratt.prime_10259083,
    ExposureEvolution.Compact40Pratt.prime_10259203]

def block59 : Witness := ⟨⟨10297681, 10349088, 3217, 3221, 3229, 10297439, 10297607, 10297669⟩, 9⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3217,
    ExposureEvolution.Compact40Pratt.prime_3221,
    ExposureEvolution.Compact40Pratt.prime_3229,
    ExposureEvolution.Compact40Pratt.prime_10297439,
    ExposureEvolution.Compact40Pratt.prime_10297607,
    ExposureEvolution.Compact40Pratt.prime_10297669]

def block60 : Witness := ⟨⟨10349089, 10374840, 3221, 3229, 3251, 10348841, 10348951, 10349083⟩, 11⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3221,
    ExposureEvolution.Compact40Pratt.prime_3229,
    ExposureEvolution.Compact40Pratt.prime_3251,
    ExposureEvolution.Compact40Pratt.prime_10348841,
    ExposureEvolution.Compact40Pratt.prime_10348951,
    ExposureEvolution.Compact40Pratt.prime_10349083]

def block61 : Witness := ⟨⟨10374841, 10426440, 3229, 3251, 3253, 10374281, 10374773, 10374839⟩, 9⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3229,
    ExposureEvolution.Compact40Pratt.prime_3251,
    ExposureEvolution.Compact40Pratt.prime_3253,
    ExposureEvolution.Compact40Pratt.prime_10374281,
    ExposureEvolution.Compact40Pratt.prime_10374773,
    ExposureEvolution.Compact40Pratt.prime_10374839]

def block62 : Witness := ⟨⟨10426441, 10569000, 3251, 3253, 3257, 10426043, 10426363, 10426417⟩, 8⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3251,
    ExposureEvolution.Compact40Pratt.prime_3253,
    ExposureEvolution.Compact40Pratt.prime_3257,
    ExposureEvolution.Compact40Pratt.prime_10426043,
    ExposureEvolution.Compact40Pratt.prime_10426363,
    ExposureEvolution.Compact40Pratt.prime_10426417]

def block63 : Witness := ⟨⟨10569001, 10582008, 3253, 3257, 3259, 10568471, 10568653, 10568993⟩, 11⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3253,
    ExposureEvolution.Compact40Pratt.prime_3257,
    ExposureEvolution.Compact40Pratt.prime_3259,
    ExposureEvolution.Compact40Pratt.prime_10568471,
    ExposureEvolution.Compact40Pratt.prime_10568653,
    ExposureEvolution.Compact40Pratt.prime_10568993]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 10582009 stop tail = true) :
    coverage 7349521 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_001
