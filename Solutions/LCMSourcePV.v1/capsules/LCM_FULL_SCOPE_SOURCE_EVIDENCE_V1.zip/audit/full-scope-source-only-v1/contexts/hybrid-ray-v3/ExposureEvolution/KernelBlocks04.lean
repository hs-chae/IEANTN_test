import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks04
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨3798601, 3806400, 1951, 1973, 1979, 3798187, 3798583, 3798593⟩, 7⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1951,
    ExposureEvolution.KernelPratt.prime_1973,
    ExposureEvolution.KernelPratt.prime_1979,
    ExposureEvolution.KernelPratt.prime_3798187,
    ExposureEvolution.KernelPratt.prime_3798583,
    ExposureEvolution.KernelPratt.prime_3798593]

def block01 : Witness := ⟨⟨3806401, 3892728, 1973, 1979, 1987, 3806281, 3806303, 3806347⟩, 8⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1973,
    ExposureEvolution.KernelPratt.prime_1979,
    ExposureEvolution.KernelPratt.prime_1987,
    ExposureEvolution.KernelPratt.prime_3806281,
    ExposureEvolution.KernelPratt.prime_3806303,
    ExposureEvolution.KernelPratt.prime_3806347]

def block02 : Witness := ⟨⟨3892729, 3916440, 1979, 1987, 1993, 3892199, 3892607, 3892697⟩, 8⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1979,
    ExposureEvolution.KernelPratt.prime_1987,
    ExposureEvolution.KernelPratt.prime_1993,
    ExposureEvolution.KernelPratt.prime_3892199,
    ExposureEvolution.KernelPratt.prime_3892607,
    ExposureEvolution.KernelPratt.prime_3892697]

def block03 : Witness := ⟨⟨3916441, 3948168, 1987, 1993, 1997, 3916057, 3916309, 3916439⟩, 10⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1987,
    ExposureEvolution.KernelPratt.prime_1993,
    ExposureEvolution.KernelPratt.prime_1997,
    ExposureEvolution.KernelPratt.prime_3916057,
    ExposureEvolution.KernelPratt.prime_3916309,
    ExposureEvolution.KernelPratt.prime_3916439]

def block04 : Witness := ⟨⟨3948169, 3972048, 1993, 1997, 1999, 3947693, 3947851, 3948163⟩, 11⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1993,
    ExposureEvolution.KernelPratt.prime_1997,
    ExposureEvolution.KernelPratt.prime_1999,
    ExposureEvolution.KernelPratt.prime_3947693,
    ExposureEvolution.KernelPratt.prime_3947851,
    ExposureEvolution.KernelPratt.prime_3948163]

def block05 : Witness := ⟨⟨3972049, 3988008, 1997, 1999, 2003, 3971651, 3971809, 3972037⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1997,
    ExposureEvolution.KernelPratt.prime_1999,
    ExposureEvolution.KernelPratt.prime_2003,
    ExposureEvolution.KernelPratt.prime_3971651,
    ExposureEvolution.KernelPratt.prime_3971809,
    ExposureEvolution.KernelPratt.prime_3972037]

def block06 : Witness := ⟨⟨3988009, 3996000, 1999, 2003, 2011, 3987521, 3987887, 3988007⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1999,
    ExposureEvolution.KernelPratt.prime_2003,
    ExposureEvolution.KernelPratt.prime_2011,
    ExposureEvolution.KernelPratt.prime_3987521,
    ExposureEvolution.KernelPratt.prime_3987887,
    ExposureEvolution.KernelPratt.prime_3988007]

def block07 : Witness := ⟨⟨3996001, 4012008, 2003, 2011, 2017, 3995699, 3995713, 3995989⟩, 11⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2003,
    ExposureEvolution.KernelPratt.prime_2011,
    ExposureEvolution.KernelPratt.prime_2017,
    ExposureEvolution.KernelPratt.prime_3995699,
    ExposureEvolution.KernelPratt.prime_3995713,
    ExposureEvolution.KernelPratt.prime_3995989]

def block08 : Witness := ⟨⟨4012009, 4044120, 2011, 2017, 2027, 4011767, 4011929, 4011991⟩, 7⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2011,
    ExposureEvolution.KernelPratt.prime_2017,
    ExposureEvolution.KernelPratt.prime_2027,
    ExposureEvolution.KernelPratt.prime_4011767,
    ExposureEvolution.KernelPratt.prime_4011929,
    ExposureEvolution.KernelPratt.prime_4011991]

def block09 : Witness := ⟨⟨4044121, 4068288, 2017, 2027, 2029, 4043623, 4043761, 4044077⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2017,
    ExposureEvolution.KernelPratt.prime_2027,
    ExposureEvolution.KernelPratt.prime_2029,
    ExposureEvolution.KernelPratt.prime_4043623,
    ExposureEvolution.KernelPratt.prime_4043761,
    ExposureEvolution.KernelPratt.prime_4044077]

def block10 : Witness := ⟨⟨4068289, 4108728, 2027, 2029, 2039, 4068073, 4068137, 4068283⟩, 8⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2027,
    ExposureEvolution.KernelPratt.prime_2029,
    ExposureEvolution.KernelPratt.prime_2039,
    ExposureEvolution.KernelPratt.prime_4068073,
    ExposureEvolution.KernelPratt.prime_4068137,
    ExposureEvolution.KernelPratt.prime_4068283]

def block11 : Witness := ⟨⟨4108729, 4116840, 2029, 2039, 2053, 4108483, 4108589, 4108717⟩, 9⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2029,
    ExposureEvolution.KernelPratt.prime_2039,
    ExposureEvolution.KernelPratt.prime_2053,
    ExposureEvolution.KernelPratt.prime_4108483,
    ExposureEvolution.KernelPratt.prime_4108589,
    ExposureEvolution.KernelPratt.prime_4108717]

def block12 : Witness := ⟨⟨4116841, 4157520, 2039, 2053, 2063, 4116391, 4116617, 4116823⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2039,
    ExposureEvolution.KernelPratt.prime_2053,
    ExposureEvolution.KernelPratt.prime_2063,
    ExposureEvolution.KernelPratt.prime_4116391,
    ExposureEvolution.KernelPratt.prime_4116617,
    ExposureEvolution.KernelPratt.prime_4116823]

def block13 : Witness := ⟨⟨4157521, 4214808, 2053, 2063, 2069, 4157099, 4157141, 4157513⟩, 6⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2053,
    ExposureEvolution.KernelPratt.prime_2063,
    ExposureEvolution.KernelPratt.prime_2069,
    ExposureEvolution.KernelPratt.prime_4157099,
    ExposureEvolution.KernelPratt.prime_4157141,
    ExposureEvolution.KernelPratt.prime_4157513]

def block14 : Witness := ⟨⟨4214809, 4255968, 2063, 2069, 2081, 4214549, 4214627, 4214807⟩, 10⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2063,
    ExposureEvolution.KernelPratt.prime_2069,
    ExposureEvolution.KernelPratt.prime_2081,
    ExposureEvolution.KernelPratt.prime_4214549,
    ExposureEvolution.KernelPratt.prime_4214627,
    ExposureEvolution.KernelPratt.prime_4214807]

def block15 : Witness := ⟨⟨4255969, 4280760, 2069, 2081, 2083, 4255807, 4255921, 4255963⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2069,
    ExposureEvolution.KernelPratt.prime_2081,
    ExposureEvolution.KernelPratt.prime_2083,
    ExposureEvolution.KernelPratt.prime_4255807,
    ExposureEvolution.KernelPratt.prime_4255921,
    ExposureEvolution.KernelPratt.prime_4255963]

def block16 : Witness := ⟨⟨4280761, 4330560, 2081, 2083, 2087, 4280537, 4280593, 4280747⟩, 7⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2081,
    ExposureEvolution.KernelPratt.prime_2083,
    ExposureEvolution.KernelPratt.prime_2087,
    ExposureEvolution.KernelPratt.prime_4280537,
    ExposureEvolution.KernelPratt.prime_4280593,
    ExposureEvolution.KernelPratt.prime_4280747]

def block17 : Witness := ⟨⟨4330561, 4338888, 2083, 2087, 2089, 4330351, 4330523, 4330559⟩, 10⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2083,
    ExposureEvolution.KernelPratt.prime_2087,
    ExposureEvolution.KernelPratt.prime_2089,
    ExposureEvolution.KernelPratt.prime_4330351,
    ExposureEvolution.KernelPratt.prime_4330523,
    ExposureEvolution.KernelPratt.prime_4330559]

def block18 : Witness := ⟨⟨4338889, 4355568, 2087, 2089, 2099, 4338613, 4338787, 4338883⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2087,
    ExposureEvolution.KernelPratt.prime_2089,
    ExposureEvolution.KernelPratt.prime_2099,
    ExposureEvolution.KernelPratt.prime_4338613,
    ExposureEvolution.KernelPratt.prime_4338787,
    ExposureEvolution.KernelPratt.prime_4338883]

def block19 : Witness := ⟨⟨4355569, 4363920, 2089, 2099, 2111, 4355327, 4355347, 4355567⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2089,
    ExposureEvolution.KernelPratt.prime_2099,
    ExposureEvolution.KernelPratt.prime_2111,
    ExposureEvolution.KernelPratt.prime_4355327,
    ExposureEvolution.KernelPratt.prime_4355347,
    ExposureEvolution.KernelPratt.prime_4355567]

def block20 : Witness := ⟨⟨4363921, 4405800, 2099, 2111, 2113, 4363363, 4363613, 4363897⟩, 13⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2099,
    ExposureEvolution.KernelPratt.prime_2111,
    ExposureEvolution.KernelPratt.prime_2113,
    ExposureEvolution.KernelPratt.prime_4363363,
    ExposureEvolution.KernelPratt.prime_4363613,
    ExposureEvolution.KernelPratt.prime_4363897]

def block21 : Witness := ⟨⟨4405801, 4456320, 2111, 2113, 2129, 4405571, 4405693, 4405789⟩, 10⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2111,
    ExposureEvolution.KernelPratt.prime_2113,
    ExposureEvolution.KernelPratt.prime_2129,
    ExposureEvolution.KernelPratt.prime_4405571,
    ExposureEvolution.KernelPratt.prime_4405693,
    ExposureEvolution.KernelPratt.prime_4405789]

def block22 : Witness := ⟨⟨4456321, 4464768, 2113, 2129, 2131, 4455959, 4456007, 4456301⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2113,
    ExposureEvolution.KernelPratt.prime_2129,
    ExposureEvolution.KernelPratt.prime_2131,
    ExposureEvolution.KernelPratt.prime_4455959,
    ExposureEvolution.KernelPratt.prime_4456007,
    ExposureEvolution.KernelPratt.prime_4456301]

def block23 : Witness := ⟨⟨4464769, 4532640, 2129, 2131, 2137, 4464253, 4464371, 4464767⟩, 10⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2129,
    ExposureEvolution.KernelPratt.prime_2131,
    ExposureEvolution.KernelPratt.prime_2137,
    ExposureEvolution.KernelPratt.prime_4464253,
    ExposureEvolution.KernelPratt.prime_4464371,
    ExposureEvolution.KernelPratt.prime_4464767]

def block24 : Witness := ⟨⟨4532641, 4541160, 2131, 2137, 2141, 4532513, 4532527, 4532639⟩, 6⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2131,
    ExposureEvolution.KernelPratt.prime_2137,
    ExposureEvolution.KernelPratt.prime_2141,
    ExposureEvolution.KernelPratt.prime_4532513,
    ExposureEvolution.KernelPratt.prime_4532527,
    ExposureEvolution.KernelPratt.prime_4532639]

def block25 : Witness := ⟨⟨4541161, 4566768, 2137, 2141, 2143, 4540993, 4540997, 4541153⟩, 7⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2137,
    ExposureEvolution.KernelPratt.prime_2141,
    ExposureEvolution.KernelPratt.prime_2143,
    ExposureEvolution.KernelPratt.prime_4540993,
    ExposureEvolution.KernelPratt.prime_4540997,
    ExposureEvolution.KernelPratt.prime_4541153]

def block26 : Witness := ⟨⟨4566769, 4583880, 2141, 2143, 2153, 4566229, 4566257, 4566767⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2141,
    ExposureEvolution.KernelPratt.prime_2143,
    ExposureEvolution.KernelPratt.prime_2153,
    ExposureEvolution.KernelPratt.prime_4566229,
    ExposureEvolution.KernelPratt.prime_4566257,
    ExposureEvolution.KernelPratt.prime_4566767]

def block27 : Witness := ⟨⟨4583881, 4592448, 2143, 2153, 2161, 4583573, 4583783, 4583869⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2143,
    ExposureEvolution.KernelPratt.prime_2153,
    ExposureEvolution.KernelPratt.prime_2161,
    ExposureEvolution.KernelPratt.prime_4583573,
    ExposureEvolution.KernelPratt.prime_4583783,
    ExposureEvolution.KernelPratt.prime_4583869]

def block28 : Witness := ⟨⟨4592449, 4635408, 2153, 2161, 2179, 4592069, 4592257, 4592429⟩, 7⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2153,
    ExposureEvolution.KernelPratt.prime_2161,
    ExposureEvolution.KernelPratt.prime_2179,
    ExposureEvolution.KernelPratt.prime_4592069,
    ExposureEvolution.KernelPratt.prime_4592257,
    ExposureEvolution.KernelPratt.prime_4592429]

def block29 : Witness := ⟨⟨4635409, 4669920, 2161, 2179, 2203, 4634977, 4635161, 4635403⟩, 8⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2161,
    ExposureEvolution.KernelPratt.prime_2179,
    ExposureEvolution.KernelPratt.prime_2203,
    ExposureEvolution.KernelPratt.prime_4634977,
    ExposureEvolution.KernelPratt.prime_4635161,
    ExposureEvolution.KernelPratt.prime_4635403]

def block30 : Witness := ⟨⟨4669921, 4748040, 2179, 2203, 2207, 4669517, 4669627, 4669913⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2179,
    ExposureEvolution.KernelPratt.prime_2203,
    ExposureEvolution.KernelPratt.prime_2207,
    ExposureEvolution.KernelPratt.prime_4669517,
    ExposureEvolution.KernelPratt.prime_4669627,
    ExposureEvolution.KernelPratt.prime_4669913]

def block31 : Witness := ⟨⟨4748041, 4853208, 2203, 2207, 2213, 4747927, 4747937, 4748039⟩, 8⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2203,
    ExposureEvolution.KernelPratt.prime_2207,
    ExposureEvolution.KernelPratt.prime_2213,
    ExposureEvolution.KernelPratt.prime_4747927,
    ExposureEvolution.KernelPratt.prime_4747937,
    ExposureEvolution.KernelPratt.prime_4748039]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 4853209 stop tail = true) :
    coverage 3798601 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks04
