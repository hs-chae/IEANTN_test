import ExposureEvolution.KernelData
import ExposureEvolution.KernelBlocks00
import ExposureEvolution.KernelBlocks01
import ExposureEvolution.KernelBlocks02
import ExposureEvolution.KernelBlocks03
import ExposureEvolution.KernelBlocks04
import ExposureEvolution.KernelBlocks05
import ExposureEvolution.KernelBlocks06
import ExposureEvolution.KernelBlocks07
import ExposureEvolution.KernelBlocks08
import ExposureEvolution.KernelBlocks09
import ExposureEvolution.KernelBlocks10
import ExposureEvolution.KernelBlocks11
import ExposureEvolution.KernelBlocks12
import ExposureEvolution.KernelBlocks13
import ExposureEvolution.KernelBlocks14
import ExposureEvolution.KernelBlocks15
import ExposureEvolution.KernelBlocks16
import ExposureEvolution.KernelBlocks17
import ExposureEvolution.KernelBlocks18
import ExposureEvolution.KernelBlocks19
import ExposureEvolution.KernelBlocks20
import ExposureEvolution.KernelBlocks21
import ExposureEvolution.KernelBlocks22
import ExposureEvolution.KernelBlocks23
import ExposureEvolution.KernelBlocks24
import ExposureEvolution.KernelBlocks25
import ExposureEvolution.KernelBlocks26
import ExposureEvolution.KernelBlocks27
namespace ExposureEvolution.KernelBlockCoverage
open ExposureEvolution.Adaptive
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem same_values : KernelData.witnesses =
  ExposureEvolution.KernelBlocks00.witnesses ++
  ExposureEvolution.KernelBlocks01.witnesses ++
  ExposureEvolution.KernelBlocks02.witnesses ++
  ExposureEvolution.KernelBlocks03.witnesses ++
  ExposureEvolution.KernelBlocks04.witnesses ++
  ExposureEvolution.KernelBlocks05.witnesses ++
  ExposureEvolution.KernelBlocks06.witnesses ++
  ExposureEvolution.KernelBlocks07.witnesses ++
  ExposureEvolution.KernelBlocks08.witnesses ++
  ExposureEvolution.KernelBlocks09.witnesses ++
  ExposureEvolution.KernelBlocks10.witnesses ++
  ExposureEvolution.KernelBlocks11.witnesses ++
  ExposureEvolution.KernelBlocks12.witnesses ++
  ExposureEvolution.KernelBlocks13.witnesses ++
  ExposureEvolution.KernelBlocks14.witnesses ++
  ExposureEvolution.KernelBlocks15.witnesses ++
  ExposureEvolution.KernelBlocks16.witnesses ++
  ExposureEvolution.KernelBlocks17.witnesses ++
  ExposureEvolution.KernelBlocks18.witnesses ++
  ExposureEvolution.KernelBlocks19.witnesses ++
  ExposureEvolution.KernelBlocks20.witnesses ++
  ExposureEvolution.KernelBlocks21.witnesses ++
  ExposureEvolution.KernelBlocks22.witnesses ++
  ExposureEvolution.KernelBlocks23.witnesses ++
  ExposureEvolution.KernelBlocks24.witnesses ++
  ExposureEvolution.KernelBlocks25.witnesses ++
  ExposureEvolution.KernelBlocks26.witnesses ++
  ExposureEvolution.KernelBlocks27.witnesses := by rfl

theorem accepted : coverage 1000000 71707024 KernelData.witnesses = true := by
  rw [same_values]
  apply ExposureEvolution.KernelBlocks00.extend
  apply ExposureEvolution.KernelBlocks01.extend
  apply ExposureEvolution.KernelBlocks02.extend
  apply ExposureEvolution.KernelBlocks03.extend
  apply ExposureEvolution.KernelBlocks04.extend
  apply ExposureEvolution.KernelBlocks05.extend
  apply ExposureEvolution.KernelBlocks06.extend
  apply ExposureEvolution.KernelBlocks07.extend
  apply ExposureEvolution.KernelBlocks08.extend
  apply ExposureEvolution.KernelBlocks09.extend
  apply ExposureEvolution.KernelBlocks10.extend
  apply ExposureEvolution.KernelBlocks11.extend
  apply ExposureEvolution.KernelBlocks12.extend
  apply ExposureEvolution.KernelBlocks13.extend
  apply ExposureEvolution.KernelBlocks14.extend
  apply ExposureEvolution.KernelBlocks15.extend
  apply ExposureEvolution.KernelBlocks16.extend
  apply ExposureEvolution.KernelBlocks17.extend
  apply ExposureEvolution.KernelBlocks18.extend
  apply ExposureEvolution.KernelBlocks19.extend
  apply ExposureEvolution.KernelBlocks20.extend
  apply ExposureEvolution.KernelBlocks21.extend
  apply ExposureEvolution.KernelBlocks22.extend
  apply ExposureEvolution.KernelBlocks23.extend
  apply ExposureEvolution.KernelBlocks24.extend
  apply ExposureEvolution.KernelBlocks25.extend
  apply ExposureEvolution.KernelBlocks26.extend
  apply ExposureEvolution.KernelBlocks27.extend
  decide +kernel

theorem finite (n : ℕ) (hn : 1000000 ≤ n ∧ n < 71707024) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m :=
  coverage_sound 1000000 71707024 KernelData.witnesses accepted n hn

#print axioms accepted
#print axioms finite
end ExposureEvolution.KernelBlockCoverage
