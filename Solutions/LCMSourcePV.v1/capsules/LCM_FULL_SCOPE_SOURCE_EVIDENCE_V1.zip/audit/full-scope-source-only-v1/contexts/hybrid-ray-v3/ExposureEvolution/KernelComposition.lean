import ExposureEvolution.Adaptive
import ExposureEvolution.KernelPrimeProgram

namespace ExposureEvolution.KernelComposition
open ExposureEvolution.Adaptive

/-- Preserve the exact original checker, composing already kernel-proved block facts. -/
theorem coverage_cons (lo stop : ℕ) (w : Witness) (ws : List Witness)
    (hlo : w.block.lo = lo) (hw : w.check = true)
    (ht : coverage (w.block.hi + 1) stop ws = true) :
    coverage lo stop (w :: ws) = true := by
  simp only [coverage, hlo, decide_true, hw, ht, Bool.true_and]

theorem check_cons (a b p : ℕ) (ps : List ℕ)
    (hp : Nat.Prime p ∧ a < p ∧ 256 * p < 257 * a)
    (ht : KernelPrimeProgram.check p b ps = true) :
    KernelPrimeProgram.check a b (p :: ps) = true := by
  simpa only [KernelPrimeProgram.check, Bool.and_eq_true, decide_eq_true_eq] using And.intro hp ht

end ExposureEvolution.KernelComposition
