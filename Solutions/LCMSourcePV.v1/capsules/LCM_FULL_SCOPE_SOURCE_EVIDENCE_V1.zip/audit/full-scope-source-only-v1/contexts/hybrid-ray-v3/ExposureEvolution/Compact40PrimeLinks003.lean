import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks003
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_11527 : next 11527 = some 11551 := by
  have hl : (List.range ((257 * 11527 - 1) / 256 - 11527)).reverse =
      [44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11551]

theorem next_11551 : next 11551 = some 11593 := by
  have hl : (List.range ((257 * 11551 - 1) / 256 - 11551)).reverse =
      [44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11593]

theorem next_11593 : next 11593 = some 11633 := by
  have hl : (List.range ((257 * 11593 - 1) / 256 - 11593)).reverse =
      [44, 43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11633]

theorem next_11633 : next 11633 = some 11677 := by
  have hl : (List.range ((257 * 11633 - 1) / 256 - 11633)).reverse =
      [44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11677]

theorem next_11677 : next 11677 = some 11719 := by
  have hl : (List.range ((257 * 11677 - 1) / 256 - 11677)).reverse =
      [44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11719]

theorem next_11719 : next 11719 = some 11743 := by
  have hl : (List.range ((257 * 11719 - 1) / 256 - 11719)).reverse =
      [44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11743]

theorem next_11743 : next 11743 = some 11783 := by
  have hl : (List.range ((257 * 11743 - 1) / 256 - 11743)).reverse =
      [44, 43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11783]

theorem next_11783 : next 11783 = some 11827 := by
  have hl : (List.range ((257 * 11783 - 1) / 256 - 11783)).reverse =
      [45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11827]

theorem next_11827 : next 11827 = some 11867 := by
  have hl : (List.range ((257 * 11827 - 1) / 256 - 11827)).reverse =
      [45, 44, 43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11867]

theorem next_11867 : next 11867 = some 11909 := by
  have hl : (List.range ((257 * 11867 - 1) / 256 - 11867)).reverse =
      [45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11909]

theorem next_11909 : next 11909 = some 11953 := by
  have hl : (List.range ((257 * 11909 - 1) / 256 - 11909)).reverse =
      [45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11953]

theorem next_11953 : next 11953 = some 11987 := by
  have hl : (List.range ((257 * 11953 - 1) / 256 - 11953)).reverse =
      [45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11987]

theorem next_11987 : next 11987 = some 12011 := by
  have hl : (List.range ((257 * 11987 - 1) / 256 - 11987)).reverse =
      [45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12011]

theorem next_12011 : next 12011 = some 12049 := by
  have hl : (List.range ((257 * 12011 - 1) / 256 - 12011)).reverse =
      [45, 44, 43, 42, 41, 40, 39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12049]

theorem next_12049 : next 12049 = some 12073 := by
  have hl : (List.range ((257 * 12049 - 1) / 256 - 12049)).reverse =
      [46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12073]

theorem next_12073 : next 12073 = some 12119 := by
  have hl : (List.range ((257 * 12073 - 1) / 256 - 12073)).reverse =
      [46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12119]

theorem next_12119 : next 12119 = some 12163 := by
  have hl : (List.range ((257 * 12119 - 1) / 256 - 12119)).reverse =
      [46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12163]

theorem next_12163 : next 12163 = some 12203 := by
  have hl : (List.range ((257 * 12163 - 1) / 256 - 12163)).reverse =
      [46, 45, 44, 43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12203]

theorem next_12203 : next 12203 = some 12241 := by
  have hl : (List.range ((257 * 12203 - 1) / 256 - 12203)).reverse =
      [46, 45, 44, 43, 42, 41, 40, 39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12241]

theorem next_12241 : next 12241 = some 12281 := by
  have hl : (List.range ((257 * 12241 - 1) / 256 - 12241)).reverse =
      [46, 45, 44, 43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12281]

theorem next_12281 : next 12281 = some 12323 := by
  have hl : (List.range ((257 * 12281 - 1) / 256 - 12281)).reverse =
      [46, 45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12323]

theorem next_12323 : next 12323 = some 12347 := by
  have hl : (List.range ((257 * 12323 - 1) / 256 - 12323)).reverse =
      [47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12347]

theorem next_12347 : next 12347 = some 12391 := by
  have hl : (List.range ((257 * 12347 - 1) / 256 - 12347)).reverse =
      [47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12391]

theorem next_12391 : next 12391 = some 12437 := by
  have hl : (List.range ((257 * 12391 - 1) / 256 - 12391)).reverse =
      [47, 46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12437]

theorem next_12437 : next 12437 = some 12479 := by
  have hl : (List.range ((257 * 12437 - 1) / 256 - 12437)).reverse =
      [47, 46, 45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12479]

theorem next_12479 : next 12479 = some 12527 := by
  have hl : (List.range ((257 * 12479 - 1) / 256 - 12479)).reverse =
      [47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12527]

theorem next_12527 : next 12527 = some 12569 := by
  have hl : (List.range ((257 * 12527 - 1) / 256 - 12527)).reverse =
      [47, 46, 45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12569]

theorem next_12569 : next 12569 = some 12613 := by
  have hl : (List.range ((257 * 12569 - 1) / 256 - 12569)).reverse =
      [48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12613]

theorem next_12613 : next 12613 = some 12659 := by
  have hl : (List.range ((257 * 12613 - 1) / 256 - 12613)).reverse =
      [48, 47, 46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12659]

theorem next_12659 : next 12659 = some 12703 := by
  have hl : (List.range ((257 * 12659 - 1) / 256 - 12659)).reverse =
      [48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12703]

theorem next_12703 : next 12703 = some 12743 := by
  have hl : (List.range ((257 * 12703 - 1) / 256 - 12703)).reverse =
      [48, 47, 46, 45, 44, 43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12743]

theorem next_12743 : next 12743 = some 12791 := by
  have hl : (List.range ((257 * 12743 - 1) / 256 - 12743)).reverse =
      [48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_12791]

def primes : List ℕ := [11551, 11593, 11633, 11677, 11719, 11743, 11783, 11827, 11867, 11909, 11953, 11987, 12011, 12049, 12073, 12119, 12163, 12203, 12241, 12281, 12323, 12347, 12391, 12437, 12479, 12527, 12569, 12613, 12659, 12703, 12743, 12791]

theorem segment : run 604 11527 89693 =
    primes ++ run 572 12791 89693 := by
  rw [Compact40PrimeCompose256.step 603 11527 89693 11551
    (by decide +kernel) next_11527]
  rw [Compact40PrimeCompose256.step 602 11551 89693 11593
    (by decide +kernel) next_11551]
  rw [Compact40PrimeCompose256.step 601 11593 89693 11633
    (by decide +kernel) next_11593]
  rw [Compact40PrimeCompose256.step 600 11633 89693 11677
    (by decide +kernel) next_11633]
  rw [Compact40PrimeCompose256.step 599 11677 89693 11719
    (by decide +kernel) next_11677]
  rw [Compact40PrimeCompose256.step 598 11719 89693 11743
    (by decide +kernel) next_11719]
  rw [Compact40PrimeCompose256.step 597 11743 89693 11783
    (by decide +kernel) next_11743]
  rw [Compact40PrimeCompose256.step 596 11783 89693 11827
    (by decide +kernel) next_11783]
  rw [Compact40PrimeCompose256.step 595 11827 89693 11867
    (by decide +kernel) next_11827]
  rw [Compact40PrimeCompose256.step 594 11867 89693 11909
    (by decide +kernel) next_11867]
  rw [Compact40PrimeCompose256.step 593 11909 89693 11953
    (by decide +kernel) next_11909]
  rw [Compact40PrimeCompose256.step 592 11953 89693 11987
    (by decide +kernel) next_11953]
  rw [Compact40PrimeCompose256.step 591 11987 89693 12011
    (by decide +kernel) next_11987]
  rw [Compact40PrimeCompose256.step 590 12011 89693 12049
    (by decide +kernel) next_12011]
  rw [Compact40PrimeCompose256.step 589 12049 89693 12073
    (by decide +kernel) next_12049]
  rw [Compact40PrimeCompose256.step 588 12073 89693 12119
    (by decide +kernel) next_12073]
  rw [Compact40PrimeCompose256.step 587 12119 89693 12163
    (by decide +kernel) next_12119]
  rw [Compact40PrimeCompose256.step 586 12163 89693 12203
    (by decide +kernel) next_12163]
  rw [Compact40PrimeCompose256.step 585 12203 89693 12241
    (by decide +kernel) next_12203]
  rw [Compact40PrimeCompose256.step 584 12241 89693 12281
    (by decide +kernel) next_12241]
  rw [Compact40PrimeCompose256.step 583 12281 89693 12323
    (by decide +kernel) next_12281]
  rw [Compact40PrimeCompose256.step 582 12323 89693 12347
    (by decide +kernel) next_12323]
  rw [Compact40PrimeCompose256.step 581 12347 89693 12391
    (by decide +kernel) next_12347]
  rw [Compact40PrimeCompose256.step 580 12391 89693 12437
    (by decide +kernel) next_12391]
  rw [Compact40PrimeCompose256.step 579 12437 89693 12479
    (by decide +kernel) next_12437]
  rw [Compact40PrimeCompose256.step 578 12479 89693 12527
    (by decide +kernel) next_12479]
  rw [Compact40PrimeCompose256.step 577 12527 89693 12569
    (by decide +kernel) next_12527]
  rw [Compact40PrimeCompose256.step 576 12569 89693 12613
    (by decide +kernel) next_12569]
  rw [Compact40PrimeCompose256.step 575 12613 89693 12659
    (by decide +kernel) next_12613]
  rw [Compact40PrimeCompose256.step 574 12659 89693 12703
    (by decide +kernel) next_12659]
  rw [Compact40PrimeCompose256.step 573 12703 89693 12743
    (by decide +kernel) next_12703]
  rw [Compact40PrimeCompose256.step 572 12743 89693 12791
    (by decide +kernel) next_12743]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 12791 stop tail = true) :
    check 11527 stop (primes ++ tail) = true := by
  change check _ _ (11551 :: 11593 :: 11633 :: 11677 :: 11719 :: 11743 :: 11783 :: 11827 :: 11867 :: 11909 :: 11953 :: 11987 :: 12011 :: 12049 :: 12073 :: 12119 :: 12163 :: 12203 :: 12241 :: 12281 :: 12323 :: 12347 :: 12391 :: 12437 :: 12479 :: 12527 :: 12569 :: 12613 :: 12659 :: 12703 :: 12743 :: 12791 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11551, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11593, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11633, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11677, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11719, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11743, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11783, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11827, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11867, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11909, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11953, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11987, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12011, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12049, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12073, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12119, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12163, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12203, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12241, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12281, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12323, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12347, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12391, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12437, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12479, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12527, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12569, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12613, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12659, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12703, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12743, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_12791, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks003
