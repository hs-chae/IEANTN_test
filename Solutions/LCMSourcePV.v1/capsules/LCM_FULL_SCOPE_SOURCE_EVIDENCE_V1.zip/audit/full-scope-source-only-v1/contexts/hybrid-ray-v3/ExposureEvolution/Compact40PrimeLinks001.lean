import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks001
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_9349 : next 9349 = some 9377 := by
  have hl : (List.range ((257 * 9349 - 1) / 256 - 9349)).reverse =
      [35, 34, 33, 32, 31, 30, 29, 28, 27] ++ (List.range 27).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9377]

theorem next_9377 : next 9377 = some 9413 := by
  have hl : (List.range ((257 * 9377 - 1) / 256 - 9377)).reverse =
      [35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9413]

theorem next_9413 : next 9413 = some 9439 := by
  have hl : (List.range ((257 * 9413 - 1) / 256 - 9413)).reverse =
      [35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9439]

theorem next_9439 : next 9439 = some 9473 := by
  have hl : (List.range ((257 * 9439 - 1) / 256 - 9439)).reverse =
      [35, 34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9473]

theorem next_9473 : next 9473 = some 9497 := by
  have hl : (List.range ((257 * 9473 - 1) / 256 - 9473)).reverse =
      [36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9497]

theorem next_9497 : next 9497 = some 9533 := by
  have hl : (List.range ((257 * 9497 - 1) / 256 - 9497)).reverse =
      [36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9533]

theorem next_9533 : next 9533 = some 9551 := by
  have hl : (List.range ((257 * 9533 - 1) / 256 - 9533)).reverse =
      [36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17] ++ (List.range 17).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9551]

theorem next_9551 : next 9551 = some 9587 := by
  have hl : (List.range ((257 * 9551 - 1) / 256 - 9551)).reverse =
      [36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9587]

theorem next_9587 : next 9587 = some 9623 := by
  have hl : (List.range ((257 * 9587 - 1) / 256 - 9587)).reverse =
      [36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9623]

theorem next_9623 : next 9623 = some 9649 := by
  have hl : (List.range ((257 * 9623 - 1) / 256 - 9623)).reverse =
      [36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9649]

theorem next_9649 : next 9649 = some 9679 := by
  have hl : (List.range ((257 * 9649 - 1) / 256 - 9649)).reverse =
      [36, 35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9679]

theorem next_9679 : next 9679 = some 9697 := by
  have hl : (List.range ((257 * 9679 - 1) / 256 - 9679)).reverse =
      [36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17] ++ (List.range 17).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9697]

theorem next_9697 : next 9697 = some 9733 := by
  have hl : (List.range ((257 * 9697 - 1) / 256 - 9697)).reverse =
      [36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9733]

theorem next_9733 : next 9733 = some 9769 := by
  have hl : (List.range ((257 * 9733 - 1) / 256 - 9733)).reverse =
      [37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9769]

theorem next_9769 : next 9769 = some 9803 := by
  have hl : (List.range ((257 * 9769 - 1) / 256 - 9769)).reverse =
      [37, 36, 35, 34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9803]

theorem next_9803 : next 9803 = some 9839 := by
  have hl : (List.range ((257 * 9803 - 1) / 256 - 9803)).reverse =
      [37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9839]

theorem next_9839 : next 9839 = some 9871 := by
  have hl : (List.range ((257 * 9839 - 1) / 256 - 9839)).reverse =
      [37, 36, 35, 34, 33, 32, 31] ++ (List.range 31).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9871]

theorem next_9871 : next 9871 = some 9907 := by
  have hl : (List.range ((257 * 9871 - 1) / 256 - 9871)).reverse =
      [37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9907]

theorem next_9907 : next 9907 = some 9941 := by
  have hl : (List.range ((257 * 9907 - 1) / 256 - 9907)).reverse =
      [37, 36, 35, 34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9941]

theorem next_9941 : next 9941 = some 9973 := by
  have hl : (List.range ((257 * 9941 - 1) / 256 - 9941)).reverse =
      [37, 36, 35, 34, 33, 32, 31] ++ (List.range 31).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_9973]

theorem next_9973 : next 9973 = some 10009 := by
  have hl : (List.range ((257 * 9973 - 1) / 256 - 9973)).reverse =
      [37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10009]

theorem next_10009 : next 10009 = some 10039 := by
  have hl : (List.range ((257 * 10009 - 1) / 256 - 10009)).reverse =
      [38, 37, 36, 35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10039]

theorem next_10039 : next 10039 = some 10069 := by
  have hl : (List.range ((257 * 10039 - 1) / 256 - 10039)).reverse =
      [38, 37, 36, 35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10069]

theorem next_10069 : next 10069 = some 10103 := by
  have hl : (List.range ((257 * 10069 - 1) / 256 - 10069)).reverse =
      [38, 37, 36, 35, 34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10103]

theorem next_10103 : next 10103 = some 10141 := by
  have hl : (List.range ((257 * 10103 - 1) / 256 - 10103)).reverse =
      [38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10141]

theorem next_10141 : next 10141 = some 10177 := by
  have hl : (List.range ((257 * 10141 - 1) / 256 - 10141)).reverse =
      [38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10177]

theorem next_10177 : next 10177 = some 10211 := by
  have hl : (List.range ((257 * 10177 - 1) / 256 - 10177)).reverse =
      [38, 37, 36, 35, 34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10211]

theorem next_10211 : next 10211 = some 10247 := by
  have hl : (List.range ((257 * 10211 - 1) / 256 - 10211)).reverse =
      [38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10247]

theorem next_10247 : next 10247 = some 10273 := by
  have hl : (List.range ((257 * 10247 - 1) / 256 - 10247)).reverse =
      [39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10273]

theorem next_10273 : next 10273 = some 10313 := by
  have hl : (List.range ((257 * 10273 - 1) / 256 - 10273)).reverse =
      [39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10313]

theorem next_10313 : next 10313 = some 10343 := by
  have hl : (List.range ((257 * 10313 - 1) / 256 - 10313)).reverse =
      [39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10343]

theorem next_10343 : next 10343 = some 10369 := by
  have hl : (List.range ((257 * 10343 - 1) / 256 - 10343)).reverse =
      [39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10369]

def primes : List ℕ := [9377, 9413, 9439, 9473, 9497, 9533, 9551, 9587, 9623, 9649, 9679, 9697, 9733, 9769, 9803, 9839, 9871, 9907, 9941, 9973, 10009, 10039, 10069, 10103, 10141, 10177, 10211, 10247, 10273, 10313, 10343, 10369]

theorem segment : run 668 9349 89693 =
    primes ++ run 636 10369 89693 := by
  rw [Compact40PrimeCompose256.step 667 9349 89693 9377
    (by decide +kernel) next_9349]
  rw [Compact40PrimeCompose256.step 666 9377 89693 9413
    (by decide +kernel) next_9377]
  rw [Compact40PrimeCompose256.step 665 9413 89693 9439
    (by decide +kernel) next_9413]
  rw [Compact40PrimeCompose256.step 664 9439 89693 9473
    (by decide +kernel) next_9439]
  rw [Compact40PrimeCompose256.step 663 9473 89693 9497
    (by decide +kernel) next_9473]
  rw [Compact40PrimeCompose256.step 662 9497 89693 9533
    (by decide +kernel) next_9497]
  rw [Compact40PrimeCompose256.step 661 9533 89693 9551
    (by decide +kernel) next_9533]
  rw [Compact40PrimeCompose256.step 660 9551 89693 9587
    (by decide +kernel) next_9551]
  rw [Compact40PrimeCompose256.step 659 9587 89693 9623
    (by decide +kernel) next_9587]
  rw [Compact40PrimeCompose256.step 658 9623 89693 9649
    (by decide +kernel) next_9623]
  rw [Compact40PrimeCompose256.step 657 9649 89693 9679
    (by decide +kernel) next_9649]
  rw [Compact40PrimeCompose256.step 656 9679 89693 9697
    (by decide +kernel) next_9679]
  rw [Compact40PrimeCompose256.step 655 9697 89693 9733
    (by decide +kernel) next_9697]
  rw [Compact40PrimeCompose256.step 654 9733 89693 9769
    (by decide +kernel) next_9733]
  rw [Compact40PrimeCompose256.step 653 9769 89693 9803
    (by decide +kernel) next_9769]
  rw [Compact40PrimeCompose256.step 652 9803 89693 9839
    (by decide +kernel) next_9803]
  rw [Compact40PrimeCompose256.step 651 9839 89693 9871
    (by decide +kernel) next_9839]
  rw [Compact40PrimeCompose256.step 650 9871 89693 9907
    (by decide +kernel) next_9871]
  rw [Compact40PrimeCompose256.step 649 9907 89693 9941
    (by decide +kernel) next_9907]
  rw [Compact40PrimeCompose256.step 648 9941 89693 9973
    (by decide +kernel) next_9941]
  rw [Compact40PrimeCompose256.step 647 9973 89693 10009
    (by decide +kernel) next_9973]
  rw [Compact40PrimeCompose256.step 646 10009 89693 10039
    (by decide +kernel) next_10009]
  rw [Compact40PrimeCompose256.step 645 10039 89693 10069
    (by decide +kernel) next_10039]
  rw [Compact40PrimeCompose256.step 644 10069 89693 10103
    (by decide +kernel) next_10069]
  rw [Compact40PrimeCompose256.step 643 10103 89693 10141
    (by decide +kernel) next_10103]
  rw [Compact40PrimeCompose256.step 642 10141 89693 10177
    (by decide +kernel) next_10141]
  rw [Compact40PrimeCompose256.step 641 10177 89693 10211
    (by decide +kernel) next_10177]
  rw [Compact40PrimeCompose256.step 640 10211 89693 10247
    (by decide +kernel) next_10211]
  rw [Compact40PrimeCompose256.step 639 10247 89693 10273
    (by decide +kernel) next_10247]
  rw [Compact40PrimeCompose256.step 638 10273 89693 10313
    (by decide +kernel) next_10273]
  rw [Compact40PrimeCompose256.step 637 10313 89693 10343
    (by decide +kernel) next_10313]
  rw [Compact40PrimeCompose256.step 636 10343 89693 10369
    (by decide +kernel) next_10343]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 10369 stop tail = true) :
    check 9349 stop (primes ++ tail) = true := by
  change check _ _ (9377 :: 9413 :: 9439 :: 9473 :: 9497 :: 9533 :: 9551 :: 9587 :: 9623 :: 9649 :: 9679 :: 9697 :: 9733 :: 9769 :: 9803 :: 9839 :: 9871 :: 9907 :: 9941 :: 9973 :: 10009 :: 10039 :: 10069 :: 10103 :: 10141 :: 10177 :: 10211 :: 10247 :: 10273 :: 10313 :: 10343 :: 10369 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9377, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9413, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9439, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9473, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9497, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9533, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9551, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9587, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9623, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9649, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9679, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9697, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9733, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9769, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9803, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9839, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9871, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9907, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9941, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_9973, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10009, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10039, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10069, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10103, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10141, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10177, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10211, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10247, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10273, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10313, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10343, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10369, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks001
