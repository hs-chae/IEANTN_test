import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks19
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨34774609, 34845408, 5903, 5923, 5927, 34774049, 34774381, 34774559⟩, 8⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5903,
    ExposureEvolution.KernelPratt.prime_5923,
    ExposureEvolution.KernelPratt.prime_5927,
    ExposureEvolution.KernelPratt.prime_34774049,
    ExposureEvolution.KernelPratt.prime_34774381,
    ExposureEvolution.KernelPratt.prime_34774559]

def block01 : Witness := ⟨⟨34845409, 35081928, 5923, 5927, 5939, 34845347, 34845397, 34845403⟩, 7⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5923,
    ExposureEvolution.KernelPratt.prime_5927,
    ExposureEvolution.KernelPratt.prime_5939,
    ExposureEvolution.KernelPratt.prime_34845347,
    ExposureEvolution.KernelPratt.prime_34845397,
    ExposureEvolution.KernelPratt.prime_34845403]

def block02 : Witness := ⟨⟨35081929, 35129328, 5927, 5939, 5953, 35081731, 35081869, 35081927⟩, 9⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5927,
    ExposureEvolution.KernelPratt.prime_5939,
    ExposureEvolution.KernelPratt.prime_5953,
    ExposureEvolution.KernelPratt.prime_35081731,
    ExposureEvolution.KernelPratt.prime_35081869,
    ExposureEvolution.KernelPratt.prime_35081927]

def block03 : Witness := ⟨⟨35129329, 35271720, 5939, 5953, 5981, 35128913, 35129183, 35129321⟩, 7⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5939,
    ExposureEvolution.KernelPratt.prime_5953,
    ExposureEvolution.KernelPratt.prime_5981,
    ExposureEvolution.KernelPratt.prime_35128913,
    ExposureEvolution.KernelPratt.prime_35129183,
    ExposureEvolution.KernelPratt.prime_35129321]

def block04 : Witness := ⟨⟨35271721, 35438208, 5953, 5981, 5987, 35271421, 35271623, 35271703⟩, 15⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5953,
    ExposureEvolution.KernelPratt.prime_5981,
    ExposureEvolution.KernelPratt.prime_5987,
    ExposureEvolution.KernelPratt.prime_35271421,
    ExposureEvolution.KernelPratt.prime_35271623,
    ExposureEvolution.KernelPratt.prime_35271703]

def block05 : Witness := ⟨⟨35438209, 35772360, 5981, 5987, 6007, 35437663, 35438129, 35438191⟩, 8⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5981,
    ExposureEvolution.KernelPratt.prime_5987,
    ExposureEvolution.KernelPratt.prime_6007,
    ExposureEvolution.KernelPratt.prime_35437663,
    ExposureEvolution.KernelPratt.prime_35438129,
    ExposureEvolution.KernelPratt.prime_35438191]

def block06 : Witness := ⟨⟨35772361, 35844168, 5987, 6007, 6011, 35771909, 35772203, 35772343⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5987,
    ExposureEvolution.KernelPratt.prime_6007,
    ExposureEvolution.KernelPratt.prime_6011,
    ExposureEvolution.KernelPratt.prime_35771909,
    ExposureEvolution.KernelPratt.prime_35772203,
    ExposureEvolution.KernelPratt.prime_35772343]

def block07 : Witness := ⟨⟨35844169, 36084048, 6007, 6011, 6029, 35843699, 35843879, 35844167⟩, 12⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6007,
    ExposureEvolution.KernelPratt.prime_6011,
    ExposureEvolution.KernelPratt.prime_6029,
    ExposureEvolution.KernelPratt.prime_35843699,
    ExposureEvolution.KernelPratt.prime_35843879,
    ExposureEvolution.KernelPratt.prime_35844167]

def block08 : Witness := ⟨⟨36084049, 36132120, 6011, 6029, 6037, 36083591, 36083897, 36084023⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6011,
    ExposureEvolution.KernelPratt.prime_6029,
    ExposureEvolution.KernelPratt.prime_6037,
    ExposureEvolution.KernelPratt.prime_36083591,
    ExposureEvolution.KernelPratt.prime_36083897,
    ExposureEvolution.KernelPratt.prime_36084023]

def block09 : Witness := ⟨⟨36132121, 36348840, 6029, 6037, 6043, 36131819, 36131891, 36132119⟩, 9⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6029,
    ExposureEvolution.KernelPratt.prime_6037,
    ExposureEvolution.KernelPratt.prime_6043,
    ExposureEvolution.KernelPratt.prime_36131819,
    ExposureEvolution.KernelPratt.prime_36131891,
    ExposureEvolution.KernelPratt.prime_36132119]

def block10 : Witness := ⟨⟨36348841, 36445368, 6037, 6043, 6047, 36348421, 36348731, 36348821⟩, 10⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6037,
    ExposureEvolution.KernelPratt.prime_6043,
    ExposureEvolution.KernelPratt.prime_6047,
    ExposureEvolution.KernelPratt.prime_36348421,
    ExposureEvolution.KernelPratt.prime_36348731,
    ExposureEvolution.KernelPratt.prime_36348821]

def block11 : Witness := ⟨⟨36445369, 36517848, 6043, 6047, 6053, 36444917, 36445009, 36445361⟩, 11⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6043,
    ExposureEvolution.KernelPratt.prime_6047,
    ExposureEvolution.KernelPratt.prime_6053,
    ExposureEvolution.KernelPratt.prime_36444917,
    ExposureEvolution.KernelPratt.prime_36445009,
    ExposureEvolution.KernelPratt.prime_36445361]

def block12 : Witness := ⟨⟨36517849, 36566208, 6047, 6053, 6067, 36517799, 36517801, 36517847⟩, 8⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6047,
    ExposureEvolution.KernelPratt.prime_6053,
    ExposureEvolution.KernelPratt.prime_6067,
    ExposureEvolution.KernelPratt.prime_36517799,
    ExposureEvolution.KernelPratt.prime_36517801,
    ExposureEvolution.KernelPratt.prime_36517847]

def block13 : Witness := ⟨⟨36566209, 36638808, 6053, 6067, 6073, 36565517, 36565873, 36566197⟩, 11⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6053,
    ExposureEvolution.KernelPratt.prime_6067,
    ExposureEvolution.KernelPratt.prime_6073,
    ExposureEvolution.KernelPratt.prime_36565517,
    ExposureEvolution.KernelPratt.prime_36565873,
    ExposureEvolution.KernelPratt.prime_36566197]

def block14 : Witness := ⟨⟨36638809, 36808488, 6067, 6073, 6079, 36638123, 36638443, 36638761⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6067,
    ExposureEvolution.KernelPratt.prime_6073,
    ExposureEvolution.KernelPratt.prime_6079,
    ExposureEvolution.KernelPratt.prime_36638123,
    ExposureEvolution.KernelPratt.prime_36638443,
    ExposureEvolution.KernelPratt.prime_36638761]

def block15 : Witness := ⟨⟨36808489, 36881328, 6073, 6079, 6089, 36808063, 36808273, 36808483⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6073,
    ExposureEvolution.KernelPratt.prime_6079,
    ExposureEvolution.KernelPratt.prime_6089,
    ExposureEvolution.KernelPratt.prime_36808063,
    ExposureEvolution.KernelPratt.prime_36808273,
    ExposureEvolution.KernelPratt.prime_36808483]

def block16 : Witness := ⟨⟨36881329, 36954240, 6079, 6089, 6091, 36880849, 36881051, 36881321⟩, 13⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6079,
    ExposureEvolution.KernelPratt.prime_6089,
    ExposureEvolution.KernelPratt.prime_6091,
    ExposureEvolution.KernelPratt.prime_36880849,
    ExposureEvolution.KernelPratt.prime_36881051,
    ExposureEvolution.KernelPratt.prime_36881321]

def block17 : Witness := ⟨⟨36954241, 37075920, 6089, 6091, 6101, 36954041, 36954223, 36954233⟩, 9⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6089,
    ExposureEvolution.KernelPratt.prime_6091,
    ExposureEvolution.KernelPratt.prime_6101,
    ExposureEvolution.KernelPratt.prime_36954041,
    ExposureEvolution.KernelPratt.prime_36954223,
    ExposureEvolution.KernelPratt.prime_36954233]

def block18 : Witness := ⟨⟨37075921, 37100280, 6091, 6101, 6113, 37075267, 37075303, 37075867⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6091,
    ExposureEvolution.KernelPratt.prime_6101,
    ExposureEvolution.KernelPratt.prime_6113,
    ExposureEvolution.KernelPratt.prime_37075267,
    ExposureEvolution.KernelPratt.prime_37075303,
    ExposureEvolution.KernelPratt.prime_37075867]

def block19 : Witness := ⟨⟨37100281, 37222200, 6101, 6113, 6121, 37100131, 37100177, 37100257⟩, 12⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6101,
    ExposureEvolution.KernelPratt.prime_6113,
    ExposureEvolution.KernelPratt.prime_6121,
    ExposureEvolution.KernelPratt.prime_37100131,
    ExposureEvolution.KernelPratt.prime_37100177,
    ExposureEvolution.KernelPratt.prime_37100257]

def block20 : Witness := ⟨⟨37222201, 37368768, 6113, 6121, 6131, 37221923, 37221949, 37222187⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6113,
    ExposureEvolution.KernelPratt.prime_6121,
    ExposureEvolution.KernelPratt.prime_6131,
    ExposureEvolution.KernelPratt.prime_37221923,
    ExposureEvolution.KernelPratt.prime_37221949,
    ExposureEvolution.KernelPratt.prime_37222187]

def block21 : Witness := ⟨⟨37368769, 37466640, 6121, 6131, 6133, 37368029, 37368731, 37368743⟩, 10⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6121,
    ExposureEvolution.KernelPratt.prime_6131,
    ExposureEvolution.KernelPratt.prime_6133,
    ExposureEvolution.KernelPratt.prime_37368029,
    ExposureEvolution.KernelPratt.prime_37368731,
    ExposureEvolution.KernelPratt.prime_37368743]

def block22 : Witness := ⟨⟨37466641, 37589160, 6131, 6133, 6143, 37466159, 37466411, 37466621⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6131,
    ExposureEvolution.KernelPratt.prime_6133,
    ExposureEvolution.KernelPratt.prime_6143,
    ExposureEvolution.KernelPratt.prime_37466159,
    ExposureEvolution.KernelPratt.prime_37466411,
    ExposureEvolution.KernelPratt.prime_37466621]

def block23 : Witness := ⟨⟨37589161, 37613688, 6133, 6143, 6151, 37588987, 37589099, 37589131⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6133,
    ExposureEvolution.KernelPratt.prime_6143,
    ExposureEvolution.KernelPratt.prime_6151,
    ExposureEvolution.KernelPratt.prime_37588987,
    ExposureEvolution.KernelPratt.prime_37589099,
    ExposureEvolution.KernelPratt.prime_37589131]

def block24 : Witness := ⟨⟨37613689, 37736448, 6143, 6151, 6163, 37613431, 37613473, 37613683⟩, 8⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6143,
    ExposureEvolution.KernelPratt.prime_6151,
    ExposureEvolution.KernelPratt.prime_6163,
    ExposureEvolution.KernelPratt.prime_37613431,
    ExposureEvolution.KernelPratt.prime_37613473,
    ExposureEvolution.KernelPratt.prime_37613683]

def block25 : Witness := ⟨⟨37736449, 37834800, 6151, 6163, 6173, 37736291, 37736339, 37736431⟩, 7⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6151,
    ExposureEvolution.KernelPratt.prime_6163,
    ExposureEvolution.KernelPratt.prime_6173,
    ExposureEvolution.KernelPratt.prime_37736291,
    ExposureEvolution.KernelPratt.prime_37736339,
    ExposureEvolution.KernelPratt.prime_37736431]

def block26 : Witness := ⟨⟨37834801, 37982568, 6163, 6173, 6197, 37834273, 37834721, 37834733⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6163,
    ExposureEvolution.KernelPratt.prime_6173,
    ExposureEvolution.KernelPratt.prime_6197,
    ExposureEvolution.KernelPratt.prime_37834273,
    ExposureEvolution.KernelPratt.prime_37834721,
    ExposureEvolution.KernelPratt.prime_37834733]

def block27 : Witness := ⟨⟨37982569, 38105928, 6173, 6197, 6199, 37982317, 37982381, 37982563⟩, 10⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6173,
    ExposureEvolution.KernelPratt.prime_6197,
    ExposureEvolution.KernelPratt.prime_6199,
    ExposureEvolution.KernelPratt.prime_37982317,
    ExposureEvolution.KernelPratt.prime_37982381,
    ExposureEvolution.KernelPratt.prime_37982563]

def block28 : Witness := ⟨⟨38105929, 38402808, 6197, 6199, 6203, 38105539, 38105593, 38105923⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6197,
    ExposureEvolution.KernelPratt.prime_6199,
    ExposureEvolution.KernelPratt.prime_6203,
    ExposureEvolution.KernelPratt.prime_38105539,
    ExposureEvolution.KernelPratt.prime_38105593,
    ExposureEvolution.KernelPratt.prime_38105923]

def block29 : Witness := ⟨⟨38402809, 38427600, 6199, 6203, 6211, 38402291, 38402681, 38402797⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6199,
    ExposureEvolution.KernelPratt.prime_6203,
    ExposureEvolution.KernelPratt.prime_6211,
    ExposureEvolution.KernelPratt.prime_38402291,
    ExposureEvolution.KernelPratt.prime_38402681,
    ExposureEvolution.KernelPratt.prime_38402797]

def block30 : Witness := ⟨⟨38427601, 38477208, 6203, 6211, 6217, 38427041, 38427047, 38427563⟩, 7⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6203,
    ExposureEvolution.KernelPratt.prime_6211,
    ExposureEvolution.KernelPratt.prime_6217,
    ExposureEvolution.KernelPratt.prime_38427041,
    ExposureEvolution.KernelPratt.prime_38427047,
    ExposureEvolution.KernelPratt.prime_38427563]

def block31 : Witness := ⟨⟨38477209, 38576520, 6211, 6217, 6221, 38476897, 38477083, 38477203⟩, 7⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6211,
    ExposureEvolution.KernelPratt.prime_6217,
    ExposureEvolution.KernelPratt.prime_6221,
    ExposureEvolution.KernelPratt.prime_38476897,
    ExposureEvolution.KernelPratt.prime_38477083,
    ExposureEvolution.KernelPratt.prime_38477203]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 38576521 stop tail = true) :
    coverage 34774609 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks19
