import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks18
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨31956409, 32001648, 5657, 5659, 5669, 31955953, 31956007, 31956391⟩, 7⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5657,
    ExposureEvolution.KernelPratt.prime_5659,
    ExposureEvolution.KernelPratt.prime_5669,
    ExposureEvolution.KernelPratt.prime_31955953,
    ExposureEvolution.KernelPratt.prime_31956007,
    ExposureEvolution.KernelPratt.prime_31956391]

def block01 : Witness := ⟨⟨32001649, 32024280, 5659, 5669, 5683, 32001421, 32001569, 32001631⟩, 9⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5659,
    ExposureEvolution.KernelPratt.prime_5669,
    ExposureEvolution.KernelPratt.prime_5683,
    ExposureEvolution.KernelPratt.prime_32001421,
    ExposureEvolution.KernelPratt.prime_32001569,
    ExposureEvolution.KernelPratt.prime_32001631]

def block02 : Witness := ⟨⟨32024281, 32137560, 5669, 5683, 5689, 32024059, 32024173, 32024269⟩, 6⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5669,
    ExposureEvolution.KernelPratt.prime_5683,
    ExposureEvolution.KernelPratt.prime_5689,
    ExposureEvolution.KernelPratt.prime_32024059,
    ExposureEvolution.KernelPratt.prime_32024173,
    ExposureEvolution.KernelPratt.prime_32024269]

def block03 : Witness := ⟨⟨32137561, 32296488, 5683, 5689, 5693, 32137043, 32137337, 32137549⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5683,
    ExposureEvolution.KernelPratt.prime_5689,
    ExposureEvolution.KernelPratt.prime_5693,
    ExposureEvolution.KernelPratt.prime_32137043,
    ExposureEvolution.KernelPratt.prime_32137337,
    ExposureEvolution.KernelPratt.prime_32137549]

def block04 : Witness := ⟨⟨32296489, 32364720, 5689, 5693, 5701, 32296321, 32296471, 32296487⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5689,
    ExposureEvolution.KernelPratt.prime_5693,
    ExposureEvolution.KernelPratt.prime_5701,
    ExposureEvolution.KernelPratt.prime_32296321,
    ExposureEvolution.KernelPratt.prime_32296471,
    ExposureEvolution.KernelPratt.prime_32296487]

def block05 : Witness := ⟨⟨32364721, 32410248, 5693, 5701, 5711, 32364193, 32364511, 32364707⟩, 10⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5693,
    ExposureEvolution.KernelPratt.prime_5701,
    ExposureEvolution.KernelPratt.prime_5711,
    ExposureEvolution.KernelPratt.prime_32364193,
    ExposureEvolution.KernelPratt.prime_32364511,
    ExposureEvolution.KernelPratt.prime_32364707]

def block06 : Witness := ⟨⟨32410249, 32501400, 5701, 5711, 5717, 32409827, 32409997, 32410247⟩, 10⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5701,
    ExposureEvolution.KernelPratt.prime_5711,
    ExposureEvolution.KernelPratt.prime_5717,
    ExposureEvolution.KernelPratt.prime_32409827,
    ExposureEvolution.KernelPratt.prime_32409997,
    ExposureEvolution.KernelPratt.prime_32410247]

def block07 : Witness := ⟨⟨32501401, 32615520, 5711, 5717, 5737, 32500907, 32501197, 32501377⟩, 8⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5711,
    ExposureEvolution.KernelPratt.prime_5717,
    ExposureEvolution.KernelPratt.prime_5737,
    ExposureEvolution.KernelPratt.prime_32500907,
    ExposureEvolution.KernelPratt.prime_32501197,
    ExposureEvolution.KernelPratt.prime_32501377]

def block08 : Witness := ⟨⟨32615521, 32684088, 5717, 5737, 5741, 32614999, 32615339, 32615519⟩, 10⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5717,
    ExposureEvolution.KernelPratt.prime_5737,
    ExposureEvolution.KernelPratt.prime_5741,
    ExposureEvolution.KernelPratt.prime_32614999,
    ExposureEvolution.KernelPratt.prime_32615339,
    ExposureEvolution.KernelPratt.prime_32615519]

def block09 : Witness := ⟨⟨32684089, 32913168, 5737, 5741, 5743, 32683613, 32684017, 32684083⟩, 7⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5737,
    ExposureEvolution.KernelPratt.prime_5741,
    ExposureEvolution.KernelPratt.prime_5743,
    ExposureEvolution.KernelPratt.prime_32683613,
    ExposureEvolution.KernelPratt.prime_32684017,
    ExposureEvolution.KernelPratt.prime_32684083]

def block10 : Witness := ⟨⟨32913169, 32959080, 5741, 5743, 5749, 32912653, 32912821, 32913151⟩, 9⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5741,
    ExposureEvolution.KernelPratt.prime_5743,
    ExposureEvolution.KernelPratt.prime_5749,
    ExposureEvolution.KernelPratt.prime_32912653,
    ExposureEvolution.KernelPratt.prime_32912821,
    ExposureEvolution.KernelPratt.prime_32913151]

def block11 : Witness := ⟨⟨32959081, 32982048, 5743, 5749, 5779, 32958883, 32958907, 32959063⟩, 9⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5743,
    ExposureEvolution.KernelPratt.prime_5749,
    ExposureEvolution.KernelPratt.prime_5779,
    ExposureEvolution.KernelPratt.prime_32958883,
    ExposureEvolution.KernelPratt.prime_32958907,
    ExposureEvolution.KernelPratt.prime_32959063]

def block12 : Witness := ⟨⟨32982049, 33051000, 5749, 5779, 5783, 32981593, 32981899, 32982017⟩, 12⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5749,
    ExposureEvolution.KernelPratt.prime_5779,
    ExposureEvolution.KernelPratt.prime_5783,
    ExposureEvolution.KernelPratt.prime_32981593,
    ExposureEvolution.KernelPratt.prime_32981899,
    ExposureEvolution.KernelPratt.prime_32982017]

def block13 : Witness := ⟨⟨33051001, 33396840, 5779, 5783, 5791, 33050723, 33050741, 33050999⟩, 14⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5779,
    ExposureEvolution.KernelPratt.prime_5783,
    ExposureEvolution.KernelPratt.prime_5791,
    ExposureEvolution.KernelPratt.prime_33050723,
    ExposureEvolution.KernelPratt.prime_33050741,
    ExposureEvolution.KernelPratt.prime_33050999]

def block14 : Witness := ⟨⟨33396841, 33443088, 5783, 5791, 5801, 33396409, 33396749, 33396833⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5783,
    ExposureEvolution.KernelPratt.prime_5791,
    ExposureEvolution.KernelPratt.prime_5801,
    ExposureEvolution.KernelPratt.prime_33396409,
    ExposureEvolution.KernelPratt.prime_33396749,
    ExposureEvolution.KernelPratt.prime_33396833]

def block15 : Witness := ⟨⟨33443089, 33535680, 5791, 5801, 5807, 33442627, 33442853, 33443083⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5791,
    ExposureEvolution.KernelPratt.prime_5801,
    ExposureEvolution.KernelPratt.prime_5807,
    ExposureEvolution.KernelPratt.prime_33442627,
    ExposureEvolution.KernelPratt.prime_33442853,
    ExposureEvolution.KernelPratt.prime_33443083]

def block16 : Witness := ⟨⟨33535681, 33651600, 5801, 5807, 5813, 33535031, 33535529, 33535651⟩, 9⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5801,
    ExposureEvolution.KernelPratt.prime_5807,
    ExposureEvolution.KernelPratt.prime_5813,
    ExposureEvolution.KernelPratt.prime_33535031,
    ExposureEvolution.KernelPratt.prime_33535529,
    ExposureEvolution.KernelPratt.prime_33535651]

def block17 : Witness := ⟨⟨33651601, 33721248, 5807, 5813, 5821, 33651469, 33651511, 33651589⟩, 7⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5807,
    ExposureEvolution.KernelPratt.prime_5813,
    ExposureEvolution.KernelPratt.prime_5821,
    ExposureEvolution.KernelPratt.prime_33651469,
    ExposureEvolution.KernelPratt.prime_33651511,
    ExposureEvolution.KernelPratt.prime_33651589]

def block18 : Witness := ⟨⟨33721249, 33790968, 5813, 5821, 5827, 33720733, 33721189, 33721223⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5813,
    ExposureEvolution.KernelPratt.prime_5821,
    ExposureEvolution.KernelPratt.prime_5827,
    ExposureEvolution.KernelPratt.prime_33720733,
    ExposureEvolution.KernelPratt.prime_33721189,
    ExposureEvolution.KernelPratt.prime_33721223]

def block19 : Witness := ⟨⟨33790969, 33884040, 5821, 5827, 5839, 33790853, 33790957, 33790963⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5821,
    ExposureEvolution.KernelPratt.prime_5827,
    ExposureEvolution.KernelPratt.prime_5839,
    ExposureEvolution.KernelPratt.prime_33790853,
    ExposureEvolution.KernelPratt.prime_33790957,
    ExposureEvolution.KernelPratt.prime_33790963]

def block20 : Witness := ⟨⟨33884041, 33953928, 5827, 5839, 5843, 33883721, 33883933, 33884033⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5827,
    ExposureEvolution.KernelPratt.prime_5839,
    ExposureEvolution.KernelPratt.prime_5843,
    ExposureEvolution.KernelPratt.prime_33883721,
    ExposureEvolution.KernelPratt.prime_33883933,
    ExposureEvolution.KernelPratt.prime_33884033]

def block21 : Witness := ⟨⟨33953929, 34093920, 5839, 5843, 5849, 33953503, 33953813, 33953921⟩, 8⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5839,
    ExposureEvolution.KernelPratt.prime_5843,
    ExposureEvolution.KernelPratt.prime_5849,
    ExposureEvolution.KernelPratt.prime_33953503,
    ExposureEvolution.KernelPratt.prime_33953813,
    ExposureEvolution.KernelPratt.prime_33953921]

def block22 : Witness := ⟨⟨34093921, 34140648, 5843, 5849, 5851, 34093537, 34093601, 34093907⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5843,
    ExposureEvolution.KernelPratt.prime_5849,
    ExposureEvolution.KernelPratt.prime_5851,
    ExposureEvolution.KernelPratt.prime_34093537,
    ExposureEvolution.KernelPratt.prime_34093601,
    ExposureEvolution.KernelPratt.prime_34093907]

def block23 : Witness := ⟨⟨34140649, 34210800, 5849, 5851, 5857, 34140443, 34140523, 34140643⟩, 9⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5849,
    ExposureEvolution.KernelPratt.prime_5851,
    ExposureEvolution.KernelPratt.prime_5857,
    ExposureEvolution.KernelPratt.prime_34140443,
    ExposureEvolution.KernelPratt.prime_34140523,
    ExposureEvolution.KernelPratt.prime_34140643]

def block24 : Witness := ⟨⟨34210801, 34234200, 5851, 5857, 5861, 34210271, 34210651, 34210753⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5851,
    ExposureEvolution.KernelPratt.prime_5857,
    ExposureEvolution.KernelPratt.prime_5861,
    ExposureEvolution.KernelPratt.prime_34210271,
    ExposureEvolution.KernelPratt.prime_34210651,
    ExposureEvolution.KernelPratt.prime_34210753]

def block25 : Witness := ⟨⟨34234201, 34304448, 5857, 5861, 5867, 34233743, 34233751, 34234177⟩, 8⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5857,
    ExposureEvolution.KernelPratt.prime_5861,
    ExposureEvolution.KernelPratt.prime_5867,
    ExposureEvolution.KernelPratt.prime_34233743,
    ExposureEvolution.KernelPratt.prime_34233751,
    ExposureEvolution.KernelPratt.prime_34234177]

def block26 : Witness := ⟨⟨34304449, 34351320, 5861, 5867, 5869, 34304191, 34304251, 34304447⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5861,
    ExposureEvolution.KernelPratt.prime_5867,
    ExposureEvolution.KernelPratt.prime_5869,
    ExposureEvolution.KernelPratt.prime_34304191,
    ExposureEvolution.KernelPratt.prime_34304251,
    ExposureEvolution.KernelPratt.prime_34304447]

def block27 : Witness := ⟨⟨34351321, 34421688, 5867, 5869, 5879, 34351201, 34351307, 34351309⟩, 11⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5867,
    ExposureEvolution.KernelPratt.prime_5869,
    ExposureEvolution.KernelPratt.prime_5879,
    ExposureEvolution.KernelPratt.prime_34351201,
    ExposureEvolution.KernelPratt.prime_34351307,
    ExposureEvolution.KernelPratt.prime_34351309]

def block28 : Witness := ⟨⟨34421689, 34445160, 5869, 5879, 5881, 34421561, 34421623, 34421671⟩, 8⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5869,
    ExposureEvolution.KernelPratt.prime_5879,
    ExposureEvolution.KernelPratt.prime_5881,
    ExposureEvolution.KernelPratt.prime_34421561,
    ExposureEvolution.KernelPratt.prime_34421623,
    ExposureEvolution.KernelPratt.prime_34421671]

def block29 : Witness := ⟨⟨34445161, 34562640, 5879, 5881, 5897, 34444483, 34444523, 34445129⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5879,
    ExposureEvolution.KernelPratt.prime_5881,
    ExposureEvolution.KernelPratt.prime_5897,
    ExposureEvolution.KernelPratt.prime_34444483,
    ExposureEvolution.KernelPratt.prime_34444523,
    ExposureEvolution.KernelPratt.prime_34445129]

def block30 : Witness := ⟨⟨34562641, 34586160, 5881, 5897, 5903, 34562089, 34562233, 34562623⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5881,
    ExposureEvolution.KernelPratt.prime_5897,
    ExposureEvolution.KernelPratt.prime_5903,
    ExposureEvolution.KernelPratt.prime_34562089,
    ExposureEvolution.KernelPratt.prime_34562233,
    ExposureEvolution.KernelPratt.prime_34562623]

def block31 : Witness := ⟨⟨34586161, 34774608, 5897, 5903, 5923, 34586081, 34586113, 34586131⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5897,
    ExposureEvolution.KernelPratt.prime_5903,
    ExposureEvolution.KernelPratt.prime_5923,
    ExposureEvolution.KernelPratt.prime_34586081,
    ExposureEvolution.KernelPratt.prime_34586113,
    ExposureEvolution.KernelPratt.prime_34586131]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 34774609 stop tail = true) :
    coverage 31956409 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks18
