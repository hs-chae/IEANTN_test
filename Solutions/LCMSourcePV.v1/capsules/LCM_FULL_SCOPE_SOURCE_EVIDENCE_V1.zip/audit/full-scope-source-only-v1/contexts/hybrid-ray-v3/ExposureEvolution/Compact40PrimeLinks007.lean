import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks007
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_17609 : next 17609 = some 17669 := by
  have hl : (List.range ((257 * 17609 - 1) / 256 - 17609)).reverse =
      [67, 66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17669]

theorem next_17669 : next 17669 = some 17737 := by
  have hl : (List.range ((257 * 17669 - 1) / 256 - 17669)).reverse =
      [68, 67] ++ (List.range 67).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17737]

theorem next_17737 : next 17737 = some 17791 := by
  have hl : (List.range ((257 * 17737 - 1) / 256 - 17737)).reverse =
      [68, 67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17791]

theorem next_17791 : next 17791 = some 17851 := by
  have hl : (List.range ((257 * 17791 - 1) / 256 - 17791)).reverse =
      [68, 67, 66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17851]

theorem next_17851 : next 17851 = some 17911 := by
  have hl : (List.range ((257 * 17851 - 1) / 256 - 17851)).reverse =
      [68, 67, 66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17911]

theorem next_17911 : next 17911 = some 17977 := by
  have hl : (List.range ((257 * 17911 - 1) / 256 - 17911)).reverse =
      [68, 67, 66, 65] ++ (List.range 65).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17977]

theorem next_17977 : next 17977 = some 18047 := by
  have hl : (List.range ((257 * 17977 - 1) / 256 - 17977)).reverse =
      [69] ++ (List.range 69).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18047]

theorem next_18047 : next 18047 = some 18097 := by
  have hl : (List.range ((257 * 18047 - 1) / 256 - 18047)).reverse =
      [69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18097]

theorem next_18097 : next 18097 = some 18149 := by
  have hl : (List.range ((257 * 18097 - 1) / 256 - 18097)).reverse =
      [69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18149]

theorem next_18149 : next 18149 = some 18217 := by
  have hl : (List.range ((257 * 18149 - 1) / 256 - 18149)).reverse =
      [69, 68, 67] ++ (List.range 67).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18217]

theorem next_18217 : next 18217 = some 18287 := by
  have hl : (List.range ((257 * 18217 - 1) / 256 - 18217)).reverse =
      [70, 69] ++ (List.range 69).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18287]

theorem next_18287 : next 18287 = some 18353 := by
  have hl : (List.range ((257 * 18287 - 1) / 256 - 18287)).reverse =
      [70, 69, 68, 67, 66, 65] ++ (List.range 65).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18353]

theorem next_18353 : next 18353 = some 18413 := by
  have hl : (List.range ((257 * 18353 - 1) / 256 - 18353)).reverse =
      [70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18413]

theorem next_18413 : next 18413 = some 18481 := by
  have hl : (List.range ((257 * 18413 - 1) / 256 - 18413)).reverse =
      [70, 69, 68, 67] ++ (List.range 67).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18481]

theorem next_18481 : next 18481 = some 18553 := by
  have hl : (List.range ((257 * 18481 - 1) / 256 - 18481)).reverse =
      [71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18553]

theorem next_18553 : next 18553 = some 18617 := by
  have hl : (List.range ((257 * 18553 - 1) / 256 - 18553)).reverse =
      [71, 70, 69, 68, 67, 66, 65, 64, 63] ++ (List.range 63).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18617]

theorem next_18617 : next 18617 = some 18679 := by
  have hl : (List.range ((257 * 18617 - 1) / 256 - 18617)).reverse =
      [71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61] ++ (List.range 61).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18679]

theorem next_18679 : next 18679 = some 18749 := by
  have hl : (List.range ((257 * 18679 - 1) / 256 - 18679)).reverse =
      [71, 70, 69] ++ (List.range 69).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18749]

theorem next_18749 : next 18749 = some 18803 := by
  have hl : (List.range ((257 * 18749 - 1) / 256 - 18749)).reverse =
      [72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18803]

theorem next_18803 : next 18803 = some 18869 := by
  have hl : (List.range ((257 * 18803 - 1) / 256 - 18803)).reverse =
      [72, 71, 70, 69, 68, 67, 66, 65] ++ (List.range 65).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18869]

theorem next_18869 : next 18869 = some 18919 := by
  have hl : (List.range ((257 * 18869 - 1) / 256 - 18869)).reverse =
      [72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18919]

theorem next_18919 : next 18919 = some 18979 := by
  have hl : (List.range ((257 * 18919 - 1) / 256 - 18919)).reverse =
      [72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_18979]

theorem next_18979 : next 18979 = some 19051 := by
  have hl : (List.range ((257 * 18979 - 1) / 256 - 18979)).reverse =
      [73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19051]

theorem next_19051 : next 19051 = some 19121 := by
  have hl : (List.range ((257 * 19051 - 1) / 256 - 19051)).reverse =
      [73, 72, 71, 70, 69] ++ (List.range 69).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19121]

theorem next_19121 : next 19121 = some 19183 := by
  have hl : (List.range ((257 * 19121 - 1) / 256 - 19121)).reverse =
      [73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61] ++ (List.range 61).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19183]

theorem next_19183 : next 19183 = some 19249 := by
  have hl : (List.range ((257 * 19183 - 1) / 256 - 19183)).reverse =
      [73, 72, 71, 70, 69, 68, 67, 66, 65] ++ (List.range 65).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19249]

theorem next_19249 : next 19249 = some 19319 := by
  have hl : (List.range ((257 * 19249 - 1) / 256 - 19249)).reverse =
      [74, 73, 72, 71, 70, 69] ++ (List.range 69).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19319]

theorem next_19319 : next 19319 = some 19391 := by
  have hl : (List.range ((257 * 19319 - 1) / 256 - 19319)).reverse =
      [74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19391]

theorem next_19391 : next 19391 = some 19463 := by
  have hl : (List.range ((257 * 19391 - 1) / 256 - 19391)).reverse =
      [74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19463]

theorem next_19463 : next 19463 = some 19531 := by
  have hl : (List.range ((257 * 19463 - 1) / 256 - 19463)).reverse =
      [75, 74, 73, 72, 71, 70, 69, 68, 67] ++ (List.range 67).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19531]

theorem next_19531 : next 19531 = some 19603 := by
  have hl : (List.range ((257 * 19531 - 1) / 256 - 19531)).reverse =
      [75, 74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19603]

theorem next_19603 : next 19603 = some 19661 := by
  have hl : (List.range ((257 * 19603 - 1) / 256 - 19603)).reverse =
      [75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57] ++ (List.range 57).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19661]

def primes : List ℕ := [17669, 17737, 17791, 17851, 17911, 17977, 18047, 18097, 18149, 18217, 18287, 18353, 18413, 18481, 18553, 18617, 18679, 18749, 18803, 18869, 18919, 18979, 19051, 19121, 19183, 19249, 19319, 19391, 19463, 19531, 19603, 19661]

theorem segment : run 476 17609 89693 =
    primes ++ run 444 19661 89693 := by
  rw [Compact40PrimeCompose256.step 475 17609 89693 17669
    (by decide +kernel) next_17609]
  rw [Compact40PrimeCompose256.step 474 17669 89693 17737
    (by decide +kernel) next_17669]
  rw [Compact40PrimeCompose256.step 473 17737 89693 17791
    (by decide +kernel) next_17737]
  rw [Compact40PrimeCompose256.step 472 17791 89693 17851
    (by decide +kernel) next_17791]
  rw [Compact40PrimeCompose256.step 471 17851 89693 17911
    (by decide +kernel) next_17851]
  rw [Compact40PrimeCompose256.step 470 17911 89693 17977
    (by decide +kernel) next_17911]
  rw [Compact40PrimeCompose256.step 469 17977 89693 18047
    (by decide +kernel) next_17977]
  rw [Compact40PrimeCompose256.step 468 18047 89693 18097
    (by decide +kernel) next_18047]
  rw [Compact40PrimeCompose256.step 467 18097 89693 18149
    (by decide +kernel) next_18097]
  rw [Compact40PrimeCompose256.step 466 18149 89693 18217
    (by decide +kernel) next_18149]
  rw [Compact40PrimeCompose256.step 465 18217 89693 18287
    (by decide +kernel) next_18217]
  rw [Compact40PrimeCompose256.step 464 18287 89693 18353
    (by decide +kernel) next_18287]
  rw [Compact40PrimeCompose256.step 463 18353 89693 18413
    (by decide +kernel) next_18353]
  rw [Compact40PrimeCompose256.step 462 18413 89693 18481
    (by decide +kernel) next_18413]
  rw [Compact40PrimeCompose256.step 461 18481 89693 18553
    (by decide +kernel) next_18481]
  rw [Compact40PrimeCompose256.step 460 18553 89693 18617
    (by decide +kernel) next_18553]
  rw [Compact40PrimeCompose256.step 459 18617 89693 18679
    (by decide +kernel) next_18617]
  rw [Compact40PrimeCompose256.step 458 18679 89693 18749
    (by decide +kernel) next_18679]
  rw [Compact40PrimeCompose256.step 457 18749 89693 18803
    (by decide +kernel) next_18749]
  rw [Compact40PrimeCompose256.step 456 18803 89693 18869
    (by decide +kernel) next_18803]
  rw [Compact40PrimeCompose256.step 455 18869 89693 18919
    (by decide +kernel) next_18869]
  rw [Compact40PrimeCompose256.step 454 18919 89693 18979
    (by decide +kernel) next_18919]
  rw [Compact40PrimeCompose256.step 453 18979 89693 19051
    (by decide +kernel) next_18979]
  rw [Compact40PrimeCompose256.step 452 19051 89693 19121
    (by decide +kernel) next_19051]
  rw [Compact40PrimeCompose256.step 451 19121 89693 19183
    (by decide +kernel) next_19121]
  rw [Compact40PrimeCompose256.step 450 19183 89693 19249
    (by decide +kernel) next_19183]
  rw [Compact40PrimeCompose256.step 449 19249 89693 19319
    (by decide +kernel) next_19249]
  rw [Compact40PrimeCompose256.step 448 19319 89693 19391
    (by decide +kernel) next_19319]
  rw [Compact40PrimeCompose256.step 447 19391 89693 19463
    (by decide +kernel) next_19391]
  rw [Compact40PrimeCompose256.step 446 19463 89693 19531
    (by decide +kernel) next_19463]
  rw [Compact40PrimeCompose256.step 445 19531 89693 19603
    (by decide +kernel) next_19531]
  rw [Compact40PrimeCompose256.step 444 19603 89693 19661
    (by decide +kernel) next_19603]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 19661 stop tail = true) :
    check 17609 stop (primes ++ tail) = true := by
  change check _ _ (17669 :: 17737 :: 17791 :: 17851 :: 17911 :: 17977 :: 18047 :: 18097 :: 18149 :: 18217 :: 18287 :: 18353 :: 18413 :: 18481 :: 18553 :: 18617 :: 18679 :: 18749 :: 18803 :: 18869 :: 18919 :: 18979 :: 19051 :: 19121 :: 19183 :: 19249 :: 19319 :: 19391 :: 19463 :: 19531 :: 19603 :: 19661 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17669, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17737, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17791, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17851, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17911, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17977, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18047, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18097, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18149, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18217, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18287, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18353, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18413, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18481, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18553, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18617, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18679, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18749, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18803, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18869, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18919, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_18979, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19051, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19121, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19183, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19249, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19319, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19391, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19463, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19531, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19603, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19661, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks007
