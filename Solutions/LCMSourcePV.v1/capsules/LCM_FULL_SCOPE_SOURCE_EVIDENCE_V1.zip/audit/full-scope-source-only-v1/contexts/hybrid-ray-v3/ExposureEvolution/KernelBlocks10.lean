import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks10
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨12187081, 12243000, 3499, 3511, 3517, 12186679, 12187051, 12187073⟩, 10⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3499,
    ExposureEvolution.KernelPratt.prime_3511,
    ExposureEvolution.KernelPratt.prime_3517,
    ExposureEvolution.KernelPratt.prime_12186679,
    ExposureEvolution.KernelPratt.prime_12187051,
    ExposureEvolution.KernelPratt.prime_12187073]

def block01 : Witness := ⟨⟨12243001, 12327120, 3511, 3517, 3527, 12242501, 12242773, 12242987⟩, 11⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3511,
    ExposureEvolution.KernelPratt.prime_3517,
    ExposureEvolution.KernelPratt.prime_3527,
    ExposureEvolution.KernelPratt.prime_12242501,
    ExposureEvolution.KernelPratt.prime_12242773,
    ExposureEvolution.KernelPratt.prime_12242987]

def block02 : Witness := ⟨⟨12327121, 12369288, 3517, 3527, 3529, 12326599, 12326927, 12327109⟩, 11⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3517,
    ExposureEvolution.KernelPratt.prime_3527,
    ExposureEvolution.KernelPratt.prime_3529,
    ExposureEvolution.KernelPratt.prime_12326599,
    ExposureEvolution.KernelPratt.prime_12326927,
    ExposureEvolution.KernelPratt.prime_12327109]

def block03 : Witness := ⟨⟨12369289, 12439728, 3527, 3529, 3533, 12368903, 12369197, 12369281⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3527,
    ExposureEvolution.KernelPratt.prime_3529,
    ExposureEvolution.KernelPratt.prime_3533,
    ExposureEvolution.KernelPratt.prime_12368903,
    ExposureEvolution.KernelPratt.prime_12369197,
    ExposureEvolution.KernelPratt.prime_12369281]

def block04 : Witness := ⟨⟨12439729, 12453840, 3529, 3533, 3539, 12439199, 12439253, 12439727⟩, 11⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3529,
    ExposureEvolution.KernelPratt.prime_3533,
    ExposureEvolution.KernelPratt.prime_3539,
    ExposureEvolution.KernelPratt.prime_12439199,
    ExposureEvolution.KernelPratt.prime_12439253,
    ExposureEvolution.KernelPratt.prime_12439727]

def block05 : Witness := ⟨⟨12453841, 12482088, 3533, 3539, 3541, 12453583, 12453757, 12453829⟩, 11⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3533,
    ExposureEvolution.KernelPratt.prime_3539,
    ExposureEvolution.KernelPratt.prime_3541,
    ExposureEvolution.KernelPratt.prime_12453583,
    ExposureEvolution.KernelPratt.prime_12453757,
    ExposureEvolution.KernelPratt.prime_12453829]

def block06 : Witness := ⟨⟨12482089, 12524520, 3539, 3541, 3547, 12481559, 12481951, 12482059⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3539,
    ExposureEvolution.KernelPratt.prime_3541,
    ExposureEvolution.KernelPratt.prime_3547,
    ExposureEvolution.KernelPratt.prime_12481559,
    ExposureEvolution.KernelPratt.prime_12481951,
    ExposureEvolution.KernelPratt.prime_12482059]

def block07 : Witness := ⟨⟨12524521, 12538680, 3541, 3547, 3557, 12524063, 12524111, 12524509⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3541,
    ExposureEvolution.KernelPratt.prime_3547,
    ExposureEvolution.KernelPratt.prime_3557,
    ExposureEvolution.KernelPratt.prime_12524063,
    ExposureEvolution.KernelPratt.prime_12524111,
    ExposureEvolution.KernelPratt.prime_12524509]

def block08 : Witness := ⟨⟨12538681, 12581208, 3547, 3557, 3559, 12538321, 12538517, 12538679⟩, 13⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3547,
    ExposureEvolution.KernelPratt.prime_3557,
    ExposureEvolution.KernelPratt.prime_3559,
    ExposureEvolution.KernelPratt.prime_12538321,
    ExposureEvolution.KernelPratt.prime_12538517,
    ExposureEvolution.KernelPratt.prime_12538679]

def block09 : Witness := ⟨⟨12581209, 12652248, 3557, 3559, 3571, 12580877, 12580949, 12581183⟩, 9⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3557,
    ExposureEvolution.KernelPratt.prime_3559,
    ExposureEvolution.KernelPratt.prime_3571,
    ExposureEvolution.KernelPratt.prime_12580877,
    ExposureEvolution.KernelPratt.prime_12580949,
    ExposureEvolution.KernelPratt.prime_12581183]

def block10 : Witness := ⟨⟨12652249, 12666480, 3559, 3571, 3581, 12652027, 12652103, 12652229⟩, 9⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3559,
    ExposureEvolution.KernelPratt.prime_3571,
    ExposureEvolution.KernelPratt.prime_3581,
    ExposureEvolution.KernelPratt.prime_12652027,
    ExposureEvolution.KernelPratt.prime_12652103,
    ExposureEvolution.KernelPratt.prime_12652229]

def block11 : Witness := ⟨⟨12666481, 12752040, 3571, 3581, 3583, 12665869, 12666421, 12666461⟩, 12⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3571,
    ExposureEvolution.KernelPratt.prime_3581,
    ExposureEvolution.KernelPratt.prime_3583,
    ExposureEvolution.KernelPratt.prime_12665869,
    ExposureEvolution.KernelPratt.prime_12666421,
    ExposureEvolution.KernelPratt.prime_12666461]

def block12 : Witness := ⟨⟨12752041, 12823560, 3581, 3583, 3593, 12751927, 12751969, 12752029⟩, 7⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3581,
    ExposureEvolution.KernelPratt.prime_3583,
    ExposureEvolution.KernelPratt.prime_3593,
    ExposureEvolution.KernelPratt.prime_12751927,
    ExposureEvolution.KernelPratt.prime_12751969,
    ExposureEvolution.KernelPratt.prime_12752029]

def block13 : Witness := ⟨⟨12823561, 12837888, 3583, 3593, 3607, 12823189, 12823333, 12823541⟩, 5⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3583,
    ExposureEvolution.KernelPratt.prime_3593,
    ExposureEvolution.KernelPratt.prime_3607,
    ExposureEvolution.KernelPratt.prime_12823189,
    ExposureEvolution.KernelPratt.prime_12823333,
    ExposureEvolution.KernelPratt.prime_12823541]

def block14 : Witness := ⟨⟨12837889, 12909648, 3593, 3607, 3613, 12837661, 12837743, 12837883⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3593,
    ExposureEvolution.KernelPratt.prime_3607,
    ExposureEvolution.KernelPratt.prime_3613,
    ExposureEvolution.KernelPratt.prime_12837661,
    ExposureEvolution.KernelPratt.prime_12837743,
    ExposureEvolution.KernelPratt.prime_12837883]

def block15 : Witness := ⟨⟨12909649, 13010448, 3607, 3613, 3617, 12909277, 12909397, 12909643⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3607,
    ExposureEvolution.KernelPratt.prime_3613,
    ExposureEvolution.KernelPratt.prime_3617,
    ExposureEvolution.KernelPratt.prime_12909277,
    ExposureEvolution.KernelPratt.prime_12909397,
    ExposureEvolution.KernelPratt.prime_12909643]

def block16 : Witness := ⟨⟨13010449, 13053768, 3613, 3617, 3623, 13009901, 13010147, 13010447⟩, 13⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3613,
    ExposureEvolution.KernelPratt.prime_3617,
    ExposureEvolution.KernelPratt.prime_3623,
    ExposureEvolution.KernelPratt.prime_13009901,
    ExposureEvolution.KernelPratt.prime_13010147,
    ExposureEvolution.KernelPratt.prime_13010447]

def block17 : Witness := ⟨⟨13053769, 13082688, 3617, 3623, 3631, 13053253, 13053371, 13053749⟩, 9⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3617,
    ExposureEvolution.KernelPratt.prime_3623,
    ExposureEvolution.KernelPratt.prime_3631,
    ExposureEvolution.KernelPratt.prime_13053253,
    ExposureEvolution.KernelPratt.prime_13053371,
    ExposureEvolution.KernelPratt.prime_13053749]

def block18 : Witness := ⟨⟨13082689, 13126128, 3623, 3631, 3637, 13082297, 13082603, 13082687⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3623,
    ExposureEvolution.KernelPratt.prime_3631,
    ExposureEvolution.KernelPratt.prime_3637,
    ExposureEvolution.KernelPratt.prime_13082297,
    ExposureEvolution.KernelPratt.prime_13082603,
    ExposureEvolution.KernelPratt.prime_13082687]

def block19 : Witness := ⟨⟨13126129, 13184160, 3631, 3637, 3643, 13125611, 13125947, 13126121⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3631,
    ExposureEvolution.KernelPratt.prime_3637,
    ExposureEvolution.KernelPratt.prime_3643,
    ExposureEvolution.KernelPratt.prime_13125611,
    ExposureEvolution.KernelPratt.prime_13125947,
    ExposureEvolution.KernelPratt.prime_13126121]

def block20 : Witness := ⟨⟨13184161, 13227768, 3637, 3643, 3659, 13183883, 13184141, 13184153⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3637,
    ExposureEvolution.KernelPratt.prime_3643,
    ExposureEvolution.KernelPratt.prime_3659,
    ExposureEvolution.KernelPratt.prime_13183883,
    ExposureEvolution.KernelPratt.prime_13184141,
    ExposureEvolution.KernelPratt.prime_13184153]

def block21 : Witness := ⟨⟨13227769, 13271448, 3643, 3659, 3671, 13227419, 13227497, 13227757⟩, 15⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3643,
    ExposureEvolution.KernelPratt.prime_3659,
    ExposureEvolution.KernelPratt.prime_3671,
    ExposureEvolution.KernelPratt.prime_13227419,
    ExposureEvolution.KernelPratt.prime_13227497,
    ExposureEvolution.KernelPratt.prime_13227757]

def block22 : Witness := ⟨⟨13271449, 13388280, 3659, 3671, 3673, 13271287, 13271389, 13271429⟩, 6⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3659,
    ExposureEvolution.KernelPratt.prime_3671,
    ExposureEvolution.KernelPratt.prime_3673,
    ExposureEvolution.KernelPratt.prime_13271287,
    ExposureEvolution.KernelPratt.prime_13271389,
    ExposureEvolution.KernelPratt.prime_13271429]

def block23 : Witness := ⟨⟨13388281, 13476240, 3671, 3673, 3677, 13387841, 13387859, 13388269⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3671,
    ExposureEvolution.KernelPratt.prime_3673,
    ExposureEvolution.KernelPratt.prime_3677,
    ExposureEvolution.KernelPratt.prime_13387841,
    ExposureEvolution.KernelPratt.prime_13387859,
    ExposureEvolution.KernelPratt.prime_13388269]

def block24 : Witness := ⟨⟨13476241, 13490928, 3673, 3677, 3691, 13475827, 13476193, 13476233⟩, 6⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3673,
    ExposureEvolution.KernelPratt.prime_3677,
    ExposureEvolution.KernelPratt.prime_3691,
    ExposureEvolution.KernelPratt.prime_13475827,
    ExposureEvolution.KernelPratt.prime_13476193,
    ExposureEvolution.KernelPratt.prime_13476233]

def block25 : Witness := ⟨⟨13490929, 13520328, 3677, 3691, 3697, 13490341, 13490803, 13490879⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3677,
    ExposureEvolution.KernelPratt.prime_3691,
    ExposureEvolution.KernelPratt.prime_3697,
    ExposureEvolution.KernelPratt.prime_13490341,
    ExposureEvolution.KernelPratt.prime_13490803,
    ExposureEvolution.KernelPratt.prime_13490879]

def block26 : Witness := ⟨⟨13520329, 13623480, 3691, 3697, 3701, 13520011, 13520047, 13520303⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3691,
    ExposureEvolution.KernelPratt.prime_3697,
    ExposureEvolution.KernelPratt.prime_3701,
    ExposureEvolution.KernelPratt.prime_13520011,
    ExposureEvolution.KernelPratt.prime_13520047,
    ExposureEvolution.KernelPratt.prime_13520303]

def block27 : Witness := ⟨⟨13623481, 13667808, 3697, 3701, 3709, 13623283, 13623413, 13623469⟩, 10⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3697,
    ExposureEvolution.KernelPratt.prime_3701,
    ExposureEvolution.KernelPratt.prime_3709,
    ExposureEvolution.KernelPratt.prime_13623283,
    ExposureEvolution.KernelPratt.prime_13623413,
    ExposureEvolution.KernelPratt.prime_13623469]

def block28 : Witness := ⟨⟨13667809, 13697400, 3701, 3709, 3719, 13667597, 13667603, 13667803⟩, 8⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3701,
    ExposureEvolution.KernelPratt.prime_3709,
    ExposureEvolution.KernelPratt.prime_3719,
    ExposureEvolution.KernelPratt.prime_13667597,
    ExposureEvolution.KernelPratt.prime_13667603,
    ExposureEvolution.KernelPratt.prime_13667803]

def block29 : Witness := ⟨⟨13697401, 13756680, 3709, 3719, 3727, 13697221, 13697357, 13697399⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3709,
    ExposureEvolution.KernelPratt.prime_3719,
    ExposureEvolution.KernelPratt.prime_3727,
    ExposureEvolution.KernelPratt.prime_13697221,
    ExposureEvolution.KernelPratt.prime_13697357,
    ExposureEvolution.KernelPratt.prime_13697399]

def block30 : Witness := ⟨⟨13756681, 13830960, 3719, 3727, 3733, 13756397, 13756453, 13756679⟩, 9⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3719,
    ExposureEvolution.KernelPratt.prime_3727,
    ExposureEvolution.KernelPratt.prime_3733,
    ExposureEvolution.KernelPratt.prime_13756397,
    ExposureEvolution.KernelPratt.prime_13756453,
    ExposureEvolution.KernelPratt.prime_13756679]

def block31 : Witness := ⟨⟨13830961, 13890528, 3727, 3733, 3739, 13830533, 13830679, 13830953⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_3727,
    ExposureEvolution.KernelPratt.prime_3733,
    ExposureEvolution.KernelPratt.prime_3739,
    ExposureEvolution.KernelPratt.prime_13830533,
    ExposureEvolution.KernelPratt.prime_13830679,
    ExposureEvolution.KernelPratt.prime_13830953]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 13890529 stop tail = true) :
    coverage 12187081 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks10
