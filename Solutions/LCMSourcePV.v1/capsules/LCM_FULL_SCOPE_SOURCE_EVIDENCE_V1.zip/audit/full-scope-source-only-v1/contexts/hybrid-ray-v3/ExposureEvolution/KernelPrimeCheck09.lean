import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelPrimeCheck09
open ExposureEvolution KernelPrimeProgram
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def primes : List ℕ := [63421, 63667, 63913, 64157, 64403, 64633, 64879, 65129, 65381, 65633, 65881, 66137, 66383, 66629, 66889, 67141, 67399, 67651, 67901, 68161, 68399, 68659, 68927, 69193, 69463, 69709, 69959, 70229, 70501, 70769, 71039, 71293, 71569, 71843, 72109, 72383, 72661, 72937, 73189, 73471, 73757, 74027, 74311, 74597, 74887, 75169, 75437, 75731, 76003, 76289, 76579, 76873, 77171, 77471, 77773, 78059, 78347, 78653, 78941, 79241, 79549, 79847, 80153, 80449]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 80449 stop tail = true) :
    check 63179 stop (primes ++ tail) = true := by
  change check _ _ (63421 :: 63667 :: 63913 :: 64157 :: 64403 :: 64633 :: 64879 :: 65129 :: 65381 :: 65633 :: 65881 :: 66137 :: 66383 :: 66629 :: 66889 :: 67141 :: 67399 :: 67651 :: 67901 :: 68161 :: 68399 :: 68659 :: 68927 :: 69193 :: 69463 :: 69709 :: 69959 :: 70229 :: 70501 :: 70769 :: 71039 :: 71293 :: 71569 :: 71843 :: 72109 :: 72383 :: 72661 :: 72937 :: 73189 :: 73471 :: 73757 :: 74027 :: 74311 :: 74597 :: 74887 :: 75169 :: 75437 :: 75731 :: 76003 :: 76289 :: 76579 :: 76873 :: 77171 :: 77471 :: 77773 :: 78059 :: 78347 :: 78653 :: 78941 :: 79241 :: 79549 :: 79847 :: 80153 :: 80449 :: tail) = true
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_63421, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_63667, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_63913, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_64157, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_64403, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_64633, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_64879, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_65129, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_65381, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_65633, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_65881, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_66137, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_66383, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_66629, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_66889, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_67141, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_67399, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_67651, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_67901, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_68161, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_68399, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_68659, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_68927, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_69193, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_69463, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_69709, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_69959, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_70229, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_70501, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_70769, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_71039, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_71293, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_71569, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_71843, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_72109, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_72383, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_72661, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_72937, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_73189, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_73471, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_73757, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_74027, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_74311, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_74597, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_74887, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_75169, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_75437, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_75731, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_76003, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_76289, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_76579, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_76873, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_77171, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_77471, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_77773, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_78059, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_78347, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_78653, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_78941, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_79241, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_79549, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_79847, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_80153, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_80449, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms extend
end ExposureEvolution.KernelPrimeCheck09
