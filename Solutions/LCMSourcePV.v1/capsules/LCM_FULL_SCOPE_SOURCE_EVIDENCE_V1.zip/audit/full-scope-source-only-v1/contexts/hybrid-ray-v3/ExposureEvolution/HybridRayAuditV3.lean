import ExposureEvolution.HybridRayV3
import Lean.Util.CollectAxioms
namespace ExposureEvolution.HybridRayAuditV3
open Lean Elab Command
run_elab do
 let env ← getEnv
 let root := ``ExposureEvolution.HybridRayV3.whole_ray
 let some ci := env.find? root | throwError "missing hybridroot"
 let expected ← Term.elabType (← `(Dusart2018.v1.proposition_5_4 → ∀ n : ℕ,1000000 ≤ n →
   ∃ m : ℕ,0 < m ∧ m < Nat.lcmUpto n ∧
    (1+(if 5000000 ≤ n then if 1000000000000 ≤ n then (4/5:ℝ) else 3/5 else 3/10)/(n:ℝ))*
       (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) < ArithmeticFunction.sigma 1 m))
 unless ← Meta.isDefEq ci.type expected do throwError "literal piecewisefullray type mismatch"
 let ax ← Lean.collectAxioms root
 unless ax.toList.all [``propext,``Classical.choice,``Quot.sound].contains do
   throwError "nonstandard axiom"
 logInfo m!"HYBRID_FULL_RAY_AUDIT_JSON {(Json.mkObj [
   ("status",toJson "THREE_POINT3_POINT6_NEW_POINT8_BRANCHES_FULL_RAY_ONE_MILLION_TO_INFINITY_STANDARD_KERNEL_PASS"),
   ("root",toJson root.toString),("type",toJson (toString (← Meta.ppExpr ci.type))),
   ("axioms",toJson (ax.toList.map Name.toString))]).compress}"
end ExposureEvolution.HybridRayAuditV3
