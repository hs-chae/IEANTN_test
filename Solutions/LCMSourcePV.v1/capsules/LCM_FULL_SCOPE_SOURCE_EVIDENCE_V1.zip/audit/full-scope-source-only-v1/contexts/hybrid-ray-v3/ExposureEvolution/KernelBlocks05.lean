import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks05
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨4853209, 4870848, 2207, 2213, 2221, 4852699, 4852873, 4853203⟩, 6⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2207,
    ExposureEvolution.KernelPratt.prime_2213,
    ExposureEvolution.KernelPratt.prime_2221,
    ExposureEvolution.KernelPratt.prime_4852699,
    ExposureEvolution.KernelPratt.prime_4852873,
    ExposureEvolution.KernelPratt.prime_4853203]

def block01 : Witness := ⟨⟨4870849, 4897368, 2213, 2221, 2237, 4870693, 4870777, 4870843⟩, 8⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2213,
    ExposureEvolution.KernelPratt.prime_2221,
    ExposureEvolution.KernelPratt.prime_2237,
    ExposureEvolution.KernelPratt.prime_4870693,
    ExposureEvolution.KernelPratt.prime_4870777,
    ExposureEvolution.KernelPratt.prime_4870843]

def block02 : Witness := ⟨⟨4897369, 4932840, 2221, 2237, 2239, 4897007, 4897267, 4897363⟩, 14⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2221,
    ExposureEvolution.KernelPratt.prime_2237,
    ExposureEvolution.KernelPratt.prime_2239,
    ExposureEvolution.KernelPratt.prime_4897007,
    ExposureEvolution.KernelPratt.prime_4897267,
    ExposureEvolution.KernelPratt.prime_4897363]

def block03 : Witness := ⟨⟨4932841, 5004168, 2237, 2239, 2243, 4932619, 4932757, 4932827⟩, 11⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2237,
    ExposureEvolution.KernelPratt.prime_2239,
    ExposureEvolution.KernelPratt.prime_2243,
    ExposureEvolution.KernelPratt.prime_4932619,
    ExposureEvolution.KernelPratt.prime_4932757,
    ExposureEvolution.KernelPratt.prime_4932827]

def block04 : Witness := ⟨⟨5004169, 5013120, 2239, 2243, 2251, 5003983, 5004031, 5004157⟩, 9⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2239,
    ExposureEvolution.KernelPratt.prime_2243,
    ExposureEvolution.KernelPratt.prime_2251,
    ExposureEvolution.KernelPratt.prime_5003983,
    ExposureEvolution.KernelPratt.prime_5004031,
    ExposureEvolution.KernelPratt.prime_5004157]

def block05 : Witness := ⟨⟨5013121, 5031048, 2243, 2251, 2267, 5012831, 5012981, 5013119⟩, 12⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2243,
    ExposureEvolution.KernelPratt.prime_2251,
    ExposureEvolution.KernelPratt.prime_2267,
    ExposureEvolution.KernelPratt.prime_5012831,
    ExposureEvolution.KernelPratt.prime_5012981,
    ExposureEvolution.KernelPratt.prime_5013119]

def block06 : Witness := ⟨⟨5031049, 5067000, 2251, 2267, 2269, 5030797, 5030807, 5031041⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2251,
    ExposureEvolution.KernelPratt.prime_2267,
    ExposureEvolution.KernelPratt.prime_2269,
    ExposureEvolution.KernelPratt.prime_5030797,
    ExposureEvolution.KernelPratt.prime_5030807,
    ExposureEvolution.KernelPratt.prime_5031041]

def block07 : Witness := ⟨⟨5067001, 5139288, 2267, 2269, 2273, 5066491, 5066837, 5066993⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2267,
    ExposureEvolution.KernelPratt.prime_2269,
    ExposureEvolution.KernelPratt.prime_2273,
    ExposureEvolution.KernelPratt.prime_5066491,
    ExposureEvolution.KernelPratt.prime_5066837,
    ExposureEvolution.KernelPratt.prime_5066993]

def block08 : Witness := ⟨⟨5139289, 5148360, 2269, 2273, 2281, 5139161, 5139203, 5139271⟩, 10⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2269,
    ExposureEvolution.KernelPratt.prime_2273,
    ExposureEvolution.KernelPratt.prime_2281,
    ExposureEvolution.KernelPratt.prime_5139161,
    ExposureEvolution.KernelPratt.prime_5139203,
    ExposureEvolution.KernelPratt.prime_5139271]

def block09 : Witness := ⟨⟨5148361, 5166528, 2273, 2281, 2287, 5147951, 5148287, 5148359⟩, 7⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2273,
    ExposureEvolution.KernelPratt.prime_2281,
    ExposureEvolution.KernelPratt.prime_2287,
    ExposureEvolution.KernelPratt.prime_5147951,
    ExposureEvolution.KernelPratt.prime_5148287,
    ExposureEvolution.KernelPratt.prime_5148359]

def block10 : Witness := ⟨⟨5166529, 5202960, 2281, 2287, 2293, 5166071, 5166383, 5166527⟩, 9⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2281,
    ExposureEvolution.KernelPratt.prime_2287,
    ExposureEvolution.KernelPratt.prime_2293,
    ExposureEvolution.KernelPratt.prime_5166071,
    ExposureEvolution.KernelPratt.prime_5166383,
    ExposureEvolution.KernelPratt.prime_5166527]

def block11 : Witness := ⟨⟨5202961, 5230368, 2287, 2293, 2297, 5202503, 5202569, 5202917⟩, 11⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2287,
    ExposureEvolution.KernelPratt.prime_2293,
    ExposureEvolution.KernelPratt.prime_2297,
    ExposureEvolution.KernelPratt.prime_5202503,
    ExposureEvolution.KernelPratt.prime_5202569,
    ExposureEvolution.KernelPratt.prime_5202917]

def block12 : Witness := ⟨⟨5230369, 5257848, 2293, 2297, 2309, 5229871, 5229989, 5230367⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2293,
    ExposureEvolution.KernelPratt.prime_2297,
    ExposureEvolution.KernelPratt.prime_2309,
    ExposureEvolution.KernelPratt.prime_5229871,
    ExposureEvolution.KernelPratt.prime_5229989,
    ExposureEvolution.KernelPratt.prime_5230367]

def block13 : Witness := ⟨⟨5257849, 5276208, 2297, 2309, 2311, 5257531, 5257723, 5257829⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2297,
    ExposureEvolution.KernelPratt.prime_2309,
    ExposureEvolution.KernelPratt.prime_2311,
    ExposureEvolution.KernelPratt.prime_5257531,
    ExposureEvolution.KernelPratt.prime_5257723,
    ExposureEvolution.KernelPratt.prime_5257829]

def block14 : Witness := ⟨⟨5276209, 5331480, 2309, 2311, 2333, 5275813, 5276093, 5276207⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2309,
    ExposureEvolution.KernelPratt.prime_2311,
    ExposureEvolution.KernelPratt.prime_2333,
    ExposureEvolution.KernelPratt.prime_5275813,
    ExposureEvolution.KernelPratt.prime_5276093,
    ExposureEvolution.KernelPratt.prime_5276207]

def block15 : Witness := ⟨⟨5331481, 5340720, 2311, 2333, 2339, 5331199, 5331379, 5331479⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2311,
    ExposureEvolution.KernelPratt.prime_2333,
    ExposureEvolution.KernelPratt.prime_2339,
    ExposureEvolution.KernelPratt.prime_5331199,
    ExposureEvolution.KernelPratt.prime_5331379,
    ExposureEvolution.KernelPratt.prime_5331479]

def block16 : Witness := ⟨⟨5340721, 5442888, 2333, 2339, 2341, 5340343, 5340421, 5340707⟩, 7⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2333,
    ExposureEvolution.KernelPratt.prime_2339,
    ExposureEvolution.KernelPratt.prime_2341,
    ExposureEvolution.KernelPratt.prime_5340343,
    ExposureEvolution.KernelPratt.prime_5340421,
    ExposureEvolution.KernelPratt.prime_5340707]

def block17 : Witness := ⟨⟨5442889, 5470920, 2339, 2341, 2347, 5442581, 5442637, 5442859⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2339,
    ExposureEvolution.KernelPratt.prime_2341,
    ExposureEvolution.KernelPratt.prime_2347,
    ExposureEvolution.KernelPratt.prime_5442581,
    ExposureEvolution.KernelPratt.prime_5442637,
    ExposureEvolution.KernelPratt.prime_5442859]

def block18 : Witness := ⟨⟨5470921, 5480280, 2341, 2347, 2351, 5470627, 5470681, 5470909⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2341,
    ExposureEvolution.KernelPratt.prime_2347,
    ExposureEvolution.KernelPratt.prime_2351,
    ExposureEvolution.KernelPratt.prime_5470627,
    ExposureEvolution.KernelPratt.prime_5470681,
    ExposureEvolution.KernelPratt.prime_5470909]

def block19 : Witness := ⟨⟨5480281, 5508408, 2347, 2351, 2357, 5479841, 5480063, 5480269⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2347,
    ExposureEvolution.KernelPratt.prime_2351,
    ExposureEvolution.KernelPratt.prime_2357,
    ExposureEvolution.KernelPratt.prime_5479841,
    ExposureEvolution.KernelPratt.prime_5480063,
    ExposureEvolution.KernelPratt.prime_5480269]

def block20 : Witness := ⟨⟨5508409, 5527200, 2351, 2357, 2371, 5508023, 5508179, 5508401⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2351,
    ExposureEvolution.KernelPratt.prime_2357,
    ExposureEvolution.KernelPratt.prime_2371,
    ExposureEvolution.KernelPratt.prime_5508023,
    ExposureEvolution.KernelPratt.prime_5508179,
    ExposureEvolution.KernelPratt.prime_5508401]

def block21 : Witness := ⟨⟨5527201, 5555448, 2357, 2371, 2377, 5526743, 5527013, 5527189⟩, 9⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2357,
    ExposureEvolution.KernelPratt.prime_2371,
    ExposureEvolution.KernelPratt.prime_2377,
    ExposureEvolution.KernelPratt.prime_5526743,
    ExposureEvolution.KernelPratt.prime_5527013,
    ExposureEvolution.KernelPratt.prime_5527189]

def block22 : Witness := ⟨⟨5555449, 5621640, 2371, 2377, 2381, 5555059, 5555117, 5555401⟩, 8⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2371,
    ExposureEvolution.KernelPratt.prime_2377,
    ExposureEvolution.KernelPratt.prime_2381,
    ExposureEvolution.KernelPratt.prime_5555059,
    ExposureEvolution.KernelPratt.prime_5555117,
    ExposureEvolution.KernelPratt.prime_5555401]

def block23 : Witness := ⟨⟨5621641, 5650128, 2377, 2381, 2383, 5621267, 5621327, 5621617⟩, 11⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2377,
    ExposureEvolution.KernelPratt.prime_2381,
    ExposureEvolution.KernelPratt.prime_2383,
    ExposureEvolution.KernelPratt.prime_5621267,
    ExposureEvolution.KernelPratt.prime_5621327,
    ExposureEvolution.KernelPratt.prime_5621617]

def block24 : Witness := ⟨⟨5650129, 5669160, 2381, 2383, 2389, 5649769, 5649877, 5650121⟩, 12⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2381,
    ExposureEvolution.KernelPratt.prime_2383,
    ExposureEvolution.KernelPratt.prime_2389,
    ExposureEvolution.KernelPratt.prime_5649769,
    ExposureEvolution.KernelPratt.prime_5649877,
    ExposureEvolution.KernelPratt.prime_5650121]

def block25 : Witness := ⟨⟨5669161, 5678688, 2383, 2389, 2393, 5668577, 5668609, 5669159⟩, 8⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2383,
    ExposureEvolution.KernelPratt.prime_2389,
    ExposureEvolution.KernelPratt.prime_2393,
    ExposureEvolution.KernelPratt.prime_5668577,
    ExposureEvolution.KernelPratt.prime_5668609,
    ExposureEvolution.KernelPratt.prime_5669159]

def block26 : Witness := ⟨⟨5678689, 5707320, 2389, 2393, 2399, 5678227, 5678483, 5678669⟩, 10⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2389,
    ExposureEvolution.KernelPratt.prime_2393,
    ExposureEvolution.KernelPratt.prime_2399,
    ExposureEvolution.KernelPratt.prime_5678227,
    ExposureEvolution.KernelPratt.prime_5678483,
    ExposureEvolution.KernelPratt.prime_5678669]

def block27 : Witness := ⟨⟨5707321, 5726448, 2393, 2399, 2411, 5707033, 5707073, 5707319⟩, 9⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2393,
    ExposureEvolution.KernelPratt.prime_2399,
    ExposureEvolution.KernelPratt.prime_2411,
    ExposureEvolution.KernelPratt.prime_5707033,
    ExposureEvolution.KernelPratt.prime_5707073,
    ExposureEvolution.KernelPratt.prime_5707319]

def block28 : Witness := ⟨⟨5726449, 5755200, 2399, 2411, 2417, 5725943, 5726359, 5726447⟩, 9⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2399,
    ExposureEvolution.KernelPratt.prime_2411,
    ExposureEvolution.KernelPratt.prime_2417,
    ExposureEvolution.KernelPratt.prime_5725943,
    ExposureEvolution.KernelPratt.prime_5726359,
    ExposureEvolution.KernelPratt.prime_5726447]

def block29 : Witness := ⟨⟨5755201, 5812920, 2411, 2417, 2423, 5754757, 5755049, 5755187⟩, 8⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2411,
    ExposureEvolution.KernelPratt.prime_2417,
    ExposureEvolution.KernelPratt.prime_2423,
    ExposureEvolution.KernelPratt.prime_5754757,
    ExposureEvolution.KernelPratt.prime_5755049,
    ExposureEvolution.KernelPratt.prime_5755187]

def block30 : Witness := ⟨⟨5812921, 5841888, 2417, 2423, 2437, 5812633, 5812823, 5812907⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2417,
    ExposureEvolution.KernelPratt.prime_2423,
    ExposureEvolution.KernelPratt.prime_2437,
    ExposureEvolution.KernelPratt.prime_5812633,
    ExposureEvolution.KernelPratt.prime_5812823,
    ExposureEvolution.KernelPratt.prime_5812907]

def block31 : Witness := ⟨⟨5841889, 5870928, 2423, 2437, 2441, 5841481, 5841571, 5841883⟩, 12⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2423,
    ExposureEvolution.KernelPratt.prime_2437,
    ExposureEvolution.KernelPratt.prime_2441,
    ExposureEvolution.KernelPratt.prime_5841481,
    ExposureEvolution.KernelPratt.prime_5841571,
    ExposureEvolution.KernelPratt.prime_5841883]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 5870929 stop tail = true) :
    coverage 4853209 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks05
