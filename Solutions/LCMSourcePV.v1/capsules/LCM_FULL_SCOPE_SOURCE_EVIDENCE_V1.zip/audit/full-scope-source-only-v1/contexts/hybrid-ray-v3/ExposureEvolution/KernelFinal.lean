import ExposureEvolution.KernelBlockCoverage
import ExposureEvolution.KernelFullGap
import ExposureEvolution.KernelSharpSurplus
namespace ExposureEvolution.KernelFinal
open Real

lemma exp_nine_small : exp (9 : ℝ) < 8468 := by
  have he : exp 1 < (87 / 32 : ℝ) := by linarith [Real.exp_one_lt_d9]
  calc exp (9 : ℝ) = (exp 1) ^ 9 := by rw [Real.exp_one_pow]; norm_num
    _ ≤ (87 / 32 : ℝ) ^ 9 := pow_le_pow_left₀ (exp_pos 1).le he.le 9
    _ < 8468 := by norm_num

theorem tail (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 71707024 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hg : KernelSharpConstant.StrictGap 8468 := KernelFullGap.full_gap hd
  have hlog : (9 : ℝ) ≤ log 8468 := by
    simpa only [log_exp] using (log_lt_log (exp_pos (9 : ℝ)) exp_nine_small).le
  have hreal : (8468 : ℝ) ^ 2 ≤ n := by exact_mod_cast hn
  obtain ⟨m, hm, hσ⟩ := KernelSharpSurplus.quantitative_of_gap
    (c := 9) hg (by norm_num : (9 : ℝ) ≤ 9) hlog n hreal
  refine ⟨m, ?_, hm, hσ⟩
  by_contra hpos
  have hm0 : m = 0 := Nat.eq_zero_of_not_pos hpos
  have hσ' : (1 + 3 / (10 * (n : ℝ))) *
      (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) < 0 := by simpa [hm0] using hσ
  exact not_lt_of_ge (by positivity) hσ'

/-- New unbounded quantitative theorem; original source assumptions are unchanged. -/
theorem whole_ray (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 1000000 ≤ n) :
    ∃ m : ℕ, 0 < m ∧ m < Nat.lcmUpto n ∧
      (1 + 3 / (10 * (n : ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
        ArithmeticFunction.sigma 1 m := by
  by_cases ht : n < 71707024
  · exact KernelBlockCoverage.finite n ⟨hn, ht⟩
  · exact tail hd n (Nat.le_of_not_lt ht)

/-- Exact quantitative comparison on the common domain; no global-best claim. -/
theorem margin_strict (n : ℕ) (hn : 0 < n) :
    (7902076804629632 / 52390502259887275 : ℝ) / n < 3 / (10 * (n : ℝ)) := by
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn
  calc
    (7902076804629632 / 52390502259887275 : ℝ) / n < (3 / 10 : ℝ) / n :=
      div_lt_div_of_pos_right (by norm_num) hnpos
    _ = 3 / (10 * (n : ℝ)) := by ring

#check @whole_ray
#print axioms whole_ray
#print axioms margin_strict
end ExposureEvolution.KernelFinal
