import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks009
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_22051 : next 22051 = some 22133 := by
  have hl : (List.range ((257 * 22051 - 1) / 256 - 22051)).reverse =
      [85, 84, 83, 82, 81] ++ (List.range 81).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22133]

theorem next_22133 : next 22133 = some 22193 := by
  have hl : (List.range ((257 * 22133 - 1) / 256 - 22133)).reverse =
      [85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22193]

theorem next_22193 : next 22193 = some 22279 := by
  have hl : (List.range ((257 * 22193 - 1) / 256 - 22193)).reverse =
      [85] ++ (List.range 85).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22279]

theorem next_22279 : next 22279 = some 22349 := by
  have hl : (List.range ((257 * 22279 - 1) / 256 - 22279)).reverse =
      [86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69] ++ (List.range 69).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22349]

theorem next_22349 : next 22349 = some 22433 := by
  have hl : (List.range ((257 * 22349 - 1) / 256 - 22349)).reverse =
      [86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22433]

theorem next_22433 : next 22433 = some 22511 := by
  have hl : (List.range ((257 * 22433 - 1) / 256 - 22433)).reverse =
      [86, 85, 84, 83, 82, 81, 80, 79, 78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22511]

theorem next_22511 : next 22511 = some 22573 := by
  have hl : (List.range ((257 * 22511 - 1) / 256 - 22511)).reverse =
      [86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61] ++ (List.range 61).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22573]

theorem next_22573 : next 22573 = some 22651 := by
  have hl : (List.range ((257 * 22573 - 1) / 256 - 22573)).reverse =
      [87, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22651]

theorem next_22651 : next 22651 = some 22739 := by
  have hl : (List.range ((257 * 22651 - 1) / 256 - 22651)).reverse =
      [87] ++ (List.range 87).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22739]

theorem next_22739 : next 22739 = some 22817 := by
  have hl : (List.range ((257 * 22739 - 1) / 256 - 22739)).reverse =
      [87, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22817]

theorem next_22817 : next 22817 = some 22901 := by
  have hl : (List.range ((257 * 22817 - 1) / 256 - 22817)).reverse =
      [88, 87, 86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22901]

theorem next_22901 : next 22901 = some 22973 := by
  have hl : (List.range ((257 * 22901 - 1) / 256 - 22901)).reverse =
      [88, 87, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22973]

theorem next_22973 : next 22973 = some 23059 := by
  have hl : (List.range ((257 * 22973 - 1) / 256 - 22973)).reverse =
      [88, 87, 86, 85] ++ (List.range 85).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23059]

theorem next_23059 : next 23059 = some 23143 := by
  have hl : (List.range ((257 * 23059 - 1) / 256 - 23059)).reverse =
      [89, 88, 87, 86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23143]

theorem next_23143 : next 23143 = some 23227 := by
  have hl : (List.range ((257 * 23143 - 1) / 256 - 23143)).reverse =
      [89, 88, 87, 86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23227]

theorem next_23227 : next 23227 = some 23311 := by
  have hl : (List.range ((257 * 23227 - 1) / 256 - 23227)).reverse =
      [89, 88, 87, 86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23311]

theorem next_23311 : next 23311 = some 23399 := by
  have hl : (List.range ((257 * 23311 - 1) / 256 - 23311)).reverse =
      [90, 89, 88, 87] ++ (List.range 87).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23399]

theorem next_23399 : next 23399 = some 23473 := by
  have hl : (List.range ((257 * 23399 - 1) / 256 - 23399)).reverse =
      [90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73] ++ (List.range 73).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23473]

theorem next_23473 : next 23473 = some 23563 := by
  have hl : (List.range ((257 * 23473 - 1) / 256 - 23473)).reverse =
      [90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23563]

theorem next_23563 : next 23563 = some 23633 := by
  have hl : (List.range ((257 * 23563 - 1) / 256 - 23563)).reverse =
      [91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69] ++ (List.range 69).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23633]

theorem next_23633 : next 23633 = some 23719 := by
  have hl : (List.range ((257 * 23633 - 1) / 256 - 23633)).reverse =
      [91, 90, 89, 88, 87, 86, 85] ++ (List.range 85).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23719]

theorem next_23719 : next 23719 = some 23801 := by
  have hl : (List.range ((257 * 23719 - 1) / 256 - 23719)).reverse =
      [91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81] ++ (List.range 81).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23801]

theorem next_23801 : next 23801 = some 23893 := by
  have hl : (List.range ((257 * 23801 - 1) / 256 - 23801)).reverse =
      [91] ++ (List.range 91).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23893]

theorem next_23893 : next 23893 = some 23981 := by
  have hl : (List.range ((257 * 23893 - 1) / 256 - 23893)).reverse =
      [92, 91, 90, 89, 88, 87] ++ (List.range 87).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_23981]

theorem next_23981 : next 23981 = some 24071 := by
  have hl : (List.range ((257 * 23981 - 1) / 256 - 23981)).reverse =
      [92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24071]

theorem next_24071 : next 24071 = some 24151 := by
  have hl : (List.range ((257 * 24071 - 1) / 256 - 24071)).reverse =
      [93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 80, 79] ++ (List.range 79).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24151]

theorem next_24151 : next 24151 = some 24239 := by
  have hl : (List.range ((257 * 24151 - 1) / 256 - 24151)).reverse =
      [93, 92, 91, 90, 89, 88, 87] ++ (List.range 87).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24239]

theorem next_24239 : next 24239 = some 24329 := by
  have hl : (List.range ((257 * 24239 - 1) / 256 - 24239)).reverse =
      [93, 92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24329]

theorem next_24329 : next 24329 = some 24421 := by
  have hl : (List.range ((257 * 24329 - 1) / 256 - 24329)).reverse =
      [94, 93, 92, 91] ++ (List.range 91).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24421]

theorem next_24421 : next 24421 = some 24509 := by
  have hl : (List.range ((257 * 24421 - 1) / 256 - 24421)).reverse =
      [94, 93, 92, 91, 90, 89, 88, 87] ++ (List.range 87).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24509]

theorem next_24509 : next 24509 = some 24593 := by
  have hl : (List.range ((257 * 24509 - 1) / 256 - 24509)).reverse =
      [94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24593]

theorem next_24593 : next 24593 = some 24683 := by
  have hl : (List.range ((257 * 24593 - 1) / 256 - 24593)).reverse =
      [95, 94, 93, 92, 91, 90, 89] ++ (List.range 89).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_24683]

def primes : List ℕ := [22133, 22193, 22279, 22349, 22433, 22511, 22573, 22651, 22739, 22817, 22901, 22973, 23059, 23143, 23227, 23311, 23399, 23473, 23563, 23633, 23719, 23801, 23893, 23981, 24071, 24151, 24239, 24329, 24421, 24509, 24593, 24683]

theorem segment : run 412 22051 89693 =
    primes ++ run 380 24683 89693 := by
  rw [Compact40PrimeCompose256.step 411 22051 89693 22133
    (by decide +kernel) next_22051]
  rw [Compact40PrimeCompose256.step 410 22133 89693 22193
    (by decide +kernel) next_22133]
  rw [Compact40PrimeCompose256.step 409 22193 89693 22279
    (by decide +kernel) next_22193]
  rw [Compact40PrimeCompose256.step 408 22279 89693 22349
    (by decide +kernel) next_22279]
  rw [Compact40PrimeCompose256.step 407 22349 89693 22433
    (by decide +kernel) next_22349]
  rw [Compact40PrimeCompose256.step 406 22433 89693 22511
    (by decide +kernel) next_22433]
  rw [Compact40PrimeCompose256.step 405 22511 89693 22573
    (by decide +kernel) next_22511]
  rw [Compact40PrimeCompose256.step 404 22573 89693 22651
    (by decide +kernel) next_22573]
  rw [Compact40PrimeCompose256.step 403 22651 89693 22739
    (by decide +kernel) next_22651]
  rw [Compact40PrimeCompose256.step 402 22739 89693 22817
    (by decide +kernel) next_22739]
  rw [Compact40PrimeCompose256.step 401 22817 89693 22901
    (by decide +kernel) next_22817]
  rw [Compact40PrimeCompose256.step 400 22901 89693 22973
    (by decide +kernel) next_22901]
  rw [Compact40PrimeCompose256.step 399 22973 89693 23059
    (by decide +kernel) next_22973]
  rw [Compact40PrimeCompose256.step 398 23059 89693 23143
    (by decide +kernel) next_23059]
  rw [Compact40PrimeCompose256.step 397 23143 89693 23227
    (by decide +kernel) next_23143]
  rw [Compact40PrimeCompose256.step 396 23227 89693 23311
    (by decide +kernel) next_23227]
  rw [Compact40PrimeCompose256.step 395 23311 89693 23399
    (by decide +kernel) next_23311]
  rw [Compact40PrimeCompose256.step 394 23399 89693 23473
    (by decide +kernel) next_23399]
  rw [Compact40PrimeCompose256.step 393 23473 89693 23563
    (by decide +kernel) next_23473]
  rw [Compact40PrimeCompose256.step 392 23563 89693 23633
    (by decide +kernel) next_23563]
  rw [Compact40PrimeCompose256.step 391 23633 89693 23719
    (by decide +kernel) next_23633]
  rw [Compact40PrimeCompose256.step 390 23719 89693 23801
    (by decide +kernel) next_23719]
  rw [Compact40PrimeCompose256.step 389 23801 89693 23893
    (by decide +kernel) next_23801]
  rw [Compact40PrimeCompose256.step 388 23893 89693 23981
    (by decide +kernel) next_23893]
  rw [Compact40PrimeCompose256.step 387 23981 89693 24071
    (by decide +kernel) next_23981]
  rw [Compact40PrimeCompose256.step 386 24071 89693 24151
    (by decide +kernel) next_24071]
  rw [Compact40PrimeCompose256.step 385 24151 89693 24239
    (by decide +kernel) next_24151]
  rw [Compact40PrimeCompose256.step 384 24239 89693 24329
    (by decide +kernel) next_24239]
  rw [Compact40PrimeCompose256.step 383 24329 89693 24421
    (by decide +kernel) next_24329]
  rw [Compact40PrimeCompose256.step 382 24421 89693 24509
    (by decide +kernel) next_24421]
  rw [Compact40PrimeCompose256.step 381 24509 89693 24593
    (by decide +kernel) next_24509]
  rw [Compact40PrimeCompose256.step 380 24593 89693 24683
    (by decide +kernel) next_24593]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 24683 stop tail = true) :
    check 22051 stop (primes ++ tail) = true := by
  change check _ _ (22133 :: 22193 :: 22279 :: 22349 :: 22433 :: 22511 :: 22573 :: 22651 :: 22739 :: 22817 :: 22901 :: 22973 :: 23059 :: 23143 :: 23227 :: 23311 :: 23399 :: 23473 :: 23563 :: 23633 :: 23719 :: 23801 :: 23893 :: 23981 :: 24071 :: 24151 :: 24239 :: 24329 :: 24421 :: 24509 :: 24593 :: 24683 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22133, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22193, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22279, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22349, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22433, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22511, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22573, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22651, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22739, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22817, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22901, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22973, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23059, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23143, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23227, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23311, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23399, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23473, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23563, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23633, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23719, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23801, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23893, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_23981, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24071, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24151, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24239, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24329, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24421, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24509, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24593, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_24683, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks009
