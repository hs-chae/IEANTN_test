import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks005
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_14159 : next 14159 = some 14207 := by
  have hl : (List.range ((257 * 14159 - 1) / 256 - 14159)).reverse =
      [54, 53, 52, 51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14207]

theorem next_14207 : next 14207 = some 14251 := by
  have hl : (List.range ((257 * 14207 - 1) / 256 - 14207)).reverse =
      [54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14251]

theorem next_14251 : next 14251 = some 14303 := by
  have hl : (List.range ((257 * 14251 - 1) / 256 - 14251)).reverse =
      [54, 53, 52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14303]

theorem next_14303 : next 14303 = some 14347 := by
  have hl : (List.range ((257 * 14303 - 1) / 256 - 14303)).reverse =
      [54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14347]

theorem next_14347 : next 14347 = some 14401 := by
  have hl : (List.range ((257 * 14347 - 1) / 256 - 14347)).reverse =
      [55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14401]

theorem next_14401 : next 14401 = some 14449 := by
  have hl : (List.range ((257 * 14401 - 1) / 256 - 14401)).reverse =
      [55, 54, 53, 52, 51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14449]

theorem next_14449 : next 14449 = some 14503 := by
  have hl : (List.range ((257 * 14449 - 1) / 256 - 14449)).reverse =
      [55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14503]

theorem next_14503 : next 14503 = some 14557 := by
  have hl : (List.range ((257 * 14503 - 1) / 256 - 14503)).reverse =
      [55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14557]

theorem next_14557 : next 14557 = some 14593 := by
  have hl : (List.range ((257 * 14557 - 1) / 256 - 14557)).reverse =
      [55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14593]

theorem next_14593 : next 14593 = some 14639 := by
  have hl : (List.range ((257 * 14593 - 1) / 256 - 14593)).reverse =
      [56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14639]

theorem next_14639 : next 14639 = some 14683 := by
  have hl : (List.range ((257 * 14639 - 1) / 256 - 14639)).reverse =
      [56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14683]

theorem next_14683 : next 14683 = some 14737 := by
  have hl : (List.range ((257 * 14683 - 1) / 256 - 14683)).reverse =
      [56, 55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14737]

theorem next_14737 : next 14737 = some 14783 := by
  have hl : (List.range ((257 * 14737 - 1) / 256 - 14737)).reverse =
      [56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45] ++ (List.range 45).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14783]

theorem next_14783 : next 14783 = some 14831 := by
  have hl : (List.range ((257 * 14783 - 1) / 256 - 14783)).reverse =
      [56, 55, 54, 53, 52, 51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14831]

theorem next_14831 : next 14831 = some 14887 := by
  have hl : (List.range ((257 * 14831 - 1) / 256 - 14831)).reverse =
      [56, 55] ++ (List.range 55).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14887]

theorem next_14887 : next 14887 = some 14939 := by
  have hl : (List.range ((257 * 14887 - 1) / 256 - 14887)).reverse =
      [57, 56, 55, 54, 53, 52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14939]

theorem next_14939 : next 14939 = some 14983 := by
  have hl : (List.range ((257 * 14939 - 1) / 256 - 14939)).reverse =
      [57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_14983]

theorem next_14983 : next 14983 = some 15031 := by
  have hl : (List.range ((257 * 14983 - 1) / 256 - 14983)).reverse =
      [57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15031]

theorem next_15031 : next 15031 = some 15083 := by
  have hl : (List.range ((257 * 15031 - 1) / 256 - 15031)).reverse =
      [57, 56, 55, 54, 53, 52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15083]

theorem next_15083 : next 15083 = some 15139 := by
  have hl : (List.range ((257 * 15083 - 1) / 256 - 15083)).reverse =
      [57, 56, 55] ++ (List.range 55).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15139]

theorem next_15139 : next 15139 = some 15193 := by
  have hl : (List.range ((257 * 15139 - 1) / 256 - 15139)).reverse =
      [58, 57, 56, 55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15193]

theorem next_15193 : next 15193 = some 15241 := by
  have hl : (List.range ((257 * 15193 - 1) / 256 - 15193)).reverse =
      [58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15241]

theorem next_15241 : next 15241 = some 15299 := by
  have hl : (List.range ((257 * 15241 - 1) / 256 - 15241)).reverse =
      [58, 57] ++ (List.range 57).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15299]

theorem next_15299 : next 15299 = some 15349 := by
  have hl : (List.range ((257 * 15299 - 1) / 256 - 15299)).reverse =
      [58, 57, 56, 55, 54, 53, 52, 51, 50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15349]

theorem next_15349 : next 15349 = some 15401 := by
  have hl : (List.range ((257 * 15349 - 1) / 256 - 15349)).reverse =
      [58, 57, 56, 55, 54, 53, 52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15401]

theorem next_15401 : next 15401 = some 15461 := by
  have hl : (List.range ((257 * 15401 - 1) / 256 - 15401)).reverse =
      [59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15461]

theorem next_15461 : next 15461 = some 15511 := by
  have hl : (List.range ((257 * 15461 - 1) / 256 - 15461)).reverse =
      [59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15511]

theorem next_15511 : next 15511 = some 15569 := by
  have hl : (List.range ((257 * 15511 - 1) / 256 - 15511)).reverse =
      [59, 58, 57] ++ (List.range 57).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15569]

theorem next_15569 : next 15569 = some 15629 := by
  have hl : (List.range ((257 * 15569 - 1) / 256 - 15569)).reverse =
      [59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15629]

theorem next_15629 : next 15629 = some 15683 := by
  have hl : (List.range ((257 * 15629 - 1) / 256 - 15629)).reverse =
      [60, 59, 58, 57, 56, 55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15683]

theorem next_15683 : next 15683 = some 15739 := by
  have hl : (List.range ((257 * 15683 - 1) / 256 - 15683)).reverse =
      [60, 59, 58, 57, 56, 55] ++ (List.range 55).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15739]

theorem next_15739 : next 15739 = some 15797 := by
  have hl : (List.range ((257 * 15739 - 1) / 256 - 15739)).reverse =
      [60, 59, 58, 57] ++ (List.range 57).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15797]

def primes : List ℕ := [14207, 14251, 14303, 14347, 14401, 14449, 14503, 14557, 14593, 14639, 14683, 14737, 14783, 14831, 14887, 14939, 14983, 15031, 15083, 15139, 15193, 15241, 15299, 15349, 15401, 15461, 15511, 15569, 15629, 15683, 15739, 15797]

theorem segment : run 540 14159 89693 =
    primes ++ run 508 15797 89693 := by
  rw [Compact40PrimeCompose256.step 539 14159 89693 14207
    (by decide +kernel) next_14159]
  rw [Compact40PrimeCompose256.step 538 14207 89693 14251
    (by decide +kernel) next_14207]
  rw [Compact40PrimeCompose256.step 537 14251 89693 14303
    (by decide +kernel) next_14251]
  rw [Compact40PrimeCompose256.step 536 14303 89693 14347
    (by decide +kernel) next_14303]
  rw [Compact40PrimeCompose256.step 535 14347 89693 14401
    (by decide +kernel) next_14347]
  rw [Compact40PrimeCompose256.step 534 14401 89693 14449
    (by decide +kernel) next_14401]
  rw [Compact40PrimeCompose256.step 533 14449 89693 14503
    (by decide +kernel) next_14449]
  rw [Compact40PrimeCompose256.step 532 14503 89693 14557
    (by decide +kernel) next_14503]
  rw [Compact40PrimeCompose256.step 531 14557 89693 14593
    (by decide +kernel) next_14557]
  rw [Compact40PrimeCompose256.step 530 14593 89693 14639
    (by decide +kernel) next_14593]
  rw [Compact40PrimeCompose256.step 529 14639 89693 14683
    (by decide +kernel) next_14639]
  rw [Compact40PrimeCompose256.step 528 14683 89693 14737
    (by decide +kernel) next_14683]
  rw [Compact40PrimeCompose256.step 527 14737 89693 14783
    (by decide +kernel) next_14737]
  rw [Compact40PrimeCompose256.step 526 14783 89693 14831
    (by decide +kernel) next_14783]
  rw [Compact40PrimeCompose256.step 525 14831 89693 14887
    (by decide +kernel) next_14831]
  rw [Compact40PrimeCompose256.step 524 14887 89693 14939
    (by decide +kernel) next_14887]
  rw [Compact40PrimeCompose256.step 523 14939 89693 14983
    (by decide +kernel) next_14939]
  rw [Compact40PrimeCompose256.step 522 14983 89693 15031
    (by decide +kernel) next_14983]
  rw [Compact40PrimeCompose256.step 521 15031 89693 15083
    (by decide +kernel) next_15031]
  rw [Compact40PrimeCompose256.step 520 15083 89693 15139
    (by decide +kernel) next_15083]
  rw [Compact40PrimeCompose256.step 519 15139 89693 15193
    (by decide +kernel) next_15139]
  rw [Compact40PrimeCompose256.step 518 15193 89693 15241
    (by decide +kernel) next_15193]
  rw [Compact40PrimeCompose256.step 517 15241 89693 15299
    (by decide +kernel) next_15241]
  rw [Compact40PrimeCompose256.step 516 15299 89693 15349
    (by decide +kernel) next_15299]
  rw [Compact40PrimeCompose256.step 515 15349 89693 15401
    (by decide +kernel) next_15349]
  rw [Compact40PrimeCompose256.step 514 15401 89693 15461
    (by decide +kernel) next_15401]
  rw [Compact40PrimeCompose256.step 513 15461 89693 15511
    (by decide +kernel) next_15461]
  rw [Compact40PrimeCompose256.step 512 15511 89693 15569
    (by decide +kernel) next_15511]
  rw [Compact40PrimeCompose256.step 511 15569 89693 15629
    (by decide +kernel) next_15569]
  rw [Compact40PrimeCompose256.step 510 15629 89693 15683
    (by decide +kernel) next_15629]
  rw [Compact40PrimeCompose256.step 509 15683 89693 15739
    (by decide +kernel) next_15683]
  rw [Compact40PrimeCompose256.step 508 15739 89693 15797
    (by decide +kernel) next_15739]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 15797 stop tail = true) :
    check 14159 stop (primes ++ tail) = true := by
  change check _ _ (14207 :: 14251 :: 14303 :: 14347 :: 14401 :: 14449 :: 14503 :: 14557 :: 14593 :: 14639 :: 14683 :: 14737 :: 14783 :: 14831 :: 14887 :: 14939 :: 14983 :: 15031 :: 15083 :: 15139 :: 15193 :: 15241 :: 15299 :: 15349 :: 15401 :: 15461 :: 15511 :: 15569 :: 15629 :: 15683 :: 15739 :: 15797 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14207, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14251, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14303, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14347, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14401, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14449, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14503, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14557, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14593, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14639, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14683, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14737, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14783, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14831, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14887, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14939, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_14983, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15031, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15083, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15139, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15193, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15241, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15299, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15349, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15401, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15461, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15511, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15569, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15629, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15683, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15739, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15797, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks005
