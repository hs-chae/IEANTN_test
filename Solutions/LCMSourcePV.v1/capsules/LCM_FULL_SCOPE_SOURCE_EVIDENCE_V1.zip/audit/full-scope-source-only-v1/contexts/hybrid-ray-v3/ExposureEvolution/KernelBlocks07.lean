import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks07
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨7252249, 7284600, 2699, 2707, 2711, 7251947, 7252187, 7252237⟩, 7⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2699,
    ExposureEvolution.KernelPratt.prime_2707,
    ExposureEvolution.KernelPratt.prime_2711,
    ExposureEvolution.KernelPratt.prime_7251947,
    ExposureEvolution.KernelPratt.prime_7252187,
    ExposureEvolution.KernelPratt.prime_7252237]

def block01 : Witness := ⟨⟨7284601, 7327848, 2707, 2711, 2713, 7284371, 7284521, 7284569⟩, 6⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2707,
    ExposureEvolution.KernelPratt.prime_2711,
    ExposureEvolution.KernelPratt.prime_2713,
    ExposureEvolution.KernelPratt.prime_7284371,
    ExposureEvolution.KernelPratt.prime_7284521,
    ExposureEvolution.KernelPratt.prime_7284569]

def block02 : Witness := ⟨⟨7327849, 7349520, 2711, 2713, 2719, 7327601, 7327627, 7327847⟩, 13⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2711,
    ExposureEvolution.KernelPratt.prime_2713,
    ExposureEvolution.KernelPratt.prime_2719,
    ExposureEvolution.KernelPratt.prime_7327601,
    ExposureEvolution.KernelPratt.prime_7327627,
    ExposureEvolution.KernelPratt.prime_7327847]

def block03 : Witness := ⟨⟨7349521, 7360368, 2713, 2719, 2729, 7349141, 7349393, 7349513⟩, 13⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2713,
    ExposureEvolution.KernelPratt.prime_2719,
    ExposureEvolution.KernelPratt.prime_2729,
    ExposureEvolution.KernelPratt.prime_7349141,
    ExposureEvolution.KernelPratt.prime_7349393,
    ExposureEvolution.KernelPratt.prime_7349513]

def block04 : Witness := ⟨⟨7360369, 7392960, 2719, 2729, 2731, 7359817, 7359949, 7360363⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2719,
    ExposureEvolution.KernelPratt.prime_2729,
    ExposureEvolution.KernelPratt.prime_2731,
    ExposureEvolution.KernelPratt.prime_7359817,
    ExposureEvolution.KernelPratt.prime_7359949,
    ExposureEvolution.KernelPratt.prime_7360363]

def block05 : Witness := ⟨⟨7392961, 7447440, 2729, 2731, 2741, 7392373, 7392617, 7392953⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2729,
    ExposureEvolution.KernelPratt.prime_2731,
    ExposureEvolution.KernelPratt.prime_2741,
    ExposureEvolution.KernelPratt.prime_7392373,
    ExposureEvolution.KernelPratt.prime_7392617,
    ExposureEvolution.KernelPratt.prime_7392953]

def block06 : Witness := ⟨⟨7447441, 7458360, 2731, 2741, 2749, 7447051, 7447061, 7447439⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2731,
    ExposureEvolution.KernelPratt.prime_2741,
    ExposureEvolution.KernelPratt.prime_2749,
    ExposureEvolution.KernelPratt.prime_7447051,
    ExposureEvolution.KernelPratt.prime_7447061,
    ExposureEvolution.KernelPratt.prime_7447439]

def block07 : Witness := ⟨⟨7458361, 7513080, 2741, 2749, 2753, 7457839, 7458067, 7458313⟩, 8⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2741,
    ExposureEvolution.KernelPratt.prime_2749,
    ExposureEvolution.KernelPratt.prime_2753,
    ExposureEvolution.KernelPratt.prime_7457839,
    ExposureEvolution.KernelPratt.prime_7458067,
    ExposureEvolution.KernelPratt.prime_7458313]

def block08 : Witness := ⟨⟨7513081, 7557000, 2749, 2753, 2767, 7512773, 7512853, 7513073⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2749,
    ExposureEvolution.KernelPratt.prime_2753,
    ExposureEvolution.KernelPratt.prime_2767,
    ExposureEvolution.KernelPratt.prime_7512773,
    ExposureEvolution.KernelPratt.prime_7512853,
    ExposureEvolution.KernelPratt.prime_7513073]

def block09 : Witness := ⟨⟨7557001, 7579008, 2753, 2767, 2777, 7556629, 7556641, 7556999⟩, 7⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2753,
    ExposureEvolution.KernelPratt.prime_2767,
    ExposureEvolution.KernelPratt.prime_2777,
    ExposureEvolution.KernelPratt.prime_7556629,
    ExposureEvolution.KernelPratt.prime_7556641,
    ExposureEvolution.KernelPratt.prime_7556999]

def block10 : Witness := ⟨⟨7579009, 7656288, 2767, 2777, 2789, 7578553, 7578643, 7579003⟩, 8⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2767,
    ExposureEvolution.KernelPratt.prime_2777,
    ExposureEvolution.KernelPratt.prime_2789,
    ExposureEvolution.KernelPratt.prime_7578553,
    ExposureEvolution.KernelPratt.prime_7578643,
    ExposureEvolution.KernelPratt.prime_7579003]

def block11 : Witness := ⟨⟨7656289, 7711728, 2777, 2789, 2791, 7655737, 7656043, 7656281⟩, 12⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2777,
    ExposureEvolution.KernelPratt.prime_2789,
    ExposureEvolution.KernelPratt.prime_2791,
    ExposureEvolution.KernelPratt.prime_7655737,
    ExposureEvolution.KernelPratt.prime_7656043,
    ExposureEvolution.KernelPratt.prime_7656281]

def block12 : Witness := ⟨⟨7711729, 7778520, 2789, 2791, 2797, 7711687, 7711703, 7711723⟩, 11⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2789,
    ExposureEvolution.KernelPratt.prime_2791,
    ExposureEvolution.KernelPratt.prime_2797,
    ExposureEvolution.KernelPratt.prime_7711687,
    ExposureEvolution.KernelPratt.prime_7711703,
    ExposureEvolution.KernelPratt.prime_7711723]

def block13 : Witness := ⟨⟨7778521, 7789680, 2791, 2797, 2801, 7778327, 7778339, 7778509⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2791,
    ExposureEvolution.KernelPratt.prime_2797,
    ExposureEvolution.KernelPratt.prime_2801,
    ExposureEvolution.KernelPratt.prime_7778327,
    ExposureEvolution.KernelPratt.prime_7778339,
    ExposureEvolution.KernelPratt.prime_7778509]

def block14 : Witness := ⟨⟨7789681, 7823208, 2797, 2801, 2803, 7789363, 7789393, 7789669⟩, 10⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2797,
    ExposureEvolution.KernelPratt.prime_2801,
    ExposureEvolution.KernelPratt.prime_2803,
    ExposureEvolution.KernelPratt.prime_7789363,
    ExposureEvolution.KernelPratt.prime_7789393,
    ExposureEvolution.KernelPratt.prime_7789669]

def block15 : Witness := ⟨⟨7823209, 7845600, 2801, 2803, 2819, 7823093, 7823183, 7823203⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2801,
    ExposureEvolution.KernelPratt.prime_2803,
    ExposureEvolution.KernelPratt.prime_2819,
    ExposureEvolution.KernelPratt.prime_7823093,
    ExposureEvolution.KernelPratt.prime_7823183,
    ExposureEvolution.KernelPratt.prime_7823203]

def block16 : Witness := ⟨⟨7845601, 7856808, 2803, 2819, 2833, 7845203, 7845301, 7845587⟩, 9⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2803,
    ExposureEvolution.KernelPratt.prime_2819,
    ExposureEvolution.KernelPratt.prime_2833,
    ExposureEvolution.KernelPratt.prime_7845203,
    ExposureEvolution.KernelPratt.prime_7845301,
    ExposureEvolution.KernelPratt.prime_7845587]

def block17 : Witness := ⟨⟨7856809, 7946760, 2819, 2833, 2837, 7856231, 7856587, 7856803⟩, 7⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2819,
    ExposureEvolution.KernelPratt.prime_2833,
    ExposureEvolution.KernelPratt.prime_2837,
    ExposureEvolution.KernelPratt.prime_7856231,
    ExposureEvolution.KernelPratt.prime_7856587,
    ExposureEvolution.KernelPratt.prime_7856803]

def block18 : Witness := ⟨⟨7946761, 8025888, 2833, 2837, 2843, 7946683, 7946717, 7946747⟩, 6⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2833,
    ExposureEvolution.KernelPratt.prime_2837,
    ExposureEvolution.KernelPratt.prime_2843,
    ExposureEvolution.KernelPratt.prime_7946683,
    ExposureEvolution.KernelPratt.prime_7946717,
    ExposureEvolution.KernelPratt.prime_7946747]

def block19 : Witness := ⟨⟨8025889, 8048568, 2837, 2843, 2851, 8025469, 8025679, 8025883⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2837,
    ExposureEvolution.KernelPratt.prime_2843,
    ExposureEvolution.KernelPratt.prime_2851,
    ExposureEvolution.KernelPratt.prime_8025469,
    ExposureEvolution.KernelPratt.prime_8025679,
    ExposureEvolution.KernelPratt.prime_8025883]

def block20 : Witness := ⟨⟨8048569, 8082648, 2843, 2851, 2857, 8048083, 8048389, 8048567⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2843,
    ExposureEvolution.KernelPratt.prime_2851,
    ExposureEvolution.KernelPratt.prime_2857,
    ExposureEvolution.KernelPratt.prime_8048083,
    ExposureEvolution.KernelPratt.prime_8048389,
    ExposureEvolution.KernelPratt.prime_8048567]

def block21 : Witness := ⟨⟨8082649, 8128200, 2851, 2857, 2861, 8082127, 8082397, 8082631⟩, 11⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2851,
    ExposureEvolution.KernelPratt.prime_2857,
    ExposureEvolution.KernelPratt.prime_2861,
    ExposureEvolution.KernelPratt.prime_8082127,
    ExposureEvolution.KernelPratt.prime_8082397,
    ExposureEvolution.KernelPratt.prime_8082631]

def block22 : Witness := ⟨⟨8128201, 8162448, 2857, 2861, 2879, 8127697, 8128063, 8128187⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2857,
    ExposureEvolution.KernelPratt.prime_2861,
    ExposureEvolution.KernelPratt.prime_2879,
    ExposureEvolution.KernelPratt.prime_8127697,
    ExposureEvolution.KernelPratt.prime_8128063,
    ExposureEvolution.KernelPratt.prime_8128187]

def block23 : Witness := ⟨⟨8162449, 8185320, 2861, 2879, 2887, 8162069, 8162353, 8162437⟩, 9⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2861,
    ExposureEvolution.KernelPratt.prime_2879,
    ExposureEvolution.KernelPratt.prime_2887,
    ExposureEvolution.KernelPratt.prime_8162069,
    ExposureEvolution.KernelPratt.prime_8162353,
    ExposureEvolution.KernelPratt.prime_8162437]

def block24 : Witness := ⟨⟨8185321, 8288640, 2879, 2887, 2897, 8185039, 8185291, 8185301⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2879,
    ExposureEvolution.KernelPratt.prime_2887,
    ExposureEvolution.KernelPratt.prime_2897,
    ExposureEvolution.KernelPratt.prime_8185039,
    ExposureEvolution.KernelPratt.prime_8185291,
    ExposureEvolution.KernelPratt.prime_8185301]

def block25 : Witness := ⟨⟨8288641, 8334768, 2887, 2897, 2903, 8288263, 8288557, 8288633⟩, 7⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2887,
    ExposureEvolution.KernelPratt.prime_2897,
    ExposureEvolution.KernelPratt.prime_2903,
    ExposureEvolution.KernelPratt.prime_8288263,
    ExposureEvolution.KernelPratt.prime_8288557,
    ExposureEvolution.KernelPratt.prime_8288633]

def block26 : Witness := ⟨⟨8334769, 8392608, 2897, 2903, 2909, 8334461, 8334499, 8334757⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2897,
    ExposureEvolution.KernelPratt.prime_2903,
    ExposureEvolution.KernelPratt.prime_2909,
    ExposureEvolution.KernelPratt.prime_8334461,
    ExposureEvolution.KernelPratt.prime_8334499,
    ExposureEvolution.KernelPratt.prime_8334757]

def block27 : Witness := ⟨⟨8392609, 8427408, 2903, 2909, 2917, 8392327, 8392561, 8392607⟩, 10⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2903,
    ExposureEvolution.KernelPratt.prime_2909,
    ExposureEvolution.KernelPratt.prime_2917,
    ExposureEvolution.KernelPratt.prime_8392327,
    ExposureEvolution.KernelPratt.prime_8392561,
    ExposureEvolution.KernelPratt.prime_8392607]

def block28 : Witness := ⟨⟨8427409, 8462280, 2909, 2917, 2927, 8427043, 8427161, 8427403⟩, 9⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2909,
    ExposureEvolution.KernelPratt.prime_2917,
    ExposureEvolution.KernelPratt.prime_2927,
    ExposureEvolution.KernelPratt.prime_8427043,
    ExposureEvolution.KernelPratt.prime_8427161,
    ExposureEvolution.KernelPratt.prime_8427403]

def block29 : Witness := ⟨⟨8462281, 8508888, 2917, 2927, 2939, 8462071, 8462093, 8462263⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2917,
    ExposureEvolution.KernelPratt.prime_2927,
    ExposureEvolution.KernelPratt.prime_2939,
    ExposureEvolution.KernelPratt.prime_8462071,
    ExposureEvolution.KernelPratt.prime_8462093,
    ExposureEvolution.KernelPratt.prime_8462263]

def block30 : Witness := ⟨⟨8508889, 8567328, 2927, 2939, 2953, 8508671, 8508847, 8508881⟩, 10⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2927,
    ExposureEvolution.KernelPratt.prime_2939,
    ExposureEvolution.KernelPratt.prime_2953,
    ExposureEvolution.KernelPratt.prime_8508671,
    ExposureEvolution.KernelPratt.prime_8508847,
    ExposureEvolution.KernelPratt.prime_8508881]

def block31 : Witness := ⟨⟨8567329, 8637720, 2939, 2953, 2957, 8566799, 8567281, 8567311⟩, 10⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_2939,
    ExposureEvolution.KernelPratt.prime_2953,
    ExposureEvolution.KernelPratt.prime_2957,
    ExposureEvolution.KernelPratt.prime_8566799,
    ExposureEvolution.KernelPratt.prime_8567281,
    ExposureEvolution.KernelPratt.prime_8567311]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 8637721 stop tail = true) :
    coverage 7252249 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks07
