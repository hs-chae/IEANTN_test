/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
/- New criterion-aware block constructor. The checked object records six primes
and an entire natural-number interval; it is independent of PrimeCover. -/
import E1Tertiary.LcmSurplus
namespace E1TwoTracks.TrackB
open Finset Nat Real
open E1Tertiary.LcmBase
set_option maxHeartbeats 3000000

structure Block where
  lo : ℕ
  hi : ℕ
  p0 : ℕ
  p1 : ℕ
  p2 : ℕ
  q0 : ℕ
  q1 : ℕ
  q2 : ℕ
  deriving Repr, DecidableEq

def Block.p (b : Block) : Fin 3 → ℕ := ![b.p0, b.p1, b.p2]
def Block.q (b : Block) : Fin 3 → ℕ := ![b.q0, b.q1, b.q2]
def Block.P (b : Block) : ℕ := b.p0 * b.p1 * b.p2
def Block.Q (b : Block) : ℕ := b.q0 * b.q1 * b.q2
def Block.A (b : Block) : ℕ := (b.q0 + 1) * (b.q1 + 1) * (b.q2 + 1)
def Block.D (b : Block) : ℕ := (b.p0 * (b.p0+1)) * (b.p1 * (b.p1+1)) * (b.p2 * (b.p2+1))
def Block.B (b : Block) : ℕ := (b.p0 * (b.p0+1)+1) * (b.p1 * (b.p1+1)+1) * (b.p2 * (b.p2+1)+1)

def Block.endpoint (b : Block) (n : ℕ) : Prop :=
  8 * (10*n+1) * b.A * b.D + 40 * (8*n+3) * b.B * b.P ≤
    10 * (8*n+3) * b.B * b.Q
instance (b : Block) (n : ℕ) : Decidable (b.endpoint n) := inferInstanceAs (Decidable (_ ≤ _))

def Block.valid (b : Block) : Prop :=
  1 ≤ b.lo ∧ b.lo ≤ b.hi ∧ b.hi < b.p0^2 ∧ b.p2 < b.q0 ∧ b.q2 < b.lo ∧
  b.p0.Prime ∧ b.p1.Prime ∧ b.p2.Prime ∧ b.q0.Prime ∧ b.q1.Prime ∧ b.q2.Prime ∧
  b.p0 < b.p1 ∧ b.p1 < b.p2 ∧ b.q0 < b.q1 ∧ b.q1 < b.q2 ∧
  b.endpoint b.lo ∧ b.endpoint b.hi
instance (b : Block) : Decidable b.valid := inferInstanceAs (Decidable (_ ∧ _))
def Block.check (b : Block) : Bool := decide b.valid

/-- Any affine inequality valid at both endpoints is valid between them. -/
theorem affine_endpoints {a b c d l h x : ℝ}
    (hl : a*l+b ≤ c*l+d) (hh : a*h+b ≤ c*h+d) (hxl : l ≤ x) (hxh : x ≤ h) :
    a*x+b ≤ c*x+d := by
  by_cases hac : a ≤ c
  · nlinarith [mul_nonneg (sub_nonneg.mpr hac) (sub_nonneg.mpr hxl)]
  · nlinarith [mul_nonneg (sub_nonneg.mpr (le_of_not_ge hac)) (sub_nonneg.mpr hxh)]

/-- Exact endpoint checks cover every natural integer in the complete block. -/
theorem Block.endpoint_sound (b : Block) (hb : b.valid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    8 * (10*(n:ℝ)+1) * b.A * b.D + 40 * (8*(n:ℝ)+3) * b.B * b.P ≤
      10 * (8*(n:ℝ)+3) * b.B * b.Q := by
  have hl : 8 * (10*(b.lo:ℝ)+1) * b.A * b.D + 40 * (8*(b.lo:ℝ)+3) * b.B * b.P ≤
      10 * (8*(b.lo:ℝ)+3) * b.B * b.Q := by exact_mod_cast hb.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hh : 8 * (10*(b.hi:ℝ)+1) * b.A * b.D + 40 * (8*(b.hi:ℝ)+3) * b.B * b.P ≤
      10 * (8*(b.hi:ℝ)+3) * b.B * b.Q := by exact_mod_cast hb.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2
  have hn1 : (b.lo:ℝ) ≤ n := by exact_mod_cast hnl
  have hn2 : (n:ℝ) ≤ b.hi := by exact_mod_cast hnh
  have ha := affine_endpoints
    (a := 80*(b.A:ℝ)*b.D + 320*b.B*b.P)
    (b := 8*(b.A:ℝ)*b.D + 120*b.B*b.P)
    (c := 80*(b.B:ℝ)*b.Q) (d := 30*(b.B:ℝ)*b.Q)
    (l := b.lo) (h := b.hi) (x := n) (by nlinarith [hl]) (by nlinarith [hh]) hn1 hn2
  nlinarith [ha]

/-- The endpoint certificate proves the original source criterion with surplus. -/
theorem Block.ratio_sound (b : Block) (hb : b.valid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    (1 + 1 / (10*(n:ℝ))) * ∏ i, (1 + (1:ℝ) / b.q i) ≤
      (∏ i, (1 + 1 / (b.p i * (b.p i+1):ℝ))) * (1 + 3 / (8*(n:ℝ))) *
      (1 - 4 * (∏ i, (b.p i:ℝ)) / ∏ i, (b.q i:ℝ)) := by
  rcases hb with ⟨hl, hle, hs, hpq, hql, hp0, hp1, hp2, hq0, hq1, hq2, hp01, hp12, hq01, hq12, helo, hehi⟩
  have hn : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by omega : 0 < b.lo) hnl)
  have hp0' : (0:ℝ) < b.p0 := by exact_mod_cast hp0.pos
  have hp1' : (0:ℝ) < b.p1 := by exact_mod_cast hp1.pos
  have hp2' : (0:ℝ) < b.p2 := by exact_mod_cast hp2.pos
  have hq0' : (0:ℝ) < b.q0 := by exact_mod_cast hq0.pos
  have hq1' : (0:ℝ) < b.q1 := by exact_mod_cast hq1.pos
  have hq2' : (0:ℝ) < b.q2 := by exact_mod_cast hq2.pos
  have hD : (0:ℝ) < b.D := by dsimp [Block.D]; push_cast; positivity
  have hQ : (0:ℝ) < b.Q := by dsimp [Block.Q]; push_cast; positivity
  have hratQ : (∏ i, (1 + (1:ℝ) / b.q i)) = (b.A:ℝ)/b.Q := by
    simp [Fin.prod_univ_three, Block.q, Block.A, Block.Q]
    field_simp
    <;> ring
  have hratP : (∏ i, (1 + 1 / (b.p i * (b.p i+1):ℝ))) = (b.B:ℝ)/b.D := by
    simp [Fin.prod_univ_three, Block.p, Block.B, Block.D]
    field_simp
    <;> ring
  have hprodP : (∏ i, (b.p i:ℝ)) = (b.P:ℝ) := by simp [Fin.prod_univ_three, Block.p, Block.P]
  have hprodQ : (∏ i, (b.q i:ℝ)) = (b.Q:ℝ) := by simp [Fin.prod_univ_three, Block.q, Block.Q]
  rw [hratQ, hratP, hprodP, hprodQ]
  have he := b.endpoint_sound ⟨hl, hle, hs, hpq, hql, hp0, hp1, hp2, hq0, hq1, hq2, hp01, hp12, hq01, hq12, helo, hehi⟩ n hnl hnh
  have he' : 8*(10*(n:ℝ)+1)*b.A*b.D ≤
      10*(8*(n:ℝ)+3)*b.B*b.Q - 40*(8*(n:ℝ)+3)*b.B*b.P := by linarith
  apply (mul_le_mul_iff_right₀ (show (0:ℝ) < 80*n*b.D*b.Q by positivity)).mp
  convert he' using 1 <;> (try rfl) <;> (try field_simp [ne_of_gt hn, ne_of_gt hD, ne_of_gt hQ]) <;> ring

noncomputable def Block.criterion (b : Block) (hb : b.valid) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) : Criterion where
  n := n
  hn := hb.1.trans hnl
  p := b.p
  hp := by rcases hb with ⟨_, _, _, _, _, h0, h1, h2, _⟩; intro i; fin_cases i <;> assumption
  hp_mono := by
    rcases hb with ⟨_, _, _, _, _, _, _, _, _, _, _, h01, h12, _⟩
    intro i j hij; fin_cases i <;> fin_cases j <;> simp_all [Block.p] <;> omega
  q := b.q
  hq := by rcases hb with ⟨_, _, _, _, _, _, _, _, h0, h1, h2, _⟩; intro i; fin_cases i <;> assumption
  hq_mono := by
    rcases hb with ⟨_, _, _, _, _, _, _, _, _, _, _, _, _, h01, h12, _⟩
    intro i j hij; fin_cases i <;> fin_cases j <;> simp_all [Block.q] <;> omega
  h_ord_1 := by
    have hs : (n:ℝ) < (b.p0:ℝ)^2 := by exact_mod_cast (lt_of_le_of_lt hnh hb.2.2.1)
    have hp : (0:ℝ) ≤ b.p0 := by positivity
    simpa [Block.p] using (Real.sqrt_lt (by positivity) hp).mpr hs
  h_ord_2 := hb.2.2.2.1
  h_ord_3 := hb.2.2.2.2.1.trans_le hnl
  h_crit := by
    have hh := b.ratio_sound hb n hnl hnh
    have hpos : (0:ℝ) ≤ ∏ i, (1 + (1:ℝ) / b.q i) := by positivity
    have hmul : (∏ i, (1 + (1:ℝ) / b.q i)) ≤
        (1 + 1 / (10*(n:ℝ))) * ∏ i, (1 + (1:ℝ) / b.q i) := by
      nlinarith [mul_nonneg (show (0:ℝ) ≤ 1 / (10*(n:ℝ)) by positivity) hpos]
    exact hmul.trans hh

/-- Every checked block gives actual smaller integers with a larger divisor sum. -/
theorem Block.sound (b : Block) (hb : b.check = true) (n : ℕ)
    (hnl : b.lo ≤ n) (hnh : n ≤ b.hi) :
    ∃ m : ℕ, m < Nat.lcmUpto n ∧
      (1 + 1/(10*(n:ℝ))) * (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m := by
  have hv : b.valid := of_decide_eq_true hb
  let c := b.criterion hv n hnl hnh
  refine ⟨c.M, c.M_lt, ?_⟩
  exact E1Tertiary.LcmSurplus.criterion_surplus c (by positivity) (b.ratio_sound hv n hnl hnh)

end E1TwoTracks.TrackB
