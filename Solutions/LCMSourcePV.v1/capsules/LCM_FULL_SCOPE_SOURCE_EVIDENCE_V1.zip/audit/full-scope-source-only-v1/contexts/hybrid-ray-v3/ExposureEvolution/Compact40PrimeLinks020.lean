import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks020
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_80449 : next 80449 = some 80761 := by
  have hl : (List.range ((257 * 80449 - 1) / 256 - 80449)).reverse =
      [313, 312, 311] ++ (List.range 311).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_80761]

theorem next_80761 : next 80761 = some 81071 := by
  have hl : (List.range ((257 * 80761 - 1) / 256 - 80761)).reverse =
      [314, 313, 312, 311, 310, 309] ++ (List.range 309).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_81071]

theorem next_81071 : next 81071 = some 81373 := by
  have hl : (List.range ((257 * 81071 - 1) / 256 - 81071)).reverse =
      [315, 314, 313, 312, 311, 310, 309, 308, 307, 306, 305, 304, 303, 302, 301] ++ (List.range 301).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_81373]

theorem next_81373 : next 81373 = some 81689 := by
  have hl : (List.range ((257 * 81373 - 1) / 256 - 81373)).reverse =
      [316, 315] ++ (List.range 315).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_81689]

theorem next_81689 : next 81689 = some 82007 := by
  have hl : (List.range ((257 * 81689 - 1) / 256 - 81689)).reverse =
      [318, 317] ++ (List.range 317).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_82007]

theorem next_82007 : next 82007 = some 82307 := by
  have hl : (List.range ((257 * 82007 - 1) / 256 - 82007)).reverse =
      [319, 318, 317, 316, 315, 314, 313, 312, 311, 310, 309, 308, 307, 306, 305, 304, 303, 302, 301, 300, 299] ++ (List.range 299).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_82307]

theorem next_82307 : next 82307 = some 82619 := by
  have hl : (List.range ((257 * 82307 - 1) / 256 - 82307)).reverse =
      [320, 319, 318, 317, 316, 315, 314, 313, 312, 311] ++ (List.range 311).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_82619]

theorem next_82619 : next 82619 = some 82939 := by
  have hl : (List.range ((257 * 82619 - 1) / 256 - 82619)).reverse =
      [321, 320, 319] ++ (List.range 319).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_82939]

theorem next_82939 : next 82939 = some 83257 := by
  have hl : (List.range ((257 * 82939 - 1) / 256 - 82939)).reverse =
      [322, 321, 320, 319, 318, 317] ++ (List.range 317).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_83257]

theorem next_83257 : next 83257 = some 83579 := by
  have hl : (List.range ((257 * 83257 - 1) / 256 - 83257)).reverse =
      [324, 323, 322, 321] ++ (List.range 321).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_83579]

theorem next_83579 : next 83579 = some 83903 := by
  have hl : (List.range ((257 * 83579 - 1) / 256 - 83579)).reverse =
      [325, 324, 323] ++ (List.range 323).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_83903]

theorem next_83903 : next 83903 = some 84229 := by
  have hl : (List.range ((257 * 83903 - 1) / 256 - 83903)).reverse =
      [326, 325] ++ (List.range 325).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_84229]

theorem next_84229 : next 84229 = some 84551 := by
  have hl : (List.range ((257 * 84229 - 1) / 256 - 84229)).reverse =
      [328, 327, 326, 325, 324, 323, 322, 321] ++ (List.range 321).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_84551]

theorem next_84551 : next 84551 = some 84871 := by
  have hl : (List.range ((257 * 84551 - 1) / 256 - 84551)).reverse =
      [329, 328, 327, 326, 325, 324, 323, 322, 321, 320, 319] ++ (List.range 319).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_84871]

theorem next_84871 : next 84871 = some 85201 := by
  have hl : (List.range ((257 * 84871 - 1) / 256 - 84871)).reverse =
      [330, 329] ++ (List.range 329).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_85201]

theorem next_85201 : next 85201 = some 85531 := by
  have hl : (List.range ((257 * 85201 - 1) / 256 - 85201)).reverse =
      [331, 330, 329] ++ (List.range 329).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_85531]

theorem next_85531 : next 85531 = some 85853 := by
  have hl : (List.range ((257 * 85531 - 1) / 256 - 85531)).reverse =
      [333, 332, 331, 330, 329, 328, 327, 326, 325, 324, 323, 322, 321] ++ (List.range 321).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_85853]

theorem next_85853 : next 85853 = some 86183 := by
  have hl : (List.range ((257 * 85853 - 1) / 256 - 85853)).reverse =
      [334, 333, 332, 331, 330, 329] ++ (List.range 329).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_86183]

theorem next_86183 : next 86183 = some 86509 := by
  have hl : (List.range ((257 * 86183 - 1) / 256 - 86183)).reverse =
      [335, 334, 333, 332, 331, 330, 329, 328, 327, 326, 325] ++ (List.range 325).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_86509]

theorem next_86509 : next 86509 = some 86843 := by
  have hl : (List.range ((257 * 86509 - 1) / 256 - 86509)).reverse =
      [336, 335, 334, 333] ++ (List.range 333).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_86843]

theorem next_86843 : next 86843 = some 87181 := by
  have hl : (List.range ((257 * 86843 - 1) / 256 - 86843)).reverse =
      [338, 337] ++ (List.range 337).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_87181]

theorem next_87181 : next 87181 = some 87517 := by
  have hl : (List.range ((257 * 87181 - 1) / 256 - 87181)).reverse =
      [339, 338, 337, 336, 335] ++ (List.range 335).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_87517]

theorem next_87517 : next 87517 = some 87853 := by
  have hl : (List.range ((257 * 87517 - 1) / 256 - 87517)).reverse =
      [340, 339, 338, 337, 336, 335] ++ (List.range 335).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_87853]

theorem next_87853 : next 87853 = some 88177 := by
  have hl : (List.range ((257 * 87853 - 1) / 256 - 87853)).reverse =
      [342, 341, 340, 339, 338, 337, 336, 335, 334, 333, 332, 331, 330, 329, 328, 327, 326, 325, 324, 323] ++ (List.range 323).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_88177]

theorem next_88177 : next 88177 = some 88513 := by
  have hl : (List.range ((257 * 88177 - 1) / 256 - 88177)).reverse =
      [343, 342, 341, 340, 339, 338, 337, 336, 335] ++ (List.range 335).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_88513]

theorem next_88513 : next 88513 = some 88853 := by
  have hl : (List.range ((257 * 88513 - 1) / 256 - 88513)).reverse =
      [344, 343, 342, 341, 340, 339] ++ (List.range 339).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_88853]

theorem next_88853 : next 88853 = some 89189 := by
  have hl : (List.range ((257 * 88853 - 1) / 256 - 88853)).reverse =
      [346, 345, 344, 343, 342, 341, 340, 339, 338, 337, 336, 335] ++ (List.range 335).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_89189]

theorem next_89189 : next 89189 = some 89533 := by
  have hl : (List.range ((257 * 89189 - 1) / 256 - 89189)).reverse =
      [347, 346, 345, 344, 343] ++ (List.range 343).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_89533]

theorem next_89533 : next 89533 = some 89867 := by
  have hl : (List.range ((257 * 89533 - 1) / 256 - 89533)).reverse =
      [348, 347, 346, 345, 344, 343, 342, 341, 340, 339, 338, 337, 336, 335, 334, 333] ++ (List.range 333).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_89867]

def primes : List ℕ := [80761, 81071, 81373, 81689, 82007, 82307, 82619, 82939, 83257, 83579, 83903, 84229, 84551, 84871, 85201, 85531, 85853, 86183, 86509, 86843, 87181, 87517, 87853, 88177, 88513, 88853, 89189, 89533, 89867]

theorem segment : run 60 80449 89693 =
    primes ++ run 31 89867 89693 := by
  rw [Compact40PrimeCompose256.step 59 80449 89693 80761
    (by decide +kernel) next_80449]
  rw [Compact40PrimeCompose256.step 58 80761 89693 81071
    (by decide +kernel) next_80761]
  rw [Compact40PrimeCompose256.step 57 81071 89693 81373
    (by decide +kernel) next_81071]
  rw [Compact40PrimeCompose256.step 56 81373 89693 81689
    (by decide +kernel) next_81373]
  rw [Compact40PrimeCompose256.step 55 81689 89693 82007
    (by decide +kernel) next_81689]
  rw [Compact40PrimeCompose256.step 54 82007 89693 82307
    (by decide +kernel) next_82007]
  rw [Compact40PrimeCompose256.step 53 82307 89693 82619
    (by decide +kernel) next_82307]
  rw [Compact40PrimeCompose256.step 52 82619 89693 82939
    (by decide +kernel) next_82619]
  rw [Compact40PrimeCompose256.step 51 82939 89693 83257
    (by decide +kernel) next_82939]
  rw [Compact40PrimeCompose256.step 50 83257 89693 83579
    (by decide +kernel) next_83257]
  rw [Compact40PrimeCompose256.step 49 83579 89693 83903
    (by decide +kernel) next_83579]
  rw [Compact40PrimeCompose256.step 48 83903 89693 84229
    (by decide +kernel) next_83903]
  rw [Compact40PrimeCompose256.step 47 84229 89693 84551
    (by decide +kernel) next_84229]
  rw [Compact40PrimeCompose256.step 46 84551 89693 84871
    (by decide +kernel) next_84551]
  rw [Compact40PrimeCompose256.step 45 84871 89693 85201
    (by decide +kernel) next_84871]
  rw [Compact40PrimeCompose256.step 44 85201 89693 85531
    (by decide +kernel) next_85201]
  rw [Compact40PrimeCompose256.step 43 85531 89693 85853
    (by decide +kernel) next_85531]
  rw [Compact40PrimeCompose256.step 42 85853 89693 86183
    (by decide +kernel) next_85853]
  rw [Compact40PrimeCompose256.step 41 86183 89693 86509
    (by decide +kernel) next_86183]
  rw [Compact40PrimeCompose256.step 40 86509 89693 86843
    (by decide +kernel) next_86509]
  rw [Compact40PrimeCompose256.step 39 86843 89693 87181
    (by decide +kernel) next_86843]
  rw [Compact40PrimeCompose256.step 38 87181 89693 87517
    (by decide +kernel) next_87181]
  rw [Compact40PrimeCompose256.step 37 87517 89693 87853
    (by decide +kernel) next_87517]
  rw [Compact40PrimeCompose256.step 36 87853 89693 88177
    (by decide +kernel) next_87853]
  rw [Compact40PrimeCompose256.step 35 88177 89693 88513
    (by decide +kernel) next_88177]
  rw [Compact40PrimeCompose256.step 34 88513 89693 88853
    (by decide +kernel) next_88513]
  rw [Compact40PrimeCompose256.step 33 88853 89693 89189
    (by decide +kernel) next_88853]
  rw [Compact40PrimeCompose256.step 32 89189 89693 89533
    (by decide +kernel) next_89189]
  rw [Compact40PrimeCompose256.step 31 89533 89693 89867
    (by decide +kernel) next_89533]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 89867 stop tail = true) :
    check 80449 stop (primes ++ tail) = true := by
  change check _ _ (80761 :: 81071 :: 81373 :: 81689 :: 82007 :: 82307 :: 82619 :: 82939 :: 83257 :: 83579 :: 83903 :: 84229 :: 84551 :: 84871 :: 85201 :: 85531 :: 85853 :: 86183 :: 86509 :: 86843 :: 87181 :: 87517 :: 87853 :: 88177 :: 88513 :: 88853 :: 89189 :: 89533 :: 89867 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_80761, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_81071, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_81373, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_81689, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_82007, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_82307, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_82619, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_82939, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_83257, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_83579, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_83903, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_84229, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_84551, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_84871, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_85201, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_85531, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_85853, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_86183, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_86509, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_86843, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_87181, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_87517, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_87853, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_88177, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_88513, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_88853, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_89189, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_89533, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_89867, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks020
