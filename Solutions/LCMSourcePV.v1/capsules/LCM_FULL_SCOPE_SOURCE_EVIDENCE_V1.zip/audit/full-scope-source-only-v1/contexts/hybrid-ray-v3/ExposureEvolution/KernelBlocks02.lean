import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks02
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨2128681, 2163840, 1471, 1481, 1483, 2128409, 2128591, 2128669⟩, 9⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1471,
    ExposureEvolution.KernelPratt.prime_1481,
    ExposureEvolution.KernelPratt.prime_1483,
    ExposureEvolution.KernelPratt.prime_2128409,
    ExposureEvolution.KernelPratt.prime_2128591,
    ExposureEvolution.KernelPratt.prime_2128669]

def block01 : Witness := ⟨⟨2163841, 2193360, 1481, 1483, 1487, 2163509, 2163527, 2163829⟩, 7⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1481,
    ExposureEvolution.KernelPratt.prime_1483,
    ExposureEvolution.KernelPratt.prime_1487,
    ExposureEvolution.KernelPratt.prime_2163509,
    ExposureEvolution.KernelPratt.prime_2163527,
    ExposureEvolution.KernelPratt.prime_2163829]

def block02 : Witness := ⟨⟨2193361, 2199288, 1483, 1487, 1489, 2193031, 2193041, 2193353⟩, 16⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1483,
    ExposureEvolution.KernelPratt.prime_1487,
    ExposureEvolution.KernelPratt.prime_1489,
    ExposureEvolution.KernelPratt.prime_2193031,
    ExposureEvolution.KernelPratt.prime_2193041,
    ExposureEvolution.KernelPratt.prime_2193353]

def block03 : Witness := ⟨⟨2199289, 2211168, 1487, 1489, 1493, 2198887, 2199061, 2199277⟩, 7⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1487,
    ExposureEvolution.KernelPratt.prime_1489,
    ExposureEvolution.KernelPratt.prime_1493,
    ExposureEvolution.KernelPratt.prime_2198887,
    ExposureEvolution.KernelPratt.prime_2199061,
    ExposureEvolution.KernelPratt.prime_2199277]

def block04 : Witness := ⟨⟨2211169, 2217120, 1489, 1493, 1499, 2210723, 2210777, 2211161⟩, 8⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1489,
    ExposureEvolution.KernelPratt.prime_1493,
    ExposureEvolution.KernelPratt.prime_1499,
    ExposureEvolution.KernelPratt.prime_2210723,
    ExposureEvolution.KernelPratt.prime_2210777,
    ExposureEvolution.KernelPratt.prime_2211161]

def block05 : Witness := ⟨⟨2217121, 2229048, 1493, 1499, 1511, 2216887, 2216957, 2217113⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1493,
    ExposureEvolution.KernelPratt.prime_1499,
    ExposureEvolution.KernelPratt.prime_1511,
    ExposureEvolution.KernelPratt.prime_2216887,
    ExposureEvolution.KernelPratt.prime_2216957,
    ExposureEvolution.KernelPratt.prime_2217113]

def block06 : Witness := ⟨⟨2229049, 2247000, 1499, 1511, 1523, 2228657, 2228923, 2229043⟩, 7⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1499,
    ExposureEvolution.KernelPratt.prime_1511,
    ExposureEvolution.KernelPratt.prime_1523,
    ExposureEvolution.KernelPratt.prime_2228657,
    ExposureEvolution.KernelPratt.prime_2228923,
    ExposureEvolution.KernelPratt.prime_2229043]

def block07 : Witness := ⟨⟨2247001, 2283120, 1511, 1523, 1531, 2246851, 2246927, 2246999⟩, 8⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1511,
    ExposureEvolution.KernelPratt.prime_1523,
    ExposureEvolution.KernelPratt.prime_1531,
    ExposureEvolution.KernelPratt.prime_2246851,
    ExposureEvolution.KernelPratt.prime_2246927,
    ExposureEvolution.KernelPratt.prime_2246999]

def block08 : Witness := ⟨⟨2283121, 2319528, 1523, 1531, 1543, 2282627, 2282899, 2283109⟩, 10⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1523,
    ExposureEvolution.KernelPratt.prime_1531,
    ExposureEvolution.KernelPratt.prime_1543,
    ExposureEvolution.KernelPratt.prime_2282627,
    ExposureEvolution.KernelPratt.prime_2282899,
    ExposureEvolution.KernelPratt.prime_2283109]

def block09 : Witness := ⟨⟨2319529, 2343960, 1531, 1543, 1549, 2319241, 2319323, 2319521⟩, 13⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1531,
    ExposureEvolution.KernelPratt.prime_1543,
    ExposureEvolution.KernelPratt.prime_1549,
    ExposureEvolution.KernelPratt.prime_2319241,
    ExposureEvolution.KernelPratt.prime_2319323,
    ExposureEvolution.KernelPratt.prime_2319521]

def block10 : Witness := ⟨⟨2343961, 2380848, 1543, 1549, 1553, 2343763, 2343857, 2343949⟩, 6⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1543,
    ExposureEvolution.KernelPratt.prime_1549,
    ExposureEvolution.KernelPratt.prime_1553,
    ExposureEvolution.KernelPratt.prime_2343763,
    ExposureEvolution.KernelPratt.prime_2343857,
    ExposureEvolution.KernelPratt.prime_2343949]

def block11 : Witness := ⟨⟨2380849, 2399400, 1549, 1553, 1559, 2380627, 2380771, 2380841⟩, 7⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1549,
    ExposureEvolution.KernelPratt.prime_1553,
    ExposureEvolution.KernelPratt.prime_1559,
    ExposureEvolution.KernelPratt.prime_2380627,
    ExposureEvolution.KernelPratt.prime_2380771,
    ExposureEvolution.KernelPratt.prime_2380841]

def block12 : Witness := ⟨⟨2399401, 2411808, 1553, 1559, 1567, 2399087, 2399297, 2399399⟩, 10⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1553,
    ExposureEvolution.KernelPratt.prime_1559,
    ExposureEvolution.KernelPratt.prime_1567,
    ExposureEvolution.KernelPratt.prime_2399087,
    ExposureEvolution.KernelPratt.prime_2399297,
    ExposureEvolution.KernelPratt.prime_2399399]

def block13 : Witness := ⟨⟨2411809, 2430480, 1559, 1567, 1571, 2411693, 2411729, 2411797⟩, 7⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1559,
    ExposureEvolution.KernelPratt.prime_1567,
    ExposureEvolution.KernelPratt.prime_1571,
    ExposureEvolution.KernelPratt.prime_2411693,
    ExposureEvolution.KernelPratt.prime_2411729,
    ExposureEvolution.KernelPratt.prime_2411797]

def block14 : Witness := ⟨⟨2430481, 2455488, 1567, 1571, 1579, 2430061, 2430427, 2430469⟩, 9⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1567,
    ExposureEvolution.KernelPratt.prime_1571,
    ExposureEvolution.KernelPratt.prime_1579,
    ExposureEvolution.KernelPratt.prime_2430061,
    ExposureEvolution.KernelPratt.prime_2430427,
    ExposureEvolution.KernelPratt.prime_2430469]

def block15 : Witness := ⟨⟨2455489, 2468040, 1571, 1579, 1583, 2455207, 2455373, 2455487⟩, 10⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1571,
    ExposureEvolution.KernelPratt.prime_1579,
    ExposureEvolution.KernelPratt.prime_1583,
    ExposureEvolution.KernelPratt.prime_2455207,
    ExposureEvolution.KernelPratt.prime_2455373,
    ExposureEvolution.KernelPratt.prime_2455487]

def block16 : Witness := ⟨⟨2468041, 2493240, 1579, 1583, 1597, 2467867, 2467943, 2468027⟩, 8⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1579,
    ExposureEvolution.KernelPratt.prime_1583,
    ExposureEvolution.KernelPratt.prime_1597,
    ExposureEvolution.KernelPratt.prime_2467867,
    ExposureEvolution.KernelPratt.prime_2467943,
    ExposureEvolution.KernelPratt.prime_2468027]

def block17 : Witness := ⟨⟨2493241, 2505888, 1583, 1597, 1601, 2492813, 2492843, 2493233⟩, 7⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1583,
    ExposureEvolution.KernelPratt.prime_1597,
    ExposureEvolution.KernelPratt.prime_1601,
    ExposureEvolution.KernelPratt.prime_2492813,
    ExposureEvolution.KernelPratt.prime_2492843,
    ExposureEvolution.KernelPratt.prime_2493233]

def block18 : Witness := ⟨⟨2505889, 2550408, 1597, 1601, 1607, 2505487, 2505859, 2505863⟩, 10⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1597,
    ExposureEvolution.KernelPratt.prime_1601,
    ExposureEvolution.KernelPratt.prime_1607,
    ExposureEvolution.KernelPratt.prime_2505487,
    ExposureEvolution.KernelPratt.prime_2505859,
    ExposureEvolution.KernelPratt.prime_2505863]

def block19 : Witness := ⟨⟨2550409, 2563200, 1601, 1607, 1609, 2549879, 2550139, 2550407⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1601,
    ExposureEvolution.KernelPratt.prime_1607,
    ExposureEvolution.KernelPratt.prime_1609,
    ExposureEvolution.KernelPratt.prime_2549879,
    ExposureEvolution.KernelPratt.prime_2550139,
    ExposureEvolution.KernelPratt.prime_2550407]

def block20 : Witness := ⟨⟨2563201, 2582448, 1607, 1609, 1613, 2562907, 2562977, 2563199⟩, 14⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1607,
    ExposureEvolution.KernelPratt.prime_1609,
    ExposureEvolution.KernelPratt.prime_1613,
    ExposureEvolution.KernelPratt.prime_2562907,
    ExposureEvolution.KernelPratt.prime_2562977,
    ExposureEvolution.KernelPratt.prime_2563199]

def block21 : Witness := ⟨⟨2582449, 2588880, 1609, 1613, 1619, 2582077, 2582093, 2582443⟩, 7⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1609,
    ExposureEvolution.KernelPratt.prime_1613,
    ExposureEvolution.KernelPratt.prime_1619,
    ExposureEvolution.KernelPratt.prime_2582077,
    ExposureEvolution.KernelPratt.prime_2582093,
    ExposureEvolution.KernelPratt.prime_2582443]

def block22 : Witness := ⟨⟨2588881, 2601768, 1613, 1619, 1621, 2588477, 2588767, 2588869⟩, 11⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1613,
    ExposureEvolution.KernelPratt.prime_1619,
    ExposureEvolution.KernelPratt.prime_1621,
    ExposureEvolution.KernelPratt.prime_2588477,
    ExposureEvolution.KernelPratt.prime_2588767,
    ExposureEvolution.KernelPratt.prime_2588869]

def block23 : Witness := ⟨⟨2601769, 2621160, 1619, 1621, 1627, 2601337, 2601601, 2601763⟩, 12⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1619,
    ExposureEvolution.KernelPratt.prime_1621,
    ExposureEvolution.KernelPratt.prime_1627,
    ExposureEvolution.KernelPratt.prime_2601337,
    ExposureEvolution.KernelPratt.prime_2601601,
    ExposureEvolution.KernelPratt.prime_2601763]

def block24 : Witness := ⟨⟨2621161, 2627640, 1621, 1627, 1637, 2621033, 2621119, 2621159⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1621,
    ExposureEvolution.KernelPratt.prime_1627,
    ExposureEvolution.KernelPratt.prime_1637,
    ExposureEvolution.KernelPratt.prime_2621033,
    ExposureEvolution.KernelPratt.prime_2621119,
    ExposureEvolution.KernelPratt.prime_2621159]

def block25 : Witness := ⟨⟨2627641, 2647128, 1627, 1637, 1657, 2627243, 2627357, 2627627⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1627,
    ExposureEvolution.KernelPratt.prime_1637,
    ExposureEvolution.KernelPratt.prime_1657,
    ExposureEvolution.KernelPratt.prime_2627243,
    ExposureEvolution.KernelPratt.prime_2627357,
    ExposureEvolution.KernelPratt.prime_2627627]

def block26 : Witness := ⟨⟨2647129, 2679768, 1637, 1657, 1663, 2646793, 2647003, 2647111⟩, 9⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1637,
    ExposureEvolution.KernelPratt.prime_1657,
    ExposureEvolution.KernelPratt.prime_1663,
    ExposureEvolution.KernelPratt.prime_2646793,
    ExposureEvolution.KernelPratt.prime_2647003,
    ExposureEvolution.KernelPratt.prime_2647111]

def block27 : Witness := ⟨⟨2679769, 2745648, 1657, 1663, 1667, 2679407, 2679433, 2679763⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1657,
    ExposureEvolution.KernelPratt.prime_1663,
    ExposureEvolution.KernelPratt.prime_1667,
    ExposureEvolution.KernelPratt.prime_2679407,
    ExposureEvolution.KernelPratt.prime_2679433,
    ExposureEvolution.KernelPratt.prime_2679763]

def block28 : Witness := ⟨⟨2745649, 2765568, 1663, 1667, 1669, 2745503, 2745529, 2745643⟩, 9⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1663,
    ExposureEvolution.KernelPratt.prime_1667,
    ExposureEvolution.KernelPratt.prime_1669,
    ExposureEvolution.KernelPratt.prime_2745503,
    ExposureEvolution.KernelPratt.prime_2745529,
    ExposureEvolution.KernelPratt.prime_2745643]

def block29 : Witness := ⟨⟨2765569, 2778888, 1667, 1669, 1693, 2765173, 2765383, 2765551⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1667,
    ExposureEvolution.KernelPratt.prime_1669,
    ExposureEvolution.KernelPratt.prime_1693,
    ExposureEvolution.KernelPratt.prime_2765173,
    ExposureEvolution.KernelPratt.prime_2765383,
    ExposureEvolution.KernelPratt.prime_2765551]

def block30 : Witness := ⟨⟨2778889, 2785560, 1669, 1693, 1697, 2778583, 2778863, 2778877⟩, 11⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1669,
    ExposureEvolution.KernelPratt.prime_1693,
    ExposureEvolution.KernelPratt.prime_1697,
    ExposureEvolution.KernelPratt.prime_2778583,
    ExposureEvolution.KernelPratt.prime_2778863,
    ExposureEvolution.KernelPratt.prime_2778877]

def block31 : Witness := ⟨⟨2785561, 2866248, 1693, 1697, 1699, 2785087, 2785469, 2785513⟩, 12⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1693,
    ExposureEvolution.KernelPratt.prime_1697,
    ExposureEvolution.KernelPratt.prime_1699,
    ExposureEvolution.KernelPratt.prime_2785087,
    ExposureEvolution.KernelPratt.prime_2785469,
    ExposureEvolution.KernelPratt.prime_2785513]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 2866249 stop tail = true) :
    coverage 2128681 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks02
