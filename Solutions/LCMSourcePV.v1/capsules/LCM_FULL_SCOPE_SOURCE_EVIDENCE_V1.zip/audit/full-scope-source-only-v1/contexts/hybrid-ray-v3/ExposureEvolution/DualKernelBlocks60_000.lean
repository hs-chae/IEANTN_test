import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_000
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨5000000, 5004168, 2237, 2239, 2243, 4932619, 4932757, 4932827⟩, 11⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2237,
    ExposureEvolution.Compact40Pratt.prime_2239,
    ExposureEvolution.Compact40Pratt.prime_2243,
    ExposureEvolution.Compact40Pratt.prime_4932619,
    ExposureEvolution.Compact40Pratt.prime_4932757,
    ExposureEvolution.Compact40Pratt.prime_4932827]

def block01 : Witness := ⟨⟨5004169, 5013120, 2239, 2243, 2251, 5003983, 5004031, 5004157⟩, 9⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2239,
    ExposureEvolution.Compact40Pratt.prime_2243,
    ExposureEvolution.Compact40Pratt.prime_2251,
    ExposureEvolution.Compact40Pratt.prime_5003983,
    ExposureEvolution.Compact40Pratt.prime_5004031,
    ExposureEvolution.Compact40Pratt.prime_5004157]

def block02 : Witness := ⟨⟨5013121, 5031048, 2243, 2251, 2267, 5012831, 5012981, 5013119⟩, 12⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2243,
    ExposureEvolution.Compact40Pratt.prime_2251,
    ExposureEvolution.Compact40Pratt.prime_2267,
    ExposureEvolution.Compact40Pratt.prime_5012831,
    ExposureEvolution.Compact40Pratt.prime_5012981,
    ExposureEvolution.Compact40Pratt.prime_5013119]

def block03 : Witness := ⟨⟨5031049, 5067000, 2251, 2267, 2269, 5030797, 5030807, 5031041⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2251,
    ExposureEvolution.Compact40Pratt.prime_2267,
    ExposureEvolution.Compact40Pratt.prime_2269,
    ExposureEvolution.Compact40Pratt.prime_5030797,
    ExposureEvolution.Compact40Pratt.prime_5030807,
    ExposureEvolution.Compact40Pratt.prime_5031041]

def block04 : Witness := ⟨⟨5067001, 5139288, 2267, 2269, 2273, 5066491, 5066837, 5066993⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2267,
    ExposureEvolution.Compact40Pratt.prime_2269,
    ExposureEvolution.Compact40Pratt.prime_2273,
    ExposureEvolution.Compact40Pratt.prime_5066491,
    ExposureEvolution.Compact40Pratt.prime_5066837,
    ExposureEvolution.Compact40Pratt.prime_5066993]

def block05 : Witness := ⟨⟨5139289, 5148360, 2269, 2273, 2281, 5139161, 5139203, 5139271⟩, 10⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2269,
    ExposureEvolution.Compact40Pratt.prime_2273,
    ExposureEvolution.Compact40Pratt.prime_2281,
    ExposureEvolution.Compact40Pratt.prime_5139161,
    ExposureEvolution.Compact40Pratt.prime_5139203,
    ExposureEvolution.Compact40Pratt.prime_5139271]

def block06 : Witness := ⟨⟨5148361, 5166528, 2273, 2281, 2287, 5147951, 5148287, 5148359⟩, 7⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2273,
    ExposureEvolution.Compact40Pratt.prime_2281,
    ExposureEvolution.Compact40Pratt.prime_2287,
    ExposureEvolution.Compact40Pratt.prime_5147951,
    ExposureEvolution.Compact40Pratt.prime_5148287,
    ExposureEvolution.Compact40Pratt.prime_5148359]

def block07 : Witness := ⟨⟨5166529, 5202960, 2281, 2287, 2293, 5166071, 5166383, 5166527⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2281,
    ExposureEvolution.Compact40Pratt.prime_2287,
    ExposureEvolution.Compact40Pratt.prime_2293,
    ExposureEvolution.Compact40Pratt.prime_5166071,
    ExposureEvolution.Compact40Pratt.prime_5166383,
    ExposureEvolution.Compact40Pratt.prime_5166527]

def block08 : Witness := ⟨⟨5202961, 5230368, 2287, 2293, 2297, 5202503, 5202569, 5202917⟩, 11⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2287,
    ExposureEvolution.Compact40Pratt.prime_2293,
    ExposureEvolution.Compact40Pratt.prime_2297,
    ExposureEvolution.Compact40Pratt.prime_5202503,
    ExposureEvolution.Compact40Pratt.prime_5202569,
    ExposureEvolution.Compact40Pratt.prime_5202917]

def block09 : Witness := ⟨⟨5230369, 5257848, 2293, 2297, 2309, 5229871, 5229989, 5230367⟩, 9⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2293,
    ExposureEvolution.Compact40Pratt.prime_2297,
    ExposureEvolution.Compact40Pratt.prime_2309,
    ExposureEvolution.Compact40Pratt.prime_5229871,
    ExposureEvolution.Compact40Pratt.prime_5229989,
    ExposureEvolution.Compact40Pratt.prime_5230367]

def block10 : Witness := ⟨⟨5257849, 5276208, 2297, 2309, 2311, 5257531, 5257723, 5257829⟩, 8⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2297,
    ExposureEvolution.Compact40Pratt.prime_2309,
    ExposureEvolution.Compact40Pratt.prime_2311,
    ExposureEvolution.Compact40Pratt.prime_5257531,
    ExposureEvolution.Compact40Pratt.prime_5257723,
    ExposureEvolution.Compact40Pratt.prime_5257829]

def block11 : Witness := ⟨⟨5276209, 5331480, 2309, 2311, 2333, 5275813, 5276093, 5276207⟩, 8⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2309,
    ExposureEvolution.Compact40Pratt.prime_2311,
    ExposureEvolution.Compact40Pratt.prime_2333,
    ExposureEvolution.Compact40Pratt.prime_5275813,
    ExposureEvolution.Compact40Pratt.prime_5276093,
    ExposureEvolution.Compact40Pratt.prime_5276207]

def block12 : Witness := ⟨⟨5331481, 5340720, 2311, 2333, 2339, 5331199, 5331379, 5331479⟩, 8⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2311,
    ExposureEvolution.Compact40Pratt.prime_2333,
    ExposureEvolution.Compact40Pratt.prime_2339,
    ExposureEvolution.Compact40Pratt.prime_5331199,
    ExposureEvolution.Compact40Pratt.prime_5331379,
    ExposureEvolution.Compact40Pratt.prime_5331479]

def block13 : Witness := ⟨⟨5340721, 5442888, 2333, 2339, 2341, 5340343, 5340421, 5340707⟩, 7⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2333,
    ExposureEvolution.Compact40Pratt.prime_2339,
    ExposureEvolution.Compact40Pratt.prime_2341,
    ExposureEvolution.Compact40Pratt.prime_5340343,
    ExposureEvolution.Compact40Pratt.prime_5340421,
    ExposureEvolution.Compact40Pratt.prime_5340707]

def block14 : Witness := ⟨⟨5442889, 5470920, 2339, 2341, 2347, 5442581, 5442637, 5442859⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2339,
    ExposureEvolution.Compact40Pratt.prime_2341,
    ExposureEvolution.Compact40Pratt.prime_2347,
    ExposureEvolution.Compact40Pratt.prime_5442581,
    ExposureEvolution.Compact40Pratt.prime_5442637,
    ExposureEvolution.Compact40Pratt.prime_5442859]

def block15 : Witness := ⟨⟨5470921, 5480280, 2341, 2347, 2351, 5470627, 5470681, 5470909⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2341,
    ExposureEvolution.Compact40Pratt.prime_2347,
    ExposureEvolution.Compact40Pratt.prime_2351,
    ExposureEvolution.Compact40Pratt.prime_5470627,
    ExposureEvolution.Compact40Pratt.prime_5470681,
    ExposureEvolution.Compact40Pratt.prime_5470909]

def block16 : Witness := ⟨⟨5480281, 5508408, 2347, 2351, 2357, 5479841, 5480063, 5480269⟩, 9⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2347,
    ExposureEvolution.Compact40Pratt.prime_2351,
    ExposureEvolution.Compact40Pratt.prime_2357,
    ExposureEvolution.Compact40Pratt.prime_5479841,
    ExposureEvolution.Compact40Pratt.prime_5480063,
    ExposureEvolution.Compact40Pratt.prime_5480269]

def block17 : Witness := ⟨⟨5508409, 5527200, 2351, 2357, 2371, 5508023, 5508179, 5508401⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2351,
    ExposureEvolution.Compact40Pratt.prime_2357,
    ExposureEvolution.Compact40Pratt.prime_2371,
    ExposureEvolution.Compact40Pratt.prime_5508023,
    ExposureEvolution.Compact40Pratt.prime_5508179,
    ExposureEvolution.Compact40Pratt.prime_5508401]

def block18 : Witness := ⟨⟨5527201, 5555448, 2357, 2371, 2377, 5526743, 5527013, 5527189⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2357,
    ExposureEvolution.Compact40Pratt.prime_2371,
    ExposureEvolution.Compact40Pratt.prime_2377,
    ExposureEvolution.Compact40Pratt.prime_5526743,
    ExposureEvolution.Compact40Pratt.prime_5527013,
    ExposureEvolution.Compact40Pratt.prime_5527189]

def block19 : Witness := ⟨⟨5555449, 5621640, 2371, 2377, 2381, 5555059, 5555117, 5555401⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2371,
    ExposureEvolution.Compact40Pratt.prime_2377,
    ExposureEvolution.Compact40Pratt.prime_2381,
    ExposureEvolution.Compact40Pratt.prime_5555059,
    ExposureEvolution.Compact40Pratt.prime_5555117,
    ExposureEvolution.Compact40Pratt.prime_5555401]

def block20 : Witness := ⟨⟨5621641, 5650128, 2377, 2381, 2383, 5621267, 5621327, 5621617⟩, 11⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2377,
    ExposureEvolution.Compact40Pratt.prime_2381,
    ExposureEvolution.Compact40Pratt.prime_2383,
    ExposureEvolution.Compact40Pratt.prime_5621267,
    ExposureEvolution.Compact40Pratt.prime_5621327,
    ExposureEvolution.Compact40Pratt.prime_5621617]

def block21 : Witness := ⟨⟨5650129, 5669160, 2381, 2383, 2389, 5649769, 5649877, 5650121⟩, 12⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2381,
    ExposureEvolution.Compact40Pratt.prime_2383,
    ExposureEvolution.Compact40Pratt.prime_2389,
    ExposureEvolution.Compact40Pratt.prime_5649769,
    ExposureEvolution.Compact40Pratt.prime_5649877,
    ExposureEvolution.Compact40Pratt.prime_5650121]

def block22 : Witness := ⟨⟨5669161, 5678688, 2383, 2389, 2393, 5668577, 5668609, 5669159⟩, 8⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2383,
    ExposureEvolution.Compact40Pratt.prime_2389,
    ExposureEvolution.Compact40Pratt.prime_2393,
    ExposureEvolution.Compact40Pratt.prime_5668577,
    ExposureEvolution.Compact40Pratt.prime_5668609,
    ExposureEvolution.Compact40Pratt.prime_5669159]

def block23 : Witness := ⟨⟨5678689, 5707320, 2389, 2393, 2399, 5678227, 5678483, 5678669⟩, 10⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2389,
    ExposureEvolution.Compact40Pratt.prime_2393,
    ExposureEvolution.Compact40Pratt.prime_2399,
    ExposureEvolution.Compact40Pratt.prime_5678227,
    ExposureEvolution.Compact40Pratt.prime_5678483,
    ExposureEvolution.Compact40Pratt.prime_5678669]

def block24 : Witness := ⟨⟨5707321, 5726448, 2393, 2399, 2411, 5707033, 5707073, 5707319⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2393,
    ExposureEvolution.Compact40Pratt.prime_2399,
    ExposureEvolution.Compact40Pratt.prime_2411,
    ExposureEvolution.Compact40Pratt.prime_5707033,
    ExposureEvolution.Compact40Pratt.prime_5707073,
    ExposureEvolution.Compact40Pratt.prime_5707319]

def block25 : Witness := ⟨⟨5726449, 5755200, 2399, 2411, 2417, 5725943, 5726359, 5726447⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2399,
    ExposureEvolution.Compact40Pratt.prime_2411,
    ExposureEvolution.Compact40Pratt.prime_2417,
    ExposureEvolution.Compact40Pratt.prime_5725943,
    ExposureEvolution.Compact40Pratt.prime_5726359,
    ExposureEvolution.Compact40Pratt.prime_5726447]

def block26 : Witness := ⟨⟨5755201, 5812920, 2411, 2417, 2423, 5754757, 5755049, 5755187⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2411,
    ExposureEvolution.Compact40Pratt.prime_2417,
    ExposureEvolution.Compact40Pratt.prime_2423,
    ExposureEvolution.Compact40Pratt.prime_5754757,
    ExposureEvolution.Compact40Pratt.prime_5755049,
    ExposureEvolution.Compact40Pratt.prime_5755187]

def block27 : Witness := ⟨⟨5812921, 5841888, 2417, 2423, 2437, 5812633, 5812823, 5812907⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2417,
    ExposureEvolution.Compact40Pratt.prime_2423,
    ExposureEvolution.Compact40Pratt.prime_2437,
    ExposureEvolution.Compact40Pratt.prime_5812633,
    ExposureEvolution.Compact40Pratt.prime_5812823,
    ExposureEvolution.Compact40Pratt.prime_5812907]

def block28 : Witness := ⟨⟨5841889, 5870928, 2423, 2437, 2441, 5841481, 5841571, 5841883⟩, 12⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2423,
    ExposureEvolution.Compact40Pratt.prime_2437,
    ExposureEvolution.Compact40Pratt.prime_2441,
    ExposureEvolution.Compact40Pratt.prime_5841481,
    ExposureEvolution.Compact40Pratt.prime_5841571,
    ExposureEvolution.Compact40Pratt.prime_5841883]

def block29 : Witness := ⟨⟨5870929, 5938968, 2437, 2441, 2447, 5870467, 5870561, 5870927⟩, 12⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2437,
    ExposureEvolution.Compact40Pratt.prime_2441,
    ExposureEvolution.Compact40Pratt.prime_2447,
    ExposureEvolution.Compact40Pratt.prime_5870467,
    ExposureEvolution.Compact40Pratt.prime_5870561,
    ExposureEvolution.Compact40Pratt.prime_5870927]

def block30 : Witness := ⟨⟨5938969, 5958480, 2441, 2447, 2459, 5938663, 5938711, 5938957⟩, 9⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2441,
    ExposureEvolution.Compact40Pratt.prime_2447,
    ExposureEvolution.Compact40Pratt.prime_2459,
    ExposureEvolution.Compact40Pratt.prime_5938663,
    ExposureEvolution.Compact40Pratt.prime_5938711,
    ExposureEvolution.Compact40Pratt.prime_5938957]

def block31 : Witness := ⟨⟨5958481, 5987808, 2447, 2459, 2467, 5957971, 5958319, 5958473⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2447,
    ExposureEvolution.Compact40Pratt.prime_2459,
    ExposureEvolution.Compact40Pratt.prime_2467,
    ExposureEvolution.Compact40Pratt.prime_5957971,
    ExposureEvolution.Compact40Pratt.prime_5958319,
    ExposureEvolution.Compact40Pratt.prime_5958473]

def block32 : Witness := ⟨⟨5987809, 6046680, 2459, 2467, 2473, 5987447, 5987551, 5987803⟩, 8⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2459,
    ExposureEvolution.Compact40Pratt.prime_2467,
    ExposureEvolution.Compact40Pratt.prime_2473,
    ExposureEvolution.Compact40Pratt.prime_5987447,
    ExposureEvolution.Compact40Pratt.prime_5987551,
    ExposureEvolution.Compact40Pratt.prime_5987803]

def block33 : Witness := ⟨⟨6046681, 6086088, 2467, 2473, 2477, 6046283, 6046349, 6046669⟩, 7⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2467,
    ExposureEvolution.Compact40Pratt.prime_2473,
    ExposureEvolution.Compact40Pratt.prime_2477,
    ExposureEvolution.Compact40Pratt.prime_6046283,
    ExposureEvolution.Compact40Pratt.prime_6046349,
    ExposureEvolution.Compact40Pratt.prime_6046669]

def block34 : Witness := ⟨⟨6086089, 6115728, 2473, 2477, 2503, 6085627, 6085741, 6086063⟩, 8⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2473,
    ExposureEvolution.Compact40Pratt.prime_2477,
    ExposureEvolution.Compact40Pratt.prime_2503,
    ExposureEvolution.Compact40Pratt.prime_6085627,
    ExposureEvolution.Compact40Pratt.prime_6085741,
    ExposureEvolution.Compact40Pratt.prime_6086063]

def block35 : Witness := ⟨⟨6115729, 6135528, 2477, 2503, 2521, 6115367, 6115691, 6115717⟩, 8⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2477,
    ExposureEvolution.Compact40Pratt.prime_2503,
    ExposureEvolution.Compact40Pratt.prime_2521,
    ExposureEvolution.Compact40Pratt.prime_6115367,
    ExposureEvolution.Compact40Pratt.prime_6115691,
    ExposureEvolution.Compact40Pratt.prime_6115717]

def block36 : Witness := ⟨⟨6135529, 6265008, 2503, 2521, 2531, 6135047, 6135491, 6135523⟩, 11⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2503,
    ExposureEvolution.Compact40Pratt.prime_2521,
    ExposureEvolution.Compact40Pratt.prime_2531,
    ExposureEvolution.Dual60PrimeSupplementV1.prime_6135047,
    ExposureEvolution.Dual60PrimeSupplementV1.prime_6135491,
    ExposureEvolution.Compact40Pratt.prime_6135523]

def block37 : Witness := ⟨⟨6265009, 6355440, 2521, 2531, 2539, 6264571, 6264793, 6265001⟩, 7⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2521,
    ExposureEvolution.Compact40Pratt.prime_2531,
    ExposureEvolution.Compact40Pratt.prime_2539,
    ExposureEvolution.Compact40Pratt.prime_6264571,
    ExposureEvolution.Compact40Pratt.prime_6264793,
    ExposureEvolution.Compact40Pratt.prime_6265001]

def block38 : Witness := ⟨⟨6355441, 6405960, 2531, 2539, 2543, 6354967, 6355103, 6355381⟩, 10⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2531,
    ExposureEvolution.Compact40Pratt.prime_2539,
    ExposureEvolution.Compact40Pratt.prime_2543,
    ExposureEvolution.Compact40Pratt.prime_6354967,
    ExposureEvolution.Compact40Pratt.prime_6355103,
    ExposureEvolution.Compact40Pratt.prime_6355381]

def block39 : Witness := ⟨⟨6405961, 6446520, 2539, 2543, 2549, 6405761, 6405929, 6405943⟩, 7⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2539,
    ExposureEvolution.Compact40Pratt.prime_2543,
    ExposureEvolution.Compact40Pratt.prime_2549,
    ExposureEvolution.Compact40Pratt.prime_6405761,
    ExposureEvolution.Compact40Pratt.prime_6405929,
    ExposureEvolution.Compact40Pratt.prime_6405943]

def block40 : Witness := ⟨⟨6446521, 6466848, 2543, 2549, 2551, 6446051, 6446183, 6446513⟩, 12⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2543,
    ExposureEvolution.Compact40Pratt.prime_2549,
    ExposureEvolution.Compact40Pratt.prime_2551,
    ExposureEvolution.Compact40Pratt.prime_6446051,
    ExposureEvolution.Compact40Pratt.prime_6446183,
    ExposureEvolution.Compact40Pratt.prime_6446513]

def block41 : Witness := ⟨⟨6466849, 6497400, 2549, 2551, 2557, 6466501, 6466711, 6466847⟩, 7⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2549,
    ExposureEvolution.Compact40Pratt.prime_2551,
    ExposureEvolution.Compact40Pratt.prime_2557,
    ExposureEvolution.Compact40Pratt.prime_6466501,
    ExposureEvolution.Compact40Pratt.prime_6466711,
    ExposureEvolution.Compact40Pratt.prime_6466847]

def block42 : Witness := ⟨⟨6497401, 6507600, 2551, 2557, 2579, 6497087, 6497167, 6497399⟩, 12⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2551,
    ExposureEvolution.Compact40Pratt.prime_2557,
    ExposureEvolution.Compact40Pratt.prime_2579,
    ExposureEvolution.Compact40Pratt.prime_6497087,
    ExposureEvolution.Compact40Pratt.prime_6497167,
    ExposureEvolution.Compact40Pratt.prime_6497399]

def block43 : Witness := ⟨⟨6507601, 6538248, 2557, 2579, 2591, 6507167, 6507407, 6507587⟩, 9⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2557,
    ExposureEvolution.Compact40Pratt.prime_2579,
    ExposureEvolution.Compact40Pratt.prime_2591,
    ExposureEvolution.Compact40Pratt.prime_6507167,
    ExposureEvolution.Compact40Pratt.prime_6507407,
    ExposureEvolution.Compact40Pratt.prime_6507587]

def block44 : Witness := ⟨⟨6538249, 6651240, 2579, 2591, 2593, 6537701, 6538057, 6538219⟩, 10⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2579,
    ExposureEvolution.Compact40Pratt.prime_2591,
    ExposureEvolution.Compact40Pratt.prime_2593,
    ExposureEvolution.Compact40Pratt.prime_6537701,
    ExposureEvolution.Compact40Pratt.prime_6538057,
    ExposureEvolution.Compact40Pratt.prime_6538219]

def block45 : Witness := ⟨⟨6651241, 6713280, 2591, 2593, 2609, 6650821, 6651091, 6651223⟩, 10⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2591,
    ExposureEvolution.Compact40Pratt.prime_2593,
    ExposureEvolution.Compact40Pratt.prime_2609,
    ExposureEvolution.Compact40Pratt.prime_6650821,
    ExposureEvolution.Compact40Pratt.prime_6651091,
    ExposureEvolution.Compact40Pratt.prime_6651223]

def block46 : Witness := ⟨⟨6713281, 6723648, 2593, 2609, 2617, 6712847, 6713089, 6713279⟩, 10⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2593,
    ExposureEvolution.Compact40Pratt.prime_2609,
    ExposureEvolution.Compact40Pratt.prime_2617,
    ExposureEvolution.Compact40Pratt.prime_6712847,
    ExposureEvolution.Compact40Pratt.prime_6713089,
    ExposureEvolution.Compact40Pratt.prime_6713279]

def block47 : Witness := ⟨⟨6723649, 6806880, 2609, 2617, 2621, 6723539, 6723571, 6723643⟩, 11⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2609,
    ExposureEvolution.Compact40Pratt.prime_2617,
    ExposureEvolution.Compact40Pratt.prime_2621,
    ExposureEvolution.Compact40Pratt.prime_6723539,
    ExposureEvolution.Compact40Pratt.prime_6723571,
    ExposureEvolution.Compact40Pratt.prime_6723643]

def block48 : Witness := ⟨⟨6806881, 6848688, 2617, 2621, 2633, 6806381, 6806729, 6806837⟩, 8⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2617,
    ExposureEvolution.Compact40Pratt.prime_2621,
    ExposureEvolution.Compact40Pratt.prime_2633,
    ExposureEvolution.Compact40Pratt.prime_6806381,
    ExposureEvolution.Compact40Pratt.prime_6806729,
    ExposureEvolution.Compact40Pratt.prime_6806837]

def block49 : Witness := ⟨⟨6848689, 6869640, 2621, 2633, 2647, 6848291, 6848377, 6848659⟩, 9⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2621,
    ExposureEvolution.Compact40Pratt.prime_2633,
    ExposureEvolution.Compact40Pratt.prime_2647,
    ExposureEvolution.Compact40Pratt.prime_6848291,
    ExposureEvolution.Compact40Pratt.prime_6848377,
    ExposureEvolution.Compact40Pratt.prime_6848659]

def block50 : Witness := ⟨⟨6869641, 6932688, 2633, 2647, 2657, 6869327, 6869437, 6869633⟩, 13⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2633,
    ExposureEvolution.Compact40Pratt.prime_2647,
    ExposureEvolution.Compact40Pratt.prime_2657,
    ExposureEvolution.Compact40Pratt.prime_6869327,
    ExposureEvolution.Compact40Pratt.prime_6869437,
    ExposureEvolution.Compact40Pratt.prime_6869633]

def block51 : Witness := ⟨⟨6932689, 7006608, 2647, 2657, 2659, 6932173, 6932543, 6932669⟩, 7⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2647,
    ExposureEvolution.Compact40Pratt.prime_2657,
    ExposureEvolution.Compact40Pratt.prime_2659,
    ExposureEvolution.Compact40Pratt.prime_6932173,
    ExposureEvolution.Compact40Pratt.prime_6932543,
    ExposureEvolution.Compact40Pratt.prime_6932669]

def block52 : Witness := ⟨⟨7006609, 7059648, 2657, 2659, 2663, 7006451, 7006541, 7006607⟩, 8⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2657,
    ExposureEvolution.Compact40Pratt.prime_2659,
    ExposureEvolution.Compact40Pratt.prime_2663,
    ExposureEvolution.Compact40Pratt.prime_7006451,
    ExposureEvolution.Compact40Pratt.prime_7006541,
    ExposureEvolution.Compact40Pratt.prime_7006607]

def block53 : Witness := ⟨⟨7059649, 7070280, 2659, 2663, 2671, 7059323, 7059529, 7059631⟩, 7⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2659,
    ExposureEvolution.Compact40Pratt.prime_2663,
    ExposureEvolution.Compact40Pratt.prime_2671,
    ExposureEvolution.Compact40Pratt.prime_7059323,
    ExposureEvolution.Compact40Pratt.prime_7059529,
    ExposureEvolution.Compact40Pratt.prime_7059631]

def block54 : Witness := ⟨⟨7070281, 7091568, 2663, 2671, 2677, 7069973, 7070099, 7070267⟩, 11⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2663,
    ExposureEvolution.Compact40Pratt.prime_2671,
    ExposureEvolution.Compact40Pratt.prime_2677,
    ExposureEvolution.Compact40Pratt.prime_7069973,
    ExposureEvolution.Compact40Pratt.prime_7070099,
    ExposureEvolution.Compact40Pratt.prime_7070267]

def block55 : Witness := ⟨⟨7091569, 7134240, 2671, 2677, 2683, 7091473, 7091537, 7091549⟩, 7⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2671,
    ExposureEvolution.Compact40Pratt.prime_2677,
    ExposureEvolution.Compact40Pratt.prime_2683,
    ExposureEvolution.Compact40Pratt.prime_7091473,
    ExposureEvolution.Compact40Pratt.prime_7091537,
    ExposureEvolution.Compact40Pratt.prime_7091549]

def block56 : Witness := ⟨⟨7134241, 7166328, 2677, 2683, 2687, 7134109, 7134119, 7134233⟩, 9⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2677,
    ExposureEvolution.Compact40Pratt.prime_2683,
    ExposureEvolution.Compact40Pratt.prime_2687,
    ExposureEvolution.Compact40Pratt.prime_7134109,
    ExposureEvolution.Compact40Pratt.prime_7134119,
    ExposureEvolution.Compact40Pratt.prime_7134233]

def block57 : Witness := ⟨⟨7166329, 7198488, 2683, 2687, 2689, 7165913, 7166153, 7166321⟩, 7⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2683,
    ExposureEvolution.Compact40Pratt.prime_2687,
    ExposureEvolution.Compact40Pratt.prime_2689,
    ExposureEvolution.Compact40Pratt.prime_7165913,
    ExposureEvolution.Compact40Pratt.prime_7166153,
    ExposureEvolution.Compact40Pratt.prime_7166321]

def block58 : Witness := ⟨⟨7198489, 7219968, 2687, 2689, 2693, 7197977, 7198349, 7198483⟩, 9⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2687,
    ExposureEvolution.Compact40Pratt.prime_2689,
    ExposureEvolution.Compact40Pratt.prime_2693,
    ExposureEvolution.Compact40Pratt.prime_7197977,
    ExposureEvolution.Compact40Pratt.prime_7198349,
    ExposureEvolution.Compact40Pratt.prime_7198483]

def block59 : Witness := ⟨⟨7219969, 7230720, 2689, 2693, 2699, 7219361, 7219757, 7219963⟩, 10⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2689,
    ExposureEvolution.Compact40Pratt.prime_2693,
    ExposureEvolution.Compact40Pratt.prime_2699,
    ExposureEvolution.Compact40Pratt.prime_7219361,
    ExposureEvolution.Compact40Pratt.prime_7219757,
    ExposureEvolution.Compact40Pratt.prime_7219963]

def block60 : Witness := ⟨⟨7230721, 7252248, 2693, 2699, 2707, 7230323, 7230481, 7230709⟩, 8⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2693,
    ExposureEvolution.Compact40Pratt.prime_2699,
    ExposureEvolution.Compact40Pratt.prime_2707,
    ExposureEvolution.Compact40Pratt.prime_7230323,
    ExposureEvolution.Compact40Pratt.prime_7230481,
    ExposureEvolution.Compact40Pratt.prime_7230709]

def block61 : Witness := ⟨⟨7252249, 7284600, 2699, 2707, 2711, 7251947, 7252187, 7252237⟩, 7⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2699,
    ExposureEvolution.Compact40Pratt.prime_2707,
    ExposureEvolution.Compact40Pratt.prime_2711,
    ExposureEvolution.Compact40Pratt.prime_7251947,
    ExposureEvolution.Compact40Pratt.prime_7252187,
    ExposureEvolution.Compact40Pratt.prime_7252237]

def block62 : Witness := ⟨⟨7284601, 7327848, 2707, 2711, 2713, 7284371, 7284521, 7284569⟩, 6⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2707,
    ExposureEvolution.Compact40Pratt.prime_2711,
    ExposureEvolution.Compact40Pratt.prime_2713,
    ExposureEvolution.Compact40Pratt.prime_7284371,
    ExposureEvolution.Compact40Pratt.prime_7284521,
    ExposureEvolution.Compact40Pratt.prime_7284569]

def block63 : Witness := ⟨⟨7327849, 7349520, 2711, 2713, 2719, 7327601, 7327627, 7327847⟩, 13⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_2711,
    ExposureEvolution.Compact40Pratt.prime_2713,
    ExposureEvolution.Compact40Pratt.prime_2719,
    ExposureEvolution.Compact40Pratt.prime_7327601,
    ExposureEvolution.Compact40Pratt.prime_7327627,
    ExposureEvolution.Compact40Pratt.prime_7327847]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 7349521 stop tail = true) :
    coverage 5000000 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_000
