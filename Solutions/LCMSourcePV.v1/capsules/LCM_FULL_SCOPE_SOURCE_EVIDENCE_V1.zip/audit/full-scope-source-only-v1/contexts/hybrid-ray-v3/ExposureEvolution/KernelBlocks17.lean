import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks17
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨29149201, 29235648, 5407, 5413, 5417, 29148929, 29149189, 29149199⟩, 8⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5407,
    ExposureEvolution.KernelPratt.prime_5413,
    ExposureEvolution.KernelPratt.prime_5417,
    ExposureEvolution.KernelPratt.prime_29148929,
    ExposureEvolution.KernelPratt.prime_29149189,
    ExposureEvolution.KernelPratt.prime_29149199]

def block01 : Witness := ⟨⟨29235649, 29300568, 5413, 5417, 5419, 29235203, 29235497, 29235637⟩, 8⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5413,
    ExposureEvolution.KernelPratt.prime_5417,
    ExposureEvolution.KernelPratt.prime_5419,
    ExposureEvolution.KernelPratt.prime_29235203,
    ExposureEvolution.KernelPratt.prime_29235497,
    ExposureEvolution.KernelPratt.prime_29235637]

def block02 : Witness := ⟨⟨29300569, 29343888, 5417, 5419, 5431, 29300087, 29300543, 29300563⟩, 11⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5417,
    ExposureEvolution.KernelPratt.prime_5419,
    ExposureEvolution.KernelPratt.prime_5431,
    ExposureEvolution.KernelPratt.prime_29300087,
    ExposureEvolution.KernelPratt.prime_29300543,
    ExposureEvolution.KernelPratt.prime_29300563]

def block03 : Witness := ⟨⟨29343889, 29365560, 5419, 5431, 5437, 29343499, 29343829, 29343871⟩, 12⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5419,
    ExposureEvolution.KernelPratt.prime_5431,
    ExposureEvolution.KernelPratt.prime_5437,
    ExposureEvolution.KernelPratt.prime_29343499,
    ExposureEvolution.KernelPratt.prime_29343829,
    ExposureEvolution.KernelPratt.prime_29343871]

def block04 : Witness := ⟨⟨29365561, 29495760, 5431, 5437, 5441, 29365249, 29365537, 29365547⟩, 9⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5431,
    ExposureEvolution.KernelPratt.prime_5437,
    ExposureEvolution.KernelPratt.prime_5441,
    ExposureEvolution.KernelPratt.prime_29365249,
    ExposureEvolution.KernelPratt.prime_29365537,
    ExposureEvolution.KernelPratt.prime_29365547]

def block05 : Witness := ⟨⟨29495761, 29560968, 5437, 5441, 5443, 29495311, 29495413, 29495717⟩, 10⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5437,
    ExposureEvolution.KernelPratt.prime_5441,
    ExposureEvolution.KernelPratt.prime_5443,
    ExposureEvolution.KernelPratt.prime_29495311,
    ExposureEvolution.KernelPratt.prime_29495413,
    ExposureEvolution.KernelPratt.prime_29495717]

def block06 : Witness := ⟨⟨29560969, 29604480, 5441, 5443, 5449, 29560493, 29560721, 29560939⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5441,
    ExposureEvolution.KernelPratt.prime_5443,
    ExposureEvolution.KernelPratt.prime_5449,
    ExposureEvolution.KernelPratt.prime_29560493,
    ExposureEvolution.KernelPratt.prime_29560721,
    ExposureEvolution.KernelPratt.prime_29560939]

def block07 : Witness := ⟨⟨29604481, 29626248, 5443, 5449, 5471, 29603941, 29604431, 29604469⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5443,
    ExposureEvolution.KernelPratt.prime_5449,
    ExposureEvolution.KernelPratt.prime_5471,
    ExposureEvolution.KernelPratt.prime_29603941,
    ExposureEvolution.KernelPratt.prime_29604431,
    ExposureEvolution.KernelPratt.prime_29604469]

def block08 : Witness := ⟨⟨29626249, 29691600, 5449, 5471, 5477, 29625901, 29625943, 29626243⟩, 6⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5449,
    ExposureEvolution.KernelPratt.prime_5471,
    ExposureEvolution.KernelPratt.prime_5477,
    ExposureEvolution.KernelPratt.prime_29625901,
    ExposureEvolution.KernelPratt.prime_29625943,
    ExposureEvolution.KernelPratt.prime_29626243]

def block09 : Witness := ⟨⟨29691601, 29931840, 5471, 5477, 5479, 29691577, 29691581, 29691593⟩, 8⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5471,
    ExposureEvolution.KernelPratt.prime_5477,
    ExposureEvolution.KernelPratt.prime_5479,
    ExposureEvolution.KernelPratt.prime_29691577,
    ExposureEvolution.KernelPratt.prime_29691581,
    ExposureEvolution.KernelPratt.prime_29691593]

def block10 : Witness := ⟨⟨29931841, 29997528, 5477, 5479, 5483, 29931449, 29931637, 29931817⟩, 8⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5477,
    ExposureEvolution.KernelPratt.prime_5479,
    ExposureEvolution.KernelPratt.prime_5483,
    ExposureEvolution.KernelPratt.prime_29931449,
    ExposureEvolution.KernelPratt.prime_29931637,
    ExposureEvolution.KernelPratt.prime_29931817]

def block11 : Witness := ⟨⟨29997529, 30019440, 5479, 5483, 5501, 29996987, 29997293, 29997521⟩, 10⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5479,
    ExposureEvolution.KernelPratt.prime_5483,
    ExposureEvolution.KernelPratt.prime_5501,
    ExposureEvolution.KernelPratt.prime_29996987,
    ExposureEvolution.KernelPratt.prime_29997293,
    ExposureEvolution.KernelPratt.prime_29997521]

def block12 : Witness := ⟨⟨30019441, 30063288, 5483, 5501, 5503, 30019079, 30019081, 30019387⟩, 10⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5483,
    ExposureEvolution.KernelPratt.prime_5501,
    ExposureEvolution.KernelPratt.prime_5503,
    ExposureEvolution.KernelPratt.prime_30019079,
    ExposureEvolution.KernelPratt.prime_30019081,
    ExposureEvolution.KernelPratt.prime_30019387]

def block13 : Witness := ⟨⟨30063289, 30261000, 5501, 5503, 5507, 30062999, 30063097, 30063287⟩, 7⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5501,
    ExposureEvolution.KernelPratt.prime_5503,
    ExposureEvolution.KernelPratt.prime_5507,
    ExposureEvolution.KernelPratt.prime_30062999,
    ExposureEvolution.KernelPratt.prime_30063097,
    ExposureEvolution.KernelPratt.prime_30063287]

def block14 : Witness := ⟨⟨30261001, 30283008, 5503, 5507, 5519, 30260491, 30260873, 30260999⟩, 7⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5503,
    ExposureEvolution.KernelPratt.prime_5507,
    ExposureEvolution.KernelPratt.prime_5519,
    ExposureEvolution.KernelPratt.prime_30260491,
    ExposureEvolution.KernelPratt.prime_30260873,
    ExposureEvolution.KernelPratt.prime_30260999]

def block15 : Witness := ⟨⟨30283009, 30327048, 5507, 5519, 5521, 30282619, 30282829, 30282971⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5507,
    ExposureEvolution.KernelPratt.prime_5519,
    ExposureEvolution.KernelPratt.prime_5521,
    ExposureEvolution.KernelPratt.prime_30282619,
    ExposureEvolution.KernelPratt.prime_30282829,
    ExposureEvolution.KernelPratt.prime_30282971]

def block16 : Witness := ⟨⟨30327049, 30459360, 5519, 5521, 5527, 30326561, 30326629, 30327043⟩, 9⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5519,
    ExposureEvolution.KernelPratt.prime_5521,
    ExposureEvolution.KernelPratt.prime_5527,
    ExposureEvolution.KernelPratt.prime_30326561,
    ExposureEvolution.KernelPratt.prime_30326629,
    ExposureEvolution.KernelPratt.prime_30327043]

def block17 : Witness := ⟨⟨30459361, 30481440, 5521, 5527, 5531, 30458797, 30459227, 30459353⟩, 14⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5521,
    ExposureEvolution.KernelPratt.prime_5527,
    ExposureEvolution.KernelPratt.prime_5531,
    ExposureEvolution.KernelPratt.prime_30458797,
    ExposureEvolution.KernelPratt.prime_30459227,
    ExposureEvolution.KernelPratt.prime_30459353]

def block18 : Witness := ⟨⟨30481441, 30547728, 5527, 5531, 5557, 30481237, 30481261, 30481433⟩, 8⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5527,
    ExposureEvolution.KernelPratt.prime_5531,
    ExposureEvolution.KernelPratt.prime_5557,
    ExposureEvolution.KernelPratt.prime_30481237,
    ExposureEvolution.KernelPratt.prime_30481261,
    ExposureEvolution.KernelPratt.prime_30481433]

def block19 : Witness := ⟨⟨30547729, 30591960, 5531, 5557, 5563, 30547471, 30547567, 30547723⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5531,
    ExposureEvolution.KernelPratt.prime_5557,
    ExposureEvolution.KernelPratt.prime_5563,
    ExposureEvolution.KernelPratt.prime_30547471,
    ExposureEvolution.KernelPratt.prime_30547567,
    ExposureEvolution.KernelPratt.prime_30547723]

def block20 : Witness := ⟨⟨30591961, 30880248, 5557, 5563, 5569, 30591647, 30591893, 30591931⟩, 7⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5557,
    ExposureEvolution.KernelPratt.prime_5563,
    ExposureEvolution.KernelPratt.prime_5569,
    ExposureEvolution.KernelPratt.prime_30591647,
    ExposureEvolution.KernelPratt.prime_30591893,
    ExposureEvolution.KernelPratt.prime_30591931]

def block21 : Witness := ⟨⟨30880249, 30946968, 5563, 5569, 5573, 30880009, 30880217, 30880219⟩, 8⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5563,
    ExposureEvolution.KernelPratt.prime_5569,
    ExposureEvolution.KernelPratt.prime_5573,
    ExposureEvolution.KernelPratt.prime_30880009,
    ExposureEvolution.KernelPratt.prime_30880217,
    ExposureEvolution.KernelPratt.prime_30880219]

def block22 : Witness := ⟨⟨30946969, 31013760, 5569, 5573, 5581, 30946499, 30946789, 30946961⟩, 20⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5569,
    ExposureEvolution.KernelPratt.prime_5573,
    ExposureEvolution.KernelPratt.prime_5581,
    ExposureEvolution.KernelPratt.prime_30946499,
    ExposureEvolution.KernelPratt.prime_30946789,
    ExposureEvolution.KernelPratt.prime_30946961]

def block23 : Witness := ⟨⟨31013761, 31058328, 5573, 5581, 5591, 31013347, 31013417, 31013747⟩, 9⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5573,
    ExposureEvolution.KernelPratt.prime_5581,
    ExposureEvolution.KernelPratt.prime_5591,
    ExposureEvolution.KernelPratt.prime_31013347,
    ExposureEvolution.KernelPratt.prime_31013417,
    ExposureEvolution.KernelPratt.prime_31013747]

def block24 : Witness := ⟨⟨31058329, 31147560, 5581, 5591, 5623, 31058147, 31058243, 31058327⟩, 8⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5581,
    ExposureEvolution.KernelPratt.prime_5591,
    ExposureEvolution.KernelPratt.prime_5623,
    ExposureEvolution.KernelPratt.prime_31058147,
    ExposureEvolution.KernelPratt.prime_31058243,
    ExposureEvolution.KernelPratt.prime_31058327]

def block25 : Witness := ⟨⟨31147561, 31259280, 5591, 5623, 5639, 31147373, 31147381, 31147559⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5591,
    ExposureEvolution.KernelPratt.prime_5623,
    ExposureEvolution.KernelPratt.prime_5639,
    ExposureEvolution.KernelPratt.prime_31147373,
    ExposureEvolution.KernelPratt.prime_31147381,
    ExposureEvolution.KernelPratt.prime_31147559]

def block26 : Witness := ⟨⟨31259281, 31618128, 5623, 5639, 5641, 31258681, 31258739, 31259269⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5623,
    ExposureEvolution.KernelPratt.prime_5639,
    ExposureEvolution.KernelPratt.prime_5641,
    ExposureEvolution.KernelPratt.prime_31258681,
    ExposureEvolution.KernelPratt.prime_31258739,
    ExposureEvolution.KernelPratt.prime_31259269]

def block27 : Witness := ⟨⟨31618129, 31798320, 5639, 5641, 5647, 31617667, 31618001, 31618127⟩, 9⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5639,
    ExposureEvolution.KernelPratt.prime_5641,
    ExposureEvolution.KernelPratt.prime_5647,
    ExposureEvolution.KernelPratt.prime_31617667,
    ExposureEvolution.KernelPratt.prime_31618001,
    ExposureEvolution.KernelPratt.prime_31618127]

def block28 : Witness := ⟨⟨31798321, 31820880, 5641, 5647, 5651, 31798079, 31798127, 31798307⟩, 8⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5641,
    ExposureEvolution.KernelPratt.prime_5647,
    ExposureEvolution.KernelPratt.prime_5651,
    ExposureEvolution.KernelPratt.prime_31798079,
    ExposureEvolution.KernelPratt.prime_31798127,
    ExposureEvolution.KernelPratt.prime_31798307]

def block29 : Witness := ⟨⟨31820881, 31888608, 5647, 5651, 5653, 31820501, 31820669, 31820869⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5647,
    ExposureEvolution.KernelPratt.prime_5651,
    ExposureEvolution.KernelPratt.prime_5653,
    ExposureEvolution.KernelPratt.prime_31820501,
    ExposureEvolution.KernelPratt.prime_31820669,
    ExposureEvolution.KernelPratt.prime_31820869]

def block30 : Witness := ⟨⟨31888609, 31933800, 5651, 5653, 5657, 31888393, 31888471, 31888601⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5651,
    ExposureEvolution.KernelPratt.prime_5653,
    ExposureEvolution.KernelPratt.prime_5657,
    ExposureEvolution.KernelPratt.prime_31888393,
    ExposureEvolution.KernelPratt.prime_31888471,
    ExposureEvolution.KernelPratt.prime_31888601]

def block31 : Witness := ⟨⟨31933801, 31956408, 5653, 5657, 5659, 31933501, 31933703, 31933799⟩, 10⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_5653,
    ExposureEvolution.KernelPratt.prime_5657,
    ExposureEvolution.KernelPratt.prime_5659,
    ExposureEvolution.KernelPratt.prime_31933501,
    ExposureEvolution.KernelPratt.prime_31933703,
    ExposureEvolution.KernelPratt.prime_31933799]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 31956409 stop tail = true) :
    coverage 29149201 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks17
