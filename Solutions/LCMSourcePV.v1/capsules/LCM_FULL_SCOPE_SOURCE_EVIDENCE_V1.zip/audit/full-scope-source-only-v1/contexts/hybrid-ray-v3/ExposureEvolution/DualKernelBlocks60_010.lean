import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_010
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨58507201, 58813560, 7669, 7673, 7681, 58506817, 58506863, 58507171⟩, 10⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7669,
    ExposureEvolution.Compact40Pratt.prime_7673,
    ExposureEvolution.Compact40Pratt.prime_7681,
    ExposureEvolution.Compact40Pratt.prime_58506817,
    ExposureEvolution.Compact40Pratt.prime_58506863,
    ExposureEvolution.Compact40Pratt.prime_58507171]

def block01 : Witness := ⟨⟨58813561, 58874928, 7673, 7681, 7687, 58813099, 58813129, 58813549⟩, 6⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7673,
    ExposureEvolution.Compact40Pratt.prime_7681,
    ExposureEvolution.Compact40Pratt.prime_7687,
    ExposureEvolution.Compact40Pratt.prime_58813099,
    ExposureEvolution.Compact40Pratt.prime_58813129,
    ExposureEvolution.Compact40Pratt.prime_58813549]

def block02 : Witness := ⟨⟨58874929, 58997760, 7681, 7687, 7691, 58874741, 58874789, 58874909⟩, 12⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7681,
    ExposureEvolution.Compact40Pratt.prime_7687,
    ExposureEvolution.Compact40Pratt.prime_7691,
    ExposureEvolution.Compact40Pratt.prime_58874741,
    ExposureEvolution.Compact40Pratt.prime_58874789,
    ExposureEvolution.Compact40Pratt.prime_58874909]

def block03 : Witness := ⟨⟨58997761, 59089968, 7687, 7691, 7699, 58997209, 58997381, 58997759⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7687,
    ExposureEvolution.Compact40Pratt.prime_7691,
    ExposureEvolution.Compact40Pratt.prime_7699,
    ExposureEvolution.Compact40Pratt.prime_58997209,
    ExposureEvolution.Compact40Pratt.prime_58997381,
    ExposureEvolution.Compact40Pratt.prime_58997759]

def block04 : Witness := ⟨⟨59089969, 59151480, 7691, 7699, 7703, 59089549, 59089757, 59089903⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7691,
    ExposureEvolution.Compact40Pratt.prime_7699,
    ExposureEvolution.Compact40Pratt.prime_7703,
    ExposureEvolution.Compact40Pratt.prime_59089549,
    ExposureEvolution.Compact40Pratt.prime_59089757,
    ExposureEvolution.Compact40Pratt.prime_59089903]

def block05 : Witness := ⟨⟨59151481, 59274600, 7699, 7703, 7717, 59151089, 59151401, 59151467⟩, 10⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7699,
    ExposureEvolution.Compact40Pratt.prime_7703,
    ExposureEvolution.Compact40Pratt.prime_7717,
    ExposureEvolution.Compact40Pratt.prime_59151089,
    ExposureEvolution.Compact40Pratt.prime_59151401,
    ExposureEvolution.Compact40Pratt.prime_59151467]

def block06 : Witness := ⟨⟨59274601, 59336208, 7703, 7717, 7723, 59274079, 59274161, 59274587⟩, 11⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7703,
    ExposureEvolution.Compact40Pratt.prime_7717,
    ExposureEvolution.Compact40Pratt.prime_7723,
    ExposureEvolution.Compact40Pratt.prime_59274079,
    ExposureEvolution.Compact40Pratt.prime_59274161,
    ExposureEvolution.Compact40Pratt.prime_59274587]

def block07 : Witness := ⟨⟨59336209, 59552088, 7717, 7723, 7727, 59336111, 59336153, 59336177⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7717,
    ExposureEvolution.Compact40Pratt.prime_7723,
    ExposureEvolution.Compact40Pratt.prime_7727,
    ExposureEvolution.Compact40Pratt.prime_59336111,
    ExposureEvolution.Compact40Pratt.prime_59336153,
    ExposureEvolution.Compact40Pratt.prime_59336177]

def block08 : Witness := ⟨⟨59552089, 59644728, 7723, 7727, 7741, 59551691, 59551841, 59552069⟩, 16⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7723,
    ExposureEvolution.Compact40Pratt.prime_7727,
    ExposureEvolution.Compact40Pratt.prime_7741,
    ExposureEvolution.Compact40Pratt.prime_59551691,
    ExposureEvolution.Compact40Pratt.prime_59551841,
    ExposureEvolution.Compact40Pratt.prime_59552069]

def block09 : Witness := ⟨⟨59644729, 59706528, 7727, 7741, 7753, 59644337, 59644499, 59644679⟩, 10⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7727,
    ExposureEvolution.Compact40Pratt.prime_7741,
    ExposureEvolution.Compact40Pratt.prime_7753,
    ExposureEvolution.Compact40Pratt.prime_59644337,
    ExposureEvolution.Compact40Pratt.prime_59644499,
    ExposureEvolution.Compact40Pratt.prime_59644679]

def block10 : Witness := ⟨⟨59706529, 59923080, 7741, 7753, 7757, 59705957, 59705981, 59706509⟩, 10⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7741,
    ExposureEvolution.Compact40Pratt.prime_7753,
    ExposureEvolution.Compact40Pratt.prime_7757,
    ExposureEvolution.Compact40Pratt.prime_59705957,
    ExposureEvolution.Compact40Pratt.prime_59705981,
    ExposureEvolution.Compact40Pratt.prime_59706509]

def block11 : Witness := ⟨⟨59923081, 60109008, 7753, 7757, 7759, 59922631, 59922881, 59923069⟩, 8⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7753,
    ExposureEvolution.Compact40Pratt.prime_7757,
    ExposureEvolution.Compact40Pratt.prime_7759,
    ExposureEvolution.Compact40Pratt.prime_59922631,
    ExposureEvolution.Compact40Pratt.prime_59922881,
    ExposureEvolution.Compact40Pratt.prime_59923069]

def block12 : Witness := ⟨⟨60109009, 60171048, 7757, 7759, 7789, 60108523, 60108803, 60108953⟩, 7⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7757,
    ExposureEvolution.Compact40Pratt.prime_7759,
    ExposureEvolution.Compact40Pratt.prime_7789,
    ExposureEvolution.Compact40Pratt.prime_60108523,
    ExposureEvolution.Compact40Pratt.prime_60108803,
    ExposureEvolution.Compact40Pratt.prime_60108953]

def block13 : Witness := ⟨⟨60171049, 60202080, 7759, 7789, 7793, 60170897, 60171011, 60171047⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7759,
    ExposureEvolution.Compact40Pratt.prime_7789,
    ExposureEvolution.Compact40Pratt.prime_7793,
    ExposureEvolution.Compact40Pratt.prime_60170897,
    ExposureEvolution.Compact40Pratt.prime_60171011,
    ExposureEvolution.Compact40Pratt.prime_60171047]

def block14 : Witness := ⟨⟨60202081, 60668520, 7789, 7793, 7817, 60201781, 60201853, 60202069⟩, 10⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7789,
    ExposureEvolution.Compact40Pratt.prime_7793,
    ExposureEvolution.Compact40Pratt.prime_7817,
    ExposureEvolution.Compact40Pratt.prime_60201781,
    ExposureEvolution.Compact40Pratt.prime_60201853,
    ExposureEvolution.Compact40Pratt.prime_60202069]

def block15 : Witness := ⟨⟨60668521, 60730848, 7793, 7817, 7823, 60668401, 60668467, 60668513⟩, 7⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7793,
    ExposureEvolution.Compact40Pratt.prime_7817,
    ExposureEvolution.Compact40Pratt.prime_7823,
    ExposureEvolution.Compact40Pratt.prime_60668401,
    ExposureEvolution.Compact40Pratt.prime_60668467,
    ExposureEvolution.Compact40Pratt.prime_60668513]

def block16 : Witness := ⟨⟨60730849, 61105488, 7817, 7823, 7829, 60730301, 60730639, 60730837⟩, 8⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7817,
    ExposureEvolution.Compact40Pratt.prime_7823,
    ExposureEvolution.Compact40Pratt.prime_7829,
    ExposureEvolution.Compact40Pratt.prime_60730301,
    ExposureEvolution.Compact40Pratt.prime_60730639,
    ExposureEvolution.Compact40Pratt.prime_60730837]

def block17 : Witness := ⟨⟨61105489, 61199328, 7823, 7829, 7841, 61105069, 61105381, 61105487⟩, 7⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7823,
    ExposureEvolution.Compact40Pratt.prime_7829,
    ExposureEvolution.Compact40Pratt.prime_7841,
    ExposureEvolution.Compact40Pratt.prime_61105069,
    ExposureEvolution.Compact40Pratt.prime_61105381,
    ExposureEvolution.Compact40Pratt.prime_61105487]

def block18 : Witness := ⟨⟨61199329, 61293240, 7829, 7841, 7853, 61199179, 61199213, 61199273⟩, 8⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7829,
    ExposureEvolution.Compact40Pratt.prime_7841,
    ExposureEvolution.Compact40Pratt.prime_7853,
    ExposureEvolution.Compact40Pratt.prime_61199179,
    ExposureEvolution.Compact40Pratt.prime_61199213,
    ExposureEvolution.Compact40Pratt.prime_61199273]

def block19 : Witness := ⟨⟨61293241, 61481280, 7841, 7853, 7867, 61293181, 61293187, 61293203⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7841,
    ExposureEvolution.Compact40Pratt.prime_7853,
    ExposureEvolution.Compact40Pratt.prime_7867,
    ExposureEvolution.Compact40Pratt.prime_61293181,
    ExposureEvolution.Compact40Pratt.prime_61293187,
    ExposureEvolution.Compact40Pratt.prime_61293203]

def block20 : Witness := ⟨⟨61481281, 61669608, 7853, 7867, 7873, 61480763, 61480849, 61481267⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7853,
    ExposureEvolution.Compact40Pratt.prime_7867,
    ExposureEvolution.Compact40Pratt.prime_7873,
    ExposureEvolution.Compact40Pratt.prime_61480763,
    ExposureEvolution.Compact40Pratt.prime_61480849,
    ExposureEvolution.Compact40Pratt.prime_61481267]

def block21 : Witness := ⟨⟨61669609, 61889688, 7867, 7873, 7877, 61669169, 61669561, 61669607⟩, 10⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7867,
    ExposureEvolution.Compact40Pratt.prime_7873,
    ExposureEvolution.Compact40Pratt.prime_7877,
    ExposureEvolution.Compact40Pratt.prime_61669169,
    ExposureEvolution.Compact40Pratt.prime_61669561,
    ExposureEvolution.Compact40Pratt.prime_61669607]

def block22 : Witness := ⟨⟨61889689, 61984128, 7873, 7877, 7879, 61889263, 61889447, 61889687⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7873,
    ExposureEvolution.Compact40Pratt.prime_7877,
    ExposureEvolution.Compact40Pratt.prime_7879,
    ExposureEvolution.Compact40Pratt.prime_61889263,
    ExposureEvolution.Compact40Pratt.prime_61889447,
    ExposureEvolution.Compact40Pratt.prime_61889687]

def block23 : Witness := ⟨⟨61984129, 62047128, 7877, 7879, 7883, 61983421, 61983437, 61984121⟩, 7⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7877,
    ExposureEvolution.Compact40Pratt.prime_7879,
    ExposureEvolution.Compact40Pratt.prime_7883,
    ExposureEvolution.Compact40Pratt.prime_61983421,
    ExposureEvolution.Compact40Pratt.prime_61983437,
    ExposureEvolution.Compact40Pratt.prime_61984121]

def block24 : Witness := ⟨⟨62047129, 62078640, 7879, 7883, 7901, 62046587, 62046797, 62047121⟩, 8⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7879,
    ExposureEvolution.Compact40Pratt.prime_7883,
    ExposureEvolution.Compact40Pratt.prime_7901,
    ExposureEvolution.Compact40Pratt.prime_62046587,
    ExposureEvolution.Compact40Pratt.prime_62046797,
    ExposureEvolution.Compact40Pratt.prime_62047121]

def block25 : Witness := ⟨⟨62078641, 62141688, 7883, 7901, 7907, 62078167, 62078609, 62078623⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7883,
    ExposureEvolution.Compact40Pratt.prime_7901,
    ExposureEvolution.Compact40Pratt.prime_7907,
    ExposureEvolution.Compact40Pratt.prime_62078167,
    ExposureEvolution.Compact40Pratt.prime_62078609,
    ExposureEvolution.Compact40Pratt.prime_62078623]

def block26 : Witness := ⟨⟨62141689, 62425800, 7901, 7907, 7919, 62141311, 62141603, 62141683⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7901,
    ExposureEvolution.Compact40Pratt.prime_7907,
    ExposureEvolution.Compact40Pratt.prime_7919,
    ExposureEvolution.Compact40Pratt.prime_62141311,
    ExposureEvolution.Compact40Pratt.prime_62141603,
    ExposureEvolution.Compact40Pratt.prime_62141683]

def block27 : Witness := ⟨⟨62425801, 62520648, 7907, 7919, 7927, 62425403, 62425567, 62425799⟩, 11⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7907,
    ExposureEvolution.Compact40Pratt.prime_7919,
    ExposureEvolution.Compact40Pratt.prime_7927,
    ExposureEvolution.Compact40Pratt.prime_62425403,
    ExposureEvolution.Compact40Pratt.prime_62425567,
    ExposureEvolution.Compact40Pratt.prime_62425799]

def block28 : Witness := ⟨⟨62520649, 62710560, 7919, 7927, 7933, 62520499, 62520551, 62520637⟩, 8⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7919,
    ExposureEvolution.Compact40Pratt.prime_7927,
    ExposureEvolution.Compact40Pratt.prime_7933,
    ExposureEvolution.Compact40Pratt.prime_62520499,
    ExposureEvolution.Compact40Pratt.prime_62520551,
    ExposureEvolution.Compact40Pratt.prime_62520637]

def block29 : Witness := ⟨⟨62710561, 62837328, 7927, 7933, 7937, 62710129, 62710157, 62710559⟩, 5⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7927,
    ExposureEvolution.Compact40Pratt.prime_7933,
    ExposureEvolution.Compact40Pratt.prime_7937,
    ExposureEvolution.Compact40Pratt.prime_62710129,
    ExposureEvolution.Compact40Pratt.prime_62710157,
    ExposureEvolution.Compact40Pratt.prime_62710559]

def block30 : Witness := ⟨⟨62837329, 62932488, 7933, 7937, 7949, 62837053, 62837087, 62837317⟩, 9⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7933,
    ExposureEvolution.Compact40Pratt.prime_7937,
    ExposureEvolution.Compact40Pratt.prime_7949,
    ExposureEvolution.Compact40Pratt.prime_62837053,
    ExposureEvolution.Compact40Pratt.prime_62837087,
    ExposureEvolution.Compact40Pratt.prime_62837317]

def block31 : Witness := ⟨⟨62932489, 62995968, 7937, 7949, 7951, 62932039, 62932451, 62932469⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7937,
    ExposureEvolution.Compact40Pratt.prime_7949,
    ExposureEvolution.Compact40Pratt.prime_7951,
    ExposureEvolution.Compact40Pratt.prime_62932039,
    ExposureEvolution.Compact40Pratt.prime_62932451,
    ExposureEvolution.Compact40Pratt.prime_62932469]

def block32 : Witness := ⟨⟨62995969, 63186600, 7949, 7951, 7963, 62995313, 62995763, 62995951⟩, 9⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7949,
    ExposureEvolution.Compact40Pratt.prime_7951,
    ExposureEvolution.Compact40Pratt.prime_7963,
    ExposureEvolution.Compact40Pratt.prime_62995313,
    ExposureEvolution.Compact40Pratt.prime_62995763,
    ExposureEvolution.Compact40Pratt.prime_62995951]

def block33 : Witness := ⟨⟨63186601, 63218400, 7951, 7963, 7993, 63186413, 63186527, 63186583⟩, 10⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7951,
    ExposureEvolution.Compact40Pratt.prime_7963,
    ExposureEvolution.Compact40Pratt.prime_7993,
    ExposureEvolution.Compact40Pratt.prime_63186413,
    ExposureEvolution.Compact40Pratt.prime_63186527,
    ExposureEvolution.Compact40Pratt.prime_63186583]

def block34 : Witness := ⟨⟨63218401, 63409368, 7963, 7993, 8009, 63218137, 63218327, 63218399⟩, 9⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7963,
    ExposureEvolution.Compact40Pratt.prime_7993,
    ExposureEvolution.Compact40Pratt.prime_8009,
    ExposureEvolution.Compact40Pratt.prime_63218137,
    ExposureEvolution.Compact40Pratt.prime_63218327,
    ExposureEvolution.Compact40Pratt.prime_63218399]

def block35 : Witness := ⟨⟨63409369, 63888048, 7993, 8009, 8011, 63409007, 63409267, 63409349⟩, 8⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7993,
    ExposureEvolution.Compact40Pratt.prime_8009,
    ExposureEvolution.Compact40Pratt.prime_8011,
    ExposureEvolution.Compact40Pratt.prime_63409007,
    ExposureEvolution.Compact40Pratt.prime_63409267,
    ExposureEvolution.Compact40Pratt.prime_63409349]

def block36 : Witness := ⟨⟨63888049, 64144080, 8009, 8011, 8017, 63887953, 63888031, 63888047⟩, 8⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8009,
    ExposureEvolution.Compact40Pratt.prime_8011,
    ExposureEvolution.Compact40Pratt.prime_8017,
    ExposureEvolution.Compact40Pratt.prime_63887953,
    ExposureEvolution.Compact40Pratt.prime_63888031,
    ExposureEvolution.Compact40Pratt.prime_63888047]

def block37 : Witness := ⟨⟨64144081, 64176120, 8011, 8017, 8039, 64143613, 64143623, 64144037⟩, 7⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8011,
    ExposureEvolution.Compact40Pratt.prime_8017,
    ExposureEvolution.Compact40Pratt.prime_8039,
    ExposureEvolution.Compact40Pratt.prime_64143613,
    ExposureEvolution.Compact40Pratt.prime_64143623,
    ExposureEvolution.Compact40Pratt.prime_64144037]

def block38 : Witness := ⟨⟨64176121, 64272288, 8017, 8039, 8053, 64175971, 64176001, 64176113⟩, 8⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8017,
    ExposureEvolution.Compact40Pratt.prime_8039,
    ExposureEvolution.Compact40Pratt.prime_8053,
    ExposureEvolution.Compact40Pratt.prime_64175971,
    ExposureEvolution.Compact40Pratt.prime_64176001,
    ExposureEvolution.Compact40Pratt.prime_64176113]

def block39 : Witness := ⟨⟨64272289, 64625520, 8039, 8053, 8059, 64271947, 64272127, 64272233⟩, 12⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8039,
    ExposureEvolution.Compact40Pratt.prime_8053,
    ExposureEvolution.Compact40Pratt.prime_8059,
    ExposureEvolution.Compact40Pratt.prime_64271947,
    ExposureEvolution.Compact40Pratt.prime_64272127,
    ExposureEvolution.Compact40Pratt.prime_64272233]

def block40 : Witness := ⟨⟨64625521, 64850808, 8053, 8059, 8069, 64625207, 64625257, 64625467⟩, 9⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8053,
    ExposureEvolution.Compact40Pratt.prime_8059,
    ExposureEvolution.Compact40Pratt.prime_8069,
    ExposureEvolution.Compact40Pratt.prime_64625207,
    ExposureEvolution.Compact40Pratt.prime_64625257,
    ExposureEvolution.Compact40Pratt.prime_64625467]

def block41 : Witness := ⟨⟨64850809, 64947480, 8059, 8069, 8081, 64850197, 64850701, 64850771⟩, 10⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8059,
    ExposureEvolution.Compact40Pratt.prime_8069,
    ExposureEvolution.Compact40Pratt.prime_8081,
    ExposureEvolution.Compact40Pratt.prime_64850197,
    ExposureEvolution.Compact40Pratt.prime_64850701,
    ExposureEvolution.Compact40Pratt.prime_64850771]

def block42 : Witness := ⟨⟨64947481, 65108760, 8069, 8081, 8087, 64947137, 64947227, 64947479⟩, 7⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8069,
    ExposureEvolution.Compact40Pratt.prime_8081,
    ExposureEvolution.Compact40Pratt.prime_8087,
    ExposureEvolution.Compact40Pratt.prime_64947137,
    ExposureEvolution.Compact40Pratt.prime_64947227,
    ExposureEvolution.Compact40Pratt.prime_64947479]

def block43 : Witness := ⟨⟨65108761, 65302560, 8081, 8087, 8089, 65108089, 65108629, 65108749⟩, 8⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8081,
    ExposureEvolution.Compact40Pratt.prime_8087,
    ExposureEvolution.Compact40Pratt.prime_8089,
    ExposureEvolution.Compact40Pratt.prime_65108089,
    ExposureEvolution.Compact40Pratt.prime_65108629,
    ExposureEvolution.Compact40Pratt.prime_65108749]

def block44 : Witness := ⟨⟨65302561, 65399568, 8087, 8089, 8093, 65302351, 65302547, 65302553⟩, 9⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8087,
    ExposureEvolution.Compact40Pratt.prime_8089,
    ExposureEvolution.Compact40Pratt.prime_8093,
    ExposureEvolution.Compact40Pratt.prime_65302351,
    ExposureEvolution.Compact40Pratt.prime_65302547,
    ExposureEvolution.Compact40Pratt.prime_65302553]

def block45 : Witness := ⟨⟨65399569, 65431920, 8089, 8093, 8101, 65399039, 65399093, 65399563⟩, 10⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8089,
    ExposureEvolution.Compact40Pratt.prime_8093,
    ExposureEvolution.Compact40Pratt.prime_8101,
    ExposureEvolution.Compact40Pratt.prime_65399039,
    ExposureEvolution.Compact40Pratt.prime_65399093,
    ExposureEvolution.Compact40Pratt.prime_65399563]

def block46 : Witness := ⟨⟨65431921, 65496648, 8093, 8101, 8111, 65431547, 65431673, 65431913⟩, 11⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8093,
    ExposureEvolution.Compact40Pratt.prime_8101,
    ExposureEvolution.Compact40Pratt.prime_8111,
    ExposureEvolution.Compact40Pratt.prime_65431547,
    ExposureEvolution.Compact40Pratt.prime_65431673,
    ExposureEvolution.Compact40Pratt.prime_65431913]

def block47 : Witness := ⟨⟨65496649, 65626200, 8101, 8111, 8117, 65495987, 65495993, 65496647⟩, 10⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8101,
    ExposureEvolution.Compact40Pratt.prime_8111,
    ExposureEvolution.Compact40Pratt.prime_8117,
    ExposureEvolution.Compact40Pratt.prime_65495987,
    ExposureEvolution.Compact40Pratt.prime_65495993,
    ExposureEvolution.Compact40Pratt.prime_65496647]

def block48 : Witness := ⟨⟨65626201, 65788320, 8111, 8117, 8123, 65625809, 65626037, 65626193⟩, 9⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8111,
    ExposureEvolution.Compact40Pratt.prime_8117,
    ExposureEvolution.Compact40Pratt.prime_8123,
    ExposureEvolution.Compact40Pratt.prime_65625809,
    ExposureEvolution.Compact40Pratt.prime_65626037,
    ExposureEvolution.Compact40Pratt.prime_65626193]

def block49 : Witness := ⟨⟨65788321, 65885688, 8117, 8123, 8147, 65787737, 65788157, 65788319⟩, 10⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8117,
    ExposureEvolution.Compact40Pratt.prime_8123,
    ExposureEvolution.Compact40Pratt.prime_8147,
    ExposureEvolution.Compact40Pratt.prime_65787737,
    ExposureEvolution.Compact40Pratt.prime_65788157,
    ExposureEvolution.Compact40Pratt.prime_65788319]

def block50 : Witness := ⟨⟨65885689, 65983128, 8123, 8147, 8161, 65885311, 65885333, 65885669⟩, 10⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8123,
    ExposureEvolution.Compact40Pratt.prime_8147,
    ExposureEvolution.Compact40Pratt.prime_8161,
    ExposureEvolution.Compact40Pratt.prime_65885311,
    ExposureEvolution.Compact40Pratt.prime_65885333,
    ExposureEvolution.Compact40Pratt.prime_65885669]

def block51 : Witness := ⟨⟨65983129, 66373608, 8147, 8161, 8167, 65982659, 65983009, 65983121⟩, 7⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8147,
    ExposureEvolution.Compact40Pratt.prime_8161,
    ExposureEvolution.Compact40Pratt.prime_8167,
    ExposureEvolution.Compact40Pratt.prime_65982659,
    ExposureEvolution.Compact40Pratt.prime_65983009,
    ExposureEvolution.Compact40Pratt.prime_65983121]

def block52 : Witness := ⟨⟨66373609, 66601920, 8161, 8167, 8171, 66373187, 66373339, 66373603⟩, 9⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8161,
    ExposureEvolution.Compact40Pratt.prime_8167,
    ExposureEvolution.Compact40Pratt.prime_8171,
    ExposureEvolution.Compact40Pratt.prime_66373187,
    ExposureEvolution.Compact40Pratt.prime_66373339,
    ExposureEvolution.Compact40Pratt.prime_66373603]

def block53 : Witness := ⟨⟨66601921, 66699888, 8167, 8171, 8179, 66601693, 66601747, 66601901⟩, 8⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8167,
    ExposureEvolution.Compact40Pratt.prime_8171,
    ExposureEvolution.Compact40Pratt.prime_8179,
    ExposureEvolution.Compact40Pratt.prime_66601693,
    ExposureEvolution.Compact40Pratt.prime_66601747,
    ExposureEvolution.Compact40Pratt.prime_66601901]

def block54 : Witness := ⟨⟨66699889, 66765240, 8171, 8179, 8191, 66699649, 66699761, 66699847⟩, 15⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8171,
    ExposureEvolution.Compact40Pratt.prime_8179,
    ExposureEvolution.Compact40Pratt.prime_8191,
    ExposureEvolution.Compact40Pratt.prime_66699649,
    ExposureEvolution.Compact40Pratt.prime_66699761,
    ExposureEvolution.Compact40Pratt.prime_66699847]

def block55 : Witness := ⟨⟨66765241, 66896040, 8179, 8191, 8209, 66765059, 66765199, 66765211⟩, 7⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8179,
    ExposureEvolution.Compact40Pratt.prime_8191,
    ExposureEvolution.Compact40Pratt.prime_8209,
    ExposureEvolution.Compact40Pratt.prime_66765059,
    ExposureEvolution.Compact40Pratt.prime_66765199,
    ExposureEvolution.Compact40Pratt.prime_66765211]

def block56 : Witness := ⟨⟨66896041, 67092480, 8191, 8209, 8219, 66895771, 66895943, 66896033⟩, 8⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8191,
    ExposureEvolution.Compact40Pratt.prime_8209,
    ExposureEvolution.Compact40Pratt.prime_8219,
    ExposureEvolution.Compact40Pratt.prime_66895771,
    ExposureEvolution.Compact40Pratt.prime_66895943,
    ExposureEvolution.Compact40Pratt.prime_66896033]

def block57 : Witness := ⟨⟨67092481, 67387680, 8209, 8219, 8221, 67092001, 67092367, 67092461⟩, 8⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8209,
    ExposureEvolution.Compact40Pratt.prime_8219,
    ExposureEvolution.Compact40Pratt.prime_8221,
    ExposureEvolution.Compact40Pratt.prime_67092001,
    ExposureEvolution.Compact40Pratt.prime_67092367,
    ExposureEvolution.Compact40Pratt.prime_67092461]

def block58 : Witness := ⟨⟨67387681, 67551960, 8219, 8221, 8231, 67387517, 67387627, 67387679⟩, 7⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8219,
    ExposureEvolution.Compact40Pratt.prime_8221,
    ExposureEvolution.Compact40Pratt.prime_8231,
    ExposureEvolution.Compact40Pratt.prime_67387517,
    ExposureEvolution.Compact40Pratt.prime_67387627,
    ExposureEvolution.Compact40Pratt.prime_67387679]

def block59 : Witness := ⟨⟨67551961, 67584840, 8221, 8231, 8233, 67551619, 67551703, 67551959⟩, 8⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8221,
    ExposureEvolution.Compact40Pratt.prime_8231,
    ExposureEvolution.Compact40Pratt.prime_8233,
    ExposureEvolution.Compact40Pratt.prime_67551619,
    ExposureEvolution.Compact40Pratt.prime_67551703,
    ExposureEvolution.Compact40Pratt.prime_67551959]

def block60 : Witness := ⟨⟨67584841, 67749360, 8231, 8233, 8237, 67584331, 67584599, 67584817⟩, 7⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8231,
    ExposureEvolution.Compact40Pratt.prime_8233,
    ExposureEvolution.Compact40Pratt.prime_8237,
    ExposureEvolution.Compact40Pratt.prime_67584331,
    ExposureEvolution.Compact40Pratt.prime_67584599,
    ExposureEvolution.Compact40Pratt.prime_67584817]

def block61 : Witness := ⟨⟨67749361, 67782288, 8233, 8237, 8243, 67749181, 67749251, 67749349⟩, 9⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8233,
    ExposureEvolution.Compact40Pratt.prime_8237,
    ExposureEvolution.Compact40Pratt.prime_8243,
    ExposureEvolution.Compact40Pratt.prime_67749181,
    ExposureEvolution.Compact40Pratt.prime_67749251,
    ExposureEvolution.Compact40Pratt.prime_67749349]

def block62 : Witness := ⟨⟨67782289, 67848168, 8237, 8243, 8263, 67781801, 67781893, 67782277⟩, 10⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8237,
    ExposureEvolution.Compact40Pratt.prime_8243,
    ExposureEvolution.Compact40Pratt.prime_8263,
    ExposureEvolution.Compact40Pratt.prime_67781801,
    ExposureEvolution.Compact40Pratt.prime_67781893,
    ExposureEvolution.Compact40Pratt.prime_67782277]

def block63 : Witness := ⟨⟨67848169, 67947048, 8243, 8263, 8269, 67847777, 67847779, 67848167⟩, 12⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_8243,
    ExposureEvolution.Compact40Pratt.prime_8263,
    ExposureEvolution.Compact40Pratt.prime_8269,
    ExposureEvolution.Compact40Pratt.prime_67847777,
    ExposureEvolution.Compact40Pratt.prime_67847779,
    ExposureEvolution.Compact40Pratt.prime_67848167]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 67947049 stop tail = true) :
    coverage 58507201 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_010
