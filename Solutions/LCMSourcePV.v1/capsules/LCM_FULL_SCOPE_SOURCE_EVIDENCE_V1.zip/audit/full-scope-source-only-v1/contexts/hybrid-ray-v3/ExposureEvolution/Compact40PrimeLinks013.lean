import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks013
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_34913 : next 34913 = some 35027 := by
  have hl : (List.range ((257 * 34913 - 1) / 256 - 34913)).reverse =
      [135, 134, 133, 132, 131, 130, 129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_35027]

theorem next_35027 : next 35027 = some 35159 := by
  have hl : (List.range ((257 * 35027 - 1) / 256 - 35027)).reverse =
      [135, 134, 133, 132, 131] ++ (List.range 131).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_35159]

theorem next_35159 : next 35159 = some 35291 := by
  have hl : (List.range ((257 * 35159 - 1) / 256 - 35159)).reverse =
      [136, 135, 134, 133, 132, 131] ++ (List.range 131).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_35291]

theorem next_35291 : next 35291 = some 35423 := by
  have hl : (List.range ((257 * 35291 - 1) / 256 - 35291)).reverse =
      [136, 135, 134, 133, 132, 131] ++ (List.range 131).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_35423]

theorem next_35423 : next 35423 = some 35543 := by
  have hl : (List.range ((257 * 35423 - 1) / 256 - 35423)).reverse =
      [137, 136, 135, 134, 133, 132, 131, 130, 129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119] ++ (List.range 119).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_35543]

theorem next_35543 : next 35543 = some 35677 := by
  have hl : (List.range ((257 * 35543 - 1) / 256 - 35543)).reverse =
      [137, 136, 135, 134, 133] ++ (List.range 133).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_35677]

theorem next_35677 : next 35677 = some 35809 := by
  have hl : (List.range ((257 * 35677 - 1) / 256 - 35677)).reverse =
      [138, 137, 136, 135, 134, 133, 132, 131] ++ (List.range 131).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_35809]

theorem next_35809 : next 35809 = some 35933 := by
  have hl : (List.range ((257 * 35809 - 1) / 256 - 35809)).reverse =
      [138, 137, 136, 135, 134, 133, 132, 131, 130, 129, 128, 127, 126, 125, 124, 123] ++ (List.range 123).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_35933]

theorem next_35933 : next 35933 = some 36073 := by
  have hl : (List.range ((257 * 35933 - 1) / 256 - 35933)).reverse =
      [139] ++ (List.range 139).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_36073]

theorem next_36073 : next 36073 = some 36209 := by
  have hl : (List.range ((257 * 36073 - 1) / 256 - 36073)).reverse =
      [139, 138, 137, 136, 135] ++ (List.range 135).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_36209]

theorem next_36209 : next 36209 = some 36343 := by
  have hl : (List.range ((257 * 36209 - 1) / 256 - 36209)).reverse =
      [140, 139, 138, 137, 136, 135, 134, 133] ++ (List.range 133).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_36343]

theorem next_36343 : next 36343 = some 36479 := by
  have hl : (List.range ((257 * 36343 - 1) / 256 - 36343)).reverse =
      [140, 139, 138, 137, 136, 135] ++ (List.range 135).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_36479]

theorem next_36479 : next 36479 = some 36607 := by
  have hl : (List.range ((257 * 36479 - 1) / 256 - 36479)).reverse =
      [141, 140, 139, 138, 137, 136, 135, 134, 133, 132, 131, 130, 129, 128, 127] ++ (List.range 127).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_36607]

theorem next_36607 : next 36607 = some 36749 := by
  have hl : (List.range ((257 * 36607 - 1) / 256 - 36607)).reverse =
      [141] ++ (List.range 141).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_36749]

theorem next_36749 : next 36749 = some 36887 := by
  have hl : (List.range ((257 * 36749 - 1) / 256 - 36749)).reverse =
      [142, 141, 140, 139, 138, 137] ++ (List.range 137).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_36887]

theorem next_36887 : next 36887 = some 37021 := by
  have hl : (List.range ((257 * 36887 - 1) / 256 - 36887)).reverse =
      [143, 142, 141, 140, 139, 138, 137, 136, 135, 134, 133] ++ (List.range 133).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_37021]

theorem next_37021 : next 37021 = some 37159 := by
  have hl : (List.range ((257 * 37021 - 1) / 256 - 37021)).reverse =
      [143, 142, 141, 140, 139, 138, 137] ++ (List.range 137).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_37159]

theorem next_37159 : next 37159 = some 37277 := by
  have hl : (List.range ((257 * 37159 - 1) / 256 - 37159)).reverse =
      [144, 143, 142, 141, 140, 139, 138, 137, 136, 135, 134, 133, 132, 131, 130, 129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119, 118, 117] ++ (List.range 117).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_37277]

theorem next_37277 : next 37277 = some 37409 := by
  have hl : (List.range ((257 * 37277 - 1) / 256 - 37277)).reverse =
      [144, 143, 142, 141, 140, 139, 138, 137, 136, 135, 134, 133, 132, 131] ++ (List.range 131).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_37409]

theorem next_37409 : next 37409 = some 37549 := by
  have hl : (List.range ((257 * 37409 - 1) / 256 - 37409)).reverse =
      [145, 144, 143, 142, 141, 140, 139] ++ (List.range 139).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_37549]

theorem next_37549 : next 37549 = some 37693 := by
  have hl : (List.range ((257 * 37549 - 1) / 256 - 37549)).reverse =
      [145, 144, 143] ++ (List.range 143).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_37693]

theorem next_37693 : next 37693 = some 37831 := by
  have hl : (List.range ((257 * 37693 - 1) / 256 - 37693)).reverse =
      [146, 145, 144, 143, 142, 141, 140, 139, 138, 137] ++ (List.range 137).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_37831]

theorem next_37831 : next 37831 = some 37967 := by
  have hl : (List.range ((257 * 37831 - 1) / 256 - 37831)).reverse =
      [146, 145, 144, 143, 142, 141, 140, 139, 138, 137, 136, 135] ++ (List.range 135).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_37967]

theorem next_37967 : next 37967 = some 38113 := by
  have hl : (List.range ((257 * 37967 - 1) / 256 - 37967)).reverse =
      [147, 146, 145] ++ (List.range 145).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_38113]

theorem next_38113 : next 38113 = some 38261 := by
  have hl : (List.range ((257 * 38113 - 1) / 256 - 38113)).reverse =
      [147] ++ (List.range 147).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_38261]

theorem next_38261 : next 38261 = some 38393 := by
  have hl : (List.range ((257 * 38261 - 1) / 256 - 38261)).reverse =
      [148, 147, 146, 145, 144, 143, 142, 141, 140, 139, 138, 137, 136, 135, 134, 133, 132, 131] ++ (List.range 131).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_38393]

theorem next_38393 : next 38393 = some 38501 := by
  have hl : (List.range ((257 * 38393 - 1) / 256 - 38393)).reverse =
      [148, 147, 146, 145, 144, 143, 142, 141, 140, 139, 138, 137, 136, 135, 134, 133, 132, 131, 130, 129, 128, 127, 126, 125, 124, 123, 122, 121, 120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_38501]

theorem next_38501 : next 38501 = some 38651 := by
  have hl : (List.range ((257 * 38501 - 1) / 256 - 38501)).reverse =
      [149] ++ (List.range 149).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_38651]

theorem next_38651 : next 38651 = some 38791 := by
  have hl : (List.range ((257 * 38651 - 1) / 256 - 38651)).reverse =
      [149, 148, 147, 146, 145, 144, 143, 142, 141, 140, 139] ++ (List.range 139).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_38791]

theorem next_38791 : next 38791 = some 38933 := by
  have hl : (List.range ((257 * 38791 - 1) / 256 - 38791)).reverse =
      [150, 149, 148, 147, 146, 145, 144, 143, 142, 141] ++ (List.range 141).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_38933]

theorem next_38933 : next 38933 = some 39079 := by
  have hl : (List.range ((257 * 38933 - 1) / 256 - 38933)).reverse =
      [151, 150, 149, 148, 147, 146, 145] ++ (List.range 145).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_39079]

theorem next_39079 : next 39079 = some 39229 := by
  have hl : (List.range ((257 * 39079 - 1) / 256 - 39079)).reverse =
      [151, 150, 149] ++ (List.range 149).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_39229]

def primes : List ℕ := [35027, 35159, 35291, 35423, 35543, 35677, 35809, 35933, 36073, 36209, 36343, 36479, 36607, 36749, 36887, 37021, 37159, 37277, 37409, 37549, 37693, 37831, 37967, 38113, 38261, 38393, 38501, 38651, 38791, 38933, 39079, 39229]

theorem segment : run 284 34913 89693 =
    primes ++ run 252 39229 89693 := by
  rw [Compact40PrimeCompose256.step 283 34913 89693 35027
    (by decide +kernel) next_34913]
  rw [Compact40PrimeCompose256.step 282 35027 89693 35159
    (by decide +kernel) next_35027]
  rw [Compact40PrimeCompose256.step 281 35159 89693 35291
    (by decide +kernel) next_35159]
  rw [Compact40PrimeCompose256.step 280 35291 89693 35423
    (by decide +kernel) next_35291]
  rw [Compact40PrimeCompose256.step 279 35423 89693 35543
    (by decide +kernel) next_35423]
  rw [Compact40PrimeCompose256.step 278 35543 89693 35677
    (by decide +kernel) next_35543]
  rw [Compact40PrimeCompose256.step 277 35677 89693 35809
    (by decide +kernel) next_35677]
  rw [Compact40PrimeCompose256.step 276 35809 89693 35933
    (by decide +kernel) next_35809]
  rw [Compact40PrimeCompose256.step 275 35933 89693 36073
    (by decide +kernel) next_35933]
  rw [Compact40PrimeCompose256.step 274 36073 89693 36209
    (by decide +kernel) next_36073]
  rw [Compact40PrimeCompose256.step 273 36209 89693 36343
    (by decide +kernel) next_36209]
  rw [Compact40PrimeCompose256.step 272 36343 89693 36479
    (by decide +kernel) next_36343]
  rw [Compact40PrimeCompose256.step 271 36479 89693 36607
    (by decide +kernel) next_36479]
  rw [Compact40PrimeCompose256.step 270 36607 89693 36749
    (by decide +kernel) next_36607]
  rw [Compact40PrimeCompose256.step 269 36749 89693 36887
    (by decide +kernel) next_36749]
  rw [Compact40PrimeCompose256.step 268 36887 89693 37021
    (by decide +kernel) next_36887]
  rw [Compact40PrimeCompose256.step 267 37021 89693 37159
    (by decide +kernel) next_37021]
  rw [Compact40PrimeCompose256.step 266 37159 89693 37277
    (by decide +kernel) next_37159]
  rw [Compact40PrimeCompose256.step 265 37277 89693 37409
    (by decide +kernel) next_37277]
  rw [Compact40PrimeCompose256.step 264 37409 89693 37549
    (by decide +kernel) next_37409]
  rw [Compact40PrimeCompose256.step 263 37549 89693 37693
    (by decide +kernel) next_37549]
  rw [Compact40PrimeCompose256.step 262 37693 89693 37831
    (by decide +kernel) next_37693]
  rw [Compact40PrimeCompose256.step 261 37831 89693 37967
    (by decide +kernel) next_37831]
  rw [Compact40PrimeCompose256.step 260 37967 89693 38113
    (by decide +kernel) next_37967]
  rw [Compact40PrimeCompose256.step 259 38113 89693 38261
    (by decide +kernel) next_38113]
  rw [Compact40PrimeCompose256.step 258 38261 89693 38393
    (by decide +kernel) next_38261]
  rw [Compact40PrimeCompose256.step 257 38393 89693 38501
    (by decide +kernel) next_38393]
  rw [Compact40PrimeCompose256.step 256 38501 89693 38651
    (by decide +kernel) next_38501]
  rw [Compact40PrimeCompose256.step 255 38651 89693 38791
    (by decide +kernel) next_38651]
  rw [Compact40PrimeCompose256.step 254 38791 89693 38933
    (by decide +kernel) next_38791]
  rw [Compact40PrimeCompose256.step 253 38933 89693 39079
    (by decide +kernel) next_38933]
  rw [Compact40PrimeCompose256.step 252 39079 89693 39229
    (by decide +kernel) next_39079]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 39229 stop tail = true) :
    check 34913 stop (primes ++ tail) = true := by
  change check _ _ (35027 :: 35159 :: 35291 :: 35423 :: 35543 :: 35677 :: 35809 :: 35933 :: 36073 :: 36209 :: 36343 :: 36479 :: 36607 :: 36749 :: 36887 :: 37021 :: 37159 :: 37277 :: 37409 :: 37549 :: 37693 :: 37831 :: 37967 :: 38113 :: 38261 :: 38393 :: 38501 :: 38651 :: 38791 :: 38933 :: 39079 :: 39229 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_35027, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_35159, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_35291, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_35423, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_35543, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_35677, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_35809, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_35933, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_36073, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_36209, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_36343, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_36479, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_36607, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_36749, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_36887, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_37021, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_37159, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_37277, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_37409, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_37549, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_37693, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_37831, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_37967, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_38113, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_38261, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_38393, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_38501, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_38651, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_38791, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_38933, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_39079, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_39229, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks013
