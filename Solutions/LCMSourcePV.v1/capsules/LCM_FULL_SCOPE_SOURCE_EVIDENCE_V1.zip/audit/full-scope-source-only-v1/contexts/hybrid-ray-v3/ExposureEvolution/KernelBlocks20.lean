import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks20
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨38576521, 38651088, 6217, 6221, 6229, 38576287, 38576477, 38576513⟩, 9⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6217,
    ExposureEvolution.KernelPratt.prime_6221,
    ExposureEvolution.KernelPratt.prime_6229,
    ExposureEvolution.KernelPratt.prime_38576287,
    ExposureEvolution.KernelPratt.prime_38576477,
    ExposureEvolution.KernelPratt.prime_38576513]

def block01 : Witness := ⟨⟨38651089, 38700840, 6221, 6229, 6247, 38650631, 38650837, 38651087⟩, 10⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6221,
    ExposureEvolution.KernelPratt.prime_6229,
    ExposureEvolution.KernelPratt.prime_6247,
    ExposureEvolution.KernelPratt.prime_38650631,
    ExposureEvolution.KernelPratt.prime_38650837,
    ExposureEvolution.KernelPratt.prime_38651087]

def block02 : Witness := ⟨⟨38700841, 38800440, 6229, 6247, 6257, 38700419, 38700481, 38700839⟩, 11⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6229,
    ExposureEvolution.KernelPratt.prime_6247,
    ExposureEvolution.KernelPratt.prime_6257,
    ExposureEvolution.KernelPratt.prime_38700419,
    ExposureEvolution.KernelPratt.prime_38700481,
    ExposureEvolution.KernelPratt.prime_38700839]

def block03 : Witness := ⟨⟨38800441, 39025008, 6247, 6257, 6263, 38799923, 38800367, 38800393⟩, 8⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6247,
    ExposureEvolution.KernelPratt.prime_6257,
    ExposureEvolution.KernelPratt.prime_6263,
    ExposureEvolution.KernelPratt.prime_38799923,
    ExposureEvolution.KernelPratt.prime_38800367,
    ExposureEvolution.KernelPratt.prime_38800393]

def block04 : Witness := ⟨⟨39025009, 39150048, 6257, 6263, 6269, 39024457, 39024487, 39024983⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6257,
    ExposureEvolution.KernelPratt.prime_6263,
    ExposureEvolution.KernelPratt.prime_6269,
    ExposureEvolution.KernelPratt.prime_39024457,
    ExposureEvolution.KernelPratt.prime_39024487,
    ExposureEvolution.KernelPratt.prime_39024983]

def block05 : Witness := ⟨⟨39150049, 39225168, 6263, 6269, 6271, 39149833, 39150017, 39150037⟩, 14⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6263,
    ExposureEvolution.KernelPratt.prime_6269,
    ExposureEvolution.KernelPratt.prime_6271,
    ExposureEvolution.KernelPratt.prime_39149833,
    ExposureEvolution.KernelPratt.prime_39150017,
    ExposureEvolution.KernelPratt.prime_39150037]

def block06 : Witness := ⟨⟨39225169, 39300360, 6269, 6271, 6277, 39224687, 39225049, 39225091⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6269,
    ExposureEvolution.KernelPratt.prime_6271,
    ExposureEvolution.KernelPratt.prime_6277,
    ExposureEvolution.KernelPratt.prime_39224687,
    ExposureEvolution.KernelPratt.prime_39225049,
    ExposureEvolution.KernelPratt.prime_39225091]

def block07 : Witness := ⟨⟨39300361, 39325440, 6271, 6277, 6287, 39299947, 39300167, 39300337⟩, 8⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6271,
    ExposureEvolution.KernelPratt.prime_6277,
    ExposureEvolution.KernelPratt.prime_6287,
    ExposureEvolution.KernelPratt.prime_39299947,
    ExposureEvolution.KernelPratt.prime_39300167,
    ExposureEvolution.KernelPratt.prime_39300337]

def block08 : Witness := ⟨⟨39325441, 39400728, 6277, 6287, 6299, 39324827, 39325241, 39325411⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6277,
    ExposureEvolution.KernelPratt.prime_6287,
    ExposureEvolution.KernelPratt.prime_6299,
    ExposureEvolution.KernelPratt.prime_39324827,
    ExposureEvolution.KernelPratt.prime_39325241,
    ExposureEvolution.KernelPratt.prime_39325411]

def block09 : Witness := ⟨⟨39400729, 39526368, 6287, 6299, 6301, 39400391, 39400393, 39400703⟩, 9⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6287,
    ExposureEvolution.KernelPratt.prime_6299,
    ExposureEvolution.KernelPratt.prime_6301,
    ExposureEvolution.KernelPratt.prime_39400391,
    ExposureEvolution.KernelPratt.prime_39400393,
    ExposureEvolution.KernelPratt.prime_39400703]

def block10 : Witness := ⟨⟨39526369, 39677400, 6299, 6301, 6311, 39525737, 39525803, 39526367⟩, 10⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6299,
    ExposureEvolution.KernelPratt.prime_6301,
    ExposureEvolution.KernelPratt.prime_6311,
    ExposureEvolution.KernelPratt.prime_39525737,
    ExposureEvolution.KernelPratt.prime_39525803,
    ExposureEvolution.KernelPratt.prime_39526367]

def block11 : Witness := ⟨⟨39677401, 39702600, 6301, 6311, 6317, 39676927, 39677387, 39677399⟩, 8⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6301,
    ExposureEvolution.KernelPratt.prime_6311,
    ExposureEvolution.KernelPratt.prime_6317,
    ExposureEvolution.KernelPratt.prime_39676927,
    ExposureEvolution.KernelPratt.prime_39677387,
    ExposureEvolution.KernelPratt.prime_39677399]

def block12 : Witness := ⟨⟨39702601, 39828720, 6311, 6317, 6323, 39701969, 39702007, 39702569⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6311,
    ExposureEvolution.KernelPratt.prime_6317,
    ExposureEvolution.KernelPratt.prime_6323,
    ExposureEvolution.KernelPratt.prime_39701969,
    ExposureEvolution.KernelPratt.prime_39702007,
    ExposureEvolution.KernelPratt.prime_39702569]

def block13 : Witness := ⟨⟨39828721, 39904488, 6317, 6323, 6329, 39828401, 39828497, 39828713⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6317,
    ExposureEvolution.KernelPratt.prime_6323,
    ExposureEvolution.KernelPratt.prime_6329,
    ExposureEvolution.KernelPratt.prime_39828401,
    ExposureEvolution.KernelPratt.prime_39828497,
    ExposureEvolution.KernelPratt.prime_39828713]

def block14 : Witness := ⟨⟨39904489, 39980328, 6323, 6329, 6337, 39904429, 39904441, 39904477⟩, 12⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6323,
    ExposureEvolution.KernelPratt.prime_6329,
    ExposureEvolution.KernelPratt.prime_6337,
    ExposureEvolution.KernelPratt.prime_39904429,
    ExposureEvolution.KernelPratt.prime_39904441,
    ExposureEvolution.KernelPratt.prime_39904477]

def block15 : Witness := ⟨⟨39980329, 40056240, 6329, 6337, 6343, 39980167, 39980249, 39980327⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6329,
    ExposureEvolution.KernelPratt.prime_6337,
    ExposureEvolution.KernelPratt.prime_6343,
    ExposureEvolution.KernelPratt.prime_39980167,
    ExposureEvolution.KernelPratt.prime_39980249,
    ExposureEvolution.KernelPratt.prime_39980327]

def block16 : Witness := ⟨⟨40056241, 40157568, 6337, 6343, 6353, 40055957, 40056019, 40056229⟩, 14⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6337,
    ExposureEvolution.KernelPratt.prime_6343,
    ExposureEvolution.KernelPratt.prime_6353,
    ExposureEvolution.KernelPratt.prime_40055957,
    ExposureEvolution.KernelPratt.prime_40056019,
    ExposureEvolution.KernelPratt.prime_40056229]

def block17 : Witness := ⟨⟨40157569, 40233648, 6343, 6353, 6359, 40157119, 40157147, 40157567⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6343,
    ExposureEvolution.KernelPratt.prime_6353,
    ExposureEvolution.KernelPratt.prime_6359,
    ExposureEvolution.KernelPratt.prime_40157119,
    ExposureEvolution.KernelPratt.prime_40157147,
    ExposureEvolution.KernelPratt.prime_40157567]

def block18 : Witness := ⟨⟨40233649, 40360608, 6353, 6359, 6361, 40233181, 40233379, 40233631⟩, 11⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6353,
    ExposureEvolution.KernelPratt.prime_6359,
    ExposureEvolution.KernelPratt.prime_6361,
    ExposureEvolution.KernelPratt.prime_40233181,
    ExposureEvolution.KernelPratt.prime_40233379,
    ExposureEvolution.KernelPratt.prime_40233631]

def block19 : Witness := ⟨⟨40360609, 40436880, 6359, 6361, 6367, 40360387, 40360597, 40360603⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6359,
    ExposureEvolution.KernelPratt.prime_6361,
    ExposureEvolution.KernelPratt.prime_6367,
    ExposureEvolution.KernelPratt.prime_40360387,
    ExposureEvolution.KernelPratt.prime_40360597,
    ExposureEvolution.KernelPratt.prime_40360603]

def block20 : Witness := ⟨⟨40436881, 40462320, 6361, 6367, 6373, 40436359, 40436453, 40436867⟩, 9⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6361,
    ExposureEvolution.KernelPratt.prime_6367,
    ExposureEvolution.KernelPratt.prime_6373,
    ExposureEvolution.KernelPratt.prime_40436359,
    ExposureEvolution.KernelPratt.prime_40436453,
    ExposureEvolution.KernelPratt.prime_40436867]

def block21 : Witness := ⟨⟨40462321, 40538688, 6367, 6373, 6379, 40461713, 40462133, 40462319⟩, 11⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6367,
    ExposureEvolution.KernelPratt.prime_6373,
    ExposureEvolution.KernelPratt.prime_6379,
    ExposureEvolution.KernelPratt.prime_40461713,
    ExposureEvolution.KernelPratt.prime_40462133,
    ExposureEvolution.KernelPratt.prime_40462319]

def block22 : Witness := ⟨⟨40538689, 40615128, 6373, 6379, 6389, 40538161, 40538629, 40538683⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6373,
    ExposureEvolution.KernelPratt.prime_6379,
    ExposureEvolution.KernelPratt.prime_6389,
    ExposureEvolution.KernelPratt.prime_40538161,
    ExposureEvolution.KernelPratt.prime_40538629,
    ExposureEvolution.KernelPratt.prime_40538683]

def block23 : Witness := ⟨⟨40615129, 40691640, 6379, 6389, 6397, 40614689, 40615049, 40615123⟩, 6⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6379,
    ExposureEvolution.KernelPratt.prime_6389,
    ExposureEvolution.KernelPratt.prime_6397,
    ExposureEvolution.KernelPratt.prime_40614689,
    ExposureEvolution.KernelPratt.prime_40615049,
    ExposureEvolution.KernelPratt.prime_40615123]

def block24 : Witness := ⟨⟨40691641, 40819320, 6389, 6397, 6421, 40691113, 40691509, 40691633⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6389,
    ExposureEvolution.KernelPratt.prime_6397,
    ExposureEvolution.KernelPratt.prime_6421,
    ExposureEvolution.KernelPratt.prime_40691113,
    ExposureEvolution.KernelPratt.prime_40691509,
    ExposureEvolution.KernelPratt.prime_40691633]

def block25 : Witness := ⟨⟨40819321, 40921608, 6397, 6421, 6427, 40819117, 40819213, 40819291⟩, 8⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6397,
    ExposureEvolution.KernelPratt.prime_6421,
    ExposureEvolution.KernelPratt.prime_6427,
    ExposureEvolution.KernelPratt.prime_40819117,
    ExposureEvolution.KernelPratt.prime_40819213,
    ExposureEvolution.KernelPratt.prime_40819291]

def block26 : Witness := ⟨⟨40921609, 41229240, 6421, 6427, 6449, 40921367, 40921469, 40921603⟩, 9⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6421,
    ExposureEvolution.KernelPratt.prime_6427,
    ExposureEvolution.KernelPratt.prime_6449,
    ExposureEvolution.KernelPratt.prime_40921367,
    ExposureEvolution.KernelPratt.prime_40921469,
    ExposureEvolution.KernelPratt.prime_40921603]

def block27 : Witness := ⟨⟨41229241, 41306328, 6427, 6449, 6451, 41229007, 41229049, 41229197⟩, 5⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6427,
    ExposureEvolution.KernelPratt.prime_6449,
    ExposureEvolution.KernelPratt.prime_6451,
    ExposureEvolution.KernelPratt.prime_41229007,
    ExposureEvolution.KernelPratt.prime_41229049,
    ExposureEvolution.KernelPratt.prime_41229197]

def block28 : Witness := ⟨⟨41306329, 41589600, 6449, 6451, 6469, 41305837, 41306257, 41306327⟩, 8⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6449,
    ExposureEvolution.KernelPratt.prime_6451,
    ExposureEvolution.KernelPratt.prime_6469,
    ExposureEvolution.KernelPratt.prime_41305837,
    ExposureEvolution.KernelPratt.prime_41306257,
    ExposureEvolution.KernelPratt.prime_41306327]

def block29 : Witness := ⟨⟨41589601, 41615400, 6451, 6469, 6473, 41589413, 41589481, 41589563⟩, 7⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6451,
    ExposureEvolution.KernelPratt.prime_6469,
    ExposureEvolution.KernelPratt.prime_6473,
    ExposureEvolution.KernelPratt.prime_41589413,
    ExposureEvolution.KernelPratt.prime_41589481,
    ExposureEvolution.KernelPratt.prime_41589563]

def block30 : Witness := ⟨⟨41615401, 41847960, 6469, 6473, 6481, 41614999, 41615059, 41615393⟩, 14⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6469,
    ExposureEvolution.KernelPratt.prime_6473,
    ExposureEvolution.KernelPratt.prime_6481,
    ExposureEvolution.KernelPratt.prime_41614999,
    ExposureEvolution.KernelPratt.prime_41615059,
    ExposureEvolution.KernelPratt.prime_41615393]

def block31 : Witness := ⟨⟨41847961, 41899728, 6473, 6481, 6491, 41847571, 41847929, 41847943⟩, 8⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_6473,
    ExposureEvolution.KernelPratt.prime_6481,
    ExposureEvolution.KernelPratt.prime_6491,
    ExposureEvolution.KernelPratt.prime_41847571,
    ExposureEvolution.KernelPratt.prime_41847929,
    ExposureEvolution.KernelPratt.prime_41847943]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 41899729 stop tail = true) :
    coverage 38576521 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks20
