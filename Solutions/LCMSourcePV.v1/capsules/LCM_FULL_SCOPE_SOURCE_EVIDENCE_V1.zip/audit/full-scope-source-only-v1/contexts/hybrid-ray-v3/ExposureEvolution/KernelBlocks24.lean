import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks24
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨54007801, 54037200, 7351, 7369, 7393, 54007579, 54007649, 54007799⟩, 9⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7351,
    ExposureEvolution.KernelPratt.prime_7369,
    ExposureEvolution.KernelPratt.prime_7393,
    ExposureEvolution.KernelPratt.prime_54007579,
    ExposureEvolution.KernelPratt.prime_54007649,
    ExposureEvolution.KernelPratt.prime_54007799]

def block01 : Witness := ⟨⟨54037201, 54302160, 7369, 7393, 7411, 54037133, 54037141, 54037171⟩, 10⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7369,
    ExposureEvolution.KernelPratt.prime_7393,
    ExposureEvolution.KernelPratt.prime_7411,
    ExposureEvolution.KernelPratt.prime_54037133,
    ExposureEvolution.KernelPratt.prime_54037141,
    ExposureEvolution.KernelPratt.prime_54037171]

def block02 : Witness := ⟨⟨54302161, 54656448, 7393, 7411, 7417, 54301501, 54301661, 54302147⟩, 9⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7393,
    ExposureEvolution.KernelPratt.prime_7411,
    ExposureEvolution.KernelPratt.prime_7417,
    ExposureEvolution.KernelPratt.prime_54301501,
    ExposureEvolution.KernelPratt.prime_54301661,
    ExposureEvolution.KernelPratt.prime_54302147]

def block03 : Witness := ⟨⟨54656449, 54922920, 7411, 7417, 7433, 54655973, 54656219, 54656429⟩, 7⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7411,
    ExposureEvolution.KernelPratt.prime_7417,
    ExposureEvolution.KernelPratt.prime_7433,
    ExposureEvolution.KernelPratt.prime_54655973,
    ExposureEvolution.KernelPratt.prime_54656219,
    ExposureEvolution.KernelPratt.prime_54656429]

def block04 : Witness := ⟨⟨54922921, 55011888, 7417, 7433, 7451, 54922489, 54922663, 54922867⟩, 10⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7417,
    ExposureEvolution.KernelPratt.prime_7433,
    ExposureEvolution.KernelPratt.prime_7451,
    ExposureEvolution.KernelPratt.prime_54922489,
    ExposureEvolution.KernelPratt.prime_54922663,
    ExposureEvolution.KernelPratt.prime_54922867]

def block05 : Witness := ⟨⟨55011889, 55249488, 7433, 7451, 7457, 55011379, 55011731, 55011871⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7433,
    ExposureEvolution.KernelPratt.prime_7451,
    ExposureEvolution.KernelPratt.prime_7457,
    ExposureEvolution.KernelPratt.prime_55011379,
    ExposureEvolution.KernelPratt.prime_55011731,
    ExposureEvolution.KernelPratt.prime_55011871]

def block06 : Witness := ⟨⟨55249489, 55517400, 7451, 7457, 7459, 55249091, 55249213, 55249477⟩, 13⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7451,
    ExposureEvolution.KernelPratt.prime_7457,
    ExposureEvolution.KernelPratt.prime_7459,
    ExposureEvolution.KernelPratt.prime_55249091,
    ExposureEvolution.KernelPratt.prime_55249213,
    ExposureEvolution.KernelPratt.prime_55249477]

def block07 : Witness := ⟨⟨55517401, 55606848, 7457, 7459, 7477, 55517149, 55517179, 55517389⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7457,
    ExposureEvolution.KernelPratt.prime_7459,
    ExposureEvolution.KernelPratt.prime_7477,
    ExposureEvolution.KernelPratt.prime_55517149,
    ExposureEvolution.KernelPratt.prime_55517179,
    ExposureEvolution.KernelPratt.prime_55517389]

def block08 : Witness := ⟨⟨55606849, 55636680, 7459, 7477, 7481, 55606349, 55606679, 55606841⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7459,
    ExposureEvolution.KernelPratt.prime_7477,
    ExposureEvolution.KernelPratt.prime_7481,
    ExposureEvolution.KernelPratt.prime_55606349,
    ExposureEvolution.KernelPratt.prime_55606679,
    ExposureEvolution.KernelPratt.prime_55606841]

def block09 : Witness := ⟨⟨55636681, 55905528, 7477, 7481, 7487, 55636547, 55636613, 55636663⟩, 7⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7477,
    ExposureEvolution.KernelPratt.prime_7481,
    ExposureEvolution.KernelPratt.prime_7487,
    ExposureEvolution.KernelPratt.prime_55636547,
    ExposureEvolution.KernelPratt.prime_55636613,
    ExposureEvolution.KernelPratt.prime_55636663]

def block10 : Witness := ⟨⟨55905529, 55965360, 7481, 7487, 7489, 55904843, 55905193, 55905491⟩, 9⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7481,
    ExposureEvolution.KernelPratt.prime_7487,
    ExposureEvolution.KernelPratt.prime_7489,
    ExposureEvolution.KernelPratt.prime_55904843,
    ExposureEvolution.KernelPratt.prime_55905193,
    ExposureEvolution.KernelPratt.prime_55905491]

def block11 : Witness := ⟨⟨55965361, 56055168, 7487, 7489, 7499, 55965043, 55965307, 55965353⟩, 11⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7487,
    ExposureEvolution.KernelPratt.prime_7489,
    ExposureEvolution.KernelPratt.prime_7499,
    ExposureEvolution.KernelPratt.prime_55965043,
    ExposureEvolution.KernelPratt.prime_55965307,
    ExposureEvolution.KernelPratt.prime_55965353]

def block12 : Witness := ⟨⟨56055169, 56085120, 7489, 7499, 7507, 56055029, 56055047, 56055151⟩, 13⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7489,
    ExposureEvolution.KernelPratt.prime_7499,
    ExposureEvolution.KernelPratt.prime_7507,
    ExposureEvolution.KernelPratt.prime_56055029,
    ExposureEvolution.KernelPratt.prime_56055047,
    ExposureEvolution.KernelPratt.prime_56055151]

def block13 : Witness := ⟨⟨56085121, 56235000, 7499, 7507, 7517, 56084729, 56085067, 56085119⟩, 8⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7499,
    ExposureEvolution.KernelPratt.prime_7507,
    ExposureEvolution.KernelPratt.prime_7517,
    ExposureEvolution.KernelPratt.prime_56084729,
    ExposureEvolution.KernelPratt.prime_56085067,
    ExposureEvolution.KernelPratt.prime_56085119]

def block14 : Witness := ⟨⟨56235001, 56355048, 7507, 7517, 7523, 56234617, 56234803, 56234987⟩, 10⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7507,
    ExposureEvolution.KernelPratt.prime_7517,
    ExposureEvolution.KernelPratt.prime_7523,
    ExposureEvolution.KernelPratt.prime_56234617,
    ExposureEvolution.KernelPratt.prime_56234803,
    ExposureEvolution.KernelPratt.prime_56234987]

def block15 : Witness := ⟨⟨56355049, 56505288, 7517, 7523, 7529, 56354723, 56354773, 56355041⟩, 7⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7517,
    ExposureEvolution.KernelPratt.prime_7523,
    ExposureEvolution.KernelPratt.prime_7529,
    ExposureEvolution.KernelPratt.prime_56354723,
    ExposureEvolution.KernelPratt.prime_56354773,
    ExposureEvolution.KernelPratt.prime_56355041]

def block16 : Witness := ⟨⟨56505289, 56595528, 7523, 7529, 7537, 56505103, 56505131, 56505283⟩, 8⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7523,
    ExposureEvolution.KernelPratt.prime_7529,
    ExposureEvolution.KernelPratt.prime_7537,
    ExposureEvolution.KernelPratt.prime_56505103,
    ExposureEvolution.KernelPratt.prime_56505131,
    ExposureEvolution.KernelPratt.prime_56505283]

def block17 : Witness := ⟨⟨56595529, 56685840, 7529, 7537, 7541, 56595017, 56595173, 56595463⟩, 11⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7529,
    ExposureEvolution.KernelPratt.prime_7537,
    ExposureEvolution.KernelPratt.prime_7541,
    ExposureEvolution.KernelPratt.prime_56595017,
    ExposureEvolution.KernelPratt.prime_56595173,
    ExposureEvolution.KernelPratt.prime_56595463]

def block18 : Witness := ⟨⟨56685841, 56806368, 7537, 7541, 7547, 56685457, 56685767, 56685833⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7537,
    ExposureEvolution.KernelPratt.prime_7541,
    ExposureEvolution.KernelPratt.prime_7547,
    ExposureEvolution.KernelPratt.prime_56685457,
    ExposureEvolution.KernelPratt.prime_56685767,
    ExposureEvolution.KernelPratt.prime_56685833]

def block19 : Witness := ⟨⟨56806369, 56866680, 7541, 7547, 7549, 56806201, 56806223, 56806363⟩, 10⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7541,
    ExposureEvolution.KernelPratt.prime_7547,
    ExposureEvolution.KernelPratt.prime_7549,
    ExposureEvolution.KernelPratt.prime_56806201,
    ExposureEvolution.KernelPratt.prime_56806223,
    ExposureEvolution.KernelPratt.prime_56806363]

def block20 : Witness := ⟨⟨56866681, 56957208, 7547, 7549, 7559, 56866079, 56866223, 56866643⟩, 9⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7547,
    ExposureEvolution.KernelPratt.prime_7549,
    ExposureEvolution.KernelPratt.prime_7559,
    ExposureEvolution.KernelPratt.prime_56866079,
    ExposureEvolution.KernelPratt.prime_56866223,
    ExposureEvolution.KernelPratt.prime_56866643]

def block21 : Witness := ⟨⟨56957209, 56987400, 7549, 7559, 7561, 56956877, 56956909, 56957207⟩, 8⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7549,
    ExposureEvolution.KernelPratt.prime_7559,
    ExposureEvolution.KernelPratt.prime_7561,
    ExposureEvolution.KernelPratt.prime_56956877,
    ExposureEvolution.KernelPratt.prime_56956909,
    ExposureEvolution.KernelPratt.prime_56957207]

def block22 : Witness := ⟨⟨56987401, 57138480, 7559, 7561, 7573, 56986777, 56987087, 56987351⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7559,
    ExposureEvolution.KernelPratt.prime_7561,
    ExposureEvolution.KernelPratt.prime_7573,
    ExposureEvolution.KernelPratt.prime_56986777,
    ExposureEvolution.KernelPratt.prime_56987087,
    ExposureEvolution.KernelPratt.prime_56987351]

def block23 : Witness := ⟨⟨57138481, 57168720, 7561, 7573, 7577, 57138143, 57138287, 57138413⟩, 9⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7561,
    ExposureEvolution.KernelPratt.prime_7573,
    ExposureEvolution.KernelPratt.prime_7577,
    ExposureEvolution.KernelPratt.prime_57138143,
    ExposureEvolution.KernelPratt.prime_57138287,
    ExposureEvolution.KernelPratt.prime_57138413]

def block24 : Witness := ⟨⟨57168721, 57350328, 7573, 7577, 7583, 57168427, 57168523, 57168689⟩, 9⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7573,
    ExposureEvolution.KernelPratt.prime_7577,
    ExposureEvolution.KernelPratt.prime_7583,
    ExposureEvolution.KernelPratt.prime_57168427,
    ExposureEvolution.KernelPratt.prime_57168523,
    ExposureEvolution.KernelPratt.prime_57168689]

def block25 : Witness := ⟨⟨57350329, 57410928, 7577, 7583, 7589, 57349727, 57350221, 57350327⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7577,
    ExposureEvolution.KernelPratt.prime_7583,
    ExposureEvolution.KernelPratt.prime_7589,
    ExposureEvolution.KernelPratt.prime_57349727,
    ExposureEvolution.KernelPratt.prime_57350221,
    ExposureEvolution.KernelPratt.prime_57350327]

def block26 : Witness := ⟨⟨57410929, 57501888, 7583, 7589, 7591, 57410677, 57410747, 57410917⟩, 7⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7583,
    ExposureEvolution.KernelPratt.prime_7589,
    ExposureEvolution.KernelPratt.prime_7591,
    ExposureEvolution.KernelPratt.prime_57410677,
    ExposureEvolution.KernelPratt.prime_57410747,
    ExposureEvolution.KernelPratt.prime_57410917]

def block27 : Witness := ⟨⟨57501889, 57592920, 7589, 7591, 7603, 57501473, 57501481, 57501883⟩, 10⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7589,
    ExposureEvolution.KernelPratt.prime_7591,
    ExposureEvolution.KernelPratt.prime_7603,
    ExposureEvolution.KernelPratt.prime_57501473,
    ExposureEvolution.KernelPratt.prime_57501481,
    ExposureEvolution.KernelPratt.prime_57501883]

def block28 : Witness := ⟨⟨57592921, 57623280, 7591, 7603, 7607, 57592697, 57592853, 57592919⟩, 12⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7591,
    ExposureEvolution.KernelPratt.prime_7603,
    ExposureEvolution.KernelPratt.prime_7607,
    ExposureEvolution.KernelPratt.prime_57592697,
    ExposureEvolution.KernelPratt.prime_57592853,
    ExposureEvolution.KernelPratt.prime_57592919]

def block29 : Witness := ⟨⟨57623281, 57805608, 7603, 7607, 7621, 57623191, 57623231, 57623273⟩, 8⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7603,
    ExposureEvolution.KernelPratt.prime_7607,
    ExposureEvolution.KernelPratt.prime_7621,
    ExposureEvolution.KernelPratt.prime_57623191,
    ExposureEvolution.KernelPratt.prime_57623231,
    ExposureEvolution.KernelPratt.prime_57623273]

def block30 : Witness := ⟨⟨57805609, 57866448, 7607, 7621, 7639, 57805529, 57805567, 57805597⟩, 6⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7607,
    ExposureEvolution.KernelPratt.prime_7621,
    ExposureEvolution.KernelPratt.prime_7639,
    ExposureEvolution.KernelPratt.prime_57805529,
    ExposureEvolution.KernelPratt.prime_57805567,
    ExposureEvolution.KernelPratt.prime_57805597]

def block31 : Witness := ⟨⟨57866449, 58079640, 7621, 7639, 7643, 57866009, 57866209, 57866423⟩, 9⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_7621,
    ExposureEvolution.KernelPratt.prime_7639,
    ExposureEvolution.KernelPratt.prime_7643,
    ExposureEvolution.KernelPratt.prime_57866009,
    ExposureEvolution.KernelPratt.prime_57866209,
    ExposureEvolution.KernelPratt.prime_57866423]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 58079641 stop tail = true) :
    coverage 54007801 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks24
