import ExposureEvolution.Compact40PrimeProgram256
namespace ExposureEvolution.Compact40PrimeCompose256
open ExposureEvolution.Compact40PrimeProgram256
set_option Elab.async false

theorem step (fuel a b p : ℕ) (ha : ¬ b ≤ a) (hn : next a = some p) :
    run (fuel + 1) a b = p :: run fuel p b := by
  simp only [run, if_neg ha, hn]

theorem check_cons (a b p : ℕ) (ps : List ℕ)
    (hp : Nat.Prime p ∧ a < p ∧ 256 * p < 257 * a)
    (ht : check p b ps = true) : check a b (p :: ps) = true := by
  simpa only [check, Bool.and_eq_true, decide_eq_true_eq] using And.intro hp ht

end ExposureEvolution.Compact40PrimeCompose256
