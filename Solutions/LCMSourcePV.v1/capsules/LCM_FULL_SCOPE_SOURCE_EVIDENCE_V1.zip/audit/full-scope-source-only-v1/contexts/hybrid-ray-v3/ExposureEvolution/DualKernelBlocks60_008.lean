import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_008
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨42523441, 42627840, 6529, 6547, 6551, 42523177, 42523381, 42523433⟩, 10⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6529,
    ExposureEvolution.Compact40Pratt.prime_6547,
    ExposureEvolution.Compact40Pratt.prime_6551,
    ExposureEvolution.Compact40Pratt.prime_42523177,
    ExposureEvolution.Compact40Pratt.prime_42523381,
    ExposureEvolution.Compact40Pratt.prime_42523433]

def block01 : Witness := ⟨⟨42627841, 42863208, 6547, 6551, 6553, 42627391, 42627713, 42627833⟩, 9⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6547,
    ExposureEvolution.Compact40Pratt.prime_6551,
    ExposureEvolution.Compact40Pratt.prime_6553,
    ExposureEvolution.Compact40Pratt.prime_42627391,
    ExposureEvolution.Compact40Pratt.prime_42627713,
    ExposureEvolution.Compact40Pratt.prime_42627833]

def block02 : Witness := ⟨⟨42863209, 42915600, 6551, 6553, 6563, 42863059, 42863123, 42863203⟩, 7⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6551,
    ExposureEvolution.Compact40Pratt.prime_6553,
    ExposureEvolution.Compact40Pratt.prime_6563,
    ExposureEvolution.Compact40Pratt.prime_42863059,
    ExposureEvolution.Compact40Pratt.prime_42863123,
    ExposureEvolution.Compact40Pratt.prime_42863203]

def block03 : Witness := ⟨⟨42915601, 42941808, 6553, 6563, 6569, 42915083, 42915209, 42915581⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6553,
    ExposureEvolution.Compact40Pratt.prime_6563,
    ExposureEvolution.Compact40Pratt.prime_6569,
    ExposureEvolution.Compact40Pratt.prime_42915083,
    ExposureEvolution.Compact40Pratt.prime_42915209,
    ExposureEvolution.Compact40Pratt.prime_42915581]

def block04 : Witness := ⟨⟨42941809, 43072968, 6563, 6569, 6571, 42941527, 42941629, 42941797⟩, 9⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6563,
    ExposureEvolution.Compact40Pratt.prime_6569,
    ExposureEvolution.Compact40Pratt.prime_6571,
    ExposureEvolution.Compact40Pratt.prime_42941527,
    ExposureEvolution.Compact40Pratt.prime_42941629,
    ExposureEvolution.Compact40Pratt.prime_42941797]

def block05 : Witness := ⟨⟨43072969, 43151760, 6569, 6571, 6577, 43072573, 43072651, 43072961⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6569,
    ExposureEvolution.Compact40Pratt.prime_6571,
    ExposureEvolution.Compact40Pratt.prime_6577,
    ExposureEvolution.Compact40Pratt.prime_43072573,
    ExposureEvolution.Compact40Pratt.prime_43072651,
    ExposureEvolution.Compact40Pratt.prime_43072961]

def block06 : Witness := ⟨⟨43151761, 43178040, 6571, 6577, 6581, 43151099, 43151309, 43151743⟩, 9⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6571,
    ExposureEvolution.Compact40Pratt.prime_6577,
    ExposureEvolution.Compact40Pratt.prime_6581,
    ExposureEvolution.Compact40Pratt.prime_43151099,
    ExposureEvolution.Compact40Pratt.prime_43151309,
    ExposureEvolution.Compact40Pratt.prime_43151743]

def block07 : Witness := ⟨⟨43178041, 43256928, 6577, 6581, 6599, 43177583, 43177609, 43178039⟩, 9⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6577,
    ExposureEvolution.Compact40Pratt.prime_6581,
    ExposureEvolution.Compact40Pratt.prime_6599,
    ExposureEvolution.Compact40Pratt.prime_43177583,
    ExposureEvolution.Compact40Pratt.prime_43177609,
    ExposureEvolution.Compact40Pratt.prime_43178039]

def block08 : Witness := ⟨⟨43256929, 43309560, 6581, 6599, 6607, 43256693, 43256761, 43256911⟩, 7⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6581,
    ExposureEvolution.Compact40Pratt.prime_6599,
    ExposureEvolution.Compact40Pratt.prime_6607,
    ExposureEvolution.Compact40Pratt.prime_43256693,
    ExposureEvolution.Compact40Pratt.prime_43256761,
    ExposureEvolution.Compact40Pratt.prime_43256911]

def block09 : Witness := ⟨⟨43309561, 43546800, 6599, 6607, 6619, 43309157, 43309289, 43309547⟩, 10⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6599,
    ExposureEvolution.Compact40Pratt.prime_6607,
    ExposureEvolution.Compact40Pratt.prime_6619,
    ExposureEvolution.Compact40Pratt.prime_43309157,
    ExposureEvolution.Compact40Pratt.prime_43309289,
    ExposureEvolution.Compact40Pratt.prime_43309547]

def block10 : Witness := ⟨⟨43546801, 43652448, 6607, 6619, 6637, 43546681, 43546687, 43546799⟩, 8⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6607,
    ExposureEvolution.Compact40Pratt.prime_6619,
    ExposureEvolution.Compact40Pratt.prime_6637,
    ExposureEvolution.Compact40Pratt.prime_43546681,
    ExposureEvolution.Compact40Pratt.prime_43546687,
    ExposureEvolution.Compact40Pratt.prime_43546799]

def block11 : Witness := ⟨⟨43652449, 43811160, 6619, 6637, 6653, 43651961, 43651981, 43652419⟩, 13⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6619,
    ExposureEvolution.Compact40Pratt.prime_6637,
    ExposureEvolution.Compact40Pratt.prime_6653,
    ExposureEvolution.Compact40Pratt.prime_43651961,
    ExposureEvolution.Compact40Pratt.prime_43651981,
    ExposureEvolution.Compact40Pratt.prime_43652419]

def block12 : Witness := ⟨⟨43811161, 44049768, 6637, 6653, 6659, 43810603, 43810609, 43811147⟩, 6⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6637,
    ExposureEvolution.Compact40Pratt.prime_6653,
    ExposureEvolution.Compact40Pratt.prime_6659,
    ExposureEvolution.Compact40Pratt.prime_43810603,
    ExposureEvolution.Compact40Pratt.prime_43810609,
    ExposureEvolution.Compact40Pratt.prime_43811147]

def block13 : Witness := ⟨⟨44049769, 44262408, 6653, 6659, 6661, 44049613, 44049661, 44049767⟩, 7⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6653,
    ExposureEvolution.Compact40Pratt.prime_6659,
    ExposureEvolution.Compact40Pratt.prime_6661,
    ExposureEvolution.Compact40Pratt.prime_44049613,
    ExposureEvolution.Compact40Pratt.prime_44049661,
    ExposureEvolution.Compact40Pratt.prime_44049767]

def block14 : Witness := ⟨⟨44262409, 44342280, 6659, 6661, 6673, 44262137, 44262193, 44262377⟩, 9⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6659,
    ExposureEvolution.Compact40Pratt.prime_6661,
    ExposureEvolution.Compact40Pratt.prime_6673,
    ExposureEvolution.Compact40Pratt.prime_44262137,
    ExposureEvolution.Compact40Pratt.prime_44262193,
    ExposureEvolution.Compact40Pratt.prime_44262377]

def block15 : Witness := ⟨⟨44342281, 44368920, 6661, 6673, 6679, 44342083, 44342107, 44342261⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6661,
    ExposureEvolution.Compact40Pratt.prime_6673,
    ExposureEvolution.Compact40Pratt.prime_6679,
    ExposureEvolution.Compact40Pratt.prime_44342083,
    ExposureEvolution.Compact40Pratt.prime_44342107,
    ExposureEvolution.Compact40Pratt.prime_44342261]

def block16 : Witness := ⟨⟨44368921, 44528928, 6673, 6679, 6689, 44368573, 44368631, 44368879⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6673,
    ExposureEvolution.Compact40Pratt.prime_6679,
    ExposureEvolution.Compact40Pratt.prime_6689,
    ExposureEvolution.Compact40Pratt.prime_44368573,
    ExposureEvolution.Compact40Pratt.prime_44368631,
    ExposureEvolution.Compact40Pratt.prime_44368879]

def block17 : Witness := ⟨⟨44528929, 44609040, 6679, 6689, 6691, 44528633, 44528773, 44528921⟩, 10⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6679,
    ExposureEvolution.Compact40Pratt.prime_6689,
    ExposureEvolution.Compact40Pratt.prime_6691,
    ExposureEvolution.Compact40Pratt.prime_44528633,
    ExposureEvolution.Compact40Pratt.prime_44528773,
    ExposureEvolution.Compact40Pratt.prime_44528921]

def block18 : Witness := ⟨⟨44609041, 44742720, 6689, 6691, 6701, 44608787, 44608997, 44609023⟩, 6⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6689,
    ExposureEvolution.Compact40Pratt.prime_6691,
    ExposureEvolution.Compact40Pratt.prime_6701,
    ExposureEvolution.Compact40Pratt.prime_44608787,
    ExposureEvolution.Compact40Pratt.prime_44608997,
    ExposureEvolution.Compact40Pratt.prime_44609023]

def block19 : Witness := ⟨⟨44742721, 44769480, 6691, 6701, 6703, 44742101, 44742277, 44742713⟩, 9⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6691,
    ExposureEvolution.Compact40Pratt.prime_6701,
    ExposureEvolution.Compact40Pratt.prime_6703,
    ExposureEvolution.Compact40Pratt.prime_44742101,
    ExposureEvolution.Compact40Pratt.prime_44742277,
    ExposureEvolution.Compact40Pratt.prime_44742713]

def block20 : Witness := ⟨⟨44769481, 44903400, 6701, 6703, 6709, 44769013, 44769391, 44769479⟩, 8⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6701,
    ExposureEvolution.Compact40Pratt.prime_6703,
    ExposureEvolution.Compact40Pratt.prime_6709,
    ExposureEvolution.Compact40Pratt.prime_44769013,
    ExposureEvolution.Compact40Pratt.prime_44769391,
    ExposureEvolution.Compact40Pratt.prime_44769479]

def block21 : Witness := ⟨⟨44903401, 44930208, 6703, 6709, 6719, 44902937, 44902943, 44903393⟩, 7⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6703,
    ExposureEvolution.Compact40Pratt.prime_6709,
    ExposureEvolution.Compact40Pratt.prime_6719,
    ExposureEvolution.Compact40Pratt.prime_44902937,
    ExposureEvolution.Compact40Pratt.prime_44902943,
    ExposureEvolution.Compact40Pratt.prime_44903393]

def block22 : Witness := ⟨⟨44930209, 45010680, 6709, 6719, 6733, 44930143, 44930189, 44930203⟩, 7⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6709,
    ExposureEvolution.Compact40Pratt.prime_6719,
    ExposureEvolution.Compact40Pratt.prime_6733,
    ExposureEvolution.Compact40Pratt.prime_44930143,
    ExposureEvolution.Compact40Pratt.prime_44930189,
    ExposureEvolution.Compact40Pratt.prime_44930203]

def block23 : Witness := ⟨⟨45010681, 45144960, 6719, 6733, 6737, 45010393, 45010477, 45010649⟩, 11⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6719,
    ExposureEvolution.Compact40Pratt.prime_6733,
    ExposureEvolution.Compact40Pratt.prime_6737,
    ExposureEvolution.Compact40Pratt.prime_45010393,
    ExposureEvolution.Compact40Pratt.prime_45010477,
    ExposureEvolution.Compact40Pratt.prime_45010649]

def block24 : Witness := ⟨⟨45144961, 45333288, 6733, 6737, 6761, 45144821, 45144901, 45144947⟩, 7⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6733,
    ExposureEvolution.Compact40Pratt.prime_6737,
    ExposureEvolution.Compact40Pratt.prime_6761,
    ExposureEvolution.Compact40Pratt.prime_45144821,
    ExposureEvolution.Compact40Pratt.prime_45144901,
    ExposureEvolution.Compact40Pratt.prime_45144947]

def block25 : Witness := ⟨⟨45333289, 45387168, 6737, 6761, 6763, 45333019, 45333089, 45333283⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6737,
    ExposureEvolution.Compact40Pratt.prime_6761,
    ExposureEvolution.Compact40Pratt.prime_6763,
    ExposureEvolution.Compact40Pratt.prime_45333019,
    ExposureEvolution.Compact40Pratt.prime_45333089,
    ExposureEvolution.Compact40Pratt.prime_45333283]

def block26 : Witness := ⟨⟨45387169, 45711120, 6761, 6763, 6779, 45386851, 45386863, 45387151⟩, 11⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6761,
    ExposureEvolution.Compact40Pratt.prime_6763,
    ExposureEvolution.Compact40Pratt.prime_6779,
    ExposureEvolution.Compact40Pratt.prime_45386851,
    ExposureEvolution.Compact40Pratt.prime_45386863,
    ExposureEvolution.Compact40Pratt.prime_45387151]

def block27 : Witness := ⟨⟨45711121, 45738168, 6763, 6779, 6781, 45711037, 45711089, 45711109⟩, 7⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6763,
    ExposureEvolution.Compact40Pratt.prime_6779,
    ExposureEvolution.Compact40Pratt.prime_6781,
    ExposureEvolution.Compact40Pratt.prime_45711037,
    ExposureEvolution.Compact40Pratt.prime_45711089,
    ExposureEvolution.Compact40Pratt.prime_45711109]

def block28 : Witness := ⟨⟨45738169, 45954840, 6779, 6781, 6791, 45738103, 45738131, 45738167⟩, 8⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6779,
    ExposureEvolution.Compact40Pratt.prime_6781,
    ExposureEvolution.Compact40Pratt.prime_6791,
    ExposureEvolution.Compact40Pratt.prime_45738103,
    ExposureEvolution.Compact40Pratt.prime_45738131,
    ExposureEvolution.Compact40Pratt.prime_45738167]

def block29 : Witness := ⟨⟨45954841, 45981960, 6781, 6791, 6793, 45954511, 45954607, 45954833⟩, 12⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6781,
    ExposureEvolution.Compact40Pratt.prime_6791,
    ExposureEvolution.Compact40Pratt.prime_6793,
    ExposureEvolution.Compact40Pratt.prime_45954511,
    ExposureEvolution.Compact40Pratt.prime_45954607,
    ExposureEvolution.Compact40Pratt.prime_45954833]

def block30 : Witness := ⟨⟨45981961, 46117680, 6791, 6793, 6803, 45981371, 45981937, 45981953⟩, 9⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6791,
    ExposureEvolution.Compact40Pratt.prime_6793,
    ExposureEvolution.Compact40Pratt.prime_6803,
    ExposureEvolution.Compact40Pratt.prime_45981371,
    ExposureEvolution.Compact40Pratt.prime_45981937,
    ExposureEvolution.Compact40Pratt.prime_45981953]

def block31 : Witness := ⟨⟨46117681, 46144848, 6793, 6803, 6823, 46117327, 46117451, 46117667⟩, 12⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6793,
    ExposureEvolution.Compact40Pratt.prime_6803,
    ExposureEvolution.Compact40Pratt.prime_6823,
    ExposureEvolution.Compact40Pratt.prime_46117327,
    ExposureEvolution.Compact40Pratt.prime_46117451,
    ExposureEvolution.Compact40Pratt.prime_46117667]

def block32 : Witness := ⟨⟨46144849, 46280808, 6803, 6823, 6827, 46144493, 46144669, 46144837⟩, 9⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6803,
    ExposureEvolution.Compact40Pratt.prime_6823,
    ExposureEvolution.Compact40Pratt.prime_6827,
    ExposureEvolution.Compact40Pratt.prime_46144493,
    ExposureEvolution.Compact40Pratt.prime_46144669,
    ExposureEvolution.Compact40Pratt.prime_46144837]

def block33 : Witness := ⟨⟨46280809, 46553328, 6823, 6827, 6829, 46280309, 46280519, 46280803⟩, 10⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6823,
    ExposureEvolution.Compact40Pratt.prime_6827,
    ExposureEvolution.Compact40Pratt.prime_6829,
    ExposureEvolution.Compact40Pratt.prime_46280309,
    ExposureEvolution.Compact40Pratt.prime_46280519,
    ExposureEvolution.Compact40Pratt.prime_46280803]

def block34 : Witness := ⟨⟨46553329, 46607928, 6827, 6829, 6833, 46552813, 46552969, 46553321⟩, 9⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6827,
    ExposureEvolution.Compact40Pratt.prime_6829,
    ExposureEvolution.Compact40Pratt.prime_6833,
    ExposureEvolution.Compact40Pratt.prime_46552813,
    ExposureEvolution.Compact40Pratt.prime_46552969,
    ExposureEvolution.Compact40Pratt.prime_46553321]

def block35 : Witness := ⟨⟨46607929, 46635240, 6829, 6833, 6841, 46607797, 46607839, 46607923⟩, 10⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6829,
    ExposureEvolution.Compact40Pratt.prime_6833,
    ExposureEvolution.Compact40Pratt.prime_6841,
    ExposureEvolution.Compact40Pratt.prime_46607797,
    ExposureEvolution.Compact40Pratt.prime_46607839,
    ExposureEvolution.Compact40Pratt.prime_46607923]

def block36 : Witness := ⟨⟨46635241, 46689888, 6833, 6841, 6857, 46634719, 46634743, 46635227⟩, 10⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6833,
    ExposureEvolution.Compact40Pratt.prime_6841,
    ExposureEvolution.Compact40Pratt.prime_6857,
    ExposureEvolution.Compact40Pratt.prime_46634719,
    ExposureEvolution.Compact40Pratt.prime_46634743,
    ExposureEvolution.Compact40Pratt.prime_46635227]

def block37 : Witness := ⟨⟨46689889, 46799280, 6841, 6857, 6863, 46689469, 46689607, 46689829⟩, 9⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6841,
    ExposureEvolution.Compact40Pratt.prime_6857,
    ExposureEvolution.Compact40Pratt.prime_6863,
    ExposureEvolution.Compact40Pratt.prime_46689469,
    ExposureEvolution.Compact40Pratt.prime_46689607,
    ExposureEvolution.Compact40Pratt.prime_46689829]

def block38 : Witness := ⟨⟨46799281, 47018448, 6857, 6863, 6869, 46798867, 46798993, 46799257⟩, 8⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6857,
    ExposureEvolution.Compact40Pratt.prime_6863,
    ExposureEvolution.Compact40Pratt.prime_6869,
    ExposureEvolution.Compact40Pratt.prime_46798867,
    ExposureEvolution.Compact40Pratt.prime_46798993,
    ExposureEvolution.Compact40Pratt.prime_46799257]

def block39 : Witness := ⟨⟨47018449, 47100768, 6863, 6869, 6871, 47018099, 47018333, 47018443⟩, 12⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6863,
    ExposureEvolution.Compact40Pratt.prime_6869,
    ExposureEvolution.Compact40Pratt.prime_6871,
    ExposureEvolution.Compact40Pratt.prime_47018099,
    ExposureEvolution.Compact40Pratt.prime_47018333,
    ExposureEvolution.Compact40Pratt.prime_47018443]

def block40 : Witness := ⟨⟨47100769, 47183160, 6869, 6871, 6883, 47100271, 47100631, 47100763⟩, 8⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6869,
    ExposureEvolution.Compact40Pratt.prime_6871,
    ExposureEvolution.Compact40Pratt.prime_6883,
    ExposureEvolution.Compact40Pratt.prime_47100271,
    ExposureEvolution.Compact40Pratt.prime_47100631,
    ExposureEvolution.Compact40Pratt.prime_47100763]

def block41 : Witness := ⟨⟨47183161, 47210640, 6871, 6883, 6899, 47182657, 47182693, 47183153⟩, 8⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6871,
    ExposureEvolution.Compact40Pratt.prime_6883,
    ExposureEvolution.Compact40Pratt.prime_6899,
    ExposureEvolution.Compact40Pratt.prime_47182657,
    ExposureEvolution.Compact40Pratt.prime_47182693,
    ExposureEvolution.Compact40Pratt.prime_47183153]

def block42 : Witness := ⟨⟨47210641, 47375688, 6883, 6899, 6907, 47210297, 47210357, 47210629⟩, 8⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6883,
    ExposureEvolution.Compact40Pratt.prime_6899,
    ExposureEvolution.Compact40Pratt.prime_6907,
    ExposureEvolution.Compact40Pratt.prime_47210297,
    ExposureEvolution.Compact40Pratt.prime_47210357,
    ExposureEvolution.Compact40Pratt.prime_47210629]

def block43 : Witness := ⟨⟨47375689, 47596200, 6899, 6907, 6911, 47375491, 47375677, 47375687⟩, 11⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6899,
    ExposureEvolution.Compact40Pratt.prime_6907,
    ExposureEvolution.Compact40Pratt.prime_6911,
    ExposureEvolution.Compact40Pratt.prime_47375491,
    ExposureEvolution.Compact40Pratt.prime_47375677,
    ExposureEvolution.Compact40Pratt.prime_47375687]

def block44 : Witness := ⟨⟨47596201, 47706648, 6907, 6911, 6917, 47595857, 47596189, 47596193⟩, 8⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6907,
    ExposureEvolution.Compact40Pratt.prime_6911,
    ExposureEvolution.Compact40Pratt.prime_6917,
    ExposureEvolution.Compact40Pratt.prime_47595857,
    ExposureEvolution.Compact40Pratt.prime_47596189,
    ExposureEvolution.Compact40Pratt.prime_47596193]

def block45 : Witness := ⟨⟨47706649, 47761920, 6911, 6917, 6947, 47706151, 47706181, 47706629⟩, 8⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6911,
    ExposureEvolution.Compact40Pratt.prime_6917,
    ExposureEvolution.Compact40Pratt.prime_6947,
    ExposureEvolution.Compact40Pratt.prime_47706151,
    ExposureEvolution.Compact40Pratt.prime_47706181,
    ExposureEvolution.Compact40Pratt.prime_47706629]

def block46 : Witness := ⟨⟨47761921, 47844888, 6917, 6947, 6949, 47761601, 47761699, 47761919⟩, 10⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6917,
    ExposureEvolution.Compact40Pratt.prime_6947,
    ExposureEvolution.Compact40Pratt.prime_6949,
    ExposureEvolution.Compact40Pratt.prime_47761601,
    ExposureEvolution.Compact40Pratt.prime_47761699,
    ExposureEvolution.Compact40Pratt.prime_47761919]

def block47 : Witness := ⟨⟨47844889, 48260808, 6947, 6949, 6959, 47844383, 47844607, 47844877⟩, 14⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6947,
    ExposureEvolution.Compact40Pratt.prime_6949,
    ExposureEvolution.Compact40Pratt.prime_6959,
    ExposureEvolution.Compact40Pratt.prime_47844383,
    ExposureEvolution.Compact40Pratt.prime_47844607,
    ExposureEvolution.Compact40Pratt.prime_47844877]

def block48 : Witness := ⟨⟨48260809, 48288600, 6949, 6959, 6961, 48260593, 48260789, 48260801⟩, 7⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6949,
    ExposureEvolution.Compact40Pratt.prime_6959,
    ExposureEvolution.Compact40Pratt.prime_6961,
    ExposureEvolution.Compact40Pratt.prime_48260593,
    ExposureEvolution.Compact40Pratt.prime_48260789,
    ExposureEvolution.Compact40Pratt.prime_48260801]

def block49 : Witness := ⟨⟨48288601, 48427680, 6959, 6961, 6967, 48288083, 48288323, 48288571⟩, 8⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6959,
    ExposureEvolution.Compact40Pratt.prime_6961,
    ExposureEvolution.Compact40Pratt.prime_6967,
    ExposureEvolution.Compact40Pratt.prime_48288083,
    ExposureEvolution.Compact40Pratt.prime_48288323,
    ExposureEvolution.Compact40Pratt.prime_48288571]

def block50 : Witness := ⟨⟨48427681, 48455520, 6961, 6967, 6971, 48427307, 48427649, 48427661⟩, 7⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6961,
    ExposureEvolution.Compact40Pratt.prime_6967,
    ExposureEvolution.Compact40Pratt.prime_6971,
    ExposureEvolution.Compact40Pratt.prime_48427307,
    ExposureEvolution.Compact40Pratt.prime_48427649,
    ExposureEvolution.Compact40Pratt.prime_48427661]

def block51 : Witness := ⟨⟨48455521, 48539088, 6967, 6971, 6977, 48454999, 48455131, 48455513⟩, 7⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6967,
    ExposureEvolution.Compact40Pratt.prime_6971,
    ExposureEvolution.Compact40Pratt.prime_6977,
    ExposureEvolution.Compact40Pratt.prime_48454999,
    ExposureEvolution.Compact40Pratt.prime_48455131,
    ExposureEvolution.Compact40Pratt.prime_48455513]

def block52 : Witness := ⟨⟨48539089, 48594840, 6971, 6977, 6983, 48538759, 48538781, 48539083⟩, 13⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6971,
    ExposureEvolution.Compact40Pratt.prime_6977,
    ExposureEvolution.Compact40Pratt.prime_6983,
    ExposureEvolution.Compact40Pratt.prime_48538759,
    ExposureEvolution.Compact40Pratt.prime_48538781,
    ExposureEvolution.Compact40Pratt.prime_48539083]

def block53 : Witness := ⟨⟨48594841, 48678528, 6977, 6983, 6991, 48594437, 48594479, 48594827⟩, 11⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6977,
    ExposureEvolution.Compact40Pratt.prime_6983,
    ExposureEvolution.Compact40Pratt.prime_6991,
    ExposureEvolution.Compact40Pratt.prime_48594437,
    ExposureEvolution.Compact40Pratt.prime_48594479,
    ExposureEvolution.Compact40Pratt.prime_48594827]

def block54 : Witness := ⟨⟨48678529, 48762288, 6983, 6991, 6997, 48678173, 48678251, 48678491⟩, 7⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6983,
    ExposureEvolution.Compact40Pratt.prime_6991,
    ExposureEvolution.Compact40Pratt.prime_6997,
    ExposureEvolution.Compact40Pratt.prime_48678173,
    ExposureEvolution.Compact40Pratt.prime_48678251,
    ExposureEvolution.Compact40Pratt.prime_48678491]

def block55 : Witness := ⟨⟨48762289, 48874080, 6991, 6997, 7001, 48761969, 48762011, 48762283⟩, 7⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6991,
    ExposureEvolution.Compact40Pratt.prime_6997,
    ExposureEvolution.Compact40Pratt.prime_7001,
    ExposureEvolution.Compact40Pratt.prime_48761969,
    ExposureEvolution.Compact40Pratt.prime_48762011,
    ExposureEvolution.Compact40Pratt.prime_48762283]

def block56 : Witness := ⟨⟨48874081, 48958008, 6997, 7001, 7013, 48873683, 48873973, 48874051⟩, 8⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_6997,
    ExposureEvolution.Compact40Pratt.prime_7001,
    ExposureEvolution.Compact40Pratt.prime_7013,
    ExposureEvolution.Compact40Pratt.prime_48873683,
    ExposureEvolution.Compact40Pratt.prime_48873973,
    ExposureEvolution.Compact40Pratt.prime_48874051]

def block57 : Witness := ⟨⟨48958009, 49014000, 7001, 7013, 7019, 48957653, 48957757, 48958001⟩, 11⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7001,
    ExposureEvolution.Compact40Pratt.prime_7013,
    ExposureEvolution.Compact40Pratt.prime_7019,
    ExposureEvolution.Compact40Pratt.prime_48957653,
    ExposureEvolution.Compact40Pratt.prime_48957757,
    ExposureEvolution.Compact40Pratt.prime_48958001]

def block58 : Witness := ⟨⟨49014001, 49182168, 7013, 7019, 7027, 49013803, 49013929, 49013971⟩, 10⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7013,
    ExposureEvolution.Compact40Pratt.prime_7019,
    ExposureEvolution.Compact40Pratt.prime_7027,
    ExposureEvolution.Compact40Pratt.prime_49013803,
    ExposureEvolution.Compact40Pratt.prime_49013929,
    ExposureEvolution.Compact40Pratt.prime_49013971]

def block59 : Witness := ⟨⟨49182169, 49266360, 7019, 7027, 7039, 49181617, 49181729, 49182149⟩, 12⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7019,
    ExposureEvolution.Compact40Pratt.prime_7027,
    ExposureEvolution.Compact40Pratt.prime_7039,
    ExposureEvolution.Compact40Pratt.prime_49181617,
    ExposureEvolution.Compact40Pratt.prime_49181729,
    ExposureEvolution.Compact40Pratt.prime_49182149]

def block60 : Witness := ⟨⟨49266361, 49378728, 7027, 7039, 7043, 49266229, 49266233, 49266353⟩, 8⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7027,
    ExposureEvolution.Compact40Pratt.prime_7039,
    ExposureEvolution.Compact40Pratt.prime_7043,
    ExposureEvolution.Compact40Pratt.prime_49266229,
    ExposureEvolution.Compact40Pratt.prime_49266233,
    ExposureEvolution.Compact40Pratt.prime_49266353]

def block61 : Witness := ⟨⟨49378729, 49547520, 7039, 7043, 7057, 49378267, 49378337, 49378709⟩, 8⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7039,
    ExposureEvolution.Compact40Pratt.prime_7043,
    ExposureEvolution.Compact40Pratt.prime_7057,
    ExposureEvolution.Compact40Pratt.prime_49378267,
    ExposureEvolution.Compact40Pratt.prime_49378337,
    ExposureEvolution.Compact40Pratt.prime_49378709]

def block62 : Witness := ⟨⟨49547521, 49603848, 7043, 7057, 7069, 49546999, 49547039, 49547513⟩, 8⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7043,
    ExposureEvolution.Compact40Pratt.prime_7057,
    ExposureEvolution.Compact40Pratt.prime_7069,
    ExposureEvolution.Compact40Pratt.prime_49546999,
    ExposureEvolution.Compact40Pratt.prime_49547039,
    ExposureEvolution.Compact40Pratt.prime_49547513]

def block63 : Witness := ⟨⟨49603849, 49801248, 7057, 7069, 7079, 49603327, 49603579, 49603831⟩, 8⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_7057,
    ExposureEvolution.Compact40Pratt.prime_7069,
    ExposureEvolution.Compact40Pratt.prime_7079,
    ExposureEvolution.Compact40Pratt.prime_49603327,
    ExposureEvolution.Compact40Pratt.prime_49603579,
    ExposureEvolution.Compact40Pratt.prime_49603831]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 49801249 stop tail = true) :
    coverage 42523441 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_008
