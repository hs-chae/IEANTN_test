import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks018
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_63179 : next 63179 = some 63421 := by
  have hl : (List.range ((257 * 63179 - 1) / 256 - 63179)).reverse =
      [245, 244, 243, 242, 241] ++ (List.range 241).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_63421]

theorem next_63421 : next 63421 = some 63667 := by
  have hl : (List.range ((257 * 63421 - 1) / 256 - 63421)).reverse =
      [246, 245] ++ (List.range 245).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_63667]

theorem next_63667 : next 63667 = some 63913 := by
  have hl : (List.range ((257 * 63667 - 1) / 256 - 63667)).reverse =
      [247, 246, 245] ++ (List.range 245).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_63913]

theorem next_63913 : next 63913 = some 64157 := by
  have hl : (List.range ((257 * 63913 - 1) / 256 - 63913)).reverse =
      [248, 247, 246, 245, 244, 243] ++ (List.range 243).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_64157]

theorem next_64157 : next 64157 = some 64403 := by
  have hl : (List.range ((257 * 64157 - 1) / 256 - 64157)).reverse =
      [249, 248, 247, 246, 245] ++ (List.range 245).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_64403]

theorem next_64403 : next 64403 = some 64633 := by
  have hl : (List.range ((257 * 64403 - 1) / 256 - 64403)).reverse =
      [250, 249, 248, 247, 246, 245, 244, 243, 242, 241, 240, 239, 238, 237, 236, 235, 234, 233, 232, 231, 230, 229] ++ (List.range 229).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_64633]

theorem next_64633 : next 64633 = some 64879 := by
  have hl : (List.range ((257 * 64633 - 1) / 256 - 64633)).reverse =
      [251, 250, 249, 248, 247, 246, 245] ++ (List.range 245).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_64879]

theorem next_64879 : next 64879 = some 65129 := by
  have hl : (List.range ((257 * 64879 - 1) / 256 - 64879)).reverse =
      [252, 251, 250, 249] ++ (List.range 249).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_65129]

theorem next_65129 : next 65129 = some 65381 := by
  have hl : (List.range ((257 * 65129 - 1) / 256 - 65129)).reverse =
      [253, 252, 251] ++ (List.range 251).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_65381]

theorem next_65381 : next 65381 = some 65633 := by
  have hl : (List.range ((257 * 65381 - 1) / 256 - 65381)).reverse =
      [254, 253, 252, 251] ++ (List.range 251).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_65633]

theorem next_65633 : next 65633 = some 65881 := by
  have hl : (List.range ((257 * 65633 - 1) / 256 - 65633)).reverse =
      [255, 254, 253, 252, 251, 250, 249, 248, 247] ++ (List.range 247).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_65881]

theorem next_65881 : next 65881 = some 66137 := by
  have hl : (List.range ((257 * 65881 - 1) / 256 - 65881)).reverse =
      [256, 255] ++ (List.range 255).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_66137]

theorem next_66137 : next 66137 = some 66383 := by
  have hl : (List.range ((257 * 66137 - 1) / 256 - 66137)).reverse =
      [257, 256, 255, 254, 253, 252, 251, 250, 249, 248, 247, 246, 245] ++ (List.range 245).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_66383]

theorem next_66383 : next 66383 = some 66629 := by
  have hl : (List.range ((257 * 66383 - 1) / 256 - 66383)).reverse =
      [258, 257, 256, 255, 254, 253, 252, 251, 250, 249, 248, 247, 246, 245] ++ (List.range 245).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_66629]

theorem next_66629 : next 66629 = some 66889 := by
  have hl : (List.range ((257 * 66629 - 1) / 256 - 66629)).reverse =
      [259] ++ (List.range 259).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_66889]

theorem next_66889 : next 66889 = some 67141 := by
  have hl : (List.range ((257 * 66889 - 1) / 256 - 66889)).reverse =
      [260, 259, 258, 257, 256, 255, 254, 253, 252, 251] ++ (List.range 251).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_67141]

theorem next_67141 : next 67141 = some 67399 := by
  have hl : (List.range ((257 * 67141 - 1) / 256 - 67141)).reverse =
      [261, 260, 259, 258, 257] ++ (List.range 257).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_67399]

theorem next_67399 : next 67399 = some 67651 := by
  have hl : (List.range ((257 * 67399 - 1) / 256 - 67399)).reverse =
      [262, 261, 260, 259, 258, 257, 256, 255, 254, 253, 252, 251] ++ (List.range 251).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_67651]

theorem next_67651 : next 67651 = some 67901 := by
  have hl : (List.range ((257 * 67651 - 1) / 256 - 67651)).reverse =
      [263, 262, 261, 260, 259, 258, 257, 256, 255, 254, 253, 252, 251, 250, 249] ++ (List.range 249).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_67901]

theorem next_67901 : next 67901 = some 68161 := by
  have hl : (List.range ((257 * 67901 - 1) / 256 - 67901)).reverse =
      [264, 263, 262, 261, 260, 259] ++ (List.range 259).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_68161]

theorem next_68161 : next 68161 = some 68399 := by
  have hl : (List.range ((257 * 68161 - 1) / 256 - 68161)).reverse =
      [265, 264, 263, 262, 261, 260, 259, 258, 257, 256, 255, 254, 253, 252, 251, 250, 249, 248, 247, 246, 245, 244, 243, 242, 241, 240, 239, 238, 237] ++ (List.range 237).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_68399]

theorem next_68399 : next 68399 = some 68659 := by
  have hl : (List.range ((257 * 68399 - 1) / 256 - 68399)).reverse =
      [266, 265, 264, 263, 262, 261, 260, 259] ++ (List.range 259).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_68659]

theorem next_68659 : next 68659 = some 68927 := by
  have hl : (List.range ((257 * 68659 - 1) / 256 - 68659)).reverse =
      [267] ++ (List.range 267).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_68927]

theorem next_68927 : next 68927 = some 69193 := by
  have hl : (List.range ((257 * 68927 - 1) / 256 - 68927)).reverse =
      [268, 267, 266, 265] ++ (List.range 265).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_69193]

theorem next_69193 : next 69193 = some 69463 := by
  have hl : (List.range ((257 * 69193 - 1) / 256 - 69193)).reverse =
      [269] ++ (List.range 269).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_69463]

theorem next_69463 : next 69463 = some 69709 := by
  have hl : (List.range ((257 * 69463 - 1) / 256 - 69463)).reverse =
      [270, 269, 268, 267, 266, 265, 264, 263, 262, 261, 260, 259, 258, 257, 256, 255, 254, 253, 252, 251, 250, 249, 248, 247, 246, 245] ++ (List.range 245).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_69709]

theorem next_69709 : next 69709 = some 69959 := by
  have hl : (List.range ((257 * 69709 - 1) / 256 - 69709)).reverse =
      [271, 270, 269, 268, 267, 266, 265, 264, 263, 262, 261, 260, 259, 258, 257, 256, 255, 254, 253, 252, 251, 250, 249] ++ (List.range 249).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_69959]

theorem next_69959 : next 69959 = some 70229 := by
  have hl : (List.range ((257 * 69959 - 1) / 256 - 69959)).reverse =
      [272, 271, 270, 269] ++ (List.range 269).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_70229]

theorem next_70229 : next 70229 = some 70501 := by
  have hl : (List.range ((257 * 70229 - 1) / 256 - 70229)).reverse =
      [273, 272, 271] ++ (List.range 271).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_70501]

theorem next_70501 : next 70501 = some 70769 := by
  have hl : (List.range ((257 * 70501 - 1) / 256 - 70501)).reverse =
      [274, 273, 272, 271, 270, 269, 268, 267] ++ (List.range 267).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_70769]

theorem next_70769 : next 70769 = some 71039 := by
  have hl : (List.range ((257 * 70769 - 1) / 256 - 70769)).reverse =
      [275, 274, 273, 272, 271, 270, 269] ++ (List.range 269).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_71039]

theorem next_71039 : next 71039 = some 71293 := by
  have hl : (List.range ((257 * 71039 - 1) / 256 - 71039)).reverse =
      [276, 275, 274, 273, 272, 271, 270, 269, 268, 267, 266, 265, 264, 263, 262, 261, 260, 259, 258, 257, 256, 255, 254, 253] ++ (List.range 253).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_71293]

def primes : List ℕ := [63421, 63667, 63913, 64157, 64403, 64633, 64879, 65129, 65381, 65633, 65881, 66137, 66383, 66629, 66889, 67141, 67399, 67651, 67901, 68161, 68399, 68659, 68927, 69193, 69463, 69709, 69959, 70229, 70501, 70769, 71039, 71293]

theorem segment : run 124 63179 89693 =
    primes ++ run 92 71293 89693 := by
  rw [Compact40PrimeCompose256.step 123 63179 89693 63421
    (by decide +kernel) next_63179]
  rw [Compact40PrimeCompose256.step 122 63421 89693 63667
    (by decide +kernel) next_63421]
  rw [Compact40PrimeCompose256.step 121 63667 89693 63913
    (by decide +kernel) next_63667]
  rw [Compact40PrimeCompose256.step 120 63913 89693 64157
    (by decide +kernel) next_63913]
  rw [Compact40PrimeCompose256.step 119 64157 89693 64403
    (by decide +kernel) next_64157]
  rw [Compact40PrimeCompose256.step 118 64403 89693 64633
    (by decide +kernel) next_64403]
  rw [Compact40PrimeCompose256.step 117 64633 89693 64879
    (by decide +kernel) next_64633]
  rw [Compact40PrimeCompose256.step 116 64879 89693 65129
    (by decide +kernel) next_64879]
  rw [Compact40PrimeCompose256.step 115 65129 89693 65381
    (by decide +kernel) next_65129]
  rw [Compact40PrimeCompose256.step 114 65381 89693 65633
    (by decide +kernel) next_65381]
  rw [Compact40PrimeCompose256.step 113 65633 89693 65881
    (by decide +kernel) next_65633]
  rw [Compact40PrimeCompose256.step 112 65881 89693 66137
    (by decide +kernel) next_65881]
  rw [Compact40PrimeCompose256.step 111 66137 89693 66383
    (by decide +kernel) next_66137]
  rw [Compact40PrimeCompose256.step 110 66383 89693 66629
    (by decide +kernel) next_66383]
  rw [Compact40PrimeCompose256.step 109 66629 89693 66889
    (by decide +kernel) next_66629]
  rw [Compact40PrimeCompose256.step 108 66889 89693 67141
    (by decide +kernel) next_66889]
  rw [Compact40PrimeCompose256.step 107 67141 89693 67399
    (by decide +kernel) next_67141]
  rw [Compact40PrimeCompose256.step 106 67399 89693 67651
    (by decide +kernel) next_67399]
  rw [Compact40PrimeCompose256.step 105 67651 89693 67901
    (by decide +kernel) next_67651]
  rw [Compact40PrimeCompose256.step 104 67901 89693 68161
    (by decide +kernel) next_67901]
  rw [Compact40PrimeCompose256.step 103 68161 89693 68399
    (by decide +kernel) next_68161]
  rw [Compact40PrimeCompose256.step 102 68399 89693 68659
    (by decide +kernel) next_68399]
  rw [Compact40PrimeCompose256.step 101 68659 89693 68927
    (by decide +kernel) next_68659]
  rw [Compact40PrimeCompose256.step 100 68927 89693 69193
    (by decide +kernel) next_68927]
  rw [Compact40PrimeCompose256.step 99 69193 89693 69463
    (by decide +kernel) next_69193]
  rw [Compact40PrimeCompose256.step 98 69463 89693 69709
    (by decide +kernel) next_69463]
  rw [Compact40PrimeCompose256.step 97 69709 89693 69959
    (by decide +kernel) next_69709]
  rw [Compact40PrimeCompose256.step 96 69959 89693 70229
    (by decide +kernel) next_69959]
  rw [Compact40PrimeCompose256.step 95 70229 89693 70501
    (by decide +kernel) next_70229]
  rw [Compact40PrimeCompose256.step 94 70501 89693 70769
    (by decide +kernel) next_70501]
  rw [Compact40PrimeCompose256.step 93 70769 89693 71039
    (by decide +kernel) next_70769]
  rw [Compact40PrimeCompose256.step 92 71039 89693 71293
    (by decide +kernel) next_71039]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 71293 stop tail = true) :
    check 63179 stop (primes ++ tail) = true := by
  change check _ _ (63421 :: 63667 :: 63913 :: 64157 :: 64403 :: 64633 :: 64879 :: 65129 :: 65381 :: 65633 :: 65881 :: 66137 :: 66383 :: 66629 :: 66889 :: 67141 :: 67399 :: 67651 :: 67901 :: 68161 :: 68399 :: 68659 :: 68927 :: 69193 :: 69463 :: 69709 :: 69959 :: 70229 :: 70501 :: 70769 :: 71039 :: 71293 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_63421, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_63667, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_63913, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_64157, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_64403, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_64633, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_64879, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_65129, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_65381, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_65633, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_65881, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_66137, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_66383, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_66629, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_66889, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_67141, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_67399, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_67651, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_67901, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_68161, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_68399, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_68659, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_68927, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_69193, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_69463, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_69709, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_69959, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_70229, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_70501, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_70769, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_71039, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_71293, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks018
