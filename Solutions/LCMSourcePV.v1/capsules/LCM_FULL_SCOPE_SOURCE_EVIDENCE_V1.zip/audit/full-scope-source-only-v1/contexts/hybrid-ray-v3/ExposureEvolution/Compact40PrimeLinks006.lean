import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks006
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_15797 : next 15797 = some 15823 := by
  have hl : (List.range ((257 * 15797 - 1) / 256 - 15797)).reverse =
      [60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25] ++ (List.range 25).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15823]

theorem next_15823 : next 15823 = some 15881 := by
  have hl : (List.range ((257 * 15823 - 1) / 256 - 15823)).reverse =
      [60, 59, 58, 57] ++ (List.range 57).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15881]

theorem next_15881 : next 15881 = some 15937 := by
  have hl : (List.range ((257 * 15881 - 1) / 256 - 15881)).reverse =
      [61, 60, 59, 58, 57, 56, 55] ++ (List.range 55).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15937]

theorem next_15937 : next 15937 = some 15991 := by
  have hl : (List.range ((257 * 15937 - 1) / 256 - 15937)).reverse =
      [61, 60, 59, 58, 57, 56, 55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_15991]

theorem next_15991 : next 15991 = some 16033 := by
  have hl : (List.range ((257 * 15991 - 1) / 256 - 15991)).reverse =
      [61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16033]

theorem next_16033 : next 16033 = some 16091 := by
  have hl : (List.range ((257 * 16033 - 1) / 256 - 16033)).reverse =
      [61, 60, 59, 58, 57] ++ (List.range 57).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16091]

theorem next_16091 : next 16091 = some 16141 := by
  have hl : (List.range ((257 * 16091 - 1) / 256 - 16091)).reverse =
      [61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49] ++ (List.range 49).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16141]

theorem next_16141 : next 16141 = some 16193 := by
  have hl : (List.range ((257 * 16141 - 1) / 256 - 16141)).reverse =
      [62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51] ++ (List.range 51).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16193]

theorem next_16193 : next 16193 = some 16253 := by
  have hl : (List.range ((257 * 16193 - 1) / 256 - 16193)).reverse =
      [62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16253]

theorem next_16253 : next 16253 = some 16301 := by
  have hl : (List.range ((257 * 16253 - 1) / 256 - 16253)).reverse =
      [62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16301]

theorem next_16301 : next 16301 = some 16363 := by
  have hl : (List.range ((257 * 16301 - 1) / 256 - 16301)).reverse =
      [62, 61] ++ (List.range 61).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16363]

theorem next_16363 : next 16363 = some 16421 := by
  have hl : (List.range ((257 * 16363 - 1) / 256 - 16363)).reverse =
      [62, 61, 60, 59, 58, 57] ++ (List.range 57).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16421]

theorem next_16421 : next 16421 = some 16481 := by
  have hl : (List.range ((257 * 16421 - 1) / 256 - 16421)).reverse =
      [63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16481]

theorem next_16481 : next 16481 = some 16529 := by
  have hl : (List.range ((257 * 16481 - 1) / 256 - 16481)).reverse =
      [63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47] ++ (List.range 47).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16529]

theorem next_16529 : next 16529 = some 16573 := by
  have hl : (List.range ((257 * 16529 - 1) / 256 - 16529)).reverse =
      [63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16573]

theorem next_16573 : next 16573 = some 16633 := by
  have hl : (List.range ((257 * 16573 - 1) / 256 - 16573)).reverse =
      [63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16633]

theorem next_16633 : next 16633 = some 16693 := by
  have hl : (List.range ((257 * 16633 - 1) / 256 - 16633)).reverse =
      [63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16693]

theorem next_16693 : next 16693 = some 16747 := by
  have hl : (List.range ((257 * 16693 - 1) / 256 - 16693)).reverse =
      [64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53] ++ (List.range 53).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16747]

theorem next_16747 : next 16747 = some 16811 := by
  have hl : (List.range ((257 * 16747 - 1) / 256 - 16747)).reverse =
      [64, 63] ++ (List.range 63).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16811]

theorem next_16811 : next 16811 = some 16871 := by
  have hl : (List.range ((257 * 16811 - 1) / 256 - 16811)).reverse =
      [64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16871]

theorem next_16871 : next 16871 = some 16931 := by
  have hl : (List.range ((257 * 16871 - 1) / 256 - 16871)).reverse =
      [64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16931]

theorem next_16931 : next 16931 = some 16993 := by
  have hl : (List.range ((257 * 16931 - 1) / 256 - 16931)).reverse =
      [65, 64, 63, 62, 61] ++ (List.range 61).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_16993]

theorem next_16993 : next 16993 = some 17053 := by
  have hl : (List.range ((257 * 16993 - 1) / 256 - 16993)).reverse =
      [65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17053]

theorem next_17053 : next 17053 = some 17117 := by
  have hl : (List.range ((257 * 17053 - 1) / 256 - 17053)).reverse =
      [65, 64, 63] ++ (List.range 63).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17117]

theorem next_17117 : next 17117 = some 17183 := by
  have hl : (List.range ((257 * 17117 - 1) / 256 - 17117)).reverse =
      [65] ++ (List.range 65).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17183]

theorem next_17183 : next 17183 = some 17239 := by
  have hl : (List.range ((257 * 17183 - 1) / 256 - 17183)).reverse =
      [66, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55] ++ (List.range 55).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17239]

theorem next_17239 : next 17239 = some 17299 := by
  have hl : (List.range ((257 * 17239 - 1) / 256 - 17239)).reverse =
      [66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17299]

theorem next_17299 : next 17299 = some 17359 := by
  have hl : (List.range ((257 * 17299 - 1) / 256 - 17299)).reverse =
      [66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17359]

theorem next_17359 : next 17359 = some 17419 := by
  have hl : (List.range ((257 * 17359 - 1) / 256 - 17359)).reverse =
      [66, 65, 64, 63, 62, 61, 60, 59] ++ (List.range 59).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17419]

theorem next_17419 : next 17419 = some 17483 := by
  have hl : (List.range ((257 * 17419 - 1) / 256 - 17419)).reverse =
      [67, 66, 65, 64, 63] ++ (List.range 63).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17483]

theorem next_17483 : next 17483 = some 17551 := by
  have hl : (List.range ((257 * 17483 - 1) / 256 - 17483)).reverse =
      [67] ++ (List.range 67).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17551]

theorem next_17551 : next 17551 = some 17609 := by
  have hl : (List.range ((257 * 17551 - 1) / 256 - 17551)).reverse =
      [67, 66, 65, 64, 63, 62, 61, 60, 59, 58, 57] ++ (List.range 57).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_17609]

def primes : List ℕ := [15823, 15881, 15937, 15991, 16033, 16091, 16141, 16193, 16253, 16301, 16363, 16421, 16481, 16529, 16573, 16633, 16693, 16747, 16811, 16871, 16931, 16993, 17053, 17117, 17183, 17239, 17299, 17359, 17419, 17483, 17551, 17609]

theorem segment : run 508 15797 89693 =
    primes ++ run 476 17609 89693 := by
  rw [Compact40PrimeCompose256.step 507 15797 89693 15823
    (by decide +kernel) next_15797]
  rw [Compact40PrimeCompose256.step 506 15823 89693 15881
    (by decide +kernel) next_15823]
  rw [Compact40PrimeCompose256.step 505 15881 89693 15937
    (by decide +kernel) next_15881]
  rw [Compact40PrimeCompose256.step 504 15937 89693 15991
    (by decide +kernel) next_15937]
  rw [Compact40PrimeCompose256.step 503 15991 89693 16033
    (by decide +kernel) next_15991]
  rw [Compact40PrimeCompose256.step 502 16033 89693 16091
    (by decide +kernel) next_16033]
  rw [Compact40PrimeCompose256.step 501 16091 89693 16141
    (by decide +kernel) next_16091]
  rw [Compact40PrimeCompose256.step 500 16141 89693 16193
    (by decide +kernel) next_16141]
  rw [Compact40PrimeCompose256.step 499 16193 89693 16253
    (by decide +kernel) next_16193]
  rw [Compact40PrimeCompose256.step 498 16253 89693 16301
    (by decide +kernel) next_16253]
  rw [Compact40PrimeCompose256.step 497 16301 89693 16363
    (by decide +kernel) next_16301]
  rw [Compact40PrimeCompose256.step 496 16363 89693 16421
    (by decide +kernel) next_16363]
  rw [Compact40PrimeCompose256.step 495 16421 89693 16481
    (by decide +kernel) next_16421]
  rw [Compact40PrimeCompose256.step 494 16481 89693 16529
    (by decide +kernel) next_16481]
  rw [Compact40PrimeCompose256.step 493 16529 89693 16573
    (by decide +kernel) next_16529]
  rw [Compact40PrimeCompose256.step 492 16573 89693 16633
    (by decide +kernel) next_16573]
  rw [Compact40PrimeCompose256.step 491 16633 89693 16693
    (by decide +kernel) next_16633]
  rw [Compact40PrimeCompose256.step 490 16693 89693 16747
    (by decide +kernel) next_16693]
  rw [Compact40PrimeCompose256.step 489 16747 89693 16811
    (by decide +kernel) next_16747]
  rw [Compact40PrimeCompose256.step 488 16811 89693 16871
    (by decide +kernel) next_16811]
  rw [Compact40PrimeCompose256.step 487 16871 89693 16931
    (by decide +kernel) next_16871]
  rw [Compact40PrimeCompose256.step 486 16931 89693 16993
    (by decide +kernel) next_16931]
  rw [Compact40PrimeCompose256.step 485 16993 89693 17053
    (by decide +kernel) next_16993]
  rw [Compact40PrimeCompose256.step 484 17053 89693 17117
    (by decide +kernel) next_17053]
  rw [Compact40PrimeCompose256.step 483 17117 89693 17183
    (by decide +kernel) next_17117]
  rw [Compact40PrimeCompose256.step 482 17183 89693 17239
    (by decide +kernel) next_17183]
  rw [Compact40PrimeCompose256.step 481 17239 89693 17299
    (by decide +kernel) next_17239]
  rw [Compact40PrimeCompose256.step 480 17299 89693 17359
    (by decide +kernel) next_17299]
  rw [Compact40PrimeCompose256.step 479 17359 89693 17419
    (by decide +kernel) next_17359]
  rw [Compact40PrimeCompose256.step 478 17419 89693 17483
    (by decide +kernel) next_17419]
  rw [Compact40PrimeCompose256.step 477 17483 89693 17551
    (by decide +kernel) next_17483]
  rw [Compact40PrimeCompose256.step 476 17551 89693 17609
    (by decide +kernel) next_17551]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 17609 stop tail = true) :
    check 15797 stop (primes ++ tail) = true := by
  change check _ _ (15823 :: 15881 :: 15937 :: 15991 :: 16033 :: 16091 :: 16141 :: 16193 :: 16253 :: 16301 :: 16363 :: 16421 :: 16481 :: 16529 :: 16573 :: 16633 :: 16693 :: 16747 :: 16811 :: 16871 :: 16931 :: 16993 :: 17053 :: 17117 :: 17183 :: 17239 :: 17299 :: 17359 :: 17419 :: 17483 :: 17551 :: 17609 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15823, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15881, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15937, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_15991, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16033, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16091, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16141, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16193, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16253, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16301, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16363, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16421, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16481, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16529, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16573, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16633, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16693, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16747, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16811, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16871, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16931, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_16993, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17053, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17117, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17183, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17239, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17299, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17359, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17419, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17483, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17551, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_17609, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks006
