import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks011
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_27689 : next 27689 = some 27793 := by
  have hl : (List.range ((257 * 27689 - 1) / 256 - 27689)).reverse =
      [107, 106, 105, 104, 103] ++ (List.range 103).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27793]

theorem next_27793 : next 27793 = some 27901 := by
  have hl : (List.range ((257 * 27793 - 1) / 256 - 27793)).reverse =
      [107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_27901]

theorem next_27901 : next 27901 = some 28001 := by
  have hl : (List.range ((257 * 27901 - 1) / 256 - 27901)).reverse =
      [107, 106, 105, 104, 103, 102, 101, 100, 99] ++ (List.range 99).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28001]

theorem next_28001 : next 28001 = some 28109 := by
  have hl : (List.range ((257 * 28001 - 1) / 256 - 28001)).reverse =
      [108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28109]

theorem next_28109 : next 28109 = some 28211 := by
  have hl : (List.range ((257 * 28109 - 1) / 256 - 28109)).reverse =
      [108, 107, 106, 105, 104, 103, 102, 101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28211]

theorem next_28211 : next 28211 = some 28319 := by
  have hl : (List.range ((257 * 28211 - 1) / 256 - 28211)).reverse =
      [109, 108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28319]

theorem next_28319 : next 28319 = some 28429 := by
  have hl : (List.range ((257 * 28319 - 1) / 256 - 28319)).reverse =
      [109] ++ (List.range 109).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28429]

theorem next_28429 : next 28429 = some 28537 := by
  have hl : (List.range ((257 * 28429 - 1) / 256 - 28429)).reverse =
      [110, 109, 108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28537]

theorem next_28537 : next 28537 = some 28643 := by
  have hl : (List.range ((257 * 28537 - 1) / 256 - 28537)).reverse =
      [110, 109, 108, 107, 106, 105] ++ (List.range 105).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28643]

theorem next_28643 : next 28643 = some 28753 := by
  have hl : (List.range ((257 * 28643 - 1) / 256 - 28643)).reverse =
      [110, 109] ++ (List.range 109).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28753]

theorem next_28753 : next 28753 = some 28859 := by
  have hl : (List.range ((257 * 28753 - 1) / 256 - 28753)).reverse =
      [111, 110, 109, 108, 107, 106, 105] ++ (List.range 105).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28859]

theorem next_28859 : next 28859 = some 28961 := by
  have hl : (List.range ((257 * 28859 - 1) / 256 - 28859)).reverse =
      [111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_28961]

theorem next_28961 : next 28961 = some 29063 := by
  have hl : (List.range ((257 * 28961 - 1) / 256 - 28961)).reverse =
      [112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29063]

theorem next_29063 : next 29063 = some 29173 := by
  have hl : (List.range ((257 * 29063 - 1) / 256 - 29063)).reverse =
      [112, 111, 110, 109] ++ (List.range 109).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29173]

theorem next_29173 : next 29173 = some 29269 := by
  have hl : (List.range ((257 * 29173 - 1) / 256 - 29173)).reverse =
      [112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 100, 99, 98, 97, 96, 95] ++ (List.range 95).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29269]

theorem next_29269 : next 29269 = some 29383 := by
  have hl : (List.range ((257 * 29269 - 1) / 256 - 29269)).reverse =
      [113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29383]

theorem next_29383 : next 29383 = some 29483 := by
  have hl : (List.range ((257 * 29383 - 1) / 256 - 29383)).reverse =
      [113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 100, 99] ++ (List.range 99).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29483]

theorem next_29483 : next 29483 = some 29587 := by
  have hl : (List.range ((257 * 29483 - 1) / 256 - 29483)).reverse =
      [114, 113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103] ++ (List.range 103).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29587]

theorem next_29587 : next 29587 = some 29683 := by
  have hl : (List.range ((257 * 29587 - 1) / 256 - 29587)).reverse =
      [114, 113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 100, 99, 98, 97, 96, 95] ++ (List.range 95).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29683]

theorem next_29683 : next 29683 = some 29789 := by
  have hl : (List.range ((257 * 29683 - 1) / 256 - 29683)).reverse =
      [114, 113, 112, 111, 110, 109, 108, 107, 106, 105] ++ (List.range 105).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29789]

theorem next_29789 : next 29789 = some 29881 := by
  have hl : (List.range ((257 * 29789 - 1) / 256 - 29789)).reverse =
      [115, 114, 113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 100, 99, 98, 97, 96, 95, 94, 93, 92, 91] ++ (List.range 91).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29881]

theorem next_29881 : next 29881 = some 29989 := by
  have hl : (List.range ((257 * 29881 - 1) / 256 - 29881)).reverse =
      [115, 114, 113, 112, 111, 110, 109, 108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_29989]

theorem next_29989 : next 29989 = some 30103 := by
  have hl : (List.range ((257 * 29989 - 1) / 256 - 29989)).reverse =
      [116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30103]

theorem next_30103 : next 30103 = some 30211 := by
  have hl : (List.range ((257 * 30103 - 1) / 256 - 30103)).reverse =
      [116, 115, 114, 113, 112, 111, 110, 109, 108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30211]

theorem next_30211 : next 30211 = some 30323 := by
  have hl : (List.range ((257 * 30211 - 1) / 256 - 30211)).reverse =
      [117, 116, 115, 114, 113, 112, 111] ++ (List.range 111).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30323]

theorem next_30323 : next 30323 = some 30431 := by
  have hl : (List.range ((257 * 30323 - 1) / 256 - 30323)).reverse =
      [117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30431]

theorem next_30431 : next 30431 = some 30539 := by
  have hl : (List.range ((257 * 30431 - 1) / 256 - 30431)).reverse =
      [117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30539]

theorem next_30539 : next 30539 = some 30649 := by
  have hl : (List.range ((257 * 30539 - 1) / 256 - 30539)).reverse =
      [118, 117, 116, 115, 114, 113, 112, 111, 110, 109] ++ (List.range 109).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30649]

theorem next_30649 : next 30649 = some 30763 := by
  have hl : (List.range ((257 * 30649 - 1) / 256 - 30649)).reverse =
      [118, 117, 116, 115, 114, 113] ++ (List.range 113).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30763]

theorem next_30763 : next 30763 = some 30881 := by
  have hl : (List.range ((257 * 30763 - 1) / 256 - 30763)).reverse =
      [119, 118, 117] ++ (List.range 117).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30881]

theorem next_30881 : next 30881 = some 30983 := by
  have hl : (List.range ((257 * 30881 - 1) / 256 - 30881)).reverse =
      [119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101] ++ (List.range 101).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_30983]

theorem next_30983 : next 30983 = some 31091 := by
  have hl : (List.range ((257 * 30983 - 1) / 256 - 30983)).reverse =
      [120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107] ++ (List.range 107).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_31091]

def primes : List ℕ := [27793, 27901, 28001, 28109, 28211, 28319, 28429, 28537, 28643, 28753, 28859, 28961, 29063, 29173, 29269, 29383, 29483, 29587, 29683, 29789, 29881, 29989, 30103, 30211, 30323, 30431, 30539, 30649, 30763, 30881, 30983, 31091]

theorem segment : run 348 27689 89693 =
    primes ++ run 316 31091 89693 := by
  rw [Compact40PrimeCompose256.step 347 27689 89693 27793
    (by decide +kernel) next_27689]
  rw [Compact40PrimeCompose256.step 346 27793 89693 27901
    (by decide +kernel) next_27793]
  rw [Compact40PrimeCompose256.step 345 27901 89693 28001
    (by decide +kernel) next_27901]
  rw [Compact40PrimeCompose256.step 344 28001 89693 28109
    (by decide +kernel) next_28001]
  rw [Compact40PrimeCompose256.step 343 28109 89693 28211
    (by decide +kernel) next_28109]
  rw [Compact40PrimeCompose256.step 342 28211 89693 28319
    (by decide +kernel) next_28211]
  rw [Compact40PrimeCompose256.step 341 28319 89693 28429
    (by decide +kernel) next_28319]
  rw [Compact40PrimeCompose256.step 340 28429 89693 28537
    (by decide +kernel) next_28429]
  rw [Compact40PrimeCompose256.step 339 28537 89693 28643
    (by decide +kernel) next_28537]
  rw [Compact40PrimeCompose256.step 338 28643 89693 28753
    (by decide +kernel) next_28643]
  rw [Compact40PrimeCompose256.step 337 28753 89693 28859
    (by decide +kernel) next_28753]
  rw [Compact40PrimeCompose256.step 336 28859 89693 28961
    (by decide +kernel) next_28859]
  rw [Compact40PrimeCompose256.step 335 28961 89693 29063
    (by decide +kernel) next_28961]
  rw [Compact40PrimeCompose256.step 334 29063 89693 29173
    (by decide +kernel) next_29063]
  rw [Compact40PrimeCompose256.step 333 29173 89693 29269
    (by decide +kernel) next_29173]
  rw [Compact40PrimeCompose256.step 332 29269 89693 29383
    (by decide +kernel) next_29269]
  rw [Compact40PrimeCompose256.step 331 29383 89693 29483
    (by decide +kernel) next_29383]
  rw [Compact40PrimeCompose256.step 330 29483 89693 29587
    (by decide +kernel) next_29483]
  rw [Compact40PrimeCompose256.step 329 29587 89693 29683
    (by decide +kernel) next_29587]
  rw [Compact40PrimeCompose256.step 328 29683 89693 29789
    (by decide +kernel) next_29683]
  rw [Compact40PrimeCompose256.step 327 29789 89693 29881
    (by decide +kernel) next_29789]
  rw [Compact40PrimeCompose256.step 326 29881 89693 29989
    (by decide +kernel) next_29881]
  rw [Compact40PrimeCompose256.step 325 29989 89693 30103
    (by decide +kernel) next_29989]
  rw [Compact40PrimeCompose256.step 324 30103 89693 30211
    (by decide +kernel) next_30103]
  rw [Compact40PrimeCompose256.step 323 30211 89693 30323
    (by decide +kernel) next_30211]
  rw [Compact40PrimeCompose256.step 322 30323 89693 30431
    (by decide +kernel) next_30323]
  rw [Compact40PrimeCompose256.step 321 30431 89693 30539
    (by decide +kernel) next_30431]
  rw [Compact40PrimeCompose256.step 320 30539 89693 30649
    (by decide +kernel) next_30539]
  rw [Compact40PrimeCompose256.step 319 30649 89693 30763
    (by decide +kernel) next_30649]
  rw [Compact40PrimeCompose256.step 318 30763 89693 30881
    (by decide +kernel) next_30763]
  rw [Compact40PrimeCompose256.step 317 30881 89693 30983
    (by decide +kernel) next_30881]
  rw [Compact40PrimeCompose256.step 316 30983 89693 31091
    (by decide +kernel) next_30983]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 31091 stop tail = true) :
    check 27689 stop (primes ++ tail) = true := by
  change check _ _ (27793 :: 27901 :: 28001 :: 28109 :: 28211 :: 28319 :: 28429 :: 28537 :: 28643 :: 28753 :: 28859 :: 28961 :: 29063 :: 29173 :: 29269 :: 29383 :: 29483 :: 29587 :: 29683 :: 29789 :: 29881 :: 29989 :: 30103 :: 30211 :: 30323 :: 30431 :: 30539 :: 30649 :: 30763 :: 30881 :: 30983 :: 31091 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27793, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_27901, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28001, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28109, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28211, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28319, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28429, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28537, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28643, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28753, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28859, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_28961, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29063, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29173, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29269, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29383, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29483, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29587, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29683, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29789, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29881, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_29989, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30103, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30211, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30323, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30431, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30539, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30649, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30763, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30881, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_30983, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_31091, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks011
