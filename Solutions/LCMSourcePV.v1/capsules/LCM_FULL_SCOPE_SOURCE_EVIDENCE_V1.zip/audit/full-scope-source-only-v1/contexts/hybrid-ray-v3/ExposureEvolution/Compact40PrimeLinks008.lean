import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks008
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_19661 : next 19661 = some 19727 := by
  have hl : (List.range ((257 * 19661 - 1) / 256 - 19661)).reverse =
      [75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65] ++ (List.range 65).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19727]

theorem next_19727 : next 19727 = some 19801 := by
  have hl : (List.range ((257 * 19727 - 1) / 256 - 19727)).reverse =
      [76, 75, 74, 73] ++ (List.range 73).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19801]

theorem next_19801 : next 19801 = some 19867 := by
  have hl : (List.range ((257 * 19801 - 1) / 256 - 19801)).reverse =
      [76, 75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65] ++ (List.range 65).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19867]

theorem next_19867 : next 19867 = some 19937 := by
  have hl : (List.range ((257 * 19867 - 1) / 256 - 19867)).reverse =
      [76, 75, 74, 73, 72, 71, 70, 69] ++ (List.range 69).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_19937]

theorem next_19937 : next 19937 = some 20011 := by
  have hl : (List.range ((257 * 19937 - 1) / 256 - 19937)).reverse =
      [76, 75, 74, 73] ++ (List.range 73).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20011]

theorem next_20011 : next 20011 = some 20089 := by
  have hl : (List.range ((257 * 20011 - 1) / 256 - 20011)).reverse =
      [77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20089]

theorem next_20089 : next 20089 = some 20161 := by
  have hl : (List.range ((257 * 20089 - 1) / 256 - 20089)).reverse =
      [77, 76, 75, 74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20161]

theorem next_20161 : next 20161 = some 20233 := by
  have hl : (List.range ((257 * 20161 - 1) / 256 - 20161)).reverse =
      [77, 76, 75, 74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20233]

theorem next_20233 : next 20233 = some 20297 := by
  have hl : (List.range ((257 * 20233 - 1) / 256 - 20233)).reverse =
      [78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63] ++ (List.range 63).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20297]

theorem next_20297 : next 20297 = some 20369 := by
  have hl : (List.range ((257 * 20297 - 1) / 256 - 20297)).reverse =
      [78, 77, 76, 75, 74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20369]

theorem next_20369 : next 20369 = some 20443 := by
  have hl : (List.range ((257 * 20369 - 1) / 256 - 20369)).reverse =
      [78, 77, 76, 75, 74, 73] ++ (List.range 73).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20443]

theorem next_20443 : next 20443 = some 20521 := by
  have hl : (List.range ((257 * 20443 - 1) / 256 - 20443)).reverse =
      [78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20521]

theorem next_20521 : next 20521 = some 20599 := by
  have hl : (List.range ((257 * 20521 - 1) / 256 - 20521)).reverse =
      [79, 78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20599]

theorem next_20599 : next 20599 = some 20663 := by
  have hl : (List.range ((257 * 20599 - 1) / 256 - 20599)).reverse =
      [79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63] ++ (List.range 63).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20663]

theorem next_20663 : next 20663 = some 20743 := by
  have hl : (List.range ((257 * 20663 - 1) / 256 - 20663)).reverse =
      [79] ++ (List.range 79).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20743]

theorem next_20743 : next 20743 = some 20809 := by
  have hl : (List.range ((257 * 20743 - 1) / 256 - 20743)).reverse =
      [80, 79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65] ++ (List.range 65).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20809]

theorem next_20809 : next 20809 = some 20887 := by
  have hl : (List.range ((257 * 20809 - 1) / 256 - 20809)).reverse =
      [80, 79, 78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20887]

theorem next_20887 : next 20887 = some 20963 := by
  have hl : (List.range ((257 * 20887 - 1) / 256 - 20887)).reverse =
      [80, 79, 78, 77, 76, 75] ++ (List.range 75).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_20963]

theorem next_20963 : next 20963 = some 21031 := by
  have hl : (List.range ((257 * 20963 - 1) / 256 - 20963)).reverse =
      [80, 79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68, 67] ++ (List.range 67).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21031]

theorem next_21031 : next 21031 = some 21107 := by
  have hl : (List.range ((257 * 21031 - 1) / 256 - 21031)).reverse =
      [81, 80, 79, 78, 77, 76, 75] ++ (List.range 75).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21107]

theorem next_21107 : next 21107 = some 21187 := by
  have hl : (List.range ((257 * 21107 - 1) / 256 - 21107)).reverse =
      [81, 80, 79] ++ (List.range 79).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21187]

theorem next_21187 : next 21187 = some 21269 := by
  have hl : (List.range ((257 * 21187 - 1) / 256 - 21187)).reverse =
      [81] ++ (List.range 81).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21269]

theorem next_21269 : next 21269 = some 21347 := by
  have hl : (List.range ((257 * 21269 - 1) / 256 - 21269)).reverse =
      [82, 81, 80, 79, 78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21347]

theorem next_21347 : next 21347 = some 21419 := by
  have hl : (List.range ((257 * 21347 - 1) / 256 - 21347)).reverse =
      [82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21419]

theorem next_21419 : next 21419 = some 21499 := by
  have hl : (List.range ((257 * 21419 - 1) / 256 - 21419)).reverse =
      [82, 81, 80, 79] ++ (List.range 79).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21499]

theorem next_21499 : next 21499 = some 21577 := by
  have hl : (List.range ((257 * 21499 - 1) / 256 - 21499)).reverse =
      [82, 81, 80, 79, 78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21577]

theorem next_21577 : next 21577 = some 21661 := by
  have hl : (List.range ((257 * 21577 - 1) / 256 - 21577)).reverse =
      [83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21661]

theorem next_21661 : next 21661 = some 21739 := by
  have hl : (List.range ((257 * 21661 - 1) / 256 - 21661)).reverse =
      [83, 82, 81, 80, 79, 78, 77] ++ (List.range 77).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21739]

theorem next_21739 : next 21739 = some 21821 := by
  have hl : (List.range ((257 * 21739 - 1) / 256 - 21739)).reverse =
      [83, 82, 81] ++ (List.range 81).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21821]

theorem next_21821 : next 21821 = some 21893 := by
  have hl : (List.range ((257 * 21821 - 1) / 256 - 21821)).reverse =
      [84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73, 72, 71] ++ (List.range 71).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21893]

theorem next_21893 : next 21893 = some 21977 := by
  have hl : (List.range ((257 * 21893 - 1) / 256 - 21893)).reverse =
      [84, 83] ++ (List.range 83).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_21977]

theorem next_21977 : next 21977 = some 22051 := by
  have hl : (List.range ((257 * 21977 - 1) / 256 - 21977)).reverse =
      [84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 74, 73] ++ (List.range 73).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_22051]

def primes : List ℕ := [19727, 19801, 19867, 19937, 20011, 20089, 20161, 20233, 20297, 20369, 20443, 20521, 20599, 20663, 20743, 20809, 20887, 20963, 21031, 21107, 21187, 21269, 21347, 21419, 21499, 21577, 21661, 21739, 21821, 21893, 21977, 22051]

theorem segment : run 444 19661 89693 =
    primes ++ run 412 22051 89693 := by
  rw [Compact40PrimeCompose256.step 443 19661 89693 19727
    (by decide +kernel) next_19661]
  rw [Compact40PrimeCompose256.step 442 19727 89693 19801
    (by decide +kernel) next_19727]
  rw [Compact40PrimeCompose256.step 441 19801 89693 19867
    (by decide +kernel) next_19801]
  rw [Compact40PrimeCompose256.step 440 19867 89693 19937
    (by decide +kernel) next_19867]
  rw [Compact40PrimeCompose256.step 439 19937 89693 20011
    (by decide +kernel) next_19937]
  rw [Compact40PrimeCompose256.step 438 20011 89693 20089
    (by decide +kernel) next_20011]
  rw [Compact40PrimeCompose256.step 437 20089 89693 20161
    (by decide +kernel) next_20089]
  rw [Compact40PrimeCompose256.step 436 20161 89693 20233
    (by decide +kernel) next_20161]
  rw [Compact40PrimeCompose256.step 435 20233 89693 20297
    (by decide +kernel) next_20233]
  rw [Compact40PrimeCompose256.step 434 20297 89693 20369
    (by decide +kernel) next_20297]
  rw [Compact40PrimeCompose256.step 433 20369 89693 20443
    (by decide +kernel) next_20369]
  rw [Compact40PrimeCompose256.step 432 20443 89693 20521
    (by decide +kernel) next_20443]
  rw [Compact40PrimeCompose256.step 431 20521 89693 20599
    (by decide +kernel) next_20521]
  rw [Compact40PrimeCompose256.step 430 20599 89693 20663
    (by decide +kernel) next_20599]
  rw [Compact40PrimeCompose256.step 429 20663 89693 20743
    (by decide +kernel) next_20663]
  rw [Compact40PrimeCompose256.step 428 20743 89693 20809
    (by decide +kernel) next_20743]
  rw [Compact40PrimeCompose256.step 427 20809 89693 20887
    (by decide +kernel) next_20809]
  rw [Compact40PrimeCompose256.step 426 20887 89693 20963
    (by decide +kernel) next_20887]
  rw [Compact40PrimeCompose256.step 425 20963 89693 21031
    (by decide +kernel) next_20963]
  rw [Compact40PrimeCompose256.step 424 21031 89693 21107
    (by decide +kernel) next_21031]
  rw [Compact40PrimeCompose256.step 423 21107 89693 21187
    (by decide +kernel) next_21107]
  rw [Compact40PrimeCompose256.step 422 21187 89693 21269
    (by decide +kernel) next_21187]
  rw [Compact40PrimeCompose256.step 421 21269 89693 21347
    (by decide +kernel) next_21269]
  rw [Compact40PrimeCompose256.step 420 21347 89693 21419
    (by decide +kernel) next_21347]
  rw [Compact40PrimeCompose256.step 419 21419 89693 21499
    (by decide +kernel) next_21419]
  rw [Compact40PrimeCompose256.step 418 21499 89693 21577
    (by decide +kernel) next_21499]
  rw [Compact40PrimeCompose256.step 417 21577 89693 21661
    (by decide +kernel) next_21577]
  rw [Compact40PrimeCompose256.step 416 21661 89693 21739
    (by decide +kernel) next_21661]
  rw [Compact40PrimeCompose256.step 415 21739 89693 21821
    (by decide +kernel) next_21739]
  rw [Compact40PrimeCompose256.step 414 21821 89693 21893
    (by decide +kernel) next_21821]
  rw [Compact40PrimeCompose256.step 413 21893 89693 21977
    (by decide +kernel) next_21893]
  rw [Compact40PrimeCompose256.step 412 21977 89693 22051
    (by decide +kernel) next_21977]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 22051 stop tail = true) :
    check 19661 stop (primes ++ tail) = true := by
  change check _ _ (19727 :: 19801 :: 19867 :: 19937 :: 20011 :: 20089 :: 20161 :: 20233 :: 20297 :: 20369 :: 20443 :: 20521 :: 20599 :: 20663 :: 20743 :: 20809 :: 20887 :: 20963 :: 21031 :: 21107 :: 21187 :: 21269 :: 21347 :: 21419 :: 21499 :: 21577 :: 21661 :: 21739 :: 21821 :: 21893 :: 21977 :: 22051 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19727, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19801, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19867, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_19937, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20011, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20089, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20161, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20233, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20297, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20369, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20443, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20521, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20599, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20663, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20743, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20809, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20887, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_20963, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21031, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21107, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21187, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21269, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21347, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21419, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21499, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21577, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21661, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21739, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21821, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21893, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_21977, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_22051, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks008
