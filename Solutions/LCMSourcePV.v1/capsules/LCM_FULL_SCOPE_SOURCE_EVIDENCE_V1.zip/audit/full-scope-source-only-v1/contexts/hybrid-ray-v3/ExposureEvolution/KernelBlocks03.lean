import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks03
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨2866249, 2879808, 1697, 1699, 1709, 2866163, 2866211, 2866247⟩, 10⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1697,
    ExposureEvolution.KernelPratt.prime_1699,
    ExposureEvolution.KernelPratt.prime_1709,
    ExposureEvolution.KernelPratt.prime_2866163,
    ExposureEvolution.KernelPratt.prime_2866211,
    ExposureEvolution.KernelPratt.prime_2866247]

def block01 : Witness := ⟨⟨2879809, 2886600, 1699, 1709, 1721, 2879447, 2879759, 2879803⟩, 13⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1699,
    ExposureEvolution.KernelPratt.prime_1709,
    ExposureEvolution.KernelPratt.prime_1721,
    ExposureEvolution.KernelPratt.prime_2879447,
    ExposureEvolution.KernelPratt.prime_2879759,
    ExposureEvolution.KernelPratt.prime_2879803]

def block02 : Witness := ⟨⟨2886601, 2920680, 1709, 1721, 1723, 2886281, 2886529, 2886593⟩, 8⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1709,
    ExposureEvolution.KernelPratt.prime_1721,
    ExposureEvolution.KernelPratt.prime_1723,
    ExposureEvolution.KernelPratt.prime_2886281,
    ExposureEvolution.KernelPratt.prime_2886529,
    ExposureEvolution.KernelPratt.prime_2886593]

def block03 : Witness := ⟨⟨2920681, 2961840, 1721, 1723, 1733, 2920409, 2920579, 2920649⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1721,
    ExposureEvolution.KernelPratt.prime_1723,
    ExposureEvolution.KernelPratt.prime_1733,
    ExposureEvolution.KernelPratt.prime_2920409,
    ExposureEvolution.KernelPratt.prime_2920579,
    ExposureEvolution.KernelPratt.prime_2920649]

def block04 : Witness := ⟨⟨2961841, 2968728, 1723, 1733, 1741, 2961613, 2961619, 2961839⟩, 9⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1723,
    ExposureEvolution.KernelPratt.prime_1733,
    ExposureEvolution.KernelPratt.prime_1741,
    ExposureEvolution.KernelPratt.prime_2961613,
    ExposureEvolution.KernelPratt.prime_2961619,
    ExposureEvolution.KernelPratt.prime_2961839]

def block05 : Witness := ⟨⟨2968729, 3003288, 1733, 1741, 1747, 2968487, 2968631, 2968717⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1733,
    ExposureEvolution.KernelPratt.prime_1741,
    ExposureEvolution.KernelPratt.prime_1747,
    ExposureEvolution.KernelPratt.prime_2968487,
    ExposureEvolution.KernelPratt.prime_2968631,
    ExposureEvolution.KernelPratt.prime_2968717]

def block06 : Witness := ⟨⟨3003289, 3031080, 1741, 1747, 1753, 3003079, 3003157, 3003281⟩, 8⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1741,
    ExposureEvolution.KernelPratt.prime_1747,
    ExposureEvolution.KernelPratt.prime_1753,
    ExposureEvolution.KernelPratt.prime_3003079,
    ExposureEvolution.KernelPratt.prime_3003157,
    ExposureEvolution.KernelPratt.prime_3003281]

def block07 : Witness := ⟨⟨3031081, 3052008, 1747, 1753, 1759, 3030673, 3030689, 3031079⟩, 10⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1747,
    ExposureEvolution.KernelPratt.prime_1753,
    ExposureEvolution.KernelPratt.prime_1759,
    ExposureEvolution.KernelPratt.prime_3030673,
    ExposureEvolution.KernelPratt.prime_3030689,
    ExposureEvolution.KernelPratt.prime_3031079]

def block08 : Witness := ⟨⟨3052009, 3073008, 1753, 1759, 1777, 3051611, 3051637, 3052003⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1753,
    ExposureEvolution.KernelPratt.prime_1759,
    ExposureEvolution.KernelPratt.prime_1777,
    ExposureEvolution.KernelPratt.prime_3051611,
    ExposureEvolution.KernelPratt.prime_3051637,
    ExposureEvolution.KernelPratt.prime_3052003]

def block09 : Witness := ⟨⟨3073009, 3094080, 1759, 1777, 1783, 3072481, 3072911, 3072983⟩, 9⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1759,
    ExposureEvolution.KernelPratt.prime_1777,
    ExposureEvolution.KernelPratt.prime_1783,
    ExposureEvolution.KernelPratt.prime_3072481,
    ExposureEvolution.KernelPratt.prime_3072911,
    ExposureEvolution.KernelPratt.prime_3072983]

def block10 : Witness := ⟨⟨3094081, 3157728, 1777, 1783, 1787, 3093703, 3093817, 3094073⟩, 9⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1777,
    ExposureEvolution.KernelPratt.prime_1783,
    ExposureEvolution.KernelPratt.prime_1787,
    ExposureEvolution.KernelPratt.prime_3093703,
    ExposureEvolution.KernelPratt.prime_3093817,
    ExposureEvolution.KernelPratt.prime_3094073]

def block11 : Witness := ⟨⟨3157729, 3179088, 1783, 1787, 1789, 3157471, 3157603, 3157711⟩, 9⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1783,
    ExposureEvolution.KernelPratt.prime_1787,
    ExposureEvolution.KernelPratt.prime_1789,
    ExposureEvolution.KernelPratt.prime_3157471,
    ExposureEvolution.KernelPratt.prime_3157603,
    ExposureEvolution.KernelPratt.prime_3157711]

def block12 : Witness := ⟨⟨3179089, 3193368, 1787, 1789, 1801, 3178913, 3178943, 3179087⟩, 6⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1787,
    ExposureEvolution.KernelPratt.prime_1789,
    ExposureEvolution.KernelPratt.prime_1801,
    ExposureEvolution.KernelPratt.prime_3178913,
    ExposureEvolution.KernelPratt.prime_3178943,
    ExposureEvolution.KernelPratt.prime_3179087]

def block13 : Witness := ⟨⟨3193369, 3200520, 1789, 1801, 1811, 3193049, 3193241, 3193363⟩, 9⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1789,
    ExposureEvolution.KernelPratt.prime_1801,
    ExposureEvolution.KernelPratt.prime_1811,
    ExposureEvolution.KernelPratt.prime_3193049,
    ExposureEvolution.KernelPratt.prime_3193241,
    ExposureEvolution.KernelPratt.prime_3193363]

def block14 : Witness := ⟨⟨3200521, 3243600, 1801, 1811, 1823, 3200339, 3200357, 3200507⟩, 10⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1801,
    ExposureEvolution.KernelPratt.prime_1811,
    ExposureEvolution.KernelPratt.prime_1823,
    ExposureEvolution.KernelPratt.prime_3200339,
    ExposureEvolution.KernelPratt.prime_3200357,
    ExposureEvolution.KernelPratt.prime_3200507]

def block15 : Witness := ⟨⟨3243601, 3279720, 1811, 1823, 1831, 3243271, 3243397, 3243589⟩, 8⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1811,
    ExposureEvolution.KernelPratt.prime_1823,
    ExposureEvolution.KernelPratt.prime_1831,
    ExposureEvolution.KernelPratt.prime_3243271,
    ExposureEvolution.KernelPratt.prime_3243397,
    ExposureEvolution.KernelPratt.prime_3243589]

def block16 : Witness := ⟨⟨3279721, 3323328, 1823, 1831, 1847, 3279193, 3279559, 3279709⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1823,
    ExposureEvolution.KernelPratt.prime_1831,
    ExposureEvolution.KernelPratt.prime_1847,
    ExposureEvolution.KernelPratt.prime_3279193,
    ExposureEvolution.KernelPratt.prime_3279559,
    ExposureEvolution.KernelPratt.prime_3279709]

def block17 : Witness := ⟨⟨3323329, 3352560, 1831, 1847, 1861, 3323059, 3323069, 3323311⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1831,
    ExposureEvolution.KernelPratt.prime_1847,
    ExposureEvolution.KernelPratt.prime_1861,
    ExposureEvolution.KernelPratt.prime_3323059,
    ExposureEvolution.KernelPratt.prime_3323069,
    ExposureEvolution.KernelPratt.prime_3323311]

def block18 : Witness := ⟨⟨3352561, 3411408, 1847, 1861, 1867, 3352289, 3352387, 3352537⟩, 12⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1847,
    ExposureEvolution.KernelPratt.prime_1861,
    ExposureEvolution.KernelPratt.prime_1867,
    ExposureEvolution.KernelPratt.prime_3352289,
    ExposureEvolution.KernelPratt.prime_3352387,
    ExposureEvolution.KernelPratt.prime_3352537]

def block19 : Witness := ⟨⟨3411409, 3463320, 1861, 1867, 1871, 3411151, 3411361, 3411391⟩, 13⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1861,
    ExposureEvolution.KernelPratt.prime_1867,
    ExposureEvolution.KernelPratt.prime_1871,
    ExposureEvolution.KernelPratt.prime_3411151,
    ExposureEvolution.KernelPratt.prime_3411361,
    ExposureEvolution.KernelPratt.prime_3411391]

def block20 : Witness := ⟨⟨3463321, 3485688, 1867, 1871, 1873, 3462881, 3463231, 3463319⟩, 9⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1867,
    ExposureEvolution.KernelPratt.prime_1871,
    ExposureEvolution.KernelPratt.prime_1873,
    ExposureEvolution.KernelPratt.prime_3462881,
    ExposureEvolution.KernelPratt.prime_3463231,
    ExposureEvolution.KernelPratt.prime_3463319]

def block21 : Witness := ⟨⟨3485689, 3500640, 1871, 1873, 1877, 3485291, 3485617, 3485687⟩, 11⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1871,
    ExposureEvolution.KernelPratt.prime_1873,
    ExposureEvolution.KernelPratt.prime_1877,
    ExposureEvolution.KernelPratt.prime_3485291,
    ExposureEvolution.KernelPratt.prime_3485617,
    ExposureEvolution.KernelPratt.prime_3485687]

def block22 : Witness := ⟨⟨3500641, 3508128, 1873, 1877, 1879, 3500033, 3500323, 3500593⟩, 11⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1873,
    ExposureEvolution.KernelPratt.prime_1877,
    ExposureEvolution.KernelPratt.prime_1879,
    ExposureEvolution.KernelPratt.prime_3500033,
    ExposureEvolution.KernelPratt.prime_3500323,
    ExposureEvolution.KernelPratt.prime_3500593]

def block23 : Witness := ⟨⟨3508129, 3523128, 1877, 1879, 1889, 3507731, 3507971, 3508111⟩, 8⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1877,
    ExposureEvolution.KernelPratt.prime_1879,
    ExposureEvolution.KernelPratt.prime_1889,
    ExposureEvolution.KernelPratt.prime_3507731,
    ExposureEvolution.KernelPratt.prime_3507971,
    ExposureEvolution.KernelPratt.prime_3508111]

def block24 : Witness := ⟨⟨3523129, 3530640, 1879, 1889, 1901, 3522971, 3523019, 3523111⟩, 10⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1879,
    ExposureEvolution.KernelPratt.prime_1889,
    ExposureEvolution.KernelPratt.prime_1901,
    ExposureEvolution.KernelPratt.prime_3522971,
    ExposureEvolution.KernelPratt.prime_3523019,
    ExposureEvolution.KernelPratt.prime_3523111]

def block25 : Witness := ⟨⟨3530641, 3568320, 1889, 1901, 1907, 3530389, 3530591, 3530629⟩, 9⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1889,
    ExposureEvolution.KernelPratt.prime_1901,
    ExposureEvolution.KernelPratt.prime_1907,
    ExposureEvolution.KernelPratt.prime_3530389,
    ExposureEvolution.KernelPratt.prime_3530591,
    ExposureEvolution.KernelPratt.prime_3530629]

def block26 : Witness := ⟨⟨3568321, 3613800, 1901, 1907, 1913, 3568153, 3568231, 3568307⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1901,
    ExposureEvolution.KernelPratt.prime_1907,
    ExposureEvolution.KernelPratt.prime_1913,
    ExposureEvolution.KernelPratt.prime_3568153,
    ExposureEvolution.KernelPratt.prime_3568231,
    ExposureEvolution.KernelPratt.prime_3568307]

def block27 : Witness := ⟨⟨3613801, 3636648, 1907, 1913, 1931, 3613513, 3613559, 3613789⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1907,
    ExposureEvolution.KernelPratt.prime_1913,
    ExposureEvolution.KernelPratt.prime_1931,
    ExposureEvolution.KernelPratt.prime_3613513,
    ExposureEvolution.KernelPratt.prime_3613559,
    ExposureEvolution.KernelPratt.prime_3613789]

def block28 : Witness := ⟨⟨3636649, 3659568, 1913, 1931, 1933, 3636371, 3636463, 3636631⟩, 10⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1913,
    ExposureEvolution.KernelPratt.prime_1931,
    ExposureEvolution.KernelPratt.prime_1933,
    ExposureEvolution.KernelPratt.prime_3636371,
    ExposureEvolution.KernelPratt.prime_3636463,
    ExposureEvolution.KernelPratt.prime_3636631]

def block29 : Witness := ⟨⟨3659569, 3728760, 1931, 1933, 1949, 3659141, 3659449, 3659567⟩, 11⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1931,
    ExposureEvolution.KernelPratt.prime_1933,
    ExposureEvolution.KernelPratt.prime_1949,
    ExposureEvolution.KernelPratt.prime_3659141,
    ExposureEvolution.KernelPratt.prime_3659449,
    ExposureEvolution.KernelPratt.prime_3659567]

def block30 : Witness := ⟨⟨3728761, 3736488, 1933, 1949, 1951, 3728537, 3728633, 3728759⟩, 7⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1933,
    ExposureEvolution.KernelPratt.prime_1949,
    ExposureEvolution.KernelPratt.prime_1951,
    ExposureEvolution.KernelPratt.prime_3728537,
    ExposureEvolution.KernelPratt.prime_3728633,
    ExposureEvolution.KernelPratt.prime_3728759]

def block31 : Witness := ⟨⟨3736489, 3798600, 1949, 1951, 1973, 3736231, 3736261, 3736477⟩, 8⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1949,
    ExposureEvolution.KernelPratt.prime_1951,
    ExposureEvolution.KernelPratt.prime_1973,
    ExposureEvolution.KernelPratt.prime_3736231,
    ExposureEvolution.KernelPratt.prime_3736261,
    ExposureEvolution.KernelPratt.prime_3736477]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 3798601 stop tail = true) :
    coverage 2866249 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks03
