import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelBlocks01
open ExposureEvolution.Adaptive E1TwoTracks.TrackB
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨1495729, 1510440, 1229, 1231, 1237, 1495561, 1495631, 1495727⟩, 7⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1229,
    ExposureEvolution.KernelPratt.prime_1231,
    ExposureEvolution.KernelPratt.prime_1237,
    ExposureEvolution.KernelPratt.prime_1495561,
    ExposureEvolution.KernelPratt.prime_1495631,
    ExposureEvolution.KernelPratt.prime_1495727]

def block01 : Witness := ⟨⟨1510441, 1515360, 1231, 1237, 1249, 1510199, 1510309, 1510429⟩, 13⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1231,
    ExposureEvolution.KernelPratt.prime_1237,
    ExposureEvolution.KernelPratt.prime_1249,
    ExposureEvolution.KernelPratt.prime_1510199,
    ExposureEvolution.KernelPratt.prime_1510309,
    ExposureEvolution.KernelPratt.prime_1510429]

def block02 : Witness := ⟨⟨1515361, 1530168, 1237, 1249, 1259, 1514837, 1515119, 1515359⟩, 8⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1237,
    ExposureEvolution.KernelPratt.prime_1249,
    ExposureEvolution.KernelPratt.prime_1259,
    ExposureEvolution.KernelPratt.prime_1514837,
    ExposureEvolution.KernelPratt.prime_1515119,
    ExposureEvolution.KernelPratt.prime_1515359]

def block03 : Witness := ⟨⟨1530169, 1560000, 1249, 1259, 1277, 1529807, 1530073, 1530157⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1249,
    ExposureEvolution.KernelPratt.prime_1259,
    ExposureEvolution.KernelPratt.prime_1277,
    ExposureEvolution.KernelPratt.prime_1529807,
    ExposureEvolution.KernelPratt.prime_1530073,
    ExposureEvolution.KernelPratt.prime_1530157]

def block04 : Witness := ⟨⟨1560001, 1585080, 1259, 1277, 1279, 1559651, 1559969, 1559989⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1259,
    ExposureEvolution.KernelPratt.prime_1277,
    ExposureEvolution.KernelPratt.prime_1279,
    ExposureEvolution.KernelPratt.prime_1559651,
    ExposureEvolution.KernelPratt.prime_1559969,
    ExposureEvolution.KernelPratt.prime_1559989]

def block05 : Witness := ⟨⟨1585081, 1630728, 1277, 1279, 1283, 1584827, 1585007, 1585033⟩, 9⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1277,
    ExposureEvolution.KernelPratt.prime_1279,
    ExposureEvolution.KernelPratt.prime_1283,
    ExposureEvolution.KernelPratt.prime_1584827,
    ExposureEvolution.KernelPratt.prime_1585007,
    ExposureEvolution.KernelPratt.prime_1585033]

def block06 : Witness := ⟨⟨1630729, 1635840, 1279, 1283, 1289, 1630303, 1630381, 1630721⟩, 13⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1279,
    ExposureEvolution.KernelPratt.prime_1283,
    ExposureEvolution.KernelPratt.prime_1289,
    ExposureEvolution.KernelPratt.prime_1630303,
    ExposureEvolution.KernelPratt.prime_1630381,
    ExposureEvolution.KernelPratt.prime_1630721]

def block07 : Witness := ⟨⟨1635841, 1646088, 1283, 1289, 1291, 1635509, 1635547, 1635827⟩, 8⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1283,
    ExposureEvolution.KernelPratt.prime_1289,
    ExposureEvolution.KernelPratt.prime_1291,
    ExposureEvolution.KernelPratt.prime_1635509,
    ExposureEvolution.KernelPratt.prime_1635547,
    ExposureEvolution.KernelPratt.prime_1635827]

def block08 : Witness := ⟨⟨1646089, 1661520, 1289, 1291, 1297, 1645747, 1645967, 1646033⟩, 9⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1289,
    ExposureEvolution.KernelPratt.prime_1291,
    ExposureEvolution.KernelPratt.prime_1297,
    ExposureEvolution.KernelPratt.prime_1645747,
    ExposureEvolution.KernelPratt.prime_1645967,
    ExposureEvolution.KernelPratt.prime_1646033]

def block09 : Witness := ⟨⟨1661521, 1666680, 1291, 1297, 1301, 1661021, 1661117, 1661519⟩, 12⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1291,
    ExposureEvolution.KernelPratt.prime_1297,
    ExposureEvolution.KernelPratt.prime_1301,
    ExposureEvolution.KernelPratt.prime_1661021,
    ExposureEvolution.KernelPratt.prime_1661117,
    ExposureEvolution.KernelPratt.prime_1661519]

def block10 : Witness := ⟨⟨1666681, 1682208, 1297, 1301, 1303, 1666309, 1666597, 1666657⟩, 11⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1297,
    ExposureEvolution.KernelPratt.prime_1301,
    ExposureEvolution.KernelPratt.prime_1303,
    ExposureEvolution.KernelPratt.prime_1666309,
    ExposureEvolution.KernelPratt.prime_1666597,
    ExposureEvolution.KernelPratt.prime_1666657]

def block11 : Witness := ⟨⟨1682209, 1692600, 1301, 1303, 1307, 1681807, 1682179, 1682207⟩, 9⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1301,
    ExposureEvolution.KernelPratt.prime_1303,
    ExposureEvolution.KernelPratt.prime_1307,
    ExposureEvolution.KernelPratt.prime_1681807,
    ExposureEvolution.KernelPratt.prime_1682179,
    ExposureEvolution.KernelPratt.prime_1682207]

def block12 : Witness := ⟨⟨1692601, 1697808, 1303, 1307, 1319, 1692161, 1692181, 1692589⟩, 10⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1303,
    ExposureEvolution.KernelPratt.prime_1307,
    ExposureEvolution.KernelPratt.prime_1319,
    ExposureEvolution.KernelPratt.prime_1692161,
    ExposureEvolution.KernelPratt.prime_1692181,
    ExposureEvolution.KernelPratt.prime_1692589]

def block13 : Witness := ⟨⟨1697809, 1708248, 1307, 1319, 1321, 1697471, 1697797, 1697803⟩, 9⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1307,
    ExposureEvolution.KernelPratt.prime_1319,
    ExposureEvolution.KernelPratt.prime_1321,
    ExposureEvolution.KernelPratt.prime_1697471,
    ExposureEvolution.KernelPratt.prime_1697797,
    ExposureEvolution.KernelPratt.prime_1697803]

def block14 : Witness := ⟨⟨1708249, 1739760, 1319, 1321, 1327, 1707899, 1707977, 1708247⟩, 8⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1319,
    ExposureEvolution.KernelPratt.prime_1321,
    ExposureEvolution.KernelPratt.prime_1327,
    ExposureEvolution.KernelPratt.prime_1707899,
    ExposureEvolution.KernelPratt.prime_1707977,
    ExposureEvolution.KernelPratt.prime_1708247]

def block15 : Witness := ⟨⟨1739761, 1745040, 1321, 1327, 1361, 1739533, 1739557, 1739747⟩, 7⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1321,
    ExposureEvolution.KernelPratt.prime_1327,
    ExposureEvolution.KernelPratt.prime_1361,
    ExposureEvolution.KernelPratt.prime_1739533,
    ExposureEvolution.KernelPratt.prime_1739557,
    ExposureEvolution.KernelPratt.prime_1739747]

def block16 : Witness := ⟨⟨1745041, 1760928, 1327, 1361, 1367, 1744621, 1744663, 1745039⟩, 10⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1327,
    ExposureEvolution.KernelPratt.prime_1361,
    ExposureEvolution.KernelPratt.prime_1367,
    ExposureEvolution.KernelPratt.prime_1744621,
    ExposureEvolution.KernelPratt.prime_1744663,
    ExposureEvolution.KernelPratt.prime_1745039]

def block17 : Witness := ⟨⟨1760929, 1852320, 1361, 1367, 1373, 1760743, 1760753, 1760923⟩, 8⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1361,
    ExposureEvolution.KernelPratt.prime_1367,
    ExposureEvolution.KernelPratt.prime_1373,
    ExposureEvolution.KernelPratt.prime_1760743,
    ExposureEvolution.KernelPratt.prime_1760753,
    ExposureEvolution.KernelPratt.prime_1760923]

def block18 : Witness := ⟨⟨1852321, 1868688, 1367, 1373, 1381, 1852051, 1852283, 1852307⟩, 7⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1367,
    ExposureEvolution.KernelPratt.prime_1373,
    ExposureEvolution.KernelPratt.prime_1381,
    ExposureEvolution.KernelPratt.prime_1852051,
    ExposureEvolution.KernelPratt.prime_1852283,
    ExposureEvolution.KernelPratt.prime_1852307]

def block19 : Witness := ⟨⟨1868689, 1885128, 1373, 1381, 1399, 1868567, 1868677, 1868687⟩, 11⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1373,
    ExposureEvolution.KernelPratt.prime_1381,
    ExposureEvolution.KernelPratt.prime_1399,
    ExposureEvolution.KernelPratt.prime_1868567,
    ExposureEvolution.KernelPratt.prime_1868677,
    ExposureEvolution.KernelPratt.prime_1868687]

def block20 : Witness := ⟨⟨1885129, 1907160, 1381, 1399, 1409, 1884833, 1884973, 1885069⟩, 12⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1381,
    ExposureEvolution.KernelPratt.prime_1399,
    ExposureEvolution.KernelPratt.prime_1409,
    ExposureEvolution.KernelPratt.prime_1884833,
    ExposureEvolution.KernelPratt.prime_1884973,
    ExposureEvolution.KernelPratt.prime_1885069]

def block21 : Witness := ⟨⟨1907161, 1957200, 1399, 1409, 1423, 1906691, 1907071, 1907153⟩, 11⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1399,
    ExposureEvolution.KernelPratt.prime_1409,
    ExposureEvolution.KernelPratt.prime_1423,
    ExposureEvolution.KernelPratt.prime_1906691,
    ExposureEvolution.KernelPratt.prime_1907071,
    ExposureEvolution.KernelPratt.prime_1907153]

def block22 : Witness := ⟨⟨1957201, 1985280, 1409, 1423, 1427, 1957069, 1957121, 1957187⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1409,
    ExposureEvolution.KernelPratt.prime_1423,
    ExposureEvolution.KernelPratt.prime_1427,
    ExposureEvolution.KernelPratt.prime_1957069,
    ExposureEvolution.KernelPratt.prime_1957121,
    ExposureEvolution.KernelPratt.prime_1957187]

def block23 : Witness := ⟨⟨1985281, 2024928, 1423, 1427, 1429, 1984991, 1985047, 1985279⟩, 9⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1423,
    ExposureEvolution.KernelPratt.prime_1427,
    ExposureEvolution.KernelPratt.prime_1429,
    ExposureEvolution.KernelPratt.prime_1984991,
    ExposureEvolution.KernelPratt.prime_1985047,
    ExposureEvolution.KernelPratt.prime_1985279]

def block24 : Witness := ⟨⟨2024929, 2036328, 1427, 1429, 1433, 2024387, 2024731, 2024917⟩, 10⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1427,
    ExposureEvolution.KernelPratt.prime_1429,
    ExposureEvolution.KernelPratt.prime_1433,
    ExposureEvolution.KernelPratt.prime_2024387,
    ExposureEvolution.KernelPratt.prime_2024731,
    ExposureEvolution.KernelPratt.prime_2024917]

def block25 : Witness := ⟨⟨2036329, 2042040, 1429, 1433, 1439, 2036009, 2036071, 2036323⟩, 7⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1429,
    ExposureEvolution.KernelPratt.prime_1433,
    ExposureEvolution.KernelPratt.prime_1439,
    ExposureEvolution.KernelPratt.prime_2036009,
    ExposureEvolution.KernelPratt.prime_2036071,
    ExposureEvolution.KernelPratt.prime_2036323]

def block26 : Witness := ⟨⟨2042041, 2053488, 1433, 1439, 1447, 2041703, 2041957, 2042039⟩, 8⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1433,
    ExposureEvolution.KernelPratt.prime_1439,
    ExposureEvolution.KernelPratt.prime_1447,
    ExposureEvolution.KernelPratt.prime_2041703,
    ExposureEvolution.KernelPratt.prime_2041957,
    ExposureEvolution.KernelPratt.prime_2042039]

def block27 : Witness := ⟨⟨2053489, 2070720, 1439, 1447, 1451, 2053063, 2053189, 2053459⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1439,
    ExposureEvolution.KernelPratt.prime_1447,
    ExposureEvolution.KernelPratt.prime_1451,
    ExposureEvolution.KernelPratt.prime_2053063,
    ExposureEvolution.KernelPratt.prime_2053189,
    ExposureEvolution.KernelPratt.prime_2053459]

def block28 : Witness := ⟨⟨2070721, 2093808, 1447, 1451, 1453, 2070587, 2070611, 2070709⟩, 8⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1447,
    ExposureEvolution.KernelPratt.prime_1451,
    ExposureEvolution.KernelPratt.prime_1453,
    ExposureEvolution.KernelPratt.prime_2070587,
    ExposureEvolution.KernelPratt.prime_2070611,
    ExposureEvolution.KernelPratt.prime_2070709]

def block29 : Witness := ⟨⟨2093809, 2105400, 1451, 1453, 1459, 2093323, 2093557, 2093807⟩, 9⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1451,
    ExposureEvolution.KernelPratt.prime_1453,
    ExposureEvolution.KernelPratt.prime_1459,
    ExposureEvolution.KernelPratt.prime_2093323,
    ExposureEvolution.KernelPratt.prime_2093557,
    ExposureEvolution.KernelPratt.prime_2093807]

def block30 : Witness := ⟨⟨2105401, 2111208, 1453, 1459, 1471, 2104951, 2105357, 2105381⟩, 8⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1453,
    ExposureEvolution.KernelPratt.prime_1459,
    ExposureEvolution.KernelPratt.prime_1471,
    ExposureEvolution.KernelPratt.prime_2104951,
    ExposureEvolution.KernelPratt.prime_2105357,
    ExposureEvolution.KernelPratt.prime_2105381]

def block31 : Witness := ⟨⟨2111209, 2128680, 1459, 1471, 1481, 2110877, 2111167, 2111189⟩, 8⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint, Witness.m,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.KernelPratt.prime_1459,
    ExposureEvolution.KernelPratt.prime_1471,
    ExposureEvolution.KernelPratt.prime_1481,
    ExposureEvolution.KernelPratt.prime_2110877,
    ExposureEvolution.KernelPratt.prime_2111167,
    ExposureEvolution.KernelPratt.prime_2111189]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 2128681 stop tail = true) :
    coverage 1495729 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: tail) = true
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.KernelComposition.coverage_cons _ _ _ _ rfl checked31
  exact h

#print axioms extend
end ExposureEvolution.KernelBlocks01
