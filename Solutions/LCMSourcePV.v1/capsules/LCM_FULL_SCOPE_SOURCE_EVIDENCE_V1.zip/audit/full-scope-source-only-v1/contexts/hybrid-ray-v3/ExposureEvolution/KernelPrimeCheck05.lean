import ExposureEvolution.KernelPratt
import ExposureEvolution.KernelComposition
namespace ExposureEvolution.KernelPrimeCheck05
open ExposureEvolution KernelPrimeProgram
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def primes : List ℕ := [24767, 24859, 24953, 25037, 25127, 25219, 25309, 25391, 25471, 25561, 25657, 25747, 25847, 25943, 26041, 26141, 26237, 26339, 26437, 26539, 26641, 26737, 26839, 26927, 27031, 27127, 27211, 27299, 27397, 27487, 27583, 27689, 27793, 27901, 28001, 28109, 28211, 28319, 28429, 28537, 28643, 28753, 28859, 28961, 29063, 29173, 29269, 29383, 29483, 29587, 29683, 29789, 29881, 29989, 30103, 30211, 30323, 30431, 30539, 30649, 30763, 30881, 30983, 31091]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 31091 stop tail = true) :
    check 24683 stop (primes ++ tail) = true := by
  change check _ _ (24767 :: 24859 :: 24953 :: 25037 :: 25127 :: 25219 :: 25309 :: 25391 :: 25471 :: 25561 :: 25657 :: 25747 :: 25847 :: 25943 :: 26041 :: 26141 :: 26237 :: 26339 :: 26437 :: 26539 :: 26641 :: 26737 :: 26839 :: 26927 :: 27031 :: 27127 :: 27211 :: 27299 :: 27397 :: 27487 :: 27583 :: 27689 :: 27793 :: 27901 :: 28001 :: 28109 :: 28211 :: 28319 :: 28429 :: 28537 :: 28643 :: 28753 :: 28859 :: 28961 :: 29063 :: 29173 :: 29269 :: 29383 :: 29483 :: 29587 :: 29683 :: 29789 :: 29881 :: 29989 :: 30103 :: 30211 :: 30323 :: 30431 :: 30539 :: 30649 :: 30763 :: 30881 :: 30983 :: 31091 :: tail) = true
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_24767, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_24859, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_24953, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25037, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25127, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25219, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25309, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25391, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25471, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25561, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25657, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25747, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25847, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_25943, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26041, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26141, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26237, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26339, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26437, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26539, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26641, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26737, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26839, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_26927, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27031, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27127, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27211, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27299, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27397, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27487, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27583, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27689, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27793, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_27901, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28001, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28109, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28211, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28319, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28429, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28537, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28643, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28753, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28859, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_28961, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29063, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29173, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29269, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29383, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29483, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29587, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29683, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29789, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29881, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_29989, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30103, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30211, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30323, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30431, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30539, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30649, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30763, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30881, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_30983, by decide +kernel, by decide +kernel⟩
  apply KernelComposition.check_cons _ _ _ _
    ⟨KernelPratt.prime_31091, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms extend
end ExposureEvolution.KernelPrimeCheck05
