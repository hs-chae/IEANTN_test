import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Dual60PrimeSupplementV1
import ExposureEvolution.DualKernelCompose60
namespace ExposureEvolution.DualKernelBlocks60_002
open ExposureEvolution.Dual60CheckerV1 E1TwoTracks.TrackB
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def block00 : Witness := ⟨⟨10582009, 10608048, 3257, 3259, 3271, 10581517, 10581937, 10581959⟩, 9⟩
theorem checked00 : block00.check = true := by
  norm_num [block00, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3257,
    ExposureEvolution.Compact40Pratt.prime_3259,
    ExposureEvolution.Compact40Pratt.prime_3271,
    ExposureEvolution.Compact40Pratt.prime_10581517,
    ExposureEvolution.Compact40Pratt.prime_10581937,
    ExposureEvolution.Compact40Pratt.prime_10581959]

def block01 : Witness := ⟨⟨10608049, 10621080, 3259, 3271, 3299, 10607449, 10607819, 10608029⟩, 10⟩
theorem checked01 : block01.check = true := by
  norm_num [block01, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3259,
    ExposureEvolution.Compact40Pratt.prime_3271,
    ExposureEvolution.Compact40Pratt.prime_3299,
    ExposureEvolution.Compact40Pratt.prime_10607449,
    ExposureEvolution.Compact40Pratt.prime_10607819,
    ExposureEvolution.Compact40Pratt.prime_10608029]

def block02 : Witness := ⟨⟨10621081, 10699440, 3271, 3299, 3301, 10620947, 10620977, 10621063⟩, 13⟩
theorem checked02 : block02.check = true := by
  norm_num [block02, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3271,
    ExposureEvolution.Compact40Pratt.prime_3299,
    ExposureEvolution.Compact40Pratt.prime_3301,
    ExposureEvolution.Compact40Pratt.prime_10620947,
    ExposureEvolution.Compact40Pratt.prime_10620977,
    ExposureEvolution.Compact40Pratt.prime_10621063]

def block03 : Witness := ⟨⟨10699441, 10883400, 3299, 3301, 3307, 10698911, 10698983, 10699421⟩, 9⟩
theorem checked03 : block03.check = true := by
  norm_num [block03, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3299,
    ExposureEvolution.Compact40Pratt.prime_3301,
    ExposureEvolution.Compact40Pratt.prime_3307,
    ExposureEvolution.Compact40Pratt.prime_10698911,
    ExposureEvolution.Compact40Pratt.prime_10698983,
    ExposureEvolution.Compact40Pratt.prime_10699421]

def block04 : Witness := ⟨⟨10883401, 10896600, 3301, 3307, 3313, 10883269, 10883321, 10883399⟩, 7⟩
theorem checked04 : block04.check = true := by
  norm_num [block04, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3301,
    ExposureEvolution.Compact40Pratt.prime_3307,
    ExposureEvolution.Compact40Pratt.prime_3313,
    ExposureEvolution.Compact40Pratt.prime_10883269,
    ExposureEvolution.Compact40Pratt.prime_10883321,
    ExposureEvolution.Compact40Pratt.prime_10883399]

def block05 : Witness := ⟨⟨10896601, 10936248, 3307, 3313, 3319, 10896341, 10896539, 10896577⟩, 11⟩
theorem checked05 : block05.check = true := by
  norm_num [block05, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3307,
    ExposureEvolution.Compact40Pratt.prime_3313,
    ExposureEvolution.Compact40Pratt.prime_3319,
    ExposureEvolution.Compact40Pratt.prime_10896341,
    ExposureEvolution.Compact40Pratt.prime_10896539,
    ExposureEvolution.Compact40Pratt.prime_10896577]

def block06 : Witness := ⟨⟨10936249, 10975968, 3313, 3319, 3323, 10935713, 10936169, 10936243⟩, 10⟩
theorem checked06 : block06.check = true := by
  norm_num [block06, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3313,
    ExposureEvolution.Compact40Pratt.prime_3319,
    ExposureEvolution.Compact40Pratt.prime_3323,
    ExposureEvolution.Compact40Pratt.prime_10935713,
    ExposureEvolution.Compact40Pratt.prime_10936169,
    ExposureEvolution.Compact40Pratt.prime_10936243]

def block07 : Witness := ⟨⟨10975969, 11015760, 3319, 3323, 3329, 10975681, 10975831, 10975967⟩, 7⟩
theorem checked07 : block07.check = true := by
  norm_num [block07, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3319,
    ExposureEvolution.Compact40Pratt.prime_3323,
    ExposureEvolution.Compact40Pratt.prime_3329,
    ExposureEvolution.Compact40Pratt.prime_10975681,
    ExposureEvolution.Compact40Pratt.prime_10975831,
    ExposureEvolution.Compact40Pratt.prime_10975967]

def block08 : Witness := ⟨⟨11015761, 11042328, 3323, 3329, 3331, 11015461, 11015663, 11015743⟩, 12⟩
theorem checked08 : block08.check = true := by
  norm_num [block08, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3323,
    ExposureEvolution.Compact40Pratt.prime_3329,
    ExposureEvolution.Compact40Pratt.prime_3331,
    ExposureEvolution.Compact40Pratt.prime_11015461,
    ExposureEvolution.Compact40Pratt.prime_11015663,
    ExposureEvolution.Compact40Pratt.prime_11015743]

def block09 : Witness := ⟨⟨11042329, 11082240, 3329, 3331, 3343, 11041777, 11042131, 11042309⟩, 11⟩
theorem checked09 : block09.check = true := by
  norm_num [block09, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3329,
    ExposureEvolution.Compact40Pratt.prime_3331,
    ExposureEvolution.Compact40Pratt.prime_3343,
    ExposureEvolution.Compact40Pratt.prime_11041777,
    ExposureEvolution.Compact40Pratt.prime_11042131,
    ExposureEvolution.Compact40Pratt.prime_11042309]

def block10 : Witness := ⟨⟨11082241, 11095560, 3331, 3343, 3347, 11082133, 11082193, 11082233⟩, 9⟩
theorem checked10 : block10.check = true := by
  norm_num [block10, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3331,
    ExposureEvolution.Compact40Pratt.prime_3343,
    ExposureEvolution.Compact40Pratt.prime_3347,
    ExposureEvolution.Compact40Pratt.prime_11082133,
    ExposureEvolution.Compact40Pratt.prime_11082193,
    ExposureEvolution.Compact40Pratt.prime_11082233]

def block11 : Witness := ⟨⟨11095561, 11175648, 3343, 3347, 3359, 11095211, 11095439, 11095559⟩, 10⟩
theorem checked11 : block11.check = true := by
  norm_num [block11, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3343,
    ExposureEvolution.Compact40Pratt.prime_3347,
    ExposureEvolution.Compact40Pratt.prime_3359,
    ExposureEvolution.Compact40Pratt.prime_11095211,
    ExposureEvolution.Compact40Pratt.prime_11095439,
    ExposureEvolution.Compact40Pratt.prime_11095559]

def block12 : Witness := ⟨⟨11175649, 11202408, 3347, 3359, 3361, 11175491, 11175503, 11175617⟩, 9⟩
theorem checked12 : block12.check = true := by
  norm_num [block12, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3347,
    ExposureEvolution.Compact40Pratt.prime_3359,
    ExposureEvolution.Compact40Pratt.prime_3361,
    ExposureEvolution.Compact40Pratt.prime_11175491,
    ExposureEvolution.Compact40Pratt.prime_11175503,
    ExposureEvolution.Compact40Pratt.prime_11175617]

def block13 : Witness := ⟨⟨11202409, 11282880, 3359, 3361, 3371, 11202073, 11202293, 11202349⟩, 7⟩
theorem checked13 : block13.check = true := by
  norm_num [block13, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3359,
    ExposureEvolution.Compact40Pratt.prime_3361,
    ExposureEvolution.Compact40Pratt.prime_3371,
    ExposureEvolution.Compact40Pratt.prime_11202073,
    ExposureEvolution.Compact40Pratt.prime_11202293,
    ExposureEvolution.Compact40Pratt.prime_11202349]

def block14 : Witness := ⟨⟨11282881, 11296320, 3361, 3371, 3373, 11282779, 11282839, 11282879⟩, 11⟩
theorem checked14 : block14.check = true := by
  norm_num [block14, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3361,
    ExposureEvolution.Compact40Pratt.prime_3371,
    ExposureEvolution.Compact40Pratt.prime_3373,
    ExposureEvolution.Compact40Pratt.prime_11282779,
    ExposureEvolution.Compact40Pratt.prime_11282839,
    ExposureEvolution.Compact40Pratt.prime_11282879]

def block15 : Witness := ⟨⟨11296321, 11363640, 3371, 3373, 3389, 11296223, 11296253, 11296301⟩, 9⟩
theorem checked15 : block15.check = true := by
  norm_num [block15, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3371,
    ExposureEvolution.Compact40Pratt.prime_3373,
    ExposureEvolution.Compact40Pratt.prime_3389,
    ExposureEvolution.Compact40Pratt.prime_11296223,
    ExposureEvolution.Compact40Pratt.prime_11296253,
    ExposureEvolution.Compact40Pratt.prime_11296301]

def block16 : Witness := ⟨⟨11363641, 11377128, 3373, 3389, 3391, 11363243, 11363249, 11363617⟩, 11⟩
theorem checked16 : block16.check = true := by
  norm_num [block16, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3373,
    ExposureEvolution.Compact40Pratt.prime_3389,
    ExposureEvolution.Compact40Pratt.prime_3391,
    ExposureEvolution.Compact40Pratt.prime_11363243,
    ExposureEvolution.Compact40Pratt.prime_11363249,
    ExposureEvolution.Compact40Pratt.prime_11363617]

def block17 : Witness := ⟨⟨11377129, 11485320, 3389, 3391, 3407, 11376571, 11376581, 11377127⟩, 7⟩
theorem checked17 : block17.check = true := by
  norm_num [block17, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3389,
    ExposureEvolution.Compact40Pratt.prime_3391,
    ExposureEvolution.Compact40Pratt.prime_3407,
    ExposureEvolution.Compact40Pratt.prime_11376571,
    ExposureEvolution.Compact40Pratt.prime_11376581,
    ExposureEvolution.Compact40Pratt.prime_11377127]

def block18 : Witness := ⟨⟨11485321, 11498880, 3391, 3407, 3413, 11485079, 11485151, 11485277⟩, 9⟩
theorem checked18 : block18.check = true := by
  norm_num [block18, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3391,
    ExposureEvolution.Compact40Pratt.prime_3407,
    ExposureEvolution.Compact40Pratt.prime_3413,
    ExposureEvolution.Compact40Pratt.prime_11485079,
    ExposureEvolution.Compact40Pratt.prime_11485151,
    ExposureEvolution.Compact40Pratt.prime_11485277]

def block19 : Witness := ⟨⟨11498881, 11607648, 3407, 3413, 3433, 11498789, 11498813, 11498843⟩, 8⟩
theorem checked19 : block19.check = true := by
  norm_num [block19, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3407,
    ExposureEvolution.Compact40Pratt.prime_3413,
    ExposureEvolution.Compact40Pratt.prime_3433,
    ExposureEvolution.Compact40Pratt.prime_11498789,
    ExposureEvolution.Compact40Pratt.prime_11498813,
    ExposureEvolution.Compact40Pratt.prime_11498843]

def block20 : Witness := ⟨⟨11607649, 11648568, 3413, 3433, 3449, 11607289, 11607523, 11607623⟩, 10⟩
theorem checked20 : block20.check = true := by
  norm_num [block20, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3413,
    ExposureEvolution.Compact40Pratt.prime_3433,
    ExposureEvolution.Compact40Pratt.prime_3449,
    ExposureEvolution.Compact40Pratt.prime_11607289,
    ExposureEvolution.Compact40Pratt.prime_11607523,
    ExposureEvolution.Compact40Pratt.prime_11607623]

def block21 : Witness := ⟨⟨11648569, 11785488, 3433, 3449, 3457, 11648251, 11648423, 11648561⟩, 9⟩
theorem checked21 : block21.check = true := by
  norm_num [block21, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3433,
    ExposureEvolution.Compact40Pratt.prime_3449,
    ExposureEvolution.Compact40Pratt.prime_3457,
    ExposureEvolution.Compact40Pratt.prime_11648251,
    ExposureEvolution.Compact40Pratt.prime_11648423,
    ExposureEvolution.Compact40Pratt.prime_11648561]

def block22 : Witness := ⟨⟨11785489, 11895600, 3449, 3457, 3461, 11785349, 11785441, 11785463⟩, 9⟩
theorem checked22 : block22.check = true := by
  norm_num [block22, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3449,
    ExposureEvolution.Compact40Pratt.prime_3457,
    ExposureEvolution.Compact40Pratt.prime_3461,
    ExposureEvolution.Compact40Pratt.prime_11785349,
    ExposureEvolution.Compact40Pratt.prime_11785441,
    ExposureEvolution.Compact40Pratt.prime_11785463]

def block23 : Witness := ⟨⟨11895601, 11950848, 3457, 3461, 3463, 11895199, 11895361, 11895589⟩, 10⟩
theorem checked23 : block23.check = true := by
  norm_num [block23, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3457,
    ExposureEvolution.Compact40Pratt.prime_3461,
    ExposureEvolution.Compact40Pratt.prime_3463,
    ExposureEvolution.Compact40Pratt.prime_11895199,
    ExposureEvolution.Compact40Pratt.prime_11895361,
    ExposureEvolution.Compact40Pratt.prime_11895589]

def block24 : Witness := ⟨⟨11950849, 11978520, 3461, 3463, 3467, 11950481, 11950537, 11950837⟩, 8⟩
theorem checked24 : block24.check = true := by
  norm_num [block24, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3461,
    ExposureEvolution.Compact40Pratt.prime_3463,
    ExposureEvolution.Compact40Pratt.prime_3467,
    ExposureEvolution.Compact40Pratt.prime_11950481,
    ExposureEvolution.Compact40Pratt.prime_11950537,
    ExposureEvolution.Compact40Pratt.prime_11950837]

def block25 : Witness := ⟨⟨11978521, 11992368, 3463, 3467, 3469, 11978023, 11978359, 11978507⟩, 10⟩
theorem checked25 : block25.check = true := by
  norm_num [block25, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3463,
    ExposureEvolution.Compact40Pratt.prime_3467,
    ExposureEvolution.Compact40Pratt.prime_3469,
    ExposureEvolution.Compact40Pratt.prime_11978023,
    ExposureEvolution.Compact40Pratt.prime_11978359,
    ExposureEvolution.Compact40Pratt.prime_11978507]

def block26 : Witness := ⟨⟨11992369, 12020088, 3467, 3469, 3491, 11992037, 11992063, 11992349⟩, 9⟩
theorem checked26 : block26.check = true := by
  norm_num [block26, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3467,
    ExposureEvolution.Compact40Pratt.prime_3469,
    ExposureEvolution.Compact40Pratt.prime_3491,
    ExposureEvolution.Compact40Pratt.prime_11992037,
    ExposureEvolution.Compact40Pratt.prime_11992063,
    ExposureEvolution.Compact40Pratt.prime_11992349]

def block27 : Witness := ⟨⟨12020089, 12033960, 3469, 3491, 3499, 12019927, 12019933, 12020083⟩, 8⟩
theorem checked27 : block27.check = true := by
  norm_num [block27, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3469,
    ExposureEvolution.Compact40Pratt.prime_3491,
    ExposureEvolution.Compact40Pratt.prime_3499,
    ExposureEvolution.Compact40Pratt.prime_12019927,
    ExposureEvolution.Compact40Pratt.prime_12019933,
    ExposureEvolution.Compact40Pratt.prime_12020083]

def block28 : Witness := ⟨⟨12033961, 12187080, 3491, 3499, 3511, 12033533, 12033877, 12033953⟩, 9⟩
theorem checked28 : block28.check = true := by
  norm_num [block28, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3491,
    ExposureEvolution.Compact40Pratt.prime_3499,
    ExposureEvolution.Compact40Pratt.prime_3511,
    ExposureEvolution.Compact40Pratt.prime_12033533,
    ExposureEvolution.Compact40Pratt.prime_12033877,
    ExposureEvolution.Compact40Pratt.prime_12033953]

def block29 : Witness := ⟨⟨12187081, 12243000, 3499, 3511, 3517, 12186679, 12187051, 12187073⟩, 10⟩
theorem checked29 : block29.check = true := by
  norm_num [block29, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3499,
    ExposureEvolution.Compact40Pratt.prime_3511,
    ExposureEvolution.Compact40Pratt.prime_3517,
    ExposureEvolution.Compact40Pratt.prime_12186679,
    ExposureEvolution.Compact40Pratt.prime_12187051,
    ExposureEvolution.Compact40Pratt.prime_12187073]

def block30 : Witness := ⟨⟨12243001, 12327120, 3511, 3517, 3527, 12242501, 12242773, 12242987⟩, 11⟩
theorem checked30 : block30.check = true := by
  norm_num [block30, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3511,
    ExposureEvolution.Compact40Pratt.prime_3517,
    ExposureEvolution.Compact40Pratt.prime_3527,
    ExposureEvolution.Compact40Pratt.prime_12242501,
    ExposureEvolution.Compact40Pratt.prime_12242773,
    ExposureEvolution.Compact40Pratt.prime_12242987]

def block31 : Witness := ⟨⟨12327121, 12369288, 3517, 3527, 3529, 12326599, 12326927, 12327109⟩, 11⟩
theorem checked31 : block31.check = true := by
  norm_num [block31, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3517,
    ExposureEvolution.Compact40Pratt.prime_3527,
    ExposureEvolution.Compact40Pratt.prime_3529,
    ExposureEvolution.Compact40Pratt.prime_12326599,
    ExposureEvolution.Compact40Pratt.prime_12326927,
    ExposureEvolution.Compact40Pratt.prime_12327109]

def block32 : Witness := ⟨⟨12369289, 12439728, 3527, 3529, 3533, 12368903, 12369197, 12369281⟩, 8⟩
theorem checked32 : block32.check = true := by
  norm_num [block32, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3527,
    ExposureEvolution.Compact40Pratt.prime_3529,
    ExposureEvolution.Compact40Pratt.prime_3533,
    ExposureEvolution.Compact40Pratt.prime_12368903,
    ExposureEvolution.Compact40Pratt.prime_12369197,
    ExposureEvolution.Compact40Pratt.prime_12369281]

def block33 : Witness := ⟨⟨12439729, 12453840, 3529, 3533, 3539, 12439199, 12439253, 12439727⟩, 11⟩
theorem checked33 : block33.check = true := by
  norm_num [block33, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3529,
    ExposureEvolution.Compact40Pratt.prime_3533,
    ExposureEvolution.Compact40Pratt.prime_3539,
    ExposureEvolution.Compact40Pratt.prime_12439199,
    ExposureEvolution.Compact40Pratt.prime_12439253,
    ExposureEvolution.Compact40Pratt.prime_12439727]

def block34 : Witness := ⟨⟨12453841, 12482088, 3533, 3539, 3541, 12453583, 12453757, 12453829⟩, 11⟩
theorem checked34 : block34.check = true := by
  norm_num [block34, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3533,
    ExposureEvolution.Compact40Pratt.prime_3539,
    ExposureEvolution.Compact40Pratt.prime_3541,
    ExposureEvolution.Compact40Pratt.prime_12453583,
    ExposureEvolution.Compact40Pratt.prime_12453757,
    ExposureEvolution.Compact40Pratt.prime_12453829]

def block35 : Witness := ⟨⟨12482089, 12524520, 3539, 3541, 3547, 12481559, 12481951, 12482059⟩, 8⟩
theorem checked35 : block35.check = true := by
  norm_num [block35, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3539,
    ExposureEvolution.Compact40Pratt.prime_3541,
    ExposureEvolution.Compact40Pratt.prime_3547,
    ExposureEvolution.Compact40Pratt.prime_12481559,
    ExposureEvolution.Compact40Pratt.prime_12481951,
    ExposureEvolution.Compact40Pratt.prime_12482059]

def block36 : Witness := ⟨⟨12524521, 12538680, 3541, 3547, 3557, 12524063, 12524111, 12524509⟩, 9⟩
theorem checked36 : block36.check = true := by
  norm_num [block36, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3541,
    ExposureEvolution.Compact40Pratt.prime_3547,
    ExposureEvolution.Compact40Pratt.prime_3557,
    ExposureEvolution.Compact40Pratt.prime_12524063,
    ExposureEvolution.Compact40Pratt.prime_12524111,
    ExposureEvolution.Compact40Pratt.prime_12524509]

def block37 : Witness := ⟨⟨12538681, 12581208, 3547, 3557, 3559, 12538321, 12538517, 12538679⟩, 13⟩
theorem checked37 : block37.check = true := by
  norm_num [block37, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3547,
    ExposureEvolution.Compact40Pratt.prime_3557,
    ExposureEvolution.Compact40Pratt.prime_3559,
    ExposureEvolution.Compact40Pratt.prime_12538321,
    ExposureEvolution.Compact40Pratt.prime_12538517,
    ExposureEvolution.Compact40Pratt.prime_12538679]

def block38 : Witness := ⟨⟨12581209, 12652248, 3557, 3559, 3571, 12580877, 12580949, 12581183⟩, 9⟩
theorem checked38 : block38.check = true := by
  norm_num [block38, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3557,
    ExposureEvolution.Compact40Pratt.prime_3559,
    ExposureEvolution.Compact40Pratt.prime_3571,
    ExposureEvolution.Compact40Pratt.prime_12580877,
    ExposureEvolution.Compact40Pratt.prime_12580949,
    ExposureEvolution.Compact40Pratt.prime_12581183]

def block39 : Witness := ⟨⟨12652249, 12666480, 3559, 3571, 3581, 12652027, 12652103, 12652229⟩, 9⟩
theorem checked39 : block39.check = true := by
  norm_num [block39, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3559,
    ExposureEvolution.Compact40Pratt.prime_3571,
    ExposureEvolution.Compact40Pratt.prime_3581,
    ExposureEvolution.Compact40Pratt.prime_12652027,
    ExposureEvolution.Compact40Pratt.prime_12652103,
    ExposureEvolution.Compact40Pratt.prime_12652229]

def block40 : Witness := ⟨⟨12666481, 12752040, 3571, 3581, 3583, 12665869, 12666421, 12666461⟩, 12⟩
theorem checked40 : block40.check = true := by
  norm_num [block40, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3571,
    ExposureEvolution.Compact40Pratt.prime_3581,
    ExposureEvolution.Compact40Pratt.prime_3583,
    ExposureEvolution.Compact40Pratt.prime_12665869,
    ExposureEvolution.Compact40Pratt.prime_12666421,
    ExposureEvolution.Compact40Pratt.prime_12666461]

def block41 : Witness := ⟨⟨12752041, 12823560, 3581, 3583, 3593, 12751927, 12751969, 12752029⟩, 7⟩
theorem checked41 : block41.check = true := by
  norm_num [block41, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3581,
    ExposureEvolution.Compact40Pratt.prime_3583,
    ExposureEvolution.Compact40Pratt.prime_3593,
    ExposureEvolution.Compact40Pratt.prime_12751927,
    ExposureEvolution.Compact40Pratt.prime_12751969,
    ExposureEvolution.Compact40Pratt.prime_12752029]

def block42 : Witness := ⟨⟨12823561, 12837888, 3583, 3593, 3607, 12823189, 12823333, 12823541⟩, 5⟩
theorem checked42 : block42.check = true := by
  norm_num [block42, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3583,
    ExposureEvolution.Compact40Pratt.prime_3593,
    ExposureEvolution.Compact40Pratt.prime_3607,
    ExposureEvolution.Compact40Pratt.prime_12823189,
    ExposureEvolution.Compact40Pratt.prime_12823333,
    ExposureEvolution.Compact40Pratt.prime_12823541]

def block43 : Witness := ⟨⟨12837889, 12909648, 3593, 3607, 3613, 12837661, 12837743, 12837883⟩, 8⟩
theorem checked43 : block43.check = true := by
  norm_num [block43, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3593,
    ExposureEvolution.Compact40Pratt.prime_3607,
    ExposureEvolution.Compact40Pratt.prime_3613,
    ExposureEvolution.Compact40Pratt.prime_12837661,
    ExposureEvolution.Compact40Pratt.prime_12837743,
    ExposureEvolution.Compact40Pratt.prime_12837883]

def block44 : Witness := ⟨⟨12909649, 13010448, 3607, 3613, 3617, 12909277, 12909397, 12909643⟩, 8⟩
theorem checked44 : block44.check = true := by
  norm_num [block44, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3607,
    ExposureEvolution.Compact40Pratt.prime_3613,
    ExposureEvolution.Compact40Pratt.prime_3617,
    ExposureEvolution.Compact40Pratt.prime_12909277,
    ExposureEvolution.Compact40Pratt.prime_12909397,
    ExposureEvolution.Compact40Pratt.prime_12909643]

def block45 : Witness := ⟨⟨13010449, 13053768, 3613, 3617, 3623, 13009901, 13010147, 13010447⟩, 13⟩
theorem checked45 : block45.check = true := by
  norm_num [block45, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3613,
    ExposureEvolution.Compact40Pratt.prime_3617,
    ExposureEvolution.Compact40Pratt.prime_3623,
    ExposureEvolution.Compact40Pratt.prime_13009901,
    ExposureEvolution.Compact40Pratt.prime_13010147,
    ExposureEvolution.Compact40Pratt.prime_13010447]

def block46 : Witness := ⟨⟨13053769, 13082688, 3617, 3623, 3631, 13053253, 13053371, 13053749⟩, 9⟩
theorem checked46 : block46.check = true := by
  norm_num [block46, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3617,
    ExposureEvolution.Compact40Pratt.prime_3623,
    ExposureEvolution.Compact40Pratt.prime_3631,
    ExposureEvolution.Compact40Pratt.prime_13053253,
    ExposureEvolution.Compact40Pratt.prime_13053371,
    ExposureEvolution.Compact40Pratt.prime_13053749]

def block47 : Witness := ⟨⟨13082689, 13126128, 3623, 3631, 3637, 13082297, 13082603, 13082687⟩, 9⟩
theorem checked47 : block47.check = true := by
  norm_num [block47, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3623,
    ExposureEvolution.Compact40Pratt.prime_3631,
    ExposureEvolution.Compact40Pratt.prime_3637,
    ExposureEvolution.Compact40Pratt.prime_13082297,
    ExposureEvolution.Compact40Pratt.prime_13082603,
    ExposureEvolution.Compact40Pratt.prime_13082687]

def block48 : Witness := ⟨⟨13126129, 13184160, 3631, 3637, 3643, 13125611, 13125947, 13126121⟩, 8⟩
theorem checked48 : block48.check = true := by
  norm_num [block48, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3631,
    ExposureEvolution.Compact40Pratt.prime_3637,
    ExposureEvolution.Compact40Pratt.prime_3643,
    ExposureEvolution.Compact40Pratt.prime_13125611,
    ExposureEvolution.Compact40Pratt.prime_13125947,
    ExposureEvolution.Compact40Pratt.prime_13126121]

def block49 : Witness := ⟨⟨13184161, 13227768, 3637, 3643, 3659, 13183883, 13184141, 13184153⟩, 8⟩
theorem checked49 : block49.check = true := by
  norm_num [block49, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3637,
    ExposureEvolution.Compact40Pratt.prime_3643,
    ExposureEvolution.Compact40Pratt.prime_3659,
    ExposureEvolution.Compact40Pratt.prime_13183883,
    ExposureEvolution.Compact40Pratt.prime_13184141,
    ExposureEvolution.Compact40Pratt.prime_13184153]

def block50 : Witness := ⟨⟨13227769, 13271448, 3643, 3659, 3671, 13227419, 13227497, 13227757⟩, 15⟩
theorem checked50 : block50.check = true := by
  norm_num [block50, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3643,
    ExposureEvolution.Compact40Pratt.prime_3659,
    ExposureEvolution.Compact40Pratt.prime_3671,
    ExposureEvolution.Compact40Pratt.prime_13227419,
    ExposureEvolution.Compact40Pratt.prime_13227497,
    ExposureEvolution.Compact40Pratt.prime_13227757]

def block51 : Witness := ⟨⟨13271449, 13388280, 3659, 3671, 3673, 13271287, 13271389, 13271429⟩, 6⟩
theorem checked51 : block51.check = true := by
  norm_num [block51, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3659,
    ExposureEvolution.Compact40Pratt.prime_3671,
    ExposureEvolution.Compact40Pratt.prime_3673,
    ExposureEvolution.Compact40Pratt.prime_13271287,
    ExposureEvolution.Compact40Pratt.prime_13271389,
    ExposureEvolution.Compact40Pratt.prime_13271429]

def block52 : Witness := ⟨⟨13388281, 13476240, 3671, 3673, 3677, 13387841, 13387859, 13388269⟩, 8⟩
theorem checked52 : block52.check = true := by
  norm_num [block52, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3671,
    ExposureEvolution.Compact40Pratt.prime_3673,
    ExposureEvolution.Compact40Pratt.prime_3677,
    ExposureEvolution.Compact40Pratt.prime_13387841,
    ExposureEvolution.Compact40Pratt.prime_13387859,
    ExposureEvolution.Compact40Pratt.prime_13388269]

def block53 : Witness := ⟨⟨13476241, 13490928, 3673, 3677, 3691, 13475827, 13476193, 13476233⟩, 6⟩
theorem checked53 : block53.check = true := by
  norm_num [block53, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3673,
    ExposureEvolution.Compact40Pratt.prime_3677,
    ExposureEvolution.Compact40Pratt.prime_3691,
    ExposureEvolution.Compact40Pratt.prime_13475827,
    ExposureEvolution.Compact40Pratt.prime_13476193,
    ExposureEvolution.Compact40Pratt.prime_13476233]

def block54 : Witness := ⟨⟨13490929, 13520328, 3677, 3691, 3697, 13490341, 13490803, 13490879⟩, 9⟩
theorem checked54 : block54.check = true := by
  norm_num [block54, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3677,
    ExposureEvolution.Compact40Pratt.prime_3691,
    ExposureEvolution.Compact40Pratt.prime_3697,
    ExposureEvolution.Compact40Pratt.prime_13490341,
    ExposureEvolution.Compact40Pratt.prime_13490803,
    ExposureEvolution.Compact40Pratt.prime_13490879]

def block55 : Witness := ⟨⟨13520329, 13623480, 3691, 3697, 3701, 13520011, 13520047, 13520303⟩, 8⟩
theorem checked55 : block55.check = true := by
  norm_num [block55, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3691,
    ExposureEvolution.Compact40Pratt.prime_3697,
    ExposureEvolution.Compact40Pratt.prime_3701,
    ExposureEvolution.Compact40Pratt.prime_13520011,
    ExposureEvolution.Compact40Pratt.prime_13520047,
    ExposureEvolution.Compact40Pratt.prime_13520303]

def block56 : Witness := ⟨⟨13623481, 13667808, 3697, 3701, 3709, 13623283, 13623413, 13623469⟩, 10⟩
theorem checked56 : block56.check = true := by
  norm_num [block56, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3697,
    ExposureEvolution.Compact40Pratt.prime_3701,
    ExposureEvolution.Compact40Pratt.prime_3709,
    ExposureEvolution.Compact40Pratt.prime_13623283,
    ExposureEvolution.Compact40Pratt.prime_13623413,
    ExposureEvolution.Compact40Pratt.prime_13623469]

def block57 : Witness := ⟨⟨13667809, 13697400, 3701, 3709, 3719, 13667597, 13667603, 13667803⟩, 8⟩
theorem checked57 : block57.check = true := by
  norm_num [block57, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3701,
    ExposureEvolution.Compact40Pratt.prime_3709,
    ExposureEvolution.Compact40Pratt.prime_3719,
    ExposureEvolution.Compact40Pratt.prime_13667597,
    ExposureEvolution.Compact40Pratt.prime_13667603,
    ExposureEvolution.Compact40Pratt.prime_13667803]

def block58 : Witness := ⟨⟨13697401, 13756680, 3709, 3719, 3727, 13697221, 13697357, 13697399⟩, 9⟩
theorem checked58 : block58.check = true := by
  norm_num [block58, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3709,
    ExposureEvolution.Compact40Pratt.prime_3719,
    ExposureEvolution.Compact40Pratt.prime_3727,
    ExposureEvolution.Compact40Pratt.prime_13697221,
    ExposureEvolution.Compact40Pratt.prime_13697357,
    ExposureEvolution.Compact40Pratt.prime_13697399]

def block59 : Witness := ⟨⟨13756681, 13830960, 3719, 3727, 3733, 13756397, 13756453, 13756679⟩, 9⟩
theorem checked59 : block59.check = true := by
  norm_num [block59, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3719,
    ExposureEvolution.Compact40Pratt.prime_3727,
    ExposureEvolution.Compact40Pratt.prime_3733,
    ExposureEvolution.Compact40Pratt.prime_13756397,
    ExposureEvolution.Compact40Pratt.prime_13756453,
    ExposureEvolution.Compact40Pratt.prime_13756679]

def block60 : Witness := ⟨⟨13830961, 13890528, 3727, 3733, 3739, 13830533, 13830679, 13830953⟩, 9⟩
theorem checked60 : block60.check = true := by
  norm_num [block60, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3727,
    ExposureEvolution.Compact40Pratt.prime_3733,
    ExposureEvolution.Compact40Pratt.prime_3739,
    ExposureEvolution.Compact40Pratt.prime_13830533,
    ExposureEvolution.Compact40Pratt.prime_13830679,
    ExposureEvolution.Compact40Pratt.prime_13830953]

def block61 : Witness := ⟨⟨13890529, 13935288, 3733, 3739, 3761, 13890313, 13890421, 13890509⟩, 7⟩
theorem checked61 : block61.check = true := by
  norm_num [block61, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3733,
    ExposureEvolution.Compact40Pratt.prime_3739,
    ExposureEvolution.Compact40Pratt.prime_3761,
    ExposureEvolution.Compact40Pratt.prime_13890313,
    ExposureEvolution.Compact40Pratt.prime_13890421,
    ExposureEvolution.Compact40Pratt.prime_13890509]

def block62 : Witness := ⟨⟨13935289, 13980120, 3739, 3761, 3767, 13934969, 13935161, 13935281⟩, 8⟩
theorem checked62 : block62.check = true := by
  norm_num [block62, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3739,
    ExposureEvolution.Compact40Pratt.prime_3761,
    ExposureEvolution.Compact40Pratt.prime_3767,
    ExposureEvolution.Compact40Pratt.prime_13934969,
    ExposureEvolution.Compact40Pratt.prime_13935161,
    ExposureEvolution.Compact40Pratt.prime_13935281]

def block63 : Witness := ⟨⟨13980121, 14145120, 3761, 3767, 3769, 13979759, 13979963, 13980107⟩, 7⟩
theorem checked63 : block63.check = true := by
  norm_num [block63, Witness.check, Witness.Valid, Witness.endpoint,
    Block.structureValid, Block.P, Block.Q, Block.A, Block.D, Block.B,
    ExposureEvolution.Compact40Pratt.prime_3761,
    ExposureEvolution.Compact40Pratt.prime_3767,
    ExposureEvolution.Compact40Pratt.prime_3769,
    ExposureEvolution.Compact40Pratt.prime_13979759,
    ExposureEvolution.Compact40Pratt.prime_13979963,
    ExposureEvolution.Compact40Pratt.prime_13980107]

def witnesses : List Witness := [block00, block01, block02, block03, block04, block05, block06, block07, block08, block09, block10, block11, block12, block13, block14, block15, block16, block17, block18, block19, block20, block21, block22, block23, block24, block25, block26, block27, block28, block29, block30, block31, block32, block33, block34, block35, block36, block37, block38, block39, block40, block41, block42, block43, block44, block45, block46, block47, block48, block49, block50, block51, block52, block53, block54, block55, block56, block57, block58, block59, block60, block61, block62, block63]

theorem extend (stop : ℕ) (tail : List Witness)
    (h : coverage 14145121 stop tail = true) :
    coverage 10582009 stop (witnesses ++ tail) = true := by
  change coverage _ _ (block00 :: block01 :: block02 :: block03 :: block04 :: block05 :: block06 :: block07 :: block08 :: block09 :: block10 :: block11 :: block12 :: block13 :: block14 :: block15 :: block16 :: block17 :: block18 :: block19 :: block20 :: block21 :: block22 :: block23 :: block24 :: block25 :: block26 :: block27 :: block28 :: block29 :: block30 :: block31 :: block32 :: block33 :: block34 :: block35 :: block36 :: block37 :: block38 :: block39 :: block40 :: block41 :: block42 :: block43 :: block44 :: block45 :: block46 :: block47 :: block48 :: block49 :: block50 :: block51 :: block52 :: block53 :: block54 :: block55 :: block56 :: block57 :: block58 :: block59 :: block60 :: block61 :: block62 :: block63 :: tail) = true
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked00
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked01
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked02
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked03
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked04
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked05
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked06
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked07
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked08
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked09
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked10
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked11
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked12
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked13
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked14
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked15
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked16
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked17
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked18
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked19
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked20
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked21
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked22
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked23
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked24
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked25
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked26
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked27
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked28
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked29
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked30
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked31
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked32
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked33
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked34
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked35
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked36
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked37
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked38
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked39
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked40
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked41
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked42
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked43
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked44
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked45
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked46
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked47
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked48
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked49
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked50
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked51
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked52
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked53
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked54
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked55
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked56
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked57
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked58
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked59
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked60
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked61
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked62
  apply ExposureEvolution.DualKernelCompose60.coverage_cons _ _ _ _ rfl checked63
  exact h

#print axioms extend
end ExposureEvolution.DualKernelBlocks60_002
