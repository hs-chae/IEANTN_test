import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks002
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_10369 : next 10369 = some 10399 := by
  have hl : (List.range ((257 * 10369 - 1) / 256 - 10369)).reverse =
      [39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10399]

theorem next_10399 : next 10399 = some 10433 := by
  have hl : (List.range ((257 * 10399 - 1) / 256 - 10399)).reverse =
      [39, 38, 37, 36, 35, 34, 33] ++ (List.range 33).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10433]

theorem next_10433 : next 10433 = some 10463 := by
  have hl : (List.range ((257 * 10433 - 1) / 256 - 10433)).reverse =
      [39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10463]

theorem next_10463 : next 10463 = some 10501 := by
  have hl : (List.range ((257 * 10463 - 1) / 256 - 10463)).reverse =
      [39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10501]

theorem next_10501 : next 10501 = some 10531 := by
  have hl : (List.range ((257 * 10501 - 1) / 256 - 10501)).reverse =
      [40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29] ++ (List.range 29).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10531]

theorem next_10531 : next 10531 = some 10567 := by
  have hl : (List.range ((257 * 10531 - 1) / 256 - 10531)).reverse =
      [40, 39, 38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10567]

theorem next_10567 : next 10567 = some 10607 := by
  have hl : (List.range ((257 * 10567 - 1) / 256 - 10567)).reverse =
      [40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10607]

theorem next_10607 : next 10607 = some 10639 := by
  have hl : (List.range ((257 * 10607 - 1) / 256 - 10607)).reverse =
      [40, 39, 38, 37, 36, 35, 34, 33, 32, 31] ++ (List.range 31).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10639]

theorem next_10639 : next 10639 = some 10667 := by
  have hl : (List.range ((257 * 10639 - 1) / 256 - 10639)).reverse =
      [40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27] ++ (List.range 27).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10667]

theorem next_10667 : next 10667 = some 10691 := by
  have hl : (List.range ((257 * 10667 - 1) / 256 - 10667)).reverse =
      [40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10691]

theorem next_10691 : next 10691 = some 10729 := by
  have hl : (List.range ((257 * 10691 - 1) / 256 - 10691)).reverse =
      [40, 39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10729]

theorem next_10729 : next 10729 = some 10753 := by
  have hl : (List.range ((257 * 10729 - 1) / 256 - 10729)).reverse =
      [40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10753]

theorem next_10753 : next 10753 = some 10789 := by
  have hl : (List.range ((257 * 10753 - 1) / 256 - 10753)).reverse =
      [41, 40, 39, 38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10789]

theorem next_10789 : next 10789 = some 10831 := by
  have hl : (List.range ((257 * 10789 - 1) / 256 - 10789)).reverse =
      [41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10831]

theorem next_10831 : next 10831 = some 10867 := by
  have hl : (List.range ((257 * 10831 - 1) / 256 - 10831)).reverse =
      [41, 40, 39, 38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10867]

theorem next_10867 : next 10867 = some 10909 := by
  have hl : (List.range ((257 * 10867 - 1) / 256 - 10867)).reverse =
      [41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10909]

theorem next_10909 : next 10909 = some 10949 := by
  have hl : (List.range ((257 * 10909 - 1) / 256 - 10909)).reverse =
      [41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10949]

theorem next_10949 : next 10949 = some 10987 := by
  have hl : (List.range ((257 * 10949 - 1) / 256 - 10949)).reverse =
      [41, 40, 39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_10987]

theorem next_10987 : next 10987 = some 11027 := by
  have hl : (List.range ((257 * 10987 - 1) / 256 - 10987)).reverse =
      [41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11027]

theorem next_11027 : next 11027 = some 11069 := by
  have hl : (List.range ((257 * 11027 - 1) / 256 - 11027)).reverse =
      [42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11069]

theorem next_11069 : next 11069 = some 11093 := by
  have hl : (List.range ((257 * 11069 - 1) / 256 - 11069)).reverse =
      [42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23] ++ (List.range 23).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11093]

theorem next_11093 : next 11093 = some 11131 := by
  have hl : (List.range ((257 * 11093 - 1) / 256 - 11093)).reverse =
      [42, 41, 40, 39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11131]

theorem next_11131 : next 11131 = some 11173 := by
  have hl : (List.range ((257 * 11131 - 1) / 256 - 11131)).reverse =
      [42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11173]

theorem next_11173 : next 11173 = some 11213 := by
  have hl : (List.range ((257 * 11173 - 1) / 256 - 11173)).reverse =
      [42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11213]

theorem next_11213 : next 11213 = some 11251 := by
  have hl : (List.range ((257 * 11213 - 1) / 256 - 11213)).reverse =
      [42, 41, 40, 39, 38, 37] ++ (List.range 37).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11251]

theorem next_11251 : next 11251 = some 11287 := by
  have hl : (List.range ((257 * 11251 - 1) / 256 - 11251)).reverse =
      [42, 41, 40, 39, 38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11287]

theorem next_11287 : next 11287 = some 11329 := by
  have hl : (List.range ((257 * 11287 - 1) / 256 - 11287)).reverse =
      [43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11329]

theorem next_11329 : next 11329 = some 11369 := by
  have hl : (List.range ((257 * 11329 - 1) / 256 - 11329)).reverse =
      [43, 42, 41, 40, 39] ++ (List.range 39).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11369]

theorem next_11369 : next 11369 = some 11411 := by
  have hl : (List.range ((257 * 11369 - 1) / 256 - 11369)).reverse =
      [43, 42, 41] ++ (List.range 41).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11411]

theorem next_11411 : next 11411 = some 11447 := by
  have hl : (List.range ((257 * 11411 - 1) / 256 - 11411)).reverse =
      [43, 42, 41, 40, 39, 38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11447]

theorem next_11447 : next 11447 = some 11491 := by
  have hl : (List.range ((257 * 11447 - 1) / 256 - 11447)).reverse =
      [43] ++ (List.range 43).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11491]

theorem next_11491 : next 11491 = some 11527 := by
  have hl : (List.range ((257 * 11491 - 1) / 256 - 11491)).reverse =
      [43, 42, 41, 40, 39, 38, 37, 36, 35] ++ (List.range 35).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_11527]

def primes : List ℕ := [10399, 10433, 10463, 10501, 10531, 10567, 10607, 10639, 10667, 10691, 10729, 10753, 10789, 10831, 10867, 10909, 10949, 10987, 11027, 11069, 11093, 11131, 11173, 11213, 11251, 11287, 11329, 11369, 11411, 11447, 11491, 11527]

theorem segment : run 636 10369 89693 =
    primes ++ run 604 11527 89693 := by
  rw [Compact40PrimeCompose256.step 635 10369 89693 10399
    (by decide +kernel) next_10369]
  rw [Compact40PrimeCompose256.step 634 10399 89693 10433
    (by decide +kernel) next_10399]
  rw [Compact40PrimeCompose256.step 633 10433 89693 10463
    (by decide +kernel) next_10433]
  rw [Compact40PrimeCompose256.step 632 10463 89693 10501
    (by decide +kernel) next_10463]
  rw [Compact40PrimeCompose256.step 631 10501 89693 10531
    (by decide +kernel) next_10501]
  rw [Compact40PrimeCompose256.step 630 10531 89693 10567
    (by decide +kernel) next_10531]
  rw [Compact40PrimeCompose256.step 629 10567 89693 10607
    (by decide +kernel) next_10567]
  rw [Compact40PrimeCompose256.step 628 10607 89693 10639
    (by decide +kernel) next_10607]
  rw [Compact40PrimeCompose256.step 627 10639 89693 10667
    (by decide +kernel) next_10639]
  rw [Compact40PrimeCompose256.step 626 10667 89693 10691
    (by decide +kernel) next_10667]
  rw [Compact40PrimeCompose256.step 625 10691 89693 10729
    (by decide +kernel) next_10691]
  rw [Compact40PrimeCompose256.step 624 10729 89693 10753
    (by decide +kernel) next_10729]
  rw [Compact40PrimeCompose256.step 623 10753 89693 10789
    (by decide +kernel) next_10753]
  rw [Compact40PrimeCompose256.step 622 10789 89693 10831
    (by decide +kernel) next_10789]
  rw [Compact40PrimeCompose256.step 621 10831 89693 10867
    (by decide +kernel) next_10831]
  rw [Compact40PrimeCompose256.step 620 10867 89693 10909
    (by decide +kernel) next_10867]
  rw [Compact40PrimeCompose256.step 619 10909 89693 10949
    (by decide +kernel) next_10909]
  rw [Compact40PrimeCompose256.step 618 10949 89693 10987
    (by decide +kernel) next_10949]
  rw [Compact40PrimeCompose256.step 617 10987 89693 11027
    (by decide +kernel) next_10987]
  rw [Compact40PrimeCompose256.step 616 11027 89693 11069
    (by decide +kernel) next_11027]
  rw [Compact40PrimeCompose256.step 615 11069 89693 11093
    (by decide +kernel) next_11069]
  rw [Compact40PrimeCompose256.step 614 11093 89693 11131
    (by decide +kernel) next_11093]
  rw [Compact40PrimeCompose256.step 613 11131 89693 11173
    (by decide +kernel) next_11131]
  rw [Compact40PrimeCompose256.step 612 11173 89693 11213
    (by decide +kernel) next_11173]
  rw [Compact40PrimeCompose256.step 611 11213 89693 11251
    (by decide +kernel) next_11213]
  rw [Compact40PrimeCompose256.step 610 11251 89693 11287
    (by decide +kernel) next_11251]
  rw [Compact40PrimeCompose256.step 609 11287 89693 11329
    (by decide +kernel) next_11287]
  rw [Compact40PrimeCompose256.step 608 11329 89693 11369
    (by decide +kernel) next_11329]
  rw [Compact40PrimeCompose256.step 607 11369 89693 11411
    (by decide +kernel) next_11369]
  rw [Compact40PrimeCompose256.step 606 11411 89693 11447
    (by decide +kernel) next_11411]
  rw [Compact40PrimeCompose256.step 605 11447 89693 11491
    (by decide +kernel) next_11447]
  rw [Compact40PrimeCompose256.step 604 11491 89693 11527
    (by decide +kernel) next_11491]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 11527 stop tail = true) :
    check 10369 stop (primes ++ tail) = true := by
  change check _ _ (10399 :: 10433 :: 10463 :: 10501 :: 10531 :: 10567 :: 10607 :: 10639 :: 10667 :: 10691 :: 10729 :: 10753 :: 10789 :: 10831 :: 10867 :: 10909 :: 10949 :: 10987 :: 11027 :: 11069 :: 11093 :: 11131 :: 11173 :: 11213 :: 11251 :: 11287 :: 11329 :: 11369 :: 11411 :: 11447 :: 11491 :: 11527 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10399, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10433, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10463, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10501, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10531, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10567, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10607, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10639, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10667, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10691, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10729, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10753, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10789, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10831, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10867, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10909, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10949, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_10987, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11027, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11069, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11093, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11131, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11173, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11213, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11251, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11287, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11329, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11369, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11411, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11447, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11491, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_11527, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks002
