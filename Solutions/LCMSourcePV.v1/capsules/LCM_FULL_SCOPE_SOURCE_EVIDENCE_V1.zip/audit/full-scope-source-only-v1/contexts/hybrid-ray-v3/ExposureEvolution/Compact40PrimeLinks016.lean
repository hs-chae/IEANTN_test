import ExposureEvolution.Compact40Pratt
import ExposureEvolution.Compact40PrimeCompose256
namespace ExposureEvolution.Compact40PrimeLinks016
open ExposureEvolution Compact40PrimeProgram256
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem next_49789 : next 49789 = some 49957 := by
  have hl : (List.range ((257 * 49789 - 1) / 256 - 49789)).reverse =
      [193, 192, 191, 190, 189, 188, 187, 186, 185, 184, 183, 182, 181, 180, 179, 178, 177, 176, 175, 174, 173, 172, 171, 170, 169, 168, 167] ++ (List.range 167).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_49957]

theorem next_49957 : next 49957 = some 50147 := by
  have hl : (List.range ((257 * 49957 - 1) / 256 - 49957)).reverse =
      [194, 193, 192, 191, 190, 189] ++ (List.range 189).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_50147]

theorem next_50147 : next 50147 = some 50341 := by
  have hl : (List.range ((257 * 50147 - 1) / 256 - 50147)).reverse =
      [194, 193] ++ (List.range 193).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_50341]

theorem next_50341 : next 50341 = some 50527 := by
  have hl : (List.range ((257 * 50341 - 1) / 256 - 50341)).reverse =
      [195, 194, 193, 192, 191, 190, 189, 188, 187, 186, 185] ++ (List.range 185).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_50527]

theorem next_50527 : next 50527 = some 50723 := by
  have hl : (List.range ((257 * 50527 - 1) / 256 - 50527)).reverse =
      [196, 195] ++ (List.range 195).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_50723]

theorem next_50723 : next 50723 = some 50909 := by
  have hl : (List.range ((257 * 50723 - 1) / 256 - 50723)).reverse =
      [197, 196, 195, 194, 193, 192, 191, 190, 189, 188, 187, 186, 185] ++ (List.range 185).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_50909]

theorem next_50909 : next 50909 = some 51071 := by
  have hl : (List.range ((257 * 50909 - 1) / 256 - 50909)).reverse =
      [197, 196, 195, 194, 193, 192, 191, 190, 189, 188, 187, 186, 185, 184, 183, 182, 181, 180, 179, 178, 177, 176, 175, 174, 173, 172, 171, 170, 169, 168, 167, 166, 165, 164, 163, 162, 161] ++ (List.range 161).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_51071]

theorem next_51071 : next 51071 = some 51263 := by
  have hl : (List.range ((257 * 51071 - 1) / 256 - 51071)).reverse =
      [198, 197, 196, 195, 194, 193, 192, 191] ++ (List.range 191).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_51263]

theorem next_51263 : next 51263 = some 51461 := by
  have hl : (List.range ((257 * 51263 - 1) / 256 - 51263)).reverse =
      [199, 198, 197] ++ (List.range 197).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_51461]

theorem next_51461 : next 51461 = some 51659 := by
  have hl : (List.range ((257 * 51461 - 1) / 256 - 51461)).reverse =
      [200, 199, 198, 197] ++ (List.range 197).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_51659]

theorem next_51659 : next 51659 = some 51859 := by
  have hl : (List.range ((257 * 51659 - 1) / 256 - 51659)).reverse =
      [200, 199] ++ (List.range 199).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_51859]

theorem next_51859 : next 51859 = some 52057 := by
  have hl : (List.range ((257 * 51859 - 1) / 256 - 51859)).reverse =
      [201, 200, 199, 198, 197] ++ (List.range 197).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_52057]

theorem next_52057 : next 52057 = some 52259 := by
  have hl : (List.range ((257 * 52057 - 1) / 256 - 52057)).reverse =
      [202, 201] ++ (List.range 201).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_52259]

theorem next_52259 : next 52259 = some 52457 := by
  have hl : (List.range ((257 * 52259 - 1) / 256 - 52259)).reverse =
      [203, 202, 201, 200, 199, 198, 197] ++ (List.range 197).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_52457]

theorem next_52457 : next 52457 = some 52639 := by
  have hl : (List.range ((257 * 52457 - 1) / 256 - 52457)).reverse =
      [203, 202, 201, 200, 199, 198, 197, 196, 195, 194, 193, 192, 191, 190, 189, 188, 187, 186, 185, 184, 183, 182, 181] ++ (List.range 181).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_52639]

theorem next_52639 : next 52639 = some 52837 := by
  have hl : (List.range ((257 * 52639 - 1) / 256 - 52639)).reverse =
      [204, 203, 202, 201, 200, 199, 198, 197] ++ (List.range 197).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_52837]

theorem next_52837 : next 52837 = some 53017 := by
  have hl : (List.range ((257 * 52837 - 1) / 256 - 52837)).reverse =
      [205, 204, 203, 202, 201, 200, 199, 198, 197, 196, 195, 194, 193, 192, 191, 190, 189, 188, 187, 186, 185, 184, 183, 182, 181, 180, 179] ++ (List.range 179).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_53017]

theorem next_53017 : next 53017 = some 53201 := by
  have hl : (List.range ((257 * 53017 - 1) / 256 - 53017)).reverse =
      [206, 205, 204, 203, 202, 201, 200, 199, 198, 197, 196, 195, 194, 193, 192, 191, 190, 189, 188, 187, 186, 185, 184, 183] ++ (List.range 183).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_53201]

theorem next_53201 : next 53201 = some 53407 := by
  have hl : (List.range ((257 * 53201 - 1) / 256 - 53201)).reverse =
      [206, 205] ++ (List.range 205).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_53407]

theorem next_53407 : next 53407 = some 53611 := by
  have hl : (List.range ((257 * 53407 - 1) / 256 - 53407)).reverse =
      [207, 206, 205, 204, 203] ++ (List.range 203).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_53611]

theorem next_53611 : next 53611 = some 53819 := by
  have hl : (List.range ((257 * 53611 - 1) / 256 - 53611)).reverse =
      [208, 207] ++ (List.range 207).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_53819]

theorem next_53819 : next 53819 = some 54013 := by
  have hl : (List.range ((257 * 53819 - 1) / 256 - 53819)).reverse =
      [209, 208, 207, 206, 205, 204, 203, 202, 201, 200, 199, 198, 197, 196, 195, 194, 193] ++ (List.range 193).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_54013]

theorem next_54013 : next 54013 = some 54217 := by
  have hl : (List.range ((257 * 54013 - 1) / 256 - 54013)).reverse =
      [209, 208, 207, 206, 205, 204, 203] ++ (List.range 203).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_54217]

theorem next_54217 : next 54217 = some 54421 := by
  have hl : (List.range ((257 * 54217 - 1) / 256 - 54217)).reverse =
      [210, 209, 208, 207, 206, 205, 204, 203] ++ (List.range 203).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_54421]

theorem next_54421 : next 54421 = some 54631 := by
  have hl : (List.range ((257 * 54421 - 1) / 256 - 54421)).reverse =
      [211, 210, 209] ++ (List.range 209).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_54631]

theorem next_54631 : next 54631 = some 54833 := by
  have hl : (List.range ((257 * 54631 - 1) / 256 - 54631)).reverse =
      [212, 211, 210, 209, 208, 207, 206, 205, 204, 203, 202, 201] ++ (List.range 201).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_54833]

theorem next_54833 : next 54833 = some 55021 := by
  have hl : (List.range ((257 * 54833 - 1) / 256 - 54833)).reverse =
      [213, 212, 211, 210, 209, 208, 207, 206, 205, 204, 203, 202, 201, 200, 199, 198, 197, 196, 195, 194, 193, 192, 191, 190, 189, 188, 187] ++ (List.range 187).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_55021]

theorem next_55021 : next 55021 = some 55229 := by
  have hl : (List.range ((257 * 55021 - 1) / 256 - 55021)).reverse =
      [213, 212, 211, 210, 209, 208, 207] ++ (List.range 207).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_55229]

theorem next_55229 : next 55229 = some 55441 := by
  have hl : (List.range ((257 * 55229 - 1) / 256 - 55229)).reverse =
      [214, 213, 212, 211] ++ (List.range 211).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_55441]

theorem next_55441 : next 55441 = some 55639 := by
  have hl : (List.range ((257 * 55441 - 1) / 256 - 55441)).reverse =
      [215, 214, 213, 212, 211, 210, 209, 208, 207, 206, 205, 204, 203, 202, 201, 200, 199, 198, 197] ++ (List.range 197).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_55639]

theorem next_55639 : next 55639 = some 55849 := by
  have hl : (List.range ((257 * 55639 - 1) / 256 - 55639)).reverse =
      [216, 215, 214, 213, 212, 211, 210, 209] ++ (List.range 209).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_55849]

theorem next_55849 : next 55849 = some 56053 := by
  have hl : (List.range ((257 * 55849 - 1) / 256 - 55849)).reverse =
      [217, 216, 215, 214, 213, 212, 211, 210, 209, 208, 207, 206, 205, 204, 203] ++ (List.range 203).reverse := by
    decide +kernel
  unfold next
  rw [hl]
  apply List.IsPrefix.findSome?_eq_some (List.prefix_append _ _)
  norm_num [List.findSome?_cons, Compact40Pratt.prime_56053]

def primes : List ℕ := [49957, 50147, 50341, 50527, 50723, 50909, 51071, 51263, 51461, 51659, 51859, 52057, 52259, 52457, 52639, 52837, 53017, 53201, 53407, 53611, 53819, 54013, 54217, 54421, 54631, 54833, 55021, 55229, 55441, 55639, 55849, 56053]

theorem segment : run 188 49789 89693 =
    primes ++ run 156 56053 89693 := by
  rw [Compact40PrimeCompose256.step 187 49789 89693 49957
    (by decide +kernel) next_49789]
  rw [Compact40PrimeCompose256.step 186 49957 89693 50147
    (by decide +kernel) next_49957]
  rw [Compact40PrimeCompose256.step 185 50147 89693 50341
    (by decide +kernel) next_50147]
  rw [Compact40PrimeCompose256.step 184 50341 89693 50527
    (by decide +kernel) next_50341]
  rw [Compact40PrimeCompose256.step 183 50527 89693 50723
    (by decide +kernel) next_50527]
  rw [Compact40PrimeCompose256.step 182 50723 89693 50909
    (by decide +kernel) next_50723]
  rw [Compact40PrimeCompose256.step 181 50909 89693 51071
    (by decide +kernel) next_50909]
  rw [Compact40PrimeCompose256.step 180 51071 89693 51263
    (by decide +kernel) next_51071]
  rw [Compact40PrimeCompose256.step 179 51263 89693 51461
    (by decide +kernel) next_51263]
  rw [Compact40PrimeCompose256.step 178 51461 89693 51659
    (by decide +kernel) next_51461]
  rw [Compact40PrimeCompose256.step 177 51659 89693 51859
    (by decide +kernel) next_51659]
  rw [Compact40PrimeCompose256.step 176 51859 89693 52057
    (by decide +kernel) next_51859]
  rw [Compact40PrimeCompose256.step 175 52057 89693 52259
    (by decide +kernel) next_52057]
  rw [Compact40PrimeCompose256.step 174 52259 89693 52457
    (by decide +kernel) next_52259]
  rw [Compact40PrimeCompose256.step 173 52457 89693 52639
    (by decide +kernel) next_52457]
  rw [Compact40PrimeCompose256.step 172 52639 89693 52837
    (by decide +kernel) next_52639]
  rw [Compact40PrimeCompose256.step 171 52837 89693 53017
    (by decide +kernel) next_52837]
  rw [Compact40PrimeCompose256.step 170 53017 89693 53201
    (by decide +kernel) next_53017]
  rw [Compact40PrimeCompose256.step 169 53201 89693 53407
    (by decide +kernel) next_53201]
  rw [Compact40PrimeCompose256.step 168 53407 89693 53611
    (by decide +kernel) next_53407]
  rw [Compact40PrimeCompose256.step 167 53611 89693 53819
    (by decide +kernel) next_53611]
  rw [Compact40PrimeCompose256.step 166 53819 89693 54013
    (by decide +kernel) next_53819]
  rw [Compact40PrimeCompose256.step 165 54013 89693 54217
    (by decide +kernel) next_54013]
  rw [Compact40PrimeCompose256.step 164 54217 89693 54421
    (by decide +kernel) next_54217]
  rw [Compact40PrimeCompose256.step 163 54421 89693 54631
    (by decide +kernel) next_54421]
  rw [Compact40PrimeCompose256.step 162 54631 89693 54833
    (by decide +kernel) next_54631]
  rw [Compact40PrimeCompose256.step 161 54833 89693 55021
    (by decide +kernel) next_54833]
  rw [Compact40PrimeCompose256.step 160 55021 89693 55229
    (by decide +kernel) next_55021]
  rw [Compact40PrimeCompose256.step 159 55229 89693 55441
    (by decide +kernel) next_55229]
  rw [Compact40PrimeCompose256.step 158 55441 89693 55639
    (by decide +kernel) next_55441]
  rw [Compact40PrimeCompose256.step 157 55639 89693 55849
    (by decide +kernel) next_55639]
  rw [Compact40PrimeCompose256.step 156 55849 89693 56053
    (by decide +kernel) next_55849]
  simp only [primes, List.cons_append, List.nil_append]

theorem extend (stop : ℕ) (tail : List ℕ)
    (h : check 56053 stop tail = true) :
    check 49789 stop (primes ++ tail) = true := by
  change check _ _ (49957 :: 50147 :: 50341 :: 50527 :: 50723 :: 50909 :: 51071 :: 51263 :: 51461 :: 51659 :: 51859 :: 52057 :: 52259 :: 52457 :: 52639 :: 52837 :: 53017 :: 53201 :: 53407 :: 53611 :: 53819 :: 54013 :: 54217 :: 54421 :: 54631 :: 54833 :: 55021 :: 55229 :: 55441 :: 55639 :: 55849 :: 56053 :: tail) = true
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_49957, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_50147, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_50341, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_50527, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_50723, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_50909, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_51071, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_51263, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_51461, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_51659, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_51859, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_52057, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_52259, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_52457, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_52639, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_52837, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_53017, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_53201, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_53407, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_53611, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_53819, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_54013, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_54217, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_54421, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_54631, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_54833, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_55021, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_55229, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_55441, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_55639, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_55849, by decide +kernel, by decide +kernel⟩
  apply Compact40PrimeCompose256.check_cons _ _ _ _
    ⟨Compact40Pratt.prime_56053, by decide +kernel, by decide +kernel⟩
  exact h

#print axioms segment
#print axioms extend
end ExposureEvolution.Compact40PrimeLinks016
