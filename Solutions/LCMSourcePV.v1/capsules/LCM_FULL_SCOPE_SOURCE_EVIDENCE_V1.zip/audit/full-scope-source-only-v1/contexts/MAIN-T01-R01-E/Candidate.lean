import Multi
import Interface
namespace Candidate
open Real Finset
open LcmDev

def alpha : ℚ := 3599/40000

lemma numeric {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    (∏ i : Fin 3,
      (1 + ε / ((1.000675 : ℝ) ^ (2 * ((i : ℕ) + 1 : ℝ))) * (1 / (1 + 1/89693)))) *
        (1 + (3 : ℝ) / 8 * ε) * (1 - 362827/1000000*ε) ≥
      1 + 3.004055 * ε - ε ^ 2 := by
  norm_cast; norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg hε.left 3, pow_nonneg hε.left 4]

lemma upper_numeric {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    ∏ i : Fin 3, (1 + (1.000675 : ℝ) ^ ((i : ℕ) + 1 : ℝ) * ε) ≤
      1 + 3.004052 * ε + 3.01 * ε ^ 2 + 1.01 * ε ^ 3 := by
  norm_cast; norm_num [Fin.prod_univ_three]; nlinarith

lemma comparison_numeric {ε : ℝ} (hε : 0 ≤ ε ∧ ε ≤ 1 / (89693 ^ 2 : ℝ)) :
    1 + 3.004052 * ε + 3.01 * ε ^ 2 + 1.01 * ε ^ 3 ≤ 1 + 3.004055 * ε - ε ^ 2 := by
  nlinarith

lemma improved (hd : Dusart2018.v1.proposition_5_4) {n : ℕ} (hn : 89693^2 ≤ n) :
    let c := LcmDev.Criterion.mk' hd hn
    (∏ i, (1 + (1:ℝ) / c.q i)) ≤
      (∏ i, (1 + (1:ℝ) / (c.p i * (c.p i + 1)))) * (1+3/(8*n)) * (1-362827/(1000000*n)) := by
  dsimp only
  change (∏ i, (1 + (1:ℝ) / (exists_q_primes hd hn).choose i)) ≤
    (∏ i, (1 + (1:ℝ) / ((exists_p_primes hd hn).choose i * ((exists_p_primes hd hn).choose i + 1)))) * (1+3/(8*n)) * (1-362827/(1000000*n))
  have hn' : (0:ℝ) ≤ 1/n ∧ (1:ℝ)/n ≤ 1/89693^2 := ⟨by positivity, by
    apply one_div_le_one_div_of_le (by norm_num)
    exact_mod_cast hn⟩
  have hpos : (0:ℝ) ≤ 1-362827/(1000000*n) := by
    have : (89693^2:ℝ) ≤ n := by exact_mod_cast hn
    rw [sub_nonneg, div_le_one₀] <;> nlinarith
  grw [prod_q_ge hd hn, prod_p_ge hd hn]
  simp_rw [div_eq_mul_one_div (_ ^ (_ : ℝ) : ℝ) (n : ℝ),
      show 3 / (8 * n : ℝ) = 3 / 8 * (1 / n) by field_simp, ← one_div_mul_one_div]
  grw [inv_cube_log_sqrt_le hn, inv_n_add_sqrt_ge hn]
  set ε : ℝ := 1/n
  calc
    _ ≤ ∏ i : Fin 3, (1 + (1 + 0.000675 : ℝ) ^ (i + 1 : ℝ) * ε) := by gcongr
    _ = ∏ i : Fin 3, (1 + (1.000675 : ℝ) ^ (i + 1 : ℝ) * ε) := by norm_num [div_eq_mul_inv]
    _ ≤ _ := upper_numeric hn'
    _ ≤ _ := comparison_numeric hn'
    _ ≤ _ := by
      grw [← numeric hn']
      apply le_of_eq
      dsimp [ε]
      simp [field]
      ring_nf

  all_goals first
    | simpa only [one_div_mul_one_div] using hpos
    | positivity [LcmDev.hlog hn]
    | intro i hi; positivity [LcmDev.hlog hn]

lemma ratio_bound (hd : Dusart2018.v1.proposition_5_4) {n : ℕ} (hn : 89693^2 ≤ n) :
    let c := LcmDev.Criterion.mk' hd hn
    ((4 * ∏ i, c.p i : ℕ):ℝ) * (n:ℝ) * √(n:ℝ) ≤ (4032521/1000000) * ((∏ i, c.q i : ℕ):ℝ) := by
  let c := LcmDev.Criterion.mk' hd hn
  have hnpos : (0:ℝ) < n := by exact_mod_cast (lt_of_lt_of_le (by norm_num : 0 < 89693^2) hn)
  have hqpos : (0:ℝ) < ((∏ i, c.q i : ℕ):ℝ) := by
    exact_mod_cast Finset.prod_pos (fun i _ => (c.hq i).pos)
  have h := pq_ratio_ge hd hn
  have he : (1 + 1 / (log √(n:ℝ))^3)^12 ≤ (4032521/4000000:ℝ) := by
    calc
      _ ≤ (1 + 0.000675 : ℝ)^12 := by
        apply pow_le_pow_left₀ (by positivity [LcmDev.hlog hn])
        linarith [inv_cube_log_sqrt_le hn]
      _ ≤ _ := by norm_num
  have hrpow : (n:ℝ)^(3/2:ℝ) = (n:ℝ) * √(n:ℝ) := by
    rw [show (3/2:ℝ) = 1 + 1/2 by norm_num, Real.rpow_add hnpos,
      Real.rpow_one, ← Real.sqrt_eq_rpow]
  have hh : ((4 * ∏ i, c.p i : ℕ):ℝ) / ((∏ i, c.q i : ℕ):ℝ) ≤ (4032521/1000000) / ((n:ℝ)*√(n:ℝ)) := by
    have h' : ((4 * ∏ i, c.p i : ℕ):ℝ) / ((∏ i, c.q i : ℕ):ℝ) ≤
        4*(1+1/(log √(n:ℝ))^3)^12 / ((n:ℝ)*√(n:ℝ)) := by
      dsimp [c, LcmDev.Criterion.mk']
      push_cast
      rw [hrpow] at h
      linarith
    exact h'.trans (div_le_div_of_nonneg_right (by linarith) (by positivity))
  have hh' := (div_le_div_iff₀ hqpos (mul_pos hnpos (Real.sqrt_pos.2 hnpos))).mp hh
  dsimp only
  nlinarith [hh']


theorem result : Exposure01.Goal alpha := by
  intro source n hn
  have hd : Dusart2018.v1.proposition_5_4 := by
    intro x hx
    change ∃ p : ℕ, Nat.Prime p ∧ x < p ∧ (p:ℝ) ≤ x+x/(Real.log x)^(3:ℝ)
    simpa using source x hx
  let c := LcmDev.Criterion.mk' hd hn
  let A : ℕ := 4 * ∏ i, c.p i
  let Q : ℕ := ∏ i, c.q i
  let C : ℕ := Exposure01.Count alpha n
  let d : ℕ := Q / A
  have hA : 0 < A := by dsimp [A]; exact mul_pos (by norm_num) (Finset.prod_pos fun i _ => (c.hp i).pos)
  have hQ : 0 < Q := Finset.prod_pos fun i _ => (c.hq i).pos
  have hn1 : 1 ≤ n := le_trans (by norm_num) hn
  have hnR : (1:ℝ) ≤ n := by exact_mod_cast hn1
  have hnpos : (0:ℝ) < n := by linarith
  have hAR : (0:ℝ) < A := by exact_mod_cast hA
  have hQR : (0:ℝ) < Q := by exact_mod_cast hQ
  have hC : (C:ℝ) ≤ (3599/40000)*√(n:ℝ) := by
    dsimp [C, Exposure01.Count, alpha]
    have h := Nat.floor_le (show (0:ℝ) ≤ ((3599/40000:ℚ):ℝ)*√(n:ℝ) by positivity)
    norm_num at h ⊢
    simpa only [div_eq_mul_inv, mul_comm, one_mul] using h
  have hratio : (A:ℝ)*(n:ℝ)*√(n:ℝ) ≤ (4032521/1000000)*(Q:ℝ) := ratio_bound hd hn
  have hAC : (A:ℝ)*(C:ℝ)*(n:ℝ) < (362827/1000000)*(Q:ℝ) := by
    have h := mul_le_mul_of_nonneg_left hC (show (0:ℝ) ≤ (A:ℝ)*(n:ℝ) by positivity)
    nlinarith
  have hACQ : A*C ≤ Q := by
    have hnon : (0:ℝ) ≤ (A:ℝ)*(C:ℝ) := by positivity
    have : (A:ℝ)*(C:ℝ) < Q := by nlinarith
    exact_mod_cast this.le
  have hCd : C ≤ d := (Nat.le_div_iff_mul_le hA).2 (by simpa [mul_comm] using hACQ)
  have hbase (t : ℕ) (ht : t < C) :
      0 < d-t ∧ A*(d-t) < Q ∧
      (Q:ℝ)*(1-362827/(1000000*(n:ℝ))) < (A:ℝ)*((d-t:ℕ):ℝ) := by
    have htd : t < d := lt_of_lt_of_le ht hCd
    have heq : A*d+Q%A=Q := Nat.div_add_mod Q A
    have hr : 0 < Q%A := by
      exact c.r_ge
    have hrlt : Q%A < A := Nat.mod_lt Q hA
    have hsub : d-t+t=d := Nat.sub_add_cancel htd.le
    have hnat : A*(d-t)+ A*t + Q%A = Q := by nlinarith
    have hrem : A*t+Q%A < A*C := by nlinarith
    have hnatR : (A:ℝ)*((d-t:ℕ):ℝ)+(A:ℝ)*t+((Q%A:ℕ):ℝ)=Q := by exact_mod_cast hnat
    have hremR : (A:ℝ)*t+((Q%A:ℕ):ℝ) < (A:ℝ)*C := by exact_mod_cast hrem
    refine ⟨Nat.sub_pos_of_lt htd, by nlinarith, ?_⟩
    apply (mul_lt_mul_iff_right₀ (show (0:ℝ) < 1000000*(n:ℝ) by positivity)).mp
    have hnz : (1000000*(n:ℝ)) ≠ 0 := by positivity
    field_simp
    nlinarith [mul_lt_mul_of_pos_right hremR hnpos]
  let w : Fin C → Multi.Criterion := fun t => {
    n := n, hn := hn1, p := c.p, hp := c.hp, hp_mono := c.hp_mono,
    q := c.q, hq := c.hq, hq_mono := c.hq_mono,
    h_ord_1 := c.h_ord_1, h_ord_2 := c.h_ord_2, h_ord_3 := c.h_ord_3,
    k := d-t, hk := (hbase t t.isLt).1, loss := 362827/(1000000*n),
    hloss := by rw [div_lt_one₀ (by positivity)]; linarith,
    hsmall := (hbase t t.isLt).2.1,
    hgap := by simpa [A, Q, Nat.cast_mul, Nat.cast_prod] using (hbase t t.isLt).2.2,
    h_crit := improved hd hn }
  let S := Finset.univ.image (fun t : Fin C => (w t).M)
  refine ⟨S, ?_, ?_⟩
  · have hinj : Function.Injective (fun t : Fin C => (w t).M) := by
      intro t u he
      change A*(d-t)*c.L' = A*(d-u)*c.L' at he
      have he' := Nat.eq_of_mul_eq_mul_right c.L'_pos he
      have he'' := Nat.eq_of_mul_eq_mul_left hA he'
      apply Fin.ext
      have ht := lt_of_lt_of_le t.isLt hCd
      have hu := lt_of_lt_of_le u.isLt hCd
      omega
    simp only [S, Finset.card_image_of_injective _ hinj, Finset.card_univ, Fintype.card_fin]
    exact le_rfl
  · intro m hm
    obtain ⟨t, _, rfl⟩ := Finset.mem_image.mp hm
    exact ⟨(w t).M_pos, (w t).M_lt, by exact_mod_cast (w t).not_highlyAbundant⟩

theorem comparison : Exposure01.Comparison alpha := by
  constructor
  · norm_num [alpha]
  · unfold Exposure01.Count
    norm_num [alpha]
end Candidate
