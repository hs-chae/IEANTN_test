import Mathlib
namespace Exposure01

def Source : Prop := ∀ x : ℝ, 89693 ≤ x → ∃ p : ℕ,
  Nat.Prime p ∧ x < p ∧ (p:ℝ) ≤ x+x/(Real.log x)^3

noncomputable def Count (α : ℚ) (n : ℕ) : ℕ := ⌊(α:ℝ)*Real.sqrt (n:ℝ)⌋₊

noncomputable def Goal (α : ℚ) : Prop := Source → ∀ n : ℕ, 89693^2 ≤ n →
  ∃ S : Finset ℕ, Count α n ≤ S.card ∧ ∀ m ∈ S,
    0 < m ∧ m < Nat.lcmUpto n ∧
    (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) < ArithmeticFunction.sigma 1 m

noncomputable def Comparison (α : ℚ) : Prop := 0 < α ∧ 2 ≤ Count α (89693^2)
end Exposure01
