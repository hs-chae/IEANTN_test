import Interface

namespace SubmittedCandidate

def alpha : ℚ := 1 / 40000

theorem comparison : Exposure01.Comparison alpha := by
  constructor
  · norm_num [alpha]
  · unfold Exposure01.Count
    norm_num [alpha, Nat.cast_pow, Real.sqrt_sq]

/-- A divisor-sum scaling inequality, without a coprimality hypothesis. -/
theorem sigma_mul_lower (a b : ℕ) (ha : 0 < a) (hb : 0 < b) :
    a * ArithmeticFunction.sigma 1 b ≤ ArithmeticFunction.sigma 1 (a * b) := by
  classical
  have hinj : Function.Injective (fun x : ℕ => a * x) := by
    intro x y h
    exact Nat.mul_left_cancel ha h
  have hsub : b.divisors.image (fun x => a * x) ⊆ (a * b).divisors := by
    intro x hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    apply Nat.mem_divisors.mpr
    exact ⟨Nat.mul_dvd_mul_left a (Nat.dvd_of_mem_divisors hy),
      ne_of_gt (Nat.mul_pos ha hb)⟩
  rw [ArithmeticFunction.sigma_one_apply, ArithmeticFunction.sigma_one_apply,
    Finset.mul_sum]
  calc
    ∑ x ∈ b.divisors, a * x = ∑ x ∈ b.divisors.image (fun x => a * x), x := by
      rw [Finset.sum_image]
      exact fun x hx y hy h => hinj h
    _ ≤ ∑ x ∈ (a * b).divisors, x := Finset.sum_le_sum_of_subset hsub

/-- A block of multiples yields genuinely distinct witnesses. -/
theorem multiples_witnesses (N d a k : ℕ) (hd : 0 < d) (ha : 0 < a)
    (hsize : d * (a + k) ≤ N)
    (hsigma : ArithmeticFunction.sigma 1 N < a * ArithmeticFunction.sigma 1 d) :
    ∃ S : Finset ℕ, S.card = k ∧ ∀ m ∈ S,
      0 < m ∧ m < N ∧
      (ArithmeticFunction.sigma 1 N : ℝ) < ArithmeticFunction.sigma 1 m := by
  classical
  refine ⟨(Finset.Ico a (a + k)).image (fun t => d * t), ?_, ?_⟩
  · rw [Finset.card_image_of_injective]
    · simp
    · intro x y h
      exact Nat.mul_left_cancel hd h
  · intro m hm
    obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hm
    obtain ⟨hat, htak⟩ := Finset.mem_Ico.mp ht
    have htpos : 0 < t := lt_of_lt_of_le ha hat
    refine ⟨Nat.mul_pos hd htpos, lt_of_lt_of_le (Nat.mul_lt_mul_of_pos_left htak hd) hsize, ?_⟩
    have hs : ArithmeticFunction.sigma 1 N < ArithmeticFunction.sigma 1 (d * t) := by
      calc
        ArithmeticFunction.sigma 1 N < a * ArithmeticFunction.sigma 1 d := hsigma
        _ ≤ t * ArithmeticFunction.sigma 1 d := Nat.mul_le_mul_right _ hat
        _ ≤ ArithmeticFunction.sigma 1 (d * t) := by
          simpa [Nat.mul_comm] using sigma_mul_lower t d htpos hd
    exact_mod_cast hs

/-- The requested count is already at least two over the full target range. -/
theorem count_at_least_two (n : ℕ) (hn : 89693 ^ 2 ≤ n) :
    2 ≤ Exposure01.Count alpha n := by
  apply le_trans comparison.2
  unfold Exposure01.Count
  apply Nat.floor_mono
  apply mul_le_mul_of_nonneg_left
  · apply Real.sqrt_le_sqrt
    exact_mod_cast hn
  · norm_num [alpha]

/-- A sufficient block criterion. This is a reduction, not a proof that the
prime-interval source supplies the required blocks. -/
theorem goal_of_blocks (α : ℚ)
    (hblocks : Exposure01.Source → ∀ n : ℕ, 89693 ^ 2 ≤ n →
      ∃ d a : ℕ, 0 < d ∧ 0 < a ∧
        d * (a + Exposure01.Count α n) ≤ Nat.lcmUpto n ∧
        ArithmeticFunction.sigma 1 (Nat.lcmUpto n) <
          a * ArithmeticFunction.sigma 1 d) :
    Exposure01.Goal α := by
  intro hsource n hn
  obtain ⟨d, a, hd, ha, hsize, hsigma⟩ := hblocks hsource n hn
  obtain ⟨S, hcard, hS⟩ := multiples_witnesses (Nat.lcmUpto n) d a
    (Exposure01.Count α n) hd ha hsize hsigma
  exact ⟨S, hcard.ge, hS⟩

end SubmittedCandidate
