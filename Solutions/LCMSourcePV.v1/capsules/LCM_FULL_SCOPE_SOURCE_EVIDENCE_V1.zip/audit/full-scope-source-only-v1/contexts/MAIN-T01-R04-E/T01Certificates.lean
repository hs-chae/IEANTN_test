import GeneralCount

namespace MultiplicityGeneral
open Finset Nat Real
set_option Elab.async false
set_option maxHeartbeats 5000000

theorem scalar_certificate_899 : ScalarCertificate (899 / 10000 : ℝ) := by
  intro ε hε
  have hsmall : ε ≤ 1 := hε.2.trans (by norm_num)
  have h2 : ε ^ 2 ≤ ε / (89693 ^ 2 : ℝ) := by
    nlinarith [mul_nonneg hε.1 (sub_nonneg.mpr hε.2)]
  have h3 : ε ^ 3 ≤ ε ^ 2 := by
    nlinarith [mul_nonneg (sq_nonneg ε) (sub_nonneg.mpr hsmall)]
  have h4 : ε ^ 4 ≤ ε ^ 3 := by
    nlinarith [mul_nonneg (pow_nonneg hε.1 3) (sub_nonneg.mpr hsmall)]
  have h5 : ε ^ 5 ≤ ε ^ 4 := by
    nlinarith [mul_nonneg (pow_nonneg hε.1 4) (sub_nonneg.mpr hsmall)]
  dsimp only [scalarLeft, scalarPrefactor]
  norm_cast
  norm_num [Fin.prod_univ_three]
  nlinarith [pow_nonneg hε.1 3, pow_nonneg hε.1 4, pow_nonneg hε.1 5]

theorem scalar_certificate_mono {α β : ℝ} (hab : α ≤ β)
    (hb : ScalarCertificate β) : ScalarCertificate α := by
  intro ε hε
  have hε0 : 0 ≤ ε := hε.1
  have hpre : 0 ≤ scalarPrefactor ε := by
    unfold scalarPrefactor
    positivity
  have hfactor : 1 - 4 * (1.000675 : ℝ)^12 * β * ε ≤
      1 - 4 * (1.000675 : ℝ)^12 * α * ε := by
    gcongr
  exact (hb ε hε).trans (mul_le_mul_of_nonneg_left hfactor hpre)

/-- A checked same-method interval, not an optimality assertion. Arbitrary
larger rational coefficients still use count_many with their own closed scalar
certificate, or must be reported as uncompleted when that proof is unavailable. -/
theorem count_for_fixed_coefficient (α : ℝ) (hα : 0 ≤ α)
    (hbound : α ≤ 899 / 10000)
    (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 89693^2 ≤ n) :
    ∃ S : Finset ℕ, ⌊α * Real.sqrt (n : ℝ)⌋₊ ≤ S.card ∧
      ∀ m ∈ S, 0 < m ∧ m < Nat.lcmUpto n ∧
        (ArithmeticFunction.sigma 1 (Nat.lcmUpto n) : ℝ) <
          ArithmeticFunction.sigma 1 m :=
  count_many α hα (scalar_certificate_mono hbound scalar_certificate_899) hd n hn

#print axioms scalar_certificate_899
#print axioms scalar_certificate_mono
#print axioms count_for_fixed_coefficient
end MultiplicityGeneral
