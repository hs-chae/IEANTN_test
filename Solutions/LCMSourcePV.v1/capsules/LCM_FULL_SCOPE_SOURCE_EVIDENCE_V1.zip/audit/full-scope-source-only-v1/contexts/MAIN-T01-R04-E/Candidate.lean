import ChainCore
import T01Certificates
namespace Candidate
open LcmDev Multiplicity Real Finset
set_option Elab.async false
set_option maxHeartbeats 5000000
theorem result : Exposure01.Goal (221/2500) := by
  intro source n hn
  have hd : Dusart2018.v1.proposition_5_4 := by
    intro x hx
    simpa only [IEANTN.HasPrimeInInterval,Real.rpow_ofNat] using source x hx
  let C := Criterion.mk' hd hn
  let K := Exposure01.Count (221/2500) n
  have hK : (K:ℝ) ≤ (221/2500:ℝ)*Real.sqrt n := by
    simpa only [K,Exposure01.Count,Rat.cast_div,Rat.cast_ofNat] using
      Nat.floor_le (by positivity : (0:ℝ) ≤ (221/2500:ℝ)*Real.sqrt n)
  have hcert : MultiplicityGeneral.ScalarCertificate (221/2500:ℝ) :=
    MultiplicityGeneral.scalar_certificate_mono (by norm_num : (221/2500:ℝ) ≤ 899/10000)
      MultiplicityGeneral.scalar_certificate_899
  have hh := FixedChain.count_exact_product_interval C K (by
    intro j hj
    have hj1 : (j+1:ℝ) ≤ (221/2500:ℝ)*Real.sqrt n := by
      have hkj : (j+1:ℝ) ≤ K := by exact_mod_cast (Nat.succ_le_iff.mpr hj)
      exact hkj.trans hK
    exact MultiplicityGeneral.comparison (221/2500) (by norm_num) hcert hd hn hj1)
  simpa only [C,K,Criterion.mk'] using hh
theorem comparison : Exposure01.Comparison (221/2500) := by
  norm_num [Exposure01.Comparison,Exposure01.Count]
end Candidate
