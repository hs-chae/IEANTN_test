import Tail

namespace Multiplicity
open ArithmeticFunction hiding log
open Finset Nat Real LcmDev
set_option maxHeartbeats 3000000

lemma quotient_injective (C : Criterion) (K : ℕ)
    (hpos : ∀ j : ℕ, j < K → 0 < witness C (C.m-j)) :
    Set.InjOn (fun j : ℕ => witness C (C.m-j)) (Finset.range K) := by
  intro a ha b hb hab
  have hwa := hpos a (Finset.mem_range.mp ha)
  have hwb := hpos b (Finset.mem_range.mp hb)
  have hma : 0 < C.m-a := by
    by_contra hh
    have hz : C.m-a=0 := Nat.eq_zero_of_not_pos hh
    simp [witness,hz] at hwa
  have hmb : 0 < C.m-b := by
    by_contra hh
    have hz : C.m-b=0 := Nat.eq_zero_of_not_pos hh
    simp [witness,hz] at hwb
  have hA : 0 < 4*∏ i,C.p i := mul_pos (by norm_num) (Finset.prod_pos fun i _ => (C.hp i).pos)
  have hq : C.m-a=C.m-b :=
    Nat.mul_left_cancel hA (Nat.mul_right_cancel C.L'_pos hab)
  omega

theorem count_many (hd : Dusart2018.v1.proposition_5_4) (n : ℕ) (hn : 89693^2 ≤ n) :
    ∃ S : Finset ℕ, ⌊Real.sqrt (n:ℝ)/100⌋₊ ≤ S.card ∧
      ∀ m ∈ S, 0 < m ∧ m < Nat.lcmUpto n ∧
        (ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) < ArithmeticFunction.sigma 1 m := by
  classical
  let C := LcmDev.Criterion.mk' hd hn
  let K : ℕ := ⌊Real.sqrt (n:ℝ)/100⌋₊
  have hK : (K:ℝ) ≤ Real.sqrt n/100 := Nat.floor_le (by positivity)
  have hJ : ∀ j:ℕ,j<K → (j+1:ℝ) ≤ Real.sqrt n/100 := by
    intro j hj
    have hh : (j+1:ℝ) ≤ (K:ℝ) := by exact_mod_cast (Nat.succ_le_iff.mpr hj)
    exact hh.trans hK
  have hgood : ∀ j:ℕ,j<K → 0<witness C (C.m-j) ∧ witness C (C.m-j)<L n ∧
      (σ (L n):ℝ)<σ (witness C (C.m-j)) := by
    intro j hj
    exact offset_good hd hn (hJ j hj)
  let S : Finset ℕ := (Finset.range K).image (fun j=>witness C (C.m-j))
  refine ⟨S,?_,?_⟩
  · have hc : S.card=K := by
      rw [Finset.card_image_of_injOn (quotient_injective C K (fun j hj=>(hgood j hj).1)),Finset.card_range]
    exact hc.ge
  · intro m hm
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hm
    exact hgood j (Finset.mem_range.mp hj)


end Multiplicity

#print axioms Multiplicity.count_many
