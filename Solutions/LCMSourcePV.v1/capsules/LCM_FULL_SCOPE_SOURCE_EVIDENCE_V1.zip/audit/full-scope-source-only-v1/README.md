# Reproduce the complete qualified LCM scope

The three provider components supply the source-first C proofs. This sidecar preserves the additional mathematical source contexts and the exact original and migrated theorem types. It contains no application objects, binaries, or private-cache dependency.

Use the public generic setup in the Adaptive component to prepare the pinned Lean 4.34.0-rc2/Mathlib environment. The generic metadata has eight entries for Witness, Adaptive, and these mathematical consumers; PrimeCover requires its separate nine-entry metadata. Both metadata files describe the same public installation.

## The 35 extension contexts

Run from a clean directory, substituting absolute paths:

```sh
python3 reproduce.py --environment /absolute/ENV8.json --out /fresh/extension-proofs --jobs 4
```

This compiles all 385 frozen Lean sources, separately for each of the 35 contexts, then checks all 67 qualified roots against the preserved full kernel expression types and the three standard axioms. Each context's application imports are contained in that context. Only public generic libraries are added to LEAN_PATH. The historical lower application cache is unnecessary for this recipe.

For a bounded check, add `--context MAIN-T01-R08-E`; for source/pin validation without compilation, add `--preflight`. Output directories must be fresh and outside this source directory.

The recorded full historical revalidation actually compiled all 35 frozen contexts with an explicitly recorded immutable study cache also present on LEAN_PATH. Its own-module-first ordering and the included dependency map show that all application imports are local to each context. That historical receipt keeps its original qualification. The new generic-only driver was actually exercised for one three-module/two-root context, and all 35 source populations passed preflight in normal, -O, and -OO modes. A second complete 35-context run of the new driver is not claimed.

## The primary 91 mathematical roots

First execute the three component clean-source reproduction procedures. Preserve their output directories, which contain RECEIPT.json and objects/. Then run:

```sh
python3 reproduce_primary.py --environment /absolute/ENV8.json \
  --adaptive /fresh/adaptive-proof --primecover /fresh/primecover-proof \
  --witness /fresh/witness-proof --out /fresh/primary91-proof
```

The driver verifies the three component source-lock identities and every selected source/object association, copies 2,846 required source-built provider objects into a fresh combined directory, compiles the remaining 348 included source modules, and checks the exact 91 frozen kernel types and standard axiom sets. These are outputs of source reproduction, not distributed opaque application caches. The corresponding 3,194-module source association map identifies the component or included source for every application import.

Add `--preflight` to check source and provider-object associations without compiling the remaining sources. The complement driver was preflighted against the actual completed component outputs; its entire new combined 348-module compilation was not rerun for this packaging step. The historical full theorem-closure recompilation and final exact-type/axiom audit are preserved separately.

## Interpretation and preserved evidence

The total is 158 qualified records before deduplication: 91 primary mathematical roots and 67 extension roots. The 67 were already kernel-only; this work does not reclassify them as new source-first discoveries. All mathematical conclusion types and original analytic premises remain fixed. The original 14 native owners have 11 direct source-execution instances; three weaker historical constructions are bypassed by the stronger proved 404-block constructor. Their old execution propositions remain historical, not same-algorithm PV results.

`SOURCE_LOCK.json` identifies all extension sources and expected root types. `PRIMARY_SOURCE_LOCK.json` identifies the primary complement and all provider source associations. Original source preimages, executed historical receipts, strict final component gates, and the central qualified closure gate are preserved by the adjacent R-relative SOURCE_SELECTION.json evidence ledger. No official comparator receipt, global QRH proof, or completion of the unchanged Lcm.v3 upstream source premises is asserted.
