import Candidate
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxHeartbeats 0
run_elab do
 let env ← getEnv
 let roots : List Name := [`Candidate.result,`Candidate.comparison]
 for name in roots do
  let some ci := env.find? name | throwError "missing root {name}"
  let ax ← Lean.collectAxioms name
  unless ax.toList.all [``propext,``Quot.sound,``Classical.choice].contains do throwError "unexpected axioms {ax}"
  logInfo m!"FINAL_CONTEXT {(Json.mkObj [("name",toJson name.toString),("type_repr",toJson (reprStr ci.type)),("axioms",toJson (ax.toList.map Name.toString))]).compress}"
