import ExposureEvolution.HybridRayV3
import Lean.Util.CollectAxioms
open Lean Elab
set_option maxHeartbeats 0
run_elab do
 let env ← getEnv
 let roots : List Name := [`ExposureEvolution.HybridRayV3.whole_ray]
 for name in roots do
  let some ci := env.find? name | throwError "missing root {name}"
  let ax ← Lean.collectAxioms name
  unless ax.toList.all [``propext,``Quot.sound,``Classical.choice].contains do throwError "unexpected axiom {ax}"
  let ty ← Meta.ppExpr ci.type
  logInfo m!"EXTENSION_FINAL {(Json.mkObj [("name",toJson name.toString),("type_repr",toJson (reprStr ci.type)),("type",toJson ty.pretty),("axioms",toJson (ax.toList.map Name.toString))]).compress}"
