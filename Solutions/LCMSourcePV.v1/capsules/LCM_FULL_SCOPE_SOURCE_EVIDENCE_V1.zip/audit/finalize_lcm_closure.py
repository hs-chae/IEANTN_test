#!/usr/bin/env python3
"""Join actual completed mathematical gates; never rewrite historical evidence."""
import hashlib,json,os,tempfile
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,m):
 if not v:raise ValueError(m)
def main():
 specs=[
 ('primary91','audit/final-root-reflection-v1/RECEIPT.json','PASS_ALL91_EXACT_STRUCTURAL_KERNEL_TYPES_PRESERVED_ALL_STD3'),
 ('extension67','audit/extension-matched-rebuild-v1/RECEIPT.json','PASS_ALL35_EXTENSION_CONTEXTS_67_QUALIFIED_ROOTS_FRESH_SOURCE_AND_EXACT_TYPES_STD3'),
 ('adaptive','adaptive/final-audit-controls-v2/normal-positive/RECEIPT.json','FINAL_STRICT_ACCEPTANCE_PASS'),
 ('primecover','primecover/namespace-finalization-v1/FINAL_ACCEPTANCE.json','PASS_FULL158_SIX_C_SIX_LCM_NAMESPACE_WITH_ADDITIVE_STRICT_FINALIZATION'),
 ('primecover_independent','publication/PRIMECOVER_NAMESPACE_FINALIZATION_INDEPENDENT_REVIEW_V1.json','PASS_ADDITIVE_ISOLATED_PROOF_AND_STRICT_READBACK_COMPOSITION'),
 ('witness','witness/final-continuation-namespace-v2/work/continuation/CONTINUATION_ACCEPTANCE.json','PASS_COMPOSED_FRESH_NAMESPACE1164_AND_FIXED_AUDIT_NATIVE404_STRICT'),
 ('witness_independent','publication/WITNESS_CONTINUATION_INDEPENDENT_REVIEW_V1.json','PASS_COMPOSED_ISOLATED_SOURCE_AUDIT_C_AND_STRICT_READBACK'),
 ('witness_three_modes','publication/witness-independent-readback-v1/work/READBACK.json','ALL_THREE_IMMUTABLE_NAMESPACE_READBACKS_IDENTICAL')]
 gates=[];data={}
 for ident,rel,status in specs:
  p=R/rel;d=json.loads(p.read_text());need(d['status']==status,'gate '+ident)
  data[ident]=d;gates.append(dict(id=ident,path=rel,sha256=sha(p),status=status))
 a=data['primary91'];need(a['qualified_roots']==91 and a['original_native_roots']==34 and a['migrated_native_roots']==0,'primary population')
 e=data['extension67'];need(len(e['contexts'])==35 and sum(len(c['roots'])for c in e['contexts'])==67,'extension population')
 for c in e['contexts']:
  for root in c['roots']:need(set(root['axioms'])<={'propext','Quot.sound','Classical.choice'},'extension axiom')
 w=data['witness'];need((w['source_modules'],w['all_compiler_theorems'],w['native_rows'],w['native_words'])==(1164,56282,404,3232),'witness population')
 wi=data['witness_independent'];need(wi['acceptance_receipt_sha256']==gates[5]['sha256'],'independent acceptance join')
 need(data['primecover_independent']['accepted_receipt_sha256']==gates[3]['sha256'],'primecover independent join')
 ad=data['adaptive'];need(ad['source_modules']==1792 and ad['source_first_programs']==4 and ad['closed_final_declarations']==16,'adaptive population')
 scope=R/'audit/final-scope-v1/SCOPE_AND_PROVIDER_LEDGER.json';s=json.loads(scope.read_text())
 need((len(s['roots']),len(s['native_owners']),s['direct_source_execution_instances'],s['weaker_historical_algorithms_bypassed'],s['historical_execution_props_removed_active'])==(91,14,11,3,4),'scope population')
 result=dict(schema='LCM_FINAL_QUALIFIED_CLOSURE_AUDIT_V1',status='PASS_ALL158_QUALIFIED_LCM_ROOTS_EXACT_TYPES_STD3_WITH_SOURCE_FIRST_PROVIDER_CLOSURES',
  main_roots=91,extension_contexts=35,extension_roots=67,prededup_qualified_root_records=158,original_native_primary_roots=34,final_native_primary_roots=0,final_native_extension_roots=0,
  original_native_owners=14,direct_source_execution_instances=11,weaker_historical_algorithms_bypassed=3,historical_execution_propositions_removed_from_active=4,
  mathematical_conclusion_types_preserved=True,source_scope_ledger=dict(path=str(scope.relative_to(R)),sha256=sha(scope)),gates=gates,
  source_execution_instances=dict(prime_cover_constructors=6,adaptive_certificate_checker_instances=4,exact404_constructor=1),
  original_evidence_unchanged=True,old_execution_lemma_APIs_all_preserved=False,official_node_verification_metadata_promoted=False,
  trust_boundary='Kernel checks Std3-only source-subset semantics and source-to-consumer mathematics. Pinned Clang/C23 unsigned _BitInt compilation, runtime/ABI, successful physical CStdIO and hardware remain explicit generic boundaries; no verified machine-code compiler or universal physical-I/O success claim.',
  verification_qualification='PrimeCover actual isolated source/C/strict stages compose with additive filename readback finalization, preserving original outer exit1. Witness original fresh1164 isolated source compilation composes with a hash-verified read-only checkpoint continuation for the corrected-R audit/C404/strict; independent three-mode strict readbacks ran in a second namespace. Extensions were freshly rebuilt in35 exact frozen contexts with an explicitly reused immutable study lower cache; no retrospective whole-closure source-cold label.',
  pending_upstream_scope='Original Lcm.v3 QRH/Density provider statuses and13 analytic source premises remain unchanged. This gate closes requested numerical LCM improvement dependencies, not the unproved global upstream QRH chain.',
  preservation='All original written sources and outcomes remain preserved. Three weaker historical algorithms are explicitly bypassed by the stronger proved404 constructor while their mathematical statement types remain unchanged; their old execution propositions are historical-only, not migrated same-algorithm proofs.',
  finalizer_sha256=sha(Path(__file__)))
 out=R/'audit/FINAL_LCM_CLOSURE_AUDIT.json';need(not out.exists(),'refuse overwrite accepted gate')
 fd,tmp=tempfile.mkstemp(prefix='.closure-',dir=out.parent)
 with os.fdopen(fd,'w')as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 Path(tmp).replace(out);print(result['status'])
if __name__=='__main__':main()
