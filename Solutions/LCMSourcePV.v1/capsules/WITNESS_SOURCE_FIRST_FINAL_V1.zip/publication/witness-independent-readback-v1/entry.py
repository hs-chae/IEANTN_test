from pathlib import Path
import json,hashlib,subprocess,time
R=Path('/review');original=Path('/work/continuation/strict/STRICT_RECEIPT.json').read_bytes();rows=[]
for name,opt in [('normal',[]),('O',['-O']),('OO',['-OO'])]:
 cmd=['/usr/bin/python3.10',*opt,'-I','-B','/original-task/audit_replay.py','--replay','/work/continuation','--out',str(R/name)];t=time.monotonic();q=subprocess.run(cmd,capture_output=True,text=True);(R/(name+'.stdout')).write_text(q.stdout);(R/(name+'.stderr')).write_text(q.stderr)
 if q.returncode:raise RuntimeError('immutable strict readback failed '+name+' '+q.stderr)
 actual=(R/name/'STRICT_RECEIPT.json').read_bytes()
 if actual!=original:raise RuntimeError('strict receipts not byte-identical '+name)
 rows.append({'mode':name,'command':cmd,'exit_code':q.returncode,'seconds':time.monotonic()-t,'receipt_sha256':hashlib.sha256(actual).hexdigest()})
(R/'READBACK.json').write_text(json.dumps({'status':'ALL_THREE_IMMUTABLE_NAMESPACE_READBACKS_IDENTICAL','runs':rows},indent=2)+'\n')
