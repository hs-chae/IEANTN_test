#!/usr/bin/env python3
"""Optimization-mode negative checks; never modifies accepted proof artifacts."""
import pathlib,json,hashlib,subprocess,sys,shutil
R=pathlib.Path(__file__).resolve().parents[1];S=R/'witness/source-only-final-v1';P=R/'witness/full-source-cold-final-v1';O=R/'witness/strict-controls-final-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 O.mkdir(exist_ok=False);original={str(p):sha(p)for p in [P/'RECEIPT.json',P/'THEOREM_AXIOMS.json',P/'actual404.csv',P/'witness_constructor',S/'SOURCE_LOCK.json',S/'reproduce.py',S/'audit_replay.py']};records=[]
 for kind,fragment in [('missing_child','proof child population'),('failed_child','child identity/result'),('wrong_axiom','theorem compiler identity/axiom policy'),('wrong_native','actual404x8 output mismatch')]:
  fake=O/kind;fake.mkdir();r=json.loads((P/'RECEIPT.json').read_text())
  for name in ['objects','logs','WitnessFullAxiomAudit.lean','witness_constructor','native-build.stdout','native-build.stderr','native-run.stderr']:(fake/name).symlink_to(P/name,target_is_directory=(P/name).is_dir())
  if kind=='missing_child':r['records'].pop()
  if kind=='failed_child':r['records'][0]['exit_code']=1
  if kind=='wrong_axiom':
   a=json.loads((P/'THEOREM_AXIOMS.json').read_text());a['rows'][0]['axioms'].append('Lean.ofReduceBool');(fake/'THEOREM_AXIOMS.json').write_text(json.dumps(a));r['all_theorem_audit']['receipt_sha256']=sha(fake/'THEOREM_AXIOMS.json')
  else:(fake/'THEOREM_AXIOMS.json').symlink_to(P/'THEOREM_AXIOMS.json')
  if kind=='wrong_native':
   raw=(P/'actual404.csv').read_bytes();(fake/'actual404.csv').write_bytes(b'0'+raw[1:])
  else:(fake/'actual404.csv').symlink_to(P/'actual404.csv')
  (fake/'RECEIPT.json').write_text(json.dumps(r))
  for flags,mode in [([], 'normal'),(['-O'],'opt'),(['-OO'],'opt2')]:
   out=O/(kind+'-'+mode);cmd=[sys.executable,*flags,str(S/'audit_replay.py'),'--replay',str(fake),'--out',str(out)];q=subprocess.run(cmd,capture_output=True,text=True)
   if q.returncode==0 or fragment not in q.stderr or (out/'STRICT_RECEIPT.json').exists():raise RuntimeError('ineffective intended rejection '+kind+' '+mode)
   records.append(dict(role=kind,mode=mode,command=cmd,exit_code=q.returncode,expected_diagnostic=fragment,stdout=q.stdout,stderr=q.stderr))
 for name,value in original.items():
  if sha(pathlib.Path(name))!=value:raise RuntimeError('accepted source/proof artifact changed')
 result=dict(status='PASS_ALL12_ACTUAL_STRICT_NEGATIVE_CLIS_NORMAL_O_OO',auditor_sha256=sha(S/'audit_replay.py'),original_accepted_artifact_hashes_unchanged=original,negative_population={'missing_active_child':3,'failed_active_child':3,'nonstandard_axiom':3,'wrong_actual_native_word':3},records=records)
 (O/'RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'])
if __name__=='__main__':main()
