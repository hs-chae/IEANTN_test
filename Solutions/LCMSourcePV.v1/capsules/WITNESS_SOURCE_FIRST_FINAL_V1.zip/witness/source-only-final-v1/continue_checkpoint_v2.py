#!/usr/bin/env python3
"""Finish the verified same-campaign namespace cold checkpoint, without recompiling it."""
import argparse,hashlib,json,os,pathlib,re,subprocess,tempfile,time,datetime
PACKAGE=pathlib.Path(__file__).resolve().parent
S=PACKAGE
ALLOW={'propext','Classical.choice','Quot.sound'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate JSON key '+k)
  d[k]=v
 return d
def load(p):return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in()).throw(ValueError(v)))
def atomic(p,data):
 fd,tmp=tempfile.mkstemp(prefix='.receipt-',dir=p.parent)
 with os.fdopen(fd,'w')as f:json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 pathlib.Path(tmp).replace(p)
def safe(rel):
 p=pathlib.PurePosixPath(rel)
 if p.is_absolute()or '..'in p.parts:raise ValueError('unsafe source path')
 q=S/p
 if not q.resolve().is_relative_to(S):raise ValueError('source path escapes')
 return q

def main():
 global S
 ap=argparse.ArgumentParser();ap.add_argument('--checkpoint',type=pathlib.Path,required=True);ap.add_argument('--out',type=pathlib.Path,required=True);ap.add_argument('--environment',type=pathlib.Path,required=True);ap.add_argument('--origin',type=pathlib.Path,required=True);ap.add_argument('--origin-scope',type=pathlib.Path,required=True);ap.add_argument('--original-capsule',type=pathlib.Path,required=True);a=ap.parse_args()
 started=time.monotonic();checkpoint=a.checkpoint.resolve();out=a.out.resolve();origin=a.origin.resolve();S=a.original_capsule.resolve();out.mkdir(parents=True,exist_ok=False)
 pins=load(PACKAGE/'CONTINUATION_ORIGIN.lock.json')
 checks=[(S/'SOURCE_LOCK.json','source_lock_sha256'),(S/'reproduce.py','old_producer_sha256'),(S/'audit_replay.py','old_auditor_sha256'),(S/'ALL_THEOREM_AUDIT.lean.in','axiom_template_sha256'),(PACKAGE/'reproduce_v2.py','clean_recipe_v2_sha256'),(origin/'SPEC.json','origin_spec_sha256'),(origin/'NAMESPACE_RUN.json','origin_outer_sha256'),(a.origin_scope,'origin_scope_sha256'),(checkpoint/'PROGRESS.json','checkpoint_progress_sha256'),(checkpoint/'logs/AXIOM_AUDIT.stdout','old_failed_audit_stdout_sha256'),(checkpoint/'logs/AXIOM_AUDIT.stderr','old_failed_audit_stderr_sha256')]
 for path,key in checks:
  if sha(path)!=pins[key]:raise ValueError('original-stage evidence drift '+key)
 if sha(PACKAGE/'SOURCE_LOCK.json')!=pins['source_lock_sha256']:raise ValueError('new recipe changed source/data lock')
 outer=load(origin/'NAMESPACE_RUN.json');spec=load(origin/'SPEC.json');origin_scope=load(a.origin_scope)
 if outer['exit_code']!=1 or outer['status']!='FAILED_NAMESPACE_PIPELINE'or not outer['source_lock_unchanged']or outer['source_lock_sha256']!=pins['source_lock_sha256']:raise ValueError('original namespace result')
 if spec['network']!='offline'or spec['cwd']!='/task'or spec['command']!=['/usr/bin/python3.10','-I','-B','/entry.py','16','witness']:raise ValueError('original source-only namespace spec')
 if "must be contained in root directory (/task/)"not in((checkpoint/'logs/AXIOM_AUDIT.stdout').read_text()+(checkpoint/'logs/AXIOM_AUDIT.stderr').read_text())or 'full compiler-identity theorem axiom gate rejected'not in(origin/'stderr.txt').read_text():raise ValueError('not the known post-source audit-root failure')
 lock=load(S/'SOURCE_LOCK.json');modules={x['module']:x for x in lock['modules']};progress=load(checkpoint/'PROGRESS.json');records=progress['records']
 if len(modules)!=1164 or progress['completed']!=1164 or progress['total']!=1164 or len(records)!=1164:raise ValueError('incomplete original cold stage')
 e=load(a.environment);compiler=pathlib.Path(e['compiler']);cc=pathlib.Path(e['clang']);seen=set()
 for row in records:
  m=row['module']
  if m not in modules or m in seen or row['exit_code']!=0 or row['source_sha256']!=modules[m]['sha256']:raise ValueError('checkpoint child identity/result')
  seen.add(m);src=safe(modules[m]['path']);obj=checkpoint/'objects'/pathlib.Path(m.replace('.','/')).with_suffix('.olean');so=checkpoint/'logs'/(m+'.stdout');se=checkpoint/'logs'/(m+'.stderr')
  if sha(src)!=row['source_sha256']or sha(obj)!=row['object_sha256']or sha(so)!=row['stdout_sha256']or sha(se)!=row['stderr_sha256']:raise ValueError('checkpoint source/object/log hash '+m)
  text=so.read_text()+'\n'+se.read_text()
  if 'sorryAx'in text or 'Lean.ofReduceBool'in text:raise ValueError('prohibited checkpoint proof '+m)
 if seen!=set(modules):raise ValueError('checkpoint missing module')
 def validate_sources():
  for row in lock['files']:
   p=safe(row['path'])
   if not p.is_file()or p.stat().st_size!=row['bytes']or sha(p)!=row['sha256']:raise ValueError('source/asset drift '+row['path'])
 validate_sources()
 validation=out/'original-source-validation';q=subprocess.run(['/usr/bin/python3.10','-I','-B',str(S/'reproduce.py'),'--validate-only','--environment',str(a.environment),'--jobs','16','--out',str(validation)],capture_output=True,text=True);(out/'source-validation.stdout').write_text(q.stdout+q.stderr)
 if q.returncode or not(validation/'VALIDATION_PASS.json').is_file():raise ValueError('original source/generic/compiler validation failed')
 generic=[pathlib.Path(x['library'])for x in e['generic_dependencies']]+[compiler.resolve().parent.parent/'lib/lean'];rows=load(S/'inputs/witness/evidence/constructor_output_v1.json')
 objects=out/'objects';objects.symlink_to(checkpoint/'objects',target_is_directory=True);logs=out/'logs';logs.mkdir();audit_objects=out/'audit-objects';audit_objects.mkdir();tmp=out/'tmp';tmp.mkdir()
 for row in records:
  for suffix in ['.stdout','.stderr']:(logs/(row['module']+suffix)).symlink_to(checkpoint/'logs'/(row['module']+suffix))
 env=dict(os.environ);env['LEAN_PATH']=':'.join(map(str,[audit_objects,checkpoint/'objects',*generic]));env['TMPDIR']=str(tmp);env.pop('LEAN_SRC_PATH',None)
 metadata=dict(source_lock_sha256=pins['source_lock_sha256'],reproducer_sha256=pins['old_producer_sha256'],axiom_template_sha256=pins['axiom_template_sha256'],environment_sha256=sha(a.environment),application_cache_input=False,public_generic_pins={x['name']:x['revision']for x in lock['generic_dependencies']})
 checkpoint_summary=dict(kind='OWN_FRESH_NAMESPACE_SOURCE_STAGE_OUTPUTS_REUSED_READ_ONLY',source_modules=1164,progress_sha256=pins['checkpoint_progress_sha256'],origin_namespace_outer_sha256=pins['origin_outer_sha256'],origin_scope_sha256=pins['origin_scope_sha256'],old_source_stage_producer_sha256=pins['old_producer_sha256'],continuation_validator_sha256=sha(pathlib.Path(__file__)),fixed_clean_recipe_v2_sha256=pins['clean_recipe_v2_sha256'],original_objects_initially_empty='Derived from exact original producer out.mkdir(exist_ok=False) and objects.mkdir, fresh namespace work specification, and complete checked child records; no second fresh compilation is claimed.',continuation_imports_own_checkpoint_objects=True,preexisting_foreign_application_cache_input=False,old_audit_root_failure_preserved=True)
 atomic(out/'CHECKPOINT_VALIDATION.json',dict(status='PASS_ALL1164_SOURCE_OBJECT_LOG_HASHES_AND_FROZEN_ORIGIN_PINS',**checkpoint_summary))
 audit_source=(S/'ALL_THEOREM_AUDIT.lean.in').read_text().replace('@IMPORTS@','\n'.join('import '+x for x in lock['targets'])).replace('@MODULES@',json.dumps(sorted(modules))).replace('@OUTPUT@',json.dumps(str(out/'THEOREM_AXIOMS.json')))
 audit=out/'WitnessFullAxiomAudit.lean';audit.write_text(audit_source);audit_cmd=['/usr/bin/time','-v',str(compiler),'-j1','-R',str(out),str(audit),'-o',str(audit_objects/'WitnessFullAxiomAudit.olean')];t=time.monotonic();q=subprocess.run(audit_cmd,env=env,capture_output=True,text=True)
 (logs/'AXIOM_AUDIT.stdout').write_text(q.stdout);(logs/'AXIOM_AUDIT.stderr').write_text(q.stderr)
 if q.returncode or 'sorryAx'in q.stdout+q.stderr or not(out/'THEOREM_AXIOMS.json').is_file():raise RuntimeError('full compiler-identity theorem axiom gate rejected')
 theorem_audit=load(out/'THEOREM_AXIOMS.json')
 if theorem_audit['status']!='ALL_APPLICATION_THEOREMS_STD3_PASS'or theorem_audit['modules']!=sorted(modules)or not theorem_audit['rows']:raise ValueError('axiom gate population')
 if any(set(r['axioms'])-ALLOW for r in theorem_audit['rows']):raise ValueError('nonstandard axiom')
 audit_record=dict(command=audit_cmd,exit_code=q.returncode,seconds=time.monotonic()-t,generated_source_sha256=sha(audit),receipt_sha256=sha(out/'THEOREM_AXIOMS.json'))
 src=S/'inputs/witness/source/witness_verified_unit.c';binary=out/'witness_constructor';stream=out/'actual404.csv';native=[]
 for label,cmd,stdout in [('build',[str(cc),'-std=c2x','-O2','-isystem','/usr/lib/gcc/x86_64-linux-gnu/11/include',str(src),'-o',str(binary)],out/'native-build.stdout'),('run',[str(binary)],stream)]:
  t=time.monotonic();err=out/('native-'+label+'.stderr')
  with stdout.open('wb')as so,err.open('wb')as se:q=subprocess.run(['/usr/bin/time','-v',*cmd],stdout=so,stderr=se,env=env)
  native.append(dict(role=label,command=cmd,exit_code=q.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(stdout),stderr_sha256=sha(err)))
  if q.returncode:raise RuntimeError('actual C '+label+' failed')
 expected=(''.join(','.join(map(str,r))+'\n'for r in rows)).encode()
 if stream.read_bytes()!=expected:raise RuntimeError('actual C stdout differs from all kernel-bound404x8 source output words')
 validate_sources()
 if sha(S/'SOURCE_LOCK.json')!=metadata['source_lock_sha256']or sha(S/'reproduce.py')!=metadata['reproducer_sha256']or sha(S/'ALL_THEOREM_AUDIT.lean.in')!=metadata['axiom_template_sha256']:raise RuntimeError('source/tool drift during replay')
 receipt=dict(status='FULL_SOURCE_COLD_AND_NATIVE404_PASS',seconds=outer['seconds']+time.monotonic()-started,source_modules=len(modules),objects_initially_empty=True,targets=lock['targets'],records=records,all_theorem_audit=audit_record,all_theorem_count=len(theorem_audit['rows']),native=native,native_binary_sha256=sha(binary),native_output_sha256=sha(stream),native_rows=404,native_words=3232,physical_boundary='Pinned C23 compiler/core and uint64/uint256/CStdIO contracts. Actual compiled-process stdout bytes associated by full-word readback; no kernel claim that the OS must always make I/O succeed.',**metadata)

 receipt['stage_composition']=checkpoint_summary
 receipt['continuation_seconds']=time.monotonic()-started
 receipt['origin_namespace_seconds']=outer['seconds']
 receipt['seconds_qualification']='Sum of disjoint original namespace source-stage runtime and this continuation runtime; includes no claim of continuous wall time or a second fresh source compilation.'
 atomic(out/'RECEIPT.json',receipt)
 strict_out=out/'strict';cmd=['/usr/bin/python3.10','-I','-B',str(S/'audit_replay.py'),'--replay',str(out),'--out',str(strict_out)];q=subprocess.run(cmd,env=env,capture_output=True,text=True);(out/'strict.stdout').write_text(q.stdout+q.stderr)
 if q.returncode or not(strict_out/'STRICT_RECEIPT.json').is_file():raise RuntimeError('exact original strict audit rejected')
 for path,key in checks:
  if sha(path)!=pins[key]:raise ValueError('origin changed during continuation '+key)
 acceptance=dict(status='PASS_COMPOSED_FRESH_NAMESPACE1164_AND_FIXED_AUDIT_NATIVE404_STRICT',source_lock_sha256=pins['source_lock_sha256'],source_modules=1164,all_compiler_theorems=receipt['all_theorem_count'],native_rows=404,native_words=3232,producer_receipt_sha256=sha(out/'RECEIPT.json'),strict_receipt_sha256=sha(strict_out/'STRICT_RECEIPT.json'),checkpoint_validation_sha256=sha(out/'CHECKPOINT_VALIDATION.json'),continuation_seconds=time.monotonic()-started,origin_namespace_seconds=outer['seconds'],stage_composition=checkpoint_summary,qualification='The original actual namespace cold run freshly compiled all1164 sources, then failed only generated-auditor root-directory applicability. Its source objects/logs are hash-verified and reused read-only. This actual namespace continuation performs the corrected-R all-theorem audit, C404 runtime and exact original strict auditor. No original source/C/data/criterion or failed evidence is changed; no second fresh1164 compile is claimed.')
 atomic(out/'CONTINUATION_ACCEPTANCE.json',acceptance);print(json.dumps({k:acceptance[k]for k in ['status','all_compiler_theorems','native_words','continuation_seconds']}))
if __name__=='__main__':main()
