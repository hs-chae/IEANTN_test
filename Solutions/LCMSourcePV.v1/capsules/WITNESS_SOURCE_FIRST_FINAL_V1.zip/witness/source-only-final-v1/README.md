# Source-first 404-block LCM constructor

This capsule contains the complete application-source closure of the actual C23 constructor, its typed C AST execution proofs, the initialized main program and printed rows, all four restored mathematical APIs and Frontier, and the unchanged existing Lcm.v1 conditional node consumer. The quantitative ray begins at 81000 and retains the original Dusart 2018 Proposition 5.4 input for the analytic tail. No compiler/runtime or numerical-execution axiom is added to Lean.

Prepare the public Lean 4.34.0-rc2 compiler and the eight pinned generic dependencies once using the release's shared `prepare_environment.py`. Its `ENVIRONMENT.json` is the only object-environment input; no application cache is accepted. The included ENVIRONMENT.json records the original local prepared paths. Use the explicit override below when relocating the capsule.

From this directory, with fresh output paths outside the capsule:

```sh
python3 reproduce.py --environment /absolute/prepared/ENVIRONMENT.json --out /fresh/witness-proof --jobs 16
python3 audit_replay.py --replay /fresh/witness-proof --out /fresh/witness-strict
```

The authoritative cold run used 256 GiB, 24 CPUs, 16 single-threaded Lean children, and a 7200-second scope. Select a job count appropriate to the host; supported values are 1 through 32. The proof workload and claims are identical. The replay creates fresh application objects and temporary files, compiles every locked application module, audits every theorem by compiler identity with only propext/Classical.choice/Quot.sound, then rebuilds and runs the actual standalone C program. It compares all 404 rows and 3232 decimal words against a fixture that is kernel-proved equal to the source-main output. A successful first command writes RECEIPT.json. The strict second command independently reads every source, object, child log, axiom result and native output, then writes STRICT_RECEIPT.json.

The actual C source has no prime or output table: it performs bounded ascending/descending prime searches, trial division, q0/q1 backtracking, exact unsigned-256-bit endpoint arithmetic and interval shrinking. The preserved proof-side Pratt facts and trace certificates accelerate ordinary kernel proofs; they are not inputs to the C constructor. Exact parameters are primeFuel=1000, fitFuel=30, q0Fuel=32, q1Fuel=16, blockFuel=1024, start=81000 and stop=10712529. SOURCE_LOCK.json records every selected source, its original path and byte hash, the explicit source-root priority, compiler hashes and generic dependency commits. No application objects are included.

The mathematical provider decodes the actual modeled main stdout and consumes that output in the existing finite criterion. Every successful modular source call is implemented by its actual AST body under strictly decreasing call ranks, producing a closed finite call tree. Application parameter conversion, initialization, buffer ownership, intermediate writes, loop control, scope restoration and printing applicability are proved. Unsupported proof-side summary queries are absent; they are not asserted to be C false returns. The failed choose_q0 branch explicitly proves its output pointer has Block type before C parameter binding.

Physical trust is the pinned C23 compiler/core, uint64/uint256 representation and standard CStdIO contracts. The replay associates the measured compiled process with the source by exact output bytes. The Lean theorem does not claim that an operating system must always make I/O succeed. The separate six-provider PrimeCover capsule supplies the independently replayed prime-cover C mains; their full Lean tail-provider closure is rebuilt here as part of the whole-ray consumer.
