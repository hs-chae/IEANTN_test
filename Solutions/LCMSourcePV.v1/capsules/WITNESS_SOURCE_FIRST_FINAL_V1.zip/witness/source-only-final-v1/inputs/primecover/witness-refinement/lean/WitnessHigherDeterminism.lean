import WitnessSummaryDeterminism

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.C
open LCMSourcePV.PrimeCover E1TwoTracks.TrackB

theorem choose0_result_unique {pf fit total lo stop p0 p1 p2 q1 q2 k top : Nat}
    {left right : Option Block}
    (hl : Choose0For pf fit total lo stop p0 p1 p2 q1 q2 k top left)
    (hr : Choose0For pf fit total lo stop p0 p1 p2 q1 q2 k top right) : left=right := by
  induction hl generalizing right with
  | done k top guard => cases hr <;> simp_all
  | hit k top q0 out guard prime test shrink =>
    cases hr with
    | done _ _ other => exact False.elim (other guard)
    | hit _ _ q0' out' _ prime' test' shrink' =>
      have he : q0=q0' := Option.some.inj (prev_result_unique prime prime')
      subst q0'
      exact congrArg some (shrink_result_unique shrink shrink')
    | skip _ _ q0' _ _ prime' test' _ _ =>
      have he : q0=q0' := Option.some.inj (prev_result_unique prime prime')
      subst q0'
      rw [test] at test'
      cases test'
  | skip k top q0 out guard prime test hk rest ih =>
    cases hr with
    | done _ _ other => exact False.elim (other guard)
    | hit _ _ q0' _ _ prime' test' _ =>
      have he : q0=q0' := Option.some.inj (prev_result_unique prime prime')
      subst q0'
      rw [test] at test'
      cases test'
    | skip _ _ q0' _ _ prime' _ _ rest' =>
      have he : q0=q0' := Option.some.inj (prev_result_unique prime prime')
      subst q0'
      exact ih rest'

theorem choose1_result_unique {pf fit q0Fuel total lo stop p0 p1 p2 q2 k top : Nat}
    {left right : Option Block}
    (hl : Choose1For pf fit q0Fuel total lo stop p0 p1 p2 q2 k top left)
    (hr : Choose1For pf fit q0Fuel total lo stop p0 p1 p2 q2 k top right) : left=right := by
  induction hl generalizing right with
  | hit k top q1 out guard prime choose =>
    cases hr with
    | hit _ _ q1' _ _ prime' choose' =>
      have he : q1=q1' := Option.some.inj (prev_result_unique prime prime')
      subst q1'
      exact choose0_result_unique choose choose'
    | skip _ _ q1' _ _ prime' choose' _ _ =>
      have he : q1=q1' := Option.some.inj (prev_result_unique prime prime')
      subst q1'
      have he := choose0_result_unique choose choose'
      cases he
  | skip k top q1 out guard prime choose hk rest ih =>
    cases hr with
    | hit _ _ q1' _ _ prime' choose' =>
      have he : q1=q1' := Option.some.inj (prev_result_unique prime prime')
      subst q1'
      have he := choose0_result_unique choose choose'
      cases he
    | skip _ _ q1' _ _ prime' _ _ rest' =>
      have he : q1=q1' := Option.some.inj (prev_result_unique prime prime')
      subst q1'
      exact ih rest'

theorem make_result_unique {pf fit q0Fuel q1Fuel lo stop : Nat} {left right : Block}
    (hl : MakeExec pf fit q0Fuel q1Fuel lo stop left)
    (hr : MakeExec pf fit q0Fuel q1Fuel lo stop right) : left=right := by
  cases hl with
  | success p0 p1 p2 q2 root out sqrt n0 n1 n2 prev choose =>
    cases hr with
    | success p0' p1' p2' q2' root' out' sqrt' n0' n1' n2' prev' choose' =>
      have hroot : root=root' := (sqrt_exec_sound sqrt).trans (sqrt_exec_sound sqrt').symm
      subst root'
      have he : p0=p0' := Option.some.inj (next_result_unique n0 n0')
      subst p0'
      have he : p1=p1' := Option.some.inj (next_result_unique n1 n1')
      subst p1'
      have he : p2=p2' := Option.some.inj (next_result_unique n2 n2')
      subst p2'
      have he : q2=q2' := Option.some.inj (prev_result_unique prev prev')
      subst q2'
      exact Option.some.inj (choose1_result_unique choose choose')

#print axioms choose0_result_unique
#print axioms choose1_result_unique
#print axioms make_result_unique
end LCMSourcePV.Witness.C
