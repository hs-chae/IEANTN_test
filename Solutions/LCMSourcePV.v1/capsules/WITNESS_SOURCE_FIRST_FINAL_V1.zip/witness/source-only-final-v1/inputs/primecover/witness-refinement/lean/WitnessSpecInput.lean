import WitnessASTTypedContracts
import WitnessASTMakeRunContract
import WitnessASTCallTree

namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C E1TwoTracks.TrackB LCMSourcePV.PrimeCover

/-- Decoded actual source call arguments. Widths, writable pointers and the
run_exact literal-expression ABI are retained; this is proof infrastructure,
not executable C input data or a numerical output table. -/
inductive SpecInput where
 | prime (n : Nat)
 | sqrt (n : Nat)
 | next (fuel a : Nat) (out : Address)
 | prev (fuel a : Nat) (out : Address)
 | productP (target : Address) (writable : Bool)
 | productQ (target : Address) (writable : Bool)
 | endpoint (target : Address) (writable : Bool) (n : Nat)
 | check (target : Address) (writable : Bool)
 | shrink (fuel : Nat) (b : Block) (out : Address)
 | choose0 (pf fit total lo stop p0 p1 p2 q1 q2 top : Nat) (out : Address)
 | choose1 (pf fit q0Fuel total lo stop p0 p1 p2 q2 top : Nat) (out : Address)
 | make (pf fit q0Fuel q1Fuel lo stop : Nat) (out : Address)
 | makeRun (lo : Nat) (out : Address)

def decodeSpec : String → List Value → Option SpecInput
 | "pc_is_prime",[.word 64 n]=>some (.prime n)
 | "integer_sqrt",[.word 64 n]=>some (.sqrt n)
 | "next_prime",[.word 64 fuel,.word 64 a,.pointer out true]=>some (.next fuel a out)
 | "prev_prime",[.word 64 fuel,.word 64 a,.pointer out true]=>some (.prev fuel a out)
 | "product_p",[.pointer target writable]=>some (.productP target writable)
 | "product_q",[.pointer target writable]=>some (.productQ target writable)
 | "exact_endpoint",[.pointer target writable,.word 64 n]=>some (.endpoint target writable n)
 | "exact_check",[.pointer target writable]=>some (.check target writable)
 | "shrink_exact",[.word 64 fuel,.block b,.pointer out true]=>some (.shrink fuel b out)
 | "choose_q0",[.word 64 pf,.word 64 fit,.word 64 total,.word 64 lo,.word 64 stop,
    .word 64 p0,.word 64 p1,.word 64 p2,.word 64 q1,.word 64 q2,.word 64 top,.pointer out true]=>
      some (.choose0 pf fit total lo stop p0 p1 p2 q1 q2 top out)
 | "choose_q1",[.word 64 pf,.word 64 fit,.word 64 q0Fuel,.word 64 total,.word 64 lo,.word 64 stop,
    .word 64 p0,.word 64 p1,.word 64 p2,.word 64 q2,.word 64 top,.pointer out true]=>
      some (.choose1 pf fit q0Fuel total lo stop p0 p1 p2 q2 top out)
 | "make_exact",[.word 64 pf,.word 64 fit,.word 64 q0Fuel,.word 64 q1Fuel,.word 64 lo,
    .word 64 stop,.pointer out true]=>some (.make pf fit q0Fuel q1Fuel lo stop out)
 | "make_exact",[.word 32 1000,.word 32 30,.word 32 32,.word 32 16,.word 64 lo,
    .word 32 10712529,.pointer out true]=>some (.makeRun lo out)
 | _,_=>none

def SpecInput.Run : SpecInput → State → (Value × State) → Prop
 | .prime n,s,result=>∃r,PrimeExec n r ∧ result=(word 64 r,s)
 | .sqrt n,s,result=>∃r,SqrtExec n r ∧ result=(word 64 r,s)
 | .next total a out,s,result=>total<2^64 ∧ a<2^64 ∧
      ∃p t,NextFor total 0 a (some p) ∧ WriteNat s out p t ∧ result=(bword true,t)
 | .prev total a out,s,result=>total<2^64 ∧ a<2^64 ∧
      ∃p t,PrevFor total 0 a (some p) ∧ WriteNat s out p t ∧ result=(bword true,t)
 | .productP target _,s,result=>∃b,BlockInput s target b ∧ result=(word 256 (C.productP b),s)
 | .productQ target _,s,result=>∃b,BlockInput s target b ∧ result=(word 256 (C.productQ b),s)
 | .endpoint target _ n,s,result=>n<2^64 ∧ ∃b r,BlockInput s target b ∧ C.endpoint b n=some r ∧ result=(bword r,s)
 | .check target _,s,result=>∃b r,BlockInput s target b ∧ CheckExec b r ∧ result=(bword r,s)
 | .shrink fuel b out,s,result=>fuel<2^64 ∧ BlockRep b ∧
      ∃target t,ShrinkFor fuel 0 b target ∧ WriteBlock s out target t ∧ result=(bword true,t)
 | .choose0 pf fit total lo stop p0 p1 p2 q1 q2 top out,s,result=>
      (∀n∈[pf,fit,total,lo,stop,p0,p1,p2,q1,q2,top],n<2^64) ∧ addressType s out=some "Block" ∧
      ∃target t,Choose0For pf fit total lo stop p0 p1 p2 q1 q2 0 top target ∧
        (match target with | none=>t=s | some b=>WriteBlock s out b t) ∧ result=(bword target.isSome,t)
 | .choose1 pf fit q0Fuel total lo stop p0 p1 p2 q2 top out,s,result=>
      (∀n∈[pf,fit,q0Fuel,total,lo,stop,p0,p1,p2,q2,top],n<2^64) ∧
      ∃target t,Choose1For pf fit q0Fuel total lo stop p0 p1 p2 q2 0 top target ∧
        (match target with | none=>t=s | some b=>WriteBlock s out b t) ∧ result=(bword target.isSome,t)
 | .make pf fit q0Fuel q1Fuel lo stop out,s,result=>
      (∀n∈[pf,fit,q0Fuel,q1Fuel,lo,stop],n<2^64) ∧
      ∃target t,MakeExec pf fit q0Fuel q1Fuel lo stop target ∧ WriteBlock s out target t ∧ result=(bword true,t)
 | .makeRun lo out,s,result=>lo<2^64 ∧
      ∃target t,MakeExec 1000 30 32 16 lo 10712529 target ∧ WriteBlock s out target t ∧ result=(bword true,t)

def SpecInput.name : SpecInput → String
 | .prime _=>"pc_is_prime" | .sqrt _=>"integer_sqrt"
 | .next ..=>"next_prime" | .prev ..=>"prev_prime"
 | .productP ..=>"product_p" | .productQ ..=>"product_q"
 | .endpoint ..=>"exact_endpoint" | .check ..=>"exact_check"
 | .shrink ..=>"shrink_exact" | .choose0 ..=>"choose_q0" | .choose1 ..=>"choose_q1"
 | .make ..=>"make_exact" | .makeRun ..=>"make_exact"

def SpecInput.args : SpecInput → List Value
 | .prime n=>[word 64 n]
 | .sqrt n=>[word 64 n]
 | .next fuel a out=>[word 64 fuel,word 64 a,.pointer out true]
 | .prev fuel a out=>[word 64 fuel,word 64 a,.pointer out true]
 | .productP target writable=>[.pointer target writable]
 | .productQ target writable=>[.pointer target writable]
 | .endpoint target writable n=>[.pointer target writable,word 64 n]
 | .check target writable=>[.pointer target writable]
 | .shrink fuel b out=>[word 64 fuel,.block b,.pointer out true]
 | .choose0 pf fit total lo stop p0 p1 p2 q1 q2 top out=>
   [word 64 pf,word 64 fit,word 64 total,word 64 lo,word 64 stop,word 64 p0,word 64 p1,
    word 64 p2,word 64 q1,word 64 q2,word 64 top,.pointer out true]
 | .choose1 pf fit q0Fuel total lo stop p0 p1 p2 q2 top out=>
   [word 64 pf,word 64 fit,word 64 q0Fuel,word 64 total,word 64 lo,word 64 stop,word 64 p0,
    word 64 p1,word 64 p2,word 64 q2,word 64 top,.pointer out true]
 | .make pf fit q0Fuel q1Fuel lo stop out=>
   [word 64 pf,word 64 fit,word 64 q0Fuel,word 64 q1Fuel,word 64 lo,word 64 stop,.pointer out true]
 | .makeRun lo out=>[word 32 1000,word 32 30,word 32 32,word 32 16,word 64 lo,
   word 32 10712529,.pointer out true]

def SpecSummary (name : String) (args : List Value) (s : State) (result : Value × State) : Prop :=
  ∃input : SpecInput,name=input.name ∧ args=input.args ∧ input.Run s result
end LCMSourcePV.Witness.AST
