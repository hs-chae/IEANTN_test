import WitnessASTSearchSteps
import WitnessASTSearchScope

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.PrimeCover

def searchHit : Stmt := .sequence [.eval searchWrite,.returnStmt (.var "true")]
def searchBranch : Stmt := .branch searchPrime searchHit .skip
def nextSearchBody : Stmt := .sequence [searchBranch]
def prevSearchBody : Stmt := .sequence [searchBranch,
  .branch (.binary "==" (.var "a") (.nat 0)) (.returnStmt (.var "false")) .skip,
  .eval searchADown]

theorem search_hit {caller after : State} {p : Nat} {out : Address}
    (effect : WriteNat caller out p after) (call : Call) (total k : Nat) :
    Run call searchHit (searchFrame caller total p out k)
      (.returned (searchFrame after total p out k) (bword true)) := by
  have ret : Eval call (.var "true") (searchFrame after total p out k)
      (searchFrame after total p out k) (bword true) := by simp [Eval,evalExpr,bword]
  apply ASTLoops.StmtRun.sequence
  · exact ASTLoops.SeqRun.next (ASTLoops.StmtRun.evaluate (search_write effect call total k))
      (ASTLoops.SeqRun.returned (ASTLoops.StmtRun.returnValue ret))
  · simp only [Scope,scopeResult,search_frame_pop total p p k k out (write_shape effect).1]

theorem next_found_body {caller after : State} {p : Nat} {out : Address}
    (effect : WriteNat caller out p after) (call : Call) (contract : PrimeContract call)
    (total k : Nat) (execution : PrimeExec p 1) :
    Run call nextSearchBody (searchFrame caller total p out k)
      (.returned (searchFrame after total p out k) (bword true)) := by
  apply ASTLoops.StmtRun.sequence
  · apply ASTLoops.SeqRun.returned
    apply ASTLoops.StmtRun.branch (search_prime call contract caller total p k 1 out execution)
    simpa [truth,word] using search_hit effect call total k
  · simp only [Scope,scopeResult,search_frame_pop total p p k k out (write_shape effect).1]

theorem next_miss_body (call : Call) (contract : PrimeContract call) (caller : State)
    (total a k : Nat) (out : Address) (execution : PrimeExec a 0) :
    Run call nextSearchBody (searchFrame caller total a out k)
      (.continuing (searchFrame caller total a out k)) := by
  apply ASTLoops.StmtRun.sequence
  · apply ASTLoops.SeqRun.next
    · apply ASTLoops.StmtRun.branch (search_prime call contract caller total a k 0 out execution)
      simpa [truth,word] using ASTLoops.StmtRun.skip (searchFrame caller total a out k)
    · exact ASTLoops.SeqRun.nil _
  · simp [Scope,scopeResult,pop_self]

theorem prev_found_body {caller after : State} {p : Nat} {out : Address}
    (effect : WriteNat caller out p after) (call : Call) (contract : PrimeContract call)
    (total k : Nat) (execution : PrimeExec p 1) :
    Run call prevSearchBody (searchFrame caller total p out k)
      (.returned (searchFrame after total p out k) (bword true)) := by
  apply ASTLoops.StmtRun.sequence
  · apply ASTLoops.SeqRun.returned
    apply ASTLoops.StmtRun.branch (search_prime call contract caller total p k 1 out execution)
    simpa [truth,word] using search_hit effect call total k
  · simp only [Scope,scopeResult,search_frame_pop total p p k k out (write_shape effect).1]

theorem prev_miss_body (call : Call) (contract : PrimeContract call) (caller : State)
    (total a k : Nat) (out : Address) (execution : PrimeExec a 0)
    (ha : a<2^64) (nonzero : a≠0) :
    Run call prevSearchBody (searchFrame caller total a out k)
      (.continuing (searchFrame caller total ((a+wordMod-1)%wordMod) out k)) := by
  apply ASTLoops.StmtRun.sequence
  · apply ASTLoops.SeqRun.next
    · apply ASTLoops.StmtRun.branch (search_prime call contract caller total a k 0 out execution)
      simpa [truth,word] using ASTLoops.StmtRun.skip (searchFrame caller total a out k)
    · apply ASTLoops.SeqRun.next
      · apply ASTLoops.StmtRun.branch (search_zero_test call caller total a k out ha)
        simpa [truth,word,boolean,nonzero] using ASTLoops.StmtRun.skip (searchFrame caller total a out k)
      · exact ASTLoops.SeqRun.next (ASTLoops.StmtRun.evaluate (search_a_decrement call caller total a k out ha))
          (ASTLoops.SeqRun.nil _)
  · simp only [Scope,scopeResult,search_frame_pop total a _ k k out rfl]

#print axioms prev_miss_body
end LCMSourcePV.Witness.AST
