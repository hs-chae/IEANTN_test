import WitnessASTForContracts

namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C

/-- Actual C parameter applicability is required even when choose_q0 returns
false without writing its out pointer. The old untyped Choose0Contract is
preserved as a provisional interface and is not claimed source-implementable.
The caller proves this type from its own allocated Block or successful write. -/
def TypedChoose0Contract (call : Call) : Prop :=
  ∀s pf fit total lo stop p0 p1 p2 q1 q2 top result address t,
    (∀n∈[pf,fit,total,lo,stop,p0,p1,p2,q1,q2,top],n < 2^64) →
    addressType s address=some "Block" →
    Choose0For pf fit total lo stop p0 p1 p2 q1 q2 0 top result →
    (match result with | none=>t=s | some b=>WriteBlock s address b t) →
    call "choose_q0" [word 64 pf,word 64 fit,word 64 total,word 64 lo,word 64 stop,
      word 64 p0,word 64 p1,word 64 p2,word 64 q1,word 64 q2,word 64 top,
      .pointer address true] s=some (bword result.isSome,t)

#print axioms TypedChoose0Contract
end LCMSourcePV.Witness.AST
