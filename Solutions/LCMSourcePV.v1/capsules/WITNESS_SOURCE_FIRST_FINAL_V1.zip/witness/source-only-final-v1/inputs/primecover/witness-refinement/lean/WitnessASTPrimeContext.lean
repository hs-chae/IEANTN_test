import WitnessASTForContracts
import WitnessASTLocals
import WitnessASTMemoryWrites

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.PrimeCover

def primeParameter (caller : State) (n : Nat) : State :=
  allocate {caller with env:=[]} "U" "n" (some (word 64 n))
def primeDivisor (caller : State) (n d : Nat) : State :=
  allocate (primeParameter caller n) "U" "d" (some (word 64 d))

theorem prime_n_local (caller : State) (n d : Nat) :
    Local (primeDivisor caller n d) "n" (word 64 n) :=
  (Local.allocated {caller with env:=[]} "U" "n" (word 64 n)).allocate_other
    "U" "d" (some (word 64 d)) (by decide)
theorem prime_d_local (caller : State) (n d : Nat) :
    Local (primeDivisor caller n d) "d" (word 64 d) :=
  Local.allocated (primeParameter caller n) "U" "d" (word 64 d)

@[simp] theorem eval_prime_n (call : Call) (caller : State) (n d fuel : Nat) :
    evalExpr call (fuel+1) (primeDivisor caller n d) (.var "n")=
      some (word 64 n,primeDivisor caller n d) :=
  (prime_n_local caller n d).eval call fuel (by decide) (by decide)
@[simp] theorem eval_prime_d (call : Call) (caller : State) (n d fuel : Nat) :
    evalExpr call (fuel+1) (primeDivisor caller n d) (.var "d")=
      some (word 64 d,primeDivisor caller n d) :=
  (prime_d_local caller n d).eval call fuel (by decide) (by decide)

@[simp] theorem prime_n_name (caller : State) (n d : Nat) :
    getVar (primeDivisor caller n d) "n"=some ⟨caller.heap.length,0,none⟩ := by
  rw [primeDivisor,getVar_allocate_other _ "U" "d" "n" _ (by decide)]
  exact allocated_var {caller with env:=[]} "U" "n" (some (word 64 n))
@[simp] theorem prime_n_read (caller : State) (n d : Nat) :
    read (primeDivisor caller n d) ⟨caller.heap.length,0,none⟩=some (word 64 n) := by
  rw [primeDivisor,read_allocate_old _ "U" "d" _ _ (by simp [primeParameter,allocate])]
  exact read_allocated {caller with env:=[]} "U" "n" (word 64 n)
@[simp] theorem prime_d_name (caller : State) (n d : Nat) :
    getVar (primeDivisor caller n d) "d"=some ⟨(primeParameter caller n).heap.length,0,none⟩ :=
  allocated_var (primeParameter caller n) "U" "d" (some (word 64 d))
@[simp] theorem prime_d_read (caller : State) (n d : Nat) :
    read (primeDivisor caller n d) ⟨(primeParameter caller n).heap.length,0,none⟩=some (word 64 d) :=
  read_allocated (primeParameter caller n) "U" "d" (word 64 d)

def primeTrialCondition : Expr := .binary "<=" (.var "d") (.binary "/" (.var "n") (.var "d"))
def primeRemainderCondition : Expr := .binary "==" (.binary "%" (.var "n") (.var "d")) (.nat 0)
def primeTrialStep : Expr := .unary "++" (.var "d")
def primeTrialBody : Stmt := .branch primeRemainderCondition (.returnStmt (.nat 0)) .skip

theorem prime_trial_condition (call : Call) (caller : State) (n d : Nat)
    (hn : n<2^64) (hd : d<2^64) (positive : 2≤d) :
    Eval call primeTrialCondition (primeDivisor caller n d) (primeDivisor caller n d)
      (boolean (decide (d≤n/d))) := by
  have hnmod : n%18446744073709551616=n := Nat.mod_eq_of_lt hn
  have hdmod : d%18446744073709551616=d := Nat.mod_eq_of_lt hd
  have hq : n/d<2^64 := lt_of_le_of_lt (Nat.div_le_self n d) hn
  have hqmod : (n/d)%18446744073709551616=n/d := Nat.mod_eq_of_lt hq
  have hd0 : d≠0 := by omega
  simp [Eval,evalExpr,primeTrialCondition,binaryValue,word,boolean,hnmod,hdmod,hqmod,hd0]

theorem prime_remainder_condition (call : Call) (caller : State) (n d : Nat)
    (hn : n<2^64) (hd : d<2^64) (positive : 2≤d) :
    Eval call primeRemainderCondition (primeDivisor caller n d) (primeDivisor caller n d)
      (boolean (decide (n%d=0))) := by
  have hnmod : n%18446744073709551616=n := Nat.mod_eq_of_lt hn
  have hdmod : d%18446744073709551616=d := Nat.mod_eq_of_lt hd
  have hr : n%d<2^64 := lt_of_lt_of_le (Nat.mod_lt n (by omega : 0<d)) hd.le
  have hrmod : (n%d)%18446744073709551616=n%d := Nat.mod_eq_of_lt hr
  have hd0 : d≠0 := by omega
  simp [Eval,evalExpr,primeRemainderCondition,binaryValue,word,boolean,hnmod,hdmod,hrmod,hd0]

theorem prime_trial_increment (call : Call) (caller : State) (n d : Nat)
    (hd : d<2^64) :
    Eval call primeTrialStep (primeDivisor caller n d) (primeDivisor caller n (bump d))
      (word 64 (bump d)) := by
  have hdmod : d%18446744073709551616=d := Nat.mod_eq_of_lt hd
  simpa [Eval,evalExpr,evalLValue,primeTrialStep,primeDivisor,allocated_var,read_allocated,
    word,bump,wordMod,hdmod] using write_allocated_word (primeParameter caller n) "d" d (d+1)

theorem prime_pop_divisor (caller : State) (n d : Nat) :
    popScope (primeParameter caller n) (primeDivisor caller n d)=primeParameter caller n :=
  pop_allocate (primeParameter caller n) "U" "d" (some (word 64 d))

theorem prime_pop_parameter (caller : State) (n : Nat) :
    popScope caller (primeParameter caller n)=caller := by
  cases caller
  simp [popScope,primeParameter,allocate]

#print axioms prime_trial_increment
end LCMSourcePV.Witness.AST
