import WitnessASTChoose0Iteration
import WitnessASTChoose0Moves

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.AST.Choose0
open LCMSourcePV.Witness.AST LCMSourcePV.Witness.C LCMSourcePV.RestrictedC E1TwoTracks.TrackB LCMSourcePV.ASTLoops

theorem for_some (call : Call) (pf ff total lo stop p0 p1 p2 q1 q2 : Nat) (address : Address)
    (hn : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2],n<2^64)
    (hPrev : PrevForContract call) (hP : ProductPContract call) (hQ : ProductQContract call)
    (hShrink : ShrinkContract call) :
    ∀{k top result},Choose0For pf ff total lo stop p0 p1 p2 q1 q2 k top result →
    ∀(caller after : State)(out : Block), result=some out → top<2^64 →
      WriteBlock caller address out after →
      ∃finalK finalTop,ForRun call (some guardExpr) stepExpr iterationBody
        (loop caller pf ff total lo stop p0 p1 p2 q1 q2 top address k)
        (.returned (loop after pf ff total lo stop p0 p1 p2 q1 q2 finalTop address finalK) (bword true)) := by
  intro k top result trace
  induction trace with
  | done k top guard => intro caller after out impossible; cases impossible
  | hit k top q0 out hg hp htest hfit =>
    intro caller after actualOut he ht hw
    have heq:=Option.some.inj he
    subst actualOut
    have hnTop : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2,top],n<2^64 := by
      intro n hmem
      have hm : n∈([pf,ff,total,lo,stop,p0,p1,p2,q1,q2]++[top]) := hmem
      rcases List.mem_append.mp hm with hm|hm
      · exact hn n hm
      · have he : n=top := by simpa only [List.mem_singleton] using hm
        exact he.symm ▸ ht
    refine ⟨k,top,ForRun.returned (t:=loop caller pf ff total lo stop p0 p1 p2 q1 q2 top address k) ?_ ?_⟩
    · simpa [truth,boolean,word,hg] using GuardRun.present (truth:=truth)
        (guard_run call caller pf ff total lo stop p0 p1 p2 q1 q2 top address k
          (lt_trans hg (hn total (by simp))) (hn total (by simp)))
    · exact iteration_run_hit call hPrev hP hQ hShrink caller after
        pf ff total lo stop p0 p1 p2 q1 q2 top address k q0 out hnTop hp htest hfit hw
  | skip k top q0 result hg hp htest hk rest ih =>
    intro caller after out he ht hw
    have hnTop : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2,top],n<2^64 := by
      intro n hmem
      have hm : n∈([pf,ff,total,lo,stop,p0,p1,p2,q1,q2]++[top]) := hmem
      rcases List.mem_append.mp hm with hm|hm
      · exact hn n hm
      · have he : n=top := by simpa only [List.mem_singleton] using hm
        exact he.symm ▸ ht
    have htNew : usub q0 1<2^64 := by
      unfold usub Unsigned.sub Unsigned.repr Unsigned.modulus
      exact Nat.mod_lt _ (by decide)
    obtain ⟨finalK,finalTop,tail⟩:=ih caller after out he htNew hw
    rw [Nat.mod_eq_of_lt hk] at tail
    refine ⟨finalK,finalTop,ForRun.next
      (t:=loop caller pf ff total lo stop p0 p1 p2 q1 q2 top address k)
      (b:=loop caller pf ff total lo stop p0 p1 p2 q1 q2 (usub q0 1) address k)
      (value:=word 64 (k+1)) ?_ ?_ ?_ tail⟩
    · simpa [truth,boolean,word,hg] using GuardRun.present (truth:=truth)
        (guard_run call caller pf ff total lo stop p0 p1 p2 q1 q2 top address k
          (lt_trans hg (hn total (by simp))) (hn total (by simp)))
    · exact iteration_run_skip call hPrev hP hQ hShrink caller
        pf ff total lo stop p0 p1 p2 q1 q2 top address k q0 hnTop hp htest
    · exact step_run call caller pf ff total lo stop p0 p1 p2 q1 q2 (usub q0 1) address k
        (lt_trans hg (hn total (by simp)))

theorem for_none (call : Call) (pf ff total lo stop p0 p1 p2 q1 q2 : Nat) (address : Address)
    (hn : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2],n<2^64)
    (hPrev : PrevForContract call) (hP : ProductPContract call) (hQ : ProductQContract call)
    (hShrink : ShrinkContract call) :
    ∀{k top result},Choose0For pf ff total lo stop p0 p1 p2 q1 q2 k top result →
    ∀(caller : State), result=none → k<2^64 → top<2^64 →
      ∃finalK finalTop,ForRun call (some guardExpr) stepExpr iterationBody
        (loop caller pf ff total lo stop p0 p1 p2 q1 q2 top address k)
        (.continuing (loop caller pf ff total lo stop p0 p1 p2 q1 q2 finalTop address finalK)) := by
  intro k top result trace
  induction trace with
  | done k top hg =>
    intro caller _ hk ht
    refine ⟨k,top,ForRun.done ?_⟩
    simpa [truth,boolean,word,hg] using GuardRun.present (truth:=truth)
      (guard_run call caller pf ff total lo stop p0 p1 p2 q1 q2 top address k hk (hn total (by simp)))
  | hit => intro caller impossible; cases impossible
  | skip k top q0 result hg hp htest hk rest ih =>
    intro caller he hkWord ht
    have hnTop : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2,top],n<2^64 := by
      intro n hmem
      have hm : n∈([pf,ff,total,lo,stop,p0,p1,p2,q1,q2]++[top]) := hmem
      rcases List.mem_append.mp hm with hm|hm
      · exact hn n hm
      · have he : n=top := by simpa only [List.mem_singleton] using hm
        exact he.symm ▸ ht
    have htNew : usub q0 1<2^64 := by
      unfold usub Unsigned.sub Unsigned.repr Unsigned.modulus
      exact Nat.mod_lt _ (by decide)
    have hkNext : (k+1)%2^64<2^64:=Nat.mod_lt _ (by decide)
    obtain ⟨finalK,finalTop,tail⟩:=ih caller he hkNext htNew
    rw [Nat.mod_eq_of_lt hk] at tail
    refine ⟨finalK,finalTop,ForRun.next
      (t:=loop caller pf ff total lo stop p0 p1 p2 q1 q2 top address k)
      (b:=loop caller pf ff total lo stop p0 p1 p2 q1 q2 (usub q0 1) address k)
      (value:=word 64 (k+1)) ?_ ?_ ?_ tail⟩
    · simpa [truth,boolean,word,hg] using GuardRun.present (truth:=truth)
        (guard_run call caller pf ff total lo stop p0 p1 p2 q1 q2 top address k hkWord (hn total (by simp)))
    · exact iteration_run_skip call hPrev hP hQ hShrink caller
        pf ff total lo stop p0 p1 p2 q1 q2 top address k q0 hnTop hp htest
    · exact step_run call caller pf ff total lo stop p0 p1 p2 q1 q2 (usub q0 1) address k hkWord

#print axioms for_some
#print axioms for_none
end LCMSourcePV.Witness.AST.Choose0
