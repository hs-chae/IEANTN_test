import WitnessSpecInput
import WitnessHigherDeterminism

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C E1TwoTracks.TrackB

theorem block_input_unique {s : State} {a : Address} {b c : Block}
    (hb : BlockInput s a b) (hc : BlockInput s a c) : b=c := by
  have he:=Option.some.inj (hb.2.2.2.1.symm.trans hc.2.2.2.1)
  cases he
  rfl

theorem write_nat_unique {s t u : State} {a : Address} {n : Nat}
    (ht : WriteNat s a n t) (hu : WriteNat s a n u) : t=u :=
  congrArg Prod.snd (Option.some.inj (ht.symm.trans hu))
theorem write_block_unique {s t u : State} {a : Address} {b : Block}
    (ht : WriteBlock s a b t) (hu : WriteBlock s a b u) : t=u :=
  congrArg Prod.snd (Option.some.inj (ht.symm.trans hu))

theorem spec_input_unique (input : SpecInput) (s : State) {left right : Value × State}
    (hl : input.Run s left) (hr : input.Run s right) : left=right := by
  cases input with
  | prime n =>
    rcases hl with ⟨a,ha,rfl⟩
    rcases hr with ⟨b,hb,rfl⟩
    rw [C.prime_result_unique ha hb]
  | sqrt n =>
    rcases hl with ⟨a,ha,rfl⟩
    rcases hr with ⟨b,hb,rfl⟩
    rw [(sqrt_exec_sound ha).trans (sqrt_exec_sound hb).symm]
  | next total a out =>
    rcases hl with ⟨_,_,p,t,hp,ht,rfl⟩
    rcases hr with ⟨_,_,q,u,hq,hu,rfl⟩
    have he:=Option.some.inj (C.next_result_unique hp hq)
    subst q
    rw [write_nat_unique ht hu]
  | prev total a out =>
    rcases hl with ⟨_,_,p,t,hp,ht,rfl⟩
    rcases hr with ⟨_,_,q,u,hq,hu,rfl⟩
    have he:=Option.some.inj (C.prev_result_unique hp hq)
    subst q
    rw [write_nat_unique ht hu]
  | productP target writable =>
    rcases hl with ⟨b,hb,rfl⟩
    rcases hr with ⟨c,hc,rfl⟩
    rw [block_input_unique hb hc]
  | productQ target writable =>
    rcases hl with ⟨b,hb,rfl⟩
    rcases hr with ⟨c,hc,rfl⟩
    rw [block_input_unique hb hc]
  | endpoint target writable n =>
    rcases hl with ⟨_,b,r,hb,he,rfl⟩
    rcases hr with ⟨_,c,r',hc,he',rfl⟩
    have eqb:=block_input_unique hb hc
    subst c
    rw [Option.some.inj (he.symm.trans he')]
  | check target writable =>
    rcases hl with ⟨b,r,hb,he,rfl⟩
    rcases hr with ⟨c,r',hc,he',rfl⟩
    have eqb:=block_input_unique hb hc
    subst c
    rw [C.check_result_unique he he']
  | shrink fuel b out =>
    rcases hl with ⟨_,_,p,t,hp,ht,rfl⟩
    rcases hr with ⟨_,_,q,u,hq,hu,rfl⟩
    have he:=C.shrink_result_unique hp hq
    subst q
    rw [write_block_unique ht hu]
  | choose0 pf fit total lo stop p0 p1 p2 q1 q2 top out =>
    rcases hl with ⟨_,_,p,t,hp,ht,rfl⟩
    rcases hr with ⟨_,_,q,u,hq,hu,rfl⟩
    have he:=C.choose0_result_unique hp hq
    subst q
    cases p with
    | none => simp_all
    | some b => rw [write_block_unique ht hu]
  | choose1 pf fit q0Fuel total lo stop p0 p1 p2 q2 top out =>
    rcases hl with ⟨_,p,t,hp,ht,rfl⟩
    rcases hr with ⟨_,q,u,hq,hu,rfl⟩
    have he:=C.choose1_result_unique hp hq
    subst q
    cases p with
    | none => simp_all
    | some b => rw [write_block_unique ht hu]
  | make pf fit q0Fuel q1Fuel lo stop out =>
    rcases hl with ⟨_,p,t,hp,ht,rfl⟩
    rcases hr with ⟨_,q,u,hq,hu,rfl⟩
    have he:=C.make_result_unique hp hq
    subst q
    rw [write_block_unique ht hu]
  | makeRun lo out =>
    rcases hl with ⟨_,p,t,hp,ht,rfl⟩
    rcases hr with ⟨_,q,u,hq,hu,rfl⟩
    have he:=C.make_result_unique hp hq
    subst q
    rw [write_block_unique ht hu]

theorem spec_decode_run (input : SpecInput) (s : State) {result : Value × State}
    (h : input.Run s result) : decodeSpec input.name input.args=some input := by
  cases input with
  | prime n =>
    rcases h with ⟨r,hr,_⟩
    have hn : n<2^64:=hr.1
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt hn] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | sqrt n =>
    rcases h with ⟨r,hr,_⟩
    have hn : n<2^64:=hr.1
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt hn] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | next total a out =>
    rcases h with ⟨ht,ha,_⟩
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt ht,Nat.mod_eq_of_lt ha] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | prev total a out =>
    rcases h with ⟨ht,ha,_⟩
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt ht,Nat.mod_eq_of_lt ha] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | productP target writable => rfl
  | productQ target writable => rfl
  | endpoint target writable n =>
    rcases h with ⟨hn,_⟩
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt hn] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | check target writable => rfl
  | shrink fuel b out =>
    rcases h with ⟨hf,_⟩
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt hf] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | choose0 pf fit total lo stop p0 p1 p2 q1 q2 top out =>
    rcases h with ⟨hn,_⟩
    have h_pf:=hn pf (by simp)
    have h_fit:=hn fit (by simp)
    have h_total:=hn total (by simp)
    have h_lo:=hn lo (by simp)
    have h_stop:=hn stop (by simp)
    have h_p0:=hn p0 (by simp)
    have h_p1:=hn p1 (by simp)
    have h_p2:=hn p2 (by simp)
    have h_q1:=hn q1 (by simp)
    have h_q2:=hn q2 (by simp)
    have h_top:=hn top (by simp)
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt h_pf,Nat.mod_eq_of_lt h_fit,Nat.mod_eq_of_lt h_total,Nat.mod_eq_of_lt h_lo,Nat.mod_eq_of_lt h_stop,Nat.mod_eq_of_lt h_p0,Nat.mod_eq_of_lt h_p1,Nat.mod_eq_of_lt h_p2,Nat.mod_eq_of_lt h_q1,Nat.mod_eq_of_lt h_q2,Nat.mod_eq_of_lt h_top] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | choose1 pf fit q0Fuel total lo stop p0 p1 p2 q2 top out =>
    rcases h with ⟨hn,_⟩
    have h_pf:=hn pf (by simp)
    have h_fit:=hn fit (by simp)
    have h_q0Fuel:=hn q0Fuel (by simp)
    have h_total:=hn total (by simp)
    have h_lo:=hn lo (by simp)
    have h_stop:=hn stop (by simp)
    have h_p0:=hn p0 (by simp)
    have h_p1:=hn p1 (by simp)
    have h_p2:=hn p2 (by simp)
    have h_q2:=hn q2 (by simp)
    have h_top:=hn top (by simp)
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt h_pf,Nat.mod_eq_of_lt h_fit,Nat.mod_eq_of_lt h_q0Fuel,Nat.mod_eq_of_lt h_total,Nat.mod_eq_of_lt h_lo,Nat.mod_eq_of_lt h_stop,Nat.mod_eq_of_lt h_p0,Nat.mod_eq_of_lt h_p1,Nat.mod_eq_of_lt h_p2,Nat.mod_eq_of_lt h_q2,Nat.mod_eq_of_lt h_top] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | make pf fit q0Fuel q1Fuel lo stop out =>
    rcases h with ⟨hn,_⟩
    have h_pf:=hn pf (by simp)
    have h_fit:=hn fit (by simp)
    have h_q0Fuel:=hn q0Fuel (by simp)
    have h_q1Fuel:=hn q1Fuel (by simp)
    have h_lo:=hn lo (by simp)
    have h_stop:=hn stop (by simp)
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt h_pf,Nat.mod_eq_of_lt h_fit,Nat.mod_eq_of_lt h_q0Fuel,Nat.mod_eq_of_lt h_q1Fuel,Nat.mod_eq_of_lt h_lo,Nat.mod_eq_of_lt h_stop] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]
  | makeRun lo out =>
    rcases h with ⟨hn,_⟩
    simp [SpecInput.name,SpecInput.args,decodeSpec,word,Nat.mod_eq_of_lt hn] <;> simp_all only [Nat.reducePow,true_and,and_true,and_self]

theorem spec_summary_unique {name : String} {args : List Value} {s : State}
    {left right : Value × State} (hl : SpecSummary name args s left)
    (hr : SpecSummary name args s right) : left=right := by
  rcases hl with ⟨input,nameEq,argsEq,hl⟩
  rcases hr with ⟨other,nameEq',argsEq',hr⟩
  have hd:=spec_decode_run input s hl
  have hd':=spec_decode_run other s hr
  rw [←nameEq,←argsEq] at hd
  rw [←nameEq',←argsEq'] at hd'
  have he:=Option.some.inj (hd.symm.trans hd')
  subst other
  exact spec_input_unique input s hl hr

#print axioms spec_summary_unique
end LCMSourcePV.Witness.AST
