import WitnessASTSearchLoops

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.PrimeCover

def nextSearchFor : Stmt := .forLoop (.declare [⟨"U","k",some (.nat 0)⟩])
  (some searchGuard) searchNextStep nextSearchBody
def prevSearchFor : Stmt := .forLoop (.declare [⟨"U","k",some (.nat 0)⟩])
  (some searchGuard) searchKStep prevSearchBody

theorem next_source_shape : f_next_prime.body=
    .sequence [nextSearchFor,.returnStmt (.var "false")] := rfl
theorem prev_source_shape : f_prev_prime.body=
    .sequence [prevSearchFor,.returnStmt (.var "false")] := rfl

theorem next_body_execution (call : Call) (contract : PrimeContract call)
    {caller after : State} {total a p : Nat} {out : Address}
    (ht : total<2^64) (ha : a<2^64) (execution : NextFor total 0 a (some p))
    (effect : WriteNat caller out p after) :
    Run call f_next_prime.body (searchParameters caller total a out)
      (.returned (searchParameters after total p out) (bword true)) := by
  obtain ⟨last,loop⟩ := next_for_source call contract caller after out total ht 0 a (some p)
    execution p rfl effect (by decide) ha
  have loopStmt : Run call nextSearchFor (searchParameters caller total a out)
      (.returned (searchParameters after total p out) (bword true)) := by
    apply ASTLoops.StmtRun.forLoop (ASTLoops.StmtRun.declare (search_declare_k call caller total a out)) loop
    simp only [Scope,scopeResult,search_parameter_pop total a p last out (write_shape effect).1]
  rw [next_source_shape]
  apply ASTLoops.StmtRun.sequence (ASTLoops.SeqRun.returned loopStmt)
  simp only [Scope,scopeResult,search_parameters_self_pop total a p out (write_shape effect).1]

theorem prev_body_execution (call : Call) (contract : PrimeContract call)
    {caller after : State} {total a p : Nat} {out : Address}
    (ht : total<2^64) (ha : a<2^64) (execution : PrevFor total 0 a (some p))
    (effect : WriteNat caller out p after) :
    Run call f_prev_prime.body (searchParameters caller total a out)
      (.returned (searchParameters after total p out) (bword true)) := by
  obtain ⟨last,loop⟩ := prev_for_source call contract caller after out total ht 0 a (some p)
    execution p rfl effect (by decide) ha
  have loopStmt : Run call prevSearchFor (searchParameters caller total a out)
      (.returned (searchParameters after total p out) (bword true)) := by
    apply ASTLoops.StmtRun.forLoop (ASTLoops.StmtRun.declare (search_declare_k call caller total a out)) loop
    simp only [Scope,scopeResult,search_parameter_pop total a p last out (write_shape effect).1]
  rw [prev_source_shape]
  apply ASTLoops.StmtRun.sequence (ASTLoops.SeqRun.returned loopStmt)
  simp only [Scope,scopeResult,search_parameters_self_pop total a p out (write_shape effect).1]

/-- The actual looked-up ascending C body, including parameter casts, local
counter, wrapped loop, typed out write, bool return and caller restoration.
The sole modular callee contract is the separately source-proved primality body. -/
theorem next_prime_body_call (call : Call) (contract : PrimeContract call)
    {caller after : State} {total a p : Nat} {out : Address}
    (ht : total<2^64) (ha : a<2^64) (execution : NextFor total 0 a (some p))
    (effect : WriteNat caller out p after) :
    BodyCall call "next_prime" [word 64 total,word 64 a,.pointer out true]
      caller (bword true) after := by
  refine ⟨f_next_prime,searchParameters caller total a out,searchParameters after total p out,
    bword true,rfl,search_bind_parameters effect total a,
    next_body_execution call contract ht ha execution effect,?_,?_⟩
  · simp [f_next_prime,castValue,asNat,bword,word]
  · exact (search_function_pop effect total p).symm

/-- Actual descending C body with its explicit zero guard and modular unsigned
counter/candidate operations; no stronger no-wrap Nat-search premise is added. -/
theorem prev_prime_body_call (call : Call) (contract : PrimeContract call)
    {caller after : State} {total a p : Nat} {out : Address}
    (ht : total<2^64) (ha : a<2^64) (execution : PrevFor total 0 a (some p))
    (effect : WriteNat caller out p after) :
    BodyCall call "prev_prime" [word 64 total,word 64 a,.pointer out true]
      caller (bword true) after := by
  refine ⟨f_prev_prime,searchParameters caller total a out,searchParameters after total p out,
    bword true,rfl,search_bind_parameters effect total a,
    prev_body_execution call contract ht ha execution effect,?_,?_⟩
  · simp [f_prev_prime,castValue,asNat,bword,word]
  · exact (search_function_pop effect total p).symm

#print axioms next_prime_body_call
#print axioms prev_prime_body_call
end LCMSourcePV.Witness.AST
