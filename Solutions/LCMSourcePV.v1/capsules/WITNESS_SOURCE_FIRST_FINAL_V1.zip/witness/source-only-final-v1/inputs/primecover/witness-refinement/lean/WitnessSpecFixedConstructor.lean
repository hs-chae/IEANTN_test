import WitnessSpecClosed
import ClosedCConstructor

set_option autoImplicit false
namespace LCMSourcePV.Witness.AST

/-- CLOSED 404-block constructor execution as a finite tree of actual C AST
body calls. The hand-loop trace is discharged by the existing ordinary-kernel
closed trace; every callback is now independently source-body implemented. -/
theorem fixed_constructor_actual_call_tree :
    ActualCallTree 8 (specRunEvent C.Closed.state_404) :=
  constructor_actual_call_tree C.Closed.state_404 C.Closed.source_run

/-- Source-file/token correspondence and the genuine source-call tree are
both explicit. The separate main proof supplies application initialization,
array/call association and stdout applicability; physical compiler/stdio
association remains the pinned generic trust boundary. -/
theorem fixed_source_bound_constructor :
    C.AllSourceFilesCorrespond ∧ ActualCallTree 8 (specRunEvent C.Closed.state_404) :=
  ⟨C.all_source_files_checked,fixed_constructor_actual_call_tree⟩

#print axioms fixed_constructor_actual_call_tree
#print axioms fixed_source_bound_constructor
end LCMSourcePV.Witness.AST
