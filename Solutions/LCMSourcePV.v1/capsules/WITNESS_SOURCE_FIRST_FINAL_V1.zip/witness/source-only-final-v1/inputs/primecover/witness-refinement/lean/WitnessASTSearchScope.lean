import WitnessASTSearchFrames

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.PrimeCover

theorem search_frame_pop {s t : State} (total a b k l : Nat) (out : Address)
    (hlen : t.heap.length=s.heap.length) :
    popScope (searchFrame s total a out k) (searchFrame t total b out l)=
      searchFrame t total b out l := by
  have henv : (searchFrame s total a out k).env=(searchFrame t total b out l).env := by
    simp [searchFrame,searchParameters,searchEnv,frameState,allocate,searchExtra,hlen]
  have hl : (searchFrame s total a out k).heap.length=(searchFrame t total b out l).heap.length := by
    simp [searchFrame,searchParameters,frameState,allocate,searchExtra,hlen]
  unfold popScope
  rw [hl,List.take_length,henv]

theorem search_parameter_pop {s t : State} (total a b k : Nat) (out : Address)
    (hlen : t.heap.length=s.heap.length) :
    popScope (searchParameters s total a out) (searchFrame t total b out k)=
      searchParameters t total b out := by
  cases s with | mk sh se =>
   cases t with | mk th te =>
    simp only at hlen
    simp [popScope,searchFrame,searchParameters,searchEnv,frameState,allocate,searchExtra,
      List.append_assoc,←hlen,List.take_append]

theorem search_parameters_self_pop {s t : State} (total a b : Nat) (out : Address)
    (hlen : t.heap.length=s.heap.length) :
    popScope (searchParameters s total a out) (searchParameters t total b out)=
      searchParameters t total b out := by
  have henv : (searchParameters s total a out).env=(searchParameters t total b out).env := by
    simp [searchParameters,searchEnv,frameState,hlen]
  have hl : (searchParameters s total a out).heap.length=(searchParameters t total b out).heap.length := by
    simp [searchParameters,frameState,searchExtra,hlen]
  unfold popScope
  rw [hl,List.take_length,henv]

theorem search_bind_parameters {s t : State} {p : Nat} {out : Address}
    (effect : WriteNat s out p t) (total a : Nat) :
    bindArgs [("U","fuel"),("U","a"),("U*","out")]
      [word 64 total,word 64 a,.pointer out true] s =
      some (searchParameters s total a out) := by
  have hbound := write_address_bound effect
  have htype := effect.target_type
  have t1 : addressType (allocate {s with env:=[]} "U" "fuel" (some (word 64 total))) out=some "U" := by
    simpa only [allocate,addressType] using (type_append {s with env:=[]} [⟨"U",[some (word 64 total)]⟩] out hbound).trans htype
  have t2 : addressType (allocate (allocate {s with env:=[]} "U" "fuel" (some (word 64 total))) "U" "a" (some (word 64 a))) out=some "U" := by
    have bound : out.object < (allocate {s with env:=[]} "U" "fuel" (some (word 64 total))).heap.length := by
      simp only [allocate,List.length_append,List.length_singleton]
      omega
    exact (type_append _ [⟨"U",[some (word 64 a)]⟩] out bound).trans t1
  rw [search_parameter_allocations]
  have cu (state : State) (n : Nat) : castValue state "U" (word 64 n)=some (word 64 n) := by
    simp [castValue,asNat,word]
  have cp : castValue (allocate (allocate {s with env:=[]} "U" "fuel" (some (word 64 total))) "U" "a" (some (word 64 a))) "U*" (.pointer out true)=some (.pointer out true) := by
    simp [castValue,t2]
  simp [bindArgs,List.foldlM,cu,cp]

theorem search_declare_k (call : Call) (caller : State) (total a : Nat) (out : Address) :
    Declare call [⟨"U","k",some (.nat 0)⟩] (searchParameters caller total a out)
      (searchFrame caller total a out 0) := by
  simp [Declare,declarations,List.foldlM,evalExpr,castValue,asNat,word,searchFrame]

theorem search_function_pop {s t : State} {p : Nat} {out : Address}
    (effect : WriteNat s out p t) (total a : Nat) :
    popScope s (searchParameters t total a out)=t :=
  effect.pop_frame (searchExtra total a out) (searchEnv t)

#print axioms search_bind_parameters
end LCMSourcePV.Witness.AST
