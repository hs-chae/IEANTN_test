import WitnessASTPrimeContext

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.PrimeCover

def pcTrialOutcome (result : Nat) (s : State) : Flow :=
  if result=0 then .returned s (word 32 0) else .continuing s

theorem pc_trial_for (caller : State) (call : Call) {n d result : Nat}
    (execution : TrialExec n d result) (hn : n<2^64) (hd2 : 2≤d) (hd : d<2^64) :
    ∃last, last<2^64 ∧
      ForRun call (some primeTrialCondition) primeTrialStep primeTrialBody
        (primeDivisor caller n d) (pcTrialOutcome result (primeDivisor caller n last)) := by
  revert hd2 hd
  induction execution with
  | done d guard =>
    intro hd2 hd
    refine ⟨d,hd,?_⟩
    change ForRun call (some primeTrialCondition) primeTrialStep primeTrialBody
      (primeDivisor caller n d) (.continuing (primeDivisor caller n d))
    apply ASTLoops.ForRun.done
    simpa [truth,boolean,word,guard] using ASTLoops.GuardRun.present (truth:=truth)
      (prime_trial_condition call caller n d hn hd hd2)
  | found d guard zero =>
    intro hd2 hd
    refine ⟨d,hd,?_⟩
    change ForRun call (some primeTrialCondition) primeTrialStep primeTrialBody
      (primeDivisor caller n d) (.returned (primeDivisor caller n d) (word 32 0))
    apply ASTLoops.ForRun.returned
    · simpa [truth,boolean,word,guard] using ASTLoops.GuardRun.present (truth:=truth)
        (prime_trial_condition call caller n d hn hd hd2)
    · apply ASTLoops.StmtRun.branch (prime_remainder_condition call caller n d hn hd hd2)
      simpa [truth,boolean,word,zero] using ASTLoops.StmtRun.returnValue
        (eval_literal call (primeDivisor caller n d) 0 (by decide))
  | step d result guard nonzero rest ih =>
    intro hd2 hd
    have hb : bump d=d+1 := bump_exact hn hd2 guard
    have hdNext : bump d<2^64 := by
      unfold bump wordMod
      exact Nat.mod_lt _ (by decide)
    obtain ⟨last,hLast,body⟩ := ih (by omega) hdNext
    refine ⟨last,hLast,?_⟩
    apply ASTLoops.ForRun.next
    · simpa [truth,boolean,word,guard] using ASTLoops.GuardRun.present (truth:=truth)
        (prime_trial_condition call caller n d hn hd hd2)
    · apply ASTLoops.StmtRun.branch (prime_remainder_condition call caller n d hn hd hd2)
      simpa [truth,boolean,word,nonzero] using ASTLoops.StmtRun.skip (primeDivisor caller n d)
    · exact prime_trial_increment call caller n d hd
    · exact body

def pcSmall : Stmt := .branch (.binary "<" (.var "n") (.nat 2)) (.returnStmt (.nat 0)) .skip
def pcFor : Stmt := .forLoop (.declare [⟨"U","d",some (.nat 2)⟩])
  (some primeTrialCondition) primeTrialStep primeTrialBody

theorem pc_source_shape : f_pc_is_prime.body=
    .sequence [pcSmall,pcFor,.returnStmt (.nat 1)] := rfl

theorem pc_small_eval (call : Call) (caller : State) (n : Nat) (hn : n<2^64) :
    Eval call (.binary "<" (.var "n") (.nat 2))
      (primeParameter caller n) (primeParameter caller n) (boolean (decide (n<2))) := by
  have hnmod : n%18446744073709551616=n := Nat.mod_eq_of_lt hn
  simp [Eval,evalExpr,primeParameter,allocated_var,read_allocated,binaryValue,word,boolean,hnmod]

theorem pc_body_execution (call : Call) (caller : State) {n result : Nat}
    (execution : PrimeExec n result) :
    Run call f_pc_is_prime.body (primeParameter caller n)
      (.returned (primeParameter caller n) (word 32 result)) := by
  rcases execution with ⟨hn,execution⟩
  change n<2^64 at hn
  rw [pc_source_shape]
  by_cases small : n<2
  · have hr : result=0 := by simpa [small] using execution
    subst result
    apply ASTLoops.StmtRun.sequence
    · apply ASTLoops.SeqRun.returned
      apply ASTLoops.StmtRun.branch (pc_small_eval call caller n hn)
      simpa [truth,boolean,word,small] using ASTLoops.StmtRun.returnValue
        (eval_literal call (primeParameter caller n) 0 (by decide))
    · exact scope_self _ _
  · have trial : TrialExec n 2 result := by simpa [small] using execution
    obtain ⟨last,hLast,loop⟩ := pc_trial_for caller call trial hn (by decide) (by decide)
    have declare : Declare call [⟨"U","d",some (.nat 2)⟩]
        (primeParameter caller n) (primeDivisor caller n 2) := by
      simp [Declare,declarations,List.foldlM,evalExpr,castValue,asNat,word,primeDivisor]
    have start : Run call pcSmall (primeParameter caller n) (.continuing (primeParameter caller n)) := by
      apply ASTLoops.StmtRun.branch (pc_small_eval call caller n hn)
      simpa [truth,boolean,word,small] using ASTLoops.StmtRun.skip (primeParameter caller n)
    have forRun : Run call pcFor (primeParameter caller n)
        (pcTrialOutcome result (primeParameter caller n)) := by
      apply ASTLoops.StmtRun.forLoop (ASTLoops.StmtRun.declare declare) loop
      by_cases hr : result=0 <;>
        simp [Scope,scopeResult,pcTrialOutcome,hr,prime_pop_divisor]
    rcases trial_values trial with hr|hr
    · subst result
      apply ASTLoops.StmtRun.sequence
      · exact ASTLoops.SeqRun.next start (ASTLoops.SeqRun.returned forRun)
      · exact scope_self _ _
    · subst result
      apply ASTLoops.StmtRun.sequence
      · exact ASTLoops.SeqRun.next start (ASTLoops.SeqRun.next forRun
          (ASTLoops.SeqRun.returned (ASTLoops.StmtRun.returnValue
            (eval_literal call (primeParameter caller n) 1 (by decide)))))
      · exact scope_self _ _

/-- Actual looked-up C body, real parameter allocation, for-loop execution,
return cast and caller-scope restoration. This works under any callback
because the primality helper makes no source function calls. -/
theorem pc_is_prime_body_call (call : Call) (caller : State) {n result : Nat}
    (execution : PrimeExec n result) :
    BodyCall call "pc_is_prime" [word 64 n] caller (word 64 result) caller := by
  refine ⟨f_pc_is_prime,primeParameter caller n,primeParameter caller n,word 32 result,
    lookup_prime,?_,pc_body_execution call caller execution,?_,?_⟩
  · simp [bindArgs,f_pc_is_prime,List.foldlM,castValue,asNat,word,primeParameter]
  · rcases (prime_exec_correct execution).1 with hr|hr <;>
      subst result <;> simp [f_pc_is_prime,castValue,asNat,word]
  · exact (prime_pop_parameter caller n).symm

#print axioms pc_is_prime_body_call
end LCMSourcePV.Witness.AST
