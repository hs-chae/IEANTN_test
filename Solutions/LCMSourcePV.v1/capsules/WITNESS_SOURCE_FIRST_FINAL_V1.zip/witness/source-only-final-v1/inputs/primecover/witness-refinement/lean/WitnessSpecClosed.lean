import WitnessSpecCoherenceJoin
import WitnessASTChoose0Body

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C

theorem c0_source_body : C0SourceBody := by
  intro pf fit total lo stop p0 p1 p2 q1 q2 top out s result execution
  rcases execution with ⟨hn,htype,target,t,trace,effect,rfl⟩
  apply choose0_typed_call (lowerService specService 4) s t
    pf fit total lo stop p0 p1 p2 q1 q2 top out target hn htype
    (spec_prev_contract 4 (by decide)) (spec_productP_contract 4 (by decide))
    (spec_productQ_contract 4 (by decide)) (spec_shrink_contract 4 (by decide)) trace
  cases target <;> exact effect

/-- CLOSED source coherence: every successful finite-summary event executes
the actual looked-up C AST under strictly lower-rank source services. There
is no raw callback correctness, successful-execution or numerical assumption. -/
theorem spec_source_coherent : SourceCoherent specService :=
  spec_source_coherent_of_c0 c0_source_body

theorem spec_summary_actual_call_tree (event : CallEvent) (returned : Returns specService event) :
    ActualCallTree (callRank event.name+1) event :=
  source_summary_call_tree specService spec_source_coherent event returned

theorem constructor_actual_call_tree (final : C.RunState)
    (trace : C.RunFor C.initialRunState final) : ActualCallTree 8 (specRunEvent final) :=
  spec_run_tree_of_coherent spec_source_coherent final trace

#print axioms spec_source_coherent
#print axioms constructor_actual_call_tree
end LCMSourcePV.Witness.AST
