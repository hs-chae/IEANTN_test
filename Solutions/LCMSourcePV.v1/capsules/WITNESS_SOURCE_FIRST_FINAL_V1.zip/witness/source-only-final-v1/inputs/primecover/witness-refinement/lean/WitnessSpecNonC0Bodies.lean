import WitnessSpecLeafBodies
import WitnessASTShrinkFunction
import WitnessASTChoose1Body

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C E1TwoTracks.TrackB

theorem choose1_for_some {pf fit q0Fuel total lo stop p0 p1 p2 q2 k top : Nat}
    {result : Option Block}
    (h : Choose1For pf fit q0Fuel total lo stop p0 p1 p2 q2 k top result) :
    ∃b,result=some b := by
  induction h with
  | hit _ _ _ out => exact ⟨out,rfl⟩
  | skip _ _ _ _ _ _ _ _ _ ih => exact ih

def SpecInput.NonC0Body : SpecInput → Prop
 | .choose0 ..=>False | _=>True

theorem spec_non_c0_body (input : SpecInput) (s : State) {result : Value × State}
    (h : input.Run s result) (ready : input.NonC0Body) :
    BodyCall (lowerService specService (callRank input.name)) input.name input.args
      s result.1 result.2 := by
  by_cases leaf : input.LeafBody
  · exact spec_leaf_body input s h leaf
  · cases input <;> simp only [SpecInput.LeafBody,not_true_eq_false] at leaf
    case shrink fuel b out =>
      rcases h with ⟨hf,hb,target,t,trace,effect,rfl⟩
      exact shrink_call _ (spec_check_contract 3 (by decide)) s t fuel b target out hf hb trace effect
    case choose0 => exact False.elim ready
    case choose1 pf fit q0Fuel total lo stop p0 p1 p2 q2 top out =>
      rcases h with ⟨hn,target,t,trace,effect,rfl⟩
      obtain ⟨b,he⟩:=choose1_for_some trace
      subst target
      exact choose1_call _ s t pf fit q0Fuel total lo stop p0 p1 p2 q2 top out b hn
        (spec_prev_contract 5 (by decide)) (spec_choose0_contract 5 (by decide)) trace effect

#print axioms spec_non_c0_body
end LCMSourcePV.Witness.AST
