import WitnessSpecContracts
import WitnessASTSearchCalls
import WitnessASTProductCalls
import WitnessASTProductQCalls
import WitnessASTEndpointFunction
import WitnessASTCheckBody
import WitnessASTMakeRunFunction
import WitnessASTSqrt

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C E1TwoTracks.TrackB LCMSourcePV.PrimeCover

def SpecInput.LeafBody : SpecInput → Prop
 | .shrink ..=>False | .choose0 ..=>False | .choose1 ..=>False | _=>True

theorem spec_leaf_body (input : SpecInput) (s : State) {result : Value × State}
    (h : input.Run s result) (ready : input.LeafBody) :
    BodyCall (lowerService specService (callRank input.name)) input.name input.args
      s result.1 result.2 := by
  cases input with
  | prime n =>
    rcases h with ⟨r,run,rfl⟩
    exact pc_is_prime_body_call _ s run
  | sqrt n =>
    rcases h with ⟨r,run,rfl⟩
    exact sqrt_body _ s n r run
  | next total a out =>
    rcases h with ⟨ht,ha,p,t,run,effect,rfl⟩
    exact next_prime_body_call _ (spec_prime_contract 1 (by decide)) ht ha run effect
  | prev total a out =>
    rcases h with ⟨ht,ha,p,t,run,effect,rfl⟩
    exact prev_prime_body_call _ (spec_prime_contract 1 (by decide)) ht ha run effect
  | productP target writable =>
    rcases h with ⟨b,input,rfl⟩
    have hb:=input.2.2.2.2
    exact product_p_call _ s target b writable input.2.2.1 input.1 input.2.1 input.2.2.2.1
      (hb _ (by simp [blockFields])) (hb _ (by simp [blockFields])) (hb _ (by simp [blockFields]))
  | productQ target writable =>
    rcases h with ⟨b,input,rfl⟩
    have hb:=input.2.2.2.2
    exact product_q_call _ s target b writable input.2.2.1 input.1 input.2.1 input.2.2.2.1
      (hb _ (by simp [blockFields])) (hb _ (by simp [blockFields])) (hb _ (by simp [blockFields]))
  | endpoint target writable n =>
    rcases h with ⟨hn,b,r,input,run,rfl⟩
    exact endpoint_call _ s target b n r writable input hn
      (spec_productP_contract 1 (by decide)) (spec_productQ_contract 1 (by decide)) run
  | check target writable =>
    rcases h with ⟨b,r,input,run,rfl⟩
    exact check_call _ s target b r writable input
      (spec_productP_contract 2 (by decide)) (spec_productQ_contract 2 (by decide))
      (spec_prime_contract 2 (by decide)) (spec_endpoint_contract 2 (by decide)) run
  | shrink => exact False.elim ready
  | choose0 => exact False.elim ready
  | choose1 => exact False.elim ready
  | make pf fit q0Fuel q1Fuel lo stop out =>
    rcases h with ⟨hn,b,t,run,effect,rfl⟩
    exact make_call _ s t pf fit q0Fuel q1Fuel lo stop out b hn
      (spec_sqrt_contract 6 (by decide)) (spec_next_contract 6 (by decide))
      (spec_prev_contract 6 (by decide)) (spec_choose1_contract 6 (by decide)) run effect
  | makeRun lo out =>
    rcases h with ⟨hn,b,t,run,effect,rfl⟩
    exact make_call_run _ s t lo out b hn
      (spec_sqrt_contract 6 (by decide)) (spec_next_contract 6 (by decide))
      (spec_prev_contract 6 (by decide)) (spec_choose1_contract 6 (by decide)) run effect

#print axioms spec_leaf_body
end LCMSourcePV.Witness.AST
