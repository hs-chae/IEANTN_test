import WitnessASTChoose0For
import WitnessASTChoose0None

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.AST.Choose0
open LCMSourcePV.Witness.AST LCMSourcePV.Witness.C E1TwoTracks.TrackB LCMSourcePV.ASTLoops

theorem choose0_source_shape : f_choose_q0.body=.sequence [
    .forLoop (.declare [⟨"U","k",some (.nat 0)⟩]) (some guardExpr) stepExpr iterationBody,
    .returnStmt (.var "false")] := rfl

theorem body_some (call : Call) (caller after : State)
    (pf ff total lo stop p0 p1 p2 q1 q2 top : Nat) (address : Address) (out : Block)
    (hn : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2,top],n<2^64)
    (hPrev : PrevForContract call) (hP : ProductPContract call) (hQ : ProductQContract call)
    (hShrink : ShrinkContract call)
    (trace : Choose0For pf ff total lo stop p0 p1 p2 q1 q2 0 top (some out))
    (hw : WriteBlock caller address out after) :
    ∃finalTop,Run call f_choose_q0.body (params caller pf ff total lo stop p0 p1 p2 q1 q2 top address)
      (.returned (params after pf ff total lo stop p0 p1 p2 q1 q2 finalTop address) (bword true)) := by
  have hn0 : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2],n<2^64 := by
    intro n hmem
    exact hn n (List.mem_append_left [top] hmem)
  obtain ⟨finalK,finalTop,loopRun⟩:=for_some call pf ff total lo stop p0 p1 p2 q1 q2 address
    hn0 hPrev hP hQ hShrink trace caller after out rfl (hn top (by simp)) hw
  have init : Run call (.declare [⟨"U","k",some (.nat 0)⟩])
      (params caller pf ff total lo stop p0 p1 p2 q1 q2 top address)
      (.continuing (loop caller pf ff total lo stop p0 p1 p2 q1 q2 top address 0)) :=
    StmtRun.declare (by rfl)
  have forRun : Run call
      (.forLoop (.declare [⟨"U","k",some (.nat 0)⟩]) (some guardExpr) stepExpr iterationBody)
      (params caller pf ff total lo stop p0 p1 p2 q1 q2 top address)
      (.returned (params after pf ff total lo stop p0 p1 p2 q1 q2 finalTop address) (bword true)) :=
    StmtRun.forLoop init loopRun
      (congrArg (fun s=>Flow.returned s (bword true))
        (pop_loop caller after pf ff total lo stop p0 p1 p2 q1 q2 top finalTop address finalK
          (write_shape hw).1).symm)
  refine ⟨finalTop,?_⟩
  rw [choose0_source_shape]
  exact StmtRun.sequence (SeqRun.returned forRun)
    (congrArg (fun s=>Flow.returned s (bword true))
      (pop_params caller after pf ff total lo stop p0 p1 p2 q1 q2 top finalTop address
        (write_shape hw).1).symm)

theorem body_none (call : Call) (caller : State)
    (pf ff total lo stop p0 p1 p2 q1 q2 top : Nat) (address : Address)
    (hn : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2,top],n<2^64)
    (hPrev : PrevForContract call) (hP : ProductPContract call) (hQ : ProductQContract call)
    (hShrink : ShrinkContract call)
    (trace : Choose0For pf ff total lo stop p0 p1 p2 q1 q2 0 top none) :
    ∃finalTop,Run call f_choose_q0.body (params caller pf ff total lo stop p0 p1 p2 q1 q2 top address)
      (.returned (params caller pf ff total lo stop p0 p1 p2 q1 q2 finalTop address) (bword false)) := by
  have hn0 : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2],n<2^64 := by
    intro n hmem
    exact hn n (List.mem_append_left [top] hmem)
  obtain ⟨finalK,finalTop,loopRun⟩:=for_none call pf ff total lo stop p0 p1 p2 q1 q2 address
    hn0 hPrev hP hQ hShrink trace caller rfl (by decide) (hn top (by simp))
  have init : Run call (.declare [⟨"U","k",some (.nat 0)⟩])
      (params caller pf ff total lo stop p0 p1 p2 q1 q2 top address)
      (.continuing (loop caller pf ff total lo stop p0 p1 p2 q1 q2 top address 0)) :=
    StmtRun.declare (by rfl)
  have forRun : Run call
      (.forLoop (.declare [⟨"U","k",some (.nat 0)⟩]) (some guardExpr) stepExpr iterationBody)
      (params caller pf ff total lo stop p0 p1 p2 q1 q2 top address)
      (.continuing (params caller pf ff total lo stop p0 p1 p2 q1 q2 finalTop address)) :=
    StmtRun.forLoop init loopRun
      (congrArg Flow.continuing
        (pop_loop caller caller pf ff total lo stop p0 p1 p2 q1 q2 top finalTop address finalK rfl).symm)
  have ret : Eval call (.var "false") (params caller pf ff total lo stop p0 p1 p2 q1 q2 finalTop address)
      (params caller pf ff total lo stop p0 p1 p2 q1 q2 finalTop address) (bword false) := by rfl
  refine ⟨finalTop,?_⟩
  rw [choose0_source_shape]
  exact StmtRun.sequence (SeqRun.next forRun (SeqRun.returned (StmtRun.returnValue ret)))
    (congrArg (fun s=>Flow.returned s (bword false))
      (pop_params caller caller pf ff total lo stop p0 p1 p2 q1 q2 top finalTop address rfl).symm)

#print axioms body_some
#print axioms body_none
end LCMSourcePV.Witness.AST.Choose0

namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C E1TwoTracks.TrackB

theorem typed_address_bound {s : State} {a : Address} {type : String}
    (h : addressType s a=some type) : a.object<s.heap.length := by
  by_contra bad
  have ho : s.heap[a.object]?=none:=List.getElem?_eq_none (by omega)
  simp [addressType,ho] at h

theorem choose0_typed_call (call : Call) (caller after : State)
    (pf ff total lo stop p0 p1 p2 q1 q2 top : Nat) (address : Address) (result : Option Block)
    (hn : ∀n∈[pf,ff,total,lo,stop,p0,p1,p2,q1,q2,top],n<2^64)
    (ht : addressType caller address=some "Block")
    (hPrev : PrevForContract call) (hP : ProductPContract call) (hQ : ProductQContract call)
    (hShrink : ShrinkContract call)
    (trace : Choose0For pf ff total lo stop p0 p1 p2 q1 q2 0 top result)
    (effect : match result with | none=>after=caller | some b=>WriteBlock caller address b after) :
    BodyCall call "choose_q0" [word 64 pf,word 64 ff,word 64 total,word 64 lo,word 64 stop,
      word 64 p0,word 64 p1,word 64 p2,word 64 q1,word 64 q2,word 64 top,.pointer address true]
      caller (bword result.isSome) after := by
  cases result with
  | none =>
    simp only at effect
    subst after
    exact choose0_call_none_of_body call caller pf ff total lo stop p0 p1 p2 q1 q2 top address
      ht (typed_address_bound ht)
      (Choose0.body_none call caller pf ff total lo stop p0 p1 p2 q1 q2 top address hn hPrev hP hQ hShrink trace)
  | some out =>
    exact choose0_call_of_body call caller after pf ff total lo stop p0 p1 p2 q1 q2 top address out effect
      (Choose0.body_some call caller after pf ff total lo stop p0 p1 p2 q1 q2 top address out hn hPrev hP hQ hShrink trace effect)

#print axioms choose0_typed_call
end LCMSourcePV.Witness.AST
