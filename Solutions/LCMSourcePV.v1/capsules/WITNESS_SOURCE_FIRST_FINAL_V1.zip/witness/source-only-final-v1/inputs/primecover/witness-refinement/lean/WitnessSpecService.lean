import WitnessSpecUnique

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C E1TwoTracks.TrackB LCMSourcePV.PrimeCover

/-- A proof-only partial service. An output exists exactly when a finite
source-loop/typed-memory summary proves it. The source C program never calls
this Lean function. Unsupported summaries return none and are not interpreted
as C false returns. Actual AST body/coherence proofs must independently close
every successful event before this service can justify a source-call tree. -/
noncomputable def specService : Call := by
  classical
  exact fun name args s=> if h : ∃result,SpecSummary name args s result then some (Classical.choose h) else none

theorem spec_service_sound {name : String} {args : List Value} {s : State} {result : Value × State}
    (h : specService name args s=some result) : SpecSummary name args s result := by
  unfold specService at h
  split at h
  · rename_i existsResult
    have eqr:=Option.some.inj h
    rw [←eqr]
    exact Classical.choose_spec existsResult
  · cases h

theorem spec_service_complete {name : String} {args : List Value} {s : State} {result : Value × State}
    (h : SpecSummary name args s result) : specService name args s=some result := by
  have hx : ∃out,SpecSummary name args s out:=⟨result,h⟩
  rw [specService,dif_pos hx]
  exact congrArg some (spec_summary_unique (Classical.choose_spec hx) h)

theorem spec_lower_complete {name : String} {args : List Value} {s : State} {result : Value × State}
    {rank : Nat} (lower : callRank name<rank) (h : SpecSummary name args s result) :
    lowerService specService rank name args s=some result := by
  rw [lowerService,if_pos lower]
  exact spec_service_complete h

#print axioms spec_service_complete
end LCMSourcePV.Witness.AST
