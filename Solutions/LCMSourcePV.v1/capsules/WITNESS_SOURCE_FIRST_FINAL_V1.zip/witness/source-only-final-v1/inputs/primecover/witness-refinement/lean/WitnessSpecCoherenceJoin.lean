import WitnessSpecNonC0Bodies
import WitnessSpecRunJoin

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C

/-- The last modular join input is an actual lower-rank AST body proof, not a
callback return assumption. A separate final module supplies this from the
source-proved typed choose_q0 body, leaving no premise in final coherence. -/
def C0SourceBody : Prop :=
  ∀pf fit total lo stop p0 p1 p2 q1 q2 top out s result,
    (SpecInput.choose0 pf fit total lo stop p0 p1 p2 q1 q2 top out).Run s result →
    BodyCall (lowerService specService 4) "choose_q0"
      (SpecInput.choose0 pf fit total lo stop p0 p1 p2 q1 q2 top out).args
      s result.1 result.2

theorem spec_source_coherent_of_c0 (c0 : C0SourceBody) : SourceCoherent specService := by
  intro event returned
  cases event with
  | mk name args before value after =>
    have hs : SpecSummary name args before (value,after):=spec_service_sound returned
    rcases hs with ⟨input,rfl,rfl,execution⟩
    by_cases ready : input.NonC0Body
    · exact spec_non_c0_body input before execution ready
    · cases input <;> simp only [SpecInput.NonC0Body,not_true_eq_false] at ready
      case choose0 pf fit total lo stop p0 p1 p2 q1 q2 top out =>
        exact c0 pf fit total lo stop p0 p1 p2 q1 q2 top out before (value,after) execution

#print axioms spec_source_coherent_of_c0
end LCMSourcePV.Witness.AST
