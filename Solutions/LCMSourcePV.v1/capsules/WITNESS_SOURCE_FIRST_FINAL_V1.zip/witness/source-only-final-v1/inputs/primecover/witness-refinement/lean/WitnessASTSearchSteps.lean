import WitnessASTSearchFrames

set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.PrimeCover

@[simp] theorem search_eval_fuel (call : Call) (caller : State) (total a : Nat) (out : Address) (k fuel : Nat) :
    evalExpr call (fuel+1) (searchFrame caller total a out k) (.var "fuel") =
      some (word 64 total,searchFrame caller total a out k) := by
  simp [evalExpr]
@[simp] theorem search_eval_a (call : Call) (caller : State) (total a : Nat) (out : Address) (k fuel : Nat) :
    evalExpr call (fuel+1) (searchFrame caller total a out k) (.var "a") =
      some (word 64 a,searchFrame caller total a out k) := by simp [evalExpr]
@[simp] theorem search_eval_out (call : Call) (caller : State) (total a : Nat) (out : Address) (k fuel : Nat) :
    evalExpr call (fuel+1) (searchFrame caller total a out k) (.var "out") =
      some (.pointer out true,searchFrame caller total a out k) := by simp [evalExpr]
@[simp] theorem search_eval_k (call : Call) (caller : State) (total a : Nat) (out : Address) (k fuel : Nat) :
    evalExpr call (fuel+1) (searchFrame caller total a out k) (.var "k") =
      some (word 64 k,searchFrame caller total a out k) := by simp [evalExpr]

def searchGuard : Expr := .binary "<" (.var "k") (.var "fuel")
def searchPrime : Expr := .call (.var "pc_is_prime") [.var "a"]
def searchWrite : Expr := .binary "=" (.unary "*" (.var "out")) (.var "a")
def searchKStep : Expr := .unary "++" (.var "k")
def searchAStep : Expr := .unary "++" (.var "a")
def searchADown : Expr := .unary "--" (.var "a")
def searchNextStep : Expr := .binary "," searchKStep searchAStep

theorem search_guard (call : Call) (caller : State) (total a k : Nat) (out : Address)
    (ht : total<2^64) (hk : k<2^64) :
    Eval call searchGuard (searchFrame caller total a out k) (searchFrame caller total a out k)
      (boolean (decide (k<total))) := by
  have htmod : total%18446744073709551616=total := Nat.mod_eq_of_lt ht
  have hkmod : k%18446744073709551616=k := Nat.mod_eq_of_lt hk
  simp [Eval,evalExpr,searchGuard,binaryValue,word,boolean,htmod,hkmod]

theorem search_prime (call : Call) (contract : PrimeContract call) (caller : State)
    (total a k result : Nat) (out : Address) (execution : PrimeExec a result) :
    Eval call searchPrime (searchFrame caller total a out k) (searchFrame caller total a out k)
      (word 64 result) := by
  simpa [Eval,searchPrime,evalExpr,List.foldlM] using
    contract (searchFrame caller total a out k) a result execution

theorem search_write {caller after : State} {p : Nat} {out : Address}
    (effect : WriteNat caller out p after) (call : Call) (total k : Nat) :
    Eval call searchWrite (searchFrame caller total p out k) (searchFrame after total p out k)
      (word 64 p) := by
  have frameWrite := effect.searchFrame total p k
  have bound := frameWrite.target_type
  simpa [Eval,searchWrite,evalExpr,evalLValue,bound,WriteNat] using frameWrite

theorem search_k_increment (call : Call) (caller : State) (total a k : Nat) (out : Address)
    (hk : k<2^64) :
    evalExpr call 999 (searchFrame caller total a out k) searchKStep =
      some (word 64 (bump k),searchFrame caller total a out (bump k)) := by
  have hkmod : k%18446744073709551616=k := Nat.mod_eq_of_lt hk
  simpa [evalExpr,evalLValue,searchKStep,searchFrame,allocated_var,read_allocated,word,bump,wordMod,hkmod] using
    write_allocated_word (searchParameters caller total a out) "k" k (k+1)

theorem search_k_step (call : Call) (caller : State) (total a k : Nat) (out : Address)
    (hk : k<2^64) :
    Eval call searchKStep (searchFrame caller total a out k)
      (searchFrame caller total a out (bump k)) (word 64 (bump k)) := by
  have hkmod : k%18446744073709551616=k := Nat.mod_eq_of_lt hk
  simpa [Eval,evalExpr,evalLValue,searchKStep,searchFrame,allocated_var,read_allocated,
    word,bump,wordMod,hkmod] using
    write_allocated_word (searchParameters caller total a out) "k" k (k+1)

theorem search_write_a (caller : State) (total a k v : Nat) (out : Address) :
    write (searchFrame caller total a out k) ⟨caller.heap.length+1,0,none⟩ true (word 64 v) =
      some (word 64 v,searchFrame caller total v out k) := by
  have cell : (searchFrame caller total a out k).heap[caller.heap.length+1]?=
      some ⟨"U",[some (word 64 a)]⟩ := by
    simp [searchFrame,searchParameters,searchExtra,frameState,allocate]
  rw [write_scalar _ _ _ _ cell]
  congr 1
  simp [searchFrame,searchParameters,searchExtra,frameState,allocate,List.set_append_right,
    List.append_assoc]

theorem search_frame_mod_a (caller : State) (total a k : Nat) (out : Address) :
    searchFrame caller total (a%2^64) out k=searchFrame caller total a out k := by
  simp [searchFrame,searchParameters,searchExtra,frameState,word]

theorem search_a_increment (call : Call) (caller : State) (total a k : Nat) (out : Address)
    (ha : a<2^64) :
    evalExpr call 999 (searchFrame caller total a out k) searchAStep =
      some (word 64 (bump a),searchFrame caller total (bump a) out k) := by
  have hamod : a%18446744073709551616=a := Nat.mod_eq_of_lt ha
  change (do let (address,writable,t)←evalLValue call 998 (searchFrame caller total a out k) (.var "a")
             let .word width n←read t address | none
             write t address writable (word width (n+1)))=_
  simp only [evalLValue,search_name_a,bind,pure,Option.bind_some,search_read_a,word]
  change write _ _ _ (word 64 (a%2^64+1))=_
  rw [Nat.mod_eq_of_lt ha]
  have h:=search_write_a caller total a k (bump a) out
  simpa only [bump,wordMod,word,Nat.mod_mod,search_frame_mod_a] using h

theorem search_a_decrement (call : Call) (caller : State) (total a k : Nat) (out : Address)
    (ha : a<2^64) :
    Eval call searchADown (searchFrame caller total a out k)
      (searchFrame caller total ((a+wordMod-1)%wordMod) out k)
      (word 64 ((a+wordMod-1)%wordMod)) := by
  change (do let (address,writable,t)←evalLValue call 999 (searchFrame caller total a out k) (.var "a")
             let .word width n←read t address | none
             write t address writable (word width (n+2^width-1)))=_
  simp only [evalLValue,search_name_a,bind,pure,Option.bind_some,search_read_a,word]
  change write _ _ _ (word 64 (a%2^64+2^64-1))=_
  rw [Nat.mod_eq_of_lt ha]
  have h:=search_write_a caller total a k ((a+wordMod-1)%wordMod) out
  simpa only [wordMod,word,Nat.mod_mod,search_frame_mod_a] using h

theorem search_next_increment (call : Call) (caller : State) (total a k : Nat) (out : Address)
    (ha : a<2^64) (hk : k<2^64) :
    Eval call searchNextStep (searchFrame caller total a out k)
      (searchFrame caller total (bump a) out (bump k)) (word 64 (bump a)) := by
  change (do let (_,t)←evalExpr call 999 (searchFrame caller total a out k) searchKStep
             evalExpr call 999 t searchAStep)=_
  rw [search_k_increment call caller total a k out hk]
  exact search_a_increment call caller total a (bump k) out ha

theorem search_zero_test (call : Call) (caller : State) (total a k : Nat) (out : Address)
    (ha : a<2^64) :
    Eval call (.binary "==" (.var "a") (.nat 0))
      (searchFrame caller total a out k) (searchFrame caller total a out k)
      (boolean (decide (a=0))) := by
  have hamod : a%18446744073709551616=a := Nat.mod_eq_of_lt ha
  simp [Eval,evalExpr,binaryValue,word,boolean,hamod]

#print axioms search_write
#print axioms search_next_increment
end LCMSourcePV.Witness.AST
