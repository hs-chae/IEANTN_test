import WitnessASTSearchBodies

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.PrimeCover

theorem next_for_source (call : Call) (contract : PrimeContract call) (caller after : State)
    (out : Address) (total : Nat) (ht : total<2^64) :
    ∀k a output, NextFor total k a output → ∀p, output=some p → WriteNat caller out p after →
    k<2^64 → a<2^64 →
    ∃last, ForRun call (some searchGuard) searchNextStep nextSearchBody
      (searchFrame caller total a out k) (.returned (searchFrame after total p out last) (bword true)) := by
  intro k a output execution
  induction execution with
  | done k a guard => intro p h; cases h
  | found k a guard execution =>
    intro p h effect hk ha
    cases h
    refine ⟨k,ASTLoops.ForRun.returned ?_ (next_found_body effect call contract total k execution)⟩
    simpa [truth,word,boolean,guard] using ASTLoops.GuardRun.present (truth:=truth)
      (search_guard call caller total a k out ht hk)
  | step k a output guard execution rest ih =>
    intro p h effect hk ha
    have hkNext : (k+1)%wordMod<2^64 := Nat.mod_lt _ (by decide)
    have haNext : (a+1)%wordMod<2^64 := Nat.mod_lt _ (by decide)
    obtain ⟨last,loop⟩ := ih p h effect hkNext haNext
    refine ⟨last,ASTLoops.ForRun.next ?_ (next_miss_body call contract caller total a k out execution)
      (search_next_increment call caller total a k out ha hk) loop⟩
    simpa [truth,word,boolean,guard] using ASTLoops.GuardRun.present (truth:=truth)
      (search_guard call caller total a k out ht hk)

theorem prev_for_source (call : Call) (contract : PrimeContract call) (caller after : State)
    (out : Address) (total : Nat) (ht : total<2^64) :
    ∀k a output, PrevFor total k a output → ∀p, output=some p → WriteNat caller out p after →
    k<2^64 → a<2^64 →
    ∃last, ForRun call (some searchGuard) searchKStep prevSearchBody
      (searchFrame caller total a out k) (.returned (searchFrame after total p out last) (bword true)) := by
  intro k a output execution
  induction execution with
  | done k a guard => intro p h; cases h
  | found k a guard execution =>
    intro p h effect hk ha
    cases h
    refine ⟨k,ASTLoops.ForRun.returned ?_ (prev_found_body effect call contract total k execution)⟩
    simpa [truth,word,boolean,guard] using ASTLoops.GuardRun.present (truth:=truth)
      (search_guard call caller total a k out ht hk)
  | zero k guard execution => intro p h; cases h
  | step k a output guard execution nonzero rest ih =>
    intro p h effect hk ha
    have hkNext : (k+1)%wordMod<2^64 := Nat.mod_lt _ (by decide)
    have haNext : (a+wordMod-1)%wordMod<2^64 := Nat.mod_lt _ (by decide)
    obtain ⟨last,loop⟩ := ih p h effect hkNext haNext
    refine ⟨last,ASTLoops.ForRun.next ?_ (prev_miss_body call contract caller total a k out execution ha nonzero)
      (search_k_step call caller total _ k out hk) loop⟩
    simpa [truth,word,boolean,guard] using ASTLoops.GuardRun.present (truth:=truth)
      (search_guard call caller total a k out ht hk)

#print axioms next_for_source
#print axioms prev_for_source
end LCMSourcePV.Witness.AST
