import WitnessSpecService

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C E1TwoTracks.TrackB LCMSourcePV.PrimeCover

theorem spec_prime_contract (rank : Nat) (hr : 0<rank) :
    PrimeContract (lowerService specService rank) := by
  intro s n result run
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.prime n,rfl,rfl,result,run,rfl⟩

theorem spec_sqrt_contract (rank : Nat) (hr : 0<rank) :
    SqrtContract (lowerService specService rank) := by
  intro s n result run
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.sqrt n,rfl,rfl,result,run,rfl⟩

theorem spec_next_contract (rank : Nat) (hr : 1<rank) :
    NextForContract (lowerService specService rank) := by
  intro s total a p address t ht ha run effect
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.next total a address,rfl,rfl,ht,ha,p,t,run,effect,rfl⟩

theorem spec_prev_contract (rank : Nat) (hr : 1<rank) :
    PrevForContract (lowerService specService rank) := by
  intro s total a p address t ht ha run effect
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.prev total a address,rfl,rfl,ht,ha,p,t,run,effect,rfl⟩

theorem spec_productP_contract (rank : Nat) (hr : 0<rank) :
    ProductPContract (lowerService specService rank) := by
  intro s a b writable input
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.productP a writable,rfl,rfl,b,input,rfl⟩

theorem spec_productQ_contract (rank : Nat) (hr : 0<rank) :
    ProductQContract (lowerService specService rank) := by
  intro s a b writable input
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.productQ a writable,rfl,rfl,b,input,rfl⟩

theorem spec_endpoint_contract (rank : Nat) (hr : 1<rank) :
    EndpointContract (lowerService specService rank) := by
  intro s a b writable n result input hn run
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.endpoint a writable n,rfl,rfl,hn,b,result,input,run,rfl⟩

theorem spec_check_contract (rank : Nat) (hr : 2<rank) :
    CheckContract (lowerService specService rank) := by
  intro s a b writable result input run
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.check a writable,rfl,rfl,b,result,input,run,rfl⟩

theorem spec_shrink_contract (rank : Nat) (hr : 3<rank) :
    ShrinkContract (lowerService specService rank) := by
  intro s fuel b out address t hf hb run effect
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.shrink fuel b address,rfl,rfl,hf,hb,out,t,run,effect,rfl⟩

theorem spec_choose0_contract (rank : Nat) (hr : 4<rank) :
    TypedChoose0Contract (lowerService specService rank) := by
  intro s pf fit total lo stop p0 p1 p2 q1 q2 top result address t hn htype run effect
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.choose0 pf fit total lo stop p0 p1 p2 q1 q2 top address,rfl,rfl,
    hn,htype,result,t,run,effect,rfl⟩

theorem spec_choose1_contract (rank : Nat) (hr : 5<rank) :
    Choose1Contract (lowerService specService rank) := by
  intro s pf fit q0Fuel total lo stop p0 p1 p2 q2 top result address t hn run effect
  apply spec_lower_complete (by simpa [callRank] using hr)
  refine ⟨.choose1 pf fit q0Fuel total lo stop p0 p1 p2 q2 top address,rfl,rfl,
    hn,result,t,run,?_,rfl⟩
  cases result <;> exact effect

theorem spec_make_contract (rank : Nat) (hr : 6<rank) :
    MakeContract (lowerService specService rank) := by
  intro s pf fit q0Fuel q1Fuel lo stop out address t hn run effect
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.make pf fit q0Fuel q1Fuel lo stop address,rfl,rfl,hn,out,t,run,effect,rfl⟩

theorem spec_make_run_contract (rank : Nat) (hr : 6<rank) :
    MakeRunContract (lowerService specService rank) := by
  intro s lo out address t hn run effect
  apply spec_lower_complete (by simpa [callRank] using hr)
  exact ⟨.makeRun lo address,rfl,rfl,hn,out,t,run,effect,rfl⟩

#print axioms spec_make_run_contract
#print axioms spec_choose0_contract
end LCMSourcePV.Witness.AST
