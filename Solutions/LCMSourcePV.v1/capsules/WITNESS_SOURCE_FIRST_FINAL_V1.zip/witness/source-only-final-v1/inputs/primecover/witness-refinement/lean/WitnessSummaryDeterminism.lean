import WitnessCControl

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.C
open LCMSourcePV.PrimeCover E1TwoTracks.TrackB

theorem prime_result_unique {n a b : Nat} (ha : PrimeExec n a) (hb : PrimeExec n b) : a=b := by
  have ca:=prime_exec_correct ha
  have cb:=prime_exec_correct hb
  rcases ca.1 with h|h <;> rcases cb.1 with k|k <;> simp_all

theorem next_result_unique {total k a : Nat} {left right : Option Nat}
    (hl : NextFor total k a left) (hr : NextFor total k a right) : left=right := by
  induction hl generalizing right with
  | done k a guard => cases hr <;> simp_all
  | found k a guard prime =>
    cases hr with
    | done _ _ stop => exact False.elim (stop guard)
    | found => rfl
    | step _ _ _ _ other _ => have h:=prime_result_unique prime other; cases h
  | step k a out guard prime rest ih =>
    cases hr with
    | done _ _ stop => exact False.elim (stop guard)
    | found _ _ _ other => have h:=prime_result_unique prime other; cases h
    | step _ _ _ _ _ other => exact ih other

theorem prev_result_unique {total k a : Nat} {left right : Option Nat}
    (hl : PrevFor total k a left) (hr : PrevFor total k a right) : left=right := by
  induction hl generalizing right with
  | done k a guard => cases hr <;> simp_all
  | found k a guard prime =>
    cases hr with
    | done _ _ stop => exact False.elim (stop guard)
    | found => rfl
    | zero _ _ other => have h:=prime_result_unique prime other; cases h
    | step _ _ _ _ other _ _ => have h:=prime_result_unique prime other; cases h
  | zero k guard prime =>
    cases hr with
    | done _ _ stop => exact False.elim (stop guard)
    | found _ _ _ other => have h:=prime_result_unique prime other; cases h
    | zero => rfl
    | step _ _ _ _ _ nonzero _ => exact False.elim (nonzero rfl)
  | step k a out guard prime nonzero rest ih =>
    cases hr with
    | done _ _ stop => exact False.elim (stop guard)
    | found _ _ _ other => have h:=prime_result_unique prime other; cases h
    | zero => exact False.elim (nonzero rfl)
    | step _ _ _ _ _ _ other => exact ih other

theorem check_result_unique {b : Block} {left right : Bool}
    (hl : CheckExec b left) (hr : CheckExec b right) : left=right := by
  cases hl <;> cases hr <;> simp_all

theorem shrink_result_unique {total k : Nat} {b left right : Block}
    (hl : ShrinkFor total k b left) (hr : ShrinkFor total k b right) : left=right := by
  induction hl generalizing right with
  | hit k b check =>
    cases hr with
    | hit => rfl
    | step _ _ _ other _ _ _ _ => have h:=check_result_unique check other; cases h
  | step k b out check hf hhi hk rest ih =>
    cases hr with
    | hit _ _ other => have h:=check_result_unique check other; cases h
    | step _ _ _ _ _ _ _ other => exact ih other

#print axioms prev_result_unique
#print axioms shrink_result_unique
end LCMSourcePV.Witness.C
