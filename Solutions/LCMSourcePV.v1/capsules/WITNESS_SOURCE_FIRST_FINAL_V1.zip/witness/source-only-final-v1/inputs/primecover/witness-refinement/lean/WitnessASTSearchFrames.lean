import WitnessASTPrimeBody
import WitnessASTFrameEffects

set_option autoImplicit false
set_option maxHeartbeats 0
set_option maxRecDepth 10000
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.PrimeCover

theorem cast_word64_target {s : State} {type : String} {n : Nat}
    (h : castValue s type (word 64 n)=some (word 64 n)) : type="U" := by
  unfold castValue at h
  split_ifs at h <;> simp_all [asNat,word]

/-- A successful uint64 out write establishes its pointee type, but imposes
no assumption that the out cell had any particular initial value. -/
theorem WriteNat.target_type {s t : State} {a : Address} {n : Nat}
    (writeNat : WriteNat s a n t) : addressType s a=some "U" := by
  have h := writeNat
  simp only [WriteNat,write,Bool.not_true,Bool.false_eq_true,ite_false,
    bind,pure,Option.bind_eq_some_iff,Option.some.injEq] at h
  rcases h with ⟨type,ht,represented,hc,obj,ho,h⟩
  have represented_eq : represented=word 64 n := by
    cases hf:a.field with
    | none =>
      simp only [hf,Option.bind_some,Option.some.injEq] at h
      exact congrArg Prod.fst h
    | some field =>
      cases hr:read s {a with field:=none} with
      | none => simp [hf,hr] at h
      | some value =>
        cases value with
        | word w value => simp [hf,hr] at h
        | pointer ptr writable => simp [hf,hr] at h
        | block block =>
          simp only [hf,hr,Option.bind_some,bind,pure,Option.bind_eq_some_iff,Option.some.injEq] at h
          rcases h with ⟨i,hi,value,hvalue,changed,hchanged,effect⟩
          exact congrArg Prod.fst effect
  rw [represented_eq] at hc
  simpa [cast_word64_target hc] using ht

def searchExtra (total a : Nat) (out : Address) : List Object :=
  [⟨"U",[some (word 64 total)]⟩,⟨"U",[some (word 64 a)]⟩,
    ⟨"U*",[some (.pointer out true)]⟩]
def searchEnv (caller : State) : Env :=
  [("out",⟨caller.heap.length+2,0,none⟩),("a",⟨caller.heap.length+1,0,none⟩),
    ("fuel",⟨caller.heap.length,0,none⟩)]
def searchParameters (caller : State) (total a : Nat) (out : Address) : State :=
  frameState caller (searchExtra total a out) (searchEnv caller)
def searchFrame (caller : State) (total a : Nat) (out : Address) (k : Nat) : State :=
  allocate (searchParameters caller total a out) "U" "k" (some (word 64 k))

theorem search_parameter_allocations (caller : State) (total a : Nat) (out : Address) :
    searchParameters caller total a out =
      allocate (allocate (allocate {caller with env:=[]} "U" "fuel" (some (word 64 total)))
        "U" "a" (some (word 64 a))) "U*" "out" (some (.pointer out true)) := by
  cases caller
  simp [searchParameters,searchExtra,searchEnv,frameState,allocate,List.append_assoc]

theorem search_frame_as_frame (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    searchFrame caller total a out k =
      frameState caller (searchExtra total a out++[⟨"U",[some (word 64 k)]⟩])
        (("k",⟨caller.heap.length+3,0,none⟩)::searchEnv caller) := by
  simp [searchFrame,searchParameters,searchExtra,frameState,allocate,List.append_assoc]

@[simp] theorem search_name_k (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    getVar (searchFrame caller total a out k) "k"=
      some ⟨(searchParameters caller total a out).heap.length,0,none⟩ :=
  allocated_var (searchParameters caller total a out) "U" "k" (some (word 64 k))
@[simp] theorem search_read_k (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    read (searchFrame caller total a out k) ⟨(searchParameters caller total a out).heap.length,0,none⟩=
      some (word 64 k) := read_allocated (searchParameters caller total a out) "U" "k" (word 64 k)

@[simp] theorem search_name_fuel (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    getVar (searchFrame caller total a out k) "fuel"=some ⟨caller.heap.length,0,none⟩ := by
  simp [searchFrame,getVar,allocate,searchParameters,frameState,searchEnv]
@[simp] theorem search_name_a (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    getVar (searchFrame caller total a out k) "a"=some ⟨caller.heap.length+1,0,none⟩ := by
  simp [searchFrame,getVar,allocate,searchParameters,frameState,searchEnv]
@[simp] theorem search_name_out (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    getVar (searchFrame caller total a out k) "out"=some ⟨caller.heap.length+2,0,none⟩ := by
  simp [searchFrame,getVar,allocate,searchParameters,frameState,searchEnv]

@[simp] theorem search_read_fuel (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    read (searchFrame caller total a out k) ⟨caller.heap.length,0,none⟩=some (word 64 total) := by
  simp [searchFrame,searchParameters,searchExtra,frameState,read,allocate,List.getElem?_append]
@[simp] theorem search_read_a (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    read (searchFrame caller total a out k) ⟨caller.heap.length+1,0,none⟩=some (word 64 a) := by
  simp [searchFrame,searchParameters,searchExtra,frameState,read,allocate,List.getElem?_append]
@[simp] theorem search_read_out (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    read (searchFrame caller total a out k) ⟨caller.heap.length+2,0,none⟩=some (.pointer out true) := by
  simp [searchFrame,searchParameters,searchExtra,frameState,read,allocate,List.getElem?_append]

theorem WriteNat.searchFrame {s t : State} {address : Address} {p : Nat}
    (h : WriteNat s address p t) (total a k : Nat) :
    WriteNat (searchFrame s total a address k) address p (searchFrame t total a address k) := by
  rw [search_frame_as_frame,search_frame_as_frame]
  have hs := (write_shape h).1
  have env : searchEnv t=searchEnv s := by simp [searchEnv,hs]
  simpa [env,hs] using h.inFrame (searchExtra total a address++[⟨"U",[some (word 64 k)]⟩])
    (("k",⟨s.heap.length+3,0,none⟩)::searchEnv s)

theorem search_pop_k (caller : State) (total a : Nat) (out : Address) (k : Nat) :
    popScope (searchParameters caller total a out) (searchFrame caller total a out k)=
      searchParameters caller total a out :=
  pop_allocate (searchParameters caller total a out) "U" "k" (some (word 64 k))

#print axioms WriteNat.target_type
#print axioms WriteNat.searchFrame
end LCMSourcePV.Witness.AST
