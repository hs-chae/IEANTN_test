import WitnessSpecContracts
import WitnessASTRunFunction

set_option autoImplicit false
set_option maxHeartbeats 0
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C

def specRunEvent (final : C.RunState) : CallEvent :=
  ⟨"run_exact",[outPointer,countPointer],runAllocated,word 1 1,runCaller final⟩

/-- The fixed constructor run body is actual source AST execution under the
strictly lower-rank, finite-summary-backed make service. -/
theorem spec_run_ranked_body (final : C.RunState) (trace : C.RunFor C.initialRunState final) :
    RankedBodyCall specService (specRunEvent final) :=
  run_exact_body (lowerService specService 7) (spec_make_run_contract 7 (by decide)) final trace

/-- Intermediate composition lemma. The final source package must supply the
closed specService coherence theorem; no coherence premise is called an axiom. -/
theorem spec_run_tree_of_coherent (coherent : SourceCoherent specService)
    (final : C.RunState) (trace : C.RunFor C.initialRunState final) :
    ActualCallTree 8 (specRunEvent final) :=
  body_call_tree_adequacy specService coherent 8 (specRunEvent final) (by change 7<8; decide)
    (spec_run_ranked_body final trace)

#print axioms spec_run_ranked_body
end LCMSourcePV.Witness.AST
