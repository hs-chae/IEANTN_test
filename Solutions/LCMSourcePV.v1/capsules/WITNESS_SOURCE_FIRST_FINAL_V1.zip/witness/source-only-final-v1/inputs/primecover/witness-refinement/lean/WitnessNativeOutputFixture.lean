import WitnessNativeFixture
import WitnessMainVerified
set_option maxHeartbeats 0
set_option maxRecDepth 200000
namespace LCMSourcePV.Witness.AST.NativeFixture
/-- Every row compared by the standalone C replay is exactly the decoded
mathematical consumer's proved source-main stdout row, not a separate table. -/
theorem actual_stdout_rows_match_fixture : Main.sourceProgram.rows=expectedRows :=
  source_rows_match_fixture
#print axioms actual_stdout_rows_match_fixture
end LCMSourcePV.Witness.AST.NativeFixture
