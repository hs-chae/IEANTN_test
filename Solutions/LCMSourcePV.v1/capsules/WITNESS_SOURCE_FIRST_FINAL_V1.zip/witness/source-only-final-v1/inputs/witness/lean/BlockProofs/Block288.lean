/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_288 : Block := (Block.mk 5480281 5508408 2347 2351 2357 5479921 5480249 5480269)
theorem make_288 : make 1000 30 32 16 5480281 10712529=some row_288 := by
  have ck_0_24_0 : (Block.mk 5480281 5508408 2347 2351 2357 5479921 5480249 5480269).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2347 LCMSourcePV.PrimeFacts.prime_2351 LCMSourcePV.PrimeFacts.prime_2357 LCMSourcePV.PrimeFacts.prime_5479921 LCMSourcePV.PrimeFacts.prime_5480249 LCMSourcePV.PrimeFacts.prime_5480269
  have sh_0_24_0 : shrink 30 (Block.mk 5480281 5508408 2347 2351 2357 5479921 5480249 5480269)=some row_288 := shrink_hit _ _ ck_0_24_0
  have c0_0_24 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 8 5479930=some row_288 :=
    choose0_hit 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 7 5479930 5479921 row_288 (SearchFacts.query_2889 LCMSourcePV.PrimeFacts.prime_5479921) (by decide) sh_0_24_0
  have c0_0_23 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 9 5479938=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 8 5479938 5479931 (some row_288) (SearchFacts.query_2890 LCMSourcePV.PrimeFacts.prime_5479931) (by decide) c0_0_24
  have c0_0_22 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 10 5479950=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 9 5479950 5479939 (some row_288) (SearchFacts.query_2891 LCMSourcePV.PrimeFacts.prime_5479939) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 11 5479986=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 10 5479986 5479951 (some row_288) (SearchFacts.query_2892 LCMSourcePV.PrimeFacts.prime_5479951) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 12 5480008=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 11 5480008 5479987 (some row_288) (SearchFacts.query_2893 LCMSourcePV.PrimeFacts.prime_5479987) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 13 5480016=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 12 5480016 5480009 (some row_288) (SearchFacts.query_2894 LCMSourcePV.PrimeFacts.prime_5480009) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 14 5480020=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 13 5480020 5480017 (some row_288) (SearchFacts.query_2895 LCMSourcePV.PrimeFacts.prime_5480017) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 15 5480022=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 14 5480022 5480021 (some row_288) (SearchFacts.query_2896 LCMSourcePV.PrimeFacts.prime_5480021) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 16 5480028=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 15 5480028 5480023 (some row_288) (SearchFacts.query_2897 LCMSourcePV.PrimeFacts.prime_5480023) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 17 5480052=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 16 5480052 5480029 (some row_288) (SearchFacts.query_2898 LCMSourcePV.PrimeFacts.prime_5480029) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 18 5480062=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 17 5480062 5480053 (some row_288) (SearchFacts.query_2899 LCMSourcePV.PrimeFacts.prime_5480053) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 19 5480076=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 18 5480076 5480063 (some row_288) (SearchFacts.query_2900 LCMSourcePV.PrimeFacts.prime_5480063) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 20 5480080=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 19 5480080 5480077 (some row_288) (SearchFacts.query_2901 LCMSourcePV.PrimeFacts.prime_5480077) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 21 5480088=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 20 5480088 5480081 (some row_288) (SearchFacts.query_2902 LCMSourcePV.PrimeFacts.prime_5480081) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 22 5480116=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 21 5480116 5480089 (some row_288) (SearchFacts.query_2903 LCMSourcePV.PrimeFacts.prime_5480089) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 23 5480118=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 22 5480118 5480117 (some row_288) (SearchFacts.query_2904 LCMSourcePV.PrimeFacts.prime_5480117) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 24 5480128=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 23 5480128 5480119 (some row_288) (SearchFacts.query_2905 LCMSourcePV.PrimeFacts.prime_5480119) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 25 5480142=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 24 5480142 5480129 (some row_288) (SearchFacts.query_2906 LCMSourcePV.PrimeFacts.prime_5480129) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 26 5480172=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 25 5480172 5480143 (some row_288) (SearchFacts.query_2907 LCMSourcePV.PrimeFacts.prime_5480143) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 27 5480196=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 26 5480196 5480173 (some row_288) (SearchFacts.query_2908 LCMSourcePV.PrimeFacts.prime_5480173) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 28 5480200=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 27 5480200 5480197 (some row_288) (SearchFacts.query_2909 LCMSourcePV.PrimeFacts.prime_5480197) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 29 5480206=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 28 5480206 5480201 (some row_288) (SearchFacts.query_2910 LCMSourcePV.PrimeFacts.prime_5480201) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 30 5480212=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 29 5480212 5480207 (some row_288) (SearchFacts.query_2911 LCMSourcePV.PrimeFacts.prime_5480207) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 31 5480230=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 30 5480230 5480213 (some row_288) (SearchFacts.query_2912 LCMSourcePV.PrimeFacts.prime_5480213) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 32 5480248=(some row_288) :=
    choose0_skip 1000 30 5480281 10712529 2347 2351 2357 5480249 5480269 31 5480248 5480231 (some row_288) (SearchFacts.query_2913 LCMSourcePV.PrimeFacts.prime_5480231) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5480281 10712529 2347 2351 2357 5480269 16 5480268=some row_288 :=
    choose1_hit 1000 30 32 5480281 10712529 2347 2351 2357 5480269 15 5480268 5480249 row_288 (SearchFacts.query_2914 LCMSourcePV.PrimeFacts.prime_5480249) c0_0_0
  have hsqrt : Nat.sqrt 5480281=2341 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5480281+1)=some 2347 := by
    rw [hsqrt];exact (SearchFacts.query_4409 LCMSourcePV.PrimeFacts.prime_2347)
  exact make_hit 1000 30 32 16 5480281 10712529 2347 2351 2357 5480269 row_288 h0 (SearchFacts.query_4410 LCMSourcePV.PrimeFacts.prime_2351) (SearchFacts.query_4411 LCMSourcePV.PrimeFacts.prime_2357) (SearchFacts.query_2915 LCMSourcePV.PrimeFacts.prime_5480269) c1_0
#print axioms make_288
end LCMSourcePV.Witness.BlockProofs
