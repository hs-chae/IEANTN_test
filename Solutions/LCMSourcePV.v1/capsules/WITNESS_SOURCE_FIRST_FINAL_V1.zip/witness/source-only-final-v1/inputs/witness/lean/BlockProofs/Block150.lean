/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_150 : Block := (Block.mk 1661521 1666680 1291 1297 1301 1661347 1661503 1661519)
theorem make_150 : make 1000 30 32 16 1661521 10712529=some row_150 := by
  have ck_0_7_0 : (Block.mk 1661521 1666680 1291 1297 1301 1661347 1661503 1661519).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1291 LCMSourcePV.PrimeFacts.prime_1297 LCMSourcePV.PrimeFacts.prime_1301 LCMSourcePV.PrimeFacts.prime_1661347 LCMSourcePV.PrimeFacts.prime_1661503 LCMSourcePV.PrimeFacts.prime_1661519
  have sh_0_7_0 : shrink 30 (Block.mk 1661521 1666680 1291 1297 1301 1661347 1661503 1661519)=some row_150 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 25 1661352=some row_150 :=
    choose0_hit 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 24 1661352 1661347 row_150 (SearchFacts.query_1581 LCMSourcePV.PrimeFacts.prime_1661347) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 26 1661430=(some row_150) :=
    choose0_skip 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 25 1661430 1661353 (some row_150) (SearchFacts.query_1582 LCMSourcePV.PrimeFacts.prime_1661353) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 27 1661436=(some row_150) :=
    choose0_skip 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 26 1661436 1661431 (some row_150) (SearchFacts.query_1583 LCMSourcePV.PrimeFacts.prime_1661431) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 28 1661440=(some row_150) :=
    choose0_skip 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 27 1661440 1661437 (some row_150) (SearchFacts.query_1584 LCMSourcePV.PrimeFacts.prime_1661437) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 29 1661446=(some row_150) :=
    choose0_skip 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 28 1661446 1661441 (some row_150) (SearchFacts.query_1585 LCMSourcePV.PrimeFacts.prime_1661441) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 30 1661478=(some row_150) :=
    choose0_skip 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 29 1661478 1661447 (some row_150) (SearchFacts.query_1586 LCMSourcePV.PrimeFacts.prime_1661447) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 31 1661488=(some row_150) :=
    choose0_skip 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 30 1661488 1661479 (some row_150) (SearchFacts.query_1587 LCMSourcePV.PrimeFacts.prime_1661479) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 32 1661502=(some row_150) :=
    choose0_skip 1000 30 1661521 10712529 1291 1297 1301 1661503 1661519 31 1661502 1661489 (some row_150) (SearchFacts.query_1588 LCMSourcePV.PrimeFacts.prime_1661489) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1661521 10712529 1291 1297 1301 1661519 16 1661518=some row_150 :=
    choose1_hit 1000 30 32 1661521 10712529 1291 1297 1301 1661519 15 1661518 1661503 row_150 (SearchFacts.query_1589 LCMSourcePV.PrimeFacts.prime_1661503) c0_0_0
  have hsqrt : Nat.sqrt 1661521=1289 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1661521+1)=some 1291 := by
    rw [hsqrt];exact (SearchFacts.query_4271 LCMSourcePV.PrimeFacts.prime_1291)
  exact make_hit 1000 30 32 16 1661521 10712529 1291 1297 1301 1661519 row_150 h0 (SearchFacts.query_4272 LCMSourcePV.PrimeFacts.prime_1297) (SearchFacts.query_4273 LCMSourcePV.PrimeFacts.prime_1301) (SearchFacts.query_1590 LCMSourcePV.PrimeFacts.prime_1661519) c1_0
#print axioms make_150
end LCMSourcePV.Witness.BlockProofs
