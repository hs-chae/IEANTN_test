/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_115 : Block := (Block.mk 1067089 1079520 1039 1049 1051 1067063 1067069 1067083)
theorem make_115 : make 1000 30 32 16 1067089 10712529=some row_115 := by
  have ck_0_0_0 : (Block.mk 1067089 1079520 1039 1049 1051 1067063 1067069 1067083).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1039 LCMSourcePV.PrimeFacts.prime_1049 LCMSourcePV.PrimeFacts.prime_1051 LCMSourcePV.PrimeFacts.prime_1067063 LCMSourcePV.PrimeFacts.prime_1067069 LCMSourcePV.PrimeFacts.prime_1067083
  have sh_0_0_0 : shrink 30 (Block.mk 1067089 1079520 1039 1049 1051 1067063 1067069 1067083)=some row_115 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 1067089 10712529 1039 1049 1051 1067069 1067083 32 1067068=some row_115 :=
    choose0_hit 1000 30 1067089 10712529 1039 1049 1051 1067069 1067083 31 1067068 1067063 row_115 (SearchFacts.query_1181 LCMSourcePV.PrimeFacts.prime_1067063) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 1067089 10712529 1039 1049 1051 1067083 16 1067082=some row_115 :=
    choose1_hit 1000 30 32 1067089 10712529 1039 1049 1051 1067083 15 1067082 1067069 row_115 (SearchFacts.query_1182 LCMSourcePV.PrimeFacts.prime_1067069) c0_0_0
  have hsqrt : Nat.sqrt 1067089=1033 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1067089+1)=some 1039 := by
    rw [hsqrt];exact (SearchFacts.query_4236 LCMSourcePV.PrimeFacts.prime_1039)
  exact make_hit 1000 30 32 16 1067089 10712529 1039 1049 1051 1067083 row_115 h0 (SearchFacts.query_4237 LCMSourcePV.PrimeFacts.prime_1049) (SearchFacts.query_4238 LCMSourcePV.PrimeFacts.prime_1051) (SearchFacts.query_1183 LCMSourcePV.PrimeFacts.prime_1067083) c1_0
#print axioms make_115
end LCMSourcePV.Witness.BlockProofs
