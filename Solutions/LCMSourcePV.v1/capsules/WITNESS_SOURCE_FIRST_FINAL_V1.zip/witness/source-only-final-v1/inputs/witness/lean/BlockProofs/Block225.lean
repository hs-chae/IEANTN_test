/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_225 : Block := (Block.mk 3463321 3485688 1867 1871 1873 3463231 3463307 3463319)
theorem make_225 : make 1000 30 32 16 3463321 10712529=some row_225 := by
  have ck_0_4_0 : (Block.mk 3463321 3485688 1867 1871 1873 3463231 3463307 3463319).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1867 LCMSourcePV.PrimeFacts.prime_1871 LCMSourcePV.PrimeFacts.prime_1873 LCMSourcePV.PrimeFacts.prime_3463231 LCMSourcePV.PrimeFacts.prime_3463307 LCMSourcePV.PrimeFacts.prime_3463319
  have sh_0_4_0 : shrink 30 (Block.mk 3463321 3485688 1867 1871 1873 3463231 3463307 3463319)=some row_225 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 28 3463248=some row_225 :=
    choose0_hit 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 27 3463248 3463231 row_225 (SearchFacts.query_2335 LCMSourcePV.PrimeFacts.prime_3463231) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 29 3463258=(some row_225) :=
    choose0_skip 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 28 3463258 3463249 (some row_225) (SearchFacts.query_2336 LCMSourcePV.PrimeFacts.prime_3463249) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 30 3463276=(some row_225) :=
    choose0_skip 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 29 3463276 3463259 (some row_225) (SearchFacts.query_2337 LCMSourcePV.PrimeFacts.prime_3463259) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 31 3463302=(some row_225) :=
    choose0_skip 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 30 3463302 3463277 (some row_225) (SearchFacts.query_2338 LCMSourcePV.PrimeFacts.prime_3463277) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 32 3463306=(some row_225) :=
    choose0_skip 1000 30 3463321 10712529 1867 1871 1873 3463307 3463319 31 3463306 3463303 (some row_225) (SearchFacts.query_2339 LCMSourcePV.PrimeFacts.prime_3463303) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3463321 10712529 1867 1871 1873 3463319 16 3463318=some row_225 :=
    choose1_hit 1000 30 32 3463321 10712529 1867 1871 1873 3463319 15 3463318 3463307 row_225 (SearchFacts.query_2340 LCMSourcePV.PrimeFacts.prime_3463307) c0_0_0
  have hsqrt : Nat.sqrt 3463321=1861 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3463321+1)=some 1867 := by
    rw [hsqrt];exact (SearchFacts.query_4346 LCMSourcePV.PrimeFacts.prime_1867)
  exact make_hit 1000 30 32 16 3463321 10712529 1867 1871 1873 3463319 row_225 h0 (SearchFacts.query_4347 LCMSourcePV.PrimeFacts.prime_1871) (SearchFacts.query_4348 LCMSourcePV.PrimeFacts.prime_1873) (SearchFacts.query_2341 LCMSourcePV.PrimeFacts.prime_3463319) c1_0
#print axioms make_225
end LCMSourcePV.Witness.BlockProofs
