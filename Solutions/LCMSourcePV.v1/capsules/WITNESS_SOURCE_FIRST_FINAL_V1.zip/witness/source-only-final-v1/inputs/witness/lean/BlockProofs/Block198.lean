/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_198 : Block := (Block.mk 2627641 2647128 1627 1637 1657 2627593 2627617 2627627)
theorem make_198 : make 1000 30 32 16 2627641 10712529=some row_198 := by
  have ck_0_0_0 : (Block.mk 2627641 2647128 1627 1637 1657 2627593 2627617 2627627).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1627 LCMSourcePV.PrimeFacts.prime_1637 LCMSourcePV.PrimeFacts.prime_1657 LCMSourcePV.PrimeFacts.prime_2627593 LCMSourcePV.PrimeFacts.prime_2627617 LCMSourcePV.PrimeFacts.prime_2627627
  have sh_0_0_0 : shrink 30 (Block.mk 2627641 2647128 1627 1637 1657 2627593 2627617 2627627)=some row_198 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 2627641 10712529 1627 1637 1657 2627617 2627627 32 2627616=some row_198 :=
    choose0_hit 1000 30 2627641 10712529 1627 1637 1657 2627617 2627627 31 2627616 2627593 row_198 (SearchFacts.query_2037 LCMSourcePV.PrimeFacts.prime_2627593) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 2627641 10712529 1627 1637 1657 2627627 16 2627626=some row_198 :=
    choose1_hit 1000 30 32 2627641 10712529 1627 1637 1657 2627627 15 2627626 2627617 row_198 (SearchFacts.query_2038 LCMSourcePV.PrimeFacts.prime_2627617) c0_0_0
  have hsqrt : Nat.sqrt 2627641=1621 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2627641+1)=some 1627 := by
    rw [hsqrt];exact (SearchFacts.query_4319 LCMSourcePV.PrimeFacts.prime_1627)
  exact make_hit 1000 30 32 16 2627641 10712529 1627 1637 1657 2627627 row_198 h0 (SearchFacts.query_4320 LCMSourcePV.PrimeFacts.prime_1637) (SearchFacts.query_4321 LCMSourcePV.PrimeFacts.prime_1657) (SearchFacts.query_2039 LCMSourcePV.PrimeFacts.prime_2627627) c1_0
#print axioms make_198
end LCMSourcePV.Witness.BlockProofs
