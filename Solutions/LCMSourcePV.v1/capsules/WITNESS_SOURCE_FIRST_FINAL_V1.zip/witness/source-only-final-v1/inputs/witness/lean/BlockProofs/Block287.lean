/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_287 : Block := (Block.mk 5470921 5480280 2341 2347 2351 5470679 5470877 5470909)
theorem make_287 : make 1000 30 32 16 5470921 10712529=some row_287 := by
  have ck_0_11_0 : (Block.mk 5470921 5480280 2341 2347 2351 5470679 5470877 5470909).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2341 LCMSourcePV.PrimeFacts.prime_2347 LCMSourcePV.PrimeFacts.prime_2351 LCMSourcePV.PrimeFacts.prime_5470679 LCMSourcePV.PrimeFacts.prime_5470877 LCMSourcePV.PrimeFacts.prime_5470909
  have sh_0_11_0 : shrink 30 (Block.mk 5470921 5480280 2341 2347 2351 5470679 5470877 5470909)=some row_287 := shrink_hit _ _ ck_0_11_0
  have c0_0_11 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 21 5470680=some row_287 :=
    choose0_hit 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 20 5470680 5470679 row_287 (SearchFacts.query_2875 LCMSourcePV.PrimeFacts.prime_5470679) (by decide) sh_0_11_0
  have c0_0_10 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 22 5470720=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 21 5470720 5470681 (some row_287) (SearchFacts.query_2876 LCMSourcePV.PrimeFacts.prime_5470681) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 23 5470722=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 22 5470722 5470721 (some row_287) (SearchFacts.query_2877 LCMSourcePV.PrimeFacts.prime_5470721) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 24 5470732=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 23 5470732 5470723 (some row_287) (SearchFacts.query_2878 LCMSourcePV.PrimeFacts.prime_5470723) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 25 5470770=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 24 5470770 5470733 (some row_287) (SearchFacts.query_2879 LCMSourcePV.PrimeFacts.prime_5470733) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 26 5470780=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 25 5470780 5470771 (some row_287) (SearchFacts.query_2880 LCMSourcePV.PrimeFacts.prime_5470771) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 27 5470792=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 26 5470792 5470781 (some row_287) (SearchFacts.query_2881 LCMSourcePV.PrimeFacts.prime_5470781) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 28 5470798=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 27 5470798 5470793 (some row_287) (SearchFacts.query_2882 LCMSourcePV.PrimeFacts.prime_5470793) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 29 5470810=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 28 5470810 5470799 (some row_287) (SearchFacts.query_2883 LCMSourcePV.PrimeFacts.prime_5470799) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 30 5470830=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 29 5470830 5470811 (some row_287) (SearchFacts.query_2884 LCMSourcePV.PrimeFacts.prime_5470811) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 31 5470852=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 30 5470852 5470831 (some row_287) (SearchFacts.query_2885 LCMSourcePV.PrimeFacts.prime_5470831) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 32 5470876=(some row_287) :=
    choose0_skip 1000 30 5470921 10712529 2341 2347 2351 5470877 5470909 31 5470876 5470853 (some row_287) (SearchFacts.query_2886 LCMSourcePV.PrimeFacts.prime_5470853) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5470921 10712529 2341 2347 2351 5470909 16 5470908=some row_287 :=
    choose1_hit 1000 30 32 5470921 10712529 2341 2347 2351 5470909 15 5470908 5470877 row_287 (SearchFacts.query_2887 LCMSourcePV.PrimeFacts.prime_5470877) c0_0_0
  have hsqrt : Nat.sqrt 5470921=2339 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5470921+1)=some 2341 := by
    rw [hsqrt];exact (SearchFacts.query_4408 LCMSourcePV.PrimeFacts.prime_2341)
  exact make_hit 1000 30 32 16 5470921 10712529 2341 2347 2351 5470909 row_287 h0 (SearchFacts.query_4409 LCMSourcePV.PrimeFacts.prime_2347) (SearchFacts.query_4410 LCMSourcePV.PrimeFacts.prime_2351) (SearchFacts.query_2888 LCMSourcePV.PrimeFacts.prime_5470909) c1_0
#print axioms make_287
end LCMSourcePV.Witness.BlockProofs
