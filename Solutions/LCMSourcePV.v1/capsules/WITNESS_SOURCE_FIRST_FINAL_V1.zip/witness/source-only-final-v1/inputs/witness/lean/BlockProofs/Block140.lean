/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_140 : Block := (Block.mk 1481089 1495728 1223 1229 1231 1481003 1481047 1481071)
theorem make_140 : make 1000 30 32 16 1481089 10712529=some row_140 := by
  have ck_0_4_0 : (Block.mk 1481089 1495728 1223 1229 1231 1481003 1481047 1481071).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1223 LCMSourcePV.PrimeFacts.prime_1229 LCMSourcePV.PrimeFacts.prime_1231 LCMSourcePV.PrimeFacts.prime_1481003 LCMSourcePV.PrimeFacts.prime_1481047 LCMSourcePV.PrimeFacts.prime_1481071
  have sh_0_4_0 : shrink 30 (Block.mk 1481089 1495728 1223 1229 1231 1481003 1481047 1481071)=some row_140 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 28 1481020=some row_140 :=
    choose0_hit 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 27 1481020 1481003 row_140 (SearchFacts.query_1507 LCMSourcePV.PrimeFacts.prime_1481003) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 29 1481026=(some row_140) :=
    choose0_skip 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 28 1481026 1481021 (some row_140) (SearchFacts.query_1508 LCMSourcePV.PrimeFacts.prime_1481021) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 30 1481032=(some row_140) :=
    choose0_skip 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 29 1481032 1481027 (some row_140) (SearchFacts.query_1509 LCMSourcePV.PrimeFacts.prime_1481027) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 31 1481040=(some row_140) :=
    choose0_skip 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 30 1481040 1481033 (some row_140) (SearchFacts.query_1510 LCMSourcePV.PrimeFacts.prime_1481033) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 32 1481046=(some row_140) :=
    choose0_skip 1000 30 1481089 10712529 1223 1229 1231 1481047 1481071 31 1481046 1481041 (some row_140) (SearchFacts.query_1511 LCMSourcePV.PrimeFacts.prime_1481041) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1481089 10712529 1223 1229 1231 1481071 16 1481070=some row_140 :=
    choose1_hit 1000 30 32 1481089 10712529 1223 1229 1231 1481071 15 1481070 1481047 row_140 (SearchFacts.query_1512 LCMSourcePV.PrimeFacts.prime_1481047) c0_0_0
  have hsqrt : Nat.sqrt 1481089=1217 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1481089+1)=some 1223 := by
    rw [hsqrt];exact (SearchFacts.query_4261 LCMSourcePV.PrimeFacts.prime_1223)
  exact make_hit 1000 30 32 16 1481089 10712529 1223 1229 1231 1481071 row_140 h0 (SearchFacts.query_4262 LCMSourcePV.PrimeFacts.prime_1229) (SearchFacts.query_4263 LCMSourcePV.PrimeFacts.prime_1231) (SearchFacts.query_1513 LCMSourcePV.PrimeFacts.prime_1481071) c1_0
#print axioms make_140
end LCMSourcePV.Witness.BlockProofs
