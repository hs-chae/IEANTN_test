/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_283 : Block := (Block.mk 5276209 5331480 2309 2311 2333 5276189 5276197 5276207)
theorem make_283 : make 1000 30 32 16 5276209 10712529=some row_283 := by
  have ck_0_1_0 : (Block.mk 5276209 5331480 2309 2311 2333 5276189 5276197 5276207).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2309 LCMSourcePV.PrimeFacts.prime_2311 LCMSourcePV.PrimeFacts.prime_2333 LCMSourcePV.PrimeFacts.prime_5276189 LCMSourcePV.PrimeFacts.prime_5276197 LCMSourcePV.PrimeFacts.prime_5276207
  have sh_0_1_0 : shrink 30 (Block.mk 5276209 5331480 2309 2311 2333 5276189 5276197 5276207)=some row_283 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 5276209 10712529 2309 2311 2333 5276197 5276207 31 5276190=some row_283 :=
    choose0_hit 1000 30 5276209 10712529 2309 2311 2333 5276197 5276207 30 5276190 5276189 row_283 (SearchFacts.query_2853 LCMSourcePV.PrimeFacts.prime_5276189) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 5276209 10712529 2309 2311 2333 5276197 5276207 32 5276196=(some row_283) :=
    choose0_skip 1000 30 5276209 10712529 2309 2311 2333 5276197 5276207 31 5276196 5276191 (some row_283) (SearchFacts.query_2854 LCMSourcePV.PrimeFacts.prime_5276191) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5276209 10712529 2309 2311 2333 5276207 16 5276206=some row_283 :=
    choose1_hit 1000 30 32 5276209 10712529 2309 2311 2333 5276207 15 5276206 5276197 row_283 (SearchFacts.query_2855 LCMSourcePV.PrimeFacts.prime_5276197) c0_0_0
  have hsqrt : Nat.sqrt 5276209=2297 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5276209+1)=some 2309 := by
    rw [hsqrt];exact (SearchFacts.query_4404 LCMSourcePV.PrimeFacts.prime_2309)
  exact make_hit 1000 30 32 16 5276209 10712529 2309 2311 2333 5276207 row_283 h0 (SearchFacts.query_4405 LCMSourcePV.PrimeFacts.prime_2311) (SearchFacts.query_4406 LCMSourcePV.PrimeFacts.prime_2333) (SearchFacts.query_2856 LCMSourcePV.PrimeFacts.prime_5276207) c1_0
#print axioms make_283
end LCMSourcePV.Witness.BlockProofs
