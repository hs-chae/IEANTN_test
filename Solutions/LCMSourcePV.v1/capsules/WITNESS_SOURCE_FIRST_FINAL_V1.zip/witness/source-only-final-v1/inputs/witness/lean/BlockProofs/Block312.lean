/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_312 : Block := (Block.mk 6446521 6466848 2543 2549 2551 6446459 6446507 6446513)
theorem make_312 : make 1000 30 32 16 6446521 10712529=some row_312 := by
  have ck_0_2_0 : (Block.mk 6446521 6466848 2543 2549 2551 6446459 6446507 6446513).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2543 LCMSourcePV.PrimeFacts.prime_2549 LCMSourcePV.PrimeFacts.prime_2551 LCMSourcePV.PrimeFacts.prime_6446459 LCMSourcePV.PrimeFacts.prime_6446507 LCMSourcePV.PrimeFacts.prime_6446513
  have sh_0_2_0 : shrink 30 (Block.mk 6446521 6466848 2543 2549 2551 6446459 6446507 6446513)=some row_312 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 6446521 10712529 2543 2549 2551 6446507 6446513 30 6446476=some row_312 :=
    choose0_hit 1000 30 6446521 10712529 2543 2549 2551 6446507 6446513 29 6446476 6446459 row_312 (SearchFacts.query_3171 LCMSourcePV.PrimeFacts.prime_6446459) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 6446521 10712529 2543 2549 2551 6446507 6446513 31 6446482=(some row_312) :=
    choose0_skip 1000 30 6446521 10712529 2543 2549 2551 6446507 6446513 30 6446482 6446477 (some row_312) (SearchFacts.query_3172 LCMSourcePV.PrimeFacts.prime_6446477) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6446521 10712529 2543 2549 2551 6446507 6446513 32 6446506=(some row_312) :=
    choose0_skip 1000 30 6446521 10712529 2543 2549 2551 6446507 6446513 31 6446506 6446483 (some row_312) (SearchFacts.query_3173 LCMSourcePV.PrimeFacts.prime_6446483) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6446521 10712529 2543 2549 2551 6446513 16 6446512=some row_312 :=
    choose1_hit 1000 30 32 6446521 10712529 2543 2549 2551 6446513 15 6446512 6446507 row_312 (SearchFacts.query_3174 LCMSourcePV.PrimeFacts.prime_6446507) c0_0_0
  have hsqrt : Nat.sqrt 6446521=2539 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6446521+1)=some 2543 := by
    rw [hsqrt];exact (SearchFacts.query_4433 LCMSourcePV.PrimeFacts.prime_2543)
  exact make_hit 1000 30 32 16 6446521 10712529 2543 2549 2551 6446513 row_312 h0 (SearchFacts.query_4434 LCMSourcePV.PrimeFacts.prime_2549) (SearchFacts.query_4435 LCMSourcePV.PrimeFacts.prime_2551) (SearchFacts.query_3175 LCMSourcePV.PrimeFacts.prime_6446513) c1_0
#print axioms make_312
end LCMSourcePV.Witness.BlockProofs
