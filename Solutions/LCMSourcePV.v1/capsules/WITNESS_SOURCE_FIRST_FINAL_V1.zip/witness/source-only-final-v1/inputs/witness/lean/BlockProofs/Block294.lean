/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_294 : Block := (Block.mk 5669161 5678688 2383 2389 2393 5668823 5669129 5669159)
theorem make_294 : make 1000 30 32 16 5669161 10712529=some row_294 := by
  have ck_0_13_0 : (Block.mk 5669161 5678688 2383 2389 2393 5668823 5669129 5669159).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2383 LCMSourcePV.PrimeFacts.prime_2389 LCMSourcePV.PrimeFacts.prime_2393 LCMSourcePV.PrimeFacts.prime_5668823 LCMSourcePV.PrimeFacts.prime_5669129 LCMSourcePV.PrimeFacts.prime_5669159
  have sh_0_13_0 : shrink 30 (Block.mk 5669161 5678688 2383 2389 2393 5668823 5669129 5669159)=some row_294 := shrink_hit _ _ ck_0_13_0
  have c0_0_13 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 19 5668828=some row_294 :=
    choose0_hit 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 18 5668828 5668823 row_294 (SearchFacts.query_2964 LCMSourcePV.PrimeFacts.prime_5668823) (by decide) sh_0_13_0
  have c0_0_12 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 20 5668866=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 19 5668866 5668829 (some row_294) (SearchFacts.query_2965 LCMSourcePV.PrimeFacts.prime_5668829) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 21 5668902=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 20 5668902 5668867 (some row_294) (SearchFacts.query_2966 LCMSourcePV.PrimeFacts.prime_5668867) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 22 5668908=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 21 5668908 5668903 (some row_294) (SearchFacts.query_2967 LCMSourcePV.PrimeFacts.prime_5668903) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 23 5668918=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 22 5668918 5668909 (some row_294) (SearchFacts.query_2968 LCMSourcePV.PrimeFacts.prime_5668909) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 24 5668950=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 23 5668950 5668919 (some row_294) (SearchFacts.query_2969 LCMSourcePV.PrimeFacts.prime_5668919) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 25 5668962=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 24 5668962 5668951 (some row_294) (SearchFacts.query_2970 LCMSourcePV.PrimeFacts.prime_5668951) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 26 5668996=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 25 5668996 5668963 (some row_294) (SearchFacts.query_2971 LCMSourcePV.PrimeFacts.prime_5668963) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 27 5669020=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 26 5669020 5668997 (some row_294) (SearchFacts.query_2972 LCMSourcePV.PrimeFacts.prime_5668997) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 28 5669022=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 27 5669022 5669021 (some row_294) (SearchFacts.query_2973 LCMSourcePV.PrimeFacts.prime_5669021) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 29 5669050=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 28 5669050 5669023 (some row_294) (SearchFacts.query_2974 LCMSourcePV.PrimeFacts.prime_5669023) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 30 5669088=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 29 5669088 5669051 (some row_294) (SearchFacts.query_2975 LCMSourcePV.PrimeFacts.prime_5669051) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 31 5669098=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 30 5669098 5669089 (some row_294) (SearchFacts.query_2976 LCMSourcePV.PrimeFacts.prime_5669089) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 32 5669128=(some row_294) :=
    choose0_skip 1000 30 5669161 10712529 2383 2389 2393 5669129 5669159 31 5669128 5669099 (some row_294) (SearchFacts.query_2977 LCMSourcePV.PrimeFacts.prime_5669099) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5669161 10712529 2383 2389 2393 5669159 16 5669158=some row_294 :=
    choose1_hit 1000 30 32 5669161 10712529 2383 2389 2393 5669159 15 5669158 5669129 row_294 (SearchFacts.query_2978 LCMSourcePV.PrimeFacts.prime_5669129) c0_0_0
  have hsqrt : Nat.sqrt 5669161=2381 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5669161+1)=some 2383 := by
    rw [hsqrt];exact (SearchFacts.query_4415 LCMSourcePV.PrimeFacts.prime_2383)
  exact make_hit 1000 30 32 16 5669161 10712529 2383 2389 2393 5669159 row_294 h0 (SearchFacts.query_4416 LCMSourcePV.PrimeFacts.prime_2389) (SearchFacts.query_4417 LCMSourcePV.PrimeFacts.prime_2393) (SearchFacts.query_2979 LCMSourcePV.PrimeFacts.prime_5669159) c1_0
#print axioms make_294
end LCMSourcePV.Witness.BlockProofs
