/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_268 : Block := (Block.mk 4748041 4853208 2203 2207 2213 4747949 4748033 4748039)
theorem make_268 : make 1000 30 32 16 4748041 10712529=some row_268 := by
  have ck_0_7_0 : (Block.mk 4748041 4853208 2203 2207 2213 4747949 4748033 4748039).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2203 LCMSourcePV.PrimeFacts.prime_2207 LCMSourcePV.PrimeFacts.prime_2213 LCMSourcePV.PrimeFacts.prime_4747949 LCMSourcePV.PrimeFacts.prime_4748033 LCMSourcePV.PrimeFacts.prime_4748039
  have sh_0_7_0 : shrink 30 (Block.mk 4748041 4853208 2203 2207 2213 4747949 4748033 4748039)=some row_268 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 25 4747956=some row_268 :=
    choose0_hit 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 24 4747956 4747949 row_268 (SearchFacts.query_2702 LCMSourcePV.PrimeFacts.prime_4747949) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 26 4747960=(some row_268) :=
    choose0_skip 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 25 4747960 4747957 (some row_268) (SearchFacts.query_2703 LCMSourcePV.PrimeFacts.prime_4747957) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 27 4747968=(some row_268) :=
    choose0_skip 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 26 4747968 4747961 (some row_268) (SearchFacts.query_2704 LCMSourcePV.PrimeFacts.prime_4747961) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 28 4747972=(some row_268) :=
    choose0_skip 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 27 4747972 4747969 (some row_268) (SearchFacts.query_2705 LCMSourcePV.PrimeFacts.prime_4747969) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 29 4747996=(some row_268) :=
    choose0_skip 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 28 4747996 4747973 (some row_268) (SearchFacts.query_2706 LCMSourcePV.PrimeFacts.prime_4747973) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 30 4747998=(some row_268) :=
    choose0_skip 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 29 4747998 4747997 (some row_268) (SearchFacts.query_2707 LCMSourcePV.PrimeFacts.prime_4747997) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 31 4748010=(some row_268) :=
    choose0_skip 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 30 4748010 4747999 (some row_268) (SearchFacts.query_2708 LCMSourcePV.PrimeFacts.prime_4747999) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 32 4748032=(some row_268) :=
    choose0_skip 1000 30 4748041 10712529 2203 2207 2213 4748033 4748039 31 4748032 4748011 (some row_268) (SearchFacts.query_2709 LCMSourcePV.PrimeFacts.prime_4748011) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4748041 10712529 2203 2207 2213 4748039 16 4748038=some row_268 :=
    choose1_hit 1000 30 32 4748041 10712529 2203 2207 2213 4748039 15 4748038 4748033 row_268 (SearchFacts.query_2710 LCMSourcePV.PrimeFacts.prime_4748033) c0_0_0
  have hsqrt : Nat.sqrt 4748041=2179 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4748041+1)=some 2203 := by
    rw [hsqrt];exact (SearchFacts.query_4389 LCMSourcePV.PrimeFacts.prime_2203)
  exact make_hit 1000 30 32 16 4748041 10712529 2203 2207 2213 4748039 row_268 h0 (SearchFacts.query_4390 LCMSourcePV.PrimeFacts.prime_2207) (SearchFacts.query_4391 LCMSourcePV.PrimeFacts.prime_2213) (SearchFacts.query_2711 LCMSourcePV.PrimeFacts.prime_4748039) c1_0
#print axioms make_268
end LCMSourcePV.Witness.BlockProofs
