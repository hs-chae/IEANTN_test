/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_156 : Block := (Block.mk 1739761 1745040 1321 1327 1361 1739693 1739741 1739747)
theorem make_156 : make 1000 30 32 16 1739761 10712529=some row_156 := by
  have ck_0_2_0 : (Block.mk 1739761 1745040 1321 1327 1361 1739693 1739741 1739747).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1321 LCMSourcePV.PrimeFacts.prime_1327 LCMSourcePV.PrimeFacts.prime_1361 LCMSourcePV.PrimeFacts.prime_1739693 LCMSourcePV.PrimeFacts.prime_1739741 LCMSourcePV.PrimeFacts.prime_1739747
  have sh_0_2_0 : shrink 30 (Block.mk 1739761 1745040 1321 1327 1361 1739693 1739741 1739747)=some row_156 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 1739761 10712529 1321 1327 1361 1739741 1739747 30 1739718=some row_156 :=
    choose0_hit 1000 30 1739761 10712529 1321 1327 1361 1739741 1739747 29 1739718 1739693 row_156 (SearchFacts.query_1628 LCMSourcePV.PrimeFacts.prime_1739693) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 1739761 10712529 1321 1327 1361 1739741 1739747 31 1739722=(some row_156) :=
    choose0_skip 1000 30 1739761 10712529 1321 1327 1361 1739741 1739747 30 1739722 1739719 (some row_156) (SearchFacts.query_1629 LCMSourcePV.PrimeFacts.prime_1739719) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1739761 10712529 1321 1327 1361 1739741 1739747 32 1739740=(some row_156) :=
    choose0_skip 1000 30 1739761 10712529 1321 1327 1361 1739741 1739747 31 1739740 1739723 (some row_156) (SearchFacts.query_1630 LCMSourcePV.PrimeFacts.prime_1739723) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1739761 10712529 1321 1327 1361 1739747 16 1739746=some row_156 :=
    choose1_hit 1000 30 32 1739761 10712529 1321 1327 1361 1739747 15 1739746 1739741 row_156 (SearchFacts.query_1631 LCMSourcePV.PrimeFacts.prime_1739741) c0_0_0
  have hsqrt : Nat.sqrt 1739761=1319 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1739761+1)=some 1321 := by
    rw [hsqrt];exact (SearchFacts.query_4277 LCMSourcePV.PrimeFacts.prime_1321)
  exact make_hit 1000 30 32 16 1739761 10712529 1321 1327 1361 1739747 row_156 h0 (SearchFacts.query_4278 LCMSourcePV.PrimeFacts.prime_1327) (SearchFacts.query_4279 LCMSourcePV.PrimeFacts.prime_1361) (SearchFacts.query_1632 LCMSourcePV.PrimeFacts.prime_1739747) c1_0
#print axioms make_156
end LCMSourcePV.Witness.BlockProofs
