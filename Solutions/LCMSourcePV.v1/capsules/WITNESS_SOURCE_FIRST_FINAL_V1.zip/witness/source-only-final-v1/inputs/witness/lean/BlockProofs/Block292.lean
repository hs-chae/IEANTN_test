/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_292 : Block := (Block.mk 5621641 5650128 2377 2381 2383 5621503 5621599 5621617)
theorem make_292 : make 1000 30 32 16 5621641 10712529=some row_292 := by
  have ck_0_2_0 : (Block.mk 5621641 5650128 2377 2381 2383 5621503 5621599 5621617).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2377 LCMSourcePV.PrimeFacts.prime_2381 LCMSourcePV.PrimeFacts.prime_2383 LCMSourcePV.PrimeFacts.prime_5621503 LCMSourcePV.PrimeFacts.prime_5621599 LCMSourcePV.PrimeFacts.prime_5621617
  have sh_0_2_0 : shrink 30 (Block.mk 5621641 5650128 2377 2381 2383 5621503 5621599 5621617)=some row_292 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 5621641 10712529 2377 2381 2383 5621599 5621617 30 5621512=some row_292 :=
    choose0_hit 1000 30 5621641 10712529 2377 2381 2383 5621599 5621617 29 5621512 5621503 row_292 (SearchFacts.query_2956 LCMSourcePV.PrimeFacts.prime_5621503) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 5621641 10712529 2377 2381 2383 5621599 5621617 31 5621596=(some row_292) :=
    choose0_skip 1000 30 5621641 10712529 2377 2381 2383 5621599 5621617 30 5621596 5621513 (some row_292) (SearchFacts.query_2957 LCMSourcePV.PrimeFacts.prime_5621513) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5621641 10712529 2377 2381 2383 5621599 5621617 32 5621598=(some row_292) :=
    choose0_skip 1000 30 5621641 10712529 2377 2381 2383 5621599 5621617 31 5621598 5621597 (some row_292) (SearchFacts.query_2958 LCMSourcePV.PrimeFacts.prime_5621597) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5621641 10712529 2377 2381 2383 5621617 16 5621616=some row_292 :=
    choose1_hit 1000 30 32 5621641 10712529 2377 2381 2383 5621617 15 5621616 5621599 row_292 (SearchFacts.query_2959 LCMSourcePV.PrimeFacts.prime_5621599) c0_0_0
  have hsqrt : Nat.sqrt 5621641=2371 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5621641+1)=some 2377 := by
    rw [hsqrt];exact (SearchFacts.query_4413 LCMSourcePV.PrimeFacts.prime_2377)
  exact make_hit 1000 30 32 16 5621641 10712529 2377 2381 2383 5621617 row_292 h0 (SearchFacts.query_4414 LCMSourcePV.PrimeFacts.prime_2381) (SearchFacts.query_4415 LCMSourcePV.PrimeFacts.prime_2383) (SearchFacts.query_2960 LCMSourcePV.PrimeFacts.prime_5621617) c1_0
#print axioms make_292
end LCMSourcePV.Witness.BlockProofs
