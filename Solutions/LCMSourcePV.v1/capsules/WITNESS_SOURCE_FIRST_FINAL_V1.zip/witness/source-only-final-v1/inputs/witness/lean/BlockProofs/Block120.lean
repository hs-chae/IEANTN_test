/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_120 : Block := (Block.mk 1129969 1142760 1069 1087 1091 1129789 1129957 1129963)
theorem make_120 : make 1000 30 32 16 1129969 10712529=some row_120 := by
  have ck_0_10_0 : (Block.mk 1129969 1142760 1069 1087 1091 1129789 1129957 1129963).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1069 LCMSourcePV.PrimeFacts.prime_1087 LCMSourcePV.PrimeFacts.prime_1091 LCMSourcePV.PrimeFacts.prime_1129789 LCMSourcePV.PrimeFacts.prime_1129957 LCMSourcePV.PrimeFacts.prime_1129963
  have sh_0_10_0 : shrink 30 (Block.mk 1129969 1142760 1069 1087 1091 1129789 1129957 1129963)=some row_120 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 22 1129818=some row_120 :=
    choose0_hit 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 21 1129818 1129789 row_120 (SearchFacts.query_1241 LCMSourcePV.PrimeFacts.prime_1129789) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 23 1129830=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 22 1129830 1129819 (some row_120) (SearchFacts.query_1242 LCMSourcePV.PrimeFacts.prime_1129819) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 24 1129840=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 23 1129840 1129831 (some row_120) (SearchFacts.query_1243 LCMSourcePV.PrimeFacts.prime_1129831) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 25 1129846=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 24 1129846 1129841 (some row_120) (SearchFacts.query_1244 LCMSourcePV.PrimeFacts.prime_1129841) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 26 1129852=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 25 1129852 1129847 (some row_120) (SearchFacts.query_1245 LCMSourcePV.PrimeFacts.prime_1129847) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 27 1129858=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 26 1129858 1129853 (some row_120) (SearchFacts.query_1246 LCMSourcePV.PrimeFacts.prime_1129853) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 28 1129860=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 27 1129860 1129859 (some row_120) (SearchFacts.query_1247 LCMSourcePV.PrimeFacts.prime_1129859) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 29 1129888=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 28 1129888 1129861 (some row_120) (SearchFacts.query_1248 LCMSourcePV.PrimeFacts.prime_1129861) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 30 1129896=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 29 1129896 1129889 (some row_120) (SearchFacts.query_1249 LCMSourcePV.PrimeFacts.prime_1129889) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 31 1129950=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 30 1129950 1129897 (some row_120) (SearchFacts.query_1250 LCMSourcePV.PrimeFacts.prime_1129897) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 32 1129956=(some row_120) :=
    choose0_skip 1000 30 1129969 10712529 1069 1087 1091 1129957 1129963 31 1129956 1129951 (some row_120) (SearchFacts.query_1251 LCMSourcePV.PrimeFacts.prime_1129951) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1129969 10712529 1069 1087 1091 1129963 16 1129962=some row_120 :=
    choose1_hit 1000 30 32 1129969 10712529 1069 1087 1091 1129963 15 1129962 1129957 row_120 (SearchFacts.query_1252 LCMSourcePV.PrimeFacts.prime_1129957) c0_0_0
  have hsqrt : Nat.sqrt 1129969=1063 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1129969+1)=some 1069 := by
    rw [hsqrt];exact (SearchFacts.query_4241 LCMSourcePV.PrimeFacts.prime_1069)
  exact make_hit 1000 30 32 16 1129969 10712529 1069 1087 1091 1129963 row_120 h0 (SearchFacts.query_4242 LCMSourcePV.PrimeFacts.prime_1087) (SearchFacts.query_4243 LCMSourcePV.PrimeFacts.prime_1091) (SearchFacts.query_1253 LCMSourcePV.PrimeFacts.prime_1129963) c1_0
#print axioms make_120
end LCMSourcePV.Witness.BlockProofs
