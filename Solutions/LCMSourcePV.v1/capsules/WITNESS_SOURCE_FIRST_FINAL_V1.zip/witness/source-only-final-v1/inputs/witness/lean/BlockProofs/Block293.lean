/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_293 : Block := (Block.mk 5650129 5669160 2381 2383 2389 5650081 5650097 5650121)
theorem make_293 : make 1000 30 32 16 5650129 10712529=some row_293 := by
  have ck_0_0_0 : (Block.mk 5650129 5669160 2381 2383 2389 5650081 5650097 5650121).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2381 LCMSourcePV.PrimeFacts.prime_2383 LCMSourcePV.PrimeFacts.prime_2389 LCMSourcePV.PrimeFacts.prime_5650081 LCMSourcePV.PrimeFacts.prime_5650097 LCMSourcePV.PrimeFacts.prime_5650121
  have sh_0_0_0 : shrink 30 (Block.mk 5650129 5669160 2381 2383 2389 5650081 5650097 5650121)=some row_293 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 5650129 10712529 2381 2383 2389 5650097 5650121 32 5650096=some row_293 :=
    choose0_hit 1000 30 5650129 10712529 2381 2383 2389 5650097 5650121 31 5650096 5650081 row_293 (SearchFacts.query_2961 LCMSourcePV.PrimeFacts.prime_5650081) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 5650129 10712529 2381 2383 2389 5650121 16 5650120=some row_293 :=
    choose1_hit 1000 30 32 5650129 10712529 2381 2383 2389 5650121 15 5650120 5650097 row_293 (SearchFacts.query_2962 LCMSourcePV.PrimeFacts.prime_5650097) c0_0_0
  have hsqrt : Nat.sqrt 5650129=2377 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5650129+1)=some 2381 := by
    rw [hsqrt];exact (SearchFacts.query_4414 LCMSourcePV.PrimeFacts.prime_2381)
  exact make_hit 1000 30 32 16 5650129 10712529 2381 2383 2389 5650121 row_293 h0 (SearchFacts.query_4415 LCMSourcePV.PrimeFacts.prime_2383) (SearchFacts.query_4416 LCMSourcePV.PrimeFacts.prime_2389) (SearchFacts.query_2963 LCMSourcePV.PrimeFacts.prime_5650121) c1_0
#print axioms make_293
end LCMSourcePV.Witness.BlockProofs
