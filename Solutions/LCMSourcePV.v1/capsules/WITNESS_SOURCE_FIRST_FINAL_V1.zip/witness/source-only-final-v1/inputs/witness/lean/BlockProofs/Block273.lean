/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_273 : Block := (Block.mk 5004169 5013120 2239 2243 2251 5004059 5004149 5004157)
theorem make_273 : make 1000 30 32 16 5004169 10712529=some row_273 := by
  have ck_0_8_0 : (Block.mk 5004169 5013120 2239 2243 2251 5004059 5004149 5004157).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2239 LCMSourcePV.PrimeFacts.prime_2243 LCMSourcePV.PrimeFacts.prime_2251 LCMSourcePV.PrimeFacts.prime_5004059 LCMSourcePV.PrimeFacts.prime_5004149 LCMSourcePV.PrimeFacts.prime_5004157
  have sh_0_8_0 : shrink 30 (Block.mk 5004169 5013120 2239 2243 2251 5004059 5004149 5004157)=some row_273 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 24 5004066=some row_273 :=
    choose0_hit 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 23 5004066 5004059 row_273 (SearchFacts.query_2764 LCMSourcePV.PrimeFacts.prime_5004059) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 25 5004070=(some row_273) :=
    choose0_skip 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 24 5004070 5004067 (some row_273) (SearchFacts.query_2765 LCMSourcePV.PrimeFacts.prime_5004067) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 26 5004072=(some row_273) :=
    choose0_skip 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 25 5004072 5004071 (some row_273) (SearchFacts.query_2766 LCMSourcePV.PrimeFacts.prime_5004071) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 27 5004088=(some row_273) :=
    choose0_skip 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 26 5004088 5004073 (some row_273) (SearchFacts.query_2767 LCMSourcePV.PrimeFacts.prime_5004073) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 28 5004118=(some row_273) :=
    choose0_skip 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 27 5004118 5004089 (some row_273) (SearchFacts.query_2768 LCMSourcePV.PrimeFacts.prime_5004089) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 29 5004120=(some row_273) :=
    choose0_skip 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 28 5004120 5004119 (some row_273) (SearchFacts.query_2769 LCMSourcePV.PrimeFacts.prime_5004119) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 30 5004126=(some row_273) :=
    choose0_skip 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 29 5004126 5004121 (some row_273) (SearchFacts.query_2770 LCMSourcePV.PrimeFacts.prime_5004121) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 31 5004142=(some row_273) :=
    choose0_skip 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 30 5004142 5004127 (some row_273) (SearchFacts.query_2771 LCMSourcePV.PrimeFacts.prime_5004127) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 32 5004148=(some row_273) :=
    choose0_skip 1000 30 5004169 10712529 2239 2243 2251 5004149 5004157 31 5004148 5004143 (some row_273) (SearchFacts.query_2772 LCMSourcePV.PrimeFacts.prime_5004143) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5004169 10712529 2239 2243 2251 5004157 16 5004156=some row_273 :=
    choose1_hit 1000 30 32 5004169 10712529 2239 2243 2251 5004157 15 5004156 5004149 row_273 (SearchFacts.query_2773 LCMSourcePV.PrimeFacts.prime_5004149) c0_0_0
  have hsqrt : Nat.sqrt 5004169=2237 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5004169+1)=some 2239 := by
    rw [hsqrt];exact (SearchFacts.query_4394 LCMSourcePV.PrimeFacts.prime_2239)
  exact make_hit 1000 30 32 16 5004169 10712529 2239 2243 2251 5004157 row_273 h0 (SearchFacts.query_4395 LCMSourcePV.PrimeFacts.prime_2243) (SearchFacts.query_4396 LCMSourcePV.PrimeFacts.prime_2251) (SearchFacts.query_2774 LCMSourcePV.PrimeFacts.prime_5004157) c1_0
#print axioms make_273
end LCMSourcePV.Witness.BlockProofs
