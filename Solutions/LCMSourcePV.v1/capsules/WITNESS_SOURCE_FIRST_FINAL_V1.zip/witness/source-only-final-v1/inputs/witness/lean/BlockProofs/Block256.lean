/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_256 : Block := (Block.mk 4355569 4363920 2089 2099 2111 4355501 4355551 4355567)
theorem make_256 : make 1000 30 32 16 4355569 10712529=some row_256 := by
  have ck_0_1_0 : (Block.mk 4355569 4363920 2089 2099 2111 4355501 4355551 4355567).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2089 LCMSourcePV.PrimeFacts.prime_2099 LCMSourcePV.PrimeFacts.prime_2111 LCMSourcePV.PrimeFacts.prime_4355501 LCMSourcePV.PrimeFacts.prime_4355551 LCMSourcePV.PrimeFacts.prime_4355567
  have sh_0_1_0 : shrink 30 (Block.mk 4355569 4363920 2089 2099 2111 4355501 4355551 4355567)=some row_256 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 4355569 10712529 2089 2099 2111 4355551 4355567 31 4355508=some row_256 :=
    choose0_hit 1000 30 4355569 10712529 2089 2099 2111 4355551 4355567 30 4355508 4355501 row_256 (SearchFacts.query_2599 LCMSourcePV.PrimeFacts.prime_4355501) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 4355569 10712529 2089 2099 2111 4355551 4355567 32 4355550=(some row_256) :=
    choose0_skip 1000 30 4355569 10712529 2089 2099 2111 4355551 4355567 31 4355550 4355509 (some row_256) (SearchFacts.query_2600 LCMSourcePV.PrimeFacts.prime_4355509) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4355569 10712529 2089 2099 2111 4355567 16 4355566=some row_256 :=
    choose1_hit 1000 30 32 4355569 10712529 2089 2099 2111 4355567 15 4355566 4355551 row_256 (SearchFacts.query_2601 LCMSourcePV.PrimeFacts.prime_4355551) c0_0_0
  have hsqrt : Nat.sqrt 4355569=2087 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4355569+1)=some 2089 := by
    rw [hsqrt];exact (SearchFacts.query_4377 LCMSourcePV.PrimeFacts.prime_2089)
  exact make_hit 1000 30 32 16 4355569 10712529 2089 2099 2111 4355567 row_256 h0 (SearchFacts.query_4378 LCMSourcePV.PrimeFacts.prime_2099) (SearchFacts.query_4379 LCMSourcePV.PrimeFacts.prime_2111) (SearchFacts.query_2602 LCMSourcePV.PrimeFacts.prime_4355567) c1_0
#print axioms make_256
end LCMSourcePV.Witness.BlockProofs
