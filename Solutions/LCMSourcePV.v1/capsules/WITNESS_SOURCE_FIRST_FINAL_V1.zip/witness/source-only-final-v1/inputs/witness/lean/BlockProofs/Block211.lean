/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_211 : Block := (Block.mk 3003289 3031080 1741 1747 1753 3003191 3003257 3003281)
theorem make_211 : make 1000 30 32 16 3003289 10712529=some row_211 := by
  have ck_0_5_0 : (Block.mk 3003289 3031080 1741 1747 1753 3003191 3003257 3003281).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1741 LCMSourcePV.PrimeFacts.prime_1747 LCMSourcePV.PrimeFacts.prime_1753 LCMSourcePV.PrimeFacts.prime_3003191 LCMSourcePV.PrimeFacts.prime_3003257 LCMSourcePV.PrimeFacts.prime_3003281
  have sh_0_5_0 : shrink 30 (Block.mk 3003289 3031080 1741 1747 1753 3003191 3003257 3003281)=some row_211 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 27 3003222=some row_211 :=
    choose0_hit 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 26 3003222 3003191 row_211 (SearchFacts.query_2198 LCMSourcePV.PrimeFacts.prime_3003191) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 28 3003226=(some row_211) :=
    choose0_skip 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 27 3003226 3003223 (some row_211) (SearchFacts.query_2199 LCMSourcePV.PrimeFacts.prime_3003223) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 29 3003232=(some row_211) :=
    choose0_skip 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 28 3003232 3003227 (some row_211) (SearchFacts.query_2200 LCMSourcePV.PrimeFacts.prime_3003227) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 30 3003240=(some row_211) :=
    choose0_skip 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 29 3003240 3003233 (some row_211) (SearchFacts.query_2201 LCMSourcePV.PrimeFacts.prime_3003233) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 31 3003250=(some row_211) :=
    choose0_skip 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 30 3003250 3003241 (some row_211) (SearchFacts.query_2202 LCMSourcePV.PrimeFacts.prime_3003241) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 32 3003256=(some row_211) :=
    choose0_skip 1000 30 3003289 10712529 1741 1747 1753 3003257 3003281 31 3003256 3003251 (some row_211) (SearchFacts.query_2203 LCMSourcePV.PrimeFacts.prime_3003251) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3003289 10712529 1741 1747 1753 3003281 16 3003280=some row_211 :=
    choose1_hit 1000 30 32 3003289 10712529 1741 1747 1753 3003281 15 3003280 3003257 row_211 (SearchFacts.query_2204 LCMSourcePV.PrimeFacts.prime_3003257) c0_0_0
  have hsqrt : Nat.sqrt 3003289=1733 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3003289+1)=some 1741 := by
    rw [hsqrt];exact (SearchFacts.query_4332 LCMSourcePV.PrimeFacts.prime_1741)
  exact make_hit 1000 30 32 16 3003289 10712529 1741 1747 1753 3003281 row_211 h0 (SearchFacts.query_4333 LCMSourcePV.PrimeFacts.prime_1747) (SearchFacts.query_4334 LCMSourcePV.PrimeFacts.prime_1753) (SearchFacts.query_2205 LCMSourcePV.PrimeFacts.prime_3003281) c1_0
#print axioms make_211
end LCMSourcePV.Witness.BlockProofs
