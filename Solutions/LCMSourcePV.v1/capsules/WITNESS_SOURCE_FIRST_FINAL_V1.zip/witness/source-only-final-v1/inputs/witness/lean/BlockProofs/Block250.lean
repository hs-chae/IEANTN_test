/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_250 : Block := (Block.mk 4157521 4214808 2053 2063 2069 4157471 4157509 4157513)
theorem make_250 : make 1000 30 32 16 4157521 10712529=some row_250 := by
  have ck_0_3_0 : (Block.mk 4157521 4214808 2053 2063 2069 4157471 4157509 4157513).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2053 LCMSourcePV.PrimeFacts.prime_2063 LCMSourcePV.PrimeFacts.prime_2069 LCMSourcePV.PrimeFacts.prime_4157471 LCMSourcePV.PrimeFacts.prime_4157509 LCMSourcePV.PrimeFacts.prime_4157513
  have sh_0_3_0 : shrink 30 (Block.mk 4157521 4214808 2053 2063 2069 4157471 4157509 4157513)=some row_250 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 4157521 10712529 2053 2063 2069 4157509 4157513 29 4157472=some row_250 :=
    choose0_hit 1000 30 4157521 10712529 2053 2063 2069 4157509 4157513 28 4157472 4157471 row_250 (SearchFacts.query_2565 LCMSourcePV.PrimeFacts.prime_4157471) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 4157521 10712529 2053 2063 2069 4157509 4157513 30 4157476=(some row_250) :=
    choose0_skip 1000 30 4157521 10712529 2053 2063 2069 4157509 4157513 29 4157476 4157473 (some row_250) (SearchFacts.query_2566 LCMSourcePV.PrimeFacts.prime_4157473) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4157521 10712529 2053 2063 2069 4157509 4157513 31 4157500=(some row_250) :=
    choose0_skip 1000 30 4157521 10712529 2053 2063 2069 4157509 4157513 30 4157500 4157477 (some row_250) (SearchFacts.query_2567 LCMSourcePV.PrimeFacts.prime_4157477) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4157521 10712529 2053 2063 2069 4157509 4157513 32 4157508=(some row_250) :=
    choose0_skip 1000 30 4157521 10712529 2053 2063 2069 4157509 4157513 31 4157508 4157501 (some row_250) (SearchFacts.query_2568 LCMSourcePV.PrimeFacts.prime_4157501) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4157521 10712529 2053 2063 2069 4157513 16 4157512=some row_250 :=
    choose1_hit 1000 30 32 4157521 10712529 2053 2063 2069 4157513 15 4157512 4157509 row_250 (SearchFacts.query_2569 LCMSourcePV.PrimeFacts.prime_4157509) c0_0_0
  have hsqrt : Nat.sqrt 4157521=2039 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4157521+1)=some 2053 := by
    rw [hsqrt];exact (SearchFacts.query_4371 LCMSourcePV.PrimeFacts.prime_2053)
  exact make_hit 1000 30 32 16 4157521 10712529 2053 2063 2069 4157513 row_250 h0 (SearchFacts.query_4372 LCMSourcePV.PrimeFacts.prime_2063) (SearchFacts.query_4373 LCMSourcePV.PrimeFacts.prime_2069) (SearchFacts.query_2570 LCMSourcePV.PrimeFacts.prime_4157513) c1_0
#print axioms make_250
end LCMSourcePV.Witness.BlockProofs
