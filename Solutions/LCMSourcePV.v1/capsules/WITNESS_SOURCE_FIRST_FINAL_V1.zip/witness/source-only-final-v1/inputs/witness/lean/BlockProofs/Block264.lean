/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_264 : Block := (Block.mk 4583881 4592448 2143 2153 2161 4583833 4583867 4583869)
theorem make_264 : make 1000 30 32 16 4583881 10712529=some row_264 := by
  have ck_0_4_0 : (Block.mk 4583881 4592448 2143 2153 2161 4583833 4583867 4583869).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2143 LCMSourcePV.PrimeFacts.prime_2153 LCMSourcePV.PrimeFacts.prime_2161 LCMSourcePV.PrimeFacts.prime_4583833 LCMSourcePV.PrimeFacts.prime_4583867 LCMSourcePV.PrimeFacts.prime_4583869
  have sh_0_4_0 : shrink 30 (Block.mk 4583881 4592448 2143 2153 2161 4583833 4583867 4583869)=some row_264 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 28 4583848=some row_264 :=
    choose0_hit 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 27 4583848 4583833 row_264 (SearchFacts.query_2674 LCMSourcePV.PrimeFacts.prime_4583833) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 29 4583850=(some row_264) :=
    choose0_skip 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 28 4583850 4583849 (some row_264) (SearchFacts.query_2675 LCMSourcePV.PrimeFacts.prime_4583849) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 30 4583856=(some row_264) :=
    choose0_skip 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 29 4583856 4583851 (some row_264) (SearchFacts.query_2676 LCMSourcePV.PrimeFacts.prime_4583851) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 31 4583860=(some row_264) :=
    choose0_skip 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 30 4583860 4583857 (some row_264) (SearchFacts.query_2677 LCMSourcePV.PrimeFacts.prime_4583857) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 32 4583866=(some row_264) :=
    choose0_skip 1000 30 4583881 10712529 2143 2153 2161 4583867 4583869 31 4583866 4583861 (some row_264) (SearchFacts.query_2678 LCMSourcePV.PrimeFacts.prime_4583861) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4583881 10712529 2143 2153 2161 4583869 16 4583868=some row_264 :=
    choose1_hit 1000 30 32 4583881 10712529 2143 2153 2161 4583869 15 4583868 4583867 row_264 (SearchFacts.query_2679 LCMSourcePV.PrimeFacts.prime_4583867) c0_0_0
  have hsqrt : Nat.sqrt 4583881=2141 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4583881+1)=some 2143 := by
    rw [hsqrt];exact (SearchFacts.query_4385 LCMSourcePV.PrimeFacts.prime_2143)
  exact make_hit 1000 30 32 16 4583881 10712529 2143 2153 2161 4583869 row_264 h0 (SearchFacts.query_4386 LCMSourcePV.PrimeFacts.prime_2153) (SearchFacts.query_4387 LCMSourcePV.PrimeFacts.prime_2161) (SearchFacts.query_2680 LCMSourcePV.PrimeFacts.prime_4583869) c1_0
#print axioms make_264
end LCMSourcePV.Witness.BlockProofs
