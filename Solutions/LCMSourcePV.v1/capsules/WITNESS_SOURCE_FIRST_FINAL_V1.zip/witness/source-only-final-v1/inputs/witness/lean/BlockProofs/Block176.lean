/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_176 : Block := (Block.mk 2199289 2211168 1487 1489 1493 2199209 2199247 2199277)
theorem make_176 : make 1000 30 32 16 2199289 10712529=some row_176 := by
  have ck_0_3_0 : (Block.mk 2199289 2211168 1487 1489 1493 2199209 2199247 2199277).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1487 LCMSourcePV.PrimeFacts.prime_1489 LCMSourcePV.PrimeFacts.prime_1493 LCMSourcePV.PrimeFacts.prime_2199209 LCMSourcePV.PrimeFacts.prime_2199247 LCMSourcePV.PrimeFacts.prime_2199277
  have sh_0_3_0 : shrink 30 (Block.mk 2199289 2211168 1487 1489 1493 2199209 2199247 2199277)=some row_176 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 2199289 10712529 1487 1489 1493 2199247 2199277 29 2199216=some row_176 :=
    choose0_hit 1000 30 2199289 10712529 1487 1489 1493 2199247 2199277 28 2199216 2199209 row_176 (SearchFacts.query_1789 LCMSourcePV.PrimeFacts.prime_2199209) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 2199289 10712529 1487 1489 1493 2199247 2199277 30 2199220=(some row_176) :=
    choose0_skip 1000 30 2199289 10712529 1487 1489 1493 2199247 2199277 29 2199220 2199217 (some row_176) (SearchFacts.query_1790 LCMSourcePV.PrimeFacts.prime_2199217) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2199289 10712529 1487 1489 1493 2199247 2199277 31 2199228=(some row_176) :=
    choose0_skip 1000 30 2199289 10712529 1487 1489 1493 2199247 2199277 30 2199228 2199221 (some row_176) (SearchFacts.query_1791 LCMSourcePV.PrimeFacts.prime_2199221) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2199289 10712529 1487 1489 1493 2199247 2199277 32 2199246=(some row_176) :=
    choose0_skip 1000 30 2199289 10712529 1487 1489 1493 2199247 2199277 31 2199246 2199229 (some row_176) (SearchFacts.query_1792 LCMSourcePV.PrimeFacts.prime_2199229) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2199289 10712529 1487 1489 1493 2199277 16 2199276=some row_176 :=
    choose1_hit 1000 30 32 2199289 10712529 1487 1489 1493 2199277 15 2199276 2199247 row_176 (SearchFacts.query_1793 LCMSourcePV.PrimeFacts.prime_2199247) c0_0_0
  have hsqrt : Nat.sqrt 2199289=1483 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2199289+1)=some 1487 := by
    rw [hsqrt];exact (SearchFacts.query_4297 LCMSourcePV.PrimeFacts.prime_1487)
  exact make_hit 1000 30 32 16 2199289 10712529 1487 1489 1493 2199277 row_176 h0 (SearchFacts.query_4298 LCMSourcePV.PrimeFacts.prime_1489) (SearchFacts.query_4299 LCMSourcePV.PrimeFacts.prime_1493) (SearchFacts.query_1794 LCMSourcePV.PrimeFacts.prime_2199277) c1_0
#print axioms make_176
end LCMSourcePV.Witness.BlockProofs
