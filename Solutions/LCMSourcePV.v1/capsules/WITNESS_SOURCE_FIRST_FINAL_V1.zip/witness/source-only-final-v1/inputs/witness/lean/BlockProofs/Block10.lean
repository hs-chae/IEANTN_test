/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_10 : Block := (Block.mk 120409 121800 349 353 359 120349 120397 120401)
theorem make_10 : make 1000 30 32 16 120409 10712529=some row_10 := by
  have ck_0_3_0 : (Block.mk 120409 121800 349 353 359 120349 120397 120401).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_349 LCMSourcePV.PrimeFacts.prime_353 LCMSourcePV.PrimeFacts.prime_359 LCMSourcePV.PrimeFacts.prime_120349 LCMSourcePV.PrimeFacts.prime_120397 LCMSourcePV.PrimeFacts.prime_120401
  have sh_0_3_0 : shrink 30 (Block.mk 120409 121800 349 353 359 120349 120397 120401)=some row_10 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 120409 10712529 349 353 359 120397 120401 29 120370=some row_10 :=
    choose0_hit 1000 30 120409 10712529 349 353 359 120397 120401 28 120370 120349 row_10 (SearchFacts.query_72 LCMSourcePV.PrimeFacts.prime_120349) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 120409 10712529 349 353 359 120397 120401 30 120382=(some row_10) :=
    choose0_skip 1000 30 120409 10712529 349 353 359 120397 120401 29 120382 120371 (some row_10) (SearchFacts.query_73 LCMSourcePV.PrimeFacts.prime_120371) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 120409 10712529 349 353 359 120397 120401 31 120390=(some row_10) :=
    choose0_skip 1000 30 120409 10712529 349 353 359 120397 120401 30 120390 120383 (some row_10) (SearchFacts.query_74 LCMSourcePV.PrimeFacts.prime_120383) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 120409 10712529 349 353 359 120397 120401 32 120396=(some row_10) :=
    choose0_skip 1000 30 120409 10712529 349 353 359 120397 120401 31 120396 120391 (some row_10) (SearchFacts.query_75 LCMSourcePV.PrimeFacts.prime_120391) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 120409 10712529 349 353 359 120401 16 120400=some row_10 :=
    choose1_hit 1000 30 32 120409 10712529 349 353 359 120401 15 120400 120397 row_10 (SearchFacts.query_76 LCMSourcePV.PrimeFacts.prime_120397) c0_0_0
  have hsqrt : Nat.sqrt 120409=347 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 120409+1)=some 349 := by
    rw [hsqrt];exact (SearchFacts.query_4131 LCMSourcePV.PrimeFacts.prime_349)
  exact make_hit 1000 30 32 16 120409 10712529 349 353 359 120401 row_10 h0 (SearchFacts.query_4132 LCMSourcePV.PrimeFacts.prime_353) (SearchFacts.query_4133 LCMSourcePV.PrimeFacts.prime_359) (SearchFacts.query_77 LCMSourcePV.PrimeFacts.prime_120401) c1_0
#print axioms make_10
end LCMSourcePV.Witness.BlockProofs
