/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_261 : Block := (Block.mk 4532641 4541160 2131 2137 2141 4532581 4532629 4532639)
theorem make_261 : make 1000 30 32 16 4532641 10712529=some row_261 := by
  have ck_0_2_0 : (Block.mk 4532641 4541160 2131 2137 2141 4532581 4532629 4532639).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2131 LCMSourcePV.PrimeFacts.prime_2137 LCMSourcePV.PrimeFacts.prime_2141 LCMSourcePV.PrimeFacts.prime_4532581 LCMSourcePV.PrimeFacts.prime_4532629 LCMSourcePV.PrimeFacts.prime_4532639
  have sh_0_2_0 : shrink 30 (Block.mk 4532641 4541160 2131 2137 2141 4532581 4532629 4532639)=some row_261 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 4532641 10712529 2131 2137 2141 4532629 4532639 30 4532598=some row_261 :=
    choose0_hit 1000 30 4532641 10712529 2131 2137 2141 4532629 4532639 29 4532598 4532581 row_261 (SearchFacts.query_2627 LCMSourcePV.PrimeFacts.prime_4532581) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 4532641 10712529 2131 2137 2141 4532629 4532639 31 4532608=(some row_261) :=
    choose0_skip 1000 30 4532641 10712529 2131 2137 2141 4532629 4532639 30 4532608 4532599 (some row_261) (SearchFacts.query_2628 LCMSourcePV.PrimeFacts.prime_4532599) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4532641 10712529 2131 2137 2141 4532629 4532639 32 4532628=(some row_261) :=
    choose0_skip 1000 30 4532641 10712529 2131 2137 2141 4532629 4532639 31 4532628 4532609 (some row_261) (SearchFacts.query_2629 LCMSourcePV.PrimeFacts.prime_4532609) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4532641 10712529 2131 2137 2141 4532639 16 4532638=some row_261 :=
    choose1_hit 1000 30 32 4532641 10712529 2131 2137 2141 4532639 15 4532638 4532629 row_261 (SearchFacts.query_2630 LCMSourcePV.PrimeFacts.prime_4532629) c0_0_0
  have hsqrt : Nat.sqrt 4532641=2129 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4532641+1)=some 2131 := by
    rw [hsqrt];exact (SearchFacts.query_4382 LCMSourcePV.PrimeFacts.prime_2131)
  exact make_hit 1000 30 32 16 4532641 10712529 2131 2137 2141 4532639 row_261 h0 (SearchFacts.query_4383 LCMSourcePV.PrimeFacts.prime_2137) (SearchFacts.query_4384 LCMSourcePV.PrimeFacts.prime_2141) (SearchFacts.query_2631 LCMSourcePV.PrimeFacts.prime_4532639) c1_0
#print axioms make_261
end LCMSourcePV.Witness.BlockProofs
