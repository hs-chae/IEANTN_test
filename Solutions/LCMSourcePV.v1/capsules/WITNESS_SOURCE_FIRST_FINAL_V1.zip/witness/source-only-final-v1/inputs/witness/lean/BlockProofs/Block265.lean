/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_265 : Block := (Block.mk 4592449 4635408 2153 2161 2179 4592339 4592389 4592429)
theorem make_265 : make 1000 30 32 16 4592449 10712529=some row_265 := by
  have ck_0_2_0 : (Block.mk 4592449 4635408 2153 2161 2179 4592339 4592389 4592429).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2153 LCMSourcePV.PrimeFacts.prime_2161 LCMSourcePV.PrimeFacts.prime_2179 LCMSourcePV.PrimeFacts.prime_4592339 LCMSourcePV.PrimeFacts.prime_4592389 LCMSourcePV.PrimeFacts.prime_4592429
  have sh_0_2_0 : shrink 30 (Block.mk 4592449 4635408 2153 2161 2179 4592339 4592389 4592429)=some row_265 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 4592449 10712529 2153 2161 2179 4592389 4592429 30 4592346=some row_265 :=
    choose0_hit 1000 30 4592449 10712529 2153 2161 2179 4592389 4592429 29 4592346 4592339 row_265 (SearchFacts.query_2681 LCMSourcePV.PrimeFacts.prime_4592339) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 4592449 10712529 2153 2161 2179 4592389 4592429 31 4592358=(some row_265) :=
    choose0_skip 1000 30 4592449 10712529 2153 2161 2179 4592389 4592429 30 4592358 4592347 (some row_265) (SearchFacts.query_2682 LCMSourcePV.PrimeFacts.prime_4592347) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4592449 10712529 2153 2161 2179 4592389 4592429 32 4592388=(some row_265) :=
    choose0_skip 1000 30 4592449 10712529 2153 2161 2179 4592389 4592429 31 4592388 4592359 (some row_265) (SearchFacts.query_2683 LCMSourcePV.PrimeFacts.prime_4592359) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4592449 10712529 2153 2161 2179 4592429 16 4592428=some row_265 :=
    choose1_hit 1000 30 32 4592449 10712529 2153 2161 2179 4592429 15 4592428 4592389 row_265 (SearchFacts.query_2684 LCMSourcePV.PrimeFacts.prime_4592389) c0_0_0
  have hsqrt : Nat.sqrt 4592449=2143 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4592449+1)=some 2153 := by
    rw [hsqrt];exact (SearchFacts.query_4386 LCMSourcePV.PrimeFacts.prime_2153)
  exact make_hit 1000 30 32 16 4592449 10712529 2153 2161 2179 4592429 row_265 h0 (SearchFacts.query_4387 LCMSourcePV.PrimeFacts.prime_2161) (SearchFacts.query_4388 LCMSourcePV.PrimeFacts.prime_2179) (SearchFacts.query_2685 LCMSourcePV.PrimeFacts.prime_4592429) c1_0
#print axioms make_265
end LCMSourcePV.Witness.BlockProofs
