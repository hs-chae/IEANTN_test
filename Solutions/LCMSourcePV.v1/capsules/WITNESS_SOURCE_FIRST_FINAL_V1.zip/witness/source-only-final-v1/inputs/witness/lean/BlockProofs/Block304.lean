/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_304 : Block := (Block.mk 5987809 6046680 2459 2467 2473 5987561 5987789 5987803)
theorem make_304 : make 1000 30 32 16 5987809 10712529=some row_304 := by
  have ck_0_19_0 : (Block.mk 5987809 6046680 2459 2467 2473 5987561 5987789 5987803).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2459 LCMSourcePV.PrimeFacts.prime_2467 LCMSourcePV.PrimeFacts.prime_2473 LCMSourcePV.PrimeFacts.prime_5987561 LCMSourcePV.PrimeFacts.prime_5987789 LCMSourcePV.PrimeFacts.prime_5987803
  have sh_0_19_0 : shrink 30 (Block.mk 5987809 6046680 2459 2467 2473 5987561 5987789 5987803)=some row_304 := shrink_hit _ _ ck_0_19_0
  have c0_0_19 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 13 5987562=some row_304 :=
    choose0_hit 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 12 5987562 5987561 row_304 (SearchFacts.query_3052 LCMSourcePV.PrimeFacts.prime_5987561) (by decide) sh_0_19_0
  have c0_0_18 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 14 5987572=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 13 5987572 5987563 (some row_304) (SearchFacts.query_3053 LCMSourcePV.PrimeFacts.prime_5987563) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 15 5987592=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 14 5987592 5987573 (some row_304) (SearchFacts.query_3054 LCMSourcePV.PrimeFacts.prime_5987573) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 16 5987608=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 15 5987608 5987593 (some row_304) (SearchFacts.query_3055 LCMSourcePV.PrimeFacts.prime_5987593) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 17 5987626=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 16 5987626 5987609 (some row_304) (SearchFacts.query_3056 LCMSourcePV.PrimeFacts.prime_5987609) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 18 5987628=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 17 5987628 5987627 (some row_304) (SearchFacts.query_3057 LCMSourcePV.PrimeFacts.prime_5987627) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 19 5987632=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 18 5987632 5987629 (some row_304) (SearchFacts.query_3058 LCMSourcePV.PrimeFacts.prime_5987629) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 20 5987650=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 19 5987650 5987633 (some row_304) (SearchFacts.query_3059 LCMSourcePV.PrimeFacts.prime_5987633) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 21 5987676=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 20 5987676 5987651 (some row_304) (SearchFacts.query_3060 LCMSourcePV.PrimeFacts.prime_5987651) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 22 5987686=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 21 5987686 5987677 (some row_304) (SearchFacts.query_3061 LCMSourcePV.PrimeFacts.prime_5987677) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 23 5987692=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 22 5987692 5987687 (some row_304) (SearchFacts.query_3062 LCMSourcePV.PrimeFacts.prime_5987687) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 24 5987700=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 23 5987700 5987693 (some row_304) (SearchFacts.query_3063 LCMSourcePV.PrimeFacts.prime_5987693) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 25 5987718=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 24 5987718 5987701 (some row_304) (SearchFacts.query_3064 LCMSourcePV.PrimeFacts.prime_5987701) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 26 5987730=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 25 5987730 5987719 (some row_304) (SearchFacts.query_3065 LCMSourcePV.PrimeFacts.prime_5987719) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 27 5987748=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 26 5987748 5987731 (some row_304) (SearchFacts.query_3066 LCMSourcePV.PrimeFacts.prime_5987731) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 28 5987758=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 27 5987758 5987749 (some row_304) (SearchFacts.query_3067 LCMSourcePV.PrimeFacts.prime_5987749) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 29 5987766=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 28 5987766 5987759 (some row_304) (SearchFacts.query_3068 LCMSourcePV.PrimeFacts.prime_5987759) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 30 5987770=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 29 5987770 5987767 (some row_304) (SearchFacts.query_3069 LCMSourcePV.PrimeFacts.prime_5987767) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 31 5987776=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 30 5987776 5987771 (some row_304) (SearchFacts.query_3070 LCMSourcePV.PrimeFacts.prime_5987771) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 32 5987788=(some row_304) :=
    choose0_skip 1000 30 5987809 10712529 2459 2467 2473 5987789 5987803 31 5987788 5987777 (some row_304) (SearchFacts.query_3071 LCMSourcePV.PrimeFacts.prime_5987777) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5987809 10712529 2459 2467 2473 5987803 16 5987802=some row_304 :=
    choose1_hit 1000 30 32 5987809 10712529 2459 2467 2473 5987803 15 5987802 5987789 row_304 (SearchFacts.query_3072 LCMSourcePV.PrimeFacts.prime_5987789) c0_0_0
  have hsqrt : Nat.sqrt 5987809=2447 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5987809+1)=some 2459 := by
    rw [hsqrt];exact (SearchFacts.query_4425 LCMSourcePV.PrimeFacts.prime_2459)
  exact make_hit 1000 30 32 16 5987809 10712529 2459 2467 2473 5987803 row_304 h0 (SearchFacts.query_4426 LCMSourcePV.PrimeFacts.prime_2467) (SearchFacts.query_4427 LCMSourcePV.PrimeFacts.prime_2473) (SearchFacts.query_3073 LCMSourcePV.PrimeFacts.prime_5987803) c1_0
#print axioms make_304
end LCMSourcePV.Witness.BlockProofs
