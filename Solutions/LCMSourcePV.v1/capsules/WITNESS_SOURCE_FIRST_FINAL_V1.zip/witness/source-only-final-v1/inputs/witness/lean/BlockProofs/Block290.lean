/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_290 : Block := (Block.mk 5527201 5555448 2357 2371 2377 5527103 5527163 5527189)
theorem make_290 : make 1000 30 32 16 5527201 10712529=some row_290 := by
  have ck_0_3_0 : (Block.mk 5527201 5555448 2357 2371 2377 5527103 5527163 5527189).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2357 LCMSourcePV.PrimeFacts.prime_2371 LCMSourcePV.PrimeFacts.prime_2377 LCMSourcePV.PrimeFacts.prime_5527103 LCMSourcePV.PrimeFacts.prime_5527163 LCMSourcePV.PrimeFacts.prime_5527189
  have sh_0_3_0 : shrink 30 (Block.mk 5527201 5555448 2357 2371 2377 5527103 5527163 5527189)=some row_290 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 5527201 10712529 2357 2371 2377 5527163 5527189 29 5527116=some row_290 :=
    choose0_hit 1000 30 5527201 10712529 2357 2371 2377 5527163 5527189 28 5527116 5527103 row_290 (SearchFacts.query_2927 LCMSourcePV.PrimeFacts.prime_5527103) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 5527201 10712529 2357 2371 2377 5527163 5527189 30 5527120=(some row_290) :=
    choose0_skip 1000 30 5527201 10712529 2357 2371 2377 5527163 5527189 29 5527120 5527117 (some row_290) (SearchFacts.query_2928 LCMSourcePV.PrimeFacts.prime_5527117) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5527201 10712529 2357 2371 2377 5527163 5527189 31 5527146=(some row_290) :=
    choose0_skip 1000 30 5527201 10712529 2357 2371 2377 5527163 5527189 30 5527146 5527121 (some row_290) (SearchFacts.query_2929 LCMSourcePV.PrimeFacts.prime_5527121) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5527201 10712529 2357 2371 2377 5527163 5527189 32 5527162=(some row_290) :=
    choose0_skip 1000 30 5527201 10712529 2357 2371 2377 5527163 5527189 31 5527162 5527147 (some row_290) (SearchFacts.query_2930 LCMSourcePV.PrimeFacts.prime_5527147) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5527201 10712529 2357 2371 2377 5527189 16 5527188=some row_290 :=
    choose1_hit 1000 30 32 5527201 10712529 2357 2371 2377 5527189 15 5527188 5527163 row_290 (SearchFacts.query_2931 LCMSourcePV.PrimeFacts.prime_5527163) c0_0_0
  have hsqrt : Nat.sqrt 5527201=2351 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5527201+1)=some 2357 := by
    rw [hsqrt];exact (SearchFacts.query_4411 LCMSourcePV.PrimeFacts.prime_2357)
  exact make_hit 1000 30 32 16 5527201 10712529 2357 2371 2377 5527189 row_290 h0 (SearchFacts.query_4412 LCMSourcePV.PrimeFacts.prime_2371) (SearchFacts.query_4413 LCMSourcePV.PrimeFacts.prime_2377) (SearchFacts.query_2932 LCMSourcePV.PrimeFacts.prime_5527189) c1_0
#print axioms make_290
end LCMSourcePV.Witness.BlockProofs
