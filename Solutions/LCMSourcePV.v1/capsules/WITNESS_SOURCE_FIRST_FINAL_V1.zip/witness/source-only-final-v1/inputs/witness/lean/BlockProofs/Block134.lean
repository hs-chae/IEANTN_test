/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_134 : Block := (Block.mk 1371241 1394760 1181 1187 1193 1371079 1371217 1371229)
theorem make_134 : make 1000 30 32 16 1371241 10712529=some row_134 := by
  have ck_0_12_0 : (Block.mk 1371241 1394760 1181 1187 1193 1371079 1371217 1371229).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1181 LCMSourcePV.PrimeFacts.prime_1187 LCMSourcePV.PrimeFacts.prime_1193 LCMSourcePV.PrimeFacts.prime_1371079 LCMSourcePV.PrimeFacts.prime_1371217 LCMSourcePV.PrimeFacts.prime_1371229
  have sh_0_12_0 : shrink 30 (Block.mk 1371241 1394760 1181 1187 1193 1371079 1371217 1371229)=some row_134 := shrink_hit _ _ ck_0_12_0
  have c0_0_12 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 20 1371088=some row_134 :=
    choose0_hit 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 19 1371088 1371079 row_134 (SearchFacts.query_1455 LCMSourcePV.PrimeFacts.prime_1371079) (by decide) sh_0_12_0
  have c0_0_11 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 21 1371102=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 20 1371102 1371089 (some row_134) (SearchFacts.query_1456 LCMSourcePV.PrimeFacts.prime_1371089) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 22 1371106=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 21 1371106 1371103 (some row_134) (SearchFacts.query_1457 LCMSourcePV.PrimeFacts.prime_1371103) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 23 1371112=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 22 1371112 1371107 (some row_134) (SearchFacts.query_1458 LCMSourcePV.PrimeFacts.prime_1371107) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 24 1371118=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 23 1371118 1371113 (some row_134) (SearchFacts.query_1459 LCMSourcePV.PrimeFacts.prime_1371113) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 25 1371120=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 24 1371120 1371119 (some row_134) (SearchFacts.query_1460 LCMSourcePV.PrimeFacts.prime_1371119) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 26 1371136=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 25 1371136 1371121 (some row_134) (SearchFacts.query_1461 LCMSourcePV.PrimeFacts.prime_1371121) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 27 1371150=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 26 1371150 1371137 (some row_134) (SearchFacts.query_1462 LCMSourcePV.PrimeFacts.prime_1371137) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 28 1371156=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 27 1371156 1371151 (some row_134) (SearchFacts.query_1463 LCMSourcePV.PrimeFacts.prime_1371151) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 29 1371178=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 28 1371178 1371157 (some row_134) (SearchFacts.query_1464 LCMSourcePV.PrimeFacts.prime_1371157) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 30 1371186=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 29 1371186 1371179 (some row_134) (SearchFacts.query_1465 LCMSourcePV.PrimeFacts.prime_1371179) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 31 1371192=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 30 1371192 1371187 (some row_134) (SearchFacts.query_1466 LCMSourcePV.PrimeFacts.prime_1371187) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 32 1371216=(some row_134) :=
    choose0_skip 1000 30 1371241 10712529 1181 1187 1193 1371217 1371229 31 1371216 1371193 (some row_134) (SearchFacts.query_1467 LCMSourcePV.PrimeFacts.prime_1371193) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1371241 10712529 1181 1187 1193 1371229 16 1371228=some row_134 :=
    choose1_hit 1000 30 32 1371241 10712529 1181 1187 1193 1371229 15 1371228 1371217 row_134 (SearchFacts.query_1468 LCMSourcePV.PrimeFacts.prime_1371217) c0_0_0
  have hsqrt : Nat.sqrt 1371241=1171 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1371241+1)=some 1181 := by
    rw [hsqrt];exact (SearchFacts.query_4255 LCMSourcePV.PrimeFacts.prime_1181)
  exact make_hit 1000 30 32 16 1371241 10712529 1181 1187 1193 1371229 row_134 h0 (SearchFacts.query_4256 LCMSourcePV.PrimeFacts.prime_1187) (SearchFacts.query_4257 LCMSourcePV.PrimeFacts.prime_1193) (SearchFacts.query_1469 LCMSourcePV.PrimeFacts.prime_1371229) c1_0
#print axioms make_134
end LCMSourcePV.Witness.BlockProofs
