/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_103 : Block := (Block.mk 908209 935088 967 971 977 908053 908183 908197)
theorem make_103 : make 1000 30 32 16 908209 10712529=some row_103 := by
  have ck_0_9_0 : (Block.mk 908209 935088 967 971 977 908053 908183 908197).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_967 LCMSourcePV.PrimeFacts.prime_971 LCMSourcePV.PrimeFacts.prime_977 LCMSourcePV.PrimeFacts.prime_908053 LCMSourcePV.PrimeFacts.prime_908183 LCMSourcePV.PrimeFacts.prime_908197
  have sh_0_9_0 : shrink 30 (Block.mk 908209 935088 967 971 977 908053 908183 908197)=some row_103 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 23 908056=some row_103 :=
    choose0_hit 1000 30 908209 10712529 967 971 977 908183 908197 22 908056 908053 row_103 (SearchFacts.query_1066 LCMSourcePV.PrimeFacts.prime_908053) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 24 908070=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 23 908070 908057 (some row_103) (SearchFacts.query_1067 LCMSourcePV.PrimeFacts.prime_908057) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 25 908080=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 24 908080 908071 (some row_103) (SearchFacts.query_1068 LCMSourcePV.PrimeFacts.prime_908071) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 26 908100=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 25 908100 908081 (some row_103) (SearchFacts.query_1069 LCMSourcePV.PrimeFacts.prime_908081) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 27 908112=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 26 908112 908101 (some row_103) (SearchFacts.query_1070 LCMSourcePV.PrimeFacts.prime_908101) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 28 908128=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 27 908128 908113 (some row_103) (SearchFacts.query_1071 LCMSourcePV.PrimeFacts.prime_908113) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 29 908136=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 28 908136 908129 (some row_103) (SearchFacts.query_1072 LCMSourcePV.PrimeFacts.prime_908129) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 30 908152=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 29 908152 908137 (some row_103) (SearchFacts.query_1073 LCMSourcePV.PrimeFacts.prime_908137) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 31 908178=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 30 908178 908153 (some row_103) (SearchFacts.query_1074 LCMSourcePV.PrimeFacts.prime_908153) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 908209 10712529 967 971 977 908183 908197 32 908182=(some row_103) :=
    choose0_skip 1000 30 908209 10712529 967 971 977 908183 908197 31 908182 908179 (some row_103) (SearchFacts.query_1075 LCMSourcePV.PrimeFacts.prime_908179) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 908209 10712529 967 971 977 908197 16 908196=some row_103 :=
    choose1_hit 1000 30 32 908209 10712529 967 971 977 908197 15 908196 908183 row_103 (SearchFacts.query_1076 LCMSourcePV.PrimeFacts.prime_908183) c0_0_0
  have hsqrt : Nat.sqrt 908209=953 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 908209+1)=some 967 := by
    rw [hsqrt];exact (SearchFacts.query_4224 LCMSourcePV.PrimeFacts.prime_967)
  exact make_hit 1000 30 32 16 908209 10712529 967 971 977 908197 row_103 h0 (SearchFacts.query_4225 LCMSourcePV.PrimeFacts.prime_971) (SearchFacts.query_4226 LCMSourcePV.PrimeFacts.prime_977) (SearchFacts.query_1077 LCMSourcePV.PrimeFacts.prime_908197) c1_0
#print axioms make_103
end LCMSourcePV.Witness.BlockProofs
