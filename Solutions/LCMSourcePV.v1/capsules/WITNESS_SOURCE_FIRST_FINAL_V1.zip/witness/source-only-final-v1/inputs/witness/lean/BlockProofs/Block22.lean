/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_22 : Block := (Block.mk 175561 177240 421 431 433 175433 175523 175543)
theorem make_22 : make 1000 30 32 16 175561 10712529=some row_22 := by
  have ck_0_7_0 : (Block.mk 175561 177240 421 431 433 175433 175523 175543).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_421 LCMSourcePV.PrimeFacts.prime_431 LCMSourcePV.PrimeFacts.prime_433 LCMSourcePV.PrimeFacts.prime_175433 LCMSourcePV.PrimeFacts.prime_175523 LCMSourcePV.PrimeFacts.prime_175543
  have sh_0_7_0 : shrink 30 (Block.mk 175561 177240 421 431 433 175433 175523 175543)=some row_22 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 175561 10712529 421 431 433 175523 175543 25 175446=some row_22 :=
    choose0_hit 1000 30 175561 10712529 421 431 433 175523 175543 24 175446 175433 row_22 (SearchFacts.query_228 LCMSourcePV.PrimeFacts.prime_175433) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 175561 10712529 421 431 433 175523 175543 26 175452=(some row_22) :=
    choose0_skip 1000 30 175561 10712529 421 431 433 175523 175543 25 175452 175447 (some row_22) (SearchFacts.query_229 LCMSourcePV.PrimeFacts.prime_175447) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 175561 10712529 421 431 433 175523 175543 27 175462=(some row_22) :=
    choose0_skip 1000 30 175561 10712529 421 431 433 175523 175543 26 175462 175453 (some row_22) (SearchFacts.query_230 LCMSourcePV.PrimeFacts.prime_175453) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 175561 10712529 421 431 433 175523 175543 28 175480=(some row_22) :=
    choose0_skip 1000 30 175561 10712529 421 431 433 175523 175543 27 175480 175463 (some row_22) (SearchFacts.query_231 LCMSourcePV.PrimeFacts.prime_175463) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 175561 10712529 421 431 433 175523 175543 29 175492=(some row_22) :=
    choose0_skip 1000 30 175561 10712529 421 431 433 175523 175543 28 175492 175481 (some row_22) (SearchFacts.query_232 LCMSourcePV.PrimeFacts.prime_175481) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 175561 10712529 421 431 433 175523 175543 30 175498=(some row_22) :=
    choose0_skip 1000 30 175561 10712529 421 431 433 175523 175543 29 175498 175493 (some row_22) (SearchFacts.query_233 LCMSourcePV.PrimeFacts.prime_175493) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 175561 10712529 421 431 433 175523 175543 31 175518=(some row_22) :=
    choose0_skip 1000 30 175561 10712529 421 431 433 175523 175543 30 175518 175499 (some row_22) (SearchFacts.query_234 LCMSourcePV.PrimeFacts.prime_175499) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 175561 10712529 421 431 433 175523 175543 32 175522=(some row_22) :=
    choose0_skip 1000 30 175561 10712529 421 431 433 175523 175543 31 175522 175519 (some row_22) (SearchFacts.query_235 LCMSourcePV.PrimeFacts.prime_175519) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 175561 10712529 421 431 433 175543 16 175542=some row_22 :=
    choose1_hit 1000 30 32 175561 10712529 421 431 433 175543 15 175542 175523 row_22 (SearchFacts.query_236 LCMSourcePV.PrimeFacts.prime_175523) c0_0_0
  have hsqrt : Nat.sqrt 175561=419 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 175561+1)=some 421 := by
    rw [hsqrt];exact (SearchFacts.query_4143 LCMSourcePV.PrimeFacts.prime_421)
  exact make_hit 1000 30 32 16 175561 10712529 421 431 433 175543 row_22 h0 (SearchFacts.query_4144 LCMSourcePV.PrimeFacts.prime_431) (SearchFacts.query_4145 LCMSourcePV.PrimeFacts.prime_433) (SearchFacts.query_237 LCMSourcePV.PrimeFacts.prime_175543) c1_0
#print axioms make_22
end LCMSourcePV.Witness.BlockProofs
