/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_245 : Block := (Block.mk 4012009 4044120 2011 2017 2027 4011701 4011979 4011991)
theorem make_245 : make 1000 30 32 16 4012009 10712529=some row_245 := by
  have ck_0_20_0 : (Block.mk 4012009 4044120 2011 2017 2027 4011701 4011979 4011991).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2011 LCMSourcePV.PrimeFacts.prime_2017 LCMSourcePV.PrimeFacts.prime_2027 LCMSourcePV.PrimeFacts.prime_4011701 LCMSourcePV.PrimeFacts.prime_4011979 LCMSourcePV.PrimeFacts.prime_4011991
  have sh_0_20_0 : shrink 30 (Block.mk 4012009 4044120 2011 2017 2027 4011701 4011979 4011991)=some row_245 := shrink_hit _ _ ck_0_20_0
  have c0_0_20 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 12 4011702=some row_245 :=
    choose0_hit 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 11 4011702 4011701 row_245 (SearchFacts.query_2495 LCMSourcePV.PrimeFacts.prime_4011701) (by decide) sh_0_20_0
  have c0_0_19 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 13 4011718=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 12 4011718 4011703 (some row_245) (SearchFacts.query_2496 LCMSourcePV.PrimeFacts.prime_4011703) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 14 4011730=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 13 4011730 4011719 (some row_245) (SearchFacts.query_2497 LCMSourcePV.PrimeFacts.prime_4011719) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 15 4011736=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 14 4011736 4011731 (some row_245) (SearchFacts.query_2498 LCMSourcePV.PrimeFacts.prime_4011731) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 16 4011766=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 15 4011766 4011737 (some row_245) (SearchFacts.query_2499 LCMSourcePV.PrimeFacts.prime_4011737) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 17 4011768=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 16 4011768 4011767 (some row_245) (SearchFacts.query_2500 LCMSourcePV.PrimeFacts.prime_4011767) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 18 4011780=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 17 4011780 4011769 (some row_245) (SearchFacts.query_2501 LCMSourcePV.PrimeFacts.prime_4011769) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 19 4011796=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 18 4011796 4011781 (some row_245) (SearchFacts.query_2502 LCMSourcePV.PrimeFacts.prime_4011781) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 20 4011810=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 19 4011810 4011797 (some row_245) (SearchFacts.query_2503 LCMSourcePV.PrimeFacts.prime_4011797) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 21 4011816=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 20 4011816 4011811 (some row_245) (SearchFacts.query_2504 LCMSourcePV.PrimeFacts.prime_4011811) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 22 4011826=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 21 4011826 4011817 (some row_245) (SearchFacts.query_2505 LCMSourcePV.PrimeFacts.prime_4011817) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 23 4011858=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 22 4011858 4011827 (some row_245) (SearchFacts.query_2506 LCMSourcePV.PrimeFacts.prime_4011827) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 24 4011862=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 23 4011862 4011859 (some row_245) (SearchFacts.query_2507 LCMSourcePV.PrimeFacts.prime_4011859) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 25 4011870=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 24 4011870 4011863 (some row_245) (SearchFacts.query_2508 LCMSourcePV.PrimeFacts.prime_4011863) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 26 4011882=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 25 4011882 4011871 (some row_245) (SearchFacts.query_2509 LCMSourcePV.PrimeFacts.prime_4011871) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 27 4011898=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 26 4011898 4011883 (some row_245) (SearchFacts.query_2510 LCMSourcePV.PrimeFacts.prime_4011883) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 28 4011910=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 27 4011910 4011899 (some row_245) (SearchFacts.query_2511 LCMSourcePV.PrimeFacts.prime_4011899) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 29 4011922=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 28 4011922 4011911 (some row_245) (SearchFacts.query_2512 LCMSourcePV.PrimeFacts.prime_4011911) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 30 4011928=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 29 4011928 4011923 (some row_245) (SearchFacts.query_2513 LCMSourcePV.PrimeFacts.prime_4011923) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 31 4011976=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 30 4011976 4011929 (some row_245) (SearchFacts.query_2514 LCMSourcePV.PrimeFacts.prime_4011929) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 32 4011978=(some row_245) :=
    choose0_skip 1000 30 4012009 10712529 2011 2017 2027 4011979 4011991 31 4011978 4011977 (some row_245) (SearchFacts.query_2515 LCMSourcePV.PrimeFacts.prime_4011977) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4012009 10712529 2011 2017 2027 4011991 16 4011990=some row_245 :=
    choose1_hit 1000 30 32 4012009 10712529 2011 2017 2027 4011991 15 4011990 4011979 row_245 (SearchFacts.query_2516 LCMSourcePV.PrimeFacts.prime_4011979) c0_0_0
  have hsqrt : Nat.sqrt 4012009=2003 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4012009+1)=some 2011 := by
    rw [hsqrt];exact (SearchFacts.query_4366 LCMSourcePV.PrimeFacts.prime_2011)
  exact make_hit 1000 30 32 16 4012009 10712529 2011 2017 2027 4011991 row_245 h0 (SearchFacts.query_4367 LCMSourcePV.PrimeFacts.prime_2017) (SearchFacts.query_4368 LCMSourcePV.PrimeFacts.prime_2027) (SearchFacts.query_2517 LCMSourcePV.PrimeFacts.prime_4011991) c1_0
#print axioms make_245
end LCMSourcePV.Witness.BlockProofs
