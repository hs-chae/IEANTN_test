/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_164 : Block := (Block.mk 1985281 2024928 1423 1427 1429 1985213 1985257 1985279)
theorem make_164 : make 1000 30 32 16 1985281 10712529=some row_164 := by
  have ck_0_4_0 : (Block.mk 1985281 2024928 1423 1427 1429 1985213 1985257 1985279).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1423 LCMSourcePV.PrimeFacts.prime_1427 LCMSourcePV.PrimeFacts.prime_1429 LCMSourcePV.PrimeFacts.prime_1985213 LCMSourcePV.PrimeFacts.prime_1985257 LCMSourcePV.PrimeFacts.prime_1985279
  have sh_0_4_0 : shrink 30 (Block.mk 1985281 2024928 1423 1427 1429 1985213 1985257 1985279)=some row_164 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 28 1985218=some row_164 :=
    choose0_hit 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 27 1985218 1985213 row_164 (SearchFacts.query_1690 LCMSourcePV.PrimeFacts.prime_1985213) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 29 1985226=(some row_164) :=
    choose0_skip 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 28 1985226 1985219 (some row_164) (SearchFacts.query_1691 LCMSourcePV.PrimeFacts.prime_1985219) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 30 1985236=(some row_164) :=
    choose0_skip 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 29 1985236 1985227 (some row_164) (SearchFacts.query_1692 LCMSourcePV.PrimeFacts.prime_1985227) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 31 1985238=(some row_164) :=
    choose0_skip 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 30 1985238 1985237 (some row_164) (SearchFacts.query_1693 LCMSourcePV.PrimeFacts.prime_1985237) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 32 1985256=(some row_164) :=
    choose0_skip 1000 30 1985281 10712529 1423 1427 1429 1985257 1985279 31 1985256 1985239 (some row_164) (SearchFacts.query_1694 LCMSourcePV.PrimeFacts.prime_1985239) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1985281 10712529 1423 1427 1429 1985279 16 1985278=some row_164 :=
    choose1_hit 1000 30 32 1985281 10712529 1423 1427 1429 1985279 15 1985278 1985257 row_164 (SearchFacts.query_1695 LCMSourcePV.PrimeFacts.prime_1985257) c0_0_0
  have hsqrt : Nat.sqrt 1985281=1409 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1985281+1)=some 1423 := by
    rw [hsqrt];exact (SearchFacts.query_4285 LCMSourcePV.PrimeFacts.prime_1423)
  exact make_hit 1000 30 32 16 1985281 10712529 1423 1427 1429 1985279 row_164 h0 (SearchFacts.query_4286 LCMSourcePV.PrimeFacts.prime_1427) (SearchFacts.query_4287 LCMSourcePV.PrimeFacts.prime_1429) (SearchFacts.query_1696 LCMSourcePV.PrimeFacts.prime_1985279) c1_0
#print axioms make_164
end LCMSourcePV.Witness.BlockProofs
