/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_301 : Block := (Block.mk 5870929 5938968 2437 2441 2447 5870759 5870923 5870927)
theorem make_301 : make 1000 30 32 16 5870929 10712529=some row_301 := by
  have ck_0_7_0 : (Block.mk 5870929 5938968 2437 2441 2447 5870759 5870923 5870927).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2437 LCMSourcePV.PrimeFacts.prime_2441 LCMSourcePV.PrimeFacts.prime_2447 LCMSourcePV.PrimeFacts.prime_5870759 LCMSourcePV.PrimeFacts.prime_5870923 LCMSourcePV.PrimeFacts.prime_5870927
  have sh_0_7_0 : shrink 30 (Block.mk 5870929 5938968 2437 2441 2447 5870759 5870923 5870927)=some row_301 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 25 5870778=some row_301 :=
    choose0_hit 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 24 5870778 5870759 row_301 (SearchFacts.query_3020 LCMSourcePV.PrimeFacts.prime_5870759) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 26 5870782=(some row_301) :=
    choose0_skip 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 25 5870782 5870779 (some row_301) (SearchFacts.query_3021 LCMSourcePV.PrimeFacts.prime_5870779) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 27 5870800=(some row_301) :=
    choose0_skip 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 26 5870800 5870783 (some row_301) (SearchFacts.query_3022 LCMSourcePV.PrimeFacts.prime_5870783) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 28 5870802=(some row_301) :=
    choose0_skip 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 27 5870802 5870801 (some row_301) (SearchFacts.query_3023 LCMSourcePV.PrimeFacts.prime_5870801) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 29 5870806=(some row_301) :=
    choose0_skip 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 28 5870806 5870803 (some row_301) (SearchFacts.query_3024 LCMSourcePV.PrimeFacts.prime_5870803) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 30 5870856=(some row_301) :=
    choose0_skip 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 29 5870856 5870807 (some row_301) (SearchFacts.query_3025 LCMSourcePV.PrimeFacts.prime_5870807) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 31 5870880=(some row_301) :=
    choose0_skip 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 30 5870880 5870857 (some row_301) (SearchFacts.query_3026 LCMSourcePV.PrimeFacts.prime_5870857) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 32 5870922=(some row_301) :=
    choose0_skip 1000 30 5870929 10712529 2437 2441 2447 5870923 5870927 31 5870922 5870881 (some row_301) (SearchFacts.query_3027 LCMSourcePV.PrimeFacts.prime_5870881) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5870929 10712529 2437 2441 2447 5870927 16 5870926=some row_301 :=
    choose1_hit 1000 30 32 5870929 10712529 2437 2441 2447 5870927 15 5870926 5870923 row_301 (SearchFacts.query_3028 LCMSourcePV.PrimeFacts.prime_5870923) c0_0_0
  have hsqrt : Nat.sqrt 5870929=2423 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5870929+1)=some 2437 := by
    rw [hsqrt];exact (SearchFacts.query_4422 LCMSourcePV.PrimeFacts.prime_2437)
  exact make_hit 1000 30 32 16 5870929 10712529 2437 2441 2447 5870927 row_301 h0 (SearchFacts.query_4423 LCMSourcePV.PrimeFacts.prime_2441) (SearchFacts.query_4424 LCMSourcePV.PrimeFacts.prime_2447) (SearchFacts.query_3029 LCMSourcePV.PrimeFacts.prime_5870927) c1_0
#print axioms make_301
end LCMSourcePV.Witness.BlockProofs
