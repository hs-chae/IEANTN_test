/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_325 : Block := (Block.mk 7059649 7070280 2659 2663 2671 7059529 7059629 7059631)
theorem make_325 : make 1000 30 32 16 7059649 10712529=some row_325 := by
  have ck_0_4_0 : (Block.mk 7059649 7070280 2659 2663 2671 7059529 7059629 7059631).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2659 LCMSourcePV.PrimeFacts.prime_2663 LCMSourcePV.PrimeFacts.prime_2671 LCMSourcePV.PrimeFacts.prime_7059529 LCMSourcePV.PrimeFacts.prime_7059629 LCMSourcePV.PrimeFacts.prime_7059631
  have sh_0_4_0 : shrink 30 (Block.mk 7059649 7070280 2659 2663 2671 7059529 7059629 7059631)=some row_325 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 28 7059586=some row_325 :=
    choose0_hit 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 27 7059586 7059529 row_325 (SearchFacts.query_3325 LCMSourcePV.PrimeFacts.prime_7059529) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 29 7059592=(some row_325) :=
    choose0_skip 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 28 7059592 7059587 (some row_325) (SearchFacts.query_3326 LCMSourcePV.PrimeFacts.prime_7059587) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 30 7059616=(some row_325) :=
    choose0_skip 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 29 7059616 7059593 (some row_325) (SearchFacts.query_3327 LCMSourcePV.PrimeFacts.prime_7059593) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 31 7059622=(some row_325) :=
    choose0_skip 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 30 7059622 7059617 (some row_325) (SearchFacts.query_3328 LCMSourcePV.PrimeFacts.prime_7059617) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 32 7059628=(some row_325) :=
    choose0_skip 1000 30 7059649 10712529 2659 2663 2671 7059629 7059631 31 7059628 7059623 (some row_325) (SearchFacts.query_3329 LCMSourcePV.PrimeFacts.prime_7059623) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 7059649 10712529 2659 2663 2671 7059631 16 7059630=some row_325 :=
    choose1_hit 1000 30 32 7059649 10712529 2659 2663 2671 7059631 15 7059630 7059629 row_325 (SearchFacts.query_3330 LCMSourcePV.PrimeFacts.prime_7059629) c0_0_0
  have hsqrt : Nat.sqrt 7059649=2657 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 7059649+1)=some 2659 := by
    rw [hsqrt];exact (SearchFacts.query_4446 LCMSourcePV.PrimeFacts.prime_2659)
  exact make_hit 1000 30 32 16 7059649 10712529 2659 2663 2671 7059631 row_325 h0 (SearchFacts.query_4447 LCMSourcePV.PrimeFacts.prime_2663) (SearchFacts.query_4448 LCMSourcePV.PrimeFacts.prime_2671) (SearchFacts.query_3331 LCMSourcePV.PrimeFacts.prime_7059631) c1_0
#print axioms make_325
end LCMSourcePV.Witness.BlockProofs
