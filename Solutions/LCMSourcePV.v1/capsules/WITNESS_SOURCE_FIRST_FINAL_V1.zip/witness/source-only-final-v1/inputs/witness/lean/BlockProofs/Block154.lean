/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_154 : Block := (Block.mk 1697809 1708248 1307 1319 1321 1697581 1697797 1697803)
theorem make_154 : make 1000 30 32 16 1697809 10712529=some row_154 := by
  have ck_0_15_0 : (Block.mk 1697809 1708248 1307 1319 1321 1697581 1697797 1697803).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1307 LCMSourcePV.PrimeFacts.prime_1319 LCMSourcePV.PrimeFacts.prime_1321 LCMSourcePV.PrimeFacts.prime_1697581 LCMSourcePV.PrimeFacts.prime_1697797 LCMSourcePV.PrimeFacts.prime_1697803
  have sh_0_15_0 : shrink 30 (Block.mk 1697809 1708248 1307 1319 1321 1697581 1697797 1697803)=some row_154 := shrink_hit _ _ ck_0_15_0
  have c0_0_15 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 17 1697586=some row_154 :=
    choose0_hit 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 16 1697586 1697581 row_154 (SearchFacts.query_1602 LCMSourcePV.PrimeFacts.prime_1697581) (by decide) sh_0_15_0
  have c0_0_14 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 18 1697620=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 17 1697620 1697587 (some row_154) (SearchFacts.query_1603 LCMSourcePV.PrimeFacts.prime_1697587) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 19 1697622=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 18 1697622 1697621 (some row_154) (SearchFacts.query_1604 LCMSourcePV.PrimeFacts.prime_1697621) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 20 1697626=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 19 1697626 1697623 (some row_154) (SearchFacts.query_1605 LCMSourcePV.PrimeFacts.prime_1697623) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 21 1697650=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 20 1697650 1697627 (some row_154) (SearchFacts.query_1606 LCMSourcePV.PrimeFacts.prime_1697627) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 22 1697676=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 21 1697676 1697651 (some row_154) (SearchFacts.query_1607 LCMSourcePV.PrimeFacts.prime_1697651) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 23 1697700=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 22 1697700 1697677 (some row_154) (SearchFacts.query_1608 LCMSourcePV.PrimeFacts.prime_1697677) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 24 1697718=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 23 1697718 1697701 (some row_154) (SearchFacts.query_1609 LCMSourcePV.PrimeFacts.prime_1697701) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 25 1697722=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 24 1697722 1697719 (some row_154) (SearchFacts.query_1610 LCMSourcePV.PrimeFacts.prime_1697719) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 26 1697736=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 25 1697736 1697723 (some row_154) (SearchFacts.query_1611 LCMSourcePV.PrimeFacts.prime_1697723) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 27 1697740=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 26 1697740 1697737 (some row_154) (SearchFacts.query_1612 LCMSourcePV.PrimeFacts.prime_1697737) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 28 1697742=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 27 1697742 1697741 (some row_154) (SearchFacts.query_1613 LCMSourcePV.PrimeFacts.prime_1697741) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 29 1697752=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 28 1697752 1697743 (some row_154) (SearchFacts.query_1614 LCMSourcePV.PrimeFacts.prime_1697743) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 30 1697766=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 29 1697766 1697753 (some row_154) (SearchFacts.query_1615 LCMSourcePV.PrimeFacts.prime_1697753) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 31 1697770=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 30 1697770 1697767 (some row_154) (SearchFacts.query_1616 LCMSourcePV.PrimeFacts.prime_1697767) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 32 1697796=(some row_154) :=
    choose0_skip 1000 30 1697809 10712529 1307 1319 1321 1697797 1697803 31 1697796 1697771 (some row_154) (SearchFacts.query_1617 LCMSourcePV.PrimeFacts.prime_1697771) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1697809 10712529 1307 1319 1321 1697803 16 1697802=some row_154 :=
    choose1_hit 1000 30 32 1697809 10712529 1307 1319 1321 1697803 15 1697802 1697797 row_154 (SearchFacts.query_1618 LCMSourcePV.PrimeFacts.prime_1697797) c0_0_0
  have hsqrt : Nat.sqrt 1697809=1303 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1697809+1)=some 1307 := by
    rw [hsqrt];exact (SearchFacts.query_4275 LCMSourcePV.PrimeFacts.prime_1307)
  exact make_hit 1000 30 32 16 1697809 10712529 1307 1319 1321 1697803 row_154 h0 (SearchFacts.query_4276 LCMSourcePV.PrimeFacts.prime_1319) (SearchFacts.query_4277 LCMSourcePV.PrimeFacts.prime_1321) (SearchFacts.query_1619 LCMSourcePV.PrimeFacts.prime_1697803) c1_0
#print axioms make_154
end LCMSourcePV.Witness.BlockProofs
