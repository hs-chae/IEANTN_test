/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_20 : Block := (Block.mk 160801 167280 409 419 421 160697 160781 160789)
theorem make_20 : make 1000 30 32 16 160801 10712529=some row_20 := by
  have ck_0_7_0 : (Block.mk 160801 167280 409 419 421 160697 160781 160789).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_409 LCMSourcePV.PrimeFacts.prime_419 LCMSourcePV.PrimeFacts.prime_421 LCMSourcePV.PrimeFacts.prime_160697 LCMSourcePV.PrimeFacts.prime_160781 LCMSourcePV.PrimeFacts.prime_160789
  have sh_0_7_0 : shrink 30 (Block.mk 160801 167280 409 419 421 160697 160781 160789)=some row_20 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 160801 10712529 409 419 421 160781 160789 25 160708=some row_20 :=
    choose0_hit 1000 30 160801 10712529 409 419 421 160781 160789 24 160708 160697 row_20 (SearchFacts.query_182 LCMSourcePV.PrimeFacts.prime_160697) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 160801 10712529 409 419 421 160781 160789 26 160710=(some row_20) :=
    choose0_skip 1000 30 160801 10712529 409 419 421 160781 160789 25 160710 160709 (some row_20) (SearchFacts.query_183 LCMSourcePV.PrimeFacts.prime_160709) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 160801 10712529 409 419 421 160781 160789 27 160722=(some row_20) :=
    choose0_skip 1000 30 160801 10712529 409 419 421 160781 160789 26 160722 160711 (some row_20) (SearchFacts.query_184 LCMSourcePV.PrimeFacts.prime_160711) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 160801 10712529 409 419 421 160781 160789 28 160738=(some row_20) :=
    choose0_skip 1000 30 160801 10712529 409 419 421 160781 160789 27 160738 160723 (some row_20) (SearchFacts.query_185 LCMSourcePV.PrimeFacts.prime_160723) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 160801 10712529 409 419 421 160781 160789 29 160750=(some row_20) :=
    choose0_skip 1000 30 160801 10712529 409 419 421 160781 160789 28 160750 160739 (some row_20) (SearchFacts.query_186 LCMSourcePV.PrimeFacts.prime_160739) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 160801 10712529 409 419 421 160781 160789 30 160752=(some row_20) :=
    choose0_skip 1000 30 160801 10712529 409 419 421 160781 160789 29 160752 160751 (some row_20) (SearchFacts.query_187 LCMSourcePV.PrimeFacts.prime_160751) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 160801 10712529 409 419 421 160781 160789 31 160756=(some row_20) :=
    choose0_skip 1000 30 160801 10712529 409 419 421 160781 160789 30 160756 160753 (some row_20) (SearchFacts.query_188 LCMSourcePV.PrimeFacts.prime_160753) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 160801 10712529 409 419 421 160781 160789 32 160780=(some row_20) :=
    choose0_skip 1000 30 160801 10712529 409 419 421 160781 160789 31 160780 160757 (some row_20) (SearchFacts.query_189 LCMSourcePV.PrimeFacts.prime_160757) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 160801 10712529 409 419 421 160789 16 160788=some row_20 :=
    choose1_hit 1000 30 32 160801 10712529 409 419 421 160789 15 160788 160781 row_20 (SearchFacts.query_190 LCMSourcePV.PrimeFacts.prime_160781) c0_0_0
  have hsqrt : Nat.sqrt 160801=401 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 160801+1)=some 409 := by
    rw [hsqrt];exact (SearchFacts.query_4141 LCMSourcePV.PrimeFacts.prime_409)
  exact make_hit 1000 30 32 16 160801 10712529 409 419 421 160789 row_20 h0 (SearchFacts.query_4142 LCMSourcePV.PrimeFacts.prime_419) (SearchFacts.query_4143 LCMSourcePV.PrimeFacts.prime_421) (SearchFacts.query_191 LCMSourcePV.PrimeFacts.prime_160789) c1_0
#print axioms make_20
end LCMSourcePV.Witness.BlockProofs
