/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_314 : Block := (Block.mk 6497401 6507600 2551 2557 2579 6497377 6497389 6497399)
theorem make_314 : make 1000 30 32 16 6497401 10712529=some row_314 := by
  have ck_0_0_0 : (Block.mk 6497401 6507600 2551 2557 2579 6497377 6497389 6497399).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2551 LCMSourcePV.PrimeFacts.prime_2557 LCMSourcePV.PrimeFacts.prime_2579 LCMSourcePV.PrimeFacts.prime_6497377 LCMSourcePV.PrimeFacts.prime_6497389 LCMSourcePV.PrimeFacts.prime_6497399
  have sh_0_0_0 : shrink 30 (Block.mk 6497401 6507600 2551 2557 2579 6497377 6497389 6497399)=some row_314 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 6497401 10712529 2551 2557 2579 6497389 6497399 32 6497388=some row_314 :=
    choose0_hit 1000 30 6497401 10712529 2551 2557 2579 6497389 6497399 31 6497388 6497377 row_314 (SearchFacts.query_3210 LCMSourcePV.PrimeFacts.prime_6497377) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 6497401 10712529 2551 2557 2579 6497399 16 6497398=some row_314 :=
    choose1_hit 1000 30 32 6497401 10712529 2551 2557 2579 6497399 15 6497398 6497389 row_314 (SearchFacts.query_3211 LCMSourcePV.PrimeFacts.prime_6497389) c0_0_0
  have hsqrt : Nat.sqrt 6497401=2549 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6497401+1)=some 2551 := by
    rw [hsqrt];exact (SearchFacts.query_4435 LCMSourcePV.PrimeFacts.prime_2551)
  exact make_hit 1000 30 32 16 6497401 10712529 2551 2557 2579 6497399 row_314 h0 (SearchFacts.query_4436 LCMSourcePV.PrimeFacts.prime_2557) (SearchFacts.query_4437 LCMSourcePV.PrimeFacts.prime_2579) (SearchFacts.query_3212 LCMSourcePV.PrimeFacts.prime_6497399) c1_0
#print axioms make_314
end LCMSourcePV.Witness.BlockProofs
