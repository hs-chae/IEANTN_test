/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_168 : Block := (Block.mk 2053489 2070720 1439 1447 1451 2053253 2053439 2053459)
theorem make_168 : make 1000 30 32 16 2053489 10712529=some row_168 := by
  have ck_0_12_0 : (Block.mk 2053489 2070720 1439 1447 1451 2053253 2053439 2053459).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1439 LCMSourcePV.PrimeFacts.prime_1447 LCMSourcePV.PrimeFacts.prime_1451 LCMSourcePV.PrimeFacts.prime_2053253 LCMSourcePV.PrimeFacts.prime_2053439 LCMSourcePV.PrimeFacts.prime_2053459
  have sh_0_12_0 : shrink 30 (Block.mk 2053489 2070720 1439 1447 1451 2053253 2053439 2053459)=some row_168 := shrink_hit _ _ ck_0_12_0
  have c0_0_12 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 20 2053290=some row_168 :=
    choose0_hit 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 19 2053290 2053253 row_168 (SearchFacts.query_1714 LCMSourcePV.PrimeFacts.prime_2053253) (by decide) sh_0_12_0
  have c0_0_11 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 21 2053306=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 20 2053306 2053291 (some row_168) (SearchFacts.query_1715 LCMSourcePV.PrimeFacts.prime_2053291) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 22 2053312=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 21 2053312 2053307 (some row_168) (SearchFacts.query_1716 LCMSourcePV.PrimeFacts.prime_2053307) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 23 2053332=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 22 2053332 2053313 (some row_168) (SearchFacts.query_1717 LCMSourcePV.PrimeFacts.prime_2053313) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 24 2053338=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 23 2053338 2053333 (some row_168) (SearchFacts.query_1718 LCMSourcePV.PrimeFacts.prime_2053333) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 25 2053356=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 24 2053356 2053339 (some row_168) (SearchFacts.query_1719 LCMSourcePV.PrimeFacts.prime_2053339) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 26 2053360=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 25 2053360 2053357 (some row_168) (SearchFacts.query_1720 LCMSourcePV.PrimeFacts.prime_2053357) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 27 2053396=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 26 2053396 2053361 (some row_168) (SearchFacts.query_1721 LCMSourcePV.PrimeFacts.prime_2053361) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 28 2053410=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 27 2053410 2053397 (some row_168) (SearchFacts.query_1722 LCMSourcePV.PrimeFacts.prime_2053397) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 29 2053420=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 28 2053420 2053411 (some row_168) (SearchFacts.query_1723 LCMSourcePV.PrimeFacts.prime_2053411) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 30 2053422=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 29 2053422 2053421 (some row_168) (SearchFacts.query_1724 LCMSourcePV.PrimeFacts.prime_2053421) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 31 2053426=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 30 2053426 2053423 (some row_168) (SearchFacts.query_1725 LCMSourcePV.PrimeFacts.prime_2053423) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 32 2053438=(some row_168) :=
    choose0_skip 1000 30 2053489 10712529 1439 1447 1451 2053439 2053459 31 2053438 2053427 (some row_168) (SearchFacts.query_1726 LCMSourcePV.PrimeFacts.prime_2053427) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2053489 10712529 1439 1447 1451 2053459 16 2053458=some row_168 :=
    choose1_hit 1000 30 32 2053489 10712529 1439 1447 1451 2053459 15 2053458 2053439 row_168 (SearchFacts.query_1727 LCMSourcePV.PrimeFacts.prime_2053439) c0_0_0
  have hsqrt : Nat.sqrt 2053489=1433 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2053489+1)=some 1439 := by
    rw [hsqrt];exact (SearchFacts.query_4289 LCMSourcePV.PrimeFacts.prime_1439)
  exact make_hit 1000 30 32 16 2053489 10712529 1439 1447 1451 2053459 row_168 h0 (SearchFacts.query_4290 LCMSourcePV.PrimeFacts.prime_1447) (SearchFacts.query_4291 LCMSourcePV.PrimeFacts.prime_1451) (SearchFacts.query_1728 LCMSourcePV.PrimeFacts.prime_2053459) c1_0
#print axioms make_168
end LCMSourcePV.Witness.BlockProofs
