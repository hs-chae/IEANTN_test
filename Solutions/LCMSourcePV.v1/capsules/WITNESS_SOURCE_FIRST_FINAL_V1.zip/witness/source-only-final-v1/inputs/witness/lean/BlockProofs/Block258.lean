/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_258 : Block := (Block.mk 4405801 4456320 2111 2113 2129 4405679 4405759 4405789)
theorem make_258 : make 1000 30 32 16 4405801 10712529=some row_258 := by
  have ck_0_7_0 : (Block.mk 4405801 4456320 2111 2113 2129 4405679 4405759 4405789).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2111 LCMSourcePV.PrimeFacts.prime_2113 LCMSourcePV.PrimeFacts.prime_2129 LCMSourcePV.PrimeFacts.prime_4405679 LCMSourcePV.PrimeFacts.prime_4405759 LCMSourcePV.PrimeFacts.prime_4405789
  have sh_0_7_0 : shrink 30 (Block.mk 4405801 4456320 2111 2113 2129 4405679 4405759 4405789)=some row_258 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 25 4405690=some row_258 :=
    choose0_hit 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 24 4405690 4405679 row_258 (SearchFacts.query_2607 LCMSourcePV.PrimeFacts.prime_4405679) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 26 4405692=(some row_258) :=
    choose0_skip 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 25 4405692 4405691 (some row_258) (SearchFacts.query_2608 LCMSourcePV.PrimeFacts.prime_4405691) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 27 4405696=(some row_258) :=
    choose0_skip 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 26 4405696 4405693 (some row_258) (SearchFacts.query_2609 LCMSourcePV.PrimeFacts.prime_4405693) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 28 4405698=(some row_258) :=
    choose0_skip 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 27 4405698 4405697 (some row_258) (SearchFacts.query_2610 LCMSourcePV.PrimeFacts.prime_4405697) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 29 4405716=(some row_258) :=
    choose0_skip 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 28 4405716 4405699 (some row_258) (SearchFacts.query_2611 LCMSourcePV.PrimeFacts.prime_4405699) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 30 4405740=(some row_258) :=
    choose0_skip 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 29 4405740 4405717 (some row_258) (SearchFacts.query_2612 LCMSourcePV.PrimeFacts.prime_4405717) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 31 4405746=(some row_258) :=
    choose0_skip 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 30 4405746 4405741 (some row_258) (SearchFacts.query_2613 LCMSourcePV.PrimeFacts.prime_4405741) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 32 4405758=(some row_258) :=
    choose0_skip 1000 30 4405801 10712529 2111 2113 2129 4405759 4405789 31 4405758 4405747 (some row_258) (SearchFacts.query_2614 LCMSourcePV.PrimeFacts.prime_4405747) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4405801 10712529 2111 2113 2129 4405789 16 4405788=some row_258 :=
    choose1_hit 1000 30 32 4405801 10712529 2111 2113 2129 4405789 15 4405788 4405759 row_258 (SearchFacts.query_2615 LCMSourcePV.PrimeFacts.prime_4405759) c0_0_0
  have hsqrt : Nat.sqrt 4405801=2099 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4405801+1)=some 2111 := by
    rw [hsqrt];exact (SearchFacts.query_4379 LCMSourcePV.PrimeFacts.prime_2111)
  exact make_hit 1000 30 32 16 4405801 10712529 2111 2113 2129 4405789 row_258 h0 (SearchFacts.query_4380 LCMSourcePV.PrimeFacts.prime_2113) (SearchFacts.query_4381 LCMSourcePV.PrimeFacts.prime_2129) (SearchFacts.query_2616 LCMSourcePV.PrimeFacts.prime_4405789) c1_0
#print axioms make_258
end LCMSourcePV.Witness.BlockProofs
