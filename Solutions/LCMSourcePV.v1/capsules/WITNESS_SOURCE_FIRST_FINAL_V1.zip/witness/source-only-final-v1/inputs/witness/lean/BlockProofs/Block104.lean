/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_104 : Block := (Block.mk 935089 942840 971 977 983 935021 935063 935071)
theorem make_104 : make 1000 30 32 16 935089 10712529=some row_104 := by
  have ck_0_2_0 : (Block.mk 935089 942840 971 977 983 935021 935063 935071).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_971 LCMSourcePV.PrimeFacts.prime_977 LCMSourcePV.PrimeFacts.prime_983 LCMSourcePV.PrimeFacts.prime_935021 LCMSourcePV.PrimeFacts.prime_935063 LCMSourcePV.PrimeFacts.prime_935071
  have sh_0_2_0 : shrink 30 (Block.mk 935089 942840 971 977 983 935021 935063 935071)=some row_104 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 935089 10712529 971 977 983 935063 935071 30 935022=some row_104 :=
    choose0_hit 1000 30 935089 10712529 971 977 983 935063 935071 29 935022 935021 row_104 (SearchFacts.query_1078 LCMSourcePV.PrimeFacts.prime_935021) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 935089 10712529 971 977 983 935063 935071 31 935058=(some row_104) :=
    choose0_skip 1000 30 935089 10712529 971 977 983 935063 935071 30 935058 935023 (some row_104) (SearchFacts.query_1079 LCMSourcePV.PrimeFacts.prime_935023) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 935089 10712529 971 977 983 935063 935071 32 935062=(some row_104) :=
    choose0_skip 1000 30 935089 10712529 971 977 983 935063 935071 31 935062 935059 (some row_104) (SearchFacts.query_1080 LCMSourcePV.PrimeFacts.prime_935059) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 935089 10712529 971 977 983 935071 16 935070=some row_104 :=
    choose1_hit 1000 30 32 935089 10712529 971 977 983 935071 15 935070 935063 row_104 (SearchFacts.query_1081 LCMSourcePV.PrimeFacts.prime_935063) c0_0_0
  have hsqrt : Nat.sqrt 935089=967 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 935089+1)=some 971 := by
    rw [hsqrt];exact (SearchFacts.query_4225 LCMSourcePV.PrimeFacts.prime_971)
  exact make_hit 1000 30 32 16 935089 10712529 971 977 983 935071 row_104 h0 (SearchFacts.query_4226 LCMSourcePV.PrimeFacts.prime_977) (SearchFacts.query_4227 LCMSourcePV.PrimeFacts.prime_983) (SearchFacts.query_1082 LCMSourcePV.PrimeFacts.prime_935071) c1_0
#print axioms make_104
end LCMSourcePV.Witness.BlockProofs
