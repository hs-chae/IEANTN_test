/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_322 : Block := (Block.mk 6869641 6932688 2633 2647 2657 6869461 6869627 6869633)
theorem make_322 : make 1000 30 32 16 6869641 10712529=some row_322 := by
  have ck_0_7_0 : (Block.mk 6869641 6932688 2633 2647 2657 6869461 6869627 6869633).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2633 LCMSourcePV.PrimeFacts.prime_2647 LCMSourcePV.PrimeFacts.prime_2657 LCMSourcePV.PrimeFacts.prime_6869461 LCMSourcePV.PrimeFacts.prime_6869627 LCMSourcePV.PrimeFacts.prime_6869633
  have sh_0_7_0 : shrink 30 (Block.mk 6869641 6932688 2633 2647 2657 6869461 6869627 6869633)=some row_322 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 25 6869520=some row_322 :=
    choose0_hit 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 24 6869520 6869461 row_322 (SearchFacts.query_3278 LCMSourcePV.PrimeFacts.prime_6869461) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 26 6869542=(some row_322) :=
    choose0_skip 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 25 6869542 6869521 (some row_322) (SearchFacts.query_3279 LCMSourcePV.PrimeFacts.prime_6869521) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 27 6869560=(some row_322) :=
    choose0_skip 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 26 6869560 6869543 (some row_322) (SearchFacts.query_3280 LCMSourcePV.PrimeFacts.prime_6869543) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 28 6869562=(some row_322) :=
    choose0_skip 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 27 6869562 6869561 (some row_322) (SearchFacts.query_3281 LCMSourcePV.PrimeFacts.prime_6869561) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 29 6869572=(some row_322) :=
    choose0_skip 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 28 6869572 6869563 (some row_322) (SearchFacts.query_3282 LCMSourcePV.PrimeFacts.prime_6869563) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 30 6869592=(some row_322) :=
    choose0_skip 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 29 6869592 6869573 (some row_322) (SearchFacts.query_3283 LCMSourcePV.PrimeFacts.prime_6869573) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 31 6869622=(some row_322) :=
    choose0_skip 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 30 6869622 6869593 (some row_322) (SearchFacts.query_3284 LCMSourcePV.PrimeFacts.prime_6869593) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 32 6869626=(some row_322) :=
    choose0_skip 1000 30 6869641 10712529 2633 2647 2657 6869627 6869633 31 6869626 6869623 (some row_322) (SearchFacts.query_3285 LCMSourcePV.PrimeFacts.prime_6869623) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6869641 10712529 2633 2647 2657 6869633 16 6869632=some row_322 :=
    choose1_hit 1000 30 32 6869641 10712529 2633 2647 2657 6869633 15 6869632 6869627 row_322 (SearchFacts.query_3286 LCMSourcePV.PrimeFacts.prime_6869627) c0_0_0
  have hsqrt : Nat.sqrt 6869641=2621 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6869641+1)=some 2633 := by
    rw [hsqrt];exact (SearchFacts.query_4443 LCMSourcePV.PrimeFacts.prime_2633)
  exact make_hit 1000 30 32 16 6869641 10712529 2633 2647 2657 6869633 row_322 h0 (SearchFacts.query_4444 LCMSourcePV.PrimeFacts.prime_2647) (SearchFacts.query_4445 LCMSourcePV.PrimeFacts.prime_2657) (SearchFacts.query_3287 LCMSourcePV.PrimeFacts.prime_6869633) c1_0
#print axioms make_322
end LCMSourcePV.Witness.BlockProofs
