/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_101 : Block := (Block.mk 885481 896808 947 953 967 885397 885449 885473)
theorem make_101 : make 1000 30 32 16 885481 10712529=some row_101 := by
  have ck_0_3_0 : (Block.mk 885481 896808 947 953 967 885397 885449 885473).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_947 LCMSourcePV.PrimeFacts.prime_953 LCMSourcePV.PrimeFacts.prime_967 LCMSourcePV.PrimeFacts.prime_885397 LCMSourcePV.PrimeFacts.prime_885449 LCMSourcePV.PrimeFacts.prime_885473
  have sh_0_3_0 : shrink 30 (Block.mk 885481 896808 947 953 967 885397 885449 885473)=some row_101 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 885481 10712529 947 953 967 885449 885473 29 885402=some row_101 :=
    choose0_hit 1000 30 885481 10712529 947 953 967 885449 885473 28 885402 885397 row_101 (SearchFacts.query_1057 LCMSourcePV.PrimeFacts.prime_885397) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 885481 10712529 947 953 967 885449 885473 30 885420=(some row_101) :=
    choose0_skip 1000 30 885481 10712529 947 953 967 885449 885473 29 885420 885403 (some row_101) (SearchFacts.query_1058 LCMSourcePV.PrimeFacts.prime_885403) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 885481 10712529 947 953 967 885449 885473 31 885426=(some row_101) :=
    choose0_skip 1000 30 885481 10712529 947 953 967 885449 885473 30 885426 885421 (some row_101) (SearchFacts.query_1059 LCMSourcePV.PrimeFacts.prime_885421) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 885481 10712529 947 953 967 885449 885473 32 885448=(some row_101) :=
    choose0_skip 1000 30 885481 10712529 947 953 967 885449 885473 31 885448 885427 (some row_101) (SearchFacts.query_1060 LCMSourcePV.PrimeFacts.prime_885427) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 885481 10712529 947 953 967 885473 16 885472=some row_101 :=
    choose1_hit 1000 30 32 885481 10712529 947 953 967 885473 15 885472 885449 row_101 (SearchFacts.query_1061 LCMSourcePV.PrimeFacts.prime_885449) c0_0_0
  have hsqrt : Nat.sqrt 885481=941 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 885481+1)=some 947 := by
    rw [hsqrt];exact (SearchFacts.query_4222 LCMSourcePV.PrimeFacts.prime_947)
  exact make_hit 1000 30 32 16 885481 10712529 947 953 967 885473 row_101 h0 (SearchFacts.query_4223 LCMSourcePV.PrimeFacts.prime_953) (SearchFacts.query_4224 LCMSourcePV.PrimeFacts.prime_967) (SearchFacts.query_1062 LCMSourcePV.PrimeFacts.prime_885473) c1_0
#print axioms make_101
end LCMSourcePV.Witness.BlockProofs
