/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_135 : Block := (Block.mk 1394761 1408968 1187 1193 1201 1394699 1394749 1394753)
theorem make_135 : make 1000 30 32 16 1394761 10712529=some row_135 := by
  have ck_0_5_0 : (Block.mk 1394761 1408968 1187 1193 1201 1394699 1394749 1394753).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1187 LCMSourcePV.PrimeFacts.prime_1193 LCMSourcePV.PrimeFacts.prime_1201 LCMSourcePV.PrimeFacts.prime_1394699 LCMSourcePV.PrimeFacts.prime_1394749 LCMSourcePV.PrimeFacts.prime_1394753
  have sh_0_5_0 : shrink 30 (Block.mk 1394761 1408968 1187 1193 1201 1394699 1394749 1394753)=some row_135 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 27 1394706=some row_135 :=
    choose0_hit 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 26 1394706 1394699 row_135 (SearchFacts.query_1470 LCMSourcePV.PrimeFacts.prime_1394699) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 28 1394710=(some row_135) :=
    choose0_skip 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 27 1394710 1394707 (some row_135) (SearchFacts.query_1471 LCMSourcePV.PrimeFacts.prime_1394707) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 29 1394712=(some row_135) :=
    choose0_skip 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 28 1394712 1394711 (some row_135) (SearchFacts.query_1472 LCMSourcePV.PrimeFacts.prime_1394711) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 30 1394736=(some row_135) :=
    choose0_skip 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 29 1394736 1394713 (some row_135) (SearchFacts.query_1473 LCMSourcePV.PrimeFacts.prime_1394713) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 31 1394746=(some row_135) :=
    choose0_skip 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 30 1394746 1394737 (some row_135) (SearchFacts.query_1474 LCMSourcePV.PrimeFacts.prime_1394737) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 32 1394748=(some row_135) :=
    choose0_skip 1000 30 1394761 10712529 1187 1193 1201 1394749 1394753 31 1394748 1394747 (some row_135) (SearchFacts.query_1475 LCMSourcePV.PrimeFacts.prime_1394747) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1394761 10712529 1187 1193 1201 1394753 16 1394752=some row_135 :=
    choose1_hit 1000 30 32 1394761 10712529 1187 1193 1201 1394753 15 1394752 1394749 row_135 (SearchFacts.query_1476 LCMSourcePV.PrimeFacts.prime_1394749) c0_0_0
  have hsqrt : Nat.sqrt 1394761=1181 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1394761+1)=some 1187 := by
    rw [hsqrt];exact (SearchFacts.query_4256 LCMSourcePV.PrimeFacts.prime_1187)
  exact make_hit 1000 30 32 16 1394761 10712529 1187 1193 1201 1394753 row_135 h0 (SearchFacts.query_4257 LCMSourcePV.PrimeFacts.prime_1193) (SearchFacts.query_4258 LCMSourcePV.PrimeFacts.prime_1201) (SearchFacts.query_1477 LCMSourcePV.PrimeFacts.prime_1394753) c1_0
#print axioms make_135
end LCMSourcePV.Witness.BlockProofs
