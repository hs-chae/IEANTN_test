/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_158 : Block := (Block.mk 1760929 1852320 1361 1367 1373 1760777 1760921 1760923)
theorem make_158 : make 1000 30 32 16 1760929 10712529=some row_158 := by
  have ck_0_9_0 : (Block.mk 1760929 1852320 1361 1367 1373 1760777 1760921 1760923).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1361 LCMSourcePV.PrimeFacts.prime_1367 LCMSourcePV.PrimeFacts.prime_1373 LCMSourcePV.PrimeFacts.prime_1760777 LCMSourcePV.PrimeFacts.prime_1760921 LCMSourcePV.PrimeFacts.prime_1760923
  have sh_0_9_0 : shrink 30 (Block.mk 1760929 1852320 1361 1367 1373 1760777 1760921 1760923)=some row_158 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 23 1760778=some row_158 :=
    choose0_hit 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 22 1760778 1760777 row_158 (SearchFacts.query_1643 LCMSourcePV.PrimeFacts.prime_1760777) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 24 1760782=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 23 1760782 1760779 (some row_158) (SearchFacts.query_1644 LCMSourcePV.PrimeFacts.prime_1760779) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 25 1760796=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 24 1760796 1760783 (some row_158) (SearchFacts.query_1645 LCMSourcePV.PrimeFacts.prime_1760783) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 26 1760812=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 25 1760812 1760797 (some row_158) (SearchFacts.query_1646 LCMSourcePV.PrimeFacts.prime_1760797) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 27 1760848=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 26 1760848 1760813 (some row_158) (SearchFacts.query_1647 LCMSourcePV.PrimeFacts.prime_1760813) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 28 1760872=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 27 1760872 1760849 (some row_158) (SearchFacts.query_1648 LCMSourcePV.PrimeFacts.prime_1760849) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 29 1760880=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 28 1760880 1760873 (some row_158) (SearchFacts.query_1649 LCMSourcePV.PrimeFacts.prime_1760873) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 30 1760896=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 29 1760896 1760881 (some row_158) (SearchFacts.query_1650 LCMSourcePV.PrimeFacts.prime_1760881) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 31 1760916=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 30 1760916 1760897 (some row_158) (SearchFacts.query_1651 LCMSourcePV.PrimeFacts.prime_1760897) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 32 1760920=(some row_158) :=
    choose0_skip 1000 30 1760929 10712529 1361 1367 1373 1760921 1760923 31 1760920 1760917 (some row_158) (SearchFacts.query_1652 LCMSourcePV.PrimeFacts.prime_1760917) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1760929 10712529 1361 1367 1373 1760923 16 1760922=some row_158 :=
    choose1_hit 1000 30 32 1760929 10712529 1361 1367 1373 1760923 15 1760922 1760921 row_158 (SearchFacts.query_1653 LCMSourcePV.PrimeFacts.prime_1760921) c0_0_0
  have hsqrt : Nat.sqrt 1760929=1327 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1760929+1)=some 1361 := by
    rw [hsqrt];exact (SearchFacts.query_4279 LCMSourcePV.PrimeFacts.prime_1361)
  exact make_hit 1000 30 32 16 1760929 10712529 1361 1367 1373 1760923 row_158 h0 (SearchFacts.query_4280 LCMSourcePV.PrimeFacts.prime_1367) (SearchFacts.query_4281 LCMSourcePV.PrimeFacts.prime_1373) (SearchFacts.query_1654 LCMSourcePV.PrimeFacts.prime_1760923) c1_0
#print axioms make_158
end LCMSourcePV.Witness.BlockProofs
