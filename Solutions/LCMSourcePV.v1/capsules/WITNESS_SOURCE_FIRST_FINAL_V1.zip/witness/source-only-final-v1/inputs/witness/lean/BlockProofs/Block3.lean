/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_3 : Block := (Block.mk 94249 96720 311 313 317 94121 94219 94229)
theorem make_3 : make 1000 30 32 16 94249 10712529=some row_3 := by
  have ck_0_5_0 : (Block.mk 94249 96720 311 313 317 94121 94219 94229).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_311 LCMSourcePV.PrimeFacts.prime_313 LCMSourcePV.PrimeFacts.prime_317 LCMSourcePV.PrimeFacts.prime_94121 LCMSourcePV.PrimeFacts.prime_94219 LCMSourcePV.PrimeFacts.prime_94229
  have sh_0_5_0 : shrink 30 (Block.mk 94249 96720 311 313 317 94121 94219 94229)=some row_3 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 94249 10712529 311 313 317 94219 94229 27 94150=some row_3 :=
    choose0_hit 1000 30 94249 10712529 311 313 317 94219 94229 26 94150 94121 row_3 (SearchFacts.query_34 LCMSourcePV.PrimeFacts.prime_94121) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 94249 10712529 311 313 317 94219 94229 28 94152=(some row_3) :=
    choose0_skip 1000 30 94249 10712529 311 313 317 94219 94229 27 94152 94151 (some row_3) (SearchFacts.query_35 LCMSourcePV.PrimeFacts.prime_94151) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 94249 10712529 311 313 317 94219 94229 29 94168=(some row_3) :=
    choose0_skip 1000 30 94249 10712529 311 313 317 94219 94229 28 94168 94153 (some row_3) (SearchFacts.query_36 LCMSourcePV.PrimeFacts.prime_94153) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 94249 10712529 311 313 317 94219 94229 30 94200=(some row_3) :=
    choose0_skip 1000 30 94249 10712529 311 313 317 94219 94229 29 94200 94169 (some row_3) (SearchFacts.query_37 LCMSourcePV.PrimeFacts.prime_94169) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 94249 10712529 311 313 317 94219 94229 31 94206=(some row_3) :=
    choose0_skip 1000 30 94249 10712529 311 313 317 94219 94229 30 94206 94201 (some row_3) (SearchFacts.query_38 LCMSourcePV.PrimeFacts.prime_94201) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 94249 10712529 311 313 317 94219 94229 32 94218=(some row_3) :=
    choose0_skip 1000 30 94249 10712529 311 313 317 94219 94229 31 94218 94207 (some row_3) (SearchFacts.query_39 LCMSourcePV.PrimeFacts.prime_94207) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 94249 10712529 311 313 317 94229 16 94228=some row_3 :=
    choose1_hit 1000 30 32 94249 10712529 311 313 317 94229 15 94228 94219 row_3 (SearchFacts.query_40 LCMSourcePV.PrimeFacts.prime_94219) c0_0_0
  have hsqrt : Nat.sqrt 94249=307 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 94249+1)=some 311 := by
    rw [hsqrt];exact (SearchFacts.query_4124 LCMSourcePV.PrimeFacts.prime_311)
  exact make_hit 1000 30 32 16 94249 10712529 311 313 317 94229 row_3 h0 (SearchFacts.query_4125 LCMSourcePV.PrimeFacts.prime_313) (SearchFacts.query_4126 LCMSourcePV.PrimeFacts.prime_317) (SearchFacts.query_41 LCMSourcePV.PrimeFacts.prime_94229) c1_0
#print axioms make_3
end LCMSourcePV.Witness.BlockProofs
