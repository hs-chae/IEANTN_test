/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_162 : Block := (Block.mk 1907161 1957200 1399 1409 1423 1907071 1907141 1907153)
theorem make_162 : make 1000 30 32 16 1907161 10712529=some row_162 := by
  have ck_0_2_0 : (Block.mk 1907161 1957200 1399 1409 1423 1907071 1907141 1907153).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1399 LCMSourcePV.PrimeFacts.prime_1409 LCMSourcePV.PrimeFacts.prime_1423 LCMSourcePV.PrimeFacts.prime_1907071 LCMSourcePV.PrimeFacts.prime_1907141 LCMSourcePV.PrimeFacts.prime_1907153
  have sh_0_2_0 : shrink 30 (Block.mk 1907161 1957200 1399 1409 1423 1907071 1907141 1907153)=some row_162 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 1907161 10712529 1399 1409 1423 1907141 1907153 30 1907106=some row_162 :=
    choose0_hit 1000 30 1907161 10712529 1399 1409 1423 1907141 1907153 29 1907106 1907071 row_162 (SearchFacts.query_1674 LCMSourcePV.PrimeFacts.prime_1907071) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 1907161 10712529 1399 1409 1423 1907141 1907153 31 1907122=(some row_162) :=
    choose0_skip 1000 30 1907161 10712529 1399 1409 1423 1907141 1907153 30 1907122 1907107 (some row_162) (SearchFacts.query_1675 LCMSourcePV.PrimeFacts.prime_1907107) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1907161 10712529 1399 1409 1423 1907141 1907153 32 1907140=(some row_162) :=
    choose0_skip 1000 30 1907161 10712529 1399 1409 1423 1907141 1907153 31 1907140 1907123 (some row_162) (SearchFacts.query_1676 LCMSourcePV.PrimeFacts.prime_1907123) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1907161 10712529 1399 1409 1423 1907153 16 1907152=some row_162 :=
    choose1_hit 1000 30 32 1907161 10712529 1399 1409 1423 1907153 15 1907152 1907141 row_162 (SearchFacts.query_1677 LCMSourcePV.PrimeFacts.prime_1907141) c0_0_0
  have hsqrt : Nat.sqrt 1907161=1381 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1907161+1)=some 1399 := by
    rw [hsqrt];exact (SearchFacts.query_4283 LCMSourcePV.PrimeFacts.prime_1399)
  exact make_hit 1000 30 32 16 1907161 10712529 1399 1409 1423 1907153 row_162 h0 (SearchFacts.query_4284 LCMSourcePV.PrimeFacts.prime_1409) (SearchFacts.query_4285 LCMSourcePV.PrimeFacts.prime_1423) (SearchFacts.query_1678 LCMSourcePV.PrimeFacts.prime_1907153) c1_0
#print axioms make_162
end LCMSourcePV.Witness.BlockProofs
