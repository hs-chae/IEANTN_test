/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_106 : Block := (Block.mk 954529 966288 983 991 997 954461 954509 954517)
theorem make_106 : make 1000 30 32 16 954529 10712529=some row_106 := by
  have ck_0_3_0 : (Block.mk 954529 966288 983 991 997 954461 954509 954517).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_983 LCMSourcePV.PrimeFacts.prime_991 LCMSourcePV.PrimeFacts.prime_997 LCMSourcePV.PrimeFacts.prime_954461 LCMSourcePV.PrimeFacts.prime_954509 LCMSourcePV.PrimeFacts.prime_954517
  have sh_0_3_0 : shrink 30 (Block.mk 954529 966288 983 991 997 954461 954509 954517)=some row_106 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 954529 10712529 983 991 997 954509 954517 29 954468=some row_106 :=
    choose0_hit 1000 30 954529 10712529 983 991 997 954509 954517 28 954468 954461 row_106 (SearchFacts.query_1091 LCMSourcePV.PrimeFacts.prime_954461) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 954529 10712529 983 991 997 954509 954517 30 954490=(some row_106) :=
    choose0_skip 1000 30 954529 10712529 983 991 997 954509 954517 29 954490 954469 (some row_106) (SearchFacts.query_1092 LCMSourcePV.PrimeFacts.prime_954469) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 954529 10712529 983 991 997 954509 954517 31 954496=(some row_106) :=
    choose0_skip 1000 30 954529 10712529 983 991 997 954509 954517 30 954496 954491 (some row_106) (SearchFacts.query_1093 LCMSourcePV.PrimeFacts.prime_954491) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 954529 10712529 983 991 997 954509 954517 32 954508=(some row_106) :=
    choose0_skip 1000 30 954529 10712529 983 991 997 954509 954517 31 954508 954497 (some row_106) (SearchFacts.query_1094 LCMSourcePV.PrimeFacts.prime_954497) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 954529 10712529 983 991 997 954517 16 954516=some row_106 :=
    choose1_hit 1000 30 32 954529 10712529 983 991 997 954517 15 954516 954509 row_106 (SearchFacts.query_1095 LCMSourcePV.PrimeFacts.prime_954509) c0_0_0
  have hsqrt : Nat.sqrt 954529=977 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 954529+1)=some 983 := by
    rw [hsqrt];exact (SearchFacts.query_4227 LCMSourcePV.PrimeFacts.prime_983)
  exact make_hit 1000 30 32 16 954529 10712529 983 991 997 954517 row_106 h0 (SearchFacts.query_4228 LCMSourcePV.PrimeFacts.prime_991) (SearchFacts.query_4229 LCMSourcePV.PrimeFacts.prime_997) (SearchFacts.query_1096 LCMSourcePV.PrimeFacts.prime_954517) c1_0
#print axioms make_106
end LCMSourcePV.Witness.BlockProofs
