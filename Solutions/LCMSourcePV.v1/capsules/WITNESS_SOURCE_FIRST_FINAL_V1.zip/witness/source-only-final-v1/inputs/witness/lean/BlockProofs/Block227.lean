/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_227 : Block := (Block.mk 3500641 3508128 1873 1877 1879 3500537 3500573 3500593)
theorem make_227 : make 1000 30 32 16 3500641 10712529=some row_227 := by
  have ck_0_1_0 : (Block.mk 3500641 3508128 1873 1877 1879 3500537 3500573 3500593).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1873 LCMSourcePV.PrimeFacts.prime_1877 LCMSourcePV.PrimeFacts.prime_1879 LCMSourcePV.PrimeFacts.prime_3500537 LCMSourcePV.PrimeFacts.prime_3500573 LCMSourcePV.PrimeFacts.prime_3500593
  have sh_0_1_0 : shrink 30 (Block.mk 3500641 3508128 1873 1877 1879 3500537 3500573 3500593)=some row_227 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 3500641 10712529 1873 1877 1879 3500573 3500593 31 3500556=some row_227 :=
    choose0_hit 1000 30 3500641 10712529 1873 1877 1879 3500573 3500593 30 3500556 3500537 row_227 (SearchFacts.query_2345 LCMSourcePV.PrimeFacts.prime_3500537) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 3500641 10712529 1873 1877 1879 3500573 3500593 32 3500572=(some row_227) :=
    choose0_skip 1000 30 3500641 10712529 1873 1877 1879 3500573 3500593 31 3500572 3500557 (some row_227) (SearchFacts.query_2346 LCMSourcePV.PrimeFacts.prime_3500557) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3500641 10712529 1873 1877 1879 3500593 16 3500592=some row_227 :=
    choose1_hit 1000 30 32 3500641 10712529 1873 1877 1879 3500593 15 3500592 3500573 row_227 (SearchFacts.query_2347 LCMSourcePV.PrimeFacts.prime_3500573) c0_0_0
  have hsqrt : Nat.sqrt 3500641=1871 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3500641+1)=some 1873 := by
    rw [hsqrt];exact (SearchFacts.query_4348 LCMSourcePV.PrimeFacts.prime_1873)
  exact make_hit 1000 30 32 16 3500641 10712529 1873 1877 1879 3500593 row_227 h0 (SearchFacts.query_4349 LCMSourcePV.PrimeFacts.prime_1877) (SearchFacts.query_4350 LCMSourcePV.PrimeFacts.prime_1879) (SearchFacts.query_2348 LCMSourcePV.PrimeFacts.prime_3500593) c1_0
#print axioms make_227
end LCMSourcePV.Witness.BlockProofs
