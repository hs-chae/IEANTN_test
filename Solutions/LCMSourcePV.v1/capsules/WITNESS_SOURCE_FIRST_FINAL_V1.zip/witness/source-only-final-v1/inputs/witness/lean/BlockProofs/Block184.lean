/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_184 : Block := (Block.mk 2380849 2399400 1549 1553 1559 2380717 2380837 2380841)
theorem make_184 : make 1000 30 32 16 2380849 10712529=some row_184 := by
  have ck_0_10_0 : (Block.mk 2380849 2399400 1549 1553 1559 2380717 2380837 2380841).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1549 LCMSourcePV.PrimeFacts.prime_1553 LCMSourcePV.PrimeFacts.prime_1559 LCMSourcePV.PrimeFacts.prime_2380717 LCMSourcePV.PrimeFacts.prime_2380837 LCMSourcePV.PrimeFacts.prime_2380841
  have sh_0_10_0 : shrink 30 (Block.mk 2380849 2399400 1549 1553 1559 2380717 2380837 2380841)=some row_184 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 22 2380726=some row_184 :=
    choose0_hit 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 21 2380726 2380717 row_184 (SearchFacts.query_1866 LCMSourcePV.PrimeFacts.prime_2380717) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 23 2380732=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 22 2380732 2380727 (some row_184) (SearchFacts.query_1867 LCMSourcePV.PrimeFacts.prime_2380727) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 24 2380738=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 23 2380738 2380733 (some row_184) (SearchFacts.query_1868 LCMSourcePV.PrimeFacts.prime_2380733) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 25 2380750=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 24 2380750 2380739 (some row_184) (SearchFacts.query_1869 LCMSourcePV.PrimeFacts.prime_2380739) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 26 2380758=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 25 2380758 2380751 (some row_184) (SearchFacts.query_1870 LCMSourcePV.PrimeFacts.prime_2380751) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 27 2380770=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 26 2380770 2380759 (some row_184) (SearchFacts.query_1871 LCMSourcePV.PrimeFacts.prime_2380759) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 28 2380786=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 27 2380786 2380771 (some row_184) (SearchFacts.query_1872 LCMSourcePV.PrimeFacts.prime_2380771) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 29 2380792=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 28 2380792 2380787 (some row_184) (SearchFacts.query_1873 LCMSourcePV.PrimeFacts.prime_2380787) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 30 2380800=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 29 2380800 2380793 (some row_184) (SearchFacts.query_1874 LCMSourcePV.PrimeFacts.prime_2380793) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 31 2380810=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 30 2380810 2380801 (some row_184) (SearchFacts.query_1875 LCMSourcePV.PrimeFacts.prime_2380801) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 32 2380836=(some row_184) :=
    choose0_skip 1000 30 2380849 10712529 1549 1553 1559 2380837 2380841 31 2380836 2380811 (some row_184) (SearchFacts.query_1876 LCMSourcePV.PrimeFacts.prime_2380811) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2380849 10712529 1549 1553 1559 2380841 16 2380840=some row_184 :=
    choose1_hit 1000 30 32 2380849 10712529 1549 1553 1559 2380841 15 2380840 2380837 row_184 (SearchFacts.query_1877 LCMSourcePV.PrimeFacts.prime_2380837) c0_0_0
  have hsqrt : Nat.sqrt 2380849=1543 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2380849+1)=some 1549 := by
    rw [hsqrt];exact (SearchFacts.query_4305 LCMSourcePV.PrimeFacts.prime_1549)
  exact make_hit 1000 30 32 16 2380849 10712529 1549 1553 1559 2380841 row_184 h0 (SearchFacts.query_4306 LCMSourcePV.PrimeFacts.prime_1553) (SearchFacts.query_4307 LCMSourcePV.PrimeFacts.prime_1559) (SearchFacts.query_1878 LCMSourcePV.PrimeFacts.prime_2380841) c1_0
#print axioms make_184
end LCMSourcePV.Witness.BlockProofs
