/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_296 : Block := (Block.mk 5707321 5726448 2393 2399 2411 5707301 5707309 5707319)
theorem make_296 : make 1000 30 32 16 5707321 10712529=some row_296 := by
  have ck_0_1_0 : (Block.mk 5707321 5726448 2393 2399 2411 5707301 5707309 5707319).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2393 LCMSourcePV.PrimeFacts.prime_2399 LCMSourcePV.PrimeFacts.prime_2411 LCMSourcePV.PrimeFacts.prime_5707301 LCMSourcePV.PrimeFacts.prime_5707309 LCMSourcePV.PrimeFacts.prime_5707319
  have sh_0_1_0 : shrink 30 (Block.mk 5707321 5726448 2393 2399 2411 5707301 5707309 5707319)=some row_296 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 5707321 10712529 2393 2399 2411 5707309 5707319 31 5707306=some row_296 :=
    choose0_hit 1000 30 5707321 10712529 2393 2399 2411 5707309 5707319 30 5707306 5707301 row_296 (SearchFacts.query_2994 LCMSourcePV.PrimeFacts.prime_5707301) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 5707321 10712529 2393 2399 2411 5707309 5707319 32 5707308=(some row_296) :=
    choose0_skip 1000 30 5707321 10712529 2393 2399 2411 5707309 5707319 31 5707308 5707307 (some row_296) (SearchFacts.query_2995 LCMSourcePV.PrimeFacts.prime_5707307) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5707321 10712529 2393 2399 2411 5707319 16 5707318=some row_296 :=
    choose1_hit 1000 30 32 5707321 10712529 2393 2399 2411 5707319 15 5707318 5707309 row_296 (SearchFacts.query_2996 LCMSourcePV.PrimeFacts.prime_5707309) c0_0_0
  have hsqrt : Nat.sqrt 5707321=2389 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5707321+1)=some 2393 := by
    rw [hsqrt];exact (SearchFacts.query_4417 LCMSourcePV.PrimeFacts.prime_2393)
  exact make_hit 1000 30 32 16 5707321 10712529 2393 2399 2411 5707319 row_296 h0 (SearchFacts.query_4418 LCMSourcePV.PrimeFacts.prime_2399) (SearchFacts.query_4419 LCMSourcePV.PrimeFacts.prime_2411) (SearchFacts.query_2997 LCMSourcePV.PrimeFacts.prime_5707319) c1_0
#print axioms make_296
end LCMSourcePV.Witness.BlockProofs
