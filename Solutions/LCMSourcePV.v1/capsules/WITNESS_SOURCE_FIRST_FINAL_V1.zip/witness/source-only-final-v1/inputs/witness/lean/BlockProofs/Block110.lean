/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_110 : Block := (Block.mk 1018081 1026168 1013 1019 1021 1017857 1018021 1018057)
theorem make_110 : make 1000 30 32 16 1018081 10712529=some row_110 := by
  have ck_0_9_0 : (Block.mk 1018081 1026168 1013 1019 1021 1017857 1018021 1018057).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1013 LCMSourcePV.PrimeFacts.prime_1019 LCMSourcePV.PrimeFacts.prime_1021 LCMSourcePV.PrimeFacts.prime_1017857 LCMSourcePV.PrimeFacts.prime_1018021 LCMSourcePV.PrimeFacts.prime_1018057
  have sh_0_9_0 : shrink 30 (Block.mk 1018081 1026168 1013 1019 1021 1017857 1018021 1018057)=some row_110 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 23 1017858=some row_110 :=
    choose0_hit 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 22 1017858 1017857 row_110 (SearchFacts.query_1140 LCMSourcePV.PrimeFacts.prime_1017857) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 24 1017880=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 23 1017880 1017859 (some row_110) (SearchFacts.query_1141 LCMSourcePV.PrimeFacts.prime_1017859) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 25 1017888=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 24 1017888 1017881 (some row_110) (SearchFacts.query_1142 LCMSourcePV.PrimeFacts.prime_1017881) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 26 1017922=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 25 1017922 1017889 (some row_110) (SearchFacts.query_1143 LCMSourcePV.PrimeFacts.prime_1017889) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 27 1017952=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 26 1017952 1017923 (some row_110) (SearchFacts.query_1144 LCMSourcePV.PrimeFacts.prime_1017923) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 28 1017958=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 27 1017958 1017953 (some row_110) (SearchFacts.query_1145 LCMSourcePV.PrimeFacts.prime_1017953) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 29 1017996=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 28 1017996 1017959 (some row_110) (SearchFacts.query_1146 LCMSourcePV.PrimeFacts.prime_1017959) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 30 1018006=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 29 1018006 1017997 (some row_110) (SearchFacts.query_1147 LCMSourcePV.PrimeFacts.prime_1017997) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 31 1018018=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 30 1018018 1018007 (some row_110) (SearchFacts.query_1148 LCMSourcePV.PrimeFacts.prime_1018007) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 32 1018020=(some row_110) :=
    choose0_skip 1000 30 1018081 10712529 1013 1019 1021 1018021 1018057 31 1018020 1018019 (some row_110) (SearchFacts.query_1149 LCMSourcePV.PrimeFacts.prime_1018019) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1018081 10712529 1013 1019 1021 1018057 16 1018056=some row_110 :=
    choose1_hit 1000 30 32 1018081 10712529 1013 1019 1021 1018057 15 1018056 1018021 row_110 (SearchFacts.query_1150 LCMSourcePV.PrimeFacts.prime_1018021) c0_0_0
  have hsqrt : Nat.sqrt 1018081=1009 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1018081+1)=some 1013 := by
    rw [hsqrt];exact (SearchFacts.query_4231 LCMSourcePV.PrimeFacts.prime_1013)
  exact make_hit 1000 30 32 16 1018081 10712529 1013 1019 1021 1018057 row_110 h0 (SearchFacts.query_4232 LCMSourcePV.PrimeFacts.prime_1019) (SearchFacts.query_4233 LCMSourcePV.PrimeFacts.prime_1021) (SearchFacts.query_1151 LCMSourcePV.PrimeFacts.prime_1018057) c1_0
#print axioms make_110
end LCMSourcePV.Witness.BlockProofs
