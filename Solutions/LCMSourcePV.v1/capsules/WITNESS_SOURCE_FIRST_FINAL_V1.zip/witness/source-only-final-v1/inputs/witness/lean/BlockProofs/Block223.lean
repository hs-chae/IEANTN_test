/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_223 : Block := (Block.mk 3352561 3411408 1847 1861 1867 3352249 3352511 3352537)
theorem make_223 : make 1000 30 32 16 3352561 10712529=some row_223 := by
  have ck_0_15_0 : (Block.mk 3352561 3411408 1847 1861 1867 3352249 3352511 3352537).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1847 LCMSourcePV.PrimeFacts.prime_1861 LCMSourcePV.PrimeFacts.prime_1867 LCMSourcePV.PrimeFacts.prime_3352249 LCMSourcePV.PrimeFacts.prime_3352511 LCMSourcePV.PrimeFacts.prime_3352537
  have sh_0_15_0 : shrink 30 (Block.mk 3352561 3411408 1847 1861 1867 3352249 3352511 3352537)=some row_223 := shrink_hit _ _ ck_0_15_0
  have c0_0_15 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 17 3352266=some row_223 :=
    choose0_hit 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 16 3352266 3352249 row_223 (SearchFacts.query_2313 LCMSourcePV.PrimeFacts.prime_3352249) (by decide) sh_0_15_0
  have c0_0_14 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 18 3352276=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 17 3352276 3352267 (some row_223) (SearchFacts.query_2314 LCMSourcePV.PrimeFacts.prime_3352267) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 19 3352288=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 18 3352288 3352277 (some row_223) (SearchFacts.query_2315 LCMSourcePV.PrimeFacts.prime_3352277) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 20 3352338=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 19 3352338 3352289 (some row_223) (SearchFacts.query_2316 LCMSourcePV.PrimeFacts.prime_3352289) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 21 3352342=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 20 3352342 3352339 (some row_223) (SearchFacts.query_2317 LCMSourcePV.PrimeFacts.prime_3352339) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 22 3352360=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 21 3352360 3352343 (some row_223) (SearchFacts.query_2318 LCMSourcePV.PrimeFacts.prime_3352343) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 23 3352372=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 22 3352372 3352361 (some row_223) (SearchFacts.query_2319 LCMSourcePV.PrimeFacts.prime_3352361) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 24 3352380=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 23 3352380 3352373 (some row_223) (SearchFacts.query_2320 LCMSourcePV.PrimeFacts.prime_3352373) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 25 3352386=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 24 3352386 3352381 (some row_223) (SearchFacts.query_2321 LCMSourcePV.PrimeFacts.prime_3352381) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 26 3352396=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 25 3352396 3352387 (some row_223) (SearchFacts.query_2322 LCMSourcePV.PrimeFacts.prime_3352387) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 27 3352402=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 26 3352402 3352397 (some row_223) (SearchFacts.query_2323 LCMSourcePV.PrimeFacts.prime_3352397) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 28 3352468=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 27 3352468 3352403 (some row_223) (SearchFacts.query_2324 LCMSourcePV.PrimeFacts.prime_3352403) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 29 3352470=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 28 3352470 3352469 (some row_223) (SearchFacts.query_2325 LCMSourcePV.PrimeFacts.prime_3352469) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 30 3352476=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 29 3352476 3352471 (some row_223) (SearchFacts.query_2326 LCMSourcePV.PrimeFacts.prime_3352471) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 31 3352482=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 30 3352482 3352477 (some row_223) (SearchFacts.query_2327 LCMSourcePV.PrimeFacts.prime_3352477) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 32 3352510=(some row_223) :=
    choose0_skip 1000 30 3352561 10712529 1847 1861 1867 3352511 3352537 31 3352510 3352483 (some row_223) (SearchFacts.query_2328 LCMSourcePV.PrimeFacts.prime_3352483) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3352561 10712529 1847 1861 1867 3352537 16 3352536=some row_223 :=
    choose1_hit 1000 30 32 3352561 10712529 1847 1861 1867 3352537 15 3352536 3352511 row_223 (SearchFacts.query_2329 LCMSourcePV.PrimeFacts.prime_3352511) c0_0_0
  have hsqrt : Nat.sqrt 3352561=1831 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3352561+1)=some 1847 := by
    rw [hsqrt];exact (SearchFacts.query_4344 LCMSourcePV.PrimeFacts.prime_1847)
  exact make_hit 1000 30 32 16 3352561 10712529 1847 1861 1867 3352537 row_223 h0 (SearchFacts.query_4345 LCMSourcePV.PrimeFacts.prime_1861) (SearchFacts.query_4346 LCMSourcePV.PrimeFacts.prime_1867) (SearchFacts.query_2330 LCMSourcePV.PrimeFacts.prime_3352537) c1_0
#print axioms make_223
end LCMSourcePV.Witness.BlockProofs
