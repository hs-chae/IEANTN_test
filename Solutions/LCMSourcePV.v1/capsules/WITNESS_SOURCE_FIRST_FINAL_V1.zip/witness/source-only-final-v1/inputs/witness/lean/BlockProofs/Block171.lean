/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_171 : Block := (Block.mk 2105401 2111208 1453 1459 1471 2105329 2105377 2105381)
theorem make_171 : make 1000 30 32 16 2105401 10712529=some row_171 := by
  have ck_0_3_0 : (Block.mk 2105401 2111208 1453 1459 1471 2105329 2105377 2105381).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1453 LCMSourcePV.PrimeFacts.prime_1459 LCMSourcePV.PrimeFacts.prime_1471 LCMSourcePV.PrimeFacts.prime_2105329 LCMSourcePV.PrimeFacts.prime_2105377 LCMSourcePV.PrimeFacts.prime_2105381
  have sh_0_3_0 : shrink 30 (Block.mk 2105401 2111208 1453 1459 1471 2105329 2105377 2105381)=some row_171 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 2105401 10712529 1453 1459 1471 2105377 2105381 29 2105346=some row_171 :=
    choose0_hit 1000 30 2105401 10712529 1453 1459 1471 2105377 2105381 28 2105346 2105329 row_171 (SearchFacts.query_1744 LCMSourcePV.PrimeFacts.prime_2105329) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 2105401 10712529 1453 1459 1471 2105377 2105381 30 2105356=(some row_171) :=
    choose0_skip 1000 30 2105401 10712529 1453 1459 1471 2105377 2105381 29 2105356 2105347 (some row_171) (SearchFacts.query_1745 LCMSourcePV.PrimeFacts.prime_2105347) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2105401 10712529 1453 1459 1471 2105377 2105381 31 2105358=(some row_171) :=
    choose0_skip 1000 30 2105401 10712529 1453 1459 1471 2105377 2105381 30 2105358 2105357 (some row_171) (SearchFacts.query_1746 LCMSourcePV.PrimeFacts.prime_2105357) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2105401 10712529 1453 1459 1471 2105377 2105381 32 2105376=(some row_171) :=
    choose0_skip 1000 30 2105401 10712529 1453 1459 1471 2105377 2105381 31 2105376 2105359 (some row_171) (SearchFacts.query_1747 LCMSourcePV.PrimeFacts.prime_2105359) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2105401 10712529 1453 1459 1471 2105381 16 2105380=some row_171 :=
    choose1_hit 1000 30 32 2105401 10712529 1453 1459 1471 2105381 15 2105380 2105377 row_171 (SearchFacts.query_1748 LCMSourcePV.PrimeFacts.prime_2105377) c0_0_0
  have hsqrt : Nat.sqrt 2105401=1451 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2105401+1)=some 1453 := by
    rw [hsqrt];exact (SearchFacts.query_4292 LCMSourcePV.PrimeFacts.prime_1453)
  exact make_hit 1000 30 32 16 2105401 10712529 1453 1459 1471 2105381 row_171 h0 (SearchFacts.query_4293 LCMSourcePV.PrimeFacts.prime_1459) (SearchFacts.query_4294 LCMSourcePV.PrimeFacts.prime_1471) (SearchFacts.query_1749 LCMSourcePV.PrimeFacts.prime_2105381) c1_0
#print axioms make_171
end LCMSourcePV.Witness.BlockProofs
