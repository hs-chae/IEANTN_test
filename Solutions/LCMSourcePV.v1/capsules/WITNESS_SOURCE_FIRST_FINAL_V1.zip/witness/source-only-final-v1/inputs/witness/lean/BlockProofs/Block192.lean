/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_192 : Block := (Block.mk 2550409 2563200 1601 1607 1609 2550167 2550403 2550407)
theorem make_192 : make 1000 30 32 16 2550409 10712529=some row_192 := by
  have ck_0_12_0 : (Block.mk 2550409 2563200 1601 1607 1609 2550167 2550403 2550407).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1601 LCMSourcePV.PrimeFacts.prime_1607 LCMSourcePV.PrimeFacts.prime_1609 LCMSourcePV.PrimeFacts.prime_2550167 LCMSourcePV.PrimeFacts.prime_2550403 LCMSourcePV.PrimeFacts.prime_2550407
  have sh_0_12_0 : shrink 30 (Block.mk 2550409 2563200 1601 1607 1609 2550167 2550403 2550407)=some row_192 := shrink_hit _ _ ck_0_12_0
  have c0_0_12 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 20 2550178=some row_192 :=
    choose0_hit 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 19 2550178 2550167 row_192 (SearchFacts.query_1961 LCMSourcePV.PrimeFacts.prime_2550167) (by decide) sh_0_12_0
  have c0_0_11 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 21 2550180=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 20 2550180 2550179 (some row_192) (SearchFacts.query_1962 LCMSourcePV.PrimeFacts.prime_2550179) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 22 2550202=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 21 2550202 2550181 (some row_192) (SearchFacts.query_1963 LCMSourcePV.PrimeFacts.prime_2550181) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 23 2550208=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 22 2550208 2550203 (some row_192) (SearchFacts.query_1964 LCMSourcePV.PrimeFacts.prime_2550203) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 24 2550252=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 23 2550252 2550209 (some row_192) (SearchFacts.query_1965 LCMSourcePV.PrimeFacts.prime_2550209) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 25 2550268=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 24 2550268 2550253 (some row_192) (SearchFacts.query_1966 LCMSourcePV.PrimeFacts.prime_2550253) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 26 2550280=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 25 2550280 2550269 (some row_192) (SearchFacts.query_1967 LCMSourcePV.PrimeFacts.prime_2550269) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 27 2550318=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 26 2550318 2550281 (some row_192) (SearchFacts.query_1968 LCMSourcePV.PrimeFacts.prime_2550281) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 28 2550328=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 27 2550328 2550319 (some row_192) (SearchFacts.query_1969 LCMSourcePV.PrimeFacts.prime_2550319) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 29 2550336=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 28 2550336 2550329 (some row_192) (SearchFacts.query_1970 LCMSourcePV.PrimeFacts.prime_2550329) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 30 2550342=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 29 2550342 2550337 (some row_192) (SearchFacts.query_1971 LCMSourcePV.PrimeFacts.prime_2550337) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 31 2550366=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 30 2550366 2550343 (some row_192) (SearchFacts.query_1972 LCMSourcePV.PrimeFacts.prime_2550343) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 32 2550402=(some row_192) :=
    choose0_skip 1000 30 2550409 10712529 1601 1607 1609 2550403 2550407 31 2550402 2550367 (some row_192) (SearchFacts.query_1973 LCMSourcePV.PrimeFacts.prime_2550367) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2550409 10712529 1601 1607 1609 2550407 16 2550406=some row_192 :=
    choose1_hit 1000 30 32 2550409 10712529 1601 1607 1609 2550407 15 2550406 2550403 row_192 (SearchFacts.query_1974 LCMSourcePV.PrimeFacts.prime_2550403) c0_0_0
  have hsqrt : Nat.sqrt 2550409=1597 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2550409+1)=some 1601 := by
    rw [hsqrt];exact (SearchFacts.query_4313 LCMSourcePV.PrimeFacts.prime_1601)
  exact make_hit 1000 30 32 16 2550409 10712529 1601 1607 1609 2550407 row_192 h0 (SearchFacts.query_4314 LCMSourcePV.PrimeFacts.prime_1607) (SearchFacts.query_4315 LCMSourcePV.PrimeFacts.prime_1609) (SearchFacts.query_1975 LCMSourcePV.PrimeFacts.prime_2550407) c1_0
#print axioms make_192
end LCMSourcePV.Witness.BlockProofs
