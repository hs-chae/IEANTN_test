/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_272 : Block := (Block.mk 4932841 5004168 2237 2239 2243 4932713 4932821 4932827)
theorem make_272 : make 1000 30 32 16 4932841 10712529=some row_272 := by
  have ck_0_8_0 : (Block.mk 4932841 5004168 2237 2239 2243 4932713 4932821 4932827).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2237 LCMSourcePV.PrimeFacts.prime_2239 LCMSourcePV.PrimeFacts.prime_2243 LCMSourcePV.PrimeFacts.prime_4932713 LCMSourcePV.PrimeFacts.prime_4932821 LCMSourcePV.PrimeFacts.prime_4932827
  have sh_0_8_0 : shrink 30 (Block.mk 4932841 5004168 2237 2239 2243 4932713 4932821 4932827)=some row_272 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 24 4932726=some row_272 :=
    choose0_hit 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 23 4932726 4932713 row_272 (SearchFacts.query_2753 LCMSourcePV.PrimeFacts.prime_4932713) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 25 4932730=(some row_272) :=
    choose0_skip 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 24 4932730 4932727 (some row_272) (SearchFacts.query_2754 LCMSourcePV.PrimeFacts.prime_4932727) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 26 4932742=(some row_272) :=
    choose0_skip 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 25 4932742 4932731 (some row_272) (SearchFacts.query_2755 LCMSourcePV.PrimeFacts.prime_4932731) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 27 4932756=(some row_272) :=
    choose0_skip 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 26 4932756 4932743 (some row_272) (SearchFacts.query_2756 LCMSourcePV.PrimeFacts.prime_4932743) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 28 4932768=(some row_272) :=
    choose0_skip 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 27 4932768 4932757 (some row_272) (SearchFacts.query_2757 LCMSourcePV.PrimeFacts.prime_4932757) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 29 4932778=(some row_272) :=
    choose0_skip 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 28 4932778 4932769 (some row_272) (SearchFacts.query_2758 LCMSourcePV.PrimeFacts.prime_4932769) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 30 4932796=(some row_272) :=
    choose0_skip 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 29 4932796 4932779 (some row_272) (SearchFacts.query_2759 LCMSourcePV.PrimeFacts.prime_4932779) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 31 4932816=(some row_272) :=
    choose0_skip 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 30 4932816 4932797 (some row_272) (SearchFacts.query_2760 LCMSourcePV.PrimeFacts.prime_4932797) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 32 4932820=(some row_272) :=
    choose0_skip 1000 30 4932841 10712529 2237 2239 2243 4932821 4932827 31 4932820 4932817 (some row_272) (SearchFacts.query_2761 LCMSourcePV.PrimeFacts.prime_4932817) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4932841 10712529 2237 2239 2243 4932827 16 4932826=some row_272 :=
    choose1_hit 1000 30 32 4932841 10712529 2237 2239 2243 4932827 15 4932826 4932821 row_272 (SearchFacts.query_2762 LCMSourcePV.PrimeFacts.prime_4932821) c0_0_0
  have hsqrt : Nat.sqrt 4932841=2221 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4932841+1)=some 2237 := by
    rw [hsqrt];exact (SearchFacts.query_4393 LCMSourcePV.PrimeFacts.prime_2237)
  exact make_hit 1000 30 32 16 4932841 10712529 2237 2239 2243 4932827 row_272 h0 (SearchFacts.query_4394 LCMSourcePV.PrimeFacts.prime_2239) (SearchFacts.query_4395 LCMSourcePV.PrimeFacts.prime_2243) (SearchFacts.query_2763 LCMSourcePV.PrimeFacts.prime_4932827) c1_0
#print axioms make_272
end LCMSourcePV.Witness.BlockProofs
