/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_328 : Block := (Block.mk 7134241 7166328 2677 2683 2687 7134181 7134223 7134233)
theorem make_328 : make 1000 30 32 16 7134241 10712529=some row_328 := by
  have ck_0_1_0 : (Block.mk 7134241 7166328 2677 2683 2687 7134181 7134223 7134233).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2677 LCMSourcePV.PrimeFacts.prime_2683 LCMSourcePV.PrimeFacts.prime_2687 LCMSourcePV.PrimeFacts.prime_7134181 LCMSourcePV.PrimeFacts.prime_7134223 LCMSourcePV.PrimeFacts.prime_7134233
  have sh_0_1_0 : shrink 30 (Block.mk 7134241 7166328 2677 2683 2687 7134181 7134223 7134233)=some row_328 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 7134241 10712529 2677 2683 2687 7134223 7134233 31 7134198=some row_328 :=
    choose0_hit 1000 30 7134241 10712529 2677 2683 2687 7134223 7134233 30 7134198 7134181 row_328 (SearchFacts.query_3356 LCMSourcePV.PrimeFacts.prime_7134181) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 7134241 10712529 2677 2683 2687 7134223 7134233 32 7134222=(some row_328) :=
    choose0_skip 1000 30 7134241 10712529 2677 2683 2687 7134223 7134233 31 7134222 7134199 (some row_328) (SearchFacts.query_3357 LCMSourcePV.PrimeFacts.prime_7134199) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 7134241 10712529 2677 2683 2687 7134233 16 7134232=some row_328 :=
    choose1_hit 1000 30 32 7134241 10712529 2677 2683 2687 7134233 15 7134232 7134223 row_328 (SearchFacts.query_3358 LCMSourcePV.PrimeFacts.prime_7134223) c0_0_0
  have hsqrt : Nat.sqrt 7134241=2671 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 7134241+1)=some 2677 := by
    rw [hsqrt];exact (SearchFacts.query_4449 LCMSourcePV.PrimeFacts.prime_2677)
  exact make_hit 1000 30 32 16 7134241 10712529 2677 2683 2687 7134233 row_328 h0 (SearchFacts.query_4450 LCMSourcePV.PrimeFacts.prime_2683) (SearchFacts.query_4451 LCMSourcePV.PrimeFacts.prime_2687) (SearchFacts.query_3359 LCMSourcePV.PrimeFacts.prime_7134233) c1_0
#print axioms make_328
end LCMSourcePV.Witness.BlockProofs
