/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_297 : Block := (Block.mk 5726449 5755200 2399 2411 2417 5726323 5726411 5726447)
theorem make_297 : make 1000 30 32 16 5726449 10712529=some row_297 := by
  have ck_0_5_0 : (Block.mk 5726449 5755200 2399 2411 2417 5726323 5726411 5726447).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2399 LCMSourcePV.PrimeFacts.prime_2411 LCMSourcePV.PrimeFacts.prime_2417 LCMSourcePV.PrimeFacts.prime_5726323 LCMSourcePV.PrimeFacts.prime_5726411 LCMSourcePV.PrimeFacts.prime_5726447
  have sh_0_5_0 : shrink 30 (Block.mk 5726449 5755200 2399 2411 2417 5726323 5726411 5726447)=some row_297 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 27 5726340=some row_297 :=
    choose0_hit 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 26 5726340 5726323 row_297 (SearchFacts.query_2998 LCMSourcePV.PrimeFacts.prime_5726323) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 28 5726358=(some row_297) :=
    choose0_skip 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 27 5726358 5726341 (some row_297) (SearchFacts.query_2999 LCMSourcePV.PrimeFacts.prime_5726341) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 29 5726386=(some row_297) :=
    choose0_skip 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 28 5726386 5726359 (some row_297) (SearchFacts.query_3000 LCMSourcePV.PrimeFacts.prime_5726359) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 30 5726392=(some row_297) :=
    choose0_skip 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 29 5726392 5726387 (some row_297) (SearchFacts.query_3001 LCMSourcePV.PrimeFacts.prime_5726387) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 31 5726406=(some row_297) :=
    choose0_skip 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 30 5726406 5726393 (some row_297) (SearchFacts.query_3002 LCMSourcePV.PrimeFacts.prime_5726393) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 32 5726410=(some row_297) :=
    choose0_skip 1000 30 5726449 10712529 2399 2411 2417 5726411 5726447 31 5726410 5726407 (some row_297) (SearchFacts.query_3003 LCMSourcePV.PrimeFacts.prime_5726407) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5726449 10712529 2399 2411 2417 5726447 16 5726446=some row_297 :=
    choose1_hit 1000 30 32 5726449 10712529 2399 2411 2417 5726447 15 5726446 5726411 row_297 (SearchFacts.query_3004 LCMSourcePV.PrimeFacts.prime_5726411) c0_0_0
  have hsqrt : Nat.sqrt 5726449=2393 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5726449+1)=some 2399 := by
    rw [hsqrt];exact (SearchFacts.query_4418 LCMSourcePV.PrimeFacts.prime_2399)
  exact make_hit 1000 30 32 16 5726449 10712529 2399 2411 2417 5726447 row_297 h0 (SearchFacts.query_4419 LCMSourcePV.PrimeFacts.prime_2411) (SearchFacts.query_4420 LCMSourcePV.PrimeFacts.prime_2417) (SearchFacts.query_3005 LCMSourcePV.PrimeFacts.prime_5726447) c1_0
#print axioms make_297
end LCMSourcePV.Witness.BlockProofs
