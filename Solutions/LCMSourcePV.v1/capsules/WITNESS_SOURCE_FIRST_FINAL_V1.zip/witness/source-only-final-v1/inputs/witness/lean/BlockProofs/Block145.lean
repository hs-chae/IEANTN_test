/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_145 : Block := (Block.mk 1560001 1585080 1259 1277 1279 1559807 1559983 1559989)
theorem make_145 : make 1000 30 32 16 1560001 10712529=some row_145 := by
  have ck_0_10_0 : (Block.mk 1560001 1585080 1259 1277 1279 1559807 1559983 1559989).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1259 LCMSourcePV.PrimeFacts.prime_1277 LCMSourcePV.PrimeFacts.prime_1279 LCMSourcePV.PrimeFacts.prime_1559807 LCMSourcePV.PrimeFacts.prime_1559983 LCMSourcePV.PrimeFacts.prime_1559989
  have sh_0_10_0 : shrink 30 (Block.mk 1560001 1585080 1259 1277 1279 1559807 1559983 1559989)=some row_145 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 22 1559820=some row_145 :=
    choose0_hit 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 21 1559820 1559807 row_145 (SearchFacts.query_1540 LCMSourcePV.PrimeFacts.prime_1559807) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 23 1559838=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 22 1559838 1559821 (some row_145) (SearchFacts.query_1541 LCMSourcePV.PrimeFacts.prime_1559821) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 24 1559848=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 23 1559848 1559839 (some row_145) (SearchFacts.query_1542 LCMSourcePV.PrimeFacts.prime_1559839) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 25 1559850=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 24 1559850 1559849 (some row_145) (SearchFacts.query_1543 LCMSourcePV.PrimeFacts.prime_1559849) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 26 1559878=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 25 1559878 1559851 (some row_145) (SearchFacts.query_1544 LCMSourcePV.PrimeFacts.prime_1559851) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 27 1559890=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 26 1559890 1559879 (some row_145) (SearchFacts.query_1545 LCMSourcePV.PrimeFacts.prime_1559879) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 28 1559892=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 27 1559892 1559891 (some row_145) (SearchFacts.query_1546 LCMSourcePV.PrimeFacts.prime_1559891) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 29 1559932=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 28 1559932 1559893 (some row_145) (SearchFacts.query_1547 LCMSourcePV.PrimeFacts.prime_1559893) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 30 1559962=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 29 1559962 1559933 (some row_145) (SearchFacts.query_1548 LCMSourcePV.PrimeFacts.prime_1559933) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 31 1559968=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 30 1559968 1559963 (some row_145) (SearchFacts.query_1549 LCMSourcePV.PrimeFacts.prime_1559963) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 32 1559982=(some row_145) :=
    choose0_skip 1000 30 1560001 10712529 1259 1277 1279 1559983 1559989 31 1559982 1559969 (some row_145) (SearchFacts.query_1550 LCMSourcePV.PrimeFacts.prime_1559969) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1560001 10712529 1259 1277 1279 1559989 16 1559988=some row_145 :=
    choose1_hit 1000 30 32 1560001 10712529 1259 1277 1279 1559989 15 1559988 1559983 row_145 (SearchFacts.query_1551 LCMSourcePV.PrimeFacts.prime_1559983) c0_0_0
  have hsqrt : Nat.sqrt 1560001=1249 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1560001+1)=some 1259 := by
    rw [hsqrt];exact (SearchFacts.query_4266 LCMSourcePV.PrimeFacts.prime_1259)
  exact make_hit 1000 30 32 16 1560001 10712529 1259 1277 1279 1559989 row_145 h0 (SearchFacts.query_4267 LCMSourcePV.PrimeFacts.prime_1277) (SearchFacts.query_4268 LCMSourcePV.PrimeFacts.prime_1279) (SearchFacts.query_1552 LCMSourcePV.PrimeFacts.prime_1559989) c1_0
#print axioms make_145
end LCMSourcePV.Witness.BlockProofs
