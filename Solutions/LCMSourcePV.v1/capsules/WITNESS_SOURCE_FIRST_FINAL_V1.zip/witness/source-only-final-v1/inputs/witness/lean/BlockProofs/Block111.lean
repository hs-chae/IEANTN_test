/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_111 : Block := (Block.mk 1026169 1038360 1019 1021 1031 1026041 1026143 1026167)
theorem make_111 : make 1000 30 32 16 1026169 10712529=some row_111 := by
  have ck_0_7_0 : (Block.mk 1026169 1038360 1019 1021 1031 1026041 1026143 1026167).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1019 LCMSourcePV.PrimeFacts.prime_1021 LCMSourcePV.PrimeFacts.prime_1031 LCMSourcePV.PrimeFacts.prime_1026041 LCMSourcePV.PrimeFacts.prime_1026143 LCMSourcePV.PrimeFacts.prime_1026167
  have sh_0_7_0 : shrink 30 (Block.mk 1026169 1038360 1019 1021 1031 1026041 1026143 1026167)=some row_111 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 25 1026042=some row_111 :=
    choose0_hit 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 24 1026042 1026041 row_111 (SearchFacts.query_1152 LCMSourcePV.PrimeFacts.prime_1026041) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 26 1026060=(some row_111) :=
    choose0_skip 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 25 1026060 1026043 (some row_111) (SearchFacts.query_1153 LCMSourcePV.PrimeFacts.prime_1026043) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 27 1026072=(some row_111) :=
    choose0_skip 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 26 1026072 1026061 (some row_111) (SearchFacts.query_1154 LCMSourcePV.PrimeFacts.prime_1026061) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 28 1026100=(some row_111) :=
    choose0_skip 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 27 1026100 1026073 (some row_111) (SearchFacts.query_1155 LCMSourcePV.PrimeFacts.prime_1026073) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 29 1026118=(some row_111) :=
    choose0_skip 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 28 1026118 1026101 (some row_111) (SearchFacts.query_1156 LCMSourcePV.PrimeFacts.prime_1026101) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 30 1026126=(some row_111) :=
    choose0_skip 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 29 1026126 1026119 (some row_111) (SearchFacts.query_1157 LCMSourcePV.PrimeFacts.prime_1026119) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 31 1026138=(some row_111) :=
    choose0_skip 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 30 1026138 1026127 (some row_111) (SearchFacts.query_1158 LCMSourcePV.PrimeFacts.prime_1026127) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 32 1026142=(some row_111) :=
    choose0_skip 1000 30 1026169 10712529 1019 1021 1031 1026143 1026167 31 1026142 1026139 (some row_111) (SearchFacts.query_1159 LCMSourcePV.PrimeFacts.prime_1026139) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1026169 10712529 1019 1021 1031 1026167 16 1026166=some row_111 :=
    choose1_hit 1000 30 32 1026169 10712529 1019 1021 1031 1026167 15 1026166 1026143 row_111 (SearchFacts.query_1160 LCMSourcePV.PrimeFacts.prime_1026143) c0_0_0
  have hsqrt : Nat.sqrt 1026169=1013 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1026169+1)=some 1019 := by
    rw [hsqrt];exact (SearchFacts.query_4232 LCMSourcePV.PrimeFacts.prime_1019)
  exact make_hit 1000 30 32 16 1026169 10712529 1019 1021 1031 1026167 row_111 h0 (SearchFacts.query_4233 LCMSourcePV.PrimeFacts.prime_1021) (SearchFacts.query_4234 LCMSourcePV.PrimeFacts.prime_1031) (SearchFacts.query_1161 LCMSourcePV.PrimeFacts.prime_1026167) c1_0
#print axioms make_111
end LCMSourcePV.Witness.BlockProofs
