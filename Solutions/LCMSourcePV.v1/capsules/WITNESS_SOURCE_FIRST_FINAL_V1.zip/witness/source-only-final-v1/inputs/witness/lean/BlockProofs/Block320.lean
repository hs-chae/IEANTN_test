/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_320 : Block := (Block.mk 6806881 6848688 2617 2621 2633 6806621 6806831 6806837)
theorem make_320 : make 1000 30 32 16 6806881 10712529=some row_320 := by
  have ck_0_13_0 : (Block.mk 6806881 6848688 2617 2621 2633 6806621 6806831 6806837).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2617 LCMSourcePV.PrimeFacts.prime_2621 LCMSourcePV.PrimeFacts.prime_2633 LCMSourcePV.PrimeFacts.prime_6806621 LCMSourcePV.PrimeFacts.prime_6806831 LCMSourcePV.PrimeFacts.prime_6806837
  have sh_0_13_0 : shrink 30 (Block.mk 6806881 6848688 2617 2621 2633 6806621 6806831 6806837)=some row_320 := shrink_hit _ _ ck_0_13_0
  have c0_0_13 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 19 6806632=some row_320 :=
    choose0_hit 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 18 6806632 6806621 row_320 (SearchFacts.query_3259 LCMSourcePV.PrimeFacts.prime_6806621) (by decide) sh_0_13_0
  have c0_0_12 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 20 6806650=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 19 6806650 6806633 (some row_320) (SearchFacts.query_3260 LCMSourcePV.PrimeFacts.prime_6806633) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 21 6806668=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 20 6806668 6806651 (some row_320) (SearchFacts.query_3261 LCMSourcePV.PrimeFacts.prime_6806651) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 22 6806670=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 21 6806670 6806669 (some row_320) (SearchFacts.query_3262 LCMSourcePV.PrimeFacts.prime_6806669) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 23 6806686=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 22 6806686 6806671 (some row_320) (SearchFacts.query_3263 LCMSourcePV.PrimeFacts.prime_6806671) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 24 6806710=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 23 6806710 6806687 (some row_320) (SearchFacts.query_3264 LCMSourcePV.PrimeFacts.prime_6806687) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 25 6806728=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 24 6806728 6806711 (some row_320) (SearchFacts.query_3265 LCMSourcePV.PrimeFacts.prime_6806711) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 26 6806742=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 25 6806742 6806729 (some row_320) (SearchFacts.query_3266 LCMSourcePV.PrimeFacts.prime_6806729) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 27 6806776=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 26 6806776 6806743 (some row_320) (SearchFacts.query_3267 LCMSourcePV.PrimeFacts.prime_6806743) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 28 6806790=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 27 6806790 6806777 (some row_320) (SearchFacts.query_3268 LCMSourcePV.PrimeFacts.prime_6806777) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 29 6806796=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 28 6806796 6806791 (some row_320) (SearchFacts.query_3269 LCMSourcePV.PrimeFacts.prime_6806791) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 30 6806800=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 29 6806800 6806797 (some row_320) (SearchFacts.query_3270 LCMSourcePV.PrimeFacts.prime_6806797) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 31 6806802=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 30 6806802 6806801 (some row_320) (SearchFacts.query_3271 LCMSourcePV.PrimeFacts.prime_6806801) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 32 6806830=(some row_320) :=
    choose0_skip 1000 30 6806881 10712529 2617 2621 2633 6806831 6806837 31 6806830 6806803 (some row_320) (SearchFacts.query_3272 LCMSourcePV.PrimeFacts.prime_6806803) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6806881 10712529 2617 2621 2633 6806837 16 6806836=some row_320 :=
    choose1_hit 1000 30 32 6806881 10712529 2617 2621 2633 6806837 15 6806836 6806831 row_320 (SearchFacts.query_3273 LCMSourcePV.PrimeFacts.prime_6806831) c0_0_0
  have hsqrt : Nat.sqrt 6806881=2609 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6806881+1)=some 2617 := by
    rw [hsqrt];exact (SearchFacts.query_4441 LCMSourcePV.PrimeFacts.prime_2617)
  exact make_hit 1000 30 32 16 6806881 10712529 2617 2621 2633 6806837 row_320 h0 (SearchFacts.query_4442 LCMSourcePV.PrimeFacts.prime_2621) (SearchFacts.query_4443 LCMSourcePV.PrimeFacts.prime_2633) (SearchFacts.query_3274 LCMSourcePV.PrimeFacts.prime_6806837) c1_0
#print axioms make_320
end LCMSourcePV.Witness.BlockProofs
