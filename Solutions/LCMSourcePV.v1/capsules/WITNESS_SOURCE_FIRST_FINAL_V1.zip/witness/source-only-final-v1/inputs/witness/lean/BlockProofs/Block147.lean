/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_147 : Block := (Block.mk 1630729 1635840 1279 1283 1289 1630547 1630669 1630721)
theorem make_147 : make 1000 30 32 16 1630729 10712529=some row_147 := by
  have ck_0_6_0 : (Block.mk 1630729 1635840 1279 1283 1289 1630547 1630669 1630721).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1279 LCMSourcePV.PrimeFacts.prime_1283 LCMSourcePV.PrimeFacts.prime_1289 LCMSourcePV.PrimeFacts.prime_1630547 LCMSourcePV.PrimeFacts.prime_1630669 LCMSourcePV.PrimeFacts.prime_1630721
  have sh_0_6_0 : shrink 30 (Block.mk 1630729 1635840 1279 1283 1289 1630547 1630669 1630721)=some row_147 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 26 1630548=some row_147 :=
    choose0_hit 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 25 1630548 1630547 row_147 (SearchFacts.query_1558 LCMSourcePV.PrimeFacts.prime_1630547) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 27 1630596=(some row_147) :=
    choose0_skip 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 26 1630596 1630549 (some row_147) (SearchFacts.query_1559 LCMSourcePV.PrimeFacts.prime_1630549) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 28 1630618=(some row_147) :=
    choose0_skip 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 27 1630618 1630597 (some row_147) (SearchFacts.query_1560 LCMSourcePV.PrimeFacts.prime_1630597) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 29 1630620=(some row_147) :=
    choose0_skip 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 28 1630620 1630619 (some row_147) (SearchFacts.query_1561 LCMSourcePV.PrimeFacts.prime_1630619) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 30 1630632=(some row_147) :=
    choose0_skip 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 29 1630632 1630621 (some row_147) (SearchFacts.query_1562 LCMSourcePV.PrimeFacts.prime_1630621) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 31 1630662=(some row_147) :=
    choose0_skip 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 30 1630662 1630633 (some row_147) (SearchFacts.query_1563 LCMSourcePV.PrimeFacts.prime_1630633) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 32 1630668=(some row_147) :=
    choose0_skip 1000 30 1630729 10712529 1279 1283 1289 1630669 1630721 31 1630668 1630663 (some row_147) (SearchFacts.query_1564 LCMSourcePV.PrimeFacts.prime_1630663) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1630729 10712529 1279 1283 1289 1630721 16 1630720=some row_147 :=
    choose1_hit 1000 30 32 1630729 10712529 1279 1283 1289 1630721 15 1630720 1630669 row_147 (SearchFacts.query_1565 LCMSourcePV.PrimeFacts.prime_1630669) c0_0_0
  have hsqrt : Nat.sqrt 1630729=1277 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1630729+1)=some 1279 := by
    rw [hsqrt];exact (SearchFacts.query_4268 LCMSourcePV.PrimeFacts.prime_1279)
  exact make_hit 1000 30 32 16 1630729 10712529 1279 1283 1289 1630721 row_147 h0 (SearchFacts.query_4269 LCMSourcePV.PrimeFacts.prime_1283) (SearchFacts.query_4270 LCMSourcePV.PrimeFacts.prime_1289) (SearchFacts.query_1566 LCMSourcePV.PrimeFacts.prime_1630721) c1_0
#print axioms make_147
end LCMSourcePV.Witness.BlockProofs
