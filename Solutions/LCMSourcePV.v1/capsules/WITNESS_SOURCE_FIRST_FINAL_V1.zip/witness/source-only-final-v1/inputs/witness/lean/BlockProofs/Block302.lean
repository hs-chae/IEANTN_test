/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_302 : Block := (Block.mk 5938969 5958480 2441 2447 2459 5938789 5938931 5938957)
theorem make_302 : make 1000 30 32 16 5938969 10712529=some row_302 := by
  have ck_0_9_0 : (Block.mk 5938969 5958480 2441 2447 2459 5938789 5938931 5938957).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2441 LCMSourcePV.PrimeFacts.prime_2447 LCMSourcePV.PrimeFacts.prime_2459 LCMSourcePV.PrimeFacts.prime_5938789 LCMSourcePV.PrimeFacts.prime_5938931 LCMSourcePV.PrimeFacts.prime_5938957
  have sh_0_9_0 : shrink 30 (Block.mk 5938969 5958480 2441 2447 2459 5938789 5938931 5938957)=some row_302 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 23 5938840=some row_302 :=
    choose0_hit 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 22 5938840 5938789 row_302 (SearchFacts.query_3030 LCMSourcePV.PrimeFacts.prime_5938789) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 24 5938842=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 23 5938842 5938841 (some row_302) (SearchFacts.query_3031 LCMSourcePV.PrimeFacts.prime_5938841) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 25 5938846=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 24 5938846 5938843 (some row_302) (SearchFacts.query_3032 LCMSourcePV.PrimeFacts.prime_5938843) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 26 5938860=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 25 5938860 5938847 (some row_302) (SearchFacts.query_3033 LCMSourcePV.PrimeFacts.prime_5938847) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 27 5938870=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 26 5938870 5938861 (some row_302) (SearchFacts.query_3034 LCMSourcePV.PrimeFacts.prime_5938861) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 28 5938896=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 27 5938896 5938871 (some row_302) (SearchFacts.query_3035 LCMSourcePV.PrimeFacts.prime_5938871) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 29 5938902=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 28 5938902 5938897 (some row_302) (SearchFacts.query_3036 LCMSourcePV.PrimeFacts.prime_5938897) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 30 5938908=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 29 5938908 5938903 (some row_302) (SearchFacts.query_3037 LCMSourcePV.PrimeFacts.prime_5938903) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 31 5938912=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 30 5938912 5938909 (some row_302) (SearchFacts.query_3038 LCMSourcePV.PrimeFacts.prime_5938909) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 32 5938930=(some row_302) :=
    choose0_skip 1000 30 5938969 10712529 2441 2447 2459 5938931 5938957 31 5938930 5938913 (some row_302) (SearchFacts.query_3039 LCMSourcePV.PrimeFacts.prime_5938913) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5938969 10712529 2441 2447 2459 5938957 16 5938956=some row_302 :=
    choose1_hit 1000 30 32 5938969 10712529 2441 2447 2459 5938957 15 5938956 5938931 row_302 (SearchFacts.query_3040 LCMSourcePV.PrimeFacts.prime_5938931) c0_0_0
  have hsqrt : Nat.sqrt 5938969=2437 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5938969+1)=some 2441 := by
    rw [hsqrt];exact (SearchFacts.query_4423 LCMSourcePV.PrimeFacts.prime_2441)
  exact make_hit 1000 30 32 16 5938969 10712529 2441 2447 2459 5938957 row_302 h0 (SearchFacts.query_4424 LCMSourcePV.PrimeFacts.prime_2447) (SearchFacts.query_4425 LCMSourcePV.PrimeFacts.prime_2459) (SearchFacts.query_3041 LCMSourcePV.PrimeFacts.prime_5938957) c1_0
#print axioms make_302
end LCMSourcePV.Witness.BlockProofs
