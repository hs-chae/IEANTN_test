/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_100 : Block := (Block.mk 877969 885480 941 947 953 877739 877939 877949)
theorem make_100 : make 1000 30 32 16 877969 10712529=some row_100 := by
  have ck_0_15_0 : (Block.mk 877969 885480 941 947 953 877739 877939 877949).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_941 LCMSourcePV.PrimeFacts.prime_947 LCMSourcePV.PrimeFacts.prime_953 LCMSourcePV.PrimeFacts.prime_877739 LCMSourcePV.PrimeFacts.prime_877939 LCMSourcePV.PrimeFacts.prime_877949
  have sh_0_15_0 : shrink 30 (Block.mk 877969 885480 941 947 953 877739 877939 877949)=some row_100 := shrink_hit _ _ ck_0_15_0
  have c0_0_15 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 17 877770=some row_100 :=
    choose0_hit 1000 30 877969 10712529 941 947 953 877939 877949 16 877770 877739 row_100 (SearchFacts.query_1039 LCMSourcePV.PrimeFacts.prime_877739) (by decide) sh_0_15_0
  have c0_0_14 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 18 877782=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 17 877782 877771 (some row_100) (SearchFacts.query_1040 LCMSourcePV.PrimeFacts.prime_877771) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 19 877816=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 18 877816 877783 (some row_100) (SearchFacts.query_1041 LCMSourcePV.PrimeFacts.prime_877783) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 20 877822=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 19 877822 877817 (some row_100) (SearchFacts.query_1042 LCMSourcePV.PrimeFacts.prime_877817) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 21 877836=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 20 877836 877823 (some row_100) (SearchFacts.query_1043 LCMSourcePV.PrimeFacts.prime_877823) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 22 877842=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 21 877842 877837 (some row_100) (SearchFacts.query_1044 LCMSourcePV.PrimeFacts.prime_877837) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 23 877852=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 22 877852 877843 (some row_100) (SearchFacts.query_1045 LCMSourcePV.PrimeFacts.prime_877843) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 24 877866=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 23 877866 877853 (some row_100) (SearchFacts.query_1046 LCMSourcePV.PrimeFacts.prime_877853) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 25 877870=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 24 877870 877867 (some row_100) (SearchFacts.query_1047 LCMSourcePV.PrimeFacts.prime_877867) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 26 877872=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 25 877872 877871 (some row_100) (SearchFacts.query_1048 LCMSourcePV.PrimeFacts.prime_877871) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 27 877878=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 26 877878 877873 (some row_100) (SearchFacts.query_1049 LCMSourcePV.PrimeFacts.prime_877873) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 28 877882=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 27 877882 877879 (some row_100) (SearchFacts.query_1050 LCMSourcePV.PrimeFacts.prime_877879) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 29 877906=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 28 877906 877883 (some row_100) (SearchFacts.query_1051 LCMSourcePV.PrimeFacts.prime_877883) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 30 877908=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 29 877908 877907 (some row_100) (SearchFacts.query_1052 LCMSourcePV.PrimeFacts.prime_877907) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 31 877936=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 30 877936 877909 (some row_100) (SearchFacts.query_1053 LCMSourcePV.PrimeFacts.prime_877909) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 877969 10712529 941 947 953 877939 877949 32 877938=(some row_100) :=
    choose0_skip 1000 30 877969 10712529 941 947 953 877939 877949 31 877938 877937 (some row_100) (SearchFacts.query_1054 LCMSourcePV.PrimeFacts.prime_877937) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 877969 10712529 941 947 953 877949 16 877948=some row_100 :=
    choose1_hit 1000 30 32 877969 10712529 941 947 953 877949 15 877948 877939 row_100 (SearchFacts.query_1055 LCMSourcePV.PrimeFacts.prime_877939) c0_0_0
  have hsqrt : Nat.sqrt 877969=937 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 877969+1)=some 941 := by
    rw [hsqrt];exact (SearchFacts.query_4221 LCMSourcePV.PrimeFacts.prime_941)
  exact make_hit 1000 30 32 16 877969 10712529 941 947 953 877949 row_100 h0 (SearchFacts.query_4222 LCMSourcePV.PrimeFacts.prime_947) (SearchFacts.query_4223 LCMSourcePV.PrimeFacts.prime_953) (SearchFacts.query_1056 LCMSourcePV.PrimeFacts.prime_877949) c1_0
#print axioms make_100
end LCMSourcePV.Witness.BlockProofs
