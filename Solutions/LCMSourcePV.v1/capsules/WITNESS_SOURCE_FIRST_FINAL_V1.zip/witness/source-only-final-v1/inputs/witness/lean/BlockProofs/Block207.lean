/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_207 : Block := (Block.mk 2886601 2920680 1709 1721 1723 2886229 2886571 2886593)
theorem make_207 : make 1000 30 32 16 2886601 10712529=some row_207 := by
  have ck_0_24_0 : (Block.mk 2886601 2920680 1709 1721 1723 2886229 2886571 2886593).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1709 LCMSourcePV.PrimeFacts.prime_1721 LCMSourcePV.PrimeFacts.prime_1723 LCMSourcePV.PrimeFacts.prime_2886229 LCMSourcePV.PrimeFacts.prime_2886571 LCMSourcePV.PrimeFacts.prime_2886593
  have sh_0_24_0 : shrink 30 (Block.mk 2886601 2920680 1709 1721 1723 2886229 2886571 2886593)=some row_207 := shrink_hit _ _ ck_0_24_0
  have c0_0_24 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 8 2886238=some row_207 :=
    choose0_hit 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 7 2886238 2886229 row_207 (SearchFacts.query_2127 LCMSourcePV.PrimeFacts.prime_2886229) (by decide) sh_0_24_0
  have c0_0_23 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 9 2886250=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 8 2886250 2886239 (some row_207) (SearchFacts.query_2128 LCMSourcePV.PrimeFacts.prime_2886239) (by decide) c0_0_24
  have c0_0_22 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 10 2886252=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 9 2886252 2886251 (some row_207) (SearchFacts.query_2129 LCMSourcePV.PrimeFacts.prime_2886251) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 11 2886262=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 10 2886262 2886253 (some row_207) (SearchFacts.query_2130 LCMSourcePV.PrimeFacts.prime_2886253) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 12 2886280=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 11 2886280 2886263 (some row_207) (SearchFacts.query_2131 LCMSourcePV.PrimeFacts.prime_2886263) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 13 2886286=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 12 2886286 2886281 (some row_207) (SearchFacts.query_2132 LCMSourcePV.PrimeFacts.prime_2886281) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 14 2886318=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 13 2886318 2886287 (some row_207) (SearchFacts.query_2133 LCMSourcePV.PrimeFacts.prime_2886287) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 15 2886352=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 14 2886352 2886319 (some row_207) (SearchFacts.query_2134 LCMSourcePV.PrimeFacts.prime_2886319) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 16 2886360=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 15 2886360 2886353 (some row_207) (SearchFacts.query_2135 LCMSourcePV.PrimeFacts.prime_2886353) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 17 2886370=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 16 2886370 2886361 (some row_207) (SearchFacts.query_2136 LCMSourcePV.PrimeFacts.prime_2886361) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 18 2886382=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 17 2886382 2886371 (some row_207) (SearchFacts.query_2137 LCMSourcePV.PrimeFacts.prime_2886371) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 19 2886408=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 18 2886408 2886383 (some row_207) (SearchFacts.query_2138 LCMSourcePV.PrimeFacts.prime_2886383) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 20 2886418=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 19 2886418 2886409 (some row_207) (SearchFacts.query_2139 LCMSourcePV.PrimeFacts.prime_2886409) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 21 2886450=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 20 2886450 2886419 (some row_207) (SearchFacts.query_2140 LCMSourcePV.PrimeFacts.prime_2886419) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 22 2886462=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 21 2886462 2886451 (some row_207) (SearchFacts.query_2141 LCMSourcePV.PrimeFacts.prime_2886451) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 23 2886466=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 22 2886466 2886463 (some row_207) (SearchFacts.query_2142 LCMSourcePV.PrimeFacts.prime_2886463) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 24 2886486=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 23 2886486 2886467 (some row_207) (SearchFacts.query_2143 LCMSourcePV.PrimeFacts.prime_2886467) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 25 2886508=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 24 2886508 2886487 (some row_207) (SearchFacts.query_2144 LCMSourcePV.PrimeFacts.prime_2886487) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 26 2886510=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 25 2886510 2886509 (some row_207) (SearchFacts.query_2145 LCMSourcePV.PrimeFacts.prime_2886509) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 27 2886516=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 26 2886516 2886511 (some row_207) (SearchFacts.query_2146 LCMSourcePV.PrimeFacts.prime_2886511) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 28 2886528=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 27 2886528 2886517 (some row_207) (SearchFacts.query_2147 LCMSourcePV.PrimeFacts.prime_2886517) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 29 2886552=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 28 2886552 2886529 (some row_207) (SearchFacts.query_2148 LCMSourcePV.PrimeFacts.prime_2886529) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 30 2886556=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 29 2886556 2886553 (some row_207) (SearchFacts.query_2149 LCMSourcePV.PrimeFacts.prime_2886553) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 31 2886562=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 30 2886562 2886557 (some row_207) (SearchFacts.query_2150 LCMSourcePV.PrimeFacts.prime_2886557) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 32 2886570=(some row_207) :=
    choose0_skip 1000 30 2886601 10712529 1709 1721 1723 2886571 2886593 31 2886570 2886563 (some row_207) (SearchFacts.query_2151 LCMSourcePV.PrimeFacts.prime_2886563) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2886601 10712529 1709 1721 1723 2886593 16 2886592=some row_207 :=
    choose1_hit 1000 30 32 2886601 10712529 1709 1721 1723 2886593 15 2886592 2886571 row_207 (SearchFacts.query_2152 LCMSourcePV.PrimeFacts.prime_2886571) c0_0_0
  have hsqrt : Nat.sqrt 2886601=1699 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2886601+1)=some 1709 := by
    rw [hsqrt];exact (SearchFacts.query_4328 LCMSourcePV.PrimeFacts.prime_1709)
  exact make_hit 1000 30 32 16 2886601 10712529 1709 1721 1723 2886593 row_207 h0 (SearchFacts.query_4329 LCMSourcePV.PrimeFacts.prime_1721) (SearchFacts.query_4330 LCMSourcePV.PrimeFacts.prime_1723) (SearchFacts.query_2153 LCMSourcePV.PrimeFacts.prime_2886593) c1_0
#print axioms make_207
end LCMSourcePV.Witness.BlockProofs
