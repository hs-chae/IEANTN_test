/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_124 : Block := (Block.mk 1194649 1203408 1097 1103 1109 1194269 1194601 1194631)
theorem make_124 : make 1000 30 32 16 1194649 10712529=some row_124 := by
  have ck_0_22_0 : (Block.mk 1194649 1203408 1097 1103 1109 1194269 1194601 1194631).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1097 LCMSourcePV.PrimeFacts.prime_1103 LCMSourcePV.PrimeFacts.prime_1109 LCMSourcePV.PrimeFacts.prime_1194269 LCMSourcePV.PrimeFacts.prime_1194601 LCMSourcePV.PrimeFacts.prime_1194631
  have sh_0_22_0 : shrink 30 (Block.mk 1194649 1203408 1097 1103 1109 1194269 1194601 1194631)=some row_124 := shrink_hit _ _ ck_0_22_0
  have c0_0_22 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 10 1194292=some row_124 :=
    choose0_hit 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 9 1194292 1194269 row_124 (SearchFacts.query_1282 LCMSourcePV.PrimeFacts.prime_1194269) (by decide) sh_0_22_0
  have c0_0_21 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 11 1194310=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 10 1194310 1194293 (some row_124) (SearchFacts.query_1283 LCMSourcePV.PrimeFacts.prime_1194293) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 12 1194328=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 11 1194328 1194311 (some row_124) (SearchFacts.query_1284 LCMSourcePV.PrimeFacts.prime_1194311) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 13 1194340=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 12 1194340 1194329 (some row_124) (SearchFacts.query_1285 LCMSourcePV.PrimeFacts.prime_1194329) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 14 1194342=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 13 1194342 1194341 (some row_124) (SearchFacts.query_1286 LCMSourcePV.PrimeFacts.prime_1194341) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 15 1194372=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 14 1194372 1194343 (some row_124) (SearchFacts.query_1287 LCMSourcePV.PrimeFacts.prime_1194343) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 16 1194378=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 15 1194378 1194373 (some row_124) (SearchFacts.query_1288 LCMSourcePV.PrimeFacts.prime_1194373) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 17 1194382=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 16 1194382 1194379 (some row_124) (SearchFacts.query_1289 LCMSourcePV.PrimeFacts.prime_1194379) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 18 1194406=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 17 1194406 1194383 (some row_124) (SearchFacts.query_1290 LCMSourcePV.PrimeFacts.prime_1194383) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 19 1194420=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 18 1194420 1194407 (some row_124) (SearchFacts.query_1291 LCMSourcePV.PrimeFacts.prime_1194407) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 20 1194438=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 19 1194438 1194421 (some row_124) (SearchFacts.query_1292 LCMSourcePV.PrimeFacts.prime_1194421) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 21 1194442=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 20 1194442 1194439 (some row_124) (SearchFacts.query_1293 LCMSourcePV.PrimeFacts.prime_1194439) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 22 1194448=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 21 1194448 1194443 (some row_124) (SearchFacts.query_1294 LCMSourcePV.PrimeFacts.prime_1194443) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 23 1194462=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 22 1194462 1194449 (some row_124) (SearchFacts.query_1295 LCMSourcePV.PrimeFacts.prime_1194449) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 24 1194492=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 23 1194492 1194463 (some row_124) (SearchFacts.query_1296 LCMSourcePV.PrimeFacts.prime_1194463) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 25 1194516=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 24 1194516 1194493 (some row_124) (SearchFacts.query_1297 LCMSourcePV.PrimeFacts.prime_1194493) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 26 1194520=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 25 1194520 1194517 (some row_124) (SearchFacts.query_1298 LCMSourcePV.PrimeFacts.prime_1194517) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 27 1194540=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 26 1194540 1194521 (some row_124) (SearchFacts.query_1299 LCMSourcePV.PrimeFacts.prime_1194521) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 28 1194546=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 27 1194546 1194541 (some row_124) (SearchFacts.query_1300 LCMSourcePV.PrimeFacts.prime_1194541) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 29 1194552=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 28 1194552 1194547 (some row_124) (SearchFacts.query_1301 LCMSourcePV.PrimeFacts.prime_1194547) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 30 1194580=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 29 1194580 1194553 (some row_124) (SearchFacts.query_1302 LCMSourcePV.PrimeFacts.prime_1194553) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 31 1194592=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 30 1194592 1194581 (some row_124) (SearchFacts.query_1303 LCMSourcePV.PrimeFacts.prime_1194581) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 32 1194600=(some row_124) :=
    choose0_skip 1000 30 1194649 10712529 1097 1103 1109 1194601 1194631 31 1194600 1194593 (some row_124) (SearchFacts.query_1304 LCMSourcePV.PrimeFacts.prime_1194593) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1194649 10712529 1097 1103 1109 1194631 16 1194630=some row_124 :=
    choose1_hit 1000 30 32 1194649 10712529 1097 1103 1109 1194631 15 1194630 1194601 row_124 (SearchFacts.query_1305 LCMSourcePV.PrimeFacts.prime_1194601) c0_0_0
  have hsqrt : Nat.sqrt 1194649=1093 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1194649+1)=some 1097 := by
    rw [hsqrt];exact (SearchFacts.query_4245 LCMSourcePV.PrimeFacts.prime_1097)
  exact make_hit 1000 30 32 16 1194649 10712529 1097 1103 1109 1194631 row_124 h0 (SearchFacts.query_4246 LCMSourcePV.PrimeFacts.prime_1103) (SearchFacts.query_4247 LCMSourcePV.PrimeFacts.prime_1109) (SearchFacts.query_1306 LCMSourcePV.PrimeFacts.prime_1194631) c1_0
#print axioms make_124
end LCMSourcePV.Witness.BlockProofs
