/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_232 : Block := (Block.mk 3613801 3636648 1907 1913 1931 3613481 3613787 3613789)
theorem make_232 : make 1000 30 32 16 3613801 10712529=some row_232 := by
  have ck_0_22_0 : (Block.mk 3613801 3636648 1907 1913 1931 3613481 3613787 3613789).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1907 LCMSourcePV.PrimeFacts.prime_1913 LCMSourcePV.PrimeFacts.prime_1931 LCMSourcePV.PrimeFacts.prime_3613481 LCMSourcePV.PrimeFacts.prime_3613787 LCMSourcePV.PrimeFacts.prime_3613789
  have sh_0_22_0 : shrink 30 (Block.mk 3613801 3636648 1907 1913 1931 3613481 3613787 3613789)=some row_232 := shrink_hit _ _ ck_0_22_0
  have c0_0_22 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 10 3613512=some row_232 :=
    choose0_hit 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 9 3613512 3613481 row_232 (SearchFacts.query_2373 LCMSourcePV.PrimeFacts.prime_3613481) (by decide) sh_0_22_0
  have c0_0_21 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 11 3613516=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 10 3613516 3613513 (some row_232) (SearchFacts.query_2374 LCMSourcePV.PrimeFacts.prime_3613513) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 12 3613522=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 11 3613522 3613517 (some row_232) (SearchFacts.query_2375 LCMSourcePV.PrimeFacts.prime_3613517) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 13 3613542=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 12 3613542 3613523 (some row_232) (SearchFacts.query_2376 LCMSourcePV.PrimeFacts.prime_3613523) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 14 3613558=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 13 3613558 3613543 (some row_232) (SearchFacts.query_2377 LCMSourcePV.PrimeFacts.prime_3613543) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 15 3613600=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 14 3613600 3613559 (some row_232) (SearchFacts.query_2378 LCMSourcePV.PrimeFacts.prime_3613559) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 16 3613606=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 15 3613606 3613601 (some row_232) (SearchFacts.query_2379 LCMSourcePV.PrimeFacts.prime_3613601) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 17 3613608=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 16 3613608 3613607 (some row_232) (SearchFacts.query_2380 LCMSourcePV.PrimeFacts.prime_3613607) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 18 3613618=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 17 3613618 3613609 (some row_232) (SearchFacts.query_2381 LCMSourcePV.PrimeFacts.prime_3613609) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 19 3613632=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 18 3613632 3613619 (some row_232) (SearchFacts.query_2382 LCMSourcePV.PrimeFacts.prime_3613619) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 20 3613636=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 19 3613636 3613633 (some row_232) (SearchFacts.query_2383 LCMSourcePV.PrimeFacts.prime_3613633) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 21 3613662=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 20 3613662 3613637 (some row_232) (SearchFacts.query_2384 LCMSourcePV.PrimeFacts.prime_3613637) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 22 3613680=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 21 3613680 3613663 (some row_232) (SearchFacts.query_2385 LCMSourcePV.PrimeFacts.prime_3613663) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 23 3613692=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 22 3613692 3613681 (some row_232) (SearchFacts.query_2386 LCMSourcePV.PrimeFacts.prime_3613681) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 24 3613702=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 23 3613702 3613693 (some row_232) (SearchFacts.query_2387 LCMSourcePV.PrimeFacts.prime_3613693) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 25 3613716=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 24 3613716 3613703 (some row_232) (SearchFacts.query_2388 LCMSourcePV.PrimeFacts.prime_3613703) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 26 3613720=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 25 3613720 3613717 (some row_232) (SearchFacts.query_2389 LCMSourcePV.PrimeFacts.prime_3613717) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 27 3613722=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 26 3613722 3613721 (some row_232) (SearchFacts.query_2390 LCMSourcePV.PrimeFacts.prime_3613721) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 28 3613732=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 27 3613732 3613723 (some row_232) (SearchFacts.query_2391 LCMSourcePV.PrimeFacts.prime_3613723) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 29 3613738=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 28 3613738 3613733 (some row_232) (SearchFacts.query_2392 LCMSourcePV.PrimeFacts.prime_3613733) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 30 3613746=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 29 3613746 3613739 (some row_232) (SearchFacts.query_2393 LCMSourcePV.PrimeFacts.prime_3613739) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 31 3613758=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 30 3613758 3613747 (some row_232) (SearchFacts.query_2394 LCMSourcePV.PrimeFacts.prime_3613747) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 32 3613786=(some row_232) :=
    choose0_skip 1000 30 3613801 10712529 1907 1913 1931 3613787 3613789 31 3613786 3613759 (some row_232) (SearchFacts.query_2395 LCMSourcePV.PrimeFacts.prime_3613759) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3613801 10712529 1907 1913 1931 3613789 16 3613788=some row_232 :=
    choose1_hit 1000 30 32 3613801 10712529 1907 1913 1931 3613789 15 3613788 3613787 row_232 (SearchFacts.query_2396 LCMSourcePV.PrimeFacts.prime_3613787) c0_0_0
  have hsqrt : Nat.sqrt 3613801=1901 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3613801+1)=some 1907 := by
    rw [hsqrt];exact (SearchFacts.query_4353 LCMSourcePV.PrimeFacts.prime_1907)
  exact make_hit 1000 30 32 16 3613801 10712529 1907 1913 1931 3613789 row_232 h0 (SearchFacts.query_4354 LCMSourcePV.PrimeFacts.prime_1913) (SearchFacts.query_4355 LCMSourcePV.PrimeFacts.prime_1931) (SearchFacts.query_2397 LCMSourcePV.PrimeFacts.prime_3613789) c1_0
#print axioms make_232
end LCMSourcePV.Witness.BlockProofs
