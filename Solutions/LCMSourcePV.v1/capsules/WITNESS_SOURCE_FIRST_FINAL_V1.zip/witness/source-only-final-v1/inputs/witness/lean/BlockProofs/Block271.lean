/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_271 : Block := (Block.mk 4897369 4932840 2221 2237 2239 4897103 4897337 4897363)
theorem make_271 : make 1000 30 32 16 4897369 10712529=some row_271 := by
  have ck_0_13_0 : (Block.mk 4897369 4932840 2221 2237 2239 4897103 4897337 4897363).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2221 LCMSourcePV.PrimeFacts.prime_2237 LCMSourcePV.PrimeFacts.prime_2239 LCMSourcePV.PrimeFacts.prime_4897103 LCMSourcePV.PrimeFacts.prime_4897337 LCMSourcePV.PrimeFacts.prime_4897363
  have sh_0_13_0 : shrink 30 (Block.mk 4897369 4932840 2221 2237 2239 4897103 4897337 4897363)=some row_271 := shrink_hit _ _ ck_0_13_0
  have c0_0_13 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 19 4897152=some row_271 :=
    choose0_hit 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 18 4897152 4897103 row_271 (SearchFacts.query_2737 LCMSourcePV.PrimeFacts.prime_4897103) (by decide) sh_0_13_0
  have c0_0_12 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 20 4897156=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 19 4897156 4897153 (some row_271) (SearchFacts.query_2738 LCMSourcePV.PrimeFacts.prime_4897153) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 21 4897170=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 20 4897170 4897157 (some row_271) (SearchFacts.query_2739 LCMSourcePV.PrimeFacts.prime_4897157) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 22 4897180=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 21 4897180 4897171 (some row_271) (SearchFacts.query_2740 LCMSourcePV.PrimeFacts.prime_4897171) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 23 4897198=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 22 4897198 4897181 (some row_271) (SearchFacts.query_2741 LCMSourcePV.PrimeFacts.prime_4897181) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 24 4897212=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 23 4897212 4897199 (some row_271) (SearchFacts.query_2742 LCMSourcePV.PrimeFacts.prime_4897199) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 25 4897218=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 24 4897218 4897213 (some row_271) (SearchFacts.query_2743 LCMSourcePV.PrimeFacts.prime_4897213) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 26 4897236=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 25 4897236 4897219 (some row_271) (SearchFacts.query_2744 LCMSourcePV.PrimeFacts.prime_4897219) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 27 4897266=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 26 4897266 4897237 (some row_271) (SearchFacts.query_2745 LCMSourcePV.PrimeFacts.prime_4897237) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 28 4897272=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 27 4897272 4897267 (some row_271) (SearchFacts.query_2746 LCMSourcePV.PrimeFacts.prime_4897267) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 29 4897278=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 28 4897278 4897273 (some row_271) (SearchFacts.query_2747 LCMSourcePV.PrimeFacts.prime_4897273) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 30 4897296=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 29 4897296 4897279 (some row_271) (SearchFacts.query_2748 LCMSourcePV.PrimeFacts.prime_4897279) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 31 4897330=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 30 4897330 4897297 (some row_271) (SearchFacts.query_2749 LCMSourcePV.PrimeFacts.prime_4897297) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 32 4897336=(some row_271) :=
    choose0_skip 1000 30 4897369 10712529 2221 2237 2239 4897337 4897363 31 4897336 4897331 (some row_271) (SearchFacts.query_2750 LCMSourcePV.PrimeFacts.prime_4897331) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4897369 10712529 2221 2237 2239 4897363 16 4897362=some row_271 :=
    choose1_hit 1000 30 32 4897369 10712529 2221 2237 2239 4897363 15 4897362 4897337 row_271 (SearchFacts.query_2751 LCMSourcePV.PrimeFacts.prime_4897337) c0_0_0
  have hsqrt : Nat.sqrt 4897369=2213 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4897369+1)=some 2221 := by
    rw [hsqrt];exact (SearchFacts.query_4392 LCMSourcePV.PrimeFacts.prime_2221)
  exact make_hit 1000 30 32 16 4897369 10712529 2221 2237 2239 4897363 row_271 h0 (SearchFacts.query_4393 LCMSourcePV.PrimeFacts.prime_2237) (SearchFacts.query_4394 LCMSourcePV.PrimeFacts.prime_2239) (SearchFacts.query_2752 LCMSourcePV.PrimeFacts.prime_4897363) c1_0
#print axioms make_271
end LCMSourcePV.Witness.BlockProofs
