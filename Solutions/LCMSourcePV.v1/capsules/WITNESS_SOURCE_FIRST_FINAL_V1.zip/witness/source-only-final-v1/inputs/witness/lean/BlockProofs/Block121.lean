/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_121 : Block := (Block.mk 1142761 1181568 1087 1091 1093 1142599 1142737 1142759)
theorem make_121 : make 1000 30 32 16 1142761 10712529=some row_121 := by
  have ck_0_5_0 : (Block.mk 1142761 1181568 1087 1091 1093 1142599 1142737 1142759).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1087 LCMSourcePV.PrimeFacts.prime_1091 LCMSourcePV.PrimeFacts.prime_1093 LCMSourcePV.PrimeFacts.prime_1142599 LCMSourcePV.PrimeFacts.prime_1142737 LCMSourcePV.PrimeFacts.prime_1142759
  have sh_0_5_0 : shrink 30 (Block.mk 1142761 1181568 1087 1091 1093 1142599 1142737 1142759)=some row_121 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 27 1142632=some row_121 :=
    choose0_hit 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 26 1142632 1142599 row_121 (SearchFacts.query_1254 LCMSourcePV.PrimeFacts.prime_1142599) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 28 1142650=(some row_121) :=
    choose0_skip 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 27 1142650 1142633 (some row_121) (SearchFacts.query_1255 LCMSourcePV.PrimeFacts.prime_1142633) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 29 1142676=(some row_121) :=
    choose0_skip 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 28 1142676 1142651 (some row_121) (SearchFacts.query_1256 LCMSourcePV.PrimeFacts.prime_1142651) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 30 1142692=(some row_121) :=
    choose0_skip 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 29 1142692 1142677 (some row_121) (SearchFacts.query_1257 LCMSourcePV.PrimeFacts.prime_1142677) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 31 1142706=(some row_121) :=
    choose0_skip 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 30 1142706 1142693 (some row_121) (SearchFacts.query_1258 LCMSourcePV.PrimeFacts.prime_1142693) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 32 1142736=(some row_121) :=
    choose0_skip 1000 30 1142761 10712529 1087 1091 1093 1142737 1142759 31 1142736 1142707 (some row_121) (SearchFacts.query_1259 LCMSourcePV.PrimeFacts.prime_1142707) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1142761 10712529 1087 1091 1093 1142759 16 1142758=some row_121 :=
    choose1_hit 1000 30 32 1142761 10712529 1087 1091 1093 1142759 15 1142758 1142737 row_121 (SearchFacts.query_1260 LCMSourcePV.PrimeFacts.prime_1142737) c0_0_0
  have hsqrt : Nat.sqrt 1142761=1069 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1142761+1)=some 1087 := by
    rw [hsqrt];exact (SearchFacts.query_4242 LCMSourcePV.PrimeFacts.prime_1087)
  exact make_hit 1000 30 32 16 1142761 10712529 1087 1091 1093 1142759 row_121 h0 (SearchFacts.query_4243 LCMSourcePV.PrimeFacts.prime_1091) (SearchFacts.query_4244 LCMSourcePV.PrimeFacts.prime_1093) (SearchFacts.query_1261 LCMSourcePV.PrimeFacts.prime_1142759) c1_0
#print axioms make_121
end LCMSourcePV.Witness.BlockProofs
