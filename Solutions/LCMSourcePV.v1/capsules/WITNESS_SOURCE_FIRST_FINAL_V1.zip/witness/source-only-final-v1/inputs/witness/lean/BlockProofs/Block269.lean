/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_269 : Block := (Block.mk 4853209 4870848 2207 2213 2221 4852873 4853183 4853203)
theorem make_269 : make 1000 30 32 16 4853209 10712529=some row_269 := by
  have ck_0_17_0 : (Block.mk 4853209 4870848 2207 2213 2221 4852873 4853183 4853203).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2207 LCMSourcePV.PrimeFacts.prime_2213 LCMSourcePV.PrimeFacts.prime_2221 LCMSourcePV.PrimeFacts.prime_4852873 LCMSourcePV.PrimeFacts.prime_4853183 LCMSourcePV.PrimeFacts.prime_4853203
  have sh_0_17_0 : shrink 30 (Block.mk 4853209 4870848 2207 2213 2221 4852873 4853183 4853203)=some row_269 := shrink_hit _ _ ck_0_17_0
  have c0_0_17 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 15 4852878=some row_269 :=
    choose0_hit 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 14 4852878 4852873 row_269 (SearchFacts.query_2712 LCMSourcePV.PrimeFacts.prime_4852873) (by decide) sh_0_17_0
  have c0_0_16 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 16 4852900=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 15 4852900 4852879 (some row_269) (SearchFacts.query_2713 LCMSourcePV.PrimeFacts.prime_4852879) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 17 4852908=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 16 4852908 4852901 (some row_269) (SearchFacts.query_2714 LCMSourcePV.PrimeFacts.prime_4852901) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 18 4852918=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 17 4852918 4852909 (some row_269) (SearchFacts.query_2715 LCMSourcePV.PrimeFacts.prime_4852909) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 19 4852962=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 18 4852962 4852919 (some row_269) (SearchFacts.query_2716 LCMSourcePV.PrimeFacts.prime_4852919) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 20 4852978=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 19 4852978 4852963 (some row_269) (SearchFacts.query_2717 LCMSourcePV.PrimeFacts.prime_4852963) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 21 4852996=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 20 4852996 4852979 (some row_269) (SearchFacts.query_2718 LCMSourcePV.PrimeFacts.prime_4852979) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 22 4853038=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 21 4853038 4852997 (some row_269) (SearchFacts.query_2719 LCMSourcePV.PrimeFacts.prime_4852997) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 23 4853052=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 22 4853052 4853039 (some row_269) (SearchFacts.query_2720 LCMSourcePV.PrimeFacts.prime_4853039) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 24 4853058=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 23 4853058 4853053 (some row_269) (SearchFacts.query_2721 LCMSourcePV.PrimeFacts.prime_4853053) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 25 4853076=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 24 4853076 4853059 (some row_269) (SearchFacts.query_2722 LCMSourcePV.PrimeFacts.prime_4853059) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 26 4853082=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 25 4853082 4853077 (some row_269) (SearchFacts.query_2723 LCMSourcePV.PrimeFacts.prime_4853077) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 27 4853086=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 26 4853086 4853083 (some row_269) (SearchFacts.query_2724 LCMSourcePV.PrimeFacts.prime_4853083) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 28 4853088=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 27 4853088 4853087 (some row_269) (SearchFacts.query_2725 LCMSourcePV.PrimeFacts.prime_4853087) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 29 4853110=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 28 4853110 4853089 (some row_269) (SearchFacts.query_2726 LCMSourcePV.PrimeFacts.prime_4853089) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 30 4853116=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 29 4853116 4853111 (some row_269) (SearchFacts.query_2727 LCMSourcePV.PrimeFacts.prime_4853111) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 31 4853170=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 30 4853170 4853117 (some row_269) (SearchFacts.query_2728 LCMSourcePV.PrimeFacts.prime_4853117) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 32 4853182=(some row_269) :=
    choose0_skip 1000 30 4853209 10712529 2207 2213 2221 4853183 4853203 31 4853182 4853171 (some row_269) (SearchFacts.query_2729 LCMSourcePV.PrimeFacts.prime_4853171) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4853209 10712529 2207 2213 2221 4853203 16 4853202=some row_269 :=
    choose1_hit 1000 30 32 4853209 10712529 2207 2213 2221 4853203 15 4853202 4853183 row_269 (SearchFacts.query_2730 LCMSourcePV.PrimeFacts.prime_4853183) c0_0_0
  have hsqrt : Nat.sqrt 4853209=2203 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4853209+1)=some 2207 := by
    rw [hsqrt];exact (SearchFacts.query_4390 LCMSourcePV.PrimeFacts.prime_2207)
  exact make_hit 1000 30 32 16 4853209 10712529 2207 2213 2221 4853203 row_269 h0 (SearchFacts.query_4391 LCMSourcePV.PrimeFacts.prime_2213) (SearchFacts.query_4392 LCMSourcePV.PrimeFacts.prime_2221) (SearchFacts.query_2731 LCMSourcePV.PrimeFacts.prime_4853203) c1_0
#print axioms make_269
end LCMSourcePV.Witness.BlockProofs
