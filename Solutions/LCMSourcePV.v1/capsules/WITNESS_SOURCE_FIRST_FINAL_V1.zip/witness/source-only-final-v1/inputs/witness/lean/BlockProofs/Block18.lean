/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_18 : Block := (Block.mk 151321 157608 397 401 409 151157 151289 151303)
theorem make_18 : make 1000 30 32 16 151321 10712529=some row_18 := by
  have ck_0_13_0 : (Block.mk 151321 157608 397 401 409 151157 151289 151303).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_397 LCMSourcePV.PrimeFacts.prime_401 LCMSourcePV.PrimeFacts.prime_409 LCMSourcePV.PrimeFacts.prime_151157 LCMSourcePV.PrimeFacts.prime_151289 LCMSourcePV.PrimeFacts.prime_151303
  have sh_0_13_0 : shrink 30 (Block.mk 151321 157608 397 401 409 151157 151289 151303)=some row_18 := shrink_hit _ _ ck_0_13_0
  have c0_0_13 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 19 151162=some row_18 :=
    choose0_hit 1000 30 151321 10712529 397 401 409 151289 151303 18 151162 151157 row_18 (SearchFacts.query_132 LCMSourcePV.PrimeFacts.prime_151157) (by decide) sh_0_13_0
  have c0_0_12 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 20 151168=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 19 151168 151163 (some row_18) (SearchFacts.query_133 LCMSourcePV.PrimeFacts.prime_151163) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 21 151170=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 20 151170 151169 (some row_18) (SearchFacts.query_134 LCMSourcePV.PrimeFacts.prime_151169) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 22 151188=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 21 151188 151171 (some row_18) (SearchFacts.query_135 LCMSourcePV.PrimeFacts.prime_151171) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 23 151200=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 22 151200 151189 (some row_18) (SearchFacts.query_136 LCMSourcePV.PrimeFacts.prime_151189) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 24 151212=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 23 151212 151201 (some row_18) (SearchFacts.query_137 LCMSourcePV.PrimeFacts.prime_151201) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 25 151236=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 24 151236 151213 (some row_18) (SearchFacts.query_138 LCMSourcePV.PrimeFacts.prime_151213) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 26 151240=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 25 151240 151237 (some row_18) (SearchFacts.query_139 LCMSourcePV.PrimeFacts.prime_151237) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 27 151242=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 26 151242 151241 (some row_18) (SearchFacts.query_140 LCMSourcePV.PrimeFacts.prime_151241) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 28 151246=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 27 151246 151243 (some row_18) (SearchFacts.query_141 LCMSourcePV.PrimeFacts.prime_151243) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 29 151252=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 28 151252 151247 (some row_18) (SearchFacts.query_142 LCMSourcePV.PrimeFacts.prime_151247) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 30 151272=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 29 151272 151253 (some row_18) (SearchFacts.query_143 LCMSourcePV.PrimeFacts.prime_151253) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 31 151278=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 30 151278 151273 (some row_18) (SearchFacts.query_144 LCMSourcePV.PrimeFacts.prime_151273) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 151321 10712529 397 401 409 151289 151303 32 151288=(some row_18) :=
    choose0_skip 1000 30 151321 10712529 397 401 409 151289 151303 31 151288 151279 (some row_18) (SearchFacts.query_145 LCMSourcePV.PrimeFacts.prime_151279) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 151321 10712529 397 401 409 151303 16 151302=some row_18 :=
    choose1_hit 1000 30 32 151321 10712529 397 401 409 151303 15 151302 151289 row_18 (SearchFacts.query_146 LCMSourcePV.PrimeFacts.prime_151289) c0_0_0
  have hsqrt : Nat.sqrt 151321=389 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 151321+1)=some 397 := by
    rw [hsqrt];exact (SearchFacts.query_4139 LCMSourcePV.PrimeFacts.prime_397)
  exact make_hit 1000 30 32 16 151321 10712529 397 401 409 151303 row_18 h0 (SearchFacts.query_4140 LCMSourcePV.PrimeFacts.prime_401) (SearchFacts.query_4141 LCMSourcePV.PrimeFacts.prime_409) (SearchFacts.query_147 LCMSourcePV.PrimeFacts.prime_151303) c1_0
#print axioms make_18
end LCMSourcePV.Witness.BlockProofs
