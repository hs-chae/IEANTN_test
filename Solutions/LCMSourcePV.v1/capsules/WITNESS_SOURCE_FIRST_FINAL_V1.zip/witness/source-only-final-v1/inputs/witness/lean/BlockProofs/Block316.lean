/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_316 : Block := (Block.mk 6538249 6651240 2579 2591 2593 6538073 6538211 6538219)
theorem make_316 : make 1000 30 32 16 6538249 10712529=some row_316 := by
  have ck_0_7_0 : (Block.mk 6538249 6651240 2579 2591 2593 6538073 6538211 6538219).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2579 LCMSourcePV.PrimeFacts.prime_2591 LCMSourcePV.PrimeFacts.prime_2593 LCMSourcePV.PrimeFacts.prime_6538073 LCMSourcePV.PrimeFacts.prime_6538211 LCMSourcePV.PrimeFacts.prime_6538219
  have sh_0_7_0 : shrink 30 (Block.mk 6538249 6651240 2579 2591 2593 6538073 6538211 6538219)=some row_316 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 25 6538110=some row_316 :=
    choose0_hit 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 24 6538110 6538073 row_316 (SearchFacts.query_3225 LCMSourcePV.PrimeFacts.prime_6538073) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 26 6538126=(some row_316) :=
    choose0_skip 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 25 6538126 6538111 (some row_316) (SearchFacts.query_3226 LCMSourcePV.PrimeFacts.prime_6538111) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 27 6538138=(some row_316) :=
    choose0_skip 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 26 6538138 6538127 (some row_316) (SearchFacts.query_3227 LCMSourcePV.PrimeFacts.prime_6538127) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 28 6538150=(some row_316) :=
    choose0_skip 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 27 6538150 6538139 (some row_316) (SearchFacts.query_3228 LCMSourcePV.PrimeFacts.prime_6538139) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 29 6538156=(some row_316) :=
    choose0_skip 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 28 6538156 6538151 (some row_316) (SearchFacts.query_3229 LCMSourcePV.PrimeFacts.prime_6538151) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 30 6538170=(some row_316) :=
    choose0_skip 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 29 6538170 6538157 (some row_316) (SearchFacts.query_3230 LCMSourcePV.PrimeFacts.prime_6538157) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 31 6538200=(some row_316) :=
    choose0_skip 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 30 6538200 6538171 (some row_316) (SearchFacts.query_3231 LCMSourcePV.PrimeFacts.prime_6538171) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 32 6538210=(some row_316) :=
    choose0_skip 1000 30 6538249 10712529 2579 2591 2593 6538211 6538219 31 6538210 6538201 (some row_316) (SearchFacts.query_3232 LCMSourcePV.PrimeFacts.prime_6538201) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6538249 10712529 2579 2591 2593 6538219 16 6538218=some row_316 :=
    choose1_hit 1000 30 32 6538249 10712529 2579 2591 2593 6538219 15 6538218 6538211 row_316 (SearchFacts.query_3233 LCMSourcePV.PrimeFacts.prime_6538211) c0_0_0
  have hsqrt : Nat.sqrt 6538249=2557 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6538249+1)=some 2579 := by
    rw [hsqrt];exact (SearchFacts.query_4437 LCMSourcePV.PrimeFacts.prime_2579)
  exact make_hit 1000 30 32 16 6538249 10712529 2579 2591 2593 6538219 row_316 h0 (SearchFacts.query_4438 LCMSourcePV.PrimeFacts.prime_2591) (SearchFacts.query_4439 LCMSourcePV.PrimeFacts.prime_2593) (SearchFacts.query_3234 LCMSourcePV.PrimeFacts.prime_6538219) c1_0
#print axioms make_316
end LCMSourcePV.Witness.BlockProofs
