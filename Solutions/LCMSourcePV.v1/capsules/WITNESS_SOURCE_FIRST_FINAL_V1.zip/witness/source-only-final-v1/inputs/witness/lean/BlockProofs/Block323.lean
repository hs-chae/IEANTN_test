/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_323 : Block := (Block.mk 6932689 7006608 2647 2657 2659 6932327 6932659 6932669)
theorem make_323 : make 1000 30 32 16 6932689 10712529=some row_323 := by
  have ck_0_18_0 : (Block.mk 6932689 7006608 2647 2657 2659 6932327 6932659 6932669).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2647 LCMSourcePV.PrimeFacts.prime_2657 LCMSourcePV.PrimeFacts.prime_2659 LCMSourcePV.PrimeFacts.prime_6932327 LCMSourcePV.PrimeFacts.prime_6932659 LCMSourcePV.PrimeFacts.prime_6932669
  have sh_0_18_0 : shrink 30 (Block.mk 6932689 7006608 2647 2657 2659 6932327 6932659 6932669)=some row_323 := shrink_hit _ _ ck_0_18_0
  have c0_0_18 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 14 6932332=some row_323 :=
    choose0_hit 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 13 6932332 6932327 row_323 (SearchFacts.query_3288 LCMSourcePV.PrimeFacts.prime_6932327) (by decide) sh_0_18_0
  have c0_0_17 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 15 6932338=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 14 6932338 6932333 (some row_323) (SearchFacts.query_3289 LCMSourcePV.PrimeFacts.prime_6932333) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 16 6932370=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 15 6932370 6932339 (some row_323) (SearchFacts.query_3290 LCMSourcePV.PrimeFacts.prime_6932339) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 17 6932376=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 16 6932376 6932371 (some row_323) (SearchFacts.query_3291 LCMSourcePV.PrimeFacts.prime_6932371) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 18 6932380=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 17 6932380 6932377 (some row_323) (SearchFacts.query_3292 LCMSourcePV.PrimeFacts.prime_6932377) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 19 6932410=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 18 6932410 6932381 (some row_323) (SearchFacts.query_3293 LCMSourcePV.PrimeFacts.prime_6932381) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 20 6932458=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 19 6932458 6932411 (some row_323) (SearchFacts.query_3294 LCMSourcePV.PrimeFacts.prime_6932411) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 21 6932460=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 20 6932460 6932459 (some row_323) (SearchFacts.query_3295 LCMSourcePV.PrimeFacts.prime_6932459) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 22 6932482=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 21 6932482 6932461 (some row_323) (SearchFacts.query_3296 LCMSourcePV.PrimeFacts.prime_6932461) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 23 6932488=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 22 6932488 6932483 (some row_323) (SearchFacts.query_3297 LCMSourcePV.PrimeFacts.prime_6932483) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 24 6932530=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 23 6932530 6932489 (some row_323) (SearchFacts.query_3298 LCMSourcePV.PrimeFacts.prime_6932489) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 25 6932532=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 24 6932532 6932531 (some row_323) (SearchFacts.query_3299 LCMSourcePV.PrimeFacts.prime_6932531) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 26 6932542=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 25 6932542 6932533 (some row_323) (SearchFacts.query_3300 LCMSourcePV.PrimeFacts.prime_6932533) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 27 6932580=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 26 6932580 6932543 (some row_323) (SearchFacts.query_3301 LCMSourcePV.PrimeFacts.prime_6932543) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 28 6932598=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 27 6932598 6932581 (some row_323) (SearchFacts.query_3302 LCMSourcePV.PrimeFacts.prime_6932581) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 29 6932602=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 28 6932602 6932599 (some row_323) (SearchFacts.query_3303 LCMSourcePV.PrimeFacts.prime_6932599) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 30 6932608=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 29 6932608 6932603 (some row_323) (SearchFacts.query_3304 LCMSourcePV.PrimeFacts.prime_6932603) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 31 6932632=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 30 6932632 6932609 (some row_323) (SearchFacts.query_3305 LCMSourcePV.PrimeFacts.prime_6932609) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 32 6932658=(some row_323) :=
    choose0_skip 1000 30 6932689 10712529 2647 2657 2659 6932659 6932669 31 6932658 6932633 (some row_323) (SearchFacts.query_3306 LCMSourcePV.PrimeFacts.prime_6932633) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6932689 10712529 2647 2657 2659 6932669 16 6932668=some row_323 :=
    choose1_hit 1000 30 32 6932689 10712529 2647 2657 2659 6932669 15 6932668 6932659 row_323 (SearchFacts.query_3307 LCMSourcePV.PrimeFacts.prime_6932659) c0_0_0
  have hsqrt : Nat.sqrt 6932689=2633 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6932689+1)=some 2647 := by
    rw [hsqrt];exact (SearchFacts.query_4444 LCMSourcePV.PrimeFacts.prime_2647)
  exact make_hit 1000 30 32 16 6932689 10712529 2647 2657 2659 6932669 row_323 h0 (SearchFacts.query_4445 LCMSourcePV.PrimeFacts.prime_2657) (SearchFacts.query_4446 LCMSourcePV.PrimeFacts.prime_2659) (SearchFacts.query_3308 LCMSourcePV.PrimeFacts.prime_6932669) c1_0
#print axioms make_323
end LCMSourcePV.Witness.BlockProofs
