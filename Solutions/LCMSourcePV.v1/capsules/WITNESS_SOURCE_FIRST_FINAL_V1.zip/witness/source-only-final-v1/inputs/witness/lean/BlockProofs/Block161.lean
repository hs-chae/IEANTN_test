/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_161 : Block := (Block.mk 1885129 1907160 1381 1399 1409 1885007 1885043 1885069)
theorem make_161 : make 1000 30 32 16 1885129 10712529=some row_161 := by
  have ck_0_2_0 : (Block.mk 1885129 1907160 1381 1399 1409 1885007 1885043 1885069).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1381 LCMSourcePV.PrimeFacts.prime_1399 LCMSourcePV.PrimeFacts.prime_1409 LCMSourcePV.PrimeFacts.prime_1885007 LCMSourcePV.PrimeFacts.prime_1885043 LCMSourcePV.PrimeFacts.prime_1885069
  have sh_0_2_0 : shrink 30 (Block.mk 1885129 1907160 1381 1399 1409 1885007 1885043 1885069)=some row_161 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 1885129 10712529 1381 1399 1409 1885043 1885069 30 1885020=some row_161 :=
    choose0_hit 1000 30 1885129 10712529 1381 1399 1409 1885043 1885069 29 1885020 1885007 row_161 (SearchFacts.query_1669 LCMSourcePV.PrimeFacts.prime_1885007) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 1885129 10712529 1381 1399 1409 1885043 1885069 31 1885032=(some row_161) :=
    choose0_skip 1000 30 1885129 10712529 1381 1399 1409 1885043 1885069 30 1885032 1885021 (some row_161) (SearchFacts.query_1670 LCMSourcePV.PrimeFacts.prime_1885021) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1885129 10712529 1381 1399 1409 1885043 1885069 32 1885042=(some row_161) :=
    choose0_skip 1000 30 1885129 10712529 1381 1399 1409 1885043 1885069 31 1885042 1885033 (some row_161) (SearchFacts.query_1671 LCMSourcePV.PrimeFacts.prime_1885033) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1885129 10712529 1381 1399 1409 1885069 16 1885068=some row_161 :=
    choose1_hit 1000 30 32 1885129 10712529 1381 1399 1409 1885069 15 1885068 1885043 row_161 (SearchFacts.query_1672 LCMSourcePV.PrimeFacts.prime_1885043) c0_0_0
  have hsqrt : Nat.sqrt 1885129=1373 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1885129+1)=some 1381 := by
    rw [hsqrt];exact (SearchFacts.query_4282 LCMSourcePV.PrimeFacts.prime_1381)
  exact make_hit 1000 30 32 16 1885129 10712529 1381 1399 1409 1885069 row_161 h0 (SearchFacts.query_4283 LCMSourcePV.PrimeFacts.prime_1399) (SearchFacts.query_4284 LCMSourcePV.PrimeFacts.prime_1409) (SearchFacts.query_1673 LCMSourcePV.PrimeFacts.prime_1885069) c1_0
#print axioms make_161
end LCMSourcePV.Witness.BlockProofs
