/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_243 : Block := (Block.mk 3988009 3996000 1999 2003 2011 3987913 3988003 3988007)
theorem make_243 : make 1000 30 32 16 3988009 10712529=some row_243 := by
  have ck_0_3_0 : (Block.mk 3988009 3996000 1999 2003 2011 3987913 3988003 3988007).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1999 LCMSourcePV.PrimeFacts.prime_2003 LCMSourcePV.PrimeFacts.prime_2011 LCMSourcePV.PrimeFacts.prime_3987913 LCMSourcePV.PrimeFacts.prime_3988003 LCMSourcePV.PrimeFacts.prime_3988007
  have sh_0_3_0 : shrink 30 (Block.mk 3988009 3996000 1999 2003 2011 3987913 3988003 3988007)=some row_243 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 3988009 10712529 1999 2003 2011 3988003 3988007 29 3987930=some row_243 :=
    choose0_hit 1000 30 3988009 10712529 1999 2003 2011 3988003 3988007 28 3987930 3987913 row_243 (SearchFacts.query_2479 LCMSourcePV.PrimeFacts.prime_3987913) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 3988009 10712529 1999 2003 2011 3988003 3988007 30 3987936=(some row_243) :=
    choose0_skip 1000 30 3988009 10712529 1999 2003 2011 3988003 3988007 29 3987936 3987931 (some row_243) (SearchFacts.query_2480 LCMSourcePV.PrimeFacts.prime_3987931) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3988009 10712529 1999 2003 2011 3988003 3988007 31 3987942=(some row_243) :=
    choose0_skip 1000 30 3988009 10712529 1999 2003 2011 3988003 3988007 30 3987942 3987937 (some row_243) (SearchFacts.query_2481 LCMSourcePV.PrimeFacts.prime_3987937) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3988009 10712529 1999 2003 2011 3988003 3988007 32 3988002=(some row_243) :=
    choose0_skip 1000 30 3988009 10712529 1999 2003 2011 3988003 3988007 31 3988002 3987943 (some row_243) (SearchFacts.query_2482 LCMSourcePV.PrimeFacts.prime_3987943) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3988009 10712529 1999 2003 2011 3988007 16 3988006=some row_243 :=
    choose1_hit 1000 30 32 3988009 10712529 1999 2003 2011 3988007 15 3988006 3988003 row_243 (SearchFacts.query_2483 LCMSourcePV.PrimeFacts.prime_3988003) c0_0_0
  have hsqrt : Nat.sqrt 3988009=1997 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3988009+1)=some 1999 := by
    rw [hsqrt];exact (SearchFacts.query_4364 LCMSourcePV.PrimeFacts.prime_1999)
  exact make_hit 1000 30 32 16 3988009 10712529 1999 2003 2011 3988007 row_243 h0 (SearchFacts.query_4365 LCMSourcePV.PrimeFacts.prime_2003) (SearchFacts.query_4366 LCMSourcePV.PrimeFacts.prime_2011) (SearchFacts.query_2484 LCMSourcePV.PrimeFacts.prime_3988007) c1_0
#print axioms make_243
end LCMSourcePV.Witness.BlockProofs
