/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_153 : Block := (Block.mk 1692601 1697808 1303 1307 1319 1692541 1692583 1692589)
theorem make_153 : make 1000 30 32 16 1692601 10712529=some row_153 := by
  have ck_0_1_0 : (Block.mk 1692601 1697808 1303 1307 1319 1692541 1692583 1692589).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1303 LCMSourcePV.PrimeFacts.prime_1307 LCMSourcePV.PrimeFacts.prime_1319 LCMSourcePV.PrimeFacts.prime_1692541 LCMSourcePV.PrimeFacts.prime_1692583 LCMSourcePV.PrimeFacts.prime_1692589
  have sh_0_1_0 : shrink 30 (Block.mk 1692601 1697808 1303 1307 1319 1692541 1692583 1692589)=some row_153 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 1692601 10712529 1303 1307 1319 1692583 1692589 31 1692562=some row_153 :=
    choose0_hit 1000 30 1692601 10712529 1303 1307 1319 1692583 1692589 30 1692562 1692541 row_153 (SearchFacts.query_1598 LCMSourcePV.PrimeFacts.prime_1692541) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 1692601 10712529 1303 1307 1319 1692583 1692589 32 1692582=(some row_153) :=
    choose0_skip 1000 30 1692601 10712529 1303 1307 1319 1692583 1692589 31 1692582 1692563 (some row_153) (SearchFacts.query_1599 LCMSourcePV.PrimeFacts.prime_1692563) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1692601 10712529 1303 1307 1319 1692589 16 1692588=some row_153 :=
    choose1_hit 1000 30 32 1692601 10712529 1303 1307 1319 1692589 15 1692588 1692583 row_153 (SearchFacts.query_1600 LCMSourcePV.PrimeFacts.prime_1692583) c0_0_0
  have hsqrt : Nat.sqrt 1692601=1301 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1692601+1)=some 1303 := by
    rw [hsqrt];exact (SearchFacts.query_4274 LCMSourcePV.PrimeFacts.prime_1303)
  exact make_hit 1000 30 32 16 1692601 10712529 1303 1307 1319 1692589 row_153 h0 (SearchFacts.query_4275 LCMSourcePV.PrimeFacts.prime_1307) (SearchFacts.query_4276 LCMSourcePV.PrimeFacts.prime_1319) (SearchFacts.query_1601 LCMSourcePV.PrimeFacts.prime_1692589) c1_0
#print axioms make_153
end LCMSourcePV.Witness.BlockProofs
