/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_108 : Block := (Block.mk 982081 994008 997 1009 1013 981949 982063 982067)
theorem make_108 : make 1000 30 32 16 982081 10712529=some row_108 := by
  have ck_0_6_0 : (Block.mk 982081 994008 997 1009 1013 981949 982063 982067).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_997 LCMSourcePV.PrimeFacts.prime_1009 LCMSourcePV.PrimeFacts.prime_1013 LCMSourcePV.PrimeFacts.prime_981949 LCMSourcePV.PrimeFacts.prime_982063 LCMSourcePV.PrimeFacts.prime_982067
  have sh_0_6_0 : shrink 30 (Block.mk 982081 994008 997 1009 1013 981949 982063 982067)=some row_108 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 982081 10712529 997 1009 1013 982063 982067 26 981960=some row_108 :=
    choose0_hit 1000 30 982081 10712529 997 1009 1013 982063 982067 25 981960 981949 row_108 (SearchFacts.query_1115 LCMSourcePV.PrimeFacts.prime_981949) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 982081 10712529 997 1009 1013 982063 982067 27 981978=(some row_108) :=
    choose0_skip 1000 30 982081 10712529 997 1009 1013 982063 982067 26 981978 981961 (some row_108) (SearchFacts.query_1116 LCMSourcePV.PrimeFacts.prime_981961) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 982081 10712529 997 1009 1013 982063 982067 28 981982=(some row_108) :=
    choose0_skip 1000 30 982081 10712529 997 1009 1013 982063 982067 27 981982 981979 (some row_108) (SearchFacts.query_1117 LCMSourcePV.PrimeFacts.prime_981979) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 982081 10712529 997 1009 1013 982063 982067 29 982020=(some row_108) :=
    choose0_skip 1000 30 982081 10712529 997 1009 1013 982063 982067 28 982020 981983 (some row_108) (SearchFacts.query_1118 LCMSourcePV.PrimeFacts.prime_981983) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 982081 10712529 997 1009 1013 982063 982067 30 982056=(some row_108) :=
    choose0_skip 1000 30 982081 10712529 997 1009 1013 982063 982067 29 982056 982021 (some row_108) (SearchFacts.query_1119 LCMSourcePV.PrimeFacts.prime_982021) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 982081 10712529 997 1009 1013 982063 982067 31 982060=(some row_108) :=
    choose0_skip 1000 30 982081 10712529 997 1009 1013 982063 982067 30 982060 982057 (some row_108) (SearchFacts.query_1120 LCMSourcePV.PrimeFacts.prime_982057) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 982081 10712529 997 1009 1013 982063 982067 32 982062=(some row_108) :=
    choose0_skip 1000 30 982081 10712529 997 1009 1013 982063 982067 31 982062 982061 (some row_108) (SearchFacts.query_1121 LCMSourcePV.PrimeFacts.prime_982061) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 982081 10712529 997 1009 1013 982067 16 982066=some row_108 :=
    choose1_hit 1000 30 32 982081 10712529 997 1009 1013 982067 15 982066 982063 row_108 (SearchFacts.query_1122 LCMSourcePV.PrimeFacts.prime_982063) c0_0_0
  have hsqrt : Nat.sqrt 982081=991 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 982081+1)=some 997 := by
    rw [hsqrt];exact (SearchFacts.query_4229 LCMSourcePV.PrimeFacts.prime_997)
  exact make_hit 1000 30 32 16 982081 10712529 997 1009 1013 982067 row_108 h0 (SearchFacts.query_4230 LCMSourcePV.PrimeFacts.prime_1009) (SearchFacts.query_4231 LCMSourcePV.PrimeFacts.prime_1013) (SearchFacts.query_1123 LCMSourcePV.PrimeFacts.prime_982067) c1_0
#print axioms make_108
end LCMSourcePV.Witness.BlockProofs
