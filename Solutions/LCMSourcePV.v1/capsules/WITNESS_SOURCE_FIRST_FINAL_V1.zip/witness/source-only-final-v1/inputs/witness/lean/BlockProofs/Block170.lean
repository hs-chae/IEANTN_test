/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_170 : Block := (Block.mk 2093809 2105400 1451 1453 1459 2093639 2093801 2093807)
theorem make_170 : make 1000 30 32 16 2093809 10712529=some row_170 := by
  have ck_0_6_0 : (Block.mk 2093809 2105400 1451 1453 1459 2093639 2093801 2093807).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1451 LCMSourcePV.PrimeFacts.prime_1453 LCMSourcePV.PrimeFacts.prime_1459 LCMSourcePV.PrimeFacts.prime_2093639 LCMSourcePV.PrimeFacts.prime_2093801 LCMSourcePV.PrimeFacts.prime_2093807
  have sh_0_6_0 : shrink 30 (Block.mk 2093809 2105400 1451 1453 1459 2093639 2093801 2093807)=some row_170 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 26 2093652=some row_170 :=
    choose0_hit 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 25 2093652 2093639 row_170 (SearchFacts.query_1735 LCMSourcePV.PrimeFacts.prime_2093639) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 27 2093698=(some row_170) :=
    choose0_skip 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 26 2093698 2093653 (some row_170) (SearchFacts.query_1736 LCMSourcePV.PrimeFacts.prime_2093653) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 28 2093700=(some row_170) :=
    choose0_skip 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 27 2093700 2093699 (some row_170) (SearchFacts.query_1737 LCMSourcePV.PrimeFacts.prime_2093699) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 29 2093760=(some row_170) :=
    choose0_skip 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 28 2093760 2093701 (some row_170) (SearchFacts.query_1738 LCMSourcePV.PrimeFacts.prime_2093701) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 30 2093782=(some row_170) :=
    choose0_skip 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 29 2093782 2093761 (some row_170) (SearchFacts.query_1739 LCMSourcePV.PrimeFacts.prime_2093761) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 31 2093788=(some row_170) :=
    choose0_skip 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 30 2093788 2093783 (some row_170) (SearchFacts.query_1740 LCMSourcePV.PrimeFacts.prime_2093783) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 32 2093800=(some row_170) :=
    choose0_skip 1000 30 2093809 10712529 1451 1453 1459 2093801 2093807 31 2093800 2093789 (some row_170) (SearchFacts.query_1741 LCMSourcePV.PrimeFacts.prime_2093789) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2093809 10712529 1451 1453 1459 2093807 16 2093806=some row_170 :=
    choose1_hit 1000 30 32 2093809 10712529 1451 1453 1459 2093807 15 2093806 2093801 row_170 (SearchFacts.query_1742 LCMSourcePV.PrimeFacts.prime_2093801) c0_0_0
  have hsqrt : Nat.sqrt 2093809=1447 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2093809+1)=some 1451 := by
    rw [hsqrt];exact (SearchFacts.query_4291 LCMSourcePV.PrimeFacts.prime_1451)
  exact make_hit 1000 30 32 16 2093809 10712529 1451 1453 1459 2093807 row_170 h0 (SearchFacts.query_4292 LCMSourcePV.PrimeFacts.prime_1453) (SearchFacts.query_4293 LCMSourcePV.PrimeFacts.prime_1459) (SearchFacts.query_1743 LCMSourcePV.PrimeFacts.prime_2093807) c1_0
#print axioms make_170
end LCMSourcePV.Witness.BlockProofs
