/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_212 : Block := (Block.mk 3031081 3052008 1747 1753 1759 3031019 3031069 3031079)
theorem make_212 : make 1000 30 32 16 3031081 10712529=some row_212 := by
  have ck_0_2_0 : (Block.mk 3031081 3052008 1747 1753 1759 3031019 3031069 3031079).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1747 LCMSourcePV.PrimeFacts.prime_1753 LCMSourcePV.PrimeFacts.prime_1759 LCMSourcePV.PrimeFacts.prime_3031019 LCMSourcePV.PrimeFacts.prime_3031069 LCMSourcePV.PrimeFacts.prime_3031079
  have sh_0_2_0 : shrink 30 (Block.mk 3031081 3052008 1747 1753 1759 3031019 3031069 3031079)=some row_212 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 3031081 10712529 1747 1753 1759 3031069 3031079 30 3031030=some row_212 :=
    choose0_hit 1000 30 3031081 10712529 1747 1753 1759 3031069 3031079 29 3031030 3031019 row_212 (SearchFacts.query_2206 LCMSourcePV.PrimeFacts.prime_3031019) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 3031081 10712529 1747 1753 1759 3031069 3031079 31 3031042=(some row_212) :=
    choose0_skip 1000 30 3031081 10712529 1747 1753 1759 3031069 3031079 30 3031042 3031031 (some row_212) (SearchFacts.query_2207 LCMSourcePV.PrimeFacts.prime_3031031) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3031081 10712529 1747 1753 1759 3031069 3031079 32 3031068=(some row_212) :=
    choose0_skip 1000 30 3031081 10712529 1747 1753 1759 3031069 3031079 31 3031068 3031043 (some row_212) (SearchFacts.query_2208 LCMSourcePV.PrimeFacts.prime_3031043) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3031081 10712529 1747 1753 1759 3031079 16 3031078=some row_212 :=
    choose1_hit 1000 30 32 3031081 10712529 1747 1753 1759 3031079 15 3031078 3031069 row_212 (SearchFacts.query_2209 LCMSourcePV.PrimeFacts.prime_3031069) c0_0_0
  have hsqrt : Nat.sqrt 3031081=1741 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3031081+1)=some 1747 := by
    rw [hsqrt];exact (SearchFacts.query_4333 LCMSourcePV.PrimeFacts.prime_1747)
  exact make_hit 1000 30 32 16 3031081 10712529 1747 1753 1759 3031079 row_212 h0 (SearchFacts.query_4334 LCMSourcePV.PrimeFacts.prime_1753) (SearchFacts.query_4335 LCMSourcePV.PrimeFacts.prime_1759) (SearchFacts.query_2210 LCMSourcePV.PrimeFacts.prime_3031079) c1_0
#print axioms make_212
end LCMSourcePV.Witness.BlockProofs
