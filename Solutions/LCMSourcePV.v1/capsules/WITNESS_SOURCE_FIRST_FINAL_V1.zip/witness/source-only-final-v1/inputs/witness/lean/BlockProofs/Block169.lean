/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_169 : Block := (Block.mk 2070721 2093808 1447 1451 1453 2070613 2070661 2070709)
theorem make_169 : make 1000 30 32 16 2070721 10712529=some row_169 := by
  have ck_0_3_0 : (Block.mk 2070721 2093808 1447 1451 1453 2070613 2070661 2070709).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1447 LCMSourcePV.PrimeFacts.prime_1451 LCMSourcePV.PrimeFacts.prime_1453 LCMSourcePV.PrimeFacts.prime_2070613 LCMSourcePV.PrimeFacts.prime_2070661 LCMSourcePV.PrimeFacts.prime_2070709
  have sh_0_3_0 : shrink 30 (Block.mk 2070721 2093808 1447 1451 1453 2070613 2070661 2070709)=some row_169 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 2070721 10712529 1447 1451 1453 2070661 2070709 29 2070618=some row_169 :=
    choose0_hit 1000 30 2070721 10712529 1447 1451 1453 2070661 2070709 28 2070618 2070613 row_169 (SearchFacts.query_1729 LCMSourcePV.PrimeFacts.prime_2070613) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 2070721 10712529 1447 1451 1453 2070661 2070709 30 2070640=(some row_169) :=
    choose0_skip 1000 30 2070721 10712529 1447 1451 1453 2070661 2070709 29 2070640 2070619 (some row_169) (SearchFacts.query_1730 LCMSourcePV.PrimeFacts.prime_2070619) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2070721 10712529 1447 1451 1453 2070661 2070709 31 2070642=(some row_169) :=
    choose0_skip 1000 30 2070721 10712529 1447 1451 1453 2070661 2070709 30 2070642 2070641 (some row_169) (SearchFacts.query_1731 LCMSourcePV.PrimeFacts.prime_2070641) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2070721 10712529 1447 1451 1453 2070661 2070709 32 2070660=(some row_169) :=
    choose0_skip 1000 30 2070721 10712529 1447 1451 1453 2070661 2070709 31 2070660 2070643 (some row_169) (SearchFacts.query_1732 LCMSourcePV.PrimeFacts.prime_2070643) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2070721 10712529 1447 1451 1453 2070709 16 2070708=some row_169 :=
    choose1_hit 1000 30 32 2070721 10712529 1447 1451 1453 2070709 15 2070708 2070661 row_169 (SearchFacts.query_1733 LCMSourcePV.PrimeFacts.prime_2070661) c0_0_0
  have hsqrt : Nat.sqrt 2070721=1439 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2070721+1)=some 1447 := by
    rw [hsqrt];exact (SearchFacts.query_4290 LCMSourcePV.PrimeFacts.prime_1447)
  exact make_hit 1000 30 32 16 2070721 10712529 1447 1451 1453 2070709 row_169 h0 (SearchFacts.query_4291 LCMSourcePV.PrimeFacts.prime_1451) (SearchFacts.query_4292 LCMSourcePV.PrimeFacts.prime_1453) (SearchFacts.query_1734 LCMSourcePV.PrimeFacts.prime_2070709) c1_0
#print axioms make_169
end LCMSourcePV.Witness.BlockProofs
