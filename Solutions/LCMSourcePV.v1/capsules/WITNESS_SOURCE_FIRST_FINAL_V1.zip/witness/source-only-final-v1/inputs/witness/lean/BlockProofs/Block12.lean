/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_12 : Block := (Block.mk 124609 128880 359 367 373 124529 124577 124601)
theorem make_12 : make 1000 30 32 16 124609 10712529=some row_12 := by
  have ck_0_4_0 : (Block.mk 124609 128880 359 367 373 124529 124577 124601).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_359 LCMSourcePV.PrimeFacts.prime_367 LCMSourcePV.PrimeFacts.prime_373 LCMSourcePV.PrimeFacts.prime_124529 LCMSourcePV.PrimeFacts.prime_124577 LCMSourcePV.PrimeFacts.prime_124601
  have sh_0_4_0 : shrink 30 (Block.mk 124609 128880 359 367 373 124529 124577 124601)=some row_12 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 124609 10712529 359 367 373 124577 124601 28 124540=some row_12 :=
    choose0_hit 1000 30 124609 10712529 359 367 373 124577 124601 27 124540 124529 row_12 (SearchFacts.query_91 LCMSourcePV.PrimeFacts.prime_124529) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 124609 10712529 359 367 373 124577 124601 29 124542=(some row_12) :=
    choose0_skip 1000 30 124609 10712529 359 367 373 124577 124601 28 124542 124541 (some row_12) (SearchFacts.query_92 LCMSourcePV.PrimeFacts.prime_124541) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 124609 10712529 359 367 373 124577 124601 30 124560=(some row_12) :=
    choose0_skip 1000 30 124609 10712529 359 367 373 124577 124601 29 124560 124543 (some row_12) (SearchFacts.query_93 LCMSourcePV.PrimeFacts.prime_124543) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 124609 10712529 359 367 373 124577 124601 31 124566=(some row_12) :=
    choose0_skip 1000 30 124609 10712529 359 367 373 124577 124601 30 124566 124561 (some row_12) (SearchFacts.query_94 LCMSourcePV.PrimeFacts.prime_124561) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 124609 10712529 359 367 373 124577 124601 32 124576=(some row_12) :=
    choose0_skip 1000 30 124609 10712529 359 367 373 124577 124601 31 124576 124567 (some row_12) (SearchFacts.query_95 LCMSourcePV.PrimeFacts.prime_124567) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 124609 10712529 359 367 373 124601 16 124600=some row_12 :=
    choose1_hit 1000 30 32 124609 10712529 359 367 373 124601 15 124600 124577 row_12 (SearchFacts.query_96 LCMSourcePV.PrimeFacts.prime_124577) c0_0_0
  have hsqrt : Nat.sqrt 124609=353 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 124609+1)=some 359 := by
    rw [hsqrt];exact (SearchFacts.query_4133 LCMSourcePV.PrimeFacts.prime_359)
  exact make_hit 1000 30 32 16 124609 10712529 359 367 373 124601 row_12 h0 (SearchFacts.query_4134 LCMSourcePV.PrimeFacts.prime_367) (SearchFacts.query_4135 LCMSourcePV.PrimeFacts.prime_373) (SearchFacts.query_97 LCMSourcePV.PrimeFacts.prime_124601) c1_0
#print axioms make_12
end LCMSourcePV.Witness.BlockProofs
