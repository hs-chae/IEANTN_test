/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_172 : Block := (Block.mk 2111209 2128680 1459 1471 1481 2111023 2111177 2111189)
theorem make_172 : make 1000 30 32 16 2111209 10712529=some row_172 := by
  have ck_0_10_0 : (Block.mk 2111209 2128680 1459 1471 1481 2111023 2111177 2111189).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1459 LCMSourcePV.PrimeFacts.prime_1471 LCMSourcePV.PrimeFacts.prime_1481 LCMSourcePV.PrimeFacts.prime_2111023 LCMSourcePV.PrimeFacts.prime_2111177 LCMSourcePV.PrimeFacts.prime_2111189
  have sh_0_10_0 : shrink 30 (Block.mk 2111209 2128680 1459 1471 1481 2111023 2111177 2111189)=some row_172 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 22 2111028=some row_172 :=
    choose0_hit 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 21 2111028 2111023 row_172 (SearchFacts.query_1750 LCMSourcePV.PrimeFacts.prime_2111023) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 23 2111040=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 22 2111040 2111029 (some row_172) (SearchFacts.query_1751 LCMSourcePV.PrimeFacts.prime_2111029) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 24 2111050=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 23 2111050 2111041 (some row_172) (SearchFacts.query_1752 LCMSourcePV.PrimeFacts.prime_2111041) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 25 2111058=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 24 2111058 2111051 (some row_172) (SearchFacts.query_1753 LCMSourcePV.PrimeFacts.prime_2111051) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 26 2111088=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 25 2111088 2111059 (some row_172) (SearchFacts.query_1754 LCMSourcePV.PrimeFacts.prime_2111059) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 27 2111092=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 26 2111092 2111089 (some row_172) (SearchFacts.query_1755 LCMSourcePV.PrimeFacts.prime_2111089) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 28 2111106=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 27 2111106 2111093 (some row_172) (SearchFacts.query_1756 LCMSourcePV.PrimeFacts.prime_2111093) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 29 2111128=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 28 2111128 2111107 (some row_172) (SearchFacts.query_1757 LCMSourcePV.PrimeFacts.prime_2111107) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 30 2111158=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 29 2111158 2111129 (some row_172) (SearchFacts.query_1758 LCMSourcePV.PrimeFacts.prime_2111129) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 31 2111166=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 30 2111166 2111159 (some row_172) (SearchFacts.query_1759 LCMSourcePV.PrimeFacts.prime_2111159) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 32 2111176=(some row_172) :=
    choose0_skip 1000 30 2111209 10712529 1459 1471 1481 2111177 2111189 31 2111176 2111167 (some row_172) (SearchFacts.query_1760 LCMSourcePV.PrimeFacts.prime_2111167) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2111209 10712529 1459 1471 1481 2111189 16 2111188=some row_172 :=
    choose1_hit 1000 30 32 2111209 10712529 1459 1471 1481 2111189 15 2111188 2111177 row_172 (SearchFacts.query_1761 LCMSourcePV.PrimeFacts.prime_2111177) c0_0_0
  have hsqrt : Nat.sqrt 2111209=1453 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2111209+1)=some 1459 := by
    rw [hsqrt];exact (SearchFacts.query_4293 LCMSourcePV.PrimeFacts.prime_1459)
  exact make_hit 1000 30 32 16 2111209 10712529 1459 1471 1481 2111189 row_172 h0 (SearchFacts.query_4294 LCMSourcePV.PrimeFacts.prime_1471) (SearchFacts.query_4295 LCMSourcePV.PrimeFacts.prime_1481) (SearchFacts.query_1762 LCMSourcePV.PrimeFacts.prime_2111189) c1_0
#print axioms make_172
end LCMSourcePV.Witness.BlockProofs
