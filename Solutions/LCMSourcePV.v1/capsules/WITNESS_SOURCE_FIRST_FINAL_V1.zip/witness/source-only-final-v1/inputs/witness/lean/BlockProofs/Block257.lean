/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_257 : Block := (Block.mk 4363921 4405800 2099 2111 2113 4363829 4363889 4363897)
theorem make_257 : make 1000 30 32 16 4363921 10712529=some row_257 := by
  have ck_0_1_0 : (Block.mk 4363921 4405800 2099 2111 2113 4363829 4363889 4363897).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2099 LCMSourcePV.PrimeFacts.prime_2111 LCMSourcePV.PrimeFacts.prime_2113 LCMSourcePV.PrimeFacts.prime_4363829 LCMSourcePV.PrimeFacts.prime_4363889 LCMSourcePV.PrimeFacts.prime_4363897
  have sh_0_1_0 : shrink 30 (Block.mk 4363921 4405800 2099 2111 2113 4363829 4363889 4363897)=some row_257 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 4363921 10712529 2099 2111 2113 4363889 4363897 31 4363836=some row_257 :=
    choose0_hit 1000 30 4363921 10712529 2099 2111 2113 4363889 4363897 30 4363836 4363829 row_257 (SearchFacts.query_2603 LCMSourcePV.PrimeFacts.prime_4363829) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 4363921 10712529 2099 2111 2113 4363889 4363897 32 4363888=(some row_257) :=
    choose0_skip 1000 30 4363921 10712529 2099 2111 2113 4363889 4363897 31 4363888 4363837 (some row_257) (SearchFacts.query_2604 LCMSourcePV.PrimeFacts.prime_4363837) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4363921 10712529 2099 2111 2113 4363897 16 4363896=some row_257 :=
    choose1_hit 1000 30 32 4363921 10712529 2099 2111 2113 4363897 15 4363896 4363889 row_257 (SearchFacts.query_2605 LCMSourcePV.PrimeFacts.prime_4363889) c0_0_0
  have hsqrt : Nat.sqrt 4363921=2089 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4363921+1)=some 2099 := by
    rw [hsqrt];exact (SearchFacts.query_4378 LCMSourcePV.PrimeFacts.prime_2099)
  exact make_hit 1000 30 32 16 4363921 10712529 2099 2111 2113 4363897 row_257 h0 (SearchFacts.query_4379 LCMSourcePV.PrimeFacts.prime_2111) (SearchFacts.query_4380 LCMSourcePV.PrimeFacts.prime_2113) (SearchFacts.query_2606 LCMSourcePV.PrimeFacts.prime_4363897) c1_0
#print axioms make_257
end LCMSourcePV.Witness.BlockProofs
