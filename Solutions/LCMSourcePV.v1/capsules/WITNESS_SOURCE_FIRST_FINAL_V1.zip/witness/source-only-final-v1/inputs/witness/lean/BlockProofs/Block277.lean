/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_277 : Block := (Block.mk 5139289 5148360 2269 2273 2281 5139137 5139259 5139271)
theorem make_277 : make 1000 30 32 16 5139289 10712529=some row_277 := by
  have ck_0_6_0 : (Block.mk 5139289 5148360 2269 2273 2281 5139137 5139259 5139271).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2269 LCMSourcePV.PrimeFacts.prime_2273 LCMSourcePV.PrimeFacts.prime_2281 LCMSourcePV.PrimeFacts.prime_5139137 LCMSourcePV.PrimeFacts.prime_5139259 LCMSourcePV.PrimeFacts.prime_5139271
  have sh_0_6_0 : shrink 30 (Block.mk 5139289 5148360 2269 2273 2281 5139137 5139259 5139271)=some row_277 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 26 5139160=some row_277 :=
    choose0_hit 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 25 5139160 5139137 row_277 (SearchFacts.query_2804 LCMSourcePV.PrimeFacts.prime_5139137) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 27 5139178=(some row_277) :=
    choose0_skip 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 26 5139178 5139161 (some row_277) (SearchFacts.query_2805 LCMSourcePV.PrimeFacts.prime_5139161) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 28 5139202=(some row_277) :=
    choose0_skip 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 27 5139202 5139179 (some row_277) (SearchFacts.query_2806 LCMSourcePV.PrimeFacts.prime_5139179) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 29 5139220=(some row_277) :=
    choose0_skip 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 28 5139220 5139203 (some row_277) (SearchFacts.query_2807 LCMSourcePV.PrimeFacts.prime_5139203) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 30 5139222=(some row_277) :=
    choose0_skip 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 29 5139222 5139221 (some row_277) (SearchFacts.query_2808 LCMSourcePV.PrimeFacts.prime_5139221) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 31 5139256=(some row_277) :=
    choose0_skip 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 30 5139256 5139223 (some row_277) (SearchFacts.query_2809 LCMSourcePV.PrimeFacts.prime_5139223) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 32 5139258=(some row_277) :=
    choose0_skip 1000 30 5139289 10712529 2269 2273 2281 5139259 5139271 31 5139258 5139257 (some row_277) (SearchFacts.query_2810 LCMSourcePV.PrimeFacts.prime_5139257) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5139289 10712529 2269 2273 2281 5139271 16 5139270=some row_277 :=
    choose1_hit 1000 30 32 5139289 10712529 2269 2273 2281 5139271 15 5139270 5139259 row_277 (SearchFacts.query_2811 LCMSourcePV.PrimeFacts.prime_5139259) c0_0_0
  have hsqrt : Nat.sqrt 5139289=2267 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5139289+1)=some 2269 := by
    rw [hsqrt];exact (SearchFacts.query_4398 LCMSourcePV.PrimeFacts.prime_2269)
  exact make_hit 1000 30 32 16 5139289 10712529 2269 2273 2281 5139271 row_277 h0 (SearchFacts.query_4399 LCMSourcePV.PrimeFacts.prime_2273) (SearchFacts.query_4400 LCMSourcePV.PrimeFacts.prime_2281) (SearchFacts.query_2812 LCMSourcePV.PrimeFacts.prime_5139271) c1_0
#print axioms make_277
end LCMSourcePV.Witness.BlockProofs
