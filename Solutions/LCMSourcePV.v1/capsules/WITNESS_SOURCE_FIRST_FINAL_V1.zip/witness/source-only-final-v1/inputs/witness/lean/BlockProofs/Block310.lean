/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_310 : Block := (Block.mk 6355441 6405960 2531 2539 2543 6354967 6355373 6355381)
theorem make_310 : make 1000 30 32 16 6355441 10712529=some row_310 := by
  have ck_0_25_0 : (Block.mk 6355441 6405960 2531 2539 2543 6354967 6355373 6355381).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2531 LCMSourcePV.PrimeFacts.prime_2539 LCMSourcePV.PrimeFacts.prime_2543 LCMSourcePV.PrimeFacts.prime_6354967 LCMSourcePV.PrimeFacts.prime_6355373 LCMSourcePV.PrimeFacts.prime_6355381
  have sh_0_25_0 : shrink 30 (Block.mk 6355441 6405960 2531 2539 2543 6354967 6355373 6355381)=some row_310 := shrink_hit _ _ ck_0_25_0
  have c0_0_25 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 7 6354976=some row_310 :=
    choose0_hit 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 6 6354976 6354967 row_310 (SearchFacts.query_3131 LCMSourcePV.PrimeFacts.prime_6354967) (by decide) sh_0_25_0
  have c0_0_24 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 8 6354982=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 7 6354982 6354977 (some row_310) (SearchFacts.query_3132 LCMSourcePV.PrimeFacts.prime_6354977) (by decide) c0_0_25
  have c0_0_23 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 9 6354988=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 8 6354988 6354983 (some row_310) (SearchFacts.query_3133 LCMSourcePV.PrimeFacts.prime_6354983) (by decide) c0_0_24
  have c0_0_22 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 10 6355000=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 9 6355000 6354989 (some row_310) (SearchFacts.query_3134 LCMSourcePV.PrimeFacts.prime_6354989) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 11 6355038=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 10 6355038 6355001 (some row_310) (SearchFacts.query_3135 LCMSourcePV.PrimeFacts.prime_6355001) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 12 6355048=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 11 6355048 6355039 (some row_310) (SearchFacts.query_3136 LCMSourcePV.PrimeFacts.prime_6355039) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 13 6355072=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 12 6355072 6355049 (some row_310) (SearchFacts.query_3137 LCMSourcePV.PrimeFacts.prime_6355049) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 14 6355078=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 13 6355078 6355073 (some row_310) (SearchFacts.query_3138 LCMSourcePV.PrimeFacts.prime_6355073) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 15 6355080=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 14 6355080 6355079 (some row_310) (SearchFacts.query_3139 LCMSourcePV.PrimeFacts.prime_6355079) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 16 6355086=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 15 6355086 6355081 (some row_310) (SearchFacts.query_3140 LCMSourcePV.PrimeFacts.prime_6355081) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 17 6355102=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 16 6355102 6355087 (some row_310) (SearchFacts.query_3141 LCMSourcePV.PrimeFacts.prime_6355087) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 18 6355120=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 17 6355120 6355103 (some row_310) (SearchFacts.query_3142 LCMSourcePV.PrimeFacts.prime_6355103) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 19 6355132=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 18 6355132 6355121 (some row_310) (SearchFacts.query_3143 LCMSourcePV.PrimeFacts.prime_6355121) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 20 6355168=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 19 6355168 6355133 (some row_310) (SearchFacts.query_3144 LCMSourcePV.PrimeFacts.prime_6355133) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 21 6355170=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 20 6355170 6355169 (some row_310) (SearchFacts.query_3145 LCMSourcePV.PrimeFacts.prime_6355169) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 22 6355186=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 21 6355186 6355171 (some row_310) (SearchFacts.query_3146 LCMSourcePV.PrimeFacts.prime_6355171) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 23 6355188=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 22 6355188 6355187 (some row_310) (SearchFacts.query_3147 LCMSourcePV.PrimeFacts.prime_6355187) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 24 6355200=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 23 6355200 6355189 (some row_310) (SearchFacts.query_3148 LCMSourcePV.PrimeFacts.prime_6355189) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 25 6355212=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 24 6355212 6355201 (some row_310) (SearchFacts.query_3149 LCMSourcePV.PrimeFacts.prime_6355201) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 26 6355242=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 25 6355242 6355213 (some row_310) (SearchFacts.query_3150 LCMSourcePV.PrimeFacts.prime_6355213) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 27 6355246=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 26 6355246 6355243 (some row_310) (SearchFacts.query_3151 LCMSourcePV.PrimeFacts.prime_6355243) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 28 6355258=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 27 6355258 6355247 (some row_310) (SearchFacts.query_3152 LCMSourcePV.PrimeFacts.prime_6355247) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 29 6355300=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 28 6355300 6355259 (some row_310) (SearchFacts.query_3153 LCMSourcePV.PrimeFacts.prime_6355259) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 30 6355308=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 29 6355308 6355301 (some row_310) (SearchFacts.query_3154 LCMSourcePV.PrimeFacts.prime_6355301) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 31 6355332=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 30 6355332 6355309 (some row_310) (SearchFacts.query_3155 LCMSourcePV.PrimeFacts.prime_6355309) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 32 6355372=(some row_310) :=
    choose0_skip 1000 30 6355441 10712529 2531 2539 2543 6355373 6355381 31 6355372 6355333 (some row_310) (SearchFacts.query_3156 LCMSourcePV.PrimeFacts.prime_6355333) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6355441 10712529 2531 2539 2543 6355381 16 6355380=some row_310 :=
    choose1_hit 1000 30 32 6355441 10712529 2531 2539 2543 6355381 15 6355380 6355373 row_310 (SearchFacts.query_3157 LCMSourcePV.PrimeFacts.prime_6355373) c0_0_0
  have hsqrt : Nat.sqrt 6355441=2521 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6355441+1)=some 2531 := by
    rw [hsqrt];exact (SearchFacts.query_4431 LCMSourcePV.PrimeFacts.prime_2531)
  exact make_hit 1000 30 32 16 6355441 10712529 2531 2539 2543 6355381 row_310 h0 (SearchFacts.query_4432 LCMSourcePV.PrimeFacts.prime_2539) (SearchFacts.query_4433 LCMSourcePV.PrimeFacts.prime_2543) (SearchFacts.query_3158 LCMSourcePV.PrimeFacts.prime_6355381) c1_0
#print axioms make_310
end LCMSourcePV.Witness.BlockProofs
