/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_254 : Block := (Block.mk 4330561 4338888 2083 2087 2089 4330351 4330523 4330559)
theorem make_254 : make 1000 30 32 16 4330561 10712529=some row_254 := by
  have ck_0_10_0 : (Block.mk 4330561 4338888 2083 2087 2089 4330351 4330523 4330559).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2083 LCMSourcePV.PrimeFacts.prime_2087 LCMSourcePV.PrimeFacts.prime_2089 LCMSourcePV.PrimeFacts.prime_4330351 LCMSourcePV.PrimeFacts.prime_4330523 LCMSourcePV.PrimeFacts.prime_4330559
  have sh_0_10_0 : shrink 30 (Block.mk 4330561 4338888 2083 2087 2089 4330351 4330523 4330559)=some row_254 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 22 4330356=some row_254 :=
    choose0_hit 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 21 4330356 4330351 row_254 (SearchFacts.query_2581 LCMSourcePV.PrimeFacts.prime_4330351) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 23 4330372=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 22 4330372 4330357 (some row_254) (SearchFacts.query_2582 LCMSourcePV.PrimeFacts.prime_4330357) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 24 4330408=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 23 4330408 4330373 (some row_254) (SearchFacts.query_2583 LCMSourcePV.PrimeFacts.prime_4330373) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 25 4330452=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 24 4330452 4330409 (some row_254) (SearchFacts.query_2584 LCMSourcePV.PrimeFacts.prime_4330409) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 26 4330456=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 25 4330456 4330453 (some row_254) (SearchFacts.query_2585 LCMSourcePV.PrimeFacts.prime_4330453) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 27 4330480=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 26 4330480 4330457 (some row_254) (SearchFacts.query_2586 LCMSourcePV.PrimeFacts.prime_4330457) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 28 4330488=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 27 4330488 4330481 (some row_254) (SearchFacts.query_2587 LCMSourcePV.PrimeFacts.prime_4330481) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 29 4330492=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 28 4330492 4330489 (some row_254) (SearchFacts.query_2588 LCMSourcePV.PrimeFacts.prime_4330489) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 30 4330506=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 29 4330506 4330493 (some row_254) (SearchFacts.query_2589 LCMSourcePV.PrimeFacts.prime_4330493) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 31 4330510=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 30 4330510 4330507 (some row_254) (SearchFacts.query_2590 LCMSourcePV.PrimeFacts.prime_4330507) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 32 4330522=(some row_254) :=
    choose0_skip 1000 30 4330561 10712529 2083 2087 2089 4330523 4330559 31 4330522 4330511 (some row_254) (SearchFacts.query_2591 LCMSourcePV.PrimeFacts.prime_4330511) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4330561 10712529 2083 2087 2089 4330559 16 4330558=some row_254 :=
    choose1_hit 1000 30 32 4330561 10712529 2083 2087 2089 4330559 15 4330558 4330523 row_254 (SearchFacts.query_2592 LCMSourcePV.PrimeFacts.prime_4330523) c0_0_0
  have hsqrt : Nat.sqrt 4330561=2081 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4330561+1)=some 2083 := by
    rw [hsqrt];exact (SearchFacts.query_4375 LCMSourcePV.PrimeFacts.prime_2083)
  exact make_hit 1000 30 32 16 4330561 10712529 2083 2087 2089 4330559 row_254 h0 (SearchFacts.query_4376 LCMSourcePV.PrimeFacts.prime_2087) (SearchFacts.query_4377 LCMSourcePV.PrimeFacts.prime_2089) (SearchFacts.query_2593 LCMSourcePV.PrimeFacts.prime_4330559) c1_0
#print axioms make_254
end LCMSourcePV.Witness.BlockProofs
