/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_117 : Block := (Block.mk 1100401 1104600 1051 1061 1063 1100311 1100381 1100387)
theorem make_117 : make 1000 30 32 16 1100401 10712529=some row_117 := by
  have ck_0_4_0 : (Block.mk 1100401 1104600 1051 1061 1063 1100311 1100381 1100387).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1051 LCMSourcePV.PrimeFacts.prime_1061 LCMSourcePV.PrimeFacts.prime_1063 LCMSourcePV.PrimeFacts.prime_1100311 LCMSourcePV.PrimeFacts.prime_1100381 LCMSourcePV.PrimeFacts.prime_1100387
  have sh_0_4_0 : shrink 30 (Block.mk 1100401 1104600 1051 1061 1063 1100311 1100381 1100387)=some row_117 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 28 1100320=some row_117 :=
    choose0_hit 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 27 1100320 1100311 row_117 (SearchFacts.query_1188 LCMSourcePV.PrimeFacts.prime_1100311) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 29 1100352=(some row_117) :=
    choose0_skip 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 28 1100352 1100321 (some row_117) (SearchFacts.query_1189 LCMSourcePV.PrimeFacts.prime_1100321) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 30 1100356=(some row_117) :=
    choose0_skip 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 29 1100356 1100353 (some row_117) (SearchFacts.query_1190 LCMSourcePV.PrimeFacts.prime_1100353) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 31 1100376=(some row_117) :=
    choose0_skip 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 30 1100376 1100357 (some row_117) (SearchFacts.query_1191 LCMSourcePV.PrimeFacts.prime_1100357) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 32 1100380=(some row_117) :=
    choose0_skip 1000 30 1100401 10712529 1051 1061 1063 1100381 1100387 31 1100380 1100377 (some row_117) (SearchFacts.query_1192 LCMSourcePV.PrimeFacts.prime_1100377) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1100401 10712529 1051 1061 1063 1100387 16 1100386=some row_117 :=
    choose1_hit 1000 30 32 1100401 10712529 1051 1061 1063 1100387 15 1100386 1100381 row_117 (SearchFacts.query_1193 LCMSourcePV.PrimeFacts.prime_1100381) c0_0_0
  have hsqrt : Nat.sqrt 1100401=1049 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1100401+1)=some 1051 := by
    rw [hsqrt];exact (SearchFacts.query_4238 LCMSourcePV.PrimeFacts.prime_1051)
  exact make_hit 1000 30 32 16 1100401 10712529 1051 1061 1063 1100387 row_117 h0 (SearchFacts.query_4239 LCMSourcePV.PrimeFacts.prime_1061) (SearchFacts.query_4240 LCMSourcePV.PrimeFacts.prime_1063) (SearchFacts.query_1194 LCMSourcePV.PrimeFacts.prime_1100387) c1_0
#print axioms make_117
end LCMSourcePV.Witness.BlockProofs
