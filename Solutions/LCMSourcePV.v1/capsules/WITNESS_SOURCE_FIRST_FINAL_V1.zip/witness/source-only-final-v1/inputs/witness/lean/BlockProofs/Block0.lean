/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_0 : Block := (Block.mk 81000 83424 293 307 311 80897 80963 80989)
theorem make_0 : make 1000 30 32 16 81000 10712529=some row_0 := by
  have ck_0_7_1 : (Block.mk 81000 83424 293 307 311 80897 80963 80989).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_293 LCMSourcePV.PrimeFacts.prime_307 LCMSourcePV.PrimeFacts.prime_311 LCMSourcePV.PrimeFacts.prime_80897 LCMSourcePV.PrimeFacts.prime_80963 LCMSourcePV.PrimeFacts.prime_80989
  have sh_0_7_1 : shrink 29 (Block.mk 81000 83424 293 307 311 80897 80963 80989)=some row_0 := shrink_hit _ _ ck_0_7_1
  have ck_0_7_0 : (Block.mk 81000 85848 293 307 311 80897 80963 80989).exactCheck=false := check_false _ (by decide)
  have sh_0_7_0 : shrink 30 (Block.mk 81000 85848 293 307 311 80897 80963 80989)=some row_0 := shrink_step _ _ _ ck_0_7_0 (by decide) sh_0_7_1
  have c0_0_7 : choose0 1000 30 81000 10712529 293 307 311 80963 80989 25 80908=some row_0 :=
    choose0_hit 1000 30 81000 10712529 293 307 311 80963 80989 24 80908 80897 row_0 (SearchFacts.query_0 LCMSourcePV.PrimeFacts.prime_80897) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 81000 10712529 293 307 311 80963 80989 26 80910=(some row_0) :=
    choose0_skip 1000 30 81000 10712529 293 307 311 80963 80989 25 80910 80909 (some row_0) (SearchFacts.query_1 LCMSourcePV.PrimeFacts.prime_80909) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 81000 10712529 293 307 311 80963 80989 27 80916=(some row_0) :=
    choose0_skip 1000 30 81000 10712529 293 307 311 80963 80989 26 80916 80911 (some row_0) (SearchFacts.query_2 LCMSourcePV.PrimeFacts.prime_80911) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 81000 10712529 293 307 311 80963 80989 28 80922=(some row_0) :=
    choose0_skip 1000 30 81000 10712529 293 307 311 80963 80989 27 80922 80917 (some row_0) (SearchFacts.query_3 LCMSourcePV.PrimeFacts.prime_80917) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 81000 10712529 293 307 311 80963 80989 29 80928=(some row_0) :=
    choose0_skip 1000 30 81000 10712529 293 307 311 80963 80989 28 80928 80923 (some row_0) (SearchFacts.query_4 LCMSourcePV.PrimeFacts.prime_80923) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 81000 10712529 293 307 311 80963 80989 30 80932=(some row_0) :=
    choose0_skip 1000 30 81000 10712529 293 307 311 80963 80989 29 80932 80929 (some row_0) (SearchFacts.query_5 LCMSourcePV.PrimeFacts.prime_80929) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 81000 10712529 293 307 311 80963 80989 31 80952=(some row_0) :=
    choose0_skip 1000 30 81000 10712529 293 307 311 80963 80989 30 80952 80933 (some row_0) (SearchFacts.query_6 LCMSourcePV.PrimeFacts.prime_80933) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 81000 10712529 293 307 311 80963 80989 32 80962=(some row_0) :=
    choose0_skip 1000 30 81000 10712529 293 307 311 80963 80989 31 80962 80953 (some row_0) (SearchFacts.query_7 LCMSourcePV.PrimeFacts.prime_80953) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 81000 10712529 293 307 311 80989 16 80988=some row_0 :=
    choose1_hit 1000 30 32 81000 10712529 293 307 311 80989 15 80988 80963 row_0 (SearchFacts.query_8 LCMSourcePV.PrimeFacts.prime_80963) c0_0_0
  have hsqrt : Nat.sqrt 81000=284 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 81000+1)=some 293 := by
    rw [hsqrt];exact (SearchFacts.query_4121 LCMSourcePV.PrimeFacts.prime_293)
  exact make_hit 1000 30 32 16 81000 10712529 293 307 311 80989 row_0 h0 (SearchFacts.query_4123 LCMSourcePV.PrimeFacts.prime_307) (SearchFacts.query_4124 LCMSourcePV.PrimeFacts.prime_311) (SearchFacts.query_9 LCMSourcePV.PrimeFacts.prime_80989) c1_0
#print axioms make_0
end LCMSourcePV.Witness.BlockProofs
