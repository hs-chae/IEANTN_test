/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_132 : Block := (Block.mk 1329409 1352568 1163 1171 1181 1329233 1329397 1329407)
theorem make_132 : make 1000 30 32 16 1329409 10712529=some row_132 := by
  have ck_0_11_0 : (Block.mk 1329409 1352568 1163 1171 1181 1329233 1329397 1329407).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1163 LCMSourcePV.PrimeFacts.prime_1171 LCMSourcePV.PrimeFacts.prime_1181 LCMSourcePV.PrimeFacts.prime_1329233 LCMSourcePV.PrimeFacts.prime_1329397 LCMSourcePV.PrimeFacts.prime_1329407
  have sh_0_11_0 : shrink 30 (Block.mk 1329409 1352568 1163 1171 1181 1329233 1329397 1329407)=some row_132 := shrink_hit _ _ ck_0_11_0
  have c0_0_11 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 21 1329240=some row_132 :=
    choose0_hit 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 20 1329240 1329233 row_132 (SearchFacts.query_1438 LCMSourcePV.PrimeFacts.prime_1329233) (by decide) sh_0_11_0
  have c0_0_10 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 22 1329268=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 21 1329268 1329241 (some row_132) (SearchFacts.query_1439 LCMSourcePV.PrimeFacts.prime_1329241) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 23 1329276=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 22 1329276 1329269 (some row_132) (SearchFacts.query_1440 LCMSourcePV.PrimeFacts.prime_1329269) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 24 1329282=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 23 1329282 1329277 (some row_132) (SearchFacts.query_1441 LCMSourcePV.PrimeFacts.prime_1329277) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 25 1329286=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 24 1329286 1329283 (some row_132) (SearchFacts.query_1442 LCMSourcePV.PrimeFacts.prime_1329283) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 26 1329312=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 25 1329312 1329287 (some row_132) (SearchFacts.query_1443 LCMSourcePV.PrimeFacts.prime_1329287) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 27 1329336=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 26 1329336 1329313 (some row_132) (SearchFacts.query_1444 LCMSourcePV.PrimeFacts.prime_1329313) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 28 1329352=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 27 1329352 1329337 (some row_132) (SearchFacts.query_1445 LCMSourcePV.PrimeFacts.prime_1329337) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 29 1329358=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 28 1329358 1329353 (some row_132) (SearchFacts.query_1446 LCMSourcePV.PrimeFacts.prime_1329353) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 30 1329370=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 29 1329370 1329359 (some row_132) (SearchFacts.query_1447 LCMSourcePV.PrimeFacts.prime_1329359) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 31 1329378=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 30 1329378 1329371 (some row_132) (SearchFacts.query_1448 LCMSourcePV.PrimeFacts.prime_1329371) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 32 1329396=(some row_132) :=
    choose0_skip 1000 30 1329409 10712529 1163 1171 1181 1329397 1329407 31 1329396 1329379 (some row_132) (SearchFacts.query_1449 LCMSourcePV.PrimeFacts.prime_1329379) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1329409 10712529 1163 1171 1181 1329407 16 1329406=some row_132 :=
    choose1_hit 1000 30 32 1329409 10712529 1163 1171 1181 1329407 15 1329406 1329397 row_132 (SearchFacts.query_1450 LCMSourcePV.PrimeFacts.prime_1329397) c0_0_0
  have hsqrt : Nat.sqrt 1329409=1153 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1329409+1)=some 1163 := by
    rw [hsqrt];exact (SearchFacts.query_4253 LCMSourcePV.PrimeFacts.prime_1163)
  exact make_hit 1000 30 32 16 1329409 10712529 1163 1171 1181 1329407 row_132 h0 (SearchFacts.query_4254 LCMSourcePV.PrimeFacts.prime_1171) (SearchFacts.query_4255 LCMSourcePV.PrimeFacts.prime_1181) (SearchFacts.query_1451 LCMSourcePV.PrimeFacts.prime_1329407) c1_0
#print axioms make_132
end LCMSourcePV.Witness.BlockProofs
