/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_208 : Block := (Block.mk 2920681 2961840 1721 1723 1733 2920633 2920637 2920649)
theorem make_208 : make 1000 30 32 16 2920681 10712529=some row_208 := by
  have ck_0_0_0 : (Block.mk 2920681 2961840 1721 1723 1733 2920633 2920637 2920649).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1721 LCMSourcePV.PrimeFacts.prime_1723 LCMSourcePV.PrimeFacts.prime_1733 LCMSourcePV.PrimeFacts.prime_2920633 LCMSourcePV.PrimeFacts.prime_2920637 LCMSourcePV.PrimeFacts.prime_2920649
  have sh_0_0_0 : shrink 30 (Block.mk 2920681 2961840 1721 1723 1733 2920633 2920637 2920649)=some row_208 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 2920681 10712529 1721 1723 1733 2920637 2920649 32 2920636=some row_208 :=
    choose0_hit 1000 30 2920681 10712529 1721 1723 1733 2920637 2920649 31 2920636 2920633 row_208 (SearchFacts.query_2154 LCMSourcePV.PrimeFacts.prime_2920633) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 2920681 10712529 1721 1723 1733 2920649 16 2920648=some row_208 :=
    choose1_hit 1000 30 32 2920681 10712529 1721 1723 1733 2920649 15 2920648 2920637 row_208 (SearchFacts.query_2155 LCMSourcePV.PrimeFacts.prime_2920637) c0_0_0
  have hsqrt : Nat.sqrt 2920681=1709 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2920681+1)=some 1721 := by
    rw [hsqrt];exact (SearchFacts.query_4329 LCMSourcePV.PrimeFacts.prime_1721)
  exact make_hit 1000 30 32 16 2920681 10712529 1721 1723 1733 2920649 row_208 h0 (SearchFacts.query_4330 LCMSourcePV.PrimeFacts.prime_1723) (SearchFacts.query_4331 LCMSourcePV.PrimeFacts.prime_1733) (SearchFacts.query_2156 LCMSourcePV.PrimeFacts.prime_2920649) c1_0
#print axioms make_208
end LCMSourcePV.Witness.BlockProofs
