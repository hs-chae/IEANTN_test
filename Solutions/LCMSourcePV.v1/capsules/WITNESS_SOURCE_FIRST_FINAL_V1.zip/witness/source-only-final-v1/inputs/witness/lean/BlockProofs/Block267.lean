/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_267 : Block := (Block.mk 4669921 4748040 2179 2203 2207 4669811 4669891 4669913)
theorem make_267 : make 1000 30 32 16 4669921 10712529=some row_267 := by
  have ck_0_6_0 : (Block.mk 4669921 4748040 2179 2203 2207 4669811 4669891 4669913).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2179 LCMSourcePV.PrimeFacts.prime_2203 LCMSourcePV.PrimeFacts.prime_2207 LCMSourcePV.PrimeFacts.prime_4669811 LCMSourcePV.PrimeFacts.prime_4669891 LCMSourcePV.PrimeFacts.prime_4669913
  have sh_0_6_0 : shrink 30 (Block.mk 4669921 4748040 2179 2203 2207 4669811 4669891 4669913)=some row_267 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 26 4669812=some row_267 :=
    choose0_hit 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 25 4669812 4669811 row_267 (SearchFacts.query_2693 LCMSourcePV.PrimeFacts.prime_4669811) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 27 4669816=(some row_267) :=
    choose0_skip 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 26 4669816 4669813 (some row_267) (SearchFacts.query_2694 LCMSourcePV.PrimeFacts.prime_4669813) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 28 4669822=(some row_267) :=
    choose0_skip 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 27 4669822 4669817 (some row_267) (SearchFacts.query_2695 LCMSourcePV.PrimeFacts.prime_4669817) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 29 4669830=(some row_267) :=
    choose0_skip 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 28 4669830 4669823 (some row_267) (SearchFacts.query_2696 LCMSourcePV.PrimeFacts.prime_4669823) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 30 4669852=(some row_267) :=
    choose0_skip 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 29 4669852 4669831 (some row_267) (SearchFacts.query_2697 LCMSourcePV.PrimeFacts.prime_4669831) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 31 4669878=(some row_267) :=
    choose0_skip 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 30 4669878 4669853 (some row_267) (SearchFacts.query_2698 LCMSourcePV.PrimeFacts.prime_4669853) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 32 4669890=(some row_267) :=
    choose0_skip 1000 30 4669921 10712529 2179 2203 2207 4669891 4669913 31 4669890 4669879 (some row_267) (SearchFacts.query_2699 LCMSourcePV.PrimeFacts.prime_4669879) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4669921 10712529 2179 2203 2207 4669913 16 4669912=some row_267 :=
    choose1_hit 1000 30 32 4669921 10712529 2179 2203 2207 4669913 15 4669912 4669891 row_267 (SearchFacts.query_2700 LCMSourcePV.PrimeFacts.prime_4669891) c0_0_0
  have hsqrt : Nat.sqrt 4669921=2161 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4669921+1)=some 2179 := by
    rw [hsqrt];exact (SearchFacts.query_4388 LCMSourcePV.PrimeFacts.prime_2179)
  exact make_hit 1000 30 32 16 4669921 10712529 2179 2203 2207 4669913 row_267 h0 (SearchFacts.query_4389 LCMSourcePV.PrimeFacts.prime_2203) (SearchFacts.query_4390 LCMSourcePV.PrimeFacts.prime_2207) (SearchFacts.query_2701 LCMSourcePV.PrimeFacts.prime_4669913) c1_0
#print axioms make_267
end LCMSourcePV.Witness.BlockProofs
