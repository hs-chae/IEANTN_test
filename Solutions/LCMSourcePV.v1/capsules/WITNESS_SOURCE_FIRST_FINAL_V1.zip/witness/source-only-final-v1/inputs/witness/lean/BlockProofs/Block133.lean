/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_133 : Block := (Block.mk 1352569 1371240 1171 1181 1187 1352521 1352543 1352557)
theorem make_133 : make 1000 30 32 16 1352569 10712529=some row_133 := by
  have ck_0_0_0 : (Block.mk 1352569 1371240 1171 1181 1187 1352521 1352543 1352557).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1171 LCMSourcePV.PrimeFacts.prime_1181 LCMSourcePV.PrimeFacts.prime_1187 LCMSourcePV.PrimeFacts.prime_1352521 LCMSourcePV.PrimeFacts.prime_1352543 LCMSourcePV.PrimeFacts.prime_1352557
  have sh_0_0_0 : shrink 30 (Block.mk 1352569 1371240 1171 1181 1187 1352521 1352543 1352557)=some row_133 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 1352569 10712529 1171 1181 1187 1352543 1352557 32 1352542=some row_133 :=
    choose0_hit 1000 30 1352569 10712529 1171 1181 1187 1352543 1352557 31 1352542 1352521 row_133 (SearchFacts.query_1452 LCMSourcePV.PrimeFacts.prime_1352521) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 1352569 10712529 1171 1181 1187 1352557 16 1352556=some row_133 :=
    choose1_hit 1000 30 32 1352569 10712529 1171 1181 1187 1352557 15 1352556 1352543 row_133 (SearchFacts.query_1453 LCMSourcePV.PrimeFacts.prime_1352543) c0_0_0
  have hsqrt : Nat.sqrt 1352569=1163 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1352569+1)=some 1171 := by
    rw [hsqrt];exact (SearchFacts.query_4254 LCMSourcePV.PrimeFacts.prime_1171)
  exact make_hit 1000 30 32 16 1352569 10712529 1171 1181 1187 1352557 row_133 h0 (SearchFacts.query_4255 LCMSourcePV.PrimeFacts.prime_1181) (SearchFacts.query_4256 LCMSourcePV.PrimeFacts.prime_1187) (SearchFacts.query_1454 LCMSourcePV.PrimeFacts.prime_1352557) c1_0
#print axioms make_133
end LCMSourcePV.Witness.BlockProofs
