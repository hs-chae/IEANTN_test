/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_190 : Block := (Block.mk 2493241 2505888 1583 1597 1601 2493037 2493229 2493233)
theorem make_190 : make 1000 30 32 16 2493241 10712529=some row_190 := by
  have ck_0_14_0 : (Block.mk 2493241 2505888 1583 1597 1601 2493037 2493229 2493233).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1583 LCMSourcePV.PrimeFacts.prime_1597 LCMSourcePV.PrimeFacts.prime_1601 LCMSourcePV.PrimeFacts.prime_2493037 LCMSourcePV.PrimeFacts.prime_2493229 LCMSourcePV.PrimeFacts.prime_2493233
  have sh_0_14_0 : shrink 30 (Block.mk 2493241 2505888 1583 1597 1601 2493037 2493229 2493233)=some row_190 := shrink_hit _ _ ck_0_14_0
  have c0_0_14 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 18 2493040=some row_190 :=
    choose0_hit 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 17 2493040 2493037 row_190 (SearchFacts.query_1934 LCMSourcePV.PrimeFacts.prime_2493037) (by decide) sh_0_14_0
  have c0_0_13 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 19 2493052=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 18 2493052 2493041 (some row_190) (SearchFacts.query_1935 LCMSourcePV.PrimeFacts.prime_2493041) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 20 2493076=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 19 2493076 2493053 (some row_190) (SearchFacts.query_1936 LCMSourcePV.PrimeFacts.prime_2493053) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 21 2493078=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 20 2493078 2493077 (some row_190) (SearchFacts.query_1937 LCMSourcePV.PrimeFacts.prime_2493077) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 22 2493082=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 21 2493082 2493079 (some row_190) (SearchFacts.query_1938 LCMSourcePV.PrimeFacts.prime_2493079) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 23 2493088=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 22 2493088 2493083 (some row_190) (SearchFacts.query_1939 LCMSourcePV.PrimeFacts.prime_2493083) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 24 2493106=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 23 2493106 2493089 (some row_190) (SearchFacts.query_1940 LCMSourcePV.PrimeFacts.prime_2493089) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 25 2493108=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 24 2493108 2493107 (some row_190) (SearchFacts.query_1941 LCMSourcePV.PrimeFacts.prime_2493107) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 26 2493120=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 25 2493120 2493109 (some row_190) (SearchFacts.query_1942 LCMSourcePV.PrimeFacts.prime_2493109) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 27 2493148=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 26 2493148 2493121 (some row_190) (SearchFacts.query_1943 LCMSourcePV.PrimeFacts.prime_2493121) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 28 2493166=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 27 2493166 2493149 (some row_190) (SearchFacts.query_1944 LCMSourcePV.PrimeFacts.prime_2493149) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 29 2493186=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 28 2493186 2493167 (some row_190) (SearchFacts.query_1945 LCMSourcePV.PrimeFacts.prime_2493167) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 30 2493192=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 29 2493192 2493187 (some row_190) (SearchFacts.query_1946 LCMSourcePV.PrimeFacts.prime_2493187) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 31 2493220=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 30 2493220 2493193 (some row_190) (SearchFacts.query_1947 LCMSourcePV.PrimeFacts.prime_2493193) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 32 2493228=(some row_190) :=
    choose0_skip 1000 30 2493241 10712529 1583 1597 1601 2493229 2493233 31 2493228 2493221 (some row_190) (SearchFacts.query_1948 LCMSourcePV.PrimeFacts.prime_2493221) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2493241 10712529 1583 1597 1601 2493233 16 2493232=some row_190 :=
    choose1_hit 1000 30 32 2493241 10712529 1583 1597 1601 2493233 15 2493232 2493229 row_190 (SearchFacts.query_1949 LCMSourcePV.PrimeFacts.prime_2493229) c0_0_0
  have hsqrt : Nat.sqrt 2493241=1579 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2493241+1)=some 1583 := by
    rw [hsqrt];exact (SearchFacts.query_4311 LCMSourcePV.PrimeFacts.prime_1583)
  exact make_hit 1000 30 32 16 2493241 10712529 1583 1597 1601 2493233 row_190 h0 (SearchFacts.query_4312 LCMSourcePV.PrimeFacts.prime_1597) (SearchFacts.query_4313 LCMSourcePV.PrimeFacts.prime_1601) (SearchFacts.query_1950 LCMSourcePV.PrimeFacts.prime_2493233) c1_0
#print axioms make_190
end LCMSourcePV.Witness.BlockProofs
