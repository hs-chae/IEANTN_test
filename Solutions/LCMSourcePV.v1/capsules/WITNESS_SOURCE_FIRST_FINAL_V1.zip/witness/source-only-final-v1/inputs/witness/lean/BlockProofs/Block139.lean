/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_139 : Block := (Block.mk 1471369 1481088 1217 1223 1229 1471307 1471343 1471361)
theorem make_139 : make 1000 30 32 16 1471369 10712529=some row_139 := by
  have ck_0_3_0 : (Block.mk 1471369 1481088 1217 1223 1229 1471307 1471343 1471361).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1217 LCMSourcePV.PrimeFacts.prime_1223 LCMSourcePV.PrimeFacts.prime_1229 LCMSourcePV.PrimeFacts.prime_1471307 LCMSourcePV.PrimeFacts.prime_1471343 LCMSourcePV.PrimeFacts.prime_1471361
  have sh_0_3_0 : shrink 30 (Block.mk 1471369 1481088 1217 1223 1229 1471307 1471343 1471361)=some row_139 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 1471369 10712529 1217 1223 1229 1471343 1471361 29 1471312=some row_139 :=
    choose0_hit 1000 30 1471369 10712529 1217 1223 1229 1471343 1471361 28 1471312 1471307 row_139 (SearchFacts.query_1501 LCMSourcePV.PrimeFacts.prime_1471307) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 1471369 10712529 1217 1223 1229 1471343 1471361 30 1471320=(some row_139) :=
    choose0_skip 1000 30 1471369 10712529 1217 1223 1229 1471343 1471361 29 1471320 1471313 (some row_139) (SearchFacts.query_1502 LCMSourcePV.PrimeFacts.prime_1471313) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1471369 10712529 1217 1223 1229 1471343 1471361 31 1471338=(some row_139) :=
    choose0_skip 1000 30 1471369 10712529 1217 1223 1229 1471343 1471361 30 1471338 1471321 (some row_139) (SearchFacts.query_1503 LCMSourcePV.PrimeFacts.prime_1471321) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1471369 10712529 1217 1223 1229 1471343 1471361 32 1471342=(some row_139) :=
    choose0_skip 1000 30 1471369 10712529 1217 1223 1229 1471343 1471361 31 1471342 1471339 (some row_139) (SearchFacts.query_1504 LCMSourcePV.PrimeFacts.prime_1471339) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1471369 10712529 1217 1223 1229 1471361 16 1471360=some row_139 :=
    choose1_hit 1000 30 32 1471369 10712529 1217 1223 1229 1471361 15 1471360 1471343 row_139 (SearchFacts.query_1505 LCMSourcePV.PrimeFacts.prime_1471343) c0_0_0
  have hsqrt : Nat.sqrt 1471369=1213 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1471369+1)=some 1217 := by
    rw [hsqrt];exact (SearchFacts.query_4260 LCMSourcePV.PrimeFacts.prime_1217)
  exact make_hit 1000 30 32 16 1471369 10712529 1217 1223 1229 1471361 row_139 h0 (SearchFacts.query_4261 LCMSourcePV.PrimeFacts.prime_1223) (SearchFacts.query_4262 LCMSourcePV.PrimeFacts.prime_1229) (SearchFacts.query_1506 LCMSourcePV.PrimeFacts.prime_1471361) c1_0
#print axioms make_139
end LCMSourcePV.Witness.BlockProofs
