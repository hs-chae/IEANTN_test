/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_200 : Block := (Block.mk 2679769 2745648 1657 1663 1667 2679737 2679749 2679763)
theorem make_200 : make 1000 30 32 16 2679769 10712529=some row_200 := by
  have ck_0_0_0 : (Block.mk 2679769 2745648 1657 1663 1667 2679737 2679749 2679763).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1657 LCMSourcePV.PrimeFacts.prime_1663 LCMSourcePV.PrimeFacts.prime_1667 LCMSourcePV.PrimeFacts.prime_2679737 LCMSourcePV.PrimeFacts.prime_2679749 LCMSourcePV.PrimeFacts.prime_2679763
  have sh_0_0_0 : shrink 30 (Block.mk 2679769 2745648 1657 1663 1667 2679737 2679749 2679763)=some row_200 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 2679769 10712529 1657 1663 1667 2679749 2679763 32 2679748=some row_200 :=
    choose0_hit 1000 30 2679769 10712529 1657 1663 1667 2679749 2679763 31 2679748 2679737 row_200 (SearchFacts.query_2051 LCMSourcePV.PrimeFacts.prime_2679737) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 2679769 10712529 1657 1663 1667 2679763 16 2679762=some row_200 :=
    choose1_hit 1000 30 32 2679769 10712529 1657 1663 1667 2679763 15 2679762 2679749 row_200 (SearchFacts.query_2052 LCMSourcePV.PrimeFacts.prime_2679749) c0_0_0
  have hsqrt : Nat.sqrt 2679769=1637 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2679769+1)=some 1657 := by
    rw [hsqrt];exact (SearchFacts.query_4321 LCMSourcePV.PrimeFacts.prime_1657)
  exact make_hit 1000 30 32 16 2679769 10712529 1657 1663 1667 2679763 row_200 h0 (SearchFacts.query_4322 LCMSourcePV.PrimeFacts.prime_1663) (SearchFacts.query_4323 LCMSourcePV.PrimeFacts.prime_1667) (SearchFacts.query_2053 LCMSourcePV.PrimeFacts.prime_2679763) c1_0
#print axioms make_200
end LCMSourcePV.Witness.BlockProofs
