/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_206 : Block := (Block.mk 2879809 2886600 1699 1709 1721 2879791 2879801 2879803)
theorem make_206 : make 1000 30 32 16 2879809 10712529=some row_206 := by
  have ck_0_0_0 : (Block.mk 2879809 2886600 1699 1709 1721 2879791 2879801 2879803).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1699 LCMSourcePV.PrimeFacts.prime_1709 LCMSourcePV.PrimeFacts.prime_1721 LCMSourcePV.PrimeFacts.prime_2879791 LCMSourcePV.PrimeFacts.prime_2879801 LCMSourcePV.PrimeFacts.prime_2879803
  have sh_0_0_0 : shrink 30 (Block.mk 2879809 2886600 1699 1709 1721 2879791 2879801 2879803)=some row_206 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 2879809 10712529 1699 1709 1721 2879801 2879803 32 2879800=some row_206 :=
    choose0_hit 1000 30 2879809 10712529 1699 1709 1721 2879801 2879803 31 2879800 2879791 row_206 (SearchFacts.query_2124 LCMSourcePV.PrimeFacts.prime_2879791) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 2879809 10712529 1699 1709 1721 2879803 16 2879802=some row_206 :=
    choose1_hit 1000 30 32 2879809 10712529 1699 1709 1721 2879803 15 2879802 2879801 row_206 (SearchFacts.query_2125 LCMSourcePV.PrimeFacts.prime_2879801) c0_0_0
  have hsqrt : Nat.sqrt 2879809=1697 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2879809+1)=some 1699 := by
    rw [hsqrt];exact (SearchFacts.query_4327 LCMSourcePV.PrimeFacts.prime_1699)
  exact make_hit 1000 30 32 16 2879809 10712529 1699 1709 1721 2879803 row_206 h0 (SearchFacts.query_4328 LCMSourcePV.PrimeFacts.prime_1709) (SearchFacts.query_4329 LCMSourcePV.PrimeFacts.prime_1721) (SearchFacts.query_2126 LCMSourcePV.PrimeFacts.prime_2879803) c1_0
#print axioms make_206
end LCMSourcePV.Witness.BlockProofs
