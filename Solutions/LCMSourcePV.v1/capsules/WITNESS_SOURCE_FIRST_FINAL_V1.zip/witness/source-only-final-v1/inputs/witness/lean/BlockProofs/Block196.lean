/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_196 : Block := (Block.mk 2601769 2621160 1619 1621 1627 2601523 2601761 2601763)
theorem make_196 : make 1000 30 32 16 2601769 10712529=some row_196 := by
  have ck_0_12_0 : (Block.mk 2601769 2621160 1619 1621 1627 2601523 2601761 2601763).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1619 LCMSourcePV.PrimeFacts.prime_1621 LCMSourcePV.PrimeFacts.prime_1627 LCMSourcePV.PrimeFacts.prime_2601523 LCMSourcePV.PrimeFacts.prime_2601761 LCMSourcePV.PrimeFacts.prime_2601763
  have sh_0_12_0 : shrink 30 (Block.mk 2601769 2621160 1619 1621 1627 2601523 2601761 2601763)=some row_196 := shrink_hit _ _ ck_0_12_0
  have c0_0_12 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 20 2601538=some row_196 :=
    choose0_hit 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 19 2601538 2601523 row_196 (SearchFacts.query_2015 LCMSourcePV.PrimeFacts.prime_2601523) (by decide) sh_0_12_0
  have c0_0_11 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 21 2601562=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 20 2601562 2601539 (some row_196) (SearchFacts.query_2016 LCMSourcePV.PrimeFacts.prime_2601539) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 22 2601568=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 21 2601568 2601563 (some row_196) (SearchFacts.query_2017 LCMSourcePV.PrimeFacts.prime_2601563) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 23 2601582=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 22 2601582 2601569 (some row_196) (SearchFacts.query_2018 LCMSourcePV.PrimeFacts.prime_2601569) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 24 2601600=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 23 2601600 2601583 (some row_196) (SearchFacts.query_2019 LCMSourcePV.PrimeFacts.prime_2601583) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 25 2601606=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 24 2601606 2601601 (some row_196) (SearchFacts.query_2020 LCMSourcePV.PrimeFacts.prime_2601601) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 26 2601616=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 25 2601616 2601607 (some row_196) (SearchFacts.query_2021 LCMSourcePV.PrimeFacts.prime_2601607) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 27 2601660=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 26 2601660 2601617 (some row_196) (SearchFacts.query_2022 LCMSourcePV.PrimeFacts.prime_2601617) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 28 2601670=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 27 2601670 2601661 (some row_196) (SearchFacts.query_2023 LCMSourcePV.PrimeFacts.prime_2601661) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 29 2601678=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 28 2601678 2601671 (some row_196) (SearchFacts.query_2024 LCMSourcePV.PrimeFacts.prime_2601671) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 30 2601712=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 29 2601712 2601679 (some row_196) (SearchFacts.query_2025 LCMSourcePV.PrimeFacts.prime_2601679) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 31 2601756=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 30 2601756 2601713 (some row_196) (SearchFacts.query_2026 LCMSourcePV.PrimeFacts.prime_2601713) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 32 2601760=(some row_196) :=
    choose0_skip 1000 30 2601769 10712529 1619 1621 1627 2601761 2601763 31 2601760 2601757 (some row_196) (SearchFacts.query_2027 LCMSourcePV.PrimeFacts.prime_2601757) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2601769 10712529 1619 1621 1627 2601763 16 2601762=some row_196 :=
    choose1_hit 1000 30 32 2601769 10712529 1619 1621 1627 2601763 15 2601762 2601761 row_196 (SearchFacts.query_2028 LCMSourcePV.PrimeFacts.prime_2601761) c0_0_0
  have hsqrt : Nat.sqrt 2601769=1613 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2601769+1)=some 1619 := by
    rw [hsqrt];exact (SearchFacts.query_4317 LCMSourcePV.PrimeFacts.prime_1619)
  exact make_hit 1000 30 32 16 2601769 10712529 1619 1621 1627 2601763 row_196 h0 (SearchFacts.query_4318 LCMSourcePV.PrimeFacts.prime_1621) (SearchFacts.query_4319 LCMSourcePV.PrimeFacts.prime_1627) (SearchFacts.query_2029 LCMSourcePV.PrimeFacts.prime_2601763) c1_0
#print axioms make_196
end LCMSourcePV.Witness.BlockProofs
