/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_216 : Block := (Block.mk 3157729 3179088 1783 1787 1789 3157537 3157703 3157711)
theorem make_216 : make 1000 30 32 16 3157729 10712529=some row_216 := by
  have ck_0_12_0 : (Block.mk 3157729 3179088 1783 1787 1789 3157537 3157703 3157711).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1783 LCMSourcePV.PrimeFacts.prime_1787 LCMSourcePV.PrimeFacts.prime_1789 LCMSourcePV.PrimeFacts.prime_3157537 LCMSourcePV.PrimeFacts.prime_3157703 LCMSourcePV.PrimeFacts.prime_3157711
  have sh_0_12_0 : shrink 30 (Block.mk 3157729 3179088 1783 1787 1789 3157537 3157703 3157711)=some row_216 := shrink_hit _ _ ck_0_12_0
  have c0_0_12 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 20 3157540=some row_216 :=
    choose0_hit 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 19 3157540 3157537 row_216 (SearchFacts.query_2244 LCMSourcePV.PrimeFacts.prime_3157537) (by decide) sh_0_12_0
  have c0_0_11 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 21 3157546=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 20 3157546 3157541 (some row_216) (SearchFacts.query_2245 LCMSourcePV.PrimeFacts.prime_3157541) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 22 3157570=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 21 3157570 3157547 (some row_216) (SearchFacts.query_2246 LCMSourcePV.PrimeFacts.prime_3157547) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 23 3157572=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 22 3157572 3157571 (some row_216) (SearchFacts.query_2247 LCMSourcePV.PrimeFacts.prime_3157571) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 24 3157576=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 23 3157576 3157573 (some row_216) (SearchFacts.query_2248 LCMSourcePV.PrimeFacts.prime_3157573) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 25 3157578=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 24 3157578 3157577 (some row_216) (SearchFacts.query_2249 LCMSourcePV.PrimeFacts.prime_3157577) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 26 3157588=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 25 3157588 3157579 (some row_216) (SearchFacts.query_2250 LCMSourcePV.PrimeFacts.prime_3157579) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 27 3157602=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 26 3157602 3157589 (some row_216) (SearchFacts.query_2251 LCMSourcePV.PrimeFacts.prime_3157589) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 28 3157612=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 27 3157612 3157603 (some row_216) (SearchFacts.query_2252 LCMSourcePV.PrimeFacts.prime_3157603) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 29 3157638=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 28 3157638 3157613 (some row_216) (SearchFacts.query_2253 LCMSourcePV.PrimeFacts.prime_3157613) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 30 3157656=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 29 3157656 3157639 (some row_216) (SearchFacts.query_2254 LCMSourcePV.PrimeFacts.prime_3157639) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 31 3157668=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 30 3157668 3157657 (some row_216) (SearchFacts.query_2255 LCMSourcePV.PrimeFacts.prime_3157657) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 32 3157702=(some row_216) :=
    choose0_skip 1000 30 3157729 10712529 1783 1787 1789 3157703 3157711 31 3157702 3157669 (some row_216) (SearchFacts.query_2256 LCMSourcePV.PrimeFacts.prime_3157669) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3157729 10712529 1783 1787 1789 3157711 16 3157710=some row_216 :=
    choose1_hit 1000 30 32 3157729 10712529 1783 1787 1789 3157711 15 3157710 3157703 row_216 (SearchFacts.query_2257 LCMSourcePV.PrimeFacts.prime_3157703) c0_0_0
  have hsqrt : Nat.sqrt 3157729=1777 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3157729+1)=some 1783 := by
    rw [hsqrt];exact (SearchFacts.query_4337 LCMSourcePV.PrimeFacts.prime_1783)
  exact make_hit 1000 30 32 16 3157729 10712529 1783 1787 1789 3157711 row_216 h0 (SearchFacts.query_4338 LCMSourcePV.PrimeFacts.prime_1787) (SearchFacts.query_4339 LCMSourcePV.PrimeFacts.prime_1789) (SearchFacts.query_2258 LCMSourcePV.PrimeFacts.prime_3157711) c1_0
#print axioms make_216
end LCMSourcePV.Witness.BlockProofs
