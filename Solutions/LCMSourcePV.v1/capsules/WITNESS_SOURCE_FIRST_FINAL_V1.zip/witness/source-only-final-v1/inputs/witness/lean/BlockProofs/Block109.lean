/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_109 : Block := (Block.mk 994009 1018080 1009 1013 1019 993821 993983 993997)
theorem make_109 : make 1000 30 32 16 994009 10712529=some row_109 := by
  have ck_0_13_0 : (Block.mk 994009 1018080 1009 1013 1019 993821 993983 993997).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1009 LCMSourcePV.PrimeFacts.prime_1013 LCMSourcePV.PrimeFacts.prime_1019 LCMSourcePV.PrimeFacts.prime_993821 LCMSourcePV.PrimeFacts.prime_993983 LCMSourcePV.PrimeFacts.prime_993997
  have sh_0_13_0 : shrink 30 (Block.mk 994009 1018080 1009 1013 1019 993821 993983 993997)=some row_109 := shrink_hit _ _ ck_0_13_0
  have c0_0_13 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 19 993822=some row_109 :=
    choose0_hit 1000 30 994009 10712529 1009 1013 1019 993983 993997 18 993822 993821 row_109 (SearchFacts.query_1124 LCMSourcePV.PrimeFacts.prime_993821) (by decide) sh_0_13_0
  have c0_0_12 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 20 993826=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 19 993826 993823 (some row_109) (SearchFacts.query_1125 LCMSourcePV.PrimeFacts.prime_993823) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 21 993840=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 20 993840 993827 (some row_109) (SearchFacts.query_1126 LCMSourcePV.PrimeFacts.prime_993827) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 22 993850=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 21 993850 993841 (some row_109) (SearchFacts.query_1127 LCMSourcePV.PrimeFacts.prime_993841) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 23 993868=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 22 993868 993851 (some row_109) (SearchFacts.query_1128 LCMSourcePV.PrimeFacts.prime_993851) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 24 993886=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 23 993886 993869 (some row_109) (SearchFacts.query_1129 LCMSourcePV.PrimeFacts.prime_993869) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 25 993892=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 24 993892 993887 (some row_109) (SearchFacts.query_1130 LCMSourcePV.PrimeFacts.prime_993887) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 26 993906=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 25 993906 993893 (some row_109) (SearchFacts.query_1131 LCMSourcePV.PrimeFacts.prime_993893) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 27 993912=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 26 993912 993907 (some row_109) (SearchFacts.query_1132 LCMSourcePV.PrimeFacts.prime_993907) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 28 993918=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 27 993918 993913 (some row_109) (SearchFacts.query_1133 LCMSourcePV.PrimeFacts.prime_993913) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 29 993942=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 28 993942 993919 (some row_109) (SearchFacts.query_1134 LCMSourcePV.PrimeFacts.prime_993919) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 30 993960=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 29 993960 993943 (some row_109) (SearchFacts.query_1135 LCMSourcePV.PrimeFacts.prime_993943) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 31 993976=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 30 993976 993961 (some row_109) (SearchFacts.query_1136 LCMSourcePV.PrimeFacts.prime_993961) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 994009 10712529 1009 1013 1019 993983 993997 32 993982=(some row_109) :=
    choose0_skip 1000 30 994009 10712529 1009 1013 1019 993983 993997 31 993982 993977 (some row_109) (SearchFacts.query_1137 LCMSourcePV.PrimeFacts.prime_993977) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 994009 10712529 1009 1013 1019 993997 16 993996=some row_109 :=
    choose1_hit 1000 30 32 994009 10712529 1009 1013 1019 993997 15 993996 993983 row_109 (SearchFacts.query_1138 LCMSourcePV.PrimeFacts.prime_993983) c0_0_0
  have hsqrt : Nat.sqrt 994009=997 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 994009+1)=some 1009 := by
    rw [hsqrt];exact (SearchFacts.query_4230 LCMSourcePV.PrimeFacts.prime_1009)
  exact make_hit 1000 30 32 16 994009 10712529 1009 1013 1019 993997 row_109 h0 (SearchFacts.query_4231 LCMSourcePV.PrimeFacts.prime_1013) (SearchFacts.query_4232 LCMSourcePV.PrimeFacts.prime_1019) (SearchFacts.query_1139 LCMSourcePV.PrimeFacts.prime_993997) c1_0
#print axioms make_109
end LCMSourcePV.Witness.BlockProofs
