/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_249 : Block := (Block.mk 4116841 4157520 2039 2053 2063 4116781 4116817 4116823)
theorem make_249 : make 1000 30 32 16 4116841 10712529=some row_249 := by
  have ck_0_0_0 : (Block.mk 4116841 4157520 2039 2053 2063 4116781 4116817 4116823).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2039 LCMSourcePV.PrimeFacts.prime_2053 LCMSourcePV.PrimeFacts.prime_2063 LCMSourcePV.PrimeFacts.prime_4116781 LCMSourcePV.PrimeFacts.prime_4116817 LCMSourcePV.PrimeFacts.prime_4116823
  have sh_0_0_0 : shrink 30 (Block.mk 4116841 4157520 2039 2053 2063 4116781 4116817 4116823)=some row_249 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 4116841 10712529 2039 2053 2063 4116817 4116823 32 4116816=some row_249 :=
    choose0_hit 1000 30 4116841 10712529 2039 2053 2063 4116817 4116823 31 4116816 4116781 row_249 (SearchFacts.query_2562 LCMSourcePV.PrimeFacts.prime_4116781) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 4116841 10712529 2039 2053 2063 4116823 16 4116822=some row_249 :=
    choose1_hit 1000 30 32 4116841 10712529 2039 2053 2063 4116823 15 4116822 4116817 row_249 (SearchFacts.query_2563 LCMSourcePV.PrimeFacts.prime_4116817) c0_0_0
  have hsqrt : Nat.sqrt 4116841=2029 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4116841+1)=some 2039 := by
    rw [hsqrt];exact (SearchFacts.query_4370 LCMSourcePV.PrimeFacts.prime_2039)
  exact make_hit 1000 30 32 16 4116841 10712529 2039 2053 2063 4116823 row_249 h0 (SearchFacts.query_4371 LCMSourcePV.PrimeFacts.prime_2053) (SearchFacts.query_4372 LCMSourcePV.PrimeFacts.prime_2063) (SearchFacts.query_2564 LCMSourcePV.PrimeFacts.prime_4116823) c1_0
#print axioms make_249
end LCMSourcePV.Witness.BlockProofs
