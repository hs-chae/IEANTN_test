/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_129 : Block := (Block.mk 1261129 1274640 1129 1151 1153 1261033 1261109 1261121)
theorem make_129 : make 1000 30 32 16 1261129 10712529=some row_129 := by
  have ck_0_3_0 : (Block.mk 1261129 1274640 1129 1151 1153 1261033 1261109 1261121).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1129 LCMSourcePV.PrimeFacts.prime_1151 LCMSourcePV.PrimeFacts.prime_1153 LCMSourcePV.PrimeFacts.prime_1261033 LCMSourcePV.PrimeFacts.prime_1261109 LCMSourcePV.PrimeFacts.prime_1261121
  have sh_0_3_0 : shrink 30 (Block.mk 1261129 1274640 1129 1151 1153 1261033 1261109 1261121)=some row_129 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 1261129 10712529 1129 1151 1153 1261109 1261121 29 1261068=some row_129 :=
    choose0_hit 1000 30 1261129 10712529 1129 1151 1153 1261109 1261121 28 1261068 1261033 row_129 (SearchFacts.query_1396 LCMSourcePV.PrimeFacts.prime_1261033) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 1261129 10712529 1129 1151 1153 1261109 1261121 30 1261078=(some row_129) :=
    choose0_skip 1000 30 1261129 10712529 1129 1151 1153 1261109 1261121 29 1261078 1261069 (some row_129) (SearchFacts.query_1397 LCMSourcePV.PrimeFacts.prime_1261069) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1261129 10712529 1129 1151 1153 1261109 1261121 31 1261080=(some row_129) :=
    choose0_skip 1000 30 1261129 10712529 1129 1151 1153 1261109 1261121 30 1261080 1261079 (some row_129) (SearchFacts.query_1398 LCMSourcePV.PrimeFacts.prime_1261079) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1261129 10712529 1129 1151 1153 1261109 1261121 32 1261108=(some row_129) :=
    choose0_skip 1000 30 1261129 10712529 1129 1151 1153 1261109 1261121 31 1261108 1261081 (some row_129) (SearchFacts.query_1399 LCMSourcePV.PrimeFacts.prime_1261081) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1261129 10712529 1129 1151 1153 1261121 16 1261120=some row_129 :=
    choose1_hit 1000 30 32 1261129 10712529 1129 1151 1153 1261121 15 1261120 1261109 row_129 (SearchFacts.query_1400 LCMSourcePV.PrimeFacts.prime_1261109) c0_0_0
  have hsqrt : Nat.sqrt 1261129=1123 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1261129+1)=some 1129 := by
    rw [hsqrt];exact (SearchFacts.query_4250 LCMSourcePV.PrimeFacts.prime_1129)
  exact make_hit 1000 30 32 16 1261129 10712529 1129 1151 1153 1261121 row_129 h0 (SearchFacts.query_4251 LCMSourcePV.PrimeFacts.prime_1151) (SearchFacts.query_4252 LCMSourcePV.PrimeFacts.prime_1153) (SearchFacts.query_1401 LCMSourcePV.PrimeFacts.prime_1261121) c1_0
#print axioms make_129
end LCMSourcePV.Witness.BlockProofs
