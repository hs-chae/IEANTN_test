/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_295 : Block := (Block.mk 5678689 5707320 2389 2393 2399 5678423 5678641 5678669)
theorem make_295 : make 1000 30 32 16 5678689 10712529=some row_295 := by
  have ck_0_11_0 : (Block.mk 5678689 5707320 2389 2393 2399 5678423 5678641 5678669).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2389 LCMSourcePV.PrimeFacts.prime_2393 LCMSourcePV.PrimeFacts.prime_2399 LCMSourcePV.PrimeFacts.prime_5678423 LCMSourcePV.PrimeFacts.prime_5678641 LCMSourcePV.PrimeFacts.prime_5678669
  have sh_0_11_0 : shrink 30 (Block.mk 5678689 5707320 2389 2393 2399 5678423 5678641 5678669)=some row_295 := shrink_hit _ _ ck_0_11_0
  have c0_0_11 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 21 5678436=some row_295 :=
    choose0_hit 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 20 5678436 5678423 row_295 (SearchFacts.query_2980 LCMSourcePV.PrimeFacts.prime_5678423) (by decide) sh_0_11_0
  have c0_0_10 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 22 5678470=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 21 5678470 5678437 (some row_295) (SearchFacts.query_2981 LCMSourcePV.PrimeFacts.prime_5678437) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 23 5678482=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 22 5678482 5678471 (some row_295) (SearchFacts.query_2982 LCMSourcePV.PrimeFacts.prime_5678471) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 24 5678488=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 23 5678488 5678483 (some row_295) (SearchFacts.query_2983 LCMSourcePV.PrimeFacts.prime_5678483) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 25 5678506=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 24 5678506 5678489 (some row_295) (SearchFacts.query_2984 LCMSourcePV.PrimeFacts.prime_5678489) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 26 5678520=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 25 5678520 5678507 (some row_295) (SearchFacts.query_2985 LCMSourcePV.PrimeFacts.prime_5678507) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 27 5678530=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 26 5678530 5678521 (some row_295) (SearchFacts.query_2986 LCMSourcePV.PrimeFacts.prime_5678521) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 28 5678580=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 27 5678580 5678531 (some row_295) (SearchFacts.query_2987 LCMSourcePV.PrimeFacts.prime_5678531) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 29 5678592=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 28 5678592 5678581 (some row_295) (SearchFacts.query_2988 LCMSourcePV.PrimeFacts.prime_5678581) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 30 5678608=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 29 5678608 5678593 (some row_295) (SearchFacts.query_2989 LCMSourcePV.PrimeFacts.prime_5678593) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 31 5678626=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 30 5678626 5678609 (some row_295) (SearchFacts.query_2990 LCMSourcePV.PrimeFacts.prime_5678609) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 32 5678640=(some row_295) :=
    choose0_skip 1000 30 5678689 10712529 2389 2393 2399 5678641 5678669 31 5678640 5678627 (some row_295) (SearchFacts.query_2991 LCMSourcePV.PrimeFacts.prime_5678627) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5678689 10712529 2389 2393 2399 5678669 16 5678668=some row_295 :=
    choose1_hit 1000 30 32 5678689 10712529 2389 2393 2399 5678669 15 5678668 5678641 row_295 (SearchFacts.query_2992 LCMSourcePV.PrimeFacts.prime_5678641) c0_0_0
  have hsqrt : Nat.sqrt 5678689=2383 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5678689+1)=some 2389 := by
    rw [hsqrt];exact (SearchFacts.query_4416 LCMSourcePV.PrimeFacts.prime_2389)
  exact make_hit 1000 30 32 16 5678689 10712529 2389 2393 2399 5678669 row_295 h0 (SearchFacts.query_4417 LCMSourcePV.PrimeFacts.prime_2393) (SearchFacts.query_4418 LCMSourcePV.PrimeFacts.prime_2399) (SearchFacts.query_2993 LCMSourcePV.PrimeFacts.prime_5678669) c1_0
#print axioms make_295
end LCMSourcePV.Witness.BlockProofs
