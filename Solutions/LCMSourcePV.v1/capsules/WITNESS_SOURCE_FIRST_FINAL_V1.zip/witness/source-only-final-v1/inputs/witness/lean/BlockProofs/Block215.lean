/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_215 : Block := (Block.mk 3094081 3157728 1777 1783 1787 3094061 3094067 3094073)
theorem make_215 : make 1000 30 32 16 3094081 10712529=some row_215 := by
  have ck_0_0_0 : (Block.mk 3094081 3157728 1777 1783 1787 3094061 3094067 3094073).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1777 LCMSourcePV.PrimeFacts.prime_1783 LCMSourcePV.PrimeFacts.prime_1787 LCMSourcePV.PrimeFacts.prime_3094061 LCMSourcePV.PrimeFacts.prime_3094067 LCMSourcePV.PrimeFacts.prime_3094073
  have sh_0_0_0 : shrink 30 (Block.mk 3094081 3157728 1777 1783 1787 3094061 3094067 3094073)=some row_215 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 3094081 10712529 1777 1783 1787 3094067 3094073 32 3094066=some row_215 :=
    choose0_hit 1000 30 3094081 10712529 1777 1783 1787 3094067 3094073 31 3094066 3094061 row_215 (SearchFacts.query_2241 LCMSourcePV.PrimeFacts.prime_3094061) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 3094081 10712529 1777 1783 1787 3094073 16 3094072=some row_215 :=
    choose1_hit 1000 30 32 3094081 10712529 1777 1783 1787 3094073 15 3094072 3094067 row_215 (SearchFacts.query_2242 LCMSourcePV.PrimeFacts.prime_3094067) c0_0_0
  have hsqrt : Nat.sqrt 3094081=1759 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3094081+1)=some 1777 := by
    rw [hsqrt];exact (SearchFacts.query_4336 LCMSourcePV.PrimeFacts.prime_1777)
  exact make_hit 1000 30 32 16 3094081 10712529 1777 1783 1787 3094073 row_215 h0 (SearchFacts.query_4337 LCMSourcePV.PrimeFacts.prime_1783) (SearchFacts.query_4338 LCMSourcePV.PrimeFacts.prime_1787) (SearchFacts.query_2243 LCMSourcePV.PrimeFacts.prime_3094073) c1_0
#print axioms make_215
end LCMSourcePV.Witness.BlockProofs
