/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_221 : Block := (Block.mk 3279721 3323328 1823 1831 1847 3279607 3279677 3279709)
theorem make_221 : make 1000 30 32 16 3279721 10712529=some row_221 := by
  have ck_0_2_0 : (Block.mk 3279721 3323328 1823 1831 1847 3279607 3279677 3279709).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1823 LCMSourcePV.PrimeFacts.prime_1831 LCMSourcePV.PrimeFacts.prime_1847 LCMSourcePV.PrimeFacts.prime_3279607 LCMSourcePV.PrimeFacts.prime_3279677 LCMSourcePV.PrimeFacts.prime_3279709
  have sh_0_2_0 : shrink 30 (Block.mk 3279721 3323328 1823 1831 1847 3279607 3279677 3279709)=some row_221 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 3279721 10712529 1823 1831 1847 3279677 3279709 30 3279640=some row_221 :=
    choose0_hit 1000 30 3279721 10712529 1823 1831 1847 3279677 3279709 29 3279640 3279607 row_221 (SearchFacts.query_2299 LCMSourcePV.PrimeFacts.prime_3279607) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 3279721 10712529 1823 1831 1847 3279677 3279709 31 3279672=(some row_221) :=
    choose0_skip 1000 30 3279721 10712529 1823 1831 1847 3279677 3279709 30 3279672 3279641 (some row_221) (SearchFacts.query_2300 LCMSourcePV.PrimeFacts.prime_3279641) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3279721 10712529 1823 1831 1847 3279677 3279709 32 3279676=(some row_221) :=
    choose0_skip 1000 30 3279721 10712529 1823 1831 1847 3279677 3279709 31 3279676 3279673 (some row_221) (SearchFacts.query_2301 LCMSourcePV.PrimeFacts.prime_3279673) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3279721 10712529 1823 1831 1847 3279709 16 3279708=some row_221 :=
    choose1_hit 1000 30 32 3279721 10712529 1823 1831 1847 3279709 15 3279708 3279677 row_221 (SearchFacts.query_2302 LCMSourcePV.PrimeFacts.prime_3279677) c0_0_0
  have hsqrt : Nat.sqrt 3279721=1811 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3279721+1)=some 1823 := by
    rw [hsqrt];exact (SearchFacts.query_4342 LCMSourcePV.PrimeFacts.prime_1823)
  exact make_hit 1000 30 32 16 3279721 10712529 1823 1831 1847 3279709 row_221 h0 (SearchFacts.query_4343 LCMSourcePV.PrimeFacts.prime_1831) (SearchFacts.query_4344 LCMSourcePV.PrimeFacts.prime_1847) (SearchFacts.query_2303 LCMSourcePV.PrimeFacts.prime_3279709) c1_0
#print axioms make_221
end LCMSourcePV.Witness.BlockProofs
