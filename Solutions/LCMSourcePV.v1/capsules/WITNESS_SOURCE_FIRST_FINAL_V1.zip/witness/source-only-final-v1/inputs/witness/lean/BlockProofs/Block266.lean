/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_266 : Block := (Block.mk 4635409 4669920 2161 2179 2203 4635343 4635391 4635403)
theorem make_266 : make 1000 30 32 16 4635409 10712529=some row_266 := by
  have ck_0_4_0 : (Block.mk 4635409 4669920 2161 2179 2203 4635343 4635391 4635403).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2161 LCMSourcePV.PrimeFacts.prime_2179 LCMSourcePV.PrimeFacts.prime_2203 LCMSourcePV.PrimeFacts.prime_4635343 LCMSourcePV.PrimeFacts.prime_4635391 LCMSourcePV.PrimeFacts.prime_4635403
  have sh_0_4_0 : shrink 30 (Block.mk 4635409 4669920 2161 2179 2203 4635343 4635391 4635403)=some row_266 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 28 4635352=some row_266 :=
    choose0_hit 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 27 4635352 4635343 row_266 (SearchFacts.query_2686 LCMSourcePV.PrimeFacts.prime_4635343) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 29 4635358=(some row_266) :=
    choose0_skip 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 28 4635358 4635353 (some row_266) (SearchFacts.query_2687 LCMSourcePV.PrimeFacts.prime_4635353) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 30 4635360=(some row_266) :=
    choose0_skip 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 29 4635360 4635359 (some row_266) (SearchFacts.query_2688 LCMSourcePV.PrimeFacts.prime_4635359) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 31 4635382=(some row_266) :=
    choose0_skip 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 30 4635382 4635361 (some row_266) (SearchFacts.query_2689 LCMSourcePV.PrimeFacts.prime_4635361) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 32 4635390=(some row_266) :=
    choose0_skip 1000 30 4635409 10712529 2161 2179 2203 4635391 4635403 31 4635390 4635383 (some row_266) (SearchFacts.query_2690 LCMSourcePV.PrimeFacts.prime_4635383) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4635409 10712529 2161 2179 2203 4635403 16 4635402=some row_266 :=
    choose1_hit 1000 30 32 4635409 10712529 2161 2179 2203 4635403 15 4635402 4635391 row_266 (SearchFacts.query_2691 LCMSourcePV.PrimeFacts.prime_4635391) c0_0_0
  have hsqrt : Nat.sqrt 4635409=2153 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4635409+1)=some 2161 := by
    rw [hsqrt];exact (SearchFacts.query_4387 LCMSourcePV.PrimeFacts.prime_2161)
  exact make_hit 1000 30 32 16 4635409 10712529 2161 2179 2203 4635403 row_266 h0 (SearchFacts.query_4388 LCMSourcePV.PrimeFacts.prime_2179) (SearchFacts.query_4389 LCMSourcePV.PrimeFacts.prime_2203) (SearchFacts.query_2692 LCMSourcePV.PrimeFacts.prime_4635403) c1_0
#print axioms make_266
end LCMSourcePV.Witness.BlockProofs
