/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_219 : Block := (Block.mk 3200521 3243600 1801 1811 1823 3200209 3200479 3200507)
theorem make_219 : make 1000 30 32 16 3200521 10712529=some row_219 := by
  have ck_0_22_0 : (Block.mk 3200521 3243600 1801 1811 1823 3200209 3200479 3200507).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1801 LCMSourcePV.PrimeFacts.prime_1811 LCMSourcePV.PrimeFacts.prime_1823 LCMSourcePV.PrimeFacts.prime_3200209 LCMSourcePV.PrimeFacts.prime_3200479 LCMSourcePV.PrimeFacts.prime_3200507
  have sh_0_22_0 : shrink 30 (Block.mk 3200521 3243600 1801 1811 1823 3200209 3200479 3200507)=some row_219 := shrink_hit _ _ ck_0_22_0
  have c0_0_22 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 10 3200212=some row_219 :=
    choose0_hit 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 9 3200212 3200209 row_219 (SearchFacts.query_2269 LCMSourcePV.PrimeFacts.prime_3200209) (by decide) sh_0_22_0
  have c0_0_21 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 11 3200250=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 10 3200250 3200213 (some row_219) (SearchFacts.query_2270 LCMSourcePV.PrimeFacts.prime_3200213) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 12 3200256=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 11 3200256 3200251 (some row_219) (SearchFacts.query_2271 LCMSourcePV.PrimeFacts.prime_3200251) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 13 3200278=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 12 3200278 3200257 (some row_219) (SearchFacts.query_2272 LCMSourcePV.PrimeFacts.prime_3200257) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 14 3200286=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 13 3200286 3200279 (some row_219) (SearchFacts.query_2273 LCMSourcePV.PrimeFacts.prime_3200279) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 15 3200290=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 14 3200290 3200287 (some row_219) (SearchFacts.query_2274 LCMSourcePV.PrimeFacts.prime_3200287) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 16 3200296=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 15 3200296 3200291 (some row_219) (SearchFacts.query_2275 LCMSourcePV.PrimeFacts.prime_3200291) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 17 3200310=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 16 3200310 3200297 (some row_219) (SearchFacts.query_2276 LCMSourcePV.PrimeFacts.prime_3200297) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 18 3200316=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 17 3200316 3200311 (some row_219) (SearchFacts.query_2277 LCMSourcePV.PrimeFacts.prime_3200311) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 19 3200332=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 18 3200332 3200317 (some row_219) (SearchFacts.query_2278 LCMSourcePV.PrimeFacts.prime_3200317) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 20 3200338=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 19 3200338 3200333 (some row_219) (SearchFacts.query_2279 LCMSourcePV.PrimeFacts.prime_3200333) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 21 3200356=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 20 3200356 3200339 (some row_219) (SearchFacts.query_2280 LCMSourcePV.PrimeFacts.prime_3200339) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 22 3200358=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 21 3200358 3200357 (some row_219) (SearchFacts.query_2281 LCMSourcePV.PrimeFacts.prime_3200357) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 23 3200362=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 22 3200362 3200359 (some row_219) (SearchFacts.query_2282 LCMSourcePV.PrimeFacts.prime_3200359) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 24 3200382=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 23 3200382 3200363 (some row_219) (SearchFacts.query_2283 LCMSourcePV.PrimeFacts.prime_3200363) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 25 3200400=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 24 3200400 3200383 (some row_219) (SearchFacts.query_2284 LCMSourcePV.PrimeFacts.prime_3200383) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 26 3200412=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 25 3200412 3200401 (some row_219) (SearchFacts.query_2285 LCMSourcePV.PrimeFacts.prime_3200401) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 27 3200422=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 26 3200422 3200413 (some row_219) (SearchFacts.query_2286 LCMSourcePV.PrimeFacts.prime_3200413) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 28 3200428=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 27 3200428 3200423 (some row_219) (SearchFacts.query_2287 LCMSourcePV.PrimeFacts.prime_3200423) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 29 3200442=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 28 3200442 3200429 (some row_219) (SearchFacts.query_2288 LCMSourcePV.PrimeFacts.prime_3200429) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 30 3200452=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 29 3200452 3200443 (some row_219) (SearchFacts.query_2289 LCMSourcePV.PrimeFacts.prime_3200443) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 31 3200458=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 30 3200458 3200453 (some row_219) (SearchFacts.query_2290 LCMSourcePV.PrimeFacts.prime_3200453) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 32 3200478=(some row_219) :=
    choose0_skip 1000 30 3200521 10712529 1801 1811 1823 3200479 3200507 31 3200478 3200459 (some row_219) (SearchFacts.query_2291 LCMSourcePV.PrimeFacts.prime_3200459) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3200521 10712529 1801 1811 1823 3200507 16 3200506=some row_219 :=
    choose1_hit 1000 30 32 3200521 10712529 1801 1811 1823 3200507 15 3200506 3200479 row_219 (SearchFacts.query_2292 LCMSourcePV.PrimeFacts.prime_3200479) c0_0_0
  have hsqrt : Nat.sqrt 3200521=1789 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3200521+1)=some 1801 := by
    rw [hsqrt];exact (SearchFacts.query_4340 LCMSourcePV.PrimeFacts.prime_1801)
  exact make_hit 1000 30 32 16 3200521 10712529 1801 1811 1823 3200507 row_219 h0 (SearchFacts.query_4341 LCMSourcePV.PrimeFacts.prime_1811) (SearchFacts.query_4342 LCMSourcePV.PrimeFacts.prime_1823) (SearchFacts.query_2293 LCMSourcePV.PrimeFacts.prime_3200507) c1_0
#print axioms make_219
end LCMSourcePV.Witness.BlockProofs
