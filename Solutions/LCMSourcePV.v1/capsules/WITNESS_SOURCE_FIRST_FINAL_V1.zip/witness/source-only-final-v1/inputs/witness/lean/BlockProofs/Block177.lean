/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_177 : Block := (Block.mk 2211169 2217120 1489 1493 1499 2211061 2211127 2211161)
theorem make_177 : make 1000 30 32 16 2211169 10712529=some row_177 := by
  have ck_0_1_0 : (Block.mk 2211169 2217120 1489 1493 1499 2211061 2211127 2211161).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1489 LCMSourcePV.PrimeFacts.prime_1493 LCMSourcePV.PrimeFacts.prime_1499 LCMSourcePV.PrimeFacts.prime_2211061 LCMSourcePV.PrimeFacts.prime_2211127 LCMSourcePV.PrimeFacts.prime_2211161
  have sh_0_1_0 : shrink 30 (Block.mk 2211169 2217120 1489 1493 1499 2211061 2211127 2211161)=some row_177 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 2211169 10712529 1489 1493 1499 2211127 2211161 31 2211108=some row_177 :=
    choose0_hit 1000 30 2211169 10712529 1489 1493 1499 2211127 2211161 30 2211108 2211061 row_177 (SearchFacts.query_1795 LCMSourcePV.PrimeFacts.prime_2211061) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 2211169 10712529 1489 1493 1499 2211127 2211161 32 2211126=(some row_177) :=
    choose0_skip 1000 30 2211169 10712529 1489 1493 1499 2211127 2211161 31 2211126 2211109 (some row_177) (SearchFacts.query_1796 LCMSourcePV.PrimeFacts.prime_2211109) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2211169 10712529 1489 1493 1499 2211161 16 2211160=some row_177 :=
    choose1_hit 1000 30 32 2211169 10712529 1489 1493 1499 2211161 15 2211160 2211127 row_177 (SearchFacts.query_1797 LCMSourcePV.PrimeFacts.prime_2211127) c0_0_0
  have hsqrt : Nat.sqrt 2211169=1487 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2211169+1)=some 1489 := by
    rw [hsqrt];exact (SearchFacts.query_4298 LCMSourcePV.PrimeFacts.prime_1489)
  exact make_hit 1000 30 32 16 2211169 10712529 1489 1493 1499 2211161 row_177 h0 (SearchFacts.query_4299 LCMSourcePV.PrimeFacts.prime_1493) (SearchFacts.query_4300 LCMSourcePV.PrimeFacts.prime_1499) (SearchFacts.query_1798 LCMSourcePV.PrimeFacts.prime_2211161) c1_0
#print axioms make_177
end LCMSourcePV.Witness.BlockProofs
