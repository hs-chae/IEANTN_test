/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_298 : Block := (Block.mk 5755201 5812920 2411 2417 2423 5755153 5755171 5755187)
theorem make_298 : make 1000 30 32 16 5755201 10712529=some row_298 := by
  have ck_0_1_0 : (Block.mk 5755201 5812920 2411 2417 2423 5755153 5755171 5755187).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2411 LCMSourcePV.PrimeFacts.prime_2417 LCMSourcePV.PrimeFacts.prime_2423 LCMSourcePV.PrimeFacts.prime_5755153 LCMSourcePV.PrimeFacts.prime_5755171 LCMSourcePV.PrimeFacts.prime_5755187
  have sh_0_1_0 : shrink 30 (Block.mk 5755201 5812920 2411 2417 2423 5755153 5755171 5755187)=some row_298 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 5755201 10712529 2411 2417 2423 5755171 5755187 31 5755158=some row_298 :=
    choose0_hit 1000 30 5755201 10712529 2411 2417 2423 5755171 5755187 30 5755158 5755153 row_298 (SearchFacts.query_3006 LCMSourcePV.PrimeFacts.prime_5755153) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 5755201 10712529 2411 2417 2423 5755171 5755187 32 5755170=(some row_298) :=
    choose0_skip 1000 30 5755201 10712529 2411 2417 2423 5755171 5755187 31 5755170 5755159 (some row_298) (SearchFacts.query_3007 LCMSourcePV.PrimeFacts.prime_5755159) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5755201 10712529 2411 2417 2423 5755187 16 5755186=some row_298 :=
    choose1_hit 1000 30 32 5755201 10712529 2411 2417 2423 5755187 15 5755186 5755171 row_298 (SearchFacts.query_3008 LCMSourcePV.PrimeFacts.prime_5755171) c0_0_0
  have hsqrt : Nat.sqrt 5755201=2399 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5755201+1)=some 2411 := by
    rw [hsqrt];exact (SearchFacts.query_4419 LCMSourcePV.PrimeFacts.prime_2411)
  exact make_hit 1000 30 32 16 5755201 10712529 2411 2417 2423 5755187 row_298 h0 (SearchFacts.query_4420 LCMSourcePV.PrimeFacts.prime_2417) (SearchFacts.query_4421 LCMSourcePV.PrimeFacts.prime_2423) (SearchFacts.query_3009 LCMSourcePV.PrimeFacts.prime_5755187) c1_0
#print axioms make_298
end LCMSourcePV.Witness.BlockProofs
