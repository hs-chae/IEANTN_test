/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_178 : Block := (Block.mk 2217121 2229048 1493 1499 1511 2217049 2217107 2217113)
theorem make_178 : make 1000 30 32 16 2217121 10712529=some row_178 := by
  have ck_0_3_0 : (Block.mk 2217121 2229048 1493 1499 1511 2217049 2217107 2217113).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1493 LCMSourcePV.PrimeFacts.prime_1499 LCMSourcePV.PrimeFacts.prime_1511 LCMSourcePV.PrimeFacts.prime_2217049 LCMSourcePV.PrimeFacts.prime_2217107 LCMSourcePV.PrimeFacts.prime_2217113
  have sh_0_3_0 : shrink 30 (Block.mk 2217121 2229048 1493 1499 1511 2217049 2217107 2217113)=some row_178 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 2217121 10712529 1493 1499 1511 2217107 2217113 29 2217066=some row_178 :=
    choose0_hit 1000 30 2217121 10712529 1493 1499 1511 2217107 2217113 28 2217066 2217049 row_178 (SearchFacts.query_1799 LCMSourcePV.PrimeFacts.prime_2217049) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 2217121 10712529 1493 1499 1511 2217107 2217113 30 2217072=(some row_178) :=
    choose0_skip 1000 30 2217121 10712529 1493 1499 1511 2217107 2217113 29 2217072 2217067 (some row_178) (SearchFacts.query_1800 LCMSourcePV.PrimeFacts.prime_2217067) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2217121 10712529 1493 1499 1511 2217107 2217113 31 2217100=(some row_178) :=
    choose0_skip 1000 30 2217121 10712529 1493 1499 1511 2217107 2217113 30 2217100 2217073 (some row_178) (SearchFacts.query_1801 LCMSourcePV.PrimeFacts.prime_2217073) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2217121 10712529 1493 1499 1511 2217107 2217113 32 2217106=(some row_178) :=
    choose0_skip 1000 30 2217121 10712529 1493 1499 1511 2217107 2217113 31 2217106 2217101 (some row_178) (SearchFacts.query_1802 LCMSourcePV.PrimeFacts.prime_2217101) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2217121 10712529 1493 1499 1511 2217113 16 2217112=some row_178 :=
    choose1_hit 1000 30 32 2217121 10712529 1493 1499 1511 2217113 15 2217112 2217107 row_178 (SearchFacts.query_1803 LCMSourcePV.PrimeFacts.prime_2217107) c0_0_0
  have hsqrt : Nat.sqrt 2217121=1489 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2217121+1)=some 1493 := by
    rw [hsqrt];exact (SearchFacts.query_4299 LCMSourcePV.PrimeFacts.prime_1493)
  exact make_hit 1000 30 32 16 2217121 10712529 1493 1499 1511 2217113 row_178 h0 (SearchFacts.query_4300 LCMSourcePV.PrimeFacts.prime_1499) (SearchFacts.query_4301 LCMSourcePV.PrimeFacts.prime_1511) (SearchFacts.query_1804 LCMSourcePV.PrimeFacts.prime_2217113) c1_0
#print axioms make_178
end LCMSourcePV.Witness.BlockProofs
