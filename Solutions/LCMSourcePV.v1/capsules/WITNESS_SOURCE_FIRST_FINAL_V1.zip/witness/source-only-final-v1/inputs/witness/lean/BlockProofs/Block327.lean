/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_327 : Block := (Block.mk 7091569 7134240 2671 2677 2683 7091317 7091543 7091549)
theorem make_327 : make 1000 30 32 16 7091569 10712529=some row_327 := by
  have ck_0_16_0 : (Block.mk 7091569 7134240 2671 2677 2683 7091317 7091543 7091549).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2671 LCMSourcePV.PrimeFacts.prime_2677 LCMSourcePV.PrimeFacts.prime_2683 LCMSourcePV.PrimeFacts.prime_7091317 LCMSourcePV.PrimeFacts.prime_7091543 LCMSourcePV.PrimeFacts.prime_7091549
  have sh_0_16_0 : shrink 30 (Block.mk 7091569 7134240 2671 2677 2683 7091317 7091543 7091549)=some row_327 := shrink_hit _ _ ck_0_16_0
  have c0_0_16 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 16 7091322=some row_327 :=
    choose0_hit 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 15 7091322 7091317 row_327 (SearchFacts.query_3337 LCMSourcePV.PrimeFacts.prime_7091317) (by decide) sh_0_16_0
  have c0_0_15 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 17 7091332=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 16 7091332 7091323 (some row_327) (SearchFacts.query_3338 LCMSourcePV.PrimeFacts.prime_7091323) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 18 7091338=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 17 7091338 7091333 (some row_327) (SearchFacts.query_3339 LCMSourcePV.PrimeFacts.prime_7091333) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 19 7091352=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 18 7091352 7091339 (some row_327) (SearchFacts.query_3340 LCMSourcePV.PrimeFacts.prime_7091339) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 20 7091376=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 19 7091376 7091353 (some row_327) (SearchFacts.query_3341 LCMSourcePV.PrimeFacts.prime_7091353) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 21 7091410=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 20 7091410 7091377 (some row_327) (SearchFacts.query_3342 LCMSourcePV.PrimeFacts.prime_7091377) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 22 7091418=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 21 7091418 7091411 (some row_327) (SearchFacts.query_3343 LCMSourcePV.PrimeFacts.prime_7091411) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 23 7091448=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 22 7091448 7091419 (some row_327) (SearchFacts.query_3344 LCMSourcePV.PrimeFacts.prime_7091419) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 24 7091470=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 23 7091470 7091449 (some row_327) (SearchFacts.query_3345 LCMSourcePV.PrimeFacts.prime_7091449) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 25 7091472=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 24 7091472 7091471 (some row_327) (SearchFacts.query_3346 LCMSourcePV.PrimeFacts.prime_7091471) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 26 7091488=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 25 7091488 7091473 (some row_327) (SearchFacts.query_3347 LCMSourcePV.PrimeFacts.prime_7091473) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 27 7091506=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 26 7091506 7091489 (some row_327) (SearchFacts.query_3348 LCMSourcePV.PrimeFacts.prime_7091489) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 28 7091508=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 27 7091508 7091507 (some row_327) (SearchFacts.query_3349 LCMSourcePV.PrimeFacts.prime_7091507) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 29 7091518=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 28 7091518 7091509 (some row_327) (SearchFacts.query_3350 LCMSourcePV.PrimeFacts.prime_7091509) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 30 7091526=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 29 7091526 7091519 (some row_327) (SearchFacts.query_3351 LCMSourcePV.PrimeFacts.prime_7091519) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 31 7091536=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 30 7091536 7091527 (some row_327) (SearchFacts.query_3352 LCMSourcePV.PrimeFacts.prime_7091527) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 32 7091542=(some row_327) :=
    choose0_skip 1000 30 7091569 10712529 2671 2677 2683 7091543 7091549 31 7091542 7091537 (some row_327) (SearchFacts.query_3353 LCMSourcePV.PrimeFacts.prime_7091537) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 7091569 10712529 2671 2677 2683 7091549 16 7091548=some row_327 :=
    choose1_hit 1000 30 32 7091569 10712529 2671 2677 2683 7091549 15 7091548 7091543 row_327 (SearchFacts.query_3354 LCMSourcePV.PrimeFacts.prime_7091543) c0_0_0
  have hsqrt : Nat.sqrt 7091569=2663 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 7091569+1)=some 2671 := by
    rw [hsqrt];exact (SearchFacts.query_4448 LCMSourcePV.PrimeFacts.prime_2671)
  exact make_hit 1000 30 32 16 7091569 10712529 2671 2677 2683 7091549 row_327 h0 (SearchFacts.query_4449 LCMSourcePV.PrimeFacts.prime_2677) (SearchFacts.query_4450 LCMSourcePV.PrimeFacts.prime_2683) (SearchFacts.query_3355 LCMSourcePV.PrimeFacts.prime_7091549) c1_0
#print axioms make_327
end LCMSourcePV.Witness.BlockProofs
