/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_238 : Block := (Block.mk 3806401 3892728 1973 1979 1987 3806321 3806333 3806347)
theorem make_238 : make 1000 30 32 16 3806401 10712529=some row_238 := by
  have ck_0_0_0 : (Block.mk 3806401 3892728 1973 1979 1987 3806321 3806333 3806347).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1973 LCMSourcePV.PrimeFacts.prime_1979 LCMSourcePV.PrimeFacts.prime_1987 LCMSourcePV.PrimeFacts.prime_3806321 LCMSourcePV.PrimeFacts.prime_3806333 LCMSourcePV.PrimeFacts.prime_3806347
  have sh_0_0_0 : shrink 30 (Block.mk 3806401 3892728 1973 1979 1987 3806321 3806333 3806347)=some row_238 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 3806401 10712529 1973 1979 1987 3806333 3806347 32 3806332=some row_238 :=
    choose0_hit 1000 30 3806401 10712529 1973 1979 1987 3806333 3806347 31 3806332 3806321 row_238 (SearchFacts.query_2432 LCMSourcePV.PrimeFacts.prime_3806321) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 3806401 10712529 1973 1979 1987 3806347 16 3806346=some row_238 :=
    choose1_hit 1000 30 32 3806401 10712529 1973 1979 1987 3806347 15 3806346 3806333 row_238 (SearchFacts.query_2433 LCMSourcePV.PrimeFacts.prime_3806333) c0_0_0
  have hsqrt : Nat.sqrt 3806401=1951 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3806401+1)=some 1973 := by
    rw [hsqrt];exact (SearchFacts.query_4359 LCMSourcePV.PrimeFacts.prime_1973)
  exact make_hit 1000 30 32 16 3806401 10712529 1973 1979 1987 3806347 row_238 h0 (SearchFacts.query_4360 LCMSourcePV.PrimeFacts.prime_1979) (SearchFacts.query_4361 LCMSourcePV.PrimeFacts.prime_1987) (SearchFacts.query_2434 LCMSourcePV.PrimeFacts.prime_3806347) c1_0
#print axioms make_238
end LCMSourcePV.Witness.BlockProofs
