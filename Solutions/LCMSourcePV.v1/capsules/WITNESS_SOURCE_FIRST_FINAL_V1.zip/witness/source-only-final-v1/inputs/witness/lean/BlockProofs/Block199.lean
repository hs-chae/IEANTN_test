/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_199 : Block := (Block.mk 2647129 2679768 1637 1657 1663 2647013 2647097 2647111)
theorem make_199 : make 1000 30 32 16 2647129 10712529=some row_199 := by
  have ck_0_8_0 : (Block.mk 2647129 2679768 1637 1657 1663 2647013 2647097 2647111).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1637 LCMSourcePV.PrimeFacts.prime_1657 LCMSourcePV.PrimeFacts.prime_1663 LCMSourcePV.PrimeFacts.prime_2647013 LCMSourcePV.PrimeFacts.prime_2647097 LCMSourcePV.PrimeFacts.prime_2647111
  have sh_0_8_0 : shrink 30 (Block.mk 2647129 2679768 1637 1657 1663 2647013 2647097 2647111)=some row_199 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 24 2647026=some row_199 :=
    choose0_hit 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 23 2647026 2647013 row_199 (SearchFacts.query_2040 LCMSourcePV.PrimeFacts.prime_2647013) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 25 2647030=(some row_199) :=
    choose0_skip 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 24 2647030 2647027 (some row_199) (SearchFacts.query_2041 LCMSourcePV.PrimeFacts.prime_2647027) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 26 2647038=(some row_199) :=
    choose0_skip 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 25 2647038 2647031 (some row_199) (SearchFacts.query_2042 LCMSourcePV.PrimeFacts.prime_2647031) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 27 2647048=(some row_199) :=
    choose0_skip 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 26 2647048 2647039 (some row_199) (SearchFacts.query_2043 LCMSourcePV.PrimeFacts.prime_2647039) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 28 2647062=(some row_199) :=
    choose0_skip 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 27 2647062 2647049 (some row_199) (SearchFacts.query_2044 LCMSourcePV.PrimeFacts.prime_2647049) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 29 2647066=(some row_199) :=
    choose0_skip 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 28 2647066 2647063 (some row_199) (SearchFacts.query_2045 LCMSourcePV.PrimeFacts.prime_2647063) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 30 2647078=(some row_199) :=
    choose0_skip 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 29 2647078 2647067 (some row_199) (SearchFacts.query_2046 LCMSourcePV.PrimeFacts.prime_2647067) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 31 2647080=(some row_199) :=
    choose0_skip 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 30 2647080 2647079 (some row_199) (SearchFacts.query_2047 LCMSourcePV.PrimeFacts.prime_2647079) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 32 2647096=(some row_199) :=
    choose0_skip 1000 30 2647129 10712529 1637 1657 1663 2647097 2647111 31 2647096 2647081 (some row_199) (SearchFacts.query_2048 LCMSourcePV.PrimeFacts.prime_2647081) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2647129 10712529 1637 1657 1663 2647111 16 2647110=some row_199 :=
    choose1_hit 1000 30 32 2647129 10712529 1637 1657 1663 2647111 15 2647110 2647097 row_199 (SearchFacts.query_2049 LCMSourcePV.PrimeFacts.prime_2647097) c0_0_0
  have hsqrt : Nat.sqrt 2647129=1627 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2647129+1)=some 1637 := by
    rw [hsqrt];exact (SearchFacts.query_4320 LCMSourcePV.PrimeFacts.prime_1637)
  exact make_hit 1000 30 32 16 2647129 10712529 1637 1657 1663 2647111 row_199 h0 (SearchFacts.query_4321 LCMSourcePV.PrimeFacts.prime_1657) (SearchFacts.query_4322 LCMSourcePV.PrimeFacts.prime_1663) (SearchFacts.query_2050 LCMSourcePV.PrimeFacts.prime_2647111) c1_0
#print axioms make_199
end LCMSourcePV.Witness.BlockProofs
