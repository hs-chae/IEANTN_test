/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_191 : Block := (Block.mk 2505889 2550408 1597 1601 1607 2505773 2505859 2505863)
theorem make_191 : make 1000 30 32 16 2505889 10712529=some row_191 := by
  have ck_0_7_0 : (Block.mk 2505889 2550408 1597 1601 1607 2505773 2505859 2505863).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1597 LCMSourcePV.PrimeFacts.prime_1601 LCMSourcePV.PrimeFacts.prime_1607 LCMSourcePV.PrimeFacts.prime_2505773 LCMSourcePV.PrimeFacts.prime_2505859 LCMSourcePV.PrimeFacts.prime_2505863
  have sh_0_7_0 : shrink 30 (Block.mk 2505889 2550408 1597 1601 1607 2505773 2505859 2505863)=some row_191 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 25 2505778=some row_191 :=
    choose0_hit 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 24 2505778 2505773 row_191 (SearchFacts.query_1951 LCMSourcePV.PrimeFacts.prime_2505773) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 26 2505790=(some row_191) :=
    choose0_skip 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 25 2505790 2505779 (some row_191) (SearchFacts.query_1952 LCMSourcePV.PrimeFacts.prime_2505779) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 27 2505792=(some row_191) :=
    choose0_skip 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 26 2505792 2505791 (some row_191) (SearchFacts.query_1953 LCMSourcePV.PrimeFacts.prime_2505791) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 28 2505808=(some row_191) :=
    choose0_skip 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 27 2505808 2505793 (some row_191) (SearchFacts.query_1954 LCMSourcePV.PrimeFacts.prime_2505793) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 29 2505828=(some row_191) :=
    choose0_skip 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 28 2505828 2505809 (some row_191) (SearchFacts.query_1955 LCMSourcePV.PrimeFacts.prime_2505809) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 30 2505846=(some row_191) :=
    choose0_skip 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 29 2505846 2505829 (some row_191) (SearchFacts.query_1956 LCMSourcePV.PrimeFacts.prime_2505829) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 31 2505856=(some row_191) :=
    choose0_skip 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 30 2505856 2505847 (some row_191) (SearchFacts.query_1957 LCMSourcePV.PrimeFacts.prime_2505847) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 32 2505858=(some row_191) :=
    choose0_skip 1000 30 2505889 10712529 1597 1601 1607 2505859 2505863 31 2505858 2505857 (some row_191) (SearchFacts.query_1958 LCMSourcePV.PrimeFacts.prime_2505857) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2505889 10712529 1597 1601 1607 2505863 16 2505862=some row_191 :=
    choose1_hit 1000 30 32 2505889 10712529 1597 1601 1607 2505863 15 2505862 2505859 row_191 (SearchFacts.query_1959 LCMSourcePV.PrimeFacts.prime_2505859) c0_0_0
  have hsqrt : Nat.sqrt 2505889=1583 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2505889+1)=some 1597 := by
    rw [hsqrt];exact (SearchFacts.query_4312 LCMSourcePV.PrimeFacts.prime_1597)
  exact make_hit 1000 30 32 16 2505889 10712529 1597 1601 1607 2505863 row_191 h0 (SearchFacts.query_4313 LCMSourcePV.PrimeFacts.prime_1601) (SearchFacts.query_4314 LCMSourcePV.PrimeFacts.prime_1607) (SearchFacts.query_1960 LCMSourcePV.PrimeFacts.prime_2505863) c1_0
#print axioms make_191
end LCMSourcePV.Witness.BlockProofs
