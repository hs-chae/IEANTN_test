/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_262 : Block := (Block.mk 4541161 4566768 2137 2141 2143 4541099 4541149 4541153)
theorem make_262 : make 1000 30 32 16 4541161 10712529=some row_262 := by
  have ck_0_5_0 : (Block.mk 4541161 4566768 2137 2141 2143 4541099 4541149 4541153).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2137 LCMSourcePV.PrimeFacts.prime_2141 LCMSourcePV.PrimeFacts.prime_2143 LCMSourcePV.PrimeFacts.prime_4541099 LCMSourcePV.PrimeFacts.prime_4541149 LCMSourcePV.PrimeFacts.prime_4541153
  have sh_0_5_0 : shrink 30 (Block.mk 4541161 4566768 2137 2141 2143 4541099 4541149 4541153)=some row_262 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 27 4541106=some row_262 :=
    choose0_hit 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 26 4541106 4541099 row_262 (SearchFacts.query_2632 LCMSourcePV.PrimeFacts.prime_4541099) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 28 4541112=(some row_262) :=
    choose0_skip 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 27 4541112 4541107 (some row_262) (SearchFacts.query_2633 LCMSourcePV.PrimeFacts.prime_4541107) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 29 4541122=(some row_262) :=
    choose0_skip 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 28 4541122 4541113 (some row_262) (SearchFacts.query_2634 LCMSourcePV.PrimeFacts.prime_4541113) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 30 4541128=(some row_262) :=
    choose0_skip 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 29 4541128 4541123 (some row_262) (SearchFacts.query_2635 LCMSourcePV.PrimeFacts.prime_4541123) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 31 4541136=(some row_262) :=
    choose0_skip 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 30 4541136 4541129 (some row_262) (SearchFacts.query_2636 LCMSourcePV.PrimeFacts.prime_4541129) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 32 4541148=(some row_262) :=
    choose0_skip 1000 30 4541161 10712529 2137 2141 2143 4541149 4541153 31 4541148 4541137 (some row_262) (SearchFacts.query_2637 LCMSourcePV.PrimeFacts.prime_4541137) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4541161 10712529 2137 2141 2143 4541153 16 4541152=some row_262 :=
    choose1_hit 1000 30 32 4541161 10712529 2137 2141 2143 4541153 15 4541152 4541149 row_262 (SearchFacts.query_2638 LCMSourcePV.PrimeFacts.prime_4541149) c0_0_0
  have hsqrt : Nat.sqrt 4541161=2131 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4541161+1)=some 2137 := by
    rw [hsqrt];exact (SearchFacts.query_4383 LCMSourcePV.PrimeFacts.prime_2137)
  exact make_hit 1000 30 32 16 4541161 10712529 2137 2141 2143 4541153 row_262 h0 (SearchFacts.query_4384 LCMSourcePV.PrimeFacts.prime_2141) (SearchFacts.query_4385 LCMSourcePV.PrimeFacts.prime_2143) (SearchFacts.query_2639 LCMSourcePV.PrimeFacts.prime_4541153) c1_0
#print axioms make_262
end LCMSourcePV.Witness.BlockProofs
