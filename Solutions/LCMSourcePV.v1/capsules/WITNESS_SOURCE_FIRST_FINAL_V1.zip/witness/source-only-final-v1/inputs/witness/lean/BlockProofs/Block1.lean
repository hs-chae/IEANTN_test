/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_1 : Block := (Block.mk 83425 85848 293 307 311 83311 83417 83423)
theorem make_1 : make 1000 30 32 16 83425 10712529=some row_1 := by
  have ck_0_8_0 : (Block.mk 83425 85848 293 307 311 83311 83417 83423).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_293 LCMSourcePV.PrimeFacts.prime_307 LCMSourcePV.PrimeFacts.prime_311 LCMSourcePV.PrimeFacts.prime_83311 LCMSourcePV.PrimeFacts.prime_83417 LCMSourcePV.PrimeFacts.prime_83423
  have sh_0_8_0 : shrink 30 (Block.mk 83425 85848 293 307 311 83311 83417 83423)=some row_1 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 24 83338=some row_1 :=
    choose0_hit 1000 30 83425 10712529 293 307 311 83417 83423 23 83338 83311 row_1 (SearchFacts.query_10 LCMSourcePV.PrimeFacts.prime_83311) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 25 83340=(some row_1) :=
    choose0_skip 1000 30 83425 10712529 293 307 311 83417 83423 24 83340 83339 (some row_1) (SearchFacts.query_11 LCMSourcePV.PrimeFacts.prime_83339) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 26 83356=(some row_1) :=
    choose0_skip 1000 30 83425 10712529 293 307 311 83417 83423 25 83356 83341 (some row_1) (SearchFacts.query_12 LCMSourcePV.PrimeFacts.prime_83341) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 27 83382=(some row_1) :=
    choose0_skip 1000 30 83425 10712529 293 307 311 83417 83423 26 83382 83357 (some row_1) (SearchFacts.query_13 LCMSourcePV.PrimeFacts.prime_83357) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 28 83388=(some row_1) :=
    choose0_skip 1000 30 83425 10712529 293 307 311 83417 83423 27 83388 83383 (some row_1) (SearchFacts.query_14 LCMSourcePV.PrimeFacts.prime_83383) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 29 83398=(some row_1) :=
    choose0_skip 1000 30 83425 10712529 293 307 311 83417 83423 28 83398 83389 (some row_1) (SearchFacts.query_15 LCMSourcePV.PrimeFacts.prime_83389) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 30 83400=(some row_1) :=
    choose0_skip 1000 30 83425 10712529 293 307 311 83417 83423 29 83400 83399 (some row_1) (SearchFacts.query_16 LCMSourcePV.PrimeFacts.prime_83399) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 31 83406=(some row_1) :=
    choose0_skip 1000 30 83425 10712529 293 307 311 83417 83423 30 83406 83401 (some row_1) (SearchFacts.query_17 LCMSourcePV.PrimeFacts.prime_83401) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 83425 10712529 293 307 311 83417 83423 32 83416=(some row_1) :=
    choose0_skip 1000 30 83425 10712529 293 307 311 83417 83423 31 83416 83407 (some row_1) (SearchFacts.query_18 LCMSourcePV.PrimeFacts.prime_83407) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 83425 10712529 293 307 311 83423 16 83422=some row_1 :=
    choose1_hit 1000 30 32 83425 10712529 293 307 311 83423 15 83422 83417 row_1 (SearchFacts.query_19 LCMSourcePV.PrimeFacts.prime_83417) c0_0_0
  have hsqrt : Nat.sqrt 83425=288 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 83425+1)=some 293 := by
    rw [hsqrt];exact (SearchFacts.query_4122 LCMSourcePV.PrimeFacts.prime_293)
  exact make_hit 1000 30 32 16 83425 10712529 293 307 311 83423 row_1 h0 (SearchFacts.query_4123 LCMSourcePV.PrimeFacts.prime_307) (SearchFacts.query_4124 LCMSourcePV.PrimeFacts.prime_311) (SearchFacts.query_20 LCMSourcePV.PrimeFacts.prime_83423) c1_0
#print axioms make_1
end LCMSourcePV.Witness.BlockProofs
