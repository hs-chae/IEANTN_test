/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_275 : Block := (Block.mk 5031049 5067000 2251 2267 2269 5030797 5031023 5031041)
theorem make_275 : make 1000 30 32 16 5031049 10712529=some row_275 := by
  have ck_0_9_0 : (Block.mk 5031049 5067000 2251 2267 2269 5030797 5031023 5031041).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2251 LCMSourcePV.PrimeFacts.prime_2267 LCMSourcePV.PrimeFacts.prime_2269 LCMSourcePV.PrimeFacts.prime_5030797 LCMSourcePV.PrimeFacts.prime_5031023 LCMSourcePV.PrimeFacts.prime_5031041
  have sh_0_9_0 : shrink 30 (Block.mk 5031049 5067000 2251 2267 2269 5030797 5031023 5031041)=some row_275 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 23 5030806=some row_275 :=
    choose0_hit 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 22 5030806 5030797 row_275 (SearchFacts.query_2785 LCMSourcePV.PrimeFacts.prime_5030797) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 24 5030820=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 23 5030820 5030807 (some row_275) (SearchFacts.query_2786 LCMSourcePV.PrimeFacts.prime_5030807) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 25 5030916=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 24 5030916 5030821 (some row_275) (SearchFacts.query_2787 LCMSourcePV.PrimeFacts.prime_5030821) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 26 5030922=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 25 5030922 5030917 (some row_275) (SearchFacts.query_2788 LCMSourcePV.PrimeFacts.prime_5030917) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 27 5030938=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 26 5030938 5030923 (some row_275) (SearchFacts.query_2789 LCMSourcePV.PrimeFacts.prime_5030923) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 28 5030968=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 27 5030968 5030939 (some row_275) (SearchFacts.query_2790 LCMSourcePV.PrimeFacts.prime_5030939) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 29 5030980=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 28 5030980 5030969 (some row_275) (SearchFacts.query_2791 LCMSourcePV.PrimeFacts.prime_5030969) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 30 5031010=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 29 5031010 5030981 (some row_275) (SearchFacts.query_2792 LCMSourcePV.PrimeFacts.prime_5030981) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 31 5031016=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 30 5031016 5031011 (some row_275) (SearchFacts.query_2793 LCMSourcePV.PrimeFacts.prime_5031011) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 32 5031022=(some row_275) :=
    choose0_skip 1000 30 5031049 10712529 2251 2267 2269 5031023 5031041 31 5031022 5031017 (some row_275) (SearchFacts.query_2794 LCMSourcePV.PrimeFacts.prime_5031017) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5031049 10712529 2251 2267 2269 5031041 16 5031040=some row_275 :=
    choose1_hit 1000 30 32 5031049 10712529 2251 2267 2269 5031041 15 5031040 5031023 row_275 (SearchFacts.query_2795 LCMSourcePV.PrimeFacts.prime_5031023) c0_0_0
  have hsqrt : Nat.sqrt 5031049=2243 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5031049+1)=some 2251 := by
    rw [hsqrt];exact (SearchFacts.query_4396 LCMSourcePV.PrimeFacts.prime_2251)
  exact make_hit 1000 30 32 16 5031049 10712529 2251 2267 2269 5031041 row_275 h0 (SearchFacts.query_4397 LCMSourcePV.PrimeFacts.prime_2267) (SearchFacts.query_4398 LCMSourcePV.PrimeFacts.prime_2269) (SearchFacts.query_2796 LCMSourcePV.PrimeFacts.prime_5031041) c1_0
#print axioms make_275
end LCMSourcePV.Witness.BlockProofs
