/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_197 : Block := (Block.mk 2621161 2627640 1621 1627 1637 2621053 2621147 2621159)
theorem make_197 : make 1000 30 32 16 2621161 10712529=some row_197 := by
  have ck_0_4_0 : (Block.mk 2621161 2627640 1621 1627 1637 2621053 2621147 2621159).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1621 LCMSourcePV.PrimeFacts.prime_1627 LCMSourcePV.PrimeFacts.prime_1637 LCMSourcePV.PrimeFacts.prime_2621053 LCMSourcePV.PrimeFacts.prime_2621147 LCMSourcePV.PrimeFacts.prime_2621159
  have sh_0_4_0 : shrink 30 (Block.mk 2621161 2627640 1621 1627 1637 2621053 2621147 2621159)=some row_197 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 28 2621062=some row_197 :=
    choose0_hit 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 27 2621062 2621053 row_197 (SearchFacts.query_2030 LCMSourcePV.PrimeFacts.prime_2621053) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 29 2621118=(some row_197) :=
    choose0_skip 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 28 2621118 2621063 (some row_197) (SearchFacts.query_2031 LCMSourcePV.PrimeFacts.prime_2621063) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 30 2621130=(some row_197) :=
    choose0_skip 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 29 2621130 2621119 (some row_197) (SearchFacts.query_2032 LCMSourcePV.PrimeFacts.prime_2621119) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 31 2621136=(some row_197) :=
    choose0_skip 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 30 2621136 2621131 (some row_197) (SearchFacts.query_2033 LCMSourcePV.PrimeFacts.prime_2621131) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 32 2621146=(some row_197) :=
    choose0_skip 1000 30 2621161 10712529 1621 1627 1637 2621147 2621159 31 2621146 2621137 (some row_197) (SearchFacts.query_2034 LCMSourcePV.PrimeFacts.prime_2621137) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2621161 10712529 1621 1627 1637 2621159 16 2621158=some row_197 :=
    choose1_hit 1000 30 32 2621161 10712529 1621 1627 1637 2621159 15 2621158 2621147 row_197 (SearchFacts.query_2035 LCMSourcePV.PrimeFacts.prime_2621147) c0_0_0
  have hsqrt : Nat.sqrt 2621161=1619 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2621161+1)=some 1621 := by
    rw [hsqrt];exact (SearchFacts.query_4318 LCMSourcePV.PrimeFacts.prime_1621)
  exact make_hit 1000 30 32 16 2621161 10712529 1621 1627 1637 2621159 row_197 h0 (SearchFacts.query_4319 LCMSourcePV.PrimeFacts.prime_1627) (SearchFacts.query_4320 LCMSourcePV.PrimeFacts.prime_1637) (SearchFacts.query_2036 LCMSourcePV.PrimeFacts.prime_2621159) c1_0
#print axioms make_197
end LCMSourcePV.Witness.BlockProofs
