/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_2 : Block := (Block.mk 85849 94248 307 311 313 85711 85843 85847)
theorem make_2 : make 1000 30 32 16 85849 10712529=some row_2 := by
  have ck_0_10_0 : (Block.mk 85849 94248 307 311 313 85711 85843 85847).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_307 LCMSourcePV.PrimeFacts.prime_311 LCMSourcePV.PrimeFacts.prime_313 LCMSourcePV.PrimeFacts.prime_85711 LCMSourcePV.PrimeFacts.prime_85843 LCMSourcePV.PrimeFacts.prime_85847
  have sh_0_10_0 : shrink 30 (Block.mk 85849 94248 307 311 313 85711 85843 85847)=some row_2 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 22 85716=some row_2 :=
    choose0_hit 1000 30 85849 10712529 307 311 313 85843 85847 21 85716 85711 row_2 (SearchFacts.query_21 LCMSourcePV.PrimeFacts.prime_85711) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 23 85732=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 22 85732 85717 (some row_2) (SearchFacts.query_22 LCMSourcePV.PrimeFacts.prime_85717) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 24 85750=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 23 85750 85733 (some row_2) (SearchFacts.query_23 LCMSourcePV.PrimeFacts.prime_85733) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 25 85780=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 24 85780 85751 (some row_2) (SearchFacts.query_24 LCMSourcePV.PrimeFacts.prime_85751) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 26 85792=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 25 85792 85781 (some row_2) (SearchFacts.query_25 LCMSourcePV.PrimeFacts.prime_85781) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 27 85816=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 26 85816 85793 (some row_2) (SearchFacts.query_26 LCMSourcePV.PrimeFacts.prime_85793) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 28 85818=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 27 85818 85817 (some row_2) (SearchFacts.query_27 LCMSourcePV.PrimeFacts.prime_85817) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 29 85828=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 28 85828 85819 (some row_2) (SearchFacts.query_28 LCMSourcePV.PrimeFacts.prime_85819) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 30 85830=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 29 85830 85829 (some row_2) (SearchFacts.query_29 LCMSourcePV.PrimeFacts.prime_85829) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 31 85836=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 30 85836 85831 (some row_2) (SearchFacts.query_30 LCMSourcePV.PrimeFacts.prime_85831) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 85849 10712529 307 311 313 85843 85847 32 85842=(some row_2) :=
    choose0_skip 1000 30 85849 10712529 307 311 313 85843 85847 31 85842 85837 (some row_2) (SearchFacts.query_31 LCMSourcePV.PrimeFacts.prime_85837) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 85849 10712529 307 311 313 85847 16 85846=some row_2 :=
    choose1_hit 1000 30 32 85849 10712529 307 311 313 85847 15 85846 85843 row_2 (SearchFacts.query_32 LCMSourcePV.PrimeFacts.prime_85843) c0_0_0
  have hsqrt : Nat.sqrt 85849=293 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 85849+1)=some 307 := by
    rw [hsqrt];exact (SearchFacts.query_4123 LCMSourcePV.PrimeFacts.prime_307)
  exact make_hit 1000 30 32 16 85849 10712529 307 311 313 85847 row_2 h0 (SearchFacts.query_4124 LCMSourcePV.PrimeFacts.prime_311) (SearchFacts.query_4125 LCMSourcePV.PrimeFacts.prime_313) (SearchFacts.query_33 LCMSourcePV.PrimeFacts.prime_85847) c1_0
#print axioms make_2
end LCMSourcePV.Witness.BlockProofs
