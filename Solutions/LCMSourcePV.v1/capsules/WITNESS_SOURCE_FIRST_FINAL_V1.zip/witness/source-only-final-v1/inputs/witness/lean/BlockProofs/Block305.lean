/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_305 : Block := (Block.mk 6046681 6086088 2467 2473 2477 6046213 6046657 6046669)
theorem make_305 : make 1000 30 32 16 6046681 10712529=some row_305 := by
  have ck_0_22_0 : (Block.mk 6046681 6086088 2467 2473 2477 6046213 6046657 6046669).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2467 LCMSourcePV.PrimeFacts.prime_2473 LCMSourcePV.PrimeFacts.prime_2477 LCMSourcePV.PrimeFacts.prime_6046213 LCMSourcePV.PrimeFacts.prime_6046657 LCMSourcePV.PrimeFacts.prime_6046669
  have sh_0_22_0 : shrink 30 (Block.mk 6046681 6086088 2467 2473 2477 6046213 6046657 6046669)=some row_305 := shrink_hit _ _ ck_0_22_0
  have c0_0_22 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 10 6046218=some row_305 :=
    choose0_hit 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 9 6046218 6046213 row_305 (SearchFacts.query_3074 LCMSourcePV.PrimeFacts.prime_6046213) (by decide) sh_0_22_0
  have c0_0_21 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 11 6046222=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 10 6046222 6046219 (some row_305) (SearchFacts.query_3075 LCMSourcePV.PrimeFacts.prime_6046219) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 12 6046230=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 11 6046230 6046223 (some row_305) (SearchFacts.query_3076 LCMSourcePV.PrimeFacts.prime_6046223) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 13 6046252=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 12 6046252 6046231 (some row_305) (SearchFacts.query_3077 LCMSourcePV.PrimeFacts.prime_6046231) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 14 6046266=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 13 6046266 6046253 (some row_305) (SearchFacts.query_3078 LCMSourcePV.PrimeFacts.prime_6046253) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 15 6046278=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 14 6046278 6046267 (some row_305) (SearchFacts.query_3079 LCMSourcePV.PrimeFacts.prime_6046267) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 16 6046282=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 15 6046282 6046279 (some row_305) (SearchFacts.query_3080 LCMSourcePV.PrimeFacts.prime_6046279) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 17 6046330=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 16 6046330 6046283 (some row_305) (SearchFacts.query_3081 LCMSourcePV.PrimeFacts.prime_6046283) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 18 6046348=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 17 6046348 6046331 (some row_305) (SearchFacts.query_3082 LCMSourcePV.PrimeFacts.prime_6046331) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 19 6046362=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 18 6046362 6046349 (some row_305) (SearchFacts.query_3083 LCMSourcePV.PrimeFacts.prime_6046349) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 20 6046386=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 19 6046386 6046363 (some row_305) (SearchFacts.query_3084 LCMSourcePV.PrimeFacts.prime_6046363) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 21 6046450=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 20 6046450 6046387 (some row_305) (SearchFacts.query_3085 LCMSourcePV.PrimeFacts.prime_6046387) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 22 6046476=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 21 6046476 6046451 (some row_305) (SearchFacts.query_3086 LCMSourcePV.PrimeFacts.prime_6046451) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 23 6046482=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 22 6046482 6046477 (some row_305) (SearchFacts.query_3087 LCMSourcePV.PrimeFacts.prime_6046477) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 24 6046488=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 23 6046488 6046483 (some row_305) (SearchFacts.query_3088 LCMSourcePV.PrimeFacts.prime_6046483) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 25 6046510=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 24 6046510 6046489 (some row_305) (SearchFacts.query_3089 LCMSourcePV.PrimeFacts.prime_6046489) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 26 6046560=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 25 6046560 6046511 (some row_305) (SearchFacts.query_3090 LCMSourcePV.PrimeFacts.prime_6046511) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 27 6046590=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 26 6046590 6046561 (some row_305) (SearchFacts.query_3091 LCMSourcePV.PrimeFacts.prime_6046561) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 28 6046602=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 27 6046602 6046591 (some row_305) (SearchFacts.query_3092 LCMSourcePV.PrimeFacts.prime_6046591) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 29 6046608=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 28 6046608 6046603 (some row_305) (SearchFacts.query_3093 LCMSourcePV.PrimeFacts.prime_6046603) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 30 6046612=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 29 6046612 6046609 (some row_305) (SearchFacts.query_3094 LCMSourcePV.PrimeFacts.prime_6046609) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 31 6046618=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 30 6046618 6046613 (some row_305) (SearchFacts.query_3095 LCMSourcePV.PrimeFacts.prime_6046613) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 32 6046656=(some row_305) :=
    choose0_skip 1000 30 6046681 10712529 2467 2473 2477 6046657 6046669 31 6046656 6046619 (some row_305) (SearchFacts.query_3096 LCMSourcePV.PrimeFacts.prime_6046619) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6046681 10712529 2467 2473 2477 6046669 16 6046668=some row_305 :=
    choose1_hit 1000 30 32 6046681 10712529 2467 2473 2477 6046669 15 6046668 6046657 row_305 (SearchFacts.query_3097 LCMSourcePV.PrimeFacts.prime_6046657) c0_0_0
  have hsqrt : Nat.sqrt 6046681=2459 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6046681+1)=some 2467 := by
    rw [hsqrt];exact (SearchFacts.query_4426 LCMSourcePV.PrimeFacts.prime_2467)
  exact make_hit 1000 30 32 16 6046681 10712529 2467 2473 2477 6046669 row_305 h0 (SearchFacts.query_4427 LCMSourcePV.PrimeFacts.prime_2473) (SearchFacts.query_4428 LCMSourcePV.PrimeFacts.prime_2477) (SearchFacts.query_3098 LCMSourcePV.PrimeFacts.prime_6046669) c1_0
#print axioms make_305
end LCMSourcePV.Witness.BlockProofs
