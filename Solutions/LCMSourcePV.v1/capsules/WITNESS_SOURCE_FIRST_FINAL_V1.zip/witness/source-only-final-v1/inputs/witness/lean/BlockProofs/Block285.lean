/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_285 : Block := (Block.mk 5340721 5442888 2333 2339 2341 5340661 5340689 5340707)
theorem make_285 : make 1000 30 32 16 5340721 10712529=some row_285 := by
  have ck_0_2_0 : (Block.mk 5340721 5442888 2333 2339 2341 5340661 5340689 5340707).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2333 LCMSourcePV.PrimeFacts.prime_2339 LCMSourcePV.PrimeFacts.prime_2341 LCMSourcePV.PrimeFacts.prime_5340661 LCMSourcePV.PrimeFacts.prime_5340689 LCMSourcePV.PrimeFacts.prime_5340707
  have sh_0_2_0 : shrink 30 (Block.mk 5340721 5442888 2333 2339 2341 5340661 5340689 5340707)=some row_285 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 5340721 10712529 2333 2339 2341 5340689 5340707 30 5340666=some row_285 :=
    choose0_hit 1000 30 5340721 10712529 2333 2339 2341 5340689 5340707 29 5340666 5340661 row_285 (SearchFacts.query_2862 LCMSourcePV.PrimeFacts.prime_5340661) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 5340721 10712529 2333 2339 2341 5340689 5340707 31 5340678=(some row_285) :=
    choose0_skip 1000 30 5340721 10712529 2333 2339 2341 5340689 5340707 30 5340678 5340667 (some row_285) (SearchFacts.query_2863 LCMSourcePV.PrimeFacts.prime_5340667) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5340721 10712529 2333 2339 2341 5340689 5340707 32 5340688=(some row_285) :=
    choose0_skip 1000 30 5340721 10712529 2333 2339 2341 5340689 5340707 31 5340688 5340679 (some row_285) (SearchFacts.query_2864 LCMSourcePV.PrimeFacts.prime_5340679) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5340721 10712529 2333 2339 2341 5340707 16 5340706=some row_285 :=
    choose1_hit 1000 30 32 5340721 10712529 2333 2339 2341 5340707 15 5340706 5340689 row_285 (SearchFacts.query_2865 LCMSourcePV.PrimeFacts.prime_5340689) c0_0_0
  have hsqrt : Nat.sqrt 5340721=2311 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5340721+1)=some 2333 := by
    rw [hsqrt];exact (SearchFacts.query_4406 LCMSourcePV.PrimeFacts.prime_2333)
  exact make_hit 1000 30 32 16 5340721 10712529 2333 2339 2341 5340707 row_285 h0 (SearchFacts.query_4407 LCMSourcePV.PrimeFacts.prime_2339) (SearchFacts.query_4408 LCMSourcePV.PrimeFacts.prime_2341) (SearchFacts.query_2866 LCMSourcePV.PrimeFacts.prime_5340707) c1_0
#print axioms make_285
end LCMSourcePV.Witness.BlockProofs
