/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_270 : Block := (Block.mk 4870849 4897368 2213 2221 2237 4870777 4870837 4870843)
theorem make_270 : make 1000 30 32 16 4870849 10712529=some row_270 := by
  have ck_0_2_0 : (Block.mk 4870849 4897368 2213 2221 2237 4870777 4870837 4870843).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2213 LCMSourcePV.PrimeFacts.prime_2221 LCMSourcePV.PrimeFacts.prime_2237 LCMSourcePV.PrimeFacts.prime_4870777 LCMSourcePV.PrimeFacts.prime_4870837 LCMSourcePV.PrimeFacts.prime_4870843
  have sh_0_2_0 : shrink 30 (Block.mk 4870849 4897368 2213 2221 2237 4870777 4870837 4870843)=some row_270 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 4870849 10712529 2213 2221 2237 4870837 4870843 30 4870798=some row_270 :=
    choose0_hit 1000 30 4870849 10712529 2213 2221 2237 4870837 4870843 29 4870798 4870777 row_270 (SearchFacts.query_2732 LCMSourcePV.PrimeFacts.prime_4870777) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 4870849 10712529 2213 2221 2237 4870837 4870843 31 4870818=(some row_270) :=
    choose0_skip 1000 30 4870849 10712529 2213 2221 2237 4870837 4870843 30 4870818 4870799 (some row_270) (SearchFacts.query_2733 LCMSourcePV.PrimeFacts.prime_4870799) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4870849 10712529 2213 2221 2237 4870837 4870843 32 4870836=(some row_270) :=
    choose0_skip 1000 30 4870849 10712529 2213 2221 2237 4870837 4870843 31 4870836 4870819 (some row_270) (SearchFacts.query_2734 LCMSourcePV.PrimeFacts.prime_4870819) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4870849 10712529 2213 2221 2237 4870843 16 4870842=some row_270 :=
    choose1_hit 1000 30 32 4870849 10712529 2213 2221 2237 4870843 15 4870842 4870837 row_270 (SearchFacts.query_2735 LCMSourcePV.PrimeFacts.prime_4870837) c0_0_0
  have hsqrt : Nat.sqrt 4870849=2207 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4870849+1)=some 2213 := by
    rw [hsqrt];exact (SearchFacts.query_4391 LCMSourcePV.PrimeFacts.prime_2213)
  exact make_hit 1000 30 32 16 4870849 10712529 2213 2221 2237 4870843 row_270 h0 (SearchFacts.query_4392 LCMSourcePV.PrimeFacts.prime_2221) (SearchFacts.query_4393 LCMSourcePV.PrimeFacts.prime_2237) (SearchFacts.query_2736 LCMSourcePV.PrimeFacts.prime_4870843) c1_0
#print axioms make_270
end LCMSourcePV.Witness.BlockProofs
