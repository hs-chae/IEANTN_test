/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_181 : Block := (Block.mk 2283121 2319528 1523 1531 1543 2282801 2283091 2283109)
theorem make_181 : make 1000 30 32 16 2283121 10712529=some row_181 := by
  have ck_0_16_0 : (Block.mk 2283121 2319528 1523 1531 1543 2282801 2283091 2283109).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1523 LCMSourcePV.PrimeFacts.prime_1531 LCMSourcePV.PrimeFacts.prime_1543 LCMSourcePV.PrimeFacts.prime_2282801 LCMSourcePV.PrimeFacts.prime_2283091 LCMSourcePV.PrimeFacts.prime_2283109
  have sh_0_16_0 : shrink 30 (Block.mk 2283121 2319528 1523 1531 1543 2282801 2283091 2283109)=some row_181 := shrink_hit _ _ ck_0_16_0
  have c0_0_16 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 16 2282806=some row_181 :=
    choose0_hit 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 15 2282806 2282801 row_181 (SearchFacts.query_1814 LCMSourcePV.PrimeFacts.prime_2282801) (by decide) sh_0_16_0
  have c0_0_15 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 17 2282848=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 16 2282848 2282807 (some row_181) (SearchFacts.query_1815 LCMSourcePV.PrimeFacts.prime_2282807) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 18 2282866=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 17 2282866 2282849 (some row_181) (SearchFacts.query_1816 LCMSourcePV.PrimeFacts.prime_2282849) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 19 2282896=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 18 2282896 2282867 (some row_181) (SearchFacts.query_1817 LCMSourcePV.PrimeFacts.prime_2282867) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 20 2282898=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 19 2282898 2282897 (some row_181) (SearchFacts.query_1818 LCMSourcePV.PrimeFacts.prime_2282897) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 21 2282922=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 20 2282922 2282899 (some row_181) (SearchFacts.query_1819 LCMSourcePV.PrimeFacts.prime_2282899) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 22 2282940=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 21 2282940 2282923 (some row_181) (SearchFacts.query_1820 LCMSourcePV.PrimeFacts.prime_2282923) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 23 2282962=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 22 2282962 2282941 (some row_181) (SearchFacts.query_1821 LCMSourcePV.PrimeFacts.prime_2282941) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 24 2282970=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 23 2282970 2282963 (some row_181) (SearchFacts.query_1822 LCMSourcePV.PrimeFacts.prime_2282963) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 25 2282988=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 24 2282988 2282971 (some row_181) (SearchFacts.query_1823 LCMSourcePV.PrimeFacts.prime_2282971) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 26 2283012=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 25 2283012 2282989 (some row_181) (SearchFacts.query_1824 LCMSourcePV.PrimeFacts.prime_2282989) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 27 2283018=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 26 2283018 2283013 (some row_181) (SearchFacts.query_1825 LCMSourcePV.PrimeFacts.prime_2283013) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 28 2283030=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 27 2283030 2283019 (some row_181) (SearchFacts.query_1826 LCMSourcePV.PrimeFacts.prime_2283019) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 29 2283036=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 28 2283036 2283031 (some row_181) (SearchFacts.query_1827 LCMSourcePV.PrimeFacts.prime_2283031) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 30 2283066=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 29 2283066 2283037 (some row_181) (SearchFacts.query_1828 LCMSourcePV.PrimeFacts.prime_2283037) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 31 2283076=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 30 2283076 2283067 (some row_181) (SearchFacts.query_1829 LCMSourcePV.PrimeFacts.prime_2283067) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 32 2283090=(some row_181) :=
    choose0_skip 1000 30 2283121 10712529 1523 1531 1543 2283091 2283109 31 2283090 2283077 (some row_181) (SearchFacts.query_1830 LCMSourcePV.PrimeFacts.prime_2283077) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2283121 10712529 1523 1531 1543 2283109 16 2283108=some row_181 :=
    choose1_hit 1000 30 32 2283121 10712529 1523 1531 1543 2283109 15 2283108 2283091 row_181 (SearchFacts.query_1831 LCMSourcePV.PrimeFacts.prime_2283091) c0_0_0
  have hsqrt : Nat.sqrt 2283121=1511 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2283121+1)=some 1523 := by
    rw [hsqrt];exact (SearchFacts.query_4302 LCMSourcePV.PrimeFacts.prime_1523)
  exact make_hit 1000 30 32 16 2283121 10712529 1523 1531 1543 2283109 row_181 h0 (SearchFacts.query_4303 LCMSourcePV.PrimeFacts.prime_1531) (SearchFacts.query_4304 LCMSourcePV.PrimeFacts.prime_1543) (SearchFacts.query_1832 LCMSourcePV.PrimeFacts.prime_2283109) c1_0
#print axioms make_181
end LCMSourcePV.Witness.BlockProofs
