/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_11 : Block := (Block.mk 121801 124608 353 359 367 121621 121787 121789)
theorem make_11 : make 1000 30 32 16 121801 10712529=some row_11 := by
  have ck_0_10_0 : (Block.mk 121801 124608 353 359 367 121621 121787 121789).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_353 LCMSourcePV.PrimeFacts.prime_359 LCMSourcePV.PrimeFacts.prime_367 LCMSourcePV.PrimeFacts.prime_121621 LCMSourcePV.PrimeFacts.prime_121787 LCMSourcePV.PrimeFacts.prime_121789
  have sh_0_10_0 : shrink 30 (Block.mk 121801 124608 353 359 367 121621 121787 121789)=some row_11 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 22 121630=some row_11 :=
    choose0_hit 1000 30 121801 10712529 353 359 367 121787 121789 21 121630 121621 row_11 (SearchFacts.query_78 LCMSourcePV.PrimeFacts.prime_121621) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 23 121632=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 22 121632 121631 (some row_11) (SearchFacts.query_79 LCMSourcePV.PrimeFacts.prime_121631) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 24 121636=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 23 121636 121633 (some row_11) (SearchFacts.query_80 LCMSourcePV.PrimeFacts.prime_121633) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 25 121660=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 24 121660 121637 (some row_11) (SearchFacts.query_81 LCMSourcePV.PrimeFacts.prime_121637) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 26 121686=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 25 121686 121661 (some row_11) (SearchFacts.query_82 LCMSourcePV.PrimeFacts.prime_121661) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 27 121696=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 26 121696 121687 (some row_11) (SearchFacts.query_83 LCMSourcePV.PrimeFacts.prime_121687) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 28 121710=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 27 121710 121697 (some row_11) (SearchFacts.query_84 LCMSourcePV.PrimeFacts.prime_121697) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 29 121720=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 28 121720 121711 (some row_11) (SearchFacts.query_85 LCMSourcePV.PrimeFacts.prime_121711) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 30 121726=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 29 121726 121721 (some row_11) (SearchFacts.query_86 LCMSourcePV.PrimeFacts.prime_121721) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 31 121762=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 30 121762 121727 (some row_11) (SearchFacts.query_87 LCMSourcePV.PrimeFacts.prime_121727) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 121801 10712529 353 359 367 121787 121789 32 121786=(some row_11) :=
    choose0_skip 1000 30 121801 10712529 353 359 367 121787 121789 31 121786 121763 (some row_11) (SearchFacts.query_88 LCMSourcePV.PrimeFacts.prime_121763) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 121801 10712529 353 359 367 121789 16 121788=some row_11 :=
    choose1_hit 1000 30 32 121801 10712529 353 359 367 121789 15 121788 121787 row_11 (SearchFacts.query_89 LCMSourcePV.PrimeFacts.prime_121787) c0_0_0
  have hsqrt : Nat.sqrt 121801=349 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 121801+1)=some 353 := by
    rw [hsqrt];exact (SearchFacts.query_4132 LCMSourcePV.PrimeFacts.prime_353)
  exact make_hit 1000 30 32 16 121801 10712529 353 359 367 121789 row_11 h0 (SearchFacts.query_4133 LCMSourcePV.PrimeFacts.prime_359) (SearchFacts.query_4134 LCMSourcePV.PrimeFacts.prime_367) (SearchFacts.query_90 LCMSourcePV.PrimeFacts.prime_121789) c1_0
#print axioms make_11
end LCMSourcePV.Witness.BlockProofs
