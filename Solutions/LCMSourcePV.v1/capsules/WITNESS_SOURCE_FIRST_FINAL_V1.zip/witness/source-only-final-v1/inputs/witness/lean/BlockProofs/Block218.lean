/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_218 : Block := (Block.mk 3193369 3200520 1789 1801 1811 3193339 3193361 3193363)
theorem make_218 : make 1000 30 32 16 3193369 10712529=some row_218 := by
  have ck_0_0_0 : (Block.mk 3193369 3200520 1789 1801 1811 3193339 3193361 3193363).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1789 LCMSourcePV.PrimeFacts.prime_1801 LCMSourcePV.PrimeFacts.prime_1811 LCMSourcePV.PrimeFacts.prime_3193339 LCMSourcePV.PrimeFacts.prime_3193361 LCMSourcePV.PrimeFacts.prime_3193363
  have sh_0_0_0 : shrink 30 (Block.mk 3193369 3200520 1789 1801 1811 3193339 3193361 3193363)=some row_218 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 3193369 10712529 1789 1801 1811 3193361 3193363 32 3193360=some row_218 :=
    choose0_hit 1000 30 3193369 10712529 1789 1801 1811 3193361 3193363 31 3193360 3193339 row_218 (SearchFacts.query_2266 LCMSourcePV.PrimeFacts.prime_3193339) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 3193369 10712529 1789 1801 1811 3193363 16 3193362=some row_218 :=
    choose1_hit 1000 30 32 3193369 10712529 1789 1801 1811 3193363 15 3193362 3193361 row_218 (SearchFacts.query_2267 LCMSourcePV.PrimeFacts.prime_3193361) c0_0_0
  have hsqrt : Nat.sqrt 3193369=1787 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3193369+1)=some 1789 := by
    rw [hsqrt];exact (SearchFacts.query_4339 LCMSourcePV.PrimeFacts.prime_1789)
  exact make_hit 1000 30 32 16 3193369 10712529 1789 1801 1811 3193363 row_218 h0 (SearchFacts.query_4340 LCMSourcePV.PrimeFacts.prime_1801) (SearchFacts.query_4341 LCMSourcePV.PrimeFacts.prime_1811) (SearchFacts.query_2268 LCMSourcePV.PrimeFacts.prime_3193363) c1_0
#print axioms make_218
end LCMSourcePV.Witness.BlockProofs
