/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_281 : Block := (Block.mk 5230369 5257848 2293 2297 2309 5230261 5230363 5230367)
theorem make_281 : make 1000 30 32 16 5230369 10712529=some row_281 := by
  have ck_0_5_0 : (Block.mk 5230369 5257848 2293 2297 2309 5230261 5230363 5230367).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2293 LCMSourcePV.PrimeFacts.prime_2297 LCMSourcePV.PrimeFacts.prime_2309 LCMSourcePV.PrimeFacts.prime_5230261 LCMSourcePV.PrimeFacts.prime_5230363 LCMSourcePV.PrimeFacts.prime_5230367
  have sh_0_5_0 : shrink 30 (Block.mk 5230369 5257848 2293 2297 2309 5230261 5230363 5230367)=some row_281 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 27 5230278=some row_281 :=
    choose0_hit 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 26 5230278 5230261 row_281 (SearchFacts.query_2831 LCMSourcePV.PrimeFacts.prime_5230261) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 28 5230296=(some row_281) :=
    choose0_skip 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 27 5230296 5230279 (some row_281) (SearchFacts.query_2832 LCMSourcePV.PrimeFacts.prime_5230279) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 29 5230320=(some row_281) :=
    choose0_skip 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 28 5230320 5230297 (some row_281) (SearchFacts.query_2833 LCMSourcePV.PrimeFacts.prime_5230297) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 30 5230326=(some row_281) :=
    choose0_skip 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 29 5230326 5230321 (some row_281) (SearchFacts.query_2834 LCMSourcePV.PrimeFacts.prime_5230321) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 31 5230348=(some row_281) :=
    choose0_skip 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 30 5230348 5230327 (some row_281) (SearchFacts.query_2835 LCMSourcePV.PrimeFacts.prime_5230327) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 32 5230362=(some row_281) :=
    choose0_skip 1000 30 5230369 10712529 2293 2297 2309 5230363 5230367 31 5230362 5230349 (some row_281) (SearchFacts.query_2836 LCMSourcePV.PrimeFacts.prime_5230349) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5230369 10712529 2293 2297 2309 5230367 16 5230366=some row_281 :=
    choose1_hit 1000 30 32 5230369 10712529 2293 2297 2309 5230367 15 5230366 5230363 row_281 (SearchFacts.query_2837 LCMSourcePV.PrimeFacts.prime_5230363) c0_0_0
  have hsqrt : Nat.sqrt 5230369=2287 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5230369+1)=some 2293 := by
    rw [hsqrt];exact (SearchFacts.query_4402 LCMSourcePV.PrimeFacts.prime_2293)
  exact make_hit 1000 30 32 16 5230369 10712529 2293 2297 2309 5230367 row_281 h0 (SearchFacts.query_4403 LCMSourcePV.PrimeFacts.prime_2297) (SearchFacts.query_4404 LCMSourcePV.PrimeFacts.prime_2309) (SearchFacts.query_2838 LCMSourcePV.PrimeFacts.prime_5230367) c1_0
#print axioms make_281
end LCMSourcePV.Witness.BlockProofs
