/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_31 : Block := (Block.mk 214369 218088 467 479 487 214129 214351 214363)
theorem make_31 : make 1000 30 32 16 214369 10712529=some row_31 := by
  have ck_0_15_0 : (Block.mk 214369 218088 467 479 487 214129 214351 214363).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_467 LCMSourcePV.PrimeFacts.prime_479 LCMSourcePV.PrimeFacts.prime_487 LCMSourcePV.PrimeFacts.prime_214129 LCMSourcePV.PrimeFacts.prime_214351 LCMSourcePV.PrimeFacts.prime_214363
  have sh_0_15_0 : shrink 30 (Block.mk 214369 218088 467 479 487 214129 214351 214363)=some row_31 := shrink_hit _ _ ck_0_15_0
  have c0_0_15 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 17 214132=some row_31 :=
    choose0_hit 1000 30 214369 10712529 467 479 487 214351 214363 16 214132 214129 row_31 (SearchFacts.query_322 LCMSourcePV.PrimeFacts.prime_214129) (by decide) sh_0_15_0
  have c0_0_14 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 18 214140=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 17 214140 214133 (some row_31) (SearchFacts.query_323 LCMSourcePV.PrimeFacts.prime_214133) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 19 214146=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 18 214146 214141 (some row_31) (SearchFacts.query_324 LCMSourcePV.PrimeFacts.prime_214141) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 20 214162=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 19 214162 214147 (some row_31) (SearchFacts.query_325 LCMSourcePV.PrimeFacts.prime_214147) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 21 214176=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 20 214176 214163 (some row_31) (SearchFacts.query_326 LCMSourcePV.PrimeFacts.prime_214163) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 22 214188=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 21 214188 214177 (some row_31) (SearchFacts.query_327 LCMSourcePV.PrimeFacts.prime_214177) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 23 214210=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 22 214210 214189 (some row_31) (SearchFacts.query_328 LCMSourcePV.PrimeFacts.prime_214189) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 24 214212=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 23 214212 214211 (some row_31) (SearchFacts.query_329 LCMSourcePV.PrimeFacts.prime_214211) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 25 214218=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 24 214218 214213 (some row_31) (SearchFacts.query_330 LCMSourcePV.PrimeFacts.prime_214213) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 26 214236=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 25 214236 214219 (some row_31) (SearchFacts.query_331 LCMSourcePV.PrimeFacts.prime_214219) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 27 214242=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 26 214242 214237 (some row_31) (SearchFacts.query_332 LCMSourcePV.PrimeFacts.prime_214237) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 28 214258=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 27 214258 214243 (some row_31) (SearchFacts.query_333 LCMSourcePV.PrimeFacts.prime_214243) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 29 214282=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 28 214282 214259 (some row_31) (SearchFacts.query_334 LCMSourcePV.PrimeFacts.prime_214259) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 30 214296=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 29 214296 214283 (some row_31) (SearchFacts.query_335 LCMSourcePV.PrimeFacts.prime_214283) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 31 214308=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 30 214308 214297 (some row_31) (SearchFacts.query_336 LCMSourcePV.PrimeFacts.prime_214297) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 214369 10712529 467 479 487 214351 214363 32 214350=(some row_31) :=
    choose0_skip 1000 30 214369 10712529 467 479 487 214351 214363 31 214350 214309 (some row_31) (SearchFacts.query_337 LCMSourcePV.PrimeFacts.prime_214309) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 214369 10712529 467 479 487 214363 16 214362=some row_31 :=
    choose1_hit 1000 30 32 214369 10712529 467 479 487 214363 15 214362 214351 row_31 (SearchFacts.query_338 LCMSourcePV.PrimeFacts.prime_214351) c0_0_0
  have hsqrt : Nat.sqrt 214369=463 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 214369+1)=some 467 := by
    rw [hsqrt];exact (SearchFacts.query_4152 LCMSourcePV.PrimeFacts.prime_467)
  exact make_hit 1000 30 32 16 214369 10712529 467 479 487 214363 row_31 h0 (SearchFacts.query_4153 LCMSourcePV.PrimeFacts.prime_479) (SearchFacts.query_4154 LCMSourcePV.PrimeFacts.prime_487) (SearchFacts.query_339 LCMSourcePV.PrimeFacts.prime_214363) c1_0
#print axioms make_31
end LCMSourcePV.Witness.BlockProofs
