/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_205 : Block := (Block.mk 2866249 2879808 1697 1699 1709 2866151 2866223 2866247)
theorem make_205 : make 1000 30 32 16 2866249 10712529=some row_205 := by
  have ck_0_4_0 : (Block.mk 2866249 2879808 1697 1699 1709 2866151 2866223 2866247).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1697 LCMSourcePV.PrimeFacts.prime_1699 LCMSourcePV.PrimeFacts.prime_1709 LCMSourcePV.PrimeFacts.prime_2866151 LCMSourcePV.PrimeFacts.prime_2866223 LCMSourcePV.PrimeFacts.prime_2866247
  have sh_0_4_0 : shrink 30 (Block.mk 2866249 2879808 1697 1699 1709 2866151 2866223 2866247)=some row_205 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 28 2866158=some row_205 :=
    choose0_hit 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 27 2866158 2866151 row_205 (SearchFacts.query_2117 LCMSourcePV.PrimeFacts.prime_2866151) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 29 2866162=(some row_205) :=
    choose0_skip 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 28 2866162 2866159 (some row_205) (SearchFacts.query_2118 LCMSourcePV.PrimeFacts.prime_2866159) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 30 2866188=(some row_205) :=
    choose0_skip 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 29 2866188 2866163 (some row_205) (SearchFacts.query_2119 LCMSourcePV.PrimeFacts.prime_2866163) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 31 2866210=(some row_205) :=
    choose0_skip 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 30 2866210 2866189 (some row_205) (SearchFacts.query_2120 LCMSourcePV.PrimeFacts.prime_2866189) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 32 2866222=(some row_205) :=
    choose0_skip 1000 30 2866249 10712529 1697 1699 1709 2866223 2866247 31 2866222 2866211 (some row_205) (SearchFacts.query_2121 LCMSourcePV.PrimeFacts.prime_2866211) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2866249 10712529 1697 1699 1709 2866247 16 2866246=some row_205 :=
    choose1_hit 1000 30 32 2866249 10712529 1697 1699 1709 2866247 15 2866246 2866223 row_205 (SearchFacts.query_2122 LCMSourcePV.PrimeFacts.prime_2866223) c0_0_0
  have hsqrt : Nat.sqrt 2866249=1693 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2866249+1)=some 1697 := by
    rw [hsqrt];exact (SearchFacts.query_4326 LCMSourcePV.PrimeFacts.prime_1697)
  exact make_hit 1000 30 32 16 2866249 10712529 1697 1699 1709 2866247 row_205 h0 (SearchFacts.query_4327 LCMSourcePV.PrimeFacts.prime_1699) (SearchFacts.query_4328 LCMSourcePV.PrimeFacts.prime_1709) (SearchFacts.query_2123 LCMSourcePV.PrimeFacts.prime_2866247) c1_0
#print axioms make_205
end LCMSourcePV.Witness.BlockProofs
