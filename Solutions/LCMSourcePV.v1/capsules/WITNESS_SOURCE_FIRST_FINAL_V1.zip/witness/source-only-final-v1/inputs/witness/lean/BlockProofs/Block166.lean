/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_166 : Block := (Block.mk 2036329 2042040 1429 1433 1439 2036269 2036299 2036323)
theorem make_166 : make 1000 30 32 16 2036329 10712529=some row_166 := by
  have ck_0_1_0 : (Block.mk 2036329 2042040 1429 1433 1439 2036269 2036299 2036323).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1429 LCMSourcePV.PrimeFacts.prime_1433 LCMSourcePV.PrimeFacts.prime_1439 LCMSourcePV.PrimeFacts.prime_2036269 LCMSourcePV.PrimeFacts.prime_2036299 LCMSourcePV.PrimeFacts.prime_2036323
  have sh_0_1_0 : shrink 30 (Block.mk 2036329 2042040 1429 1433 1439 2036269 2036299 2036323)=some row_166 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 2036329 10712529 1429 1433 1439 2036299 2036323 31 2036272=some row_166 :=
    choose0_hit 1000 30 2036329 10712529 1429 1433 1439 2036299 2036323 30 2036272 2036269 row_166 (SearchFacts.query_1706 LCMSourcePV.PrimeFacts.prime_2036269) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 2036329 10712529 1429 1433 1439 2036299 2036323 32 2036298=(some row_166) :=
    choose0_skip 1000 30 2036329 10712529 1429 1433 1439 2036299 2036323 31 2036298 2036273 (some row_166) (SearchFacts.query_1707 LCMSourcePV.PrimeFacts.prime_2036273) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2036329 10712529 1429 1433 1439 2036323 16 2036322=some row_166 :=
    choose1_hit 1000 30 32 2036329 10712529 1429 1433 1439 2036323 15 2036322 2036299 row_166 (SearchFacts.query_1708 LCMSourcePV.PrimeFacts.prime_2036299) c0_0_0
  have hsqrt : Nat.sqrt 2036329=1427 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2036329+1)=some 1429 := by
    rw [hsqrt];exact (SearchFacts.query_4287 LCMSourcePV.PrimeFacts.prime_1429)
  exact make_hit 1000 30 32 16 2036329 10712529 1429 1433 1439 2036323 row_166 h0 (SearchFacts.query_4288 LCMSourcePV.PrimeFacts.prime_1433) (SearchFacts.query_4289 LCMSourcePV.PrimeFacts.prime_1439) (SearchFacts.query_1709 LCMSourcePV.PrimeFacts.prime_2036323) c1_0
#print axioms make_166
end LCMSourcePV.Witness.BlockProofs
