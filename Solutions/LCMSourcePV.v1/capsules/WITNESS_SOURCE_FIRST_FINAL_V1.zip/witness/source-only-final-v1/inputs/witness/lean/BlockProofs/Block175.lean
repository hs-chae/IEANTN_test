/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_175 : Block := (Block.mk 2193361 2199288 1483 1487 1489 2193259 2193337 2193353)
theorem make_175 : make 1000 30 32 16 2193361 10712529=some row_175 := by
  have ck_0_5_0 : (Block.mk 2193361 2199288 1483 1487 1489 2193259 2193337 2193353).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1483 LCMSourcePV.PrimeFacts.prime_1487 LCMSourcePV.PrimeFacts.prime_1489 LCMSourcePV.PrimeFacts.prime_2193259 LCMSourcePV.PrimeFacts.prime_2193337 LCMSourcePV.PrimeFacts.prime_2193353
  have sh_0_5_0 : shrink 30 (Block.mk 2193361 2199288 1483 1487 1489 2193259 2193337 2193353)=some row_175 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 27 2193262=some row_175 :=
    choose0_hit 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 26 2193262 2193259 row_175 (SearchFacts.query_1781 LCMSourcePV.PrimeFacts.prime_2193259) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 28 2193270=(some row_175) :=
    choose0_skip 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 27 2193270 2193263 (some row_175) (SearchFacts.query_1782 LCMSourcePV.PrimeFacts.prime_2193263) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 29 2193310=(some row_175) :=
    choose0_skip 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 28 2193310 2193271 (some row_175) (SearchFacts.query_1783 LCMSourcePV.PrimeFacts.prime_2193271) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 30 2193312=(some row_175) :=
    choose0_skip 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 29 2193312 2193311 (some row_175) (SearchFacts.query_1784 LCMSourcePV.PrimeFacts.prime_2193311) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 31 2193318=(some row_175) :=
    choose0_skip 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 30 2193318 2193313 (some row_175) (SearchFacts.query_1785 LCMSourcePV.PrimeFacts.prime_2193313) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 32 2193336=(some row_175) :=
    choose0_skip 1000 30 2193361 10712529 1483 1487 1489 2193337 2193353 31 2193336 2193319 (some row_175) (SearchFacts.query_1786 LCMSourcePV.PrimeFacts.prime_2193319) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2193361 10712529 1483 1487 1489 2193353 16 2193352=some row_175 :=
    choose1_hit 1000 30 32 2193361 10712529 1483 1487 1489 2193353 15 2193352 2193337 row_175 (SearchFacts.query_1787 LCMSourcePV.PrimeFacts.prime_2193337) c0_0_0
  have hsqrt : Nat.sqrt 2193361=1481 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2193361+1)=some 1483 := by
    rw [hsqrt];exact (SearchFacts.query_4296 LCMSourcePV.PrimeFacts.prime_1483)
  exact make_hit 1000 30 32 16 2193361 10712529 1483 1487 1489 2193353 row_175 h0 (SearchFacts.query_4297 LCMSourcePV.PrimeFacts.prime_1487) (SearchFacts.query_4298 LCMSourcePV.PrimeFacts.prime_1489) (SearchFacts.query_1788 LCMSourcePV.PrimeFacts.prime_2193353) c1_0
#print axioms make_175
end LCMSourcePV.Witness.BlockProofs
