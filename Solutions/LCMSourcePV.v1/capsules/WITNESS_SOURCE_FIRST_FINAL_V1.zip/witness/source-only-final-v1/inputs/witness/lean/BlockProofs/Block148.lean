/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_148 : Block := (Block.mk 1635841 1646088 1283 1289 1291 1635773 1635817 1635827)
theorem make_148 : make 1000 30 32 16 1635841 10712529=some row_148 := by
  have ck_0_1_0 : (Block.mk 1635841 1646088 1283 1289 1291 1635773 1635817 1635827).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1283 LCMSourcePV.PrimeFacts.prime_1289 LCMSourcePV.PrimeFacts.prime_1291 LCMSourcePV.PrimeFacts.prime_1635773 LCMSourcePV.PrimeFacts.prime_1635817 LCMSourcePV.PrimeFacts.prime_1635827
  have sh_0_1_0 : shrink 30 (Block.mk 1635841 1646088 1283 1289 1291 1635773 1635817 1635827)=some row_148 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 1635841 10712529 1283 1289 1291 1635817 1635827 31 1635810=some row_148 :=
    choose0_hit 1000 30 1635841 10712529 1283 1289 1291 1635817 1635827 30 1635810 1635773 row_148 (SearchFacts.query_1567 LCMSourcePV.PrimeFacts.prime_1635773) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 1635841 10712529 1283 1289 1291 1635817 1635827 32 1635816=(some row_148) :=
    choose0_skip 1000 30 1635841 10712529 1283 1289 1291 1635817 1635827 31 1635816 1635811 (some row_148) (SearchFacts.query_1568 LCMSourcePV.PrimeFacts.prime_1635811) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1635841 10712529 1283 1289 1291 1635827 16 1635826=some row_148 :=
    choose1_hit 1000 30 32 1635841 10712529 1283 1289 1291 1635827 15 1635826 1635817 row_148 (SearchFacts.query_1569 LCMSourcePV.PrimeFacts.prime_1635817) c0_0_0
  have hsqrt : Nat.sqrt 1635841=1279 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1635841+1)=some 1283 := by
    rw [hsqrt];exact (SearchFacts.query_4269 LCMSourcePV.PrimeFacts.prime_1283)
  exact make_hit 1000 30 32 16 1635841 10712529 1283 1289 1291 1635827 row_148 h0 (SearchFacts.query_4270 LCMSourcePV.PrimeFacts.prime_1289) (SearchFacts.query_4271 LCMSourcePV.PrimeFacts.prime_1291) (SearchFacts.query_1570 LCMSourcePV.PrimeFacts.prime_1635827) c1_0
#print axioms make_148
end LCMSourcePV.Witness.BlockProofs
