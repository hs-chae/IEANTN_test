/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_222 : Block := (Block.mk 3323329 3352560 1831 1847 1861 3323141 3323249 3323311)
theorem make_222 : make 1000 30 32 16 3323329 10712529=some row_222 := by
  have ck_0_6_0 : (Block.mk 3323329 3352560 1831 1847 1861 3323141 3323249 3323311).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1831 LCMSourcePV.PrimeFacts.prime_1847 LCMSourcePV.PrimeFacts.prime_1861 LCMSourcePV.PrimeFacts.prime_3323141 LCMSourcePV.PrimeFacts.prime_3323249 LCMSourcePV.PrimeFacts.prime_3323311
  have sh_0_6_0 : shrink 30 (Block.mk 3323329 3352560 1831 1847 1861 3323141 3323249 3323311)=some row_222 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 26 3323182=some row_222 :=
    choose0_hit 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 25 3323182 3323141 row_222 (SearchFacts.query_2304 LCMSourcePV.PrimeFacts.prime_3323141) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 27 3323188=(some row_222) :=
    choose0_skip 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 26 3323188 3323183 (some row_222) (SearchFacts.query_2305 LCMSourcePV.PrimeFacts.prime_3323183) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 28 3323190=(some row_222) :=
    choose0_skip 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 27 3323190 3323189 (some row_222) (SearchFacts.query_2306 LCMSourcePV.PrimeFacts.prime_3323189) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 29 3323206=(some row_222) :=
    choose0_skip 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 28 3323206 3323191 (some row_222) (SearchFacts.query_2307 LCMSourcePV.PrimeFacts.prime_3323191) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 30 3323212=(some row_222) :=
    choose0_skip 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 29 3323212 3323207 (some row_222) (SearchFacts.query_2308 LCMSourcePV.PrimeFacts.prime_3323207) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 31 3323238=(some row_222) :=
    choose0_skip 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 30 3323238 3323213 (some row_222) (SearchFacts.query_2309 LCMSourcePV.PrimeFacts.prime_3323213) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 32 3323248=(some row_222) :=
    choose0_skip 1000 30 3323329 10712529 1831 1847 1861 3323249 3323311 31 3323248 3323239 (some row_222) (SearchFacts.query_2310 LCMSourcePV.PrimeFacts.prime_3323239) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3323329 10712529 1831 1847 1861 3323311 16 3323310=some row_222 :=
    choose1_hit 1000 30 32 3323329 10712529 1831 1847 1861 3323311 15 3323310 3323249 row_222 (SearchFacts.query_2311 LCMSourcePV.PrimeFacts.prime_3323249) c0_0_0
  have hsqrt : Nat.sqrt 3323329=1823 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3323329+1)=some 1831 := by
    rw [hsqrt];exact (SearchFacts.query_4343 LCMSourcePV.PrimeFacts.prime_1831)
  exact make_hit 1000 30 32 16 3323329 10712529 1831 1847 1861 3323311 row_222 h0 (SearchFacts.query_4344 LCMSourcePV.PrimeFacts.prime_1847) (SearchFacts.query_4345 LCMSourcePV.PrimeFacts.prime_1861) (SearchFacts.query_2312 LCMSourcePV.PrimeFacts.prime_3323311) c1_0
#print axioms make_222
end LCMSourcePV.Witness.BlockProofs
