/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_319 : Block := (Block.mk 6723649 6806880 2609 2617 2621 6723589 6723641 6723643)
theorem make_319 : make 1000 30 32 16 6723649 10712529=some row_319 := by
  have ck_0_4_0 : (Block.mk 6723649 6806880 2609 2617 2621 6723589 6723641 6723643).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2609 LCMSourcePV.PrimeFacts.prime_2617 LCMSourcePV.PrimeFacts.prime_2621 LCMSourcePV.PrimeFacts.prime_6723589 LCMSourcePV.PrimeFacts.prime_6723641 LCMSourcePV.PrimeFacts.prime_6723643
  have sh_0_4_0 : shrink 30 (Block.mk 6723649 6806880 2609 2617 2621 6723589 6723641 6723643)=some row_319 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 28 6723592=some row_319 :=
    choose0_hit 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 27 6723592 6723589 row_319 (SearchFacts.query_3252 LCMSourcePV.PrimeFacts.prime_6723589) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 29 6723616=(some row_319) :=
    choose0_skip 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 28 6723616 6723593 (some row_319) (SearchFacts.query_3253 LCMSourcePV.PrimeFacts.prime_6723593) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 30 6723622=(some row_319) :=
    choose0_skip 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 29 6723622 6723617 (some row_319) (SearchFacts.query_3254 LCMSourcePV.PrimeFacts.prime_6723617) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 31 6723636=(some row_319) :=
    choose0_skip 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 30 6723636 6723623 (some row_319) (SearchFacts.query_3255 LCMSourcePV.PrimeFacts.prime_6723623) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 32 6723640=(some row_319) :=
    choose0_skip 1000 30 6723649 10712529 2609 2617 2621 6723641 6723643 31 6723640 6723637 (some row_319) (SearchFacts.query_3256 LCMSourcePV.PrimeFacts.prime_6723637) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6723649 10712529 2609 2617 2621 6723643 16 6723642=some row_319 :=
    choose1_hit 1000 30 32 6723649 10712529 2609 2617 2621 6723643 15 6723642 6723641 row_319 (SearchFacts.query_3257 LCMSourcePV.PrimeFacts.prime_6723641) c0_0_0
  have hsqrt : Nat.sqrt 6723649=2593 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6723649+1)=some 2609 := by
    rw [hsqrt];exact (SearchFacts.query_4440 LCMSourcePV.PrimeFacts.prime_2609)
  exact make_hit 1000 30 32 16 6723649 10712529 2609 2617 2621 6723643 row_319 h0 (SearchFacts.query_4441 LCMSourcePV.PrimeFacts.prime_2617) (SearchFacts.query_4442 LCMSourcePV.PrimeFacts.prime_2621) (SearchFacts.query_3258 LCMSourcePV.PrimeFacts.prime_6723643) c1_0
#print axioms make_319
end LCMSourcePV.Witness.BlockProofs
