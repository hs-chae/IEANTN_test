/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_28 : Block := (Block.mk 201601 208848 457 461 463 201577 201589 201599)
theorem make_28 : make 1000 30 32 16 201601 10712529=some row_28 := by
  have ck_0_1_0 : (Block.mk 201601 208848 457 461 463 201577 201589 201599).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_457 LCMSourcePV.PrimeFacts.prime_461 LCMSourcePV.PrimeFacts.prime_463 LCMSourcePV.PrimeFacts.prime_201577 LCMSourcePV.PrimeFacts.prime_201589 LCMSourcePV.PrimeFacts.prime_201599
  have sh_0_1_0 : shrink 30 (Block.mk 201601 208848 457 461 463 201577 201589 201599)=some row_28 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 201601 10712529 457 461 463 201589 201599 31 201580=some row_28 :=
    choose0_hit 1000 30 201601 10712529 457 461 463 201589 201599 30 201580 201577 row_28 (SearchFacts.query_284 LCMSourcePV.PrimeFacts.prime_201577) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 201601 10712529 457 461 463 201589 201599 32 201588=(some row_28) :=
    choose0_skip 1000 30 201601 10712529 457 461 463 201589 201599 31 201588 201581 (some row_28) (SearchFacts.query_285 LCMSourcePV.PrimeFacts.prime_201581) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 201601 10712529 457 461 463 201599 16 201598=some row_28 :=
    choose1_hit 1000 30 32 201601 10712529 457 461 463 201599 15 201598 201589 row_28 (SearchFacts.query_286 LCMSourcePV.PrimeFacts.prime_201589) c0_0_0
  have hsqrt : Nat.sqrt 201601=449 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 201601+1)=some 457 := by
    rw [hsqrt];exact (SearchFacts.query_4149 LCMSourcePV.PrimeFacts.prime_457)
  exact make_hit 1000 30 32 16 201601 10712529 457 461 463 201599 row_28 h0 (SearchFacts.query_4150 LCMSourcePV.PrimeFacts.prime_461) (SearchFacts.query_4151 LCMSourcePV.PrimeFacts.prime_463) (SearchFacts.query_287 LCMSourcePV.PrimeFacts.prime_201599) c1_0
#print axioms make_28
end LCMSourcePV.Witness.BlockProofs
