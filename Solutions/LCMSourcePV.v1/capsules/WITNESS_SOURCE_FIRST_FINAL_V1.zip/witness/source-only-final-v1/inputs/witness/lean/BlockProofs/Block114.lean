/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_114 : Block := (Block.mk 1062961 1067088 1033 1039 1049 1062877 1062947 1062949)
theorem make_114 : make 1000 30 32 16 1062961 10712529=some row_114 := by
  have ck_0_5_0 : (Block.mk 1062961 1067088 1033 1039 1049 1062877 1062947 1062949).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1033 LCMSourcePV.PrimeFacts.prime_1039 LCMSourcePV.PrimeFacts.prime_1049 LCMSourcePV.PrimeFacts.prime_1062877 LCMSourcePV.PrimeFacts.prime_1062947 LCMSourcePV.PrimeFacts.prime_1062949
  have sh_0_5_0 : shrink 30 (Block.mk 1062961 1067088 1033 1039 1049 1062877 1062947 1062949)=some row_114 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 27 1062880=some row_114 :=
    choose0_hit 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 26 1062880 1062877 row_114 (SearchFacts.query_1173 LCMSourcePV.PrimeFacts.prime_1062877) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 28 1062906=(some row_114) :=
    choose0_skip 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 27 1062906 1062881 (some row_114) (SearchFacts.query_1174 LCMSourcePV.PrimeFacts.prime_1062881) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 29 1062910=(some row_114) :=
    choose0_skip 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 28 1062910 1062907 (some row_114) (SearchFacts.query_1175 LCMSourcePV.PrimeFacts.prime_1062907) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 30 1062912=(some row_114) :=
    choose0_skip 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 29 1062912 1062911 (some row_114) (SearchFacts.query_1176 LCMSourcePV.PrimeFacts.prime_1062911) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 31 1062930=(some row_114) :=
    choose0_skip 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 30 1062930 1062913 (some row_114) (SearchFacts.query_1177 LCMSourcePV.PrimeFacts.prime_1062913) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 32 1062946=(some row_114) :=
    choose0_skip 1000 30 1062961 10712529 1033 1039 1049 1062947 1062949 31 1062946 1062931 (some row_114) (SearchFacts.query_1178 LCMSourcePV.PrimeFacts.prime_1062931) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1062961 10712529 1033 1039 1049 1062949 16 1062948=some row_114 :=
    choose1_hit 1000 30 32 1062961 10712529 1033 1039 1049 1062949 15 1062948 1062947 row_114 (SearchFacts.query_1179 LCMSourcePV.PrimeFacts.prime_1062947) c0_0_0
  have hsqrt : Nat.sqrt 1062961=1031 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1062961+1)=some 1033 := by
    rw [hsqrt];exact (SearchFacts.query_4235 LCMSourcePV.PrimeFacts.prime_1033)
  exact make_hit 1000 30 32 16 1062961 10712529 1033 1039 1049 1062949 row_114 h0 (SearchFacts.query_4236 LCMSourcePV.PrimeFacts.prime_1039) (SearchFacts.query_4237 LCMSourcePV.PrimeFacts.prime_1049) (SearchFacts.query_1180 LCMSourcePV.PrimeFacts.prime_1062949) c1_0
#print axioms make_114
end LCMSourcePV.Witness.BlockProofs
