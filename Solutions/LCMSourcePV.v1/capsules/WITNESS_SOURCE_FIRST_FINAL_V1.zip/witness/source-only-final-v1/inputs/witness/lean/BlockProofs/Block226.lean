/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_226 : Block := (Block.mk 3485689 3500640 1871 1873 1877 3485641 3485681 3485687)
theorem make_226 : make 1000 30 32 16 3485689 10712529=some row_226 := by
  have ck_0_0_0 : (Block.mk 3485689 3500640 1871 1873 1877 3485641 3485681 3485687).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1871 LCMSourcePV.PrimeFacts.prime_1873 LCMSourcePV.PrimeFacts.prime_1877 LCMSourcePV.PrimeFacts.prime_3485641 LCMSourcePV.PrimeFacts.prime_3485681 LCMSourcePV.PrimeFacts.prime_3485687
  have sh_0_0_0 : shrink 30 (Block.mk 3485689 3500640 1871 1873 1877 3485641 3485681 3485687)=some row_226 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 3485689 10712529 1871 1873 1877 3485681 3485687 32 3485680=some row_226 :=
    choose0_hit 1000 30 3485689 10712529 1871 1873 1877 3485681 3485687 31 3485680 3485641 row_226 (SearchFacts.query_2342 LCMSourcePV.PrimeFacts.prime_3485641) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 3485689 10712529 1871 1873 1877 3485687 16 3485686=some row_226 :=
    choose1_hit 1000 30 32 3485689 10712529 1871 1873 1877 3485687 15 3485686 3485681 row_226 (SearchFacts.query_2343 LCMSourcePV.PrimeFacts.prime_3485681) c0_0_0
  have hsqrt : Nat.sqrt 3485689=1867 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3485689+1)=some 1871 := by
    rw [hsqrt];exact (SearchFacts.query_4347 LCMSourcePV.PrimeFacts.prime_1871)
  exact make_hit 1000 30 32 16 3485689 10712529 1871 1873 1877 3485687 row_226 h0 (SearchFacts.query_4348 LCMSourcePV.PrimeFacts.prime_1873) (SearchFacts.query_4349 LCMSourcePV.PrimeFacts.prime_1877) (SearchFacts.query_2344 LCMSourcePV.PrimeFacts.prime_3485687) c1_0
#print axioms make_226
end LCMSourcePV.Witness.BlockProofs
