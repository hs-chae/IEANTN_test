/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_260 : Block := (Block.mk 4464769 4532640 2129 2131 2137 4464751 4464763 4464767)
theorem make_260 : make 1000 30 32 16 4464769 10712529=some row_260 := by
  have ck_0_0_0 : (Block.mk 4464769 4532640 2129 2131 2137 4464751 4464763 4464767).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2129 LCMSourcePV.PrimeFacts.prime_2131 LCMSourcePV.PrimeFacts.prime_2137 LCMSourcePV.PrimeFacts.prime_4464751 LCMSourcePV.PrimeFacts.prime_4464763 LCMSourcePV.PrimeFacts.prime_4464767
  have sh_0_0_0 : shrink 30 (Block.mk 4464769 4532640 2129 2131 2137 4464751 4464763 4464767)=some row_260 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 4464769 10712529 2129 2131 2137 4464763 4464767 32 4464762=some row_260 :=
    choose0_hit 1000 30 4464769 10712529 2129 2131 2137 4464763 4464767 31 4464762 4464751 row_260 (SearchFacts.query_2624 LCMSourcePV.PrimeFacts.prime_4464751) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 4464769 10712529 2129 2131 2137 4464767 16 4464766=some row_260 :=
    choose1_hit 1000 30 32 4464769 10712529 2129 2131 2137 4464767 15 4464766 4464763 row_260 (SearchFacts.query_2625 LCMSourcePV.PrimeFacts.prime_4464763) c0_0_0
  have hsqrt : Nat.sqrt 4464769=2113 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4464769+1)=some 2129 := by
    rw [hsqrt];exact (SearchFacts.query_4381 LCMSourcePV.PrimeFacts.prime_2129)
  exact make_hit 1000 30 32 16 4464769 10712529 2129 2131 2137 4464767 row_260 h0 (SearchFacts.query_4382 LCMSourcePV.PrimeFacts.prime_2131) (SearchFacts.query_4383 LCMSourcePV.PrimeFacts.prime_2137) (SearchFacts.query_2626 LCMSourcePV.PrimeFacts.prime_4464767) c1_0
#print axioms make_260
end LCMSourcePV.Witness.BlockProofs
