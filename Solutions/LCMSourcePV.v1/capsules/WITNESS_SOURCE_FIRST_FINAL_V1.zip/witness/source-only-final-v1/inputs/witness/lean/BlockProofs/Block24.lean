/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_24 : Block := (Block.mk 185761 187488 433 439 443 185707 185749 185753)
theorem make_24 : make 1000 30 32 16 185761 10712529=some row_24 := by
  have ck_0_4_0 : (Block.mk 185761 187488 433 439 443 185707 185749 185753).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_433 LCMSourcePV.PrimeFacts.prime_439 LCMSourcePV.PrimeFacts.prime_443 LCMSourcePV.PrimeFacts.prime_185707 LCMSourcePV.PrimeFacts.prime_185749 LCMSourcePV.PrimeFacts.prime_185753
  have sh_0_4_0 : shrink 30 (Block.mk 185761 187488 433 439 443 185707 185749 185753)=some row_24 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 185761 10712529 433 439 443 185749 185753 28 185710=some row_24 :=
    choose0_hit 1000 30 185761 10712529 433 439 443 185749 185753 27 185710 185707 row_24 (SearchFacts.query_247 LCMSourcePV.PrimeFacts.prime_185707) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 185761 10712529 433 439 443 185749 185753 29 185722=(some row_24) :=
    choose0_skip 1000 30 185761 10712529 433 439 443 185749 185753 28 185722 185711 (some row_24) (SearchFacts.query_248 LCMSourcePV.PrimeFacts.prime_185711) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 185761 10712529 433 439 443 185749 185753 30 185736=(some row_24) :=
    choose0_skip 1000 30 185761 10712529 433 439 443 185749 185753 29 185736 185723 (some row_24) (SearchFacts.query_249 LCMSourcePV.PrimeFacts.prime_185723) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 185761 10712529 433 439 443 185749 185753 31 185746=(some row_24) :=
    choose0_skip 1000 30 185761 10712529 433 439 443 185749 185753 30 185746 185737 (some row_24) (SearchFacts.query_250 LCMSourcePV.PrimeFacts.prime_185737) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 185761 10712529 433 439 443 185749 185753 32 185748=(some row_24) :=
    choose0_skip 1000 30 185761 10712529 433 439 443 185749 185753 31 185748 185747 (some row_24) (SearchFacts.query_251 LCMSourcePV.PrimeFacts.prime_185747) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 185761 10712529 433 439 443 185753 16 185752=some row_24 :=
    choose1_hit 1000 30 32 185761 10712529 433 439 443 185753 15 185752 185749 row_24 (SearchFacts.query_252 LCMSourcePV.PrimeFacts.prime_185749) c0_0_0
  have hsqrt : Nat.sqrt 185761=431 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 185761+1)=some 433 := by
    rw [hsqrt];exact (SearchFacts.query_4145 LCMSourcePV.PrimeFacts.prime_433)
  exact make_hit 1000 30 32 16 185761 10712529 433 439 443 185753 row_24 h0 (SearchFacts.query_4146 LCMSourcePV.PrimeFacts.prime_439) (SearchFacts.query_4147 LCMSourcePV.PrimeFacts.prime_443) (SearchFacts.query_253 LCMSourcePV.PrimeFacts.prime_185753) c1_0
#print axioms make_24
end LCMSourcePV.Witness.BlockProofs
