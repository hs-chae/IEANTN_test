/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_214 : Block := (Block.mk 3073009 3094080 1759 1777 1783 3072943 3072977 3072983)
theorem make_214 : make 1000 30 32 16 3073009 10712529=some row_214 := by
  have ck_0_2_0 : (Block.mk 3073009 3094080 1759 1777 1783 3072943 3072977 3072983).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1759 LCMSourcePV.PrimeFacts.prime_1777 LCMSourcePV.PrimeFacts.prime_1783 LCMSourcePV.PrimeFacts.prime_3072943 LCMSourcePV.PrimeFacts.prime_3072977 LCMSourcePV.PrimeFacts.prime_3072983
  have sh_0_2_0 : shrink 30 (Block.mk 3073009 3094080 1759 1777 1783 3072943 3072977 3072983)=some row_214 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 3073009 10712529 1759 1777 1783 3072977 3072983 30 3072946=some row_214 :=
    choose0_hit 1000 30 3073009 10712529 1759 1777 1783 3072977 3072983 29 3072946 3072943 row_214 (SearchFacts.query_2236 LCMSourcePV.PrimeFacts.prime_3072943) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 3073009 10712529 1759 1777 1783 3072977 3072983 31 3072958=(some row_214) :=
    choose0_skip 1000 30 3073009 10712529 1759 1777 1783 3072977 3072983 30 3072958 3072947 (some row_214) (SearchFacts.query_2237 LCMSourcePV.PrimeFacts.prime_3072947) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3073009 10712529 1759 1777 1783 3072977 3072983 32 3072976=(some row_214) :=
    choose0_skip 1000 30 3073009 10712529 1759 1777 1783 3072977 3072983 31 3072976 3072959 (some row_214) (SearchFacts.query_2238 LCMSourcePV.PrimeFacts.prime_3072959) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3073009 10712529 1759 1777 1783 3072983 16 3072982=some row_214 :=
    choose1_hit 1000 30 32 3073009 10712529 1759 1777 1783 3072983 15 3072982 3072977 row_214 (SearchFacts.query_2239 LCMSourcePV.PrimeFacts.prime_3072977) c0_0_0
  have hsqrt : Nat.sqrt 3073009=1753 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3073009+1)=some 1759 := by
    rw [hsqrt];exact (SearchFacts.query_4335 LCMSourcePV.PrimeFacts.prime_1759)
  exact make_hit 1000 30 32 16 3073009 10712529 1759 1777 1783 3072983 row_214 h0 (SearchFacts.query_4336 LCMSourcePV.PrimeFacts.prime_1777) (SearchFacts.query_4337 LCMSourcePV.PrimeFacts.prime_1783) (SearchFacts.query_2240 LCMSourcePV.PrimeFacts.prime_3072983) c1_0
#print axioms make_214
end LCMSourcePV.Witness.BlockProofs
