/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_167 : Block := (Block.mk 2042041 2053488 1433 1439 1447 2041997 2042021 2042039)
theorem make_167 : make 1000 30 32 16 2042041 10712529=some row_167 := by
  have ck_0_1_0 : (Block.mk 2042041 2053488 1433 1439 1447 2041997 2042021 2042039).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1433 LCMSourcePV.PrimeFacts.prime_1439 LCMSourcePV.PrimeFacts.prime_1447 LCMSourcePV.PrimeFacts.prime_2041997 LCMSourcePV.PrimeFacts.prime_2042021 LCMSourcePV.PrimeFacts.prime_2042039
  have sh_0_1_0 : shrink 30 (Block.mk 2042041 2053488 1433 1439 1447 2041997 2042021 2042039)=some row_167 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 2042041 10712529 1433 1439 1447 2042021 2042039 31 2042016=some row_167 :=
    choose0_hit 1000 30 2042041 10712529 1433 1439 1447 2042021 2042039 30 2042016 2041997 row_167 (SearchFacts.query_1710 LCMSourcePV.PrimeFacts.prime_2041997) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 2042041 10712529 1433 1439 1447 2042021 2042039 32 2042020=(some row_167) :=
    choose0_skip 1000 30 2042041 10712529 1433 1439 1447 2042021 2042039 31 2042020 2042017 (some row_167) (SearchFacts.query_1711 LCMSourcePV.PrimeFacts.prime_2042017) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2042041 10712529 1433 1439 1447 2042039 16 2042038=some row_167 :=
    choose1_hit 1000 30 32 2042041 10712529 1433 1439 1447 2042039 15 2042038 2042021 row_167 (SearchFacts.query_1712 LCMSourcePV.PrimeFacts.prime_2042021) c0_0_0
  have hsqrt : Nat.sqrt 2042041=1429 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2042041+1)=some 1433 := by
    rw [hsqrt];exact (SearchFacts.query_4288 LCMSourcePV.PrimeFacts.prime_1433)
  exact make_hit 1000 30 32 16 2042041 10712529 1433 1439 1447 2042039 row_167 h0 (SearchFacts.query_4289 LCMSourcePV.PrimeFacts.prime_1439) (SearchFacts.query_4290 LCMSourcePV.PrimeFacts.prime_1447) (SearchFacts.query_1713 LCMSourcePV.PrimeFacts.prime_2042039) c1_0
#print axioms make_167
end LCMSourcePV.Witness.BlockProofs
