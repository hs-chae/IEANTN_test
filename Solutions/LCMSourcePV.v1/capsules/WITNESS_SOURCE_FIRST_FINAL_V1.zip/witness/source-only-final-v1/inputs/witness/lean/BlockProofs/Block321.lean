/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_321 : Block := (Block.mk 6848689 6869640 2621 2633 2647 6848629 6848657 6848659)
theorem make_321 : make 1000 30 32 16 6848689 10712529=some row_321 := by
  have ck_0_0_0 : (Block.mk 6848689 6869640 2621 2633 2647 6848629 6848657 6848659).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2621 LCMSourcePV.PrimeFacts.prime_2633 LCMSourcePV.PrimeFacts.prime_2647 LCMSourcePV.PrimeFacts.prime_6848629 LCMSourcePV.PrimeFacts.prime_6848657 LCMSourcePV.PrimeFacts.prime_6848659
  have sh_0_0_0 : shrink 30 (Block.mk 6848689 6869640 2621 2633 2647 6848629 6848657 6848659)=some row_321 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 6848689 10712529 2621 2633 2647 6848657 6848659 32 6848656=some row_321 :=
    choose0_hit 1000 30 6848689 10712529 2621 2633 2647 6848657 6848659 31 6848656 6848629 row_321 (SearchFacts.query_3275 LCMSourcePV.PrimeFacts.prime_6848629) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 6848689 10712529 2621 2633 2647 6848659 16 6848658=some row_321 :=
    choose1_hit 1000 30 32 6848689 10712529 2621 2633 2647 6848659 15 6848658 6848657 row_321 (SearchFacts.query_3276 LCMSourcePV.PrimeFacts.prime_6848657) c0_0_0
  have hsqrt : Nat.sqrt 6848689=2617 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6848689+1)=some 2621 := by
    rw [hsqrt];exact (SearchFacts.query_4442 LCMSourcePV.PrimeFacts.prime_2621)
  exact make_hit 1000 30 32 16 6848689 10712529 2621 2633 2647 6848659 row_321 h0 (SearchFacts.query_4443 LCMSourcePV.PrimeFacts.prime_2633) (SearchFacts.query_4444 LCMSourcePV.PrimeFacts.prime_2647) (SearchFacts.query_3277 LCMSourcePV.PrimeFacts.prime_6848659) c1_0
#print axioms make_321
end LCMSourcePV.Witness.BlockProofs
