/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_306 : Block := (Block.mk 6086089 6115728 2473 2477 2503 6086029 6086057 6086063)
theorem make_306 : make 1000 30 32 16 6086089 10712529=some row_306 := by
  have ck_0_0_0 : (Block.mk 6086089 6115728 2473 2477 2503 6086029 6086057 6086063).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2473 LCMSourcePV.PrimeFacts.prime_2477 LCMSourcePV.PrimeFacts.prime_2503 LCMSourcePV.PrimeFacts.prime_6086029 LCMSourcePV.PrimeFacts.prime_6086057 LCMSourcePV.PrimeFacts.prime_6086063
  have sh_0_0_0 : shrink 30 (Block.mk 6086089 6115728 2473 2477 2503 6086029 6086057 6086063)=some row_306 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 6086089 10712529 2473 2477 2503 6086057 6086063 32 6086056=some row_306 :=
    choose0_hit 1000 30 6086089 10712529 2473 2477 2503 6086057 6086063 31 6086056 6086029 row_306 (SearchFacts.query_3099 LCMSourcePV.PrimeFacts.prime_6086029) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 6086089 10712529 2473 2477 2503 6086063 16 6086062=some row_306 :=
    choose1_hit 1000 30 32 6086089 10712529 2473 2477 2503 6086063 15 6086062 6086057 row_306 (SearchFacts.query_3100 LCMSourcePV.PrimeFacts.prime_6086057) c0_0_0
  have hsqrt : Nat.sqrt 6086089=2467 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6086089+1)=some 2473 := by
    rw [hsqrt];exact (SearchFacts.query_4427 LCMSourcePV.PrimeFacts.prime_2473)
  exact make_hit 1000 30 32 16 6086089 10712529 2473 2477 2503 6086063 row_306 h0 (SearchFacts.query_4428 LCMSourcePV.PrimeFacts.prime_2477) (SearchFacts.query_4429 LCMSourcePV.PrimeFacts.prime_2503) (SearchFacts.query_3101 LCMSourcePV.PrimeFacts.prime_6086063) c1_0
#print axioms make_306
end LCMSourcePV.Witness.BlockProofs
