/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_309 : Block := (Block.mk 6265009 6355440 2521 2531 2539 6264943 6264997 6265001)
theorem make_309 : make 1000 30 32 16 6265009 10712529=some row_309 := by
  have ck_0_1_0 : (Block.mk 6265009 6355440 2521 2531 2539 6264943 6264997 6265001).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2521 LCMSourcePV.PrimeFacts.prime_2531 LCMSourcePV.PrimeFacts.prime_2539 LCMSourcePV.PrimeFacts.prime_6264943 LCMSourcePV.PrimeFacts.prime_6264997 LCMSourcePV.PrimeFacts.prime_6265001
  have sh_0_1_0 : shrink 30 (Block.mk 6265009 6355440 2521 2531 2539 6264943 6264997 6265001)=some row_309 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 6265009 10712529 2521 2531 2539 6264997 6265001 31 6264982=some row_309 :=
    choose0_hit 1000 30 6265009 10712529 2521 2531 2539 6264997 6265001 30 6264982 6264943 row_309 (SearchFacts.query_3127 LCMSourcePV.PrimeFacts.prime_6264943) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 6265009 10712529 2521 2531 2539 6264997 6265001 32 6264996=(some row_309) :=
    choose0_skip 1000 30 6265009 10712529 2521 2531 2539 6264997 6265001 31 6264996 6264983 (some row_309) (SearchFacts.query_3128 LCMSourcePV.PrimeFacts.prime_6264983) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6265009 10712529 2521 2531 2539 6265001 16 6265000=some row_309 :=
    choose1_hit 1000 30 32 6265009 10712529 2521 2531 2539 6265001 15 6265000 6264997 row_309 (SearchFacts.query_3129 LCMSourcePV.PrimeFacts.prime_6264997) c0_0_0
  have hsqrt : Nat.sqrt 6265009=2503 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6265009+1)=some 2521 := by
    rw [hsqrt];exact (SearchFacts.query_4430 LCMSourcePV.PrimeFacts.prime_2521)
  exact make_hit 1000 30 32 16 6265009 10712529 2521 2531 2539 6265001 row_309 h0 (SearchFacts.query_4431 LCMSourcePV.PrimeFacts.prime_2531) (SearchFacts.query_4432 LCMSourcePV.PrimeFacts.prime_2539) (SearchFacts.query_3130 LCMSourcePV.PrimeFacts.prime_6265001) c1_0
#print axioms make_309
end LCMSourcePV.Witness.BlockProofs
