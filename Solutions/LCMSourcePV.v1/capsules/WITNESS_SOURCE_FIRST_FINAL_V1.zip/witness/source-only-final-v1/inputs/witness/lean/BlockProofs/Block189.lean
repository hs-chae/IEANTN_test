/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_189 : Block := (Block.mk 2468041 2493240 1579 1583 1597 2467979 2468021 2468027)
theorem make_189 : make 1000 30 32 16 2468041 10712529=some row_189 := by
  have ck_0_1_0 : (Block.mk 2468041 2493240 1579 1583 1597 2467979 2468021 2468027).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1579 LCMSourcePV.PrimeFacts.prime_1583 LCMSourcePV.PrimeFacts.prime_1597 LCMSourcePV.PrimeFacts.prime_2467979 LCMSourcePV.PrimeFacts.prime_2468021 LCMSourcePV.PrimeFacts.prime_2468027
  have sh_0_1_0 : shrink 30 (Block.mk 2468041 2493240 1579 1583 1597 2467979 2468021 2468027)=some row_189 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 2468041 10712529 1579 1583 1597 2468021 2468027 31 2467980=some row_189 :=
    choose0_hit 1000 30 2468041 10712529 1579 1583 1597 2468021 2468027 30 2467980 2467979 row_189 (SearchFacts.query_1930 LCMSourcePV.PrimeFacts.prime_2467979) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 2468041 10712529 1579 1583 1597 2468021 2468027 32 2468020=(some row_189) :=
    choose0_skip 1000 30 2468041 10712529 1579 1583 1597 2468021 2468027 31 2468020 2467981 (some row_189) (SearchFacts.query_1931 LCMSourcePV.PrimeFacts.prime_2467981) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2468041 10712529 1579 1583 1597 2468027 16 2468026=some row_189 :=
    choose1_hit 1000 30 32 2468041 10712529 1579 1583 1597 2468027 15 2468026 2468021 row_189 (SearchFacts.query_1932 LCMSourcePV.PrimeFacts.prime_2468021) c0_0_0
  have hsqrt : Nat.sqrt 2468041=1571 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2468041+1)=some 1579 := by
    rw [hsqrt];exact (SearchFacts.query_4310 LCMSourcePV.PrimeFacts.prime_1579)
  exact make_hit 1000 30 32 16 2468041 10712529 1579 1583 1597 2468027 row_189 h0 (SearchFacts.query_4311 LCMSourcePV.PrimeFacts.prime_1583) (SearchFacts.query_4312 LCMSourcePV.PrimeFacts.prime_1597) (SearchFacts.query_1933 LCMSourcePV.PrimeFacts.prime_2468027) c1_0
#print axioms make_189
end LCMSourcePV.Witness.BlockProofs
