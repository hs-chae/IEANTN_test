/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_173 : Block := (Block.mk 2128681 2163840 1471 1481 1483 2128547 2128667 2128669)
theorem make_173 : make 1000 30 32 16 2128681 10712529=some row_173 := by
  have ck_0_9_0 : (Block.mk 2128681 2163840 1471 1481 1483 2128547 2128667 2128669).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1471 LCMSourcePV.PrimeFacts.prime_1481 LCMSourcePV.PrimeFacts.prime_1483 LCMSourcePV.PrimeFacts.prime_2128547 LCMSourcePV.PrimeFacts.prime_2128667 LCMSourcePV.PrimeFacts.prime_2128669
  have sh_0_9_0 : shrink 30 (Block.mk 2128681 2163840 1471 1481 1483 2128547 2128667 2128669)=some row_173 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 23 2128548=some row_173 :=
    choose0_hit 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 22 2128548 2128547 row_173 (SearchFacts.query_1763 LCMSourcePV.PrimeFacts.prime_2128547) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 24 2128558=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 23 2128558 2128549 (some row_173) (SearchFacts.query_1764 LCMSourcePV.PrimeFacts.prime_2128549) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 25 2128560=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 24 2128560 2128559 (some row_173) (SearchFacts.query_1765 LCMSourcePV.PrimeFacts.prime_2128559) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 26 2128590=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 25 2128590 2128561 (some row_173) (SearchFacts.query_1766 LCMSourcePV.PrimeFacts.prime_2128561) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 27 2128600=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 26 2128600 2128591 (some row_173) (SearchFacts.query_1767 LCMSourcePV.PrimeFacts.prime_2128591) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 28 2128602=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 27 2128602 2128601 (some row_173) (SearchFacts.query_1768 LCMSourcePV.PrimeFacts.prime_2128601) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 29 2128630=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 28 2128630 2128603 (some row_173) (SearchFacts.query_1769 LCMSourcePV.PrimeFacts.prime_2128603) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 30 2128648=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 29 2128648 2128631 (some row_173) (SearchFacts.query_1770 LCMSourcePV.PrimeFacts.prime_2128631) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 31 2128662=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 30 2128662 2128649 (some row_173) (SearchFacts.query_1771 LCMSourcePV.PrimeFacts.prime_2128649) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 32 2128666=(some row_173) :=
    choose0_skip 1000 30 2128681 10712529 1471 1481 1483 2128667 2128669 31 2128666 2128663 (some row_173) (SearchFacts.query_1772 LCMSourcePV.PrimeFacts.prime_2128663) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2128681 10712529 1471 1481 1483 2128669 16 2128668=some row_173 :=
    choose1_hit 1000 30 32 2128681 10712529 1471 1481 1483 2128669 15 2128668 2128667 row_173 (SearchFacts.query_1773 LCMSourcePV.PrimeFacts.prime_2128667) c0_0_0
  have hsqrt : Nat.sqrt 2128681=1459 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2128681+1)=some 1471 := by
    rw [hsqrt];exact (SearchFacts.query_4294 LCMSourcePV.PrimeFacts.prime_1471)
  exact make_hit 1000 30 32 16 2128681 10712529 1471 1481 1483 2128669 row_173 h0 (SearchFacts.query_4295 LCMSourcePV.PrimeFacts.prime_1481) (SearchFacts.query_4296 LCMSourcePV.PrimeFacts.prime_1483) (SearchFacts.query_1774 LCMSourcePV.PrimeFacts.prime_2128669) c1_0
#print axioms make_173
end LCMSourcePV.Witness.BlockProofs
