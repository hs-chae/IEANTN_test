/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_230 : Block := (Block.mk 3530641 3568320 1889 1901 1907 3530563 3530623 3530629)
theorem make_230 : make 1000 30 32 16 3530641 10712529=some row_230 := by
  have ck_0_4_0 : (Block.mk 3530641 3568320 1889 1901 1907 3530563 3530623 3530629).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1889 LCMSourcePV.PrimeFacts.prime_1901 LCMSourcePV.PrimeFacts.prime_1907 LCMSourcePV.PrimeFacts.prime_3530563 LCMSourcePV.PrimeFacts.prime_3530623 LCMSourcePV.PrimeFacts.prime_3530629
  have sh_0_4_0 : shrink 30 (Block.mk 3530641 3568320 1889 1901 1907 3530563 3530623 3530629)=some row_230 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 28 3530586=some row_230 :=
    choose0_hit 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 27 3530586 3530563 row_230 (SearchFacts.query_2356 LCMSourcePV.PrimeFacts.prime_3530563) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 29 3530590=(some row_230) :=
    choose0_skip 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 28 3530590 3530587 (some row_230) (SearchFacts.query_2357 LCMSourcePV.PrimeFacts.prime_3530587) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 30 3530602=(some row_230) :=
    choose0_skip 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 29 3530602 3530591 (some row_230) (SearchFacts.query_2358 LCMSourcePV.PrimeFacts.prime_3530591) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 31 3530608=(some row_230) :=
    choose0_skip 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 30 3530608 3530603 (some row_230) (SearchFacts.query_2359 LCMSourcePV.PrimeFacts.prime_3530603) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 32 3530622=(some row_230) :=
    choose0_skip 1000 30 3530641 10712529 1889 1901 1907 3530623 3530629 31 3530622 3530609 (some row_230) (SearchFacts.query_2360 LCMSourcePV.PrimeFacts.prime_3530609) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3530641 10712529 1889 1901 1907 3530629 16 3530628=some row_230 :=
    choose1_hit 1000 30 32 3530641 10712529 1889 1901 1907 3530629 15 3530628 3530623 row_230 (SearchFacts.query_2361 LCMSourcePV.PrimeFacts.prime_3530623) c0_0_0
  have hsqrt : Nat.sqrt 3530641=1879 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3530641+1)=some 1889 := by
    rw [hsqrt];exact (SearchFacts.query_4351 LCMSourcePV.PrimeFacts.prime_1889)
  exact make_hit 1000 30 32 16 3530641 10712529 1889 1901 1907 3530629 row_230 h0 (SearchFacts.query_4352 LCMSourcePV.PrimeFacts.prime_1901) (SearchFacts.query_4353 LCMSourcePV.PrimeFacts.prime_1907) (SearchFacts.query_2362 LCMSourcePV.PrimeFacts.prime_3530629) c1_0
#print axioms make_230
end LCMSourcePV.Witness.BlockProofs
