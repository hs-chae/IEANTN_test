/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_213 : Block := (Block.mk 3052009 3073008 1753 1759 1777 3051623 3051977 3052003)
theorem make_213 : make 1000 30 32 16 3052009 10712529=some row_213 := by
  have ck_0_22_0 : (Block.mk 3052009 3073008 1753 1759 1777 3051623 3051977 3052003).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1753 LCMSourcePV.PrimeFacts.prime_1759 LCMSourcePV.PrimeFacts.prime_1777 LCMSourcePV.PrimeFacts.prime_3051623 LCMSourcePV.PrimeFacts.prime_3051977 LCMSourcePV.PrimeFacts.prime_3052003
  have sh_0_22_0 : shrink 30 (Block.mk 3052009 3073008 1753 1759 1777 3051623 3051977 3052003)=some row_213 := shrink_hit _ _ ck_0_22_0
  have c0_0_22 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 10 3051636=some row_213 :=
    choose0_hit 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 9 3051636 3051623 row_213 (SearchFacts.query_2211 LCMSourcePV.PrimeFacts.prime_3051623) (by decide) sh_0_22_0
  have c0_0_21 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 11 3051676=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 10 3051676 3051637 (some row_213) (SearchFacts.query_2212 LCMSourcePV.PrimeFacts.prime_3051637) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 12 3051688=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 11 3051688 3051677 (some row_213) (SearchFacts.query_2213 LCMSourcePV.PrimeFacts.prime_3051677) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 13 3051702=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 12 3051702 3051689 (some row_213) (SearchFacts.query_2214 LCMSourcePV.PrimeFacts.prime_3051689) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 14 3051706=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 13 3051706 3051703 (some row_213) (SearchFacts.query_2215 LCMSourcePV.PrimeFacts.prime_3051703) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 15 3051742=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 14 3051742 3051707 (some row_213) (SearchFacts.query_2216 LCMSourcePV.PrimeFacts.prime_3051707) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 16 3051748=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 15 3051748 3051743 (some row_213) (SearchFacts.query_2217 LCMSourcePV.PrimeFacts.prime_3051743) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 17 3051750=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 16 3051750 3051749 (some row_213) (SearchFacts.query_2218 LCMSourcePV.PrimeFacts.prime_3051749) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 18 3051766=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 17 3051766 3051751 (some row_213) (SearchFacts.query_2219 LCMSourcePV.PrimeFacts.prime_3051751) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 19 3051772=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 18 3051772 3051767 (some row_213) (SearchFacts.query_2220 LCMSourcePV.PrimeFacts.prime_3051767) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 20 3051778=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 19 3051778 3051773 (some row_213) (SearchFacts.query_2221 LCMSourcePV.PrimeFacts.prime_3051773) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 21 3051820=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 20 3051820 3051779 (some row_213) (SearchFacts.query_2222 LCMSourcePV.PrimeFacts.prime_3051779) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 22 3051832=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 21 3051832 3051821 (some row_213) (SearchFacts.query_2223 LCMSourcePV.PrimeFacts.prime_3051821) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 23 3051862=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 22 3051862 3051833 (some row_213) (SearchFacts.query_2224 LCMSourcePV.PrimeFacts.prime_3051833) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 24 3051868=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 23 3051868 3051863 (some row_213) (SearchFacts.query_2225 LCMSourcePV.PrimeFacts.prime_3051863) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 25 3051876=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 24 3051876 3051869 (some row_213) (SearchFacts.query_2226 LCMSourcePV.PrimeFacts.prime_3051869) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 26 3051888=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 25 3051888 3051877 (some row_213) (SearchFacts.query_2227 LCMSourcePV.PrimeFacts.prime_3051877) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 27 3051900=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 26 3051900 3051889 (some row_213) (SearchFacts.query_2228 LCMSourcePV.PrimeFacts.prime_3051889) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 28 3051928=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 27 3051928 3051901 (some row_213) (SearchFacts.query_2229 LCMSourcePV.PrimeFacts.prime_3051901) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 29 3051942=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 28 3051942 3051929 (some row_213) (SearchFacts.query_2230 LCMSourcePV.PrimeFacts.prime_3051929) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 30 3051946=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 29 3051946 3051943 (some row_213) (SearchFacts.query_2231 LCMSourcePV.PrimeFacts.prime_3051943) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 31 3051952=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 30 3051952 3051947 (some row_213) (SearchFacts.query_2232 LCMSourcePV.PrimeFacts.prime_3051947) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 32 3051976=(some row_213) :=
    choose0_skip 1000 30 3052009 10712529 1753 1759 1777 3051977 3052003 31 3051976 3051953 (some row_213) (SearchFacts.query_2233 LCMSourcePV.PrimeFacts.prime_3051953) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3052009 10712529 1753 1759 1777 3052003 16 3052002=some row_213 :=
    choose1_hit 1000 30 32 3052009 10712529 1753 1759 1777 3052003 15 3052002 3051977 row_213 (SearchFacts.query_2234 LCMSourcePV.PrimeFacts.prime_3051977) c0_0_0
  have hsqrt : Nat.sqrt 3052009=1747 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3052009+1)=some 1753 := by
    rw [hsqrt];exact (SearchFacts.query_4334 LCMSourcePV.PrimeFacts.prime_1753)
  exact make_hit 1000 30 32 16 3052009 10712529 1753 1759 1777 3052003 row_213 h0 (SearchFacts.query_4335 LCMSourcePV.PrimeFacts.prime_1759) (SearchFacts.query_4336 LCMSourcePV.PrimeFacts.prime_1777) (SearchFacts.query_2235 LCMSourcePV.PrimeFacts.prime_3052003) c1_0
#print axioms make_213
end LCMSourcePV.Witness.BlockProofs
