/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_241 : Block := (Block.mk 3948169 3972048 1993 1997 1999 3948073 3948151 3948163)
theorem make_241 : make 1000 30 32 16 3948169 10712529=some row_241 := by
  have ck_0_4_0 : (Block.mk 3948169 3972048 1993 1997 1999 3948073 3948151 3948163).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1993 LCMSourcePV.PrimeFacts.prime_1997 LCMSourcePV.PrimeFacts.prime_1999 LCMSourcePV.PrimeFacts.prime_3948073 LCMSourcePV.PrimeFacts.prime_3948151 LCMSourcePV.PrimeFacts.prime_3948163
  have sh_0_4_0 : shrink 30 (Block.mk 3948169 3972048 1993 1997 1999 3948073 3948151 3948163)=some row_241 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 28 3948100=some row_241 :=
    choose0_hit 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 27 3948100 3948073 row_241 (SearchFacts.query_2444 LCMSourcePV.PrimeFacts.prime_3948073) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 29 3948120=(some row_241) :=
    choose0_skip 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 28 3948120 3948101 (some row_241) (SearchFacts.query_2445 LCMSourcePV.PrimeFacts.prime_3948101) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 30 3948136=(some row_241) :=
    choose0_skip 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 29 3948136 3948121 (some row_241) (SearchFacts.query_2446 LCMSourcePV.PrimeFacts.prime_3948121) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 31 3948148=(some row_241) :=
    choose0_skip 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 30 3948148 3948137 (some row_241) (SearchFacts.query_2447 LCMSourcePV.PrimeFacts.prime_3948137) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 32 3948150=(some row_241) :=
    choose0_skip 1000 30 3948169 10712529 1993 1997 1999 3948151 3948163 31 3948150 3948149 (some row_241) (SearchFacts.query_2448 LCMSourcePV.PrimeFacts.prime_3948149) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3948169 10712529 1993 1997 1999 3948163 16 3948162=some row_241 :=
    choose1_hit 1000 30 32 3948169 10712529 1993 1997 1999 3948163 15 3948162 3948151 row_241 (SearchFacts.query_2449 LCMSourcePV.PrimeFacts.prime_3948151) c0_0_0
  have hsqrt : Nat.sqrt 3948169=1987 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3948169+1)=some 1993 := by
    rw [hsqrt];exact (SearchFacts.query_4362 LCMSourcePV.PrimeFacts.prime_1993)
  exact make_hit 1000 30 32 16 3948169 10712529 1993 1997 1999 3948163 row_241 h0 (SearchFacts.query_4363 LCMSourcePV.PrimeFacts.prime_1997) (SearchFacts.query_4364 LCMSourcePV.PrimeFacts.prime_1999) (SearchFacts.query_2450 LCMSourcePV.PrimeFacts.prime_3948163) c1_0
#print axioms make_241
end LCMSourcePV.Witness.BlockProofs
