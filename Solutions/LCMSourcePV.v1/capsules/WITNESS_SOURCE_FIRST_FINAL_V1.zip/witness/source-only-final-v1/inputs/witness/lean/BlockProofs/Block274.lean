/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_274 : Block := (Block.mk 5013121 5031048 2243 2251 2267 5012971 5013101 5013119)
theorem make_274 : make 1000 30 32 16 5013121 10712529=some row_274 := by
  have ck_0_7_0 : (Block.mk 5013121 5031048 2243 2251 2267 5012971 5013101 5013119).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2243 LCMSourcePV.PrimeFacts.prime_2251 LCMSourcePV.PrimeFacts.prime_2267 LCMSourcePV.PrimeFacts.prime_5012971 LCMSourcePV.PrimeFacts.prime_5013101 LCMSourcePV.PrimeFacts.prime_5013119
  have sh_0_7_0 : shrink 30 (Block.mk 5013121 5031048 2243 2251 2267 5012971 5013101 5013119)=some row_274 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 25 5012980=some row_274 :=
    choose0_hit 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 24 5012980 5012971 row_274 (SearchFacts.query_2775 LCMSourcePV.PrimeFacts.prime_5012971) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 26 5012992=(some row_274) :=
    choose0_skip 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 25 5012992 5012981 (some row_274) (SearchFacts.query_2776 LCMSourcePV.PrimeFacts.prime_5012981) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 27 5012998=(some row_274) :=
    choose0_skip 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 26 5012998 5012993 (some row_274) (SearchFacts.query_2777 LCMSourcePV.PrimeFacts.prime_5012993) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 28 5013022=(some row_274) :=
    choose0_skip 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 27 5013022 5012999 (some row_274) (SearchFacts.query_2778 LCMSourcePV.PrimeFacts.prime_5012999) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 29 5013036=(some row_274) :=
    choose0_skip 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 28 5013036 5013023 (some row_274) (SearchFacts.query_2779 LCMSourcePV.PrimeFacts.prime_5013023) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 30 5013082=(some row_274) :=
    choose0_skip 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 29 5013082 5013037 (some row_274) (SearchFacts.query_2780 LCMSourcePV.PrimeFacts.prime_5013037) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 31 5013088=(some row_274) :=
    choose0_skip 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 30 5013088 5013083 (some row_274) (SearchFacts.query_2781 LCMSourcePV.PrimeFacts.prime_5013083) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 32 5013100=(some row_274) :=
    choose0_skip 1000 30 5013121 10712529 2243 2251 2267 5013101 5013119 31 5013100 5013089 (some row_274) (SearchFacts.query_2782 LCMSourcePV.PrimeFacts.prime_5013089) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5013121 10712529 2243 2251 2267 5013119 16 5013118=some row_274 :=
    choose1_hit 1000 30 32 5013121 10712529 2243 2251 2267 5013119 15 5013118 5013101 row_274 (SearchFacts.query_2783 LCMSourcePV.PrimeFacts.prime_5013101) c0_0_0
  have hsqrt : Nat.sqrt 5013121=2239 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5013121+1)=some 2243 := by
    rw [hsqrt];exact (SearchFacts.query_4395 LCMSourcePV.PrimeFacts.prime_2243)
  exact make_hit 1000 30 32 16 5013121 10712529 2243 2251 2267 5013119 row_274 h0 (SearchFacts.query_4396 LCMSourcePV.PrimeFacts.prime_2251) (SearchFacts.query_4397 LCMSourcePV.PrimeFacts.prime_2267) (SearchFacts.query_2784 LCMSourcePV.PrimeFacts.prime_5013119) c1_0
#print axioms make_274
end LCMSourcePV.Witness.BlockProofs
