/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_300 : Block := (Block.mk 5841889 5870928 2423 2437 2441 5841799 5841859 5841883)
theorem make_300 : make 1000 30 32 16 5841889 10712529=some row_300 := by
  have ck_0_1_0 : (Block.mk 5841889 5870928 2423 2437 2441 5841799 5841859 5841883).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2423 LCMSourcePV.PrimeFacts.prime_2437 LCMSourcePV.PrimeFacts.prime_2441 LCMSourcePV.PrimeFacts.prime_5841799 LCMSourcePV.PrimeFacts.prime_5841859 LCMSourcePV.PrimeFacts.prime_5841883
  have sh_0_1_0 : shrink 30 (Block.mk 5841889 5870928 2423 2437 2441 5841799 5841859 5841883)=some row_300 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 5841889 10712529 2423 2437 2441 5841859 5841883 31 5841820=some row_300 :=
    choose0_hit 1000 30 5841889 10712529 2423 2437 2441 5841859 5841883 30 5841820 5841799 row_300 (SearchFacts.query_3016 LCMSourcePV.PrimeFacts.prime_5841799) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 5841889 10712529 2423 2437 2441 5841859 5841883 32 5841858=(some row_300) :=
    choose0_skip 1000 30 5841889 10712529 2423 2437 2441 5841859 5841883 31 5841858 5841821 (some row_300) (SearchFacts.query_3017 LCMSourcePV.PrimeFacts.prime_5841821) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5841889 10712529 2423 2437 2441 5841883 16 5841882=some row_300 :=
    choose1_hit 1000 30 32 5841889 10712529 2423 2437 2441 5841883 15 5841882 5841859 row_300 (SearchFacts.query_3018 LCMSourcePV.PrimeFacts.prime_5841859) c0_0_0
  have hsqrt : Nat.sqrt 5841889=2417 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5841889+1)=some 2423 := by
    rw [hsqrt];exact (SearchFacts.query_4421 LCMSourcePV.PrimeFacts.prime_2423)
  exact make_hit 1000 30 32 16 5841889 10712529 2423 2437 2441 5841883 row_300 h0 (SearchFacts.query_4422 LCMSourcePV.PrimeFacts.prime_2437) (SearchFacts.query_4423 LCMSourcePV.PrimeFacts.prime_2441) (SearchFacts.query_3019 LCMSourcePV.PrimeFacts.prime_5841883) c1_0
#print axioms make_300
end LCMSourcePV.Witness.BlockProofs
