/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_149 : Block := (Block.mk 1646089 1661520 1289 1291 1297 1645933 1646023 1646033)
theorem make_149 : make 1000 30 32 16 1646089 10712529=some row_149 := by
  have ck_0_7_0 : (Block.mk 1646089 1661520 1289 1291 1297 1645933 1646023 1646033).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1289 LCMSourcePV.PrimeFacts.prime_1291 LCMSourcePV.PrimeFacts.prime_1297 LCMSourcePV.PrimeFacts.prime_1645933 LCMSourcePV.PrimeFacts.prime_1646023 LCMSourcePV.PrimeFacts.prime_1646033
  have sh_0_7_0 : shrink 30 (Block.mk 1646089 1661520 1289 1291 1297 1645933 1646023 1646033)=some row_149 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 25 1645936=some row_149 :=
    choose0_hit 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 24 1645936 1645933 row_149 (SearchFacts.query_1571 LCMSourcePV.PrimeFacts.prime_1645933) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 26 1645938=(some row_149) :=
    choose0_skip 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 25 1645938 1645937 (some row_149) (SearchFacts.query_1572 LCMSourcePV.PrimeFacts.prime_1645937) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 27 1645960=(some row_149) :=
    choose0_skip 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 26 1645960 1645939 (some row_149) (SearchFacts.query_1573 LCMSourcePV.PrimeFacts.prime_1645939) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 28 1645966=(some row_149) :=
    choose0_skip 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 27 1645966 1645961 (some row_149) (SearchFacts.query_1574 LCMSourcePV.PrimeFacts.prime_1645961) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 29 1645978=(some row_149) :=
    choose0_skip 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 28 1645978 1645967 (some row_149) (SearchFacts.query_1575 LCMSourcePV.PrimeFacts.prime_1645967) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 30 1645998=(some row_149) :=
    choose0_skip 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 29 1645998 1645979 (some row_149) (SearchFacts.query_1576 LCMSourcePV.PrimeFacts.prime_1645979) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 31 1646016=(some row_149) :=
    choose0_skip 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 30 1646016 1645999 (some row_149) (SearchFacts.query_1577 LCMSourcePV.PrimeFacts.prime_1645999) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 32 1646022=(some row_149) :=
    choose0_skip 1000 30 1646089 10712529 1289 1291 1297 1646023 1646033 31 1646022 1646017 (some row_149) (SearchFacts.query_1578 LCMSourcePV.PrimeFacts.prime_1646017) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1646089 10712529 1289 1291 1297 1646033 16 1646032=some row_149 :=
    choose1_hit 1000 30 32 1646089 10712529 1289 1291 1297 1646033 15 1646032 1646023 row_149 (SearchFacts.query_1579 LCMSourcePV.PrimeFacts.prime_1646023) c0_0_0
  have hsqrt : Nat.sqrt 1646089=1283 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1646089+1)=some 1289 := by
    rw [hsqrt];exact (SearchFacts.query_4270 LCMSourcePV.PrimeFacts.prime_1289)
  exact make_hit 1000 30 32 16 1646089 10712529 1289 1291 1297 1646033 row_149 h0 (SearchFacts.query_4271 LCMSourcePV.PrimeFacts.prime_1291) (SearchFacts.query_4272 LCMSourcePV.PrimeFacts.prime_1297) (SearchFacts.query_1580 LCMSourcePV.PrimeFacts.prime_1646033) c1_0
#print axioms make_149
end LCMSourcePV.Witness.BlockProofs
