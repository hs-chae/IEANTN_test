/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_142 : Block := (Block.mk 1510441 1515360 1231 1237 1249 1510373 1510427 1510429)
theorem make_142 : make 1000 30 32 16 1510441 10712529=some row_142 := by
  have ck_0_4_0 : (Block.mk 1510441 1515360 1231 1237 1249 1510373 1510427 1510429).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1231 LCMSourcePV.PrimeFacts.prime_1237 LCMSourcePV.PrimeFacts.prime_1249 LCMSourcePV.PrimeFacts.prime_1510373 LCMSourcePV.PrimeFacts.prime_1510427 LCMSourcePV.PrimeFacts.prime_1510429
  have sh_0_4_0 : shrink 30 (Block.mk 1510441 1515360 1231 1237 1249 1510373 1510427 1510429)=some row_142 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 28 1510390=some row_142 :=
    choose0_hit 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 27 1510390 1510373 row_142 (SearchFacts.query_1518 LCMSourcePV.PrimeFacts.prime_1510373) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 29 1510392=(some row_142) :=
    choose0_skip 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 28 1510392 1510391 (some row_142) (SearchFacts.query_1519 LCMSourcePV.PrimeFacts.prime_1510391) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 30 1510416=(some row_142) :=
    choose0_skip 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 29 1510416 1510393 (some row_142) (SearchFacts.query_1520 LCMSourcePV.PrimeFacts.prime_1510393) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 31 1510422=(some row_142) :=
    choose0_skip 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 30 1510422 1510417 (some row_142) (SearchFacts.query_1521 LCMSourcePV.PrimeFacts.prime_1510417) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 32 1510426=(some row_142) :=
    choose0_skip 1000 30 1510441 10712529 1231 1237 1249 1510427 1510429 31 1510426 1510423 (some row_142) (SearchFacts.query_1522 LCMSourcePV.PrimeFacts.prime_1510423) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1510441 10712529 1231 1237 1249 1510429 16 1510428=some row_142 :=
    choose1_hit 1000 30 32 1510441 10712529 1231 1237 1249 1510429 15 1510428 1510427 row_142 (SearchFacts.query_1523 LCMSourcePV.PrimeFacts.prime_1510427) c0_0_0
  have hsqrt : Nat.sqrt 1510441=1229 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1510441+1)=some 1231 := by
    rw [hsqrt];exact (SearchFacts.query_4263 LCMSourcePV.PrimeFacts.prime_1231)
  exact make_hit 1000 30 32 16 1510441 10712529 1231 1237 1249 1510429 row_142 h0 (SearchFacts.query_4264 LCMSourcePV.PrimeFacts.prime_1237) (SearchFacts.query_4265 LCMSourcePV.PrimeFacts.prime_1249) (SearchFacts.query_1524 LCMSourcePV.PrimeFacts.prime_1510429) c1_0
#print axioms make_142
end LCMSourcePV.Witness.BlockProofs
