/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_201 : Block := (Block.mk 2745649 2765568 1663 1667 1669 2745581 2745637 2745643)
theorem make_201 : make 1000 30 32 16 2745649 10712529=some row_201 := by
  have ck_0_1_0 : (Block.mk 2745649 2765568 1663 1667 1669 2745581 2745637 2745643).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1663 LCMSourcePV.PrimeFacts.prime_1667 LCMSourcePV.PrimeFacts.prime_1669 LCMSourcePV.PrimeFacts.prime_2745581 LCMSourcePV.PrimeFacts.prime_2745637 LCMSourcePV.PrimeFacts.prime_2745643
  have sh_0_1_0 : shrink 30 (Block.mk 2745649 2765568 1663 1667 1669 2745581 2745637 2745643)=some row_201 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 2745649 10712529 1663 1667 1669 2745637 2745643 31 2745606=some row_201 :=
    choose0_hit 1000 30 2745649 10712529 1663 1667 1669 2745637 2745643 30 2745606 2745581 row_201 (SearchFacts.query_2054 LCMSourcePV.PrimeFacts.prime_2745581) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 2745649 10712529 1663 1667 1669 2745637 2745643 32 2745636=(some row_201) :=
    choose0_skip 1000 30 2745649 10712529 1663 1667 1669 2745637 2745643 31 2745636 2745607 (some row_201) (SearchFacts.query_2055 LCMSourcePV.PrimeFacts.prime_2745607) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2745649 10712529 1663 1667 1669 2745643 16 2745642=some row_201 :=
    choose1_hit 1000 30 32 2745649 10712529 1663 1667 1669 2745643 15 2745642 2745637 row_201 (SearchFacts.query_2056 LCMSourcePV.PrimeFacts.prime_2745637) c0_0_0
  have hsqrt : Nat.sqrt 2745649=1657 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2745649+1)=some 1663 := by
    rw [hsqrt];exact (SearchFacts.query_4322 LCMSourcePV.PrimeFacts.prime_1663)
  exact make_hit 1000 30 32 16 2745649 10712529 1663 1667 1669 2745643 row_201 h0 (SearchFacts.query_4323 LCMSourcePV.PrimeFacts.prime_1667) (SearchFacts.query_4324 LCMSourcePV.PrimeFacts.prime_1669) (SearchFacts.query_2057 LCMSourcePV.PrimeFacts.prime_2745643) c1_0
#print axioms make_201
end LCMSourcePV.Witness.BlockProofs
