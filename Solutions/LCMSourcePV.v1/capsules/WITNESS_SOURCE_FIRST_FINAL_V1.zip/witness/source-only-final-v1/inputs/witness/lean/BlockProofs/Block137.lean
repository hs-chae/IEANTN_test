/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_137 : Block := (Block.mk 1423249 1442400 1201 1213 1217 1423159 1423237 1423243)
theorem make_137 : make 1000 30 32 16 1423249 10712529=some row_137 := by
  have ck_0_5_0 : (Block.mk 1423249 1442400 1201 1213 1217 1423159 1423237 1423243).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1201 LCMSourcePV.PrimeFacts.prime_1213 LCMSourcePV.PrimeFacts.prime_1217 LCMSourcePV.PrimeFacts.prime_1423159 LCMSourcePV.PrimeFacts.prime_1423237 LCMSourcePV.PrimeFacts.prime_1423243
  have sh_0_5_0 : shrink 30 (Block.mk 1423249 1442400 1201 1213 1217 1423159 1423237 1423243)=some row_137 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 27 1423180=some row_137 :=
    choose0_hit 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 26 1423180 1423159 row_137 (SearchFacts.query_1482 LCMSourcePV.PrimeFacts.prime_1423159) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 28 1423182=(some row_137) :=
    choose0_skip 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 27 1423182 1423181 (some row_137) (SearchFacts.query_1483 LCMSourcePV.PrimeFacts.prime_1423181) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 29 1423186=(some row_137) :=
    choose0_skip 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 28 1423186 1423183 (some row_137) (SearchFacts.query_1484 LCMSourcePV.PrimeFacts.prime_1423183) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 30 1423192=(some row_137) :=
    choose0_skip 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 29 1423192 1423187 (some row_137) (SearchFacts.query_1485 LCMSourcePV.PrimeFacts.prime_1423187) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 31 1423230=(some row_137) :=
    choose0_skip 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 30 1423230 1423193 (some row_137) (SearchFacts.query_1486 LCMSourcePV.PrimeFacts.prime_1423193) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 32 1423236=(some row_137) :=
    choose0_skip 1000 30 1423249 10712529 1201 1213 1217 1423237 1423243 31 1423236 1423231 (some row_137) (SearchFacts.query_1487 LCMSourcePV.PrimeFacts.prime_1423231) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1423249 10712529 1201 1213 1217 1423243 16 1423242=some row_137 :=
    choose1_hit 1000 30 32 1423249 10712529 1201 1213 1217 1423243 15 1423242 1423237 row_137 (SearchFacts.query_1488 LCMSourcePV.PrimeFacts.prime_1423237) c0_0_0
  have hsqrt : Nat.sqrt 1423249=1193 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1423249+1)=some 1201 := by
    rw [hsqrt];exact (SearchFacts.query_4258 LCMSourcePV.PrimeFacts.prime_1201)
  exact make_hit 1000 30 32 16 1423249 10712529 1201 1213 1217 1423243 row_137 h0 (SearchFacts.query_4259 LCMSourcePV.PrimeFacts.prime_1213) (SearchFacts.query_4260 LCMSourcePV.PrimeFacts.prime_1217) (SearchFacts.query_1489 LCMSourcePV.PrimeFacts.prime_1423243) c1_0
#print axioms make_137
end LCMSourcePV.Witness.BlockProofs
