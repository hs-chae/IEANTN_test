/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_144 : Block := (Block.mk 1530169 1560000 1249 1259 1277 1530037 1530149 1530157)
theorem make_144 : make 1000 30 32 16 1530169 10712529=some row_144 := by
  have ck_0_9_0 : (Block.mk 1530169 1560000 1249 1259 1277 1530037 1530149 1530157).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1249 LCMSourcePV.PrimeFacts.prime_1259 LCMSourcePV.PrimeFacts.prime_1277 LCMSourcePV.PrimeFacts.prime_1530037 LCMSourcePV.PrimeFacts.prime_1530149 LCMSourcePV.PrimeFacts.prime_1530157
  have sh_0_9_0 : shrink 30 (Block.mk 1530169 1560000 1249 1259 1277 1530037 1530149 1530157)=some row_144 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 23 1530070=some row_144 :=
    choose0_hit 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 22 1530070 1530037 row_144 (SearchFacts.query_1528 LCMSourcePV.PrimeFacts.prime_1530037) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 24 1530072=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 23 1530072 1530071 (some row_144) (SearchFacts.query_1529 LCMSourcePV.PrimeFacts.prime_1530071) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 25 1530076=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 24 1530076 1530073 (some row_144) (SearchFacts.query_1530 LCMSourcePV.PrimeFacts.prime_1530073) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 26 1530090=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 25 1530090 1530077 (some row_144) (SearchFacts.query_1531 LCMSourcePV.PrimeFacts.prime_1530077) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 27 1530096=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 26 1530096 1530091 (some row_144) (SearchFacts.query_1532 LCMSourcePV.PrimeFacts.prime_1530091) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 28 1530102=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 27 1530102 1530097 (some row_144) (SearchFacts.query_1533 LCMSourcePV.PrimeFacts.prime_1530097) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 29 1530106=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 28 1530106 1530103 (some row_144) (SearchFacts.query_1534 LCMSourcePV.PrimeFacts.prime_1530103) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 30 1530130=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 29 1530130 1530107 (some row_144) (SearchFacts.query_1535 LCMSourcePV.PrimeFacts.prime_1530107) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 31 1530142=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 30 1530142 1530131 (some row_144) (SearchFacts.query_1536 LCMSourcePV.PrimeFacts.prime_1530131) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 32 1530148=(some row_144) :=
    choose0_skip 1000 30 1530169 10712529 1249 1259 1277 1530149 1530157 31 1530148 1530143 (some row_144) (SearchFacts.query_1537 LCMSourcePV.PrimeFacts.prime_1530143) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1530169 10712529 1249 1259 1277 1530157 16 1530156=some row_144 :=
    choose1_hit 1000 30 32 1530169 10712529 1249 1259 1277 1530157 15 1530156 1530149 row_144 (SearchFacts.query_1538 LCMSourcePV.PrimeFacts.prime_1530149) c0_0_0
  have hsqrt : Nat.sqrt 1530169=1237 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1530169+1)=some 1249 := by
    rw [hsqrt];exact (SearchFacts.query_4265 LCMSourcePV.PrimeFacts.prime_1249)
  exact make_hit 1000 30 32 16 1530169 10712529 1249 1259 1277 1530157 row_144 h0 (SearchFacts.query_4266 LCMSourcePV.PrimeFacts.prime_1259) (SearchFacts.query_4267 LCMSourcePV.PrimeFacts.prime_1277) (SearchFacts.query_1539 LCMSourcePV.PrimeFacts.prime_1530157) c1_0
#print axioms make_144
end LCMSourcePV.Witness.BlockProofs
