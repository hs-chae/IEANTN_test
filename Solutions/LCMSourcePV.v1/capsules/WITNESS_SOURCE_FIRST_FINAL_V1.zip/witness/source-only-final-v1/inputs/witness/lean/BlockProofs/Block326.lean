/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_326 : Block := (Block.mk 7070281 7091568 2663 2671 2677 7070213 7070243 7070267)
theorem make_326 : make 1000 30 32 16 7070281 10712529=some row_326 := by
  have ck_0_2_0 : (Block.mk 7070281 7091568 2663 2671 2677 7070213 7070243 7070267).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2663 LCMSourcePV.PrimeFacts.prime_2671 LCMSourcePV.PrimeFacts.prime_2677 LCMSourcePV.PrimeFacts.prime_7070213 LCMSourcePV.PrimeFacts.prime_7070243 LCMSourcePV.PrimeFacts.prime_7070267
  have sh_0_2_0 : shrink 30 (Block.mk 7070281 7091568 2663 2671 2677 7070213 7070243 7070267)=some row_326 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 7070281 10712529 2663 2671 2677 7070243 7070267 30 7070220=some row_326 :=
    choose0_hit 1000 30 7070281 10712529 2663 2671 2677 7070243 7070267 29 7070220 7070213 row_326 (SearchFacts.query_3332 LCMSourcePV.PrimeFacts.prime_7070213) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 7070281 10712529 2663 2671 2677 7070243 7070267 31 7070226=(some row_326) :=
    choose0_skip 1000 30 7070281 10712529 2663 2671 2677 7070243 7070267 30 7070226 7070221 (some row_326) (SearchFacts.query_3333 LCMSourcePV.PrimeFacts.prime_7070221) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 7070281 10712529 2663 2671 2677 7070243 7070267 32 7070242=(some row_326) :=
    choose0_skip 1000 30 7070281 10712529 2663 2671 2677 7070243 7070267 31 7070242 7070227 (some row_326) (SearchFacts.query_3334 LCMSourcePV.PrimeFacts.prime_7070227) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 7070281 10712529 2663 2671 2677 7070267 16 7070266=some row_326 :=
    choose1_hit 1000 30 32 7070281 10712529 2663 2671 2677 7070267 15 7070266 7070243 row_326 (SearchFacts.query_3335 LCMSourcePV.PrimeFacts.prime_7070243) c0_0_0
  have hsqrt : Nat.sqrt 7070281=2659 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 7070281+1)=some 2663 := by
    rw [hsqrt];exact (SearchFacts.query_4447 LCMSourcePV.PrimeFacts.prime_2663)
  exact make_hit 1000 30 32 16 7070281 10712529 2663 2671 2677 7070267 row_326 h0 (SearchFacts.query_4448 LCMSourcePV.PrimeFacts.prime_2671) (SearchFacts.query_4449 LCMSourcePV.PrimeFacts.prime_2677) (SearchFacts.query_3336 LCMSourcePV.PrimeFacts.prime_7070267) c1_0
#print axioms make_326
end LCMSourcePV.Witness.BlockProofs
