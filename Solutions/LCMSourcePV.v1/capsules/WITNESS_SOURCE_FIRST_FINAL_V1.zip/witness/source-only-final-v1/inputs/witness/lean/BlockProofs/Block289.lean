/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_289 : Block := (Block.mk 5508409 5527200 2351 2357 2371 5508229 5508397 5508401)
theorem make_289 : make 1000 30 32 16 5508409 10712529=some row_289 := by
  have ck_0_8_0 : (Block.mk 5508409 5527200 2351 2357 2371 5508229 5508397 5508401).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2351 LCMSourcePV.PrimeFacts.prime_2357 LCMSourcePV.PrimeFacts.prime_2371 LCMSourcePV.PrimeFacts.prime_5508229 LCMSourcePV.PrimeFacts.prime_5508397 LCMSourcePV.PrimeFacts.prime_5508401
  have sh_0_8_0 : shrink 30 (Block.mk 5508409 5527200 2351 2357 2371 5508229 5508397 5508401)=some row_289 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 24 5508240=some row_289 :=
    choose0_hit 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 23 5508240 5508229 row_289 (SearchFacts.query_2916 LCMSourcePV.PrimeFacts.prime_5508229) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 25 5508262=(some row_289) :=
    choose0_skip 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 24 5508262 5508241 (some row_289) (SearchFacts.query_2917 LCMSourcePV.PrimeFacts.prime_5508241) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 26 5508276=(some row_289) :=
    choose0_skip 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 25 5508276 5508263 (some row_289) (SearchFacts.query_2918 LCMSourcePV.PrimeFacts.prime_5508263) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 27 5508286=(some row_289) :=
    choose0_skip 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 26 5508286 5508277 (some row_289) (SearchFacts.query_2919 LCMSourcePV.PrimeFacts.prime_5508277) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 28 5508318=(some row_289) :=
    choose0_skip 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 27 5508318 5508287 (some row_289) (SearchFacts.query_2920 LCMSourcePV.PrimeFacts.prime_5508287) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 29 5508340=(some row_289) :=
    choose0_skip 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 28 5508340 5508319 (some row_289) (SearchFacts.query_2921 LCMSourcePV.PrimeFacts.prime_5508319) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 30 5508378=(some row_289) :=
    choose0_skip 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 29 5508378 5508341 (some row_289) (SearchFacts.query_2922 LCMSourcePV.PrimeFacts.prime_5508341) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 31 5508382=(some row_289) :=
    choose0_skip 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 30 5508382 5508379 (some row_289) (SearchFacts.query_2923 LCMSourcePV.PrimeFacts.prime_5508379) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 32 5508396=(some row_289) :=
    choose0_skip 1000 30 5508409 10712529 2351 2357 2371 5508397 5508401 31 5508396 5508383 (some row_289) (SearchFacts.query_2924 LCMSourcePV.PrimeFacts.prime_5508383) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5508409 10712529 2351 2357 2371 5508401 16 5508400=some row_289 :=
    choose1_hit 1000 30 32 5508409 10712529 2351 2357 2371 5508401 15 5508400 5508397 row_289 (SearchFacts.query_2925 LCMSourcePV.PrimeFacts.prime_5508397) c0_0_0
  have hsqrt : Nat.sqrt 5508409=2347 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5508409+1)=some 2351 := by
    rw [hsqrt];exact (SearchFacts.query_4410 LCMSourcePV.PrimeFacts.prime_2351)
  exact make_hit 1000 30 32 16 5508409 10712529 2351 2357 2371 5508401 row_289 h0 (SearchFacts.query_4411 LCMSourcePV.PrimeFacts.prime_2357) (SearchFacts.query_4412 LCMSourcePV.PrimeFacts.prime_2371) (SearchFacts.query_2926 LCMSourcePV.PrimeFacts.prime_5508401) c1_0
#print axioms make_289
end LCMSourcePV.Witness.BlockProofs
