/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_224 : Block := (Block.mk 3411409 3463320 1861 1867 1871 3411367 3411389 3411391)
theorem make_224 : make 1000 30 32 16 3411409 10712529=some row_224 := by
  have ck_0_1_0 : (Block.mk 3411409 3463320 1861 1867 1871 3411367 3411389 3411391).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1861 LCMSourcePV.PrimeFacts.prime_1867 LCMSourcePV.PrimeFacts.prime_1871 LCMSourcePV.PrimeFacts.prime_3411367 LCMSourcePV.PrimeFacts.prime_3411389 LCMSourcePV.PrimeFacts.prime_3411391
  have sh_0_1_0 : shrink 30 (Block.mk 3411409 3463320 1861 1867 1871 3411367 3411389 3411391)=some row_224 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 3411409 10712529 1861 1867 1871 3411389 3411391 31 3411376=some row_224 :=
    choose0_hit 1000 30 3411409 10712529 1861 1867 1871 3411389 3411391 30 3411376 3411367 row_224 (SearchFacts.query_2331 LCMSourcePV.PrimeFacts.prime_3411367) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 3411409 10712529 1861 1867 1871 3411389 3411391 32 3411388=(some row_224) :=
    choose0_skip 1000 30 3411409 10712529 1861 1867 1871 3411389 3411391 31 3411388 3411377 (some row_224) (SearchFacts.query_2332 LCMSourcePV.PrimeFacts.prime_3411377) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3411409 10712529 1861 1867 1871 3411391 16 3411390=some row_224 :=
    choose1_hit 1000 30 32 3411409 10712529 1861 1867 1871 3411391 15 3411390 3411389 row_224 (SearchFacts.query_2333 LCMSourcePV.PrimeFacts.prime_3411389) c0_0_0
  have hsqrt : Nat.sqrt 3411409=1847 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3411409+1)=some 1861 := by
    rw [hsqrt];exact (SearchFacts.query_4345 LCMSourcePV.PrimeFacts.prime_1861)
  exact make_hit 1000 30 32 16 3411409 10712529 1861 1867 1871 3411391 row_224 h0 (SearchFacts.query_4346 LCMSourcePV.PrimeFacts.prime_1867) (SearchFacts.query_4347 LCMSourcePV.PrimeFacts.prime_1871) (SearchFacts.query_2334 LCMSourcePV.PrimeFacts.prime_3411391) c1_0
#print axioms make_224
end LCMSourcePV.Witness.BlockProofs
