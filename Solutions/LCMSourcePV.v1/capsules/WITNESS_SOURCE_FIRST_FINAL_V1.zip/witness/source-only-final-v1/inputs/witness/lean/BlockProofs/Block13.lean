/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_13 : Block := (Block.mk 128881 134688 367 373 379 128833 128873 128879)
theorem make_13 : make 1000 30 32 16 128881 10712529=some row_13 := by
  have ck_0_3_0 : (Block.mk 128881 134688 367 373 379 128833 128873 128879).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_367 LCMSourcePV.PrimeFacts.prime_373 LCMSourcePV.PrimeFacts.prime_379 LCMSourcePV.PrimeFacts.prime_128833 LCMSourcePV.PrimeFacts.prime_128873 LCMSourcePV.PrimeFacts.prime_128879
  have sh_0_3_0 : shrink 30 (Block.mk 128881 134688 367 373 379 128833 128873 128879)=some row_13 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 128881 10712529 367 373 379 128873 128879 29 128836=some row_13 :=
    choose0_hit 1000 30 128881 10712529 367 373 379 128873 128879 28 128836 128833 row_13 (SearchFacts.query_98 LCMSourcePV.PrimeFacts.prime_128833) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 128881 10712529 367 373 379 128873 128879 30 128856=(some row_13) :=
    choose0_skip 1000 30 128881 10712529 367 373 379 128873 128879 29 128856 128837 (some row_13) (SearchFacts.query_99 LCMSourcePV.PrimeFacts.prime_128837) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 128881 10712529 367 373 379 128873 128879 31 128860=(some row_13) :=
    choose0_skip 1000 30 128881 10712529 367 373 379 128873 128879 30 128860 128857 (some row_13) (SearchFacts.query_100 LCMSourcePV.PrimeFacts.prime_128857) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 128881 10712529 367 373 379 128873 128879 32 128872=(some row_13) :=
    choose0_skip 1000 30 128881 10712529 367 373 379 128873 128879 31 128872 128861 (some row_13) (SearchFacts.query_101 LCMSourcePV.PrimeFacts.prime_128861) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 128881 10712529 367 373 379 128879 16 128878=some row_13 :=
    choose1_hit 1000 30 32 128881 10712529 367 373 379 128879 15 128878 128873 row_13 (SearchFacts.query_102 LCMSourcePV.PrimeFacts.prime_128873) c0_0_0
  have hsqrt : Nat.sqrt 128881=359 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 128881+1)=some 367 := by
    rw [hsqrt];exact (SearchFacts.query_4134 LCMSourcePV.PrimeFacts.prime_367)
  exact make_hit 1000 30 32 16 128881 10712529 367 373 379 128879 row_13 h0 (SearchFacts.query_4135 LCMSourcePV.PrimeFacts.prime_373) (SearchFacts.query_4136 LCMSourcePV.PrimeFacts.prime_379) (SearchFacts.query_103 LCMSourcePV.PrimeFacts.prime_128879) c1_0
#print axioms make_13
end LCMSourcePV.Witness.BlockProofs
