/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_185 : Block := (Block.mk 2399401 2411808 1553 1559 1567 2399039 2399389 2399399)
theorem make_185 : make 1000 30 32 16 2399401 10712529=some row_185 := by
  have ck_0_23_0 : (Block.mk 2399401 2411808 1553 1559 1567 2399039 2399389 2399399).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1553 LCMSourcePV.PrimeFacts.prime_1559 LCMSourcePV.PrimeFacts.prime_1567 LCMSourcePV.PrimeFacts.prime_2399039 LCMSourcePV.PrimeFacts.prime_2399389 LCMSourcePV.PrimeFacts.prime_2399399
  have sh_0_23_0 : shrink 30 (Block.mk 2399401 2411808 1553 1559 1567 2399039 2399389 2399399)=some row_185 := shrink_hit _ _ ck_0_23_0
  have c0_0_23 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 9 2399040=some row_185 :=
    choose0_hit 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 8 2399040 2399039 row_185 (SearchFacts.query_1879 LCMSourcePV.PrimeFacts.prime_2399039) (by decide) sh_0_23_0
  have c0_0_22 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 10 2399080=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 9 2399080 2399041 (some row_185) (SearchFacts.query_1880 LCMSourcePV.PrimeFacts.prime_2399041) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 11 2399086=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 10 2399086 2399081 (some row_185) (SearchFacts.query_1881 LCMSourcePV.PrimeFacts.prime_2399081) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 12 2399092=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 11 2399092 2399087 (some row_185) (SearchFacts.query_1882 LCMSourcePV.PrimeFacts.prime_2399087) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 13 2399112=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 12 2399112 2399093 (some row_185) (SearchFacts.query_1883 LCMSourcePV.PrimeFacts.prime_2399093) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 14 2399118=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 13 2399118 2399113 (some row_185) (SearchFacts.query_1884 LCMSourcePV.PrimeFacts.prime_2399113) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 15 2399128=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 14 2399128 2399119 (some row_185) (SearchFacts.query_1885 LCMSourcePV.PrimeFacts.prime_2399119) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 16 2399142=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 15 2399142 2399129 (some row_185) (SearchFacts.query_1886 LCMSourcePV.PrimeFacts.prime_2399129) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 17 2399166=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 16 2399166 2399143 (some row_185) (SearchFacts.query_1887 LCMSourcePV.PrimeFacts.prime_2399143) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 18 2399170=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 17 2399170 2399167 (some row_185) (SearchFacts.query_1888 LCMSourcePV.PrimeFacts.prime_2399167) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 19 2399206=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 18 2399206 2399171 (some row_185) (SearchFacts.query_1889 LCMSourcePV.PrimeFacts.prime_2399171) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 20 2399212=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 19 2399212 2399207 (some row_185) (SearchFacts.query_1890 LCMSourcePV.PrimeFacts.prime_2399207) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 21 2399230=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 20 2399230 2399213 (some row_185) (SearchFacts.query_1891 LCMSourcePV.PrimeFacts.prime_2399213) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 22 2399236=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 21 2399236 2399231 (some row_185) (SearchFacts.query_1892 LCMSourcePV.PrimeFacts.prime_2399231) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 23 2399248=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 22 2399248 2399237 (some row_185) (SearchFacts.query_1893 LCMSourcePV.PrimeFacts.prime_2399237) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 24 2399272=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 23 2399272 2399249 (some row_185) (SearchFacts.query_1894 LCMSourcePV.PrimeFacts.prime_2399249) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 25 2399296=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 24 2399296 2399273 (some row_185) (SearchFacts.query_1895 LCMSourcePV.PrimeFacts.prime_2399273) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 26 2399316=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 25 2399316 2399297 (some row_185) (SearchFacts.query_1896 LCMSourcePV.PrimeFacts.prime_2399297) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 27 2399322=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 26 2399322 2399317 (some row_185) (SearchFacts.query_1897 LCMSourcePV.PrimeFacts.prime_2399317) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 28 2399332=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 27 2399332 2399323 (some row_185) (SearchFacts.query_1898 LCMSourcePV.PrimeFacts.prime_2399323) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 29 2399358=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 28 2399358 2399333 (some row_185) (SearchFacts.query_1899 LCMSourcePV.PrimeFacts.prime_2399333) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 30 2399380=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 29 2399380 2399359 (some row_185) (SearchFacts.query_1900 LCMSourcePV.PrimeFacts.prime_2399359) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 31 2399386=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 30 2399386 2399381 (some row_185) (SearchFacts.query_1901 LCMSourcePV.PrimeFacts.prime_2399381) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 32 2399388=(some row_185) :=
    choose0_skip 1000 30 2399401 10712529 1553 1559 1567 2399389 2399399 31 2399388 2399387 (some row_185) (SearchFacts.query_1902 LCMSourcePV.PrimeFacts.prime_2399387) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2399401 10712529 1553 1559 1567 2399399 16 2399398=some row_185 :=
    choose1_hit 1000 30 32 2399401 10712529 1553 1559 1567 2399399 15 2399398 2399389 row_185 (SearchFacts.query_1903 LCMSourcePV.PrimeFacts.prime_2399389) c0_0_0
  have hsqrt : Nat.sqrt 2399401=1549 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2399401+1)=some 1553 := by
    rw [hsqrt];exact (SearchFacts.query_4306 LCMSourcePV.PrimeFacts.prime_1553)
  exact make_hit 1000 30 32 16 2399401 10712529 1553 1559 1567 2399399 row_185 h0 (SearchFacts.query_4307 LCMSourcePV.PrimeFacts.prime_1559) (SearchFacts.query_4308 LCMSourcePV.PrimeFacts.prime_1567) (SearchFacts.query_1904 LCMSourcePV.PrimeFacts.prime_2399399) c1_0
#print axioms make_185
end LCMSourcePV.Witness.BlockProofs
