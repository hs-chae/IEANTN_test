/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_193 : Block := (Block.mk 2563201 2582448 1607 1609 1613 2562907 2563193 2563199)
theorem make_193 : make 1000 30 32 16 2563201 10712529=some row_193 := by
  have ck_0_20_0 : (Block.mk 2563201 2582448 1607 1609 1613 2562907 2563193 2563199).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1607 LCMSourcePV.PrimeFacts.prime_1609 LCMSourcePV.PrimeFacts.prime_1613 LCMSourcePV.PrimeFacts.prime_2562907 LCMSourcePV.PrimeFacts.prime_2563193 LCMSourcePV.PrimeFacts.prime_2563199
  have sh_0_20_0 : shrink 30 (Block.mk 2563201 2582448 1607 1609 1613 2562907 2563193 2563199)=some row_193 := shrink_hit _ _ ck_0_20_0
  have c0_0_20 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 12 2562940=some row_193 :=
    choose0_hit 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 11 2562940 2562907 row_193 (SearchFacts.query_1976 LCMSourcePV.PrimeFacts.prime_2562907) (by decide) sh_0_20_0
  have c0_0_19 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 13 2562942=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 12 2562942 2562941 (some row_193) (SearchFacts.query_1977 LCMSourcePV.PrimeFacts.prime_2562941) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 14 2562946=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 13 2562946 2562943 (some row_193) (SearchFacts.query_1978 LCMSourcePV.PrimeFacts.prime_2562943) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 15 2562976=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 14 2562976 2562947 (some row_193) (SearchFacts.query_1979 LCMSourcePV.PrimeFacts.prime_2562947) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 16 2562978=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 15 2562978 2562977 (some row_193) (SearchFacts.query_1980 LCMSourcePV.PrimeFacts.prime_2562977) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 17 2562982=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 16 2562982 2562979 (some row_193) (SearchFacts.query_1981 LCMSourcePV.PrimeFacts.prime_2562979) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 18 2563002=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 17 2563002 2562983 (some row_193) (SearchFacts.query_1982 LCMSourcePV.PrimeFacts.prime_2562983) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 19 2563006=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 18 2563006 2563003 (some row_193) (SearchFacts.query_1983 LCMSourcePV.PrimeFacts.prime_2563003) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 20 2563008=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 19 2563008 2563007 (some row_193) (SearchFacts.query_1984 LCMSourcePV.PrimeFacts.prime_2563007) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 21 2563012=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 20 2563012 2563009 (some row_193) (SearchFacts.query_1985 LCMSourcePV.PrimeFacts.prime_2563009) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 22 2563062=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 21 2563062 2563013 (some row_193) (SearchFacts.query_1986 LCMSourcePV.PrimeFacts.prime_2563013) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 23 2563078=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 22 2563078 2563063 (some row_193) (SearchFacts.query_1987 LCMSourcePV.PrimeFacts.prime_2563063) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 24 2563086=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 23 2563086 2563079 (some row_193) (SearchFacts.query_1988 LCMSourcePV.PrimeFacts.prime_2563079) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 25 2563108=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 24 2563108 2563087 (some row_193) (SearchFacts.query_1989 LCMSourcePV.PrimeFacts.prime_2563087) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 26 2563116=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 25 2563116 2563109 (some row_193) (SearchFacts.query_1990 LCMSourcePV.PrimeFacts.prime_2563109) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 27 2563138=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 26 2563138 2563117 (some row_193) (SearchFacts.query_1991 LCMSourcePV.PrimeFacts.prime_2563117) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 28 2563146=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 27 2563146 2563139 (some row_193) (SearchFacts.query_1992 LCMSourcePV.PrimeFacts.prime_2563139) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 29 2563150=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 28 2563150 2563147 (some row_193) (SearchFacts.query_1993 LCMSourcePV.PrimeFacts.prime_2563147) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 30 2563152=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 29 2563152 2563151 (some row_193) (SearchFacts.query_1994 LCMSourcePV.PrimeFacts.prime_2563151) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 31 2563180=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 30 2563180 2563153 (some row_193) (SearchFacts.query_1995 LCMSourcePV.PrimeFacts.prime_2563153) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 32 2563192=(some row_193) :=
    choose0_skip 1000 30 2563201 10712529 1607 1609 1613 2563193 2563199 31 2563192 2563181 (some row_193) (SearchFacts.query_1996 LCMSourcePV.PrimeFacts.prime_2563181) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2563201 10712529 1607 1609 1613 2563199 16 2563198=some row_193 :=
    choose1_hit 1000 30 32 2563201 10712529 1607 1609 1613 2563199 15 2563198 2563193 row_193 (SearchFacts.query_1997 LCMSourcePV.PrimeFacts.prime_2563193) c0_0_0
  have hsqrt : Nat.sqrt 2563201=1601 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2563201+1)=some 1607 := by
    rw [hsqrt];exact (SearchFacts.query_4314 LCMSourcePV.PrimeFacts.prime_1607)
  exact make_hit 1000 30 32 16 2563201 10712529 1607 1609 1613 2563199 row_193 h0 (SearchFacts.query_4315 LCMSourcePV.PrimeFacts.prime_1609) (SearchFacts.query_4316 LCMSourcePV.PrimeFacts.prime_1613) (SearchFacts.query_1998 LCMSourcePV.PrimeFacts.prime_2563199) c1_0
#print axioms make_193
end LCMSourcePV.Witness.BlockProofs
