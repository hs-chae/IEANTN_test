/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_113 : Block := (Block.mk 1042441 1062960 1031 1033 1039 1042333 1042427 1042439)
theorem make_113 : make 1000 30 32 16 1042441 10712529=some row_113 := by
  have ck_0_5_0 : (Block.mk 1042441 1062960 1031 1033 1039 1042333 1042427 1042439).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1031 LCMSourcePV.PrimeFacts.prime_1033 LCMSourcePV.PrimeFacts.prime_1039 LCMSourcePV.PrimeFacts.prime_1042333 LCMSourcePV.PrimeFacts.prime_1042427 LCMSourcePV.PrimeFacts.prime_1042439
  have sh_0_5_0 : shrink 30 (Block.mk 1042441 1062960 1031 1033 1039 1042333 1042427 1042439)=some row_113 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 27 1042356=some row_113 :=
    choose0_hit 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 26 1042356 1042333 row_113 (SearchFacts.query_1165 LCMSourcePV.PrimeFacts.prime_1042333) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 28 1042368=(some row_113) :=
    choose0_skip 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 27 1042368 1042357 (some row_113) (SearchFacts.query_1166 LCMSourcePV.PrimeFacts.prime_1042357) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 29 1042372=(some row_113) :=
    choose0_skip 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 28 1042372 1042369 (some row_113) (SearchFacts.query_1167 LCMSourcePV.PrimeFacts.prime_1042369) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 30 1042380=(some row_113) :=
    choose0_skip 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 29 1042380 1042373 (some row_113) (SearchFacts.query_1168 LCMSourcePV.PrimeFacts.prime_1042373) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 31 1042398=(some row_113) :=
    choose0_skip 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 30 1042398 1042381 (some row_113) (SearchFacts.query_1169 LCMSourcePV.PrimeFacts.prime_1042381) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 32 1042426=(some row_113) :=
    choose0_skip 1000 30 1042441 10712529 1031 1033 1039 1042427 1042439 31 1042426 1042399 (some row_113) (SearchFacts.query_1170 LCMSourcePV.PrimeFacts.prime_1042399) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1042441 10712529 1031 1033 1039 1042439 16 1042438=some row_113 :=
    choose1_hit 1000 30 32 1042441 10712529 1031 1033 1039 1042439 15 1042438 1042427 row_113 (SearchFacts.query_1171 LCMSourcePV.PrimeFacts.prime_1042427) c0_0_0
  have hsqrt : Nat.sqrt 1042441=1021 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1042441+1)=some 1031 := by
    rw [hsqrt];exact (SearchFacts.query_4234 LCMSourcePV.PrimeFacts.prime_1031)
  exact make_hit 1000 30 32 16 1042441 10712529 1031 1033 1039 1042439 row_113 h0 (SearchFacts.query_4235 LCMSourcePV.PrimeFacts.prime_1033) (SearchFacts.query_4236 LCMSourcePV.PrimeFacts.prime_1039) (SearchFacts.query_1172 LCMSourcePV.PrimeFacts.prime_1042439) c1_0
#print axioms make_113
end LCMSourcePV.Witness.BlockProofs
