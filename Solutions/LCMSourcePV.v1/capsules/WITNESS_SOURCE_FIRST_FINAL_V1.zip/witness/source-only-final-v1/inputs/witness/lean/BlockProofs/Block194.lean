/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_194 : Block := (Block.mk 2582449 2588880 1609 1613 1619 2582399 2582441 2582443)
theorem make_194 : make 1000 30 32 16 2582449 10712529=some row_194 := by
  have ck_0_2_0 : (Block.mk 2582449 2588880 1609 1613 1619 2582399 2582441 2582443).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1609 LCMSourcePV.PrimeFacts.prime_1613 LCMSourcePV.PrimeFacts.prime_1619 LCMSourcePV.PrimeFacts.prime_2582399 LCMSourcePV.PrimeFacts.prime_2582441 LCMSourcePV.PrimeFacts.prime_2582443
  have sh_0_2_0 : shrink 30 (Block.mk 2582449 2588880 1609 1613 1619 2582399 2582441 2582443)=some row_194 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 2582449 10712529 1609 1613 1619 2582441 2582443 30 2582400=some row_194 :=
    choose0_hit 1000 30 2582449 10712529 1609 1613 1619 2582441 2582443 29 2582400 2582399 row_194 (SearchFacts.query_1999 LCMSourcePV.PrimeFacts.prime_2582399) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 2582449 10712529 1609 1613 1619 2582441 2582443 31 2582406=(some row_194) :=
    choose0_skip 1000 30 2582449 10712529 1609 1613 1619 2582441 2582443 30 2582406 2582401 (some row_194) (SearchFacts.query_2000 LCMSourcePV.PrimeFacts.prime_2582401) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2582449 10712529 1609 1613 1619 2582441 2582443 32 2582440=(some row_194) :=
    choose0_skip 1000 30 2582449 10712529 1609 1613 1619 2582441 2582443 31 2582440 2582407 (some row_194) (SearchFacts.query_2001 LCMSourcePV.PrimeFacts.prime_2582407) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2582449 10712529 1609 1613 1619 2582443 16 2582442=some row_194 :=
    choose1_hit 1000 30 32 2582449 10712529 1609 1613 1619 2582443 15 2582442 2582441 row_194 (SearchFacts.query_2002 LCMSourcePV.PrimeFacts.prime_2582441) c0_0_0
  have hsqrt : Nat.sqrt 2582449=1607 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2582449+1)=some 1609 := by
    rw [hsqrt];exact (SearchFacts.query_4315 LCMSourcePV.PrimeFacts.prime_1609)
  exact make_hit 1000 30 32 16 2582449 10712529 1609 1613 1619 2582443 row_194 h0 (SearchFacts.query_4316 LCMSourcePV.PrimeFacts.prime_1613) (SearchFacts.query_4317 LCMSourcePV.PrimeFacts.prime_1619) (SearchFacts.query_2003 LCMSourcePV.PrimeFacts.prime_2582443) c1_0
#print axioms make_194
end LCMSourcePV.Witness.BlockProofs
