/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_29 : Block := (Block.mk 208849 212520 461 463 467 208673 208837 208843)
theorem make_29 : make 1000 30 32 16 208849 10712529=some row_29 := by
  have ck_0_10_0 : (Block.mk 208849 212520 461 463 467 208673 208837 208843).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_461 LCMSourcePV.PrimeFacts.prime_463 LCMSourcePV.PrimeFacts.prime_467 LCMSourcePV.PrimeFacts.prime_208673 LCMSourcePV.PrimeFacts.prime_208837 LCMSourcePV.PrimeFacts.prime_208843
  have sh_0_10_0 : shrink 30 (Block.mk 208849 212520 461 463 467 208673 208837 208843)=some row_29 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 22 208686=some row_29 :=
    choose0_hit 1000 30 208849 10712529 461 463 467 208837 208843 21 208686 208673 row_29 (SearchFacts.query_288 LCMSourcePV.PrimeFacts.prime_208673) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 23 208696=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 22 208696 208687 (some row_29) (SearchFacts.query_289 LCMSourcePV.PrimeFacts.prime_208687) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 24 208698=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 23 208698 208697 (some row_29) (SearchFacts.query_290 LCMSourcePV.PrimeFacts.prime_208697) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 25 208720=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 24 208720 208699 (some row_29) (SearchFacts.query_291 LCMSourcePV.PrimeFacts.prime_208699) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 26 208728=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 25 208728 208721 (some row_29) (SearchFacts.query_292 LCMSourcePV.PrimeFacts.prime_208721) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 27 208738=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 26 208738 208729 (some row_29) (SearchFacts.query_293 LCMSourcePV.PrimeFacts.prime_208729) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 28 208758=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 27 208758 208739 (some row_29) (SearchFacts.query_294 LCMSourcePV.PrimeFacts.prime_208739) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 29 208786=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 28 208786 208759 (some row_29) (SearchFacts.query_295 LCMSourcePV.PrimeFacts.prime_208759) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 30 208798=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 29 208798 208787 (some row_29) (SearchFacts.query_296 LCMSourcePV.PrimeFacts.prime_208787) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 31 208806=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 30 208806 208799 (some row_29) (SearchFacts.query_297 LCMSourcePV.PrimeFacts.prime_208799) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 208849 10712529 461 463 467 208837 208843 32 208836=(some row_29) :=
    choose0_skip 1000 30 208849 10712529 461 463 467 208837 208843 31 208836 208807 (some row_29) (SearchFacts.query_298 LCMSourcePV.PrimeFacts.prime_208807) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 208849 10712529 461 463 467 208843 16 208842=some row_29 :=
    choose1_hit 1000 30 32 208849 10712529 461 463 467 208843 15 208842 208837 row_29 (SearchFacts.query_299 LCMSourcePV.PrimeFacts.prime_208837) c0_0_0
  have hsqrt : Nat.sqrt 208849=457 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 208849+1)=some 461 := by
    rw [hsqrt];exact (SearchFacts.query_4150 LCMSourcePV.PrimeFacts.prime_461)
  exact make_hit 1000 30 32 16 208849 10712529 461 463 467 208843 row_29 h0 (SearchFacts.query_4151 LCMSourcePV.PrimeFacts.prime_463) (SearchFacts.query_4152 LCMSourcePV.PrimeFacts.prime_467) (SearchFacts.query_300 LCMSourcePV.PrimeFacts.prime_208843) c1_0
#print axioms make_29
end LCMSourcePV.Witness.BlockProofs
