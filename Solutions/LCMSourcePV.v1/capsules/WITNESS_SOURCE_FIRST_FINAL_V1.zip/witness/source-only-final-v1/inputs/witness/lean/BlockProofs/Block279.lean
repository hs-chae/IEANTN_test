/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_279 : Block := (Block.mk 5166529 5202960 2281 2287 2293 5166449 5166481 5166527)
theorem make_279 : make 1000 30 32 16 5166529 10712529=some row_279 := by
  have ck_0_0_0 : (Block.mk 5166529 5202960 2281 2287 2293 5166449 5166481 5166527).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2281 LCMSourcePV.PrimeFacts.prime_2287 LCMSourcePV.PrimeFacts.prime_2293 LCMSourcePV.PrimeFacts.prime_5166449 LCMSourcePV.PrimeFacts.prime_5166481 LCMSourcePV.PrimeFacts.prime_5166527
  have sh_0_0_0 : shrink 30 (Block.mk 5166529 5202960 2281 2287 2293 5166449 5166481 5166527)=some row_279 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 5166529 10712529 2281 2287 2293 5166481 5166527 32 5166480=some row_279 :=
    choose0_hit 1000 30 5166529 10712529 2281 2287 2293 5166481 5166527 31 5166480 5166449 row_279 (SearchFacts.query_2822 LCMSourcePV.PrimeFacts.prime_5166449) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 5166529 10712529 2281 2287 2293 5166527 16 5166526=some row_279 :=
    choose1_hit 1000 30 32 5166529 10712529 2281 2287 2293 5166527 15 5166526 5166481 row_279 (SearchFacts.query_2823 LCMSourcePV.PrimeFacts.prime_5166481) c0_0_0
  have hsqrt : Nat.sqrt 5166529=2273 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5166529+1)=some 2281 := by
    rw [hsqrt];exact (SearchFacts.query_4400 LCMSourcePV.PrimeFacts.prime_2281)
  exact make_hit 1000 30 32 16 5166529 10712529 2281 2287 2293 5166527 row_279 h0 (SearchFacts.query_4401 LCMSourcePV.PrimeFacts.prime_2287) (SearchFacts.query_4402 LCMSourcePV.PrimeFacts.prime_2293) (SearchFacts.query_2824 LCMSourcePV.PrimeFacts.prime_5166527) c1_0
#print axioms make_279
end LCMSourcePV.Witness.BlockProofs
