/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_276 : Block := (Block.mk 5067001 5139288 2267 2269 2273 5066881 5066987 5066993)
theorem make_276 : make 1000 30 32 16 5067001 10712529=some row_276 := by
  have ck_0_4_0 : (Block.mk 5067001 5139288 2267 2269 2273 5066881 5066987 5066993).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2267 LCMSourcePV.PrimeFacts.prime_2269 LCMSourcePV.PrimeFacts.prime_2273 LCMSourcePV.PrimeFacts.prime_5066881 LCMSourcePV.PrimeFacts.prime_5066987 LCMSourcePV.PrimeFacts.prime_5066993
  have sh_0_4_0 : shrink 30 (Block.mk 5067001 5139288 2267 2269 2273 5066881 5066987 5066993)=some row_276 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 28 5066920=some row_276 :=
    choose0_hit 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 27 5066920 5066881 row_276 (SearchFacts.query_2797 LCMSourcePV.PrimeFacts.prime_5066881) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 29 5066926=(some row_276) :=
    choose0_skip 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 28 5066926 5066921 (some row_276) (SearchFacts.query_2798 LCMSourcePV.PrimeFacts.prime_5066921) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 30 5066932=(some row_276) :=
    choose0_skip 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 29 5066932 5066927 (some row_276) (SearchFacts.query_2799 LCMSourcePV.PrimeFacts.prime_5066927) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 31 5066950=(some row_276) :=
    choose0_skip 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 30 5066950 5066933 (some row_276) (SearchFacts.query_2800 LCMSourcePV.PrimeFacts.prime_5066933) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 32 5066986=(some row_276) :=
    choose0_skip 1000 30 5067001 10712529 2267 2269 2273 5066987 5066993 31 5066986 5066951 (some row_276) (SearchFacts.query_2801 LCMSourcePV.PrimeFacts.prime_5066951) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5067001 10712529 2267 2269 2273 5066993 16 5066992=some row_276 :=
    choose1_hit 1000 30 32 5067001 10712529 2267 2269 2273 5066993 15 5066992 5066987 row_276 (SearchFacts.query_2802 LCMSourcePV.PrimeFacts.prime_5066987) c0_0_0
  have hsqrt : Nat.sqrt 5067001=2251 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5067001+1)=some 2267 := by
    rw [hsqrt];exact (SearchFacts.query_4397 LCMSourcePV.PrimeFacts.prime_2267)
  exact make_hit 1000 30 32 16 5067001 10712529 2267 2269 2273 5066993 row_276 h0 (SearchFacts.query_4398 LCMSourcePV.PrimeFacts.prime_2269) (SearchFacts.query_4399 LCMSourcePV.PrimeFacts.prime_2273) (SearchFacts.query_2803 LCMSourcePV.PrimeFacts.prime_5066993) c1_0
#print axioms make_276
end LCMSourcePV.Witness.BlockProofs
