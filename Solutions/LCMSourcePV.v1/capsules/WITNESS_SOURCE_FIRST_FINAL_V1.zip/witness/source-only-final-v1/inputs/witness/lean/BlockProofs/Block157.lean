/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_157 : Block := (Block.mk 1745041 1760928 1327 1361 1367 1744819 1745011 1745039)
theorem make_157 : make 1000 30 32 16 1745041 10712529=some row_157 := by
  have ck_0_7_0 : (Block.mk 1745041 1760928 1327 1361 1367 1744819 1745011 1745039).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1327 LCMSourcePV.PrimeFacts.prime_1361 LCMSourcePV.PrimeFacts.prime_1367 LCMSourcePV.PrimeFacts.prime_1744819 LCMSourcePV.PrimeFacts.prime_1745011 LCMSourcePV.PrimeFacts.prime_1745039
  have sh_0_7_0 : shrink 30 (Block.mk 1745041 1760928 1327 1361 1367 1744819 1745011 1745039)=some row_157 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 25 1744858=some row_157 :=
    choose0_hit 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 24 1744858 1744819 row_157 (SearchFacts.query_1633 LCMSourcePV.PrimeFacts.prime_1744819) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 26 1744870=(some row_157) :=
    choose0_skip 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 25 1744870 1744859 (some row_157) (SearchFacts.query_1634 LCMSourcePV.PrimeFacts.prime_1744859) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 27 1744876=(some row_157) :=
    choose0_skip 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 26 1744876 1744871 (some row_157) (SearchFacts.query_1635 LCMSourcePV.PrimeFacts.prime_1744871) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 28 1744890=(some row_157) :=
    choose0_skip 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 27 1744890 1744877 (some row_157) (SearchFacts.query_1636 LCMSourcePV.PrimeFacts.prime_1744877) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 29 1744926=(some row_157) :=
    choose0_skip 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 28 1744926 1744891 (some row_157) (SearchFacts.query_1637 LCMSourcePV.PrimeFacts.prime_1744891) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 30 1744990=(some row_157) :=
    choose0_skip 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 29 1744990 1744927 (some row_157) (SearchFacts.query_1638 LCMSourcePV.PrimeFacts.prime_1744927) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 31 1744992=(some row_157) :=
    choose0_skip 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 30 1744992 1744991 (some row_157) (SearchFacts.query_1639 LCMSourcePV.PrimeFacts.prime_1744991) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 32 1745010=(some row_157) :=
    choose0_skip 1000 30 1745041 10712529 1327 1361 1367 1745011 1745039 31 1745010 1744993 (some row_157) (SearchFacts.query_1640 LCMSourcePV.PrimeFacts.prime_1744993) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1745041 10712529 1327 1361 1367 1745039 16 1745038=some row_157 :=
    choose1_hit 1000 30 32 1745041 10712529 1327 1361 1367 1745039 15 1745038 1745011 row_157 (SearchFacts.query_1641 LCMSourcePV.PrimeFacts.prime_1745011) c0_0_0
  have hsqrt : Nat.sqrt 1745041=1321 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1745041+1)=some 1327 := by
    rw [hsqrt];exact (SearchFacts.query_4278 LCMSourcePV.PrimeFacts.prime_1327)
  exact make_hit 1000 30 32 16 1745041 10712529 1327 1361 1367 1745039 row_157 h0 (SearchFacts.query_4279 LCMSourcePV.PrimeFacts.prime_1361) (SearchFacts.query_4280 LCMSourcePV.PrimeFacts.prime_1367) (SearchFacts.query_1642 LCMSourcePV.PrimeFacts.prime_1745039) c1_0
#print axioms make_157
end LCMSourcePV.Witness.BlockProofs
