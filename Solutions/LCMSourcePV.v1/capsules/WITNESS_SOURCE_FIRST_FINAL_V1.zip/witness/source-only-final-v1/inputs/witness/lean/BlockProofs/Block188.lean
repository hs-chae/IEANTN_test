/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_188 : Block := (Block.mk 2455489 2468040 1571 1579 1583 2455471 2455477 2455487)
theorem make_188 : make 1000 30 32 16 2455489 10712529=some row_188 := by
  have ck_0_0_0 : (Block.mk 2455489 2468040 1571 1579 1583 2455471 2455477 2455487).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1571 LCMSourcePV.PrimeFacts.prime_1579 LCMSourcePV.PrimeFacts.prime_1583 LCMSourcePV.PrimeFacts.prime_2455471 LCMSourcePV.PrimeFacts.prime_2455477 LCMSourcePV.PrimeFacts.prime_2455487
  have sh_0_0_0 : shrink 30 (Block.mk 2455489 2468040 1571 1579 1583 2455471 2455477 2455487)=some row_188 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 2455489 10712529 1571 1579 1583 2455477 2455487 32 2455476=some row_188 :=
    choose0_hit 1000 30 2455489 10712529 1571 1579 1583 2455477 2455487 31 2455476 2455471 row_188 (SearchFacts.query_1927 LCMSourcePV.PrimeFacts.prime_2455471) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 2455489 10712529 1571 1579 1583 2455487 16 2455486=some row_188 :=
    choose1_hit 1000 30 32 2455489 10712529 1571 1579 1583 2455487 15 2455486 2455477 row_188 (SearchFacts.query_1928 LCMSourcePV.PrimeFacts.prime_2455477) c0_0_0
  have hsqrt : Nat.sqrt 2455489=1567 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2455489+1)=some 1571 := by
    rw [hsqrt];exact (SearchFacts.query_4309 LCMSourcePV.PrimeFacts.prime_1571)
  exact make_hit 1000 30 32 16 2455489 10712529 1571 1579 1583 2455487 row_188 h0 (SearchFacts.query_4310 LCMSourcePV.PrimeFacts.prime_1579) (SearchFacts.query_4311 LCMSourcePV.PrimeFacts.prime_1583) (SearchFacts.query_1929 LCMSourcePV.PrimeFacts.prime_2455487) c1_0
#print axioms make_188
end LCMSourcePV.Witness.BlockProofs
