/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_26 : Block := (Block.mk 192721 196248 443 449 457 192581 192677 192697)
theorem make_26 : make 1000 30 32 16 192721 10712529=some row_26 := by
  have ck_0_10_0 : (Block.mk 192721 196248 443 449 457 192581 192677 192697).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_443 LCMSourcePV.PrimeFacts.prime_449 LCMSourcePV.PrimeFacts.prime_457 LCMSourcePV.PrimeFacts.prime_192581 LCMSourcePV.PrimeFacts.prime_192677 LCMSourcePV.PrimeFacts.prime_192697
  have sh_0_10_0 : shrink 30 (Block.mk 192721 196248 443 449 457 192581 192677 192697)=some row_26 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 22 192582=some row_26 :=
    choose0_hit 1000 30 192721 10712529 443 449 457 192677 192697 21 192582 192581 row_26 (SearchFacts.query_259 LCMSourcePV.PrimeFacts.prime_192581) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 23 192586=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 22 192586 192583 (some row_26) (SearchFacts.query_260 LCMSourcePV.PrimeFacts.prime_192583) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 24 192600=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 23 192600 192587 (some row_26) (SearchFacts.query_261 LCMSourcePV.PrimeFacts.prime_192587) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 25 192610=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 24 192610 192601 (some row_26) (SearchFacts.query_262 LCMSourcePV.PrimeFacts.prime_192601) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 26 192612=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 25 192612 192611 (some row_26) (SearchFacts.query_263 LCMSourcePV.PrimeFacts.prime_192611) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 27 192616=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 26 192616 192613 (some row_26) (SearchFacts.query_264 LCMSourcePV.PrimeFacts.prime_192613) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 28 192628=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 27 192628 192617 (some row_26) (SearchFacts.query_265 LCMSourcePV.PrimeFacts.prime_192617) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 29 192630=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 28 192630 192629 (some row_26) (SearchFacts.query_266 LCMSourcePV.PrimeFacts.prime_192629) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 30 192636=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 29 192636 192631 (some row_26) (SearchFacts.query_267 LCMSourcePV.PrimeFacts.prime_192631) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 31 192666=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 30 192666 192637 (some row_26) (SearchFacts.query_268 LCMSourcePV.PrimeFacts.prime_192637) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 192721 10712529 443 449 457 192677 192697 32 192676=(some row_26) :=
    choose0_skip 1000 30 192721 10712529 443 449 457 192677 192697 31 192676 192667 (some row_26) (SearchFacts.query_269 LCMSourcePV.PrimeFacts.prime_192667) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 192721 10712529 443 449 457 192697 16 192696=some row_26 :=
    choose1_hit 1000 30 32 192721 10712529 443 449 457 192697 15 192696 192677 row_26 (SearchFacts.query_270 LCMSourcePV.PrimeFacts.prime_192677) c0_0_0
  have hsqrt : Nat.sqrt 192721=439 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 192721+1)=some 443 := by
    rw [hsqrt];exact (SearchFacts.query_4147 LCMSourcePV.PrimeFacts.prime_443)
  exact make_hit 1000 30 32 16 192721 10712529 443 449 457 192697 row_26 h0 (SearchFacts.query_4148 LCMSourcePV.PrimeFacts.prime_449) (SearchFacts.query_4149 LCMSourcePV.PrimeFacts.prime_457) (SearchFacts.query_271 LCMSourcePV.PrimeFacts.prime_192697) c1_0
#print axioms make_26
end LCMSourcePV.Witness.BlockProofs
