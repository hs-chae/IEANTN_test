/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_183 : Block := (Block.mk 2343961 2380848 1543 1549 1553 2343857 2343917 2343949)
theorem make_183 : make 1000 30 32 16 2343961 10712529=some row_183 := by
  have ck_0_4_0 : (Block.mk 2343961 2380848 1543 1549 1553 2343857 2343917 2343949).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1543 LCMSourcePV.PrimeFacts.prime_1549 LCMSourcePV.PrimeFacts.prime_1553 LCMSourcePV.PrimeFacts.prime_2343857 LCMSourcePV.PrimeFacts.prime_2343917 LCMSourcePV.PrimeFacts.prime_2343949
  have sh_0_4_0 : shrink 30 (Block.mk 2343961 2380848 1543 1549 1553 2343857 2343917 2343949)=some row_183 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 28 2343880=some row_183 :=
    choose0_hit 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 27 2343880 2343857 row_183 (SearchFacts.query_1859 LCMSourcePV.PrimeFacts.prime_2343857) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 29 2343882=(some row_183) :=
    choose0_skip 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 28 2343882 2343881 (some row_183) (SearchFacts.query_1860 LCMSourcePV.PrimeFacts.prime_2343881) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 30 2343888=(some row_183) :=
    choose0_skip 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 29 2343888 2343883 (some row_183) (SearchFacts.query_1861 LCMSourcePV.PrimeFacts.prime_2343883) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 31 2343898=(some row_183) :=
    choose0_skip 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 30 2343898 2343889 (some row_183) (SearchFacts.query_1862 LCMSourcePV.PrimeFacts.prime_2343889) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 32 2343916=(some row_183) :=
    choose0_skip 1000 30 2343961 10712529 1543 1549 1553 2343917 2343949 31 2343916 2343899 (some row_183) (SearchFacts.query_1863 LCMSourcePV.PrimeFacts.prime_2343899) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2343961 10712529 1543 1549 1553 2343949 16 2343948=some row_183 :=
    choose1_hit 1000 30 32 2343961 10712529 1543 1549 1553 2343949 15 2343948 2343917 row_183 (SearchFacts.query_1864 LCMSourcePV.PrimeFacts.prime_2343917) c0_0_0
  have hsqrt : Nat.sqrt 2343961=1531 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2343961+1)=some 1543 := by
    rw [hsqrt];exact (SearchFacts.query_4304 LCMSourcePV.PrimeFacts.prime_1543)
  exact make_hit 1000 30 32 16 2343961 10712529 1543 1549 1553 2343949 row_183 h0 (SearchFacts.query_4305 LCMSourcePV.PrimeFacts.prime_1549) (SearchFacts.query_4306 LCMSourcePV.PrimeFacts.prime_1553) (SearchFacts.query_1865 LCMSourcePV.PrimeFacts.prime_2343949) c1_0
#print axioms make_183
end LCMSourcePV.Witness.BlockProofs
