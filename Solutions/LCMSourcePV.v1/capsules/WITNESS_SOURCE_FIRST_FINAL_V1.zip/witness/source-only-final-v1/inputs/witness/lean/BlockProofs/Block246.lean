/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_246 : Block := (Block.mk 4044121 4068288 2017 2027 2029 4044041 4044049 4044077)
theorem make_246 : make 1000 30 32 16 4044121 10712529=some row_246 := by
  have ck_0_0_0 : (Block.mk 4044121 4068288 2017 2027 2029 4044041 4044049 4044077).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2017 LCMSourcePV.PrimeFacts.prime_2027 LCMSourcePV.PrimeFacts.prime_2029 LCMSourcePV.PrimeFacts.prime_4044041 LCMSourcePV.PrimeFacts.prime_4044049 LCMSourcePV.PrimeFacts.prime_4044077
  have sh_0_0_0 : shrink 30 (Block.mk 4044121 4068288 2017 2027 2029 4044041 4044049 4044077)=some row_246 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 4044121 10712529 2017 2027 2029 4044049 4044077 32 4044048=some row_246 :=
    choose0_hit 1000 30 4044121 10712529 2017 2027 2029 4044049 4044077 31 4044048 4044041 row_246 (SearchFacts.query_2518 LCMSourcePV.PrimeFacts.prime_4044041) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 4044121 10712529 2017 2027 2029 4044077 16 4044076=some row_246 :=
    choose1_hit 1000 30 32 4044121 10712529 2017 2027 2029 4044077 15 4044076 4044049 row_246 (SearchFacts.query_2519 LCMSourcePV.PrimeFacts.prime_4044049) c0_0_0
  have hsqrt : Nat.sqrt 4044121=2011 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4044121+1)=some 2017 := by
    rw [hsqrt];exact (SearchFacts.query_4367 LCMSourcePV.PrimeFacts.prime_2017)
  exact make_hit 1000 30 32 16 4044121 10712529 2017 2027 2029 4044077 row_246 h0 (SearchFacts.query_4368 LCMSourcePV.PrimeFacts.prime_2027) (SearchFacts.query_4369 LCMSourcePV.PrimeFacts.prime_2029) (SearchFacts.query_2520 LCMSourcePV.PrimeFacts.prime_4044077) c1_0
#print axioms make_246
end LCMSourcePV.Witness.BlockProofs
