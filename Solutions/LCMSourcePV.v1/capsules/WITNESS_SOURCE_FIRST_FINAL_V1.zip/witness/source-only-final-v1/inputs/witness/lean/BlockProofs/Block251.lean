/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_251 : Block := (Block.mk 4214809 4255968 2063 2069 2081 4214761 4214779 4214807)
theorem make_251 : make 1000 30 32 16 4214809 10712529=some row_251 := by
  have ck_0_0_0 : (Block.mk 4214809 4255968 2063 2069 2081 4214761 4214779 4214807).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2063 LCMSourcePV.PrimeFacts.prime_2069 LCMSourcePV.PrimeFacts.prime_2081 LCMSourcePV.PrimeFacts.prime_4214761 LCMSourcePV.PrimeFacts.prime_4214779 LCMSourcePV.PrimeFacts.prime_4214807
  have sh_0_0_0 : shrink 30 (Block.mk 4214809 4255968 2063 2069 2081 4214761 4214779 4214807)=some row_251 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 4214809 10712529 2063 2069 2081 4214779 4214807 32 4214778=some row_251 :=
    choose0_hit 1000 30 4214809 10712529 2063 2069 2081 4214779 4214807 31 4214778 4214761 row_251 (SearchFacts.query_2571 LCMSourcePV.PrimeFacts.prime_4214761) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 4214809 10712529 2063 2069 2081 4214807 16 4214806=some row_251 :=
    choose1_hit 1000 30 32 4214809 10712529 2063 2069 2081 4214807 15 4214806 4214779 row_251 (SearchFacts.query_2572 LCMSourcePV.PrimeFacts.prime_4214779) c0_0_0
  have hsqrt : Nat.sqrt 4214809=2053 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4214809+1)=some 2063 := by
    rw [hsqrt];exact (SearchFacts.query_4372 LCMSourcePV.PrimeFacts.prime_2063)
  exact make_hit 1000 30 32 16 4214809 10712529 2063 2069 2081 4214807 row_251 h0 (SearchFacts.query_4373 LCMSourcePV.PrimeFacts.prime_2069) (SearchFacts.query_4374 LCMSourcePV.PrimeFacts.prime_2081) (SearchFacts.query_2573 LCMSourcePV.PrimeFacts.prime_4214807) c1_0
#print axioms make_251
end LCMSourcePV.Witness.BlockProofs
