/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_236 : Block := (Block.mk 3736489 3798600 1949 1951 1973 3736423 3736471 3736477)
theorem make_236 : make 1000 30 32 16 3736489 10712529=some row_236 := by
  have ck_0_1_0 : (Block.mk 3736489 3798600 1949 1951 1973 3736423 3736471 3736477).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1949 LCMSourcePV.PrimeFacts.prime_1951 LCMSourcePV.PrimeFacts.prime_1973 LCMSourcePV.PrimeFacts.prime_3736423 LCMSourcePV.PrimeFacts.prime_3736471 LCMSourcePV.PrimeFacts.prime_3736477
  have sh_0_1_0 : shrink 30 (Block.mk 3736489 3798600 1949 1951 1973 3736423 3736471 3736477)=some row_236 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 3736489 10712529 1949 1951 1973 3736471 3736477 31 3736428=some row_236 :=
    choose0_hit 1000 30 3736489 10712529 1949 1951 1973 3736471 3736477 30 3736428 3736423 row_236 (SearchFacts.query_2415 LCMSourcePV.PrimeFacts.prime_3736423) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 3736489 10712529 1949 1951 1973 3736471 3736477 32 3736470=(some row_236) :=
    choose0_skip 1000 30 3736489 10712529 1949 1951 1973 3736471 3736477 31 3736470 3736429 (some row_236) (SearchFacts.query_2416 LCMSourcePV.PrimeFacts.prime_3736429) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3736489 10712529 1949 1951 1973 3736477 16 3736476=some row_236 :=
    choose1_hit 1000 30 32 3736489 10712529 1949 1951 1973 3736477 15 3736476 3736471 row_236 (SearchFacts.query_2417 LCMSourcePV.PrimeFacts.prime_3736471) c0_0_0
  have hsqrt : Nat.sqrt 3736489=1933 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3736489+1)=some 1949 := by
    rw [hsqrt];exact (SearchFacts.query_4357 LCMSourcePV.PrimeFacts.prime_1949)
  exact make_hit 1000 30 32 16 3736489 10712529 1949 1951 1973 3736477 row_236 h0 (SearchFacts.query_4358 LCMSourcePV.PrimeFacts.prime_1951) (SearchFacts.query_4359 LCMSourcePV.PrimeFacts.prime_1973) (SearchFacts.query_2418 LCMSourcePV.PrimeFacts.prime_3736477) c1_0
#print axioms make_236
end LCMSourcePV.Witness.BlockProofs
