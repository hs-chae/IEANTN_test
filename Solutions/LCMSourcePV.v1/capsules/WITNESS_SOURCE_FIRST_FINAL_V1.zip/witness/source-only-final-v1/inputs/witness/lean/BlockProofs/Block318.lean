/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_318 : Block := (Block.mk 6713281 6723648 2593 2609 2617 6713257 6713261 6713279)
theorem make_318 : make 1000 30 32 16 6713281 10712529=some row_318 := by
  have ck_0_0_0 : (Block.mk 6713281 6723648 2593 2609 2617 6713257 6713261 6713279).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2593 LCMSourcePV.PrimeFacts.prime_2609 LCMSourcePV.PrimeFacts.prime_2617 LCMSourcePV.PrimeFacts.prime_6713257 LCMSourcePV.PrimeFacts.prime_6713261 LCMSourcePV.PrimeFacts.prime_6713279
  have sh_0_0_0 : shrink 30 (Block.mk 6713281 6723648 2593 2609 2617 6713257 6713261 6713279)=some row_318 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 6713281 10712529 2593 2609 2617 6713261 6713279 32 6713260=some row_318 :=
    choose0_hit 1000 30 6713281 10712529 2593 2609 2617 6713261 6713279 31 6713260 6713257 row_318 (SearchFacts.query_3249 LCMSourcePV.PrimeFacts.prime_6713257) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 6713281 10712529 2593 2609 2617 6713279 16 6713278=some row_318 :=
    choose1_hit 1000 30 32 6713281 10712529 2593 2609 2617 6713279 15 6713278 6713261 row_318 (SearchFacts.query_3250 LCMSourcePV.PrimeFacts.prime_6713261) c0_0_0
  have hsqrt : Nat.sqrt 6713281=2591 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6713281+1)=some 2593 := by
    rw [hsqrt];exact (SearchFacts.query_4439 LCMSourcePV.PrimeFacts.prime_2593)
  exact make_hit 1000 30 32 16 6713281 10712529 2593 2609 2617 6713279 row_318 h0 (SearchFacts.query_4440 LCMSourcePV.PrimeFacts.prime_2609) (SearchFacts.query_4441 LCMSourcePV.PrimeFacts.prime_2617) (SearchFacts.query_3251 LCMSourcePV.PrimeFacts.prime_6713279) c1_0
#print axioms make_318
end LCMSourcePV.Witness.BlockProofs
