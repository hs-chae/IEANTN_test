/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_15 : Block := (Block.mk 139129 143640 379 383 389 139067 139121 139123)
theorem make_15 : make 1000 30 32 16 139129 10712529=some row_15 := by
  have ck_0_3_0 : (Block.mk 139129 143640 379 383 389 139067 139121 139123).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_379 LCMSourcePV.PrimeFacts.prime_383 LCMSourcePV.PrimeFacts.prime_389 LCMSourcePV.PrimeFacts.prime_139067 LCMSourcePV.PrimeFacts.prime_139121 LCMSourcePV.PrimeFacts.prime_139123
  have sh_0_3_0 : shrink 30 (Block.mk 139129 143640 379 383 389 139067 139121 139123)=some row_15 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 139129 10712529 379 383 389 139121 139123 29 139078=some row_15 :=
    choose0_hit 1000 30 139129 10712529 379 383 389 139121 139123 28 139078 139067 row_15 (SearchFacts.query_107 LCMSourcePV.PrimeFacts.prime_139067) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 139129 10712529 379 383 389 139121 139123 30 139090=(some row_15) :=
    choose0_skip 1000 30 139129 10712529 379 383 389 139121 139123 29 139090 139079 (some row_15) (SearchFacts.query_108 LCMSourcePV.PrimeFacts.prime_139079) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 139129 10712529 379 383 389 139121 139123 31 139108=(some row_15) :=
    choose0_skip 1000 30 139129 10712529 379 383 389 139121 139123 30 139108 139091 (some row_15) (SearchFacts.query_109 LCMSourcePV.PrimeFacts.prime_139091) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 139129 10712529 379 383 389 139121 139123 32 139120=(some row_15) :=
    choose0_skip 1000 30 139129 10712529 379 383 389 139121 139123 31 139120 139109 (some row_15) (SearchFacts.query_110 LCMSourcePV.PrimeFacts.prime_139109) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 139129 10712529 379 383 389 139123 16 139122=some row_15 :=
    choose1_hit 1000 30 32 139129 10712529 379 383 389 139123 15 139122 139121 row_15 (SearchFacts.query_111 LCMSourcePV.PrimeFacts.prime_139121) c0_0_0
  have hsqrt : Nat.sqrt 139129=373 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 139129+1)=some 379 := by
    rw [hsqrt];exact (SearchFacts.query_4136 LCMSourcePV.PrimeFacts.prime_379)
  exact make_hit 1000 30 32 16 139129 10712529 379 383 389 139123 row_15 h0 (SearchFacts.query_4137 LCMSourcePV.PrimeFacts.prime_383) (SearchFacts.query_4138 LCMSourcePV.PrimeFacts.prime_389) (SearchFacts.query_112 LCMSourcePV.PrimeFacts.prime_139123) c1_0
#print axioms make_15
end LCMSourcePV.Witness.BlockProofs
