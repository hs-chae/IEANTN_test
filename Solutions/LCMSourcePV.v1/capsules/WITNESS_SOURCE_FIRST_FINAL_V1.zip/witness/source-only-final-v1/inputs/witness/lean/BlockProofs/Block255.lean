/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_255 : Block := (Block.mk 4338889 4355568 2087 2089 2099 4338811 4338871 4338883)
theorem make_255 : make 1000 30 32 16 4338889 10712529=some row_255 := by
  have ck_0_2_0 : (Block.mk 4338889 4355568 2087 2089 2099 4338811 4338871 4338883).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2087 LCMSourcePV.PrimeFacts.prime_2089 LCMSourcePV.PrimeFacts.prime_2099 LCMSourcePV.PrimeFacts.prime_4338811 LCMSourcePV.PrimeFacts.prime_4338871 LCMSourcePV.PrimeFacts.prime_4338883
  have sh_0_2_0 : shrink 30 (Block.mk 4338889 4355568 2087 2089 2099 4338811 4338871 4338883)=some row_255 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 4338889 10712529 2087 2089 2099 4338871 4338883 30 4338822=some row_255 :=
    choose0_hit 1000 30 4338889 10712529 2087 2089 2099 4338871 4338883 29 4338822 4338811 row_255 (SearchFacts.query_2594 LCMSourcePV.PrimeFacts.prime_4338811) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 4338889 10712529 2087 2089 2099 4338871 4338883 31 4338846=(some row_255) :=
    choose0_skip 1000 30 4338889 10712529 2087 2089 2099 4338871 4338883 30 4338846 4338823 (some row_255) (SearchFacts.query_2595 LCMSourcePV.PrimeFacts.prime_4338823) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4338889 10712529 2087 2089 2099 4338871 4338883 32 4338870=(some row_255) :=
    choose0_skip 1000 30 4338889 10712529 2087 2089 2099 4338871 4338883 31 4338870 4338847 (some row_255) (SearchFacts.query_2596 LCMSourcePV.PrimeFacts.prime_4338847) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4338889 10712529 2087 2089 2099 4338883 16 4338882=some row_255 :=
    choose1_hit 1000 30 32 4338889 10712529 2087 2089 2099 4338883 15 4338882 4338871 row_255 (SearchFacts.query_2597 LCMSourcePV.PrimeFacts.prime_4338871) c0_0_0
  have hsqrt : Nat.sqrt 4338889=2083 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4338889+1)=some 2087 := by
    rw [hsqrt];exact (SearchFacts.query_4376 LCMSourcePV.PrimeFacts.prime_2087)
  exact make_hit 1000 30 32 16 4338889 10712529 2087 2089 2099 4338883 row_255 h0 (SearchFacts.query_4377 LCMSourcePV.PrimeFacts.prime_2089) (SearchFacts.query_4378 LCMSourcePV.PrimeFacts.prime_2099) (SearchFacts.query_2598 LCMSourcePV.PrimeFacts.prime_4338883) c1_0
#print axioms make_255
end LCMSourcePV.Witness.BlockProofs
