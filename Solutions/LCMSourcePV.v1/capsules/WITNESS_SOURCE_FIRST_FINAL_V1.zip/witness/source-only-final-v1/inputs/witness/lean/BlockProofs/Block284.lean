/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_284 : Block := (Block.mk 5331481 5340720 2311 2333 2339 5331439 5331467 5331479)
theorem make_284 : make 1000 30 32 16 5331481 10712529=some row_284 := by
  have ck_0_2_0 : (Block.mk 5331481 5340720 2311 2333 2339 5331439 5331467 5331479).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2311 LCMSourcePV.PrimeFacts.prime_2333 LCMSourcePV.PrimeFacts.prime_2339 LCMSourcePV.PrimeFacts.prime_5331439 LCMSourcePV.PrimeFacts.prime_5331467 LCMSourcePV.PrimeFacts.prime_5331479
  have sh_0_2_0 : shrink 30 (Block.mk 5331481 5340720 2311 2333 2339 5331439 5331467 5331479)=some row_284 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 5331481 10712529 2311 2333 2339 5331467 5331479 30 5331450=some row_284 :=
    choose0_hit 1000 30 5331481 10712529 2311 2333 2339 5331467 5331479 29 5331450 5331439 row_284 (SearchFacts.query_2857 LCMSourcePV.PrimeFacts.prime_5331439) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 5331481 10712529 2311 2333 2339 5331467 5331479 31 5331462=(some row_284) :=
    choose0_skip 1000 30 5331481 10712529 2311 2333 2339 5331467 5331479 30 5331462 5331451 (some row_284) (SearchFacts.query_2858 LCMSourcePV.PrimeFacts.prime_5331451) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5331481 10712529 2311 2333 2339 5331467 5331479 32 5331466=(some row_284) :=
    choose0_skip 1000 30 5331481 10712529 2311 2333 2339 5331467 5331479 31 5331466 5331463 (some row_284) (SearchFacts.query_2859 LCMSourcePV.PrimeFacts.prime_5331463) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5331481 10712529 2311 2333 2339 5331479 16 5331478=some row_284 :=
    choose1_hit 1000 30 32 5331481 10712529 2311 2333 2339 5331479 15 5331478 5331467 row_284 (SearchFacts.query_2860 LCMSourcePV.PrimeFacts.prime_5331467) c0_0_0
  have hsqrt : Nat.sqrt 5331481=2309 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5331481+1)=some 2311 := by
    rw [hsqrt];exact (SearchFacts.query_4405 LCMSourcePV.PrimeFacts.prime_2311)
  exact make_hit 1000 30 32 16 5331481 10712529 2311 2333 2339 5331479 row_284 h0 (SearchFacts.query_4406 LCMSourcePV.PrimeFacts.prime_2333) (SearchFacts.query_4407 LCMSourcePV.PrimeFacts.prime_2339) (SearchFacts.query_2861 LCMSourcePV.PrimeFacts.prime_5331479) c1_0
#print axioms make_284
end LCMSourcePV.Witness.BlockProofs
