/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_17 : Block := (Block.mk 146689 151320 389 397 401 146617 146681 146683)
theorem make_17 : make 1000 30 32 16 146689 10712529=some row_17 := by
  have ck_0_4_0 : (Block.mk 146689 151320 389 397 401 146617 146681 146683).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_389 LCMSourcePV.PrimeFacts.prime_397 LCMSourcePV.PrimeFacts.prime_401 LCMSourcePV.PrimeFacts.prime_146617 LCMSourcePV.PrimeFacts.prime_146681 LCMSourcePV.PrimeFacts.prime_146683
  have sh_0_4_0 : shrink 30 (Block.mk 146689 151320 389 397 401 146617 146681 146683)=some row_17 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 146689 10712529 389 397 401 146681 146683 28 146638=some row_17 :=
    choose0_hit 1000 30 146689 10712529 389 397 401 146681 146683 27 146638 146617 row_17 (SearchFacts.query_125 LCMSourcePV.PrimeFacts.prime_146617) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 146689 10712529 389 397 401 146681 146683 29 146646=(some row_17) :=
    choose0_skip 1000 30 146689 10712529 389 397 401 146681 146683 28 146646 146639 (some row_17) (SearchFacts.query_126 LCMSourcePV.PrimeFacts.prime_146639) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 146689 10712529 389 397 401 146681 146683 30 146668=(some row_17) :=
    choose0_skip 1000 30 146689 10712529 389 397 401 146681 146683 29 146668 146647 (some row_17) (SearchFacts.query_127 LCMSourcePV.PrimeFacts.prime_146647) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 146689 10712529 389 397 401 146681 146683 31 146676=(some row_17) :=
    choose0_skip 1000 30 146689 10712529 389 397 401 146681 146683 30 146676 146669 (some row_17) (SearchFacts.query_128 LCMSourcePV.PrimeFacts.prime_146669) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 146689 10712529 389 397 401 146681 146683 32 146680=(some row_17) :=
    choose0_skip 1000 30 146689 10712529 389 397 401 146681 146683 31 146680 146677 (some row_17) (SearchFacts.query_129 LCMSourcePV.PrimeFacts.prime_146677) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 146689 10712529 389 397 401 146683 16 146682=some row_17 :=
    choose1_hit 1000 30 32 146689 10712529 389 397 401 146683 15 146682 146681 row_17 (SearchFacts.query_130 LCMSourcePV.PrimeFacts.prime_146681) c0_0_0
  have hsqrt : Nat.sqrt 146689=383 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 146689+1)=some 389 := by
    rw [hsqrt];exact (SearchFacts.query_4138 LCMSourcePV.PrimeFacts.prime_389)
  exact make_hit 1000 30 32 16 146689 10712529 389 397 401 146683 row_17 h0 (SearchFacts.query_4139 LCMSourcePV.PrimeFacts.prime_397) (SearchFacts.query_4140 LCMSourcePV.PrimeFacts.prime_401) (SearchFacts.query_131 LCMSourcePV.PrimeFacts.prime_146683) c1_0
#print axioms make_17
end LCMSourcePV.Witness.BlockProofs
