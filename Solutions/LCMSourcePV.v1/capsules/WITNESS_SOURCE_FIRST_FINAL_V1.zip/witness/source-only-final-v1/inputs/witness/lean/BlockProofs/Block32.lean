/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_32 : Block := (Block.mk 218089 229440 479 487 491 217933 218083 218087)
theorem make_32 : make 1000 30 32 16 218089 10712529=some row_32 := by
  have ck_0_10_0 : (Block.mk 218089 229440 479 487 491 217933 218083 218087).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_479 LCMSourcePV.PrimeFacts.prime_487 LCMSourcePV.PrimeFacts.prime_491 LCMSourcePV.PrimeFacts.prime_217933 LCMSourcePV.PrimeFacts.prime_218083 LCMSourcePV.PrimeFacts.prime_218087
  have sh_0_10_0 : shrink 30 (Block.mk 218089 229440 479 487 491 217933 218083 218087)=some row_32 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 22 217936=some row_32 :=
    choose0_hit 1000 30 218089 10712529 479 487 491 218083 218087 21 217936 217933 row_32 (SearchFacts.query_340 LCMSourcePV.PrimeFacts.prime_217933) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 23 217968=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 22 217968 217937 (some row_32) (SearchFacts.query_341 LCMSourcePV.PrimeFacts.prime_217937) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 24 217978=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 23 217978 217969 (some row_32) (SearchFacts.query_342 LCMSourcePV.PrimeFacts.prime_217969) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 25 217980=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 24 217980 217979 (some row_32) (SearchFacts.query_343 LCMSourcePV.PrimeFacts.prime_217979) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 26 218002=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 25 218002 217981 (some row_32) (SearchFacts.query_344 LCMSourcePV.PrimeFacts.prime_217981) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 27 218020=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 26 218020 218003 (some row_32) (SearchFacts.query_345 LCMSourcePV.PrimeFacts.prime_218003) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 28 218046=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 27 218046 218021 (some row_32) (SearchFacts.query_346 LCMSourcePV.PrimeFacts.prime_218021) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 29 218068=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 28 218068 218047 (some row_32) (SearchFacts.query_347 LCMSourcePV.PrimeFacts.prime_218047) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 30 218076=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 29 218076 218069 (some row_32) (SearchFacts.query_348 LCMSourcePV.PrimeFacts.prime_218069) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 31 218080=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 30 218080 218077 (some row_32) (SearchFacts.query_349 LCMSourcePV.PrimeFacts.prime_218077) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 218089 10712529 479 487 491 218083 218087 32 218082=(some row_32) :=
    choose0_skip 1000 30 218089 10712529 479 487 491 218083 218087 31 218082 218081 (some row_32) (SearchFacts.query_350 LCMSourcePV.PrimeFacts.prime_218081) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 218089 10712529 479 487 491 218087 16 218086=some row_32 :=
    choose1_hit 1000 30 32 218089 10712529 479 487 491 218087 15 218086 218083 row_32 (SearchFacts.query_351 LCMSourcePV.PrimeFacts.prime_218083) c0_0_0
  have hsqrt : Nat.sqrt 218089=467 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 218089+1)=some 479 := by
    rw [hsqrt];exact (SearchFacts.query_4153 LCMSourcePV.PrimeFacts.prime_479)
  exact make_hit 1000 30 32 16 218089 10712529 479 487 491 218087 row_32 h0 (SearchFacts.query_4154 LCMSourcePV.PrimeFacts.prime_487) (SearchFacts.query_4155 LCMSourcePV.PrimeFacts.prime_491) (SearchFacts.query_352 LCMSourcePV.PrimeFacts.prime_218087) c1_0
#print axioms make_32
end LCMSourcePV.Witness.BlockProofs
