/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_14 : Block := (Block.mk 134689 139128 373 379 383 134677 134681 134683)
theorem make_14 : make 1000 30 32 16 134689 10712529=some row_14 := by
  have ck_0_0_0 : (Block.mk 134689 139128 373 379 383 134677 134681 134683).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_373 LCMSourcePV.PrimeFacts.prime_379 LCMSourcePV.PrimeFacts.prime_383 LCMSourcePV.PrimeFacts.prime_134677 LCMSourcePV.PrimeFacts.prime_134681 LCMSourcePV.PrimeFacts.prime_134683
  have sh_0_0_0 : shrink 30 (Block.mk 134689 139128 373 379 383 134677 134681 134683)=some row_14 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 134689 10712529 373 379 383 134681 134683 32 134680=some row_14 :=
    choose0_hit 1000 30 134689 10712529 373 379 383 134681 134683 31 134680 134677 row_14 (SearchFacts.query_104 LCMSourcePV.PrimeFacts.prime_134677) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 134689 10712529 373 379 383 134683 16 134682=some row_14 :=
    choose1_hit 1000 30 32 134689 10712529 373 379 383 134683 15 134682 134681 row_14 (SearchFacts.query_105 LCMSourcePV.PrimeFacts.prime_134681) c0_0_0
  have hsqrt : Nat.sqrt 134689=367 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 134689+1)=some 373 := by
    rw [hsqrt];exact (SearchFacts.query_4135 LCMSourcePV.PrimeFacts.prime_373)
  exact make_hit 1000 30 32 16 134689 10712529 373 379 383 134683 row_14 h0 (SearchFacts.query_4136 LCMSourcePV.PrimeFacts.prime_379) (SearchFacts.query_4137 LCMSourcePV.PrimeFacts.prime_383) (SearchFacts.query_106 LCMSourcePV.PrimeFacts.prime_134683) c1_0
#print axioms make_14
end LCMSourcePV.Witness.BlockProofs
