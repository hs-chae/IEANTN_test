/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_244 : Block := (Block.mk 3996001 4012008 2003 2011 2017 3995851 3995977 3995989)
theorem make_244 : make 1000 30 32 16 3996001 10712529=some row_244 := by
  have ck_0_7_0 : (Block.mk 3996001 4012008 2003 2011 2017 3995851 3995977 3995989).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2003 LCMSourcePV.PrimeFacts.prime_2011 LCMSourcePV.PrimeFacts.prime_2017 LCMSourcePV.PrimeFacts.prime_3995851 LCMSourcePV.PrimeFacts.prime_3995977 LCMSourcePV.PrimeFacts.prime_3995989
  have sh_0_7_0 : shrink 30 (Block.mk 3996001 4012008 2003 2011 2017 3995851 3995977 3995989)=some row_244 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 25 3995890=some row_244 :=
    choose0_hit 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 24 3995890 3995851 row_244 (SearchFacts.query_2485 LCMSourcePV.PrimeFacts.prime_3995851) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 26 3995896=(some row_244) :=
    choose0_skip 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 25 3995896 3995891 (some row_244) (SearchFacts.query_2486 LCMSourcePV.PrimeFacts.prime_3995891) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 27 3995902=(some row_244) :=
    choose0_skip 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 26 3995902 3995897 (some row_244) (SearchFacts.query_2487 LCMSourcePV.PrimeFacts.prime_3995897) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 28 3995920=(some row_244) :=
    choose0_skip 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 27 3995920 3995903 (some row_244) (SearchFacts.query_2488 LCMSourcePV.PrimeFacts.prime_3995903) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 29 3995922=(some row_244) :=
    choose0_skip 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 28 3995922 3995921 (some row_244) (SearchFacts.query_2489 LCMSourcePV.PrimeFacts.prime_3995921) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 30 3995932=(some row_244) :=
    choose0_skip 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 29 3995932 3995923 (some row_244) (SearchFacts.query_2490 LCMSourcePV.PrimeFacts.prime_3995923) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 31 3995940=(some row_244) :=
    choose0_skip 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 30 3995940 3995933 (some row_244) (SearchFacts.query_2491 LCMSourcePV.PrimeFacts.prime_3995933) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 32 3995976=(some row_244) :=
    choose0_skip 1000 30 3996001 10712529 2003 2011 2017 3995977 3995989 31 3995976 3995941 (some row_244) (SearchFacts.query_2492 LCMSourcePV.PrimeFacts.prime_3995941) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3996001 10712529 2003 2011 2017 3995989 16 3995988=some row_244 :=
    choose1_hit 1000 30 32 3996001 10712529 2003 2011 2017 3995989 15 3995988 3995977 row_244 (SearchFacts.query_2493 LCMSourcePV.PrimeFacts.prime_3995977) c0_0_0
  have hsqrt : Nat.sqrt 3996001=1999 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3996001+1)=some 2003 := by
    rw [hsqrt];exact (SearchFacts.query_4365 LCMSourcePV.PrimeFacts.prime_2003)
  exact make_hit 1000 30 32 16 3996001 10712529 2003 2011 2017 3995989 row_244 h0 (SearchFacts.query_4366 LCMSourcePV.PrimeFacts.prime_2011) (SearchFacts.query_4367 LCMSourcePV.PrimeFacts.prime_2017) (SearchFacts.query_2494 LCMSourcePV.PrimeFacts.prime_3995989) c1_0
#print axioms make_244
end LCMSourcePV.Witness.BlockProofs
