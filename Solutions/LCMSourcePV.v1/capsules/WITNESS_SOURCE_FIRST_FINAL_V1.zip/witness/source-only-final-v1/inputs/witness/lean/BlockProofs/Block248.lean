/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_248 : Block := (Block.mk 4108729 4116840 2029 2039 2053 4108627 4108681 4108717)
theorem make_248 : make 1000 30 32 16 4108729 10712529=some row_248 := by
  have ck_0_4_0 : (Block.mk 4108729 4116840 2029 2039 2053 4108627 4108681 4108717).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2029 LCMSourcePV.PrimeFacts.prime_2039 LCMSourcePV.PrimeFacts.prime_2053 LCMSourcePV.PrimeFacts.prime_4108627 LCMSourcePV.PrimeFacts.prime_4108681 LCMSourcePV.PrimeFacts.prime_4108717
  have sh_0_4_0 : shrink 30 (Block.mk 4108729 4116840 2029 2039 2053 4108627 4108681 4108717)=some row_248 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 28 4108660=some row_248 :=
    choose0_hit 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 27 4108660 4108627 row_248 (SearchFacts.query_2555 LCMSourcePV.PrimeFacts.prime_4108627) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 29 4108666=(some row_248) :=
    choose0_skip 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 28 4108666 4108661 (some row_248) (SearchFacts.query_2556 LCMSourcePV.PrimeFacts.prime_4108661) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 30 4108668=(some row_248) :=
    choose0_skip 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 29 4108668 4108667 (some row_248) (SearchFacts.query_2557 LCMSourcePV.PrimeFacts.prime_4108667) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 31 4108672=(some row_248) :=
    choose0_skip 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 30 4108672 4108669 (some row_248) (SearchFacts.query_2558 LCMSourcePV.PrimeFacts.prime_4108669) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 32 4108680=(some row_248) :=
    choose0_skip 1000 30 4108729 10712529 2029 2039 2053 4108681 4108717 31 4108680 4108673 (some row_248) (SearchFacts.query_2559 LCMSourcePV.PrimeFacts.prime_4108673) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4108729 10712529 2029 2039 2053 4108717 16 4108716=some row_248 :=
    choose1_hit 1000 30 32 4108729 10712529 2029 2039 2053 4108717 15 4108716 4108681 row_248 (SearchFacts.query_2560 LCMSourcePV.PrimeFacts.prime_4108681) c0_0_0
  have hsqrt : Nat.sqrt 4108729=2027 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4108729+1)=some 2029 := by
    rw [hsqrt];exact (SearchFacts.query_4369 LCMSourcePV.PrimeFacts.prime_2029)
  exact make_hit 1000 30 32 16 4108729 10712529 2029 2039 2053 4108717 row_248 h0 (SearchFacts.query_4370 LCMSourcePV.PrimeFacts.prime_2039) (SearchFacts.query_4371 LCMSourcePV.PrimeFacts.prime_2053) (SearchFacts.query_2561 LCMSourcePV.PrimeFacts.prime_4108717) c1_0
#print axioms make_248
end LCMSourcePV.Witness.BlockProofs
