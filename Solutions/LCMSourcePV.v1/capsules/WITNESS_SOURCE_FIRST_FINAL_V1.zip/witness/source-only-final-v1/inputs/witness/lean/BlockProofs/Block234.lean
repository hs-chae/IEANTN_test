/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_234 : Block := (Block.mk 3659569 3728760 1931 1933 1949 3659531 3659543 3659567)
theorem make_234 : make 1000 30 32 16 3659569 10712529=some row_234 := by
  have ck_0_0_0 : (Block.mk 3659569 3728760 1931 1933 1949 3659531 3659543 3659567).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1931 LCMSourcePV.PrimeFacts.prime_1933 LCMSourcePV.PrimeFacts.prime_1949 LCMSourcePV.PrimeFacts.prime_3659531 LCMSourcePV.PrimeFacts.prime_3659543 LCMSourcePV.PrimeFacts.prime_3659567
  have sh_0_0_0 : shrink 30 (Block.mk 3659569 3728760 1931 1933 1949 3659531 3659543 3659567)=some row_234 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 3659569 10712529 1931 1933 1949 3659543 3659567 32 3659542=some row_234 :=
    choose0_hit 1000 30 3659569 10712529 1931 1933 1949 3659543 3659567 31 3659542 3659531 row_234 (SearchFacts.query_2405 LCMSourcePV.PrimeFacts.prime_3659531) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 3659569 10712529 1931 1933 1949 3659567 16 3659566=some row_234 :=
    choose1_hit 1000 30 32 3659569 10712529 1931 1933 1949 3659567 15 3659566 3659543 row_234 (SearchFacts.query_2406 LCMSourcePV.PrimeFacts.prime_3659543) c0_0_0
  have hsqrt : Nat.sqrt 3659569=1913 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3659569+1)=some 1931 := by
    rw [hsqrt];exact (SearchFacts.query_4355 LCMSourcePV.PrimeFacts.prime_1931)
  exact make_hit 1000 30 32 16 3659569 10712529 1931 1933 1949 3659567 row_234 h0 (SearchFacts.query_4356 LCMSourcePV.PrimeFacts.prime_1933) (SearchFacts.query_4357 LCMSourcePV.PrimeFacts.prime_1949) (SearchFacts.query_2407 LCMSourcePV.PrimeFacts.prime_3659567) c1_0
#print axioms make_234
end LCMSourcePV.Witness.BlockProofs
