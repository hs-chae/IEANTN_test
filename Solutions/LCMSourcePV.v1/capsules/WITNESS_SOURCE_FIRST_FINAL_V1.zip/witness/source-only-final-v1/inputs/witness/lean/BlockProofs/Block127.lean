/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_127 : Block := (Block.mk 1229881 1247688 1117 1123 1129 1229743 1229869 1229873)
theorem make_127 : make 1000 30 32 16 1229881 10712529=some row_127 := by
  have ck_0_4_0 : (Block.mk 1229881 1247688 1117 1123 1129 1229743 1229869 1229873).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1117 LCMSourcePV.PrimeFacts.prime_1123 LCMSourcePV.PrimeFacts.prime_1129 LCMSourcePV.PrimeFacts.prime_1229743 LCMSourcePV.PrimeFacts.prime_1229869 LCMSourcePV.PrimeFacts.prime_1229873
  have sh_0_4_0 : shrink 30 (Block.mk 1229881 1247688 1117 1123 1129 1229743 1229869 1229873)=some row_127 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 28 1229772=some row_127 :=
    choose0_hit 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 27 1229772 1229743 row_127 (SearchFacts.query_1355 LCMSourcePV.PrimeFacts.prime_1229743) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 29 1229782=(some row_127) :=
    choose0_skip 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 28 1229782 1229773 (some row_127) (SearchFacts.query_1356 LCMSourcePV.PrimeFacts.prime_1229773) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 30 1229806=(some row_127) :=
    choose0_skip 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 29 1229806 1229783 (some row_127) (SearchFacts.query_1357 LCMSourcePV.PrimeFacts.prime_1229783) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 31 1229826=(some row_127) :=
    choose0_skip 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 30 1229826 1229807 (some row_127) (SearchFacts.query_1358 LCMSourcePV.PrimeFacts.prime_1229807) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 32 1229868=(some row_127) :=
    choose0_skip 1000 30 1229881 10712529 1117 1123 1129 1229869 1229873 31 1229868 1229827 (some row_127) (SearchFacts.query_1359 LCMSourcePV.PrimeFacts.prime_1229827) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1229881 10712529 1117 1123 1129 1229873 16 1229872=some row_127 :=
    choose1_hit 1000 30 32 1229881 10712529 1117 1123 1129 1229873 15 1229872 1229869 row_127 (SearchFacts.query_1360 LCMSourcePV.PrimeFacts.prime_1229869) c0_0_0
  have hsqrt : Nat.sqrt 1229881=1109 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1229881+1)=some 1117 := by
    rw [hsqrt];exact (SearchFacts.query_4248 LCMSourcePV.PrimeFacts.prime_1117)
  exact make_hit 1000 30 32 16 1229881 10712529 1117 1123 1129 1229873 row_127 h0 (SearchFacts.query_4249 LCMSourcePV.PrimeFacts.prime_1123) (SearchFacts.query_4250 LCMSourcePV.PrimeFacts.prime_1129) (SearchFacts.query_1361 LCMSourcePV.PrimeFacts.prime_1229873) c1_0
#print axioms make_127
end LCMSourcePV.Witness.BlockProofs
