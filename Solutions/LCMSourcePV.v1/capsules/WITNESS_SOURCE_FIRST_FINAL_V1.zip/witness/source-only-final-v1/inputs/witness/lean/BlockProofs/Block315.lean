/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_315 : Block := (Block.mk 6507601 6538248 2557 2579 2591 6507373 6507569 6507587)
theorem make_315 : make 1000 30 32 16 6507601 10712529=some row_315 := by
  have ck_0_9_0 : (Block.mk 6507601 6538248 2557 2579 2591 6507373 6507569 6507587).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2557 LCMSourcePV.PrimeFacts.prime_2579 LCMSourcePV.PrimeFacts.prime_2591 LCMSourcePV.PrimeFacts.prime_6507373 LCMSourcePV.PrimeFacts.prime_6507569 LCMSourcePV.PrimeFacts.prime_6507587
  have sh_0_9_0 : shrink 30 (Block.mk 6507601 6538248 2557 2579 2591 6507373 6507569 6507587)=some row_315 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 23 6507406=some row_315 :=
    choose0_hit 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 22 6507406 6507373 row_315 (SearchFacts.query_3213 LCMSourcePV.PrimeFacts.prime_6507373) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 24 6507420=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 23 6507420 6507407 (some row_315) (SearchFacts.query_3214 LCMSourcePV.PrimeFacts.prime_6507407) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 25 6507462=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 24 6507462 6507421 (some row_315) (SearchFacts.query_3215 LCMSourcePV.PrimeFacts.prime_6507421) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 26 6507468=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 25 6507468 6507463 (some row_315) (SearchFacts.query_3216 LCMSourcePV.PrimeFacts.prime_6507463) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 27 6507510=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 26 6507510 6507469 (some row_315) (SearchFacts.query_3217 LCMSourcePV.PrimeFacts.prime_6507469) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 28 6507516=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 27 6507516 6507511 (some row_315) (SearchFacts.query_3218 LCMSourcePV.PrimeFacts.prime_6507511) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 29 6507520=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 28 6507520 6507517 (some row_315) (SearchFacts.query_3219 LCMSourcePV.PrimeFacts.prime_6507517) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 30 6507532=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 29 6507532 6507521 (some row_315) (SearchFacts.query_3220 LCMSourcePV.PrimeFacts.prime_6507521) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 31 6507538=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 30 6507538 6507533 (some row_315) (SearchFacts.query_3221 LCMSourcePV.PrimeFacts.prime_6507533) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 32 6507568=(some row_315) :=
    choose0_skip 1000 30 6507601 10712529 2557 2579 2591 6507569 6507587 31 6507568 6507539 (some row_315) (SearchFacts.query_3222 LCMSourcePV.PrimeFacts.prime_6507539) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6507601 10712529 2557 2579 2591 6507587 16 6507586=some row_315 :=
    choose1_hit 1000 30 32 6507601 10712529 2557 2579 2591 6507587 15 6507586 6507569 row_315 (SearchFacts.query_3223 LCMSourcePV.PrimeFacts.prime_6507569) c0_0_0
  have hsqrt : Nat.sqrt 6507601=2551 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6507601+1)=some 2557 := by
    rw [hsqrt];exact (SearchFacts.query_4436 LCMSourcePV.PrimeFacts.prime_2557)
  exact make_hit 1000 30 32 16 6507601 10712529 2557 2579 2591 6507587 row_315 h0 (SearchFacts.query_4437 LCMSourcePV.PrimeFacts.prime_2579) (SearchFacts.query_4438 LCMSourcePV.PrimeFacts.prime_2591) (SearchFacts.query_3224 LCMSourcePV.PrimeFacts.prime_6507587) c1_0
#print axioms make_315
end LCMSourcePV.Witness.BlockProofs
