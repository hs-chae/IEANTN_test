/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_119 : Block := (Block.mk 1125721 1129968 1063 1069 1087 1125539 1125701 1125713)
theorem make_119 : make 1000 30 32 16 1125721 10712529=some row_119 := by
  have ck_0_10_0 : (Block.mk 1125721 1129968 1063 1069 1087 1125539 1125701 1125713).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1063 LCMSourcePV.PrimeFacts.prime_1069 LCMSourcePV.PrimeFacts.prime_1087 LCMSourcePV.PrimeFacts.prime_1125539 LCMSourcePV.PrimeFacts.prime_1125701 LCMSourcePV.PrimeFacts.prime_1125713
  have sh_0_10_0 : shrink 30 (Block.mk 1125721 1129968 1063 1069 1087 1125539 1125701 1125713)=some row_119 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 22 1125556=some row_119 :=
    choose0_hit 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 21 1125556 1125539 row_119 (SearchFacts.query_1228 LCMSourcePV.PrimeFacts.prime_1125539) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 23 1125558=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 22 1125558 1125557 (some row_119) (SearchFacts.query_1229 LCMSourcePV.PrimeFacts.prime_1125557) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 24 1125568=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 23 1125568 1125559 (some row_119) (SearchFacts.query_1230 LCMSourcePV.PrimeFacts.prime_1125559) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 25 1125570=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 24 1125570 1125569 (some row_119) (SearchFacts.query_1231 LCMSourcePV.PrimeFacts.prime_1125569) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 26 1125580=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 25 1125580 1125571 (some row_119) (SearchFacts.query_1232 LCMSourcePV.PrimeFacts.prime_1125571) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 27 1125598=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 26 1125598 1125581 (some row_119) (SearchFacts.query_1233 LCMSourcePV.PrimeFacts.prime_1125581) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 28 1125628=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 27 1125628 1125599 (some row_119) (SearchFacts.query_1234 LCMSourcePV.PrimeFacts.prime_1125599) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 29 1125646=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 28 1125646 1125629 (some row_119) (SearchFacts.query_1235 LCMSourcePV.PrimeFacts.prime_1125629) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 30 1125652=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 29 1125652 1125647 (some row_119) (SearchFacts.query_1236 LCMSourcePV.PrimeFacts.prime_1125647) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 31 1125678=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 30 1125678 1125653 (some row_119) (SearchFacts.query_1237 LCMSourcePV.PrimeFacts.prime_1125653) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 32 1125700=(some row_119) :=
    choose0_skip 1000 30 1125721 10712529 1063 1069 1087 1125701 1125713 31 1125700 1125679 (some row_119) (SearchFacts.query_1238 LCMSourcePV.PrimeFacts.prime_1125679) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1125721 10712529 1063 1069 1087 1125713 16 1125712=some row_119 :=
    choose1_hit 1000 30 32 1125721 10712529 1063 1069 1087 1125713 15 1125712 1125701 row_119 (SearchFacts.query_1239 LCMSourcePV.PrimeFacts.prime_1125701) c0_0_0
  have hsqrt : Nat.sqrt 1125721=1061 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1125721+1)=some 1063 := by
    rw [hsqrt];exact (SearchFacts.query_4240 LCMSourcePV.PrimeFacts.prime_1063)
  exact make_hit 1000 30 32 16 1125721 10712529 1063 1069 1087 1125713 row_119 h0 (SearchFacts.query_4241 LCMSourcePV.PrimeFacts.prime_1069) (SearchFacts.query_4242 LCMSourcePV.PrimeFacts.prime_1087) (SearchFacts.query_1240 LCMSourcePV.PrimeFacts.prime_1125713) c1_0
#print axioms make_119
end LCMSourcePV.Witness.BlockProofs
