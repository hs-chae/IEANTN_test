/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_286 : Block := (Block.mk 5442889 5470920 2339 2341 2347 5442659 5442817 5442859)
theorem make_286 : make 1000 30 32 16 5442889 10712529=some row_286 := by
  have ck_0_5_0 : (Block.mk 5442889 5470920 2339 2341 2347 5442659 5442817 5442859).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2339 LCMSourcePV.PrimeFacts.prime_2341 LCMSourcePV.PrimeFacts.prime_2347 LCMSourcePV.PrimeFacts.prime_5442659 LCMSourcePV.PrimeFacts.prime_5442817 LCMSourcePV.PrimeFacts.prime_5442859
  have sh_0_5_0 : shrink 30 (Block.mk 5442889 5470920 2339 2341 2347 5442659 5442817 5442859)=some row_286 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 27 5442666=some row_286 :=
    choose0_hit 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 26 5442666 5442659 row_286 (SearchFacts.query_2867 LCMSourcePV.PrimeFacts.prime_5442659) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 28 5442672=(some row_286) :=
    choose0_skip 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 27 5442672 5442667 (some row_286) (SearchFacts.query_2868 LCMSourcePV.PrimeFacts.prime_5442667) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 29 5442726=(some row_286) :=
    choose0_skip 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 28 5442726 5442673 (some row_286) (SearchFacts.query_2869 LCMSourcePV.PrimeFacts.prime_5442673) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 30 5442750=(some row_286) :=
    choose0_skip 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 29 5442750 5442727 (some row_286) (SearchFacts.query_2870 LCMSourcePV.PrimeFacts.prime_5442727) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 31 5442780=(some row_286) :=
    choose0_skip 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 30 5442780 5442751 (some row_286) (SearchFacts.query_2871 LCMSourcePV.PrimeFacts.prime_5442751) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 32 5442816=(some row_286) :=
    choose0_skip 1000 30 5442889 10712529 2339 2341 2347 5442817 5442859 31 5442816 5442781 (some row_286) (SearchFacts.query_2872 LCMSourcePV.PrimeFacts.prime_5442781) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5442889 10712529 2339 2341 2347 5442859 16 5442858=some row_286 :=
    choose1_hit 1000 30 32 5442889 10712529 2339 2341 2347 5442859 15 5442858 5442817 row_286 (SearchFacts.query_2873 LCMSourcePV.PrimeFacts.prime_5442817) c0_0_0
  have hsqrt : Nat.sqrt 5442889=2333 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5442889+1)=some 2339 := by
    rw [hsqrt];exact (SearchFacts.query_4407 LCMSourcePV.PrimeFacts.prime_2339)
  exact make_hit 1000 30 32 16 5442889 10712529 2339 2341 2347 5442859 row_286 h0 (SearchFacts.query_4408 LCMSourcePV.PrimeFacts.prime_2341) (SearchFacts.query_4409 LCMSourcePV.PrimeFacts.prime_2347) (SearchFacts.query_2874 LCMSourcePV.PrimeFacts.prime_5442859) c1_0
#print axioms make_286
end LCMSourcePV.Witness.BlockProofs
