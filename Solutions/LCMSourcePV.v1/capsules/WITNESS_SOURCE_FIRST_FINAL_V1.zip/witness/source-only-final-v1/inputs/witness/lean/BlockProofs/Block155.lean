/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_155 : Block := (Block.mk 1708249 1739760 1319 1321 1327 1708159 1708229 1708247)
theorem make_155 : make 1000 30 32 16 1708249 10712529=some row_155 := by
  have ck_0_5_0 : (Block.mk 1708249 1739760 1319 1321 1327 1708159 1708229 1708247).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1319 LCMSourcePV.PrimeFacts.prime_1321 LCMSourcePV.PrimeFacts.prime_1327 LCMSourcePV.PrimeFacts.prime_1708159 LCMSourcePV.PrimeFacts.prime_1708229 LCMSourcePV.PrimeFacts.prime_1708247
  have sh_0_5_0 : shrink 30 (Block.mk 1708249 1739760 1319 1321 1327 1708159 1708229 1708247)=some row_155 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 27 1708162=some row_155 :=
    choose0_hit 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 26 1708162 1708159 row_155 (SearchFacts.query_1620 LCMSourcePV.PrimeFacts.prime_1708159) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 28 1708168=(some row_155) :=
    choose0_skip 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 27 1708168 1708163 (some row_155) (SearchFacts.query_1621 LCMSourcePV.PrimeFacts.prime_1708163) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 29 1708180=(some row_155) :=
    choose0_skip 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 28 1708180 1708169 (some row_155) (SearchFacts.query_1622 LCMSourcePV.PrimeFacts.prime_1708169) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 30 1708206=(some row_155) :=
    choose0_skip 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 29 1708206 1708181 (some row_155) (SearchFacts.query_1623 LCMSourcePV.PrimeFacts.prime_1708181) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 31 1708218=(some row_155) :=
    choose0_skip 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 30 1708218 1708207 (some row_155) (SearchFacts.query_1624 LCMSourcePV.PrimeFacts.prime_1708207) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 32 1708228=(some row_155) :=
    choose0_skip 1000 30 1708249 10712529 1319 1321 1327 1708229 1708247 31 1708228 1708219 (some row_155) (SearchFacts.query_1625 LCMSourcePV.PrimeFacts.prime_1708219) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1708249 10712529 1319 1321 1327 1708247 16 1708246=some row_155 :=
    choose1_hit 1000 30 32 1708249 10712529 1319 1321 1327 1708247 15 1708246 1708229 row_155 (SearchFacts.query_1626 LCMSourcePV.PrimeFacts.prime_1708229) c0_0_0
  have hsqrt : Nat.sqrt 1708249=1307 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1708249+1)=some 1319 := by
    rw [hsqrt];exact (SearchFacts.query_4276 LCMSourcePV.PrimeFacts.prime_1319)
  exact make_hit 1000 30 32 16 1708249 10712529 1319 1321 1327 1708247 row_155 h0 (SearchFacts.query_4277 LCMSourcePV.PrimeFacts.prime_1321) (SearchFacts.query_4278 LCMSourcePV.PrimeFacts.prime_1327) (SearchFacts.query_1627 LCMSourcePV.PrimeFacts.prime_1708247) c1_0
#print axioms make_155
end LCMSourcePV.Witness.BlockProofs
