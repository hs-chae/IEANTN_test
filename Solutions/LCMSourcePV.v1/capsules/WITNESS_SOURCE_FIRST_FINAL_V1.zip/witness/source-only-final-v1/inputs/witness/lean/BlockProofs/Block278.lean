/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_278 : Block := (Block.mk 5148361 5166528 2273 2281 2287 5148271 5148337 5148359)
theorem make_278 : make 1000 30 32 16 5148361 10712529=some row_278 := by
  have ck_0_6_0 : (Block.mk 5148361 5166528 2273 2281 2287 5148271 5148337 5148359).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2273 LCMSourcePV.PrimeFacts.prime_2281 LCMSourcePV.PrimeFacts.prime_2287 LCMSourcePV.PrimeFacts.prime_5148271 LCMSourcePV.PrimeFacts.prime_5148337 LCMSourcePV.PrimeFacts.prime_5148359
  have sh_0_6_0 : shrink 30 (Block.mk 5148361 5166528 2273 2281 2287 5148271 5148337 5148359)=some row_278 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 26 5148276=some row_278 :=
    choose0_hit 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 25 5148276 5148271 row_278 (SearchFacts.query_2813 LCMSourcePV.PrimeFacts.prime_5148271) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 27 5148286=(some row_278) :=
    choose0_skip 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 26 5148286 5148277 (some row_278) (SearchFacts.query_2814 LCMSourcePV.PrimeFacts.prime_5148277) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 28 5148288=(some row_278) :=
    choose0_skip 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 27 5148288 5148287 (some row_278) (SearchFacts.query_2815 LCMSourcePV.PrimeFacts.prime_5148287) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 29 5148292=(some row_278) :=
    choose0_skip 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 28 5148292 5148289 (some row_278) (SearchFacts.query_2816 LCMSourcePV.PrimeFacts.prime_5148289) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 30 5148300=(some row_278) :=
    choose0_skip 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 29 5148300 5148293 (some row_278) (SearchFacts.query_2817 LCMSourcePV.PrimeFacts.prime_5148293) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 31 5148312=(some row_278) :=
    choose0_skip 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 30 5148312 5148301 (some row_278) (SearchFacts.query_2818 LCMSourcePV.PrimeFacts.prime_5148301) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 32 5148336=(some row_278) :=
    choose0_skip 1000 30 5148361 10712529 2273 2281 2287 5148337 5148359 31 5148336 5148313 (some row_278) (SearchFacts.query_2819 LCMSourcePV.PrimeFacts.prime_5148313) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5148361 10712529 2273 2281 2287 5148359 16 5148358=some row_278 :=
    choose1_hit 1000 30 32 5148361 10712529 2273 2281 2287 5148359 15 5148358 5148337 row_278 (SearchFacts.query_2820 LCMSourcePV.PrimeFacts.prime_5148337) c0_0_0
  have hsqrt : Nat.sqrt 5148361=2269 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5148361+1)=some 2273 := by
    rw [hsqrt];exact (SearchFacts.query_4399 LCMSourcePV.PrimeFacts.prime_2273)
  exact make_hit 1000 30 32 16 5148361 10712529 2273 2281 2287 5148359 row_278 h0 (SearchFacts.query_4400 LCMSourcePV.PrimeFacts.prime_2281) (SearchFacts.query_4401 LCMSourcePV.PrimeFacts.prime_2287) (SearchFacts.query_2821 LCMSourcePV.PrimeFacts.prime_5148359) c1_0
#print axioms make_278
end LCMSourcePV.Witness.BlockProofs
