/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_233 : Block := (Block.mk 3636649 3659568 1913 1931 1933 3636541 3636617 3636631)
theorem make_233 : make 1000 30 32 16 3636649 10712529=some row_233 := by
  have ck_0_4_0 : (Block.mk 3636649 3659568 1913 1931 1933 3636541 3636617 3636631).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1913 LCMSourcePV.PrimeFacts.prime_1931 LCMSourcePV.PrimeFacts.prime_1933 LCMSourcePV.PrimeFacts.prime_3636541 LCMSourcePV.PrimeFacts.prime_3636617 LCMSourcePV.PrimeFacts.prime_3636631
  have sh_0_4_0 : shrink 30 (Block.mk 3636649 3659568 1913 1931 1933 3636541 3636617 3636631)=some row_233 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 28 3636546=some row_233 :=
    choose0_hit 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 27 3636546 3636541 row_233 (SearchFacts.query_2398 LCMSourcePV.PrimeFacts.prime_3636541) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 29 3636550=(some row_233) :=
    choose0_skip 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 28 3636550 3636547 (some row_233) (SearchFacts.query_2399 LCMSourcePV.PrimeFacts.prime_3636547) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 30 3636568=(some row_233) :=
    choose0_skip 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 29 3636568 3636551 (some row_233) (SearchFacts.query_2400 LCMSourcePV.PrimeFacts.prime_3636551) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 31 3636592=(some row_233) :=
    choose0_skip 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 30 3636592 3636569 (some row_233) (SearchFacts.query_2401 LCMSourcePV.PrimeFacts.prime_3636569) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 32 3636616=(some row_233) :=
    choose0_skip 1000 30 3636649 10712529 1913 1931 1933 3636617 3636631 31 3636616 3636593 (some row_233) (SearchFacts.query_2402 LCMSourcePV.PrimeFacts.prime_3636593) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3636649 10712529 1913 1931 1933 3636631 16 3636630=some row_233 :=
    choose1_hit 1000 30 32 3636649 10712529 1913 1931 1933 3636631 15 3636630 3636617 row_233 (SearchFacts.query_2403 LCMSourcePV.PrimeFacts.prime_3636617) c0_0_0
  have hsqrt : Nat.sqrt 3636649=1907 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3636649+1)=some 1913 := by
    rw [hsqrt];exact (SearchFacts.query_4354 LCMSourcePV.PrimeFacts.prime_1913)
  exact make_hit 1000 30 32 16 3636649 10712529 1913 1931 1933 3636631 row_233 h0 (SearchFacts.query_4355 LCMSourcePV.PrimeFacts.prime_1931) (SearchFacts.query_4356 LCMSourcePV.PrimeFacts.prime_1933) (SearchFacts.query_2404 LCMSourcePV.PrimeFacts.prime_3636631) c1_0
#print axioms make_233
end LCMSourcePV.Witness.BlockProofs
