/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_210 : Block := (Block.mk 2968729 3003288 1733 1741 1747 2968639 2968711 2968717)
theorem make_210 : make 1000 30 32 16 2968729 10712529=some row_210 := by
  have ck_0_4_0 : (Block.mk 2968729 3003288 1733 1741 1747 2968639 2968711 2968717).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1733 LCMSourcePV.PrimeFacts.prime_1741 LCMSourcePV.PrimeFacts.prime_1747 LCMSourcePV.PrimeFacts.prime_2968639 LCMSourcePV.PrimeFacts.prime_2968711 LCMSourcePV.PrimeFacts.prime_2968717
  have sh_0_4_0 : shrink 30 (Block.mk 2968729 3003288 1733 1741 1747 2968639 2968711 2968717)=some row_210 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 28 2968672=some row_210 :=
    choose0_hit 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 27 2968672 2968639 row_210 (SearchFacts.query_2191 LCMSourcePV.PrimeFacts.prime_2968639) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 29 2968680=(some row_210) :=
    choose0_skip 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 28 2968680 2968673 (some row_210) (SearchFacts.query_2192 LCMSourcePV.PrimeFacts.prime_2968673) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 30 2968696=(some row_210) :=
    choose0_skip 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 29 2968696 2968681 (some row_210) (SearchFacts.query_2193 LCMSourcePV.PrimeFacts.prime_2968681) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 31 2968708=(some row_210) :=
    choose0_skip 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 30 2968708 2968697 (some row_210) (SearchFacts.query_2194 LCMSourcePV.PrimeFacts.prime_2968697) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 32 2968710=(some row_210) :=
    choose0_skip 1000 30 2968729 10712529 1733 1741 1747 2968711 2968717 31 2968710 2968709 (some row_210) (SearchFacts.query_2195 LCMSourcePV.PrimeFacts.prime_2968709) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2968729 10712529 1733 1741 1747 2968717 16 2968716=some row_210 :=
    choose1_hit 1000 30 32 2968729 10712529 1733 1741 1747 2968717 15 2968716 2968711 row_210 (SearchFacts.query_2196 LCMSourcePV.PrimeFacts.prime_2968711) c0_0_0
  have hsqrt : Nat.sqrt 2968729=1723 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2968729+1)=some 1733 := by
    rw [hsqrt];exact (SearchFacts.query_4331 LCMSourcePV.PrimeFacts.prime_1733)
  exact make_hit 1000 30 32 16 2968729 10712529 1733 1741 1747 2968717 row_210 h0 (SearchFacts.query_4332 LCMSourcePV.PrimeFacts.prime_1741) (SearchFacts.query_4333 LCMSourcePV.PrimeFacts.prime_1747) (SearchFacts.query_2197 LCMSourcePV.PrimeFacts.prime_2968717) c1_0
#print axioms make_210
end LCMSourcePV.Witness.BlockProofs
