/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_179 : Block := (Block.mk 2229049 2247000 1499 1511 1523 2228981 2229041 2229043)
theorem make_179 : make 1000 30 32 16 2229049 10712529=some row_179 := by
  have ck_0_3_0 : (Block.mk 2229049 2247000 1499 1511 1523 2228981 2229041 2229043).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1499 LCMSourcePV.PrimeFacts.prime_1511 LCMSourcePV.PrimeFacts.prime_1523 LCMSourcePV.PrimeFacts.prime_2228981 LCMSourcePV.PrimeFacts.prime_2229041 LCMSourcePV.PrimeFacts.prime_2229043
  have sh_0_3_0 : shrink 30 (Block.mk 2229049 2247000 1499 1511 1523 2228981 2229041 2229043)=some row_179 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 2229049 10712529 1499 1511 1523 2229041 2229043 29 2228982=some row_179 :=
    choose0_hit 1000 30 2229049 10712529 1499 1511 1523 2229041 2229043 28 2228982 2228981 row_179 (SearchFacts.query_1805 LCMSourcePV.PrimeFacts.prime_2228981) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 2229049 10712529 1499 1511 1523 2229041 2229043 30 2228986=(some row_179) :=
    choose0_skip 1000 30 2229049 10712529 1499 1511 1523 2229041 2229043 29 2228986 2228983 (some row_179) (SearchFacts.query_1806 LCMSourcePV.PrimeFacts.prime_2228983) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2229049 10712529 1499 1511 1523 2229041 2229043 31 2229036=(some row_179) :=
    choose0_skip 1000 30 2229049 10712529 1499 1511 1523 2229041 2229043 30 2229036 2228987 (some row_179) (SearchFacts.query_1807 LCMSourcePV.PrimeFacts.prime_2228987) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2229049 10712529 1499 1511 1523 2229041 2229043 32 2229040=(some row_179) :=
    choose0_skip 1000 30 2229049 10712529 1499 1511 1523 2229041 2229043 31 2229040 2229037 (some row_179) (SearchFacts.query_1808 LCMSourcePV.PrimeFacts.prime_2229037) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2229049 10712529 1499 1511 1523 2229043 16 2229042=some row_179 :=
    choose1_hit 1000 30 32 2229049 10712529 1499 1511 1523 2229043 15 2229042 2229041 row_179 (SearchFacts.query_1809 LCMSourcePV.PrimeFacts.prime_2229041) c0_0_0
  have hsqrt : Nat.sqrt 2229049=1493 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2229049+1)=some 1499 := by
    rw [hsqrt];exact (SearchFacts.query_4300 LCMSourcePV.PrimeFacts.prime_1499)
  exact make_hit 1000 30 32 16 2229049 10712529 1499 1511 1523 2229043 row_179 h0 (SearchFacts.query_4301 LCMSourcePV.PrimeFacts.prime_1511) (SearchFacts.query_4302 LCMSourcePV.PrimeFacts.prime_1523) (SearchFacts.query_1810 LCMSourcePV.PrimeFacts.prime_2229043) c1_0
#print axioms make_179
end LCMSourcePV.Witness.BlockProofs
