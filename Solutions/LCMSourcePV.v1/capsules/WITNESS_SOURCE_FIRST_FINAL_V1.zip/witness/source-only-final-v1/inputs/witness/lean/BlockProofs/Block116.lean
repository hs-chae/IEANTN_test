/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_116 : Block := (Block.mk 1079521 1100400 1049 1051 1061 1079471 1079503 1079509)
theorem make_116 : make 1000 30 32 16 1079521 10712529=some row_116 := by
  have ck_0_1_0 : (Block.mk 1079521 1100400 1049 1051 1061 1079471 1079503 1079509).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1049 LCMSourcePV.PrimeFacts.prime_1051 LCMSourcePV.PrimeFacts.prime_1061 LCMSourcePV.PrimeFacts.prime_1079471 LCMSourcePV.PrimeFacts.prime_1079503 LCMSourcePV.PrimeFacts.prime_1079509
  have sh_0_1_0 : shrink 30 (Block.mk 1079521 1100400 1049 1051 1061 1079471 1079503 1079509)=some row_116 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 1079521 10712529 1049 1051 1061 1079503 1079509 31 1079472=some row_116 :=
    choose0_hit 1000 30 1079521 10712529 1049 1051 1061 1079503 1079509 30 1079472 1079471 row_116 (SearchFacts.query_1184 LCMSourcePV.PrimeFacts.prime_1079471) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 1079521 10712529 1049 1051 1061 1079503 1079509 32 1079502=(some row_116) :=
    choose0_skip 1000 30 1079521 10712529 1049 1051 1061 1079503 1079509 31 1079502 1079473 (some row_116) (SearchFacts.query_1185 LCMSourcePV.PrimeFacts.prime_1079473) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1079521 10712529 1049 1051 1061 1079509 16 1079508=some row_116 :=
    choose1_hit 1000 30 32 1079521 10712529 1049 1051 1061 1079509 15 1079508 1079503 row_116 (SearchFacts.query_1186 LCMSourcePV.PrimeFacts.prime_1079503) c0_0_0
  have hsqrt : Nat.sqrt 1079521=1039 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1079521+1)=some 1049 := by
    rw [hsqrt];exact (SearchFacts.query_4237 LCMSourcePV.PrimeFacts.prime_1049)
  exact make_hit 1000 30 32 16 1079521 10712529 1049 1051 1061 1079509 row_116 h0 (SearchFacts.query_4238 LCMSourcePV.PrimeFacts.prime_1051) (SearchFacts.query_4239 LCMSourcePV.PrimeFacts.prime_1061) (SearchFacts.query_1187 LCMSourcePV.PrimeFacts.prime_1079509) c1_0
#print axioms make_116
end LCMSourcePV.Witness.BlockProofs
