/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_259 : Block := (Block.mk 4456321 4464768 2113 2129 2131 4456147 4456297 4456301)
theorem make_259 : make 1000 30 32 16 4456321 10712529=some row_259 := by
  have ck_0_4_0 : (Block.mk 4456321 4464768 2113 2129 2131 4456147 4456297 4456301).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2113 LCMSourcePV.PrimeFacts.prime_2129 LCMSourcePV.PrimeFacts.prime_2131 LCMSourcePV.PrimeFacts.prime_4456147 LCMSourcePV.PrimeFacts.prime_4456297 LCMSourcePV.PrimeFacts.prime_4456301
  have sh_0_4_0 : shrink 30 (Block.mk 4456321 4464768 2113 2129 2131 4456147 4456297 4456301)=some row_259 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 28 4456182=some row_259 :=
    choose0_hit 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 27 4456182 4456147 row_259 (SearchFacts.query_2617 LCMSourcePV.PrimeFacts.prime_4456147) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 29 4456188=(some row_259) :=
    choose0_skip 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 28 4456188 4456183 (some row_259) (SearchFacts.query_2618 LCMSourcePV.PrimeFacts.prime_4456183) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 30 4456212=(some row_259) :=
    choose0_skip 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 29 4456212 4456189 (some row_259) (SearchFacts.query_2619 LCMSourcePV.PrimeFacts.prime_4456189) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 31 4456222=(some row_259) :=
    choose0_skip 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 30 4456222 4456213 (some row_259) (SearchFacts.query_2620 LCMSourcePV.PrimeFacts.prime_4456213) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 32 4456296=(some row_259) :=
    choose0_skip 1000 30 4456321 10712529 2113 2129 2131 4456297 4456301 31 4456296 4456223 (some row_259) (SearchFacts.query_2621 LCMSourcePV.PrimeFacts.prime_4456223) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4456321 10712529 2113 2129 2131 4456301 16 4456300=some row_259 :=
    choose1_hit 1000 30 32 4456321 10712529 2113 2129 2131 4456301 15 4456300 4456297 row_259 (SearchFacts.query_2622 LCMSourcePV.PrimeFacts.prime_4456297) c0_0_0
  have hsqrt : Nat.sqrt 4456321=2111 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4456321+1)=some 2113 := by
    rw [hsqrt];exact (SearchFacts.query_4380 LCMSourcePV.PrimeFacts.prime_2113)
  exact make_hit 1000 30 32 16 4456321 10712529 2113 2129 2131 4456301 row_259 h0 (SearchFacts.query_4381 LCMSourcePV.PrimeFacts.prime_2129) (SearchFacts.query_4382 LCMSourcePV.PrimeFacts.prime_2131) (SearchFacts.query_2623 LCMSourcePV.PrimeFacts.prime_4456301) c1_0
#print axioms make_259
end LCMSourcePV.Witness.BlockProofs
