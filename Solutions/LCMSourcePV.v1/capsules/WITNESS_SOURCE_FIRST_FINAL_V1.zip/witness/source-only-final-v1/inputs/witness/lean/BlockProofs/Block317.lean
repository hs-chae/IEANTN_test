/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_317 : Block := (Block.mk 6651241 6713280 2591 2593 2609 6651077 6651221 6651223)
theorem make_317 : make 1000 30 32 16 6651241 10712529=some row_317 := by
  have ck_0_11_0 : (Block.mk 6651241 6713280 2591 2593 2609 6651077 6651221 6651223).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2591 LCMSourcePV.PrimeFacts.prime_2593 LCMSourcePV.PrimeFacts.prime_2609 LCMSourcePV.PrimeFacts.prime_6651077 LCMSourcePV.PrimeFacts.prime_6651221 LCMSourcePV.PrimeFacts.prime_6651223
  have sh_0_11_0 : shrink 30 (Block.mk 6651241 6713280 2591 2593 2609 6651077 6651221 6651223)=some row_317 := shrink_hit _ _ ck_0_11_0
  have c0_0_11 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 21 6651090=some row_317 :=
    choose0_hit 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 20 6651090 6651077 row_317 (SearchFacts.query_3235 LCMSourcePV.PrimeFacts.prime_6651077) (by decide) sh_0_11_0
  have c0_0_10 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 22 6651100=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 21 6651100 6651091 (some row_317) (SearchFacts.query_3236 LCMSourcePV.PrimeFacts.prime_6651091) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 23 6651106=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 22 6651106 6651101 (some row_317) (SearchFacts.query_3237 LCMSourcePV.PrimeFacts.prime_6651101) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 24 6651118=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 23 6651118 6651107 (some row_317) (SearchFacts.query_3238 LCMSourcePV.PrimeFacts.prime_6651107) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 25 6651132=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 24 6651132 6651119 (some row_317) (SearchFacts.query_3239 LCMSourcePV.PrimeFacts.prime_6651119) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 26 6651148=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 25 6651148 6651133 (some row_317) (SearchFacts.query_3240 LCMSourcePV.PrimeFacts.prime_6651133) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 27 6651166=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 26 6651166 6651149 (some row_317) (SearchFacts.query_3241 LCMSourcePV.PrimeFacts.prime_6651149) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 28 6651172=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 27 6651172 6651167 (some row_317) (SearchFacts.query_3242 LCMSourcePV.PrimeFacts.prime_6651167) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 29 6651180=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 28 6651180 6651173 (some row_317) (SearchFacts.query_3243 LCMSourcePV.PrimeFacts.prime_6651173) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 30 6651186=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 29 6651186 6651181 (some row_317) (SearchFacts.query_3244 LCMSourcePV.PrimeFacts.prime_6651181) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 31 6651216=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 30 6651216 6651187 (some row_317) (SearchFacts.query_3245 LCMSourcePV.PrimeFacts.prime_6651187) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 32 6651220=(some row_317) :=
    choose0_skip 1000 30 6651241 10712529 2591 2593 2609 6651221 6651223 31 6651220 6651217 (some row_317) (SearchFacts.query_3246 LCMSourcePV.PrimeFacts.prime_6651217) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6651241 10712529 2591 2593 2609 6651223 16 6651222=some row_317 :=
    choose1_hit 1000 30 32 6651241 10712529 2591 2593 2609 6651223 15 6651222 6651221 row_317 (SearchFacts.query_3247 LCMSourcePV.PrimeFacts.prime_6651221) c0_0_0
  have hsqrt : Nat.sqrt 6651241=2579 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6651241+1)=some 2591 := by
    rw [hsqrt];exact (SearchFacts.query_4438 LCMSourcePV.PrimeFacts.prime_2591)
  exact make_hit 1000 30 32 16 6651241 10712529 2591 2593 2609 6651223 row_317 h0 (SearchFacts.query_4439 LCMSourcePV.PrimeFacts.prime_2593) (SearchFacts.query_4440 LCMSourcePV.PrimeFacts.prime_2609) (SearchFacts.query_3248 LCMSourcePV.PrimeFacts.prime_6651223) c1_0
#print axioms make_317
end LCMSourcePV.Witness.BlockProofs
