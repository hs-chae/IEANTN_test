/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_186 : Block := (Block.mk 2411809 2430480 1559 1567 1571 2411543 2411777 2411797)
theorem make_186 : make 1000 30 32 16 2411809 10712529=some row_186 := by
  have ck_0_14_0 : (Block.mk 2411809 2430480 1559 1567 1571 2411543 2411777 2411797).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1559 LCMSourcePV.PrimeFacts.prime_1567 LCMSourcePV.PrimeFacts.prime_1571 LCMSourcePV.PrimeFacts.prime_2411543 LCMSourcePV.PrimeFacts.prime_2411777 LCMSourcePV.PrimeFacts.prime_2411797
  have sh_0_14_0 : shrink 30 (Block.mk 2411809 2430480 1559 1567 1571 2411543 2411777 2411797)=some row_186 := shrink_hit _ _ ck_0_14_0
  have c0_0_14 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 18 2411550=some row_186 :=
    choose0_hit 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 17 2411550 2411543 row_186 (SearchFacts.query_1905 LCMSourcePV.PrimeFacts.prime_2411543) (by decide) sh_0_14_0
  have c0_0_13 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 19 2411566=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 18 2411566 2411551 (some row_186) (SearchFacts.query_1906 LCMSourcePV.PrimeFacts.prime_2411551) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 20 2411580=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 19 2411580 2411567 (some row_186) (SearchFacts.query_1907 LCMSourcePV.PrimeFacts.prime_2411567) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 21 2411586=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 20 2411586 2411581 (some row_186) (SearchFacts.query_1908 LCMSourcePV.PrimeFacts.prime_2411581) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 22 2411592=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 21 2411592 2411587 (some row_186) (SearchFacts.query_1909 LCMSourcePV.PrimeFacts.prime_2411587) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 23 2411596=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 22 2411596 2411593 (some row_186) (SearchFacts.query_1910 LCMSourcePV.PrimeFacts.prime_2411593) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 24 2411626=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 23 2411626 2411597 (some row_186) (SearchFacts.query_1911 LCMSourcePV.PrimeFacts.prime_2411597) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 25 2411638=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 24 2411638 2411627 (some row_186) (SearchFacts.query_1912 LCMSourcePV.PrimeFacts.prime_2411627) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 26 2411640=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 25 2411640 2411639 (some row_186) (SearchFacts.query_1913 LCMSourcePV.PrimeFacts.prime_2411639) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 27 2411662=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 26 2411662 2411641 (some row_186) (SearchFacts.query_1914 LCMSourcePV.PrimeFacts.prime_2411641) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 28 2411692=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 27 2411692 2411663 (some row_186) (SearchFacts.query_1915 LCMSourcePV.PrimeFacts.prime_2411663) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 29 2411698=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 28 2411698 2411693 (some row_186) (SearchFacts.query_1916 LCMSourcePV.PrimeFacts.prime_2411693) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 30 2411728=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 29 2411728 2411699 (some row_186) (SearchFacts.query_1917 LCMSourcePV.PrimeFacts.prime_2411699) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 31 2411736=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 30 2411736 2411729 (some row_186) (SearchFacts.query_1918 LCMSourcePV.PrimeFacts.prime_2411729) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 32 2411776=(some row_186) :=
    choose0_skip 1000 30 2411809 10712529 1559 1567 1571 2411777 2411797 31 2411776 2411737 (some row_186) (SearchFacts.query_1919 LCMSourcePV.PrimeFacts.prime_2411737) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2411809 10712529 1559 1567 1571 2411797 16 2411796=some row_186 :=
    choose1_hit 1000 30 32 2411809 10712529 1559 1567 1571 2411797 15 2411796 2411777 row_186 (SearchFacts.query_1920 LCMSourcePV.PrimeFacts.prime_2411777) c0_0_0
  have hsqrt : Nat.sqrt 2411809=1553 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2411809+1)=some 1559 := by
    rw [hsqrt];exact (SearchFacts.query_4307 LCMSourcePV.PrimeFacts.prime_1559)
  exact make_hit 1000 30 32 16 2411809 10712529 1559 1567 1571 2411797 row_186 h0 (SearchFacts.query_4308 LCMSourcePV.PrimeFacts.prime_1567) (SearchFacts.query_4309 LCMSourcePV.PrimeFacts.prime_1571) (SearchFacts.query_1921 LCMSourcePV.PrimeFacts.prime_2411797) c1_0
#print axioms make_186
end LCMSourcePV.Witness.BlockProofs
