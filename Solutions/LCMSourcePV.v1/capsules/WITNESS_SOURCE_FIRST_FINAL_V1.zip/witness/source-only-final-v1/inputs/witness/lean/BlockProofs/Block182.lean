/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_182 : Block := (Block.mk 2319529 2343960 1531 1543 1549 2319253 2319517 2319521)
theorem make_182 : make 1000 30 32 16 2319529 10712529=some row_182 := by
  have ck_0_23_0 : (Block.mk 2319529 2343960 1531 1543 1549 2319253 2319517 2319521).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1531 LCMSourcePV.PrimeFacts.prime_1543 LCMSourcePV.PrimeFacts.prime_1549 LCMSourcePV.PrimeFacts.prime_2319253 LCMSourcePV.PrimeFacts.prime_2319517 LCMSourcePV.PrimeFacts.prime_2319521
  have sh_0_23_0 : shrink 30 (Block.mk 2319529 2343960 1531 1543 1549 2319253 2319517 2319521)=some row_182 := shrink_hit _ _ ck_0_23_0
  have c0_0_23 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 9 2319256=some row_182 :=
    choose0_hit 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 8 2319256 2319253 row_182 (SearchFacts.query_1833 LCMSourcePV.PrimeFacts.prime_2319253) (by decide) sh_0_23_0
  have c0_0_22 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 10 2319276=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 9 2319276 2319257 (some row_182) (SearchFacts.query_1834 LCMSourcePV.PrimeFacts.prime_2319257) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 11 2319286=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 10 2319286 2319277 (some row_182) (SearchFacts.query_1835 LCMSourcePV.PrimeFacts.prime_2319277) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 12 2319298=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 11 2319298 2319287 (some row_182) (SearchFacts.query_1836 LCMSourcePV.PrimeFacts.prime_2319287) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 13 2319318=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 12 2319318 2319299 (some row_182) (SearchFacts.query_1837 LCMSourcePV.PrimeFacts.prime_2319299) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 14 2319322=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 13 2319322 2319319 (some row_182) (SearchFacts.query_1838 LCMSourcePV.PrimeFacts.prime_2319319) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 15 2319336=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 14 2319336 2319323 (some row_182) (SearchFacts.query_1839 LCMSourcePV.PrimeFacts.prime_2319323) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 16 2319340=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 15 2319340 2319337 (some row_182) (SearchFacts.query_1840 LCMSourcePV.PrimeFacts.prime_2319337) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 17 2319352=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 16 2319352 2319341 (some row_182) (SearchFacts.query_1841 LCMSourcePV.PrimeFacts.prime_2319341) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 18 2319370=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 17 2319370 2319353 (some row_182) (SearchFacts.query_1842 LCMSourcePV.PrimeFacts.prime_2319353) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 19 2319378=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 18 2319378 2319371 (some row_182) (SearchFacts.query_1843 LCMSourcePV.PrimeFacts.prime_2319371) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 20 2319406=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 19 2319406 2319379 (some row_182) (SearchFacts.query_1844 LCMSourcePV.PrimeFacts.prime_2319379) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 21 2319408=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 20 2319408 2319407 (some row_182) (SearchFacts.query_1845 LCMSourcePV.PrimeFacts.prime_2319407) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 22 2319412=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 21 2319412 2319409 (some row_182) (SearchFacts.query_1846 LCMSourcePV.PrimeFacts.prime_2319409) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 23 2319430=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 22 2319430 2319413 (some row_182) (SearchFacts.query_1847 LCMSourcePV.PrimeFacts.prime_2319413) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 24 2319432=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 23 2319432 2319431 (some row_182) (SearchFacts.query_1848 LCMSourcePV.PrimeFacts.prime_2319431) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 25 2319436=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 24 2319436 2319433 (some row_182) (SearchFacts.query_1849 LCMSourcePV.PrimeFacts.prime_2319433) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 26 2319460=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 25 2319460 2319437 (some row_182) (SearchFacts.query_1850 LCMSourcePV.PrimeFacts.prime_2319437) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 27 2319468=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 26 2319468 2319461 (some row_182) (SearchFacts.query_1851 LCMSourcePV.PrimeFacts.prime_2319461) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 28 2319478=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 27 2319478 2319469 (some row_182) (SearchFacts.query_1852 LCMSourcePV.PrimeFacts.prime_2319469) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 29 2319486=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 28 2319486 2319479 (some row_182) (SearchFacts.query_1853 LCMSourcePV.PrimeFacts.prime_2319479) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 30 2319502=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 29 2319502 2319487 (some row_182) (SearchFacts.query_1854 LCMSourcePV.PrimeFacts.prime_2319487) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 31 2319508=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 30 2319508 2319503 (some row_182) (SearchFacts.query_1855 LCMSourcePV.PrimeFacts.prime_2319503) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 32 2319516=(some row_182) :=
    choose0_skip 1000 30 2319529 10712529 1531 1543 1549 2319517 2319521 31 2319516 2319509 (some row_182) (SearchFacts.query_1856 LCMSourcePV.PrimeFacts.prime_2319509) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2319529 10712529 1531 1543 1549 2319521 16 2319520=some row_182 :=
    choose1_hit 1000 30 32 2319529 10712529 1531 1543 1549 2319521 15 2319520 2319517 row_182 (SearchFacts.query_1857 LCMSourcePV.PrimeFacts.prime_2319517) c0_0_0
  have hsqrt : Nat.sqrt 2319529=1523 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2319529+1)=some 1531 := by
    rw [hsqrt];exact (SearchFacts.query_4303 LCMSourcePV.PrimeFacts.prime_1531)
  exact make_hit 1000 30 32 16 2319529 10712529 1531 1543 1549 2319521 row_182 h0 (SearchFacts.query_4304 LCMSourcePV.PrimeFacts.prime_1543) (SearchFacts.query_4305 LCMSourcePV.PrimeFacts.prime_1549) (SearchFacts.query_1858 LCMSourcePV.PrimeFacts.prime_2319521) c1_0
#print axioms make_182
end LCMSourcePV.Witness.BlockProofs
