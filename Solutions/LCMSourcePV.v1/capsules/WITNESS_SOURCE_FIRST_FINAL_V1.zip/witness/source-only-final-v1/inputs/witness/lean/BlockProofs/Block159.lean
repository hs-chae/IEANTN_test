/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_159 : Block := (Block.mk 1852321 1868688 1367 1373 1381 1852283 1852289 1852307)
theorem make_159 : make 1000 30 32 16 1852321 10712529=some row_159 := by
  have ck_0_0_0 : (Block.mk 1852321 1868688 1367 1373 1381 1852283 1852289 1852307).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1367 LCMSourcePV.PrimeFacts.prime_1373 LCMSourcePV.PrimeFacts.prime_1381 LCMSourcePV.PrimeFacts.prime_1852283 LCMSourcePV.PrimeFacts.prime_1852289 LCMSourcePV.PrimeFacts.prime_1852307
  have sh_0_0_0 : shrink 30 (Block.mk 1852321 1868688 1367 1373 1381 1852283 1852289 1852307)=some row_159 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 1852321 10712529 1367 1373 1381 1852289 1852307 32 1852288=some row_159 :=
    choose0_hit 1000 30 1852321 10712529 1367 1373 1381 1852289 1852307 31 1852288 1852283 row_159 (SearchFacts.query_1655 LCMSourcePV.PrimeFacts.prime_1852283) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 1852321 10712529 1367 1373 1381 1852307 16 1852306=some row_159 :=
    choose1_hit 1000 30 32 1852321 10712529 1367 1373 1381 1852307 15 1852306 1852289 row_159 (SearchFacts.query_1656 LCMSourcePV.PrimeFacts.prime_1852289) c0_0_0
  have hsqrt : Nat.sqrt 1852321=1361 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1852321+1)=some 1367 := by
    rw [hsqrt];exact (SearchFacts.query_4280 LCMSourcePV.PrimeFacts.prime_1367)
  exact make_hit 1000 30 32 16 1852321 10712529 1367 1373 1381 1852307 row_159 h0 (SearchFacts.query_4281 LCMSourcePV.PrimeFacts.prime_1373) (SearchFacts.query_4282 LCMSourcePV.PrimeFacts.prime_1381) (SearchFacts.query_1657 LCMSourcePV.PrimeFacts.prime_1852307) c1_0
#print axioms make_159
end LCMSourcePV.Witness.BlockProofs
