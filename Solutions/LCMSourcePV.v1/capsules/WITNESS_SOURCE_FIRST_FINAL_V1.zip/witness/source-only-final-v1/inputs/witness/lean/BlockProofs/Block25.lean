/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_25 : Block := (Block.mk 187489 192720 439 443 449 187441 187471 187477)
theorem make_25 : make 1000 30 32 16 187489 10712529=some row_25 := by
  have ck_0_2_0 : (Block.mk 187489 192720 439 443 449 187441 187471 187477).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_439 LCMSourcePV.PrimeFacts.prime_443 LCMSourcePV.PrimeFacts.prime_449 LCMSourcePV.PrimeFacts.prime_187441 LCMSourcePV.PrimeFacts.prime_187471 LCMSourcePV.PrimeFacts.prime_187477
  have sh_0_2_0 : shrink 30 (Block.mk 187489 192720 439 443 449 187441 187471 187477)=some row_25 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 187489 10712529 439 443 449 187471 187477 30 187462=some row_25 :=
    choose0_hit 1000 30 187489 10712529 439 443 449 187471 187477 29 187462 187441 row_25 (SearchFacts.query_254 LCMSourcePV.PrimeFacts.prime_187441) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 187489 10712529 439 443 449 187471 187477 31 187468=(some row_25) :=
    choose0_skip 1000 30 187489 10712529 439 443 449 187471 187477 30 187468 187463 (some row_25) (SearchFacts.query_255 LCMSourcePV.PrimeFacts.prime_187463) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 187489 10712529 439 443 449 187471 187477 32 187470=(some row_25) :=
    choose0_skip 1000 30 187489 10712529 439 443 449 187471 187477 31 187470 187469 (some row_25) (SearchFacts.query_256 LCMSourcePV.PrimeFacts.prime_187469) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 187489 10712529 439 443 449 187477 16 187476=some row_25 :=
    choose1_hit 1000 30 32 187489 10712529 439 443 449 187477 15 187476 187471 row_25 (SearchFacts.query_257 LCMSourcePV.PrimeFacts.prime_187471) c0_0_0
  have hsqrt : Nat.sqrt 187489=433 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 187489+1)=some 439 := by
    rw [hsqrt];exact (SearchFacts.query_4146 LCMSourcePV.PrimeFacts.prime_439)
  exact make_hit 1000 30 32 16 187489 10712529 439 443 449 187477 row_25 h0 (SearchFacts.query_4147 LCMSourcePV.PrimeFacts.prime_443) (SearchFacts.query_4148 LCMSourcePV.PrimeFacts.prime_449) (SearchFacts.query_258 LCMSourcePV.PrimeFacts.prime_187477) c1_0
#print axioms make_25
end LCMSourcePV.Witness.BlockProofs
