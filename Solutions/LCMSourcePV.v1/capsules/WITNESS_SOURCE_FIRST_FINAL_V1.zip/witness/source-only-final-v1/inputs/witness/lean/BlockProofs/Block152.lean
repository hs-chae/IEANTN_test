/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_152 : Block := (Block.mk 1682209 1692600 1301 1303 1307 1682159 1682179 1682207)
theorem make_152 : make 1000 30 32 16 1682209 10712529=some row_152 := by
  have ck_0_0_0 : (Block.mk 1682209 1692600 1301 1303 1307 1682159 1682179 1682207).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1301 LCMSourcePV.PrimeFacts.prime_1303 LCMSourcePV.PrimeFacts.prime_1307 LCMSourcePV.PrimeFacts.prime_1682159 LCMSourcePV.PrimeFacts.prime_1682179 LCMSourcePV.PrimeFacts.prime_1682207
  have sh_0_0_0 : shrink 30 (Block.mk 1682209 1692600 1301 1303 1307 1682159 1682179 1682207)=some row_152 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 1682209 10712529 1301 1303 1307 1682179 1682207 32 1682178=some row_152 :=
    choose0_hit 1000 30 1682209 10712529 1301 1303 1307 1682179 1682207 31 1682178 1682159 row_152 (SearchFacts.query_1595 LCMSourcePV.PrimeFacts.prime_1682159) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 1682209 10712529 1301 1303 1307 1682207 16 1682206=some row_152 :=
    choose1_hit 1000 30 32 1682209 10712529 1301 1303 1307 1682207 15 1682206 1682179 row_152 (SearchFacts.query_1596 LCMSourcePV.PrimeFacts.prime_1682179) c0_0_0
  have hsqrt : Nat.sqrt 1682209=1297 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1682209+1)=some 1301 := by
    rw [hsqrt];exact (SearchFacts.query_4273 LCMSourcePV.PrimeFacts.prime_1301)
  exact make_hit 1000 30 32 16 1682209 10712529 1301 1303 1307 1682207 row_152 h0 (SearchFacts.query_4274 LCMSourcePV.PrimeFacts.prime_1303) (SearchFacts.query_4275 LCMSourcePV.PrimeFacts.prime_1307) (SearchFacts.query_1597 LCMSourcePV.PrimeFacts.prime_1682207) c1_0
#print axioms make_152
end LCMSourcePV.Witness.BlockProofs
