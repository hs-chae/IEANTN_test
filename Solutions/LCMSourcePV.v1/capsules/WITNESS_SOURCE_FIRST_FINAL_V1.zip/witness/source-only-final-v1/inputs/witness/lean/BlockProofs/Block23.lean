/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_23 : Block := (Block.mk 177241 185760 431 433 439 177127 177223 177239)
theorem make_23 : make 1000 30 32 16 177241 10712529=some row_23 := by
  have ck_0_6_0 : (Block.mk 177241 185760 431 433 439 177127 177223 177239).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_431 LCMSourcePV.PrimeFacts.prime_433 LCMSourcePV.PrimeFacts.prime_439 LCMSourcePV.PrimeFacts.prime_177127 LCMSourcePV.PrimeFacts.prime_177223 LCMSourcePV.PrimeFacts.prime_177239
  have sh_0_6_0 : shrink 30 (Block.mk 177241 185760 431 433 439 177127 177223 177239)=some row_23 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 177241 10712529 431 433 439 177223 177239 26 177130=some row_23 :=
    choose0_hit 1000 30 177241 10712529 431 433 439 177223 177239 25 177130 177127 row_23 (SearchFacts.query_238 LCMSourcePV.PrimeFacts.prime_177127) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 177241 10712529 431 433 439 177223 177239 27 177166=(some row_23) :=
    choose0_skip 1000 30 177241 10712529 431 433 439 177223 177239 26 177166 177131 (some row_23) (SearchFacts.query_239 LCMSourcePV.PrimeFacts.prime_177131) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 177241 10712529 431 433 439 177223 177239 28 177172=(some row_23) :=
    choose0_skip 1000 30 177241 10712529 431 433 439 177223 177239 27 177172 177167 (some row_23) (SearchFacts.query_240 LCMSourcePV.PrimeFacts.prime_177167) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 177241 10712529 431 433 439 177223 177239 29 177208=(some row_23) :=
    choose0_skip 1000 30 177241 10712529 431 433 439 177223 177239 28 177208 177173 (some row_23) (SearchFacts.query_241 LCMSourcePV.PrimeFacts.prime_177173) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 177241 10712529 431 433 439 177223 177239 30 177210=(some row_23) :=
    choose0_skip 1000 30 177241 10712529 431 433 439 177223 177239 29 177210 177209 (some row_23) (SearchFacts.query_242 LCMSourcePV.PrimeFacts.prime_177209) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 177241 10712529 431 433 439 177223 177239 31 177216=(some row_23) :=
    choose0_skip 1000 30 177241 10712529 431 433 439 177223 177239 30 177216 177211 (some row_23) (SearchFacts.query_243 LCMSourcePV.PrimeFacts.prime_177211) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 177241 10712529 431 433 439 177223 177239 32 177222=(some row_23) :=
    choose0_skip 1000 30 177241 10712529 431 433 439 177223 177239 31 177222 177217 (some row_23) (SearchFacts.query_244 LCMSourcePV.PrimeFacts.prime_177217) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 177241 10712529 431 433 439 177239 16 177238=some row_23 :=
    choose1_hit 1000 30 32 177241 10712529 431 433 439 177239 15 177238 177223 row_23 (SearchFacts.query_245 LCMSourcePV.PrimeFacts.prime_177223) c0_0_0
  have hsqrt : Nat.sqrt 177241=421 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 177241+1)=some 431 := by
    rw [hsqrt];exact (SearchFacts.query_4144 LCMSourcePV.PrimeFacts.prime_431)
  exact make_hit 1000 30 32 16 177241 10712529 431 433 439 177239 row_23 h0 (SearchFacts.query_4145 LCMSourcePV.PrimeFacts.prime_433) (SearchFacts.query_4146 LCMSourcePV.PrimeFacts.prime_439) (SearchFacts.query_246 LCMSourcePV.PrimeFacts.prime_177239) c1_0
#print axioms make_23
end LCMSourcePV.Witness.BlockProofs
