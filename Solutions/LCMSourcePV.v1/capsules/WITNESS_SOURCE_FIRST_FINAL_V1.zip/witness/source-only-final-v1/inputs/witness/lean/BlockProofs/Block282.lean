/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_282 : Block := (Block.mk 5257849 5276208 2297 2309 2311 5257597 5257807 5257829)
theorem make_282 : make 1000 30 32 16 5257849 10712529=some row_282 := by
  have ck_0_11_0 : (Block.mk 5257849 5276208 2297 2309 2311 5257597 5257807 5257829).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2297 LCMSourcePV.PrimeFacts.prime_2309 LCMSourcePV.PrimeFacts.prime_2311 LCMSourcePV.PrimeFacts.prime_5257597 LCMSourcePV.PrimeFacts.prime_5257807 LCMSourcePV.PrimeFacts.prime_5257829
  have sh_0_11_0 : shrink 30 (Block.mk 5257849 5276208 2297 2309 2311 5257597 5257807 5257829)=some row_282 := shrink_hit _ _ ck_0_11_0
  have c0_0_11 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 21 5257618=some row_282 :=
    choose0_hit 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 20 5257618 5257597 row_282 (SearchFacts.query_2839 LCMSourcePV.PrimeFacts.prime_5257597) (by decide) sh_0_11_0
  have c0_0_10 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 22 5257626=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 21 5257626 5257619 (some row_282) (SearchFacts.query_2840 LCMSourcePV.PrimeFacts.prime_5257619) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 23 5257710=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 22 5257710 5257627 (some row_282) (SearchFacts.query_2841 LCMSourcePV.PrimeFacts.prime_5257627) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 24 5257722=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 23 5257722 5257711 (some row_282) (SearchFacts.query_2842 LCMSourcePV.PrimeFacts.prime_5257711) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 25 5257726=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 24 5257726 5257723 (some row_282) (SearchFacts.query_2843 LCMSourcePV.PrimeFacts.prime_5257723) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 26 5257740=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 25 5257740 5257727 (some row_282) (SearchFacts.query_2844 LCMSourcePV.PrimeFacts.prime_5257727) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 27 5257770=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 26 5257770 5257741 (some row_282) (SearchFacts.query_2845 LCMSourcePV.PrimeFacts.prime_5257741) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 28 5257780=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 27 5257780 5257771 (some row_282) (SearchFacts.query_2846 LCMSourcePV.PrimeFacts.prime_5257771) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 29 5257782=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 28 5257782 5257781 (some row_282) (SearchFacts.query_2847 LCMSourcePV.PrimeFacts.prime_5257781) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 30 5257788=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 29 5257788 5257783 (some row_282) (SearchFacts.query_2848 LCMSourcePV.PrimeFacts.prime_5257783) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 31 5257792=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 30 5257792 5257789 (some row_282) (SearchFacts.query_2849 LCMSourcePV.PrimeFacts.prime_5257789) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 32 5257806=(some row_282) :=
    choose0_skip 1000 30 5257849 10712529 2297 2309 2311 5257807 5257829 31 5257806 5257793 (some row_282) (SearchFacts.query_2850 LCMSourcePV.PrimeFacts.prime_5257793) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5257849 10712529 2297 2309 2311 5257829 16 5257828=some row_282 :=
    choose1_hit 1000 30 32 5257849 10712529 2297 2309 2311 5257829 15 5257828 5257807 row_282 (SearchFacts.query_2851 LCMSourcePV.PrimeFacts.prime_5257807) c0_0_0
  have hsqrt : Nat.sqrt 5257849=2293 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5257849+1)=some 2297 := by
    rw [hsqrt];exact (SearchFacts.query_4403 LCMSourcePV.PrimeFacts.prime_2297)
  exact make_hit 1000 30 32 16 5257849 10712529 2297 2309 2311 5257829 row_282 h0 (SearchFacts.query_4404 LCMSourcePV.PrimeFacts.prime_2309) (SearchFacts.query_4405 LCMSourcePV.PrimeFacts.prime_2311) (SearchFacts.query_2852 LCMSourcePV.PrimeFacts.prime_5257829) c1_0
#print axioms make_282
end LCMSourcePV.Witness.BlockProofs
