/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_107 : Block := (Block.mk 966289 982080 991 997 1009 966013 966257 966271)
theorem make_107 : make 1000 30 32 16 966289 10712529=some row_107 := by
  have ck_0_15_0 : (Block.mk 966289 982080 991 997 1009 966013 966257 966271).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_991 LCMSourcePV.PrimeFacts.prime_997 LCMSourcePV.PrimeFacts.prime_1009 LCMSourcePV.PrimeFacts.prime_966013 LCMSourcePV.PrimeFacts.prime_966257 LCMSourcePV.PrimeFacts.prime_966271
  have sh_0_15_0 : shrink 30 (Block.mk 966289 982080 991 997 1009 966013 966257 966271)=some row_107 := shrink_hit _ _ ck_0_15_0
  have c0_0_15 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 17 966028=some row_107 :=
    choose0_hit 1000 30 966289 10712529 991 997 1009 966257 966271 16 966028 966013 row_107 (SearchFacts.query_1097 LCMSourcePV.PrimeFacts.prime_966013) (by decide) sh_0_15_0
  have c0_0_14 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 18 966040=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 17 966040 966029 (some row_107) (SearchFacts.query_1098 LCMSourcePV.PrimeFacts.prime_966029) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 19 966108=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 18 966108 966041 (some row_107) (SearchFacts.query_1099 LCMSourcePV.PrimeFacts.prime_966041) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 20 966112=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 19 966112 966109 (some row_107) (SearchFacts.query_1100 LCMSourcePV.PrimeFacts.prime_966109) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 21 966138=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 20 966138 966113 (some row_107) (SearchFacts.query_1101 LCMSourcePV.PrimeFacts.prime_966113) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 22 966148=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 21 966148 966139 (some row_107) (SearchFacts.query_1102 LCMSourcePV.PrimeFacts.prime_966139) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 23 966156=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 22 966156 966149 (some row_107) (SearchFacts.query_1103 LCMSourcePV.PrimeFacts.prime_966149) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 24 966190=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 23 966190 966157 (some row_107) (SearchFacts.query_1104 LCMSourcePV.PrimeFacts.prime_966157) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 25 966196=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 24 966196 966191 (some row_107) (SearchFacts.query_1105 LCMSourcePV.PrimeFacts.prime_966191) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 26 966208=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 25 966208 966197 (some row_107) (SearchFacts.query_1106 LCMSourcePV.PrimeFacts.prime_966197) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 27 966210=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 26 966210 966209 (some row_107) (SearchFacts.query_1107 LCMSourcePV.PrimeFacts.prime_966209) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 28 966220=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 27 966220 966211 (some row_107) (SearchFacts.query_1108 LCMSourcePV.PrimeFacts.prime_966211) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 29 966226=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 28 966226 966221 (some row_107) (SearchFacts.query_1109 LCMSourcePV.PrimeFacts.prime_966221) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 30 966232=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 29 966232 966227 (some row_107) (SearchFacts.query_1110 LCMSourcePV.PrimeFacts.prime_966227) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 31 966240=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 30 966240 966233 (some row_107) (SearchFacts.query_1111 LCMSourcePV.PrimeFacts.prime_966233) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 966289 10712529 991 997 1009 966257 966271 32 966256=(some row_107) :=
    choose0_skip 1000 30 966289 10712529 991 997 1009 966257 966271 31 966256 966241 (some row_107) (SearchFacts.query_1112 LCMSourcePV.PrimeFacts.prime_966241) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 966289 10712529 991 997 1009 966271 16 966270=some row_107 :=
    choose1_hit 1000 30 32 966289 10712529 991 997 1009 966271 15 966270 966257 row_107 (SearchFacts.query_1113 LCMSourcePV.PrimeFacts.prime_966257) c0_0_0
  have hsqrt : Nat.sqrt 966289=983 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 966289+1)=some 991 := by
    rw [hsqrt];exact (SearchFacts.query_4228 LCMSourcePV.PrimeFacts.prime_991)
  exact make_hit 1000 30 32 16 966289 10712529 991 997 1009 966271 row_107 h0 (SearchFacts.query_4229 LCMSourcePV.PrimeFacts.prime_997) (SearchFacts.query_4230 LCMSourcePV.PrimeFacts.prime_1009) (SearchFacts.query_1114 LCMSourcePV.PrimeFacts.prime_966271) c1_0
#print axioms make_107
end LCMSourcePV.Witness.BlockProofs
