/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_252 : Block := (Block.mk 4255969 4280760 2069 2081 2083 4255939 4255949 4255963)
theorem make_252 : make 1000 30 32 16 4255969 10712529=some row_252 := by
  have ck_0_0_0 : (Block.mk 4255969 4280760 2069 2081 2083 4255939 4255949 4255963).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2069 LCMSourcePV.PrimeFacts.prime_2081 LCMSourcePV.PrimeFacts.prime_2083 LCMSourcePV.PrimeFacts.prime_4255939 LCMSourcePV.PrimeFacts.prime_4255949 LCMSourcePV.PrimeFacts.prime_4255963
  have sh_0_0_0 : shrink 30 (Block.mk 4255969 4280760 2069 2081 2083 4255939 4255949 4255963)=some row_252 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 4255969 10712529 2069 2081 2083 4255949 4255963 32 4255948=some row_252 :=
    choose0_hit 1000 30 4255969 10712529 2069 2081 2083 4255949 4255963 31 4255948 4255939 row_252 (SearchFacts.query_2574 LCMSourcePV.PrimeFacts.prime_4255939) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 4255969 10712529 2069 2081 2083 4255963 16 4255962=some row_252 :=
    choose1_hit 1000 30 32 4255969 10712529 2069 2081 2083 4255963 15 4255962 4255949 row_252 (SearchFacts.query_2575 LCMSourcePV.PrimeFacts.prime_4255949) c0_0_0
  have hsqrt : Nat.sqrt 4255969=2063 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4255969+1)=some 2069 := by
    rw [hsqrt];exact (SearchFacts.query_4373 LCMSourcePV.PrimeFacts.prime_2069)
  exact make_hit 1000 30 32 16 4255969 10712529 2069 2081 2083 4255963 row_252 h0 (SearchFacts.query_4374 LCMSourcePV.PrimeFacts.prime_2081) (SearchFacts.query_4375 LCMSourcePV.PrimeFacts.prime_2083) (SearchFacts.query_2576 LCMSourcePV.PrimeFacts.prime_4255963) c1_0
#print axioms make_252
end LCMSourcePV.Witness.BlockProofs
