/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_240 : Block := (Block.mk 3916441 3948168 1987 1993 1997 3916391 3916433 3916439)
theorem make_240 : make 1000 30 32 16 3916441 10712529=some row_240 := by
  have ck_0_2_0 : (Block.mk 3916441 3948168 1987 1993 1997 3916391 3916433 3916439).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1987 LCMSourcePV.PrimeFacts.prime_1993 LCMSourcePV.PrimeFacts.prime_1997 LCMSourcePV.PrimeFacts.prime_3916391 LCMSourcePV.PrimeFacts.prime_3916433 LCMSourcePV.PrimeFacts.prime_3916439
  have sh_0_2_0 : shrink 30 (Block.mk 3916441 3948168 1987 1993 1997 3916391 3916433 3916439)=some row_240 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 3916441 10712529 1987 1993 1997 3916433 3916439 30 3916402=some row_240 :=
    choose0_hit 1000 30 3916441 10712529 1987 1993 1997 3916433 3916439 29 3916402 3916391 row_240 (SearchFacts.query_2439 LCMSourcePV.PrimeFacts.prime_3916391) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 3916441 10712529 1987 1993 1997 3916433 3916439 31 3916410=(some row_240) :=
    choose0_skip 1000 30 3916441 10712529 1987 1993 1997 3916433 3916439 30 3916410 3916403 (some row_240) (SearchFacts.query_2440 LCMSourcePV.PrimeFacts.prime_3916403) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3916441 10712529 1987 1993 1997 3916433 3916439 32 3916432=(some row_240) :=
    choose0_skip 1000 30 3916441 10712529 1987 1993 1997 3916433 3916439 31 3916432 3916411 (some row_240) (SearchFacts.query_2441 LCMSourcePV.PrimeFacts.prime_3916411) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3916441 10712529 1987 1993 1997 3916439 16 3916438=some row_240 :=
    choose1_hit 1000 30 32 3916441 10712529 1987 1993 1997 3916439 15 3916438 3916433 row_240 (SearchFacts.query_2442 LCMSourcePV.PrimeFacts.prime_3916433) c0_0_0
  have hsqrt : Nat.sqrt 3916441=1979 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3916441+1)=some 1987 := by
    rw [hsqrt];exact (SearchFacts.query_4361 LCMSourcePV.PrimeFacts.prime_1987)
  exact make_hit 1000 30 32 16 3916441 10712529 1987 1993 1997 3916439 row_240 h0 (SearchFacts.query_4362 LCMSourcePV.PrimeFacts.prime_1993) (SearchFacts.query_4363 LCMSourcePV.PrimeFacts.prime_1997) (SearchFacts.query_2443 LCMSourcePV.PrimeFacts.prime_3916439) c1_0
#print axioms make_240
end LCMSourcePV.Witness.BlockProofs
