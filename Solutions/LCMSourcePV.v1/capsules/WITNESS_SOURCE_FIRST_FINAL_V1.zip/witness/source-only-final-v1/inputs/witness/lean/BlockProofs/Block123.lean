/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_123 : Block := (Block.mk 1190281 1194648 1093 1097 1103 1190149 1190263 1190279)
theorem make_123 : make 1000 30 32 16 1190281 10712529=some row_123 := by
  have ck_0_6_0 : (Block.mk 1190281 1194648 1093 1097 1103 1190149 1190263 1190279).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1093 LCMSourcePV.PrimeFacts.prime_1097 LCMSourcePV.PrimeFacts.prime_1103 LCMSourcePV.PrimeFacts.prime_1190149 LCMSourcePV.PrimeFacts.prime_1190263 LCMSourcePV.PrimeFacts.prime_1190279
  have sh_0_6_0 : shrink 30 (Block.mk 1190281 1194648 1093 1097 1103 1190149 1190263 1190279)=some row_123 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 26 1190158=some row_123 :=
    choose0_hit 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 25 1190158 1190149 row_123 (SearchFacts.query_1273 LCMSourcePV.PrimeFacts.prime_1190149) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 27 1190176=(some row_123) :=
    choose0_skip 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 26 1190176 1190159 (some row_123) (SearchFacts.query_1274 LCMSourcePV.PrimeFacts.prime_1190159) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 28 1190200=(some row_123) :=
    choose0_skip 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 27 1190200 1190177 (some row_123) (SearchFacts.query_1275 LCMSourcePV.PrimeFacts.prime_1190177) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 29 1190236=(some row_123) :=
    choose0_skip 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 28 1190236 1190201 (some row_123) (SearchFacts.query_1276 LCMSourcePV.PrimeFacts.prime_1190201) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 30 1190248=(some row_123) :=
    choose0_skip 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 29 1190248 1190237 (some row_123) (SearchFacts.query_1277 LCMSourcePV.PrimeFacts.prime_1190237) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 31 1190260=(some row_123) :=
    choose0_skip 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 30 1190260 1190249 (some row_123) (SearchFacts.query_1278 LCMSourcePV.PrimeFacts.prime_1190249) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 32 1190262=(some row_123) :=
    choose0_skip 1000 30 1190281 10712529 1093 1097 1103 1190263 1190279 31 1190262 1190261 (some row_123) (SearchFacts.query_1279 LCMSourcePV.PrimeFacts.prime_1190261) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1190281 10712529 1093 1097 1103 1190279 16 1190278=some row_123 :=
    choose1_hit 1000 30 32 1190281 10712529 1093 1097 1103 1190279 15 1190278 1190263 row_123 (SearchFacts.query_1280 LCMSourcePV.PrimeFacts.prime_1190263) c0_0_0
  have hsqrt : Nat.sqrt 1190281=1091 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1190281+1)=some 1093 := by
    rw [hsqrt];exact (SearchFacts.query_4244 LCMSourcePV.PrimeFacts.prime_1093)
  exact make_hit 1000 30 32 16 1190281 10712529 1093 1097 1103 1190279 row_123 h0 (SearchFacts.query_4245 LCMSourcePV.PrimeFacts.prime_1097) (SearchFacts.query_4246 LCMSourcePV.PrimeFacts.prime_1103) (SearchFacts.query_1281 LCMSourcePV.PrimeFacts.prime_1190279) c1_0
#print axioms make_123
end LCMSourcePV.Witness.BlockProofs
