/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_138 : Block := (Block.mk 1442401 1471368 1213 1217 1223 1442267 1442377 1442393)
theorem make_138 : make 1000 30 32 16 1442401 10712529=some row_138 := by
  have ck_0_8_0 : (Block.mk 1442401 1471368 1213 1217 1223 1442267 1442377 1442393).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1213 LCMSourcePV.PrimeFacts.prime_1217 LCMSourcePV.PrimeFacts.prime_1223 LCMSourcePV.PrimeFacts.prime_1442267 LCMSourcePV.PrimeFacts.prime_1442377 LCMSourcePV.PrimeFacts.prime_1442393
  have sh_0_8_0 : shrink 30 (Block.mk 1442401 1471368 1213 1217 1223 1442267 1442377 1442393)=some row_138 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 24 1442278=some row_138 :=
    choose0_hit 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 23 1442278 1442267 row_138 (SearchFacts.query_1490 LCMSourcePV.PrimeFacts.prime_1442267) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 25 1442298=(some row_138) :=
    choose0_skip 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 24 1442298 1442279 (some row_138) (SearchFacts.query_1491 LCMSourcePV.PrimeFacts.prime_1442279) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 26 1442316=(some row_138) :=
    choose0_skip 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 25 1442316 1442299 (some row_138) (SearchFacts.query_1492 LCMSourcePV.PrimeFacts.prime_1442299) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 27 1442320=(some row_138) :=
    choose0_skip 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 26 1442320 1442317 (some row_138) (SearchFacts.query_1493 LCMSourcePV.PrimeFacts.prime_1442317) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 28 1442326=(some row_138) :=
    choose0_skip 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 27 1442326 1442321 (some row_138) (SearchFacts.query_1494 LCMSourcePV.PrimeFacts.prime_1442321) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 29 1442332=(some row_138) :=
    choose0_skip 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 28 1442332 1442327 (some row_138) (SearchFacts.query_1495 LCMSourcePV.PrimeFacts.prime_1442327) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 30 1442340=(some row_138) :=
    choose0_skip 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 29 1442340 1442333 (some row_138) (SearchFacts.query_1496 LCMSourcePV.PrimeFacts.prime_1442333) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 31 1442350=(some row_138) :=
    choose0_skip 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 30 1442350 1442341 (some row_138) (SearchFacts.query_1497 LCMSourcePV.PrimeFacts.prime_1442341) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 32 1442376=(some row_138) :=
    choose0_skip 1000 30 1442401 10712529 1213 1217 1223 1442377 1442393 31 1442376 1442351 (some row_138) (SearchFacts.query_1498 LCMSourcePV.PrimeFacts.prime_1442351) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1442401 10712529 1213 1217 1223 1442393 16 1442392=some row_138 :=
    choose1_hit 1000 30 32 1442401 10712529 1213 1217 1223 1442393 15 1442392 1442377 row_138 (SearchFacts.query_1499 LCMSourcePV.PrimeFacts.prime_1442377) c0_0_0
  have hsqrt : Nat.sqrt 1442401=1201 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1442401+1)=some 1213 := by
    rw [hsqrt];exact (SearchFacts.query_4259 LCMSourcePV.PrimeFacts.prime_1213)
  exact make_hit 1000 30 32 16 1442401 10712529 1213 1217 1223 1442393 row_138 h0 (SearchFacts.query_4260 LCMSourcePV.PrimeFacts.prime_1217) (SearchFacts.query_4261 LCMSourcePV.PrimeFacts.prime_1223) (SearchFacts.query_1500 LCMSourcePV.PrimeFacts.prime_1442393) c1_0
#print axioms make_138
end LCMSourcePV.Witness.BlockProofs
