/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_130 : Block := (Block.mk 1274641 1324800 1151 1153 1163 1274509 1274629 1274633)
theorem make_130 : make 1000 30 32 16 1274641 10712529=some row_130 := by
  have ck_0_6_0 : (Block.mk 1274641 1324800 1151 1153 1163 1274509 1274629 1274633).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1151 LCMSourcePV.PrimeFacts.prime_1153 LCMSourcePV.PrimeFacts.prime_1163 LCMSourcePV.PrimeFacts.prime_1274509 LCMSourcePV.PrimeFacts.prime_1274629 LCMSourcePV.PrimeFacts.prime_1274633
  have sh_0_6_0 : shrink 30 (Block.mk 1274641 1324800 1151 1153 1163 1274509 1274629 1274633)=some row_130 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 26 1274548=some row_130 :=
    choose0_hit 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 25 1274548 1274509 row_130 (SearchFacts.query_1402 LCMSourcePV.PrimeFacts.prime_1274509) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 27 1274556=(some row_130) :=
    choose0_skip 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 26 1274556 1274549 (some row_130) (SearchFacts.query_1403 LCMSourcePV.PrimeFacts.prime_1274549) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 28 1274560=(some row_130) :=
    choose0_skip 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 27 1274560 1274557 (some row_130) (SearchFacts.query_1404 LCMSourcePV.PrimeFacts.prime_1274557) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 29 1274598=(some row_130) :=
    choose0_skip 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 28 1274598 1274561 (some row_130) (SearchFacts.query_1405 LCMSourcePV.PrimeFacts.prime_1274561) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 30 1274616=(some row_130) :=
    choose0_skip 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 29 1274616 1274599 (some row_130) (SearchFacts.query_1406 LCMSourcePV.PrimeFacts.prime_1274599) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 31 1274620=(some row_130) :=
    choose0_skip 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 30 1274620 1274617 (some row_130) (SearchFacts.query_1407 LCMSourcePV.PrimeFacts.prime_1274617) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 32 1274628=(some row_130) :=
    choose0_skip 1000 30 1274641 10712529 1151 1153 1163 1274629 1274633 31 1274628 1274621 (some row_130) (SearchFacts.query_1408 LCMSourcePV.PrimeFacts.prime_1274621) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1274641 10712529 1151 1153 1163 1274633 16 1274632=some row_130 :=
    choose1_hit 1000 30 32 1274641 10712529 1151 1153 1163 1274633 15 1274632 1274629 row_130 (SearchFacts.query_1409 LCMSourcePV.PrimeFacts.prime_1274629) c0_0_0
  have hsqrt : Nat.sqrt 1274641=1129 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1274641+1)=some 1151 := by
    rw [hsqrt];exact (SearchFacts.query_4251 LCMSourcePV.PrimeFacts.prime_1151)
  exact make_hit 1000 30 32 16 1274641 10712529 1151 1153 1163 1274633 row_130 h0 (SearchFacts.query_4252 LCMSourcePV.PrimeFacts.prime_1153) (SearchFacts.query_4253 LCMSourcePV.PrimeFacts.prime_1163) (SearchFacts.query_1410 LCMSourcePV.PrimeFacts.prime_1274633) c1_0
#print axioms make_130
end LCMSourcePV.Witness.BlockProofs
