/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_237 : Block := (Block.mk 3798601 3806400 1951 1973 1979 3798467 3798589 3798593)
theorem make_237 : make 1000 30 32 16 3798601 10712529=some row_237 := by
  have ck_0_10_0 : (Block.mk 3798601 3806400 1951 1973 1979 3798467 3798589 3798593).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1951 LCMSourcePV.PrimeFacts.prime_1973 LCMSourcePV.PrimeFacts.prime_1979 LCMSourcePV.PrimeFacts.prime_3798467 LCMSourcePV.PrimeFacts.prime_3798589 LCMSourcePV.PrimeFacts.prime_3798593
  have sh_0_10_0 : shrink 30 (Block.mk 3798601 3806400 1951 1973 1979 3798467 3798589 3798593)=some row_237 := shrink_hit _ _ ck_0_10_0
  have c0_0_10 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 22 3798468=some row_237 :=
    choose0_hit 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 21 3798468 3798467 row_237 (SearchFacts.query_2419 LCMSourcePV.PrimeFacts.prime_3798467) (by decide) sh_0_10_0
  have c0_0_9 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 23 3798480=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 22 3798480 3798469 (some row_237) (SearchFacts.query_2420 LCMSourcePV.PrimeFacts.prime_3798469) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 24 3798516=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 23 3798516 3798481 (some row_237) (SearchFacts.query_2421 LCMSourcePV.PrimeFacts.prime_3798481) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 25 3798520=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 24 3798520 3798517 (some row_237) (SearchFacts.query_2422 LCMSourcePV.PrimeFacts.prime_3798517) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 26 3798532=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 25 3798532 3798521 (some row_237) (SearchFacts.query_2423 LCMSourcePV.PrimeFacts.prime_3798521) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 27 3798538=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 26 3798538 3798533 (some row_237) (SearchFacts.query_2424 LCMSourcePV.PrimeFacts.prime_3798533) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 28 3798546=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 27 3798546 3798539 (some row_237) (SearchFacts.query_2425 LCMSourcePV.PrimeFacts.prime_3798539) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 29 3798568=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 28 3798568 3798547 (some row_237) (SearchFacts.query_2426 LCMSourcePV.PrimeFacts.prime_3798547) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 30 3798580=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 29 3798580 3798569 (some row_237) (SearchFacts.query_2427 LCMSourcePV.PrimeFacts.prime_3798569) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 31 3798582=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 30 3798582 3798581 (some row_237) (SearchFacts.query_2428 LCMSourcePV.PrimeFacts.prime_3798581) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 32 3798588=(some row_237) :=
    choose0_skip 1000 30 3798601 10712529 1951 1973 1979 3798589 3798593 31 3798588 3798583 (some row_237) (SearchFacts.query_2429 LCMSourcePV.PrimeFacts.prime_3798583) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3798601 10712529 1951 1973 1979 3798593 16 3798592=some row_237 :=
    choose1_hit 1000 30 32 3798601 10712529 1951 1973 1979 3798593 15 3798592 3798589 row_237 (SearchFacts.query_2430 LCMSourcePV.PrimeFacts.prime_3798589) c0_0_0
  have hsqrt : Nat.sqrt 3798601=1949 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3798601+1)=some 1951 := by
    rw [hsqrt];exact (SearchFacts.query_4358 LCMSourcePV.PrimeFacts.prime_1951)
  exact make_hit 1000 30 32 16 3798601 10712529 1951 1973 1979 3798593 row_237 h0 (SearchFacts.query_4359 LCMSourcePV.PrimeFacts.prime_1973) (SearchFacts.query_4360 LCMSourcePV.PrimeFacts.prime_1979) (SearchFacts.query_2431 LCMSourcePV.PrimeFacts.prime_3798593) c1_0
#print axioms make_237
end LCMSourcePV.Witness.BlockProofs
