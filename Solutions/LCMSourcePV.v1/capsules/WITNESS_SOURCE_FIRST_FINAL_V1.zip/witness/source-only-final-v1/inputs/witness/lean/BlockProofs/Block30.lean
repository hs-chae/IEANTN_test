/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_30 : Block := (Block.mk 212521 214368 463 467 479 212209 212501 212507)
theorem make_30 : make 1000 30 32 16 212521 10712529=some row_30 := by
  have ck_0_18_0 : (Block.mk 212521 214368 463 467 479 212209 212501 212507).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_463 LCMSourcePV.PrimeFacts.prime_467 LCMSourcePV.PrimeFacts.prime_479 LCMSourcePV.PrimeFacts.prime_212209 LCMSourcePV.PrimeFacts.prime_212501 LCMSourcePV.PrimeFacts.prime_212507
  have sh_0_18_0 : shrink 30 (Block.mk 212521 214368 463 467 479 212209 212501 212507)=some row_30 := shrink_hit _ _ ck_0_18_0
  have c0_0_18 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 14 212226=some row_30 :=
    choose0_hit 1000 30 212521 10712529 463 467 479 212501 212507 13 212226 212209 row_30 (SearchFacts.query_301 LCMSourcePV.PrimeFacts.prime_212209) (by decide) sh_0_18_0
  have c0_0_17 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 15 212238=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 14 212238 212227 (some row_30) (SearchFacts.query_302 LCMSourcePV.PrimeFacts.prime_212227) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 16 212242=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 15 212242 212239 (some row_30) (SearchFacts.query_303 LCMSourcePV.PrimeFacts.prime_212239) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 17 212280=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 16 212280 212243 (some row_30) (SearchFacts.query_304 LCMSourcePV.PrimeFacts.prime_212243) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 18 212292=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 17 212292 212281 (some row_30) (SearchFacts.query_305 LCMSourcePV.PrimeFacts.prime_212281) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 19 212296=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 18 212296 212293 (some row_30) (SearchFacts.query_306 LCMSourcePV.PrimeFacts.prime_212293) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 20 212352=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 19 212352 212297 (some row_30) (SearchFacts.query_307 LCMSourcePV.PrimeFacts.prime_212297) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 21 212368=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 20 212368 212353 (some row_30) (SearchFacts.query_308 LCMSourcePV.PrimeFacts.prime_212353) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 22 212382=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 21 212382 212369 (some row_30) (SearchFacts.query_309 LCMSourcePV.PrimeFacts.prime_212369) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 23 212410=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 22 212410 212383 (some row_30) (SearchFacts.query_310 LCMSourcePV.PrimeFacts.prime_212383) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 24 212418=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 23 212418 212411 (some row_30) (SearchFacts.query_311 LCMSourcePV.PrimeFacts.prime_212411) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 25 212422=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 24 212422 212419 (some row_30) (SearchFacts.query_312 LCMSourcePV.PrimeFacts.prime_212419) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 26 212436=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 25 212436 212423 (some row_30) (SearchFacts.query_313 LCMSourcePV.PrimeFacts.prime_212423) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 27 212446=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 26 212446 212437 (some row_30) (SearchFacts.query_314 LCMSourcePV.PrimeFacts.prime_212437) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 28 212452=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 27 212452 212447 (some row_30) (SearchFacts.query_315 LCMSourcePV.PrimeFacts.prime_212447) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 29 212460=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 28 212460 212453 (some row_30) (SearchFacts.query_316 LCMSourcePV.PrimeFacts.prime_212453) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 30 212466=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 29 212466 212461 (some row_30) (SearchFacts.query_317 LCMSourcePV.PrimeFacts.prime_212461) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 31 212478=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 30 212478 212467 (some row_30) (SearchFacts.query_318 LCMSourcePV.PrimeFacts.prime_212467) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 212521 10712529 463 467 479 212501 212507 32 212500=(some row_30) :=
    choose0_skip 1000 30 212521 10712529 463 467 479 212501 212507 31 212500 212479 (some row_30) (SearchFacts.query_319 LCMSourcePV.PrimeFacts.prime_212479) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 212521 10712529 463 467 479 212507 16 212506=some row_30 :=
    choose1_hit 1000 30 32 212521 10712529 463 467 479 212507 15 212506 212501 row_30 (SearchFacts.query_320 LCMSourcePV.PrimeFacts.prime_212501) c0_0_0
  have hsqrt : Nat.sqrt 212521=461 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 212521+1)=some 463 := by
    rw [hsqrt];exact (SearchFacts.query_4151 LCMSourcePV.PrimeFacts.prime_463)
  exact make_hit 1000 30 32 16 212521 10712529 463 467 479 212507 row_30 h0 (SearchFacts.query_4152 LCMSourcePV.PrimeFacts.prime_467) (SearchFacts.query_4153 LCMSourcePV.PrimeFacts.prime_479) (SearchFacts.query_321 LCMSourcePV.PrimeFacts.prime_212507) c1_0
#print axioms make_30
end LCMSourcePV.Witness.BlockProofs
