/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_131 : Block := (Block.mk 1324801 1329408 1153 1163 1171 1324451 1324753 1324783)
theorem make_131 : make 1000 30 32 16 1324801 10712529=some row_131 := by
  have ck_0_24_0 : (Block.mk 1324801 1329408 1153 1163 1171 1324451 1324753 1324783).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1153 LCMSourcePV.PrimeFacts.prime_1163 LCMSourcePV.PrimeFacts.prime_1171 LCMSourcePV.PrimeFacts.prime_1324451 LCMSourcePV.PrimeFacts.prime_1324753 LCMSourcePV.PrimeFacts.prime_1324783
  have sh_0_24_0 : shrink 30 (Block.mk 1324801 1329408 1153 1163 1171 1324451 1324753 1324783)=some row_131 := shrink_hit _ _ ck_0_24_0
  have c0_0_24 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 8 1324456=some row_131 :=
    choose0_hit 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 7 1324456 1324451 row_131 (SearchFacts.query_1411 LCMSourcePV.PrimeFacts.prime_1324451) (by decide) sh_0_24_0
  have c0_0_23 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 9 1324480=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 8 1324480 1324457 (some row_131) (SearchFacts.query_1412 LCMSourcePV.PrimeFacts.prime_1324457) (by decide) c0_0_24
  have c0_0_22 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 10 1324510=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 9 1324510 1324481 (some row_131) (SearchFacts.query_1413 LCMSourcePV.PrimeFacts.prime_1324481) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 11 1324512=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 10 1324512 1324511 (some row_131) (SearchFacts.query_1414 LCMSourcePV.PrimeFacts.prime_1324511) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 12 1324566=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 11 1324566 1324513 (some row_131) (SearchFacts.query_1415 LCMSourcePV.PrimeFacts.prime_1324513) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 13 1324570=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 12 1324570 1324567 (some row_131) (SearchFacts.query_1416 LCMSourcePV.PrimeFacts.prime_1324567) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 14 1324572=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 13 1324572 1324571 (some row_131) (SearchFacts.query_1417 LCMSourcePV.PrimeFacts.prime_1324571) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 15 1324576=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 14 1324576 1324573 (some row_131) (SearchFacts.query_1418 LCMSourcePV.PrimeFacts.prime_1324573) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 16 1324578=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 15 1324578 1324577 (some row_131) (SearchFacts.query_1419 LCMSourcePV.PrimeFacts.prime_1324577) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 17 1324590=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 16 1324590 1324579 (some row_131) (SearchFacts.query_1420 LCMSourcePV.PrimeFacts.prime_1324579) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 18 1324606=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 17 1324606 1324591 (some row_131) (SearchFacts.query_1421 LCMSourcePV.PrimeFacts.prime_1324591) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 19 1324612=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 18 1324612 1324607 (some row_131) (SearchFacts.query_1422 LCMSourcePV.PrimeFacts.prime_1324607) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 20 1324618=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 19 1324618 1324613 (some row_131) (SearchFacts.query_1423 LCMSourcePV.PrimeFacts.prime_1324613) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 21 1324620=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 20 1324620 1324619 (some row_131) (SearchFacts.query_1424 LCMSourcePV.PrimeFacts.prime_1324619) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 22 1324626=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 21 1324626 1324621 (some row_131) (SearchFacts.query_1425 LCMSourcePV.PrimeFacts.prime_1324621) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 23 1324648=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 22 1324648 1324627 (some row_131) (SearchFacts.query_1426 LCMSourcePV.PrimeFacts.prime_1324627) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 24 1324650=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 23 1324650 1324649 (some row_131) (SearchFacts.query_1427 LCMSourcePV.PrimeFacts.prime_1324649) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 25 1324662=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 24 1324662 1324651 (some row_131) (SearchFacts.query_1428 LCMSourcePV.PrimeFacts.prime_1324651) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 26 1324666=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 25 1324666 1324663 (some row_131) (SearchFacts.query_1429 LCMSourcePV.PrimeFacts.prime_1324663) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 27 1324678=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 26 1324678 1324667 (some row_131) (SearchFacts.query_1430 LCMSourcePV.PrimeFacts.prime_1324667) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 28 1324680=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 27 1324680 1324679 (some row_131) (SearchFacts.query_1431 LCMSourcePV.PrimeFacts.prime_1324679) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 29 1324716=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 28 1324716 1324681 (some row_131) (SearchFacts.query_1432 LCMSourcePV.PrimeFacts.prime_1324681) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 30 1324720=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 29 1324720 1324717 (some row_131) (SearchFacts.query_1433 LCMSourcePV.PrimeFacts.prime_1324717) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 31 1324732=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 30 1324732 1324721 (some row_131) (SearchFacts.query_1434 LCMSourcePV.PrimeFacts.prime_1324721) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 32 1324752=(some row_131) :=
    choose0_skip 1000 30 1324801 10712529 1153 1163 1171 1324753 1324783 31 1324752 1324733 (some row_131) (SearchFacts.query_1435 LCMSourcePV.PrimeFacts.prime_1324733) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1324801 10712529 1153 1163 1171 1324783 16 1324782=some row_131 :=
    choose1_hit 1000 30 32 1324801 10712529 1153 1163 1171 1324783 15 1324782 1324753 row_131 (SearchFacts.query_1436 LCMSourcePV.PrimeFacts.prime_1324753) c0_0_0
  have hsqrt : Nat.sqrt 1324801=1151 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1324801+1)=some 1153 := by
    rw [hsqrt];exact (SearchFacts.query_4252 LCMSourcePV.PrimeFacts.prime_1153)
  exact make_hit 1000 30 32 16 1324801 10712529 1153 1163 1171 1324783 row_131 h0 (SearchFacts.query_4253 LCMSourcePV.PrimeFacts.prime_1163) (SearchFacts.query_4254 LCMSourcePV.PrimeFacts.prime_1171) (SearchFacts.query_1437 LCMSourcePV.PrimeFacts.prime_1324783) c1_0
#print axioms make_131
end LCMSourcePV.Witness.BlockProofs
