/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_27 : Block := (Block.mk 196249 201600 449 457 461 196111 196201 196247)
theorem make_27 : make 1000 30 32 16 196249 10712529=some row_27 := by
  have ck_0_9_0 : (Block.mk 196249 201600 449 457 461 196111 196201 196247).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_449 LCMSourcePV.PrimeFacts.prime_457 LCMSourcePV.PrimeFacts.prime_461 LCMSourcePV.PrimeFacts.prime_196111 LCMSourcePV.PrimeFacts.prime_196201 LCMSourcePV.PrimeFacts.prime_196247
  have sh_0_9_0 : shrink 30 (Block.mk 196249 201600 449 457 461 196111 196201 196247)=some row_27 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 23 196116=some row_27 :=
    choose0_hit 1000 30 196249 10712529 449 457 461 196201 196247 22 196116 196111 row_27 (SearchFacts.query_272 LCMSourcePV.PrimeFacts.prime_196111) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 24 196138=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 23 196138 196117 (some row_27) (SearchFacts.query_273 LCMSourcePV.PrimeFacts.prime_196117) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 25 196158=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 24 196158 196139 (some row_27) (SearchFacts.query_274 LCMSourcePV.PrimeFacts.prime_196139) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 26 196168=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 25 196168 196159 (some row_27) (SearchFacts.query_275 LCMSourcePV.PrimeFacts.prime_196159) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 27 196170=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 26 196170 196169 (some row_27) (SearchFacts.query_276 LCMSourcePV.PrimeFacts.prime_196169) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 28 196176=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 27 196176 196171 (some row_27) (SearchFacts.query_277 LCMSourcePV.PrimeFacts.prime_196171) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 29 196180=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 28 196180 196177 (some row_27) (SearchFacts.query_278 LCMSourcePV.PrimeFacts.prime_196177) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 30 196186=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 29 196186 196181 (some row_27) (SearchFacts.query_279 LCMSourcePV.PrimeFacts.prime_196181) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 31 196192=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 30 196192 196187 (some row_27) (SearchFacts.query_280 LCMSourcePV.PrimeFacts.prime_196187) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 196249 10712529 449 457 461 196201 196247 32 196200=(some row_27) :=
    choose0_skip 1000 30 196249 10712529 449 457 461 196201 196247 31 196200 196193 (some row_27) (SearchFacts.query_281 LCMSourcePV.PrimeFacts.prime_196193) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 196249 10712529 449 457 461 196247 16 196246=some row_27 :=
    choose1_hit 1000 30 32 196249 10712529 449 457 461 196247 15 196246 196201 row_27 (SearchFacts.query_282 LCMSourcePV.PrimeFacts.prime_196201) c0_0_0
  have hsqrt : Nat.sqrt 196249=443 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 196249+1)=some 449 := by
    rw [hsqrt];exact (SearchFacts.query_4148 LCMSourcePV.PrimeFacts.prime_449)
  exact make_hit 1000 30 32 16 196249 10712529 449 457 461 196247 row_27 h0 (SearchFacts.query_4149 LCMSourcePV.PrimeFacts.prime_457) (SearchFacts.query_4150 LCMSourcePV.PrimeFacts.prime_461) (SearchFacts.query_283 LCMSourcePV.PrimeFacts.prime_196247) c1_0
#print axioms make_27
end LCMSourcePV.Witness.BlockProofs
