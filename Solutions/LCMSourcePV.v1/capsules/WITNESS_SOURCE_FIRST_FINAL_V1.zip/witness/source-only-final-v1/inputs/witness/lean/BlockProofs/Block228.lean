/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_228 : Block := (Block.mk 3508129 3523128 1877 1879 1889 3508073 3508079 3508111)
theorem make_228 : make 1000 30 32 16 3508129 10712529=some row_228 := by
  have ck_0_0_0 : (Block.mk 3508129 3523128 1877 1879 1889 3508073 3508079 3508111).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1877 LCMSourcePV.PrimeFacts.prime_1879 LCMSourcePV.PrimeFacts.prime_1889 LCMSourcePV.PrimeFacts.prime_3508073 LCMSourcePV.PrimeFacts.prime_3508079 LCMSourcePV.PrimeFacts.prime_3508111
  have sh_0_0_0 : shrink 30 (Block.mk 3508129 3523128 1877 1879 1889 3508073 3508079 3508111)=some row_228 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 3508129 10712529 1877 1879 1889 3508079 3508111 32 3508078=some row_228 :=
    choose0_hit 1000 30 3508129 10712529 1877 1879 1889 3508079 3508111 31 3508078 3508073 row_228 (SearchFacts.query_2349 LCMSourcePV.PrimeFacts.prime_3508073) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 3508129 10712529 1877 1879 1889 3508111 16 3508110=some row_228 :=
    choose1_hit 1000 30 32 3508129 10712529 1877 1879 1889 3508111 15 3508110 3508079 row_228 (SearchFacts.query_2350 LCMSourcePV.PrimeFacts.prime_3508079) c0_0_0
  have hsqrt : Nat.sqrt 3508129=1873 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3508129+1)=some 1877 := by
    rw [hsqrt];exact (SearchFacts.query_4349 LCMSourcePV.PrimeFacts.prime_1877)
  exact make_hit 1000 30 32 16 3508129 10712529 1877 1879 1889 3508111 row_228 h0 (SearchFacts.query_4350 LCMSourcePV.PrimeFacts.prime_1879) (SearchFacts.query_4351 LCMSourcePV.PrimeFacts.prime_1889) (SearchFacts.query_2351 LCMSourcePV.PrimeFacts.prime_3508111) c1_0
#print axioms make_228
end LCMSourcePV.Witness.BlockProofs
