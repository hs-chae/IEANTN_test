/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_125 : Block := (Block.mk 1203409 1216608 1103 1109 1117 1203193 1203359 1203361)
theorem make_125 : make 1000 30 32 16 1203409 10712529=some row_125 := by
  have ck_0_11_0 : (Block.mk 1203409 1216608 1103 1109 1117 1203193 1203359 1203361).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1103 LCMSourcePV.PrimeFacts.prime_1109 LCMSourcePV.PrimeFacts.prime_1117 LCMSourcePV.PrimeFacts.prime_1203193 LCMSourcePV.PrimeFacts.prime_1203359 LCMSourcePV.PrimeFacts.prime_1203361
  have sh_0_11_0 : shrink 30 (Block.mk 1203409 1216608 1103 1109 1117 1203193 1203359 1203361)=some row_125 := shrink_hit _ _ ck_0_11_0
  have c0_0_11 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 21 1203210=some row_125 :=
    choose0_hit 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 20 1203210 1203193 row_125 (SearchFacts.query_1307 LCMSourcePV.PrimeFacts.prime_1203193) (by decide) sh_0_11_0
  have c0_0_10 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 22 1203216=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 21 1203216 1203211 (some row_125) (SearchFacts.query_1308 LCMSourcePV.PrimeFacts.prime_1203211) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 23 1203220=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 22 1203220 1203217 (some row_125) (SearchFacts.query_1309 LCMSourcePV.PrimeFacts.prime_1203217) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 24 1203228=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 23 1203228 1203221 (some row_125) (SearchFacts.query_1310 LCMSourcePV.PrimeFacts.prime_1203221) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 25 1203232=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 24 1203232 1203229 (some row_125) (SearchFacts.query_1311 LCMSourcePV.PrimeFacts.prime_1203229) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 26 1203262=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 25 1203262 1203233 (some row_125) (SearchFacts.query_1312 LCMSourcePV.PrimeFacts.prime_1203233) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 27 1203282=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 26 1203282 1203263 (some row_125) (SearchFacts.query_1313 LCMSourcePV.PrimeFacts.prime_1203263) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 28 1203286=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 27 1203286 1203283 (some row_125) (SearchFacts.query_1314 LCMSourcePV.PrimeFacts.prime_1203283) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 29 1203328=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 28 1203328 1203287 (some row_125) (SearchFacts.query_1315 LCMSourcePV.PrimeFacts.prime_1203287) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 30 1203330=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 29 1203330 1203329 (some row_125) (SearchFacts.query_1316 LCMSourcePV.PrimeFacts.prime_1203329) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 31 1203342=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 30 1203342 1203331 (some row_125) (SearchFacts.query_1317 LCMSourcePV.PrimeFacts.prime_1203331) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 32 1203358=(some row_125) :=
    choose0_skip 1000 30 1203409 10712529 1103 1109 1117 1203359 1203361 31 1203358 1203343 (some row_125) (SearchFacts.query_1318 LCMSourcePV.PrimeFacts.prime_1203343) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1203409 10712529 1103 1109 1117 1203361 16 1203360=some row_125 :=
    choose1_hit 1000 30 32 1203409 10712529 1103 1109 1117 1203361 15 1203360 1203359 row_125 (SearchFacts.query_1319 LCMSourcePV.PrimeFacts.prime_1203359) c0_0_0
  have hsqrt : Nat.sqrt 1203409=1097 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1203409+1)=some 1103 := by
    rw [hsqrt];exact (SearchFacts.query_4246 LCMSourcePV.PrimeFacts.prime_1103)
  exact make_hit 1000 30 32 16 1203409 10712529 1103 1109 1117 1203361 row_125 h0 (SearchFacts.query_4247 LCMSourcePV.PrimeFacts.prime_1109) (SearchFacts.query_4248 LCMSourcePV.PrimeFacts.prime_1117) (SearchFacts.query_1320 LCMSourcePV.PrimeFacts.prime_1203361) c1_0
#print axioms make_125
end LCMSourcePV.Witness.BlockProofs
