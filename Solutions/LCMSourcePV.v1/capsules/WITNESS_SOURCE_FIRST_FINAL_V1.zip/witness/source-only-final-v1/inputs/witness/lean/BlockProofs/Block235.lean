/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_235 : Block := (Block.mk 3728761 3736488 1933 1949 1951 3728671 3728743 3728759)
theorem make_235 : make 1000 30 32 16 3728761 10712529=some row_235 := by
  have ck_0_4_0 : (Block.mk 3728761 3736488 1933 1949 1951 3728671 3728743 3728759).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1933 LCMSourcePV.PrimeFacts.prime_1949 LCMSourcePV.PrimeFacts.prime_1951 LCMSourcePV.PrimeFacts.prime_3728671 LCMSourcePV.PrimeFacts.prime_3728743 LCMSourcePV.PrimeFacts.prime_3728759
  have sh_0_4_0 : shrink 30 (Block.mk 3728761 3736488 1933 1949 1951 3728671 3728743 3728759)=some row_235 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 28 3728686=some row_235 :=
    choose0_hit 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 27 3728686 3728671 row_235 (SearchFacts.query_2408 LCMSourcePV.PrimeFacts.prime_3728671) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 29 3728712=(some row_235) :=
    choose0_skip 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 28 3728712 3728687 (some row_235) (SearchFacts.query_2409 LCMSourcePV.PrimeFacts.prime_3728687) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 30 3728716=(some row_235) :=
    choose0_skip 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 29 3728716 3728713 (some row_235) (SearchFacts.query_2410 LCMSourcePV.PrimeFacts.prime_3728713) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 31 3728718=(some row_235) :=
    choose0_skip 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 30 3728718 3728717 (some row_235) (SearchFacts.query_2411 LCMSourcePV.PrimeFacts.prime_3728717) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 32 3728742=(some row_235) :=
    choose0_skip 1000 30 3728761 10712529 1933 1949 1951 3728743 3728759 31 3728742 3728719 (some row_235) (SearchFacts.query_2412 LCMSourcePV.PrimeFacts.prime_3728719) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3728761 10712529 1933 1949 1951 3728759 16 3728758=some row_235 :=
    choose1_hit 1000 30 32 3728761 10712529 1933 1949 1951 3728759 15 3728758 3728743 row_235 (SearchFacts.query_2413 LCMSourcePV.PrimeFacts.prime_3728743) c0_0_0
  have hsqrt : Nat.sqrt 3728761=1931 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3728761+1)=some 1933 := by
    rw [hsqrt];exact (SearchFacts.query_4356 LCMSourcePV.PrimeFacts.prime_1933)
  exact make_hit 1000 30 32 16 3728761 10712529 1933 1949 1951 3728759 row_235 h0 (SearchFacts.query_4357 LCMSourcePV.PrimeFacts.prime_1949) (SearchFacts.query_4358 LCMSourcePV.PrimeFacts.prime_1951) (SearchFacts.query_2414 LCMSourcePV.PrimeFacts.prime_3728759) c1_0
#print axioms make_235
end LCMSourcePV.Witness.BlockProofs
