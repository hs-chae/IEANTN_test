/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_174 : Block := (Block.mk 2163841 2193360 1481 1483 1487 2163767 2163827 2163829)
theorem make_174 : make 1000 30 32 16 2163841 10712529=some row_174 := by
  have ck_0_3_0 : (Block.mk 2163841 2193360 1481 1483 1487 2163767 2163827 2163829).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1481 LCMSourcePV.PrimeFacts.prime_1483 LCMSourcePV.PrimeFacts.prime_1487 LCMSourcePV.PrimeFacts.prime_2163767 LCMSourcePV.PrimeFacts.prime_2163827 LCMSourcePV.PrimeFacts.prime_2163829
  have sh_0_3_0 : shrink 30 (Block.mk 2163841 2193360 1481 1483 1487 2163767 2163827 2163829)=some row_174 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 2163841 10712529 1481 1483 1487 2163827 2163829 29 2163786=some row_174 :=
    choose0_hit 1000 30 2163841 10712529 1481 1483 1487 2163827 2163829 28 2163786 2163767 row_174 (SearchFacts.query_1775 LCMSourcePV.PrimeFacts.prime_2163767) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 2163841 10712529 1481 1483 1487 2163827 2163829 30 2163808=(some row_174) :=
    choose0_skip 1000 30 2163841 10712529 1481 1483 1487 2163827 2163829 29 2163808 2163787 (some row_174) (SearchFacts.query_1776 LCMSourcePV.PrimeFacts.prime_2163787) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2163841 10712529 1481 1483 1487 2163827 2163829 31 2163822=(some row_174) :=
    choose0_skip 1000 30 2163841 10712529 1481 1483 1487 2163827 2163829 30 2163822 2163809 (some row_174) (SearchFacts.query_1777 LCMSourcePV.PrimeFacts.prime_2163809) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2163841 10712529 1481 1483 1487 2163827 2163829 32 2163826=(some row_174) :=
    choose0_skip 1000 30 2163841 10712529 1481 1483 1487 2163827 2163829 31 2163826 2163823 (some row_174) (SearchFacts.query_1778 LCMSourcePV.PrimeFacts.prime_2163823) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2163841 10712529 1481 1483 1487 2163829 16 2163828=some row_174 :=
    choose1_hit 1000 30 32 2163841 10712529 1481 1483 1487 2163829 15 2163828 2163827 row_174 (SearchFacts.query_1779 LCMSourcePV.PrimeFacts.prime_2163827) c0_0_0
  have hsqrt : Nat.sqrt 2163841=1471 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2163841+1)=some 1481 := by
    rw [hsqrt];exact (SearchFacts.query_4295 LCMSourcePV.PrimeFacts.prime_1481)
  exact make_hit 1000 30 32 16 2163841 10712529 1481 1483 1487 2163829 row_174 h0 (SearchFacts.query_4296 LCMSourcePV.PrimeFacts.prime_1483) (SearchFacts.query_4297 LCMSourcePV.PrimeFacts.prime_1487) (SearchFacts.query_1780 LCMSourcePV.PrimeFacts.prime_2163829) c1_0
#print axioms make_174
end LCMSourcePV.Witness.BlockProofs
