/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_324 : Block := (Block.mk 7006609 7059648 2657 2659 2663 7006343 7006577 7006607)
theorem make_324 : make 1000 30 32 16 7006609 10712529=some row_324 := by
  have ck_0_13_0 : (Block.mk 7006609 7059648 2657 2659 2663 7006343 7006577 7006607).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2657 LCMSourcePV.PrimeFacts.prime_2659 LCMSourcePV.PrimeFacts.prime_2663 LCMSourcePV.PrimeFacts.prime_7006343 LCMSourcePV.PrimeFacts.prime_7006577 LCMSourcePV.PrimeFacts.prime_7006607
  have sh_0_13_0 : shrink 30 (Block.mk 7006609 7059648 2657 2659 2663 7006343 7006577 7006607)=some row_324 := shrink_hit _ _ ck_0_13_0
  have c0_0_13 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 19 7006360=some row_324 :=
    choose0_hit 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 18 7006360 7006343 row_324 (SearchFacts.query_3309 LCMSourcePV.PrimeFacts.prime_7006343) (by decide) sh_0_13_0
  have c0_0_12 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 20 7006378=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 19 7006378 7006361 (some row_324) (SearchFacts.query_3310 LCMSourcePV.PrimeFacts.prime_7006361) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 21 7006380=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 20 7006380 7006379 (some row_324) (SearchFacts.query_3311 LCMSourcePV.PrimeFacts.prime_7006379) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 22 7006392=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 21 7006392 7006381 (some row_324) (SearchFacts.query_3312 LCMSourcePV.PrimeFacts.prime_7006381) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 23 7006422=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 22 7006422 7006393 (some row_324) (SearchFacts.query_3313 LCMSourcePV.PrimeFacts.prime_7006393) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 24 7006450=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 23 7006450 7006423 (some row_324) (SearchFacts.query_3314 LCMSourcePV.PrimeFacts.prime_7006423) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 25 7006456=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 24 7006456 7006451 (some row_324) (SearchFacts.query_3315 LCMSourcePV.PrimeFacts.prime_7006451) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 26 7006476=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 25 7006476 7006457 (some row_324) (SearchFacts.query_3316 LCMSourcePV.PrimeFacts.prime_7006457) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 27 7006480=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 26 7006480 7006477 (some row_324) (SearchFacts.query_3317 LCMSourcePV.PrimeFacts.prime_7006477) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 28 7006536=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 27 7006536 7006481 (some row_324) (SearchFacts.query_3318 LCMSourcePV.PrimeFacts.prime_7006481) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 29 7006540=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 28 7006540 7006537 (some row_324) (SearchFacts.query_3319 LCMSourcePV.PrimeFacts.prime_7006537) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 30 7006552=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 29 7006552 7006541 (some row_324) (SearchFacts.query_3320 LCMSourcePV.PrimeFacts.prime_7006541) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 31 7006560=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 30 7006560 7006553 (some row_324) (SearchFacts.query_3321 LCMSourcePV.PrimeFacts.prime_7006553) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 32 7006576=(some row_324) :=
    choose0_skip 1000 30 7006609 10712529 2657 2659 2663 7006577 7006607 31 7006576 7006561 (some row_324) (SearchFacts.query_3322 LCMSourcePV.PrimeFacts.prime_7006561) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 7006609 10712529 2657 2659 2663 7006607 16 7006606=some row_324 :=
    choose1_hit 1000 30 32 7006609 10712529 2657 2659 2663 7006607 15 7006606 7006577 row_324 (SearchFacts.query_3323 LCMSourcePV.PrimeFacts.prime_7006577) c0_0_0
  have hsqrt : Nat.sqrt 7006609=2647 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 7006609+1)=some 2657 := by
    rw [hsqrt];exact (SearchFacts.query_4445 LCMSourcePV.PrimeFacts.prime_2657)
  exact make_hit 1000 30 32 16 7006609 10712529 2657 2659 2663 7006607 row_324 h0 (SearchFacts.query_4446 LCMSourcePV.PrimeFacts.prime_2659) (SearchFacts.query_4447 LCMSourcePV.PrimeFacts.prime_2663) (SearchFacts.query_3324 LCMSourcePV.PrimeFacts.prime_7006607) c1_0
#print axioms make_324
end LCMSourcePV.Witness.BlockProofs
