/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_308 : Block := (Block.mk 6135529 6265008 2503 2521 2531 6135463 6135509 6135523)
theorem make_308 : make 1000 30 32 16 6135529 10712529=some row_308 := by
  have ck_0_2_0 : (Block.mk 6135529 6265008 2503 2521 2531 6135463 6135509 6135523).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2503 LCMSourcePV.PrimeFacts.prime_2521 LCMSourcePV.PrimeFacts.prime_2531 LCMSourcePV.PrimeFacts.prime_6135463 LCMSourcePV.PrimeFacts.prime_6135509 LCMSourcePV.PrimeFacts.prime_6135523
  have sh_0_2_0 : shrink 30 (Block.mk 6135529 6265008 2503 2521 2531 6135463 6135509 6135523)=some row_308 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 6135529 10712529 2503 2521 2531 6135509 6135523 30 6135472=some row_308 :=
    choose0_hit 1000 30 6135529 10712529 2503 2521 2531 6135509 6135523 29 6135472 6135463 row_308 (SearchFacts.query_3122 LCMSourcePV.PrimeFacts.prime_6135463) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 6135529 10712529 2503 2521 2531 6135509 6135523 31 6135490=(some row_308) :=
    choose0_skip 1000 30 6135529 10712529 2503 2521 2531 6135509 6135523 30 6135490 6135473 (some row_308) (SearchFacts.query_3123 LCMSourcePV.PrimeFacts.prime_6135473) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6135529 10712529 2503 2521 2531 6135509 6135523 32 6135508=(some row_308) :=
    choose0_skip 1000 30 6135529 10712529 2503 2521 2531 6135509 6135523 31 6135508 6135491 (some row_308) (SearchFacts.query_3124 LCMSourcePV.PrimeFacts.prime_6135491) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6135529 10712529 2503 2521 2531 6135523 16 6135522=some row_308 :=
    choose1_hit 1000 30 32 6135529 10712529 2503 2521 2531 6135523 15 6135522 6135509 row_308 (SearchFacts.query_3125 LCMSourcePV.PrimeFacts.prime_6135509) c0_0_0
  have hsqrt : Nat.sqrt 6135529=2477 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6135529+1)=some 2503 := by
    rw [hsqrt];exact (SearchFacts.query_4429 LCMSourcePV.PrimeFacts.prime_2503)
  exact make_hit 1000 30 32 16 6135529 10712529 2503 2521 2531 6135523 row_308 h0 (SearchFacts.query_4430 LCMSourcePV.PrimeFacts.prime_2521) (SearchFacts.query_4431 LCMSourcePV.PrimeFacts.prime_2531) (SearchFacts.query_3126 LCMSourcePV.PrimeFacts.prime_6135523) c1_0
#print axioms make_308
end LCMSourcePV.Witness.BlockProofs
