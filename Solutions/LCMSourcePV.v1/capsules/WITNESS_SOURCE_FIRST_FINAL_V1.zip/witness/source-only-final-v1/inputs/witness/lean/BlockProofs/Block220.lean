/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_220 : Block := (Block.mk 3243601 3279720 1811 1823 1831 3243511 3243587 3243589)
theorem make_220 : make 1000 30 32 16 3243601 10712529=some row_220 := by
  have ck_0_2_0 : (Block.mk 3243601 3279720 1811 1823 1831 3243511 3243587 3243589).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1811 LCMSourcePV.PrimeFacts.prime_1823 LCMSourcePV.PrimeFacts.prime_1831 LCMSourcePV.PrimeFacts.prime_3243511 LCMSourcePV.PrimeFacts.prime_3243587 LCMSourcePV.PrimeFacts.prime_3243589
  have sh_0_2_0 : shrink 30 (Block.mk 3243601 3279720 1811 1823 1831 3243511 3243587 3243589)=some row_220 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 3243601 10712529 1811 1823 1831 3243587 3243589 30 3243520=some row_220 :=
    choose0_hit 1000 30 3243601 10712529 1811 1823 1831 3243587 3243589 29 3243520 3243511 row_220 (SearchFacts.query_2294 LCMSourcePV.PrimeFacts.prime_3243511) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 3243601 10712529 1811 1823 1831 3243587 3243589 31 3243522=(some row_220) :=
    choose0_skip 1000 30 3243601 10712529 1811 1823 1831 3243587 3243589 30 3243522 3243521 (some row_220) (SearchFacts.query_2295 LCMSourcePV.PrimeFacts.prime_3243521) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3243601 10712529 1811 1823 1831 3243587 3243589 32 3243586=(some row_220) :=
    choose0_skip 1000 30 3243601 10712529 1811 1823 1831 3243587 3243589 31 3243586 3243523 (some row_220) (SearchFacts.query_2296 LCMSourcePV.PrimeFacts.prime_3243523) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3243601 10712529 1811 1823 1831 3243589 16 3243588=some row_220 :=
    choose1_hit 1000 30 32 3243601 10712529 1811 1823 1831 3243589 15 3243588 3243587 row_220 (SearchFacts.query_2297 LCMSourcePV.PrimeFacts.prime_3243587) c0_0_0
  have hsqrt : Nat.sqrt 3243601=1801 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3243601+1)=some 1811 := by
    rw [hsqrt];exact (SearchFacts.query_4341 LCMSourcePV.PrimeFacts.prime_1811)
  exact make_hit 1000 30 32 16 3243601 10712529 1811 1823 1831 3243589 row_220 h0 (SearchFacts.query_4342 LCMSourcePV.PrimeFacts.prime_1823) (SearchFacts.query_4343 LCMSourcePV.PrimeFacts.prime_1831) (SearchFacts.query_2298 LCMSourcePV.PrimeFacts.prime_3243589) c1_0
#print axioms make_220
end LCMSourcePV.Witness.BlockProofs
