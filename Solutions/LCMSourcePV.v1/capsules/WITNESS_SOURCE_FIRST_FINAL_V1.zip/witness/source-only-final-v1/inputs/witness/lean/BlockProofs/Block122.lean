/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_122 : Block := (Block.mk 1181569 1190280 1091 1093 1097 1181443 1181561 1181563)
theorem make_122 : make 1000 30 32 16 1181569 10712529=some row_122 := by
  have ck_0_8_0 : (Block.mk 1181569 1190280 1091 1093 1097 1181443 1181561 1181563).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1091 LCMSourcePV.PrimeFacts.prime_1093 LCMSourcePV.PrimeFacts.prime_1097 LCMSourcePV.PrimeFacts.prime_1181443 LCMSourcePV.PrimeFacts.prime_1181561 LCMSourcePV.PrimeFacts.prime_1181563
  have sh_0_8_0 : shrink 30 (Block.mk 1181569 1190280 1091 1093 1097 1181443 1181561 1181563)=some row_122 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 24 1181460=some row_122 :=
    choose0_hit 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 23 1181460 1181443 row_122 (SearchFacts.query_1262 LCMSourcePV.PrimeFacts.prime_1181443) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 25 1181470=(some row_122) :=
    choose0_skip 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 24 1181470 1181461 (some row_122) (SearchFacts.query_1263 LCMSourcePV.PrimeFacts.prime_1181461) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 26 1181472=(some row_122) :=
    choose0_skip 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 25 1181472 1181471 (some row_122) (SearchFacts.query_1264 LCMSourcePV.PrimeFacts.prime_1181471) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 27 1181500=(some row_122) :=
    choose0_skip 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 26 1181500 1181473 (some row_122) (SearchFacts.query_1265 LCMSourcePV.PrimeFacts.prime_1181473) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 28 1181506=(some row_122) :=
    choose0_skip 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 27 1181506 1181501 (some row_122) (SearchFacts.query_1266 LCMSourcePV.PrimeFacts.prime_1181501) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 29 1181518=(some row_122) :=
    choose0_skip 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 28 1181518 1181507 (some row_122) (SearchFacts.query_1267 LCMSourcePV.PrimeFacts.prime_1181507) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 30 1181526=(some row_122) :=
    choose0_skip 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 29 1181526 1181519 (some row_122) (SearchFacts.query_1268 LCMSourcePV.PrimeFacts.prime_1181519) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 31 1181548=(some row_122) :=
    choose0_skip 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 30 1181548 1181527 (some row_122) (SearchFacts.query_1269 LCMSourcePV.PrimeFacts.prime_1181527) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 32 1181560=(some row_122) :=
    choose0_skip 1000 30 1181569 10712529 1091 1093 1097 1181561 1181563 31 1181560 1181549 (some row_122) (SearchFacts.query_1270 LCMSourcePV.PrimeFacts.prime_1181549) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1181569 10712529 1091 1093 1097 1181563 16 1181562=some row_122 :=
    choose1_hit 1000 30 32 1181569 10712529 1091 1093 1097 1181563 15 1181562 1181561 row_122 (SearchFacts.query_1271 LCMSourcePV.PrimeFacts.prime_1181561) c0_0_0
  have hsqrt : Nat.sqrt 1181569=1087 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1181569+1)=some 1091 := by
    rw [hsqrt];exact (SearchFacts.query_4243 LCMSourcePV.PrimeFacts.prime_1091)
  exact make_hit 1000 30 32 16 1181569 10712529 1091 1093 1097 1181563 row_122 h0 (SearchFacts.query_4244 LCMSourcePV.PrimeFacts.prime_1093) (SearchFacts.query_4245 LCMSourcePV.PrimeFacts.prime_1097) (SearchFacts.query_1272 LCMSourcePV.PrimeFacts.prime_1181563) c1_0
#print axioms make_122
end LCMSourcePV.Witness.BlockProofs
