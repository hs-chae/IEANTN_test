/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_16 : Block := (Block.mk 143641 146688 383 389 397 143513 143617 143629)
theorem make_16 : make 1000 30 32 16 143641 10712529=some row_16 := by
  have ck_0_9_0 : (Block.mk 143641 146688 383 389 397 143513 143617 143629).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_383 LCMSourcePV.PrimeFacts.prime_389 LCMSourcePV.PrimeFacts.prime_397 LCMSourcePV.PrimeFacts.prime_143513 LCMSourcePV.PrimeFacts.prime_143617 LCMSourcePV.PrimeFacts.prime_143629
  have sh_0_9_0 : shrink 30 (Block.mk 143641 146688 383 389 397 143513 143617 143629)=some row_16 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 23 143518=some row_16 :=
    choose0_hit 1000 30 143641 10712529 383 389 397 143617 143629 22 143518 143513 row_16 (SearchFacts.query_113 LCMSourcePV.PrimeFacts.prime_143513) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 24 143526=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 23 143526 143519 (some row_16) (SearchFacts.query_114 LCMSourcePV.PrimeFacts.prime_143519) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 25 143536=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 24 143536 143527 (some row_16) (SearchFacts.query_115 LCMSourcePV.PrimeFacts.prime_143527) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 26 143550=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 25 143550 143537 (some row_16) (SearchFacts.query_116 LCMSourcePV.PrimeFacts.prime_143537) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 27 143566=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 26 143566 143551 (some row_16) (SearchFacts.query_117 LCMSourcePV.PrimeFacts.prime_143551) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 28 143568=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 27 143568 143567 (some row_16) (SearchFacts.query_118 LCMSourcePV.PrimeFacts.prime_143567) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 29 143572=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 28 143572 143569 (some row_16) (SearchFacts.query_119 LCMSourcePV.PrimeFacts.prime_143569) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 30 143592=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 29 143592 143573 (some row_16) (SearchFacts.query_120 LCMSourcePV.PrimeFacts.prime_143573) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 31 143608=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 30 143608 143593 (some row_16) (SearchFacts.query_121 LCMSourcePV.PrimeFacts.prime_143593) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 143641 10712529 383 389 397 143617 143629 32 143616=(some row_16) :=
    choose0_skip 1000 30 143641 10712529 383 389 397 143617 143629 31 143616 143609 (some row_16) (SearchFacts.query_122 LCMSourcePV.PrimeFacts.prime_143609) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 143641 10712529 383 389 397 143629 16 143628=some row_16 :=
    choose1_hit 1000 30 32 143641 10712529 383 389 397 143629 15 143628 143617 row_16 (SearchFacts.query_123 LCMSourcePV.PrimeFacts.prime_143617) c0_0_0
  have hsqrt : Nat.sqrt 143641=379 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 143641+1)=some 383 := by
    rw [hsqrt];exact (SearchFacts.query_4137 LCMSourcePV.PrimeFacts.prime_383)
  exact make_hit 1000 30 32 16 143641 10712529 383 389 397 143629 row_16 h0 (SearchFacts.query_4138 LCMSourcePV.PrimeFacts.prime_389) (SearchFacts.query_4139 LCMSourcePV.PrimeFacts.prime_397) (SearchFacts.query_124 LCMSourcePV.PrimeFacts.prime_143629) c1_0
#print axioms make_16
end LCMSourcePV.Witness.BlockProofs
