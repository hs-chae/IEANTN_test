/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_151 : Block := (Block.mk 1666681 1682208 1297 1301 1303 1666607 1666627 1666657)
theorem make_151 : make 1000 30 32 16 1666681 10712529=some row_151 := by
  have ck_0_1_0 : (Block.mk 1666681 1682208 1297 1301 1303 1666607 1666627 1666657).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1297 LCMSourcePV.PrimeFacts.prime_1301 LCMSourcePV.PrimeFacts.prime_1303 LCMSourcePV.PrimeFacts.prime_1666607 LCMSourcePV.PrimeFacts.prime_1666627 LCMSourcePV.PrimeFacts.prime_1666657
  have sh_0_1_0 : shrink 30 (Block.mk 1666681 1682208 1297 1301 1303 1666607 1666627 1666657)=some row_151 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 1666681 10712529 1297 1301 1303 1666627 1666657 31 1666618=some row_151 :=
    choose0_hit 1000 30 1666681 10712529 1297 1301 1303 1666627 1666657 30 1666618 1666607 row_151 (SearchFacts.query_1591 LCMSourcePV.PrimeFacts.prime_1666607) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 1666681 10712529 1297 1301 1303 1666627 1666657 32 1666626=(some row_151) :=
    choose0_skip 1000 30 1666681 10712529 1297 1301 1303 1666627 1666657 31 1666626 1666619 (some row_151) (SearchFacts.query_1592 LCMSourcePV.PrimeFacts.prime_1666619) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1666681 10712529 1297 1301 1303 1666657 16 1666656=some row_151 :=
    choose1_hit 1000 30 32 1666681 10712529 1297 1301 1303 1666657 15 1666656 1666627 row_151 (SearchFacts.query_1593 LCMSourcePV.PrimeFacts.prime_1666627) c0_0_0
  have hsqrt : Nat.sqrt 1666681=1291 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1666681+1)=some 1297 := by
    rw [hsqrt];exact (SearchFacts.query_4272 LCMSourcePV.PrimeFacts.prime_1297)
  exact make_hit 1000 30 32 16 1666681 10712529 1297 1301 1303 1666657 row_151 h0 (SearchFacts.query_4273 LCMSourcePV.PrimeFacts.prime_1301) (SearchFacts.query_4274 LCMSourcePV.PrimeFacts.prime_1303) (SearchFacts.query_1594 LCMSourcePV.PrimeFacts.prime_1666657) c1_0
#print axioms make_151
end LCMSourcePV.Witness.BlockProofs
