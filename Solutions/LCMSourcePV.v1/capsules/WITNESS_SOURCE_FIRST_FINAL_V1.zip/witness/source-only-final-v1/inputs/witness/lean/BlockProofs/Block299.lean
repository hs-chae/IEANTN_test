/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_299 : Block := (Block.mk 5812921 5841888 2417 2423 2437 5812837 5812889 5812907)
theorem make_299 : make 1000 30 32 16 5812921 10712529=some row_299 := by
  have ck_0_3_0 : (Block.mk 5812921 5841888 2417 2423 2437 5812837 5812889 5812907).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2417 LCMSourcePV.PrimeFacts.prime_2423 LCMSourcePV.PrimeFacts.prime_2437 LCMSourcePV.PrimeFacts.prime_5812837 LCMSourcePV.PrimeFacts.prime_5812889 LCMSourcePV.PrimeFacts.prime_5812907
  have sh_0_3_0 : shrink 30 (Block.mk 5812921 5841888 2417 2423 2437 5812837 5812889 5812907)=some row_299 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 5812921 10712529 2417 2423 2437 5812889 5812907 29 5812842=some row_299 :=
    choose0_hit 1000 30 5812921 10712529 2417 2423 2437 5812889 5812907 28 5812842 5812837 row_299 (SearchFacts.query_3010 LCMSourcePV.PrimeFacts.prime_5812837) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 5812921 10712529 2417 2423 2437 5812889 5812907 30 5812866=(some row_299) :=
    choose0_skip 1000 30 5812921 10712529 2417 2423 2437 5812889 5812907 29 5812866 5812843 (some row_299) (SearchFacts.query_3011 LCMSourcePV.PrimeFacts.prime_5812843) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5812921 10712529 2417 2423 2437 5812889 5812907 31 5812882=(some row_299) :=
    choose0_skip 1000 30 5812921 10712529 2417 2423 2437 5812889 5812907 30 5812882 5812867 (some row_299) (SearchFacts.query_3012 LCMSourcePV.PrimeFacts.prime_5812867) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5812921 10712529 2417 2423 2437 5812889 5812907 32 5812888=(some row_299) :=
    choose0_skip 1000 30 5812921 10712529 2417 2423 2437 5812889 5812907 31 5812888 5812883 (some row_299) (SearchFacts.query_3013 LCMSourcePV.PrimeFacts.prime_5812883) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5812921 10712529 2417 2423 2437 5812907 16 5812906=some row_299 :=
    choose1_hit 1000 30 32 5812921 10712529 2417 2423 2437 5812907 15 5812906 5812889 row_299 (SearchFacts.query_3014 LCMSourcePV.PrimeFacts.prime_5812889) c0_0_0
  have hsqrt : Nat.sqrt 5812921=2411 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5812921+1)=some 2417 := by
    rw [hsqrt];exact (SearchFacts.query_4420 LCMSourcePV.PrimeFacts.prime_2417)
  exact make_hit 1000 30 32 16 5812921 10712529 2417 2423 2437 5812907 row_299 h0 (SearchFacts.query_4421 LCMSourcePV.PrimeFacts.prime_2423) (SearchFacts.query_4422 LCMSourcePV.PrimeFacts.prime_2437) (SearchFacts.query_3015 LCMSourcePV.PrimeFacts.prime_5812907) c1_0
#print axioms make_299
end LCMSourcePV.Witness.BlockProofs
