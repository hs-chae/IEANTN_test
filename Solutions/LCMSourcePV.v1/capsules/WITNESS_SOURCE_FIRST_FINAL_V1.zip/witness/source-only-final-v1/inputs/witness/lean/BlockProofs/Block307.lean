/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_307 : Block := (Block.mk 6115729 6135528 2477 2503 2521 6115399 6115691 6115717)
theorem make_307 : make 1000 30 32 16 6115729 10712529=some row_307 := by
  have ck_0_17_0 : (Block.mk 6115729 6135528 2477 2503 2521 6115399 6115691 6115717).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2477 LCMSourcePV.PrimeFacts.prime_2503 LCMSourcePV.PrimeFacts.prime_2521 LCMSourcePV.PrimeFacts.prime_6115399 LCMSourcePV.PrimeFacts.prime_6115691 LCMSourcePV.PrimeFacts.prime_6115717
  have sh_0_17_0 : shrink 30 (Block.mk 6115729 6135528 2477 2503 2521 6115399 6115691 6115717)=some row_307 := shrink_hit _ _ ck_0_17_0
  have c0_0_17 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 15 6115410=some row_307 :=
    choose0_hit 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 14 6115410 6115399 row_307 (SearchFacts.query_3102 LCMSourcePV.PrimeFacts.prime_6115399) (by decide) sh_0_17_0
  have c0_0_16 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 16 6115422=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 15 6115422 6115411 (some row_307) (SearchFacts.query_3103 LCMSourcePV.PrimeFacts.prime_6115411) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 17 6115440=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 16 6115440 6115423 (some row_307) (SearchFacts.query_3104 LCMSourcePV.PrimeFacts.prime_6115423) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 18 6115488=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 17 6115488 6115441 (some row_307) (SearchFacts.query_3105 LCMSourcePV.PrimeFacts.prime_6115441) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 19 6115506=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 18 6115506 6115489 (some row_307) (SearchFacts.query_3106 LCMSourcePV.PrimeFacts.prime_6115489) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 20 6115512=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 19 6115512 6115507 (some row_307) (SearchFacts.query_3107 LCMSourcePV.PrimeFacts.prime_6115507) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 21 6115530=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 20 6115530 6115513 (some row_307) (SearchFacts.query_3108 LCMSourcePV.PrimeFacts.prime_6115513) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 22 6115536=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 21 6115536 6115531 (some row_307) (SearchFacts.query_3109 LCMSourcePV.PrimeFacts.prime_6115531) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 23 6115540=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 22 6115540 6115537 (some row_307) (SearchFacts.query_3110 LCMSourcePV.PrimeFacts.prime_6115537) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 24 6115546=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 23 6115546 6115541 (some row_307) (SearchFacts.query_3111 LCMSourcePV.PrimeFacts.prime_6115541) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 25 6115560=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 24 6115560 6115547 (some row_307) (SearchFacts.query_3112 LCMSourcePV.PrimeFacts.prime_6115547) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 26 6115578=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 25 6115578 6115561 (some row_307) (SearchFacts.query_3113 LCMSourcePV.PrimeFacts.prime_6115561) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 27 6115638=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 26 6115638 6115579 (some row_307) (SearchFacts.query_3114 LCMSourcePV.PrimeFacts.prime_6115579) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 28 6115642=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 27 6115642 6115639 (some row_307) (SearchFacts.query_3115 LCMSourcePV.PrimeFacts.prime_6115639) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 29 6115660=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 28 6115660 6115643 (some row_307) (SearchFacts.query_3116 LCMSourcePV.PrimeFacts.prime_6115643) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 30 6115666=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 29 6115666 6115661 (some row_307) (SearchFacts.query_3117 LCMSourcePV.PrimeFacts.prime_6115661) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 31 6115678=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 30 6115678 6115667 (some row_307) (SearchFacts.query_3118 LCMSourcePV.PrimeFacts.prime_6115667) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 32 6115690=(some row_307) :=
    choose0_skip 1000 30 6115729 10712529 2477 2503 2521 6115691 6115717 31 6115690 6115679 (some row_307) (SearchFacts.query_3119 LCMSourcePV.PrimeFacts.prime_6115679) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6115729 10712529 2477 2503 2521 6115717 16 6115716=some row_307 :=
    choose1_hit 1000 30 32 6115729 10712529 2477 2503 2521 6115717 15 6115716 6115691 row_307 (SearchFacts.query_3120 LCMSourcePV.PrimeFacts.prime_6115691) c0_0_0
  have hsqrt : Nat.sqrt 6115729=2473 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6115729+1)=some 2477 := by
    rw [hsqrt];exact (SearchFacts.query_4428 LCMSourcePV.PrimeFacts.prime_2477)
  exact make_hit 1000 30 32 16 6115729 10712529 2477 2503 2521 6115717 row_307 h0 (SearchFacts.query_4429 LCMSourcePV.PrimeFacts.prime_2503) (SearchFacts.query_4430 LCMSourcePV.PrimeFacts.prime_2521) (SearchFacts.query_3121 LCMSourcePV.PrimeFacts.prime_6115717) c1_0
#print axioms make_307
end LCMSourcePV.Witness.BlockProofs
