/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_163 : Block := (Block.mk 1957201 1985280 1409 1423 1427 1957051 1957157 1957187)
theorem make_163 : make 1000 30 32 16 1957201 10712529=some row_163 := by
  have ck_0_8_0 : (Block.mk 1957201 1985280 1409 1423 1427 1957051 1957157 1957187).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1409 LCMSourcePV.PrimeFacts.prime_1423 LCMSourcePV.PrimeFacts.prime_1427 LCMSourcePV.PrimeFacts.prime_1957051 LCMSourcePV.PrimeFacts.prime_1957157 LCMSourcePV.PrimeFacts.prime_1957187
  have sh_0_8_0 : shrink 30 (Block.mk 1957201 1985280 1409 1423 1427 1957051 1957157 1957187)=some row_163 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 24 1957068=some row_163 :=
    choose0_hit 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 23 1957068 1957051 row_163 (SearchFacts.query_1679 LCMSourcePV.PrimeFacts.prime_1957051) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 25 1957078=(some row_163) :=
    choose0_skip 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 24 1957078 1957069 (some row_163) (SearchFacts.query_1680 LCMSourcePV.PrimeFacts.prime_1957069) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 26 1957096=(some row_163) :=
    choose0_skip 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 25 1957096 1957079 (some row_163) (SearchFacts.query_1681 LCMSourcePV.PrimeFacts.prime_1957079) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 27 1957098=(some row_163) :=
    choose0_skip 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 26 1957098 1957097 (some row_163) (SearchFacts.query_1682 LCMSourcePV.PrimeFacts.prime_1957097) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 28 1957116=(some row_163) :=
    choose0_skip 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 27 1957116 1957099 (some row_163) (SearchFacts.query_1683 LCMSourcePV.PrimeFacts.prime_1957099) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 29 1957120=(some row_163) :=
    choose0_skip 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 28 1957120 1957117 (some row_163) (SearchFacts.query_1684 LCMSourcePV.PrimeFacts.prime_1957117) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 30 1957128=(some row_163) :=
    choose0_skip 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 29 1957128 1957121 (some row_163) (SearchFacts.query_1685 LCMSourcePV.PrimeFacts.prime_1957121) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 31 1957146=(some row_163) :=
    choose0_skip 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 30 1957146 1957129 (some row_163) (SearchFacts.query_1686 LCMSourcePV.PrimeFacts.prime_1957129) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 32 1957156=(some row_163) :=
    choose0_skip 1000 30 1957201 10712529 1409 1423 1427 1957157 1957187 31 1957156 1957147 (some row_163) (SearchFacts.query_1687 LCMSourcePV.PrimeFacts.prime_1957147) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1957201 10712529 1409 1423 1427 1957187 16 1957186=some row_163 :=
    choose1_hit 1000 30 32 1957201 10712529 1409 1423 1427 1957187 15 1957186 1957157 row_163 (SearchFacts.query_1688 LCMSourcePV.PrimeFacts.prime_1957157) c0_0_0
  have hsqrt : Nat.sqrt 1957201=1399 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1957201+1)=some 1409 := by
    rw [hsqrt];exact (SearchFacts.query_4284 LCMSourcePV.PrimeFacts.prime_1409)
  exact make_hit 1000 30 32 16 1957201 10712529 1409 1423 1427 1957187 row_163 h0 (SearchFacts.query_4285 LCMSourcePV.PrimeFacts.prime_1423) (SearchFacts.query_4286 LCMSourcePV.PrimeFacts.prime_1427) (SearchFacts.query_1689 LCMSourcePV.PrimeFacts.prime_1957187) c1_0
#print axioms make_163
end LCMSourcePV.Witness.BlockProofs
