/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_195 : Block := (Block.mk 2588881 2601768 1613 1619 1621 2588701 2588827 2588869)
theorem make_195 : make 1000 30 32 16 2588881 10712529=some row_195 := by
  have ck_0_8_0 : (Block.mk 2588881 2601768 1613 1619 1621 2588701 2588827 2588869).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1613 LCMSourcePV.PrimeFacts.prime_1619 LCMSourcePV.PrimeFacts.prime_1621 LCMSourcePV.PrimeFacts.prime_2588701 LCMSourcePV.PrimeFacts.prime_2588827 LCMSourcePV.PrimeFacts.prime_2588869
  have sh_0_8_0 : shrink 30 (Block.mk 2588881 2601768 1613 1619 1621 2588701 2588827 2588869)=some row_195 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 24 2588710=some row_195 :=
    choose0_hit 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 23 2588710 2588701 row_195 (SearchFacts.query_2004 LCMSourcePV.PrimeFacts.prime_2588701) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 25 2588722=(some row_195) :=
    choose0_skip 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 24 2588722 2588711 (some row_195) (SearchFacts.query_2005 LCMSourcePV.PrimeFacts.prime_2588711) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 26 2588752=(some row_195) :=
    choose0_skip 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 25 2588752 2588723 (some row_195) (SearchFacts.query_2006 LCMSourcePV.PrimeFacts.prime_2588723) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 27 2588766=(some row_195) :=
    choose0_skip 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 26 2588766 2588753 (some row_195) (SearchFacts.query_2007 LCMSourcePV.PrimeFacts.prime_2588753) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 28 2588770=(some row_195) :=
    choose0_skip 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 27 2588770 2588767 (some row_195) (SearchFacts.query_2008 LCMSourcePV.PrimeFacts.prime_2588767) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 29 2588808=(some row_195) :=
    choose0_skip 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 28 2588808 2588771 (some row_195) (SearchFacts.query_2009 LCMSourcePV.PrimeFacts.prime_2588771) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 30 2588818=(some row_195) :=
    choose0_skip 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 29 2588818 2588809 (some row_195) (SearchFacts.query_2010 LCMSourcePV.PrimeFacts.prime_2588809) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 31 2588820=(some row_195) :=
    choose0_skip 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 30 2588820 2588819 (some row_195) (SearchFacts.query_2011 LCMSourcePV.PrimeFacts.prime_2588819) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 32 2588826=(some row_195) :=
    choose0_skip 1000 30 2588881 10712529 1613 1619 1621 2588827 2588869 31 2588826 2588821 (some row_195) (SearchFacts.query_2012 LCMSourcePV.PrimeFacts.prime_2588821) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2588881 10712529 1613 1619 1621 2588869 16 2588868=some row_195 :=
    choose1_hit 1000 30 32 2588881 10712529 1613 1619 1621 2588869 15 2588868 2588827 row_195 (SearchFacts.query_2013 LCMSourcePV.PrimeFacts.prime_2588827) c0_0_0
  have hsqrt : Nat.sqrt 2588881=1609 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2588881+1)=some 1613 := by
    rw [hsqrt];exact (SearchFacts.query_4316 LCMSourcePV.PrimeFacts.prime_1613)
  exact make_hit 1000 30 32 16 2588881 10712529 1613 1619 1621 2588869 row_195 h0 (SearchFacts.query_4317 LCMSourcePV.PrimeFacts.prime_1619) (SearchFacts.query_4318 LCMSourcePV.PrimeFacts.prime_1621) (SearchFacts.query_2014 LCMSourcePV.PrimeFacts.prime_2588869) c1_0
#print axioms make_195
end LCMSourcePV.Witness.BlockProofs
