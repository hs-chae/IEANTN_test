/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_291 : Block := (Block.mk 5555449 5621640 2371 2377 2381 5555023 5555387 5555401)
theorem make_291 : make 1000 30 32 16 5555449 10712529=some row_291 := by
  have ck_0_20_0 : (Block.mk 5555449 5621640 2371 2377 2381 5555023 5555387 5555401).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2371 LCMSourcePV.PrimeFacts.prime_2377 LCMSourcePV.PrimeFacts.prime_2381 LCMSourcePV.PrimeFacts.prime_5555023 LCMSourcePV.PrimeFacts.prime_5555387 LCMSourcePV.PrimeFacts.prime_5555401
  have sh_0_20_0 : shrink 30 (Block.mk 5555449 5621640 2371 2377 2381 5555023 5555387 5555401)=some row_291 := shrink_hit _ _ ck_0_20_0
  have c0_0_20 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 12 5555046=some row_291 :=
    choose0_hit 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 11 5555046 5555023 row_291 (SearchFacts.query_2933 LCMSourcePV.PrimeFacts.prime_5555023) (by decide) sh_0_20_0
  have c0_0_19 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 13 5555056=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 12 5555056 5555047 (some row_291) (SearchFacts.query_2934 LCMSourcePV.PrimeFacts.prime_5555047) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 14 5555058=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 13 5555058 5555057 (some row_291) (SearchFacts.query_2935 LCMSourcePV.PrimeFacts.prime_5555057) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 15 5555082=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 14 5555082 5555059 (some row_291) (SearchFacts.query_2936 LCMSourcePV.PrimeFacts.prime_5555059) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 16 5555116=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 15 5555116 5555083 (some row_291) (SearchFacts.query_2937 LCMSourcePV.PrimeFacts.prime_5555083) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 17 5555148=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 16 5555148 5555117 (some row_291) (SearchFacts.query_2938 LCMSourcePV.PrimeFacts.prime_5555117) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 18 5555176=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 17 5555176 5555149 (some row_291) (SearchFacts.query_2939 LCMSourcePV.PrimeFacts.prime_5555149) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 19 5555182=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 18 5555182 5555177 (some row_291) (SearchFacts.query_2940 LCMSourcePV.PrimeFacts.prime_5555177) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 20 5555188=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 19 5555188 5555183 (some row_291) (SearchFacts.query_2941 LCMSourcePV.PrimeFacts.prime_5555183) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 21 5555190=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 20 5555190 5555189 (some row_291) (SearchFacts.query_2942 LCMSourcePV.PrimeFacts.prime_5555189) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 22 5555196=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 21 5555196 5555191 (some row_291) (SearchFacts.query_2943 LCMSourcePV.PrimeFacts.prime_5555191) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 23 5555218=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 22 5555218 5555197 (some row_291) (SearchFacts.query_2944 LCMSourcePV.PrimeFacts.prime_5555197) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 24 5555232=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 23 5555232 5555219 (some row_291) (SearchFacts.query_2945 LCMSourcePV.PrimeFacts.prime_5555219) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 25 5555236=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 24 5555236 5555233 (some row_291) (SearchFacts.query_2946 LCMSourcePV.PrimeFacts.prime_5555233) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 26 5555266=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 25 5555266 5555237 (some row_291) (SearchFacts.query_2947 LCMSourcePV.PrimeFacts.prime_5555237) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 27 5555320=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 26 5555320 5555267 (some row_291) (SearchFacts.query_2948 LCMSourcePV.PrimeFacts.prime_5555267) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 28 5555322=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 27 5555322 5555321 (some row_291) (SearchFacts.query_2949 LCMSourcePV.PrimeFacts.prime_5555321) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 29 5555338=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 28 5555338 5555323 (some row_291) (SearchFacts.query_2950 LCMSourcePV.PrimeFacts.prime_5555323) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 30 5555356=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 29 5555356 5555339 (some row_291) (SearchFacts.query_2951 LCMSourcePV.PrimeFacts.prime_5555339) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 31 5555368=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 30 5555368 5555357 (some row_291) (SearchFacts.query_2952 LCMSourcePV.PrimeFacts.prime_5555357) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 32 5555386=(some row_291) :=
    choose0_skip 1000 30 5555449 10712529 2371 2377 2381 5555387 5555401 31 5555386 5555369 (some row_291) (SearchFacts.query_2953 LCMSourcePV.PrimeFacts.prime_5555369) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5555449 10712529 2371 2377 2381 5555401 16 5555400=some row_291 :=
    choose1_hit 1000 30 32 5555449 10712529 2371 2377 2381 5555401 15 5555400 5555387 row_291 (SearchFacts.query_2954 LCMSourcePV.PrimeFacts.prime_5555387) c0_0_0
  have hsqrt : Nat.sqrt 5555449=2357 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5555449+1)=some 2371 := by
    rw [hsqrt];exact (SearchFacts.query_4412 LCMSourcePV.PrimeFacts.prime_2371)
  exact make_hit 1000 30 32 16 5555449 10712529 2371 2377 2381 5555401 row_291 h0 (SearchFacts.query_4413 LCMSourcePV.PrimeFacts.prime_2377) (SearchFacts.query_4414 LCMSourcePV.PrimeFacts.prime_2381) (SearchFacts.query_2955 LCMSourcePV.PrimeFacts.prime_5555401) c1_0
#print axioms make_291
end LCMSourcePV.Witness.BlockProofs
