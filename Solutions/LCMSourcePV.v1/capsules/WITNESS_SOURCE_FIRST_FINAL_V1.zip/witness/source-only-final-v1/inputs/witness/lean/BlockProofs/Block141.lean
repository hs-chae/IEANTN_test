/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_141 : Block := (Block.mk 1495729 1510440 1229 1231 1237 1495691 1495723 1495727)
theorem make_141 : make 1000 30 32 16 1495729 10712529=some row_141 := by
  have ck_0_1_0 : (Block.mk 1495729 1510440 1229 1231 1237 1495691 1495723 1495727).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1229 LCMSourcePV.PrimeFacts.prime_1231 LCMSourcePV.PrimeFacts.prime_1237 LCMSourcePV.PrimeFacts.prime_1495691 LCMSourcePV.PrimeFacts.prime_1495723 LCMSourcePV.PrimeFacts.prime_1495727
  have sh_0_1_0 : shrink 30 (Block.mk 1495729 1510440 1229 1231 1237 1495691 1495723 1495727)=some row_141 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 1495729 10712529 1229 1231 1237 1495723 1495727 31 1495716=some row_141 :=
    choose0_hit 1000 30 1495729 10712529 1229 1231 1237 1495723 1495727 30 1495716 1495691 row_141 (SearchFacts.query_1514 LCMSourcePV.PrimeFacts.prime_1495691) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 1495729 10712529 1229 1231 1237 1495723 1495727 32 1495722=(some row_141) :=
    choose0_skip 1000 30 1495729 10712529 1229 1231 1237 1495723 1495727 31 1495722 1495717 (some row_141) (SearchFacts.query_1515 LCMSourcePV.PrimeFacts.prime_1495717) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1495729 10712529 1229 1231 1237 1495727 16 1495726=some row_141 :=
    choose1_hit 1000 30 32 1495729 10712529 1229 1231 1237 1495727 15 1495726 1495723 row_141 (SearchFacts.query_1516 LCMSourcePV.PrimeFacts.prime_1495723) c0_0_0
  have hsqrt : Nat.sqrt 1495729=1223 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1495729+1)=some 1229 := by
    rw [hsqrt];exact (SearchFacts.query_4262 LCMSourcePV.PrimeFacts.prime_1229)
  exact make_hit 1000 30 32 16 1495729 10712529 1229 1231 1237 1495727 row_141 h0 (SearchFacts.query_4263 LCMSourcePV.PrimeFacts.prime_1231) (SearchFacts.query_4264 LCMSourcePV.PrimeFacts.prime_1237) (SearchFacts.query_1517 LCMSourcePV.PrimeFacts.prime_1495727) c1_0
#print axioms make_141
end LCMSourcePV.Witness.BlockProofs
