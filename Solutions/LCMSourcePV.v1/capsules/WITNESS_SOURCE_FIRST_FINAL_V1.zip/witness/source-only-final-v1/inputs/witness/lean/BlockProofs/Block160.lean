/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_160 : Block := (Block.mk 1868689 1885128 1373 1381 1399 1868567 1868677 1868687)
theorem make_160 : make 1000 30 32 16 1868689 10712529=some row_160 := by
  have ck_0_8_0 : (Block.mk 1868689 1885128 1373 1381 1399 1868567 1868677 1868687).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1373 LCMSourcePV.PrimeFacts.prime_1381 LCMSourcePV.PrimeFacts.prime_1399 LCMSourcePV.PrimeFacts.prime_1868567 LCMSourcePV.PrimeFacts.prime_1868677 LCMSourcePV.PrimeFacts.prime_1868687
  have sh_0_8_0 : shrink 30 (Block.mk 1868689 1885128 1373 1381 1399 1868567 1868677 1868687)=some row_160 := shrink_hit _ _ ck_0_8_0
  have c0_0_8 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 24 1868568=some row_160 :=
    choose0_hit 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 23 1868568 1868567 row_160 (SearchFacts.query_1658 LCMSourcePV.PrimeFacts.prime_1868567) (by decide) sh_0_8_0
  have c0_0_7 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 25 1868590=(some row_160) :=
    choose0_skip 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 24 1868590 1868569 (some row_160) (SearchFacts.query_1659 LCMSourcePV.PrimeFacts.prime_1868569) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 26 1868598=(some row_160) :=
    choose0_skip 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 25 1868598 1868591 (some row_160) (SearchFacts.query_1660 LCMSourcePV.PrimeFacts.prime_1868591) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 27 1868616=(some row_160) :=
    choose0_skip 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 26 1868616 1868599 (some row_160) (SearchFacts.query_1661 LCMSourcePV.PrimeFacts.prime_1868599) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 28 1868626=(some row_160) :=
    choose0_skip 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 27 1868626 1868617 (some row_160) (SearchFacts.query_1662 LCMSourcePV.PrimeFacts.prime_1868617) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 29 1868638=(some row_160) :=
    choose0_skip 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 28 1868638 1868627 (some row_160) (SearchFacts.query_1663 LCMSourcePV.PrimeFacts.prime_1868627) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 30 1868640=(some row_160) :=
    choose0_skip 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 29 1868640 1868639 (some row_160) (SearchFacts.query_1664 LCMSourcePV.PrimeFacts.prime_1868639) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 31 1868662=(some row_160) :=
    choose0_skip 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 30 1868662 1868641 (some row_160) (SearchFacts.query_1665 LCMSourcePV.PrimeFacts.prime_1868641) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 32 1868676=(some row_160) :=
    choose0_skip 1000 30 1868689 10712529 1373 1381 1399 1868677 1868687 31 1868676 1868663 (some row_160) (SearchFacts.query_1666 LCMSourcePV.PrimeFacts.prime_1868663) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1868689 10712529 1373 1381 1399 1868687 16 1868686=some row_160 :=
    choose1_hit 1000 30 32 1868689 10712529 1373 1381 1399 1868687 15 1868686 1868677 row_160 (SearchFacts.query_1667 LCMSourcePV.PrimeFacts.prime_1868677) c0_0_0
  have hsqrt : Nat.sqrt 1868689=1367 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1868689+1)=some 1373 := by
    rw [hsqrt];exact (SearchFacts.query_4281 LCMSourcePV.PrimeFacts.prime_1373)
  exact make_hit 1000 30 32 16 1868689 10712529 1373 1381 1399 1868687 row_160 h0 (SearchFacts.query_4282 LCMSourcePV.PrimeFacts.prime_1381) (SearchFacts.query_4283 LCMSourcePV.PrimeFacts.prime_1399) (SearchFacts.query_1668 LCMSourcePV.PrimeFacts.prime_1868687) c1_0
#print axioms make_160
end LCMSourcePV.Witness.BlockProofs
