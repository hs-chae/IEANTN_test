/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_280 : Block := (Block.mk 5202961 5230368 2287 2293 2297 5202877 5202913 5202917)
theorem make_280 : make 1000 30 32 16 5202961 10712529=some row_280 := by
  have ck_0_3_0 : (Block.mk 5202961 5230368 2287 2293 2297 5202877 5202913 5202917).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2287 LCMSourcePV.PrimeFacts.prime_2293 LCMSourcePV.PrimeFacts.prime_2297 LCMSourcePV.PrimeFacts.prime_5202877 LCMSourcePV.PrimeFacts.prime_5202913 LCMSourcePV.PrimeFacts.prime_5202917
  have sh_0_3_0 : shrink 30 (Block.mk 5202961 5230368 2287 2293 2297 5202877 5202913 5202917)=some row_280 := shrink_hit _ _ ck_0_3_0
  have c0_0_3 : choose0 1000 30 5202961 10712529 2287 2293 2297 5202913 5202917 29 5202886=some row_280 :=
    choose0_hit 1000 30 5202961 10712529 2287 2293 2297 5202913 5202917 28 5202886 5202877 row_280 (SearchFacts.query_2825 LCMSourcePV.PrimeFacts.prime_5202877) (by decide) sh_0_3_0
  have c0_0_2 : choose0 1000 30 5202961 10712529 2287 2293 2297 5202913 5202917 30 5202892=(some row_280) :=
    choose0_skip 1000 30 5202961 10712529 2287 2293 2297 5202913 5202917 29 5202892 5202887 (some row_280) (SearchFacts.query_2826 LCMSourcePV.PrimeFacts.prime_5202887) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5202961 10712529 2287 2293 2297 5202913 5202917 31 5202906=(some row_280) :=
    choose0_skip 1000 30 5202961 10712529 2287 2293 2297 5202913 5202917 30 5202906 5202893 (some row_280) (SearchFacts.query_2827 LCMSourcePV.PrimeFacts.prime_5202893) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5202961 10712529 2287 2293 2297 5202913 5202917 32 5202912=(some row_280) :=
    choose0_skip 1000 30 5202961 10712529 2287 2293 2297 5202913 5202917 31 5202912 5202907 (some row_280) (SearchFacts.query_2828 LCMSourcePV.PrimeFacts.prime_5202907) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5202961 10712529 2287 2293 2297 5202917 16 5202916=some row_280 :=
    choose1_hit 1000 30 32 5202961 10712529 2287 2293 2297 5202917 15 5202916 5202913 row_280 (SearchFacts.query_2829 LCMSourcePV.PrimeFacts.prime_5202913) c0_0_0
  have hsqrt : Nat.sqrt 5202961=2281 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5202961+1)=some 2287 := by
    rw [hsqrt];exact (SearchFacts.query_4401 LCMSourcePV.PrimeFacts.prime_2287)
  exact make_hit 1000 30 32 16 5202961 10712529 2287 2293 2297 5202917 row_280 h0 (SearchFacts.query_4402 LCMSourcePV.PrimeFacts.prime_2293) (SearchFacts.query_4403 LCMSourcePV.PrimeFacts.prime_2297) (SearchFacts.query_2830 LCMSourcePV.PrimeFacts.prime_5202917) c1_0
#print axioms make_280
end LCMSourcePV.Witness.BlockProofs
