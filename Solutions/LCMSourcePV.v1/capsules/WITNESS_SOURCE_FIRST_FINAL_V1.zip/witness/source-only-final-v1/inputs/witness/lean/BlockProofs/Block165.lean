/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_165 : Block := (Block.mk 2024929 2036328 1427 1429 1433 2024831 2024909 2024917)
theorem make_165 : make 1000 30 32 16 2024929 10712529=some row_165 := by
  have ck_0_6_0 : (Block.mk 2024929 2036328 1427 1429 1433 2024831 2024909 2024917).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1427 LCMSourcePV.PrimeFacts.prime_1429 LCMSourcePV.PrimeFacts.prime_1433 LCMSourcePV.PrimeFacts.prime_2024831 LCMSourcePV.PrimeFacts.prime_2024909 LCMSourcePV.PrimeFacts.prime_2024917
  have sh_0_6_0 : shrink 30 (Block.mk 2024929 2036328 1427 1429 1433 2024831 2024909 2024917)=some row_165 := shrink_hit _ _ ck_0_6_0
  have c0_0_6 : choose0 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 26 2024832=some row_165 :=
    choose0_hit 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 25 2024832 2024831 row_165 (SearchFacts.query_1697 LCMSourcePV.PrimeFacts.prime_2024831) (by decide) sh_0_6_0
  have c0_0_5 : choose0 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 27 2024842=(some row_165) :=
    choose0_skip 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 26 2024842 2024833 (some row_165) (SearchFacts.query_1698 LCMSourcePV.PrimeFacts.prime_2024833) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 28 2024860=(some row_165) :=
    choose0_skip 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 27 2024860 2024843 (some row_165) (SearchFacts.query_1699 LCMSourcePV.PrimeFacts.prime_2024843) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 29 2024862=(some row_165) :=
    choose0_skip 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 28 2024862 2024861 (some row_165) (SearchFacts.query_1700 LCMSourcePV.PrimeFacts.prime_2024861) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 30 2024872=(some row_165) :=
    choose0_skip 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 29 2024872 2024863 (some row_165) (SearchFacts.query_1701 LCMSourcePV.PrimeFacts.prime_2024863) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 31 2024880=(some row_165) :=
    choose0_skip 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 30 2024880 2024873 (some row_165) (SearchFacts.query_1702 LCMSourcePV.PrimeFacts.prime_2024873) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 32 2024908=(some row_165) :=
    choose0_skip 1000 30 2024929 10712529 1427 1429 1433 2024909 2024917 31 2024908 2024881 (some row_165) (SearchFacts.query_1703 LCMSourcePV.PrimeFacts.prime_2024881) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2024929 10712529 1427 1429 1433 2024917 16 2024916=some row_165 :=
    choose1_hit 1000 30 32 2024929 10712529 1427 1429 1433 2024917 15 2024916 2024909 row_165 (SearchFacts.query_1704 LCMSourcePV.PrimeFacts.prime_2024909) c0_0_0
  have hsqrt : Nat.sqrt 2024929=1423 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2024929+1)=some 1427 := by
    rw [hsqrt];exact (SearchFacts.query_4286 LCMSourcePV.PrimeFacts.prime_1427)
  exact make_hit 1000 30 32 16 2024929 10712529 1427 1429 1433 2024917 row_165 h0 (SearchFacts.query_4287 LCMSourcePV.PrimeFacts.prime_1429) (SearchFacts.query_4288 LCMSourcePV.PrimeFacts.prime_1433) (SearchFacts.query_1705 LCMSourcePV.PrimeFacts.prime_2024917) c1_0
#print axioms make_165
end LCMSourcePV.Witness.BlockProofs
