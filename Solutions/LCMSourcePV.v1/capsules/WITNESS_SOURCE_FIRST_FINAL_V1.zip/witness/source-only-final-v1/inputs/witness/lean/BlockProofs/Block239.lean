/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_239 : Block := (Block.mk 3892729 3916440 1979 1987 1993 3892631 3892657 3892697)
theorem make_239 : make 1000 30 32 16 3892729 10712529=some row_239 := by
  have ck_0_1_0 : (Block.mk 3892729 3916440 1979 1987 1993 3892631 3892657 3892697).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1979 LCMSourcePV.PrimeFacts.prime_1987 LCMSourcePV.PrimeFacts.prime_1993 LCMSourcePV.PrimeFacts.prime_3892631 LCMSourcePV.PrimeFacts.prime_3892657 LCMSourcePV.PrimeFacts.prime_3892697
  have sh_0_1_0 : shrink 30 (Block.mk 3892729 3916440 1979 1987 1993 3892631 3892657 3892697)=some row_239 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 3892729 10712529 1979 1987 1993 3892657 3892697 31 3892648=some row_239 :=
    choose0_hit 1000 30 3892729 10712529 1979 1987 1993 3892657 3892697 30 3892648 3892631 row_239 (SearchFacts.query_2435 LCMSourcePV.PrimeFacts.prime_3892631) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 3892729 10712529 1979 1987 1993 3892657 3892697 32 3892656=(some row_239) :=
    choose0_skip 1000 30 3892729 10712529 1979 1987 1993 3892657 3892697 31 3892656 3892649 (some row_239) (SearchFacts.query_2436 LCMSourcePV.PrimeFacts.prime_3892649) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3892729 10712529 1979 1987 1993 3892697 16 3892696=some row_239 :=
    choose1_hit 1000 30 32 3892729 10712529 1979 1987 1993 3892697 15 3892696 3892657 row_239 (SearchFacts.query_2437 LCMSourcePV.PrimeFacts.prime_3892657) c0_0_0
  have hsqrt : Nat.sqrt 3892729=1973 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3892729+1)=some 1979 := by
    rw [hsqrt];exact (SearchFacts.query_4360 LCMSourcePV.PrimeFacts.prime_1979)
  exact make_hit 1000 30 32 16 3892729 10712529 1979 1987 1993 3892697 row_239 h0 (SearchFacts.query_4361 LCMSourcePV.PrimeFacts.prime_1987) (SearchFacts.query_4362 LCMSourcePV.PrimeFacts.prime_1993) (SearchFacts.query_2438 LCMSourcePV.PrimeFacts.prime_3892697) c1_0
#print axioms make_239
end LCMSourcePV.Witness.BlockProofs
