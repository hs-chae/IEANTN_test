/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_203 : Block := (Block.mk 2778889 2785560 1669 1693 1697 2778583 2778863 2778877)
theorem make_203 : make 1000 30 32 16 2778889 10712529=some row_203 := by
  have ck_0_15_0 : (Block.mk 2778889 2785560 1669 1693 1697 2778583 2778863 2778877).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1669 LCMSourcePV.PrimeFacts.prime_1693 LCMSourcePV.PrimeFacts.prime_1697 LCMSourcePV.PrimeFacts.prime_2778583 LCMSourcePV.PrimeFacts.prime_2778863 LCMSourcePV.PrimeFacts.prime_2778877
  have sh_0_15_0 : shrink 30 (Block.mk 2778889 2785560 1669 1693 1697 2778583 2778863 2778877)=some row_203 := shrink_hit _ _ ck_0_15_0
  have c0_0_15 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 17 2778618=some row_203 :=
    choose0_hit 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 16 2778618 2778583 row_203 (SearchFacts.query_2072 LCMSourcePV.PrimeFacts.prime_2778583) (by decide) sh_0_15_0
  have c0_0_14 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 18 2778646=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 17 2778646 2778619 (some row_203) (SearchFacts.query_2073 LCMSourcePV.PrimeFacts.prime_2778619) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 19 2778648=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 18 2778648 2778647 (some row_203) (SearchFacts.query_2074 LCMSourcePV.PrimeFacts.prime_2778647) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 20 2778672=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 19 2778672 2778649 (some row_203) (SearchFacts.query_2075 LCMSourcePV.PrimeFacts.prime_2778649) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 21 2778688=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 20 2778688 2778673 (some row_203) (SearchFacts.query_2076 LCMSourcePV.PrimeFacts.prime_2778673) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 22 2778696=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 21 2778696 2778689 (some row_203) (SearchFacts.query_2077 LCMSourcePV.PrimeFacts.prime_2778689) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 23 2778738=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 22 2778738 2778697 (some row_203) (SearchFacts.query_2078 LCMSourcePV.PrimeFacts.prime_2778697) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 24 2778778=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 23 2778778 2778739 (some row_203) (SearchFacts.query_2079 LCMSourcePV.PrimeFacts.prime_2778739) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 25 2778792=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 24 2778792 2778779 (some row_203) (SearchFacts.query_2080 LCMSourcePV.PrimeFacts.prime_2778779) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 26 2778798=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 25 2778798 2778793 (some row_203) (SearchFacts.query_2081 LCMSourcePV.PrimeFacts.prime_2778793) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 27 2778822=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 26 2778822 2778799 (some row_203) (SearchFacts.query_2082 LCMSourcePV.PrimeFacts.prime_2778799) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 28 2778826=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 27 2778826 2778823 (some row_203) (SearchFacts.query_2083 LCMSourcePV.PrimeFacts.prime_2778823) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 29 2778828=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 28 2778828 2778827 (some row_203) (SearchFacts.query_2084 LCMSourcePV.PrimeFacts.prime_2778827) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 30 2778832=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 29 2778832 2778829 (some row_203) (SearchFacts.query_2085 LCMSourcePV.PrimeFacts.prime_2778829) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 31 2778850=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 30 2778850 2778833 (some row_203) (SearchFacts.query_2086 LCMSourcePV.PrimeFacts.prime_2778833) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 32 2778862=(some row_203) :=
    choose0_skip 1000 30 2778889 10712529 1669 1693 1697 2778863 2778877 31 2778862 2778851 (some row_203) (SearchFacts.query_2087 LCMSourcePV.PrimeFacts.prime_2778851) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2778889 10712529 1669 1693 1697 2778877 16 2778876=some row_203 :=
    choose1_hit 1000 30 32 2778889 10712529 1669 1693 1697 2778877 15 2778876 2778863 row_203 (SearchFacts.query_2088 LCMSourcePV.PrimeFacts.prime_2778863) c0_0_0
  have hsqrt : Nat.sqrt 2778889=1667 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2778889+1)=some 1669 := by
    rw [hsqrt];exact (SearchFacts.query_4324 LCMSourcePV.PrimeFacts.prime_1669)
  exact make_hit 1000 30 32 16 2778889 10712529 1669 1693 1697 2778877 row_203 h0 (SearchFacts.query_4325 LCMSourcePV.PrimeFacts.prime_1693) (SearchFacts.query_4326 LCMSourcePV.PrimeFacts.prime_1697) (SearchFacts.query_2089 LCMSourcePV.PrimeFacts.prime_2778877) c1_0
#print axioms make_203
end LCMSourcePV.Witness.BlockProofs
