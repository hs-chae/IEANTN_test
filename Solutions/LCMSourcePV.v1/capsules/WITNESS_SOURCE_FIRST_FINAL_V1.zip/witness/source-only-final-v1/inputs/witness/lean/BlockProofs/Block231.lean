/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_231 : Block := (Block.mk 3568321 3613800 1901 1907 1913 3568157 3568259 3568307)
theorem make_231 : make 1000 30 32 16 3568321 10712529=some row_231 := by
  have ck_0_7_0 : (Block.mk 3568321 3613800 1901 1907 1913 3568157 3568259 3568307).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1901 LCMSourcePV.PrimeFacts.prime_1907 LCMSourcePV.PrimeFacts.prime_1913 LCMSourcePV.PrimeFacts.prime_3568157 LCMSourcePV.PrimeFacts.prime_3568259 LCMSourcePV.PrimeFacts.prime_3568307
  have sh_0_7_0 : shrink 30 (Block.mk 3568321 3613800 1901 1907 1913 3568157 3568259 3568307)=some row_231 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 25 3568162=some row_231 :=
    choose0_hit 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 24 3568162 3568157 row_231 (SearchFacts.query_2363 LCMSourcePV.PrimeFacts.prime_3568157) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 26 3568206=(some row_231) :=
    choose0_skip 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 25 3568206 3568163 (some row_231) (SearchFacts.query_2364 LCMSourcePV.PrimeFacts.prime_3568163) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 27 3568210=(some row_231) :=
    choose0_skip 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 26 3568210 3568207 (some row_231) (SearchFacts.query_2365 LCMSourcePV.PrimeFacts.prime_3568207) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 28 3568216=(some row_231) :=
    choose0_skip 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 27 3568216 3568211 (some row_231) (SearchFacts.query_2366 LCMSourcePV.PrimeFacts.prime_3568211) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 29 3568230=(some row_231) :=
    choose0_skip 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 28 3568230 3568217 (some row_231) (SearchFacts.query_2367 LCMSourcePV.PrimeFacts.prime_3568217) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 30 3568236=(some row_231) :=
    choose0_skip 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 29 3568236 3568231 (some row_231) (SearchFacts.query_2368 LCMSourcePV.PrimeFacts.prime_3568231) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 31 3568240=(some row_231) :=
    choose0_skip 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 30 3568240 3568237 (some row_231) (SearchFacts.query_2369 LCMSourcePV.PrimeFacts.prime_3568237) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 32 3568258=(some row_231) :=
    choose0_skip 1000 30 3568321 10712529 1901 1907 1913 3568259 3568307 31 3568258 3568241 (some row_231) (SearchFacts.query_2370 LCMSourcePV.PrimeFacts.prime_3568241) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3568321 10712529 1901 1907 1913 3568307 16 3568306=some row_231 :=
    choose1_hit 1000 30 32 3568321 10712529 1901 1907 1913 3568307 15 3568306 3568259 row_231 (SearchFacts.query_2371 LCMSourcePV.PrimeFacts.prime_3568259) c0_0_0
  have hsqrt : Nat.sqrt 3568321=1889 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3568321+1)=some 1901 := by
    rw [hsqrt];exact (SearchFacts.query_4352 LCMSourcePV.PrimeFacts.prime_1901)
  exact make_hit 1000 30 32 16 3568321 10712529 1901 1907 1913 3568307 row_231 h0 (SearchFacts.query_4353 LCMSourcePV.PrimeFacts.prime_1907) (SearchFacts.query_4354 LCMSourcePV.PrimeFacts.prime_1913) (SearchFacts.query_2372 LCMSourcePV.PrimeFacts.prime_3568307) c1_0
#print axioms make_231
end LCMSourcePV.Witness.BlockProofs
