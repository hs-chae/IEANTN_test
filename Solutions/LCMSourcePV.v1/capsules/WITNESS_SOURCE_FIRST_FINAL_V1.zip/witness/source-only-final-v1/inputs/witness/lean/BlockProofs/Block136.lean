/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_136 : Block := (Block.mk 1408969 1423248 1193 1201 1213 1408879 1408961 1408963)
theorem make_136 : make 1000 30 32 16 1408969 10712529=some row_136 := by
  have ck_0_1_0 : (Block.mk 1408969 1423248 1193 1201 1213 1408879 1408961 1408963).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1193 LCMSourcePV.PrimeFacts.prime_1201 LCMSourcePV.PrimeFacts.prime_1213 LCMSourcePV.PrimeFacts.prime_1408879 LCMSourcePV.PrimeFacts.prime_1408961 LCMSourcePV.PrimeFacts.prime_1408963
  have sh_0_1_0 : shrink 30 (Block.mk 1408969 1423248 1193 1201 1213 1408879 1408961 1408963)=some row_136 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 1408969 10712529 1193 1201 1213 1408961 1408963 31 1408888=some row_136 :=
    choose0_hit 1000 30 1408969 10712529 1193 1201 1213 1408961 1408963 30 1408888 1408879 row_136 (SearchFacts.query_1478 LCMSourcePV.PrimeFacts.prime_1408879) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 1408969 10712529 1193 1201 1213 1408961 1408963 32 1408960=(some row_136) :=
    choose0_skip 1000 30 1408969 10712529 1193 1201 1213 1408961 1408963 31 1408960 1408889 (some row_136) (SearchFacts.query_1479 LCMSourcePV.PrimeFacts.prime_1408889) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1408969 10712529 1193 1201 1213 1408963 16 1408962=some row_136 :=
    choose1_hit 1000 30 32 1408969 10712529 1193 1201 1213 1408963 15 1408962 1408961 row_136 (SearchFacts.query_1480 LCMSourcePV.PrimeFacts.prime_1408961) c0_0_0
  have hsqrt : Nat.sqrt 1408969=1187 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1408969+1)=some 1193 := by
    rw [hsqrt];exact (SearchFacts.query_4257 LCMSourcePV.PrimeFacts.prime_1193)
  exact make_hit 1000 30 32 16 1408969 10712529 1193 1201 1213 1408963 row_136 h0 (SearchFacts.query_4258 LCMSourcePV.PrimeFacts.prime_1201) (SearchFacts.query_4259 LCMSourcePV.PrimeFacts.prime_1213) (SearchFacts.query_1481 LCMSourcePV.PrimeFacts.prime_1408963) c1_0
#print axioms make_136
end LCMSourcePV.Witness.BlockProofs
