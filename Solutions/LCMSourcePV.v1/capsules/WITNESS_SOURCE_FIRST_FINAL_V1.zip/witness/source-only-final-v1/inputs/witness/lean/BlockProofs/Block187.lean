/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_187 : Block := (Block.mk 2430481 2455488 1567 1571 1579 2430397 2430457 2430469)
theorem make_187 : make 1000 30 32 16 2430481 10712529=some row_187 := by
  have ck_0_2_0 : (Block.mk 2430481 2455488 1567 1571 1579 2430397 2430457 2430469).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1567 LCMSourcePV.PrimeFacts.prime_1571 LCMSourcePV.PrimeFacts.prime_1579 LCMSourcePV.PrimeFacts.prime_2430397 LCMSourcePV.PrimeFacts.prime_2430457 LCMSourcePV.PrimeFacts.prime_2430469
  have sh_0_2_0 : shrink 30 (Block.mk 2430481 2455488 1567 1571 1579 2430397 2430457 2430469)=some row_187 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 2430481 10712529 1567 1571 1579 2430457 2430469 30 2430426=some row_187 :=
    choose0_hit 1000 30 2430481 10712529 1567 1571 1579 2430457 2430469 29 2430426 2430397 row_187 (SearchFacts.query_1922 LCMSourcePV.PrimeFacts.prime_2430397) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 2430481 10712529 1567 1571 1579 2430457 2430469 31 2430450=(some row_187) :=
    choose0_skip 1000 30 2430481 10712529 1567 1571 1579 2430457 2430469 30 2430450 2430427 (some row_187) (SearchFacts.query_1923 LCMSourcePV.PrimeFacts.prime_2430427) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2430481 10712529 1567 1571 1579 2430457 2430469 32 2430456=(some row_187) :=
    choose0_skip 1000 30 2430481 10712529 1567 1571 1579 2430457 2430469 31 2430456 2430451 (some row_187) (SearchFacts.query_1924 LCMSourcePV.PrimeFacts.prime_2430451) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2430481 10712529 1567 1571 1579 2430469 16 2430468=some row_187 :=
    choose1_hit 1000 30 32 2430481 10712529 1567 1571 1579 2430469 15 2430468 2430457 row_187 (SearchFacts.query_1925 LCMSourcePV.PrimeFacts.prime_2430457) c0_0_0
  have hsqrt : Nat.sqrt 2430481=1559 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2430481+1)=some 1567 := by
    rw [hsqrt];exact (SearchFacts.query_4308 LCMSourcePV.PrimeFacts.prime_1567)
  exact make_hit 1000 30 32 16 2430481 10712529 1567 1571 1579 2430469 row_187 h0 (SearchFacts.query_4309 LCMSourcePV.PrimeFacts.prime_1571) (SearchFacts.query_4310 LCMSourcePV.PrimeFacts.prime_1579) (SearchFacts.query_1926 LCMSourcePV.PrimeFacts.prime_2430469) c1_0
#print axioms make_187
end LCMSourcePV.Witness.BlockProofs
