/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_303 : Block := (Block.mk 5958481 5987808 2447 2459 2467 5958349 5958451 5958473)
theorem make_303 : make 1000 30 32 16 5958481 10712529=some row_303 := by
  have ck_0_7_0 : (Block.mk 5958481 5987808 2447 2459 2467 5958349 5958451 5958473).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2447 LCMSourcePV.PrimeFacts.prime_2459 LCMSourcePV.PrimeFacts.prime_2467 LCMSourcePV.PrimeFacts.prime_5958349 LCMSourcePV.PrimeFacts.prime_5958451 LCMSourcePV.PrimeFacts.prime_5958473
  have sh_0_7_0 : shrink 30 (Block.mk 5958481 5987808 2447 2459 2467 5958349 5958451 5958473)=some row_303 := shrink_hit _ _ ck_0_7_0
  have c0_0_7 : choose0 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 25 5958366=some row_303 :=
    choose0_hit 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 24 5958366 5958349 row_303 (SearchFacts.query_3042 LCMSourcePV.PrimeFacts.prime_5958349) (by decide) sh_0_7_0
  have c0_0_6 : choose0 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 26 5958370=(some row_303) :=
    choose0_skip 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 25 5958370 5958367 (some row_303) (SearchFacts.query_3043 LCMSourcePV.PrimeFacts.prime_5958367) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 27 5958388=(some row_303) :=
    choose0_skip 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 26 5958388 5958371 (some row_303) (SearchFacts.query_3044 LCMSourcePV.PrimeFacts.prime_5958371) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 28 5958400=(some row_303) :=
    choose0_skip 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 27 5958400 5958389 (some row_303) (SearchFacts.query_3045 LCMSourcePV.PrimeFacts.prime_5958389) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 29 5958430=(some row_303) :=
    choose0_skip 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 28 5958430 5958401 (some row_303) (SearchFacts.query_3046 LCMSourcePV.PrimeFacts.prime_5958401) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 30 5958436=(some row_303) :=
    choose0_skip 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 29 5958436 5958431 (some row_303) (SearchFacts.query_3047 LCMSourcePV.PrimeFacts.prime_5958431) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 31 5958438=(some row_303) :=
    choose0_skip 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 30 5958438 5958437 (some row_303) (SearchFacts.query_3048 LCMSourcePV.PrimeFacts.prime_5958437) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 32 5958450=(some row_303) :=
    choose0_skip 1000 30 5958481 10712529 2447 2459 2467 5958451 5958473 31 5958450 5958439 (some row_303) (SearchFacts.query_3049 LCMSourcePV.PrimeFacts.prime_5958439) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 5958481 10712529 2447 2459 2467 5958473 16 5958472=some row_303 :=
    choose1_hit 1000 30 32 5958481 10712529 2447 2459 2467 5958473 15 5958472 5958451 row_303 (SearchFacts.query_3050 LCMSourcePV.PrimeFacts.prime_5958451) c0_0_0
  have hsqrt : Nat.sqrt 5958481=2441 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 5958481+1)=some 2447 := by
    rw [hsqrt];exact (SearchFacts.query_4424 LCMSourcePV.PrimeFacts.prime_2447)
  exact make_hit 1000 30 32 16 5958481 10712529 2447 2459 2467 5958473 row_303 h0 (SearchFacts.query_4425 LCMSourcePV.PrimeFacts.prime_2459) (SearchFacts.query_4426 LCMSourcePV.PrimeFacts.prime_2467) (SearchFacts.query_3051 LCMSourcePV.PrimeFacts.prime_5958473) c1_0
#print axioms make_303
end LCMSourcePV.Witness.BlockProofs
