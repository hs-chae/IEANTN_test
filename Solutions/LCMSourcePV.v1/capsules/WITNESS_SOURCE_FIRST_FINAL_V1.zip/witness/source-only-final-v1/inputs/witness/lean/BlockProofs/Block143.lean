/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_143 : Block := (Block.mk 1515361 1530168 1237 1249 1259 1515317 1515347 1515359)
theorem make_143 : make 1000 30 32 16 1515361 10712529=some row_143 := by
  have ck_0_0_0 : (Block.mk 1515361 1530168 1237 1249 1259 1515317 1515347 1515359).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1237 LCMSourcePV.PrimeFacts.prime_1249 LCMSourcePV.PrimeFacts.prime_1259 LCMSourcePV.PrimeFacts.prime_1515317 LCMSourcePV.PrimeFacts.prime_1515347 LCMSourcePV.PrimeFacts.prime_1515359
  have sh_0_0_0 : shrink 30 (Block.mk 1515361 1530168 1237 1249 1259 1515317 1515347 1515359)=some row_143 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 1515361 10712529 1237 1249 1259 1515347 1515359 32 1515346=some row_143 :=
    choose0_hit 1000 30 1515361 10712529 1237 1249 1259 1515347 1515359 31 1515346 1515317 row_143 (SearchFacts.query_1525 LCMSourcePV.PrimeFacts.prime_1515317) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 1515361 10712529 1237 1249 1259 1515359 16 1515358=some row_143 :=
    choose1_hit 1000 30 32 1515361 10712529 1237 1249 1259 1515359 15 1515358 1515347 row_143 (SearchFacts.query_1526 LCMSourcePV.PrimeFacts.prime_1515347) c0_0_0
  have hsqrt : Nat.sqrt 1515361=1231 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1515361+1)=some 1237 := by
    rw [hsqrt];exact (SearchFacts.query_4264 LCMSourcePV.PrimeFacts.prime_1237)
  exact make_hit 1000 30 32 16 1515361 10712529 1237 1249 1259 1515359 row_143 h0 (SearchFacts.query_4265 LCMSourcePV.PrimeFacts.prime_1249) (SearchFacts.query_4266 LCMSourcePV.PrimeFacts.prime_1259) (SearchFacts.query_1527 LCMSourcePV.PrimeFacts.prime_1515359) c1_0
#print axioms make_143
end LCMSourcePV.Witness.BlockProofs
