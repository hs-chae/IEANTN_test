/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_105 : Block := (Block.mk 942841 954528 977 983 991 942719 942811 942827)
theorem make_105 : make 1000 30 32 16 942841 10712529=some row_105 := by
  have ck_0_5_0 : (Block.mk 942841 954528 977 983 991 942719 942811 942827).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_977 LCMSourcePV.PrimeFacts.prime_983 LCMSourcePV.PrimeFacts.prime_991 LCMSourcePV.PrimeFacts.prime_942719 LCMSourcePV.PrimeFacts.prime_942811 LCMSourcePV.PrimeFacts.prime_942827
  have sh_0_5_0 : shrink 30 (Block.mk 942841 954528 977 983 991 942719 942811 942827)=some row_105 := shrink_hit _ _ ck_0_5_0
  have c0_0_5 : choose0 1000 30 942841 10712529 977 983 991 942811 942827 27 942726=some row_105 :=
    choose0_hit 1000 30 942841 10712529 977 983 991 942811 942827 26 942726 942719 row_105 (SearchFacts.query_1083 LCMSourcePV.PrimeFacts.prime_942719) (by decide) sh_0_5_0
  have c0_0_4 : choose0 1000 30 942841 10712529 977 983 991 942811 942827 28 942748=(some row_105) :=
    choose0_skip 1000 30 942841 10712529 977 983 991 942811 942827 27 942748 942727 (some row_105) (SearchFacts.query_1084 LCMSourcePV.PrimeFacts.prime_942727) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 942841 10712529 977 983 991 942811 942827 29 942762=(some row_105) :=
    choose0_skip 1000 30 942841 10712529 977 983 991 942811 942827 28 942762 942749 (some row_105) (SearchFacts.query_1085 LCMSourcePV.PrimeFacts.prime_942749) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 942841 10712529 977 983 991 942811 942827 30 942778=(some row_105) :=
    choose0_skip 1000 30 942841 10712529 977 983 991 942811 942827 29 942778 942763 (some row_105) (SearchFacts.query_1086 LCMSourcePV.PrimeFacts.prime_942763) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 942841 10712529 977 983 991 942811 942827 31 942786=(some row_105) :=
    choose0_skip 1000 30 942841 10712529 977 983 991 942811 942827 30 942786 942779 (some row_105) (SearchFacts.query_1087 LCMSourcePV.PrimeFacts.prime_942779) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 942841 10712529 977 983 991 942811 942827 32 942810=(some row_105) :=
    choose0_skip 1000 30 942841 10712529 977 983 991 942811 942827 31 942810 942787 (some row_105) (SearchFacts.query_1088 LCMSourcePV.PrimeFacts.prime_942787) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 942841 10712529 977 983 991 942827 16 942826=some row_105 :=
    choose1_hit 1000 30 32 942841 10712529 977 983 991 942827 15 942826 942811 row_105 (SearchFacts.query_1089 LCMSourcePV.PrimeFacts.prime_942811) c0_0_0
  have hsqrt : Nat.sqrt 942841=971 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 942841+1)=some 977 := by
    rw [hsqrt];exact (SearchFacts.query_4226 LCMSourcePV.PrimeFacts.prime_977)
  exact make_hit 1000 30 32 16 942841 10712529 977 983 991 942827 row_105 h0 (SearchFacts.query_4227 LCMSourcePV.PrimeFacts.prime_983) (SearchFacts.query_4228 LCMSourcePV.PrimeFacts.prime_991) (SearchFacts.query_1090 LCMSourcePV.PrimeFacts.prime_942827) c1_0
#print axioms make_105
end LCMSourcePV.Witness.BlockProofs
