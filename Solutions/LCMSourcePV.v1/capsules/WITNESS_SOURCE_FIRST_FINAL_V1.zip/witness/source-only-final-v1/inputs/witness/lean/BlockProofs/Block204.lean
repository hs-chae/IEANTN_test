/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_204 : Block := (Block.mk 2785561 2866248 1693 1697 1699 2785099 2785511 2785513)
theorem make_204 : make 1000 30 32 16 2785561 10712529=some row_204 := by
  have ck_0_24_0 : (Block.mk 2785561 2866248 1693 1697 1699 2785099 2785511 2785513).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1693 LCMSourcePV.PrimeFacts.prime_1697 LCMSourcePV.PrimeFacts.prime_1699 LCMSourcePV.PrimeFacts.prime_2785099 LCMSourcePV.PrimeFacts.prime_2785511 LCMSourcePV.PrimeFacts.prime_2785513
  have sh_0_24_0 : shrink 30 (Block.mk 2785561 2866248 1693 1697 1699 2785099 2785511 2785513)=some row_204 := shrink_hit _ _ ck_0_24_0
  have c0_0_24 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 8 2785128=some row_204 :=
    choose0_hit 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 7 2785128 2785099 row_204 (SearchFacts.query_2090 LCMSourcePV.PrimeFacts.prime_2785099) (by decide) sh_0_24_0
  have c0_0_23 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 9 2785156=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 8 2785156 2785129 (some row_204) (SearchFacts.query_2091 LCMSourcePV.PrimeFacts.prime_2785129) (by decide) c0_0_24
  have c0_0_22 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 10 2785176=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 9 2785176 2785157 (some row_204) (SearchFacts.query_2092 LCMSourcePV.PrimeFacts.prime_2785157) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 11 2785186=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 10 2785186 2785177 (some row_204) (SearchFacts.query_2093 LCMSourcePV.PrimeFacts.prime_2785177) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 12 2785200=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 11 2785200 2785187 (some row_204) (SearchFacts.query_2094 LCMSourcePV.PrimeFacts.prime_2785187) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 13 2785206=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 12 2785206 2785201 (some row_204) (SearchFacts.query_2095 LCMSourcePV.PrimeFacts.prime_2785201) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 14 2785218=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 13 2785218 2785207 (some row_204) (SearchFacts.query_2096 LCMSourcePV.PrimeFacts.prime_2785207) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 15 2785240=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 14 2785240 2785219 (some row_204) (SearchFacts.query_2097 LCMSourcePV.PrimeFacts.prime_2785219) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 16 2785260=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 15 2785260 2785241 (some row_204) (SearchFacts.query_2098 LCMSourcePV.PrimeFacts.prime_2785241) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 17 2785272=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 16 2785272 2785261 (some row_204) (SearchFacts.query_2099 LCMSourcePV.PrimeFacts.prime_2785261) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 18 2785300=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 17 2785300 2785273 (some row_204) (SearchFacts.query_2100 LCMSourcePV.PrimeFacts.prime_2785273) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 19 2785312=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 18 2785312 2785301 (some row_204) (SearchFacts.query_2101 LCMSourcePV.PrimeFacts.prime_2785301) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 20 2785332=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 19 2785332 2785313 (some row_204) (SearchFacts.query_2102 LCMSourcePV.PrimeFacts.prime_2785313) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 21 2785338=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 20 2785338 2785333 (some row_204) (SearchFacts.query_2103 LCMSourcePV.PrimeFacts.prime_2785333) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 22 2785350=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 21 2785350 2785339 (some row_204) (SearchFacts.query_2104 LCMSourcePV.PrimeFacts.prime_2785339) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 23 2785356=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 22 2785356 2785351 (some row_204) (SearchFacts.query_2105 LCMSourcePV.PrimeFacts.prime_2785351) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 24 2785378=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 23 2785378 2785357 (some row_204) (SearchFacts.query_2106 LCMSourcePV.PrimeFacts.prime_2785357) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 25 2785422=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 24 2785422 2785379 (some row_204) (SearchFacts.query_2107 LCMSourcePV.PrimeFacts.prime_2785379) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 26 2785438=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 25 2785438 2785423 (some row_204) (SearchFacts.query_2108 LCMSourcePV.PrimeFacts.prime_2785423) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 27 2785450=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 26 2785450 2785439 (some row_204) (SearchFacts.query_2109 LCMSourcePV.PrimeFacts.prime_2785439) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 28 2785462=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 27 2785462 2785451 (some row_204) (SearchFacts.query_2110 LCMSourcePV.PrimeFacts.prime_2785451) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 29 2785468=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 28 2785468 2785463 (some row_204) (SearchFacts.query_2111 LCMSourcePV.PrimeFacts.prime_2785463) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 30 2785482=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 29 2785482 2785469 (some row_204) (SearchFacts.query_2112 LCMSourcePV.PrimeFacts.prime_2785469) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 31 2785486=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 30 2785486 2785483 (some row_204) (SearchFacts.query_2113 LCMSourcePV.PrimeFacts.prime_2785483) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 32 2785510=(some row_204) :=
    choose0_skip 1000 30 2785561 10712529 1693 1697 1699 2785511 2785513 31 2785510 2785487 (some row_204) (SearchFacts.query_2114 LCMSourcePV.PrimeFacts.prime_2785487) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2785561 10712529 1693 1697 1699 2785513 16 2785512=some row_204 :=
    choose1_hit 1000 30 32 2785561 10712529 1693 1697 1699 2785513 15 2785512 2785511 row_204 (SearchFacts.query_2115 LCMSourcePV.PrimeFacts.prime_2785511) c0_0_0
  have hsqrt : Nat.sqrt 2785561=1669 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2785561+1)=some 1693 := by
    rw [hsqrt];exact (SearchFacts.query_4325 LCMSourcePV.PrimeFacts.prime_1693)
  exact make_hit 1000 30 32 16 2785561 10712529 1693 1697 1699 2785513 row_204 h0 (SearchFacts.query_4326 LCMSourcePV.PrimeFacts.prime_1697) (SearchFacts.query_4327 LCMSourcePV.PrimeFacts.prime_1699) (SearchFacts.query_2116 LCMSourcePV.PrimeFacts.prime_2785513) c1_0
#print axioms make_204
end LCMSourcePV.Witness.BlockProofs
