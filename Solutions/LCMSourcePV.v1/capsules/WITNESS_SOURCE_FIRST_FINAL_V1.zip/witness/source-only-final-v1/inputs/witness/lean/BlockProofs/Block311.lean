/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_311 : Block := (Block.mk 6405961 6446520 2539 2543 2549 6405797 6405941 6405943)
theorem make_311 : make 1000 30 32 16 6405961 10712529=some row_311 := by
  have ck_0_9_0 : (Block.mk 6405961 6446520 2539 2543 2549 6405797 6405941 6405943).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2539 LCMSourcePV.PrimeFacts.prime_2543 LCMSourcePV.PrimeFacts.prime_2549 LCMSourcePV.PrimeFacts.prime_6405797 LCMSourcePV.PrimeFacts.prime_6405941 LCMSourcePV.PrimeFacts.prime_6405943
  have sh_0_9_0 : shrink 30 (Block.mk 6405961 6446520 2539 2543 2549 6405797 6405941 6405943)=some row_311 := shrink_hit _ _ ck_0_9_0
  have c0_0_9 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 23 6405810=some row_311 :=
    choose0_hit 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 22 6405810 6405797 row_311 (SearchFacts.query_3159 LCMSourcePV.PrimeFacts.prime_6405797) (by decide) sh_0_9_0
  have c0_0_8 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 24 6405826=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 23 6405826 6405811 (some row_311) (SearchFacts.query_3160 LCMSourcePV.PrimeFacts.prime_6405811) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 25 6405828=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 24 6405828 6405827 (some row_311) (SearchFacts.query_3161 LCMSourcePV.PrimeFacts.prime_6405827) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 26 6405876=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 25 6405876 6405829 (some row_311) (SearchFacts.query_3162 LCMSourcePV.PrimeFacts.prime_6405829) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 27 6405898=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 26 6405898 6405877 (some row_311) (SearchFacts.query_3163 LCMSourcePV.PrimeFacts.prime_6405877) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 28 6405900=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 27 6405900 6405899 (some row_311) (SearchFacts.query_3164 LCMSourcePV.PrimeFacts.prime_6405899) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 29 6405910=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 28 6405910 6405901 (some row_311) (SearchFacts.query_3165 LCMSourcePV.PrimeFacts.prime_6405901) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 30 6405912=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 29 6405912 6405911 (some row_311) (SearchFacts.query_3166 LCMSourcePV.PrimeFacts.prime_6405911) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 31 6405928=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 30 6405928 6405913 (some row_311) (SearchFacts.query_3167 LCMSourcePV.PrimeFacts.prime_6405913) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 32 6405940=(some row_311) :=
    choose0_skip 1000 30 6405961 10712529 2539 2543 2549 6405941 6405943 31 6405940 6405929 (some row_311) (SearchFacts.query_3168 LCMSourcePV.PrimeFacts.prime_6405929) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 6405961 10712529 2539 2543 2549 6405943 16 6405942=some row_311 :=
    choose1_hit 1000 30 32 6405961 10712529 2539 2543 2549 6405943 15 6405942 6405941 row_311 (SearchFacts.query_3169 LCMSourcePV.PrimeFacts.prime_6405941) c0_0_0
  have hsqrt : Nat.sqrt 6405961=2531 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 6405961+1)=some 2539 := by
    rw [hsqrt];exact (SearchFacts.query_4432 LCMSourcePV.PrimeFacts.prime_2539)
  exact make_hit 1000 30 32 16 6405961 10712529 2539 2543 2549 6405943 row_311 h0 (SearchFacts.query_4433 LCMSourcePV.PrimeFacts.prime_2543) (SearchFacts.query_4434 LCMSourcePV.PrimeFacts.prime_2549) (SearchFacts.query_3170 LCMSourcePV.PrimeFacts.prime_6405943) c1_0
#print axioms make_311
end LCMSourcePV.Witness.BlockProofs
