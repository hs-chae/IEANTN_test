/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_180 : Block := (Block.mk 2247001 2283120 1511 1523 1531 2246971 2246977 2246999)
theorem make_180 : make 1000 30 32 16 2247001 10712529=some row_180 := by
  have ck_0_0_0 : (Block.mk 2247001 2283120 1511 1523 1531 2246971 2246977 2246999).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1511 LCMSourcePV.PrimeFacts.prime_1523 LCMSourcePV.PrimeFacts.prime_1531 LCMSourcePV.PrimeFacts.prime_2246971 LCMSourcePV.PrimeFacts.prime_2246977 LCMSourcePV.PrimeFacts.prime_2246999
  have sh_0_0_0 : shrink 30 (Block.mk 2247001 2283120 1511 1523 1531 2246971 2246977 2246999)=some row_180 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 2247001 10712529 1511 1523 1531 2246977 2246999 32 2246976=some row_180 :=
    choose0_hit 1000 30 2247001 10712529 1511 1523 1531 2246977 2246999 31 2246976 2246971 row_180 (SearchFacts.query_1811 LCMSourcePV.PrimeFacts.prime_2246971) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 2247001 10712529 1511 1523 1531 2246999 16 2246998=some row_180 :=
    choose1_hit 1000 30 32 2247001 10712529 1511 1523 1531 2246999 15 2246998 2246977 row_180 (SearchFacts.query_1812 LCMSourcePV.PrimeFacts.prime_2246977) c0_0_0
  have hsqrt : Nat.sqrt 2247001=1499 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2247001+1)=some 1511 := by
    rw [hsqrt];exact (SearchFacts.query_4301 LCMSourcePV.PrimeFacts.prime_1511)
  exact make_hit 1000 30 32 16 2247001 10712529 1511 1523 1531 2246999 row_180 h0 (SearchFacts.query_4302 LCMSourcePV.PrimeFacts.prime_1523) (SearchFacts.query_4303 LCMSourcePV.PrimeFacts.prime_1531) (SearchFacts.query_1813 LCMSourcePV.PrimeFacts.prime_2246999) c1_0
#print axioms make_180
end LCMSourcePV.Witness.BlockProofs
