/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_19 : Block := (Block.mk 157609 160800 401 409 419 157477 157561 157579)
theorem make_19 : make 1000 30 32 16 157609 10712529=some row_19 := by
  have c0_0_32 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 0 157230=none := rfl
  have c0_0_31 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 1 157242=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 0 157242 157231 none (SearchFacts.query_148 LCMSourcePV.PrimeFacts.prime_157231) (by decide) c0_0_32
  have c0_0_30 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 2 157246=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 1 157246 157243 none (SearchFacts.query_149 LCMSourcePV.PrimeFacts.prime_157243) (by decide) c0_0_31
  have c0_0_29 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 3 157252=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 2 157252 157247 none (SearchFacts.query_150 LCMSourcePV.PrimeFacts.prime_157247) (by decide) c0_0_30
  have c0_0_28 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 4 157258=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 3 157258 157253 none (SearchFacts.query_151 LCMSourcePV.PrimeFacts.prime_157253) (by decide) c0_0_29
  have c0_0_27 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 5 157270=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 4 157270 157259 none (SearchFacts.query_152 LCMSourcePV.PrimeFacts.prime_157259) (by decide) c0_0_28
  have c0_0_26 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 6 157272=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 5 157272 157271 none (SearchFacts.query_153 LCMSourcePV.PrimeFacts.prime_157271) (by decide) c0_0_27
  have c0_0_25 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 7 157276=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 6 157276 157273 none (SearchFacts.query_154 LCMSourcePV.PrimeFacts.prime_157273) (by decide) c0_0_26
  have c0_0_24 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 8 157278=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 7 157278 157277 none (SearchFacts.query_155 LCMSourcePV.PrimeFacts.prime_157277) (by decide) c0_0_25
  have c0_0_23 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 9 157290=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 8 157290 157279 none (SearchFacts.query_156 LCMSourcePV.PrimeFacts.prime_157279) (by decide) c0_0_24
  have c0_0_22 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 10 157302=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 9 157302 157291 none (SearchFacts.query_157 LCMSourcePV.PrimeFacts.prime_157291) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 11 157306=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 10 157306 157303 none (SearchFacts.query_158 LCMSourcePV.PrimeFacts.prime_157303) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 12 157320=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 11 157320 157307 none (SearchFacts.query_159 LCMSourcePV.PrimeFacts.prime_157307) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 13 157326=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 12 157326 157321 none (SearchFacts.query_160 LCMSourcePV.PrimeFacts.prime_157321) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 14 157348=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 13 157348 157327 none (SearchFacts.query_161 LCMSourcePV.PrimeFacts.prime_157327) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 15 157350=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 14 157350 157349 none (SearchFacts.query_162 LCMSourcePV.PrimeFacts.prime_157349) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 16 157362=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 15 157362 157351 none (SearchFacts.query_163 LCMSourcePV.PrimeFacts.prime_157351) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 17 157392=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 16 157392 157363 none (SearchFacts.query_164 LCMSourcePV.PrimeFacts.prime_157363) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 18 157410=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 17 157410 157393 none (SearchFacts.query_165 LCMSourcePV.PrimeFacts.prime_157393) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 19 157426=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 18 157426 157411 none (SearchFacts.query_166 LCMSourcePV.PrimeFacts.prime_157411) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 20 157428=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 19 157428 157427 none (SearchFacts.query_167 LCMSourcePV.PrimeFacts.prime_157427) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 21 157432=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 20 157432 157429 none (SearchFacts.query_168 LCMSourcePV.PrimeFacts.prime_157429) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 22 157456=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 21 157456 157433 none (SearchFacts.query_169 LCMSourcePV.PrimeFacts.prime_157433) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 23 157476=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 22 157476 157457 none (SearchFacts.query_170 LCMSourcePV.PrimeFacts.prime_157457) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 24 157482=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 23 157482 157477 none (SearchFacts.query_171 LCMSourcePV.PrimeFacts.prime_157477) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 25 157488=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 24 157488 157483 none (SearchFacts.query_172 LCMSourcePV.PrimeFacts.prime_157483) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 26 157512=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 25 157512 157489 none (SearchFacts.query_173 LCMSourcePV.PrimeFacts.prime_157489) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 27 157518=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 26 157518 157513 none (SearchFacts.query_174 LCMSourcePV.PrimeFacts.prime_157513) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 28 157522=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 27 157522 157519 none (SearchFacts.query_175 LCMSourcePV.PrimeFacts.prime_157519) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 29 157542=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 28 157542 157523 none (SearchFacts.query_176 LCMSourcePV.PrimeFacts.prime_157523) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 30 157558=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 29 157558 157543 none (SearchFacts.query_177 LCMSourcePV.PrimeFacts.prime_157543) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 31 157560=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 30 157560 157559 none (SearchFacts.query_178 LCMSourcePV.PrimeFacts.prime_157559) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 157609 10712529 401 409 419 157571 157579 32 157570=none :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157571 157579 31 157570 157561 none (SearchFacts.query_179 LCMSourcePV.PrimeFacts.prime_157561) (by decide) c0_0_1
  have ck_1_7_0 : (Block.mk 157609 160800 401 409 419 157477 157561 157579).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_401 LCMSourcePV.PrimeFacts.prime_409 LCMSourcePV.PrimeFacts.prime_419 LCMSourcePV.PrimeFacts.prime_157477 LCMSourcePV.PrimeFacts.prime_157561 LCMSourcePV.PrimeFacts.prime_157579
  have sh_1_7_0 : shrink 30 (Block.mk 157609 160800 401 409 419 157477 157561 157579)=some row_19 := shrink_hit _ _ ck_1_7_0
  have c0_1_7 : choose0 1000 30 157609 10712529 401 409 419 157561 157579 25 157482=some row_19 :=
    choose0_hit 1000 30 157609 10712529 401 409 419 157561 157579 24 157482 157477 row_19 (SearchFacts.query_171 LCMSourcePV.PrimeFacts.prime_157477) (by decide) sh_1_7_0
  have c0_1_6 : choose0 1000 30 157609 10712529 401 409 419 157561 157579 26 157488=(some row_19) :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157561 157579 25 157488 157483 (some row_19) (SearchFacts.query_172 LCMSourcePV.PrimeFacts.prime_157483) (by decide) c0_1_7
  have c0_1_5 : choose0 1000 30 157609 10712529 401 409 419 157561 157579 27 157512=(some row_19) :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157561 157579 26 157512 157489 (some row_19) (SearchFacts.query_173 LCMSourcePV.PrimeFacts.prime_157489) (by decide) c0_1_6
  have c0_1_4 : choose0 1000 30 157609 10712529 401 409 419 157561 157579 28 157518=(some row_19) :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157561 157579 27 157518 157513 (some row_19) (SearchFacts.query_174 LCMSourcePV.PrimeFacts.prime_157513) (by decide) c0_1_5
  have c0_1_3 : choose0 1000 30 157609 10712529 401 409 419 157561 157579 29 157522=(some row_19) :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157561 157579 28 157522 157519 (some row_19) (SearchFacts.query_175 LCMSourcePV.PrimeFacts.prime_157519) (by decide) c0_1_4
  have c0_1_2 : choose0 1000 30 157609 10712529 401 409 419 157561 157579 30 157542=(some row_19) :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157561 157579 29 157542 157523 (some row_19) (SearchFacts.query_176 LCMSourcePV.PrimeFacts.prime_157523) (by decide) c0_1_3
  have c0_1_1 : choose0 1000 30 157609 10712529 401 409 419 157561 157579 31 157558=(some row_19) :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157561 157579 30 157558 157543 (some row_19) (SearchFacts.query_177 LCMSourcePV.PrimeFacts.prime_157543) (by decide) c0_1_2
  have c0_1_0 : choose0 1000 30 157609 10712529 401 409 419 157561 157579 32 157560=(some row_19) :=
    choose0_skip 1000 30 157609 10712529 401 409 419 157561 157579 31 157560 157559 (some row_19) (SearchFacts.query_178 LCMSourcePV.PrimeFacts.prime_157559) (by decide) c0_1_1
  have c1_1 : choose1 1000 30 32 157609 10712529 401 409 419 157579 15 157570=some row_19 :=
    choose1_hit 1000 30 32 157609 10712529 401 409 419 157579 14 157570 157561 row_19 (SearchFacts.query_179 LCMSourcePV.PrimeFacts.prime_157561) c0_1_0
  have c1_0 : choose1 1000 30 32 157609 10712529 401 409 419 157579 16 157578=some row_19 :=
    choose1_skip 1000 30 32 157609 10712529 401 409 419 157579 15 157578 157571 (some row_19) (SearchFacts.query_180 LCMSourcePV.PrimeFacts.prime_157571) c0_0_0 c1_1
  have hsqrt : Nat.sqrt 157609=397 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 157609+1)=some 401 := by
    rw [hsqrt];exact (SearchFacts.query_4140 LCMSourcePV.PrimeFacts.prime_401)
  exact make_hit 1000 30 32 16 157609 10712529 401 409 419 157579 row_19 h0 (SearchFacts.query_4141 LCMSourcePV.PrimeFacts.prime_409) (SearchFacts.query_4142 LCMSourcePV.PrimeFacts.prime_419) (SearchFacts.query_181 LCMSourcePV.PrimeFacts.prime_157579) c1_0
#print axioms make_19
end LCMSourcePV.Witness.BlockProofs
