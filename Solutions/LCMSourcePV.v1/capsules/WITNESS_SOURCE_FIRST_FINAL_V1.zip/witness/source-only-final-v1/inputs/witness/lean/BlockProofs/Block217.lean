/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_217 : Block := (Block.mk 3179089 3193368 1787 1789 1801 3178961 3179063 3179087)
theorem make_217 : make 1000 30 32 16 3179089 10712529=some row_217 := by
  have ck_0_4_0 : (Block.mk 3179089 3193368 1787 1789 1801 3178961 3179063 3179087).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1787 LCMSourcePV.PrimeFacts.prime_1789 LCMSourcePV.PrimeFacts.prime_1801 LCMSourcePV.PrimeFacts.prime_3178961 LCMSourcePV.PrimeFacts.prime_3179063 LCMSourcePV.PrimeFacts.prime_3179087
  have sh_0_4_0 : shrink 30 (Block.mk 3179089 3193368 1787 1789 1801 3178961 3179063 3179087)=some row_217 := shrink_hit _ _ ck_0_4_0
  have c0_0_4 : choose0 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 28 3178962=some row_217 :=
    choose0_hit 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 27 3178962 3178961 row_217 (SearchFacts.query_2259 LCMSourcePV.PrimeFacts.prime_3178961) (by decide) sh_0_4_0
  have c0_0_3 : choose0 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 29 3178996=(some row_217) :=
    choose0_skip 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 28 3178996 3178963 (some row_217) (SearchFacts.query_2260 LCMSourcePV.PrimeFacts.prime_3178963) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 30 3178998=(some row_217) :=
    choose0_skip 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 29 3178998 3178997 (some row_217) (SearchFacts.query_2261 LCMSourcePV.PrimeFacts.prime_3178997) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 31 3179026=(some row_217) :=
    choose0_skip 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 30 3179026 3178999 (some row_217) (SearchFacts.query_2262 LCMSourcePV.PrimeFacts.prime_3178999) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 32 3179062=(some row_217) :=
    choose0_skip 1000 30 3179089 10712529 1787 1789 1801 3179063 3179087 31 3179062 3179027 (some row_217) (SearchFacts.query_2263 LCMSourcePV.PrimeFacts.prime_3179027) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3179089 10712529 1787 1789 1801 3179087 16 3179086=some row_217 :=
    choose1_hit 1000 30 32 3179089 10712529 1787 1789 1801 3179087 15 3179086 3179063 row_217 (SearchFacts.query_2264 LCMSourcePV.PrimeFacts.prime_3179063) c0_0_0
  have hsqrt : Nat.sqrt 3179089=1783 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3179089+1)=some 1787 := by
    rw [hsqrt];exact (SearchFacts.query_4338 LCMSourcePV.PrimeFacts.prime_1787)
  exact make_hit 1000 30 32 16 3179089 10712529 1787 1789 1801 3179087 row_217 h0 (SearchFacts.query_4339 LCMSourcePV.PrimeFacts.prime_1789) (SearchFacts.query_4340 LCMSourcePV.PrimeFacts.prime_1801) (SearchFacts.query_2265 LCMSourcePV.PrimeFacts.prime_3179087) c1_0
#print axioms make_217
end LCMSourcePV.Witness.BlockProofs
