/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_253 : Block := (Block.mk 4280761 4330560 2081 2083 2087 4280657 4280741 4280747)
theorem make_253 : make 1000 30 32 16 4280761 10712529=some row_253 := by
  have ck_0_1_0 : (Block.mk 4280761 4330560 2081 2083 2087 4280657 4280741 4280747).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_2081 LCMSourcePV.PrimeFacts.prime_2083 LCMSourcePV.PrimeFacts.prime_2087 LCMSourcePV.PrimeFacts.prime_4280657 LCMSourcePV.PrimeFacts.prime_4280741 LCMSourcePV.PrimeFacts.prime_4280747
  have sh_0_1_0 : shrink 30 (Block.mk 4280761 4330560 2081 2083 2087 4280657 4280741 4280747)=some row_253 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 4280761 10712529 2081 2083 2087 4280741 4280747 31 4280658=some row_253 :=
    choose0_hit 1000 30 4280761 10712529 2081 2083 2087 4280741 4280747 30 4280658 4280657 row_253 (SearchFacts.query_2577 LCMSourcePV.PrimeFacts.prime_4280657) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 4280761 10712529 2081 2083 2087 4280741 4280747 32 4280740=(some row_253) :=
    choose0_skip 1000 30 4280761 10712529 2081 2083 2087 4280741 4280747 31 4280740 4280659 (some row_253) (SearchFacts.query_2578 LCMSourcePV.PrimeFacts.prime_4280659) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 4280761 10712529 2081 2083 2087 4280747 16 4280746=some row_253 :=
    choose1_hit 1000 30 32 4280761 10712529 2081 2083 2087 4280747 15 4280746 4280741 row_253 (SearchFacts.query_2579 LCMSourcePV.PrimeFacts.prime_4280741) c0_0_0
  have hsqrt : Nat.sqrt 4280761=2069 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 4280761+1)=some 2081 := by
    rw [hsqrt];exact (SearchFacts.query_4374 LCMSourcePV.PrimeFacts.prime_2081)
  exact make_hit 1000 30 32 16 4280761 10712529 2081 2083 2087 4280747 row_253 h0 (SearchFacts.query_4375 LCMSourcePV.PrimeFacts.prime_2083) (SearchFacts.query_4376 LCMSourcePV.PrimeFacts.prime_2087) (SearchFacts.query_2580 LCMSourcePV.PrimeFacts.prime_4280747) c1_0
#print axioms make_253
end LCMSourcePV.Witness.BlockProofs
