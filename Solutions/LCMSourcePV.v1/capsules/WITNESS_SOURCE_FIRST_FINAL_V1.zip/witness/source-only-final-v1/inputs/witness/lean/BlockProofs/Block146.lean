/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_146 : Block := (Block.mk 1585081 1630728 1277 1279 1283 1585009 1585027 1585033)
theorem make_146 : make 1000 30 32 16 1585081 10712529=some row_146 := by
  have ck_0_2_0 : (Block.mk 1585081 1630728 1277 1279 1283 1585009 1585027 1585033).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1277 LCMSourcePV.PrimeFacts.prime_1279 LCMSourcePV.PrimeFacts.prime_1283 LCMSourcePV.PrimeFacts.prime_1585009 LCMSourcePV.PrimeFacts.prime_1585027 LCMSourcePV.PrimeFacts.prime_1585033
  have sh_0_2_0 : shrink 30 (Block.mk 1585081 1630728 1277 1279 1283 1585009 1585027 1585033)=some row_146 := shrink_hit _ _ ck_0_2_0
  have c0_0_2 : choose0 1000 30 1585081 10712529 1277 1279 1283 1585027 1585033 30 1585012=some row_146 :=
    choose0_hit 1000 30 1585081 10712529 1277 1279 1283 1585027 1585033 29 1585012 1585009 row_146 (SearchFacts.query_1553 LCMSourcePV.PrimeFacts.prime_1585009) (by decide) sh_0_2_0
  have c0_0_1 : choose0 1000 30 1585081 10712529 1277 1279 1283 1585027 1585033 31 1585020=(some row_146) :=
    choose0_skip 1000 30 1585081 10712529 1277 1279 1283 1585027 1585033 30 1585020 1585013 (some row_146) (SearchFacts.query_1554 LCMSourcePV.PrimeFacts.prime_1585013) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 1585081 10712529 1277 1279 1283 1585027 1585033 32 1585026=(some row_146) :=
    choose0_skip 1000 30 1585081 10712529 1277 1279 1283 1585027 1585033 31 1585026 1585021 (some row_146) (SearchFacts.query_1555 LCMSourcePV.PrimeFacts.prime_1585021) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 1585081 10712529 1277 1279 1283 1585033 16 1585032=some row_146 :=
    choose1_hit 1000 30 32 1585081 10712529 1277 1279 1283 1585033 15 1585032 1585027 row_146 (SearchFacts.query_1556 LCMSourcePV.PrimeFacts.prime_1585027) c0_0_0
  have hsqrt : Nat.sqrt 1585081=1259 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1585081+1)=some 1277 := by
    rw [hsqrt];exact (SearchFacts.query_4267 LCMSourcePV.PrimeFacts.prime_1277)
  exact make_hit 1000 30 32 16 1585081 10712529 1277 1279 1283 1585033 row_146 h0 (SearchFacts.query_4268 LCMSourcePV.PrimeFacts.prime_1279) (SearchFacts.query_4269 LCMSourcePV.PrimeFacts.prime_1283) (SearchFacts.query_1557 LCMSourcePV.PrimeFacts.prime_1585033) c1_0
#print axioms make_146
end LCMSourcePV.Witness.BlockProofs
