/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_202 : Block := (Block.mk 2765569 2778888 1667 1669 1693 2765369 2765531 2765551)
theorem make_202 : make 1000 30 32 16 2765569 10712529=some row_202 := by
  have ck_0_11_0 : (Block.mk 2765569 2778888 1667 1669 1693 2765369 2765531 2765551).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1667 LCMSourcePV.PrimeFacts.prime_1669 LCMSourcePV.PrimeFacts.prime_1693 LCMSourcePV.PrimeFacts.prime_2765369 LCMSourcePV.PrimeFacts.prime_2765531 LCMSourcePV.PrimeFacts.prime_2765551
  have sh_0_11_0 : shrink 30 (Block.mk 2765569 2778888 1667 1669 1693 2765369 2765531 2765551)=some row_202 := shrink_hit _ _ ck_0_11_0
  have c0_0_11 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 21 2765382=some row_202 :=
    choose0_hit 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 20 2765382 2765369 row_202 (SearchFacts.query_2058 LCMSourcePV.PrimeFacts.prime_2765369) (by decide) sh_0_11_0
  have c0_0_10 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 22 2765386=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 21 2765386 2765383 (some row_202) (SearchFacts.query_2059 LCMSourcePV.PrimeFacts.prime_2765383) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 23 2765418=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 22 2765418 2765387 (some row_202) (SearchFacts.query_2060 LCMSourcePV.PrimeFacts.prime_2765387) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 24 2765428=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 23 2765428 2765419 (some row_202) (SearchFacts.query_2061 LCMSourcePV.PrimeFacts.prime_2765419) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 25 2765436=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 24 2765436 2765429 (some row_202) (SearchFacts.query_2062 LCMSourcePV.PrimeFacts.prime_2765429) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 26 2765452=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 25 2765452 2765437 (some row_202) (SearchFacts.query_2063 LCMSourcePV.PrimeFacts.prime_2765437) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 27 2765460=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 26 2765460 2765453 (some row_202) (SearchFacts.query_2064 LCMSourcePV.PrimeFacts.prime_2765453) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 28 2765470=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 27 2765470 2765461 (some row_202) (SearchFacts.query_2065 LCMSourcePV.PrimeFacts.prime_2765461) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 29 2765472=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 28 2765472 2765471 (some row_202) (SearchFacts.query_2066 LCMSourcePV.PrimeFacts.prime_2765471) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 30 2765512=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 29 2765512 2765473 (some row_202) (SearchFacts.query_2067 LCMSourcePV.PrimeFacts.prime_2765473) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 31 2765518=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 30 2765518 2765513 (some row_202) (SearchFacts.query_2068 LCMSourcePV.PrimeFacts.prime_2765513) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 32 2765530=(some row_202) :=
    choose0_skip 1000 30 2765569 10712529 1667 1669 1693 2765531 2765551 31 2765530 2765519 (some row_202) (SearchFacts.query_2069 LCMSourcePV.PrimeFacts.prime_2765519) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 2765569 10712529 1667 1669 1693 2765551 16 2765550=some row_202 :=
    choose1_hit 1000 30 32 2765569 10712529 1667 1669 1693 2765551 15 2765550 2765531 row_202 (SearchFacts.query_2070 LCMSourcePV.PrimeFacts.prime_2765531) c0_0_0
  have hsqrt : Nat.sqrt 2765569=1663 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 2765569+1)=some 1667 := by
    rw [hsqrt];exact (SearchFacts.query_4323 LCMSourcePV.PrimeFacts.prime_1667)
  exact make_hit 1000 30 32 16 2765569 10712529 1667 1669 1693 2765551 row_202 h0 (SearchFacts.query_4324 LCMSourcePV.PrimeFacts.prime_1669) (SearchFacts.query_4325 LCMSourcePV.PrimeFacts.prime_1693) (SearchFacts.query_2071 LCMSourcePV.PrimeFacts.prime_2765551) c1_0
#print axioms make_202
end LCMSourcePV.Witness.BlockProofs
