/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_242 : Block := (Block.mk 3972049 3988008 1997 1999 2003 3971651 3972029 3972037)
theorem make_242 : make 1000 30 32 16 3972049 10712529=some row_242 := by
  have ck_0_25_0 : (Block.mk 3972049 3988008 1997 1999 2003 3971651 3972029 3972037).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1997 LCMSourcePV.PrimeFacts.prime_1999 LCMSourcePV.PrimeFacts.prime_2003 LCMSourcePV.PrimeFacts.prime_3971651 LCMSourcePV.PrimeFacts.prime_3972029 LCMSourcePV.PrimeFacts.prime_3972037
  have sh_0_25_0 : shrink 30 (Block.mk 3972049 3988008 1997 1999 2003 3971651 3972029 3972037)=some row_242 := shrink_hit _ _ ck_0_25_0
  have c0_0_25 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 7 3971676=some row_242 :=
    choose0_hit 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 6 3971676 3971651 row_242 (SearchFacts.query_2451 LCMSourcePV.PrimeFacts.prime_3971651) (by decide) sh_0_25_0
  have c0_0_24 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 8 3971686=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 7 3971686 3971677 (some row_242) (SearchFacts.query_2452 LCMSourcePV.PrimeFacts.prime_3971677) (by decide) c0_0_25
  have c0_0_23 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 9 3971712=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 8 3971712 3971687 (some row_242) (SearchFacts.query_2453 LCMSourcePV.PrimeFacts.prime_3971687) (by decide) c0_0_24
  have c0_0_22 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 10 3971718=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 9 3971718 3971713 (some row_242) (SearchFacts.query_2454 LCMSourcePV.PrimeFacts.prime_3971713) (by decide) c0_0_23
  have c0_0_21 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 11 3971730=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 10 3971730 3971719 (some row_242) (SearchFacts.query_2455 LCMSourcePV.PrimeFacts.prime_3971719) (by decide) c0_0_22
  have c0_0_20 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 12 3971742=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 11 3971742 3971731 (some row_242) (SearchFacts.query_2456 LCMSourcePV.PrimeFacts.prime_3971731) (by decide) c0_0_21
  have c0_0_19 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 13 3971748=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 12 3971748 3971743 (some row_242) (SearchFacts.query_2457 LCMSourcePV.PrimeFacts.prime_3971743) (by decide) c0_0_20
  have c0_0_18 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 14 3971790=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 13 3971790 3971749 (some row_242) (SearchFacts.query_2458 LCMSourcePV.PrimeFacts.prime_3971749) (by decide) c0_0_19
  have c0_0_17 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 15 3971796=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 14 3971796 3971791 (some row_242) (SearchFacts.query_2459 LCMSourcePV.PrimeFacts.prime_3971791) (by decide) c0_0_18
  have c0_0_16 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 16 3971808=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 15 3971808 3971797 (some row_242) (SearchFacts.query_2460 LCMSourcePV.PrimeFacts.prime_3971797) (by decide) c0_0_17
  have c0_0_15 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 17 3971832=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 16 3971832 3971809 (some row_242) (SearchFacts.query_2461 LCMSourcePV.PrimeFacts.prime_3971809) (by decide) c0_0_16
  have c0_0_14 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 18 3971842=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 17 3971842 3971833 (some row_242) (SearchFacts.query_2462 LCMSourcePV.PrimeFacts.prime_3971833) (by decide) c0_0_15
  have c0_0_13 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 19 3971860=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 18 3971860 3971843 (some row_242) (SearchFacts.query_2463 LCMSourcePV.PrimeFacts.prime_3971843) (by decide) c0_0_14
  have c0_0_12 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 20 3971878=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 19 3971878 3971861 (some row_242) (SearchFacts.query_2464 LCMSourcePV.PrimeFacts.prime_3971861) (by decide) c0_0_13
  have c0_0_11 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 21 3971880=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 20 3971880 3971879 (some row_242) (SearchFacts.query_2465 LCMSourcePV.PrimeFacts.prime_3971879) (by decide) c0_0_12
  have c0_0_10 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 22 3971886=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 21 3971886 3971881 (some row_242) (SearchFacts.query_2466 LCMSourcePV.PrimeFacts.prime_3971881) (by decide) c0_0_11
  have c0_0_9 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 23 3971898=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 22 3971898 3971887 (some row_242) (SearchFacts.query_2467 LCMSourcePV.PrimeFacts.prime_3971887) (by decide) c0_0_10
  have c0_0_8 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 24 3971910=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 23 3971910 3971899 (some row_242) (SearchFacts.query_2468 LCMSourcePV.PrimeFacts.prime_3971899) (by decide) c0_0_9
  have c0_0_7 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 25 3971916=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 24 3971916 3971911 (some row_242) (SearchFacts.query_2469 LCMSourcePV.PrimeFacts.prime_3971911) (by decide) c0_0_8
  have c0_0_6 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 26 3971962=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 25 3971962 3971917 (some row_242) (SearchFacts.query_2470 LCMSourcePV.PrimeFacts.prime_3971917) (by decide) c0_0_7
  have c0_0_5 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 27 3971976=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 26 3971976 3971963 (some row_242) (SearchFacts.query_2471 LCMSourcePV.PrimeFacts.prime_3971963) (by decide) c0_0_6
  have c0_0_4 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 28 3971982=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 27 3971982 3971977 (some row_242) (SearchFacts.query_2472 LCMSourcePV.PrimeFacts.prime_3971977) (by decide) c0_0_5
  have c0_0_3 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 29 3971992=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 28 3971992 3971983 (some row_242) (SearchFacts.query_2473 LCMSourcePV.PrimeFacts.prime_3971983) (by decide) c0_0_4
  have c0_0_2 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 30 3972010=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 29 3972010 3971993 (some row_242) (SearchFacts.query_2474 LCMSourcePV.PrimeFacts.prime_3971993) (by decide) c0_0_3
  have c0_0_1 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 31 3972018=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 30 3972018 3972011 (some row_242) (SearchFacts.query_2475 LCMSourcePV.PrimeFacts.prime_3972011) (by decide) c0_0_2
  have c0_0_0 : choose0 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 32 3972028=(some row_242) :=
    choose0_skip 1000 30 3972049 10712529 1997 1999 2003 3972029 3972037 31 3972028 3972019 (some row_242) (SearchFacts.query_2476 LCMSourcePV.PrimeFacts.prime_3972019) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3972049 10712529 1997 1999 2003 3972037 16 3972036=some row_242 :=
    choose1_hit 1000 30 32 3972049 10712529 1997 1999 2003 3972037 15 3972036 3972029 row_242 (SearchFacts.query_2477 LCMSourcePV.PrimeFacts.prime_3972029) c0_0_0
  have hsqrt : Nat.sqrt 3972049=1993 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3972049+1)=some 1997 := by
    rw [hsqrt];exact (SearchFacts.query_4363 LCMSourcePV.PrimeFacts.prime_1997)
  exact make_hit 1000 30 32 16 3972049 10712529 1997 1999 2003 3972037 row_242 h0 (SearchFacts.query_4364 LCMSourcePV.PrimeFacts.prime_1999) (SearchFacts.query_4365 LCMSourcePV.PrimeFacts.prime_2003) (SearchFacts.query_2478 LCMSourcePV.PrimeFacts.prime_3972037) c1_0
#print axioms make_242
end LCMSourcePV.Witness.BlockProofs
