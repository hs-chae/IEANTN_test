/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_229 : Block := (Block.mk 3523129 3530640 1879 1889 1901 3523081 3523109 3523111)
theorem make_229 : make 1000 30 32 16 3523129 10712529=some row_229 := by
  have ck_0_1_0 : (Block.mk 3523129 3530640 1879 1889 1901 3523081 3523109 3523111).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1879 LCMSourcePV.PrimeFacts.prime_1889 LCMSourcePV.PrimeFacts.prime_1901 LCMSourcePV.PrimeFacts.prime_3523081 LCMSourcePV.PrimeFacts.prime_3523109 LCMSourcePV.PrimeFacts.prime_3523111
  have sh_0_1_0 : shrink 30 (Block.mk 3523129 3530640 1879 1889 1901 3523081 3523109 3523111)=some row_229 := shrink_hit _ _ ck_0_1_0
  have c0_0_1 : choose0 1000 30 3523129 10712529 1879 1889 1901 3523109 3523111 31 3523086=some row_229 :=
    choose0_hit 1000 30 3523129 10712529 1879 1889 1901 3523109 3523111 30 3523086 3523081 row_229 (SearchFacts.query_2352 LCMSourcePV.PrimeFacts.prime_3523081) (by decide) sh_0_1_0
  have c0_0_0 : choose0 1000 30 3523129 10712529 1879 1889 1901 3523109 3523111 32 3523108=(some row_229) :=
    choose0_skip 1000 30 3523129 10712529 1879 1889 1901 3523109 3523111 31 3523108 3523087 (some row_229) (SearchFacts.query_2353 LCMSourcePV.PrimeFacts.prime_3523087) (by decide) c0_0_1
  have c1_0 : choose1 1000 30 32 3523129 10712529 1879 1889 1901 3523111 16 3523110=some row_229 :=
    choose1_hit 1000 30 32 3523129 10712529 1879 1889 1901 3523111 15 3523110 3523109 row_229 (SearchFacts.query_2354 LCMSourcePV.PrimeFacts.prime_3523109) c0_0_0
  have hsqrt : Nat.sqrt 3523129=1877 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 3523129+1)=some 1879 := by
    rw [hsqrt];exact (SearchFacts.query_4350 LCMSourcePV.PrimeFacts.prime_1879)
  exact make_hit 1000 30 32 16 3523129 10712529 1879 1889 1901 3523111 row_229 h0 (SearchFacts.query_4351 LCMSourcePV.PrimeFacts.prime_1889) (SearchFacts.query_4352 LCMSourcePV.PrimeFacts.prime_1901) (SearchFacts.query_2355 LCMSourcePV.PrimeFacts.prime_3523111) c1_0
#print axioms make_229
end LCMSourcePV.Witness.BlockProofs
