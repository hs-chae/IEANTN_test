/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_112 : Block := (Block.mk 1038361 1042440 1021 1031 1033 1038319 1038329 1038337)
theorem make_112 : make 1000 30 32 16 1038361 10712529=some row_112 := by
  have ck_0_0_0 : (Block.mk 1038361 1042440 1021 1031 1033 1038319 1038329 1038337).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_1021 LCMSourcePV.PrimeFacts.prime_1031 LCMSourcePV.PrimeFacts.prime_1033 LCMSourcePV.PrimeFacts.prime_1038319 LCMSourcePV.PrimeFacts.prime_1038329 LCMSourcePV.PrimeFacts.prime_1038337
  have sh_0_0_0 : shrink 30 (Block.mk 1038361 1042440 1021 1031 1033 1038319 1038329 1038337)=some row_112 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 1038361 10712529 1021 1031 1033 1038329 1038337 32 1038328=some row_112 :=
    choose0_hit 1000 30 1038361 10712529 1021 1031 1033 1038329 1038337 31 1038328 1038319 row_112 (SearchFacts.query_1162 LCMSourcePV.PrimeFacts.prime_1038319) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 1038361 10712529 1021 1031 1033 1038337 16 1038336=some row_112 :=
    choose1_hit 1000 30 32 1038361 10712529 1021 1031 1033 1038337 15 1038336 1038329 row_112 (SearchFacts.query_1163 LCMSourcePV.PrimeFacts.prime_1038329) c0_0_0
  have hsqrt : Nat.sqrt 1038361=1019 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 1038361+1)=some 1021 := by
    rw [hsqrt];exact (SearchFacts.query_4233 LCMSourcePV.PrimeFacts.prime_1021)
  exact make_hit 1000 30 32 16 1038361 10712529 1021 1031 1033 1038337 row_112 h0 (SearchFacts.query_4234 LCMSourcePV.PrimeFacts.prime_1031) (SearchFacts.query_4235 LCMSourcePV.PrimeFacts.prime_1033) (SearchFacts.query_1164 LCMSourcePV.PrimeFacts.prime_1038337) c1_0
#print axioms make_112
end LCMSourcePV.Witness.BlockProofs
