/- Copyright (c) 2026 IEANTN contributors. Apache 2.0. Authors: OpenAI (Codex). -/
import TraceRules
import SearchFacts.All
import LCMSourcePV.PrimeFacts.All
namespace LCMSourcePV.Witness.BlockProofs
open E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def row_102 : Block := (Block.mk 896809 908208 953 967 971 896771 896783 896803)
theorem make_102 : make 1000 30 32 16 896809 10712529=some row_102 := by
  have ck_0_0_0 : (Block.mk 896809 908208 953 967 971 896771 896783 896803).exactCheck=true := check_true _ (by decide) LCMSourcePV.PrimeFacts.prime_953 LCMSourcePV.PrimeFacts.prime_967 LCMSourcePV.PrimeFacts.prime_971 LCMSourcePV.PrimeFacts.prime_896771 LCMSourcePV.PrimeFacts.prime_896783 LCMSourcePV.PrimeFacts.prime_896803
  have sh_0_0_0 : shrink 30 (Block.mk 896809 908208 953 967 971 896771 896783 896803)=some row_102 := shrink_hit _ _ ck_0_0_0
  have c0_0_0 : choose0 1000 30 896809 10712529 953 967 971 896783 896803 32 896782=some row_102 :=
    choose0_hit 1000 30 896809 10712529 953 967 971 896783 896803 31 896782 896771 row_102 (SearchFacts.query_1063 LCMSourcePV.PrimeFacts.prime_896771) (by decide) sh_0_0_0
  have c1_0 : choose1 1000 30 32 896809 10712529 953 967 971 896803 16 896802=some row_102 :=
    choose1_hit 1000 30 32 896809 10712529 953 967 971 896803 15 896802 896783 row_102 (SearchFacts.query_1064 LCMSourcePV.PrimeFacts.prime_896783) c0_0_0
  have hsqrt : Nat.sqrt 896809=947 := (Nat.eq_sqrt.mpr ⟨by decide,by decide⟩).symm
  have h0 : nextPrime 1000 (Nat.sqrt 896809+1)=some 953 := by
    rw [hsqrt];exact (SearchFacts.query_4223 LCMSourcePV.PrimeFacts.prime_953)
  exact make_hit 1000 30 32 16 896809 10712529 953 967 971 896803 row_102 h0 (SearchFacts.query_4224 LCMSourcePV.PrimeFacts.prime_967) (SearchFacts.query_4225 LCMSourcePV.PrimeFacts.prime_971) (SearchFacts.query_1065 LCMSourcePV.PrimeFacts.prime_896803) c1_0
#print axioms make_102
end LCMSourcePV.Witness.BlockProofs
