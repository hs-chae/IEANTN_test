/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import Mathlib

namespace LCMSourcePV.Witness.C

def sqrtWord : ℕ := 2^64
def sqrtMid (lo hi : ℕ) : ℕ := (lo+(hi-lo)/2+1)%sqrtWord

/-- The source loop, with unsigned assignments and its actual integer division guard. -/
inductive SqrtLoop (n : ℕ) : ℕ → ℕ → ℕ → Prop
  | done {lo hi} (h : ¬lo<hi) : SqrtLoop n lo hi lo
  | up {lo hi out} (h : lo<hi) (guard : sqrtMid lo hi ≤ n/sqrtMid lo hi)
      (rest : SqrtLoop n (sqrtMid lo hi) hi out) : SqrtLoop n lo hi out
  | down {lo hi out} (h : lo<hi) (guard : ¬sqrtMid lo hi ≤ n/sqrtMid lo hi)
      (rest : SqrtLoop n lo ((sqrtMid lo hi-1)%sqrtWord) out) : SqrtLoop n lo hi out

def SqrtExec (n out : ℕ) : Prop := n<sqrtWord ∧ SqrtLoop n 0 n out

def SqrtInvariant (n lo hi : ℕ) : Prop :=
  lo≤Nat.sqrt n ∧ Nat.sqrt n≤hi ∧ hi≤n

theorem sqrt_mid_bounds {n lo hi : ℕ} (hn : n<sqrtWord)
    (hinv : SqrtInvariant n lo hi) (hlt : lo<hi) :
    sqrtMid lo hi = lo+(hi-lo)/2+1 ∧ lo<sqrtMid lo hi ∧
      sqrtMid lo hi≤hi ∧ 0<sqrtMid lo hi ∧ sqrtMid lo hi<sqrtWord := by
  have hh : lo≤hi := hinv.1.trans hinv.2.1
  have hp : 0<hi-lo := Nat.sub_pos_of_lt hlt
  have hdiv : (hi-lo)/2<hi-lo := Nat.div_lt_self hp (by decide)
  have hm : lo+(hi-lo)/2+1≤hi := by omega
  have hw : lo+(hi-lo)/2+1<sqrtWord := hm.trans_lt (hinv.2.2.trans_lt hn)
  have he : sqrtMid lo hi=lo+(hi-lo)/2+1 := by
    exact Nat.mod_eq_of_lt hw
  rw [he]
  exact ⟨rfl,by omega,hm,by omega,hw⟩

theorem sqrt_guard {n m : ℕ} (hmid : 0 < m) :
    (m≤n/m ↔ m≤Nat.sqrt n) := by
  rw [Nat.le_div_iff_mul_le hmid, Nat.le_sqrt]

/-- Every arithmetic intermediate in the supported source loop is in range. -/
theorem sqrt_source_safety {n lo hi : ℕ} (hn : n<sqrtWord)
    (hinv : SqrtInvariant n lo hi) (hlt : lo<hi) :
    lo≤hi ∧ hi<sqrtWord ∧ hi-lo<sqrtWord ∧
      lo+(hi-lo)/2<sqrtWord ∧ lo+(hi-lo)/2+1<sqrtWord ∧
      0<sqrtMid lo hi ∧ sqrtMid lo hi-1<sqrtWord := by
  have hb := sqrt_mid_bounds hn hinv hlt
  have hhiN : hi≤n := hinv.2.2
  have hlohi : lo≤hi := hinv.1.trans hinv.2.1
  exact ⟨hlohi,by omega,by omega,by omega,by omega,hb.2.2.2.1,by omega⟩

/-- Literal unsigned operations in `(lo + ((hi-lo)/2)) + 1`. -/
def sqrtUnsignedMid (lo hi : ℕ) : ℕ :=
  (((lo+((hi+sqrtWord-lo)%sqrtWord)/2)%sqrtWord)+1)%sqrtWord

theorem sqrt_mid_source_operations {n lo hi : ℕ} (hn : n<sqrtWord)
    (hinv : SqrtInvariant n lo hi) (hlt : lo<hi) :
    sqrtUnsignedMid lo hi=sqrtMid lo hi := by
  have hs := sqrt_source_safety hn hinv hlt
  have he : hi+sqrtWord-lo=(hi-lo)+sqrtWord := by omega
  have hsub : (hi+sqrtWord-lo)%sqrtWord=hi-lo := by
    simp only [he,Nat.add_mod,Nat.mod_self,Nat.add_zero,Nat.mod_eq_of_lt hs.2.2.1]
  dsimp only [sqrtUnsignedMid,sqrtMid]
  rw [hsub,Nat.mod_eq_of_lt hs.2.2.2.1]

theorem sqrt_decrement_source_operations {n lo hi : ℕ} (hn : n<sqrtWord)
    (hinv : SqrtInvariant n lo hi) (hlt : lo<hi) :
    (sqrtMid lo hi+sqrtWord-1)%sqrtWord=(sqrtMid lo hi-1)%sqrtWord := by
  have hs := sqrt_source_safety hn hinv hlt
  have he : sqrtMid lo hi+sqrtWord-1=(sqrtMid lo hi-1)+sqrtWord := by omega
  simp only [he,Nat.add_mod,Nat.mod_self,Nat.add_zero,Nat.mod_mod]

theorem sqrt_loop_exists {n : ℕ} (hn : n<sqrtWord) :
    ∀ fuel lo hi, hi-lo=fuel → SqrtInvariant n lo hi → SqrtLoop n lo hi (Nat.sqrt n) := by
  intro fuel
  induction fuel using Nat.strong_induction_on with
  | h fuel ih =>
    intro lo hi heq hinv
    have hhiN : hi≤n := hinv.2.2
    by_cases hlt : lo<hi
    · have hb := sqrt_mid_bounds hn hinv hlt
      by_cases hg : sqrtMid lo hi≤n/sqrtMid lo hi
      · apply SqrtLoop.up hlt hg
        apply ih (hi-sqrtMid lo hi) (by omega) (sqrtMid lo hi) hi rfl
        exact ⟨(sqrt_guard hb.2.2.2.1).mp hg,hinv.2⟩
      · apply SqrtLoop.down hlt hg
        have hmhi : sqrtMid lo hi-1<sqrtWord := by omega
        rw [Nat.mod_eq_of_lt hmhi]
        apply ih (sqrtMid lo hi-1-lo) (by omega) lo (sqrtMid lo hi-1) rfl
        have hroot : Nat.sqrt n<sqrtMid lo hi := by
          exact Nat.lt_of_not_ge (fun h => hg ((sqrt_guard hb.2.2.2.1).mpr h))
        exact ⟨hinv.1,by omega,by omega⟩
    · have he : lo=Nat.sqrt n := by rcases hinv with ⟨hl,hh,hn⟩; omega
      simpa only [he] using (SqrtLoop.done (n:=n) hlt)

theorem SqrtLoop.sound {n lo hi out : ℕ} (run : SqrtLoop n lo hi out)
    (hn : n<sqrtWord) (hinv : SqrtInvariant n lo hi) : out=Nat.sqrt n := by
  induction run with
  | done h => rcases hinv with ⟨hl,hh,hn⟩; omega
  | @up lo hi out h hg rest ih =>
    have hb := sqrt_mid_bounds hn hinv h
    exact ih ⟨(sqrt_guard hb.2.2.2.1).mp hg,hinv.2⟩
  | @down lo hi out h hg rest ih =>
    have hb := sqrt_mid_bounds hn hinv h
    have hhiN : hi≤n := hinv.2.2
    have hroot : Nat.sqrt n<sqrtMid lo hi := by
      exact Nat.lt_of_not_ge (fun h => hg ((sqrt_guard hb.2.2.2.1).mpr h))
    apply ih
    have hmhi : sqrtMid lo hi-1<sqrtWord := by omega
    rw [Nat.mod_eq_of_lt hmhi]
    exact ⟨hinv.1,by omega,by omega⟩

theorem sqrt_exec_exact64 {n : ℕ} (hn : n<sqrtWord) : SqrtExec n (Nat.sqrt n) := by
  refine ⟨hn,sqrt_loop_exists hn (n-0) 0 n rfl ?_⟩
  exact ⟨Nat.zero_le _,Nat.sqrt_le_self n,le_rfl⟩

theorem sqrt_exec_exact {n : ℕ} (hn : n<2^24) : SqrtExec n (Nat.sqrt n) := by
  apply sqrt_exec_exact64
  dsimp [sqrtWord]
  omega

theorem sqrt_exec_sound {n out : ℕ} (run : SqrtExec n out) : out=Nat.sqrt n := by
  exact run.2.sound run.1 ⟨Nat.zero_le _,Nat.sqrt_le_self n,le_rfl⟩

#print axioms sqrt_exec_exact
#print axioms sqrt_exec_sound

end LCMSourcePV.Witness.C
