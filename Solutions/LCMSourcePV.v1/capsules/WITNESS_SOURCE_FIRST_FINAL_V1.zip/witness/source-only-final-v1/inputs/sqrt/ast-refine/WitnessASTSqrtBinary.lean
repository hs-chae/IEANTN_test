/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTSqrtFrame
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024

theorem sqrt_eval_add_at (call : Call) (fuel : Nat) (s : State) (lhs rhs : Expr)
    (a b value : Value)
    (ha : evalExpr call fuel s lhs=some (a,s))
    (hb : evalExpr call fuel s rhs=some (b,s))
    (hv : binaryValue "+" a b=some value) :
    evalExpr call (fuel+1) s (.binary "+" lhs rhs)=some (value,s) := by
  change ((evalExpr call fuel s lhs).bind (fun (v,next)=>
    (evalExpr call fuel next rhs).bind (fun (r,last)=>
      (binaryValue "+" v r).bind (fun value=>some (value,last)))))=_
  rw [ha]
  simp only [Option.bind_some]
  rw [hb]
  simp only [Option.bind_some]
  rw [hv]
  rfl

theorem sqrt_eval_sub_at (call : Call) (fuel : Nat) (s : State) (lhs rhs : Expr)
    (a b value : Value)
    (ha : evalExpr call fuel s lhs=some (a,s))
    (hb : evalExpr call fuel s rhs=some (b,s))
    (hv : binaryValue "-" a b=some value) :
    evalExpr call (fuel+1) s (.binary "-" lhs rhs)=some (value,s) := by
  change ((evalExpr call fuel s lhs).bind (fun (v,next)=>
    (evalExpr call fuel next rhs).bind (fun (r,last)=>
      (binaryValue "-" v r).bind (fun value=>some (value,last)))))=_
  rw [ha]
  simp only [Option.bind_some]
  rw [hb]
  simp only [Option.bind_some]
  rw [hv]
  rfl

theorem sqrt_eval_div_at (call : Call) (fuel : Nat) (s : State) (lhs rhs : Expr)
    (a b value : Value)
    (ha : evalExpr call fuel s lhs=some (a,s))
    (hb : evalExpr call fuel s rhs=some (b,s))
    (hv : binaryValue "/" a b=some value) :
    evalExpr call (fuel+1) s (.binary "/" lhs rhs)=some (value,s) := by
  change ((evalExpr call fuel s lhs).bind (fun (v,next)=>
    (evalExpr call fuel next rhs).bind (fun (r,last)=>
      (binaryValue "/" v r).bind (fun value=>some (value,last)))))=_
  rw [ha]
  simp only [Option.bind_some]
  rw [hb]
  simp only [Option.bind_some]
  rw [hv]
  rfl

theorem sqrt_eval_lt_at (call : Call) (fuel : Nat) (s : State) (lhs rhs : Expr)
    (a b value : Value)
    (ha : evalExpr call fuel s lhs=some (a,s))
    (hb : evalExpr call fuel s rhs=some (b,s))
    (hv : binaryValue "<" a b=some value) :
    evalExpr call (fuel+1) s (.binary "<" lhs rhs)=some (value,s) := by
  change ((evalExpr call fuel s lhs).bind (fun (v,next)=>
    (evalExpr call fuel next rhs).bind (fun (r,last)=>
      (binaryValue "<" v r).bind (fun value=>some (value,last)))))=_
  rw [ha]
  simp only [Option.bind_some]
  rw [hb]
  simp only [Option.bind_some]
  rw [hv]
  rfl

theorem sqrt_eval_le_at (call : Call) (fuel : Nat) (s : State) (lhs rhs : Expr)
    (a b value : Value)
    (ha : evalExpr call fuel s lhs=some (a,s))
    (hb : evalExpr call fuel s rhs=some (b,s))
    (hv : binaryValue "<=" a b=some value) :
    evalExpr call (fuel+1) s (.binary "<=" lhs rhs)=some (value,s) := by
  change ((evalExpr call fuel s lhs).bind (fun (v,next)=>
    (evalExpr call fuel next rhs).bind (fun (r,last)=>
      (binaryValue "<=" v r).bind (fun value=>some (value,last)))))=_
  rw [ha]
  simp only [Option.bind_some]
  rw [hb]
  simp only [Option.bind_some]
  rw [hv]
  rfl

#print axioms sqrt_eval_div_at
end LCMSourcePV.Witness.AST
