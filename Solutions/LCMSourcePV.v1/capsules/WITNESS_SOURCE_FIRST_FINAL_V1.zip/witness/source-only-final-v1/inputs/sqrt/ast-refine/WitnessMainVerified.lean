/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessOutputSound
import WitnessSpecFixedConstructor
namespace LCMSourcePV.Witness.Main
open LCMSourcePV.Witness.C LCMSourcePV.Witness.AST E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 10000

def libraryEvent (st : RunState) : CallEvent :=
  ⟨"run_exact",[outPointer,countPointer],allocated.runtime,word 1 1,(afterRun st []).runtime⟩

theorem library_event_tree (st : RunState) (trace : C.RunFor initialRunState st) :
    ActualCallTree 8 (libraryEvent st) := by
  apply body_call_tree_adequacy specService spec_source_coherent 8 (libraryEvent st) (by change 7 < 8;decide)
  change BodyCall (lowerService specService 7) "run_exact" [outPointer,countPointer]
    {runAllocated with env:=mainEnv} (word 1 1) {runCaller st with env:=mainEnv}
  exact body_call_reenv (spec_run_ranked_body st trace) mainEnv

noncomputable def singleRunService (st : RunState) : Call := by
  classical
  exact fun name args before=>
    if name="run_exact" ∧ args=[outPointer,countPointer] ∧ before=allocated.runtime then
      some (word 1 1,(afterRun st []).runtime) else none

theorem single_run_returns (st : RunState) :
    singleRunService st "run_exact" [outPointer,countPointer] allocated.runtime=
      some (word 1 1,(afterRun st []).runtime) := by
  classical
  simp [singleRunService]

theorem single_run_supported (st : RunState) (trace : C.RunFor initialRunState st) :
    Supports (singleRunService st) (ActualCallTree 8) := by
  intro event h
  rcases event with ⟨name,args,before,value,after⟩
  unfold Returns singleRunService at h
  split at h
  · rename_i hx
    rcases hx with ⟨rfl,rfl,rfl⟩
    have he:=Prod.mk.inj (Option.some.inj h)
    rcases he with ⟨rfl,rfl⟩
    exact library_event_tree st trace
  · cases h

/-- A source-bound application execution with all callback events backed by
finite actual AST call trees. Output rows are part of this proved execution;
no initial output-memory or callback-success assumption is present. -/
structure CertifiedOutput where
  rows : List (List Nat)
  service : Call
  source : LCMSourcePV.RestrictedC.SourceCorresponds renderMain C.actualMain mainAST
  librarySource : C.AllSourceFilesCorrespond
  supported : Supports service (ActualCallTree 8)
  execution : Run service mainAST empty (.returned (finished rows) (word 32 0))

noncomputable def sourceProgram : CertifiedOutput where
  rows:=C.Closed.prefix_404.map fields
  service:=singleRunService C.Closed.state_404
  source:=main_source_corresponds
  librarySource:=C.all_source_files_checked
  supported:=single_run_supported _ C.Closed.source_run
  execution:=main_execution _ _ _ (single_run_returns _)
    C.Closed.source_run C.Closed.source_output_initialized

/-- The mathematical provider reads the emitted main rows rather than an old
native result or an independently supplied witness table. -/
noncomputable def decodedOutput : List Block := sourceProgram.rows.filterMap blockOfFields

theorem fields_roundtrip (b : Block) : blockOfFields (fields b)=some b := by
  cases b
  rfl

theorem decoded_output_eq : decodedOutput=C.Closed.prefix_404 := by
  simp only [decodedOutput,sourceProgram,List.filterMap_map]
  have he : (fun b:Block=>blockOfFields (fields b))=some := by
    funext b
    exact fields_roundtrip b
  simp only [Function.comp_def]
  rw [he]
  simp

theorem decoded_output_length : decodedOutput.length=404 := by
  rw [decoded_output_eq]
  exact C.Closed.length_404

theorem decoded_output_cover : cover 81000 10712529 decodedOutput=true := by
  rw [decoded_output_eq]
  exact source_output_cover _ _ C.Closed.source_run C.Closed.source_output_initialized

/-- Original exact finite LCM statement, consuming the actual main's decoded
output through the source-check/ordinary mathematical sigma criterion. -/
theorem exactFinite (n : Nat) (hn : 81000 ≤ n ∧ n < 10712529) :
    ∃m:Nat,m < Nat.lcmUpto n ∧
      (1+1/(10*(n:ℝ)))*(ArithmeticFunction.sigma 1 (Nat.lcmUpto n):ℝ) <
        ArithmeticFunction.sigma 1 m :=
  LCMSourcePV.Witness.cover_sound 81000 10712529 decodedOutput decoded_output_cover n hn

#print axioms library_event_tree
#print axioms sourceProgram
#print axioms decoded_output_cover
#print axioms exactFinite
end LCMSourcePV.Witness.Main
