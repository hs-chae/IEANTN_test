/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTSqrtBinary
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024

@[simp] theorem sqrt_var_n (call : Call) (fuel : Nat) (s : State) (n lo hi : Nat) :
 evalExpr call (Nat.succ fuel) (sqrtFrame s n lo hi) (.var "n")=some (word 64 n,sqrtFrame s n lo hi) := (sqrt_frame_var call fuel s n lo hi).1
@[simp] theorem sqrt_var_lo (call : Call) (fuel : Nat) (s : State) (n lo hi : Nat) :
 evalExpr call (Nat.succ fuel) (sqrtFrame s n lo hi) (.var "lo")=some (word 64 lo,sqrtFrame s n lo hi) := (sqrt_frame_var call fuel s n lo hi).2.1
@[simp] theorem sqrt_var_hi (call : Call) (fuel : Nat) (s : State) (n lo hi : Nat) :
 evalExpr call (Nat.succ fuel) (sqrtFrame s n lo hi) (.var "hi")=some (word 64 hi,sqrtFrame s n lo hi) := (sqrt_frame_var call fuel s n lo hi).2.2
@[simp] theorem sqrt_midvar_n (call : Call) (fuel : Nat) (s : State) (n lo hi mid : Nat) :
 evalExpr call (Nat.succ fuel) (sqrtMidFrame s n lo hi mid) (.var "n")=some (word 64 n,sqrtMidFrame s n lo hi mid) := (sqrt_midframe_var call fuel s n lo hi mid).1
@[simp] theorem sqrt_midvar_lo (call : Call) (fuel : Nat) (s : State) (n lo hi mid : Nat) :
 evalExpr call (Nat.succ fuel) (sqrtMidFrame s n lo hi mid) (.var "lo")=some (word 64 lo,sqrtMidFrame s n lo hi mid) := (sqrt_midframe_var call fuel s n lo hi mid).2.1
@[simp] theorem sqrt_midvar_hi (call : Call) (fuel : Nat) (s : State) (n lo hi mid : Nat) :
 evalExpr call (Nat.succ fuel) (sqrtMidFrame s n lo hi mid) (.var "hi")=some (word 64 hi,sqrtMidFrame s n lo hi mid) := (sqrt_midframe_var call fuel s n lo hi mid).2.2.1
@[simp] theorem sqrt_midvar_mid (call : Call) (fuel : Nat) (s : State) (n lo hi mid : Nat) :
 evalExpr call (Nat.succ fuel) (sqrtMidFrame s n lo hi mid) (.var "mid")=some (word 64 mid,sqrtMidFrame s n lo hi mid) := (sqrt_midframe_var call fuel s n lo hi mid).2.2.2

def sqrtCond : Expr := .binary "<" (.var "lo") (.var "hi")
def sqrtMidExpr : Expr := .binary "+" (.binary "+" (.var "lo")
  (.binary "/" (.binary "-" (.var "hi") (.var "lo")) (.nat 2))) (.nat 1)
def sqrtMidCond : Expr := .binary "<=" (.var "mid")
  (.binary "/" (.var "n") (.var "mid"))

theorem sqrt_word_add (a b : Nat) :
    binaryValue "+" (word 64 a) (word 64 b)=some (word 64 (a+b)) := by
  change some (Value.word 64 ((a%2^64+b%2^64)%2^64))=some (Value.word 64 ((a+b)%2^64))
  simp only [Nat.add_mod,Nat.mod_mod]

theorem sqrt_test (call : Call) (s : State) (n lo hi : Nat)
    (hlo : lo < 2^64) (hhi : hi < 2^64) :
    Eval call sqrtCond (sqrtFrame s n lo hi) (sqrtFrame s n lo hi)
      (boolean (lo < hi)) := by
  apply sqrt_eval_lt_at call 999
  · exact sqrt_var_lo call 998 s n lo hi
  · exact sqrt_var_hi call 998 s n lo hi
  · change some (boolean (lo%2^64 < hi%2^64))=_
    rw [Nat.mod_eq_of_lt hlo,Nat.mod_eq_of_lt hhi]

theorem sqrt_mid_expr (call : Call) (s : State) (n lo hi : Nat)
    (hn : n < sqrtWord) (hinv : SqrtInvariant n lo hi) (hlt : lo < hi) :
    Eval call sqrtMidExpr (sqrtFrame s n lo hi) (sqrtFrame s n lo hi)
      (word 64 (sqrtMid lo hi)) := by
  have hs:=sqrt_source_safety hn hinv hlt
  have hlo : lo < 2^64 := lt_of_le_of_lt hs.1 hs.2.1
  have hhi : hi < 2^64 := hs.2.1
  let sub:Nat := (hi+2^64-lo)%2^64
  have hsub : sub < 2^64 := Nat.mod_lt _ (by decide)
  have ha : evalExpr call 997 (sqrtFrame s n lo hi)
      (.binary "-" (.var "hi") (.var "lo"))=some (word 64 sub,sqrtFrame s n lo hi) := by
    apply sqrt_eval_sub_at call 996
    · exact sqrt_var_hi call 995 s n lo hi
    · exact sqrt_var_lo call 995 s n lo hi
    · change some (Value.word 64 ((hi%2^64+2^64-lo%2^64)%2^64))=
        some (Value.word 64 (sub%2^64))
      rw [Nat.mod_eq_of_lt hlo,Nat.mod_eq_of_lt hhi,Nat.mod_eq_of_lt hsub]
  have hb : evalExpr call 998 (sqrtFrame s n lo hi)
      (.binary "/" (.binary "-" (.var "hi") (.var "lo")) (.nat 2))=
      some (word 64 (sub/2),sqrtFrame s n lo hi) := by
    apply sqrt_eval_div_at call 997 _ _ _ _ _ _ ha
    · rfl
    · change some (Value.word 64 ((sub%2^64/2)%2^64))=_
      rw [Nat.mod_eq_of_lt hsub]
      rfl
  have hc : evalExpr call 999 (sqrtFrame s n lo hi)
      (.binary "+" (.var "lo")
        (.binary "/" (.binary "-" (.var "hi") (.var "lo")) (.nat 2)))=
      some (word 64 (lo+sub/2),sqrtFrame s n lo hi) := by
    exact sqrt_eval_add_at call 998 _ _ _ _ _ _
      (sqrt_var_lo call 997 s n lo hi) hb (sqrt_word_add _ _)
  have hd : Eval call sqrtMidExpr (sqrtFrame s n lo hi) (sqrtFrame s n lo hi)
      (word 64 (lo+sub/2+1)) := by
    apply sqrt_eval_add_at call 999 _ _ _ _ _ _ hc
    · rfl
    · change some (Value.word 64 (((lo+sub/2)%2^64+1)%2^64))=_
      simp [word,Nat.mod_add_mod]
  have he : word 64 (lo+sub/2+1)=word 64 (sqrtMid lo hi) := by
    have hh:=sqrt_mid_source_operations hn hinv hlt
    apply congrArg (Value.word 64)
    change (((lo+sub/2+1)%2^64))=sqrtMid lo hi%2^64
    have hx : (lo+sub/2+1)%2^64=sqrtUnsignedMid lo hi := by
      dsimp [sqrtUnsignedMid,sub,sqrtWord]
      rw [Nat.mod_add_mod]
    have hm64 : sqrtMid lo hi < 2^64 := (sqrt_mid_bounds hn hinv hlt).2.2.2.2
    rw [hx,hh,Nat.mod_eq_of_lt hm64]
  rw [he] at hd
  exact hd

theorem sqrt_mid_test (call : Call) (s : State) (n lo hi : Nat)
    (hn : n < sqrtWord) (hinv : SqrtInvariant n lo hi) (hlt : lo < hi) :
    Eval call sqrtMidCond (sqrtMidFrame s n lo hi (sqrtMid lo hi))
      (sqrtMidFrame s n lo hi (sqrtMid lo hi))
      (boolean (sqrtMid lo hi ≤ n/sqrtMid lo hi)) := by
  have hb:=sqrt_mid_bounds hn hinv hlt
  have hn64 : n < 2^64 := hn
  have hm64 : sqrtMid lo hi < 2^64 := hb.2.2.2.2
  have hdiv : n/sqrtMid lo hi < 2^64 := (Nat.div_le_self _ _).trans_lt hn
  have hmpos : sqrtMid lo hi ≠ 0 := Nat.ne_of_gt hb.2.2.2.1
  have hd : evalExpr call 999 (sqrtMidFrame s n lo hi (sqrtMid lo hi))
      (.binary "/" (.var "n") (.var "mid"))=
      some (word 64 (n/sqrtMid lo hi),sqrtMidFrame s n lo hi (sqrtMid lo hi)) := by
    apply sqrt_eval_div_at call 998
    · exact sqrt_midvar_n call 997 s n lo hi (sqrtMid lo hi)
    · exact sqrt_midvar_mid call 997 s n lo hi (sqrtMid lo hi)
    · change (if sqrtMid lo hi%2^64==0 then none else
        some (word 64 (n%2^64/(sqrtMid lo hi%2^64))))=_
      rw [Nat.mod_eq_of_lt hn64,Nat.mod_eq_of_lt hm64]
      simp [hmpos]
  apply sqrt_eval_le_at call 999
  · exact sqrt_midvar_mid call 998 s n lo hi (sqrtMid lo hi)
  · exact hd
  · change some (boolean (sqrtMid lo hi%2^64 ≤ (n/sqrtMid lo hi)%2^64))=_
    rw [Nat.mod_eq_of_lt hm64,Nat.mod_eq_of_lt hdiv]

#print axioms sqrt_mid_expr
#print axioms sqrt_mid_test
end LCMSourcePV.Witness.AST
