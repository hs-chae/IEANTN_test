/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessMainPrint
namespace LCMSourcePV.Witness.Main
open LCMSourcePV.Witness.C LCMSourcePV.Witness.AST E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

def BufferRep (st : RunState) : Prop :=
  ∀(i : Nat) (b : Block),st.buffer[i]?=some (some b) → BlockRep b

theorem buffer_rep_initial : BufferRep initialRunState := by
  intro i b h
  simp only [initialRunState,List.getElem?_replicate] at h
  split at h <;> cases h

theorem buffer_rep_store {st next : RunState} {b : Block}
    (h : storeBlock st b=some next) (hb : BlockRep b) (hs : BufferRep st) : BufferRep next := by
  unfold storeBlock at h
  split at h
  · cases h
    intro i b' hread
    simp only [List.getElem?_set] at hread
    split at hread
    · cases hread
      exact hb
    · exact hs i b' hread
  · cases h

theorem buffer_rep_final {st final : RunState} (trace : C.RunFor st final)
    (hs : BufferRep st) : BufferRep final := by
  induction trace with
  | done st hloop hstop=>exact hs
  | step st next final b hloop hstop hm hstore rest ih=>
    exact ih (buffer_rep_store hstore (run_make_rep hm) hs)

theorem initialized_read {st : RunState} {bs : List Block}
    (h : initializedOutput st bs) {i : Nat} (hi : i < bs.length) :
    st.buffer[i]?=some (some bs[i]) := by
  have hc : i < st.count := by rw [h.1];exact hi
  have he:=congrArg (fun xs=>xs[i]?) h.2.2.1
  simpa [hc,hi] using he

theorem print_for_suffix (call : Call) (st : RunState) (bs : List Block)
    (hinit : initializedOutput st bs) (hrep : BufferRep st) :
    ∀remaining i,bs.length-i=remaining → i ≤ bs.length → ∀rows,
    ForRun call (.binary "<" (.var "i") (.var "count")) (.unary "++" (.var "i"))
      mainPrintBody (printLoop st i rows)
      (.continuing (printLoop st bs.length (rows++(bs.drop i).map fields))) := by
  intro remaining
  induction remaining using Nat.strong_induction_on with
  | h remaining ih=>
    intro i he hi rows
    have hc64 : st.count < 2^64 := by have hh:=hinit.2.2.2;omega
    have hi64 : i < 2^64 := by have hh:=hinit.1;omega
    by_cases hil : i < bs.length
    · have hi1 : i+1 < 2^64 := by have hh:=hinit.1;omega
      have hr:=initialized_read hinit hil
      have hb:=hrep i bs[i] hr
      have hbuf : i < st.buffer.length := by
        have hh:=hinit.1;have hl:=hinit.2.1;have hm:=hinit.2.2.2;omega
      apply ForRun.next (c:=printLoop st (i+1) (rows++[fields bs[i]]))
        (value:=word 64 (i+1))
      · exact print_test call st i rows hi64 hc64
      · simp [truth,boolean,word,hinit.1,hil]
      · exact print_iteration call st i rows bs[i] hr hb hi64 hbuf
      · exact print_increment call st i (rows++[fields bs[i]]) hi1
      · have hrest:=ih (bs.length-(i+1)) (by omega) (i+1) rfl (by omega)
          (rows++[fields bs[i]])
        simpa only [List.drop_eq_getElem_cons hil,List.map_cons,List.append_assoc,
          List.singleton_append] using hrest
    · have hei : i=bs.length := by omega
      subst i
      have hdone:=ForRun.done (step:=.unary "++" (.var "i")) (body:=mainPrintBody)
        (print_test call st bs.length rows hi64 hc64)
        (by simp [truth,boolean,word,hinit.1])
      simpa only [List.drop_length,List.map_nil,List.append_nil] using hdone

theorem print_for_all (call : Call) (st : RunState) (bs : List Block)
    (hinit : initializedOutput st bs) (hrep : BufferRep st) :
    ForRun call (.binary "<" (.var "i") (.var "count")) (.unary "++" (.var "i"))
      mainPrintBody (printLoop st 0 [])
      (.continuing (printLoop st st.count (bs.map fields))) := by
  simpa [hinit.1] using print_for_suffix call st bs hinit hrep bs.length 0 (by omega)
    (Nat.zero_le _) []

#print axioms print_for_all
#print axioms buffer_rep_final
end LCMSourcePV.Witness.Main
