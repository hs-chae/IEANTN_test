/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTRunLoop
namespace LCMSourcePV.Witness.AST
open E1TwoTracks.TrackB LCMSourcePV.Witness.C LCMSourcePV.RestrictedC LCMSourcePV.ASTLoops
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

def runAllocated : State :=
  ⟨[⟨"Block",runBuffer initialRunState.buffer⟩,⟨"U",[none]⟩],[]⟩
def runParametersUninitialized : State :=
  ⟨runAllocated.heap++[⟨"Block*",[some outPointer]⟩,⟨"U*",[some countPointer]⟩],
    [("count",⟨3,0,none⟩),("out",⟨2,0,none⟩)]⟩
def runLoUninitialized : State :=
  allocate runParametersUninitialized "U" "lo" (some (word 64 81000))
def runCaller (st : RunState) : State :=
  ⟨[⟨"Block",runBuffer st.buffer⟩,sqrtCell st.count],[]⟩
def runParameters (st : RunState) : State :=
  ⟨(runCaller st).heap++[⟨"Block*",[some outPointer]⟩,⟨"U*",[some countPointer]⟩],
    [("count",⟨3,0,none⟩),("out",⟨2,0,none⟩)]⟩
def runLoFrame (st : RunState) : State :=
  allocate (runParameters st) "U" "lo" (some (word 64 st.lo))

theorem run_bind_actual : bindArgs f_run_exact.parameters [outPointer,countPointer]
    runAllocated=some runParametersUninitialized := by
  simp [bindArgs,f_run_exact,List.foldlM,castValue,outPointer,countPointer,
    runAllocated,runParametersUninitialized,allocate,addressType,runBuffer,initialRunState]

theorem run_declare_lo (call : Call) :
    Declare call [⟨"U","lo",some (.nat 81000)⟩]
      runParametersUninitialized runLoUninitialized := by
  rfl

theorem run_initialize_count (call : Call) :
    Eval call (.binary "=" (.unary "*" (.var "count")) (.nat 0))
      runLoUninitialized (runLoFrame initialRunState) (word 64 0) := by
  change ((evalExpr call 999 runLoUninitialized (.nat 0)).bind
    (fun (v,next)=>(evalLValue call 999 next (.unary "*" (.var "count"))).bind
      (fun (a,writable,last)=>write last a writable v)))=_
  rfl

theorem run_declare_fuel (call : Call) :
    Declare call [⟨"U","fuel",some (.nat 0)⟩]
      (runLoFrame initialRunState) (runFrame initialRunState) := by
  rfl

theorem run_pop_fuel (st final : RunState) :
    popScope (runLoFrame st) (runFrame final)=runLoFrame final := by
  rfl

theorem run_pop_lo (final : RunState) :
    popScope runParametersUninitialized (runLoFrame final)=runParameters final := by
  rfl

theorem run_pop_parameters (final : RunState) :
    popScope runAllocated (runParameters final)=runCaller final := by
  rfl

theorem run_initial_rep : RunRep initialRunState := by
  norm_num [RunRep,initialRunState]

/-- Complete actual run_exact body for the fixed allocated main input. The
array and count cell start uninitialized. Every read follows the source's
own initializer or make/store operation. MakeRunContract is an intermediate
callee obligation, closed separately by actual lower-ranked body proofs. -/
theorem run_exact_body (call : Call) (hm : MakeRunContract call) (final : RunState)
    (trace : RunFor initialRunState final) :
    BodyCall call "run_exact" [outPointer,countPointer]
      runAllocated (word 1 1) (runCaller final) := by
  refine ⟨f_run_exact,runParametersUninitialized,runParameters final,word 1 1,
    ?_,run_bind_actual,?_,?_,(run_pop_parameters final).symm⟩
  · rfl
  · change Run call (.sequence [
      .declare [⟨"U","lo",some (.nat 81000)⟩],
      .eval (.binary "=" (.unary "*" (.var "count")) (.nat 0)),
      .forLoop (.declare [⟨"U","fuel",some (.nat 0)⟩]) (some runLoopCond)
        (.unary "++" (.var "fuel")) runIteration,
      .returnStmt runStopCond]) runParametersUninitialized
      (.returned (runParameters final) (word 1 1))
    apply StmtRun.sequence
    · apply SeqRun.next (StmtRun.declare (run_declare_lo call))
      apply SeqRun.next (StmtRun.evaluate (run_initialize_count call))
      apply SeqRun.returned
      apply StmtRun.forLoop (StmtRun.declare (run_declare_fuel call))
        (run_for_ast call hm trace run_initial_rep)
      exact congrArg (fun s=>Flow.returned s (word 1 1))
        (run_pop_fuel initialRunState final).symm
    · exact congrArg (fun s=>Flow.returned s (word 1 1)) (run_pop_lo final).symm
  · rfl

/-- The main's two allocated caller objects do not assume any output data. -/
theorem run_initial_storage :
    runAllocated.heap=[⟨"Block",List.replicate 1024 none⟩,⟨"U",[none]⟩] ∧
    runAllocated.env=[] := by
  simp [runAllocated,runBuffer,initialRunState]

#print axioms run_exact_body
#print axioms run_initial_storage
end LCMSourcePV.Witness.AST
