/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessMainExecution
import WitnessCControlSound
namespace LCMSourcePV.Witness.Main
open LCMSourcePV.Witness.C LCMSourcePV.Witness.AST E1TwoTracks.TrackB LCMSourcePV.RestrictedC
set_option maxHeartbeats 0
set_option maxRecDepth 10000

theorem initialized_prefix_unique {k lo : Nat} {prior bs : List Block}
    (hp : prior.length ≤ 1024) (h : initializedOutput (prefixState k lo prior) bs) :
    bs=prior := by
  have hold:=prefix_initialized k lo prior hp
  have hm : prior.map some=bs.map some := hold.2.2.1.symm.trans h.2.2.1
  exact ((List.map_inj_right (fun x y h=>Option.some.inj h)).mp hm).symm

/-- Each printed block is one of the actual make/store outputs, in order.
The cover conclusion concerns the exact initialized output prefix rather
than an unrelated existential certificate. -/
theorem run_for_prefix_output {st final : RunState} (trace : C.RunFor st final) :
    ∀k lo prior,st=prefixState k lo prior → prior.length ≤ 1024 → lo < 2^24 →
      ∀bs,initializedOutput final bs →
      ∃suffix,bs=prior++suffix ∧ cover lo 10712529 suffix=true := by
  induction trace with
  | done st hloop hstop=>
    intro k lo prior he hp hlo bs hout
    subst st
    have hb:=initialized_prefix_unique hp hout
    refine ⟨[],by simpa using hb,?_⟩
    simpa [cover,prefixState] using hstop
  | step st next final b hloop hstop hm hstore rest ih=>
    intro k lo prior he hp hlo bs hout
    subst st
    have hlen : (prefixState k lo prior).buffer.length=1024 := by
      simp [prefixState];omega
    have hsmall : prior.length < 1024 := by
      have hx:=hstore
      unfold storeBlock at hx
      rw [hlen] at hx
      split at hx
      · assumption
      · cases hx
    have hk : k+1 < 2^64 := by
      have h : k < 1024 := hloop
      omega
    have hn : next=prefixState (k+1) (uadd b.hi 1) (prior++[b]) :=
      Option.some.inj (hstore.symm.trans (store_prefix k lo prior b hsmall hk))
    have hmath:=make_exec_sound hm hlo (by decide) (by decide)
    have hinc : uadd b.hi 1=b.hi+1 := by
      apply Unsigned.add_exact
      have hh:=hmath.2.1
      norm_num [Unsigned.modulus]
      omega
    have hpnext : (prior++[b]).length ≤ 1024 := by simp;omega
    have hlonext : uadd b.hi 1 < 2^24 := by rw [hinc];have hh:=hmath.2.1;omega
    obtain ⟨suffix,hbs,hcov⟩:=ih (k+1) (uadd b.hi 1) (prior++[b]) hn hpnext hlonext bs hout
    refine ⟨b::suffix,?_,?_⟩
    · simpa only [List.append_assoc,List.singleton_append] using hbs
    · simp only [cover,Bool.and_eq_true,decide_eq_true_eq]
      exact ⟨⟨hmath.1,hmath.2.2⟩,by simpa only [hinc] using hcov⟩

theorem source_output_cover (st : RunState) (bs : List Block)
    (trace : C.RunFor initialRunState st) (hout : initializedOutput st bs) :
    cover 81000 10712529 bs=true := by
  obtain ⟨suffix,he,hcover⟩:=run_for_prefix_output trace 0 81000 [] rfl (by simp) (by decide) bs hout
  simpa using he ▸ hcover

#print axioms source_output_cover
end LCMSourcePV.Witness.Main
