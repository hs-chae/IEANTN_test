/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTChoose0Parameters
namespace LCMSourcePV.Witness.AST
open E1TwoTracks.TrackB LCMSourcePV.Witness.C
set_option maxHeartbeats 0

theorem choose0_call_none_of_body (call : Call) (caller : State)
    (pf ff total lo stop p0 p1 p2 q1 q2 top : Nat) (address : Address)
    (ht : addressType caller address=some "Block")
    (hb : address.object < caller.heap.length)
    (body : ∃finalTop,Run call f_choose_q0.body
      (Choose0.params caller pf ff total lo stop p0 p1 p2 q1 q2 top address)
      (.returned (Choose0.params caller pf ff total lo stop p0 p1 p2 q1 q2 finalTop address)
        (bword false))) :
    BodyCall call "choose_q0"
      [word 64 pf,word 64 ff,word 64 total,word 64 lo,word 64 stop,word 64 p0,
        word 64 p1,word 64 p2,word 64 q1,word 64 q2,word 64 top,.pointer address true]
      caller (bword false) caller := by
  obtain ⟨finalTop,hbody⟩:=body
  refine ⟨f_choose_q0,Choose0.params caller pf ff total lo stop p0 p1 p2 q1 q2 top address,
    Choose0.params caller pf ff total lo stop p0 p1 p2 q1 q2 finalTop address,
    bword false,?_,choose0_bind caller pf ff total lo stop p0 p1 p2 q1 q2 top address
      ht hb,hbody,?_,?_⟩
  · rfl
  · rfl
  · symm
    apply pop_frame_effect caller caller _ _ rfl rfl

#print axioms choose0_call_none_of_body
end LCMSourcePV.Witness.AST
