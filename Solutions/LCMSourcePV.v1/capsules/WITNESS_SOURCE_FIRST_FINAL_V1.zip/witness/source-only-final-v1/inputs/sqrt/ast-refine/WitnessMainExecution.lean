/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessMainLoop
namespace LCMSourcePV.Witness.Main
open LCMSourcePV.Witness.C LCMSourcePV.Witness.AST E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

def arrayStage : MState := allocateArray empty "Block" "out" 1024
def finished (rows : List (List Nat)) : MState := ⟨⟨[],[]⟩,[],rows⟩

theorem allocate_count (call : Call) :
    Run call (.core (.declare [⟨"U","count",none⟩])) arrayStage (.continuing allocated) := by
  have hd : AST.Declare call [⟨"U","count",none⟩] arrayStage.runtime allocated.runtime := by
    simp [AST.Declare,declarations,List.foldlM,allocate,arrayStage,allocateArray,empty,
      allocated,runAllocated,mainEnv,runBuffer,initialRunState]
  have hr : AST.Run call (lowerStmt arrayStage.arrays (.declare [⟨"U","count",none⟩]))
      arrayStage.runtime (.continuing allocated.runtime) := by
    simp only [lowerStmt,lowerDecl,List.map_cons,List.map_nil,Option.map_none]
    exact LCMSourcePV.ASTLoops.StmtRun.declare hd
  exact Run.core hr

theorem run_test (call : Call) (st : RunState)
    (hc : call "run_exact" [outPointer,countPointer] allocated.runtime=
      some (word 1 1,(afterRun st []).runtime)) :
    Main.Eval call (.unary "!" (.call (.var "run_exact")
      [.var "out",.unary "&" (.var "count")])) allocated (afterRun st []) (boolean false) := by
  refine ⟨?_,rfl,rfl⟩
  simp only [allocated,lowerExpr,lowerLValue,List.map_cons,List.map_nil]
  change AST.Eval call (.unary "!" (.call (.var "run_exact")
      [.unary "&" (.var "out"),.unary "&" (.var "count")])) _ _ _
  apply eval_not_call call "run_exact" _ [outPointer,countPointer]
  · apply PureArgs.cons
    · exact eval_address_at call 995 allocated.runtime "out" ⟨0,0,none⟩ (by rfl)
    · apply PureArgs.cons
      · exact eval_address_at call 995 allocated.runtime "count" ⟨1,0,none⟩ (by rfl)
      · exact PureArgs.nil
  · exact hc

theorem print_for_statement (call : Call) (st : RunState) (bs : List Block)
    (hinit : initializedOutput st bs) (hrep : BufferRep st) :
    Run call (.forLoop (.declare [⟨"U","i",some (.nat 0)⟩])
      (.binary "<" (.var "i") (.var "count")) (.unary "++" (.var "i")) mainPrintBody)
      (afterRun st []) (.continuing (afterRun st (bs.map fields))) := by
  have hd : Run call (.core (.declare [⟨"U","i",some (.nat 0)⟩]))
      (afterRun st []) (.continuing (printLoop st 0 [])) := by
    have hc : AST.Run call (lowerStmt (afterRun st []).arrays (.declare [⟨"U","i",some (.nat 0)⟩]))
        (afterRun st []).runtime (.continuing (printLoop st 0 []).runtime) := by
      simp only [lowerStmt,lowerDecl,List.map_cons,List.map_nil,Option.map_some,lowerExpr]
      apply LCMSourcePV.ASTLoops.StmtRun.declare
      rfl
    exact Run.core hc
  have hf:=Run.forLoop hd (print_for_all call st bs hinit hrep)
  exact hf

/-- The complete parsed main is executed. Initial output memory is absent;
array and scalar storage are allocated by its own declaration rules. The
only intermediate premise is its one real run_exact call, separately backed
by the proved actual library call tree in the closed provider. -/
theorem main_execution (call : Call) (st : RunState) (bs : List Block)
    (hc : call "run_exact" [outPointer,countPointer] allocated.runtime=
      some (word 1 1,(afterRun st []).runtime))
    (trace : C.RunFor initialRunState st) (hinit : initializedOutput st bs) :
    Run call mainAST empty (.returned (finished (bs.map fields)) (word 32 0)) := by
  have hrep : BufferRep st := buffer_rep_final trace buffer_rep_initial
  have hseq : SeqRun call [
      .array "Block" "out" 1024,.core (.declare [⟨"U","count",none⟩]),
      .branch (.unary "!" (.call (.var "run_exact") [.var "out",.unary "&" (.var "count")]))
        (.core (.returnStmt (.nat 1))) none,
      .forLoop (.declare [⟨"U","i",some (.nat 0)⟩])
        (.binary "<" (.var "i") (.var "count")) (.unary "++" (.var "i")) mainPrintBody,
      .core (.returnStmt (.nat 0))] empty
      (.returned (afterRun st (bs.map fields)) (word 32 0)) := by
    apply SeqRun.next (Run.array empty "Block" "out" 1024 (by decide))
    apply SeqRun.next (allocate_count call)
    apply SeqRun.next
    · exact Run.branchNo (run_test call st hc) (by rfl)
    · apply SeqRun.next (print_for_statement call st bs hinit hrep)
      apply SeqRun.returned
      have hr : AST.Run call (lowerStmt (afterRun st (bs.map fields)).arrays (.returnStmt (.nat 0)))
          (afterRun st (bs.map fields)).runtime
          (.returned (afterRun st (bs.map fields)).runtime (word 32 0)) := by
        simp only [lowerStmt,lowerExpr]
        apply LCMSourcePV.ASTLoops.StmtRun.returnValue
        rfl
      exact Run.core hr
  have h:=Run.sequence hseq
  exact h

#print axioms main_execution
end LCMSourcePV.Witness.Main
