/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTSqrtStep
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.ASTLoops
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024

def sqrtParam (s : State) (n : Nat) : State :=
  ⟨s.heap++[sqrtCell n],[("n",⟨s.heap.length,0,none⟩)]⟩

theorem sqrt_while_of_trace (call : Call) (s : State) {n lo hi out : Nat}
    (hn : n < sqrtWord) (run : SqrtLoop n lo hi out)
    (hinv : SqrtInvariant n lo hi) :
    WhileRun call sqrtCond sqrtIteration (sqrtFrame s n lo hi)
      (.continuing (sqrtFrame s n out out)) := by
  revert hinv
  induction run with
  | @done lo hi h =>
    intro hinv
    have hle : lo ≤ hi := hinv.1.trans hinv.2.1
    have hh : hi=lo := by omega
    subst hi
    apply WhileRun.done (sqrt_test call s n lo lo
      (hinv.2.2.trans_lt hn) (hinv.2.2.trans_lt hn))
    simp [truth,boolean,word]
  | @up lo hi out h hg rest ih =>
    intro hinv
    have hb:=sqrt_mid_bounds hn hinv h
    apply WhileRun.next (sqrt_test call s n lo hi
      ((hinv.1.trans hinv.2.1).trans_lt (hinv.2.2.trans_lt hn))
      (hinv.2.2.trans_lt hn))
    · simp [truth,boolean,word,h]
    · exact sqrt_iteration_up call s n lo hi hn hinv h hg
    · exact ih ⟨(sqrt_guard hb.2.2.2.1).mp hg,hinv.2⟩
  | @down lo hi out h hg rest ih =>
    intro hinv
    have hb:=sqrt_mid_bounds hn hinv h
    apply WhileRun.next (sqrt_test call s n lo hi
      ((hinv.1.trans hinv.2.1).trans_lt (hinv.2.2.trans_lt hn))
      (hinv.2.2.trans_lt hn))
    · simp [truth,boolean,word,h]
    · exact sqrt_iteration_down call s n lo hi hn hinv h hg
    · apply ih
      have hm : sqrtMid lo hi-1 < sqrtWord := (sqrt_source_safety hn hinv h).2.2.2.2.2.2
      have hr : Nat.sqrt n < sqrtMid lo hi :=
        Nat.lt_of_not_ge (fun hroot=>hg ((sqrt_guard hb.2.2.2.1).mpr hroot))
      rw [SqrtInvariant,Nat.mod_eq_of_lt hm]
      exact ⟨hinv.1,by omega,by have hh:=hinv.2.2;omega⟩

theorem sqrt_bind (s : State) (n : Nat) :
    bindArgs f_integer_sqrt.parameters [word 64 n] s=some (sqrtParam s n) := by
  simp [bindArgs,f_integer_sqrt,List.foldlM,castValue,asNat,word,allocate,
    sqrtParam,sqrtCell]

theorem sqrt_declare_initial (call : Call) (s : State) (n : Nat) :
    Declare call [⟨"U","lo",some (.nat 0)⟩,⟨"U","hi",some (.var "n")⟩]
      (sqrtParam s n) (sqrtFrame s n 0 n) := by
  simp (disch:=omega) [Declare,declarations,List.foldlM,evalExpr,getVar,read,
    castValue,asNat,word,allocate,sqrtParam,sqrtFrame,sqrtCell,
    List.find?_cons,List.getElem?_append,List.getElem?_cons,List.append_assoc]

theorem sqrt_pop_to_param (s : State) (n lo hi : Nat) :
    popScope (sqrtParam s n) (sqrtFrame s n lo hi)=sqrtParam s n := by
  simp [popScope,sqrtParam,sqrtFrame,List.take_append]

theorem sqrt_pop_param (s : State) (n : Nat) :
    popScope s (sqrtParam s n)=s := by
  cases s
  simp [popScope,sqrtParam,List.take_append]

/-- Actual parsed integer_sqrt body, including mutable local objects,
midpoint division, unsigned assignments, compound scopes and return cast.
The callee service is arbitrary because this body contains no calls. -/
theorem sqrt_body (call : Call) (s : State) (n out : Nat) (run : SqrtExec n out) :
    BodyCall call "integer_sqrt" [word 64 n] s (word 64 out) s := by
  refine ⟨f_integer_sqrt,sqrtParam s n,sqrtParam s n,word 64 out,?_,
    sqrt_bind s n,?_,?_,(sqrt_pop_param s n).symm⟩
  · rfl
  · change Run call (.sequence [
      .declare [⟨"U","lo",some (.nat 0)⟩,⟨"U","hi",some (.var "n")⟩],
      .whileLoop sqrtCond sqrtIteration,.returnStmt (.var "lo")])
      (sqrtParam s n) (.returned (sqrtParam s n) (word 64 out))
    apply StmtRun.sequence
    · apply SeqRun.next (StmtRun.declare (sqrt_declare_initial call s n))
      apply SeqRun.next (StmtRun.whileLoop (sqrt_while_of_trace call s run.1 run.2
        ⟨Nat.zero_le _,Nat.sqrt_le_self _,le_rfl⟩))
      apply SeqRun.returned
      apply StmtRun.returnValue
      exact sqrt_var_lo call 999 s n out out
    · exact congrArg (fun t=>Flow.returned t (word 64 out))
        (sqrt_pop_to_param s n out out).symm
  · simp [f_integer_sqrt,castValue,asNat,word]

#print axioms sqrt_while_of_trace
#print axioms sqrt_body
end LCMSourcePV.Witness.AST
