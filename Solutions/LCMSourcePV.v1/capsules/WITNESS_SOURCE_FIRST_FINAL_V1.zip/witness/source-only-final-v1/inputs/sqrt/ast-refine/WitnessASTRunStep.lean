/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTRunExpr
import WitnessASTMakeRunContract
namespace LCMSourcePV.Witness.AST
open E1TwoTracks.TrackB LCMSourcePV.Witness.C LCMSourcePV.RestrictedC LCMSourcePV.ASTLoops
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

def runMakeExpr : Expr := .unary "!" (.call (.var "make_exact")
  [.nat 1000,.nat 30,.nat 32,.nat 16,.var "lo",.nat 10712529,.unary "&" (.var "b")])
def runIteration : Stmt := .sequence [
  .branch runStopCond (.returnStmt (.var "true")) .skip,
  .declare [⟨"Block","b",none⟩],
  .branch runMakeExpr (.returnStmt (.var "false")) .skip,
  .eval runStoreExpr,.eval runNextExpr]
def runStored (st : RunState) (b : Block) : RunState :=
  {st with count:=st.count+1,buffer:=st.buffer.set st.count (some b)}
def runNextWithoutFuel (st : RunState) (b : Block) : RunState :=
  {runStored st b with lo:=uadd b.hi 1}

theorem run_make_expr (call : Call) (hm : MakeRunContract call) (st : RunState) (b : Block)
    (hs : RunRep st) (trace : MakeExec 1000 30 32 16 st.lo 10712529 b) :
    Eval call runMakeExpr (runBlockFrame st none) (runBlockFrame st (some b)) (boolean false) := by
  apply eval_not_call call "make_exact" _
    [word 32 1000,word 32 30,word 32 32,word 32 16,word 64 st.lo,
      word 32 10712529,.pointer ⟨6,0,none⟩ true]
  · apply PureArgs.cons (by rfl)
    apply PureArgs.cons (by rfl)
    apply PureArgs.cons (by rfl)
    apply PureArgs.cons (by rfl)
    apply PureArgs.cons (runBlockFrame_var_lo call 997 st none)
    apply PureArgs.cons (by rfl)
    apply PureArgs.cons
    · apply eval_address_at call 995
      simp [getVar,runBlockFrame,allocate,runFrame,List.find?_cons]
    · exact PureArgs.nil
  · exact hm _ _ _ _ _ hs.2.1 trace (run_block_out_write st b (run_make_rep trace))

theorem run_declare_block (call : Call) (st : RunState) :
    Declare call [⟨"Block","b",none⟩] (runFrame st) (runBlockFrame st none) := by
  rfl

theorem run_iteration_step (call : Call) (hm : MakeRunContract call)
    (st : RunState) (b : Block) (hs : RunRep st)
    (hstop : st.lo < 10712529) (hc : st.count < st.buffer.length)
    (trace : MakeExec 1000 30 32 16 st.lo 10712529 b) :
    Run call runIteration (runFrame st) (.continuing (runFrame (runNextWithoutFuel st b))) := by
  apply StmtRun.sequence
  · apply SeqRun.next
    · apply StmtRun.branch (run_stop_test call st hs)
      simpa [truth,boolean,word,Nat.not_le.mpr hstop] using StmtRun.skip (runFrame st)
    · apply SeqRun.next (StmtRun.declare (run_declare_block call st))
      apply SeqRun.next
      · apply StmtRun.branch (run_make_expr call hm st b hs trace)
        simpa [truth,boolean,word] using StmtRun.skip (runBlockFrame st (some b))
      · apply SeqRun.next (StmtRun.evaluate (run_store_expr call st b hs (run_make_rep trace) hc))
        apply SeqRun.next (StmtRun.evaluate (run_next_expr call (runStored st b) b))
        exact SeqRun.nil _
  · exact congrArg Flow.continuing (run_pop_block st (runNextWithoutFuel st b) (some b)).symm

theorem run_iteration_done (call : Call) (st : RunState) (hs : RunRep st)
    (hstop : 10712529 ≤ st.lo) :
    Run call runIteration (runFrame st) (.returned (runFrame st) (word 1 1)) := by
  apply StmtRun.sequence
  · apply SeqRun.returned
    apply StmtRun.branch (run_stop_test call st hs)
    have hr : Run call (.returnStmt (.var "true")) (runFrame st)
        (.returned (runFrame st) (word 1 1)) := StmtRun.returnValue (by rfl)
    simpa [truth,boolean,word,hstop] using hr
  · exact scope_self _ _

theorem run_store_equations {st next : RunState} {b : Block}
    (hstore : storeBlock st b=some next) (hs : RunRep st) :
    st.count < st.buffer.length ∧
      next={runNextWithoutFuel st b with loopIndex:=(st.loopIndex+1)%2^64} := by
  have hc : st.count+1 < 2^64 := by
    unfold storeBlock at hstore
    split at hstore
    · have hh:=hs.2.2.2
      omega
    · cases hstore
  have he : uadd st.count 1=st.count+1 := Unsigned.add_exact hc
  unfold storeBlock at hstore
  split at hstore
  · rename_i h
    cases hstore
    exact ⟨h,by simp only [runNextWithoutFuel,runStored,he]⟩
  · cases hstore

#print axioms run_iteration_step
#print axioms run_iteration_done
end LCMSourcePV.Witness.AST
