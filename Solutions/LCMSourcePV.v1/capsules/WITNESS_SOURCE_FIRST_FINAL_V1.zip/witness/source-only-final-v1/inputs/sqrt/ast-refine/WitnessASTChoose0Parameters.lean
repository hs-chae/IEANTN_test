/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTChoose0Frame
import WitnessASTBlockOut
namespace LCMSourcePV.Witness.AST
open E1TwoTracks.TrackB LCMSourcePV.Witness.C
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

def choose0NumberParameters (caller : State) (pf ff total lo stop p0 p1 p2 q1 q2 top : Nat) : State :=
 (allocate (allocate (allocate (allocate (allocate (allocate (allocate (allocate (allocate (allocate (allocate ({caller with env:=[]}) "U" "primeFuel" (some (word 64 pf))) "U" "fitFuel" (some (word 64 ff))) "U" "fuel" (some (word 64 total))) "U" "lo" (some (word 64 lo))) "U" "stop" (some (word 64 stop))) "U" "p0" (some (word 64 p0))) "U" "p1" (some (word 64 p1))) "U" "p2" (some (word 64 p2))) "U" "q1" (some (word 64 q1))) "U" "q2" (some (word 64 q2))) "U" "top" (some (word 64 top)))

theorem choose0_bind (caller : State) (pf ff total lo stop p0 p1 p2 q1 q2 top : Nat)
    (out : Address) (ht : addressType caller out=some "Block")
    (hb : out.object < caller.heap.length) :
    bindArgs f_choose_q0.parameters
      [word 64 pf,word 64 ff,word 64 total,word 64 lo,word 64 stop,word 64 p0,
        word 64 p1,word 64 p2,word 64 q1,word 64 q2,word 64 top,.pointer out true]
      caller=some (Choose0.params caller pf ff total lo stop p0 p1 p2 q1 q2 top out) := by
  have ht11 : addressType (choose0NumberParameters caller pf ff total lo stop p0 p1 p2 q1 q2 top) out=some "Block" := by
    simpa only [choose0NumberParameters,allocate,addressType,List.append_assoc,
      List.getElem?_append,hb,ite_true] using ht
  simp only [choose0NumberParameters,allocate,List.append_assoc,List.length_append,
    List.length_singleton,List.length_cons,List.length_nil,List.singleton_append,List.cons_append,List.nil_append,
    Nat.add_assoc,Nat.reduceAdd,word,Nat.reducePow] at ht11
  simp [bindArgs,f_choose_q0,List.foldlM,choose0NumberParameters,Choose0.params,castValue,
    asNat,word,allocate,ht11,List.append_assoc,Nat.add_assoc]

theorem choose0_call_of_body (call : Call) (caller after : State)
    (pf ff total lo stop p0 p1 p2 q1 q2 top : Nat) (address : Address) (out : Block)
    (hwrite : WriteBlock caller address out after)
    (body : ∃finalTop,Run call f_choose_q0.body
      (Choose0.params caller pf ff total lo stop p0 p1 p2 q1 q2 top address)
      (.returned (Choose0.params after pf ff total lo stop p0 p1 p2 q1 q2 finalTop address)
        (bword true))) :
    BodyCall call "choose_q0"
      [word 64 pf,word 64 ff,word 64 total,word 64 lo,word 64 stop,word 64 p0,
        word 64 p1,word 64 p2,word 64 q1,word 64 q2,word 64 top,.pointer address true]
      caller (bword true) after := by
  obtain ⟨finalTop,hbody⟩:=body
  refine ⟨f_choose_q0,Choose0.params caller pf ff total lo stop p0 p1 p2 q1 q2 top address,
    Choose0.params after pf ff total lo stop p0 p1 p2 q1 q2 finalTop address,
    bword true,?_,choose0_bind caller pf ff total lo stop p0 p1 p2 q1 q2 top address
      hwrite.target_type (write_address_bound hwrite),hbody,?_,?_⟩
  · rfl
  · rfl
  · symm
    apply pop_frame_effect caller after _ _ (write_shape hwrite).1 (write_shape hwrite).2

#print axioms choose0_bind
#print axioms choose0_call_of_body
end LCMSourcePV.Witness.AST
