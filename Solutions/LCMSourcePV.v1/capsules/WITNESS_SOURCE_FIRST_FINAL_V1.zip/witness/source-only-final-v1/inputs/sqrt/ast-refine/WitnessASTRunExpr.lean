/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTRunMath
import WitnessASTArgumentWords
namespace LCMSourcePV.Witness.AST
open E1TwoTracks.TrackB LCMSourcePV.Witness.C LCMSourcePV.RestrictedC
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

def runLoopCond : Expr := .binary "<" (.var "fuel") (.nat 1024)
def runStopCond : Expr := .binary "<=" (.nat 10712529) (.var "lo")
def runStoreExpr : Expr := .binary "="
  (.index (.var "out") (.post "++" (.unary "*" (.var "count")))) (.var "b")
def runNextExpr : Expr := .binary "=" (.var "lo")
  (.binary "+" (.field "." (.var "b") "hi") (.nat 1))

theorem run_loop_test (call : Call) (st : RunState) (hs : RunRep st) :
    Eval call runLoopCond (runFrame st) (runFrame st) (boolean (st.loopIndex < 1024)) := by
  apply sqrt_eval_lt_at call 999
  · exact runFrame_var_fuel call 998 st
  · rfl
  · change some (boolean (st.loopIndex%2^64 < 1024))=_
    rw [Nat.mod_eq_of_lt hs.2.2.1]

theorem run_stop_test (call : Call) (st : RunState) (hs : RunRep st) :
    Eval call runStopCond (runFrame st) (runFrame st) (boolean (10712529 ≤ st.lo)) := by
  apply sqrt_eval_le_at call 999
  · rfl
  · exact runFrame_var_lo call 998 st
  · change some (boolean (10712529 ≤ st.lo%2^64))=_
    rw [Nat.mod_eq_of_lt hs.2.1]

theorem run_increment (call : Call) (st : RunState) (hs : RunRep st) :
    Eval call (.unary "++" (.var "fuel")) (runFrame st)
      (runFrame {st with loopIndex:= (st.loopIndex+1)%2^64})
      (word 64 ((st.loopIndex+1)%2^64)) := by
  have hl : evalLValue call 999 (runFrame st) (.var "fuel")=
      some (⟨5,0,none⟩,true,runFrame st) := by
    simp [evalLValue,getVar,runFrame,List.find?_cons]
  change ((evalLValue call 999 (runFrame st) (.var "fuel")).bind
    (fun (a,writable,next)=>(read next a).bind (fun old=>
      match old with
      | .word width n=>write next a writable (word width (n+1))
      | _=>none)))=_
  rw [hl]
  change write (runFrame st) ⟨5,0,none⟩ true (word 64 (st.loopIndex%2^64+1))=_
  rw [Nat.mod_eq_of_lt hs.2.2.1]
  have hh:=run_write_fuel st ((st.loopIndex+1)%2^64)
  change write (runFrame st) ⟨5,0,none⟩ true
      (Value.word 64 (((st.loopIndex+1)%2^64)%2^64))=
      some (Value.word 64 (((st.loopIndex+1)%2^64)%2^64),
        runFrame {st with loopIndex:=(st.loopIndex+1)%2^64}) at hh
  rw [Nat.mod_mod] at hh
  change write (runFrame st) ⟨5,0,none⟩ true
      (Value.word 64 ((st.loopIndex+1)%2^64))=
      some (Value.word 64 (((st.loopIndex+1)%2^64)%2^64),
        runFrame {st with loopIndex:=(st.loopIndex+1)%2^64})
  rw [Nat.mod_mod]
  exact hh

theorem run_next_expr (call : Call) (st : RunState) (b : Block) :
    Eval call runNextExpr (runBlockFrame st (some b))
      (runBlockFrame {st with lo:=uadd b.hi 1} (some b)) (word 64 (uadd b.hi 1)) := by
  have hf : evalExpr call 998 (runBlockFrame st (some b))
      (.field "." (.var "b") "hi")=some (word 64 b.hi,runBlockFrame st (some b)) := by
    change ((evalExpr call 997 (runBlockFrame st (some b)) (.var "b")).bind
      (fun result=>match result.1 with
        | .block block=>(fieldIndex "hi").bind (fun i=>(fields block)[i]?.bind
            (fun n=>some (word 64 n,result.2)))
        | _=>none))=_
    rw [runBlockFrame_var_b call 996]
    rfl
  have he:=eval_add_one_at call 996 (runBlockFrame st (some b))
    (.field "." (.var "b") "hi") b.hi hf
  have hl : evalLValue call 999 (runBlockFrame st (some b)) (.var "lo")=
      some (⟨4,0,none⟩,true,runBlockFrame st (some b)) := by
    simp [evalLValue,getVar,runBlockFrame,runFrame,allocate,List.find?_cons]
  change ((evalExpr call 999 (runBlockFrame st (some b))
      (.binary "+" (.field "." (.var "b") "hi") (.nat 1))).bind
    (fun (v,next)=>(evalLValue call 999 next (.var "lo")).bind
      (fun (a,writable,last)=>write last a writable v)))=_
  rw [he]
  simp only [Option.bind_some]
  rw [hl]
  exact run_write_lo st (some b) _

theorem run_count_lvalue_at (call : Call) (fuel : Nat) (st : RunState) (b : Option Block) :
    evalLValue call (fuel+3) (runBlockFrame st b) (.unary "*" (.var "count"))=
      some (⟨1,0,none⟩,true,runBlockFrame st b) := by
  change ((evalExpr call (fuel+2) (runBlockFrame st b) (.var "count")).bind
    (fun result=>match result.1 with
      | .pointer a writable=>(addressType result.2 a).bind
          (fun _=>some (a,writable,result.2))
      | _=>none))=_
  rw [runBlockFrame_var_count call (fuel+1)]
  rfl

theorem run_post_count (call : Call) (st : RunState) (b : Option Block) (hs : RunRep st) :
    evalExpr call 998 (runBlockFrame st b) (.post "++" (.unary "*" (.var "count")))=
      some (word 64 st.count,runBlockFrame {st with count:=st.count+1} b) := by
  change ((evalLValue call 997 (runBlockFrame st b) (.unary "*" (.var "count"))).bind
    (fun (a,writable,next)=>(read next a).bind (fun old=>
      match old with
      | .word width n=>(write next a writable (word width (n+1))).bind
          (fun result=>some (old,result.2))
      | _=>none)))=_
  rw [run_count_lvalue_at call 994]
  change ((write (runBlockFrame st b) ⟨1,0,none⟩ true
    (word 64 (st.count%2^64+1))).bind
    (fun result=>some (word 64 st.count,result.2)))=_
  rw [Nat.mod_eq_of_lt hs.1,run_write_count]
  rfl

theorem run_array_lvalue (call : Call) (st : RunState) (b : Block) (hs : RunRep st)
    (hc : st.count < st.buffer.length) :
    evalLValue call 999 (runBlockFrame st (some b))
      (.index (.var "out") (.post "++" (.unary "*" (.var "count"))))=
      some (⟨0,st.count,none⟩,true,runBlockFrame {st with count:=st.count+1} (some b)) := by
  change ((evalExpr call 998 (runBlockFrame st (some b)) (.var "out")).bind
    (fun result=>match result.1 with
      | .pointer base writable=>if base.field.isSome then none else
        (evalExpr call 998 result.2 (.post "++" (.unary "*" (.var "count")))).bind
          (fun (idx,last)=>(asNat idx).bind (fun n=>
            (addressType last {base with index:=base.index+n}).bind
              (fun _=>some ({base with index:=base.index+n},writable,last))))
      | _=>none))=_
  rw [runBlockFrame_var_out call 997]
  change ((evalExpr call 998 (runBlockFrame st (some b))
    (.post "++" (.unary "*" (.var "count")))).bind
      (fun (idx,last)=>(asNat idx).bind (fun n=>
        (addressType last ⟨0,0+n,none⟩).bind
          (fun _=>some (Address.mk 0 (0+n) none,true,last)))))=_
  rw [run_post_count call st (some b) hs]
  have hcmod : st.count%18446744073709551616=st.count := Nat.mod_eq_of_lt hs.1
  simp [asNat,word,hcmod,addressType,runBlockFrame,runFrame,
    allocate,runBuffer,Nat.not_le.mpr hc]

theorem run_array_write_at (st : RunState) (b : Block) (index : Nat)
    (hb : BlockRep b) (hi : index < st.buffer.length) :
    write (runBlockFrame st (some b)) ⟨0,index,none⟩ true (.block b)=
      some (.block b,runBlockFrame {st with buffer:=st.buffer.set index (some b)} (some b)) := by
  rw [write_block _ 0 index ⟨"Block",runBuffer st.buffer⟩ b (by rfl) rfl
    (by simpa [runBuffer] using hi) hb]
  simp [runBlockFrame,runFrame,allocate,runBuffer,List.map_set]

theorem run_store_expr (call : Call) (st : RunState) (b : Block) (hs : RunRep st)
    (hb : BlockRep b) (hc : st.count < st.buffer.length) :
    Eval call runStoreExpr (runBlockFrame st (some b))
      (runBlockFrame {st with count:=st.count+1, buffer:=st.buffer.set st.count (some b)} (some b)) (.block b) := by
  change ((evalExpr call 999 (runBlockFrame st (some b)) (.var "b")).bind
    (fun (v,next)=>(evalLValue call 999 next
      (.index (.var "out") (.post "++" (.unary "*" (.var "count"))))).bind
      (fun (a,writable,last)=>write last a writable v)))=_
  rw [runBlockFrame_var_b call 998]
  simp only [Option.bind_some]
  rw [run_array_lvalue call st b hs hc]
  exact run_array_write_at {st with count:=st.count+1} b st.count hb hc

#print axioms run_store_expr
#print axioms run_next_expr
end LCMSourcePV.Witness.AST
