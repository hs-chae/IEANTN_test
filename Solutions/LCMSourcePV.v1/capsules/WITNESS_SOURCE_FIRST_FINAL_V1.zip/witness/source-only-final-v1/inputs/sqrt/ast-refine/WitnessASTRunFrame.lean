/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTSqrt
namespace LCMSourcePV.Witness.AST
open E1TwoTracks.TrackB LCMSourcePV.Witness.C
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024

def runBuffer (xs : List (Option Block)) : List (Option Value) :=
  xs.map (fun x=>x.map Value.block)
def outPointer : Value := .pointer ⟨0,0,none⟩ true
def countPointer : Value := .pointer ⟨1,0,none⟩ true

def runFrame (st : RunState) : State :=
  ⟨[⟨"Block",runBuffer st.buffer⟩,sqrtCell st.count,
    ⟨"Block*",[some outPointer]⟩,⟨"U*",[some countPointer]⟩,
    sqrtCell st.lo,sqrtCell st.loopIndex],
    [("fuel",⟨5,0,none⟩),("lo",⟨4,0,none⟩),
      ("count",⟨3,0,none⟩),("out",⟨2,0,none⟩)]⟩
def runBlockFrame (st : RunState) (b : Option Block) : State :=
  allocate (runFrame st) "Block" "b" (b.map Value.block)
def RunRep (st : RunState) : Prop :=
  st.count < 2^64 ∧ st.lo < 2^64 ∧ st.loopIndex < 2^64 ∧ st.buffer.length=1024

@[simp] theorem runFrame_var_fuel (call : Call) (fuel : Nat) (st : RunState) :
    evalExpr call (fuel+1) (runFrame st) (.var "fuel")=some (word 64 st.loopIndex,runFrame st) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

@[simp] theorem runFrame_var_lo (call : Call) (fuel : Nat) (st : RunState) :
    evalExpr call (fuel+1) (runFrame st) (.var "lo")=some (word 64 st.lo,runFrame st) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

@[simp] theorem runFrame_var_count (call : Call) (fuel : Nat) (st : RunState) :
    evalExpr call (fuel+1) (runFrame st) (.var "count")=some (countPointer,runFrame st) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

@[simp] theorem runFrame_var_out (call : Call) (fuel : Nat) (st : RunState) :
    evalExpr call (fuel+1) (runFrame st) (.var "out")=some (outPointer,runFrame st) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

@[simp] theorem runBlockFrame_var_fuel (call : Call) (fuel : Nat) (st : RunState) (b : Option Block) :
    evalExpr call (fuel+1) (runBlockFrame st b) (.var "fuel")=some (word 64 st.loopIndex,runBlockFrame st b) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

@[simp] theorem runBlockFrame_var_lo (call : Call) (fuel : Nat) (st : RunState) (b : Option Block) :
    evalExpr call (fuel+1) (runBlockFrame st b) (.var "lo")=some (word 64 st.lo,runBlockFrame st b) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

@[simp] theorem runBlockFrame_var_count (call : Call) (fuel : Nat) (st : RunState) (b : Option Block) :
    evalExpr call (fuel+1) (runBlockFrame st b) (.var "count")=some (countPointer,runBlockFrame st b) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

@[simp] theorem runBlockFrame_var_out (call : Call) (fuel : Nat) (st : RunState) (b : Option Block) :
    evalExpr call (fuel+1) (runBlockFrame st b) (.var "out")=some (outPointer,runBlockFrame st b) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

@[simp] theorem runBlockFrame_var_b (call : Call) (fuel : Nat) (st : RunState) (b : Block) :
    evalExpr call (fuel+1) (runBlockFrame st (some b)) (.var "b")=
      some (.block b,runBlockFrame st (some b)) := by
  simp [evalExpr,getVar,read,runFrame,runBlockFrame,allocate,sqrtCell,
    List.find?_cons,List.getElem?_cons]

theorem run_block_out_write (st : RunState) (b : Block) (hb : BlockRep b) :
    WriteBlock (runBlockFrame st none) ⟨6,0,none⟩ b (runBlockFrame st (some b)) := by
  apply write_block _ 6 0 ⟨"Block",[none]⟩ b
  · rfl
  · rfl
  · decide
  · exact hb

theorem run_write_count (st : RunState) (b : Option Block) (count : Nat) :
    write (runBlockFrame st b) ⟨1,0,none⟩ true (word 64 count)=
      some (word 64 count,runBlockFrame {st with count:=count} b) := by
  rw [write_scalar _ _ _ _ (by rfl)]
  rfl

theorem run_write_lo (st : RunState) (b : Option Block) (lo : Nat) :
    write (runBlockFrame st b) ⟨4,0,none⟩ true (word 64 lo)=
      some (word 64 lo,runBlockFrame {st with lo:=lo} b) := by
  rw [write_scalar _ _ _ _ (by rfl)]
  rfl

theorem run_write_fuel (st : RunState) (fuel : Nat) :
    write (runFrame st) ⟨5,0,none⟩ true (word 64 fuel)=
      some (word 64 fuel,runFrame {st with loopIndex:=fuel}) := by
  rw [write_scalar _ _ _ _ (by rfl)]
  rfl

theorem run_write_array (st : RunState) (b : Block) (hb : BlockRep b)
    (hi : st.count < st.buffer.length) :
    write (runBlockFrame st (some b)) ⟨0,st.count,none⟩ true (.block b)=
      some (.block b,runBlockFrame {st with buffer:=st.buffer.set st.count (some b)} (some b)) := by
  rw [write_block _ 0 st.count ⟨"Block",runBuffer st.buffer⟩ b (by rfl) rfl
    (by simpa [runBuffer] using hi) hb]
  simp [runBlockFrame,runFrame,allocate,runBuffer,List.map_set]

theorem run_pop_block (st next : RunState) (b : Option Block) :
    popScope (runFrame st) (runBlockFrame next b)=runFrame next := by
  simp [popScope,runFrame,runBlockFrame,allocate]

#print axioms run_write_array
end LCMSourcePV.Witness.AST
