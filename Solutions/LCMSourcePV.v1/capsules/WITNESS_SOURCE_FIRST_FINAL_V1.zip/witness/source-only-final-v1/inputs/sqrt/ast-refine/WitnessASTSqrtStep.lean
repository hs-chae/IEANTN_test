/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTSqrtExpr
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C LCMSourcePV.ASTLoops
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024

def sqrtIteration : Stmt := .sequence [
  .declare [⟨"U","mid",some sqrtMidExpr⟩],
  .branch sqrtMidCond (.eval (.binary "=" (.var "lo") (.var "mid")))
    (.eval (.binary "=" (.var "hi") (.binary "-" (.var "mid") (.nat 1))))]

theorem sqrt_declare_mid (call : Call) (s : State) (n lo hi : Nat)
    (hn : n < sqrtWord) (hinv : SqrtInvariant n lo hi) (hlt : lo < hi) :
    Declare call [⟨"U","mid",some sqrtMidExpr⟩] (sqrtFrame s n lo hi)
      (sqrtMidFrame s n lo hi (sqrtMid lo hi)) := by
  have h:=sqrt_mid_expr call s n lo hi hn hinv hlt
  unfold Eval at h
  simp only [Declare,declarations,List.foldlM_cons,List.foldlM_nil]
  rw [h]
  simp [castValue,asNat,word,sqrtMidFrame]

theorem sqrt_assign_lo (call : Call) (s : State) (n lo hi mid : Nat) :
    Eval call (.binary "=" (.var "lo") (.var "mid"))
      (sqrtMidFrame s n lo hi mid) (sqrtMidFrame s n mid hi mid) (word 64 mid) := by
  change ((evalExpr call 999 (sqrtMidFrame s n lo hi mid) (.var "mid")).bind
    (fun (v,next)=>(evalLValue call 999 next (.var "lo")).bind
      (fun (a,writable,last)=>write last a writable v)))=_
  rw [sqrt_midvar_mid call 998]
  simp only [Option.bind_some]
  rw [(sqrt_midframe_lvalue call 998 s n lo hi mid).1]
  simp only [Option.bind_some]
  exact sqrt_write_lo s n lo hi mid mid

theorem sqrt_assign_hi (call : Call) (s : State) (n lo hi : Nat)
    (hn : n < sqrtWord) (hinv : SqrtInvariant n lo hi) (hlt : lo < hi) :
    Eval call (.binary "=" (.var "hi") (.binary "-" (.var "mid") (.nat 1)))
      (sqrtMidFrame s n lo hi (sqrtMid lo hi))
      (sqrtMidFrame s n lo ((sqrtMid lo hi-1)%sqrtWord) (sqrtMid lo hi))
      (word 64 ((sqrtMid lo hi-1)%sqrtWord)) := by
  have hb:=sqrt_mid_bounds hn hinv hlt
  have hm64 : sqrtMid lo hi < 2^64 := hb.2.2.2.2
  have he:=sqrt_decrement_source_operations hn hinv hlt
  have hexpr : evalExpr call 999 (sqrtMidFrame s n lo hi (sqrtMid lo hi))
      (.binary "-" (.var "mid") (.nat 1))=
      some (word 64 ((sqrtMid lo hi-1)%sqrtWord),
        sqrtMidFrame s n lo hi (sqrtMid lo hi)) := by
    apply sqrt_eval_sub_at call 998
    · exact sqrt_midvar_mid call 997 s n lo hi (sqrtMid lo hi)
    · rfl
    · change some (Value.word 64 ((sqrtMid lo hi%2^64+2^64-1)%2^64))=_
      rw [Nat.mod_eq_of_lt hm64]
      change some (Value.word 64 ((sqrtMid lo hi+sqrtWord-1)%sqrtWord))=
        some (Value.word 64 (((sqrtMid lo hi-1)%sqrtWord)%sqrtWord))
      rw [he,Nat.mod_mod]
  change ((evalExpr call 999 (sqrtMidFrame s n lo hi (sqrtMid lo hi))
    (.binary "-" (.var "mid") (.nat 1))).bind
    (fun (v,next)=>(evalLValue call 999 next (.var "hi")).bind
      (fun (a,writable,last)=>write last a writable v)))=_
  rw [hexpr]
  simp only [Option.bind_some]
  rw [(sqrt_midframe_lvalue call 998 s n lo hi (sqrtMid lo hi)).2]
  simp only [Option.bind_some]
  exact sqrt_write_hi s n lo hi (sqrtMid lo hi) _

theorem sqrt_iteration_up (call : Call) (s : State) (n lo hi : Nat)
    (hn : n < sqrtWord) (hinv : SqrtInvariant n lo hi) (hlt : lo < hi)
    (hg : sqrtMid lo hi ≤ n/sqrtMid lo hi) :
    Run call sqrtIteration (sqrtFrame s n lo hi)
      (.continuing (sqrtFrame s n (sqrtMid lo hi) hi)) := by
  apply StmtRun.sequence
  · apply SeqRun.next (StmtRun.declare (sqrt_declare_mid call s n lo hi hn hinv hlt))
    apply SeqRun.next
    · apply StmtRun.branch (sqrt_mid_test call s n lo hi hn hinv hlt)
      simpa [truth,boolean,word,hg] using
        (StmtRun.evaluate (sqrt_assign_lo call s n lo hi (sqrtMid lo hi)))
    · exact SeqRun.nil _
  · exact congrArg Flow.continuing (sqrt_pop_mid s n lo hi (sqrtMid lo hi) hi (sqrtMid lo hi)).symm

theorem sqrt_iteration_down (call : Call) (s : State) (n lo hi : Nat)
    (hn : n < sqrtWord) (hinv : SqrtInvariant n lo hi) (hlt : lo < hi)
    (hg : ¬sqrtMid lo hi ≤ n/sqrtMid lo hi) :
    Run call sqrtIteration (sqrtFrame s n lo hi)
      (.continuing (sqrtFrame s n lo ((sqrtMid lo hi-1)%sqrtWord))) := by
  apply StmtRun.sequence
  · apply SeqRun.next (StmtRun.declare (sqrt_declare_mid call s n lo hi hn hinv hlt))
    apply SeqRun.next
    · apply StmtRun.branch (sqrt_mid_test call s n lo hi hn hinv hlt)
      simpa [truth,boolean,word,hg] using
        (StmtRun.evaluate (sqrt_assign_hi call s n lo hi hn hinv hlt))
    · exact SeqRun.nil _
  · exact congrArg Flow.continuing (sqrt_pop_mid s n lo hi lo ((sqrtMid lo hi-1)%sqrtWord) (sqrtMid lo hi)).symm

#print axioms sqrt_iteration_up
#print axioms sqrt_iteration_down
end LCMSourcePV.Witness.AST
