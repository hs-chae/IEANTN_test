/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessMainGrammar
namespace LCMSourcePV.Witness.Main
open LCMSourcePV.Witness.C LCMSourcePV.Witness.AST LCMSourcePV.ASTLoops
set_option maxHeartbeats 0

structure MState where
  runtime : AST.State
  arrays : List String
  output : List (List Nat)
abbrev Flow := LCMSourcePV.ASTLoops.Flow MState AST.Value

def liftCore (before : MState) : AST.Flow → Flow
  | .continuing st=>.continuing {before with runtime:=st}
  | .returned st v=>.returned {before with runtime:=st} v

def pop (entry finished : MState) : MState :=
  ⟨popScope entry.runtime finished.runtime,entry.arrays,finished.output⟩
def exitScope (entry : MState) : Flow → Flow
  | .continuing st=>.continuing (pop entry st)
  | .returned st v=>.returned (pop entry st) v

def Eval (call : AST.Call) (e : Expr) (s t : MState) (value : AST.Value) : Prop :=
  AST.Eval call (lowerExpr s.arrays e) s.runtime t.runtime value ∧
    t.arrays=s.arrays ∧ t.output=s.output

def allocateArray (s : MState) (type name : String) (size : Nat) : MState :=
  ⟨⟨s.runtime.heap++[⟨type,List.replicate size none⟩],
      (name,⟨s.runtime.heap.length,0,none⟩)::s.runtime.env⟩,
    name::s.arrays,s.output⟩

/-- printf's generic C-library contract is restricted to this checked exact
format and eight represented uint64 arguments. Application argument reads,
ordering, loop count and row selection are proved, not platform assumptions.
The deterministic stdout model records numbers; physical successful writes
and PRIu64 formatting remain the documented CStdIO/compiler ABI boundary. -/
def Prints (call : AST.Call) (args : List Expr) (s : MState) (row : List Nat) : Prop :=
  row.length=8 ∧ (∀n∈row,n < 2^64) ∧
  PureArgs call 1000 s.runtime (args.map (lowerExpr s.arrays)) (row.map (word 64))

mutual
 inductive Run (call : AST.Call) : Stmt → MState → Flow → Prop
  | core {body s result} (run : AST.Run call (lowerStmt s.arrays body) s.runtime result) :
      Run call (.core body) s (liftCore s result)
  | array (s : MState) (type name : String) (size : Nat) (positive : 0 < size) :
      Run call (.array type name size) s (.continuing (allocateArray s type name size))
  | printf {args s row} (arguments : Prints call args s row) :
      Run call (.printf8 args) s (.continuing {s with output:=s.output++[row]})
  | sequence {body s result} (run : SeqRun call body s result) :
      Run call (.sequence body) s (exitScope s result)
  | branchYes {e yes no s t value result} (test : Eval call e s t value)
      (positive : truth value=true) (body : Run call yes t result) :
      Run call (.branch e yes no) s result
  | branchNo {e yes s t value} (test : Eval call e s t value)
      (negative : truth value=false) :
      Run call (.branch e yes none) s (.continuing t)
  | branchElse {e yes no s t value result} (test : Eval call e s t value)
      (negative : truth value=false) (body : Run call no t result) :
      Run call (.branch e yes (some no)) s result
  | forLoop {init cond step body s t result}
      (initialization : Run call (.core init) s (.continuing t))
      (loop : ForRun call cond step body t result) :
      Run call (.forLoop init cond step body) s (exitScope s result)
  | forInitialReturn {init cond step body s t value}
      (initialization : Run call (.core init) s (.returned t value)) :
      Run call (.forLoop init cond step body) s (exitScope s (.returned t value))
 inductive SeqRun (call : AST.Call) : List Stmt → MState → Flow → Prop
  | nil (s : MState) : SeqRun call [] s (.continuing s)
  | next {head tail s t result} (first : Run call head s (.continuing t))
      (rest : SeqRun call tail t result) : SeqRun call (head::tail) s result
  | returned {head tail s t v} (first : Run call head s (.returned t v)) :
      SeqRun call (head::tail) s (.returned t v)
 inductive ForRun (call : AST.Call) : Expr → Expr → Stmt → MState → Flow → Prop
  | done {cond step body s t value} (test : Eval call cond s t value)
      (stop : truth value=false) : ForRun call cond step body s (.continuing t)
  | next {cond step body s t b c condition value result}
      (test : Eval call cond s t condition) (positive : truth condition=true)
      (iteration : Run call body t (.continuing b)) (increment : Eval call step b c value)
      (rest : ForRun call cond step body c result) : ForRun call cond step body s result
  | returned {cond step body s t b condition value}
      (test : Eval call cond s t condition) (positive : truth condition=true)
      (iteration : Run call body t (.returned b value)) :
      ForRun call cond step body s (.returned b value)
end

theorem body_call_reenv {call : AST.Call} {name : String} {args : List AST.Value}
    {s t : AST.State} {value : AST.Value} (h : BodyCall call name args s value t) (env : AST.Env) :
    BodyCall call name args {s with env:=env} value {t with env:=env} := by
  rcases h with ⟨f,start,finished,raw,hfind,hbind,hrun,hcast,hpop⟩
  refine ⟨f,start,finished,raw,hfind,?_,hrun,hcast,?_⟩
  · exact hbind
  · rw [hpop]
    rfl

#print axioms body_call_reenv
end LCMSourcePV.Witness.Main
