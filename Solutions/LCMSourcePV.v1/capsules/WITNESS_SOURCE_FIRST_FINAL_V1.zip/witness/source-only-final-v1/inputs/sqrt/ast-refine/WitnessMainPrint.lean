/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessMainFrames
namespace LCMSourcePV.Witness.Main
open LCMSourcePV.Witness.C LCMSourcePV.Witness.AST E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

theorem print_declare_b (call : Call) (st : RunState) (i : Nat) (rows : List (List Nat))
    (hi : i < 2^64) (hbuf : i < st.buffer.length) :
    AST.Declare call [⟨"const Block*","b",some
      (.unary "&" (.index (.unary "&" (.var "out")) (.var "i")))⟩]
      (printLoop st i rows).runtime (printBody st i rows).runtime := by
  have ha : evalExpr call 998 (printLoop st i rows).runtime (.unary "&" (.var "out"))=
      some (.pointer ⟨0,0,none⟩ true,(printLoop st i rows).runtime) := by
    simp [evalExpr,evalLValue,getVar,printLoop,afterRun,allocate,runCaller,mainEnv,List.find?_cons]
  have hl : evalLValue call 999 (printLoop st i rows).runtime
      (.index (.unary "&" (.var "out")) (.var "i"))=
      some (⟨0,i,none⟩,true,(printLoop st i rows).runtime) := by
    change ((evalExpr call 998 (printLoop st i rows).runtime (.unary "&" (.var "out"))).bind
      (fun result=>match result.1 with
        | .pointer base writable=>if base.field.isSome then none else
          (evalExpr call 998 result.2 (.var "i")).bind
            (fun (idx,last)=>(asNat idx).bind (fun n=>
              (addressType last {base with index:=base.index+n}).bind
                (fun _=>some ({base with index:=base.index+n},writable,last))))
        | _=>none))=_
    rw [ha]
    change ((evalExpr call 998 (printLoop st i rows).runtime (.var "i")).bind
      (fun (idx,last)=>(asNat idx).bind (fun n=>
        (addressType last ⟨0,0+n,none⟩).bind
          (fun _=>some (Address.mk 0 (0+n) none,true,last)))))=_
    rw [print_var_i call 997]
    have himod : i%18446744073709551616=i := Nat.mod_eq_of_lt hi
    simp [asNat,word,himod,addressType,printLoop,afterRun,allocate,runCaller,runBuffer,
      Nat.not_le.mpr hbuf]
  have he : evalExpr call 1000 (printLoop st i rows).runtime
      (.unary "&" (.index (.unary "&" (.var "out")) (.var "i")))=
      some (.pointer ⟨0,i,none⟩ true,(printLoop st i rows).runtime) := by
    change ((evalLValue call 999 (printLoop st i rows).runtime
      (.index (.unary "&" (.var "out")) (.var "i"))).bind
        (fun (a,writable,next)=>some (Value.pointer a writable,next)))=_
    rw [hl]
    rfl
  simp only [AST.Declare,declarations,List.foldlM_cons,List.foldlM_nil]
  rw [he]
  simp [castValue,addressType,printLoop,afterRun,allocate,runCaller,runBuffer,
    Nat.not_le.mpr hbuf,printBody]

theorem print_arguments (call : Call) (st : RunState) (i : Nat) (rows : List (List Nat))
    (b : Block) (hread : st.buffer[i]?=some (some b)) (hb : BlockRep b) :
    Prints call mainPrintArgs (printBody st i rows) (fields b) := by
  refine ⟨by cases b;rfl,hb,?_⟩
  simp only [printBody,mainPrintArgs,List.map_cons,List.map_nil,lowerExpr,fields]
  change PureArgs call 1000 (printBody st i rows).runtime
    [.field "->" (.var "b") "lo",.field "->" (.var "b") "hi",
     .field "->" (.var "b") "p0",.field "->" (.var "b") "p1",
     .field "->" (.var "b") "p2",.field "->" (.var "b") "q0",
     .field "->" (.var "b") "q1",.field "->" (.var "b") "q2"]
    [word 64 b.lo,word 64 b.hi,word 64 b.p0,word 64 b.p1,
     word 64 b.p2,word 64 b.q0,word 64 b.q1,word 64 b.q2]
  apply PureArgs.cons (print_field_at call 998 st i rows b "lo" 0 b.lo hread (by rfl) (by rfl))
  apply PureArgs.cons (print_field_at call 998 st i rows b "hi" 1 b.hi hread (by rfl) (by rfl))
  apply PureArgs.cons (print_field_at call 998 st i rows b "p0" 2 b.p0 hread (by rfl) (by rfl))
  apply PureArgs.cons (print_field_at call 998 st i rows b "p1" 3 b.p1 hread (by rfl) (by rfl))
  apply PureArgs.cons (print_field_at call 998 st i rows b "p2" 4 b.p2 hread (by rfl) (by rfl))
  apply PureArgs.cons (print_field_at call 998 st i rows b "q0" 5 b.q0 hread (by rfl) (by rfl))
  apply PureArgs.cons (print_field_at call 998 st i rows b "q1" 6 b.q1 hread (by rfl) (by rfl))
  apply PureArgs.cons (print_field_at call 998 st i rows b "q2" 7 b.q2 hread (by rfl) (by rfl))
  exact PureArgs.nil

theorem print_iteration (call : Call) (st : RunState) (i : Nat) (rows : List (List Nat))
    (b : Block) (hread : st.buffer[i]?=some (some b)) (hb : BlockRep b)
    (hi : i < 2^64) (hbuf : i < st.buffer.length) :
    Run call mainPrintBody (printLoop st i rows)
      (.continuing (printLoop st i (rows++[fields b]))) := by
  have hd : Run call (.core (.declare [⟨"const Block*","b",some
      (.unary "&" (.index (.var "out") (.var "i")))⟩]))
      (printLoop st i rows) (.continuing (printBody st i rows)) := by
    have hc : AST.Run call (lowerStmt (printLoop st i rows).arrays
      (.declare [⟨"const Block*","b",some
        (.unary "&" (.index (.var "out") (.var "i")))⟩]))
      (printLoop st i rows).runtime (.continuing (printBody st i rows).runtime) := by
      simp only [printLoop,lowerStmt,lowerDecl,List.map_cons,List.map_nil,Option.map_some,
        lowerExpr,lowerLValue]
      change AST.Run call (.declare [⟨"const Block*","b",some
        (.unary "&" (.index (.unary "&" (.var "out")) (.var "i")))⟩]) _ _
      exact LCMSourcePV.ASTLoops.StmtRun.declare (print_declare_b call st i rows hi hbuf)
    exact Run.core hc
  have hseq : SeqRun call [
      .core (.declare [⟨"const Block*","b",some
        (.unary "&" (.index (.var "out") (.var "i")))⟩]),.printf8 mainPrintArgs]
      (printLoop st i rows) (.continuing (printBody st i (rows++[fields b]))) := by
    apply SeqRun.next hd
    apply SeqRun.next (Run.printf (print_arguments call st i rows b hread hb))
    exact SeqRun.nil _
  have h:=Run.sequence hseq
  simpa only [mainPrintBody,exitScope,print_pop_body] using h

#print axioms print_iteration
end LCMSourcePV.Witness.Main
