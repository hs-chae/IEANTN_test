/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessMainSemantics
namespace LCMSourcePV.Witness.Main
open LCMSourcePV.Witness.C LCMSourcePV.Witness.AST E1TwoTracks.TrackB
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

def mainEnv : AST.Env := [("count",⟨1,0,none⟩),("out",⟨0,0,none⟩)]
def empty : MState := ⟨⟨[],[]⟩,[],[]⟩
def allocated : MState := ⟨{runAllocated with env:=mainEnv},["out"],[]⟩
def afterRun (st : RunState) (rows : List (List Nat)) : MState :=
  ⟨{runCaller st with env:=mainEnv},["out"],rows⟩
def printLoop (st : RunState) (i : Nat) (rows : List (List Nat)) : MState :=
  ⟨allocate (afterRun st rows).runtime "U" "i" (some (word 64 i)),["out"],rows⟩
def printBody (st : RunState) (i : Nat) (rows : List (List Nat)) : MState :=
  ⟨allocate (printLoop st i rows).runtime "const Block*" "b"
      (some (.pointer ⟨0,i,none⟩ false)),["out"],rows⟩

theorem print_var_i (call : Call) (fuel : Nat) (st : RunState) (i : Nat) (rows : List (List Nat)) :
    evalExpr call (fuel+1) (printLoop st i rows).runtime (.var "i")=
      some (word 64 i,(printLoop st i rows).runtime) := by
  simp [evalExpr,getVar,AST.read,printLoop,afterRun,allocate,runCaller,mainEnv,
    sqrtCell,List.find?_cons,List.getElem?_cons]

theorem print_var_count (call : Call) (fuel : Nat) (st : RunState) (i : Nat) (rows : List (List Nat)) :
    evalExpr call (fuel+1) (printLoop st i rows).runtime (.var "count")=
      some (word 64 st.count,(printLoop st i rows).runtime) := by
  simp [evalExpr,getVar,AST.read,printLoop,afterRun,allocate,runCaller,mainEnv,
    sqrtCell,List.find?_cons,List.getElem?_cons]

theorem print_body_var_b (call : Call) (fuel : Nat) (st : RunState) (i : Nat) (rows : List (List Nat)) :
    evalExpr call (fuel+1) (printBody st i rows).runtime (.var "b")=
      some (.pointer ⟨0,i,none⟩ false,(printBody st i rows).runtime) := by
  simp [evalExpr,getVar,AST.read,printBody,printLoop,afterRun,allocate,runCaller,mainEnv,
    sqrtCell,List.find?_cons,List.getElem?_cons]

theorem print_field_at (call : Call) (fuel : Nat) (st : RunState) (i : Nat)
    (rows : List (List Nat)) (b : Block) (name : String) (index n : Nat)
    (hread : st.buffer[i]?=some (some b)) (hf : fieldIndex name=some index)
    (hn : (fields b)[index]?=some n) :
    evalExpr call (fuel+2) (printBody st i rows).runtime (.field "->" (.var "b") name)=
      some (word 64 n,(printBody st i rows).runtime) := by
  change ((evalExpr call (fuel+1) (printBody st i rows).runtime (.var "b")).bind
    (fun result=>match result.1 with
      | .pointer a _=>if a.field.isSome then none else
          (AST.read result.2 {a with field:=some name}).bind (fun v=>some (v,result.2))
      | _=>none))=_
  rw [print_body_var_b call fuel]
  simp [AST.read,printBody,printLoop,afterRun,allocate,runCaller,runBuffer,
    List.getElem?_map,hread,hf,hn]

theorem print_pop_body (st : RunState) (i : Nat) (before rows : List (List Nat)) :
    pop (printLoop st i before) (printBody st i rows)=printLoop st i rows := by
  rfl

theorem print_test (call : Call) (st : RunState) (i : Nat) (rows : List (List Nat))
    (hi : i < 2^64) (hc : st.count < 2^64) :
    Main.Eval call (.binary "<" (.var "i") (.var "count"))
      (printLoop st i rows) (printLoop st i rows) (boolean (i < st.count)) := by
  refine ⟨?_,rfl,rfl⟩
  simp only [printLoop]
  simp [lowerExpr,lowerLValue]
  change AST.Eval call (.binary "<" (.var "i") (.var "count")) _ _ _
  apply sqrt_eval_lt_at call 999
  · exact print_var_i call 998 st i rows
  · exact print_var_count call 998 st i rows
  · change some (boolean (i%2^64 < st.count%2^64))=_
    rw [Nat.mod_eq_of_lt hi,Nat.mod_eq_of_lt hc]

theorem print_increment (call : Call) (st : RunState) (i : Nat) (rows : List (List Nat))
    (hi : i+1 < 2^64) :
    Main.Eval call (.unary "++" (.var "i")) (printLoop st i rows)
      (printLoop st (i+1) rows) (word 64 (i+1)) := by
  refine ⟨?_,rfl,rfl⟩
  simp only [printLoop]
  simp [lowerExpr,lowerLValue]
  change AST.Eval call (.unary "++" (.var "i")) _ _ _
  have hl : evalLValue call 999 (printLoop st i rows).runtime (.var "i")=
      some (⟨2,0,none⟩,true,(printLoop st i rows).runtime) := by
    simp [evalLValue,getVar,printLoop,afterRun,allocate,runCaller,mainEnv,List.find?_cons]
  change ((evalLValue call 999 (printLoop st i rows).runtime (.var "i")).bind
    (fun (a,writable,next)=>(AST.read next a).bind (fun old=>
      match old with
      | .word width n=>AST.write next a writable (word width (n+1))
      | _=>none)))=_
  rw [hl]
  change AST.write (printLoop st i rows).runtime ⟨2,0,none⟩ true (word 64 (i%2^64+1))=_
  rw [Nat.mod_eq_of_lt (show i < 2^64 by omega)]
  exact write_allocated_word _ "i" i (i+1)

#print axioms print_field_at
#print axioms print_increment
end LCMSourcePV.Witness.Main
