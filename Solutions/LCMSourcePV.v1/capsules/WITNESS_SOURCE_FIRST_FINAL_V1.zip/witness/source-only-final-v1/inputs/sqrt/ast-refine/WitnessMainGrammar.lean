/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessSourceFiles
import WitnessASTRunFunction
namespace LCMSourcePV.Witness.Main
open LCMSourcePV.Witness.C LCMSourcePV.Witness.AST
set_option maxHeartbeats 0
set_option maxRecDepth 10000

/-- The application main uses two additional C forms: an automatic array and
an eight-uint64 printf. The existing library AST is retained for scalar
expressions and statements. No constructor denotes a whole function body. -/
inductive Stmt where
  | core (body : C.Stmt)
  | array (type name : String) (size : Nat)
  | sequence (body : List Stmt)
  | branch (condition : Expr) (yes : Stmt) (no : Option Stmt)
  | forLoop (initial : C.Stmt) (condition step : Expr) (body : Stmt)
  | printf8 (arguments : List Expr)

/- Ordinary C array-to-pointer conversion in value contexts. Lvalue/address
contexts retain their actual object address. Here only main's declared out
array is admitted; no arbitrary C frontend is claimed. -/
mutual
 def lowerExpr (arrays : List String) : Expr → Expr
  | .var name=>if arrays.contains name then .unary "&" (.var name) else .var name
  | .unary op e=>if op=="&" then .unary op (lowerLValue arrays e)
      else .unary op (lowerExpr arrays e)
  | .post op e=>.post op (lowerLValue arrays e)
  | .binary op a b=>if op=="=" then .binary op (lowerLValue arrays a) (lowerExpr arrays b)
      else .binary op (lowerExpr arrays a) (lowerExpr arrays b)
  | .cast type e=>.cast type (lowerExpr arrays e)
  | .field op e f=>.field op (lowerExpr arrays e) f
  | .index a i=>.index (lowerExpr arrays a) (lowerExpr arrays i)
  | .call f args=>.call f (args.map (lowerExpr arrays))
  | .record es=>.record (es.map (lowerExpr arrays))
  | .nat n=>.nat n
 def lowerLValue (arrays : List String) : Expr → Expr
  | .var name=>.var name
  | .unary op e=>if op=="*" then .unary op (lowerExpr arrays e) else .unary op e
  | .field op e f=>.field op (lowerExpr arrays e) f
  | .index a i=>.index (lowerExpr arrays a) (lowerExpr arrays i)
  | .nat n=>.nat n
  | .post op e=>.post op e
  | .cast type e=>.cast type e
  | .binary op a b=>.binary op a b
  | .call f args=>.call f args
  | .record es=>.record es
end

def lowerDecl (arrays : List String) (d : Decl) : Decl :=
  {d with value:=d.value.map (lowerExpr arrays)}
def lowerStmt (arrays : List String) : C.Stmt → C.Stmt
  | .skip=>.skip
  | .declare ds=>.declare (ds.map (lowerDecl arrays))
  | .eval e=>.eval (lowerExpr arrays e)
  | .returnStmt e=>.returnStmt (lowerExpr arrays e)
  | .branch e a b=>.branch (lowerExpr arrays e) (lowerStmt arrays a) (lowerStmt arrays b)
  | .sequence xs=>.sequence (xs.map (lowerStmt arrays))
  | .forLoop init cond step body=>.forLoop (lowerStmt arrays init)
      (cond.map (lowerExpr arrays)) (lowerExpr arrays step) (lowerStmt arrays body)
  | .whileLoop cond body=>.whileLoop (lowerExpr arrays cond) (lowerStmt arrays body)

def printfFormat8 : String := "\"%\" PRIu64 \",%\" PRIu64 \",%\" PRIu64 \",%\" PRIu64 \",%\" PRIu64 \",%\" PRIu64 \",%\" PRIu64 \",%\" PRIu64 \"\\n\""

def parenthesize (outer inner : Nat) (text : String) : String :=
  if inner < outer then "("++text++")" else text

def binaryPrecedence (op : String) : Nat :=
  if op="," then 1 else if op="=" then 2 else if op="||" then 3 else
  if op="&&" then 4 else if op="==" || op="!=" then 8 else
  if ["<",">","<=",">="].contains op then 9 else if op="+" || op="-" then 12 else 13

def renderMainExpr : Nat → Nat → Expr → Option String
  | 0,_,_=>none
  | k+1,prec,.nat n=>some (toString n)
  | k+1,prec,.var name=>some name
  | k+1,prec,.unary op e=>do
      return parenthesize prec 14 (op++(←renderMainExpr k 14 e))
  | k+1,prec,.post op e=>do
      return parenthesize prec 15 ((←renderMainExpr k 15 e)++op)
  | k+1,prec,.binary op a b=>do
      let p:=binaryPrecedence op
      return parenthesize prec p ((←renderMainExpr k p a)++op++(←renderMainExpr k (p+1) b))
  | k+1,prec,.index base i=>do
      return parenthesize prec 15 ((←renderMainExpr k 15 base)++"["++(←renderMainExpr k 0 i)++"]")
  | k+1,prec,.field op e name=>do
      return parenthesize prec 15 ((←renderMainExpr k 15 e)++op++name)
  | k+1,prec,.call f args=>do
      return parenthesize prec 15 ((←renderMainExpr k 15 f)++"("++
        join (←args.mapM (renderMainExpr k 2))++")")
  | k+1,prec,.cast type e=>do
      return parenthesize prec 14 ("("++type++")"++(←renderMainExpr k 14 e))
  | k+1,prec,.record es=>do
      return "{"++join (←es.mapM (renderMainExpr k 2))++"}"

def renderMainDecl (d : Decl) : Option String := do
  let suffix←match d.value with
    | none=>some ""
    | some e=>(fun x=>"="++x) <$> renderMainExpr 1000 2 e
  return d.type++" "++d.name++suffix

def renderMainCore : C.Stmt → Option String
  | .declare ds=>do
      return String.intercalate "\n" ((←ds.mapM renderMainDecl).map (·++";"))
  | .returnStmt e=>do return "return "++(←renderMainExpr 1000 0 e)++";"
  | .eval e=>do return (←renderMainExpr 1000 0 e)++";"
  | .skip=>some ";"
  | body=>C.renderStmt 1000 body

def renderStmt : Nat → Stmt → Option String
  | 0,_=>none
  | k+1,.core body=>renderMainCore body
  | k+1,.array type name n=>some (type++" "++name++"["++toString n++"];" )
  | k+1,.sequence xs=>do
      return "{"++String.intercalate "\n" (←xs.mapM (renderStmt k))++"}"
  | k+1,.branch cond yes no=>do
      let head:="if("++(←renderMainExpr 1000 0 cond)++")"++(←renderStmt k yes)
      match no with
      | none=>return head
      | some other=>return head++"else "++(←renderStmt k other)
  | k+1,.forLoop init cond step body=>do
      return "for("++(←renderMainCore init)++(←renderMainExpr 1000 0 cond)++";"++
        (←renderMainExpr 1000 0 step)++")"++(←renderStmt k body)
  | k+1,.printf8 args=>do
      return "printf("++printfFormat8++","++join (←args.mapM (renderMainExpr 1000 2))++");"

def mainPrintArgs : List Expr :=
  ["lo","hi","p0","p1","p2","q0","q1","q2"].map (fun field=>.field "->" (.var "b") field)
def mainPrintBody : Stmt := .sequence [
  .core (.declare [⟨"const Block*","b",some (.unary "&" (.index (.var "out") (.var "i")))⟩]),
  .printf8 mainPrintArgs]
def mainAST : Stmt := .sequence [
  .array "Block" "out" 1024,
  .core (.declare [⟨"U","count",none⟩]),
  .branch (.unary "!" (.call (.var "run_exact") [.var "out",.unary "&" (.var "count")]))
    (.core (.returnStmt (.nat 1))) none,
  .forLoop (.declare [⟨"U","i",some (.nat 0)⟩])
    (.binary "<" (.var "i") (.var "count")) (.unary "++" (.var "i")) mainPrintBody,
  .core (.returnStmt (.nat 0))]
def renderMain (s : Stmt) : Option String := do
  return "int main()"++(←renderStmt 1000 s)++"\n"

theorem main_source_corresponds :
    LCMSourcePV.RestrictedC.SourceCorresponds renderMain C.actualMain mainAST := by
  refine ⟨(renderMain mainAST).getD "",?_,?_,?_⟩ <;> decide

#print axioms main_source_corresponds
end LCMSourcePV.Witness.Main
