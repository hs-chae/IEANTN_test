/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTFrames
import WitnessASTLocals
import WitnessASTContracts
namespace LCMSourcePV.Witness.AST
open LCMSourcePV.Witness.C
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024

def sqrtCell (n : Nat) : Object := ⟨"U",[some (word 64 n)]⟩
def sqrtFrame (s : State) (n lo hi : Nat) : State :=
  ⟨s.heap++[sqrtCell n,sqrtCell lo,sqrtCell hi],
   [("hi",⟨s.heap.length+2,0,none⟩),("lo",⟨s.heap.length+1,0,none⟩),
    ("n",⟨s.heap.length,0,none⟩)]⟩
def sqrtMidFrame (s : State) (n lo hi mid : Nat) : State :=
  allocate (sqrtFrame s n lo hi) "U" "mid" (some (word 64 mid))

theorem sqrt_frame_var (call : Call) (fuel : Nat) (s : State) (n lo hi : Nat) :
    evalExpr call (fuel+1) (sqrtFrame s n lo hi) (.var "n")=
        some (word 64 n,sqrtFrame s n lo hi) ∧
    evalExpr call (fuel+1) (sqrtFrame s n lo hi) (.var "lo")=
        some (word 64 lo,sqrtFrame s n lo hi) ∧
    evalExpr call (fuel+1) (sqrtFrame s n lo hi) (.var "hi")=
        some (word 64 hi,sqrtFrame s n lo hi) := by
  simp (disch:=omega) [evalExpr,getVar,sqrtFrame,read,sqrtCell,List.getElem?_append,List.getElem?_cons,List.find?_cons]

theorem sqrt_midframe_var (call : Call) (fuel : Nat) (s : State) (n lo hi mid : Nat) :
    evalExpr call (fuel+1) (sqrtMidFrame s n lo hi mid) (.var "n")=
        some (word 64 n,sqrtMidFrame s n lo hi mid) ∧
    evalExpr call (fuel+1) (sqrtMidFrame s n lo hi mid) (.var "lo")=
        some (word 64 lo,sqrtMidFrame s n lo hi mid) ∧
    evalExpr call (fuel+1) (sqrtMidFrame s n lo hi mid) (.var "hi")=
        some (word 64 hi,sqrtMidFrame s n lo hi mid) ∧
    evalExpr call (fuel+1) (sqrtMidFrame s n lo hi mid) (.var "mid")=
        some (word 64 mid,sqrtMidFrame s n lo hi mid) := by
  simp (disch:=omega) [evalExpr,getVar,sqrtMidFrame,sqrtFrame,allocate,read,sqrtCell,
    List.getElem?_append,List.getElem?_cons,List.find?_cons,List.append_assoc]

theorem sqrt_midframe_lvalue (call : Call) (fuel : Nat) (s : State) (n lo hi mid : Nat) :
    evalLValue call (fuel+1) (sqrtMidFrame s n lo hi mid) (.var "lo")=
        some (⟨s.heap.length+1,0,none⟩,true,sqrtMidFrame s n lo hi mid) ∧
    evalLValue call (fuel+1) (sqrtMidFrame s n lo hi mid) (.var "hi")=
        some (⟨s.heap.length+2,0,none⟩,true,sqrtMidFrame s n lo hi mid) := by
  simp [evalLValue,getVar,sqrtMidFrame,sqrtFrame,allocate]

theorem sqrt_write_lo (s : State) (n lo hi mid value : Nat) :
    write (sqrtMidFrame s n lo hi mid) ⟨s.heap.length+1,0,none⟩ true (word 64 value)=
      some (word 64 value,sqrtMidFrame s n value hi mid) := by
  have h : (sqrtMidFrame s n lo hi mid).heap[s.heap.length+1]?=
      some (sqrtCell lo) := by
    simp (disch:=omega) [sqrtMidFrame,sqrtFrame,allocate,List.getElem?_append,List.getElem?_cons,List.find?_cons]
  rw [write_scalar _ _ _ _ h]
  congr 1
  simp (disch:=omega) [sqrtMidFrame,sqrtFrame,allocate,sqrtCell,List.set_append,
    List.append_assoc]

theorem sqrt_write_hi (s : State) (n lo hi mid value : Nat) :
    write (sqrtMidFrame s n lo hi mid) ⟨s.heap.length+2,0,none⟩ true (word 64 value)=
      some (word 64 value,sqrtMidFrame s n lo value mid) := by
  have h : (sqrtMidFrame s n lo hi mid).heap[s.heap.length+2]?=
      some (sqrtCell hi) := by
    simp (disch:=omega) [sqrtMidFrame,sqrtFrame,allocate,List.getElem?_append,List.getElem?_cons,List.find?_cons]
  rw [write_scalar _ _ _ _ h]
  congr 1
  simp (disch:=omega) [sqrtMidFrame,sqrtFrame,allocate,sqrtCell,List.set_append,
    List.append_assoc]

theorem sqrt_pop_mid (s : State) (n lo hi lo' hi' mid : Nat) :
    popScope (sqrtFrame s n lo hi) (sqrtMidFrame s n lo' hi' mid)=sqrtFrame s n lo' hi' := by
  simp [popScope,sqrtFrame,sqrtMidFrame,allocate,List.append_assoc,List.take_append]

theorem sqrt_pop_frame (s : State) (n lo hi : Nat) :
    popScope s (sqrtFrame s n lo hi)=s := by
  cases s
  simp [popScope,sqrtFrame,List.take_append]

#print axioms sqrt_write_lo
#print axioms sqrt_pop_mid
end LCMSourcePV.Witness.AST
