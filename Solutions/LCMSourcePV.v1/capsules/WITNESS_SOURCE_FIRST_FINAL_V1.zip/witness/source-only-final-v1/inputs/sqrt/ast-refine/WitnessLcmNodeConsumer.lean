/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import IEANTN.Nodes.Lcm.v1.Conclusions
import E1TwoTracks.TrackBExactProgram
namespace LCMSourcePV.Network
open ArithmeticFunction
set_option maxHeartbeats 0

theorem not_highlyAbundant_81000 (hd : Dusart2018.v1.proposition_5_4) :
    ∀n:Nat,81000 ≤ n → ¬Lcm.v1.HighlyAbundant (Nat.lcmUpto n) := by
  intro n hn high
  obtain ⟨m,hm,hgain⟩:=E1TwoTracks.TrackB.exactQuantitative hd n hn
  have hsmall : (sigma 1 m:ℝ) < (sigma 1 (Nat.lcmUpto n):ℝ) := by
    exact_mod_cast high m hm
  have hs : (0:ℝ) ≤ sigma 1 (Nat.lcmUpto n) := Nat.cast_nonneg _
  have hc : (0:ℝ) ≤ 1/(10*(n:ℝ)) := div_nonneg (by norm_num)
    (mul_nonneg (by norm_num) (Nat.cast_nonneg _))
  nlinarith

/-- Actual existing Lcm.v1 conditional conclusion, supplied by the stronger
source-first finite81000 constructor plus the unchanged Dusart analytic tail.
No node/core statement or formalization metadata is changed. -/
theorem lcm_v1_source_first (dusart2018_v1_proposition_5_4 : Dusart2018.v1.proposition_5_4) :
    Lcm.v1.lcmUpto_not_highlyAbundant := by
  intro n hn
  exact not_highlyAbundant_81000 dusart2018_v1_proposition_5_4 n (by omega)

#print axioms not_highlyAbundant_81000
#print axioms lcm_v1_source_first
end LCMSourcePV.Network
