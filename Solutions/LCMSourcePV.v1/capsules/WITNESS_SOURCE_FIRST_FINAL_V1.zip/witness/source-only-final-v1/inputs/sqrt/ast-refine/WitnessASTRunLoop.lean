/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTRunStep
namespace LCMSourcePV.Witness.AST
open E1TwoTracks.TrackB LCMSourcePV.Witness.C LCMSourcePV.RestrictedC LCMSourcePV.ASTLoops
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option exponentiation.threshold 1024
set_option linter.unusedSimpArgs false

theorem run_for_ast (call : Call) (hm : MakeRunContract call)
    {st final : RunState} (trace : RunFor st final) (hs : RunRep st) :
    ForRun call (some runLoopCond) (.unary "++" (.var "fuel")) runIteration
      (runFrame st) (.returned (runFrame final) (word 1 1)) := by
  revert hs
  induction trace with
  | done st hloop hstop=>
    intro hs
    apply ForRun.returned
    · have hg:=GuardRun.present (truth:=truth) (run_loop_test call st hs)
      simpa [truth,boolean,word,hloop] using hg
    · exact run_iteration_done call st hs hstop
  | step st next final b hloop hstop hmTrace hstore rest ih=>
    intro hs
    have he:=run_store_equations hstore hs
    have hn:=run_store_rep hstore hs
    have hnb : RunRep (runNextWithoutFuel st b) := by
      rw [he.2] at hn
      exact ⟨hn.1,hn.2.1,hs.2.2.1,hn.2.2.2⟩
    apply ForRun.next (c:=runFrame next) (value:=word 64 ((st.loopIndex+1)%2^64))
    · have hg:=GuardRun.present (truth:=truth) (run_loop_test call st hs)
      simpa [truth,boolean,word,hloop] using hg
    · exact run_iteration_step call hm st b hs hstop he.1 hmTrace
    · have hi:=run_increment call (runNextWithoutFuel st b) hnb
      rw [he.2]
      exact hi
    · exact ih hn

#print axioms run_for_ast
end LCMSourcePV.Witness.AST
