/-
Copyright (c) 2026 IEANTN contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: OpenAI (Codex)
-/
import WitnessASTRunFrame
namespace LCMSourcePV.Witness.AST
open E1TwoTracks.TrackB LCMSourcePV.Witness.C LCMSourcePV.RestrictedC
set_option maxHeartbeats 0
set_option maxRecDepth 10000
set_option linter.unusedSimpArgs false

theorem run_check_rep {b : Block} {r : Bool} (h : CheckExec b r) : BlockRep b := by
  cases h <;> assumption

theorem run_shrink_rep {limit k : Nat} {b out : Block} (h : ShrinkFor limit k b out) :
    BlockRep out := by
  induction h with
  | hit k b hc => exact run_check_rep hc
  | step k b out hc hf hhi hk rest ih=>exact ih

theorem run_choose0_rep {pf ff total lo stop p0 p1 p2 q1 q2 k top : Nat}
    {res : Option Block} (h : Choose0For pf ff total lo stop p0 p1 p2 q1 q2 k top res) :
    ∀b,res=some b → BlockRep b := by
  induction h with
  | done k top hg=>intro b he;cases he
  | hit k top q0 out hg hp ht hf=>intro b he;cases he;exact run_shrink_rep hf
  | skip k top q0 out hg hp ht hk rest ih=>exact ih

theorem run_choose1_rep {pf ff q0f total lo stop p0 p1 p2 q2 k top : Nat}
    {res : Option Block} (h : Choose1For pf ff q0f total lo stop p0 p1 p2 q2 k top res) :
    ∀b,res=some b → BlockRep b := by
  induction h with
  | hit k top q1 out hg hp hc=>exact run_choose0_rep hc
  | skip k top q1 out hg hp hc hk rest ih=>exact ih

theorem run_make_rep {pf ff q0f q1f lo stop : Nat} {out : Block}
    (h : MakeExec pf ff q0f q1f lo stop out) : BlockRep out := by
  cases h with
  | success p0 p1 p2 q2 root out hr h0 h1 h2 hq hc=>exact run_choose1_rep hc out rfl

theorem run_store_rep {st next : RunState} {b : Block}
    (h : storeBlock st b=some next) (hs : RunRep st) : RunRep next := by
  unfold storeBlock at h
  split at h
  · cases h
    refine ⟨?_,?_,?_,?_⟩
    · exact Nat.mod_lt _ (by decide)
    · exact Nat.mod_lt _ (by decide)
    · exact Nat.mod_lt _ (by decide)
    · simpa using hs.2.2.2
  · cases h

#print axioms run_make_rep
#print axioms run_store_rep
end LCMSourcePV.Witness.AST
