#!/usr/bin/env python3
"""Independent strict readback of every source, proof child and C output word."""
import argparse,hashlib,json,pathlib,os,tempfile
S=pathlib.Path(__file__).resolve().parent
ALLOW={'propext','Classical.choice','Quot.sound'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate JSON key '+k)
  d[k]=v
 return d
def load(p):return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in()).throw(ValueError(v)))
def atomic(p,d):
 fd,name=tempfile.mkstemp(prefix='.strict-',dir=p.parent)
 with os.fdopen(fd,'w')as f:json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 pathlib.Path(name).replace(p)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--replay',type=pathlib.Path,required=True);ap.add_argument('--out',type=pathlib.Path,required=True);a=ap.parse_args()
 replay=a.replay.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
 lock=load(S/'SOURCE_LOCK.json');r=load(replay/'RECEIPT.json')
 if r['status']!='FULL_SOURCE_COLD_AND_NATIVE404_PASS'or r['source_lock_sha256']!=sha(S/'SOURCE_LOCK.json')or r['objects_initially_empty']is not True or r['application_cache_input']is not False:raise ValueError('provenance/status')
 if r['reproducer_sha256']!=sha(S/'reproduce_v2.py')or r['axiom_template_sha256']!=sha(S/'ALL_THEOREM_AUDIT.lean.in'):raise ValueError('validator source identity')
 if r['targets']!=lock['targets']:raise ValueError('target population')
 for row in lock['files']:
  p=S/row['path']
  if not p.is_file()or p.stat().st_size!=row['bytes']or sha(p)!=row['sha256']:raise ValueError('source readback '+row['path'])
 modules={row['module']:row for row in lock['modules']}
 if r['source_modules']!=len(modules)or len(r['records'])!=len(modules):raise ValueError('proof child population')
 seen=set()
 for row in r['records']:
  m=row['module']
  if m not in modules or m in seen or row['exit_code']!=0 or row['source_sha256']!=modules[m]['sha256']:raise ValueError('child identity/result '+m)
  seen.add(m);obj=replay/'objects'/pathlib.Path(m.replace('.','/')).with_suffix('.olean');so=replay/'logs'/(m+'.stdout');se=replay/'logs'/(m+'.stderr')
  if sha(obj)!=row['object_sha256']or sha(so)!=row['stdout_sha256']or sha(se)!=row['stderr_sha256']:raise ValueError('child artifact drift '+m)
  text=so.read_text()+'\n'+se.read_text()
  if 'sorryAx'in text or 'Lean.ofReduceBool'in text:raise ValueError('prohibited proof mechanism '+m)
 if seen!=set(modules):raise ValueError('missing active child')
 audit=load(replay/'THEOREM_AXIOMS.json')
 if audit['status']!='ALL_APPLICATION_THEOREMS_STD3_PASS'or audit['modules']!=sorted(modules)or not audit['rows']or r['all_theorem_count']!=len(audit['rows']):raise ValueError('compiler theorem population')
 if r['all_theorem_audit']['exit_code']!=0 or r['all_theorem_audit']['receipt_sha256']!=sha(replay/'THEOREM_AXIOMS.json')or r['all_theorem_audit']['generated_source_sha256']!=sha(replay/'WitnessFullAxiomAudit.lean'):raise ValueError('all-theorem audit artifact identity')
 identities=set()
 for row in audit['rows']:
  key=(row['module'],row['declaration'])
  if row['module']not in modules or not row['declaration']or key in identities or any(x not in ALLOW for x in row['axioms']):raise ValueError('theorem compiler identity/axiom policy')
  identities.add(key)
 required=['LCMSourcePV.Witness.AST.fixed_constructor_actual_call_tree','LCMSourcePV.Witness.AST.spec_source_coherent','LCMSourcePV.Witness.Main.exactFinite','LCMSourcePV.Witness.Main.decoded_output_cover','LCMSourcePV.Network.not_highlyAbundant_81000','LCMSourcePV.Network.lcm_v1_source_first','LCMSourcePV.Witness.AST.NativeFixture.actual_stdout_rows_match_fixture']
 all_decls={x[1]for x in identities}
 if any(x not in all_decls for x in required):raise ValueError('missing mandatory full source/native/math target')
 rows=load(S/'inputs/witness/evidence/constructor_output_v1.json');expected=(''.join(','.join(map(str,row))+'\n'for row in rows)).encode();stream=replay/'actual404.csv';binary=replay/'witness_constructor'
 if len(rows)!=404 or any(len(row)!=8 for row in rows)or stream.read_bytes()!=expected or r['native_words']!=3232 or r['native_rows']!=404:raise ValueError('actual404x8 output mismatch')
 if sha(stream)!=r['native_output_sha256']or sha(binary)!=r['native_binary_sha256']:raise ValueError('native artifact drift')
 if len(r['native'])!=2 or {x['role']for x in r['native']}!={'build','run'}or any(x['exit_code']!=0 for x in r['native']):raise ValueError('native child routes')
 for row in r['native']:
  label=row['role'];stdout=stream if label=='run'else replay/'native-build.stdout';stderr=replay/('native-'+label+'.stderr')
  if sha(stdout)!=row['stdout_sha256']or sha(stderr)!=row['stderr_sha256']:raise ValueError('native command/log readback')
  if label=='build'and str(S/'inputs/witness/source/witness_verified_unit.c')not in row['command']:raise ValueError('wrong source build')
  if label=='run'and row['command']!=[str(binary)]:raise ValueError('wrong native executable')
 result=dict(status='FINAL_STRICT_WITNESS_SOURCE_ONLY_PASS',source_lock_sha256=sha(S/'SOURCE_LOCK.json'),producer_receipt_sha256=sha(replay/'RECEIPT.json'),auditor_sha256=sha(pathlib.Path(__file__)),all_application_source_modules=len(modules),all_compiler_theorem_identities=len(identities),native_rows=404,native_words=3232,all_source_children_and_output_words_read_back=True,application_cache_input=False,mandatory_targets=required,axiom_policy=sorted(ALLOW),physical_boundary=r['physical_boundary'])
 atomic(out/'STRICT_RECEIPT.json',result);print('FINAL_STRICT_WITNESS_SOURCE_ONLY_PASS')
if __name__=='__main__':main()
