# Start here: corrected portable replay

The Lean, C, certificate data, parameters and SOURCE_LOCK.json are unchanged. Use `reproduce_v2.py` and `audit_replay_v2.py` for a fresh replay:

```sh
python3 reproduce_v2.py --environment /absolute/prepared/ENVIRONMENT.json --out /fresh/witness-proof --jobs 16
python3 audit_replay_v2.py --replay /fresh/witness-proof --out /fresh/witness-strict
```

The public generic preparer uses its default eight-dependency profile for this component; PrimeCover uses its separate nine-dependency profile. No application cache is an input to a fresh replay. Use the release's existing namespace wrapper for the final isolated procedure. The replay creates its own fresh temporary directory. The observed resource profile is 256 GiB, 24 CPUs and 16 single-threaded Lean children; a single source-binding child used about 24 GiB RSS, so adjust concurrency to available memory.

The only producer-v2 change is an explicit Lean root argument for its generated axiom-audit file. This permits the fresh output directory to sit outside the source directory, including in the original namespace sandbox. `RECIPE_PATCH_V2.json` gives the exact one-command-argument patch. The original `reproduce.py`, `audit_replay.py` and README.md remain unchanged as historical evidence.

The authoritative final verification has two actual namespace stages. The first freshly compiled all 1164 application modules, then its auxiliary audit launcher rejected the generated file because the root argument was absent. The continuation checks every source/object/log/exit result and all original namespace pins, reuses only those owned outputs read-only, performs the corrected all-theorem audit, rebuilds/runs the real C404 constructor, and invokes the exact original strict auditor. It does not claim a second fresh source compilation. All 56282 theorem compiler identities pass the standard-axiom gate and all 3232 native output words match the kernel-bound source-main rows. Final independent namespace readback receipts accompany the release.

The continuation script is retained for evidence reproduction; it requires the recorded same-campaign checkpoint, namespace metadata and origin pins. It is not needed for a new clean replay with the corrected producer-v2 commands. The source-call proof and mathematical consumer are described in the historical README; its old generated-audit launcher is superseded by producer-v2.
