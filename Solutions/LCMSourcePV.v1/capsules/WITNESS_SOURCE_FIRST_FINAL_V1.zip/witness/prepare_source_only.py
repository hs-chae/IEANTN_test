#!/usr/bin/env python3
"""Freeze the exact application-source closure; never copies application objects."""
import argparse,hashlib,json,pathlib,re,shutil
R=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def imports(p):
    found=[]
    for line in p.read_text().splitlines():
        text=line.strip().split('--',1)[0].strip()
        if text.startswith('public import '):text=text[7:]
        if not text.startswith('import '):continue
        names=text[7:].split()
        if not names or any(not re.fullmatch(r'[A-Za-z0-9_.]+',n)for n in names):raise ValueError('unsupported import '+str(p))
        found.extend(names)
    return found

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=pathlib.Path,required=True);ap.add_argument('--environment',type=pathlib.Path,required=True);ap.add_argument('--targets',nargs='+',required=True);ap.add_argument('--extra-root',type=pathlib.Path,action='append',default=[]);a=ap.parse_args()
    out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    e=json.loads(a.environment.read_text())
    roots=[R/p for p in ['primecover/witness-refinement/lean','sqrt/ast-refine','witness/lean','overlay','lean','primecover/lean','primes/source','network','primecover/source-only-v2/lean']]+[p.resolve()for p in a.extra_root]
    generic=[pathlib.Path(x['library'])for x in e['generic_dependencies']]+[pathlib.Path(e['compiler']).resolve().parent.parent/'lib/lean']
    chosen={};external=set();deps={};alternatives={}
    def visit(m):
        if m in chosen or m in external:return
        rel=pathlib.Path(m.replace('.','/')).with_suffix('.lean');candidates=[root/rel for root in roots if(root/rel).is_file()]
        if not candidates:
            obj=rel.with_suffix('.olean')
            if not any((g/obj).is_file()for g in generic):raise ValueError('missing source/non-generic import '+m)
            external.add(m);return
        src=candidates[0];chosen[m]=src
        alternatives[m]=[dict(path=str(p),sha256=sha(p),selected=i==0)for i,p in enumerate(candidates)]
        deps[m]=imports(src)
        for dep in deps[m]:visit(dep)
    for m in a.targets:visit(m)
    copied={};modules=[]
    def copy_original(src):
        src=src.resolve()
        try:rel=src.relative_to(R)
        except ValueError:raise ValueError('extra source root outside current campaign requires explicit portable mapping '+str(src))
        dest=out/'inputs'/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists()and sha(dest)!=sha(src):raise ValueError('copy target collision')
        if not dest.exists():shutil.copyfile(src,dest)
        copied[str(dest.relative_to(out))]=dict(path=str(dest.relative_to(out)),bytes=dest.stat().st_size,sha256=sha(dest),original=str(src),original_sha256=sha(src))
        return dest
    for m,src in sorted(chosen.items()):
        dest=copy_original(src)
        original_root=next(root for root in roots if (root/pathlib.Path(m.replace('.','/')).with_suffix('.lean'))==src)
        modules.append(dict(module=m,path=str(dest.relative_to(out)),root=str((out/'inputs'/original_root.relative_to(R)).relative_to(out)),sha256=sha(dest),imports=deps[m],alternatives=alternatives[m]))
        for match in re.finditer(r'include_str\s+((?:"[^"\n]*"\s*(?:/\s*)?)+)',src.read_text()):
            parts=re.findall(r'"([^"\n]*)"',match[1]);asset=src.parent.joinpath(*parts).resolve()
            if not asset.is_file():raise ValueError('missing include_str asset '+str(asset))
            target=copy_original(asset)
            expected=dest.parent.joinpath(*parts).resolve()
            if expected!=target:raise ValueError('relative include_str mapping changed')
    source=R/'witness/source'
    for p in sorted(source.rglob('*')):
        if p.is_file()and p.suffix in {'.c','.h','.inc'}:copy_original(p)
    fixture=R/'witness/evidence/constructor_output_v1.json';copy_original(fixture)
    shutil.copyfile(a.environment,out/'ENVIRONMENT.json')
    pins=[dict(name=x['name'],revision=x['revision'])for x in e['generic_dependencies']]
    lock=dict(schema='witness-full-source-only-v1',targets=a.targets,modules=modules,files=sorted(copied.values(),key=lambda x:x['path']),external_generic_imports=sorted(external),compiler_sha256=sha(pathlib.Path(e['compiler'])),clang_sha256=sha(pathlib.Path(e['clang'])),generic_dependencies=pins,environment_sha256=sha(out/'ENVIRONMENT.json'),source_selection='Explicit ordered source roots, exact transitive imports of final targets; only compiler/public generic dependencies excluded. This is not an all-source/external-claim attribution census.',source_priority=[str(p)for p in roots],application_objects_in_capsule=False)
    (out/'SOURCE_LOCK.json').write_text(json.dumps(lock,indent=2)+'\n')
    print(json.dumps(dict(status='SOURCE_FREEZE_PREPARED',modules=len(modules),files=len(copied),source_lock_sha256=sha(out/'SOURCE_LOCK.json'))))
if __name__=='__main__':main()
