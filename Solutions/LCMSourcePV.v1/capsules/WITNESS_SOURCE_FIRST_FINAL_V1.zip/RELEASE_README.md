# Witness source-first LCM release

Extract the archive into a new directory. Its R-relative layout is deliberate:
the proof source capsule is `witness/source-only-final-v1` and the shared public generic setup is
`adaptive/source-only-v1`. Read `witness/source-only-final-v1/README_v2.md`.
The original recipes and failed-stage evidence remain historical records.

For an existing pinned public Lean/Mathlib installation, emit component-specific
metadata (eight dependencies for Witness, nine including Cli for PrimeCover):

    python3 adaptive/source-only-v1/prepare_environment.py --component witness --toolchain /absolute/lean-4.34.0-rc2-linux --mathlib /absolute/mathlib --out /fresh/generic-witness.json

For a fresh public installation first use the pinned recipe:

    python3 adaptive/source-only-v1/generic_environment/scripts/bootstrap.py --work /fresh/public-generic --receipt /fresh/public-bootstrap.json

Then use that installation's actual toolchain/Mathlib paths in the preparer above.
No old application objects are required or included. Keep replay outputs outside
the source capsule. From `witness/source-only-final-v1` run:

    python3 reproduce_v2.py --environment /fresh/generic-witness.json --out /fresh/witness-proof --jobs 16
    python3 audit_replay_v2.py --replay /fresh/witness-proof --out /fresh/witness-strict

These are portable host replay commands. Final isolation additionally uses the
preserved original namespace helper/SPEC; do not describe direct host execution
as isolated verification. The accepted evidence is explicit about the two-stage
Witness source compilation/audit continuation and the PrimeCover post-success
receipt-filename finalization. Neither failed original outer exit is erased.

The kernel proves application source/AST/execution/output/mathematical closure.
Pinned compiler/runtime/unsigned ABI and successful physical standard I/O remain
the approved generic trust boundary. The analytic tail retains its unchanged
explicit Dusart 2018 Proposition 5.4 source input. No optimality, physical-I/O
infallibility or verified machine-code compiler claim is made.

`MANIFEST.json` pins every other archive member. The included sealer can repeat
complete source-selection/member-hash readback when placed at its original
`primecover/seal_component_archive.py` path in the extracted R-relative tree.
