#!/bin/bash
# Non-login bash; run once in a fresh assigned /work. Exact commands and streams.
cd /work/submission || exit 1
unset PYTHONOPTIMIZE
export PYTHONDONTWRITEBYTECODE=1
if ! test -d /work/review-input; then
 /usr/bin/python3.10 /task/RESTORE_CANDIDATE.py --out /work/review-input || exit 1
fi
cd /work/review-input || exit 1
{ for cmd in '/usr/bin/g++ -O3 -std=c++17 count.cpp -o /work/review-count' '/work/review-count' '/usr/bin/python3.10 analytic.py' '/usr/bin/python3.10 ramanujan.py' '/usr/bin/python3.10 mertens.py' '/usr/bin/python3.10 mertens.py scan'; do
 printf '\nCOMMAND: %s\n' "$cmd"; eval "$cmd"; printf 'EXIT: %s\n' "$?"
done; } >/work/submission/replay.stdout 2>/work/submission/replay.stderr
cd /work/submission || exit 1
export PYTHONPATH=/work/review-input
/usr/bin/python3.10 extra_checks.py >extra.stdout 2>extra.stderr; printf '%s\n' "$?" >extra.exit
/usr/bin/python3.10 ablation.py >ablation.stdout 2>ablation.stderr; printf '%s\n' "$?" >ablation.exit
