# Own C006 source and computation-tier clarification

## What the frozen original source states

Let C(x) = Σ(n ≤ x) Λ(n)/n − (log x − γ), and let L = log x. CH2, original PDF p. 35, Lemma 9.2, display (9.1), literally states the UNSCALED inequality

    −0.7585825520… ≤ C(x) ≤ 0.787…    for 1 ≤ x ≤ 10¹² + 3.

The immediately following proof on p. 35 explicitly says it computes √x · C(x) directly for x ≤ 10¹⁰, and uses the harmonic-adjusted expression times √x for larger x, with the displayed O*(1/x) correction. It reports finite extrema and says the extrema for [1, 10¹² + 3] occur within [1, 10¹⁰]. This is the recoverable published NORMALIZED finite-computation passage; distinguish it from the unscaled displayed statement. CH2 p. 36, proof of Corollary 1.3, invokes the stronger Lemma 9.2 bounds below its large cutoff. Corollary 1.3 itself, original PDF p. 3, states for every x ≥ 1 that

    |C(x)| ≤ π/(3 · 10¹²) + 113.67/√x.

These are existing frozen source claims and published computations, not new computations or premises supplied by this feedback. This note supplies neither an independent reconstruction nor source-first program verification of CH2's finite computation.

Frozen source locators: CH2.txt physical LF 5666–5682 (Lemma/display), 5684–5716 (normalized-computation proof passage), 5723–5762 (Corollary 1.3 proof), and 250–264 (Corollary 1.3 statement). PDF p. 35 and p. 36 take precedence over text layout.

## The exact own use requiring correction

Your locked mertens-proof.md physical LF 95 calls .8/√x a “Lemma 9.2 improvement.” Your locked mertens.py physical LF 16–18 sets the ordinary Corollary 1.3 bound w and then wcap = min(w, .8 exp(−L/2)). Its actual operative range is 13 ≤ L ≤ 27.6 < log(10¹² + 3), inside the conservative finite range just identified. Physical LF 51–58 then propagates that cap through d, dm, jw, zp and zm. In particular, the signed-envelope sharpening and the fourth-component .175/L² ray from L = 16 use the normalized finite-computation input.

The literal unscaled display (9.1) alone does not imply |C(x)| ≤ .8/√x. Correct the precise source attribution, operative range and inherited published-computation trust, with the original displayed formula and proof passage clearly separated. Alternatively retire exactly the optional normalized sharpening and any dependent statement that cannot be established at the retained source tier. Do not introduce a new numerical assumption or treat advice from this note as a premise.

## Preserve the valid floor and original evidence

Keep all unrelated valid Ramanujan and Mertens conclusions and their original domains. The literal-display-only sensitivity calculation retains the first three .185/L³ bounds from L = 16, all later polynomial rows, power rays and all Ramanujan results. Its one failed sufficient certificate cell for the fourth .175/L² row is not a counterexample to that row. Preserve that distinction and the raw sensitivity evidence. No new constant, algorithm, numerical certificate or core proof is supplied here.

This is an explicit own-source clarification supplement to your original completed M review. All 15 original M payloads, including review.json and review.md, are preserved byte-for-byte. The supplement is not a new independent M session, a retroactive change to its raw verdicts, or another subject's solution. Submit the corrected complete own portfolio for the same D01 stage and subsequent full re-review; retain original research and review evidence separately.

## Written-source identity pins

- CH2.pdf SHA256 558f33421d8cbd31c969434c065375836dace5fa7248358542d7691c03138e31
- CH2.txt SHA256 a70bfda18e7efbde379d202c1db98e8c1fb2c918310efe874f72ea390730dba8
- mertens-proof.md SHA256 7e04783cf309c074f2812bf281fa51ab1fdf8693c2e6f32a5a51e257a433a273
- mertens.py SHA256 233948c390da8d85a8aa336c94011184091b9bd87e2683785d5078018feab616
- original candidate LOCK.json SHA256 6f615a3666fb3f25a497d87bded3489d1d5cd6f26988016d6c9370b403b70e35
- original M LOCK.json SHA256 d9d7b910a591b9345ae92033177a404ce360bcc69d6aaec71e425702e2b3ea5b
- original raw review.json SHA256 3368f1bfa8e446d5a4d882f751b6ef1c57f66cd5a10c82a6c6f8dddeb65877e3
