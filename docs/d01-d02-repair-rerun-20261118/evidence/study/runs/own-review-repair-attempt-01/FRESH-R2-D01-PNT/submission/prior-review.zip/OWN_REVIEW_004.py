"""Within-method audit: disable only the typography-sensitive CH2 (9.1) input."""
from pathlib import Path
from fractions import Fraction as F
p=Path('/work/review-input/mertens.py')
s=p.read_text()
s=s.replace("if 5*L.hi<=138*S: wcap=mn(w,I('.8')*r)", "if False: wcap=mn(w,I('.8')*r)")
s=s.replace("if L.hi<=27*S:", "if False:")
ns={"__name__": "ablation"}
exec(compile(s,str(p),'exec'),ns)
ns['test_early_power']('.0215')
for row, (l,p) in enumerate([(16,[(3,'.185')]*3+[(2,'.175')]),(F('17.83'),[(3,'.09')]*3+[(2,'.09')]),(22,[(4,'.5')]*3+[(3,'.5')]),(34,[(5,'4')]*3+[(4,'4')]),(56,[(6,'.3')]*3+[(5,'.3')])]):
    for part in [p[:3]+[(0,0)],[(0,0)]*3+p[-1:]]:
        try: ns['test_poly'](l,240,part)
        except ValueError as e: print('noncertificate (not a counterexample)',l,part,e)
