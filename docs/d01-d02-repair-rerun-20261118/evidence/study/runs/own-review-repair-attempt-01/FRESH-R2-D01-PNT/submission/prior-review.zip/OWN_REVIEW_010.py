"""Ancillary checks of locked formulas; does not change candidate files."""
import json, hashlib
from pathlib import Path
from fractions import Fraction as F
from ramanujan import *
from pdf_stream import get
root=Path('/corpus/originals')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for d in json.loads(Path('/task/SOURCE_INDEX.json').read_text())['sources']:
    for fmt in ('pdf','text'):
        p=root/d[fmt]
        assert sha(p)==d[fmt+'_sha256']
        print('source SHA256',p.name,sha(p))
idx=json.loads(Path('/task/CANDIDATE_INDEX.json').read_text())
for d in idx['candidate_files']:
    p=Path('/task')/d['packet_name']; q=Path('/work/review-input')/d['original_name']
    assert sha(p)==sha(q)==d['sha256']
    print('candidate SHA256',p.name,q.name,sha(q))
for fn,pages in [('CH2',[3,22,35,36,43]),('Dusart2018',[3,4,7,8,11,13,14,17,18,19,20]),('DudekPlatt1407.1901v1',[2,8,9,10]),('FKS',[2,4,5,7,8,22,23,26]),('OpenAIQRH',[4]),('PlattTrudgianFiniteRH',[2,4,5]),('PlattTrudgian1809.03134v2',[2,3])]:
    for pn in pages:
        k,v,c,objs=get(str(root/(fn+'.pdf')),pn)
        print('original PDF page',fn,pn,'object',k,'decoded objects and SHA256',[(j,hashlib.sha256(s).hexdigest()) for j,s in c])
for L,T,V in [(I(200),4*ex(I(25)),10*ex(I(25))),(I(100),ex(I(50))/6,ex(I(50)))]:
    assert low(T,L) and low(T,51) and low((ex(L/2)-2)/5,T) and low(V,F(245,100)*T)
assert low(ex(I(58)),1) and low(I('2.169e25'),ex(I(58)))
assert low(ex(I('6.5')),599) and low(ex(I(8)),2657)
assert low(I(10**13),ex(I('29.9'))) and low(ex(I(13)),10**4) and low(I(10**12+3),ex(I('27.6')))
for l,q in [(34,F(1,2)),(34,F(13,20)),(35,F(2,5))]:
    assert low(q*ex(I(l)/2),10**7) and low(H,q*ex(I(58)/2))
assert low(ex(I(30)),10**9)
assert low(ex(I(100)),767135587)
assert low(I('.3'),(I('.0196')/I('.3'))*200**5*ex(I(-25)))
def rr(x):
    x=I(x);return E*x/x.log()*632207037-1644673232**2
assert low(0,rr('38358837682.125'))
assert low(0,rr('38358837682.217926365'))
assert low(rr('38358837682.217926366'),0)
print('endpoint examples, source triggers, overlap ratio, and checks: PASS')
# Pairwise crossings of .0215 power branch against the five log-power rows.
for start,k,c in [('16',2,'.185'),('16',2,'.175'),('17.83',2,'.09'),
                  ('22',3,'.5'),('34',4,'4'),('56',5,'.3')]:
    def ratio(L):
        return I('.0215')/I(c)*L**k*ex(-L/8)
    assert low(ratio(I(start)),1) and low(1,ratio(I(200)))
    print('unique crossover before 200 on descending side',start,k,c)
